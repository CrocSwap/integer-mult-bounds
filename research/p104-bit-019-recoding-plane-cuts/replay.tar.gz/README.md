# Exclude recoding on the funded 0→19 topology in named planes

Allow every surviving paid row to change within each named binary difference subspace and give arbitrary full causal scheduling and stock retention. Fix original productive endpoints and keep the extra 0→19 value within the same plane.

Exact GF(2) stock relations exclude the three-axis plane and eight enlargements through dimension seven. Independent terminal-only cores attest the three- and four-axis cases; freeing the forbidden chart-421 direction supplies a positive relaxation canary.

Permit changed coefficients outside these named spans or alter funded incidence. Apply the full origin and adjoint gate to any candidate.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. Both clean manifests, Python standard-library replay of all saved exhaustive projection cases and a separate literal-tape audit with explicit XOR contradictions and satisfiable overgrant controls passed.
