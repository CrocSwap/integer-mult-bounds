#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Verify complete extracted and optional tar inventory, not only listed files."""
if not __debug__:
    raise RuntimeError('Assertions must be enabled')
from hashlib import sha256
from pathlib import Path, PurePosixPath
import sys
import tarfile
ROOT=Path(__file__).resolve().parent

def main():
    raw=(ROOT/'SHA256SUMS').read_bytes()
    expected={}
    for line in raw.decode().splitlines():
        h,name=line.split('  ',1)
        p=PurePosixPath(name)
        assert len(h)==64 and all(c in '0123456789abcdef' for c in h)
        assert not p.is_absolute() and '..' not in p.parts and str(p)==name
        assert name not in expected
        expected[name]=h
    actual=set()
    for p in ROOT.rglob('*'):
        assert not p.is_symlink() and '__pycache__' not in p.parts and p.suffix!='.pyc'
        if p.is_file() and p!=ROOT/'SHA256SUMS':
            name=p.relative_to(ROOT).as_posix()
            actual.add(name)
            assert sha256(p.read_bytes()).hexdigest()==expected.get(name),name
    assert actual==set(expected)
    if '--archive' in sys.argv:
        path=sys.argv[sys.argv.index('--archive')+1]
        with tarfile.open(path,'r:gz') as archive:
            members=archive.getmembers()
            assert len(members)==len({m.name for m in members})
            assert all(m.isfile() and not m.issym() and not m.islnk() for m in members)
            assert {m.name for m in members}==set(expected)|{'SHA256SUMS'}
            for member in members:
                data=archive.extractfile(member).read()
                if member.name=='SHA256SUMS': assert data==raw
                else: assert sha256(data).hexdigest()==expected[member.name]
    print('PASS_COMPLETE_INVENTORY',len(actual),'manifested files plus manifest')

if __name__=='__main__': main()
