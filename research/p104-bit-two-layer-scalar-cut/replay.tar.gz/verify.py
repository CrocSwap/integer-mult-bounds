#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Raw-tape, two-layer donor graph and four-receipt necessary price screen."""
if not __debug__:
    raise RuntimeError('Assertions must be enabled')
from collections import Counter
from contextlib import redirect_stdout
from decimal import Decimal
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, combinations_with_replacement
from pathlib import Path, PurePosixPath
import io
import json
import runpy
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT/'base-e0602007.tar.gz'
BASE_SHA = 'e06020078e62d62e58f5ff01241b680b3671e063714c15480b3c6fb419946704'
SEEDS = [(3315,3316,3317,528,344),(3386,3387,3388,586,356)]
assert sha256(BASE.read_bytes()).hexdigest() == BASE_SHA

# Independently implement low-pivot membership, on raw punctured values, not
# the base screen's Span or propagated packet-graph evaluation.
def add(b, row):
    while row:
        p = (row & -row).bit_length()-1
        if p not in b:
            b[p] = row
            return
        row ^= b[p]

def contains(b, row):
    while row:
        p = (row & -row).bit_length()-1
        if p not in b:
            return False
        row ^= b[p]
    return True

def witness(choices, target):
    b = {}
    for i, (_, _, row) in enumerate(choices):
        label = 1 << i
        while row:
            p = (row & -row).bit_length()-1
            if p not in b:
                b[p] = (row,label)
                break
            u,v = b[p]
            row ^= u
            label ^= v
    label = 0
    while target:
        p = (target & -target).bit_length()-1
        assert p in b
        u,v = b[p]
        target ^= u
        label ^= v
    picked = [(group, name, row) for i,(group,name,row) in enumerate(choices) if (label>>i)&1]
    return {group: [name for g,name,_ in picked if g==group]
            for group in ('receiver','sender','donor0','donor1')}, picked

def case(raw, params, prices):
    k,j,carrier,receiver,sender = params
    hist,moves,_,_,_ = raw['run']((k,j))
    clock,actual_sender,actual_receiver,_ = moves[carrier]
    assert (actual_sender,actual_receiver)==(sender,receiver)
    owners = [i for i,d in enumerate(raw['w']['final']) if d==receiver]
    assert len(owners)==1
    owner = owners[0]
    target = raw['expected'][owner]
    receiver_rows = [(label,row) for label,_,row in hist[receiver] if label!=carrier]
    sender_rows = [(label,row) for label,t,row in hist[sender] if t<clock]
    assert all(label not in (k,j) for label,_ in receiver_rows+sender_rows)
    base = {}
    for _,row in receiver_rows+sender_rows:
        add(base,row)
    assert not contains(base,target)
    donors = {}
    for donor, events in sorted(hist.items()):
        grade = raw['grade'](donor,sender)
        if donor==sender or grade is None or grade==0:
            continue
        rows = [(label,row) for label,t,row in events if t<clock]
        if rows:
            assert all(label not in (k,j) for label,_ in rows)
            donors[donor] = (grade,rows)
    assert len(donors) == (50 if carrier==3317 else 52)
    assert all(1<=g<=6 for g,_ in donors.values())

    @lru_cache(None)
    def supplies(ids):
        b = base.copy()
        for donor in ids:
            for _,row in donors[donor][1]:
                add(b,row)
        return contains(b,target)

    assert all(not supplies((d,)) for d in donors)
    pairs = list(combinations(donors,2))
    edges = [list((a,b)) for a,b in pairs if supplies((a,b))]
    assert edges==[[0,1],[0,506]]
    edge_set = {frozenset(e) for e in edges}
    triangles = [list(t) for t in combinations(donors,3)
                 if all(frozenset(e) in edge_set for e in combinations(t,2))]
    assert not triangles
    pair_digest = sha256(''.join(f'{a},{b},{int(supplies((a,b)))}\n' for a,b in pairs).encode()).hexdigest()

    # A four-vector realization requires a 2D code in its four coefficients.
    # See README: after excluding weight 1 and triangle (2,2,2), its support
    # weights are (2,2,4) or (2,3,3). The latter needs both useful triples.
    admitted = []
    for a,b in edges:
        for x,y in combinations_with_replacement(donors,2):
            def useful(*ids):
                return supplies(tuple(sorted(set(ids))))
            paired = useful(x,y)
            triples = useful(a,x,y) and useful(b,x,y)
            if paired or triples:
                ids = [a,b,x,y]
                grades = sorted(donors[d][0] for d in ids)
                admitted.append({'donors':ids,'one_layer_grades':grades,
                                 'second_pair_necessary_test':paired,
                                 'both_triples_necessary_test':triples})
    assert len(admitted)==4
    assert all(r['one_layer_grades']==[2,2,6,6] for r in admitted)
    assert all(r['second_pair_necessary_test'] for r in admitted)

    # Construct an explicit free-stock decomposition for useful edge (0,1).
    choices = ([('receiver',n,x) for n,x in receiver_rows]
               + [('sender',n,x) for n,x in sender_rows]
               + [('donor0',n,x) for n,x in donors[0][1]]
               + [('donor1',n,x) for n,x in donors[1][1]])
    selected, picked = witness(choices,target)
    check = 0
    for _,_,row in picked:
        check ^= row
    assert check==target and selected['donor0'] and selected['donor1']

    K=Decimal('0.00388')
    cost=prices.ZERO
    for g in [2,2,6,6]:
        cost=prices.plus(cost,prices.power(2*g,K))
    removed=prices.scale(prices.plus(prices.power(8,K),prices.power(4,K)),2)
    delta=prices.scale(prices.minus(removed,cost),36)
    assert delta[1]<0
    return {'carrier':carrier,'holes':[k,j],'owner':owner,'receiver':receiver,
            'sender':sender,'clock':clock,'donors_by_one_layer_grade':dict(sorted(Counter(str(g) for g,_ in donors.values()).items())),
            'one_donor_failures':len(donors),'donor_pairs_tested':len(pairs),
            'useful_pairs':edges,'pair_decision_sha256':pair_digest,'useful_pair_triangles':0,
            'four_receipt_necessary_combinations':admitted,
            'one_layer_pair_0_1_decomposition':selected,
            'four_replicated_receipt_grades':[4,4,12,12],
            'minimum_four_receipt_charge_per_paired_incidence':prices.display(cost),
            'maximum_36_incidence_removed_less_four_receipt_charge':prices.display(delta)}

def main():
    # All combinations of two independent vectors in F2^4, represented by
    # their three nonzero sums. Every 2D coefficient code occurs once.
    codes={tuple(sorted((a,b,a^b))) for a in range(1,16) for b in range(a+1,16)}
    assert len(codes)==35
    weights=Counter(tuple(sorted(x.bit_count() for x in c)) for c in codes
                    if min(x.bit_count() for x in c)>1)
    assert weights=={(2,2,2):4,(2,2,4):3,(2,3,3):6}
    # Synthetic positive control: the same two-copy model with a useful-pair
    # triangle can need exactly three receipts and restore both target rows.
    q,z0,z1=1,2,4
    A=((z0,z1),(z0^q,z1),(z0,z1^q))
    for donor in A:
        b={}
        for row in donor: add(b,row)
        assert not contains(b,q)
    for a,bidx in combinations(range(3),2):
        b={}
        for row in A[a]+A[bidx]: add(b,row)
        assert contains(b,q)
    w0=z0^(z1<<3)
    w1=(z0^q)^(z1<<3)
    w2=z0^((z1^q)<<3)
    assert w0^w1==q and w0^w2==q<<3
    with tempfile.TemporaryDirectory(prefix='p104-three-receipt-') as tmp:
        d=Path(tmp)
        with tarfile.open(BASE,'r:gz') as tar:
            names=[]
            for member in tar.getmembers():
                path=PurePosixPath(member.name)
                assert member.isfile() and not path.is_absolute() and '..' not in path.parts
                names.append(member.name)
            assert len(names)==len(set(names))
            tar.extractall(d,filter='data')
        for args in ([str(d/'verify_manifest.py'),'--archive',str(BASE)],
                     [str(d/'early-receipt-terminal-carriers/verify_raw.py'),'--verify'],
                     [str(d/'screen.py'),'--verify']):
            subprocess.run([sys.executable,'-I','-B',*args],cwd=d,check=True,
                           stdout=subprocess.DEVNULL)
        saved_argv=sys.argv
        try:
            sys.argv=[str(d/'early-receipt-terminal-carriers/verify_raw.py'),'--verify']
            with redirect_stdout(io.StringIO()):
                raw=runpy.run_path(sys.argv[0],run_name='raw_proof')
            # Import only the pinned directed tariff helper from the base.
            sys.argv=[str(d/'screen.py'),'--verify']
            with redirect_stdout(io.StringIO()):
                base=runpy.run_path(sys.argv[0],run_name='base_proof')
        finally:
            sys.argv=saved_argv
        cases=[case(raw,seed,base['prices']) for seed in SEEDS]
    result={'schema':'p104-two-carrier-three-receipt-cut/1',
            'base_archive_sha256':BASE_SHA,'rate':'0.00388',
            'method':'Raw primitive puncture histories, separate low-pivot GF(2) membership, and exhaustive useful pair and necessary triple checks.',
            'two_dimensional_binary_codes_with_no_weight_one':{'2,2,2':4,'2,2,4':3,'2,3,3':6},
            'three_receipt_obstruction':'Each single donor misses the 2D target and its useful-pair graph is triangle-free.',
            'synthetic_triangle_control':'Three lifted donors each miss the target alone, every pair is useful, and three explicit mixed-layer receipts recover both targets.',
            'price_scope':'Omitted versus added contacts only; no carrier repricing, complete invoice or physical realization.',
            'cases':cases}
    output=json.dumps(result,sort_keys=True,indent=2)+'\n'
    if '--write' in sys.argv:
        (ROOT/'RESULT.json').write_text(output)
    else:
        assert (ROOT/'RESULT.json').read_text()==output, 'frozen result mismatch'
    print('PASS_RAW_PAIR_TRIPLE_AND_PRICE',[(c['carrier'],c['donor_pairs_tested']) for c in cases])

if __name__=='__main__':
    main()
