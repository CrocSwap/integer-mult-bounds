# Three receipts still cannot repair two replicated terminal carriers

For each of two separately tested punctured copies of the #7830 binary word,
at least **four scalar receipts** are necessary to restore the two independent
layer targets under the fixed-stock model below. The earlier two-receipt cut
is retained in the embedded, resealed base archive. This is a bounded GF(2)
obstruction and a partial tariff comparison. It is not a proposed native
supplier, a complete caller invoice, or a new κ bound.

The exact base archive is `base-e0602007.tar.gz`, SHA-256
`e06020078e62d62e58f5ff01241b680b3671e063714c15480b3c6fb419946704`.
It contains the source word and #7985 supplement, their manifests and retained
Apache-2.0 contributor notices, its two-layer proof, its independent raw-tape
verification, and the original two-receipt screen. The native is #7830 at
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` (canonical word SHA-256
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`).
The base also cites #7985 at `251e15df3e0c058a843e7cb13f5882179a4e3afc`
and the distinct #7983 model at `5f393bfc838276228ff8adfee9c5625d8ce9197f`.

## Scope and exact graph

The two cases are separate experiments; their charts need not coincide.

| Holes in each layer | Carrier | Sender → receiver | Clock | Target owner | Nested old donors |
| --- | ---: | --- | ---: | ---: | ---: |
| 3315, 3316 | 3317 | 344 → 528 | 12248 | 114 | 50 |
| 3386, 3387 | 3388 | 356 → 586 | 18011 | 172 | 52 |

Replicate the one-layer public-input space and old chart geometry twice, with
independent inputs. Zero the listed old packets in each layer and replay every
surviving paid equation. The carrier has no surviving paid descendant. Its
two scalar sends may be freely re-encoded across layers, and its receiver may
freely re-decode. All strict-preclock old sender/receiver stock is freely
retained. A new receipt is one GF(2) scalar, an arbitrary XOR of both layer
histories at **one** old donor nested with the sender, delivered at the cut.
Donor histories and all other paid routes/equations stay fixed; no newly
constructed mixed-donor chart or retiming is granted. Exterior decoding is
optimistic. These assumptions reproduce the base archive's incidence model,
while allowing three and then four receipts for this extension.

Let `B` be the punctured receiver stock with the carrier removed, and `S`
the strict-preclock sender stock. In each case its one missing target has a
nonzero image `q` modulo `B+S`. For an old donor `d`, write `U_d` for its
one-layer punctured history modulo `B+S`. The verifier uses actual primitive
MOVE histories and a separate low-pivot reducer to test whether
`q ∈ U_a+U_b` for every unordered pair of distinct eligible donors. No single
donor supplies `q`. There are exactly **two** useful pairs in each case:

```
{0,1}, {0,506}
```

Donor 0 has one-layer grade 6; donors 1 and 506 have grade 2. The 3317 case
checks 1,225 pairs and the 3388 case checks 1,326. Both pair graphs are
triangle-free. `RESULT.json` pins all-pair decision digests and includes a
literal XOR decomposition witnessing `{0,1}` in each case. The decomposition
is an optimistic stock statement, not a schedule or physical copying proof.

## Why three scalar receipts fail

After quotienting the two-copy space by `(B+S)⊕(B+S)`, the required target
space is `T = span{(q,0),(0,q)}`, which has dimension two. Since no single
old donor supplies `q`, its two-layer space has zero intersection with `T`.
If at most two receipts span `T`, each receipt belongs to `T`, impossible.
Suppose three do. They must be linearly independent (otherwise two suffice),
and their span modulo `T` has dimension one. Each receipt has the same
nonzero image there, so each pairwise sum is in `T`. Those three sums must be
the three distinct nonzero vectors of `T`. For any pair, a nonzero layer of
that sum expresses `q` using precisely the pair's one-layer donor histories.
Thus every pair among the three donor charts must be an edge of the useful
pair graph. Reusing the same donor cannot provide a nonzero pair sum in `T`.
The graphs above have no triangle, so three receipts cannot suffice. A
synthetic lifted two-layer control with a useful-pair triangle verifies that
three scalar receipts can recover both targets when this hypothesis changes.

## Four-receipt necessary tariff

Assume four receipts restore both targets. Their four vectors must be
independent, or three would suffice. Their coefficient vectors which map into
`T` form a two-dimensional binary code of length four. It has no weight-one
word. Exhaustively, its possible nonzero support-weight patterns are
`(2,2,2)`, `(2,2,4)`, and `(2,3,3)`; `verify.py` checks all 35 binary
2-dimensional codes. The first pattern requires a useful-pair triangle and
is impossible. The second requires two useful pairs. In the third, writing
its weight-two support as `{a,b}` and the remaining positions as `{x,y}`,
both donor triples `{a,x,y}` and `{b,x,y}` must independently supply the
one-layer `q`. This is a necessary test only: it generously allows separate
witnesses for the triples.

The verifier checks these pair and triple conditions for every eligible donor
combination, including repeated donor charts. In both cases, every combination
that survives the necessary test has one-layer receipt-grade multiset
`{2,2,6,6}`. Thus in fully replicated geometry the four scalar receipts have
grades `{4,4,12,12}`. At `H(g)=g^(1−0.00388)`, the two copies' four
omissions remove `2H(8)+2H(4)` per paired incidence, and the four receipts
cost at least `2H(12)+2H(4)`. Directed interval arithmetic gives

```
36 × (2H(8)+2H(4) − 2H(12)−2H(4))
  ∈ [−284.338431427061627418, −284.338431427061627417].
```

The interval shown here is rounded outward; `RESULT.json` gives the full
90-digit interval. This is only the omitted-versus-added-contact change. It
omits the retained carrier repricing and all other caller charges and does
not establish a complete invoice or κ result. Repeating the `{0,1}` one-layer
stock witness in both independent layers supplies both quotient targets with
four scalar receipts in this optimistic algebraic model; it does not prove
physical retention, erasure, timing or actual donor delivery.

The result does not cover more than four receipts, changed upstream equations,
new donor charts combining old charts, non-replicated or regraded endpoints,
retiming, altered receiver histories, other holes/carriers, vector-valued
contacts, another caller or a physical compiler. Positive constructions in
those spaces require a complete signed and productive invoice, finite and
physical replay, precision and outer obligations.

## Offline reproduction

Use CPython 3.12 with assertions enabled and the standard library. Extract this
archive into an empty directory, then run:

```sh
sha256sum -c SHA256SUMS
python3 -IB verify_manifest.py --archive /path/to/this-archive.tar.gz
python3 -IB verify.py
```

The manifest verifier rejects unlisted files, caches, symlinks and extra or
changed archive members. The main verifier extracts the pinned base to an
isolated temporary directory, verifies the complete nested inventory and base
archive, executes the base's raw and two-layer checks, then reconstructs the
new pair, triple and directed-price results and compares them byte-for-byte
with `RESULT.json`. It evaluates actual punctured raw-tape values with a
separate low-pivot elimination; it does not reuse the base screen's span
engine. `--write` is available for deterministic certificate regeneration.
