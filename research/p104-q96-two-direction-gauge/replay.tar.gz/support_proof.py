#!/usr/bin/env python3
"""Exact support certificate for the two-port, two-basis singleton gauge.

For any u in GF(2)^9, its exceptional set for an output support D is
E_u={t in D: u dot L[t]=1}. After deleting ports p,q, u is orthogonal to
D minus {p,q} iff E_u subset {p,q}. Two distinct nonzero orthogonal vectors would
be linearly independent, so having at most one such vector proves span >=8.
"""
import itertools,json
from collections import Counter
import check

L,G,X,C=check.load()
mask=lambda v:sum(1<<i for i,x in enumerate(v) if x)
parity=[sum(1<<i for i,l in enumerate(L) if check.dot(u,l)) for u in range(512)]
pairs=[(p,q,(1<<p)|(1<<q)) for p,q in itertools.combinations(range(96),2)]
cases=[]
for i in range(8):
    cases.append((i,None,'singleton',mask(X[i])))
for i,j in itertools.combinations(range(8),2):
    for r in check.choices(X[i],X[j]):
        v=[r.denominator*x-r.numerator*y for x,y in zip(X[i],X[j])]
        assert any(v)
        cases.append((i,j,str(r),mask(v)))
# Opposite orders are covered because W_j-rW_i is a nonzero scalar multiple
# of W_i-(1/r)W_j. Finite nonzero rational exceptions plus generic support
# also exhaust all real nonzero r.
assert len(cases)==91 and len({item[3] for item in cases})==91
hist=Counter();baseline=Counter();loss_pair_counts=Counter(); sampled=0
for case_i,(i,j,ratio,d) in enumerate(cases):
    b=check.f2rank(L[t] for t in range(96) if d>>t&1)
    baseline[b]+=1
    exceptional=[(u,d&parity[u]) for u in range(1,512) if (d&parity[u]).bit_count()<=2]
    for p,q,pmask in pairs:
        normals=[u for u,e in exceptional if e & ~pmask == 0]
        assert len(normals)<=1, (i,j,ratio,p,q,normals)
        rank=9-len(normals)
        hist[rank]+=1
        if rank<b:loss_pair_counts[(p,q)]+=1
        # Independent direct GF(2) elimination across structured cases.
        if (case_i*4560+p*96+q)%199==0:
            direct=check.f2rank(L[t] for t in range(96) if d>>t&1 and t!=p and t!=q)
            assert direct==rank
            sampled+=1
assert sum(hist.values())==91*4560 and min(hist)==8

# Intake supports for nonzero real combinations: endpoints and exact special
# cancellation ratios + a generic. First/second row order is irrelevant.
intakes=0; singleton_checks=0; ih=Counter()
for a,b in itertools.combinations(range(8),2):
    choices=[C[a],C[b]]
    for r in check.choices(C[a],C[b]):
        choices.append([r.denominator*x-r.numerator*y for x,y in zip(C[a],C[b])])
    for c in choices:
        basis=check.independent(L[t] for t,x in enumerate(c) if x)
        assert len(basis)>=8
        ih[len(basis)]+=1;intakes+=1
        for p in range(96):
            assert any(check.dot(L[p],y) for y in basis)
            singleton_checks+=1
assert intakes==140 and singleton_checks==13440
best=sorted(loss_pair_counts.items(), key=lambda kv:(-kv[1],kv[0]))
result={'output_unoriented_support_cases':len(cases),
        'baseline_support_span_histogram':dict(sorted(baseline.items())),
        'distinct_port_pairs':len(pairs),
        'two_deletion_cases':sum(hist.values()),
        'two_deletion_support_span_histogram':dict(sorted(hist.items())),
        'direct_independent_elimination_samples':sampled,
        'port_pairs_losing_at_least_one_output_span_dimension':len(loss_pair_counts),
        'most_weak_pairs':[[list(k),v] for k,v in best[:10]],
        'intake_support_cases':intakes,'intake_span_histogram':dict(sorted(ih.items())),
        'singleton_intake_pairing_checks':singleton_checks,
        'all_singleton_intake_pairings_rank_one':True,
        'two_direction_chain_price_floor':58}
print(json.dumps(result,indent=2,sort_keys=True))
