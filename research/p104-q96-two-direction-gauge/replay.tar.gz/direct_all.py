#!/usr/bin/env python3
"""Independently Gaussian-eliminate all output support/deletion cases."""
import itertools,json
from collections import Counter
import check
L,G,X,C=check.load()
vecs=list(X)
for i,j in itertools.combinations(range(8),2):
    for r in check.choices(X[i],X[j]):
        vecs.append([r.denominator*x-r.numerator*y for x,y in zip(X[i],X[j])])
assert len(vecs)==91
hist=Counter()
for v in vecs:
    supported=[(L[t],t) for t,x in enumerate(v) if x]
    for p,q in itertools.combinations(range(96),2):
        hist[check.f2rank(l for l,t in supported if t!=p and t!=q)]+=1
assert hist=={8:42085,9:372875}
print(json.dumps({'direct_elimination_cases':sum(hist.values()),
                  'direct_elimination_span_histogram':dict(sorted(hist.items()))},indent=2,sort_keys=True))
