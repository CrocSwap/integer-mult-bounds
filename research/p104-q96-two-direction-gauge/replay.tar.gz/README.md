# Q96: two independent singleton gauges in eight lifetimes

For the fixed eight-row E8 decoder from [#7898](https://github.com/CrocSwap/integer-mult-bounds/pull/7898) at `48c99e161e92bc40f925d818a8f5c7a5e0baab0f`, this packet proves that the two-singleton family below has exact minimum support-pairing chain price **58**. An explicit legal pinned-engine run attains **R = 58** with ten nonzero epochs in eight lifetimes. Its output and intake factor ranks are **(10,8)** both before and after converting Abel tails to signed epoch increments. This family therefore does not reach 55.

The lower bound covers *all* distinct Q96 ports, all real rank-two coefficient matrices supported on two original rows, all nonzero real row rescalings, and every ordered partition of the ten rows into lifetimes, including two disjoint pairs and a triple. It applies to the cold-intake support-pairing chain price and, via the #7869 chain law, is a lower bound on the pinned-model R for such a run. It is not a result for another E8 basis, three-or-more-row gauge coefficients, general rank-(10,8) chains, hot relays, arbitrary word implementations, or a kappa gain.

## Sources and definitions

The E8 vectors and `check.py` are taken from the locally supplied #7898 replay packet. The #7898 public PR at the specified head identifies its archived replay SHA-256 as `1241ed8cc50ea4395593d456dab1293cb0a588796cb76c34082fde014491c41b`. The two underlying independently pinned source files are included and their identities checked:

* [#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852), commit `41beda1d6435760dc99e38bd7e65f36798aad212`, `source/7852/DecoderWall4Data.lean`: Git blob `90949f8d5dbcdee99974de505018768f4f9f640e`.
* [#7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869), commit `06c207a9feb3994a4b987dc3010657b6e85b7956`, `source/7869/eng.py`: Git blob `cad7f0d954221c6806533efbe757d659162c27e0`, SHA-256 `900b41f42c978e2bca2db001a5dc81dc93953adb5e842a4924d37c860124c2f6`.

Let `X_i,V_i`, `0 <= i < 8`, denote #7898's exact rational decoder; the local checker reconstructs it from #7852, verifies its eight support-pairing prices are 7 and verifies `sum X_i V_i^T = -G/2` on the entire 96-by-96 matrix. Use two distinct ports `p,q`, with unit singleton outputs `e_p,e_q`. Pick original rows `a != b` and real coefficients `alpha_i,beta_i` supported only on `{a,b}` such that

```
det [[alpha_a, beta_a], [alpha_b, beta_b]] != 0.
W_i = X_i + alpha_i e_p + beta_i e_q      C_i = V_i          (0 <= i < 8)
W_8 = e_p                                  C_8 = -alpha_a V_a - alpha_b V_b
W_9 = e_q                                  C_9 = -beta_a  V_a - beta_b  V_b.
```

All ten factors are nonzero. Both gauge terms cancel exactly, so `sum W_i C_i^T = -G/2`. Because the eight original intake rows are independent and the coefficient matrix is rank two, each compensator is nonzero. The checker finds three *disjoint* eight-row bases in the 96-by-8 output matrix. Any two deleted ports leave one basis intact. Consequently `e_p,e_q` are independent modulo `span(X)`, and the Abel output rank is 10 for every distinct `p,q`; the intake rank is 8. Row rescalings and the invertible Abel-to-increment map preserve both ranks.

## Proof of the floor

For an ordered lifetime whose rescaled Abel output tails are `T_1,...,T_k`, the *actual* outputs are `T_1-T_2,...,T_(k-1)-T_k,T_k`, with the correspondingly inversely scaled fresh intake vectors. These signed differences, rather than the Abel tails themselves, must be priced. For a nonzero epoch `(w,c)`, its support-pairing price is

```
rank over GF(2) of [ parity(label[t] & label[s]) ]
                  t in supp(w), s in supp(c).
```

`support_proof.py` verifies the following finite facts from the pinned labels:

1. For every single `X_i` and every nonzero two-row combination `X_i-r X_j`, removing any two distinct ports leaves output-label span at least 8. The 91 distinct unoriented supports consist of the eight single rows and, for each pair, every exact coordinate-cancellation ratio plus a generic nonzero ratio. These cases are exhaustive even for real `r`. Over all 4,560 port pairs, the resulting 414,960 support spans have histogram `{8: 42085, 9: 372875}`.
2. For every nonzero real combination of any two `V_i`, its intake-label span is at least 8. All 140 endpoint, exceptional-ratio and generic intake cases pass; each of the 96 singleton port labels pairs nontrivially with every intake support (13,440 checks).

For fact 1, the code enumerates all nonzero vectors `u` of the nine-dimensional binary label space. Let `E_u` be the supported ports with `u dot label[t]=1`. After deleting `p,q`, `u` is orthogonal to the remaining support exactly when `E_u` is contained in `{p,q}`. At most one nonzero `u` qualifies for every case; two different nonzero vectors over GF(2) would be independent, so the span dimension is at least 8. Direct binary Gaussian elimination cross-checks 2,089 selected cases.

Every original-row epoch has, outside `p,q`, either a nonzero multiple of `X_i` or a nonzero `X_i-r X_j`. Its intake is a nonzero multiple of `V_i`. The two spans are at least 8 in a nondegenerate nine-dimensional pairing space; thus its price is at least `8-(9-8)=7`. This gives at least `8*7=56`.

For each of the two compensator epochs, the fresh intake is a nonzero combination of `V_a,V_b`. If its next tail is another singleton, its own distinct port remains in the signed increment, whose pairing with the intake is nonzero. If the next tail is an original row, the increment has a full nonzero `X_j` outside `p,q` and pairs with rank at least 7. A last singleton likewise has price 1. Thus each compensator epoch costs at least 1, giving **58** in every order and every lifetime partition.

## Exact witness, chronology and controls

Choose weak ports `p=1,q=5` (labels 19 and 13), original rows 0 and 1, and coefficient matrix `[[1,1],[1,-1]]`, determinant -2. Deleting these two ports reduces the output-label span of each of `X_0-X_7` and `X_1-X_7` from 9 to 8; the test is not restricted to these ports.

The ordered two-epoch lifetimes are `(0,8)` and `(1,9)`, plus singletons 2 through 7. The actual increments in the pairs are

```
(X_0+e_5, V_0),             (e_1, -V_0-V_1)
(X_1+e_1-2e_5, V_1),       (e_5, -V_0+V_1).
```

The cumulative intakes at the second epochs are `-V_1` and `-V_0+2V_1`, respectively: these singleton outputs are nonzero receipt contributions, not zero-value padding. The ten epoch prices are `[7,1,7,1,7,7,7,7,7,7]`. The pinned #7869 engine replays 1,439 operations, with zero illegal operations and zero pinning errors, and verifies the full receipt `-G/2` and `-I` on every odd cell. Its ascents match the prices exactly, **R=58**.

The engine additionally checks all four choices of direction in these two ordered pairs. Their costs are 58, 65, 65 and 72. For the fixed triple of rows `(0,8,9)`, all six orders are replayed with costs 59, 59, 65, 66, 65 and 66. These samples show legal chart chronology; the analytical floor covers all pair and triple choices and all nonzero rescalings, not only these unit-scale replays.

A mutation that incorrectly treats the first Abel tail as its own increment produces 24 odd-cell violations. A separate `p=q=1` collapsed-direction control has factor ranks `(9,8)` and replay cost 58; it is not used as evidence for the rank-10 witness.

## Reproduce

```
python3 -B verify.py
python3 -B verify.py --direct-all
```

The first command validates the packet manifest, reruns the exhaustive support proof and all 11 rational engine replays, and compares exact JSON evidence. The second adds direct GF(2) Gaussian elimination of all 414,960 output-support and deletion cases, independently cross-checking the orthogonal-normal certificate. It uses only Python 3.10+ standard library and works from any current directory. The underlying source hashes are checked during the run. `SHA256SUMS` is a consistency manifest, not an independent signature of the referenced commits. Source notices and the Apache-2.0 license are preserved.
