# Source and attribution notice

The pinned E8 basis construction and `check.py` are copied from the local replay packet of PR #7898, attributed there to the contributing authors. This packet includes unchanged source files from `CrocSwap/integer-mult-bounds`:

* `source/7852/DecoderWall4Data.lean`, from PR #7852 at commit `41beda1d6435760dc99e38bd7e65f36798aad212`; its original notice is `source/7852/NOTICE.md`.
* `source/7869/eng.py`, from PR #7869 at commit `06c207a9feb3994a4b987dc3010657b6e85b7956`; its original notice is `source/7869/NOTICE.md`.

Both upstream packages identify their license as Apache License 2.0. The license text is included as `LICENSE`. `data.json` extracts the labels and packed Gram entries from the #7852 source. The other checks and evidence in this packet are new and do not imply endorsement by the upstream authors.
