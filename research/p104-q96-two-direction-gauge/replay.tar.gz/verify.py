#!/usr/bin/env python3
"""Verify the two-direction gauge proof and exact engine replay."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def manifest():
    rows={}
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        h,sep,name=line.partition('  ')
        p=Path(name)
        if not sep or len(h)!=64 or p.is_absolute() or '..' in p.parts or name in rows:
            raise ValueError('bad manifest entry')
        rows[name]=h
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'SHA256SUMS'}
    if actual!=set(rows):raise ValueError('files differ from manifest: '+str((sorted(set(rows)-actual), sorted(actual-set(rows)))))
    for name,h in rows.items():
        p=ROOT/name
        if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:
            raise ValueError('hash mismatch: '+name)
    return len(rows)

def run(script,evidence):
    p=subprocess.run([sys.executable,'-B',str(ROOT/script)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:raise RuntimeError(script+' failed: '+p.stderr)
    result=json.loads(p.stdout)
    if result!=json.loads((ROOT/'evidence'/evidence).read_text()):raise ValueError(script+' evidence differs')
    return result

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--direct-all',action='store_true',help='also directly eliminate all 414,960 output support/deletion cases')
    args=ap.parse_args()
    n=manifest()
    proof=run('support_proof.py','support_proof.json')
    x=run('experiment.py','experiment.json')
    print('Verified %d packet files.' % n)
    print('Two-deletion support spans: %d cases; minimum %d.' % (proof['two_deletion_cases'],min(map(int,proof['two_deletion_support_span_histogram']))))
    print('Arbitrary-real scoped chain-price floor: %d.' % proof['two_direction_chain_price_floor'])
    print('Q96 rank-(10,8) witness: R=%d, %d lifetimes, %d epochs, exact full receipts and legal chronology.' % (x['pair_orders'][0]['ascents'],x['pair_orders'][0]['lifetimes'],x['pair_orders'][0]['epochs']))
    print('All four pair orders, six triple orders, and rank-9 control replays passed.')
    print('Incorrect Abel-tail mutation violates %d odd cells.' % x['abel_tail_mutation_odd_violations'])
    if args.direct_all:
        direct=run('direct_all.py','direct_all.json')
        assert direct['direct_elimination_span_histogram']==proof['two_deletion_support_span_histogram']
        print('Direct GF(2) elimination checked all %d cases and matched the support proof.' % direct['direct_elimination_cases'])
    else:
        print('Pass --direct-all to cross-check every two-deletion case by direct GF(2) elimination.')

if __name__=='__main__':
    try:main()
    except (ValueError,RuntimeError,OSError,KeyError,json.JSONDecodeError) as e:
        print('Verification failed: '+str(e),file=sys.stderr)
        sys.exit(1)
