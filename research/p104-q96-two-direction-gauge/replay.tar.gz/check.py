#!/usr/bin/env python3
"""Exact nine-epoch chain screen on #7852 Q96; no third-party packages.

The nine rows are a deliberately bounded gauge of one particular 8-row E8
decoder.  This is NOT an exhaustive search of nine-row decoders.  Output and
intake matrices have independent scaling conventions documented below.
"""
import argparse
import hashlib
import itertools
import json
import re
from collections import Counter
from fractions import Fraction
from pathlib import Path

HERE = Path(__file__).resolve().parent
FRAME = [0, 6, 16, 22, 29, 36, 45, 95]
# These two 8-vectors live in the FRAME coordinate system. Their mutual dot
# product is a diagonal matrix with entries d_i = -2 or 2. They were found by
# scanning the 511 nonzero 9-bit normals and solving exact rational kernels.
Z = [[-1,1,0,-1,0,0,1,0], [1,-1,0,-1,0,0,1,0],
     [1,1,0,1,0,0,1,0], [0,0,-1,0,1,-1,0,1],
     [0,1,0,0,1,0,1,1], [0,-1,-1,-1,1,0,0,0],
     [1,-1,0,1,0,0,1,0], [0,0,0,-1,-1,1,1,0]]
Y = [[1,0,0,0,0,1,-1,1], [-1,0,-1,1,0,1,0,0],
     [-1,-1,1,0,0,0,0,1], [0,0,-1,0,-1,-1,0,1],
     [0,0,1,0,1,1,0,1], [0,0,1,0,-1,-1,0,1],
     [-1,-1,0,1,0,0,1,0], [0,0,-1,0,-1,1,0,1]]

def f2rank(values):
    basis = {}
    for x in values:
        while x:
            k = x.bit_length() - 1
            if k not in basis:
                basis[k] = x
                break
            x ^= basis[k]
    return len(basis)

def independent(values):
    basis = {}
    for x in values:
        while x:
            k = x.bit_length()-1
            if k not in basis:
                basis[k] = x
                break
            x ^= basis[k]
    return list(basis.values())

def qrank(vectors):
    rows = [[Fraction(v) for v in x] for x in vectors]
    rank = 0
    for col in range(len(rows[0])):
        pivot = next((i for i in range(rank, len(rows)) if rows[i][col]), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for i in range(rank+1, len(rows)):
            if rows[i][col]:
                m = rows[i][col]/rows[rank][col]
                rows[i] = [a-m*b for a,b in zip(rows[i], rows[rank])]
        rank += 1
        if rank == len(rows):
            break
    return rank

def dot(a, b):
    return (a & b).bit_count() & 1

def qprice(labels, w, c):
    # Compress each S-label into a basis; the rank of the 0/1 pairing matrix
    # over GF(2) is unchanged. This is NOT a rational rank of the pairing.
    sbasis = independent(labels[i] for i,x in enumerate(c) if x)
    return f2rank(sum(dot(lab, s) << k for k,s in enumerate(sbasis))
                  for lab,x in zip(labels,w) if x)

def span(basis):
    ret = {0}
    for x in basis:
        ret |= {v ^ x for v in ret}
    return ret

def perp(basis, n):
    return {u for u in range(1 << n) if all(not dot(u,v) for v in basis)}

def pair_cost(labels, w1, c1, w2, c2, n):
    """Least two-epoch ascent cost under free birth and descent, no relays.

    Taking the largest cold initial chart A1=C1^perp and the first output
    chart H=A1+span(D1) costs dim(H)-dim(A1). The best next intake chart is
    H intersect C2^perp. Enlarging H by k can reduce the second ascent by at
    most k, so no larger first output chart improves total cost.
    """
    c1b=independent(labels[i] for i,x in enumerate(c1) if x)
    c2b=independent(labels[i] for i,x in enumerate(c2) if x)
    w1b=independent(labels[i] for i,x in enumerate(w1) if x)
    w2b=independent(labels[i] for i,x in enumerate(w2) if x)
    a1=perp(c1b,n)
    h=span(independent(list(a1)+w1b))
    a2=h & perp(c2b,n)
    b2=span(w2b)
    dim=lambda sub: (len(sub)).bit_length()-1
    cost1=dim(h)-dim(a1)
    cost2=dim(b2)-dim(b2 & a2)
    return cost1+cost2, (cost1,cost2), (dim(a1),dim(h),dim(a2),dim(b2))

def load():
    data = json.loads((HERE/'data.json').read_text())
    raw = (HERE/'source'/'7852'/'DecoderWall4Data.lean').read_bytes()
    blob = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert blob == data['source_blob'] == '90949f8d5dbcdee99974de505018768f4f9f640e'
    assert data['source_commit'] == '41beda1d6435760dc99e38bd7e65f36798aad212'
    source=raw.decode()
    def parse(name):
        return list(map(int,re.findall(r'\d+',re.search(r'def '+name+r' : List ℕ := \[([\s\S]*?)\]',source).group(1))))
    assert data['labs']==parse('labs') and list(map(int,data['gramRows']))==parse('gramRows')
    labs=data['labs'][:96]
    assert len(labs)==96 and all(dot(q,q)==1 for q in labs)
    gram=[[((int(p)>>(2*j)) & 3)-1 for j in range(96)] for p in data['gramRows'][:96]]
    A=[[gram[t][j] for j in FRAME] for t in range(96)]
    assert all(gram[FRAME[i]][FRAME[j]] == 2*(i==j) for i in range(8) for j in range(8))
    assert all(sum(A[t][k]*A[s][k] for k in range(8)) == 2*gram[t][s] for t in range(96) for s in range(96))
    assert all(gram[t][s] == (2 if t == s else 0) for t in range(96) for s in range(96) if dot(labs[t],labs[s]))
    # The frame block is 2I. For p outside the frame e_p cannot be in col A;
    # for frame p it would require the corresponding A column to have no
    # second nonzero entry. Check that this never happens, so adding e_p
    # raises output rank from 8 to 9 for every one of the 96 choices.
    assert all(sum(bool(A[t][k]) for t in range(96)) > 1 for k in range(8))
    ds=[sum(a*b for a,b in zip(z,y)) for z,y in zip(Z,Y)]
    assert set(ds)=={-2,2} and all(sum(a*b for a,b in zip(Z[i],Y[j])) == (ds[i] if i==j else 0) for i in range(8) for j in range(8))
    # W[k] are actual integer output factors, C4[k] are four times the
    # actual signed intake factors. Both vectors are nonzero on Q96.
    W=[[-sum(row[j]*z[j] for j in range(8))//2 for row in A] for z in Z]
    C4=[[sum(row[j]*y[j] for j in range(8))*(1 if d>0 else -1) for row in A] for y,d in zip(Y,ds)]
    assert all(sum(row[j]*z[j] for j in range(8)) % 2 == 0 for row in A for z in Z)
    assert all(sum(W[k][t]*C4[k][s] for k in range(8)) == -2*gram[t][s] for t in range(96) for s in range(96))
    assert (qrank(W),qrank(C4)) == (8,8)
    assert [qprice(labs,w,c) for w,c in zip(W,C4)] == [7]*8
    return labs,gram,W,C4

def gauge(W0,C0,p,a,b):
    W=[v[:] for v in W0]+[[0]*96]
    C=[v[:] for v in C0]+[[-x-y for x,y in zip(C0[a],C0[b])]]
    W[a][p]+=1
    W[b][p]+=1
    W[8][p]=1
    assert all(any(x) for x in W+C)
    return W,C

def choices(u,v):
    # w1 = u-r v. Each nonzero r where a support coordinate vanishes is an
    # exact rational breakpoint. Every other nonzero rational has one generic
    # support, so one representative completely covers all scalings.
    special={Fraction(a,b) for a,b in zip(u,v) if a and b}
    generic=Fraction(1)
    while generic in special:
        generic += 1
    return sorted(special | {generic})

def screen(labs, W,C, witness_only=False):
    prices=[qprice(labs,w,c) for w,c in zip(W,C)]
    histogram=Counter()
    hits=[]
    best=100
    pair_count=0
    for i,j in itertools.permutations(range(9),2):
        pair_count+=1
        for r in choices(W[i],W[j]):
            a,b=r.numerator,r.denominator
            increment=[b*x-a*y for x,y in zip(W[i],W[j])]
            assert any(increment)
            total=sum(prices)-prices[i]+qprice(labs,increment,C[i])
            histogram[total]+=1
            if total < best:
                best=total
                hits=[(i,j,str(r),increment)]
            elif total == best:
                hits.append((i,j,str(r),increment))
    i,j,r,w=hits[0]
    # r merely scales second output, so use W[j] for the geometric chart.
    geometric,parts,dims=pair_cost(labs,w,C[i],W[j],C[j],9)
    realized=sum(prices)-prices[i]-prices[j]+geometric
    return {'abel_prices':prices,'abel_total':sum(prices),'ordered_pairs':pair_count,
            'support_cases':sum(histogram.values()),'price_histogram':dict(sorted(histogram.items())),
            'minimum':best,'minimizer':[i,j,r], 'minimizer_count':len(hits),
            'minimizer_chain_prices':[qprice(labs,w,C[i]),prices[j]],
            'minimizer_chart_cost':realized,'pair_chart_cost':parts,'pair_chart_dimensions':dims,
            'minimizer_first_support_size':sum(bool(x) for x in w)}

def q5_control():
    labels=[1,2,7,11,13]; n=5
    c1=[0,0,1,1,0]; c2=[1,1,0,0,0]
    w1=[-1,0,0,0,0];w2=[0,0,-1,-1,0]
    W1=[a+b for a,b in zip(w1,w2)]
    ep=[qprice(labels,w1,c1),qprice(labels,w2,c2)]
    abel=[qprice(labels,W1,c1),qprice(labels,w2,c2)]
    assert ep==[1,1] and abel==[2,1]
    g,parts,dims=pair_cost(labels,w1,c1,w2,c2,4)
    assert g==2
    odd={(t,s) for t in range(n) for s in range(n) if dot(labels[t],labels[s])}
    target={(0,2),(0,3),(2,0),(2,1),(2,2),(3,0),(3,1),(3,3)}
    got={(t,s) for t,s in odd if w1[t]*c1[s]+w2[t]*(c1[s]+c2[s])}
    assert got==target
    # Field-independent necessary support conditions for <=2 price. A single
    # nonzero rank-one term cannot hide a nonzero odd cell outside the target.
    # With two terms, any such unwanted cell must occur in both supports.
    subs=[tuple(i for i in range(n) if m>>i & 1) for m in range(1,1<<n)]
    rows={}
    for D in subs:
        for S in subs:
            ww=[int(i in D) for i in range(n)];cc=[int(i in S) for i in range(n)]
            p=qprice(labels,ww,cc)
            o=frozenset((t,s) for t in D for s in S if (t,s) in odd)
            if p<=2 and o: rows[o]=min(p,rows.get(o,3))
    one=sum(o==target for o in rows)
    two=sum(1 for o1,p1 in rows.items() for o2,p2 in rows.items()
            if p1+p2<=2 and target <= o1|o2 and not ((odd-target)&(o1^o2)))
    assert (one,two)==(0,0)
    return {'labels':labels,'chain_prices':ep,'abel_prices':abel,'explicit_chart_cost':g,
            'pair_chart_parts':parts,'target_cells':len(target),'mass_le_2_support_candidates':[one,two],
            'conclusion':'chain cost 2 < decoder mass 3, Q5 nonidentity target'}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--port',type=int,default=0)
    ap.add_argument('--a',type=int,default=0)
    ap.add_argument('--b',type=int,default=1)
    opt=ap.parse_args()
    labs,gram,W0,C0=load()
    assert 0<=opt.port<96 and 0<=opt.a<opt.b<8
    W,C=gauge(W0,C0,opt.port,opt.a,opt.b)
    assert (qrank(W),qrank(C))==(9,8)
    assert all(sum(W[k][t]*C[k][s] for k in range(9)) == -2*gram[t][s] for t in range(96) for s in range(96))
    result={'source_commit':'41beda1d6435760dc99e38bd7e65f36798aad212',
            'port':opt.port,'gauge_columns':[opt.a,opt.b],
            'base_prices':[qprice(labs,w,c) for w,c in zip(W0,C0)],
            'factor_ranks_Q':[qrank(W),qrank(C)],'completion_exact':True,
            'screen':screen(labs,W,C),'q5_positive_control':q5_control()}
    print(json.dumps(result,indent=2,sort_keys=True))

if __name__=='__main__': main()
