#!/usr/bin/env python3
"""Exact pinned engine replay of two-direction gauge, orders, and controls."""
from fractions import Fraction
from itertools import permutations
from pathlib import Path
import hashlib,json,sys
import check
ROOT=Path(__file__).resolve().parent
engine=ROOT/'source/7869/eng.py'
raw=engine.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='900b41f42c978e2bca2db001a5dc81dc93953adb5e842a4924d37c860124c2f6'
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()=='cad7f0d954221c6806533efbe757d659162c27e0'
sys.path.insert(0,str(engine.parent))
import eng
L,G,X,C4=check.load()
C0=[[Fraction(v,4) for v in c] for c in C4]

def gauge(p,q):
    W=[v[:] for v in X]+[[int(t==p) for t in range(96)], [int(t==q) for t in range(96)]]
    for i,aa,bb in [(0,1,1),(1,1,-1)]:
        W[i][p]+=aa;W[i][q]+=bb
    C=[v[:] for v in C0]+[[-x-y for x,y in zip(C0[0],C0[1])],[-x+y for x,y in zip(C0[0],C0[1])]]
    assert all(any(x) for x in W+C)
    assert all(sum(W[k][t]*C[k][s] for k in range(10)) == -Fraction(G[t][s],2) for t in range(96) for s in range(96))
    return W,C

def epochs(W,C,chains):
    # Exact Abel summation: each output increment is the row's tail minus
    # the next tail; the last increment is its own tail.
    out=[]
    for ch in chains:
        v=[]
        for t,i in enumerate(ch):
            w=([a-b for a,b in zip(W[i],W[ch[t+1]])] if t+1<len(ch) else W[i][:])
            c=C[i][:]
            assert any(w) and any(c)
            v.append((w,c))
        out.append(v)
    return out

def replay(W,C,chains):
    assert sorted(i for ch in chains for i in ch)==list(range(10)) and len(chains)==8
    eps=epochs(W,C,chains)
    assert (check.qrank([w for c in eps for w,_ in c]),check.qrank([s for c in eps for _,s in c]))==(check.qrank(W),8)
    R=eng.Run(9,L,eng.Field(0))
    epoch_prices=[];epoch_actual=[];trace=[];cumulative_nonzero=[]
    for idx,ch in enumerate(eps):
        first=ch[0][1]
        A=eng.perp([L[t] for t,x in enumerate(first) if x],9)
        oid=('O',idx);R.INIT(oid,A)
        cum=[Fraction(0) for _ in L]
        for phase,(w,c) in enumerate(ch):
            before=R.cost
            if phase:
                cold=eng.perp([L[t] for t,x in enumerate(c) if x],9)
                A=frozenset(R.reg[oid][0] & cold)
                R.MOVE(oid,A)
            assert all(not check.dot(v,L[t]) for v in A for t,x in enumerate(c) if x)
            for s,v in enumerate(c):
                if v:
                    y=('Y',s)
                    R.MOVE(y,eng.span(list(R.reg[y][0])+list(A)))
                    R.ADD(oid,v,y)
            cum=[x+y for x,y in zip(cum,c)]
            cumulative_nonzero.append(any(cum))
            H=eng.span(list(A)+[L[t] for t,x in enumerate(w) if x])
            R.MOVE(oid,H)
            for t,v in enumerate(w):
                if v:R.ADD(('X',t),v,oid)
            price=check.qprice(L,w,c);actual=R.cost-before
            assert actual>=price
            epoch_prices.append(price);epoch_actual.append(actual)
            trace.append({'abel_row':chains[idx][phase],'input_dim':eng.fdim(A),'output_dim':eng.fdim(H),'price':price,'ascents':actual,'increment_support':sum(bool(x) for x in w),'fresh_support':sum(bool(x) for x in c),'cumulative_nonzero':any(cum)})
        R.CLEAR(oid)
    assert not R.bad and not R.pinned()
    got=R.rec()
    assert all(got[t][s]==-Fraction(G[t][s],2) for t in range(96) for s in range(96))
    assert all(got[t][s]==(-1 if t==s else 0) for t in range(96) for s in range(96) if check.dot(L[t],L[s]))
    return {'chains':chains,'abel_factor_ranks_Q':[check.qrank(W),check.qrank(C)],
            'epoch_factor_ranks_Q':[check.qrank([w for ch in eps for w,c in ch]),check.qrank([c for ch in eps for w,c in ch])],
            'lifetimes':len(chains),'epochs':sum(map(len,chains)),
            'prices':epoch_prices,'price_sum':sum(epoch_prices),'epoch_ascents':epoch_actual,'ascents':R.cost,
            'all_cumulative_intakes_nonzero':all(cumulative_nonzero),
            'all_legal':True,'pinning_errors':len(R.pinned()),'full_and_odd_receipts_exact':True,
            'operations':len(R.ops),'trace':trace}

W,C=gauge(1,5)
# Exactly two disjoint pairs; enumerate both orders in each pair.
results=[]
for f in (False,True):
    for g in (False,True):
        p1=[8,0] if f else [0,8]
        p2=[9,1] if g else [1,9]
        chains=[p1,p2]+[[i] for i in range(2,8)]
        results.append(replay(W,C,chains))
assert [r['ascents'] for r in results]==[58,65,65,72]
assert all(r['abel_factor_ranks_Q']==r['epoch_factor_ranks_Q']==[10,8] for r in results)
assert results[0]['all_cumulative_intakes_nonzero']
# Six orderings of a length-three lifetime, other seven singleton lifetimes.
triples=[]
for trip in permutations([0,8,9]):
    triples.append(replay(W,C,[list(trip)]+[[i] for i in range(1,8)]))
assert all(r['abel_factor_ranks_Q']==[10,8] for r in triples)
# Deliberately collapse the two singleton directions to the same port. This
# is only a rank-9 control, not evidence for the rank-10 claim.
W9,C9=gauge(1,1)
control=replay(W9,C9,[[0,8],[1,9]]+[[i] for i in range(2,8)])
assert control['abel_factor_ranks_Q']==[9,8] and control['ascents']==58
# If one incorrectly feeds an Abel tail itself as its first increment,
# it introduces e_p*C0 in the final receipt.
viol=[(t,s) for t in range(96) for s in range(96) if check.dot(L[t],L[s]) and W[8][t]*C[0][s]]
assert viol
# Verify the chosen ports really are weak for two base combinations.
for i,j in [(0,7),(1,7)]:
    v=[x-y for x,y in zip(X[i],X[j])]
    assert check.f2rank(L[t] for t,x in enumerate(v) if x)==9
    assert check.f2rank(L[t] for t,x in enumerate(v) if x and t not in (1,5))==8
# Three disjoint bases imply any two port deletions leave one intact, so the
# two singletons are independent modulo span(X) at every distinct p,q.
frames=[[0,1,2,3,4,5,8,11],[6,7,9,10,12,13,14,20],[15,16,17,18,19,21,25,28]]
assert len(set(t for fr in frames for t in fr))==24
assert all(check.qrank([[X[k][t] for k in range(8)] for t in fr])==8 for fr in frames)
print(json.dumps({'ports':[1,5],'label_pair':[L[1],L[5]],'weak_deletion_witnesses':[[0,7,1,9,8],[1,7,1,9,8]],
                  'coefficient_matrix':[[1,1],[1,-1]],'coefficient_determinant':-2,
                  'frames_for_universal_rank10':frames,
                  'pair_orders':results,'triple_orders':triples,'collapsed_rank9_control':control,
                  'abel_tail_mutation_odd_violations':len(viol),'abel_tail_mutation_first_violation':viol[0]},indent=2,sort_keys=True))
