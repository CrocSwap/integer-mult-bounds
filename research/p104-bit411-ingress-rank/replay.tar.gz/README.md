# Owner 411: chart-1 cut and reversible shared-bridge control

**Result.** In the pinned #7830 BIT word, the 537 fixed public outputs on chart 1 have 537 independent binary input rows. The word starts with no public fields on chart 1, sends exactly 537 paid fields into it, and sends no paid field out. Its first 536 chart-1 arrivals span the 536 fixed output rows other than owner 411; packet 3553 at clock 31290 contributes the independent owner-411 direction. Therefore 536 one-field ingresses cannot implement the same fixed chart-1 outputs. This is an exact cut for this binary linear model, not a theorem against re-routing with 537 or more ingresses or changing the endpoint contract.

The causal scan grants free copies at every reached chart and uses earlier existing MOVE routes, so a chart can be reachable even when the 411 direction remains mixed with other data. Under that deliberately optimistic rule, **47** chart-1 arrivals before 3553 have a reachable sender: 32 have grade 1, 14 grade 2, and one grade 4. The only direct 509-to-1 arrival is 3544 at clock 31263. One earliest chart-level path is 509 → 380 by packet 2321 at clock 7265, then 380 → 1 by packet 2562 at clock 8873. `CUT.json` lists all 47 arrivals and their earlier paths. Reachability alone does not supply an unmixed 411 field or a valid replacement.

## Exact encoded control

At its source, packet 3544 originally carries owner 432. The experiment adds 411 to it before dispatch, so the paid field arrives carrying `432 XOR 411`. After the original 3553 arrives carrying 411, a second ADD restores packet 3544 to 432 before its only outward reader. The two directions are independent public inputs, and the 411 return remains in place. The **only** changed forward paid-packet payload is 3544; every original packet route and grade is unchanged.

The full edited word is `ENCODED-CONTROL-WORD.json.gz`: canonical SHA-256 `85d5799efa9897910ae7af5e44cce00c2f0358be8bd9f43afbbe8bd3be81c501`, gzip SHA-256 `5dbec562dd874bb1f414d8bd97e7e2086c12737627ac26d0e6de7ee2e8b9c7f1`. The replay checks all 680 output rows, equivalent to 462,400 scalar coefficients, **in each orientation**, and all paired-caller polynomial coefficients. It removes the owner-411 output ADD at original clock 35800 as a negative control: exactly the 411 coefficient of output 411 flips in both orientations. There are 3,554 dirty private retirements in each direction, as before. This is a valid *control*, not a charged saving.

All native and complete paid/productive histograms remain identical to the source; the 36-call signed gain is exactly zero. The directed complete signed margins are:

| κ | Signed target-minus-paid margin |
| --- | --- |
| `0.003879928046155` | [`-0.000000000381874566916336446610288956312999528387`, `-0.000000000381874566916336446610288956312999528386`] |
| `0.003879929046155` | [`-0.000385127316613866441054139472099789196374646204`, `-0.000385127316613866441054139472099789196374646203`] |

The two extra native ADDs increase the 36-call raw-record account by **4,882,176**, to **934,187,713,680**, under the `10^12` ceiling; the accounted owned-field count stays **6,998,544**. The restoration is thus explicitly accounted for in the ordinary record model. No added MOVE or reduced productive target is hidden in the control.

## Bounded lower-grade replacement screen

The cut requires retaining at least 537 chart-1 ingresses; it alone does not forbid a cheaper replacement. `search.py` tests a stricter, explicit family of replacements. It injects the owner-411 direction immediately before any of the **17 existing chart-509 MOVE dispatches** before packet 3553, retains their existing routes, and tries replacing 3553 with one MOVE into chart 1 from a live chart of dimension 5, 6, or 7 (new grade 3, 2, or 1). The replacement sender may be **any XOR of all fields live at that chart** before the original bridge. The screen allows arbitrary linear decoding at chart 1 and optimistically ignores the cost or even the feasibility of repairing changed outputs on other charts.

Before the original bridge there are no CLEARs, SWAPs, public ADD destinations, repeat MOVEs of a field or post-MOVE writes to previously moved fields. The source snapshot therefore retains all original arrivals and public stocks; local copies and XORs add no new linear directions. The search considers 1,011 live fields across 300 possible source charts, and tests all 5,100 injection/chart combinations. It even permits the replacement packet to carry a clean direction while 411 travels in an earlier encoded arrival. For each field it reduces its unencoded row against the 536 fixed non-411 chart-1 outputs and tracks how the injection changes both that field and those outputs. Gaussian elimination on the residual plus 411 parity checks *all* same-chart XOR combinations, not just individual fields. No test supplies an additional bridge value that lets chart 1 recover owner 411 while retaining the 536 output directions. Because the parity equations are linear in the selected injections and every one of the 17 basis injections fails, their simultaneous XOR combinations also fail within this same family.

This screen has not ruled out altered routes or other source edits, additional paid packets, replacement of exterior readers, changes to target endpoints or productive grades, or other encodings outside the stated family. It supplies no new κ lower bound and does not claim that the source #7830 conditional bound is unconditionally established.

## Sources and reproduction

The source is the complete #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; source gzip SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`, canonical word `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`, frame/start/final layout `a0ffffd99fb9b91f0013695877480766319ac51b926ed00dd5f7ec32f2d1e1a6`, and caller gzip `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`. The retained replay and directed tariff code and predecessor attribution appear in `vendor/` and `NOTICE`; no independent human review is asserted.

With Python 3 and the standard library, run `python3 -B verify.py`. The verifier checks the manifest, binds its process and children to one allowed CPU when supported, runs the three analyses serially, and verifies the same manifest again, including the deterministic receipts. `CUT.json`, `SEARCH.json`, and `ENCODING-CONTROL.json` record the results. All inputs used by the checks are included in this directory.
