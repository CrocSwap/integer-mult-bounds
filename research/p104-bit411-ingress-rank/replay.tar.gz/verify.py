#!/usr/bin/env python3
"""Check pinned inputs, serially replay every result, and check receipts."""
from hashlib import sha256
from pathlib import Path
import os,subprocess,sys
HERE=Path(__file__).resolve().parent

def verify_manifest():
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1)
  p=(HERE/name).resolve()
  assert p.is_relative_to(HERE) and p.is_file(), f'unsafe or missing manifest entry {name}'
  assert sha256(p.read_bytes()).hexdigest()==digest, f'SHA-256 mismatch: {name}'

verify_manifest()
if hasattr(os,'sched_getaffinity'):
 available=os.sched_getaffinity(0)
 if available:os.sched_setaffinity(0,{min(available)})
env=os.environ.copy()
env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONNOUSERSITE='1')
env.pop('PYTHONPATH',None)
for script,expected in [('cut.py','PASS rank 536 537 reachable 47'),
                        ('search.py','candidate_source_packets 17 pool 882 viable 0'),
                        ('encoding_control.py','PASS_ENCODED_CONTROL_NO_CHARGED_IMPROVEMENT'),
                        ('exchange_control.py','PASS_TWO_INPUT_ROLE_EXCHANGE_NO_CHARGED_IMPROVEMENT')]:
 result=subprocess.run([sys.executable,'-B',str(HERE/script)],cwd=HERE,env=env,
                       text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
 assert result.returncode==0, f'{script} failed:\n{result.stdout}'
 assert expected in result.stdout, f'{script} missing expected status:\n{result.stdout}'
 print(f'PASS {script}')
verify_manifest()
print('PASS all source hashes, replay assertions, and deterministic receipt hashes')
