#!/usr/bin/env python3
"""Search single 411 injection and bridged chart-1 replacement with exact F2 cut algebra."""
from pathlib import Path
import hashlib,json,gzip,sys,collections,time,resource
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import binary_operator as op
P=Path(__file__).resolve().parent/'inputs'/'WORD.json.gz'
w=op.load_json(P,op.WORD_GZIP,True); assert op.canonical_hash(w)==op.WORD
program=w['program'];n=w['public'];nfields=n+w['owned_fields'];b411=1<<411
start=time.process_time()
# Independent exact target outputs in receiver chart 1, with output-label coordinates.
output=op.expected_operator(False);targets=[i for i,c in enumerate(w['final']) if c==1 and i!=411]
basis={}
def labels(mask):
 while mask:
  low=mask&-mask;yield low.bit_length()-1;mask^=low
def reduce(v):
 combo=0
 while v:
  pivot=v.bit_length()-1
  if pivot not in basis:break
  row,mask=basis[pivot];v^=row;combo^=mask
 return v,combo
for i in targets:
 v,c=reduce(output[i]);assert v;basis[v.bit_length()-1]=(v,c^(1<<i))
assert len(targets)==len(basis)==536
# Snapshot unmodified field rows and chart addresses just before original bridge INIT.
cells=[(c,1<<i) for i,c in enumerate(w['start'])]+[None]*w['owned_fields']
packet=n;candidate_packets=[]
for clock,(code,addr,*args) in enumerate(program):
 if clock==31288: snap=cells.copy(); break
 if code=='INIT':cells[addr]=(args[0],0)
 elif code=='CLEAR':cells[addr]=None
 elif code=='ADD':cells[addr]=(cells[addr][0],cells[addr][1]^cells[args[0]][1])
 elif code=='SWAP':cells[addr],cells[args[0]]=cells[args[0]],cells[addr]
 else:
  assert code=='MOVE'
  if args[0]==509:candidate_packets.append({'packet':packet,'clock':clock,'address':addr,'receiver':args[1]})
  cells[addr]=(args[1],cells[addr][1]);packet+=1
assert snap[411]==(509,b411)
# All pre-bridge public values and packet arrivals remain available: no
# retirement, swap or in-place rewrite of an already-moved packet occurs.
moved=set()
for event in program[:31288]:
 code,addr,*args=event
 assert code not in ('CLEAR','SWAP')
 if code=='MOVE':assert addr not in moved;moved.add(addr)
 if code=='ADD':assert addr>=n and addr not in moved
# Build fixed pool of candidate bridge fields whose original rows have receiver-chart representations.
pool=[]
chart_pool=collections.defaultdict(list)
for addr,cell in enumerate(snap):
 if cell is None:continue
 chart,row=cell; dim=w['frames'][str(chart)]['dim']
 if not (5<=dim<=7) or row&b411:continue
 rem,combo=reduce(row)
 chart_pool[chart].append((addr,row,rem,combo))
 if not rem and row:pool.append((addr,chart,8-dim,row,combo))
results=[];positive=None
for src in candidate_packets:
 delta=[0]*nfields;snapshot=None
 for clock,(code,addr,*args) in enumerate(program):
  if clock==src['clock']:delta[addr]^=1
  if clock==31288:snapshot=delta.copy()
  if code in ('INIT','CLEAR'):delta[addr]=0
  elif code=='ADD':delta[addr]^=delta[args[0]]
  elif code=='SWAP':delta[addr],delta[args[0]]=delta[args[0]],delta[addr]
  else:assert code=='MOVE'
 affected=[i for i in range(n) if delta[i]]
 assert not delta[411]
 nonreceiver=[i for i in affected if w['final'][i]!=1]
 outmask=sum(1<<i for i in affected)
 if src['packet']==3544:
  # Positive control: the clean owner-432 field on chart 509, at grade 4,
  # exposes 411 when combined with the modified 432 chart-1 output.
  assert snap[432]==(509,1<<432) and snapshot[432]==0
  rem,combo=reduce(snap[432][1])
  assert rem==0 and combo==1<<432 and (combo&outmask).bit_count()%2==1
  positive={'injected_packet':3544,'clean_source_field':432,'source_chart':509,
            'replacement_grade':4,'decoded_directions':[432,411]}
 options=[]
 if not delta[411]:
  for addr,chart,grade,row,combo in pool:
   if snapshot[addr]^((combo&outmask).bit_count()&1):
    options.append({'source_field':addr,'source_chart':chart,'new_grade':grade,'row_support':row.bit_count(),
                    'decode_outputs':list(labels(combo))})
 options.sort(key=lambda q:(q['new_grade'],len(q['decode_outputs']),q['source_field']))
 # Complete local linear-span test: choose any XOR of same-chart live fields,
 # not just one. Eliminate the old receiver target space and test whether a
 # combination differs from the encoded target-output span in the 411 bit.
 span_options=[]
 span_charts_tested=0
 for chart,items in chart_pool.items():
  span_charts_tested+=1
  elimination={}
  for addr,row,rem,combo in items:
   flag=snapshot[addr]^((combo&outmask).bit_count()&1)
   v=(rem<<1)|flag; witness=1<<addr
   while v:
    pivot=v.bit_length()-1
    if pivot not in elimination:
     elimination[pivot]=(v,witness);break
    other,used=elimination[pivot];v^=other;witness^=used
  v=1;witness=0
  while v:
   pivot=v.bit_length()-1
   if pivot not in elimination:break
   other,used=elimination[pivot];v^=other;witness^=used
  if v:continue
  ids=list(labels(witness));row=0;delta_value=0
  for addr in ids:row^=snap[addr][1];delta_value^=snapshot[addr]
  rem,combo=reduce(row)
  assert rem==0 and (delta_value^((combo&outmask).bit_count()&1))==1
  span_options.append({'source_fields':ids,'source_chart':chart,'new_grade':8-w['frames'][str(chart)]['dim'],
                       'row_support':row.bit_count(),'bridge_has_411':bool(delta_value),
                       'decode_outputs':list(labels(combo))})
 span_options.sort(key=lambda q:(q['new_grade'],len(q['decode_outputs'])+len(q['source_fields'])))
 results.append({**src,'affected_receiver_outputs':len(affected)-len(nonreceiver),'affected_nonreceiver_outputs':nonreceiver,
                 'affected_output_ids':affected,'eligible_bridge_options':len(options),'best':options[:5], 'all_options':options,
                 'span_charts_tested':span_charts_tested,'span_options':span_options})
assert (len(candidate_packets),len(chart_pool),sum(map(len,chart_pool.values())),sum(x['span_charts_tested'] for x in results))==(17,300,1011,5100)
assert positive and not any(x['all_options'] or x['span_options'] for x in results)
print('candidate_source_packets',len(candidate_packets),'pool',len(pool),'viable',sum(bool(x['span_options']) for x in results))
for x in results:
 print(x['packet'],x['clock'],x['receiver'],'nonreceiver',len(x['affected_nonreceiver_outputs']),'changed receiver',x['affected_receiver_outputs'],'single',x['eligible_bridge_options'],'span',len(x['span_options']),'best',x['span_options'][:1])
out={'word':op.WORD,'pool_rows_spanned_by_original_536_chart1_outputs':len(pool),'injection_packet_count':len(candidate_packets),
 'snapshot_candidate_source_charts':len(chart_pool),'snapshot_candidate_source_fields':sum(map(len,chart_pool.values())),
 'source_chart_tests':sum(x['span_charts_tested'] for x in results),
 'grade4_clean_source_positive_control':positive,
 'viable_single_injections':sum(bool(x['all_options']) for x in results),
 'viable_local_span_injections':sum(bool(x['span_options']) for x in results),'rank_chart1_outputs_without_411':len(basis),
 'results':results}
Path(__file__).with_name('SEARCH.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
