#!/usr/bin/env python3
"""Full-word reversible sharing control: no paid/target saving is claimed."""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import copy,gzip,json,sys,time,resource
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import binary_operator as op
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import price
HERE=Path(__file__).resolve().parent
INPUT=HERE/'inputs'
w=op.load_json(INPUT/'WORD.json.gz',op.WORD_GZIP,True)
caller=op.load_json(INPUT/'EFREE-CALLER.json.gz',op.CALLER,True)
assert op.canonical_hash(w)==op.WORD
atlas=op.Atlas(w['frames']);assert atlas.main_contacts(w['start'],w['final'])==111
oldf,oldr,_=op.native_checks(w,atlas)
assert w['program'][31263]==['MOVE',3544,509,1]
assert w['program'][31290]==['MOVE',3553,509,1]
assert w['program'][35800]==['ADD',3965,3553,1]
assert all(3544 not in e[1:3] for e in w['program'][31264:31291])
# Share owner 411 reversibly over the 432 packet. Retain 3553 to decode it.
# The separate ADD at the 411 output is the meaningful omission control.
new=copy.deepcopy(w)
p=[]; omitted=None
for clock,event in enumerate(w['program']):
 if clock==31263:p.append(['ADD',3544,411,509])
 if clock==35800:omitted=len(p)
 p.append(event[:])
 if clock==31290:p.append(['ADD',3544,3553,1])
new['program']=p
canonical=json.dumps(new,sort_keys=True,separators=(',',':')).encode()
new_sha=sha256(canonical).hexdigest()
assert new_sha=='85d5799efa9897910ae7af5e44cce00c2f0358be8bd9f43afbbe8bd3be81c501'
packed=(HERE/'ENCODED-CONTROL-WORD.json.gz').read_bytes()
assert sha256(packed).hexdigest()=='5dbec562dd874bb1f414d8bd97e7e2086c12737627ac26d0e6de7ee2e8b9c7f1'
assert gzip.decompress(packed)==canonical
start=time.process_time(); forward=op.run_tape(new,atlas,False);reverse=op.run_tape(new,atlas,True)
for rev,tape,base in ((False,forward,oldf),(True,reverse,oldr)):
 assert tape.output==op.expected_operator(rev)
 assert tape.dirty==base.dirty==3554
 wrong=op.run_tape(new,atlas,rev,omit=omitted)
 assert [a^b for a,b in zip(wrong.output,tape.output)]==[(1<<411 if i==411 else 0) for i in range(680)]
 assert {p:(q.source,q.receiver,q.grade) for p,q in tape.packets.items()}=={p:(q.source,q.receiver,q.grade) for p,q in base.packets.items()}
assert oldf.packets[3544].arrival.row==1<<432
assert forward.packets[3544].arrival.row==(1<<432)^(1<<411)
assert forward.packets[3553].arrival.row==1<<411
changed={k for k in forward.packets if forward.packets[k].arrival.row!=oldf.packets[k].arrival.row}
assert changed=={3544}
np,nt,paid,targets=op.binary_invoice(new,caller,atlas,forward)
bnp,bnt,bpaid,btargets=op.binary_invoice(w,caller,atlas,oldf)
assert (np,nt,paid,targets)==(bnp,bnt,bpaid,btargets)
boundary=op.ordinary_boundary(w,caller,bpaid,btargets)
delta_records=36*16*(w['owned_fields']+w['public']+4)*(len(p)-len(w['program']))
new_records=boundary['raw_records']+delta_records
assert (delta_records,new_records)==(4882176,934187713680) and new_records<10**12
intervals={}
signed=price.signed_profile(targets,paid)
for kval in ('0.003879928046155','0.003879929046155'):
 v=price.moment(signed,Fraction(kval))
 intervals[kval]={'full_signed_margin':price.decimal_interval(v,48),'gain': ['0','0']}
result={'status':'PASS_ENCODED_CONTROL_NO_CHARGED_IMPROVEMENT',
 'source_word':op.WORD,'source_gzip':op.WORD_GZIP,'control_canonical_word':new_sha,
 'control_gzip':sha256(packed).hexdigest(),'added_native_operations':2,
 'sent_3544':{'clock_original':31263,'source_owner':432,'source_chart':509,'receiver_chart':1,
              'payload_after_encoding':'owner432 XOR owner411','independent_public_directions':[432,411]},
 'bridge_3553':{'clock_original':31290,'source_chart':509,'receiver_chart':1,'grade':4,'payload':'owner411'},
 'only_forward_packet_with_changed_value':sorted(changed),'all_680_outputs_each_orientation_exact':True,
 'coefficients_each_orientation':680**2,'changed_direction_is_reversible_and_fixed_readers_restored':True,
 'negative_control_removed_control_clock':omitted,'negative_control_original_clock':35800,
 'negative_control_only_owner411_in_each_orientation':True,'dirty_private_retirements':[forward.dirty,reverse.dirty],
 'native_paid':dict(np),'native_productive':dict(nt),'full_paid':dict(paid),'full_productive':dict(targets),
 'full_36_call_payment':intervals,'extra_raw_records':delta_records,'control_raw_records':new_records,
 'unchanged_owned_fields':boundary['owned_fields']}
(HERE/'ENCODING-CONTROL.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
