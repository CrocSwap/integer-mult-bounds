#!/usr/bin/env python3
"""Replay a second exact control exchanging the two ingress payload roles."""
from hashlib import sha256
from pathlib import Path
from fractions import Fraction
import copy,gzip,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
import binary_operator as op
import price
w=op.load_json(HERE/'inputs'/'WORD.json.gz',op.WORD_GZIP,True)
caller=op.load_json(HERE/'inputs'/'EFREE-CALLER.json.gz',op.CALLER,True)
assert op.canonical_hash(w)==op.WORD
atlas=op.Atlas(w['frames']);oldf,oldr,_=op.native_checks(w,atlas)
for k,row in {31263:['MOVE',3544,509,1],31289:['ADD',3553,411,509],
              31290:['MOVE',3553,509,1],35800:['ADD',3965,3553,1],
              36134:['ADD',3986,3544,1]}.items():assert w['program'][k]==row
new=copy.deepcopy(w);p=[];omitted=None
for k,row in enumerate(w['program']):
 if k==31263:omitted=len(p);p.append(['ADD',3544,411,509])
 if k==31289:row=['ADD',3553,432,509]
 if k==35800:row=['ADD',3965,3544,1]
 if k==36134:row=['ADD',3986,3553,1]
 p.append(row[:])
 if k==31290:p.append(['ADD',3544,3553,1])
new['program']=p
canonical=json.dumps(new,sort_keys=True,separators=(',',':')).encode()
word=sha256(canonical).hexdigest()
packed=gzip.compress(canonical,compresslevel=9,mtime=0)
(HERE/'EXCHANGE-CONTROL-WORD.json.gz').write_bytes(packed)
f=op.run_tape(new,atlas,False);r=op.run_tape(new,atlas,True)
for reverse,tape,old in ((False,f,oldf),(True,r,oldr)):
 assert tape.output==op.expected_operator(reverse) and tape.dirty==old.dirty==3554
 assert {k:(v.source,v.receiver,v.grade) for k,v in tape.packets.items()}=={k:(v.source,v.receiver,v.grade) for k,v in old.packets.items()}
 bad=op.run_tape(new,atlas,reverse,omit=omitted)
 assert [a^b for a,b in zip(bad.output,tape.output)]==[(1<<411 if i==411 else 0) for i in range(680)]
assert f.packets[3544].arrival.row==(1<<432)^(1<<411)
assert f.packets[3553].arrival.row==1<<432
changed={k for k in f.packets if f.packets[k].arrival.row!=oldf.packets[k].arrival.row}
assert changed=={3544,3553}
np,nt,paid,targets=op.binary_invoice(new,caller,atlas,f)
bnp,bnt,bpaid,btargets=op.binary_invoice(w,caller,atlas,oldf)
assert (np,nt,paid,targets)==(bnp,bnt,bpaid,btargets)
boundary=op.ordinary_boundary(w,caller,bpaid,btargets)
delta=36*16*(w['owned_fields']+w['public']+4)*(len(p)-len(w['program']))
assert delta==4882176 and boundary['raw_records']+delta==934187713680
signed=price.signed_profile(targets,paid)
prices={}
for x in ('0.003879928046155','0.003879929046155'):
 prices[x]=price.decimal_interval(price.moment(signed,Fraction(x)),48)
result={'status':'PASS_TWO_INPUT_ROLE_EXCHANGE_NO_CHARGED_IMPROVEMENT',
        'control_canonical_word':word,'control_gzip':sha256(packed).hexdigest(),
        'original_source_word':op.WORD,'owner_directions':[411,432],
        'packet_payloads':{'3544':'owner432 XOR owner411','3553':'owner432'},
        'only_changed_forward_packets':sorted(changed),
        'reader_changes':{'original_clock35800':'reads 3544 instead of 3553',
                          'original_clock36134':'reads 3553 instead of 3544'},
        'all_680_outputs_each_orientation_exact':True,'coefficients_each_orientation':680**2,
        'negative_control_omitted_clock':omitted,'negative_control_is_injection':True,
        'negative_control_only_owner411_in_each_orientation':True,
        'caller_polynomial_coefficients_each_orientation':38**2,
        'native_paid':dict(np),'native_productive':dict(nt),'signed_margins':prices,
        '36_call_signed_gain':['0','0'],'extra_raw_records':delta,
        'control_raw_records':boundary['raw_records']+delta,'dirty_private_retirements':[f.dirty,r.dirty]}
(HERE/'EXCHANGE-CONTROL.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps(result,sort_keys=True,indent=2))
