#!/usr/bin/env python3
"""Exact chart-1 communication cut and relaxed causal reach census."""
from pathlib import Path
from collections import Counter
import json,sys,time,resource
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import binary_operator as op
HERE=Path(__file__).resolve().parent
w=op.load_json(Path(__file__).resolve().parent/'inputs'/'WORD.json.gz',op.WORD_GZIP,True)
assert op.canonical_hash(w)==op.WORD
start=time.process_time();atlas=op.Atlas(w['frames']);f,r,omitted=op.native_checks(w,atlas)
def rank(rows):
 basis={}
 for v in rows:
  while v:
   j=v.bit_length()-1
   if j not in basis:basis[j]=v;break
   v^=basis[j]
 return len(basis)
S=f.stock[1];D=f.demand[1];without=[o.row for o in S if o.label!=3553]
outputs=[o.row for o in D if o.label!=~411]
assert len(S)==len(D)==537 and len(without)==len(outputs)==536
assert all(o.label>=680 for o in S) and all(o.label<0 for o in D)
assert not any(row&1<<411 for row in without)
assert rank(without)==rank(outputs)==rank(without+outputs)==536
assert rank([o.row for o in S])==rank([o.row for o in D])==537
assert f.packets[3553].arrival.row==1<<411
# Deliberately generous: arbitrarily many free copies can be kept at every
# reached chart. A reachable chart can inject the encoded 411 direction into
# any later MOVE, even if unmixing it would not actually be possible there.
reach={509:[]}; packet=w['public'];arrivals=[];packets={}
for clock,event in enumerate(w['program']):
 if event[0]!='MOVE':continue
 _,address,a,b=event;packets[packet]={'clock':clock,'source':a,'receiver':b,'address':address}
 before=reach.get(a)
 if b==1 and clock<31290 and before is not None:
  arrivals.append({'packet':packet,'clock':clock,'source_chart':a,
                   'grade':atlas.grade(a,b),'reachable_after_packets':before})
 if before is not None and b not in reach:reach[b]=before+[packet]
 packet+=1
assert len(arrivals)==47 and [v['packet'] for v in arrivals if v['source_chart']==509]==[3544]
assert Counter(v['grade'] for v in arrivals)==Counter({1:32,2:14,4:1})
assert reach[1]==[2321,2562] and packets[2321]['clock']==7265 and packets[2562]['clock']==8873
assert sum(e[0]=='MOVE' and e[2]==1 for e in w['program'])==0
assert sum(e[0]=='MOVE' and e[3]==1 for e in w['program'])==537
result={'word':op.WORD,'word_gzip':op.WORD_GZIP,'chart1_initial_public_fields':0,
 'chart1_incoming_moves':537,'chart1_outgoing_moves':0,'chart1_final_public_fields':537,
 'rank_incoming_all':537,'rank_537_fixed_public_output_rows':537,
 'rank_before_bridge':536,'rank_non411_fixed_outputs':536,
 'rank_union_before_bridge_and_non411_outputs':536,
 'bridge_3553_clock':31290,'bridge_3553_row':'owner411','source_omission_clock':omitted,
 'relaxed_reachable_chart1_senders_before_bridge_count':len(arrivals),
 'eligible_arrival_grade_counts':dict(Counter(v['grade'] for v in arrivals)),
 'direct_chart509_arrival':3544,'first_relaxed_path_into_chart1':[packets[i] | {'packet':i} for i in reach[1]],
 'eligible_arrivals':arrivals,
 'obstruction':'No unchanged-chart1-interface realization with only 536 one-field ingresses can provide 537 independent fixed chart1 output rows.',
 'scope':'Exact binary linear model and fixed chart1 public endpoints; no restriction claimed on added ingress, changed endpoints or changed external chart routes.',
}
(HERE/'CUT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print('PASS rank',rank(without),rank([o.row for o in D]),'reachable',len(arrivals),'grades',dict(Counter(v['grade'] for v in arrivals)))
