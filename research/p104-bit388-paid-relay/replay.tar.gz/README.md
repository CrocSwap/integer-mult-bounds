# Paid relays into the chart-388 BIT receiver

Two **literal paid relay controls** reproduce the entire pinned BIT operator and the old three chart-388 exits. Both lose signed value after all paid hops are counted. They establish no improved κ bound. The cheaper-looking grade-3 hop in the second control is real, but the two upstream recodings damage a later chart-283 reader; restoring it costs more than the gross grade saving.

The binary comparator is [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at scientific head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The two earlier recodings follow the `(2917,2922)` witness in [#7889](https://github.com/CrocSwap/integer-mult-bounds/pull/7889) at `e9b3c3a677fe80c75295d9072f1b64ef29403c40`. The exact predecessor archive is included and checked against its published SHA-256; [SOURCES.json](SOURCES.json) records the inputs. All clocks below are zero-based **original-word** clocks unless explicitly called changed-word clocks.

## Receiver and live-bank screen

Original field 927 carries `u1=x43` from chart 45 to chart 388 at clock 880, grade 5. Fields 2023 and 2190 carry `u2` and `u3` from charts 283 and 311 at clocks 5207 and 6326, both grade 2. The first chart-388 read is at clock 8954. The old ordered exits at 8957, 8961 and 8964 carry `u1+u2+u3`, `u2+u3` and `u2`; the three arrivals have rank 3 over F₂.

Original chart 560 receives precisely two rows before that read, in fields 2578 and 2581 at clocks 8938 and 8949. They have rank 2 and no nonzero intersection with the span of `u1,u2,u3`. Their complete public-coordinate supports, the targets, and scan witnesses are in [SCAN.json](SCAN.json) and [SCAN-two-recodes-unrestored.json](SCAN-two-recodes-unrestored.json). A proposed new source scalar can be combined locally with either or both 560 rows. Because the two old deliveries are retained exactly, the useful scalar arriving at chart 388 has the form `u1+a*u2+b*u3`; the screen checks all four such choices against all four combinations of the 560 rows. A sender must hold a **live** same-chart scalar or XOR of live fields at the indicated cut, not merely have held it historically. Its new MOVE to 560 must be nested and have positive grade.

The scan examines every changed-chart state before clock 8954, after deleting the old 927 construction, and counts a chart/target/stock combination once at its earliest witnessing cut. It separately enumerates actual singleton fields. A chart is revisited whenever its live stock changes. There are 105 atlas charts other than 560 nested with 560 at positive grade: 4 grade 1, 7 grade 3, 35 grade 5, 58 grade 6 and 1 grade 7. All grade checks use the actual rational frames. With no other payload changes, the 3,241 live-bank snapshots yield one bank class: chart 45 initially contains `x43`, at grade 6. Five singleton field identities realize that class. There is no grade 1, 3, or 5 witness in this fixed-payload screen.

With exactly the two #7889 recodings made **without** restoration, the 3,240 snapshots produce four bank/target classes and eight singleton identities:

| Earliest cut | Source chart | Grade to 560 | Example live-bank scalar |
| ---: | ---: | ---: | --- |
| Initial | 45 | 6 | `x43`, public field 43 |
| 2917 | 160 | 5 | field 924 XOR recoded field 1495 = `x43` |
| 2922 | 283 | 3 | recoded field 1496 = `x43` |
| 4122 | 283 | 3 | XOR of fields 988, 1111, 1496, 1756 and 1816 = `x43+u2` |

None of these four earliest examples uses a 560 stock row. The unrestored run is an optimistic enumeration: downstream old readers of field 1496 may be wrong. It does not range over other payload choices, additional recodes, altered initial or later source routes, more than one new source scalar, or different 283/311 deliveries. In particular, it is not a general exclusion of funded relays. The checked literal below supplies and pays for the missing reader restoration.

## Restoration obligation and its minimum price

In the `(2917,2922)` recodings, field 1495 changes from `x527` to `x321` and field 1496 arrives at chart 283 as `x43` instead of

```
x43 + x74 + x321 + x405 + x527.
```

The first original chart-283 reader at clock 5191 needs that original field. Even granting **free retained shadows of every one of the six chart-283 inputs** before this reader, neither the old scalar nor the original first output is in their rank-six span. The receipt includes the six exact rows and a positive control that supplies the missing scalar. Consequently, while all other old arrivals and reader obligations remain fixed, local recoding alone cannot repair this reader; at least one additional positive-grade inbound scalar is necessary. Changing other old incoming payloads or otherwise rewriting the larger program is outside this argument.

Let `H(r)=r^(1−κ)`. Replacing the original grade-5 arrival with a grade-3 new 283→560 hop and grade-1 560→388 hop gives the optimistic 36-call change `36*(H(5)−H(3)−H(1))`, about `+35.338865768176` at κ `0.003879928046156`. Charging even one **minimum grade-1** restoration, and granting all other restoration and local work for free, gives the upper bound

```
36*(H(5) - H(3) - 2*H(1))
  in [-0.6611342318243407085944521900, -0.6611342318243407085944521899]
```

at that trial. At `0.003879929046155`, the corresponding upper bound is about `−0.661134401574`. These are directed enclosures for the expression, with the actual gain bounded **above** by its upper endpoint under the fixed-incidence conditions. They are not the invoice of the literal implementation, and they do not exclude a coordinated rewrite that changes another paid edge or productive target.

## Two emitted controls and complete accounts

[words/direct.json.gz](words/direct.json.gz) copies `x43` while it is live at chart 45 and pays 45→560 at grade 6 and 560→388 at grade 1. It removes the old 45→388 grade-5 MOVE.

[words/two-recodes.json.gz](words/two-recodes.json.gz) changes the two existing payloads as above. It reuses owned field 927 to carry the missing correction `x321+x527` by a new 0→160 grade-2 hop, adds the live local field `x74+x405`, and pays 160→283 at grade 2. At chart 283 it restores the original field 1496 before any old reader; then it transforms field 927 into `x43` and pays the distinct 283→560 grade-3 and 560→388 grade-1 hops. Thus no new owned field is needed. All retained original ADD and MOVE outputs other than the four explicit events at clocks 2916, 2917, 2921 and 2922 match their old values, including every subsequent original reader and all three old exits. The changed-word packet clocks and exact supports are recorded in [RESULT.json](RESULT.json).

The table reports `new productive-minus-paid − old productive-minus-paid` for the **complete 36-call** caller. Productive histograms and all public endpoint charts are unchanged; local operations are free in this signed invoice but included in the ordinary record count. Native paid changes are shown before multiplication by 36.

| Literal | Native paid histogram change | Gain at 0.003879928046156 | Gain at 0.003879929046155 |
| --- | --- | ---: | ---: |
| Direct | `+H(1)+H(6)−H(5)` | −71.624105959500 | −71.624105863056 |
| Two recodes with paid restoration | `+H(1)+2H(2)+H(3)−H(5)` | −108.274386506307 | −108.274386576512 |

The complete signed margins for the restored control are approximately `−108.274386507074` and `−108.274771703828` at the respective trials. Directed bounds and complete paid/productive histograms for both controls are in [RESULT.json](RESULT.json). The direct and restored words use 934,393,669,392 and 934,822,668,432 ordinary records, respectively; each uses 6,998,544 owned fields in the caller allowance, below the inherited limits of 10¹² records and 10⁷ fields.

For **each changed literal**, the checker verifies all `680²` native coefficients forward and adjoint, all `38²` caller polynomial coefficients in both directions, unchanged helper productive targets, 3,554 dirty private retirements in each direction, and the protected owner-411 bridge and its omission control. A separately authored interpreter checks MOVE first use, charts, all public maps, full 36-call paid occurrence counts and the ordinary account. A separate outward fixed-point price engine agrees with directed square-root intervals. Omitting the correction and changing the chart-388 first reader are each rejected by both independent operator directions; adding a grade-2 paid occurrence strictly lowers the checked complete signed margin.

## Reproduction

Python 3.12 and the standard library, offline from this directory:

```sh
sha256sum -c SHA256SUMS
python3 -I -B build.py
python3 -I -B scan.py
python3 -I -B scan.py --two-recodes
python3 -I -B verify_relay.py
sha256sum -c SHA256SUMS
```

The default commands reconstruct and compare the checked-in words, origin maps and JSON receipts without modifying them. `build.py --write-words` and the relevant `--write-results` flags deliberately regenerate files, so run them only if updating the receipt. The nested [source](source/) and [independent](independent/) directories retain their own notices and source provenance. The exact #7889 archive is [predecessor-7889.tar.gz](predecessor-7889.tar.gz).

These are mathematical word, ownership, caller and price checks, not a finite compiler, precision-tape, physical-erasure, outer-theorem or independent human qualification. Clear1nsight prepared the controls with substantial OpenAI Codex assistance; earlier source contributions are credited in the retained notices.
