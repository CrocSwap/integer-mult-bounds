#!/usr/bin/env python3
"""Emit two literal, paid chart-560 relay controls from the pinned word."""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import gzip,json,sys
if not __debug__:raise RuntimeError('assertions must remain enabled')

HERE=Path(__file__).resolve().parent
assert set(sys.argv[1:]) <= {'--write-words'}
write='--write-words' in sys.argv[1:]
raw=(HERE/'WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));p=w['program']
assert p[878:881]==[['INIT',927,45],['ADD',927,43,45],['MOVE',927,45,388]]
assert p[2915:2923]==[['INIT',1495,0],['ADD',1495,527,0],['MOVE',1495,0,160],
 ['INIT',1496,160],['ADD',1496,924,160],['ADD',1496,1122,160],['ADD',1496,1495,160],['MOVE',1496,160,283]]
assert p[8949]==['MOVE',2581,387,560]
assert p[8954:8965]==[['ADD',2583,927,388],['ADD',2583,2023,388],['ADD',2583,2190,388],['MOVE',2583,388,517],
 ['INIT',2584,388],['ADD',2584,2023,388],['ADD',2584,2190,388],['MOVE',2584,388,560],
 ['INIT',2585,388],['ADD',2585,2023,388],['MOVE',2585,388,1]]

def construct(mode):
 out=[]; origin=[]
 def insert(op):out.append(op);origin.append(None)
 if mode=='direct':
  for e in [['INIT',927,45],['ADD',927,43,45],['MOVE',927,45,560]]:insert(e)
 for i,e in enumerate(p):
  if i in (878,879,880) or mode=='two-recodes' and i==2920:continue
  if mode=='two-recodes' and i==2916:e=['ADD',1495,321,0]
  out.append(e.copy());origin.append(i)
  if mode=='two-recodes' and i==2917:
   # 927 carries the missing delta x321+x527+(x74+x405).
   for z in [['INIT',927,0],['ADD',927,321,0],['ADD',927,527,0],
             ['MOVE',927,0,160],['ADD',927,1122,160]]:insert(z)
  if mode=='two-recodes' and i==2922:
   # 1496 entered 283 as x43. Restore its original value before any old
   # 283 reader, then recode 927 to x43 and pay for the upstream relay.
   for z in [['MOVE',927,160,283],['ADD',1496,927,283],['ADD',927,1496,283],['MOVE',927,283,560]]:insert(z)
  if i==8949:insert(['MOVE',927,560,388])
 q=deepcopy(w);q['program']=out
 return q,origin

(HERE/'words').mkdir(exist_ok=True)
for name in ('direct','two-recodes'):
 q,origin=construct(name);canon=json.dumps(q,sort_keys=True,separators=(',',':')).encode()
 path=HERE/'words'/f'{name}.json.gz';origin_path=HERE/'words'/f'{name}.origin.json'
 if write:
  path.write_bytes(gzip.compress(canon,mtime=0));origin_path.write_text(json.dumps(origin,separators=(',',':'))+'\n')
 data=path.read_bytes()
 assert json.loads(gzip.decompress(data))==q and json.loads(origin_path.read_text())==origin
 print(name,'events',len(q['program']),'canonical',sha256(canon).hexdigest(),'gzip',sha256(data).hexdigest())
