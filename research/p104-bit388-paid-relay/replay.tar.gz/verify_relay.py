#!/usr/bin/env python3
"""Full symbolic and caller checks of the two literal relay controls."""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip,json,sys,tarfile
if not __debug__:raise RuntimeError('assertions must remain enabled')
H=Path(__file__).resolve().parent
need_write='--write-results' in sys.argv[1:]
assert set(sys.argv[1:]) <= {'--write-results'}
sys.path.insert(0,str(H/'source'))
import verify as v
op=v.op
sys.path.insert(0,str(H/'independent'))
import changed_bit_replay as independent
import target_exact as price

def need(ok,why):
 if not ok:raise ValueError(why)
def bits(q):return [i for i in range(680) if q>>i&1]
def counts(q):return {str(k):v for k,v in sorted(q.items()) if v}
def subtract(a,b):
 q=a.copy();q.subtract(b);return q
def read(path):
 raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)
for path,digest in v.PINS.items():need(sha256((H/'source'/path).read_bytes()).hexdigest()==digest,'source pin '+path)
archive=H/'predecessor-7889.tar.gz'
need(sha256(archive.read_bytes()).hexdigest()=='8756014ac027bbe6aaad673af12b49ecd7f3b0a3f5688374e06babeec91a473a','pinned #7889 archive')
with tarfile.open(archive,'r:gz') as tf:
 prior_cut=json.load(tf.extractfile('./CUT.json'));prior_transfer=json.load(tf.extractfile('./TRANSFER.json'))
prior,=[x for x in prior_cut['hits'] if (x['first'],x['second'])==(2917,2922)]
prior_trace,=[x for x in prior_transfer['witnesses'] if (x['first'],x['second'])==(2917,2922)]
need(prior['first_delta']==[321,527] and prior['second_replacement']==[43] and
     prior_trace['reader_restoration_screen']['second']['clock']==5191 and
     not prior_trace['reader_restoration_screen']['second']['free_history_contains_original_output'],
     'pinned #7889 pair and reader obstruction')
w=read(H/'WORD.json.gz');caller=read(H/'source/inputs/EFREE-CALLER.json.gz');source=read(H/'source/inputs/WORD.json.gz')
need(w==source and sha256(v.canon(w)).hexdigest()==v.WORD,'source word identity')
atlas=op.Atlas(w['frames']);charts=independent.Charts(w['frames'])
need(atlas.main_contacts(w['start'],w['final'])==111,'main contacts')
f0,b0,deleted=op.native_checks(w,atlas)
np0,nt0,paid0,targets0=op.binary_invoice(w,caller,atlas,f0)
receipt=read(H/'source/inputs/BIT.json')
for x,k in ((np0,'native_paid'),(nt0,'native_targets'),(paid0,'paid'),(targets0,'targets')):
 need(x==Counter({int(a):b for a,b in receipt['native'][k].items()}),'original invoice '+k)
ind0_paid,ind0_targets,ind0_trace=independent.recount_from_candidate(w,caller,charts)
need(ind0_paid==paid0 and ind0_targets==targets0,'independent original invoice')
call_f=independent.caller_transfer(caller,False);call_r=independent.caller_transfer(caller,True)
rates=['0.003879928046156','0.003879929046155']

def price_int(paid,targets,rate):return price.signed(paid,targets,rate)
def primary_interval(paid,targets,rate):
 h=subtract(targets,paid);lo=hi=F(0)
 for r,c in h.items():
  a,b=v.power_bounds(r,1-F(rate),204)
  lo+=c*(a if c>0 else b);hi+=c*(b if c>0 else a)
 return lo,hi
def overlap(a,b):return F(a[0],price.GRID)<=b[1] and b[0]<=F(a[1],price.GRID)

def observe(word,origins):
 tags=word['start'][:]+[None]*word['owned_fields'];vals=[1<<i for i in range(680)]+[0]*word['owned_fields']
 observed={};new_packets=[]
 for i,(evt,o) in enumerate(zip(word['program'],origins)):
  code,r,*a=evt
  if code=='INIT':need(tags[r] is None,'observation init');tags[r]=a[0];vals[r]=0
  elif code=='CLEAR':need(tags[r]==a[0],'observation clear');tags[r]=None;vals[r]=0
  elif code=='ADD':need(tags[r]==tags[a[0]]==a[1],'observation add');vals[r]^=vals[a[0]]
  elif code=='SWAP':s=a[0];tags[r],tags[s]=tags[s],tags[r];vals[r],vals[s]=vals[s],vals[r]
  elif code=='MOVE':
   need(tags[r]==a[0] and atlas.grade(*a)>0,'observation move');tags[r]=a[1]
   if o is None:new_packets.append({'clock':i,'role':r,'source':a[0],'destination':a[1],'grade':atlas.grade(*a),'support':bits(vals[r])})
  else:raise ValueError(code)
  if o is not None and code in ('ADD','MOVE'):observed[o]=vals[r]
 return observed,new_packets

origins0=list(range(len(w['program'])));old,none=observe(w,origins0);need(not none,'baseline labels')
base_price={k:price_int(paid0,targets0,k) for k in rates}
for k in rates:need(overlap(base_price[k],primary_interval(paid0,targets0,k)),'baseline arithmetic independent overlap')
screen=read(H/'SCAN-two-recodes-unrestored.json')['reader_restoration_screen']
need(screen['first_original_reader_clock']==5191 and not screen['original_first_output_in_free_history_span'],'reader restoration obstruction')
need(screen['original_first_output_support']==prior_trace['reader_restoration_screen']['second']['original_output'],
     'reconstructed #7889 reader output')
optimistic={}
for k in rates:
 gross=price.signed(Counter({1:36,3:36}),Counter({5:36}),k)
 # With all other prices and targets fixed, the absent original first-reader
 # output needs at least one extra, positive-grade inbound scalar. Granting a
 # free history and charging that scalar the minimum H(1)=1 gives this bound.
 after_minimum=price.signed(Counter({1:72,3:36}),Counter({5:36}),k)
 need(gross[0]>0 and after_minimum[1]<0,'restoration destroys optimistic sign')
 optimistic[k]={'gross_without_restoration':price.interval_output(gross),
                'upper_bound_with_one_grade_one_restoration':price.interval_output(after_minimum)}

out={}
for name in ('direct','two-recodes'):
 path=H/'words'/f'{name}.json.gz';q=read(path);origin=read(H/'words'/f'{name}.origin.json')
 need(len(origin)==len(q['program']) and all(q[k]==w[k] for k in w if k!='program'),'frozen layout and endpoints')
 obs,packets=observe(q,origin)
 changed={i: {'old':bits(old[i]),'new':bits(obs[i])} for i in obs if i in old and old[i]!=obs[i]}
 expected={2916,2917,2921,2922} if name=='two-recodes' else set()
 need(set(changed)==expected,f'all original event outputs preserved outside the two recodes: {changed.keys()}')
 need(all(obs[i]==old[i] for i in (5207,6326,8957,8961,8964)),'retained arrivals and three old exits')
 if name=='direct':
  need([(x['source'],x['destination'],x['grade']) for x in packets]==[(45,560,6),(560,388,1)],'direct physical route')
 else:
  need([(x['source'],x['destination'],x['grade']) for x in packets]==[(0,160,2),(160,283,2),(283,560,3),(560,388,1)],'recoded funded physical route')
  need(changed[2917]['new']==[321] and changed[2922]['new']==[43],'actual two recoded ingress values')
  need(packets[0]['support']==[321,527] and packets[1]['support']==[74,321,405,527] and packets[2]['support']==[43] and packets[3]['support']==[43],'actual correction and relay payloads')
 forward=op.run_tape(q,atlas,False);backward=op.run_tape(q,atlas,True)
 for reverse,t in ((False,forward),(True,backward)):
  need(t.output==op.expected_operator(reverse),'all 680 by 680 coefficients')
  need(t.dirty==3554,'all owned dirty retirements')
  bridge_clock,=[i for i,e in enumerate(q['program']) if e[0]=='MOVE' and e[1]==3553]
  bridge_id=680+sum(e[0]=='MOVE' for e in q['program'][:bridge_clock]);bridge=t.packets[bridge_id]
  need((bridge.source,bridge.receiver,bridge.arrival.row,bridge.grade)==((*((1,509) if reverse else (509,1)),1<<411,4)),'protected bridge')
  need([i for i,x in t.packets.items() if x.arrival.row>>411&1]==[bridge_id],'bridge isolation')
  skip,=[i for i,e in enumerate(q['program']) if e[0]=='ADD' and e[1]==3553 and e[2]==411]
  omission=op.run_tape(q,atlas,reverse,omit=skip).output
  need([a^b for a,b in zip(omission,t.output)]==[(1<<411) if i==411 else 0 for i in range(680)],'bridge omission')
 np,nt,paid,targets=op.binary_invoice(q,caller,atlas,forward)
 need(nt==nt0 and targets==targets0,'all productive grades unchanged')
 indpaid,indtargets,physical=independent.recount_from_candidate(q,caller,charts)
 need((indpaid,indtargets)==(paid,targets),'independent complete invoice')
 need(physical['dirty_retirements']==[3554,3554] and physical['owned_fields']==ind0_trace['owned_fields'],'owned retirements and account')
 expected_delta=Counter({1:1,6:1,5:-1}) if name=='direct' else Counter({1:1,2:2,3:1,5:-1})
 delta=subtract(np,np0);need(delta==expected_delta,'native paid delta')
 delta36=subtract(paid,paid0);need(delta36==Counter({k:36*v for k,v in delta.items()}),'36 call paid delta')
 prices={}
 for k in rates:
  oldp=base_price[k];newp=price_int(paid,targets,k)
  gain=(newp[0]-oldp[1],newp[1]-oldp[0])
  need(newp[1]<0 and gain[1]<0,'complete and signed gain both negative')
  need(overlap(newp,primary_interval(paid,targets,k)),'candidate arithmetic independent overlap')
  prices[k]={'baseline_complete_signed':price.interval_output(oldp),'candidate_complete_signed':price.interval_output(newp),'gain_36_calls':price.interval_output(gain)}
 out[name]={'word_gzip_sha256':sha256(path.read_bytes()).hexdigest(),'canonical_sha256':sha256(v.canon(q)).hexdigest(),
 'native_events':len(q['program']),'physical_added_packets':packets,'changed_original_outputs':changed,
 'all_other_original_add_and_move_outputs_identical':True,'three_original_exits_preserved':True,
 'native_paid_delta':counts(delta),'caller_paid_delta':counts(delta36),'full_paid':counts(paid),'full_productive':counts(targets),
 'physical_independent':physical,'prices':prices}

# Legal local mutation: omit the recoded-control correction and show that
# independently run full forward AND adjoint endpoint checks catch it.
q=read(H/'words/two-recodes.json.gz');i,=[i for i,e in enumerate(q['program']) if e==['ADD',1496,927,283]]
mut=dict(q);mut['program']=q['program'][:i]+q['program'][i+1:]
rejections=[]
for reverse in (False,True):
 try:independent.run_word(mut,charts,reverse)
 except ValueError as e:
  need(str(e)=='all-public linear operator','wrong mutation disposition');rejections.append(str(e))
 else:raise ValueError('omitted restoration accepted')
observer=read(H/'words/two-recodes.json.gz');j,=[j for j,e in enumerate(observer['program']) if e==['ADD',2583,927,388]]
observer['program'][j]=['ADD',2583,2023,388]
observer_rejections=[]
for reverse in (False,True):
 try:independent.run_word(observer,charts,reverse)
 except ValueError as e:
  need(str(e)=='all-public linear operator','wrong observer disposition');observer_rejections.append(str(e))
 else:raise ValueError('changed 388 reader accepted')
price_controls={}
for k in rates:
 altered=paid0.copy();altered[2]+=1
 bad=price_int(altered,targets0,k)
 need(bad[1]<base_price[k][0],'additional paid grade-two scalar decreases complete price')
 price_controls[k]={'one_extra_grade_2_strictly_decreases_signed_balance':True}
result={'status':'PASS_LITERAL_RELAY_OPERATOR_AND_COMPLETE_CALLER_INVOICES',
 'scope':'Two mathematical native literal words and unchanged 36-call caller, with exact public maps, charts, ownership, bridge, all retained original event outputs, productive and paid counts. No compiler, erasure, precision-tape or outer-theorem qualification.',
 'caller_polynomial_coefficients_each_direction':38**2,'caller_forward_sha256':call_f,'caller_adjoint_sha256':call_r,
 'baseline_physical':ind0_trace,'optimistic_grade_three_relay_price':optimistic,
 'controls':out,'predecessor_archive_sha256':'8756014ac027bbe6aaad673af12b49ecd7f3b0a3f5688374e06babeec91a473a',
 'omitted_correction_clock':i,'omitted_correction_rejections':rejections,
 'mutated_receiver_clock':j,'mutated_receiver_rejections':observer_rejections,'price_negative_controls':price_controls}
data=json.dumps(result,indent=2,sort_keys=True)+'\n'
if need_write:(H/'RESULT.json').write_text(data)
need((H/'RESULT.json').read_text()==data,'full receipt differs from checked-in RESULT.json')
for name,x in out.items():
 print(name,'paid delta',x['native_paid_delta'],'caller paid delta',x['caller_paid_delta'])
 for k,t in x['prices'].items():print(' ',k,'gain',t['gain_36_calls'],'complete',t['candidate_complete_signed'])
print('omitted correction rejected both orientations')
