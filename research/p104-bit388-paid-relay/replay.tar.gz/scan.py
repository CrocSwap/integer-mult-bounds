#!/usr/bin/env python3
"""Live, single-new-MOVE relay search in the pinned word (one process).

With source edits limited to removing the old clock-880 field construction,
enumerate source-chart live banks after each event and all four combinations
of the two original chart-560 rows and x43 plus the two fixed 388 arrivals.
Every reported bank witness is a real same-chart XOR at the recorded cut.
"""
from collections import Counter, defaultdict
from hashlib import sha256
from pathlib import Path
import gzip, json, sys
if not __debug__:raise RuntimeError('assertions must remain enabled')

H=Path(__file__).resolve().parent
TWO_RECODINGS='--two-recodes' in sys.argv[1:]
WRITE='--write-results' in sys.argv[1:]
assert set(sys.argv[1:]) <= {'--two-recodes','--write-results'}
raw=(H/'WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw)); p=w['program']; n=w['public']; count=n+w['owned_fields']
assert n==680 and p[878:881]==[['INIT',927,45],['ADD',927,43,45],['MOVE',927,45,388]]

def members(x):return [i for i in range(n) if x>>i&1]
def grade(c,d):
 a=w['frames'][str(c)];b=w['frames'][str(d)]
 if a['dim']>b['dim']:a,b=b,a
 if not all(sum(x*y for x,y in zip(row,normal))==0 for row in a['B'] for normal in b['A']):return None
 return b['dim']-a['dim']
def bas(rows):
 out={}
 for value, role in rows:
  mask=1<<role
  while value:
   pivot=value.bit_length()-1
   if pivot not in out:out[pivot]=(value,mask);break
   r,m=out[pivot];value^=r;mask^=m
 return out
def solve(b,value):
 mask=0
 while value:
  pivot=value.bit_length()-1
  if pivot not in b:return None
  v,m=b[pivot];value^=v;mask^=m
 return mask

# Obtain target and 560 stock from a separate baseline forward replay.
v=[1<<i for i in range(n)]+[0]*w['owned_fields']; tag=w['start'][:]+[None]*w['owned_fields']
for clock,(op,r,*a) in enumerate(p[:8954]):
 if op=='INIT':assert tag[r] is None;tag[r]=a[0];v[r]=0
 elif op=='CLEAR':assert tag[r]==a[0];tag[r]=None;v[r]=0
 elif op=='ADD':assert tag[r]==tag[a[0]]==a[1];v[r]^=v[a[0]]
 elif op=='SWAP':s=a[0];tag[r],tag[s]=tag[s],tag[r];v[r],v[s]=v[s],v[r]
 elif op=='MOVE':assert tag[r]==a[0];tag[r]=a[1]
 else:raise ValueError(op)
u=[v[i] for i in (927,2023,2190)]; stock=[v[i] for i in (2578,2581)];old_1496=v[1496]
assert u[0]==1<<43 and tag[2578]==tag[2581]==560 and len(bas([(q,i) for i,q in enumerate(u)]))==3
assert len(bas([(q,i) for i,q in enumerate(stock)]))==2
assert all(solve(bas([(q,i) for i,q in enumerate(stock)]),
                 (u[0] if k&1 else 0)^(u[1] if k&2 else 0)^(u[2] if k&4 else 0)) is None
           for k in range(1,8))
goals={(tm,sm):u[0]^(u[1] if tm&1 else 0)^(u[2] if tm&2 else 0)^(stock[0] if sm&1 else 0)^(stock[1] if sm&2 else 0) for tm in range(4) for sm in range(4)}
grades={int(c):grade(int(c),560) for c in w['frames'] if int(c)!=560}
grades={c:g for c,g in grades.items() if g is not None and g>0}
assert grade(45,388)==5 and grade(560,388)==1

# The old 388 field is genuinely absent throughout this replay: it cannot be
# counted as a source by any candidate. Snapshot is after each original event.
v=[1<<i for i in range(n)]+[0]*w['owned_fields']; tag=w['start'][:]+[None]*w['owned_fields']
roles=defaultdict(set)
for r,c in enumerate(w['start']):roles[c].add(r)
history_283=[(f'public-{r}',v[r]) for r,c in enumerate(w['start']) if c==283]
restore_screen=None
hits={}; singles={}; observations=Counter(); checks=Counter()
def inspect(c,clock):
 if c not in grades:return
 rs=sorted(roles[c]);
 if not rs:return
 bb=bas((v[r],r) for r in rs)
 checks['bank_snapshots']+=1
 for (tm,sm),goal in goals.items():
  label=(c,tm,sm);solution=solve(bb,goal)
  if solution is not None:
   observations['bank_matches']+=1
   if label not in hits:
    chosen=[r for r in rs if solution>>r&1]
    hits[label]={'chart':c,'grade':grades[c],'after_clock':clock,'target_mask':tm,'stock_mask':sm,'source_roles':chosen,
      'source_role_supports':[members(v[r]) for r in chosen],'bank_size':len(rs),'bank_rank':len(bb)}
  # Enumerate all actual singleton fields separately rather than relying on
  # an arbitrary basis solver's choice of representation.
  for r in rs:
   if v[r]==goal:
    observations['singleton_matches']+=1
    key=(c,tm,sm,r)
    if key not in singles:singles[key]={'chart':c,'grade':grades[c],'after_clock':clock,'target_mask':tm,'stock_mask':sm,'role':r,'support':members(v[r])}
for c in sorted(roles):inspect(c,-1)
for clock,(op,r,*a) in enumerate(p[:8954]):
 if TWO_RECODINGS and clock==5191:
  # Even granting free shadows of EVERY input ever received by chart 283,
  # its original 1496 and the first original ADD output are unavailable.
  assert (op,r,a)==('ADD',2021,[1496,283])
  history_basis=bas((row,j) for j,(_,row) in enumerate(history_283))
  original_first_output=old_1496 ^ v[2021]
  assert solve(history_basis,old_1496) is None and solve(history_basis,original_first_output) is None
  plus_one=bas([(row,j) for j,(_,row) in enumerate(history_283)]+[(old_1496,len(history_283))])
  assert solve(plus_one,old_1496) is not None and solve(plus_one,original_first_output) is not None
  restore_screen={'first_original_reader_clock':clock,'reader':p[clock],
   'original_scalar_support':members(old_1496),'recoded_scalar_support':members(v[1496]),
   'original_first_output_support':members(original_first_output),
   'history_rows':[{'clock':k,'support':members(row)} for k,row in history_283],
   'history_rank':len(history_basis),'original_scalar_in_free_history_span':False,
   'original_first_output_in_free_history_span':False,'added_original_scalar_positive_control':True}
 if clock in (878,879,880) or TWO_RECODINGS and clock==2920:continue
 if TWO_RECODINGS and clock==2916:op,r,a='ADD',1495,[321,0]
 affected=set()
 if op=='INIT':assert tag[r] is None;tag[r]=a[0];v[r]=0;roles[a[0]].add(r);affected.add(a[0])
 elif op=='CLEAR':assert tag[r]==a[0];roles[a[0]].remove(r);tag[r]=None;v[r]=0;affected.add(a[0])
 elif op=='ADD':
  s,c=a;assert tag[r]==tag[s]==c;v[r]^=v[s];affected.add(c)
 elif op=='SWAP':
  s=a[0];cr,cs=tag[r],tag[s];assert cr is not None and cs is not None
  roles[cr].remove(r);roles[cs].remove(s);roles[cs].add(r);roles[cr].add(s)
  tag[r],tag[s]=tag[s],tag[r];v[r],v[s]=v[s],v[r];affected.update((cr,cs))
 elif op=='MOVE':
  s,d=a;assert tag[r]==s;roles[s].remove(r);roles[d].add(r);tag[r]=d;affected.update((s,d))
  if d==283:history_283.append((clock,v[r]))
 else:raise ValueError(op)
 for c in sorted(affected):inspect(c,clock)
assert 927 not in [r for rs in roles.values() for r in rs]
assert tag[2023]==tag[2190]==388 and tag[2578]==tag[2581]==560
assert [v[i] for i in (2023,2190)]==u[1:] and [v[i] for i in (2578,2581)]==stock
bank=sorted(hits.values(),key=lambda z:(z['after_clock'],z['grade'],z['chart'],z['target_mask'],z['stock_mask']))
single=sorted(singles.values(),key=lambda z:(z['after_clock'],z['grade'],z['chart'],z['target_mask'],z['stock_mask'],z['role']))
scope='One added paid scalar MOVE from a live source bank into 560, with original 927 construction removed; arbitrary live XOR at source and arbitrary combination with 560 two fixed rows; one 560-to-388 scalar; original 283 and 311 deliveries unchanged. Snapshots immediately after each source chart changes, before old clock 8954. A positive is an information witness only until emitted and replayed.'
scope+=(' Two existing MOVE payloads are recoded by replacing original ADD(1495,527) at 2916 with ADD(1495,321) and omitting ADD(1496,1122) at 2920; altered 1496 is NOT restored, so later banks are optimistic and may break original readers.' if TWO_RECODINGS else ' No other existing payloads changed.')
out={'scope':scope,
 'word_sha256':sha256(raw).hexdigest(), 'target_supports':[members(q) for q in u],
 'stock_560_roles':[2578,2581],'stock_560_supports':[members(q) for q in stock],
 'legal_source_grade_counts':dict(sorted(Counter(grades.values()).items())),
 'bank_snapshots':checks['bank_snapshots'],'bank_and_single_match_observations':dict(observations),
 'bank_witness_count':len(bank),'bank_witnesses_by_grade':dict(sorted(Counter(x['grade'] for x in bank).items())),
 'singleton_witness_count':len(single),'singleton_witnesses_by_grade':dict(sorted(Counter(x['grade'] for x in single).items())),
 'bank_witnesses':bank,'singleton_witnesses':single,'reader_restoration_screen':restore_screen}
path=H/('SCAN-two-recodes-unrestored.json' if TWO_RECODINGS else 'SCAN.json')
data=json.dumps(out,indent=2,sort_keys=True)+'\n'
if WRITE:path.write_text(data)
assert path.read_text()==data,'scan differs from checked-in receipt'
print('bank snapshots',checks['bank_snapshots'],'bank witnesses',len(bank),'by grade',out['bank_witnesses_by_grade'])
print('singleton witnesses',len(single),'by grade',out['singleton_witnesses_by_grade'])
print('first banks',bank[:12]);print('first singles',single[:12])
