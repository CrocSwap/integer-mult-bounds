# Finite handoff for the first 15-place target

**No changed candidate, finite supplier, or κ improvement is certified here.**
This is a source-pinned conditional handoff for a possible Round 3 word. It
uses #7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, the sanitized
451-factor #7863 archive at `b3e4412fe01f07dc58305616fabf96345f49a781`, and
#7868 at `3f7c3c1f2a9a0963736562037e01fe41aec46b8c`. The independently
directed upper endpoint of the **unchanged** BIT signed profile is
`U=0.003879928046155`. The first 15-decimal number above it is
`K=0.003879928046156`.

The script checks source hashes and uses the #7830 directed interval engine,
the #7863 source consumer gate, and exact rational/integer arithmetic. Its
changed selector reproduces the unmodified source selector at 14 places; it
does not execute a modified native word, 451 product, cover, compiler,
precision-tape proof, or full consumer. All examples below require a real
word with its own complete physical and signed receipts.

## What “minimum grid” means

`10^-15` is the coarsest decimal tick that represents **exactly K**. A
coarser grid can certify K by certifying a stronger rate: the existing
`10^-14` selector first claims `0.00387992804616`. Finer ticks reduce the
rate demanded of a future BIT supplier. There is no universal smallest
positive spacing: a finer grid and smaller positive losses can always be
proposed, subject to their finite and physical proofs.

The retained selector with tick `g` and positive rational crossing to the
right selects `claim=(min(left,floor(cap/g))-8)g` and tests `claim+7g`.
It therefore requires `cap≥claim+8g`. The original code hard-codes 14-place
formatting **and** the integer right search endpoint `690000000000` in those
ticks. A finer implementation must change `TICKS`, formatting, and that
endpoint together; changing only the first two makes its initial bracket
invalid. The script checks exact reproduction of the original 14-place
selector and brackets the 18-place rational crossing at
`[0.003880136444745846,0.003880136444745847]`.

With the original seed `s=0.00385248`, `rho=1/250`, seven strict ordinary
stages, uniform loss `e`, and cover loss `d`, the final ordinary cap `a_7`
satisfies

```
a_7 < (1-rho^7)(C-e-d)+rho^7 s.
C > e+d + (claim+8g-rho^7 s)/(1-rho^7).
```

This is a strict **necessary** raw-trial bound for the named selector and
stage count; it is not sufficient to construct the BIT supplier. Here are
outward rounded lower thresholds, with `e_old=2.5e-12`, `d_old=1e-13`,
`e_new=1e-19`, and `d_new=1e-20`:

| Grid and losses | First claim ≥ K | Necessary raw C, strictly greater than |
| --- | --- | --- |
| 14 places, old | `0.00387992804616` | `0.003879928048840000000449708789596160...` |
| 15 places, old | `0.003879928046156` | `0.003879928048764000000449708788350976...` |
| 15 places, new | `0.003879928046156` | `0.003879928046164000110449708788350976...` |
| 18 places, new | `0.003879928046156` | `0.003879928046156008110449708788220035...` |

The 15- and 18-place rows require a newly bound selector and new losses;
neither is an already certified application.

## One fully specified numerical schedule

Set `g=1e-18`, `e=1e-19`, `d=1e-20` and test raw
`C=0.0038799280461560083`. Keep `v=451`, cutoff `11^v`, floor `16^v`,
ambient `134^v`, `u=13/50`, `w=17/50`, and `theta=13/15`. The following
checks hold **if** a changed word supplies the required strict moment and
physical interfaces:

* The unchanged 451 uniform-parameter inequalities pass at C with log power
  60 and `H=log2(N)=45160000000000000000000`. This is the first point on the
  `e=1e-19` H-grid satisfying `(H+1)^60<2^(eH)`. The test checks the initial
  range and monotonicity of the integer-grid ratio before binary search.
* The original delayed-cover sufficient budget is met by a newly frozen
  catalogue and odd `q>2^75 N^5`, since `64/2^75<d/4` but one fewer bit
  fails that budget. The actual `H d=2258/5`, so the source good-class
  multiplier also fits. Prime existence assumes a finite, q-independent
  complete exclusion list and still requires the genuine fresh-child/fallback
  and restored-stock implementation.
* Seven strictly rounded 20-place stages yield ordinary cap
  `0.00387992804615600817`. The first is
  `0.00387981825397138414`; all seven and strict gaps are in `EXPECTED.json`.
  A **new** cold stage from an elementary base can arithmetically fund the
  seed because `(1-rho)(C-e-d)-s = 0.00001192833397138415724`.
  Doing so gives eight nontrivial stages if all eight physical interfaces are
  actually re-instantiated. Reusing an old completed seed instead requires
  including its real nested stock and precision bill.
* The adapted 18-place selector returns K, with tested rate
  `0.003879928046156007` and cap headroom `1.17e-18`. On the **unchanged**
  48-call rational histogram, the copied source gate passes its complete
  directed moment checks, 54 strict and four functional arithmetic checks,
  and input lift. Its rational `H` is `184014000000000000000000`, log power
  2381, and the common-root argument has 14,110 bits. The analogous 15-place
  source gate gives rational `H=159801000000000000000`.

The script also proves the outer formulas' 58 margins are all at least `g/10`
throughout `0<g≤1e-15`, at claim K and hypothetical cap `K+8g`: each source
formula is a degree-at-most-two rational polynomial, and exact coefficients
are bounded over the interval. It verifies source rational moment envelopes
over that interval. This is not a compiler replay at every such gap.

The old BIT invoice at the example C is **negative**:

```
M_old(C) ∈ [-0.000000000770198055995903043637252413569166,
            -0.000000000770198055995903043637252413569165].
```

Thus a real changed profile needs strictly more than that magnitude in
complete signed Δ merely to make the raw moment positive at C. This is not
an achieved Δ. Actual discarded targets, new jobs, ownership, recursion and
all changed occurrence ranks must be charged.

## Raw positivity and tensor separation are different

For a changed complete profile at C, let `T=T_(1-C)>0`, `P=P_(1-C)`,
`alpha=P/T`, `gamma=P_(1-C+13/50)/(11^(13/50)T)`, and
`lambda=16^(17/50)T_(1-C-17/50)/T`. The 451 certificate needs outward caps
that establish

```
1/(1+451(1-alpha_cap)) + 2 gamma_cap^451 + lambda_cap^451 < 1.
```

With `D=2 gamma^451+lambda^451`, a necessary actual-ratio condition is
`(T-P)/T > D/[451(1-D)]`, as well as `D<1`. An unshifted positive signed
margin alone does not imply it. At the example C, **if only hypothetically**
the changed profile retained the old T, gamma and lambda, it would need
signed Δ above `0.00000000270903716211159889625...`; that numerical bound is
not universal because a real edit may change all three.

If an actual candidate has `C>K`, `alpha<1`, `gamma<1`, and `lambda<1`,
then for suitable outward rational caps below one the displayed expression
tends to zero as the tensor count grows. A sufficiently large finite tensor
count therefore passes this **moment inequality**. This is only an
asymptotic existence observation for the moment test. The new tensor power
requires its own occurrence construction, exact tail and target-floor
witnesses, H and logarithmic bounds, compiler, owners, padding, stock,
precision, and consumer. Very small margins may also require finer cap
rounding and more than the source's 70/80-digit arithmetic.

For any fixed strict raw advantage `C-K>0`, after those separate ratio
conditions hold one can choose a fine enough decimal `g` and small positive
`e,d`, then use sufficiently many strictly chosen ordinary stages so the
pure rate losses fit below `C-K`. This explains why there is no universal
positive raw-price gap induced solely by the choice of decimal grid. It is
**not** a proof that those additional tensor, stock or physical contracts
hold for an arbitrary raw-positive word.

## #7868's alternative and the stock guard

[#7868's carrier proof](https://github.com/CrocSwap/integer-mult-bounds/blob/3f7c3c1f2a9a0963736562037e01fe41aec46b8c/research/bounded-general-multiplier/CARRIER-PROOF.md)
uses the original 480-factor source, six ordinary stages and a shifted
periodic compiler. Its [ternary construction](https://github.com/CrocSwap/integer-mult-bounds/blob/3f7c3c1f2a9a0963736562037e01fe41aec46b8c/research/bounded-general-multiplier/TERNARY-COVER.md)
checks the original 636 native and 111 joint-port frames, three-local
projectors/matchers and a worst-case **nine-child** rank-one leaf. It fixes
`q=3` and removes the old bad-pivot-frequency surcharge, but it does **not**
make the leaf free: if the uniform ratio is `P/B<N^(1-C+e)`, its covered
moment still needs `9 N^(-d)<1`. The example passes the isolated arithmetic
`9<2^floor(Hd)`; the changed leaf, all row multiplicities, routes and work
have not been constructed.

For a changed word, using q=3 requires re-establishing that every actual
projector and matcher is defined over the rationals local at three, every
needed frame determinant is a 3-adic unit, every changed nested difference
and port placement is valid, and the factored routes and nine-child leaf
implement all payloads and restore all spectators. #7868's finite census,
coefficient bounds, 480-fold parameters and six-stage receipt are not
automatically certificates for a changed word or for this 451-fold,
eight-stage schedule. An arbitrary fixed q outside a newly frozen exclusion
catalogue is a separate option with its own frequency and stock charges.

Even q=3 requires the true row reserve

```
W=B |GL_N(F_q)| q^(N^2(w-1)),
D=2+ceil(log_N(max(1,ceil(E/w)))),
w=ceil(E^(1/250)),
```

with the entire group, high fibres, old backing and eventual restoration.
If a borrowed `k` q-adic digits must hold `W^D` and `k<E/2`, then the
unit-upper-triangular subgroup and `D≥2` imply
`E>4N^2(w-1)+2N(N-1)`. For `E≥2^250` this gives the necessary bound

```
log2 E > (250/249)(2H+1)
       = 90682730923694779116466.867469879518...  (example H).
```

This is a lower bound on the **logarithm of q-adic input width**, not a
constructive activation threshold. #7868's reported numeric sufficient
threshold `481927710843386` uses its own H and six-stage hypotheses and
cannot be substituted into this example.

A conditional paper generalization of #7868's six-stage arithmetic gives an
explicit sufficient **stock-size shape** for `m` stages. Suppose `q=3`,
`N=2^H`, `H≥4`, `u=log2 E`, and the actual simultaneous ledger proves

```
0≤b_i≤N^2,  0≤w_i≤2·2^(u/250),  0≤D_i≤3+u/H,
k≤1+sum_i D_i(b_i+N^2 w_i).
```

Let `B=ceil(log2(36m+3))` and
`T=ceil(250(2H+B)/249)≤3H`. For `u≥T`, put
`x=2^(u/250)` and `y=2^((249/250)(u-T))`. The source's elementary bound
`y≥1+(u-T)/4` gives `3+u/H≤6y`; hence
`k≤(18m+1)N^2 yx`. The definition of T gives
`2^u≥2^B N^2 yx`, and `2^B>2(18m+1)`, so `k<E/2`.
For the example H, the conditional threshold is
`log2 E≥90682730923694779116474` for seven debts, or
`log2 E≥90682730923694779116475` for eight. The m-stage extension is a
paper argument plus exact integer controls, **not** the six-stage Lean
theorem itself and not a proof that the changed ledger has the stated shape.
Additional distinct old-seed reserves or conversions must be charged and may
increase m or invalidate the shape.

## Next binding and replay steps

On receiving an actual word from the lead, authenticate its canonical and
gzip hashes; independently replay forward and adjoint arbitrary-input
operators, complete occurrence labels and ownership; count all 36-call paid
and productive ranks and physical work; then evaluate its α, gamma, lambda
and complete signed margin at the selected C. Only after a real strict
moment survives should the candidate-specific product and every dropped
target, 3-local or frozen-q cover, `W^D` ledger, initial seed, seven or more
precision/ordinary stages, and full rational consumer be rebuilt. The
qualifier and expanded auditor both hard-code the old BIT word and receipt;
they must be bound to the actual new word and completed supplier before a
consumer replay. The retained premises are `native_all_columns`,
`owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery`.

For the independent BIT evaluator's receipt shape, a bounded first price is:

```
python3 -B candidate_probe.py --receipt RECEIPT.json --word WORD.json.gz \
  --trial 0.0038799280461560083 --tensor 451 --out CANDIDATE-PRICE.json
```

The probe checks the receipt's gzip hash against the supplied word, reports the
canonical JSON hash, prices complete signed bins directly, and evaluates the
outward-capped 451 moment bound. Its label/grade support, target-floor, and
old resource-limit flags are **screens only**; it does not replay any native
operator, prove the receipt's bins or counts, verify independent targets, or
construct the physical and precision interfaces. The bound's selected
40-place caps are conservative and may be too coarse for extremely small
margins; using them requires a refined supplier because the archived 451
program rounds caps to 22 places. The probe also reports a 22-place check
from this **one** interval engine; the archived program takes the largest
upper bound from three engines, so its full test still must be rerun. Its
`--tensor` option is a bounded integer calculation, not an implementation of
a new tensor supplier.

For a receipt with a *directed positive* raw margin at a trial `C>K`, the
probe also constructs a conditional exact-rational rate plan: it chooses a
decimal gap `g` with `64g<C-K`, sets `e=g/100` and `d=g/1000`, and chooses
enough strictly funded stages above the seed to exceed `K+8g`. It then
reports the conservative adapter cap `K+8g`. This plan does not claim that
the supplied tensor passes the moment bound or that any stage, its cover,
stock or precision exists. It flags when a much finer source interval engine
needs review and limits this diagnostic to at most 100 decimal places and 128
stages.

If a receipt is positive **at K** but has no already priced positive trial
above K, the probe uses the positive directed margin at K and an absolute
derivative upper bound `sum_r |T[r]-P[r]| r^(1-K) log(r)` to construct a
strictly larger rational trial with a positive lower margin. It chooses an
advance at most half the margin divided by that bound, then reprices it.
The resulting plan still needs its alpha, gamma, lambda and all physical
conditions rerun at the new trial. A positive margin below K alone cannot
justify this step if the separately checked margin at K is nonpositive.

The Round 2 independently replayed zero-net word is a negative control: the
probe obtains exactly zero signed Δ, a negative raw margin and a failed 451
bound. A second **synthetic histogram-only** control removes one paid
grade-one occurrence and exercises the positive-arithmetic path; no executed
word or physical deletion is implied. A word with the wrong gzip bytes was
rejected.

For the standard-library offline replay, from this directory run:

```
python3 -I -B self_test.py
python3 -I -B replay.py
```

The self-test makes a fresh temporary copy, checks the SHA-256 inventory,
replays it, scans inputs including the compressed word for host paths, and
rejects a modified source, altered receipt and optimized Python mode. The
replay compares the rate-grid result and zero-net price with the committed
expected bytes, then exercises the target-positive derivative bridge and a
`1e-60`-advantage rate plan using a clearly synthetic histogram. It rejects a
word with a mismatched gzip hash. `--output-dir` selects a different output
directory. Source bytes are authenticated locally, including Git-blob checks
for the included #7868 subset. The programs do not fetch or modify an upstream
source.

The bundled zero-net receipt is a minimal, path-free extract of the separate
Round 2 evaluator's receipt, which has SHA-256
`1a527f9776cd1fa404a34ed2bf03e1faf1b4fe0c5ba968c3df5e6d3d53723d3a`.
The word's gzip SHA-256 is
`e83abcf1a2bba96681ac14bc6c76eb4ff78db86f7677ea1f19c1b839cdf275a8`.
The compact extract is a control input; replaying it here does not repeat the
independent operator or ownership checks.

#7868's ternary and stock work is credited to Ali Romman, prepared with
substantial OpenAI Codex assistance, and the contributors identified in its
source notices; the remaining #7830 and #7863 credits are retained with the
source subset. See `NOTICE.md` and the original notices for attribution.
