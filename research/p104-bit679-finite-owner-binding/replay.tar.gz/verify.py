#!/usr/bin/env python3
"""Check the inventory and replay the finite fixture in a clean temporary copy."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import shutil, subprocess, sys, tarfile

ROOT=Path(__file__).resolve().parent

def need(ok,message):
    if not ok: raise ValueError(message)

def source_authentication():
    archives={
        'REMOTE-7907.tar.gz':('e53e772469766f30ff6ed7d1aee9e4c21d7863fff5cec5185b4e2e3d11daa692',
          [(f'./upstream/{x}',f'upstream/{x}') for x in ('periodic.py','powered.py','tagged_sources.py','ternary_frames.py','ternary_leaf.py','NOTICE.md','FLOW-NOTICE.md')]+[('./LICENSE','LICENSE')]),
        'REMOTE-7911.tar.gz':('4d7138d84a5af55c56316191db743c63b3a82d1f46d0fad7a851d34d0765f45e',
          [('./EXPECTED.json','inputs/EXPECTED-7911.json'),('./README.md','inputs/README-7911.md'),('./SOURCE-7863.json','inputs/SOURCE-7863.json')]),
        'REMOTE-7912.tar.gz':('87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096',
          [('./project.py','project.py'),('./ZERO-CONTROL-WORD.json.gz','inputs/ZERO-CONTROL-WORD.json.gz')]+[(f'./inputs/{x}',f'inputs/{x}') for x in ('WORD.json.gz','physical.py','finite.py','bit_native.py','literal.py','EFREE-CALLER.json.gz','NOTICE-7786','NOTICE-7830','NOTICE-PAID-BIRTHS','LICENSE')])}
    for filename,(wanted,files) in archives.items():
        path=ROOT/filename
        need(sha256(path.read_bytes()).hexdigest()==wanted,'published archive SHA mismatch: '+filename)
        # Read named members only; never extract archive paths to the filesystem.
        with tarfile.open(path,'r:gz') as archive:
            for member,local in files:
                source=archive.extractfile(member)
                need(source is not None and source.read()==(ROOT/local).read_bytes(),
                     'archive member mismatch: '+filename+':'+member)

def main():
    need(__debug__,'run without optimized Python')
    entries=[]
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        wanted,name=line.split('  ',1)
        path=Path(name)
        need(not path.is_absolute() and '..' not in path.parts,'bad manifest path')
        data=(ROOT/path).read_bytes()
        need(sha256(data).hexdigest()==wanted,'file SHA mismatch: '+name)
        entries.append(name)
    need('replay.py' in entries and 'RESULT.json' in entries and 'TABLES.json.gz' in entries,'incomplete manifest')
    source_authentication()
    with TemporaryDirectory(prefix='p104-679-owner-') as tmp:
        root=Path(tmp)
        for name in entries:
            src=ROOT/name;dst=root/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
        proc=subprocess.run([sys.executable,'-I','-B','replay.py'],cwd=root,capture_output=True,text=True)
        need(proc.returncode==0,'clean replay failed: '+proc.stderr)
        for name in ('RESULT.json','TABLES.json.gz'):
            need((root/name).read_bytes()==(ROOT/name).read_bytes(),'replay output mismatch: '+name)
        word=root/'inputs/ZERO-CONTROL-WORD.json.gz'
        data=bytearray(word.read_bytes());data[len(data)//2]^=1;word.write_bytes(data)
        bad=subprocess.run([sys.executable,'-I','-B','replay.py'],cwd=root,capture_output=True,text=True)
        need(bad.returncode!=0 and 'source SHA' in bad.stderr,'modified word was not rejected by input pin')
        optimized=subprocess.run([sys.executable,'-O','-I','-B','replay.py'],cwd=root,capture_output=True,text=True)
        need(optimized.returncode!=0 and 'run without Python -O' in optimized.stderr,'optimized mode was not rejected')
    print('PASS_INVENTORY_CLEAN_REPLAY_AND_SOURCE_CONTROLS')
if __name__=='__main__':main()
