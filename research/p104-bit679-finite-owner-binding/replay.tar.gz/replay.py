#!/usr/bin/env python3
"""Reconstruct the 679-owner control, call bindings and one local two-factor leaf.

This is a finite diagnostic, not a supplier or precision-tape certification.
Run with assertions enabled. Output is confined to this directory by default.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from itertools import islice
from math import lcm
from pathlib import Path
import gzip, json, random, sys

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'inputs'),str(HERE/'upstream')]
import physical, bit_native as bit, literal
import project as p
from tagged_sources import binary_ports
from powered import PoweredWord
from ternary_frames import (projector, transpose, split, multiply, native_factors,
                            covered_factors, identity, frame_at_three)
from ternary_leaf import run_leaf, select_pivot

OLD='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
NEW='09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be'
PINS={'inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
      'inputs/ZERO-CONTROL-WORD.json.gz':'f0aa75a63cc9200f627721851bd68c27367ae80e7fca2f0fe6f515fe2bfc9f63',
      'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'}

def require(test,msg):
    if not test: raise ValueError(msg)

def digest(x):
    return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def load_input(name):
    b=(HERE/name).read_bytes();require(sha256(b).hexdigest()==PINS[name],'source SHA: '+name)
    return json.loads(gzip.decompress(b))

def reconstruct(old,new):
    # Follow the actual #7912 producer, preserving original graph labels.
    S={649}; eliminated=3266; donors={2926,2982}
    state=p.project(S,keep=donors|{eliminated})
    require(state['erased']==0,'unexpected extra pruning')
    mask=1<<649
    initial={i:c for i,c in p.initial.items() if i not in S}
    final={i:c for i,c in p.final.items() if i not in S}
    moves={i:p.moves[i] for i in state['alive'] if i!=eliminated}
    rows={i:p.orig[i]&~mask for i in state['alive'] if i!=eliminated}
    rows.update({~i:p.orig[~i]&~mask for i in final})
    dr=p.orig[eliminated]&~mask&~(1<<eliminated)
    require(dr==0,'expected specialized donor row to vanish')
    for d in donors: rows[d]^=dr
    for j in rows: rows[j]&=~(1<<eliminated)
    forward,fr=physical.dual(p.n,moves,rows)
    order=bit.schedule(final,initial,forward,fr)
    rebuilt=bit.emit_word(old,final,initial,forward,fr,order)
    require(rebuilt==new,'literal rebuilt word differs')
    owners=sorted(initial)
    old_routes,_,oldcl=physical.packet_word(old)
    new_routes,_,newcl=physical.packet_word(new)
    require(owners==[i for i in range(680) if i!=649],'original public-owner mapping')
    require(order==[i for i in range(680,3554) if i!=3266],'original packet mapping')
    for j,orig in enumerate(order):
        newpacket=679+j
        require(new_routes[newpacket]==old_routes[orig],'packet chart mapping')
        require(new['program'][newcl[newpacket]][1]==newpacket,'new paid bank mapping')
        require(old['program'][oldcl[orig]][1]==orig,'old paid bank mapping')
    return owners,order,oldcl,newcl

def native_rows(word,owners,order,clocks):
    dims={int(k):f['dim'] for k,f in word['frames'].items()}
    helper=[];moves=[]
    for address in range(222,len(owners)):
        a,b=word['start'][address],word['final'][address]
        helper.append([address,owners[address],a,b,abs(dims[b]-dims[a])])
    for i,orig in enumerate(order):
        packet=word['public']+i
        clock=clocks[packet]
        op,bank,a,b=word['program'][clock]
        require(op=='MOVE' and bank==packet,'paid actual clock/bank')
        moves.append([clock,bank,orig,a,b,abs(dims[b]-dims[a])])
    return helper,moves

def tables(word,owners,order,clocks,caller):
    h,m=native_rows(word,owners,order,clocks)
    word_hash=digest(word)
    out=[]
    for clock,event in enumerate(caller['events']):
        if event[0]=='LOCAL':
            out.append({'word':word_hash,'caller_clock':clock,'event':event,
                        'helper':[r.copy() for r in h], 'paid_move':[r.copy() for r in m]})
    return out

def bind(table,expected):
    require(table['word']==expected['word'],'wrong word namespace')
    require(table['caller_clock']==expected['caller_clock'] and table['event']==expected['event'], 'wrong caller namespace')
    require(table['helper']==expected['helper'],'wrong helper address or identity')
    require(table['paid_move']==expected['paid_move'],'wrong paid address, identity or chronology')
    for field in ('helper','paid_move'):
        ix=0 if field=='helper' else 1
        require(len({r[ix] for r in table[field]})==len(table[field]),'duplicate local bank')

def must_reject(table,expected,part):
    try: bind(table,expected)
    except ValueError as exc:
        require(part in str(exc),'unexpected rejection')
        return str(exc)
    raise ValueError('bad binding accepted')

def reference_leaf(u,v,weights,head,tail,mod):
    n,width=len(u),len(weights)
    out_h=[r.copy() for r in head];out_t=[r.copy() for r in tail]
    for j,a in enumerate(weights):
        x=[pow(a[i],-1,mod)*head[i][j] for i in range(n)]
        y=[tail[n-1-i][width-1-j] for i in range(n)]
        d=sum(c*(r-l) for c,r,l in zip(v,y,x,strict=True))
        for i in range(n):
            out_h[i][j]=(head[i][j]+a[i]*u[i]*d)%mod
            out_t[n-1-i][width-1-j]=(y[i]-u[i]*d)%mod
    return out_h+out_t

def determinant_integer(rows):
    a=[list(r) for r in rows];n=len(a);prev=1;sign=1
    for j in range(n-1):
        k=next((i for i in range(j,n) if a[i][j]),None)
        require(k is not None,'singular frame')
        if k!=j:a[j],a[k]=a[k],a[j];sign=-sign
        pivot=a[j][j]
        for i in range(j+1,n):
            for k in range(j+1,n):
                num=a[i][k]*pivot-a[i][j]*a[j][k]
                q,r=divmod(num,prev);require(r==0,'nonexact Bareiss division');a[i][k]=q
            a[i][j]=0
        prev=pivot
    return sign*a[-1][-1]

def rank_mod3(a):
    mat=[[x%3 for x in row] for row in a];r=0
    for j in range(len(mat[0])):
        k=next((i for i in range(r,len(mat)) if mat[i][j]),None)
        if k is None:continue
        mat[r],mat[k]=mat[k],mat[r]
        inv=pow(mat[r][j],-1,3);mat[r]=[x*inv%3 for x in mat[r]]
        for i in range(r+1,len(mat)):
            c=mat[i][j]
            if c:mat[i]=[(x-c*y)%3 for x,y in zip(mat[i],mat[r],strict=True)]
        r+=1
        if r==len(mat):break
    return r

def catalogue(old,new):
    require(old['frames']==new['frames'],'changed frame catalogue')
    mats={};den={};ranks={};det=Counter();portdet=Counter()
    for key,f in new['frames'].items():
        i=int(key);basis=transpose(f['B']+f['A']);d=determinant_integer(basis)
        require(d%3!=0,'frame determinant is not a 3-adic unit');det[abs(d)]+=1
        q=projector(basis,f['dim']);scale=lcm(*(x.denominator for row in q for x in row))
        require(scale%3!=0,'projector denominator not a 3-adic unit')
        mats[i]=[[int(scale*x) for x in row] for row in q];den[i]=scale;ranks[i]=f['dim']
        require(multiply(mats[i],mats[i])==[[scale*x for x in row] for row in mats[i]],'frame idempotent')
    for j in range(111):
        a,b=new['start'][j],new['final'][j+111]
        basis=transpose(new['frames'][str(a)]['B']+new['frames'][str(b)]['B'])
        d=determinant_integer(basis);require(d%3!=0,'joint-port determinant not unit');portdet[abs(d)]+=1
        q=projector(basis,1)
        require(q==[[Fraction(v,den[a]) for v in row] for row in mats[a]],'joint port head')
    def pairs(w):
        return ([(row[2],row[3]) for row in w['program'] if row[0]=='MOVE'],
                list(zip(w['start'][222:],w['final'][222:],strict=True)))
    oldmoves,oldhelpers=pairs(old);moves,helpers=pairs(new)
    def counts(rows):return Counter(tuple(sorted(x)) for x in rows)
    move_diff=counts(moves);move_diff.subtract(counts(oldmoves))
    help_diff=counts(helpers);help_diff.subtract(counts(oldhelpers))
    require({k:v for k,v in move_diff.items() if v}=={(1,506):-1},'paid pair delta')
    require({k:v for k,v in help_diff.items() if v}=={(1,506):-1},'helper pair delta')
    unique=sorted(set(counts(moves))|set(counts(helpers)))
    require(set(unique)==set(counts(oldmoves))|set(counts(oldhelpers)),'pair catalogue changed')
    for a,b in unique:
        if ranks[a]>ranks[b]:a,b=b,a
        x,y,dx,dy=mats[a],mats[b],den[a],den[b]
        require(ranks[a]<ranks[b],'nonpositive pair grade')
        target=[[v*dy for v in row] for row in x]
        require(multiply(x,y)==multiply(y,x)==target,'nested pair')
        dd=[[yy*dx-xx*dy for xx,yy in zip(xr,yr,strict=True)] for xr,yr in zip(x,y,strict=True)]
        denom=dx*dy
        require(multiply(dd,dd)==[[denom*v for v in row] for row in dd],'difference idempotence')
        require(rank_mod3(dd)==ranks[b]-ranks[a],'difference grade at three')
    require(det=={1:28,4:326,16:250,64:32} and portdet=={1:8,4:103},'determinant census')
    return {'native_frames':len(mats),'native_determinants':dict(sorted(det.items())),
            'joint_ports':111,'joint_port_determinants':dict(sorted(portdet.items())),
            'native_move_occurrences':len(moves),'helper_difference_occurrences':len(helpers),
            'distinct_unordered_pairs':len(unique),'candidate_pair_set_equals_baseline':True,
            'paid_and_helper_each_lose_one_pair':'(1,506)',
            'pairs_sha256':digest(unique),'checks':'exact frame unit at 3, nesting both ways, difference idempotence and 3-residue grade',
            'scope':'native and joint-port catalogue, not the full changed cover or 451-fold placement'}

def local_leaf(word,paid4,paid3):
    def proj(chart):
        f=word['frames'][str(chart)]
        return projector(transpose(f['B']+f['A']),f['dim'])
    def diff(a,b): return [[v-u for u,v in zip(x,y,strict=True)] for x,y in zip(a,b,strict=True)]
    def add(a,b): return [[u+v for u,v in zip(x,y,strict=True)] for x,y in zip(a,b,strict=True)]
    zero=[[0]*8 for _ in range(8)]
    p4=diff(proj(paid4[3]),proj(paid4[4]));p3=diff(proj(paid3[3]),proj(paid3[4]))
    a,ar=split(p4,1);b,br=split(p3,1)
    require(add(a,ar)==p4 and add(b,br)==p3,'factor splits sum to source')
    for x,y in [(a,ar),(ar,a),(b,br),(br,b)]: require(multiply(x,y)==zero,'factor splits orthogonal')
    require(frame_at_three(p4)[1]==4 and frame_at_three(p3)[1]==3,'actual local grades')
    u1,v1=native_factors(a);u2,v2=native_factors(b)
    # Image and dual factors of one rank-one term of the genuine 4x3 tensor.
    u0=[x*y for x in u1 for y in u2];v0=[x*y for x in v1 for y in v2]
    require(sum(x*y for x,y in zip(u0,v0,strict=True))==1,'tensor line normalization')
    rng=random.Random(7912679); cases=[]
    for digits in (1,2,3):
        mod=3**digits; g=identity(64)
        # Swap a zero diagonal into slot 0 when available to force the nonleading adapter.
        z=next((i for i in range(64) if (u0[i]*v0[i]).numerator % 3==0),None)
        require(z is not None,'need a nonleading test row')
        g[0],g[z]=g[z],g[0]
        u,v=covered_factors((u0,v0),g,digits)
        pivot=select_pivot(u,v);require(pivot>0,'expected nonleading pivot')
        width=2;units=[x for x in range(mod) if x%3]
        weights=[[rng.choice(units) for _ in range(64)] for __ in range(width)]
        head=[[rng.randrange(mod) for _ in range(width)] for __ in range(64)]
        tail=[[rng.randrange(mod) for _ in range(width)] for __ in range(64)]
        result,children=run_leaf(u,v,weights,head,tail,digits)
        require(result==reference_leaf(u,v,weights,head,tail,mod),'actual tensor-line result')
        require(children==(width,)*9,'nonleading nine-child charge')
        back,back_children=run_leaf(u,v,weights,result[:64],result[64:],digits)
        require(back==head+tail and len(back_children)==9,'inverse restoration')
        cases.append({'q':3,'digits':digits,'pivot':pivot,'children_each_way':len(children),
                      'width':width,'inverse_restores_complete_two_banks':True})
    return {'paid_factors':[paid4,paid3], 'raw_tensor_grade':12, 'ambient':'8 x 8 local chart axes',
            'split':'(1+3) tensor (1+2); chosen line 1 x 1',
            'row_factor_u_sha256':digest([str(x) for x in u0]),
            'row_factor_v_sha256':digest([str(x) for x in v0]),'cases':cases,
            'scope':'local generator-level exact-factor control, not full 134^2 caller placement or 451-fold run'}

def choose_port(word,tag):
    return next(i for i,p in enumerate(word) if p.tag==tag)

def main():
    require(__debug__,'run without Python -O')
    old=load_input('inputs/WORD.json.gz');new=load_input('inputs/ZERO-CONTROL-WORD.json.gz')
    caller=load_input('inputs/EFREE-CALLER.json.gz')
    require((digest(old),digest(new))==(OLD,NEW),'canonical word hashes')
    owners,order,oldcl,newcl=reconstruct(old,new)
    tc=tables(new,owners,order,newcl,caller)
    tb=tables(old,list(range(680)),list(range(680,3554)),oldcl,caller)
    require(len(tc)==len(tb)==36,'36 LOCAL calls')
    independently_regenerated=tables(new,owners,order,newcl,caller)
    for t,expected in zip(tc,independently_regenerated,strict=True): bind(t,expected)
    del independently_regenerated
    require(len({t['caller_clock'] for t in tc})==36,'call namespaces unique')
    require(all(len(t['helper'])==457 and len(t['paid_move'])==2873 for t in tc),'local table sizes')
    require(all(len(t['helper'])==458 and len(t['paid_move'])==2874 for t in tb),'baseline table sizes')
    bad=deepcopy(tb[0]);r_wrong_sha=must_reject(bad,tc[0],'wrong word namespace')
    bad['word']=NEW;r_forged=must_reject(bad,tc[0],'wrong helper')
    # Swapping two equal-grade original-owner identities preserves all grade bins.
    bad=deepcopy(tc[0]);a,b=bad['helper'][0],bad['helper'][1]
    for j in range(1,len(bad['helper'])):
        if bad['helper'][j][4]==a[4] and bad['helper'][j][1]!=a[1]: b=bad['helper'][j];break
    require(a[4]==b[4] and a[1]!=b[1],'equal-grade swap fixture')
    a[1],b[1]=b[1],a[1]
    require(Counter(x[4] for x in bad['helper'])==Counter(x[4] for x in tc[0]['helper']),'same rank histogram')
    r_swap=must_reject(bad,tc[0],'wrong helper')
    bad=deepcopy(tc[0]); bad['caller_clock']=tc[1]['caller_clock']
    r_call=must_reject(bad,tc[0],'wrong caller namespace')
    bad=deepcopy(tc[0]);bad['paid_move']=deepcopy(tb[0]['paid_move'])
    r_paid=must_reject(bad,tc[0],'wrong paid')
    b0,b1=binary_ports(old,caller),binary_ports(new,caller)
    # Compare every generated per-call tag with the independently structured
    # source adapter, including order and grade.
    for t in tc:
        clock=t['caller_clock']
        given_h=[(('helper',clock,r[0]),r[4]) for r in t['helper']]
        given_m=[(('move',clock,r[0],r[1]),r[5]) for r in t['paid_move']]
        source_h=[(x.tag,x.rank) for x in b1.targets if x.tag[0]=='helper' and x.tag[1]==clock]
        source_m=[(x.tag,x.rank) for x in b1.paid if x.tag[0]=='move' and x.tag[1]==clock]
        require(given_h==source_h and given_m==source_m,'adapter tag binding')
    ph0,ph1=Counter(x.rank for x in b0.paid),Counter(x.rank for x in b1.paid)
    th0,th1=Counter(x.rank for x in b0.targets),Counter(x.rank for x in b1.targets)
    def delta(a,b):
        x=Counter(a);x.subtract(b);return {k:v for k,v in sorted(x.items()) if v}
    require(delta(ph1,ph0)=={4:-36} and delta(th1,th0)=={4:-36},'separate 36-call histograms')
    net=Counter(th1);net.subtract(th0);net.subtract(ph1);net.update(ph0)
    require(not any(net.values()),'signed delta nonzero')
    root=next(x.tag for x in b1.targets if x.tag[0]=='root' and x.rank==127)
    helper=('helper',tc[0]['caller_clock'],649)
    target_old=PoweredWord(134,b0.targets,b0.paid,2,16,10,11).target(tuple(choose_port(b0.targets,t) for t in (root,helper)))
    target_new=PoweredWord(134,b1.targets,b1.paid,2,16,10,11).target(tuple(choose_port(b1.targets,t) for t in (root,helper)))
    require((target_old.rank,target_new.rank)==(508,254) and target_old.rank>=16**2>target_new.rank,'two-factor erasure branch')
    # Same legacy tag path; the old target is exactly at the 451-factor floor,
    # but the new address 649 makes this syntactic path fall to half the floor.
    common4=next(x.tag for x in b1.targets if x.rank==4 and x.tag[0]=='helper' and x.tag[2]==648)
    common8=next(x.tag for x in b1.targets if x.rank==8 and x.tag[0]=='root')
    common64=next(x.tag for x in b1.targets if x.rank==64 and x.tag[0]=='root')
    path=[helper]+[common4]*223+[common8]*2+[common64]*225
    pow_old=PoweredWord(134,b0.targets,b0.paid,451,16,10,11)
    pow_new=PoweredWord(134,b1.targets,b1.paid,451,16,10,11)
    ar=pow_old.target([choose_port(b0.targets,t) for t in path]).rank
    br=pow_new.target([choose_port(b1.targets,t) for t in path]).rank
    require(ar==16**451 and 2*br==ar,'451-factor retention flip')
    p4=next(r for r in tc[0]['paid_move'] if r[2]==3267)
    p3=next(r for r in tc[0]['paid_move'] if r[0]==20)
    require(p4==[11347,3265,3267,506,1,4] and p3[-1]==3,'paid source rows')
    tag4=('move',tc[0]['caller_clock'],p4[0],p4[1]);tag3=('move',tc[0]['caller_clock'],p3[0],p3[1])
    mini=PoweredWord(134,b1.targets,b1.paid,2,16,10,11)
    blocks=list(mini.blocks((choose_port(b1.paid,tag4),choose_port(b1.paid,tag3))))
    require(len(blocks)==1 and (blocks[0].first,blocks[0].rank)==(0,12),'ordered mixed-rank paid slab')
    leaf=local_leaf(new,p4,p3)
    cat=catalogue(old,new)
    charts=literal.Charts(new['frames']);charts.main_contacts(new['start'],new['final'])
    fw,fl,_=literal.tape(new,charts);ad,al,_=literal.tape(new,charts,adjoint=True)
    require(fw==literal.expected_rows(679,False) and ad==literal.expected_rows(679,True),'literal endpoint replay')
    clear=next(i for i,r in enumerate(new['program']) if r[0]=='CLEAR')
    try:literal.tape(new,charts,omit=clear)
    except ValueError: clear_rejected=True
    else: raise ValueError('missing literal CLEAR accepted')
    packed=gzip.compress((json.dumps(tc,sort_keys=True,separators=(',',':'))+'\n').encode(),mtime=0)
    (HERE/'TABLES.json.gz').write_bytes(packed)
    h_old=next(x for x in tb[0]['helper'] if x[0]==649)
    h_new=next(x for x in tc[0]['helper'] if x[0]==649)
    fine_raw=(HERE/'inputs/EXPECTED-7911.json').read_bytes()
    require(sha256(fine_raw).hexdigest()=='b99810b63ecce725db18c8bf3205a3e18b2262c036da03919a6c2659856e0053','fine-rate evidence SHA')
    fine=json.loads(fine_raw)
    original_interval=fine['old_BIT_at_example_raw']['signed']
    require(all(Fraction(x)<0 for x in original_interval),'source old signed moment must be negative')
    result={'status':'PASS_36_CALL_TABLES_AND_LOCAL_TWO_FACTOR_CONTROL',
      'sources':{'baseline_canonical':OLD,'candidate_canonical':NEW,'caller_gzip_sha256':PINS['inputs/EFREE-CALLER.json.gz']},
      'namespace':{'calls':36,'call_clocks':[x['caller_clock'] for x in tc],
         'candidate_helpers_per_call':457,'candidate_paid_per_call':2873,
         'baseline_helpers_per_call':458,'baseline_paid_per_call':2874,
         'table_gzip_sha256':sha256(packed).hexdigest(),'tables_canonical_sha256':digest(tc),
         'each_helper_row':'[new address, original owner, start chart, final chart, grade]',
         'each_paid_row':'[new clock, new bank, original packet, start chart, final chart, grade]',
         'old_address_649':h_old,'new_address_649':h_new,'removed_original_owner':649,
         'removed_original_paid_packet':3266,'moved_original_packet_3267':p4,
         'negative_controls':{'old_namespace':r_wrong_sha,'forged_old_table':r_forged,
             'equal_grade_owner_swap':r_swap,'wrong_call':r_call,'old_paid_addresses':r_paid}},
      'histograms':{'paid_delta':delta(ph1,ph0),'target_delta':delta(th1,th0),'complete_signed_delta':{}},
      'product_trace':{'root_tag':root,'legacy_helper_tag':helper,'two_factor_old_grade':508,
         'two_factor_new_grade':254,'two_factor_floor':256,'old_retained':True,'new_fresh_zero':True,
         'power_451_old_grade':'16^451','power_451_new_grade':'16^451/2',
         'power_451_floor':'16^451','power_451_old_retained':True,'power_451_new_fresh_zero':True,
         'fresh_zero_retirement':'provider must create separately owned zero and retire after physical inverse; not established by this arithmetic check',
         'paid_tags':[tag4,tag3],'paid_ranks':[4,3],'paid_product_grade':12,'slab_cap':100,'slab_start':0,'slab_rank':12},
      'local_ternary_leaf':leaf, 'candidate_ternary_catalogue':cat,
      'fine_rate_source':{'source_pr':7911,'head':'4afc1ffbcde45da360e631a8634b1c86261ddc09',
         'example_raw_trial':fine['raw_example'],'old_signed_interval':original_interval,
         'control_signed_interval_equal_by_exact_bin_cancellation':True,
         'source_precision_premises':fine['premises'],
         'scope':'authenticated source receipt plus exact histogram cancellation, not a re-execution of the interval engine'},
      'literal':{'orientations':2,'independent_rows_each_way':679,'native_clear_omission_rejected':clear_rejected,
         'forward_dirty_retirements':fl['erase_dirty'],'adjoint_dirty_retirements':al['erase_dirty'],
         'scope':'literal CLEAR discards dirty content; this is not physical erasure/refinement'},
      'not_established':['complete changed 451-factor supplier or all target/paid paths','full 134^2 cover row and production routes',
         'physical dirty erasure and owned zero restoration','full q=3 cover on every changed 451-fold placement',
         'simultaneous W^D reserves, conversions and restoration','changed-word exact normalizers and precision tape',
         'fine-rate consumer requalification, analytic recovery, or a kappa gain']}
    (HERE/'RESULT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(result['status']);print(json.dumps({'helper_old':h_old,'helper_new':h_new,'paid4':p4,
        'literal_dirty':[fl['erase_dirty'],al['erase_dirty']],'tables_sha256':sha256(packed).hexdigest(),
        'negative_controls':result['namespace']['negative_controls'],'leaf_cases':leaf['cases']},sort_keys=True))
if __name__=='__main__':main()
