# Terminal scalar gauges for the pinned BIT caller

This is a standalone, one-core, offline certificate for the unchanged-gate scalar-gauge grammar of the #7830 BIT caller. Opening all 32 caller idle scalars and all 38 terminal scalars still permits no changed idle mask or productive terminal mask. The result includes the requested role-2 clocks 19/397 and role-21 clocks 24/425. It does not exclude compensated gates, changed coefficients, nonlocal rewrites, matrix gauges or different caller words, and it constructs no new κ bound.

## Reproduce from a clean copy

Requires Python 3.9 or newer, with only the standard library. Run from this directory:

```sh
python3 -I -B check.py
```

The command verifies `SHA256SUMS`, copies this entire directory to a fresh temporary directory, runs all computations there and compares each output byte-for-byte to `results/`. It also checks that an altered caller, a forged equality-tree witness and a corrupted productive histogram are rejected. No network, repository checkout, environment variables or original campaign directory are required. The user-facing source tree is not modified. On systems exposing CPU affinity, each computation pins itself to one available core.

## Statement and evidence

For original gates `M_t`, modified gates `N_t`, and diagonal gauges `D_t`, solve `N_t D_t = D_(t+1) M_t` with `D_0 = I`. All 798 original clocks remain present: 362 `ADD`, 364 `SWAP`, 4 `QUERY`, 36 `LOCAL` and 32 `IDLE_ONE`. All `ADD`, `SWAP`, `QUERY` and `LOCAL` gates are unchanged; each idle multiplier may be an arbitrary commuting scalar unit, and terminal gauges are unconstrained.

The `ADD` and `QUERY` shears have unit off-diagonal coefficients; `LOCAL` is a stage scalar times such a shear. In the pinned formal replay, `q` is an involution and hence a unit. Localizing stage variables makes them units too. Gate equations require equality of both shear-operand gauges; a swap exchanges them; an opened idle has independent before and after values. Equality of the stage-mask operators must hold in this localization, so the arbitrary-unit relaxation supplies a necessary condition for every proposed mask change.

The compact graph has 70 variables and 402 shear-equality edges, all in one component *without imposing any terminal boundary condition*. Each idle's before and after gauges are thus equal even before the input is anchored. One anchored input forces every state and terminal gauge to one. The certificate includes 69 original-clock spanning-tree edges and two-edge witnesses for each requested idle cut. A separate computation expands every role at every clock: 30,362 states and 30,694 propagation or shear equalities again form one component. Independent GF(2) row reduction gives incidence rank 69 and anchored rank 70; graph connectivity proves equality over any scalar-unit group.

A positive toy control has one nontrivial free terminal gauge. Its changed forward and adjoint maps differ from the originals until the required inverse is transported: if `N = D_out M`, then `M = D_out^-1 N` and `M^T = N^T D_out^-1`. Fixing the toy terminal boundary removes that degree of freedom. The inverse in this control is formal; no physical restoration is claimed. In the pinned caller `D_out = I`, so no changed grade or inverse is available to price.

Fault controls also attempt the role-2 and role-21 stage-10 idle transfers in memory while leaving every query unchanged. Both forward and adjoint caller replays detect changed outputs. A separate synthetic accounting fault omits one query's 111 rank-one charges and incorrectly flips the near-trial margin's sign. These examples illustrate failure modes; the general obstruction is the equality-component proof.

## Full retained invoice

The original caller's 38 diagonal roots replay exactly forward and adjoint. Its full invoice includes all separately owed owners: 36 native paid copies (103,464 paid positions), four queries (444 grade-one paid positions), 32 idles (3,552 paid positions), 36 native productive copies (16,488 fields), and 38 root outputs across 111 ports (4,218 fields). The complete histograms have 107,460 paid positions and 20,706 productive fields. All remain unchanged because the solved gauge is trivial.

For tariff `sum_r count[r] * r^(1-kappa)`, directed rational-grid enclosures give:

| κ trial | Paid moment | Productive moment | Productive − paid |
|---|---:|---:|---:|
| 0.003879928046156 | 289333.1918075098825944834112748… | 289333.1918075091155929809801445… | −0.00000000076700150243113026146… |
| 0.003879929046155 | 289333.1912882247725880624754280… | 289333.1909030974559741960343739… | −0.00038512731661386644105413947… |

Exact outward numerators and denominators appear in `results/TERMINAL-GAUGE-CERTIFICATE.json`. Separate 100-digit Decimal enclosures are checked inside the rational-grid intervals. These are fixed-invoice results, not universal upper bounds on different legal callers. A later construction must establish its exact forward/adjoint maps, physical ownership and transport, complete paid and productive prices, finite product and stock budgets, BIT cap, common outer application, and the retained #7830 assumptions.

## Source snapshots and credits

All copied source files are unchanged and their hashes are in `SHA256SUMS` and the main certificate. The upstream locations are:

- `sources/caller/EFREE-CALLER.json.gz`: [Ali Romman's #7776 source, pinned commit `4f7c67ae`](https://github.com/aliromman/integer-mult-bounds/blob/4f7c67ae387cc91580f469aeda4d508b372b9ec1/research/paired-query-only-bit/EFREE-CALLER.json.gz).
- `sources/parent/literal.py` and `price.py`: [Clear1nsight's parent independent replay, pinned commit `913fb6fe`](https://github.com/Clear1nsight/integer-mult-bounds/tree/913fb6febe28cc3ccad1c16de8e45b8bce0da063/research/p104-subdivided-helper-births/binary/independent).
- `sources/7786/`: [#7786 source lock and independent BIT invoice, pinned commit `89a67c40`](https://github.com/CrocSwap/integer-mult-bounds/tree/89a67c404226d51028e135de2b9169e9020d57af/research/p104-iterated-returns).
- `sources/7830/`: [#7830 result, BIT invoice, source manifest and notice, pinned head `87fbf4f7`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier). `REPOSITORY-NOTICE` is the corresponding repository-level notice.
- `sources/comparator-price.json`: a prior derived fixed-profile comparison receipt, included as an additional cross-check and not represented as an upstream source file.

The #7830 manifest points to the #7786 source lock and independent invoice; the lock authenticates the retained caller, literal replay and price engine. The package checks those links and compares the full BIT histogram to both #7830 and #7786 receipts. It does not replay the entire native construction or its compiler and does not claim an independent proof of inherited assumptions.

The retained Apache-2.0 license is in `LICENSE`; the source-specific and repository notices are preserved under `sources/`. Those notices credit Clear1nsight, Ali Romman, Jerry Chen (CubeJerry), DreamingOfClouds, zxv, Rohan Arun, Cinna Davis, Douglas Colkitt and the other listed predecessor contributors. The separate Decimal cross-check follows the preceding joint-invoice screen's rounding procedure. See `NOTICE` for the scope of this adaptation.
