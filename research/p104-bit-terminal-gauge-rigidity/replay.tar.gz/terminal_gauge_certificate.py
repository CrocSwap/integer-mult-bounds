#!/usr/bin/env python3
"""Exact free-diagonal transport obstruction for the pinned BIT caller.

Use literal gate equations over commuting scalar units. All 32 idle gates can
change their scalar, all terminal gauges are free, and all input gauges are 1.
The connectivity proof applies to arbitrary scalar units, not just one-bit
stage exponents. No ADD, SWAP, QUERY, or LOCAL is altered or deleted.
"""
from collections import Counter, deque
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip
import json
import os
import sys

HERE = Path(__file__).resolve().parent
SOURCES = HERE / 'sources'
LIT = SOURCES / 'parent'
CALLER = SOURCES / 'caller/EFREE-CALLER.json.gz'
BIT = SOURCES / '7830/BIT.json'
RESULT = SOURCES / '7830/RESULT.json'
MANIFEST = SOURCES / '7830/SOURCES.json'
LOCK = SOURCES / '7786/SOURCE-LOCK.json'
OLD_BIT = SOURCES / '7786/INDEPENDENT.json'
COMPARE = SOURCES / 'comparator-price.json'
PINS = {
    CALLER: '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
    LIT / 'literal.py': '4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
    LIT / 'price.py': 'd720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b',
    BIT: '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
    RESULT: '036eb36b24467b6842e1348a49ec6ca7ac87d3e66c5856cfadf6d387189ea360',
    COMPARE: '21f893eb9c06bd5a6900efff5e1bbb6511ed3bf1d5c2c1b495317319a9720ff0',
    MANIFEST: '357e6fe1a57bcb03be10874ba69ad075729802f15ac9614606856a16dc2c8e4f',
    LOCK: 'b46b919292e1a1907345056b6925f5f1400d45650e2f0f610779a07163bb64ee',
    OLD_BIT: '5865e19155488b80ccb1faa1ba74c2ffbc5ac22e8f22f10c5f4496ae49fc1229',
}
HEAD = '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'

# Bound this computation to one currently available core, even if invoked without taskset.
if hasattr(os, 'sched_getaffinity'):
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
for path, wanted in PINS.items():
    actual = sha256(path.read_bytes()).hexdigest()
    assert actual == wanted, (str(path), actual, wanted)
sys.dont_write_bytecode = True
sys.path.insert(0, str(LIT))
import literal
import price

caller = json.loads(gzip.decompress(CALLER.read_bytes()))
bit = json.loads(BIT.read_bytes())
result = json.loads(RESULT.read_bytes())
compare = json.loads(COMPARE.read_bytes())
manifest = json.loads(MANIFEST.read_bytes())
lock = json.loads(LOCK.read_bytes())
old_bit = json.loads(OLD_BIT.read_bytes())
assert any(row.get('path', '').endswith('p104-iterated-returns/SOURCE-LOCK.json') and row['sha256'] == PINS[LOCK] for row in manifest)
assert any(row.get('path', '').endswith('p104-iterated-returns/binary/INDEPENDENT.json') and row['sha256'] == PINS[OLD_BIT] for row in manifest)
assert lock['sources']['parent']['files']['binary/independent/literal.py']['sha256'] == PINS[LIT / 'literal.py']
assert lock['sources']['parent']['files']['binary/independent/price.py']['sha256'] == PINS[LIT / 'price.py']
assert lock['sources']['source']['files']['research/paired-query-only-bit/EFREE-CALLER.json.gz']['sha256'] == PINS[CALLER]
assert result['native_calls']['binary'] == 36
assert compare['source_verified_head'] == HEAD
assert bit['word_sha256'] == result['binary_word'] == compare['sides']['binary']['native_word']
assert bit['native']['caller_sha256'] == sha256(CALLER.read_bytes()).hexdigest()
assert len(caller['events']) == 798 and caller['roles'] == 38
expected_ops = {'ADD': 362, 'SWAP': 364, 'QUERY': 4, 'LOCAL': 36, 'IDLE_ONE': 32}
assert Counter(e[0] for e in caller['events']) == expected_ops
for clock, role, stages in [(19, 2, list(range(2, 10))), (397, 2, [10]),
                             (24, 21, list(range(2, 10))), (425, 21, [10])]:
    assert caller['events'][clock] == ['IDLE_ONE', role, stages]


def components(source, cuts):
    """Build equality graph: fixed shear operands equal, idle cuts independent.

    SWAP carries gauge labels to the opposite role, while an uncut idle
    transports unchanged. A cut creates a fresh vertex for the role after it;
    its scalar ratio is completely unrestricted at this stage.
    """
    n = source['roles']
    vertices = n
    current = list(range(n))
    inputs = current.copy()
    edges, cut_pairs = [], {}
    for clock, (op, *args) in enumerate(source['events']):
        if op in ('ADD', 'QUERY'):
            a, b = args
            edges.append({'u': current[a], 'v': current[b], 'clock': clock,
                          'op': op, 'roles': [a, b]})
        elif op == 'LOCAL':
            stage, a, b = args
            edges.append({'u': current[a], 'v': current[b], 'clock': clock,
                          'op': op, 'roles': [a, b], 'stage': stage})
        elif op == 'SWAP':
            a, b = args
            current[a], current[b] = current[b], current[a]
        elif op == 'IDLE_ONE':
            owner, _ = args
            if clock in cuts:
                cut_pairs[clock] = [current[owner], vertices]
                current[owner] = vertices
                vertices += 1
        else:
            raise ValueError((clock, op))
    assert set(cut_pairs) == set(cuts)
    adjacency = [[] for _ in range(vertices)]
    for i, edge in enumerate(edges):
        adjacency[edge['u']].append((edge['v'], i))
        adjacency[edge['v']].append((edge['u'], i))
    labels = [-1] * vertices
    forest = []
    component = 0
    for root in range(vertices):
        if labels[root] >= 0:
            continue
        labels[root] = component
        queue = deque([root])
        while queue:
            v = queue.popleft()
            for w, i in adjacency[v]:
                if labels[w] == -1:
                    labels[w] = component
                    forest.append(i)
                    queue.append(w)
        component += 1
    input_components = {labels[i] for i in inputs}
    terminal_components = {labels[i] for i in current}
    return dict(vertices=vertices, edges=edges, inputs=inputs, terminal=current,
                cuts=cut_pairs, labels=labels, component_count=component,
                input_components=input_components, terminal_components=terminal_components,
                free_components=set(range(component)) - input_components,
                forest=forest, adjacency=adjacency)


def rank_gf2(rows):
    pivots = {}
    for row in rows:
        while row:
            col = row.bit_length() - 1
            if col in pivots:
                row ^= pivots[col]
            else:
                pivots[col] = row
                break
    return len(pivots)


def path(graph, source, target):
    queue = deque([source]); previous = {source: None}
    while queue and target not in previous:
        v = queue.popleft()
        for w, edge in graph['adjacency'][v]:
            if w not in previous:
                previous[w] = (v, edge)
                queue.append(w)
    assert target in previous
    out = []
    while target != source:
        v, edge = previous[target]
        out.append(graph['edges'][edge])
        target = v
    return list(reversed(out))


def summary(g):
    return {'vertices': g['vertices'], 'equality_constraints': len(g['edges']),
            'components': g['component_count'],
            'components_not_fixed_by_input': len(g['free_components']),
            'terminal_components': sorted(g['terminal_components']),
            'all_terminal_gauges_input_fixed': all(g['labels'][v] in g['input_components'] for v in g['terminal']),
            'cuts': {str(k): {'vertices': v, 'same_component': g['labels'][v[0]] == g['labels'][v[1]]}
                     for k, v in g['cuts'].items()}}

idle_clocks = {i for i, e in enumerate(caller['events']) if e[0] == 'IDLE_ONE'}
scopes = {'role2': {19, 397}, 'role21': {24, 425},
          'both_requested': {19, 24, 397, 425}, 'all_idle_masks': idle_clocks}
graphs = {name: components(caller, cuts) for name, cuts in scopes.items()}
for g in graphs.values():
    assert g['component_count'] == 1 and not g['free_components']
    assert all(g['labels'][a] == g['labels'][b] for a, b in g['cuts'].values())
g = graphs['all_idle_masks']
assert g['vertices'] == 70 and len(g['edges']) == 402 and len(g['forest']) == 69
# Independently row-reduce all equality equations with just one input anchor.
edge_rows = [(1 << e['u']) ^ (1 << e['v']) for e in g['edges']]
edge_rank = rank_gf2(edge_rows)
anchored_rank = rank_gf2(edge_rows + [1])
assert (edge_rank, anchored_rank) == (69, 70)
# Check the supplied spanning-tree edges alone connect all 70 vertices.
assert rank_gf2([edge_rows[i] for i in g['forest']]) == 69

# Positive control: output row 0 can be changed after the final shear, and
# the correct inverse is applied on outputs forward / inputs in the adjoint.
toy = {'roles': 2, 'events': [['QUERY', 0, 1], ['QUERY', 0, 1],
                               ['IDLE_ONE', 0, [1]], ['IDLE_ONE', 1, [1]]]}
toy_graph = components(toy, {2})
assert len(toy_graph['free_components']) == 1
assert toy_graph['labels'][toy_graph['terminal'][0]] in toy_graph['free_components']
assert toy_graph['labels'][toy_graph['terminal'][1]] in toy_graph['input_components']
toy_changed = deepcopy(toy)
toy_changed['events'][2][2].append(2)
fwd, changed_fwd = literal.caller_rows(toy), literal.caller_rows(toy_changed)
adj, changed_adj = literal.caller_rows(toy, True), literal.caller_rows(toy_changed, True)
stage2 = literal.caller_monomial([2])
restored_fwd = [literal.shift(changed_fwd[0], -stage2), changed_fwd[1]]

def inverse_columns(forms, monomial, role):
    output = []
    for form in forms:
        new = {}
        for m, bits in form.items():
            for j in range(toy['roles']):
                if (bits >> j) & 1:
                    shift = -monomial if j == role else 0
                    new = literal.add(new, {m + shift: 1 << j})
        output.append(new)
    return output
restored_adj = inverse_columns(changed_adj, stage2, 0)
assert changed_fwd != fwd and changed_adj != adj
assert restored_fwd == fwd and restored_adj == adj
# If toy terminal row 0 is also anchored, the free scalar is forced to 1.
toy_terminal_fixed = toy_graph['input_components'] | {toy_graph['labels'][v] for v in toy_graph['terminal']}
assert not (set(range(toy_graph['component_count'])) - toy_terminal_fixed)

# Replay exact original caller forward and adjoint, because the equation proof
# forces every idle and terminal scalar to remain literally the original.
roots = [{literal.caller_monomial(owner['stages']) | owner['q']: 1 << j}
         for j, owner in enumerate(caller['diagonal'])]
assert literal.caller_rows(caller) == roots
assert literal.caller_rows(caller, True) == roots


def hist(d):
    return Counter({int(k): int(v) for k, v in d.items()})

def times(c, n):
    return Counter({k: n*v for k, v in c.items()})

def hjson(c):
    return {str(k): v for k, v in sorted(c.items()) if v}

ports = caller['ports']
native_paid = hist(bit['native']['native_paid'])
native_targets = hist(bit['native']['native_targets'])
# Derive separate owed owners directly from literal event and output masks.
idle_paid = Counter()
query_paid = Counter()
for op, *args in caller['events']:
    if op == 'IDLE_ONE':
        idle_paid[7 * len(args[1])] += ports
    if op == 'QUERY':
        query_paid[1] += ports
root_targets = Counter()
for owner in caller['diagonal']:
    root_targets[1 + 7*len(owner['stages'])] += ports
paid = times(native_paid, 36) + idle_paid + query_paid
targets = times(native_targets, 36) + root_targets
assert paid == hist(bit['native']['paid']) == hist(compare['sides']['binary']['paid']) == hist(old_bit['complete_paid'])
assert targets == hist(bit['native']['targets']) == hist(compare['sides']['binary']['targets']) == hist(old_bit['complete_productive'])

def record(x):
    return {'grid_numerators': [str(x[0]), str(x[1])],
            'grid_denominator': str(price.GRID),
            'decimal_outward': price.decimal_interval(x, 48)}

invoices = {}
for raw in ('0.003879928046156', '0.003879929046155'):
    k = Fraction(raw)
    p = price.moment(paid, k)
    t = price.moment(targets, k)
    margin = price.moment(price.signed_profile(targets, paid), k)
    assert margin[1] < 0
    separate = price.sub(t, p)
    assert separate[0] <= margin[0] <= margin[1] <= separate[1]
    invoices[raw] = {'paid': record(p), 'productive': record(t), 'productive_minus_paid': record(margin)}

receipt = {
    'status': 'PASS_ZERO_FREE_GAUGE_EVEN_WITH_FREE_TERMINAL_MASKS',
    'construction_head': HEAD,
    'source_hashes': {p.relative_to(HERE).as_posix(): v for p, v in PINS.items()},
    'scope': 'All 798 original events; arbitrary commuting scalar units at every idle; unchanged ADD/SWAP/QUERY/LOCAL and all input gauges fixed to 1; all 38 terminal gauges initially free.',
    'assumptions': 'Work in the formal localization where stage symbols and q are units; any valid original polynomial gate identity must hold there. A gate-local free diagonal gauge changes only idle scalars and terminal diagonal masks.',
    'equations': {'fixed_shear': 'g_after,a=g_before,a=g_after,b=g_before,b (applies to ADD, QUERY and LOCAL); other roles unchanged',
                  'swap': 'post gauges exchange along the swapped roles',
                  'idle': 'g_after,owner/g_before,owner = new_idle_scalar/old_idle_scalar; other roles unchanged',
                  'boundary': 'g_input=1; terminal is not constrained in the graph',
                  'terminal_transport': 'N=D_out M; hence M=D_out^-1 N and M^T=N^T D_out^-1. Changed output mask/grade must be repriced and any required inverse physically supplied; this instance forces D_out=I.'},
    'operations': expected_ops,
    'results': {name: summary(x) for name, x in graphs.items()},
    'gf2_incidence_rank': {'edge_only': edge_rank, 'plus_one_input_anchor': anchored_rank, 'variables': g['vertices']},
    'spanning_tree_edges': [g['edges'][i] for i in g['forest']],
    'witness_paths_same_scalar_across_requested_cut': {str(t): path(g, *g['cuts'][t]) for t in (19, 397, 24, 425)},
    'toy_terminal_control': {'cut_clock': 2, 'free_components_with_terminal_released': len(toy_graph['free_components']),
                             'free_components_with_terminal_fixed': len(set(range(toy_graph['component_count'])) - toy_terminal_fixed),
                             'forward_inverse_output_transport_equal': restored_fwd == fwd,
                             'adjoint_inverse_input_transport_equal': restored_adj == adj,
                             'unrestored_maps_both_differ': changed_fwd != fwd and changed_adj != adj},
    'caller_original_forward_and_adjoint_match_roots': True,
    'changed_idle_masks': 0, 'changed_output_masks': 0, 'changed_query_events': 0,
    'idle_paid': hjson(idle_paid), 'query_paid': hjson(query_paid),
    'native_paid_36_copies': hjson(times(native_paid, 36)), 'root_productive': hjson(root_targets),
    'native_targets_36_copies': hjson(times(native_targets, 36)),
    'complete_paid': hjson(paid), 'complete_productive': hjson(targets), 'invoices': invoices,
    'limitations': 'Necessary and sufficient only for this free eventwise scalar-gauge grammar. Does not exclude changed shears, changed LOCAL coefficients, new paid restoration gates, nonlocal cancellations, different words, or nonlinear/matrix gauges. No changed construction is obtained; finite and outer requalification would be required for any later candidate.',
}
out = HERE / 'results/TERMINAL-GAUGE-CERTIFICATE.json'
out.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print('PASS results/TERMINAL-GAUGE-CERTIFICATE.json')
print('all-idle graph:', g['vertices'], 'variables,', len(g['edges']), 'equalities,', g['component_count'], 'component')
for k, inv in invoices.items():
    print(k, 'productive minus paid', inv['productive_minus_paid']['decimal_outward'])
