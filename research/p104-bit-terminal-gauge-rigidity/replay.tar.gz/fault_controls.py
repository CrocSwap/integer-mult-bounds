#!/usr/bin/env python3
"""Negative controls: naive mask transfers and omission of an owed query price."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
for name, wanted in [('literal.py', '4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c'),
                     ('price.py', 'd720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b')]:
    assert sha256((HERE / 'sources/parent' / name).read_bytes()).hexdigest() == wanted
sys.dont_write_bytecode = True
sys.path.insert(0, str(HERE / 'sources/parent'))
import literal
import price
raw = (HERE / 'sources/caller/EFREE-CALLER.json.gz').read_bytes()
assert sha256(raw).hexdigest() == '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
c = json.loads(gzip.decompress(raw))
f, a = literal.caller_rows(c), literal.caller_rows(c, True)
roots = [{literal.caller_monomial(owner['stages']) | owner['q']: 1 << j}
         for j, owner in enumerate(c['diagonal'])]
assert f == roots == a

retimes = {}
for name, pairs in [('role2', [(19,397)]), ('role21', [(24,425)]),
                    ('both', [(19,397),(24,425)])]:
    altered = deepcopy(c)
    for start, end in pairs:
        assert 10 not in altered['events'][start][2] and altered['events'][end][2] == [10]
        altered['events'][start][2].append(10)
        altered['events'][end][2].remove(10)
    # Keep every query and every other gate untouched, in memory only.
    assert [e for e in altered['events'] if e[0] == 'QUERY'] == [e for e in c['events'] if e[0] == 'QUERY']
    af = literal.caller_rows(altered)
    aa = literal.caller_rows(altered, True)
    bad_forward = [j for j in range(c['roles']) if af[j] != f[j]]
    bad_adjoint = [j for j in range(c['roles']) if aa[j] != a[j]]
    assert bad_forward and bad_adjoint
    retimes[name] = {'changed_forward_rows': bad_forward, 'changed_adjoint_rows': bad_adjoint,
                     'unchanged_queries': True, 'accepted_as_candidate': False}

bit_raw = (HERE / 'sources/7830/BIT.json').read_bytes()
assert sha256(bit_raw).hexdigest() == '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'
bit = json.loads(bit_raw)['native']
paid = Counter({int(k): int(v) for k, v in bit['paid'].items()})
targets = Counter({int(k): int(v) for k, v in bit['targets'].items()})
k = Fraction('0.003879929046155')
true = price.moment(price.signed_profile(targets, paid), k)
false_paid = paid.copy()
# Negative bookkeeping control: omit one 111-port query charge in memory.
false_paid[1] -= c['ports']
wrong = price.moment(price.signed_profile(targets, false_paid), k)
change = price.sub(wrong, true)
assert true[1] < 0 and wrong[0] > 0
assert change[0] <= 111*price.GRID <= change[1]
out = {
  'status': 'PASS_EXPECTED_FAILURES_AND_QUERY_ACCOUNTING_CONTROL',
  'naive_mask_transfers_rejected_forward_and_adjoint': retimes,
  'query_price_fault': {'scope': 'synthetic in-memory invoice only, no caller query deleted',
                        'omitted_rank_1_paid_positions': c['ports'],
                        'true_margin': price.decimal_interval(true, 45),
                        'incorrect_margin': price.decimal_interval(wrong, 45),
                        'tariff_difference_contains': '111',
                        'sign_incorrectly_flips': True},
}
(HERE / 'results/FAULT-CONTROLS.json').write_text(json.dumps(out, indent=2, sort_keys=True)+'\n')
print('PASS naive changed masks fail both replays; uncharged query corrupts signed invoice')
