#!/usr/bin/env python3
"""Authenticate the bundle, reproduce it in a clean copy, and inject faults."""
from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent

def require(ok, message):
    if not ok:
        raise ValueError(message)

manifest = HERE / 'SHA256SUMS'
entries = {}
for line in manifest.read_text().splitlines():
    digest, name = line.split('  ', 1)
    relative = Path(name)
    require(not relative.is_absolute() and '..' not in relative.parts and name not in entries,
            'invalid or duplicate manifest path')
    path = HERE / relative
    require(path.is_file() and not path.is_symlink(), f'missing or linked manifest file: {name}')
    require(sha256(path.read_bytes()).hexdigest() == digest, f'SHA-256 mismatch: {name}')
    entries[name] = digest
actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name != 'SHA256SUMS'}
require(actual == set(entries), 'manifest does not cover exactly the package files')
print('PASS SHA-256 manifest', len(entries), 'files', flush=True)

scripts = [('terminal_gauge_certificate.py', 'TERMINAL-GAUGE-CERTIFICATE.json'),
           ('verify_clock_graph.py', 'INDEPENDENT-CLOCK-CERTIFICATE.json'),
           ('verify_invoice.py', 'DECIMAL-VERIFY.json'),
           ('fault_controls.py', 'FAULT-CONTROLS.json')]

def execute(work, script, expect_success=True):
    proc = subprocess.run([sys.executable, '-I', '-B', str(work / script)], cwd=work,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=60)
    if expect_success:
        require(proc.returncode == 0, f'{script} failed:\n{proc.stderr}')
    else:
        require(proc.returncode != 0 and 'AssertionError' in proc.stderr,
                f'{script} accepted a corrupted input or failed unexpectedly:\n{proc.stderr}')
    return proc

with tempfile.TemporaryDirectory(prefix='terminal-gauge-clean-') as tmp:
    work = Path(tmp) / 'bundle'
    shutil.copytree(HERE, work)
    expected = {filename: (HERE / 'results' / filename).read_bytes() for _, filename in scripts}
    for script, result in scripts:
        proc = execute(work, script)
        require((work / 'results' / result).read_bytes() == expected[result],
                f'nonreproducible result: {result}')
        print('PASS clean replay', script, flush=True)
    toy = json.loads(expected['TERMINAL-GAUGE-CERTIFICATE.json'])['toy_terminal_control']
    require(toy['free_components_with_terminal_released'] == 1
            and toy['free_components_with_terminal_fixed'] == 0
            and toy['forward_inverse_output_transport_equal']
            and toy['adjoint_inverse_input_transport_equal']
            and toy['unrestored_maps_both_differ'], 'positive terminal-transport control failed')

    caller = work / 'sources/caller/EFREE-CALLER.json.gz'
    original = caller.read_bytes()
    damaged = bytearray(original); damaged[0] ^= 1
    caller.write_bytes(damaged)
    execute(work, 'terminal_gauge_certificate.py', False)
    caller.write_bytes(original)
    print('PASS source corruption rejected', flush=True)

    cert = work / 'results/TERMINAL-GAUGE-CERTIFICATE.json'
    original = cert.read_bytes()
    changed = json.loads(original)
    changed['spanning_tree_edges'][0]['roles'][0] = (changed['spanning_tree_edges'][0]['roles'][0] + 1) % 38
    cert.write_text(json.dumps(changed))
    execute(work, 'verify_clock_graph.py', False)
    cert.write_bytes(original)
    print('PASS bad equality-tree witness rejected', flush=True)

    changed = json.loads(original)
    changed['complete_productive']['57'] += 1
    cert.write_text(json.dumps(changed))
    execute(work, 'verify_invoice.py', False)
    cert.write_bytes(original)
    print('PASS corrupted productive invoice rejected', flush=True)
print('PASS portable clean-copy replay, positive control, and fault controls')
