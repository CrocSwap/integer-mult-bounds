#!/usr/bin/env python3
"""Independently reconstruct all 38 x 799 gauge states and verify receipt."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
import json
import os

if hasattr(os, 'sched_getaffinity'):
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
HERE = Path(__file__).resolve().parent
CALLER = HERE / 'sources/caller/EFREE-CALLER.json.gz'
raw = CALLER.read_bytes()
assert sha256(raw).hexdigest() == '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
c = json.loads(gzip.decompress(raw))
receipt_bytes = (HERE / 'results/TERMINAL-GAUGE-CERTIFICATE.json').read_bytes()
receipt = json.loads(receipt_bytes)
roles, events = c['roles'], c['events']
assert roles == 38 and len(events) == 798
state_count = roles * (len(events) + 1)
parent = list(range(state_count))
size = [1]*state_count

def state(t, role):
    return roles*t + role

def root(a):
    while a != parent[a]:
        parent[a] = parent[parent[a]]
        a = parent[a]
    return a

def merge(a, b):
    a, b = root(a), root(b)
    if a == b:
        return
    if size[a] < size[b]:
        a, b = b, a
    parent[b] = a
    size[a] += size[b]

edge_count = 0
clock_cuts = []
tree = {i: [] for i in range(len(events))}
for e in receipt['spanning_tree_edges']:
    tree[e['clock']].append(e)
compact = list(range(roles)); next_id = roles
for t, row in enumerate(events):
    op, *args = row
    # Independent construction: create every time/role state, propagate all
    # unmodified role wires, omit exactly one link at each free idle.
    for r in range(roles):
        dest = r
        if op == 'SWAP':
            a,b = args
            dest = b if r == a else a if r == b else r
        if op == 'IDLE_ONE' and r == args[0]:
            continue
        merge(state(t, r), state(t+1, dest)); edge_count += 1
    if op in ('ADD', 'QUERY', 'LOCAL'):
        a, b = args[-2:]
        merge(state(t, a), state(t, b)); edge_count += 1
        for entry in tree[t]:
            assert entry['op'] == op and entry['roles'] == [a,b]
            assert [entry['u'], entry['v']] == [compact[a], compact[b]]
    else:
        assert not tree[t]
    if op == 'SWAP':
        a,b = args; compact[a],compact[b] = compact[b],compact[a]
    elif op == 'IDLE_ONE':
        owner,_ = args
        clock_cuts.append((t, owner))
        compact[owner] = next_id; next_id += 1
    else:
        assert op in ('ADD', 'QUERY', 'LOCAL')
assert len(clock_cuts) == 32 and next_id == 70
assert edge_count == 30694 and state_count == 30362
labels = {root(i) for i in range(state_count)}
assert len(labels) == 1
anchor = root(state(0,0))
assert all(root(state(t,r)) == anchor for t in range(799) for r in range(38))
assert len(receipt['spanning_tree_edges']) == 69
assert all(root(state(t, r)) == root(state(t+1, r)) for t,r in clock_cuts)
assert all(root(state(798, r)) == anchor for r in range(roles))
output = {
    'status': 'PASS_INDEPENDENT_EXPLICIT_TIME_EXPANSION',
    'scope': 'All 798 gates and every role between clocks; 32 idle links omitted, no terminal anchor added',
    'caller_sha256': sha256(raw).hexdigest(),
    'certificate_sha256': sha256(receipt_bytes).hexdigest(),
    'clocks': len(events), 'roles': roles, 'state_nodes': state_count,
    'wire_propagation_plus_shear_equalities': edge_count,
    'components_before_input_anchor': len(labels),
    'every_state_equal_to_first_input': True,
    'every_idle_cut_closed_by_other_equalities': True,
    'all_terminal_gauges_fixed_by_one_input': True,
    'checked_spanning_tree_edge_labels': len(receipt['spanning_tree_edges']),
    'operation_counts': dict(Counter(x[0] for x in events)),
}
out = HERE / 'results/INDEPENDENT-CLOCK-CERTIFICATE.json'
out.write_text(json.dumps(output, indent=2, sort_keys=True)+'\n')
print('PASS', state_count, 'clock-role states,', edge_count, 'equalities,', len(labels), 'component')
