#!/usr/bin/env python3
"""Separate Decimal moment cross-check, based on joint/decimal_crosscheck.py."""
from collections import Counter
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
from fractions import Fraction
from functools import cache
from hashlib import sha256
from pathlib import Path
import json
import os

if hasattr(os, 'sched_getaffinity'):
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
HERE = Path(__file__).resolve().parent
BIT = HERE / 'sources/7830/BIT.json'
raw = BIT.read_bytes()
assert sha256(raw).hexdigest() == '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'
base = json.loads(raw)['native']
receipt = json.loads((HERE / 'results/TERMINAL-GAUGE-CERTIFICATE.json').read_bytes())
paid = Counter({int(k): v for k, v in base['paid'].items()})
targets = Counter({int(k): v for k, v in base['targets'].items()})
assert receipt['complete_paid'] == base['paid'] and receipt['complete_productive'] == base['targets']
NEAR = Context(prec=100, rounding=ROUND_HALF_EVEN)
DOWN = Context(prec=100, rounding=ROUND_FLOOR)
UP = Context(prec=100, rounding=ROUND_CEILING)

@cache
def power(rank, exponent):
    if rank == 1:
        return Decimal(1), Decimal(1)
    # Decimal ln and exp are correctly rounded to nearest; step one decimal
    # value outward and round the monotone intervening products outward.
    x = NEAR.ln(Decimal(rank))
    lo = DOWN.multiply(NEAR.next_minus(x), exponent)
    hi = UP.multiply(NEAR.next_plus(x), exponent)
    return NEAR.next_minus(NEAR.exp(lo)), NEAR.next_plus(NEAR.exp(hi))

def moment(hist, exponent):
    lo = hi = Decimal(0)
    for rank, n in sorted(hist.items()):
        x, y = power(rank, exponent)
        lo = DOWN.add(lo, DOWN.multiply(x, Decimal(n)))
        hi = UP.add(hi, UP.multiply(y, Decimal(n)))
    return lo, hi

out = {}
for k, row in receipt['invoices'].items():
    exponent = DOWN.subtract(Decimal(1), Decimal(k))
    p = moment(paid, exponent)
    t = moment(targets, exponent)
    lo, hi = DOWN.subtract(t[0], p[1]), UP.subtract(t[1], p[0])
    recorded = row['productive_minus_paid']
    grid_lo, grid_hi = (Fraction(x, int(recorded['grid_denominator'])) for x in map(int, recorded['grid_numerators']))
    assert grid_lo <= Fraction(lo) <= Fraction(hi) <= grid_hi < 0
    out[k] = {'paid': list(map(str, p)), 'productive': list(map(str, t)), 'productive_minus_paid': [str(lo), str(hi)]}
result = {'status': 'PASS_SEPARATE_100_DIGIT_DECIMAL_CHECK_WITHIN_RATIONAL_GRID',
          'source': 'separate paid and productive moments; procedure adapted from the preceding joint decimal_crosscheck.py',
          'bit_sha256': sha256(raw).hexdigest(), 'values': out}
(HERE / 'results/DECIMAL-VERIFY.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
print('PASS separate directed Decimal checks for', len(out), 'trials')
