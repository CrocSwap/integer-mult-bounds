#!/usr/bin/env python3
"""Pin source data and bind the retained named cube to the generator."""
from pathlib import Path
import hashlib
import importlib.util
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PINS = {
    "source/drat/gen.py": "2109ace16a7b04aa399ab0a06739afbb6fe378348e06360ce26620b721a08472",
    "source/drat/cubes.txt": "792af281bcb7d5652274ae201624fb69ab49fa99b29fba4522ab295924de3002",
    "source/drat/hashes.tsv": "3cdd8553d2de9c1800daef10f8ea138f6ba3abe27ce8228b9a4ebb3ad678dce7",
    "source/drat/data/e8base.json": "b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41",
    "source/drat/data/labels.txt": "8e6220f83b17ef0686dea27fc285ceb0f8f992a780287b12456792a5fb4aa4d5",
    "source/drat/data/perms.json": "1b4e6b64f605f78432d075928ae28696ebf1945679c0818eb319ad61b5e3a3a3",
    "source/drat/data/zclauses.json": "7d586edab8c5527bc47dae89b5e396f69327da7f39707473706bdb7100b05e27",
    "coverage-witnesses.txt": "46c232791c3854b5181cc0e6f1307c6d6db8bbd737bece76cc796a7058885cd6",
    "inactive-cover-witnesses.tsv": "88b1681613fda52eff688df9c3a67d9bc7d6b6babd4056ad24b4e32dc8e15d4b",
    "residual-cubes.tsv": "5326f358c5aee7c8849b7cdf7241580721c6f0cfa4d24c0f914357d8f03af2ae",
    "picosat/f3591.cnf": "9b68e622353ea97eaa2ef982723385f05c975b092ebcf1d9da45313126370cf3",
    "picosat/f3591.drat": "cd58f0d0250e97bd74d065bcbadc6d0a354e7ad3a224ad4b23235ef3dab125c8",
    "picosat/f3591-core.cnf": "3bbf22ccd1736de06560cf427ce581c8a3e970e39a0d4a67ba414e2a763b9836",
    "picosat/f3591-core.drat": "7404438b3cb7c1944d7b6dfbc3548e993b66ffff917f42fba5235d6439e95221",
    "picosat/picosat.c": "ece48ed0c92cb43fdab8fc29c26a75d912233a13108697bb791d20f3d182a435",
    "picosat/picosat.h": "42eb87b8770850341a35338a40eedeeb233c17fc35a6d72f44cd16ec9f0a5e21",
    "drat-trim/drat-trim.c": "d834b649f437e091597f5347f259b9f681087f89ca0844d0cee250a1a1a0c2ee",
}
for name, expected in PINS.items():
    got = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    if got != expected:
        raise AssertionError(f"{name}: expected {expected}, got {got}")
print(f"PASS {len(PINS)} SHA-256 artifact pins")

spec = importlib.util.spec_from_file_location("pinned_gen", ROOT / "source/drat/gen.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
got = hashlib.sha256(gen.cube_text("f3591").encode()).hexdigest()
expected = PINS["picosat/f3591.cnf"]
assert got == expected
rows = [line.split("\t") for line in (ROOT / "source/drat/hashes.tsv").read_text().splitlines()
        if line.startswith("f3591\t")]
assert len(rows) == 1 and rows[0][1] == expected
print("PASS f3591 regenerates byte-identically and agrees with the author's hash row")
