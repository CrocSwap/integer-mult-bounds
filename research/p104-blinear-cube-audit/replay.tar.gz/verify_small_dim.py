#!/usr/bin/env python3
"""Check data premises for the dimension-at-most-three no-cover theorem.

The actual combinatorial proof, not a SAT search, is written in REVIEW.md.
"""
from pathlib import Path
import json

data = Path(__file__).resolve().parent / "source/drat/data"
E = json.loads((data / "e8base.json").read_text())
CL = json.loads((data / "zclauses.json").read_text())
H = [1 + sum((v & 1) << (i+1) for i, v in enumerate(c)) for c in E["C"][:104]]
assert len(H) == len(set(H)) == 104
assert all(h & 1 for h in H)
assert len(CL) == 104 and all(clauses and all(0 < v < 1 << 16 for v in clauses)
                              for clauses in CL)
assert 16 * 2 ** (3-1) == 64 < len(H)
print("PASS 104 distinct affine labels; every port has nonempty covering clauses")
print("PASS 16 subspaces of dimension <= 3 can contain at most 64 of 104 labels")
print("CONCLUSION the all-dim(U_z)<=3 subdomain has no satisfying cover, at any budget")
