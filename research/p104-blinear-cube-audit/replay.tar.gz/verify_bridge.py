#!/usr/bin/env python3
"""Check the exact finite premises for the tight decoder -> CNF bridge.

See REVIEW.md for the rational rank argument, Z/4 reduction, price identity,
row merging, normalization, and limitations. No solver or author code is used.
"""
from collections import Counter
from pathlib import Path
import json

D = Path(__file__).resolve().parent / "source/drat/data"
e = json.loads((D / "e8base.json").read_text())
C, G = e["C"], e["Gb"]
LAB = [int(v) for v in (D / "labels.txt").read_text().split()]
ports, normals = C[:104], C[104:]
assert len(ports) == len(LAB) == 104 and len(normals) == 16

def ip(a, b):
    return sum(a[i]*G[i][j]*b[j] for i in range(8) for j in range(8))

def vecbits(v, affine=False):
    return ((1 if affine else 0)
            | sum((v & 1) << (i + int(affine)) for i, v in enumerate(v)))

def rank2(rows):
    basis = {}
    for v in rows:
        while v:
            k = v.bit_length() - 1
            if k in basis:
                v ^= basis[k]
            else:
                basis[k] = v
                break
    return len(basis)

assert all(ip(c, c) == 2 for c in C)
assert all(ip(C[i], C[j]) in (-1, 0, 1)
           for i in range(120) for j in range(i))
assert rank2([vecbits(row) for row in G]) == 8
assert rank2([vecbits(row) for row in ports]) == 8
assert all(((LAB[t] & LAB[s]).bit_count() & 1)
           == (1 ^ (ip(ports[t], ports[s]) & 1))
           for t in range(104) for s in range(104))
print("PASS E8 pairing: norms 2, other pairs 0/+/-1, invertible mod 2, Q matches")
print("PASS 104 port coordinates span F2^8 (hence Q^8 and (Z/4)^8)")

orth_ranks = []
for t, c in enumerate(ports):
    orth = [ports[s] for s in range(104) if s != t and ip(c, ports[s]) == 0]
    orth_ranks.append(rank2([vecbits(v) for v in orth]))
assert Counter(orth_ranks) == {7: 104}
print("PASS each port's orthogonal peers have mod-2 rank 7 (104/104)")

for z, n in enumerate(normals):
    support = [t for t, c in enumerate(ports) if ip(c, n) != 0]
    # beta((1,a),(1,b)) = 1 + <a,b> mod 2. Normal n_z is
    # orthogonal to every support label and the support has rank eight.
    assert all((1 + ip(ports[t], n)) % 2 == 0 for t in support)
    assert rank2([vecbits(ports[t], affine=True) for t in support]) == 8
    assert vecbits(n, affine=True) not in {vecbits(c, affine=True) for c in ports}
print("PASS every normal spans the beta-perp of its support (16/16)")
