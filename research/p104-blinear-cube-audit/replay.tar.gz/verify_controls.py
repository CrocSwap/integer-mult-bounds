#!/usr/bin/env python3
"""Negative controls for mask witnesses, split boxes and the RUP checker."""
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
def rejected(command, fragment):
    result = subprocess.run(command, text=True, capture_output=True, check=False)
    if result.returncode == 0 or fragment not in result.stdout + result.stderr:
        raise AssertionError(f"expected rejection {fragment!r}, got {result.returncode}: "
                             + result.stdout + result.stderr)

with tempfile.TemporaryDirectory(prefix="audit-controls-", dir=ROOT) as folder:
    tmp = Path(folder)
    shutil.copytree(ROOT / "source/drat", tmp / "source/drat")
    shutil.copy(ROOT / "verify_coverage.py", tmp / "verify_coverage.py")
    shutil.copy(ROOT / "coverage-witnesses.txt", tmp / "coverage-witnesses.txt")

    perm = json.loads((tmp / "source/drat/data/perms.json").read_text())
    identity = perm.index(list(range(16)))
    lines = (tmp / "coverage-witnesses.txt").read_text().splitlines()
    mask = next(i for i, value in enumerate(lines) if int(value) != 65535)
    lines[mask] = str(identity)
    (tmp / "coverage-witnesses.txt").write_text("\n".join(lines) + "\n")
    rejected([sys.executable, "-B", str(tmp / "verify_coverage.py")],
             "witness never differs")
    print(f"PASS identity permutation rejected for omitted mask {mask}")

    shutil.copy(ROOT / "coverage-witnesses.txt", tmp / "coverage-witnesses.txt")
    g = tmp / "source/drat/gen.py"
    text = g.read_text()
    before = '"j8_8": (0, False, [[U(0, 7)], [U(1, 7)]]),'
    after = '"j8_8": (0, False, [[U(0, 7)], [U(1, 6)]]),'
    assert text.count(before) == 1
    g.write_text(text.replace(before, after))
    rejected([sys.executable, "-B", str(tmp / "verify_coverage.py")], "mask-0 split")
    print("PASS overlapping split boxes rejected")

    proof = (ROOT / "picosat/f3591-core.drat").read_text().splitlines()
    assert proof[0] == "-133 0"
    proof[0] = "133 0"
    invalid = tmp / "invalid.drat"
    invalid.write_text("\n".join(proof) + "\n")
    rejected([sys.executable, "-B", str(ROOT / "check_rup.py"),
              str(ROOT / "picosat/f3591.cnf"), str(ROOT / "picosat/f3591-core.cnf"),
              str(invalid)], "RUP failure at addition 1")
    print("PASS altered first RUP lemma rejected")
