#!/usr/bin/env python3
"""Check the P104 cube partition from local witnesses, without the author's DFS.

The only imported author code is gen.py: it exposes the actual generated lex
clauses and cube units, which are compared with the simple specifications here.
This does not check any UNSAT proof or establish the decoder-to-CNF reduction.
"""
from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
DRAT = ROOT / "source" / "drat"
DATA = DRAT / "data"
spec = importlib.util.spec_from_file_location("pinned_gen", DRAT / "gen.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)

def require(x, message):
    if not x:
        raise AssertionError(message)

P = [tuple(p) for p in json.loads((DATA / "perms.json").read_text())]
identity = tuple(range(16))
require(len(P) == len(set(P)) == 384 and identity in P, "permutation cardinality")
require(all(sorted(p) == list(range(16)) for p in P), "malformed permutation")
Pset = set(P)
require(all(tuple(p[q[i]] for i in range(16)) in Pset for p in P for q in P),
        "permutations not closed")
print("PASS group: 384 distinct permutations, identity and all 147456 compositions")

# Independently reconstruct each actual lex block from its ordered variables.
# Inspect exact clauses; the proof in REVIEW.md covers both semantic directions.
b = gen.Base()
expect = []
idx = 0
aux = set()
for p in P:
    if p == identity:
        continue
    prev = None
    for j, q in enumerate(p):
        if j == q:
            continue
        actual_p, actual_j, equal, strict = b.lex[idx]
        idx += 1
        require(tuple(actual_p) == p and actual_j == j and len(strict) == 9,
                "lex metadata mismatch")
        fresh = [equal] + strict
        require(not (set(fresh) & aux) and len(set(fresh)) == 10, "reused lex auxiliary")
        aux.update(fresh)
        pre = [] if prev is None else [-prev]
        for v in range(9):
            expect.append(tuple(pre + [-b.used[q, v], b.used[j, v]]))
        for v, sv in enumerate(strict):
            expect.extend([(-sv, b.used[j, v]), (-sv, -b.used[q, v])])
        expect.append(tuple(pre + [equal] + list(strict)))
        prev = equal
require(idx == len(b.lex), "lex block count")
require(expect == b.cls[b.n_tot1:], "lex clauses differ")
before_max = max(abs(lit) for clause in b.cls[:b.n_tot1] for lit in clause)
require(min(aux) > before_max and max(aux) == b.nv, "lex variables not fresh")
print(f"PASS generated lex blocks: {idx} positions, {len(expect)} clauses")

rows = []
for line in (DRAT / "cubes.txt").read_text().splitlines():
    if not line or line.startswith("#"):
        continue
    cid, names, _ = line.split("\t")
    mask = 0 if names == "-" else sum(1 << int(z) for z in names.split(","))
    rows.append((cid, mask))
require(len(rows) == len({cid for cid, _ in rows}) == 1001, "cube ids")
norm = Counter({(-b.used[z, 7], b.used[z, 8], -b.nin[z]): 1 for z in range(16)})
lookup = {v: k for k, v in b.used.items()}
boxes = {}
for cid, mask in rows:
    extra = gen.cube_extra(b, cid)
    nonunits = Counter(tuple(c) for c in extra if len(c) != 1)
    require(nonunits == norm, f"{cid}: normalization clauses")
    units = [c[0] for c in extra if len(c) == 1]
    require(len(units) == len(set(units)), f"{cid}: duplicate unit")
    require(all(abs(u) in lookup for u in units), f"{cid}: non-order unit")
    require(all((b.used[z, 8] if mask >> z & 1 else -b.used[z, 8]) in units
                for z in range(16)), f"{cid}: incorrect mask units")
    lo, hi = [0]*16, [9]*16
    for u in units:
        z, i = lookup[abs(u)]
        if u > 0:
            lo[z] = max(lo[z], i+1)
        else:
            hi[z] = min(hi[z], i)
    require(all(lo[z] <= hi[z] for z in range(16)), f"{cid}: empty box")
    if mask not in (0, 1):
        require(len(units) == 16, f"{cid}: unexpected split")
    else:
        require(all(lookup[abs(u)][1] == 8 or lookup[abs(u)][0] in (0, 1)
                    for u in units), f"{cid}: split outside rows 0 and 1")
    boxes.setdefault(mask, []).append((lo, hi))
require(len(boxes) == 993, "mask count")
require(all(len(boxes[m]) == 1 for m in boxes if m not in (0, 1)),
        "repeated nonsplit mask")
require(len(boxes[0]) == 6 and len(boxes[1]) == 4, "split cube counts")
for x in range(9):
    for y in range(9):
        require(sum(lo[0] <= x <= hi[0] and lo[1] <= y <= hi[1]
                    for lo, hi in boxes[0]) == 1, "mask-0 split")
for y in range(9):
    require(sum(lo[0] <= 9 <= hi[0] and lo[1] <= y <= hi[1]
                for lo, hi in boxes[1]) == 1, "mask-1 split")
print("PASS generated cube units: 1001 boxes, 993 masks; splits partition 81+9 cases")

raw = (ROOT / "coverage-witnesses.txt").read_bytes()
records = [int(x) for x in raw.decode("ascii").splitlines()]
require(len(records) == 65536 and all(0 <= i <= 65535 for i in records), "witness length or value")
for mask, index in enumerate(records):
    if mask in boxes:
        require(index == 65535, f"mask {mask}: expected covered marker")
        continue
    require(index < len(P), f"mask {mask}: bad permutation index")
    perm = P[index]
    for j, q in enumerate(perm):
        if j == q or (mask >> j & 1 and mask >> q & 1):
            continue
        require(not (mask >> j & 1) and (mask >> q & 1),
                f"mask {mask}: claimed witness does not force strict loss")
        break
    else:
        raise AssertionError(f"mask {mask}: witness never differs")
print("PASS coverage: 64543 omitted masks each have a direct lex-loss witness")
print("PASS witness sha256", hashlib.sha256(raw).hexdigest())
