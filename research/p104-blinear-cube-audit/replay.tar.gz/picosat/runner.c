#include "picosat.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

/* Minimal DIMACS runner for one bounded diagnostic. This is not a proof checker. */
int main(int argc, char **argv) {
    if (argc != 3) return 2;
    FILE *in = fopen(argv[1], "r");
    if (!in) return 2;
    PicoSAT *p = picosat_init();
    if (!picosat_enable_trace_generation(p)) return 3;
    char line[4096];
    while (fgets(line, sizeof line, in)) {
        if (line[0] == 'c' || line[0] == 'p') continue;
        char *s = line, *end;
        for (;;) {
            long x = strtol(s, &end, 10);
            if (end == s) break;
            if (x > INT_MAX || x < INT_MIN) return 2;
            picosat_add(p, (int)x);
            s = end;
        }
    }
    fclose(in);
    int status = picosat_sat(p, -1);
    printf("PicoSAT API %d: %s\n", PICOSAT_API_VERSION, status == 10 ? "SAT" : status == 20 ? "UNSAT" : "UNKNOWN");
    if (status == 20) {
        FILE *proof = fopen(argv[2], "w");
        if (!proof) return 2;
        picosat_write_rup_trace(p, proof);
        fclose(proof);
    }
    picosat_reset(p);
    return status;
}
