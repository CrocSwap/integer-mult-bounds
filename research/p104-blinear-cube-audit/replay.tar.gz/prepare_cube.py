#!/usr/bin/env python3
"""Regenerate the f3591 CNF only after checking pinned generator input hashes."""
from pathlib import Path
import hashlib
import importlib.util
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
inputs = {
    "source/drat/gen.py": "2109ace16a7b04aa399ab0a06739afbb6fe378348e06360ce26620b721a08472",
    "source/drat/data/e8base.json": "b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41",
    "source/drat/data/perms.json": "1b4e6b64f605f78432d075928ae28696ebf1945679c0818eb319ad61b5e3a3a3",
    "source/drat/data/zclauses.json": "7d586edab8c5527bc47dae89b5e396f69327da7f39707473706bdb7100b05e27",
}
for path, expected in inputs.items():
    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected, path
spec = importlib.util.spec_from_file_location("pinned_gen", ROOT / "source/drat/gen.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
payload = gen.cube_text("f3591").encode()
expected = "9b68e622353ea97eaa2ef982723385f05c975b092ebcf1d9da45313126370cf3"
assert hashlib.sha256(payload).hexdigest() == expected
output = ROOT / "picosat/f3591.cnf"
if output.exists():
    assert hashlib.sha256(output.read_bytes()).hexdigest() == expected, "existing CNF differs"
else:
    output.write_bytes(payload)
print("PASS pinned generator inputs; full f3591 CNF SHA-256", expected)
