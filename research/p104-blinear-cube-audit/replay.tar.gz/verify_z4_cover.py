#!/usr/bin/env python3
"""Re-derive every P104 Z/4 cover clause using bitset subset closure.

For each character x in (Z/4)^8, let R(x) mark normals z with <x,z> != 0,
and T(x) mark ports c with <x,c> != 0.  The OR clause on R(x) is necessary
at every port in T(x). Stored clauses are sufficient exactly when each T(x)
is contained in the union of targets of stored masks contained in R(x).
The 2^16 subset transform below checks that in bulk. We also require every
stored port/mask pair to be witnessed by a character and minimal. The separate
algebraic explanation of dual separation is in REVIEW.md.
"""
from pathlib import Path
import json

DATA = Path(__file__).resolve().parent / "source/drat/data"
e = json.loads((DATA / "e8base.json").read_text())
CL = json.loads((DATA / "zclauses.json").read_text())
C, G = e["C"], e["Gb"]
assert len(C) == 120 and len(CL) == 104
by_mask = [0] * 65536
for t, clauses in enumerate(CL):
    assert len(clauses) == len(set(clauses)) and clauses
    for mask in clauses:
        assert 0 < mask < 65536
        assert not any(other != mask and other & mask == other for other in clauses)
        by_mask[mask] |= 1 << t

# For every mask R, targets[R] is the set of ports with at least one stored
# clause that is a subset of R. This does not use the author's minimization.
targets = by_mask[:]
for bit in range(16):
    for mask in range(65536):
        if mask >> bit & 1:
            targets[mask] |= targets[mask ^ (1 << bit)]

# Precompute the independent contribution of each 4-coordinate block.
table = []
for c in C:
    coeff = [sum(G[i][j] * c[j] for j in range(8)) % 4 for i in range(8)]
    blocks = []
    for start in (0, 4):
        blocks.append([sum(((x >> (2*i)) & 3) * coeff[start+i]
                           for i in range(4)) % 4 for x in range(256)])
    table.append(blocks)

observed = [0] * 65536
rm_seen = set()
tight = set()
for x in range(65536):
    lo, hi = x & 255, x >> 8
    mask = 0
    for z in range(16):
        a, b = table[104+z]
        if (a[lo] + b[hi]) % 4:
            mask |= 1 << z
    ports = 0
    has_two = False
    for t in range(104):
        a, b = table[t]
        value = (a[lo] + b[hi]) % 4
        if value == 2:
            has_two = True
        if value:
            ports |= 1 << t
    if x and not has_two:
        tight.add(x)
    if ports & ~targets[mask]:
        raise AssertionError(f"missing stored clause for Z4 character {x}")
    observed[mask] |= ports
    rm_seen.add(mask)

for mask in range(65536):
    if by_mask[mask] & ~observed[mask]:
        raise AssertionError(f"stored mask {mask} has no character witness")
print("PASS all 65536 Z4 characters: every port/mask obstruction is covered")
print(f"PASS {sum(map(len,CL))} stored clauses: each witnessed and inclusion-minimal")
print(f"PASS {len(rm_seen)} distinct row-support masks generated from characters")
pack = lambda v: sum((c % 4) << (2*i) for i, c in enumerate(v))
expected_tight = {pack(c) for c in C[104:]} | {pack([-v for v in c]) for c in C[104:]}
assert len(expected_tight) == 32 and tight == expected_tight
print("PASS 32 nonzero tight vectors are exactly +/- the 16 pinned normals")
