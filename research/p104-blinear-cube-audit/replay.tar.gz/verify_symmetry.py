#!/usr/bin/env python3
"""Independently bind all 384 row permutations to the pinned P104 relaxation.

This verifies permutation closure, a beta-preserving linear change of labels,
port bijections and exact transport of every covering clause. It proves no SAT
or DRAT result. Uses Python's standard library and the pinned plain JSON data.
"""
from pathlib import Path
import json

DATA = Path(__file__).resolve().parent / "source/drat/data"
E = json.loads((DATA / "e8base.json").read_text())
CL = json.loads((DATA / "zclauses.json").read_text())
P = [tuple(p) for p in json.loads((DATA / "perms.json").read_text())]
LAB = [int(x) for x in (DATA / "labels.txt").read_text().split()]

def req(x, what):
    if not x:
        raise AssertionError(what)

def bits(v):
    return sum((x & 1) << i for i, x in enumerate(v))

C = [bits(c) for c in E["C"][:104]]
Z = [bits(c) for c in E["C"][104:]]
G = [bits(row) for row in E["Gb"]]
req(len(C) == len(set(C)) == 104 and len(Z) == len(set(Z)) == 16,
    "distinct ports and rows")
req(not (set(C) & set(Z)), "row normal coincides with a port")

def beta8(x, y):
    return sum(((x >> i) & 1) * ((G[i] & y).bit_count() & 1)
               for i in range(8)) & 1

req(len(LAB) == 104 and all(((LAB[i] & LAB[j]).bit_count() & 1)
                            == (1 ^ beta8(C[i], C[j]))
                            for i in range(104) for j in range(104)),
    "affine geometry does not match pinned Q")
print("PASS 104 distinct labels, 16 distinct normals, disjoint, Q matches beta")

index = {x: i for i, x in enumerate(C)}
clsets = [set(v) for v in CL]
for perm_no, p in enumerate(P):
    # Eliminate the 16 input/output pairs simultaneously. Every dependence
    # must be preserved, and rank eight gives a uniquely defined linear map.
    basis = [None] * 8
    for x, y in zip(Z, (Z[p[z]] for z in range(16))):
        for k in range(7, -1, -1):
            if not (x >> k & 1):
                continue
            if basis[k] is not None:
                x ^= basis[k][0]
                y ^= basis[k][1]
            else:
                basis[k] = (x, y)
                break
        else:
            req(y == 0, f"permutation {perm_no}: inconsistent normal dependence")
    req(all(basis), f"permutation {perm_no}: normals do not span")

    def image(x):
        y = 0
        for k in range(7, -1, -1):
            if x >> k & 1:
                x ^= basis[k][0]
                y ^= basis[k][1]
        req(x == 0, "incomplete basis")
        return y

    units = [image(1 << i) for i in range(8)]
    # Isometry on the basis implies isometry on all vectors; nondegeneracy
    # is independently verified below, making the map invertible.
    req(all(beta8(units[i], units[j]) == beta8(1 << i, 1 << j)
            for i in range(8) for j in range(8)),
        f"permutation {perm_no}: beta isometry")
    req(all(image(Z[z]) == Z[p[z]] for z in range(16)), "normal transport")
    req(all(image(c) in index for c in C), f"permutation {perm_no}: port image")
    pp = [index[image(c)] for c in C]
    req(len(set(pp)) == 104, f"permutation {perm_no}: ports not bijective")

    # Transport 16-bit masks with two independently precomputed lookup tables.
    low = [sum(1 << p[z] for z in range(8) if mask >> z & 1)
           for mask in range(256)]
    high = [sum(1 << p[z+8] for z in range(8) if mask >> z & 1)
            for mask in range(256)]
    for t in range(104):
        mapped = {low[mask & 255] | high[mask >> 8] for mask in CL[t]}
        req(mapped == clsets[pp[t]], f"permutation {perm_no}: clauses port {t}")

# Nondegeneracy by row elimination: image is an isometry of this form.
rows = G[:]
rank = 0
for bit in range(8):
    pivot = next((j for j in range(rank, 8) if rows[j] >> bit & 1), None)
    if pivot is None:
        continue
    rows[rank], rows[pivot] = rows[pivot], rows[rank]
    for j in range(8):
        if j != rank and rows[j] >> bit & 1:
            rows[j] ^= rows[rank]
    rank += 1
req(rank == 8, "degenerate beta")
print("PASS 384 affine beta-isometries transport all normals, ports and 17152 clauses")
