#!/usr/bin/env python3
"""Run the archive's standard library checks in a reproducible order."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
checks = [
    ["prepare_cube.py"],
    ["verify_artifacts.py"],
    ["verify_bridge.py"],
    ["verify_z4_cover.py"],
    ["verify_fidelity.py"],
    ["verify_symmetry.py"],
    ["verify_coverage.py"],
    ["verify_cover_eliminations.py"],
    ["verify_small_dim.py"],
    ["check_rup.py", "picosat/f3591.cnf", "picosat/f3591-core.cnf", "picosat/f3591-core.drat"],
    ["verify_controls.py"],
]
for args in checks:
    print("RUN", " ".join(args), flush=True)
    subprocess.run([sys.executable, "-B", *args], cwd=ROOT, check=True)
print("ALL CHECKS PASSED")
