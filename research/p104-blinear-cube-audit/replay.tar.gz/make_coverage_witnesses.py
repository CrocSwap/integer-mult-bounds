#!/usr/bin/env python3
"""Create a compact, locally checkable permutation witness for each omitted mask.

Run from this directory.  The output contains 65,536 decimal integers, one per line.
65535 marks a mask present in cubes.txt; every other value indexes a row of
perms.json.  This generator is not part of the verifier's trusted logic.
"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent
DRAT = ROOT / "source" / "drat"
perms = json.loads((DRAT / "data/perms.json").read_text())
covered = set()
for line in (DRAT / "cubes.txt").read_text().splitlines():
    if line.startswith("#") or not line:
        continue
    _, names, _ = line.split("\t")
    covered.add(0 if names == "-" else sum(1 << int(z) for z in names.split(",")))

records = []
for mask in range(1 << 16):
    if mask in covered:
        records.append(65535)
        continue
    for k, perm in enumerate(perms):
        for j, q in enumerate(perm):
            if j == q or (mask >> j & 1 and mask >> q & 1):
                continue
            if not (mask >> j & 1) and (mask >> q & 1):
                records.append(k)
                break
            break
        else:
            continue
        if len(records) == mask + 1:
            break
    else:
        raise ValueError(f"no local witness for mask {mask}")

out = ROOT / "coverage-witnesses.txt"
out.write_text("".join(f"{record}\n" for record in records), encoding="ascii")
print(f"wrote {out.name}: {sum(x != 65535 for x in records)} witnesses")
