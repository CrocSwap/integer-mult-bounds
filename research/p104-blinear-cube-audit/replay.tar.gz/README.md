# Independent audit of P104 tight B-linear decoder encoding

Read [REVIEW.md](REVIEW.md) for the exact hypotheses, proofs, provenance,
reproduction commands, and limitations. The accompanying original inputs are
from PR #7852 at commit `41beda1d6435760dc99e38bd7e65f36798aad212`; their
upstream location and file pins are recorded in the review.

The audit checks the covering reduction, all generated CNF components,
symmetry, and exhaustive cube coverage. Direct cover contradictions eliminate
**612 of 1,001 cubes**; the remaining 389 are listed explicitly. It also gives
a direct proof for the subdomain with every row dimension at most three. Cube
`f3591` is among the 612; its newly generated refutation can be independently
replayed by the included standard-library Python RUP checker. Only that one
cube was rerun with a solver. This package does not establish the full
budget-55 claim or a kappa bound.

For a first check, run `python3 -B verify_all.py`, or run the individual commands
in the reproduction section of REVIEW.md.
`prepare_cube.py` rebuilds the full named cube if absent, after checking the
pinned generator inputs, and requires its exact SHA-256. `verify_artifacts.py`
checks source and proof digests. `verify_controls.py` runs three deliberately failing
mutations and requires them to be rejected. `SHA256SUMS` inventories this
archive's other files. No compiled solver binaries are included.
