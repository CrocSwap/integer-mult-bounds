// Independent triangle screen: enumerate every 18-bit transvection, dedup
// resulting 9-dimensional subspaces by binary RREF, and use direct pair ranks.
#include <array>
#include <algorithm>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <vector>
using Basis=std::array<unsigned,9>;
using Score=long long;
constexpr unsigned MASK=(1u<<9)-1;
int omega(unsigned x,unsigned y){return std::popcount(((x&MASK)&(y>>9))^((y&MASK)&(x>>9)))&1;}
Basis rref(Basis x){
 int pos=0;for(int c=17;c>=0;c--){int k=pos;while(k<9&&!((x[k]>>c)&1))k++;if(k==9)continue;std::swap(x[k],x[pos]);for(int i=0;i<9;i++)if(i!=pos&&((x[i]>>c)&1))x[i]^=x[pos];pos++;}
 if(pos!=9)throw std::runtime_error("rank not 9");return x;
}
int grade(Basis const& a,Basis const& b){
 std::array<unsigned,9> piv{};int r=0;
 for(auto x:a){unsigned row=0;for(int i=0;i<9;i++)row|=omega(x,b[i])<<i;
  while(row){int k=std::bit_width(row)-1;if(piv[k])row^=piv[k];else{piv[k]=row;r++;break;}}}
 return r;
}
std::vector<Basis> all_neighbors(Basis const& old){
 std::map<Basis,unsigned> unique;
 auto identity=rref(old);
 for(unsigned axis=1;axis<(1u<<18);axis++){
  Basis x=old;for(auto& v:x)if(omega(v,axis))v^=axis;
  auto y=rref(x);if(y==identity)continue;
  unique.try_emplace(y,axis);
 }
 if(unique.size()!=1022)throw std::runtime_error("neighbor count");
 std::vector<Basis> all;for(auto const& [x,v]:unique){(void)v; if(grade(x,old)!=1)throw std::runtime_error("non-neighbor");all.push_back(x);}return all;
}
struct Contact{int a,b,p,h,r;int other(int x)const{return a^b^x;}};
struct Node{int label,frame,fixed;std::vector<int> edges;};
struct State{Basis b;Score exterior=0;bool ok=true;};
struct Table{std::vector<Score> score;std::vector<uint8_t> grade;};
int main(int argc,char**argv){
 if(argc!=3)return 2;std::ifstream graph(argv[1]),weights(argv[2]);int nf,nv,ne;graph>>nf>>nv>>ne;
 std::vector<Basis> f(nf);for(auto& x:f)for(auto& v:x)graph>>v;
 std::vector<Node> nodes(nv);std::array<int,3> idx{-1,-1,-1};
 for(int i=0;i<nv;i++){graph>>nodes[i].label>>nodes[i].frame>>nodes[i].fixed;for(int j=0;j<3;j++)if(nodes[i].label==std::array{542,1249,1292}[j])idx[j]=i;}
 std::vector<Contact> e(ne);for(int i=0;i<ne;i++){graph>>e[i].a>>e[i].b>>e[i].p>>e[i].h>>e[i].r;nodes[e[i].a].edges.push_back(i);nodes[e[i].b].edges.push_back(i);if(grade(f[nodes[e[i].a].frame],f[nodes[e[i].b].frame])!=e[i].r)return 3;}
 std::array<Score,10> w{};for(auto&x:w)weights>>x;if(!graph||!weights)return 4;
 auto charge=[&](Contact const& c,int r){return Score(c.h-c.p)*(w[r]-w[c.r]);};
 std::array<std::vector<State>,3> s;std::array<int,3> good{};
 for(int z=0;z<3;z++){
  if(idx[z]<0||nodes[idx[z]].fixed)return 5;
  for(auto const& basis:all_neighbors(f[nodes[idx[z]].frame])){
   State state;state.b=basis;
   for(int q:nodes[idx[z]].edges){auto const&c=e[q];int other=c.other(idx[z]);if(std::find(idx.begin(),idx.end(),other)!=idx.end())continue;
    int r=grade(basis,f[nodes[other].frame]);state.exterior+=charge(c,r);if(!r&&(c.p||c.h))state.ok=false;}
   good[z]+=state.ok;s[z].push_back(state);
  }
 }
 std::array<std::pair<int,int>,3> ep{{{0,1},{0,2},{1,2}}};std::array<Table,3> T;constexpr int N=1022;
 for(int q=0;q<3;q++){
  auto [x,y]=ep[q];int edge=-1;for(int k:nodes[idx[x]].edges)if(e[k].other(idx[x])==idx[y])edge=k;
  if(edge<0)throw std::runtime_error("not a triangle");T[q].score.resize(N*N);T[q].grade.resize(N*N);
  for(int i=0;i<N;i++)for(int j=0;j<N;j++){int r=grade(s[x][i].b,s[y][j].b);T[q].grade[i*N+j]=r;T[q].score[i*N+j]=charge(e[edge],r);}
 }
 Score relaxed=INT64_MIN,strict=INT64_MIN;uint64_t count=0,scount=0;
 // Alternative contraction order: fix two nodes and reduce the remaining one.
 for(int j=0;j<N;j++)for(int i=0;i<N;i++){
  int ij=i*N+j;auto base=s[0][i].exterior+s[1][j].exterior+T[0].score[ij];
  bool valid=s[0][i].ok&&s[1][j].ok&&T[0].grade[ij];
  for(int k=0;k<N;k++){
   int ik=i*N+k,jk=j*N+k;
   Score v=base+s[2][k].exterior+T[1].score[ik]+T[2].score[jk];
   if(v>relaxed)relaxed=v;count++;
   if(valid&&s[2][k].ok&&T[1].grade[ik]&&T[2].grade[jk]){if(v>strict)strict=v;scount++;}
  }
 }
 std::cout<<"direct_rref_neighbor_counts "<<s[0].size()<<' '<<s[1].size()<<' '<<s[2].size()<<" unary_eligible "<<good[0]<<' '<<good[1]<<' '<<good[2]<<'\n';
 std::cout<<"relaxed "<<count<<' '<<relaxed<<" strict "<<scount<<' '<<strict<<'\n';
}
