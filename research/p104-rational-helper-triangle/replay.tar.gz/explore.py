from collections import Counter, defaultdict
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
DATA = HERE
import clifford_exact as clifford
from common import canonical, margin, enclose, histogram

N = 9
MASK = (1 << N) - 1
TARGET = '0.003889928046155'
POINT = [0.0] + [x ** (1 - float(TARGET)) for x in range(1, N + 1)]

def load(name):
    path = DATA / 'inputs' / name
    raw = path.read_bytes()
    locks = json.loads((DATA / 'SOURCE-LOCK.json').read_bytes())
    pin = next(r for r in locks if r['file'] == 'inputs/' + name)
    assert sha256(raw).hexdigest() == pin['sha256']
    return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)

GRAPH = load('DOUBLE-CANDIDATE.json.gz')
LAYOUT = load('LAYOUT.json.gz')
APP = load('DOUBLE-APPLICATION.json')
WORD = sha256(canonical(GRAPH)).hexdigest()
LAYOUT_SHA = sha256(canonical(LAYOUT)).hexdigest()
assert WORD == '7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48' == APP['word_sha256']
assert LAYOUT_SHA == 'f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7' == APP['layout_sha256']
assert APP['caller'] == '156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858'
FRAMES = LAYOUT['frames']
assert GRAPH['frames'] == FRAMES
LIVE = set(LAYOUT['live'])
MAIN = LIVE | {r + 112 for r in LIVE} | set(LAYOUT['hosted']['X2']) | set(LAYOUT['hosted']['Y2'])
FIXED = {GRAPH[name][r] for name in ('initial', 'final') for r in MAIN}
PAID = [(slot, a, b) for slot, a, b in GRAPH['moves']]
HELPERS = [(r, GRAPH['initial'][r], GRAPH['final'][r]) for r in range(len(GRAPH['initial'])) if r not in MAIN]
INC = defaultdict(lambda: defaultdict(lambda: [[], []]))
for values, j in ((PAID, 0), (HELPERS, 1)):
    for label, a, b in values:
        INC[a][b][j].append((label, a, b))
        INC[b][a][j].append((label, a, b))

def outer(v):
    return tuple(v if v >> i & 1 else 0 for i in range(N))


def xor(a, b):
    return tuple(x ^ y for x, y in zip(a, b, strict=True))


def polar(vectors):
    result = (0,) * N
    for v in vectors:
        result = xor(result, outer(v))
    return result

MATS = list(map(polar, FRAMES))
ADAPTERS = []
NATIVE = [Counter(), Counter()]
for group, counter in zip((PAID, HELPERS), NATIVE, strict=True):
    for _, a, b in group:
        counter[abs(len(FRAMES[a]) - len(FRAMES[b]))] += 1

def orthogonal(F):
    return all(((a & b).bit_count() & 1) == (i == j) for i, a in enumerate(F) for j, b in enumerate(F))

def is_alt(M):
    return not any(v >> i & 1 for i, v in enumerate(M))

def matrix_rank(M):
    return clifford.rank(M)

if __name__ == '__main__':
    print('word', WORD, 'layout',LAYOUT_SHA,'keys',list(GRAPH))
    print('frames', len(FRAMES), 'fixed', len(FIXED), 'main', len(MAIN), 'unfixed active',len(INC.keys() - FIXED), 'orth', sum(map(orthogonal,FRAMES)), 'distinct polar', len(set(MATS)))
    for group in (PAID, HELPERS):
        counts = Counter()
        for label, a, b in group:
            old = abs(len(FRAMES[a]) - len(FRAMES[b]))
            M = xor(MATS[a], MATS[b])
            counts[(old,matrix_rank(M),is_alt(M))]+=1
        print(counts)
    for c in sorted(INC.keys() - FIXED, key=lambda c: len(INC[c]), reverse=True)[:18]:
        print('chart',c,FRAMES[c], 'neighbors',{j: (len(g[0]),len(g[1])) for j,g in INC[c].items()})
