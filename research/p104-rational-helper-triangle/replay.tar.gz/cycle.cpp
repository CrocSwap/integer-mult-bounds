#include "neighbors.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

using Basis = std::vector<unsigned>;
using PackedBill = __int128_t;
using Score = int64_t;
constexpr int n = 9;
constexpr unsigned mask = (1u << n) - 1;
constexpr int bill_digit_bits = 14;
constexpr int digits_modulus = 1 << bill_digit_bits;

unsigned symplectic(unsigned a, unsigned b) {
    return std::popcount(((a & mask) & (b >> n)) ^ ((b & mask) & (a >> n))) & 1;
}

unsigned pairing(Basis const& lag, unsigned axis) {
    unsigned result = 0;
    for (int j = 0; j < n; ++j) result |= symplectic(lag[j], axis) << j;
    return result;
}

Basis transvect(Basis lag, unsigned axis) {
    for (auto& v : lag) if (symplectic(v, axis)) v ^= axis;
    return lag;
}

template <size_t width, class Rows>
int rank_binary(Rows const& rows) {
    std::array<unsigned, width> pivots{};
    int rank = 0;
    for (auto v : rows) {
        while (v) {
            const int j = std::bit_width(v) - 1;
            if (pivots[j]) v ^= pivots[j];
            else {
                pivots[j] = v;
                ++rank;
                break;
            }
        }
    }
    return rank;
}

int relative(Basis const& a, Basis const& b) {
    std::array<unsigned, n> rows;
    for (int j = 0; j < n; ++j) rows[j] = pairing(b, a[j]);
    return rank_binary<n>(rows);
}

int direct_relative(Basis const& a, unsigned v, Basis const& b, unsigned w) {
    std::array<unsigned, 2*n> combined;
    for (int j = 0; j < n; ++j) {
        combined[j] = a[j] ^ (symplectic(a[j], v) ? v : 0);
        combined[n+j] = b[j] ^ (symplectic(b[j], w) ? w : 0);
    }
    return rank_binary<2*n>(combined) - n;
}

struct Contact {
    int a, b, paid, helper, rank;
    int coefficient() const { return helper - paid; }
    int other(int endpoint) const { return a ^ b ^ endpoint; }
};

// One moving Lagrangian and one fixed Lagrangian. Eliminate into their sum,
// remembering the representative from the moving side.
struct SingleRank {
    std::array<unsigned, 2*n> pivots{}, left{};
    int rank;

    SingleRank(Basis const& moving, Basis const& fixed, int old_rank) : rank(old_rank) {
        for (auto const* side : {&moving, &fixed}) {
            for (auto v : *side) {
                unsigned a = side == &moving ? v : 0;
                while (v) {
                    const int j = std::bit_width(v) - 1;
                    if (pivots[j]) {
                        v ^= pivots[j];
                        a ^= left[j];
                    } else {
                        pivots[j] = v;
                        left[j] = a;
                        break;
                    }
                }
            }
        }
    }

    int after(unsigned axis) const {
        unsigned v = axis, a = 0;
        while (v) {
            const int j = std::bit_width(v) - 1;
            if (!pivots[j]) return rank + 1;
            v ^= pivots[j];
            a ^= left[j];
        }
        return rank - symplectic(a, axis);
    }
};

// For the simultaneously updated pair, put the base pairing into diag(I_r,0)
// and take the Schur complement of I_r in the rank-two update.
struct CoupledRank {
    Basis a, b;
    int rank = 0;

    CoupledRank(Basis left, Basis right) : a(std::move(left)), b(std::move(right)) {
        for (; rank < n; ++rank) {
            int i = rank, j = n;
            for (; i < n; ++i) {
                for (j = rank; j < n; ++j) if (symplectic(a[i], b[j])) break;
                if (j < n) break;
            }
            if (i == n) break;
            std::swap(a[rank], a[i]);
            std::swap(b[rank], b[j]);
            for (i = rank + 1; i < n; ++i) if (symplectic(a[i], b[rank])) a[i] ^= a[rank];
            for (j = rank + 1; j < n; ++j) if (symplectic(a[rank], b[j])) b[j] ^= b[rank];
        }
    }

    struct Axis {
        unsigned v, a, b;
    };

    Axis axis(unsigned v) const { return {v, pairing(a, v), pairing(b, v)}; }

    int after(Axis v, Axis w) const {
        const unsigned active = (1u << rank) - 1;
        const unsigned alpha = v.a;
        const unsigned q = w.a;
        const unsigned beta = w.b;
        const unsigned u = v.b ^ (symplectic(v.v, w.v) ? beta : 0);

        const unsigned h0 = (u & ~active) | ((1 ^ (std::popcount(u & alpha & active) & 1)) << n)
                             | ((std::popcount(u & q & active) & 1) << (n + 1));
        const unsigned h1 = (beta & ~active) | ((std::popcount(beta & alpha & active) & 1) << n)
                             | ((1 ^ (std::popcount(beta & q & active) & 1)) << (n + 1));
        const unsigned pattern_01 = (alpha & ~q & ~active) ? 1u << n : 0;
        const unsigned pattern_10 = (q & ~alpha & ~active) ? 1u << (n + 1) : 0;
        const unsigned pattern_11 = (alpha & q & ~active) ? 3u << n : 0;
        return rank - 2 + rank_binary<n+2>(std::array{pattern_01, pattern_10, pattern_11, h0, h1});
    }
};

struct Contact2 { int a,b,paid,helper,rank; int other(int i) const{return a^b^i;} };
struct Node2 {int label,frame,fixed;std::vector<int> inc;};
struct Choice {unsigned axis;int64_t unary=0;bool valid=true;};
struct Pair {std::vector<int64_t> score;std::vector<uint8_t> rank;};
struct Best {int64_t score=std::numeric_limits<int64_t>::min();int a=-1,b=-1,c=-1;};
int main(int argc,char**argv){
 if(argc!=3)return 2;
 std::ifstream graph(argv[1]),t(argv[2]);int nf,nv,ne;graph>>nf>>nv>>ne;
 if(nf!=1103||nv!=1362||ne!=4179)return 3;
 std::vector<Basis> frames(nf,Basis(n)); for(auto&f:frames)for(auto&v:f)graph>>v;
 std::vector<Node2> nodes(nv);std::array<int,3> idx{-1,-1,-1},labels{542,1249,1292};
 for(int i=0;i<nv;i++){graph>>nodes[i].label>>nodes[i].frame>>nodes[i].fixed;for(int j=0;j<3;j++)if(nodes[i].label==labels[j])idx[j]=i;}
 std::vector<Contact2> contacts(ne);int allcount=0;
 for(auto&c:contacts){graph>>c.a>>c.b>>c.paid>>c.helper>>c.rank;nodes[c.a].inc.push_back(&c-&contacts[0]);nodes[c.b].inc.push_back(&c-&contacts[0]);allcount+=c.paid+c.helper;if(c.rank!=relative(frames[nodes[c.a].frame],frames[nodes[c.b].frame]))throw std::runtime_error("old rank");}
 std::array<int64_t,10> w{};for(auto&x:w)t>>x;if(!graph||!t||allcount!=6596)throw std::runtime_error("input");
 for(int i:idx)if(i<0||nodes[i].fixed)throw std::runtime_error("fixed endpoint");
 auto price=[&](Contact2 const&c,int r){return int64_t(c.helper-c.paid)*(w[r]-w[c.rank]);};
 std::array<std::vector<Choice>,3> edit;
 int affected=0,paid=0,help=0;for(auto&c:contacts){bool z=false;for(int i:idx)z|=c.a==i||c.b==i;if(z){affected++;paid+=c.paid;help+=c.helper;}}
 if(affected!=32||paid!=45||help!=14)throw std::runtime_error("census");
 for(int h=0;h<3;h++){
  auto const&lag=frames[nodes[idx[h]].frame];auto axes=canonical_transvection_axes(lag);
  if(axes.size()!=1022)throw std::runtime_error("axes size");
  for(size_t k=0;k<axes.size();k++){
   unsigned fun=k/2+1,axis=axes[k];if(pairing(lag,axis)!=fun || (k%2&&(axes[k-1]^axis)!=lag[std::countr_zero(fun)]))throw std::runtime_error("axis enumeration");
   edit[h].push_back({axis,0,true});
  }
  for(int e:nodes[idx[h]].inc){auto const&c=contacts[e];int other=c.other(idx[h]);
   if(std::find(idx.begin(),idx.end(),other)!=idx.end())continue;
   auto const&fixed=frames[nodes[other].frame];SingleRank fast(lag,fixed,c.rank);
   for(auto&x:edit[h]){int rank=fast.after(x.axis);if(rank!=direct_relative(lag,x.axis,fixed,0))throw std::runtime_error("unary independent rank mismatch");x.unary+=price(c,rank);if(!rank&&(c.paid||c.helper))x.valid=false;}
  }
 }
 constexpr int count=1022;
 std::array<std::pair<int,int>,3> endpoints{{{0,1},{0,2},{1,2}}};std::array<Pair,3> pair;
 for(int h=0;h<3;h++){
  auto [a,b]=endpoints[h];Contact2 const*ptr=nullptr;for(int e:nodes[idx[a]].inc)if(contacts[e].other(idx[a])==idx[b]){if(ptr)throw std::runtime_error("parallel graph edge");ptr=&contacts[e];}
  if(!ptr)throw std::runtime_error("missing triangle edge"); auto const&c=*ptr;
  auto const&la=frames[nodes[idx[a]].frame];auto const&lb=frames[nodes[idx[b]].frame];CoupledRank joint(la,lb);
  if(joint.rank!=c.rank)throw std::runtime_error("joint start rank");
  pair[h].score.resize(count*count);pair[h].rank.resize(count*count);
  for(int x=0;x<count;x++)for(int y=0;y<count;y++){
   int r=joint.after(joint.axis(edit[a][x].axis),joint.axis(edit[b][y].axis));
   if(r!=direct_relative(la,edit[a][x].axis,lb,edit[b][y].axis))throw std::runtime_error("joint independent rank mismatch");
   pair[h].score[x*count+y]=price(c,r);pair[h].rank[x*count+y]=r;
  }
 }
 std::array<int,3> unary_bad{};for(int x=0;x<3;x++)for(auto&a:edit[x])unary_bad[x]+=!a.valid;
 uint64_t total=0,strict_count=0,relax_pos=0,strict_pos=0,relax_zero=0,strict_zero=0;Best rbest,sbest;
 // Exhaustive max-plus contraction of the 3-edge cycle. Unary terms include
 // every affected exterior incidence; pair terms each include the closing edge.
 for(int i=0;i<count;i++)for(int j=0;j<count;j++){
  int ij=i*count+j;int64_t xy=edit[0][i].unary+edit[1][j].unary+pair[0].score[ij];
  bool validij=edit[0][i].valid&&edit[1][j].valid&&pair[0].rank[ij]>0;
  for(int k=0;k<count;k++){
   int ik=i*count+k,jk=j*count+k;
   int64_t z=xy+edit[2][k].unary+pair[1].score[ik]+pair[2].score[jk];
   total++;relax_pos+=z>0;relax_zero+=z==0;
   if(z>rbest.score)rbest={z,i,j,k};
   bool strict=validij&&edit[2][k].valid&&pair[1].rank[ik]>0&&pair[2].rank[jk]>0;
   strict_count+=strict;strict_pos+=strict&&(z>0);strict_zero+=strict&&(z==0);
   if(strict&&z>sbest.score)sbest={z,i,j,k};
  }
 }
 if(total!=1067462648ULL)throw std::runtime_error("tuple count");
 auto output=[&](char const*name,Best const&b){std::cout<<name<<" score "<<b.score<<" indices "<<b.a<<' '<<b.b<<' '<<b.c<<" axes "<<edit[0][b.a].axis<<' '<<edit[1][b.b].axis<<' '<<edit[2][b.c].axis<<" grades "<<int(pair[0].rank[b.a*count+b.b])<<' '<<int(pair[1].rank[b.a*count+b.c])<<' '<<int(pair[2].rank[b.b*count+b.c])<<'\n';};
 std::cout<<"nodes 542 1249 1292 contacts "<<affected<<" paid "<<paid<<" helper "<<help<<" coupled_ranks_crosschecked "<<3*count*count<<'\n';
 std::cout<<"unary_rejected "<<unary_bad[0]<<' '<<unary_bad[1]<<' '<<unary_bad[2]<<'\n';
 std::cout<<"relaxed_total "<<total<<" grid_positive "<<relax_pos<<" grid_zero "<<relax_zero<<'\n';
 std::cout<<"strict_total "<<strict_count<<" grid_positive "<<strict_pos<<" grid_zero "<<strict_zero<<'\n';
 output("relaxed_best",rbest);output("strict_best",sbest);
}
