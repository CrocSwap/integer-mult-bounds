#!/usr/bin/env python3
"""Rebuild and price a complete helper-interaction triangle from locked inputs."""
from collections import Counter,deque
from fractions import Fraction as F
from hashlib import sha256
from io import StringIO
from itertools import combinations
from pathlib import Path
import json,subprocess,tempfile
from common import authenticate,enclose,histogram,margin
from extended import Components
from search import GRAPH,APP,LAYOUT,MAIN,FRAMES,WORD,LAYOUT_SHA,lagrangian,relative,symplectic,matrix_rank

HERE=Path(__file__).resolve().parent
NODES=(542,1249,1292)
TRIALS={'near':'0.003879929046155','plus5e6':'0.003884928046155'}
BASE={'near':['0.211243929926514344381566367581254905069893951','0.211243929926514344381566367581254905069893952'],
      'plus5e6':['-4.880391089954707282632121322599412665463258252','-4.880391089954707282632121322599412665463258251']}
PRIMARY={
 'near':['nodes 542 1249 1292 contacts 32 paid 45 helper 14 coupled_ranks_crosschecked 3133452','unary_rejected 3 3 6',
 'relaxed_total 1067462648 grid_positive 0 grid_zero 0','strict_total 1054972738 grid_positive 0 grid_zero 0',
 'relaxed_best score -5943174352457 indices 126 446 3 axes 448 224 1052 grades 5 2 7',
 'strict_best score -13970296795033 indices 0 12 2 axes 11 7 1026 grades 3 2 5'],
 'plus5e6':['nodes 542 1249 1292 contacts 32 paid 45 helper 14 coupled_ranks_crosschecked 3133452','unary_rejected 3 3 6',
 'relaxed_total 1067462648 grid_positive 0 grid_zero 0','strict_total 1054972738 grid_positive 0 grid_zero 0',
 'relaxed_best score -5943100853836 indices 126 446 3 axes 448 224 1052 grades 5 2 7',
 'strict_best score -13970258079048 indices 0 12 2 axes 11 7 1026 grades 3 2 5']}
INDEPENDENT={
 'near':['direct_rref_neighbor_counts 1022 1022 1022 unary_eligible 1019 1019 1016','relaxed 1067462648 -5943174352457 strict 1054972738 -13970296795033'],
 'plus5e6':['direct_rref_neighbor_counts 1022 1022 1022 unary_eligible 1019 1019 1016','relaxed 1067462648 -5943100853836 strict 1054972738 -13970258079048']}

def source_graph():
 assert authenticate()==4
 assert WORD=='7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
 assert LAYOUT_SHA=='f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7'
 assert APP['caller']=='156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858'
 assert GRAPH['frames']==LAYOUT['frames'] and len(MAIN)==400
 C=Components();nodes=sorted(C.group);idx={a:i for i,a in enumerate(nodes)};edges=[]
 assert len(nodes)==1362 and len(C.fixed)==333 and len(FRAMES)==1103
 for i in range(len(FRAMES)):
  basis=lagrangian(i);assert matrix_rank(basis)==9 and all(symplectic(a,b)==0 for a in basis for b in basis)
 for a in nodes:
  for b,(paid,helper) in C.inc[a].items():
   if a<b:
    rank=relative(lagrangian(C.chart[a]),lagrangian(C.chart[b]))
    assert rank==abs(len(FRAMES[C.chart[a]])-len(FRAMES[C.chart[b]]))
    edges.append((idx[a],idx[b],len(paid),len(helper),rank))
 assert len(edges)==4179 and len(C.paid)==sum(e[2] for e in edges)==5707 and len(C.helper)==sum(e[3] for e in edges)==889
 for kind,k in [('paid',2),('targets',3)]:
  native=Counter()
  for e in edges:native[e[4]]+=48*e[k]
  full=histogram(APP['application']['invoice'][kind]);assert all(full[r]>=n for r,n in native.items())
 out=StringIO();print(len(FRAMES),len(nodes),len(edges),file=out)
 for frame in range(len(FRAMES)):print(*lagrangian(frame),file=out)
 for a in nodes:print(a,C.chart[a],int(a in C.fixed),file=out)
 for edge in edges:print(*edge,file=out)
 data=out.getvalue().encode();assert sha256(data).hexdigest()=='54f0f83bc687da2ca782c8dc43570bea44ab8ffa3934adf7ba0503bc03ef9103'
 return C,data

def check_scalar_schedule(C):
 n=len(GRAPH['initial']);first=GRAPH['first_output'];order=GRAPH['schedule'];at={x:i for i,x in enumerate(order)}
 moves={i:(a,b) for i,a,b in GRAPH['moves']};forms={i:{k:F(v) for k,v in row} for i,row in GRAPH['forms']}
 assert n==len(GRAPH['final'])==1289 and len(at)==len(order)==len(forms)==6996 and len(moves)==5707
 assert all(len(dict(row))==len(row) for _,row in GRAPH['forms'])
 source={i:a for i,(a,b) in moves.items()}|{first+i:c for i,c in enumerate(GRAPH['final'])}
 deposits={~i:c for i,c in enumerate(GRAPH['initial'])}|{i:b for i,(a,b) in moves.items()}
 assert set(source)==set(forms)==set(at)
 terms=num_bits=den_bits=0
 for i in order:
  goal=('send',i) if i in moves else ('exit',i-first)
  for k,q in forms[i].items():
   assert q and k in deposits and deposits[k]==source[i] and (k<0 or at[k]<at[i])
   donor=('src',~k) if k<0 else ('recv',k);assert C.cls(goal)==C.cls(donor)
   num_bits=max(num_bits,abs(q.numerator).bit_length());den_bits=max(den_bits,q.denominator.bit_length());terms+=1
 assert (terms,num_bits,den_bits)==(220217,37,31)
 assert [(i,at[i]) for i in (98632,99627,98744,102950,first+1249)]==[(98632,3094),(99627,2687),(98744,4132),(102950,3424),(first+1249,6956)]
 assert [forms[98632].get(-1250,F(0)),forms[99627].get(-1250,F(0)),forms[98744].get(98632,F(0)),forms[102950].get(99627,F(0)),forms[first+1249].get(98744,F(0)),forms[first+1249].get(102950,F(0))]==[-1,0,1,1,0,1]

def check_cycles(C):
 m=set(C.group)-C.fixed;adj={a:set(C.inc[a])&m for a in m};assert len(m)==1029 and sum(map(len,adj.values()))//2==2248
 tri=set()
 for a,nb in adj.items():
  for b,c in combinations(nb,2):
   if c in adj[b]:tri.add(tuple(sorted((a,b,c))))
 assert len(tri)==77
 helper_v={a for a in m if any(g[1] for g in C.inc[a].values())};assert len(helper_v)==90
 helper_tri=[t for t in sorted(tri) if any(C.inc[a][b][1] for a,b in combinations(t,2))]
 assert helper_tri==[(542,1249,1292),(1249,1292,1473),(1249,1292,1477),(1249,1292,2040),(1249,1292,3510),(1249,1292,7418)]
 assert sum(all(a in helper_v for a in t) for t in helper_tri)==3
 paid_arcs={(a,b) for _,a,b in C.paid if a in m and b in m};helper_arcs={(a,b) for _,a,b in C.helper if a in m and b in m};arcs=paid_arcs|helper_arcs
 assert (len(paid_arcs),len(helper_arcs),len(arcs))==(2259,18,2260)
 direct={a:set() for a in m}
 for a,b in arcs:direct[a].add(b)
 reach=[]
 for a,b in sorted(helper_arcs):
  todo=deque([b]);seen={b}
  while todo:
   for x in direct[todo.popleft()]-seen:seen.add(x);todo.append(x)
  assert a not in seen
  reach.append({'source':a,'destination':b,'reachable_from_destination':len(seen),'source_reachable':False})
 expected=json.loads((HERE/'GRAPH-CROSSCHECK.json').read_bytes())
 assert expected['orientation']['helper_arc_reachability']==reach and expected['orientation']['helper_arcs_on_any_directed_cycle']==0
 directed_tri=[t for t in tri if all(x in arcs for x in ((t[0],t[1]),(t[1],t[2]),(t[2],t[0]))) or all(x in arcs for x in ((t[0],t[2]),(t[2],t[1]),(t[1],t[0])))]
 assert len(directed_tri)==3 and not set(directed_tri)&set(helper_tri)
 affected={tuple(sorted((a,b))) for a in NODES for b in C.inc[a]}
 assert len(affected)==32 and sum(len(C.inc[a][b][0]) for a,b in affected)==45 and sum(len(C.inc[a][b][1]) for a,b in affected)==14
 return affected

def trial_tariffs():
 saved=json.loads((HERE/'TARIFFS.json').read_bytes());out={};bases={};scale=10**12
 p=histogram(APP['application']['invoice']['paid']);h=histogram(APP['application']['invoice']['targets'])
 for name,k in TRIALS.items():
  w=[0]
  for rank in range(1,10):
   lo,hi=margin(Counter(),Counter({rank:1}),k);x=(lo*scale).numerator//(lo*scale).denominator
   assert x<=lo*scale<=hi*scale<x+1;w.append(x)
  assert w==saved[name]['tariffs'];base=margin(p,h,k);assert enclose(base)==BASE[name]
  out[name]=(' '.join(map(str,w))+'\n').encode();bases[name]=base
 return out,bases

def check_witnesses(C,edges,bases):
 data=json.loads((HERE/'WITNESS.json').read_bytes())
 for name,k in TRIALS.items():
  for kind,axes,zero_p in [('relaxed',(448,224,1052),10),('strict',(11,7,1026),0)]:
   x=data[name+'_'+kind];changes={}
   assert x['axes']==list(axes) and x['grid_max_per_call']==int(PRIMARY[name][4 if kind=='relaxed' else 5].split()[2])
   for a,v in zip(NODES,axes,strict=True):
    old=lagrangian(C.chart[a]);new=tuple(z^(v if symplectic(z,v) else 0) for z in old)
    assert relative(old,new)==1;changes[a]=new
   pd=Counter();hd=Counter();zp=zh=0
   for a,b in edges:
    old=relative(lagrangian(C.chart[a]),lagrangian(C.chart[b]));new=relative(changes.get(a,lagrangian(C.chart[a])),changes.get(b,lagrangian(C.chart[b])))
    for items,counts in zip(C.inc[a][b],(pd,hd),strict=True):
     counts[old]-=48*len(items)
     if new:counts[new]+=48*len(items)
    if not new:zp+=len(C.inc[a][b][0]);zh+=len(C.inc[a][b][1])
   assert (zp,zh)==(zero_p,0)==(x['zero_paid'],x['zero_helper'])
   assert {str(a):b for a,b in sorted(pd.items())}==x['paid_histogram_delta_48']
   assert {str(a):b for a,b in sorted(hd.items())}==x['helper_histogram_delta_48']
   gain=margin(pd,hd,k);assert enclose(gain)==x['witness_exact_gain']
   upper=F((x['grid_max_per_call']+59)*48,10**12);assert upper==F(x['universal_48_call_gain_upper_exact']) and gain[1]<=upper
   assert enclose((bases[name][1]+upper,bases[name][1]+upper))[1]==x['universal_complete_margin_upper']

def check_result_manifest():
 result=json.loads((HERE/'RESULT.json').read_bytes());witness=json.loads((HERE/'WITNESS.json').read_bytes())
 assert result['schema']=='p104-helper-interaction-cycle/v1'
 assert (result['relaxed_choices'],result['positive_grade_choices'])==(1067462648,1054972738)
 assert result['graph']['directed_cycles_containing_mutable_helper_arc']==0
 for name,k in TRIALS.items():
  x=result['trials'][name];w=witness[name+'_relaxed'];strict=witness[name+'_strict']
  assert x['kappa']==k and x['baseline_margin_48']==BASE[name][1]
  assert F(x['relaxed_gain_upper_48'])==F(w['universal_48_call_gain_upper_exact'])
  assert F(x['strict_gain_upper_48'])==F(strict['universal_48_call_gain_upper_exact'])
  assert x['relaxed_complete_margin_upper']==w['universal_complete_margin_upper']
 assert not result['positive_candidate_constructed'] and not result['new_kappa_claim']

def main():
 check_result_manifest()
 C,geometry=source_graph();print('PASS authenticated inputs, source-derived geometry and all original grades',flush=True)
 check_scalar_schedule(C);edges=check_cycles(C);print('PASS 220217 scalar reads, cycle census and 18 directed helper-arc reachability tests',flush=True)
 weights,bases=trial_tariffs();check_witnesses(C,edges,bases);print('PASS directed tariffs, complete baselines and exact witness histograms',flush=True)
 with tempfile.TemporaryDirectory(prefix='helper-cycle-') as tmp:
  root=Path(tmp);(root/'geometry').write_bytes(geometry)
  a=root/'cycle';b=root/'independent'
  subprocess.run(['c++','-std=c++20','-O3',str(HERE/'cycle.cpp'),'-o',str(a)],check=True)
  subprocess.run(['c++','-std=c++20','-O3',str(HERE/'independent.cpp'),'-o',str(b)],check=True)
  for name in TRIALS:
   tariff=root/(name+'.tariff');tariff.write_bytes(weights[name])
   def run(exe):return subprocess.run([str(exe),str(root/'geometry'),str(tariff)],text=True,stdout=subprocess.PIPE,check=True).stdout.splitlines()
   assert run(a)==PRIMARY[name]
   assert run(b)==INDEPENDENT[name]
   print('PASS',name,'1022^3 complete relaxed triples and 1054972738 positive-grade triples',flush=True)
 print('PASS complete 48-call gain upper bounds: near -285.272368915104; plus5e6 -285.268840981296')

if __name__=='__main__':main()
