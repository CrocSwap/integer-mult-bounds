# A helper-interaction triangle price exclusion

Every simultaneous one-neighbor chart change on occurrence components `542`, `1249`, and `1292` makes the complete 48-call rational signed margin negative at both trial points below. This remains true in an enlarged model that permits zero-grade paid or helper contacts, charges every affected paid and productive incidence, and grants free physical chart materialization. The result is a bounded computational price screen; it does not give a new κ, construct a changed physical word, or establish a universal supplier or decoder wall.

| Trial κ | Original complete rational margin | Upper bound on 48-call gain, all `1022³` relaxed triples | Upper bound on resulting complete rational margin |
| --- | ---: | ---: | ---: |
| `0.003879929046155` | `+0.211243929926514344381566367581…` | `−285.272368915104` | `−285.061124985177485655618433632418…` |
| `0.003884928046155` | `−4.880391089954707282632121322599…` | `−285.268840981296` | `−290.149232071250707282632121322599…` |

The first point is the pinned binary signed upper plus `10⁻⁹`; the second is that upper plus `0.000005`. The family contains exactly **1,067,462,648** triples. Requiring every affected paid and productive grade to remain positive leaves **1,054,972,738** triples, whose gain bounds are `−670.574246158752` and `−670.572387791472` respectively. The incumbent binary budget remains a separate constraint. Complete numerical enclosures, histograms, affected incidences and witnesses are in [WITNESS.json](WITNESS.json); [RESULT.json](RESULT.json) summarizes the scope.

## Graph, chronology, and the meaning of cycle

Join occurrence tokens whenever a nonzero original scalar row reads a donor at the same chart. Anchor each component containing an original main-port endpoint, and aggregate all contacts between the same two components while retaining their multiplicities. This induced **undirected** graph has 1,029 mutable components, 2,248 simple contacts, and 77 simple triangles. Six triangles contain a productive-helper contact; they all share `1249–1292`. Three of those six have all vertices incident to a productive-helper identity. The selected triangle is `542–1249–1292`, and all six are disjoint from the earlier screened path `4922–8754–5626`. Two parallel paid contacts on the same pair are billed separately but do not form a simple three-component cycle.

The chosen triangle has two paid occurrences at original rank 3 on `542–1249`, two paid occurrences at rank 2 on `542–1292`, and one helper identity at rank 5 on `1249–1292`. Its entire incident boundary consists of 32 contact pairs, 45 paid occurrences and 14 productive-helper identities, including all contacts to unmoved or anchored components. [AUDIT.json](AUDIT.json) identifies the actual slots and roles.

The interaction cycle is **not** a directed feedback claim. If paid edges are oriented send→receive and helper edges input→terminal, the mutable graph has 2,260 distinct directed arcs. A complete reachability search finds no return path for any of the 18 mutable helper arcs, so no directed cycle of any length contains such an arc within that induced graph. Three directed triangles exist, none using a helper edge. Paths through anchored components are outside that orientation statement. The full counts and reachability receipts are in [GRAPH-CROSSCHECK.json](GRAPH-CROSSCHECK.json).

All original scalar rows and their order are retained in the price relaxation. The source audit checks all 220,217 nonzero local reads for matching original chart, co-location and earlier availability unless initially present. The largest original numerator and denominator have 37 and 31 bits, respectively. Selected paid slots have schedule positions `98632:3094`, `99627:2687`, `98744:4132`, and `102950:3424`; helper output 1249 is at position 6956. The audit also records direct zero and nonzero coefficients for the named rows. These checks preserve abstract scalar bookkeeping and do not prove that changed physical charts can actually be compiled.

## Reproduce

With Python 3.11+ and a C++20 compiler named `c++`, run from this directory:

```sh
python3 -B verify.py
```

The verifier authenticates the compressed word, layout, application and retained Clifford implementation using SHA-256 and Git blob IDs. It derives the complete component graph from the source, checks all 1,103 frame bases for nine-dimensional isotropy and all old contact grades, verifies scalar chronology and orientation reachability, derives directed tariff weights and complete baseline margins, and independently recalculates both exact witnesses. It compiles both C++ programs into a temporary directory and runs both full-triangle enumerators at both trial values. No network, prebuilt executable, external checkout, or workstation-specific path is required. A clean local run took about 20 seconds of one-core CPU and 156 MiB peak RSS; timings vary by machine.

## Price method

Each original 9-dimensional Lagrangian has 511 distinct 8-dimensional hyperplanes, each with two alternate Lagrangian extensions. Therefore it has 1,022 one-step neighbors. The primary program enumerates canonical transvection axes and cross-checks every one of its 3,133,452 coupled pair ranks against direct 18-row elimination. The second enumerates all `2^18` axes, reduces and deduplicates the resulting bases in RREF, checks each retained space is one step away, computes ranks independently from binary pairing matrices, and reproduces both full-triangle maxima and the positive-grade count. These are distinct code checks, not independent human review or a Lean proof.

For a contact with `p` paid occurrences and `h` productive occurrences, the signed change is `(h−p)(H(new)−H(old))`, with `H(r)=r^(1−κ)` and the optimistic convention `H(0)=0`. Both programs include all three joint edges and every exterior term. Each weight is an independently directed floor of `10¹²H(r)`. The old-to-new flooring error is less than one grid unit for each of the 59 affected paid-plus-helper occurrences. Adding 59 units per native call to the largest grid score, then multiplying by 48, yields the displayed conservative upper bounds. Unchanged caller and other application terms remain in the full baseline. A maximum in the integer grid need not be the exact real-valued maximum; the stated error covers that distinction.

The relaxed maximum uses axes `(448,224,1052)` and gives internal grades `(5,2,7)`; ten paid incidences have rank zero. The strict maximum uses axes `(11,7,1026)` and internal grades `(3,2,5)`. Their independently directed prices are listed in [WITNESS.json](WITNESS.json).

## Provenance and limits

The rational word and complete application are retained by #7830 at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The canonical word hash is `7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48`; the layout hash is `f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7`; the unchanged caller hash is `156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858`. The source-derived graph hash is `54f0f83bc687da2ca782c8dc43570bea44ab8ffa3934adf7ba0503bc03ef9103`. [SOURCE-LOCK.json](SOURCE-LOCK.json) gives the exact source commits, paths, byte hashes and Git blob IDs. #7852 head `41beda1d6435760dc99e38bd7e65f36798aad212` and main `e54523517d0f03e58352e647c403a5af3e525a57` are context pins, not premises of the price computation.

The screen fixes all scalar rows, incidence, chronology, other charts, 48-call caller, and service accounting, and replaces **all three** named charts with exactly one-step abstract Lagrangian neighbors. It does not cover other triangles, longer cycles, unchanged or one/two-node choices, multi-step edits, different scalar rows, source/target rerouting, changed service budgets, or other caller architectures. Any promising alternative would still need physical compilation, exact forward and adjoint all-column replay, and the complete finite application checks. The inherited `native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery` premises remain unproved here. No frontier selection is implied.

Credit the #7786/#7781 rational source, Ali Romman's #7776 carrier, tariff and caller, #7774 restored chain, the #7830 double contraction, and the predecessor fixed-incidence graph/neighbor work by Clear1nsight with OpenAI Codex assistance. This cycle extension and the computational cross-checks were performed with Codex assistance and are not independent human review. See [NOTICE.md](NOTICE.md).
