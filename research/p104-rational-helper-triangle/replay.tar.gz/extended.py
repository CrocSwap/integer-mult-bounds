"""Search actual occurrence co-location components without changing scalar rows."""
from search import *

class Components:
    def __init__(self):
        self.classes={}
        self.chart=[]
        self.tokens=[]
        self.owners={}
        for i,a in enumerate(GRAPH['initial']):
            self.add(('src',i),a)
        for slot,a,b in PAID:
            self.add(('send',slot),a)
            self.add(('recv',slot),b)
        for i,a in enumerate(GRAPH['final']):
            self.add(('exit',i),a)
        moves = {slot:(a,b) for slot,a,b in PAID}
        terminal = GRAPH['first_output']
        for slot,values in GRAPH['forms']:
            goal = ('send',slot) if slot in moves else ('exit',slot-terminal)
            target = self.owners[goal]
            for donor,_ in values:
                other=('src',~donor) if donor < 0 else ('recv',donor)
                self.union(target,self.owners[other])
        roots={self.root(i) for i in range(len(self.chart))}
        self.group=defaultdict(list)
        for i in range(len(self.chart)):
            self.group[self.root(i)].append(self.tokens[i])
        self.paid=[(slot,self.cls(('send',slot)),self.cls(('recv',slot))) for slot,_,_ in PAID]
        self.helper=[(r,self.cls(('src',r)),self.cls(('exit',r))) for r,_,_ in HELPERS]
        self.fixed={self.cls((typ,r)) for r in MAIN for typ in ('src','exit')}
        self.inc=defaultdict(lambda:defaultdict(lambda:[[],[]]))
        for kind,j in ((self.paid,0),(self.helper,1)):
            for label,a,b in kind:
                assert a!=b
                self.inc[a][b][j].append((label,self.chart[a],self.chart[b],a,b))
                self.inc[b][a][j].append((label,self.chart[a],self.chart[b],a,b))

    def add(self,token,a):
        key=len(self.chart)
        self.owners[token]=key
        self.classes[key]=key
        self.chart.append(a)
        self.tokens.append(token)

    def root(self,a):
        if self.classes[a] != a:
            self.classes[a]=self.root(self.classes[a])
        return self.classes[a]

    def union(self,a,b):
        a,b=self.root(a),self.root(b)
        assert self.chart[a]==self.chart[b]
        if a!=b:
            self.classes[max(a,b)]=min(a,b)

    def cls(self,token):
        return self.root(self.owners[token])

def price(comp, changes):
    affected={(a,b) for a in changes for b in comp.inc[a]}
    paid=Counter()
    target=Counter()
    records=[[],[]]
    visited=set()
    assert not (comp.fixed & changes.keys())
    for a,b in sorted(affected):
        if (b,a) in visited:continue
        visited.add((a,b))
        old=old_grade(comp.chart[a],comp.chart[b])
        new=relative(changes.get(a,lagrangian(comp.chart[a])),changes.get(b,lagrangian(comp.chart[b])))
        assert new > 0 or not comp.inc[a][b][1]
        if old==new: continue
        for group,deltas,rows in zip(comp.inc[a][b],(paid,target),records,strict=True):
            if new:deltas[new]+=48*len(group)
            deltas[old]-=48*len(group)
            rows.extend([list(item)+[old,new] for item in group])
    return {'gain':enclose(margin(paid,target,TARGET)),'paid_delta':dict(paid),'target_delta':dict(target),
            'paid':records[0],'helpers':records[1]}

def scan(components, allow_ordinary=True):
    top=[]
    positive=Counter()
    best={}
    for i in sorted(components.inc.keys()-components.fixed):
        c=components.chart[i]
        slots=[(old_grade(c,components.chart[b]),g,cross(lagrangian(c),lagrangian(components.chart[b])),
                        linear_combos(cross(conjugate_axes(c),lagrangian(components.chart[b]))))
                        for b,g in components.inc[i].items()]
        highest=None
        for v in range(1,1<<N):
            pivot=(v & -v).bit_length()-1
            sums=[0.,0.]
            valid=[True,True]
            for old,groups,a,dual in slots:
                p=a[pivot]
                restricted=[a[j] ^ (p if v>>j&1 else 0) for j in range(N) if j != pivot]
                b=dual[v]
                for flag, extra in enumerate((p,0)):
                    if not valid[flag]: continue
                    rank=matrix_rank(restricted+[b^extra])
                    if not rank and (groups[1] or not allow_ordinary):
                        valid[flag]=False
                    else:
                        sums[flag]+=group_price(groups,rank,old)
            for flag in range(2):
                if valid[flag]:
                    gain=48*sums[flag]
                    cand=(gain,i,c,v,flag)
                    if gain>1e-10:positive[i]+=1
                    if highest is None or cand>highest:highest=cand
        if highest is not None:best[i]=highest
    return sorted(best.values(),reverse=True),positive

if __name__=='__main__':
    comp=Components()
    print('components',len(comp.group),'fixed',len(comp.fixed),'active',len(comp.inc),
          'active private',len(comp.inc.keys()-comp.fixed),
          'charts with split',sum(n>1 for n in Counter(comp.chart[i] for i in comp.group).values()),flush=True)
    print('helper-only',[(i,comp.chart[i],len(g),len(comp.group[i])) for i,g in comp.inc.items() if
          i not in comp.fixed and not any(len(G[0]) for G in g.values())],flush=True)
    for allow in [True,False]:
        best,pos=scan(comp,allow)
        print('positive',allow,len(pos),sum(pos.values()),'top',best[:25],process_time(),flush=True)
        details=[]
        for g,i,c,v,e in best[:30]:
            candidate=matrix_rows_for_replacement(c,(v,e))
            p=price(comp,{i:candidate})
            assert abs(float(p['gain'][0])-g) < 1e-8
            details.append({'component':i,'chart':c,'v':v,'extension':e,'labels':comp.group[i],**p})
        save_file('COMPONENT-ADJACENT'+('-ORDINARY' if allow else '')+'.json',
                  {'max_by_component':best,'positive_counts':pos,'detailed':details,
                   'active':len(comp.inc),'private':len(comp.inc.keys()-comp.fixed),
                   'anchored':len(comp.fixed)})
