"""Exact relative physical ranks on actual P104 Lagrangians and adjacent edits."""
from functools import cache
from collections import Counter
from time import process_time
from explore import *

ZERO = (0,) * N

@cache
def chart(i):
    return clifford.canonical_frame(N, tuple(FRAMES[i]))

@cache
def lagrangian(i):
    cols = chart(i).adjoint().tab
    return tuple(x | (z << N) for x, z, _ in cols[N:])

@cache
def conjugate_axes(i):
    cols = chart(i).adjoint().tab
    return tuple(x | (z << N) for x, z, _ in cols[:N])

def symplectic(a, b):
    return ((a & (b >> N)).bit_count() ^ (b & (a >> N)).bit_count()) & 1

def cross(left, right):
    return tuple(sum(symplectic(x, z) << j for j, z in enumerate(right)) for x in left)

def relative(left, right):
    return matrix_rank(cross(left, right))

@cache
def old_grade(a,b):
    return abs(len(FRAMES[a]) - len(FRAMES[b]))

def group_price(neighbor_groups, rank, baseline):
    paid, helper = list(map(len,neighbor_groups))
    return (helper-paid) * (POINT[rank]-POINT[baseline])

def linear_combos(rows):
    result = [0]
    for x in rows:
        result.extend([a^x for a in result])
    return result

def edit_charts(i):
    old = chart(i)
    for v in range(1, 1 << N):
        pivot = (v & -v).bit_length()-1
        gate = clifford.cgate(N,v)
        yield (v,0), old.then(gate)
        yield (v,1), old.then(clifford.diag(N, tuple((1 << pivot) if j == pivot else 0 for j in range(N)))).then(gate)

def matrix_rows_for_replacement(i, key):
    v, phase = key
    pivot = (v & -v).bit_length()-1
    z = lagrangian(i)
    x = conjugate_axes(i)
    old = [z[j] ^ (z[pivot] if v >> j & 1 else 0) for j in range(N) if j != pivot]
    new = z[pivot]
    for j, image in enumerate(x):
        if v >> j & 1:
            new ^= image
    if phase:
        new ^= z[pivot]
    return tuple(old+[new])

def price_edit(i, candidate, relative_fn=relative):
    changes = [[],[]]
    deltas = [Counter(), Counter()]
    mode = 0
    for b, groups in INC[i].items():
        new = relative_fn(candidate, lagrangian(b))
        old = old_grade(i, b)
        if not new and groups[1]:
            return None
        if old == new:
            continue
        if not new:
            mode += len(groups[0])
        for grp, changed, hist in zip(groups,changes,deltas,strict=True):
            changed.extend([list(item) + [old,new] for item in grp])
            hist[old] -= len(grp)*48
            if new:
                hist[new] += len(grp)*48
    return {'paid': changes[0], 'helpers': changes[1],
            'paid_delta': dict(deltas[0]), 'target_delta': dict(deltas[1]),
            'gain': enclose(margin(*deltas,TARGET)), 'grade_zero_paid': mode}

def scan_adjacent(allow_ordinary=False):
    top = []
    positive = Counter()
    best = {}
    for i in sorted(INC.keys()-FIXED):
        slots = [(old_grade(i,b), g, cross(lagrangian(i), lagrangian(b)),
                  linear_combos(cross(conjugate_axes(i),lagrangian(b)))) for b,g in INC[i].items()]
        highest = None
        for v in range(1,1 << N):
            pivot = (v & -v).bit_length()-1
            sums = [0.0,0.0]
            valid = [True,True]
            changed = [0,0]
            for old, groups, a, dual in slots:
                a_pivot = a[pivot]
                restricted = [a[j] ^ (a_pivot if v >> j & 1 else 0)
                              for j in range(N) if j != pivot]
                b = dual[v]
                for k, extra in enumerate((a_pivot, 0)):
                    if valid[k]:
                        rank = matrix_rank(restricted + [b ^ extra])
                        if rank == 0 and (groups[1] or not allow_ordinary):
                            valid[k] = False
                        else:
                            sums[k] += group_price(groups, rank, old)
                            changed[k] += rank != old
            for flag in range(2):
                gain = sums[flag]
                if valid[flag] and gain > 1e-10:
                    positive[i] += 1
                    cand = (gain * 48, i, v, flag, changed[flag])
                    if highest is None or cand > highest:
                        highest = cand
        if highest is not None:
            best[i] = highest
    top = sorted(best.values(), reverse=True)
    return top, positive

def save_file(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def run():
    for vals in PAID, HELPERS:
        for r,a,b in vals:
            assert relative(lagrangian(a),lagrangian(b)) == old_grade(a,b), (r,a,b)
    print('actual grades all verified', process_time(),flush=True)
    best, counts = scan_adjacent(allow_ordinary=False)
    print('adjacent positive charts',len(best),'positive edits',sum(counts.values()), 'best', best[:30],
          process_time(),flush=True)
    details=[]
    for approximate,i,v,e,changed in best[:30]:
        candidate = matrix_rows_for_replacement(i,(v,e))
        bill = price_edit(i,candidate)
        assert bill and abs(float(bill['gain'][0])-approximate) < 1e-8
        details.append({'chart':i,'native_axes':FRAMES[i], 'v':v,'extension':e,**bill})
    save_file('ADJACENT.json', {'max_by_chart': best, 'positive_counts':counts, 'detailed': details})

if __name__ == '__main__':
    run()
