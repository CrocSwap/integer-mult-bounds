# P104 paired-cut separation

This portable archive reproduces the strongest designated #7113 paired-cut
violation of the fixed 804-bank balanced-plane witness from
[#7857](https://github.com/CrocSwap/integer-mult-bounds/pull/7857) at head
`c55b7721e1a8ef438f7b932f07e4e05ab24897b9`, using P104 definitions from
[#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) at head
`41beda1d6435760dc99e38bd7e65f36798aad212`.

From this directory, run with Python 3:

```
python3 -B -S verify.py
```

The exact optimum is 50 deficit units in each direction. A 50-label
independent set attains it; 28 edges and four odd cycles certify that it
cannot be exceeded. An append-only repair of the fixed witness with fixed
fields would have D+R >= 128. A redesigned bank set, full banked-graph
realizability, `hJ`, `hV`, and κ are outside the result. [RESULT.md](RESULT.md)
gives the derivation and limitations; [RECEIPT.json](RECEIPT.json) records
expected outputs. [SOURCES.json](SOURCES.json) gives exact upstream paths,
commit pins, blob identities and SHA-256 digests. No network or third-party
libraries are needed to replay.

The original P104 material is by DreamingOfClouds with Claude Opus 5.5, as
set out in [NOTICE-P104.md](NOTICE-P104.md). The #7857 balanced-plane
construction was prepared by Clear1nsight with substantial OpenAI Codex
assistance. The separation, certificate, and analysis in this archive were
prepared with OpenAI Codex assistance. Included upstream source retains its
[Apache-2.0 license](LICENSE).
