#!/usr/bin/env python3
"""Check pinned public source bytes, replay exact certificate, check receipt."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = json.loads((ROOT / 'SOURCES.json').read_text())
receipt = json.loads((ROOT / 'RECEIPT.json').read_text())
for item in source['sources']:
    data = (ROOT / item['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert blob == item['git_blob_sha1'], item['path']
print('SOURCE BYTE CHECK:', len(source['sources']), 'SHA-256 and Git blob hashes match')

import separate
measured = separate.main()
for key, value in measured.items():
    assert receipt[key] == value, (key, receipt[key], value)
print('RECEIPT CHECK: all', len(measured), 'computed fields match')
