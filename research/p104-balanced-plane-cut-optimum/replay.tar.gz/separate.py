#!/usr/bin/env python3
"""Exact paired-cut separation for the #7857 balanced-plane witness.

Standard library only. The source files checked here are pinned copies, not
changes to the upstream package. See RESULT.md for scope and derivation.
"""
import collections
import functools
import hashlib
import itertools
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PINS = {
    'verify_balanced_planes.py': 'b30dba1af21f73cd4ee074e770793cf7b374b4d61336dfd3694b1afdbdd6adb9',
    'verify_chart_paths.py': '9a07f3e0afb8f9d4dff97183e7e0acdc1bbb885ae43d25ca9ef42c534f234872',
    'verify_relaxation.py': 'e9f6a489a1e9265943498ef6d55957a2cced0ffef2108f5cb12979d8fbc30600',
    'pinned/UniHSC7113.lean': '3d1af09c5cf76b8eacfdff51a7a8d86cdd4501fdcdbafb6b56979a501949a7db',
    'pinned/WordModelDefs.lean': '22d8779e82d053f81c6752c8b3e8e7cde5fe33e353c116ebbbfc9f7baa66656d',
}
for name, want in PINS.items():
    got = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    assert got == want, (name, got, want)

from verify_relaxation import BASE, H, cut_test, load_source, rank_data
from verify_chart_paths import line, plane, dim, hyperplane, sub
from verify_balanced_planes import match

# A checkable upper-bound certificate for the conflict graph. Each pair is
# an edge; each longer list is an odd cycle listed in cyclic order. Together
# they cover each port exactly once, bounding an independent set by 50.
CERT_EDGES = [
    [11,35],[19,505],[13,475],[21,37],[41,22],[73,191],[265,70],
    [49,74],[81,44],[273,164],[321,253],[38,88],[290,351],[28,375],
    [140,471],[84,148],[56,239],[152,280],[168,392],[304,336],
    [208,439],[494,463],[478,382],[501,487],[493,367],[445,319],
    [499,443],[251,247],
]
CERT_CYCLES = [
    [131,254,446,194,322,274,259,506,196,415,477,381,385],
    [69,50,98,133,388,134,386,379,14,508,193],
    [261,138,276,268,324,292,262,112,176,400,146],
    [145,100,223,328,296,352,224,416,26,431,200,502,161],
]


def independent_set(adjacency):
    """Exact maximum independent set with exhaustive, certified recurrences.

    Delete isolated vertex, use the safe leaf exchange rule, split components,
    otherwise branch on excluding/including a max-degree vertex. No bounds,
    floating-point tolerances or heuristic early exits are used.
    """
    n = len(adjacency)
    stats = collections.Counter()

    @functools.lru_cache(None)
    def solve(mask):
        stats['states'] += 1
        if not mask:
            return 0, 0
        vs = [i for i in range(n) if mask >> i & 1]
        for i in vs:
            neigh = adjacency[i] & mask
            if neigh == 0:
                stats['isolated'] += 1
                k, w = solve(mask & ~(1 << i))
                return k + 1, w | (1 << i)
            if neigh.bit_count() == 1:
                # Any solution containing its neighbor can exchange it for i.
                stats['leaf'] += 1
                k, w = solve(mask & ~(neigh | (1 << i)))
                return k + 1, w | (1 << i)
        # Split disconnected components before branching.
        reached = 1 << vs[0]
        frontier = reached
        while frontier:
            lsb = frontier & -frontier
            i = lsb.bit_length() - 1
            frontier ^= lsb
            nxt = adjacency[i] & mask & ~reached
            reached |= nxt
            frontier |= nxt
        if reached != mask:
            stats['split'] += 1
            k1, w1 = solve(reached)
            k2, w2 = solve(mask ^ reached)
            return k1 + k2, w1 | w2
        i = max(vs, key=lambda v: ((adjacency[v] & mask).bit_count(), -v))
        stats['branch'] += 1
        exclude = solve(mask & ~(1 << i))
        k, w = solve(mask & ~(adjacency[i] | (1 << i)))
        include = (k + 1, w | (1 << i))
        return max(exclude, include, key=lambda z: z[0])

    value, chosen = solve((1 << n) - 1)
    assert value == chosen.bit_count()
    assert all(not (adjacency[i] & chosen) for i in range(n) if chosen >> i & 1)
    return value, chosen, stats


def toy_controls():
    """Exhaust the local Boolean identities and all graphs with n <= 5."""
    for a, b, c in itertools.product(range(2), repeat=3):
        gap_out = (a and not b) + (b and not c) - (a and not c)
        gap_in = (not a and b) + (not b and c) - (not a and c)
        assert gap_out == gap_in == int(a == c and a != b)
    for w in (1, 2):
        for px in range(2):
            for py in itertools.product(range(2), repeat=w):
                x_cost, y_cost = w * (1 - px), sum(py)
                best = max(l * t - x_cost * l - y_cost * t
                           for l, t in itertools.product(range(2), repeat=2))
                assert best == int(x_cost == 0 and y_cost == 0)
    for n in range(1, 6):
        edges = list(itertools.combinations(range(n), 2))
        for graph in range(1 << len(edges)):
            adj = [0] * n
            for e, (a, b) in enumerate(edges):
                if graph >> e & 1:
                    adj[a] |= 1 << b
                    adj[b] |= 1 << a
            got, _, _ = independent_set(adj)
            best = max(s.bit_count() for s in range(1 << n)
                       if all(not (adj[i] & s) for i in range(n) if s >> i & 1))
            assert got == best, (n, graph, got, best)


def main():
    toy_controls()
    ports, non_d, flag = load_source(BASE)
    top = (1 << (1 << H)) - 1
    zero = 1
    xp = {q: plane(q, ports[(i + 1) % len(ports)]) for i, q in enumerate(ports)}
    yp, caps = match(ports, non_d, xp)
    b1, b2 = plane(flag[0], flag[8]), plane(flag[0], flag[8] ^ flag[1])
    assert len(set(xp.values())) == len(ports) == 104
    assert len(caps) == 104 and sum(caps.values()) == 200
    assert b1 != b2 and b1 not in caps and b2 not in caps
    assert all(p in caps and sub(p, hyperplane(q)) for q in ports for p in yp[q])
    assert all(xp[q] not in yp[q] for q in ports)
    paths = []
    for q in ports:
        for p in yp[q]:
            paths.extend([(line(q), xp[q], top), (zero, p, hyperplane(q))])
    assert len(paths) == 400
    assert all(sub(a, b) and sub(b, c) and dim(a) < dim(b) < dim(c)
               for a, b, c in paths)
    banks = [edge for a, b, c in paths for edge in ((a, b), (b, c))]
    banks.extend([(b1, top), (top, b1), (b2, top), (top, b2)])
    assert len(banks) == 804
    assert not cut_test(collections.Counter((dim(a), dim(b)) for a, b in banks))[0]
    assert sum(dim(a) - dim(b) for a, b in banks if dim(a) > dim(b)) == 14
    assert sum(dim(b) - dim(a) for a, b in banks if dim(a) < dim(b)) - 3200 == 14

    def measured(pred):
        bo = sum(a in pred and b not in pred for a, b in banks)
        bi = sum(a not in pred and b in pred for a, b in banks)
        fo = sum(a in pred and c not in pred for a, b, c in paths)
        fi = sum(a not in pred and c in pred for a, b, c in paths)
        inside_x = {q for q in ports if line(q) in pred and top in pred}
        outside_y = {q for q in ports if zero not in pred and hyperplane(q) not in pred}
        selected = inside_x & outside_y
        return bo, bi, fo, fi, selected

    def eligible_rows(pred):
        # UniHSC7113.rowL / rowP have paired endpoints of the same q:
        # low Y -> X and high X2 -> Y2 at D, X -> Y at non-D.
        out = sum(zero not in pred and hyperplane(q) not in pred
                  and line(q) in pred and top in pred for q in ports)
        inn = sum(line(q) in pred and top in pred
                  and zero not in pred and hyperplane(q) not in pred for q in ports)
        return out, inn

    q = 11
    assert ports[0] == q
    pred11 = {top, line(q), xp[q], b1, b2} | {hyperplane(r) for r in ports if r != q}
    assert all(p not in pred11 for p in yp[q])
    check11 = measured(pred11)
    assert check11[:4] == (0, 396, 0, 396) and check11[4] == {11}
    assert eligible_rows(pred11) == (1, 1)

    # Edge q--r iff selecting both forces r's x-plane simultaneously inside
    # and outside through one of q's y-paths.
    inv = {xp[q]: i for i, q in enumerate(ports)}
    adj = [0] * len(ports)
    for i, q in enumerate(ports):
        for p in yp[q]:
            j = inv[p]
            assert i != j
            adj[i] |= 1 << j
            adj[j] |= 1 << i
    assert all((adj[i] >> j & 1) == (adj[j] >> i & 1)
               for i in range(len(ports)) for j in range(len(ports)))
    idx = {q: i for i, q in enumerate(ports)}
    covered = [q for block in CERT_EDGES + CERT_CYCLES for q in block]
    assert len(covered) == len(set(covered)) == len(ports) and set(covered) == set(ports)
    assert all(adj[idx[a]] >> idx[b] & 1 for a, b in CERT_EDGES)
    for cycle in CERT_CYCLES:
        assert len(cycle) >= 3 and len(cycle) % 2 == 1
        assert all(adj[idx[a]] >> idx[b] & 1
                   for a, b in zip(cycle, cycle[1:] + cycle[:1]))
    certified_upper = len(CERT_EDGES) + sum(len(c) // 2 for c in CERT_CYCLES)
    assert certified_upper == 50
    alpha, witness, stats = independent_set(adj)
    assert alpha == certified_upper
    chosen = [q for i, q in enumerate(ports) if witness >> i & 1]
    chosen_set = set(chosen)
    # All arbitrary chart sides are specified: inside exactly this finite set.
    pred = {top, b1, b2} | {line(q) for q in chosen} | {xp[q] for q in chosen}
    pred |= {hyperplane(q) for q in ports if q not in chosen_set}
    result = measured(pred)
    assert result[4] == chosen_set
    assert result[0] - result[2] == 0 and result[1] - result[3] == 0
    assert result[2] == 0
    assert result[:4] == (0, 214, 0, 214) and alpha == 50
    assert eligible_rows(pred) == (50, 50)
    assert sum(1 + (i not in non_d) for i, q in enumerate(ports) if q in chosen_set) == 93
    remaining = len(ports) - len(chosen)
    min_d_remaining = max(0, 96 - len(chosen))
    minimum_field_in = 2 * (remaining + min_d_remaining)
    assert minimum_field_in == 200
    assert all(xp[q] in pred and all(p not in pred for p in yp[q]) for q in chosen)
    assert all(not (adj[i] & witness) for i in range(104) if witness >> i & 1)
    print('SOURCE PINS: PR #7852 41beda1d6435760dc99e38bd7e65f36798aad212; '
          'PR #7857 c55b7721e1a8ef438f7b932f07e4e05ab24897b9')
    print('REPRODUCED LABEL 11: (bank out,in; field out,in)', check11[:4], 'paired extras 1 each direction')
    print('WITNESS: paths',len(paths),'banks',len(banks),'D=14 R=14')
    print('CONFLICT GRAPH: vertices',len(ports),'edges',sum(x.bit_count() for x in adj)//2,
          'max degree',max(x.bit_count() for x in adj))
    print('UPPER CERTIFICATE: 28 edges and odd cycles of lengths',
          [len(c) for c in CERT_CYCLES], 'cover all 104 vertices; upper bound', certified_upper)
    print('EXACT OPTIMUM:',alpha,'paired-cut deficits each direction; MIS search stats',dict(stats))
    print('OPTIMAL PREDICATE: (bank out,in; field out,in)',result[:4], 'paired extras',alpha,'each direction')
    print('FULL-GRAPH NECESSARY BANKS (out,in): concrete split >= (50,264); arbitrary DCount=96 split >= (50,250)')
    print('APPEND-ONLY CONTROL: >=100 added nested banks and X>=128 with fixed witness fields')
    print('SELECTED PORT LABELS:',chosen)
    print('TOY CONTROLS: exhaustive path/predicate truth tables and MIS vs brute force on all graphs with <=5 vertices')
    print('SCOPE: fixed 804-bank relaxation witness; no full HSContract graph, output matrix, hJ, hV, legal word, or kappa conclusion')
    return {
        'bank_count': len(banks), 'field_count': len(paths), 'D': 14, 'R': 14,
        'conflict_vertices': len(ports),
        'conflict_edges': sum(x.bit_count() for x in adj) // 2,
        'maximum_paired_cut_deficit_each_direction': alpha,
        'certificate': {'disjoint_edges': len(CERT_EDGES),
                        'odd_cycle_lengths': [len(c) for c in CERT_CYCLES],
                        'witness_independent_set_size': len(chosen)},
        'label_11_control': {'bank_out': check11[0], 'bank_in': check11[1],
                             'field_out': check11[2], 'field_in': check11[3],
                             'extra_each_direction': 1},
        'maximizer': {'bank_out': result[0], 'bank_in': result[1],
                      'field_out': result[2], 'field_in': result[3],
                      'extra_each_direction': alpha},
        'required_full_graph_banks_concrete_D_split':
            {'out_at_least': result[2] + alpha, 'in_at_least': result[3] + alpha},
        'required_full_graph_banks_any_DCount_96_split':
            {'out_at_least': alpha, 'in_at_least': minimum_field_in + alpha},
        'fixed_fields_and_banks_append_only_repair':
            {'new_banks_at_least': 2 * alpha, 'D_plus_R_at_least': 28 + 2 * alpha},
    }

if __name__ == '__main__':
    main()
