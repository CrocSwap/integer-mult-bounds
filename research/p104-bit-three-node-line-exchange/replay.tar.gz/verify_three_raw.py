#!/usr/bin/env python3
"""Independent raw-incidence replay for every candidate in the three-site scan.

Build paths from all possible middle nodes, not anchor expansion; test quotient
ranks; price all 2874/458 primitive route/helper incidences before combining.
No grouped signed-edge calculation from the producer is used.
"""
from collections import Counter,defaultdict
from itertools import combinations,product
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'source'))
from common import baseline,RATES,check
from mincut import network,directed_weights
from timeline import timeline
b=baseline();w=b[0];nodes,charts,fixed,_,_=network(w);trace=timeline(w)
contact=trace['contacts'];rank=[w['frames'][str(c)]['dim'] for c in charts]
nb=[set() for _ in nodes];incident=defaultdict(set)
for z,c in enumerate(contact):
    i,j=c['i'],c['j'];nb[i].add(j);nb[j].add(i);incident[i].add(z);incident[j].add(z)
check(Counter(c['kind'] for c in contact)=={'paid':2874,'helper':458},'raw invoice census')
weights=[directed_weights(k) for k in RATES];states=tuple(product((0,1),repeat=2))
seedfile=json.loads((H/'SEEDS.json').read_text());seeds=seedfile['seed_roster']
check(len(seeds)==96,'seed count')
groups={}
for sid,s in enumerate(seeds):
    group=groups.setdefault(s['pattern_hex'],{'pattern_index':s['pattern_index'],'axis':s['axis'],'seed_ids':[],'anchors':set()})
    group['seed_ids'].append(sid);group['anchors'].update(s['pair'])

def raw_eval(x,changes):
    rows=sorted(set().union(*(incident[n] for n in changes)))
    score=Counter();bad=[];reversed_helpers=[];zero_helpers=[]
    for z in rows:
        c=contact[z];i,j=c['i'],c['j'];ui,vi=changes.get(i,(x[i],0));uj,vj=changes.get(j,(x[j],0))
        qi,qj=rank[i]-x[i],rank[j]-x[j]
        le=(ui<=uj and vi<=vj);ge=(ui>=uj and vi>=vj)
        if (qi<qj and not le) or (qi>qj and not ge) or (qi==qj and not (le or ge)):
            bad.append(z);continue
        new=abs((qi+ui+vi)-(qj+uj+vj))
        check(0<=new<=9,'rank bound')
        if c['kind']=='helper':
            if not (qi<=qj and le):reversed_helpers.append(c['id'])
            if new==0:zero_helpers.append(c['id'])
        sign=1 if c['kind']=='helper' else -1
        score[new]+=sign;score[c['old_grade']]-=sign
    return bad,{g:n for g,n in sorted(score.items()) if n},reversed_helpers,zero_helpers

# Every recovered seed is independently priced from primitive incidences.
for s in seeds:
    pat=bytes.fromhex(s['pattern_hex']);x=[pat[c] for c in charts]
    changes={n:tuple(a) for n,a in zip(s['pair'],s['states'])}
    bad,hist,_,_=raw_eval(x,changes)
    check(not bad and hist=={int(g):n for g,n in s['hist'].items()},'raw seed reconstruction')
    check(all(sum(v*(hi[g] if v>0 else lo[g]) for g,v in hist.items())<0 for lo,hi in weights),'raw seed strict negative')

saved={}
for line in (H/'COMPATIBLE.jsonl').read_text().splitlines():
    row=json.loads(line);key=(row['pattern_index'],tuple(row['triple']),tuple(map(tuple,row['states'])))
    check(key not in saved,'duplicate roster item');saved[key]=row
seen=set();stats=Counter();fail=[];strict_by_rate=[0,0];maxima=[None,None]
for hexpat,info in sorted(groups.items(),key=lambda item:item[1]['pattern_index']):
    pat=bytes.fromhex(hexpat);x=[pat[c] for c in charts]
    free={i for i in range(len(nodes)) if x[i]<2 and i not in fixed and all(x[j]<2 for j in nb[i])}
    triples=set();paths=0
    for middle in sorted(free):
        for p,q in combinations(sorted(nb[middle]&free),2):
            t=tuple(sorted((p,middle,q)))
            if set(t)&info['anchors']:paths+=1;triples.add(t)
    stats['patterns']+=1;stats['paths']+=paths;stats['triples']+=len(triples)
    for t in sorted(triples):
        for st in product(*(tuple(s for s in states if s!=(x[n],0)) for n in t)):
            stats['tested']+=1;bad,hist,reverse,zero=raw_eval(x,dict(zip(t,st)))
            if bad:continue
            stats['nested']+=1
            if reverse:stats['nested_with_reversed_helper']+=1
            if zero:stats['nested_with_zero_grade_helper']+=1
            low=[sum(v*(lo[g] if v>0 else hi[g]) for g,v in hist.items()) for lo,hi in weights]
            high=[sum(v*(hi[g] if v>0 else lo[g]) for g,v in hist.items()) for lo,hi in weights]
            for i in range(2):
                if low[i]>0:strict_by_rate[i]+=1
                maxima[i]=high[i] if maxima[i] is None else max(maxima[i],high[i])
            key=(info['pattern_index'],t,st);seen.add(key)
            row=saved.get(key)
            if row is None:fail.append(['missing',key]);continue
            if ({int(k):v for k,v in row['native_signed_coefficients'].items()}!=hist or
                row['native_lower_units']!=low or row['native_upper_units']!=high):
                fail.append(['price mismatch',key])
check(not fail and seen==set(saved),'all 648 tests and all 48 priced rows match')
scan=json.loads((H/'THREE-SCAN.json').read_text())
check(stats['tested']==scan['statistics']['tested'] and stats['nested']==scan['statistics']['nested'],'census')
check(maxima==[r['maximum_native_upper_units'] for r in scan['rate_results']],'maximum outward enclosures')
stats.setdefault('nested_with_reversed_helper',0)
stats.setdefault('nested_with_zero_grade_helper',0)
out={'status':'PASS_INDEPENDENT_RAW_INCIDENCE','raw_paid_incidences':2874,'raw_helper_incidences':458,
     'replayed_seed_count':len(seeds),'statistics':dict(stats),'maximum_native_upper_units':maxima,
     'strictly_positive_lower_case_counts':strict_by_rate,'mismatches':len(fail),
     'scope':'same fixed-boundary seed-derived three-node family; raw contact prices and separately enumerated paths'}
(H/'VERIFY-THREE-RAW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
