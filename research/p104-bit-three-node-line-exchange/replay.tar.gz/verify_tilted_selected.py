#!/usr/bin/env python3
"""Extend path scan to fresh-only changes of old-line nonreducing charts.

A nonreducing old projector cannot be modified by adding or subtracting the old
line while remaining an orthogonal projector. It may retain its old part and
add E. For all additional seed-touching paths this script finds an unchanged
boundary that rules out every allowed changed state, using exact rational
projector multiplication and retaining explicit nonzero residual entries.
"""
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'source'))
from common import baseline,check
from mincut import network
from timeline import timeline
from exchange import axes,projector,matplus,matmul,mtrace,vector_mult
w=baseline()[0];nodes,charts,fixed,_,_=network(w);raw=timeline(w)['contacts'];nb=[set() for _ in nodes]
for c in raw:nb[c['i']].add(c['j']);nb[c['j']].add(c['i'])
seeds=json.loads((H/'SEEDS.json').read_text())['seed_roster'];groups={}
for seed in seeds:
 g=groups.setdefault(seed['pattern_hex'],{'pattern_index':seed['pattern_index'],'axis':seed['axis'],'anchors':set()})
 g['anchors'].update(seed['pair'])

def diff(a,b):
 for i in range(9):
  for j in range(9):
   if a[i][j]!=b[i][j]:return [i,j,str(a[i][j]-b[i][j])]
 return None

stats=Counter();path_roster=[];certs=[]
for hp,info in sorted(groups.items(),key=lambda q:q[1]['pattern_index']):
 pat=bytes.fromhex(hp);x=[pat[c] for c in charts];free=set(range(len(nodes)))-fixed
 paths=defaultdict(list)
 for mid in sorted(free):
  for a,c in combinations(sorted(nb[mid]&free),2):
   t=tuple(sorted((a,mid,c)))
   if set(t)&info['anchors'] and any(x[n]==2 for n in t):paths[t].append([a,mid,c])
 r,L,_,E=axes(info['axis']);idx=info['pattern_index']
 @lru_cache(None)
 def old(i):return projector(w['frames'][str(charts[i])])
 @lru_cache(None)
 def cert(kind,i,j):
  a,q=old(i),old(j);oldprod=matmul(a,q);check(oldprod==a,'old selected subspace contained in fixed exterior')
  if kind=='orthogonal_selected':
   check(x[i]==0 and x[j]==2 and not any(vector_mult(a,r)),'orthogonal selected and tilted exterior')
   states=[([u,v],matplus(matplus(a,L,u),E,v)) for u,v in ((0,1),(1,0),(1,1))]
  else:
   check(kind=='tilted_selected' and x[i]==2 and mtrace(q)>mtrace(a),'tilted selected below exterior')
   ar=vector_mult(a,r);check(any(ar) and ar!=r,'selected old projector truly nonreducing')
   states=[(['keep_old',1],matplus(a,E))]
  witnesses=[]
  for st,p in states:
   check(matmul(p,p)==p,'proposed state is an exact projector')
   pq=matmul(p,q);dp,dq=diff(pq,p),diff(pq,q)
   check(dp is not None and dq is not None,'fixed boundary is nonnested in both directions')
   witnesses.append({'state':st,'PQ_minus_P_nonzero':dp,'PQ_minus_Q_nonzero':dq})
  certs.append({'pattern_index':idx,'kind':kind,'selected':i,'exterior':j,
                'selected_chart':charts[i],'exterior_chart':charts[j],
                'selected_rank':int(mtrace(a)),'exterior_rank':int(mtrace(q)),
                'witnesses':witnesses});return len(certs)-1
 for t,pl in sorted(paths.items()):
  outer={i:nb[i]-set(t) for i in t};blocked=[]
  for i in t:
   if x[i]==0:
    blocked += [('orthogonal_selected',i,j) for j in outer[i] if x[j]==2]
   if x[i]==2:
    blocked += [('tilted_selected',i,j) for j in outer[i]
                if w['frames'][str(charts[j])]['dim']>w['frames'][str(charts[i])]['dim']]
  check(blocked,'every new triple has a fixed-boundary obstruction')
  kind,i,j=sorted(blocked)[0];index=cert(kind,i,j)
  n=1
  for i in t:n*=1 if x[i]==2 else 3
  stats['extra_triples']+=1;stats['extra_paths']+=len(pl);stats['extra_assignments']+=n
  path_roster.append({'pattern_index':idx,'triple':t,'paths':pl,'candidate_assignments':n,'blocking_certificate':index})
 print('pattern',idx,'extra triples',len(paths),'certificates',cert.cache_info().currsize,flush=True)
check(stats['extra_triples']==340 and stats['extra_assignments']==3060,'expanded fresh-only census')
base=json.loads((H/'ALL-PATHS.json').read_text())
check(base['status']=='PASS_ALL_PATHS_COVERED','base screen completed')
out={'status':'PASS_TILTED_SELECTED_EXTRA_PATHS','statistics':dict(stats),'unique_boundary_certificates':len(certs),
     'combined_paths':base['statistics']['paths']+stats['extra_paths'],
     'combined_triples':base['statistics']['unique_triples']+stats['extra_triples'],
     'combined_assignments':base['statistics']['candidate_assignments']+stats['extra_assignments'],
     'combined_compatible':base['compatible_placements'],
     'scope':'add a selected chart with old line neither contained nor orthogonal, retaining its old projector and adding the fresh line; all other assumptions of ALL-PATHS.json',
     'boundary_certificates':certs,'path_roster':path_roster}
(H/'TILTED-SELECTED.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('RESULT',json.dumps({k:v for k,v in out.items() if k not in ('boundary_certificates','path_roster')},indent=2,sort_keys=True))
