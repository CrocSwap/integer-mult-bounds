#!/usr/bin/env python3
"""Full primitive bill and exact projector details for the largest 3-site row."""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'source'))
from common import baseline,RATES,ZERO,plus,scale,power,moment,minus,display,check
from mincut import network
from timeline import timeline
from exchange import axes,projector,matplus,matmul,mtrace,vector_mult
base=baseline();w=base[0];nodes,charts,fixed,_,_=network(w);t=timeline(w)
saved=json.loads((H/'THREE-SCAN.json').read_text());row=saved['rate_results'][0]['witness'];triple=row['triple']
seeds=json.loads((H/'SEEDS.json').read_text())['seed_roster'];seed=next(s for s in seeds if s['pattern_index']==row['pattern_index'])
p=bytes.fromhex(seed['pattern_hex']);x=[p[c] for c in charts];r,L,_,E=axes(seed['axis'])
changes={n:tuple(z) for n,z in zip(triple,row['states'])}
@lru_cache(None)
def mat(i):
    old=projector(w['frames'][str(charts[i])]);check(x[i]<2 and vector_mult(old,r)==tuple(x[i]*v for v in r),'reduced line')
    u,v=changes.get(i,(x[i],0));return matplus(matplus(old,L,u-x[i]),E,v)
paid=Counter({int(k):v for k,v in base[5].items()});target=Counter({int(k):v for k,v in base[6].items()})
dp=Counter();dh=Counter();incident=[];zero=[];orientation=[]
for c in t['contacts']:
    if c['i'] not in changes and c['j'] not in changes:continue
    i,j=c['i'],c['j'];a,q=mat(i),mat(j);prod=matmul(a,q);check(prod==a or prod==q,'all contacts nested')
    new=int(abs(mtrace(a)-mtrace(q)));kind=c['kind'];old=c['old_grade']
    if kind=='helper':orientation.append(prod==a and new>0)
    if new==0:zero.append({'kind':kind,'id':c['id']})
    if new!=old:
        ctr=dp if kind=='paid' else dh;ctr[old]-=1;ctr[new]+=1
        incident.append({**c,'new_grade':new})
for g,n in dp.items():paid[g]+=36*n
for g,n in dh.items():target[g]+=36*n
signed=Counter(dh)
for g,n in dp.items():signed[g]-=n
hist={str(g):n for g,n in sorted(signed.items()) if n};check(hist==row['native_signed_coefficients'],'witness signed histogram')
results={}
for k in RATES:
    d=ZERO
    for g,n in signed.items():d=plus(d,scale(power(g,k),36*n))
    b0=moment(base[5],base[6],k);direct=moment(paid,target,k);from_delta=plus(b0,d)
    check(direct[0]<=from_delta[1] and from_delta[0]<=direct[1],'direct complete invoice overlap')
    results[str(k)]={'complete_36_call_delta':display(d),'recomputed_complete_bit_margin':display(direct),
                     'unchanged_rational_margin':display(moment(base[7]['signed']['paid'],base[7]['signed']['productive'],k))}
result={'axis':seed['axis'],'triple':triple,'states':row['states'],
        'nodes':[{'component':i,'root':nodes[i],'chart':charts[i],'old_bit':x[i],
                  'old_rank':w['frames'][str(charts[i])]['dim']} for i in triple],
        'strict_seed_ids':row['strict_seed_extensions'],
        'changed_primitive_contacts':incident,'zero_grade_incident_contacts':zero,
        'all_helper_contacts_forward_and_positive':all(orientation),
        'native_paid_delta':{str(g):n for g,n in sorted(dp.items()) if n},
        'native_helper_delta':{str(g):n for g,n in sorted(dh.items()) if n},
        'native_signed_coefficients':hist,'complete_paid_histogram':{str(g):n for g,n in sorted(paid.items()) if n},
        'complete_target_histogram':{str(g):n for g,n in sorted(target.items()) if n},
        'rates':results,'literal_construction':False}
(H/'WITNESS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
