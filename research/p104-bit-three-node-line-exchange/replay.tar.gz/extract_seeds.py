#!/usr/bin/env python3
"""Recover the 96 R4 nontie witnesses and verify the entire saved digest.

This is an extraction control, because R4's saved scan has only a digest, not
its 96 rows. Do not run absent the lead's authorization.
"""
from collections import Counter
from hashlib import sha256
from itertools import product
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
from common import baseline,RATES,check
from mincut import network,patterns,directed_weights,SCALE
w,*_=baseline(); nodes,charts,fixed,nb,edges=network(w)
ranks=[w['frames'][str(c)]['dim'] for c in charts]
weights=[directed_weights(k) for k in RATES]
states=tuple(product((0,1),repeat=2)); seen=set(); stats=Counter(); digest=sha256(); seeds=[]
for num,(axis,pat) in enumerate(patterns(w['frames'])):
    if num==0 or pat in seen: continue
    seen.add(pat);stats['unique_patterns']+=1
    x=[pat[c] for c in charts]
    free={i for i,z in enumerate(x) if z!=2 and i not in fixed and all(x[j]!=2 for j in nb[i])}
    pairs=sorted((i,j) for i in free for j in nb[i] if i<j and j in free)
    if pairs:stats['patterns_with_pairs']+=1
    for i,j in pairs:
        stats['pairs']+=1
        adj=[(a,b,*edges[tuple(sorted((a,b)))]) for a in (i,j) for b in nb[a] if b not in (i,j) or a<b]
        for ai,aj in product(states,repeat=2):
            stats['assignments']+=1
            pos={i:ai,j:aj};hist=Counter();good=True
            for a,b,m,g in adj:
                xa,xb=x[a],x[b];u=pos.get(a,(xa,0));v=pos.get(b,(xb,0))
                d=g-abs(xa-xb)
                if ranks[a]>ranks[b]:u,v=v,u
                if d:
                    if u[0]>v[0] or u[1]>v[1]:good=False;break
                elif not ((u[0]<=v[0] and u[1]<=v[1]) or (v[0]<=u[0] and v[1]<=u[1])):
                    good=False;break
                new=d+abs(u[0]-v[0])+abs(u[1]-v[1]);check(0<=new<=9,'new rank')
                if m and new!=g:hist[g]+=m;hist[new]-=m
            if not good:continue
            stats['nested']+=1
            hist={g:c for g,c in sorted(hist.items()) if c}
            if not hist:stats['exact_ties']+=1
            lows=[sum(c*(lo[g] if c>0 else hi[g]) for g,c in hist.items()) for lo,hi in weights]
            highs=[sum(c*(hi[g] if c>0 else lo[g]) for g,c in hist.items()) for lo,hi in weights]
            row=[num,axis,i,j,ai,aj,hist,lows,highs]
            digest.update(json.dumps(row,separators=(',',':'),sort_keys=True).encode()+b'\n')
            if hist:
                check(all(z<0 for z in highs),'seed must be strictly negative at both rates')
                seeds.append(dict(pattern_index=num,axis=axis,pattern_hex=pat.hex(),pair=[i,j],states=[ai,aj],hist=hist,
                                  lower_units=lows,upper_units=highs,
                                  materially_changed=[ai!=(x[i],0),aj!=(x[j],0)]))
parent=json.loads((HERE/'PARENT-SCAN.json').read_text())
check(dict(stats)==parent['statistics'],'parent census')
check(digest.hexdigest()==parent['digest_of_tested_nested_states'],'complete parent nested-state digest')
check(len(seeds)==96,'96 nontie seeds')
out={'source_parent_digest':digest.hexdigest(),'seed_count':len(seeds),'seed_roster':seeds,
     'distinct_patterns':len({r['pattern_hex'] for r in seeds}),
     'both_seed_nodes_materially_changed':sum(all(r['materially_changed']) for r in seeds),
     'scale':SCALE,'rates':[str(k) for k in RATES]}
(HERE/'SEEDS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='seed_roster'},indent=2))
