#!/usr/bin/env python3
"""Re-run the bounded input control and all independent screens deterministically."""
from hashlib import sha256
from pathlib import Path
from time import monotonic
import json,subprocess,sys
H=Path(__file__).resolve().parent
tracked=['SEEDS.json','ESTIMATE.json','COMPATIBLE.jsonl','THREE-SCAN.json',
         'VERIFY-THREE-RAW.json','VERIFY-PROJECTORS.json','ALL-PATHS.json',
         'TILTED-SELECTED.json','VERIFY-COVERAGE.json','WITNESS.json']
def digest(p):return sha256((H/p).read_bytes()).hexdigest()
before={p:digest(p) for p in tracked}
steps=[(['sha256sum','-c','PARENT-SHA256SUMS'],H),(['sha256sum','-c','SHA256SUMS'],H/'source')]
steps += [([sys.executable,'-B',p],H) for p in ['extract_seeds.py','scan_three.py','verify_three_raw.py','verify_projectors.py','verify_all_paths.py','verify_tilted_selected.py','verify_coverage.py','witness.py']]
results=[]
for cmd,cwd in steps:
 t=monotonic();r=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=45)
 results.append({'command':cmd[0] if len(cmd)<3 else cmd[-1],'exit_code':r.returncode,'seconds':round(monotonic()-t,3)})
 print(results[-1],flush=True)
 if r.returncode:
  print(r.stdout);print(r.stderr,file=sys.stderr);raise SystemExit(r.returncode)
after={p:digest(p) for p in tracked}
if before!=after:
 print('CHANGED',[p for p in tracked if before[p]!=after[p]]);raise SystemExit(1)
out={'status':'PASS_COLD_DETERMINISTIC_REPLAY','runs':results,'artifact_hashes':after}
(H/'COLD-REPLAY.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
