#!/usr/bin/env python3
"""Direct 9x9 rational-projector verification of all 648 placements.

All boundary contacts, including rejected placements, are tested by exact
matrix multiplication. This does not rely on quotient-rank nestedness formulas.
"""
from collections import Counter
from functools import lru_cache
from itertools import product
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'source'))
from common import baseline,check
from mincut import network
from timeline import timeline
from exchange import axes,projector,matplus,matmul,mtrace,vector_mult,transpose
from scope import groups,paths_from_anchors,available
base=baseline();word=base[0];nodes,charts,fixed,nb,_=network(word);raw=timeline(word)['contacts']
seeds=json.loads((H/'SEEDS.json').read_text())['seed_roster']
saved={}
for ln in (H/'COMPATIBLE.jsonl').read_text().splitlines():
    a=json.loads(ln);saved[(a['pattern_index'],tuple(a['triple']),tuple(map(tuple,a['states'])))]=a
states=tuple(product((0,1),repeat=2));counts=Counter();seen=set();results=[]
for hexpat,info in groups(seeds):
    pat=bytes.fromhex(hexpat);x,free=available(pat,charts,fixed,nb)
    paths=paths_from_anchors(nb,free,info['anchors']);r,l,e,ep=axes(info['axis'])
    @lru_cache(None)
    def old(n):
        p=projector(word['frames'][str(charts[n])]);check(x[n] in (0,1),'line reduces each tested chart')
        check(vector_mult(p,r)==tuple(x[n]*v for v in r),'rational old-line occupancy')
        return p
    @lru_cache(None)
    def place(n,s):
        p=matplus(matplus(old(n),l,s[0]-x[n]),ep,s[1])
        check(p==transpose(p) and matmul(p,p)==p,'exact rational state is a projector')
        return p
    @lru_cache(None)
    def edge(i,j,si,sj):
        p,q=place(i,si),place(j,sj);pq=matmul(p,q)
        ok=pq==p or pq==q
        return ok, int(abs(mtrace(p)-mtrace(q))) if ok else None
    for triple in paths:
        sub=set(triple);contacts=[c for c in raw if c['i'] in sub or c['j'] in sub]
        unique=sorted({tuple(sorted((c['i'],c['j']))) for c in contacts})
        for st in product(*(tuple(s for s in states if s!=(x[n],0)) for n in triple)):
            counts['tested']+=1;pos=dict(zip(triple,st));grades={};bad=False
            for i,j in unique:
                ok,g=edge(i,j,pos.get(i,(x[i],0)),pos.get(j,(x[j],0)))
                if not ok:bad=True
                grades[i,j]=g
            if bad:continue
            counts['nested']+=1;hist=Counter()
            for c in contacts:
                g=grades[tuple(sorted((c['i'],c['j'])))];sign=1 if c['kind']=='helper' else -1
                hist[g]+=sign;hist[c['old_grade']]-=sign
            h={str(g):n for g,n in sorted(hist.items()) if n}
            key=(info['pattern_index'],triple,st);seen.add(key)
            check(key in saved and h==saved[key]['native_signed_coefficients'],'exact matrix result and raw price match')
    counts['distinct_projector_placements']+=place.cache_info().currsize
    counts['distinct_contact_placement_tests']+=edge.cache_info().currsize
    results.append({'pattern':info['pattern_index'],'projectors':place.cache_info().currsize,
                    'exact_contact_tests':edge.cache_info().currsize})
check(seen==set(saved),'every producer accepted row directly verified, none omitted')
scan=json.loads((H/'THREE-SCAN.json').read_text())
check(counts['tested']==scan['statistics']['tested'] and counts['nested']==scan['statistics']['nested'],'complete exact projector census')
out={'status':'PASS_EXACT_RATIONAL_PROJECTORS','statistics':dict(counts),'per_pattern':results,
     'method':'for every tested placement multiply both 9x9 projectors on every incident edge; accepted contact iff PQ=P or PQ=Q',
     'physical_word_compiled':False}
(H/'VERIFY-PROJECTORS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
