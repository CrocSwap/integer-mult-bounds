#!/usr/bin/env python3
"""Fixed-exterior three-node old/fresh placements, seeded by R4 nonties.

Each unique triple has at least one length-two path touching any node from a
96-case R4 seed at that line. All three nodes must differ from their original
old/fresh placement. Every incident paid/helper contact must remain nested.
All compatible placements are saved; no physical compilation is asserted.
"""
from collections import Counter
from hashlib import sha256
from itertools import product
from pathlib import Path
import argparse,json,sys
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'source'))
from common import baseline,RATES,check,moment,display,ZERO,plus,scale,power
from mincut import network,directed_weights,SCALE
from scope import groups,paths_from_anchors,available
p=argparse.ArgumentParser();p.add_argument('--estimate',action='store_true');a=p.parse_args()
seedfile=json.loads((H/'SEEDS.json').read_text()); seeds=seedfile['seed_roster']
check(seedfile['seed_count']==96 and len(seeds)==96,'96 R4 seeds')
base=baseline();w=base[0];nodes,charts,fixed,nb,edges=network(w)
ranks=[w['frames'][str(c)]['dim'] for c in charts]
weights=[directed_weights(k) for k in RATES]; states=tuple(product((0,1),repeat=2))
stats=Counter();records=[]; scope=[]
for hexpat,info in groups(seeds):
    pat=bytes.fromhex(hexpat);x,free=available(pat,charts,fixed,nb)
    paths=paths_from_anchors(nb,free,info['anchors'])
    stats['seed_line_patterns']+=1;stats['eligible_unique_triples']+=len(paths)
    stats['eligible_paths']+=sum(len(v) for v in paths.values())
    stats['candidate_assignments']+=27*len(paths)
    scope.append({'pattern_index':info['pattern_index'],'axis':info['axis'],
                  'seed_ids':info['seed_ids'],'anchors':sorted(info['anchors']),
                  'triples':len(paths),'paths':sum(len(v) for v in paths.values())})
    records.append((hexpat,info,x,paths))
est={'source_parent_digest':seedfile['source_parent_digest'],'statistics':dict(stats),
     'patterns':scope,'maximum_assignments':27*stats['eligible_unique_triples'],
     'scope':'unique triples with an eligible length-two path touching any seed endpoint; all three nodes materially changed'}
(H/'ESTIMATE.json').write_text(json.dumps(est,indent=2,sort_keys=True)+'\n')
print('ESTIMATE',json.dumps(est['statistics'],sort_keys=True),flush=True)
if a.estimate:raise SystemExit(0)
roster=H/'COMPATIBLE.jsonl'; digest=sha256(); best=[None for _ in RATES];
counts=Counter();lower_positive=[0 for _ in RATES];withseed=0
with roster.open('w') as out:
 for hexpat,info,x,paths in records:
    for triple,pathlist in paths.items():
        subset=set(triple)
        contacts=sorted((i,j,*edges[(i,j)]) for i,j in edges if i in subset or j in subset)
        seed_ids=[sid for sid in info['seed_ids'] if set(seeds[sid]['pair'])<=subset]
        for assignment in product(*(tuple(s for s in states if s!=(x[n],0)) for n in triple)):
            counts['tested']+=1; pos=dict(zip(triple,assignment));hist=Counter();ok=True
            for i,j,m,g in contacts:
                ui=pos.get(i,(x[i],0));uj=pos.get(j,(x[j],0));d=g-abs(x[i]-x[j])
                if ranks[i]>ranks[j]:ui,uj=uj,ui
                le=ui[0]<=uj[0] and ui[1]<=uj[1]
                ge=ui[0]>=uj[0] and ui[1]>=uj[1]
                if (d>0 and not le) or (d==0 and not (le or ge)):ok=False;break
                new=d+abs(ui[0]-uj[0])+abs(ui[1]-uj[1])
                check(0<=new<=9,'grade bound')
                if new!=g:hist[g]+=m;hist[new]-=m
            if not ok:continue
            counts['nested']+=1
            hist={g:v for g,v in sorted(hist.items()) if v}
            if not hist:counts['exact_ties']+=1
            lows=[sum(c*(lo[g] if c>0 else hi[g]) for g,c in hist.items()) for lo,hi in weights]
            highs=[sum(c*(hi[g] if c>0 else lo[g]) for g,c in hist.items()) for lo,hi in weights]
            strict=[sid for sid in seed_ids if all(seeds[sid]['materially_changed']) and
                    all(tuple(seeds[sid]['states'][k])==pos[node] for k,node in enumerate(seeds[sid]['pair']))]
            if strict:counts['strict_seed_extensions']+=1
            if seed_ids:counts['seed_pair_in_triple']+=1
            row={'pattern_index':info['pattern_index'],'triple':triple,'states':assignment,
                 'native_signed_coefficients':hist,'native_lower_units':lows,'native_upper_units':highs,
                 'strict_seed_extensions':strict}
            b=(json.dumps(row,sort_keys=True,separators=(',',':'))+'\n').encode()
            digest.update(b);out.write(b.decode())
            for i in range(len(RATES)):
                if lows[i]>0:lower_positive[i]+=1
                if best[i] is None or highs[i]>best[i]['native_upper_units'][i]:best[i]=row
    print('pattern',info['pattern_index'],'triples',len(paths),'tested',counts['tested'],'nested',counts['nested'],flush=True)
check(counts['tested']==est['maximum_assignments'],'complete candidate assignments')
full=[]
for z,k in enumerate(RATES):
    row=best[z]
    if row is None: full.append(None);continue
    delta=ZERO
    for g,c in row['native_signed_coefficients'].items():delta=plus(delta,scale(power(g,k),36*c))
    baseline_m=moment(base[5],base[6],k); changed=plus(baseline_m,delta)
    full.append({'rate':str(k),'maximum_native_upper_units':row['native_upper_units'][z],
                 'witness':row,'witness_complete_36_call_delta':display(delta),
                 'witness_complete_36_call_bit_margin':display(changed),
                 'unchanged_rational_margin':display(moment(base[7]['signed']['paid'],base[7]['signed']['productive'],k)),
                 'strictly_positive_native_lower_cases':lower_positive[z]})
result={'source_pins':{'7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','7910':'7880a7a0af4cf405991c60f26811fee926398406'},
        'source_parent_digest':seedfile['source_parent_digest'],'scope':est['scope'],
        'completed':True,'scale':SCALE,'statistics':{**dict(stats),**dict(counts)},
        'rate_results':full,'compatible_roster_sha256':digest.hexdigest(),
        'limitations':'fixed exterior; original packet and helper incidence; grade-zero contacts treated free; no literal atlas replay'}
(H/'THREE-SCAN.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('RESULT',json.dumps(result,indent=2,sort_keys=True),flush=True)
