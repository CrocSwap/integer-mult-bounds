#!/usr/bin/env python3
"""Independently audit all saved path/certificate references and residuals."""
from collections import defaultdict
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'source'))
from common import baseline,check
from mincut import network
from timeline import timeline
from exchange import axes,projector,matplus,matmul,vector_mult
w=baseline()[0];nodes,charts,fixed,_,_=network(w);contacts=timeline(w)['contacts'];nb=[set() for _ in nodes]
for c in contacts:nb[c['i']].add(c['j']);nb[c['j']].add(c['i'])
seeds=json.loads((H/'SEEDS.json').read_text())['seed_roster'];groups={}
for s in seeds:
 g=groups.setdefault(s['pattern_index'],{'pattern':bytes.fromhex(s['pattern_hex']),'axis':s['axis'],'anchors':set()})
 g['anchors'].update(s['pair'])
base=json.loads((H/'ALL-PATHS.json').read_text());extra=json.loads((H/'TILTED-SELECTED.json').read_text())
@lru_cache(None)
def old(node):return projector(w['frames'][str(charts[node])])
@lru_cache(None)
def audit_cert(which,idx):
 doc=base if which=='base' else extra;c=doc['boundary_certificates'][idx]
 g=groups[c['pattern_index']];p=g['pattern'];x=[p[z] for z in charts];i,j=c['selected'],c['exterior']
 a,q=old(i),old(j);r,L,_,E=axes(g['axis']);check(matmul(a,q)==a,'cert original containment')
 check(c['selected_chart']==charts[i] and c['exterior_chart']==charts[j],'cert chart IDs')
 kind=c.get('kind','orthogonal_selected')
 if kind=='orthogonal_selected':
  check(x[i]==0 and x[j]==2 and not any(vector_mult(a,r)),'orthogonal versus tilted certificate')
  states=[([u,v],matplus(matplus(a,L,u),E,v)) for u,v in ((0,1),(1,0),(1,1))]
 else:
  check(kind=='tilted_selected' and x[i]==2,'tilted selected certificate')
  ar=vector_mult(a,r);check(any(ar) and ar!=r,'selected chart tilted')
  states=[(['keep_old',1],matplus(a,E))]
 check(len(c['witnesses'])==len(states),'certificate covers every state')
 for witness,(st,p) in zip(c['witnesses'],states):
  check(witness['state']==st and matmul(p,p)==p,'listed exact state projector')
  pq=matmul(p,q)
  for key,ref in [('PQ_minus_P_nonzero',p),('PQ_minus_Q_nonzero',q)]:
   row,col,value=witness[key];dv=pq[row][col]-ref[row][col]
   check(dv and str(dv)==value,'saved nonzero rational residual')
 return c
expected={}
for idx,g in groups.items():
 free=set(range(len(nodes)))-fixed
 for a in sorted(g['anchors']&free):
  for b,c in combinations(sorted(nb[a]&free),2):
   t=tuple(sorted((b,a,c)));expected.setdefault((idx,t),set()).add((b,a,c))
  for mid in sorted(nb[a]&free):
   for z in sorted((nb[mid]&free)-{a}):
    b,c=sorted((a,z));t=tuple(sorted((a,mid,z)));expected.setdefault((idx,t),set()).add((b,mid,c))
found={};unblocked=0
for which,doc in [('base',base),('extra',extra)]:
 for row in doc['path_roster']:
  idx=row['pattern_index'];t=tuple(row['triple']);key=(idx,t);check(key not in found,'unique path triple')
  g=groups[idx];x=[g['pattern'][c] for c in charts]
  check((any(x[i]==2 for i in t))==(which=='extra'),'correct line-reduction partition')
  found[key]=set(map(tuple,row['paths']))
  ci=row['blocking_certificate']
  if ci is None:
   check(which=='base' and all(x[j]<2 for i in t for j in nb[i]),'unblocked only in direct matrix set');unblocked+=1;continue
  cert=audit_cert(which,ci)
  check(cert['pattern_index']==idx and cert['selected'] in t and cert['exterior'] not in t and
        cert['exterior'] in nb[cert['selected']],'certificate is fixed incident boundary for this triple')
check(found==expected,'all distinct seed-touching paths and triples exhaustively match raw graph')
check(len(found)==982 and unblocked==24,'scope counts')
check(audit_cert.cache_info().currsize==len(base['boundary_certificates'])+len(extra['boundary_certificates']),'every saved certificate is used and checked')
out={'status':'PASS_INDEPENDENT_COVERAGE_AND_RESIDUAL_AUDIT','seed_patterns':len(groups),
     'raw_incidence_contacts':len(contacts),'paths':sum(map(len,expected.values())),
     'triples':len(found),'unblocked_triples':unblocked,
     'all_saved_boundary_certificates_checked':audit_cert.cache_info().currsize,
     'methods':'independent raw-graph anchor path enumeration, validate every saved rational residual and certificate-to-triple reference'}
(H/'VERIFY-COVERAGE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True))
