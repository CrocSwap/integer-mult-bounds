#!/usr/bin/env python3
"""Close the non-reducing-exterior gap in the 3-node seed-derived scope.

For each additional path, record an exterior chart at which all three changed
states fail exact 9x9 rational projector nestedness. The exterior has old-line
class 2, so it can never be a selected old/fresh component. This eliminates the
whole triple independently of the other two states.
"""
from collections import Counter,defaultdict
from functools import lru_cache
from itertools import combinations,product
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'source'))
from common import baseline,check
from mincut import network
from timeline import timeline
from exchange import axes,projector,matplus,matmul,mtrace,vector_mult
b=baseline();w=b[0];nodes,charts,fixed,_,_=network(w);raw=timeline(w)['contacts']
nb=[set() for _ in nodes]
for c in raw:nb[c['i']].add(c['j']);nb[c['j']].add(c['i'])
seeds=json.loads((H/'SEEDS.json').read_text())['seed_roster'];groups={}
for sid,s in enumerate(seeds):
    g=groups.setdefault(s['pattern_hex'],{'pattern_index':s['pattern_index'],'axis':s['axis'],'anchors':set()})
    g['anchors'].update(s['pair'])

def first_diff(a,b):
    for i in range(9):
        for j in range(9):
            if a[i][j]!=b[i][j]:return [i,j,str(a[i][j]-b[i][j])]
    return None

stats=Counter();roster=[];certs=[]
for hp,info in sorted(groups.items(),key=lambda x:x[1]['pattern_index']):
    p=bytes.fromhex(hp);x=[p[c] for c in charts]
    free={i for i in range(len(nodes)) if i not in fixed and x[i]<2}
    # Enumerate paths independently by their middle rather than via anchors.
    paths=defaultdict(list)
    for mid in sorted(free):
        for a,c in combinations(sorted(nb[mid]&free),2):
            t=tuple(sorted((a,mid,c)))
            if set(t)&info['anchors']:paths[t].append([a,mid,c])
    r,L,_,E=axes(info['axis']);index=info['pattern_index']
    @lru_cache(None)
    def old(i):return projector(w['frames'][str(charts[i])])
    @lru_cache(None)
    def certificate(i,j):
        check(x[i]==0 and x[j]==2 and j in nb[i] and j not in free,'eligible selected node with tilted exterior')
        a,q=old(i),old(j); ar=vector_mult(a,r);qr=vector_mult(q,r)
        check(not any(ar) and any(qr) and qr!=r,'old line exterior class checked exactly')
        aq=matmul(a,q);check(aq==a,'selected old chart is properly contained in tilted exterior')
        witnesses=[]
        for u,v in ((0,1),(1,0),(1,1)):
            new=matplus(matplus(a,L,u),E,v);prod=matmul(new,q)
            diffp=first_diff(prod,new);diffq=first_diff(prod,q)
            check(diffp is not None and diffq is not None,'changed projector fails both inclusion directions')
            witnesses.append({'state':[u,v],'PQ_minus_P_nonzero':diffp,'PQ_minus_Q_nonzero':diffq})
        cert={'pattern_index':index,'selected':i,'exterior':j,'selected_chart':charts[i],
              'exterior_chart':charts[j],'selected_rank':int(mtrace(a)),'exterior_rank':int(mtrace(q)),
              'witnesses':witnesses}
        certs.append(cert);return len(certs)-1
    for triple,pl in sorted(paths.items()):
        stats['unique_triples']+=1;stats['paths']+=len(pl);stats['candidate_assignments']+=27
        blocked=sorted((i,j) for i in triple for j in nb[i] if x[i]==0 and x[j]==2)
        if blocked:
            i,j=blocked[0];c=certificate(i,j);stats['universally_blocked_triples']+=1
            entry={'pattern_index':index,'triple':triple,'paths':pl,'blocking_certificate':c}
        else:
            check(all(all(x[j]<2 for j in nb[i]) for i in triple),'no uncertified non-reducing boundary')
            stats['full_matrix_enumerated_triples']+=1
            entry={'pattern_index':index,'triple':triple,'paths':pl,'blocking_certificate':None}
        roster.append(entry)
    print('pattern',index,'paths',sum(map(len,paths.values())),'triples',len(paths),
          'certificates',certificate.cache_info().currsize,flush=True)
scan=json.loads((H/'THREE-SCAN.json').read_text())
check(stats['candidate_assignments']==17334 and stats['unique_triples']==642,'complete path scope')
check(stats['full_matrix_enumerated_triples']==scan['statistics']['eligible_unique_triples']==24,'all remaining triples are enumerated')
check(stats['universally_blocked_triples']*27+scan['statistics']['tested']==stats['candidate_assignments'],'exhaustive 3-state partition')
proj=json.loads((H/'VERIFY-PROJECTORS.json').read_text())
check(proj['statistics']['tested']==648 and proj['statistics']['nested']==48,'direct projectors on survivors')
result={'source_pins':scan['source_pins'],'statistics':dict(stats),'unique_boundary_certificates':len(certs),
        'status':'PASS_ALL_PATHS_COVERED','scope':'all distinct length-two paths on three unfrozen line-reducing nodes touching any R4 nontie seed component at that representative line; every node materially changed; all exterior projectors fixed',
        'exclusion_method':'618 triples each have an unchanged tilted exterior contact failing both inclusion directions for every changed state of one selected node, verified using exact rational projectors',
        'nonblocked_method':'all 648 states of the remaining 24 triples checked by direct exact rational projectors and independently priced from raw paid/helper incidence',
        'compatible_placements':scan['statistics']['nested'],'compatible_roster_sha256':scan['compatible_roster_sha256'],
        'boundary_certificates':certs,'path_roster':roster}
(H/'ALL-PATHS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('RESULT',json.dumps({k:v for k,v in result.items() if k not in ('boundary_certificates','path_roster')},indent=2,sort_keys=True))
