# Prove whole-word BIT scalar cuts and least-price island repairs

130 exact chart cuts exclude 2,872 of the 2,873 original nonbridge deletions with the other incidences and endpoints held fixed, despite arbitrary recoding and clocks. The certificates also cover 49 named changed topologies. Packet 3410 is the one deletion outside the exclusion.

With exterior inputs fixed, the outside outputs factor through the ordered outgoing transcript. In the 48 island subfamily the relaxed capacity is 679. Buying the cheapest residual augmenting path is the exact minimum extra grade price for capacity 680. The repair shapes are one grade four in 45 cases and one grade five in three. Even granting arbitrarily many added legal nested scalar contacts, the best complete 36-call BIT margin upper bound at 0.00388 is below −71.8343339161046255.

Change prior surviving incidences, endpoints, productive bins or caller. An independent operator remains necessary for packet 3410. The grade-4 chart-388 topology outside the 48 is covered only by the static cut.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. Both extracted manifests and Python 3.12 standard-library verify.py replays passed, including the independent integral flows, duals, 50,520 directed nested contacts, both tariff rates, both original operators and corrupt controls.
