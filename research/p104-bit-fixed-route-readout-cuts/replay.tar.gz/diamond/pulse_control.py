#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Two scalar pulses for the fixed-clock chart 0/2/5/125 routing screen."""
import gzip,hashlib,json,os
from pathlib import Path
if hasattr(os,'sched_getaffinity') and hasattr(os,'sched_setaffinity'):
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
p=Path(__file__).resolve().parent / 'inputs/BIT-WORD.json.gz'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(p.read_bytes())); prog=w['program']; n=w['public']
assert n==680 and prog[2]==['MOVE',680,0,2] and prog[11]==['ADD',683,680,2]
assert prog[61]==['MOVE',697,0,5] and prog[70]==['ADD',700,697,5]

def in_span(target,vs):
    # In these two pulse runs, values range over only F2^2.
    s={0}
    for v in vs:s |= {x^v for x in tuple(s)}
    return target in s

def test(a,b,swapped):
    values=[0]*(n+w['owned_fields']);values[222]=1;values[229]=2
    tags=w['start'][:]+[None]*w['owned_fields']; observations={}
    for t in range(71):
        op,r,*args=prog[t]
        if t in (11,70):
            chart=2 if t==11 else 5
            want=1 if t==11 else 2
            available={i:values[i] for i,tag in enumerate(tags) if tag==chart}
            observations[str(t)]={'desired_two_pulse_signature':want,
                                  'stock_two_pulse_signatures':sorted(set(available.values())),
                                  'source_role_present':tags[680 if t==11 else 697]==chart,
                                  'any_local_xor_recovers_signature':in_span(want,available.values())}
            if swapped and t==11: break
        if op=='INIT':
            assert tags[r] is None; tags[r]=args[0];values[r]=0
        elif op=='ADD':
            peer,chart=args;assert tags[r]==tags[peer]==chart
            values[r]^=values[peer]
        elif op=='MOVE':
            src,dst=args;assert tags[r]==src
            if t==2: values[r]=a;dst=5 if swapped else 2
            elif t==61: values[r]=b;dst=2 if swapped else 5
            tags[r]=dst
        elif op=='SWAP':
            peer=args[0];values[r],values[peer]=values[peer],values[r];tags[r],tags[peer]=tags[peer],tags[r]
        elif op=='CLEAR':
            assert tags[r]==args[0];tags[r]=None;values[r]=0
        else: raise ValueError(op)
    return observations

cases=[]
for a in (1,2,3):
 for b in (1,2,3):
  if a==b:continue
  same=test(a,b,False);cross=test(a,b,True)
  assert not cross['11']['any_local_xor_recovers_signature']
  cases.append({'basis':[a,b],'same_destinations':same,'swapped_destinations':cross})
assert len(cases)==6
assert [r['basis'] for r in cases if all(r['same_destinations'][c]['any_local_xor_recovers_signature'] for c in ('11','70'))]==[[1,2]]
assert test(1,2,False)['11']['any_local_xor_recovers_signature']
print(json.dumps({'pulse_input_coordinates':[222,229], 'unchanged_control':'identity recovers both readers',
                  'swapped_gate':'all six fail by reader 11', 'cases':cases},sort_keys=True,indent=2))
