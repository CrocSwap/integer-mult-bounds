#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Two coded scalar routes through one pinned native BIT diamond.

Necessary screens on fixed source and destination clocks, not a new word.
"""
import gzip, hashlib, json, os, sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

# Keep the bounded replay on one CPU, even when launched without taskset.
if hasattr(os, 'sched_getaffinity') and hasattr(os, 'sched_setaffinity'):
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
SOURCE = Path(__file__).resolve().parent / 'inputs'
WORD = SOURCE / 'BIT-WORD.json.gz'
INVOICE = SOURCE / '7830-REVIEW.json'
PINS = {
    WORD: 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
    INVOICE: '077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d',
    SOURCE / 'price.py': 'd720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b',
    SOURCE / 'literal.py': '4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
}
for path, pin in PINS.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == pin, path
sys.path.insert(0, str(SOURCE))
import price

word = json.loads(gzip.decompress(WORD.read_bytes()))
canonical = hashlib.sha256(json.dumps(word,sort_keys=True,separators=(',', ':')).encode()).hexdigest()
assert canonical == 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
program = word['program']
assert (word['public'],word['owned_fields'],len(program)) == (680,3554,42958)
expected = {2:['MOVE',680,0,2], 5:['MOVE',681,0,2], 8:['MOVE',682,0,2],
            11:['ADD',683,680,2], 12:['MOVE',683,2,125],
            61:['MOVE',697,0,5], 64:['MOVE',698,0,5], 67:['MOVE',699,0,5],
            70:['ADD',700,697,5], 71:['MOVE',700,5,125],
            2394:['ADD',1356,683,125],2395:['ADD',1356,700,125],
            40084:['CLEAR',680,2],40101:['CLEAR',697,5],
            40087:['CLEAR',683,125],40104:['CLEAR',700,125]}
for t,event in expected.items(): assert program[t] == event, (t, program[t])

# The asserted contacts really are each role's first post-MOVE use.
def mentions(event,role):
    return event[1] == role or (event[0] in ('ADD','SWAP') and event[2] == role)
for role,send,read in ((680,2,11),(697,61,70),(683,12,2394),(700,71,2395)):
    assert all(not mentions(program[t],role) for t in range(send+1,read))
    assert mentions(program[read],role)

# Check the four source-frame admissibilities using their exact B/A rows.
def leg(a,b):
    f,g=word['frames'][str(a)],word['frames'][str(b)]
    if f['dim'] > g['dim']: f,g=g,f
    assert f['dim'] < g['dim']
    assert all(sum(x*y for x,y in zip(br,ar)) == 0 for br in f['B'] for ar in g['A'])
    return g['dim'] - f['dim']
assert {s:word['frames'][str(s)]['dim'] for s in (0,2,5,125)} == {0:0,2:1,5:1,125:2}
legs = {(a,b):leg(a,b) for a,b in ((0,2),(0,5),(2,125),(5,125))}
assert set(legs.values()) == {1}

# Exact literal linear-row replay, on all independent public columns.
def replay(adjoint=False):
    n, owned = word['public'], word['owned_fields']
    rows=[1<<i for i in range(n)] + [0]*owned
    tags=list(word['final'] if adjoint else word['start']) + [None]*owned
    snap={}; dirty=0; peak=live=0
    clocks=range(len(program)-1,-1,-1) if adjoint else range(len(program))
    for t in clocks:
        if not adjoint and t in (2,11,12,61,70,71,2394,2395,2396):
            snap[t]={'values': {r:rows[r] for r in (0,3,222,223,224,229,230,231,680,681,682,683,697,698,699,700,1356)},
                     'stock': {chart:{r:rows[r] for r,tag in enumerate(tags) if tag==chart} for chart in (0,2,5,125)}}
        op,r,*args=program[t]
        if op in ('INIT','CLEAR'):
            chart=args[0]
            opens=(op=='CLEAR') if adjoint else (op=='INIT')
            if opens:
                assert tags[r] is None and rows[r] == 0 and r>=n
                tags[r]=chart;live+=1;peak=max(peak,live)
            else:
                assert tags[r] == chart and r>=n
                dirty+=int(bool(rows[r]));tags[r]=None;rows[r]=0;live-=1
        elif op=='ADD':
            peer,chart=args
            assert tags[r]==tags[peer]==chart and r!=peer
            if adjoint: rows[peer] ^= rows[r]
            else: rows[r] ^= rows[peer]
        elif op=='SWAP':
            peer=args[0]
            assert tags[r] is not None and tags[peer] is not None and r!=peer
            rows[r],rows[peer]=rows[peer],rows[r]
            tags[r],tags[peer]=tags[peer],tags[r]
        else:
            assert op=='MOVE' and r>=n
            src,dst=(args[::-1] if adjoint else args)
            assert tags[r]==src
            tags[r]=dst
    dest=word['start'] if adjoint else word['final']
    assert tags==dest+[None]*owned and live==0 and not any(rows[n:])
    expected_rows=[]
    for i in range(n):
        row=1<<i
        if adjoint and i<111: row ^= 1<<(i+111)
        if not adjoint and 111<=i<222: row ^= 1<<(i-111)
        expected_rows.append(row)
    assert rows[:n]==expected_rows
    return snap, {'endpoint_rows_checked':n,'dirty_clear_count':dirty,'peak_live_private':peak}

snap,control=replay(False)
_,adjoint_control=replay(True)

def bbuild(rows):
    out={}
    for row in rows:
        while row:
            p=row.bit_length()-1
            if p in out: row^=out[p]
            else: out[p]=row;break
    return out

def residual(row,basis):
    while row:
        p=row.bit_length()-1
        if p not in basis: break
        row^=basis[p]
    return row

def present(row, rows): return residual(row,bbuild(rows)) == 0

def mrow(mask, a,b): return (a if mask&1 else 0) ^ (b if mask&2 else 0)

def coord(row): return [i for i in range(680) if (row>>i)&1]

a,b=1<<222,1<<229
u,v=(1<<0)^a,(1<<3)^b
assert snap[2]['values'][680]==a and snap[61]['values'][697]==b
assert snap[12]['values'][683]==u and snap[71]['values'][700]==v
assert u != v and u and v and a != b
assert snap[2394]['values'][683]==u and snap[2395]['values'][700]==v
assert all(present(x,snap[t]['stock'][0].values()) for t in (2,61) for x in (a,b))

# Chart-local stock excluding the selected original incoming role, just before
# its first read. Other moves, first readers, and return clocks are fixed.
stock2=[x for r,x in snap[11]['stock'][2].items() if r!=680]
stock5=[x for r,x in snap[70]['stock'][5].items() if r!=697]
assert not present(a,stock2) and not present(b,stock5)
assert all(not (x & a) for x in stock2)
assert all(not (x & b) for x in stock5)
# No operations from the rewired early route touch chart 2 before its reader;
# the only original arrivals there in that interval remain 681 and 682.
assert [(t,e) for t,e in enumerate(program[3:11],3) if e[0]=='MOVE' and e[3]==2] == [(5,program[5]),(8,program[8])]

bases=[]
for x in (1,2,3):
  for y in (1,2,3):
    if x==y: continue  # any two distinct nonzero F2^2 vectors are independent
    code1,code2=mrow(x,a,b),mrow(y,a,b)
    same1=present(a,stock2+[code1]); same2=present(b,stock5+[code2])
    # Under swapped destinations, the only selected arrival at chart 2 is t61,
    # strictly after its first reader at t11. No expression reaches it by then.
    swapped_first=present(a,stock2)
    ret1=present(mrow(x,u,v),snap[12]['stock'][2].values())
    ret2=present(mrow(y,u,v),snap[71]['stock'][5].values())
    bases.append({'basis_masks':[x,y], 'coded_ingress_coordinates':[coord(code1),coord(code2)],
                  'same_destination_first_reader_pass':[same1,same2],
                  'swapped_destination_first_reader_pass':swapped_first,
                  'return_sender_stock_pass':[ret1,ret2]})
assert len(bases)==6
assert [z['basis_masks'] for z in bases if all(z['same_destination_first_reader_pass'])] == [[1,2]]
assert not any(z['swapped_destination_first_reader_pass'] for z in bases)
assert [z['basis_masks'] for z in bases if all(z['return_sender_stock_pass'])] == [[1,2]]

receipt=json.loads(INVOICE.read_text())
assert receipt['binary']['physical']['word']==canonical
assert receipt['binary']['physical']['native_calls']==36
inv=receipt['binary']['signed']
paid={int(k):v for k,v in inv['paid'].items()}
target={int(k):v for k,v in inv['productive'].items()}
assert (sum(paid.values()),sum(target.values()))==(107460,20706)
k=Fraction('0.003879929046155')
signed=price.signed_profile(target,paid)
margin=price.decimal_interval(price.moment(signed,k),42)
# All four diamond edges have grade one; two switched arrivals preserve the
# histogram exactly, on all 36 native invocations. Original return moves stay.
changed=Counter(paid);changed[1]-=2*36;changed[1]+=2*36
assert changed==Counter(paid)
assert price.moment(price.signed_profile(target,changed),k)==price.moment(signed,k)
result={
 'source':{'pr':7830,'head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
           'candidate_binary_canonical_sha256':canonical,'word_gzip_sha256':PINS[WORD],
           'published_review_sha256':PINS[INVOICE],
           'context_pr_7852_head':'41beda1d6435760dc99e38bd7e65f36798aad212',
           'main_head':'e54523517d0f03e58352e647c403a5af3e525a57'},
 'scope':'One specified diamond; two selected arrivals at fixed clocks 2 and 61, all other routes fixed, six GL(2,F2) encodings of x222 and x229; either retain destinations or exchange them. Preserve reads 11 and 70 and return clocks 12 and 71. Unlimited free local F2 linear recombination is granted at each receiver; no new cross-chart packets or other changed source operations are granted.',
 'edges':[{'clock':t,'event':program[t],'grade':1} for t in (2,12,61,71)],
 'original_ingress_coordinates':[coord(a),coord(b)],
 'original_return_coordinates':[coord(u),coord(v)],
 'first_return_receivers':[{'clock':t,'event':program[t]} for t in (2394,2395)],
 'clock_exclusion':{'swapped_early_send_arrives_chart':5,'chart2_selected_arrival':61,
                    'chart2_first_read':11,'chart2_other_stock_rank':len(bbuild(stock2)),
                    'separating_public_coordinate':222,
                    'other_stock_rows':{str(r):coord(row) for r,row in snap[11]['stock'][2].items() if r!=680}},
 'return_sender_stock':{'first_clock':12,'second_clock':71,
                        'u_available_at_first':present(u,snap[12]['stock'][2].values()),
                        'v_available_at_first':present(v,snap[12]['stock'][2].values()),
                        'u_available_at_second':present(u,snap[71]['stock'][5].values()),
                        'v_available_at_second':present(v,snap[71]['stock'][5].values())},
 'bases':bases,'baseline_forward_control':control,'baseline_adjoint_control':adjoint_control,
 'signed_invoice':{'kappa':'0.003879929046155','paid':paid,'productive':target,
                   'paid_total':sum(paid.values()),'productive_total':sum(target.values()),
                   'native_invocations':36,'changed_paid_histogram':'identical in equal-grade switched-contact hypothetical',
                   'productive_delta':{},'signed_delta':'0 exactly under frozen target and no additional paid services',
                   'baseline_and_hypothetical_signed_balance':margin,
                   'qualification':'Necessary price only: none of the switched variants passes the first-read gate; this is not a changed word or complete physical candidate.'},
 'limitations':['No other diamond, different clock placement, extra cross-chart packet, changed unselected event, altered targets or multi-route schedule is excluded.',
                'The original readers and returned forms are checked for this local contact only; no successful changed operator exists to replay.',
                'The unchanged complete invoice is repriced; source supplier, physical compiler and inherited outer assumptions are not re-proved.']}
print(json.dumps(result,indent=2,sort_keys=True))
