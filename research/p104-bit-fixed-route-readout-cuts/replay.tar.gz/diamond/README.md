# Two coded routes in the first native BIT diamond

This is a local, bounded exclusion, not a changed word or a new κ bound. It examines one literal four-chart diamond in the binary native word used by [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), pinned at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The [published independent review](inputs/7830-REVIEW.json) supplies the source invoice, and the binary canonical SHA-256 is `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. #7852 at `41beda1d6435760dc99e38bd7e65f36798aad212` is research context, not a theorem used here. Main was pinned at `e54523517d0f03e58352e647c403a5af3e525a57` for the assignment. All clocks below are zero-based.

| Clock | Existing native operation | Rank |
|---:|---|---:|
| 2 | `MOVE(680, 0, 2)` | 1 |
| 12 | `MOVE(683, 2, 125)` | 1 |
| 61 | `MOVE(697, 0, 5)` | 1 |
| 71 | `MOVE(700, 5, 125)` | 1 |

The two independent original ingress payloads are `a=x222` and `b=x229`. Their first original readers are `ADD(683,680,2)` at 11 and `ADD(700,697,5)` at 70. Their outgoing return payloads are `u=x0+x222` and `v=x3+x229`, read at chart 125 by operations 2394 and 2395 respectively. Both payload pairs have rank two over F₂; all 680 public coordinates are independent at entry.

The ingress experiment holds the two ingress clocks at 2 and 61 and every unselected event and its original source payload fixed, including the other chart-2 arrivals at clocks 5 and 8. No other source encoding or earlier cross-chart packet is added. The two selected scalar payloads may be any one of the six invertible bases `(a,b)`, `(a,a+b)`, `(b,a)`, `(b,a+b)`, `(a+b,a)`, `(a+b,b)`. Both underlying data directions are available in chart 0 at both send clocks. The decoder is optimistically granted unlimited free F₂-linear combinations of local live fields. Existing reader values and both original returns must be preserved. Two cases are checked:

1. **Exchange the ingress destinations:** send at 2 to chart 5 and at 61 to chart 2. Every basis fails before the second send: at clock 11 the first reader needs `a`, whereas the other chart-2 stock has span `{x0,x223,x224}`. The input pulse `x222=1` and all other inputs zero annihilates that stock and makes the needed read 1. No local decoding can fix the missing bit. The original first read is also no longer a legal contact with role 680, which is now at chart 5.
2. **Keep the original destinations:** only `(a,b)` meets both original first-reader requirements. Separately, with original ingress retained, the outgoing-sender stocks at clocks 12 and 71 contain `u` but not `v`, and `v` but not `u`, respectively; only the identity basis of `(u,v)` is simultaneously available for the two returns. The five other invertible return bases fail at least one sender-stock gate. These are necessary tests, allowing free local coding; they do not construct a modified tape.

The retargeted arrivals would still both have rank 1; retaining the two original rank-1 return contacts and every target leaves the paid and productive histograms exactly unchanged, including all 36 native invocations. Using the complete #7830 binary signed inventory, 107,460 paid and 20,706 productive positions, gives target-minus-paid balance in

```
[-0.000385127316613866441054139472099789196375,
 -0.000385127316613866441054139472099789196374]
```

at `κ=0.003879929046155`. Thus, even **if** the exchange were otherwise implementable without further charges, its ideal signed delta under frozen targets would be exactly zero. This is a repricing of the authenticated full source histogram, not an invoice for a valid changed candidate. No additional scalar, allocation, precision, erasure or routing work is credited as free in a physical conclusion.

`screen.py` authenticates both word and invoice, checks the four nested rational frames and grades, replays all 680 public columns in the unchanged forward and adjoint words, exhausts the six named bases at the first readers and return-sender spans, and uses directed rational-grid arithmetic to reprice every histogram bin. `pulse_control.py` separately interprets the two independent input pulses and detects the missing first read for each basis; the unchanged identity is its positive control. `RESULT.json` and `CONTROL.json` retain the exact data. Each replay script restricts itself to one CPU where Linux affinity is available. The initial local runs used `nice -n 15` and completed in under one second each.

This does **not** rule out another diamond, moving the send clocks, using additional cross-chart sends, changing an unselected operation, changing the targets, or a wider joint-code schedule. Because no switched basis reaches the first reader, no altered full caller, independent supplier replay, physical compiler, erasure, or outer application was qualified. The #7830 supplier's five inherited assumptions remain outside this check.

[Discussion #7111](https://github.com/CrocSwap/integer-mult-bounds/discussions/7111) contains earlier frozen-placement and repeated-route deletion screens, the stated next need for a second direction with both returns, and related broader native/caller experiments. This screen neither claims priority nor repeats the separately identified two-contact caller experiment: it concerns these native chart moves.

## Open next questions

Which different four-chart diamond admits two independent packets at the required clocks and has an actually cheaper replacement invoice after paying its sender preparation, all original readers, both returns, productive targets, erasure and precision? A surviving candidate needs full forward and adjoint all-column replay and the complete 36-call signed invoice before the finite supplier and 48-call application can be reconsidered. Retiming, extra packets and changed other events are outside this check.

## Clean replay

All source pins and contributor credits are in [SOURCES.json](SOURCES.json) and [NOTICE](NOTICE). Python 3.12, standard library only; no network, workstation paths, or external source checkout are required:

```sh
python3 -IB replay.py
```

The replay verifies [SHA256SUMS](SHA256SUMS), runs both scripts from temporary working directories, byte-compares their output to the saved receipts, and prints `PASS_PINNED_DIAMOND_AND_PULSE_REPLAY`. The unchanged supplier and inherited application are not requalified.
