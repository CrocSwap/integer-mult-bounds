#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Authenticate the portable package and reproduce both saved receipts."""
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path

root=Path(__file__).resolve().parent
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ',1)
    path=root/name
    if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        raise SystemExit('checksum mismatch: '+name)
for script, expected in (('screen.py','RESULT.json'),('pulse_control.py','CONTROL.json')):
    with tempfile.TemporaryDirectory(prefix='bit-diamond-replay-') as temp:
        proc=subprocess.run([sys.executable,'-IB',str(root/script)],cwd=temp,
                            capture_output=True,check=True)
    want=(root/expected).read_bytes()
    if proc.stdout != want:
        try:
            same = json.loads(proc.stdout) == json.loads(want)
        except (ValueError,UnicodeError):
            same = False
        raise SystemExit(f'{script}: receipt differs (semantic equality={same})')
    if proc.stderr:
        raise SystemExit(f'{script}: unexpected stderr: {proc.stderr!r}')
print('PASS_PINNED_DIAMOND_AND_PULSE_REPLAY')
