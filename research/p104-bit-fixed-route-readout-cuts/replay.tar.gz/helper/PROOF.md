# Exact fixed-source cut

For each nominated first/second window, write the seven granted old stock rows as a matrix `R` over GF(2) on all 680 independent public coordinates. Write `S` for their response to every individually granted first-chart signal control. Any local linear readout is a row vector `ℓ`. A pure first-signal observation must satisfy `ℓR=0` and `ℓS≠0`.

The replay computes the complete left kernel of `R`. In all three cases `R` has seven rows and rank six; its unique nonzero left-kernel generator satisfies `ℓS=0`. Consequently no pure first-signal readout exists from those stocks. This argument grants free persistent copies and independent first-signal injections; it does not require preserving any other old packet demand or dirty carry. It applies only while the specified old input rows and second-source cut are fixed. The scalar equations apply to arbitrary complete binary fields under the retained linear native model; they are not a construction of that physical model.

| Original sample ID | Target chain | MOVE clocks | Sender stocks | All later receiver arrivals | First controls | Sole zero-old-data relation |
|---:|---|---|---|---|---:|---|
| 159 | 0→519→619→1 | 2569, 9081 | 1402, 2018, 2143 | 2614, 2620, 2625, 3306 | 14 | 2018+2143+2614 |
| 215 | 0→524→601→1 | 4294, 9627 | 1862, 2085, 2239 | 2752, 2762, 3290, 3505 | 15 | 1862+2085+2239+2752 |
| 216 | 0→524→604→1 | 4294, 9639 | 2011, 2139, 2405 | 2755, 2760, 2763, 3511 | 15 | 2011+2139+2755 |

Packet identifiers are the extractor's IDs on this exact word. The source rows include the three original sender stocks at the second selected clock, granted as though independently delivered to the middle chart. The receiver rows include every original arrival at that chart, even arrivals after the selected clock. All later sends from the first chart are granted as separate control channels. A permissible new independent output at the middle must be recoverable from these rows under the stipulated direct-sum boundary; other boundary contracts and changed old rows remain open.

## The causal 469 witness

For sample 215, chart dimensions along `0→524→601→1` are `0,4,7,8`. Both inserted paid splits are nested: original grade 4 becomes `2+2`, and grade 2 becomes `1+1`. At the first window, original packet 1854 and the split arrival from packet 1862 have rows `x105+x468` and `x105+x469`, so the readout is `q=x468+x469`. One relaxed old-source direction is `d=e255+e469` and `q·d=1`. The original first continuation can affect receiver packet 2752 at clock 9624, making this a causal example rather than a pair of isolated images.

Let world A have all old public inputs zero and add one to packet 1862 after its proposed first split. Let world B add no such signal and set only old inputs 187 and 469. Literal scalar execution gives the following equal values:

| Granted stock | Value in A and B |
|---|---:|
| sender 1862 | 1 |
| sender 2085 | 0 |
| sender 2239 | 0 |
| arrival 2752 | 1 |
| arrivals 2762, 3290, 3505 | 0 |

Thus even an arbitrary function of these granted values cannot distinguish this particular pair. The linear kernel result covers all first-signal control choices. Under the example invertible source reframe for `q` and `d`, old pulse `{187,469}` has preimage `{187,255,469}`; it is not eliminated by that reframe. A separate pristine copy of the old packet-1862 value would break the indistinguishability in the optimistic model. The package grants this only as a control, not as an actual free observation.

The 200-case pre-screen grants simultaneous free ingress and egress combinations on the unchanged packet graph. Its helper `q=k` restriction and ranking fixture define a search subset, not the full space of possible `q`, calibration, route changes or cuts. Its egress rank counts describe a relaxation; the final gates independently check the stated full old-input image. The literal baseline also verifies both directions and dirty retirement, but the candidate's changed demands and dirty carries remain unconstructed.
