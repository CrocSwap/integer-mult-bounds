#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Offline, bounded replay of three fixed-source BIT middle-readout cuts.

Inputs are checked before compilation and are never fetched. This is a scoped
negative screen, not a proposed BIT word or a certified kappa improvement.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from types import ModuleType
import gzip
import json
import sys

if not __debug__:
    raise RuntimeError('run without Python optimization; checks use assertions')
HERE = Path(__file__).resolve().parent
INPUTS = HERE / 'inputs'
PINS = {
    'WORD.json.gz': 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
    'bit_native.py': '4368c62a5d42f81189d6776b8dba8c85a311b6a199b816244b545c6bb7d3dc1e',
    'BIT.json': '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
    'independent.py': 'a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
}
CANONICAL = 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'

def authenticated(name):
    raw = (INPUTS / name).read_bytes()
    assert sha256(raw).hexdigest() == PINS[name], 'source pin: ' + name
    return raw

def module_from_pinned(name, filename):
    """Compile authenticated bytes directly: no stale imported bytecode."""
    raw = authenticated(filename)
    mod = ModuleType(name)
    mod.__file__ = str(INPUTS / filename)
    sys.modules[name] = mod
    exec(compile(raw, mod.__file__, 'exec'), mod.__dict__)
    return mod

word = json.loads(gzip.decompress(authenticated('WORD.json.gz')))
assert sha256(json.dumps(word, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == CANONICAL
edge = module_from_pinned('pinned_bit_native_7776', 'bit_native.py')
price = module_from_pinned('pinned_bit_price_7830', 'independent.py')
archive = json.loads(authenticated('BIT.json'))
sample_bytes = (HERE / 'SAMPLE.json').read_bytes()
assert sha256(sample_bytes).hexdigest() == 'd0ade1ac8ed0de4bc8bf181786049949a4b40ef9650546bd8ba1e897449e2c22'
sample = json.loads(sample_bytes)
assert sample['schema'] == 'p104-bit-two-window-sample/1' and len(sample['cases']) == 200
n = word['public']
assert n == 680
initial, final, moves, rows, clocks = edge.extract(word)
order = edge.schedule(initial, final, moves, rows)
assert len(order) == 2874 and all(clocks[a] < clocks[b] for a, b in zip(order, order[1:]))
by_clock = {v: k for k, v in clocks.items()}
assert len(by_clock) == len(moves)

def indices(mask):
    return edge.indices(mask)

def transfer(col):
    # Complete original forward public map and its inverse; it is involutive.
    return col ^ ((col & ((1 << 111) - 1)) << 111)

values = {j: 1 << j for j in initial}
for k in order:
    values[k] = edge.combine(rows[k], values)
columns = {j: 0 for j in initial.keys() | moves.keys()}
for r in initial:
    for j in indices(rows[~r]):
        columns[j] ^= 1 << r
for k in reversed(order):
    for j in indices(rows[k]):
        columns[j] ^= columns[k]
for r in initial:
    expected_row = (1 << r) ^ ((1 << (r - 111)) if 111 <= r < 222 else 0)
    assert edge.combine(rows[~r], values) == expected_row
    assert columns[r] == transfer(1 << r)
# Zeroing one real selected paid payload must break at least one old output.
zeroed = {r: 1 << r for r in initial}
for k in order:
    zeroed[k] = 0 if clocks[k] == 4294 else edge.combine(rows[k], zeroed)
assert any(edge.combine(rows[~r], zeroed) != edge.combine(rows[~r], values) for r in initial)

def add(basis, value, witness):
    while value:
        pivot = value.bit_length() - 1
        if pivot in basis:
            value ^= basis[pivot][0]
            witness ^= basis[pivot][1]
        else:
            basis[pivot] = (value, witness)
            return

def restrict(vectors, allowed):
    """Basis for span(vectors) intersected with the allowed coordinates."""
    bad, good = {}, {}
    for i, vector in enumerate(vectors):
        v, witness = vector, 1 << i
        while outside := v & ~allowed:
            pivot = outside.bit_length() - 1
            if pivot in bad:
                v ^= bad[pivot][0]
                witness ^= bad[pivot][1]
            else:
                bad[pivot] = (v, witness)
                break
        else:
            if v:
                add(good, v, witness)
    return good

def contained(a, b):
    lower, upper = (word['frames'][str(i)] for i in (a, b))
    return lower['dim'] < upper['dim'] and all(
        sum(F(x) * F(y) for x, y in zip(u, v)) == 0
        for u in lower['B'] for v in upper['A']
    )

def middle_of(a, middle, b):
    da = word['frames'][str(a)]['dim']
    db = word['frames'][str(b)]['dim']
    low, high = (a, b) if da < db else (b, a)
    return contained(low, middle) and contained(middle, high)

def ingress(chart, clock, packet):
    result = [values[r] for r, c in initial.items() if c == chart]
    result.extend(values[k] for k, (_, c) in moves.items()
                  if c == chart and clocks[k] < clock)
    result.append(values[packet])  # intermediate arrival on the split packet
    return result

def egress(chart, clock, packet):
    result = [columns[k] for k, (a, _) in moves.items()
              if a == chart and clocks[k] > clock]
    result.extend(1 << r for r, c in final.items() if c == chart)
    result.append(columns[packet])  # continuation of the split packet
    return result

rank_histogram, cases, survivors = Counter(), [], []
seen = set()
for record in sample['cases']:
    A, c1, c2, B = record['charts']
    t1, t2 = record['clocks']
    assert A == 0 and B == 1 and t1 < t2 and (t1, t2) not in seen
    seen.add((t1, t2))
    assert contained(A, c1) and contained(c1, c2) and contained(c2, B)
    k1, k2 = by_clock[t1], by_clock[t2]
    assert middle_of(*((moves[k1][0], c1, moves[k1][1])))
    assert middle_of(*((moves[k2][0], c2, moves[k2][1])))
    # Two distinct physical packets, not identical-row/column siblings.
    assert values[k1] != values[k2] and columns[k1] != columns[k2]
    A_mask = sum(1 << r for r, chart in initial.items() if chart == A)
    B_mask = sum(1 << r for r, chart in final.items() if chart == B)
    common = sum(1 << r for r in range(222, n) if initial[r] == A and final[r] == B)
    assert common.bit_count() == 389
    in_rows = ingress(c1, t1, k1) + ingress(c2, t2, k2)
    out_columns = egress(c1, t1, k1) + egress(c2, t2, k2)
    combined = [y | (transfer(y) << n) for y in out_columns]
    ob = restrict(combined, B_mask | (A_mask << n))
    ib = restrict(in_rows, common)
    pairings = []
    for x, _ in ib.values():
        for z, _ in ob.values():
            d = z >> n
            if (x & d).bit_count() % 2:
                pairings.append({'q': list(indices(x)), 'd': list(indices(d))})
    rank_histogram[len(ob)] += 1
    item = {'ranked_chain': record['ranked_chain'], 'charts': record['charts'],
            'clocks': record['clocks'], 'joint_egress_rank': len(ob),
            'joint_ingress_helper_rank': len(ib), 'pairing_count': len(pairings)}
    cases.append(item)
    if pairings:
        survivors.append((record, pairings))
assert dict(rank_histogram) == {0: 140, 1: 46, 2: 13, 3: 1}
assert [r['ranked_chain'] for r, _ in survivors] == [159, 215, 216]
assert all(len(pairs) == 1 for _, pairs in survivors)
assert survivors[0][1][0] == {'q': [261], 'd': [261,439,451,463,495,502,505,570,629]}
assert survivors[1][1][0] == {'q': [468,469], 'd': [255,469]}
assert survivors[2][1][0] == {'q': [468,469], 'd': [255,295,296,308,419,469]}

def readout_gate(record):
    _, c1, c2, _ = record['charts']
    t1, t2 = record['clocks']
    k1, k2 = by_clock[t1], by_clock[t2]
    source_chart = moves[k2][0]
    controls = sorted([k1] + [k for k, (a, _) in moves.items()
                              if a == c1 and clocks[k] > t1], key=clocks.get)
    assert len(controls) == len(set(controls))
    ci = {k: i for i, k in enumerate(controls)}
    # Every bit is a separate, freely granted control at the first window.
    response = {r: 0 for r in initial}
    for k in order:
        response[k] = edge.combine(rows[k], response) ^ ((1 << ci[k]) if k in ci else 0)
    source = ([r for r, c in initial.items() if c == source_chart]
              + [k for k, (_, b) in moves.items() if b == source_chart and clocks[k] < t2])
    receiver = ([r for r, c in initial.items() if c == c2]
                + [k for k, (_, b) in moves.items() if b == c2])
    stock = source + receiver
    assert len(stock) == len(set(stock))
    pivots, relations = {}, []
    for i, k in enumerate(stock):
        v, mask = values[k], 1 << i
        while v:
            pivot = v.bit_length() - 1
            if pivot in pivots:
                v ^= pivots[pivot][0]
                mask ^= pivots[pivot][1]
            else:
                pivots[pivot] = (v, mask)
                break
        if not v:
            signal = 0
            for j in indices(mask):
                signal ^= response[stock[j]]
            relations.append((mask, signal))
    assert len(pivots) == 6 and len(relations) == 1
    assert all(signal == 0 for _, signal in relations)
    # Mutation control: misreport one stock's first-signal image and check that
    # the exact relation detects the corruption.
    relation_mask = relations[0][0]
    j = next(indices(relation_mask))
    corrupted = response[stock[j]] ^ 1
    signal = 0
    for p in indices(relation_mask):
        signal ^= corrupted if p == j else response[stock[p]]
    assert signal != 0
    # A hypothetical pristine copy of first packet k1, when that packet is
    # among the already granted stocks, has the same old row and zero control
    # response. Its difference from the changed stock exposes control bit 0.
    pristine_control = k1 in stock and bool(response[k1] & 1)
    if pristine_control:
        assert (values[k1] ^ values[k1]) == 0
        assert (response[k1] ^ 0) & 1
    return {'ranked_chain': record['ranked_chain'], 'charts': record['charts'],
            'clocks': record['clocks'], 'free_first_signal_controls': len(controls),
            'sender_stocks': source, 'receiver_arrivals': receiver,
            'old_image_rank': len(pivots), 'old_zero_relations': len(relations),
            'zero_relations_with_signal': 0,
            'sole_relation': [stock[j] for j in indices(relation_mask)],
            'corrupted_signal_control_rejected': True,
            'grant_pristine_first_packet_exposes_signal': pristine_control}

gates = [readout_gate(record) for record, _ in survivors]
assert [g['free_first_signal_controls'] for g in gates] == [14, 15, 15]
assert gates[1]['sender_stocks'] == [1862, 2085, 2239]
assert gates[1]['receiver_arrivals'] == [2752, 2762, 3290, 3505]
assert gates[1]['sole_relation'] == [1862, 2085, 2239, 2752]
assert gates[1]['grant_pristine_first_packet_exposes_signal']

# Explicit all-column ingress for the causal helper-469 example.
assert word['start'][469] == 0 and word['final'][469] == 1
assert word['program'][4294] == ['MOVE', 1862, 251, 447]
assert word['program'][9627] == ['MOVE', 2753, 447, 1]
assert values[by_clock[4264]] ^ values[by_clock[4294]] == (1 << 468) ^ (1 << 469)
assert [word['frames'][str(i)]['dim'] for i in (0, 524, 601, 1)] == [0,4,7,8]

# Independent literal replay, without packet extraction, of forward and
# adjoint native operators. All bank values are full 680-bit rows.
def literal(reverse=False, omit_clear=None):
    banks = [1 << i for i in range(n)] + [0] * word['owned_fields']
    tags = list(word['final' if reverse else 'start']) + [None] * word['owned_fields']
    dirty = retired = 0
    sequence = range(len(word['program'])-1, -1, -1) if reverse else range(len(word['program']))
    for clock in sequence:
        if clock == omit_clear:
            continue
        op, r, *args = word['program'][clock]
        if op in ('INIT', 'CLEAR'):
            chart = args[0]
            opens = (op == 'CLEAR') if reverse else (op == 'INIT')
            if opens:
                assert tags[r] is None
                tags[r], banks[r] = chart, 0
            else:
                assert tags[r] == chart
                dirty += bool(banks[r])
                retired += 1
                tags[r], banks[r] = None, 0
        elif op == 'ADD':
            peer, chart = args
            assert tags[r] == tags[peer] == chart and r != peer
            if reverse:
                banks[peer] ^= banks[r]
            else:
                banks[r] ^= banks[peer]
        elif op == 'SWAP':
            peer = args[0]
            assert tags[r] is not None and tags[peer] is not None
            banks[r], banks[peer] = banks[peer], banks[r]
            tags[r], tags[peer] = tags[peer], tags[r]
        else:
            assert op == 'MOVE'
            a, b = args[::-1] if reverse else args
            assert tags[r] == a
            tags[r] = b
    assert tags == list(word['start' if reverse else 'final']) + [None] * word['owned_fields']
    assert not any(banks[n:])
    return banks[:n], dirty, retired

fwd, dirty_f, retired_f = literal()
adj, dirty_a, retired_a = literal(True)
assert fwd == [(1 << r) ^ ((1 << (r-111)) if 111 <= r < 222 else 0) for r in range(n)]
assert adj == [transfer(1 << r) for r in range(n)]
assert (dirty_f, dirty_a, retired_f, retired_a) == (3554, 3554, 3554, 3554)
# Missing retirement must fail even if the public output happens to match.
last_clear = max(i for i, event in enumerate(word['program']) if event[0] == 'CLEAR')
try:
    literal(omit_clear=last_clear)
except AssertionError:
    pass
else:
    raise AssertionError('missing CLEAR accepted')

# Independent scalar two-world test for the nominated causal 469 cut.
def scalar(active, inject=False):
    banks = [int(i in active) for i in range(n)] + [0] * word['owned_fields']
    tags = list(word['start']) + [None] * word['owned_fields']
    found = {}
    sender, receiver = (1862, 2085, 2239), (2752, 2762, 3290, 3505)
    for clock, (op, r, *args) in enumerate(word['program']):
        if clock == 9627:
            assert all(tags[k] == 447 for k in sender)
            for k in sender:
                found['sender:' + str(k)] = banks[k]
        if op == 'INIT':
            assert tags[r] is None
            tags[r], banks[r] = args[0], 0
        elif op == 'CLEAR':
            assert tags[r] == args[0]
            tags[r], banks[r] = None, 0
        elif op == 'ADD':
            peer, chart = args
            assert tags[r] == tags[peer] == chart
            banks[r] ^= banks[peer]
        elif op == 'SWAP':
            peer = args[0]
            banks[r], banks[peer] = banks[peer], banks[r]
            tags[r], tags[peer] = tags[peer], tags[r]
        else:
            assert op == 'MOVE'
            a, b = args
            assert tags[r] == a
            if clock == 4294 and inject:
                banks[r] ^= 1
            if r in receiver and clocks[r] == clock:
                found['arrival:' + str(r)] = banks[r]
            tags[r] = b
    return found

observed = scalar([], True)
assert observed == scalar([187, 469])
assert observed == {'sender:1862':1, 'sender:2085':0, 'sender:2239':0,
                    'arrival:2752':1, 'arrival:2762':0, 'arrival:3290':0, 'arrival:3505':0}
# The example ingress reframe is invertible and maps this alternate old input
# [187,255,469] to the witness pulse [187,469].
def source_reframe(v):
    x0 = v & ~(1 << 469)
    qx = ((x0 >> 468) ^ (x0 >> 469)) & 1
    return x0 ^ (((1 << 255) | (1 << 469)) if (((v >> 469) & 1) ^ qx) else 0)
assert source_reframe((1 << 187) | (1 << 255) | (1 << 469)) == (1 << 187) | (1 << 469)
# Give an ideal unperturbed copy of old packet 1862 as one additional free
# observation. Its row agrees but its first-control response differs, so the
# signal becomes distinguishable in this generous model.
assert values[1862] == values[by_clock[4294]]
assert 1862 in gates[1]['sole_relation']

# Reprice ONLY the unrealized 4+3+1 geometry against the complete pinned
# paired histogram. This is not a candidate's full physical tariff.
T, P = price.histogram(archive['native']['targets']), price.histogram(archive['native']['paid'])
assert archive['native_calls'] == 36 and sum(T.values()) == 20706 and sum(P.values()) == 107460
newT, newP = T.copy(), P.copy()
for r, count in ((1,36), (3,36), (4,36), (8,-36)):
    newT[r] += count
for r, count in ((1,72), (2,36), (4,-36)):
    newP[r] += count
assert min(newT.values()) >= 0 and min(newP.values()) >= 0
assert sum(r*v for r,v in T.items()) == sum(r*v for r,v in newT.items())
assert sum(r*v for r,v in P.items()) == sum(r*v for r,v in newP.items())
t = 1 - F('0.00387992904884')
base = price.sub(price.moment(T,t), price.moment(P,t))
hypothetical = price.sub(price.moment(newT,t), price.moment(newP,t))
gain = price.sub(hypothetical, base)
extra_one = price.sub(hypothetical, price.enclose(F(1)))
extra_three = price.sub(hypothetical, price.scale(price.power(3,t), 36))
assert base[1] < 0 < hypothetical[0] and gain[0] > 0 and extra_one[1] < 0 and extra_three[1] < 0

result = {'status':'PASS_SCOPED_NEGATIVE_SCREEN', 'word':CANONICAL,
          'sample_cases':len(cases), 'egress_rank_histogram':dict(sorted(rank_histogram.items())),
          'restricted_q_equals_k_survivors':[r['ranked_chain'] for r,_ in survivors],
          'three_fixed_source_cuts':gates,
          'literal':{'coefficients_each_direction':n*n,'dirty_retirements_each_direction':dirty_f,
                     'missing_CLEAR_rejected':True,'equal_two_world_stocks':observed,
                     'alternative_old_input':[187,469],'example_reframe_preimage':[187,255,469]},
          'hypothetical_price':{'trial':'0.00387992904884', 'baseline_margin':price.report_interval(base),
               'gain_before_repairs':price.report_interval(gain),
               'margin_with_one_extra_H1_in_paired_word':price.report_interval(extra_one),
               'margin_with_one_H3_per_native_call':price.report_interval(extra_three)}}
expected_bytes = (HERE / 'EXPECTED.json').read_bytes()
assert sha256(expected_bytes).hexdigest() == '208893410f49d056120f09af401dd2fba05b0dbaf1139515b68e6451a95069b0'
expected = json.loads(expected_bytes)
# Normalize JSON integer dictionary keys for exact portable fixture comparison.
result = json.loads(json.dumps(result, sort_keys=True))
assert result == expected, 'scientific receipt differs from frozen expected result'
print('PASS_SCOPED_NEGATIVE_SCREEN', 'cases=200', 'restricted-survivors=3',
      'fixed-source-middle-cuts=3', 'native-coefficients-each-way=462400')
