# Three fixed-source BIT middle-readout cuts

On the frozen binary native word used by [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), an exact bounded screen found three relaxed two-window helper candidates among 200 distinct packet-pair representatives. All three fail a subsequent fixed-source middle-readout test, even when the readout receives free copies of every relevant old sender and receiver stock and the first signal can be injected independently into every later first-chart send. This is a **scoped negative result**, with no modified supplier, full signed candidate tariff or new κ bound.

For the main witness, productive helper **469** has boundary charts `0→1`. The proposed middle charts `524→601` split its rank-eight boundary into ranks `4+3+1`, using distinct paid packet windows at clocks 4294 and 9627. A real earlier packet reaches the second chart. Nevertheless, in the granted seven-stock readout, the old-input row rank is six and the only dependency has zero response to all 15 freely granted first-signal controls. A scalar tape replay gives a concrete pair of indistinguishable local states: first signal one with all old inputs zero, versus first signal zero with old inputs 187 and 469 equal to one. The exact values at the three sender stocks and four receiver arrivals match. [Proof and scope](PROOF.md) · [Frozen receipt](EXPECTED.json)

The 200-case sample is fixed in [SAMPLE.json](SAMPLE.json). The replay reconstructs exact rational frame containments, checks the two original packets in each representative have different input rows and output columns, evaluates the full old 680-column graph and recomputes the joint egress and restricted `q=k` image tests. Three representatives pass that deliberately limited test; the subsequent readout gate tests those three. The sample originated from a floating-point geometry ranking; its global ranking is **not** reproduced or claimed. The other representatives are not generally excluded under `q≠k` or other basis changes. The sample is not an exhaustive chart/time search.

## Reproduce offline

From this directory, on CPython 3.12 with the standard library:

```sh
python3 -B verify.py
```

Expected output:

```text
PASS_SCOPED_NEGATIVE_SCREEN cases=200 restricted-survivors=3 fixed-source-middle-cuts=3 native-coefficients-each-way=462400
```

One clean run on CPython 3.12.3 used 0.86 seconds wall time and 38,740 KiB peak RSS. The command reads only package-local files, verifies every executable source byte before loading it, performs no download and writes no file. It does not need Git, NumPy or the historical source checkout. The `-B` flag disables bytecode writes; authenticated Python source is compiled directly. The verifier checks the unmodified literal native in each direction, including all 462,400 public coefficients and all 3,554 dirty private retirements per direction. Controls corrupt a readout response, omit a literal `CLEAR`, zero an original paid payload, and grant the missing pristine observation. The changed candidate is **not** built or replayed; none of these baseline checks establishes its demands or dirty-carry preservation.

The source archive and exact public paths, heads and digests are in [SOURCES.json](SOURCES.json). The byte checks authenticate inputs; they do not themselves prove public Git ancestry, scientific approval, a physical realization or an application theorem. No host CI result is asserted.

## Price context

At trial `0.00387992904884`, the pinned complete 36-call paired histogram has signed margin approximately `−0.000386161382432`. If a `4+3+1` split with the two indicated subdivisions were achieved with no other changes or cost, its hypothetical gain would be approximately `0.503345983394`. In that optimistic arithmetic, even one additional `H₁` in the entire paired word makes the margin approximately `−0.497040177989`; a separate grade-three 524→601 observation per native call would make it approximately `−107.037665849`. The replay checks these as directed enclosures using the retained #7830 interval engine. No lower bound asserts that every possible changed-source or shared construction must buy either repair, and the numbers are not a complete changed-word tariff.

## Related work and open next questions

The [#7111 Round 309–316 handoff](https://github.com/CrocSwap/integer-mult-bounds/discussions/7111#discussioncomment-19777560), read from the 21 November 2026 campaign capture, reports an earlier singleton split screen and fixed-chart/two-helper checks. This package instead records two distinct chart/time windows and the seven-stock arbitrary-column cut; it does not supersede those results or claim novelty over unsearched work. The earlier constructive binary-birth proof is retained through the #7786/#7781 provenance described in [NOTICE](NOTICE).

- Can a nominated earlier changed packet or paid observation give chart 601 a second independent image that separates the first signal? First identify the sender, availability clock and exact arbitrary-column row, then include its readers, dirty carries and complete paid price.
- Can a different joint boundary encoding avoid the stipulated pure middle-daughter readout? Give the explicit source and return basis maps, preserve every existing demand and dirty carry, and replay the complete new operator in both directions before pricing it.
- Any positive candidate still needs complete paired invoices, physical ownership/retirement, finite compiler, stock, precision and outer application checks. The present screen does not discharge them.

Prepared for Clear1nsight with substantial OpenAI Codex assistance; predecessor credit and retained notices are in [NOTICE](NOTICE).
