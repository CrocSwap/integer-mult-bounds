#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Direct raw primitive re-extraction of two seven-variable chart-388 rewirings."""
from collections import Counter,defaultdict
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'/'vendor'))
sys.path.insert(0,str(ROOT/'source'))
import binary_operator as operator
import common

def require(ok,description):
    if not ok:raise ValueError(description)

def indices(x):
    while x:
        b=x&-x
        yield b.bit_length()-1
        x^=b

def xor(xs):
    v=0
    for x in xs:v^=x
    return v

class Space:
    def __init__(self):
        self.rows={}
    def reduce(self,x):
        value=0
        for p in sorted(self.rows,reverse=True):
            if (x>>p)&1:
                row,tag=self.rows[p]
                x^=row;value^=tag
        return x,value
    def insert(self,x,tag=0):
        rem,value=self.reduce(x)
        if not rem:return False
        self.rows[rem.bit_length()-1]=(rem,value^tag)
        return True
    def contains(self,x):return not self.reduce(x)[0]
    def basis(self):return [v for v,_ in self.rows.values()]

def formal(word,early):
    n=word['public']
    fixed_mask=(1<<n)-1
    late=(2583,2584,2585)
    positions={p:n+i for i,p in enumerate(early+late)}
    cells=[1<<i for i in range(n)]+[0]*word['owned_fields']
    banks=defaultdict(list);forms={i:1<<i for i in range(n)}
    for i,c in enumerate(word['start']):banks[c].append(i)
    route={};clocks={};packet=n
    for time,event in enumerate(word['program']):
        o,i,*tail=event
        if o=='ADD':cells[i]^=cells[tail[0]]
        elif o=='SWAP':cells[i],cells[tail[0]]=cells[tail[0]],cells[i]
        elif o in ('INIT','CLEAR'):cells[i]=0
        else:
            require(o=='MOVE','MOVE parser')
            a,b=tail
            route[packet]=a,b;clocks[packet]=time
            if packet==927:cells[i]=0
            else:
                if packet in positions:cells[i]=1<<positions[packet]
                banks[b].append(packet)
            forms[packet]=cells[i];packet+=1
    require(packet==3554,'complete 2,874-transfer primitive word')
    groups=defaultdict(list)
    for i,c in enumerate(word['final']):groups[c].append(i)
    return dict(banks=banks,forms=forms,groups=groups,routes=route,clocks=clocks,n=n,
                mask=fixed_mask,early=early,late=late,targets=operator.expected_operator(False))

def src_slice(value,coords):
    return sum(((value>>i)&1)<<j for j,i in enumerate(coords))

def early_conditions(P,coords):
    # Quotient by the chosen source-coordinate subspace. Every row in a bank
    # separates into one immutable outside component and one short affine word.
    forms,banks,groups=P['forms'],P['banks'],P['groups']
    n=P['n'];keep=P['mask'];source=sum(1<<i for i in coords);width=len(coords)
    tests=defaultdict(list);late_mask=7<<4
    for c,owners in groups.items():
        scope=0
        for p in banks[c]:scope|=forms[p]>>n
        if scope&late_mask:continue
        outer=Space();kernel=Space();demands=Space()
        for p in banks[c]:
            fixed=forms[p]&keep
            g=forms[p]>>n
            ext=fixed&~source
            word=src_slice(fixed,coords)|(g<<width)
            rem,t=outer.reduce(ext)
            if rem:outer.insert(ext,word)
            else:kernel.insert(word^t)
        for i in owners:
            demand=P['targets'][i]
            rem,t=outer.reduce(demand&~source)
            require(not rem,'outside components of each early chart demand')
            demands.insert(src_slice(demand,coords)^t)
        tests[scope].append((c,kernel.basis(),demands.basis()))
    return tests

def matches(charts,environment,width):
    low=(1<<width)-1
    def substitute(v):return (v&low)^xor(environment[i] for i in indices(v>>width))
    for c,kernel,demands in charts:
        s=Space()
        for v in kernel:s.insert(substitute(v))
        if any(not s.contains(substitute(v)) for v in demands):return False
    return True

def early_screen(P,coords,structured):
    tests=early_conditions(P,coords);memo={}
    def permits(scope,env):
        key=scope,tuple(env[i] for i in indices(scope))
        if key not in memo:memo[key]=matches(tests[scope],env,len(coords))
        return memo[key]
    passed=[];gross=0
    if structured:
        for head in range(32):
            choices=[(head if m&1 else 0)^(96 if m&2 else 0)^(128 if m&4 else 0) for m in range(8)]
            for triple in product(range(8),repeat=3):
                env=(head,*(choices[m] for m in triple));gross+=1
                if all(permits(scope,env) for scope in tests):passed.append((head,triple,env))
    else:
        for env in product(range(32),repeat=4):
            gross+=1
            if all(permits(scope,env) for scope in tests):passed.append(env)
    return gross,passed,{str(k):len(v) for k,v in tests.items()}

def assigned(P,coords,env):
    values=[]
    for x in env:values.append(sum(1<<coords[j] for j in indices(x)))
    shifts=[xor(values[j] for j in indices(m)) for m in range(16)]
    return {p:((v&P['mask'])^shifts[(v>>P['n'])&15],v>>(P['n']+4)) for p,v in P['forms'].items()}

def affine_meet(offset,directions,other_offset,subspace):
    # Keep precisely the current affine combinations lying in the other coset.
    quotient=Space();kernel=[]
    for v in directions:
        image=subspace.reduce(v)[0]
        rem,u=quotient.reduce(image)
        if rem:quotient.insert(image,v)
        elif u^v:kernel.append(u^v)
    rhs=subspace.reduce(offset^other_offset)[0]
    rem,u=quotient.reduce(rhs)
    return None if rem else (offset^u,kernel)

def required_2583(P,forms):
    conditions=[]
    for c,owners in P['groups'].items():
        bank=P['banks'][c]
        qbits=0
        for p in bank:qbits|=forms[p][1]
        if qbits!=1:continue
        free=Space();ref=None
        for p in bank:
            v,q=forms[p]
            if q:
                if ref is None:ref=v;continue
                v^=ref
            free.insert(v)
        defects={free.reduce(P['targets'][h])[0] for h in owners}-{0}
        if len(defects)>1:return None
        if defects:conditions.append((next(iter(defects))^ref,free))
    conditions.sort(key=lambda item:len(item[1].rows))
    require(conditions,'at least one demand requires the 2583 symbol')
    offset,first=conditions[0];directions=first.basis()
    for other,space in conditions[1:]:
        sol=affine_meet(offset,directions,other,space)
        if sol is None:return None
        offset,directions=sol
    return offset,directions

def storage(formal,forms,charts,h):
    total=0
    for c in charts:
        for p in formal['banks'][c]:
            require(not (forms[p][0]&h).bit_count()%2,'zero fixed sender component at '+str((c,p)))
            total+=1
    return total

def main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--write',action='store_true');ns=ap.parse_args()
    for s in json.loads((ROOT/'SOURCES.json').read_bytes())['files']:
        require(sha256((ROOT/s['local']).read_bytes()).hexdigest()==s['sha256'],s['local'])
    W=operator.load_json(ROOT/'source/inputs/WORD.json.gz',operator.WORD_GZIP,True)
    atlas=operator.Atlas(W['frames'])
    forward,reverse=[operator.run_tape(W,atlas,x) for x in (False,True)]
    require(forward.output==operator.expected_operator(False) and reverse.output==operator.expected_operator(True),'all original public rows and columns')
    coords=(43,320,321,322,323);h=sum(1<<j for j in coords)
    oldrow=forward.packets[2583].arrival.row
    take=lambda p:forward.packets[p].arrival.row
    F1=formal(W,(923,924,925,926))
    require([F1['routes'][p] for p in (923,924,925,926,927,2583,2584,2585)]==[(45,158),(45,160),(45,295),(45,322),(45,388),(388,517),(388,560),(388,1)],'exact surviving exterior and omitted routes')
    require([take(p) for p in (919,920,921,922)]==[1<<i for i in coords[1:]],'four exact chart-45 donor inputs')
    total,cd,early_groups=early_screen(F1,coords,False)
    require((total,len(cd))==(32**4,32),'unaffected final chart assignments')
    surviving=[]
    for code in cd:
        ff=assigned(F1,coords,code)
        sol=required_2583(F1,ff)
        if sol is not None:surviving.append((code,sol))
    require(len(surviving)==1,'unique joint exterior exit tuple')
    code,(forced,null)=surviving[0]
    require(code==(3,5,9,17) and forced==oldrow and not null,'unique unrestricted required late 2583')
    ff=assigned(F1,coords,code);count=storage(F1,ff,(1,388),h)
    require(count==539 and (forced&h).bit_count()%2==1,'order-independent nonzero obstruction')
    # Restoring the original pure paid packet puts a nonzero test value in 388.
    require((take(927)&h).bit_count()%2==1 and take(927)==1<<43,'original paid route canary')
    F2=formal(W,(924,1496,1497,1498));coords2=coords+(74,405,527)
    require(take(1122)==(1<<74)^(1<<405) and take(1495)==1<<527,'physical 160 donor histories')
    require([F2['routes'][p] for p in (924,1122,1495)]==[(45,160),(76,160),(0,160)],'source bank')
    gross,good,early_groups2=early_screen(F2,coords2,True)
    require(len(good)==1 and good[0][0:2]==(5,(7,3,1)),'unique quadruple at charts 45 and 160')
    ff2=assigned(F2,coords2,good[0][2])
    gens=[ff2[p][0] for p in (924,1122,1495,2023,2190)]
    allsrc=Space()
    for v in gens:allsrc.insert(v)
    require(len(allsrc.rows)==5 and all(not (v&h).bit_count()%2 for v in gens),'entire granted late source annihilated')
    count2=storage(F2,ff2,(1,),h)
    require(count2==537 and (P43:=F2['targets'][43])==1<<43 and (P43&h).bit_count()%2,'unreachable chart-1 terminal')
    require(atlas.grade(45,388)==5 and atlas.grade(1,388)==2 and atlas.grade(160,388)==4,'exact rational route prices')
    W0,caller,_,_,_,paid,prod,rat=common.baseline()
    rp={int(k):v for k,v in rat['signed']['paid'].items()};rt={int(k):v for k,v in rat['signed']['productive'].items()}
    outcomes={}
    for rate in map(common.D,('0.00388','0.0038800000000000083')):
        raw=common.moment(paid,prod,rate)
        prices={}
        for grade in (2,4):
            delta=common.scale(common.moment({grade:1},{5:1},rate),36)
            prices[grade]=dict(delta=common.display(delta),hypothetical_binary_margin=common.display(common.plus(raw,delta)))
        outcomes[str(rate)]=dict(base=common.display(raw),rational=common.display(common.moment(rp,rt,rate)),infeasible_route_marks=prices)
    result=dict(native=operator.WORD,three_chart=dict(early_assignments=total,after_early=len(cd),early_chart_groups=early_groups,unrestricted_solutions=len(surviving),only_code=code,required_late=hex(forced),freedom=len(null),checked_receiver_rows=count),four_chart=dict(early_assignments=gross,after_early=len(good),only_code=good[0][:2],early_chart_groups=early_groups2,late_granted_space_dimension=len(allsrc.rows),checked_terminal_rows=count2,missing_owner=43),separator=coords,complete_price=outcomes)
    out=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if ns.write:(ROOT/'RESULT.json').write_text(out)
    else:require(out==(ROOT/'RESULT.json').read_text(),'complete recomputed receipt')
    print('PASS',total,len(cd),len(surviving),count,gross,len(good),count2,flush=True)
if __name__=='__main__':main()
