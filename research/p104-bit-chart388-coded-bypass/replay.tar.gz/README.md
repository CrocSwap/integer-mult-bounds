# Seven variable paid equations around BIT receiver chart 388

Two attempts to reduce original paid move 927 fail on the same five-coordinate input. Both permit new binary linear payloads on multiple surviving senders and unrestricted decoding at all 138 terminal charts. The old grade-5 receipt at chart 388 carries input 43 from chart 45. The first attempted replacement brings data from chart 1 at grade 2. The second brings data from chart 160 at grade 4. The rational atlas verifies both proposed contacts. The exact invoice at κ = 0.00388 would favor either replacement if its operator could be implemented. [Pinned #7830 complete binary word](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15) · [Earlier #7924 paid-relay controls at 388](https://github.com/CrocSwap/integer-mult-bounds/tree/c83039ac63874fa9f9a2fd0bb650469886076dc6)

## Actual original contacts

The old chart-45 exits 923, 924, 925 and 926 carry input 43 plus input 320, 321, 322 or 323, respectively. The source has all five independent directions before the exits. The fifth exit, packet 927, sends input 43 alone to chart 388, which also receives packets 2023 and 2190. The three old exits from 388 are 2583 to 517, 2584 to 560 and 2585 to 1. Write the original 388 inputs as $x,u,v$. Those three exits carry $x+u+v,u+v,u$.

The verifier directly tracks primitive INIT, ADD, MOVE, SWAP and CLEAR records. It zeros 927, substitutes separate formal variables at the seven named surviving MOVE events in each model and preserves the other sender equations. At a terminal chart it grants every retained historical local vector, including the old program's private history. Final decoders may choose any XOR of these vectors. All other original sender equations propagate the consequences of the seven changed values.

## Grade-2 replacement through charts 1 and 388

Permit arbitrary independent source combinations on the four exits 923 through 926. Permit free choices on all three later equations 2583, 2584 and 2585. In addition to replacing 927, grant unlimited causal linear communication in either direction between charts 1 and 388. Unlimited traffic strictly relaxes the price and the number of candidate replacement messages.

Only 32 of the $32^4=1,048,576$ possible early tuples pass the 78 terminal charts which never observe any of the three late variables. Each test quotients by the outside components of the five-dimensional chart-45 input space. It evaluates the remaining short binary equations exactly and permits an independent decoder at each terminal. This step makes no restriction on any later payload.

Of the remaining terminal charts, 58 see packet 2583 and neither 2584 nor 2585. At each such chart eliminate the 2583 coefficient from the stocked rows to obtain a free subspace. Where a demanded row is missing, the one variable is confined to an affine translate of that free subspace. Two independent missing directions are impossible. Intersect the affine requirements across the 58 charts over the full 680-dimensional input space. There is exactly one feasible early tuple, namely the four original mixed values. Their required 2583 payload is the original $x+u+v$, with zero remaining freedom.

Consider the input with ones exactly on 43, 320, 321, 322 and 323. Each of the four early exits is zero. Set the three late symbols to zero in the formal primitive tape. The fixed components of all 539 old incoming-stock rows in pooled charts 1 and 388 are zero on this input. By chronological induction a homogeneous linear scheme in this pool can produce only zero on its first emission and every later emission. The same argument covers an arbitrary number of extra messages within the pool, and any causal reordering of the frozen exterior equations. The unique required 2583 value is one. The original paid 927 supplies that missing one in the original native word.

## Grade-4 replacement from chart 160

Retain the marked source chart 45 for 924, but allow its payload to be any of the 32 local combinations. Keep the other three original mixed chart-45 exits. Chart 160 receives 924, 1122, and 1495. The latter two equal $x_{74}+x_{405}$ and $x_{527}$ respectively. Allow arbitrary independent combinations of all three on the surviving sends 1496, 1497 and 1498. The proposed new nested transfer from chart 160 to 388 could carry an arbitrary combination of the same local stock. Allow each of the three late 388 outputs to choose its own coding.

The terminal charts unaffected by all three late outputs reduce the $32 × 8^3 = 16,384$ early assignments to one. It sends $x_{43}+x_{321}$ on 924. On 1496, 1497 and 1498 it sends, respectively, the sum of all three 160 arrivals, the sum of 924 and 1122, and 924 alone. These are the three old values, obtained as a consequence of the terminal conditions.

At 388 now grant the entire five-dimensional span of 924, 1122, 1495, 2023 and 2190 independently to every late output. This allows the effect of arbitrarily many new 160-to-388 transfers. The five-coordinate input above annihilates every generator and all 537 fixed components in the chart-1 terminal stock. Owner 43 at chart 1 requests its independent input, which evaluates to one. Consequently the proposed fourth chart and all seven surviving variable equations cannot realize this grade reduction.

## Scope and replay

The verifier imports the old literal word and its signed caller bills from the included pinned source, checks both old primitive orientations and re-extracts every formal stock from the primitive instructions. It recomputes the finite enumerations, affine intersections, separating input, exact grades, complete original binary and rational moments, and conditional arithmetic for the infeasible grade reductions. The trial rates are 0.00388 and 0.0038800000000000083. The latter is above the nominal rounded six-stage raw transfer threshold for the requested final saving. Neither attempt reaches the operator gate. [Finite transfer method](https://github.com/CrocSwap/integer-mult-bounds/pull/7975)

Run from the extracted directory in Python 3.12.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```

Earlier #7924 financed different incoming chains and demonstrated two literal, fully paid constructions with unchanged chart-388 exits and negative whole prices. Here the old exits themselves may change within the two specified networks. Mutating additional exterior equations, using another branch of the surrounding graph, or changing the source chart incidence of one of the surviving transmissions would require a separate construction.
