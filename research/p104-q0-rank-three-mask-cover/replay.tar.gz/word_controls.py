#!/usr/bin/env python3
"""Exact literal 3D controls, checked by two independent word replayers."""
import importlib.util
import json
import os
import sys
from pathlib import Path
import sympy as sp

HERE=Path(__file__).resolve().parent
SRC=HERE/'source'
os.environ['P104_GUIDANCE_SOURCE']=str(SRC)
sys.path.insert(0,str(SRC))
import attribution as at


def cases():
    separate={'schema':'q0-disjoint-3d-control','roles':3,'stages':6,
              'events':[['IDLE_ONE',0,[1,2]],['IDLE_ONE',1,[3,4]],['IDLE_ONE',2,[5,6]]],
              'diagonal':[[0,0,1,1,0,0,0,0],[0,0,0,0,1,1,0,0],[0,0,0,0,0,0,1,1]]}
    # Invertible P is a product of these elementary additions.  With all
    # three registers idled at stage 4, the middle block is the scalar D4 I.
    ops=[(0,1,1),(0,2,1),(1,0,1),(1,2,2),(2,0,1),(2,1,1)]
    forward=[['ADD',a,b,str(c)] for a,b,c in ops]
    backward=[['ADD',a,b,str(-c)] for a,b,c in reversed(ops)]
    shared={'schema':'q0-one-shared-stage-irreducible-3d-control','roles':3,'stages':4,
            'events':[['IDLE_ONE',0,[1]],['IDLE_ONE',1,[2]],['IDLE_ONE',2,[3]]] +
                     forward + [['IDLE_ONE',r,[4]] for r in range(3)] + backward,
            'diagonal':[[0,0,1,0,0,1],[0,0,0,1,0,1],[0,0,0,0,1,1]]}
    return {'disjoint':separate,'one_shared':shared}


def sympy_replay(c):
    # Independent direct row-operation implementation; no #7869 or #7903 code.
    n=c['roles']; k=c['stages']; D=sp.symbols('D1:'+str(k+1))
    R=sp.eye(n)
    for e in c['events']:
        if e[0]=='ADD':
            a,b,z=e[1],e[2],sp.Rational(e[3]); R[a,:]=R[a,:]+z*R[b,:]
        elif e[0]=='IDLE_ONE':
            R[e[1],:]=sp.prod(D[t-1] for t in e[2])*R[e[1],:]
        else:
            raise ValueError(e)
    expected=sp.diag(*[sp.prod(D[t]**dg[t+2] for t in range(k)) for dg in c['diagonal']])
    return all(sp.expand(x)==0 for x in R-expected)


def independent_projectors(c):
    n=c['roles'];P=sp.eye(n);ret=[]
    for pos,e in enumerate(c['events']):
        if e[0]=='ADD':
            a,b,z=e[1],e[2],sp.Rational(e[3]);P[a,:]=P[a,:]+z*P[b,:]
        elif e[0]=='IDLE_ONE':
            i=e[1];ret.append((pos,tuple(e[2]),P.inv()[:,i]*P[i,:]))
        else: raise ValueError(e)
    assert P==sp.eye(n)
    return ret


def run_one(name,c):
    legal,wellformed=at.q0check.legal(c)
    assert legal and wellformed and sympy_replay(c)
    masks,events=at.capture(c); projs=independent_projectors(c)
    n=c['roles'];k=c['stages']
    assert len(projs)==len(events)
    for e,(pos,S,p) in zip(events,projs):
        assert e['source_index']==pos and set(e['S'])==set(S)
        assert p==sp.Matrix(e['v'])*sp.Matrix([e['w']])
        assert p*p==p and p.trace()==1
    for t in range(1,k+1):
        ps=[p for _,S,p in projs if t in S]
        diag=sp.diag(*[int(t in m) for m in masks])
        assert sum(ps,sp.zeros(n))==diag
        assert all(p*q==sp.zeros(n) for i,p in enumerate(ps) for j,q in enumerate(ps) if i!=j)
    witness={}
    for strict in (False,True):
        _,_,_,_,sol=at.solve(events,masks,k,strict)
        assert sol is not None
        witness['strict' if strict else 'mask_only']=[{'event':events[i]['key'],
            'stages':sorted(events[i]['S']),'role':sol[i]} for i in range(len(events))]
    data={'four_root_pinned_q0_checker':True,'independent_direct_symbolic_D_replay':True,
          'projector_stage_sums_and_orthogonality':True,'roles':n,'stages':k,
          'masks':[sorted(x) for x in masks],'incidence_events':len(events),
          'witnesses':witness,'hosts':0,'q_targets_even':True}
    if name=='one_shared':
        assert len(projs)==6
        dense=projs[3][2]
        assert all(x!=0 for x in dense)
        E=[sp.diag(*[int(i==j) for i in range(n)]) for j in range(n)]
        # Each E_i p E_j is a nonzero multiple of the elementary E_ij.
        products=[E[i]*dense*E[j] for i in range(n) for j in range(n)]
        matrix=sp.Matrix.hstack(*[x.reshape(n*n,1) for x in products])
        assert matrix.rank()==n*n
        data.update({'dense_projector':str(dense.tolist()),
          'algebra_certificate':'nine products E_i p E_j, 0<=i,j<3',
          'algebra_rank':int(matrix.rank()),'algebra_dimension':n*n,
          'algebra_determinant':str(matrix.det())})
    return data


def main():
    words=cases(); out={}
    for name,c in words.items():
        (HERE/f'{name}-word.json').write_text(json.dumps(c,indent=2)+'\n')
        out[name]=run_one(name,c)
    bad=json.loads(json.dumps(words['one_shared']))
    bad['events'][9]=['IDLE_ONE',0,[2,4]]
    out['negative_mutated_idle']={'pinned_legal':at.q0check.legal(bad)[0],
                                  'independent_symbolic_replay':sympy_replay(bad)}
    assert out['negative_mutated_idle']=={'pinned_legal':False,'independent_symbolic_replay':False}
    (HERE/'WORD-CONTROLS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    for name in out:
        print(name,out[name].get('four_root_pinned_q0_checker',out[name]))
    print('PASS 3D irreducible algebra rank',out['one_shared']['algebra_rank'],'/9')

if __name__=='__main__':main()
