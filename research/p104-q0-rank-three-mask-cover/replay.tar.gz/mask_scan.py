#!/usr/bin/env python3
"""Exhaustive bounded rank-3 squarefree mask-only screen; no matrix search.

Enumerate all unordered endpoint triples over k labelled stages, and all
multisets of nonempty event masks whose per-stage counts match the endpoints.
Every event must fit at least one endpoint mask.  Additional necessary tests
are stage-local Hall matchings and individual trace-subset support.  A failed
global exact cover here is NOT a legal-word counterexample.
"""
import argparse
import itertools
import json
from pathlib import Path


def masks(m, k):
    return [i+1 for i in range(k) if m & (1 << i)]


def event_multisets(targets, k):
    n = 1 << k
    allowed = [e for e in range(1, n) if any(e & ~a == 0 for a in targets)]
    allowed.sort(key=lambda e: (-e.bit_count(), e))
    bits = [[i for i in range(k) if e >> i & 1] for e in allowed]
    remain = [sum((a >> i) & 1 for a in targets) for i in range(k)]
    current = []
    def gen(j):
        if j == len(allowed):
            if not any(remain):
                yield tuple(current)
            return
        # At least one remaining mask must cover every outstanding stage.
        for t, c in enumerate(remain):
            if c and not any(t in b for b in bits[j:]):
                return
        ids = bits[j]
        maximum = min(remain[t] for t in ids)
        e = allowed[j]
        for count in range(maximum + 1):
            for t in ids:
                remain[t] -= count
            current.extend([e] * count)
            yield from gen(j+1)
            if count:
                del current[-count:]
            for t in ids:
                remain[t] += count
    yield from gen(0)


def domains_for(events, targets):
    return [tuple(r for r, a in enumerate(targets) if not e & ~a) for e in events]


def stage_match(events, targets, domains, k):
    for t in range(k):
        ids = [i for i, e in enumerate(events) if e >> t & 1]
        def match(p, used):
            if p == len(ids):
                return True
            return any(not (used >> r & 1) and match(p+1, used | 1 << r)
                       for r in domains[ids[p]])
        if not match(0, 0):
            return False
    return True


def trace_subsets(events, targets):
    for a in targets:
        possible = {0}
        for e in events:
            if e & ~a:
                continue
            possible |= {v | e for v in tuple(possible) if not v & e}
        if a not in possible:
            return False
    return True


def solve(events, targets, domains):
    order = sorted(range(len(events)), key=lambda i:(len(domains[i]), -events[i].bit_count(), events[i], i))
    remaining = list(targets)
    choice = [None] * len(events)
    def rec(p):
        if p == len(order):
            return all(x == 0 for x in remaining)
        i = order[p]
        e = events[i]
        for r in domains[i]:
            if e & remaining[r] == e:
                remaining[r] ^= e
                choice[i] = r
                if rec(p+1):
                    return True
                remaining[r] ^= e
                choice[i] = None
        return False
    return choice if rec(0) else None


def cancellation_obstruction(events, targets, k):
    # Equal endpoint projectors P_s=P_t and incidence-set cancellation give
    # p_i=p_j.  If i,j also meet at some stage, stage orthogonality gives
    # p_i p_j=0, contradicting p_i^2=p_i != 0. Disjoint eligible
    # role subspaces also forbid equality of two nonzero projectors.
    for s in range(k):
        for t in range(s+1,k):
            if any(bool(a >> s & 1) != bool(a >> t & 1) for a in targets):
                continue
            only_s=[i for i,e in enumerate(events) if e >> s & 1 and not e >> t & 1]
            only_t=[i for i,e in enumerate(events) if e >> t & 1 and not e >> s & 1]
            if len(only_s)==len(only_t)==1:
                i,j=only_s[0],only_t[0]
                common_domains = any(not ((events[i] | events[j]) & ~a) for a in targets)
                if events[i] & events[j]:
                    return (s,t,i,j,'share_stage')
                if not common_domains:
                    return (s,t,i,j,'disjoint_role_support')
    return None


def saturation_obstruction(events, targets, domains):
    # For R a set of endpoint roles, |R| pairwise orthogonal nonzero
    # rank-one projectors supported in R must sum to its coordinate P_R.
    # A shared stage guarantees orthogonality.  Compare two saturated
    # cliques with the same R and cancel all but one projector on each side.
    n=len(targets)
    for role_bits in range(1,1 << n):
        roles={r for r in range(n) if role_bits >> r & 1}
        candidates=[i for i,d in enumerate(domains) if set(d) <= roles]
        cliques=[]
        for combo in itertools.combinations(candidates,len(roles)):
            if all(events[i] & events[j] for i,j in itertools.combinations(combo,2)):
                cliques.append(frozenset(combo))
        for left,right in itertools.combinations(cliques,2):
            a=left-right;b=right-left
            if len(a)==len(b)==1:
                i=next(iter(a));j=next(iter(b))
                if events[i] & events[j] or not (set(domains[i]) & set(domains[j])):
                    return {'roles':sorted(roles),'cliques':[sorted(left),sorted(right)],
                            'forced_equal_events':[i,j],
                            'conflict':'shared_stage' if events[i] & events[j] else 'disjoint_role_support'}
    return None

def render_case(targets, events, domains, k):
    return {'target_masks': [masks(a,k) for a in targets],
            'event_masks': [masks(e,k) for e in events],
            'eligible_roles_0_based': [list(d) for d in domains],
            'shared_stages': [t+1 for t in range(k) if sum(bool(a >> t & 1) for a in targets)>1]}


def scan(k):
    n = 1 << k
    counts = dict(endpoint_triples=0, multiset_cases=0, stage_matching=0,
                  trace_support=0, all_necessary=0, necessary_global=0,
                  necessary_no_global=0, at_most_one_shared=0,
                  at_most_one_shared_no_global=0,
                  no_global_eliminated_by_pair_cancellation=0,
                  no_global_after_pair_cancellation=0,
                  no_global_eliminated_by_saturation=0,
                  no_global_after_saturation=0)
    first_bad = None
    first_saturation_only = None
    for targets in itertools.combinations_with_replacement(range(n),3):
        counts['endpoint_triples'] += 1
        shared = sum(sum(bool(a >> t & 1) for a in targets)>1 for t in range(k))
        for events in event_multisets(targets,k):
            counts['multiset_cases'] += 1
            domains=domains_for(events,targets)
            local=stage_match(events,targets,domains,k)
            trace=trace_subsets(events,targets)
            counts['stage_matching'] += local
            counts['trace_support'] += trace
            if not (local and trace):
                continue
            counts['all_necessary'] += 1
            ok=solve(events,targets,domains) is not None
            counts['necessary_global'] += ok
            counts['necessary_no_global'] += not ok
            if shared <= 1:
                counts['at_most_one_shared'] += 1
                counts['at_most_one_shared_no_global'] += not ok
            if not ok:
                obstruction=cancellation_obstruction(events,targets,k)
                counts['no_global_eliminated_by_pair_cancellation'] += obstruction is not None
                counts['no_global_after_pair_cancellation'] += obstruction is None
                saturated=saturation_obstruction(events,targets,domains)
                counts['no_global_eliminated_by_saturation'] += saturated is not None
                counts['no_global_after_saturation'] += saturated is None
                if obstruction is None and saturated is not None and first_saturation_only is None:
                    first_saturation_only=render_case(targets,events,domains,k)
                    first_saturation_only['saturation_obstruction']=saturated
                if first_bad is None:
                    first_bad=render_case(targets,events,domains,k)
                    if saturated is not None:
                        first_bad['saturation_obstruction']=saturated
                    if obstruction is not None:
                        ss,tt,ii,jj,why=obstruction
                        first_bad['pair_cancellation']={'equal_endpoint_stages':[ss+1,tt+1],
                           'forced_equal_event_indices_0_based':[ii,jj],
                           'conflict':why}

    return {'stages':k,'counts':counts,'first_necessary_but_no_cover':first_bad,
            'first_needing_saturation':first_saturation_only}


if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('--max-k',type=int,default=4); p.add_argument('--out',default='MASK-SCAN.json')
    args=p.parse_args()
    result={'scope':'All endpoint-mask triples and compatible unordered nonempty-event multisets. Stage-local matching and individual trace support are necessary, not sufficient, for a symbolic word.',
            'rank':3, 'stages_labelled':True, 'endpoints_unordered_with_repetitions':True,
            'event_multisets_unordered_with_repetitions':True, 'results':[]}
    for k in range(1,args.max_k+1):
        a=scan(k);result['results'].append(a); print('k=',k,a['counts'],flush=True)
    Path(args.out).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
