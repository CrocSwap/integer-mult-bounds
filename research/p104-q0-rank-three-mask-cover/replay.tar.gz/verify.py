#!/usr/bin/env python3
"""Hash and independently regenerate the 3D mask-attribution evidence."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
GENERATED=['disjoint-word.json','one_shared-word.json','WORD-CONTROLS.json',
           'MASK-SCAN.json','INDEPENDENT-MASK-SCAN.json']

def digest(b): return hashlib.sha256(b).hexdigest()

def main():
    for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
        h,path=line.split('  ',1)
        assert digest((ROOT/path).read_bytes())==h, path
    raw=(ROOT/'SOURCE-7918.tar.gz').read_bytes()
    assert digest(raw)=='beab0fdb56c3b3fabbe9650048d24c784ea82c3ef45e744ab240462f1b00403e'
    with tarfile.open(ROOT/'SOURCE-7918.tar.gz','r:gz') as tf:
        for original,copy in [('./attribution.py','source/attribution.py'),
            ('./source/data/q0_callers/check.py','source/data/q0_callers/check.py')]:
            assert tf.extractfile(original).read()==(ROOT/copy).read_bytes()
    assert digest((ROOT/'source/data/q0_callers/check.py').read_bytes())=='2233655e29abce6ad1282e6da52ea70a77e7cb2f71b331f78834c165955cd504'
    with tempfile.TemporaryDirectory(prefix='p104-mask3-') as temp:
        w=Path(temp)/'packet'
        shutil.copytree(ROOT,w,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.log'))
        env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
        env.pop('P104_GUIDANCE_SOURCE',None);env.pop('P104_ATTRIBUTION_SOURCE',None)
        for script in ('word_controls.py','mask_scan.py','crosscheck_masks.py'):
            subprocess.run([sys.executable,'-B',script],cwd=w,env=env,check=True)
        for name in GENERATED:
            assert (ROOT/name).read_bytes()==(w/name).read_bytes(),name
        out=json.loads((w/'MASK-SCAN.json').read_text())
        assert [x['stages'] for x in out['results']]==[1,2,3,4]
        assert all(x['counts']['no_global_after_saturation']==0 for x in out['results'])
    print('PASS source hashes and independent byte-identical regeneration',flush=True)

if __name__=='__main__':main()
