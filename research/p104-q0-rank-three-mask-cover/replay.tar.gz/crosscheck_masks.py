#!/usr/bin/env python3
"""Independent small-bound mask enumeration and saturation-certificate replay.

This program imports neither mask_scan nor the Q0 projectors. It enumerates
all event multisets FIRST, buckets by stage degree, then assigns endpoint
triples. Exact-cover DP and independent saturation checks classify each case.
"""
import itertools
import json
from collections import defaultdict
from pathlib import Path


def all_event_buckets(k):
    universe=range(1,1<<k); degree=[0]*k; word=[]; buckets=defaultdict(list)
    def gen(e):
        if e==(1<<k):
            buckets[tuple(degree)].append(tuple(word));return
        indices=[t for t in range(k) if e>>t&1]
        cap=min(3-degree[t] for t in indices)
        for count in range(cap+1):
            for t in indices: degree[t]+=count
            word.extend([e]*count)
            gen(e+1)
            if count: del word[-count:]
            for t in indices: degree[t]-=count
    gen(1);return buckets


def subset_family(events, target):
    # Bitset of event indices, rather than stage unions, independently checks
    # each role's available exact covers (and hence trace support).
    options=[]
    for subset in range(1<<len(events)):
        stages=0
        for i,e in enumerate(events):
            if subset>>i&1:
                if stages&e: break
                stages|=e
        else:
            if stages==target: options.append(subset)
    return options


def all_assignable(families, n):
    complete=(1<<n)-1
    for a in families[0]:
        for b in families[1]:
            if a&b: continue
            for c in families[2]:
                if (a|b|c)==complete and not ((a|b)&c): return True
    return False


def hall(events,targets,domains,k):
    for t in range(k):
        es=[i for i,e in enumerate(events) if e>>t&1]
        rs=[r for r,a in enumerate(targets) if a>>t&1]
        if not any(all(r in domains[i] for i,r in zip(es,perm)) for perm in itertools.permutations(rs)):
            return False
    return True


def saturation(events,domains):
    for Rnum in range(1,8):
        R={i for i in range(3) if Rnum>>i&1}
        sets=[]
        for subset in itertools.combinations(range(len(events)),len(R)):
            if not all(set(domains[i]).issubset(R) for i in subset): continue
            if all(events[i]&events[j] for i,j in itertools.combinations(subset,2)):
                sets.append(set(subset))
        for a,b in itertools.combinations(sets,2):
            d1=a-b;d2=b-a
            if len(d1)!=1 or len(d2)!=1: continue
            i=next(iter(d1));j=next(iter(d2))
            if events[i]&events[j] or not (set(domains[i])&set(domains[j])):
                return True
    return False


def scan(k):
    buckets=all_event_buckets(k)
    counts={'endpoint_triples':0,'multiset_cases':0,'stage_matching':0,
            'trace_support':0,'all_necessary':0,'necessary_global':0,
            'necessary_no_global':0,'at_most_one_shared':0,
            'at_most_one_shared_no_global':0,'no_global_eliminated_by_saturation':0,
            'no_global_after_saturation':0}
    for T in itertools.combinations_with_replacement(range(1<<k),3):
        counts['endpoint_triples']+=1
        deg=tuple(sum((a>>t)&1 for a in T) for t in range(k))
        shared=sum(d>1 for d in deg)
        for E in buckets[deg]:
            D=[tuple(r for r,a in enumerate(T) if e&a==e) for e in E]
            if any(not d for d in D): continue
            counts['multiset_cases']+=1
            loc=hall(E,T,D,k)
            families=[subset_family(E,a) for a in T]
            trace=all(bool(f) for f in families)
            counts['stage_matching']+=loc;counts['trace_support']+=trace
            if not (loc and trace): continue
            counts['all_necessary']+=1
            good=all_assignable(families,len(E))
            counts['necessary_global']+=good;counts['necessary_no_global']+=not good
            if shared<=1:
                counts['at_most_one_shared']+=1
                counts['at_most_one_shared_no_global']+=not good
            if not good:
                blocked=saturation(E,D)
                counts['no_global_eliminated_by_saturation']+=blocked
                counts['no_global_after_saturation']+=not blocked
    return counts


def main():
    source=json.loads(Path('MASK-SCAN.json').read_text());out=[]
    for item in source['results']:
        k=item['stages'];counts=scan(k)
        assert all(counts[n]==item['counts'][n] for n in counts),(k,counts,item['counts'])
        out.append({'stages':k,'matched_independently':True,'counts':counts})
        print('PASS independent enumeration and saturation',k,counts['multiset_cases'],flush=True)
    Path('INDEPENDENT-MASK-SCAN.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')

if __name__=='__main__':main()
