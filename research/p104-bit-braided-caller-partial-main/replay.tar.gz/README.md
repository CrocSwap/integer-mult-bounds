# Changed-contact braids and a partial-main control

No κ improvement was found. Two explicit caller schedules change true
native contacts and ownership across the two chains. One has an exact body
obstruction to seam-only repair; the other has a fully replayed six-QUERY
formal word but a strongly negative complete signed invoice. A subsequent
one-port partial-main pivot yields the desired unary `qD` algebraically,
but its 37-root caller still needs four seam QUERYs and its total invoice
is negative even if the discarded native output is free.

The input caller is [#7952](https://github.com/CrocSwap/integer-mult-bounds/pull/7952)
at `755fcee748d4e90feda281f27d06e7bc66ecf954`. The
[#7964](https://github.com/CrocSwap/integer-mult-bounds/pull/7964) control
is pinned at `1f90b620855e08b6a941a304ed25eda5600c0deb`; its fixed
two-IDLE model does not cover the changed LOCAL contacts here. Native
word and complete invoice are from [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830)
at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`.

## Two changed native-contact designs

In the frozen caller, stage 1 has two disjoint LOCALs `(0,1)` and `(19,20)`.
In each design the second remains fixed and all 36 actual native calls,
their helper charges and the other 32 IDLE masks remain fixed. The first
LOCAL is changed together with its ordinary conjugating additions:

* **Cross-chain reused arm:** replace `(0,1)` with `(0,27)`. Arm 27 is
  contacted by hub 19 at stage 8 as well; arm 1 bypasses stage 1. Its
  body-grade changes are `64→57` on role 1 and `15→22` on role 27.
  The `q=1` body operator remains diagonal, but the actual `ε=q+1`
  residual has two off-diagonal terms whose body monomials cannot be made
  by any constant seam QUERY matrix. For output 0, input 27, the actual
  monomial uses all stages 1–18 whereas a seam query can use only stages
  `1,8,…,18`. The reciprocal entry also has mismatched monomials. Head
  omissions change only diagonal entries and cannot repair these two terms.
  Retiming IDLEs, extra body routing or queries outside this seam remain
  possible directions, with their own required price and physical proof.
* **Hub-bypassing arm bridge:** replace `(0,1)` with `(8,27)`. This
  connects two stage-8 arms belonging to opposite chains, bypasses hub 0
  at stage 1, and leaves `(19,20)` disjoint. The changed root grades are
  `127→120`, `64→57`, and twice `15→22`. Its actual body monomials
  do align at the seam, but the necessary specialized `ε` rank is six.
  `solve_b.py` factors that exact seam into six square-zero rank-one
  updates and constructs the complete **578-event** formal caller, with
  504 ADDs, 36 LOCALs, 32 IDLEs and six QUERYs. Both 38² formal
  orientations pass, and independent code checks the actual 36 disjoint
  calls and full paid/productive histograms. Its full BIT margin is
  approximately `−212.83981418681764` at `0.003879928046156` and
  `−212.84019699574201` at `0.003879929046155`. Its modeled ordinary
  count is 935,467,158,336 and backing 5,146,176, both within the source
  allowances but worse than the frozen caller.

`RESULT.json` also enumerates **9,178** combinations of at most three
omitted root heads for each design. This is an optimistic price-only scan:
it grants that the minimum ε rank is achievable and does not establish
that those modified targets are admissible. Its best upper bounds on
signed change remain `−214.5867138813` for the reused-arm design and
`−210.6919287900` for the arm bridge at the first trial. This bounded
scan does not rule out other schedules, additional target changes or
different supplier constructions.

## One-port partial-main pivot

For the actual native word, take port `p=0`, initialize its Y input to
zero, retain its Y output and project out its X output. The untouched 110
other main pairs and 458 helper owners are retained. The actual selected
native matrix is **679×679** and full rank. Its adjoint restriction is
exactly the transpose. At the lifted caller level the two-role map is

`(X,0) --LOCAL_s--> (D_s X, q D_s X) --project--> q D_s X`.

The transpose uses the opposite inclusion/projection and yields the same
unary scalar. This mathematical projection does not prove that the live
old X value may be discarded physically.

As an interspersed test, `partial_main.py` removes one port's original
stage-1 arm role 1 and its grade-56 IDLE; it inserts the unary return at
that same stage while all other port callers and all 36 shared native bills
remain in place. The explicit **390-event**, 37-root formal caller passes
all 37² forward and 37² adjoint coefficients. The remaining seam rank is
still **four**, with four actual formal QUERYs, so the unary head does not
save a seam query in this schedule. The one-port productive grade-64 target
is also removed. Even granting free disposal, its complete BIT signed
change is `H(56)−H(64) = −7.84339043185598` at the first trial and
`−7.84339039187440` at the near trial, where `H(r)=r^(1−κ)`.

An explicit clean two-field *formal* replacement is

`LOCAL_s(X,Y); QUERY(X,Y); SWAP(X,Y); QUERY(X,Y)`.

It acts as `qD_s I` on both fields in both orientations, so a zero scratch
is restored. It costs two extra grade-one QUERYs, and the corresponding
one-port signed change is `−9.84339043185598` at the first trial. A
216-triple check rules out clean `qD_s I` with only one QUERY and arbitrary
ordinary `GL(2,F2)` changes around this one LOCAL, within that exact
two-field model. Physical chart contacts, endpoint binding, any dirty
owned-erasure permission, and finite precision for the changed caller are
not established.

The mixed-port ordinary model reserves 38 physical fields for the reduced
37-root port, including temporary space. It gives 934,158,609,464 records
and 3,004,896 backing units for free projection, or 934,170,187,600 and
3,005,156 with the two-QUERY clean restore. These are modeled envelopes,
not physical certificates. All prices include the original 36 native
charges; the unchanged 48-call rational companion has margins about
`+0.212262470163347` and `+0.211243929926514` at the two trials.

## Reproduce

Run CPython with assertions enabled in this directory:

```sh
(cd source && sha256sum -c SHA256SUMS && python3 -I -B verify.py)
python3 -I -B screen.py > RESULT.json
python3 -I -B solve_b.py > BRIDGE-RESULT.json
python3 -I -B partial_main.py > PARTIAL-RESULT.json
```

The independent baseline caller and rational replay receipts are retained
under `independent/`. The `UNARY` event in the partial caller is a formal
inclusion/projection placeholder, not an independently established physical
instruction. Native dirty retirements and inherited all-columns,
owned-erasure, compiler, precision-tape and analytic-recovery premises
remain relevant.
