#!/usr/bin/env python3
"""Reproduce all braid and partial-main receipts in an isolated copy."""
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
import json,shutil,subprocess,sys,time
R=Path(__file__).resolve().parent;C=R/'cold'
if C.exists():shutil.rmtree(C)
C.mkdir()
shutil.copytree(R/'source',C/'source')
shutil.copytree(R/'independent'/'inputs',C/'independent'/'inputs')
for x in ('replay_bit.py','replay_caller.py','replay_rational.py'):
 shutil.copy2(R/'independent'/x,C/'independent'/x)
for x in ('screen.py','solve_b.py','partial_main.py'):
 shutil.copy2(R/x,C/x)
records=[]
def run(cwd,args,target,expected=None):
 t=time.monotonic()
 p=subprocess.run(args,cwd=C/cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 (C/target).write_bytes(p.stdout)
 if expected:assert p.stdout==(R/expected).read_bytes(),expected
 records.append({'cwd':cwd,'command':args,'seconds':round(time.monotonic()-t,3),
  'sha256':sha256(p.stdout).hexdigest(),'byte_identical_to':expected,'stderr':p.stderr.decode()})
run('source',['sha256sum','-c','SHA256SUMS'],'source-manifest.log')
run('source',[sys.executable,'-I','-B','verify.py'],'source-verify.log')
run('independent',[sys.executable,'-I','-B','replay_caller.py'],'independent/CALLER-REPLAY.json','independent/CALLER-REPLAY.json')
run('independent',[sys.executable,'-I','-B','replay_rational.py'],'independent/RATIONAL-REPLAY.json','independent/RATIONAL-REPLAY.json')
for script,output in (('screen.py','RESULT.json'),('solve_b.py','BRIDGE-RESULT.json'),('partial_main.py','PARTIAL-RESULT.json')):
 run('.',[sys.executable,'-I','-B',script],output,output)
for candidate in ('BRIDGE-CALLER.json','PARTIAL-CALLER.json'):
 assert (C/candidate).read_bytes()==(R/candidate).read_bytes()
out={'status':'PASS','completed_utc':datetime.now(timezone.utc).isoformat(),'steps':records,'candidate_bytes_identical':True}
(R/'COLD-REPLAY.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
