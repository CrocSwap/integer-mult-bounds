#!/usr/bin/env python3
"""One-port partial native call and 37-root interspersed caller control."""
from collections import Counter
from copy import deepcopy
from pathlib import Path
from hashlib import sha256
import gzip, json, random, sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'source')]
import common as C
import caller as B
import screen as S
from itertools import product

def formal(c,rev=False):
 n=c['roles'];rows=[{0:1<<i} for i in range(n)]
 seq=reversed(c['events']) if rev else c['events']
 for op,*arg in seq:
  if op in ('ADD','QUERY'):
   a,b=arg[::-1] if rev else arg
   rows[a]=C.literal.add(rows[a],C.literal.shift(rows[b],0,op=='QUERY'))
  elif op=='SWAP':
   a,b=arg;rows[a],rows[b]=rows[b],rows[a]
  elif op=='LOCAL':
   stage,a,b=arg
   if rev:a,b=b,a
   d=C.literal.caller_monomial([stage])
   rows[a],rows[b]=C.literal.shift(rows[a],d),C.literal.shift(C.literal.add(rows[b],C.literal.shift(rows[a],0,True)),d)
  elif op=='IDLE_ONE':
   a,mask=arg;rows[a]=C.literal.shift(rows[a],C.literal.caller_monomial(mask))
  elif op=='UNARY':
   stage,a=arg;rows[a]=C.literal.shift(rows[a],C.literal.caller_monomial([stage]),True)
  else:raise ValueError(op)
 return rows

def body(c):
 rows=S.q1(formal(c));out=[]
 for i,r in enumerate(rows):
  assert len(r)==1
  (m,x),=r.items();assert x==1<<i;out.append(m)
 return out

def cells(c,diag):
 out={}
 for i,row in enumerate(formal(c)):
  for m,v in row.items():
   if m&1:
    for j in S.bits(v):out.setdefault((i,j),set()).symmetric_difference_update([m&~1])
  out.setdefault((i,i),set()).symmetric_difference_update([diag[i]])
 return {k:v for k,v in out.items() if v}

def factors(matrix):
 n=len(matrix);p={};u=[]
 for j in range(n):
  v=sum(((r>>j)&1)<<i for i,r in enumerate(matrix));x=v
  while x and x.bit_length() in p:x^=p[x.bit_length()]
  if x:p[x.bit_length()]=x;u.append(v)
 piv={}
 for k,v in enumerate(u):
  x=v;l=1<<k
  while x and x.bit_length() in piv:
   y,z=piv[x.bit_length()];x^=y;l^=z
  assert x;piv[x.bit_length()]=(x,l)
 v=[0]*len(u)
 for j in range(n):
  x=sum(((r>>j)&1)<<i for i,r in enumerate(matrix));l=0
  while x:
   y,z=piv[x.bit_length()];x^=y;l^=z
  for k in S.bits(l):v[k]|=1<<j
 rr=random.Random(91877)
 for trial in range(30000):
  a,b=u.copy(),v.copy()
  for _ in range(20+trial%12):
   i,j=rr.sample(range(len(u)),2)
   if rr.randrange(2):a[i],a[j]=a[j],a[i];b[i],b[j]=b[j],b[i]
   else:a[i]^=a[j];b[j]^=b[i]
  if all((x&y).bit_count()%2==0 for x,y in zip(a,b)):
   rebuilt=[0]*n
   for x,y in zip(a,b):
    for i in S.bits(x):rebuilt[i]^=y
   assert rebuilt==matrix
   return a,b,trial+1
 raise ValueError('factorization not found')

def indexed_event(e):
 op,*arg=e
 def m(x):
  assert x!=1
  return x-(x>1)
 if op in ('ADD','QUERY','SWAP'):return [op,m(arg[0]),m(arg[1])]
 if op=='LOCAL':return [op,arg[0],m(arg[1]),m(arg[2])]
 if op=='IDLE_ONE':return [op,m(arg[0]),arg[1]]
 raise ValueError(op)

def two_field_one_query_screen():
 """LOCAL(q), one QUERY(q), arbitrary ordinary GL2 around/between."""
 gl=[a for a in product(range(4),repeat=2) if a[0] and a[1] and a[0]!=a[1]]
 def mul(a,b):return tuple((b[0] if x&1 else 0)^(b[1] if x&2 else 0) for x in a)
 def xor(a,b):return tuple(x^y for x,y in zip(a,b))
 ident=(1,2); l0=(1,3); l1=(0,1); q0=(3,2); q1=(2,0)
 good=0
 for a,b,c in product(gl,repeat=3):
  ev=mul(a,mul(q0,mul(b,mul(l0,c))))
  ep=xor(mul(a,mul(q1,mul(b,mul(l0,c)))),mul(a,mul(q0,mul(b,mul(l1,c)))))
  good+=ev==ident and ep==ident
 assert good==0
 return {'ordinary_basis_triples_tested':len(gl)**3,'achieve_clean_qD_identity':good}

def main():
 orig=json.loads(gzip.decompress((ROOT/'source/CALLER.json.gz').read_bytes()))
 assert orig['events'][:4]==[['ADD',0,1],['LOCAL',1,0,1],['ADD',1,0],['ADD',0,1]]
 assert orig['events'][72]==['IDLE_ONE',1,list(range(2,10))]
 # Proposed specialization drops input/output role 1 and inserts one native
 # projected unary action on role 0 at the original first LOCAL site.
 prefix=[['UNARY',1,0]]+[indexed_event(e) for i,e in enumerate(orig['events'][4:88],4) if i!=72]
 suffix=[indexed_event(e) for e in orig['events'][236:]]
 template={'roles':37,'stages':18,'events':prefix+suffix}
 diag=[C.literal.caller_monomial(x['stages']) for i,x in enumerate(orig['diagonal']) if i!=1]
 assert body(template)==diag
 pr={'roles':37,'stages':18,'events':prefix};p=body(pr)
 post=[C.literal.caller_monomial(sorted(set(S.stages(x))-set(S.stages(y)))) for x,y in zip(diag,p)]
 m=[0]*37
 for (i,j),vals in cells(template,diag).items():
  assert vals=={post[i]+p[j]};m[i]^=1<<j
 assert S.rank(m)==4
 u,v,tries=factors(m);seam=B.compact(sum((B.query(a,b) for a,b in zip(u,v)),[]))
 assert Counter(e[0] for e in seam)['QUERY']==4
 word={**template,'events':prefix+seam+suffix}
 expected=[{d|1:1<<i} for i,d in enumerate(diag)]
 assert formal(word)==expected==formal(word,True)
 raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode()
 (ROOT/'PARTIAL-CALLER.json').write_bytes(raw+b'\n')
 # Literal two-role one-stage full/adjoint semantics and clean scratch.
 def toy(events):return {'roles':2,'stages':1,'events':events}
 one=toy([['LOCAL',1,0,1]])
 ff=formal(one);aa=formal(one,True);d=C.literal.caller_monomial([1])
 # Inclusion X, Y=0 and projection Y; transpose is inclusion Y, projection X.
 assert ff[1].get(d|1,0)&1 and aa[0].get(d|1,0)&2
 assert all((m==d|1 or not (mask&1)) for m,mask in ff[1].items())
 assert all((m==d|1 or not (mask&2)) for m,mask in aa[0].items())
 clean=toy([['LOCAL',1,0,1],['QUERY',0,1],['SWAP',0,1],['QUERY',0,1]])
 assert formal(clean)==[{d|1:1},{d|1:2}]==formal(clean,True)
 broken=toy(clean['events'][:-1]);assert formal(broken)!=formal(clean) and formal(broken,True)!=formal(clean,True)
 one_query=two_field_one_query_screen()
 # Actual pinned native inclusion/projection: 679 x 679 each orientation.
 w,old,_,np,nt,P,T,rat=C.baseline();charts=C.literal.Charts(w['frames'])
 f,fd,_=C.literal.tape(w,charts);a,ad,_=C.literal.tape(w,charts,adjoint=True)
 ins=[i for i in range(680) if i!=111];outs=[i for i in range(680) if i!=0]
 reduced=[sum(((f[oi]>>ij)&1)<<j for j,ij in enumerate(ins)) for oi in outs]
 reverse=[sum(((a[ii]>>oj)&1)<<j for j,oj in enumerate(outs)) for ii in ins]
 assert all(((reduced[i]>>j)&1)==((reverse[j]>>i)&1) for i in range(679) for j in range(679))
 assert S.rank(reduced)==S.rank(reverse)==679
 assert fd['paid']==ad['paid']==np and fd['erase_dirty']==ad['erase_dirty']==3554
 # One port loses its original role-1 target and role-1 IDLE. All 36 shared
 # native bills and all 110 unmodified port callers remain fixed.
 pp=P.copy();pp[56]-=1;tt=T.copy();tt[64]-=1
 cleanp=pp.copy();cleanp[1]+=2
 # Apply the published ordinary accounting per port, reserving 38 physical
 # fields even on the 37-root path for its temporary.  This is a modeled
 # envelope, not a physical ownership or precision certificate.
 native_bank=w['owned_fields']+w['public']+4
 native_flow=16*native_bank*len(w['program'])
 baseops=Counter(e[0] for e in orig['events']);partops=Counter(e[0] for e in word['events'])
 def ordinary(pr,ta,partial,all_base=False):
  # port multiplicity, ADD, SWAP, QUERY, native calls, roles reserved,
  # total events, IDLE_ONE
  origprofile=(111 if all_base else 110,baseops['ADD'],baseops['SWAP'],baseops['QUERY'],36,38,len(orig['events']),baseops['IDLE_ONE'])
  profiles=[origprofile]
  if not all_base:
   profiles.append((1,partops['ADD'],1 if partial=='clean' else 0,
                    partops['QUERY']+(2 if partial=='clean' else 0),36,38,
                    len(word['events'])+(3 if partial=='clean' else 0),partops['IDLE_ONE']))
  caller=sum(n*(8*(add+3*sw)+256*(calls+q+roles)) for n,add,sw,q,calls,roles,ev,idle in profiles)
  groups=4*(sum(pr.values())+sum(ta.values()))+8*sum(n*(calls+idle) for n,add,sw,q,calls,roles,ev,idle in profiles)
  routes=groups*80*(134**2+134)
  owned=36*(w['owned_fields']+4)+2*sum(n*roles*ev for n,add,sw,q,calls,roles,ev,idle in profiles)+16*sum(n*(calls+q+roles) for n,add,sw,q,calls,roles,ev,idle in profiles)
  return {'ordinary_records':36*native_flow+caller+routes,'owned_backing':owned,
          'caller_bank_transits':caller,'route_groups':groups,'route_records':routes}
 assert ordinary(P,T,None,True)['ordinary_records']==C.literal.ordinary(w,orig,baseops,P,T)['ordinary_records']
 assert ordinary(P,T,None,True)['owned_backing']==C.literal.ordinary(w,orig,baseops,P,T)['owned_backing']
 rates={}
 for k in C.RATES:
  base=C.moment(P,T,k);projected=C.moment(pp,tt,k);restored=C.moment(cleanp,tt,k)
  rates[str(k)]={'original_bit':S.show(base),'projected_bit':S.show(projected),
   'projected_delta':S.show(C.minus(projected,base)),
   'clean_two_extra_query_bit':S.show(restored),'clean_two_extra_query_delta':S.show(C.minus(restored,base)),
   'rational_48_call_unchanged':S.show(C.moment(rat['signed']['paid'],rat['signed']['productive'],k))}
  assert C.minus(projected,base)[1]<0
 print(json.dumps({'status':'PARTIAL_FORMAL_CONTROL_NO_GAIN',
  'single_native_port':'X arbitrary, Y=0; retain Y and project X; transpose uses opposite inclusion/projection',
  'native_actual_679_by_679_forward_and_adjoint_full_rank':True,
  'native_actual_36_shared_calls_and_paid_charges_unchanged':True,
  'native_dirty_private_retirements_forward_and_adjoint':3554,
  'one_port_caller_live_roots':37,'unary_stage':1,'omitted_original_role':1,
  'query_residual_rank':S.rank(m),'seam_queries':4,'seam_factorization_attempts':tries,
  'caller_events':len(word['events']),'caller_event_counts':dict(Counter(e[0] for e in word['events'])),
  'caller_canonical_sha256':sha256(raw).hexdigest(),
  'formal_forward_and_adjoint_coefficients_each':37**2,
  'formal_clean_embedding':clean['events'],'clean_embedding_paid_querys':2,
  'clean_embedding_is_qD_times_identity_on_two_fields':True,
  'one_query_two_field_constant_basis_screen':one_query,
  'zero_cost_projection_requires_owned_lifetime_and_discard_proof':True,
  'partial_caller_target_dropped_grade':64,'partial_caller_paid_idle_dropped_grade':56,
  'modeled_ordinary_baseline':ordinary(P,T,None,True),
  'modeled_ordinary_projected':ordinary(pp,tt,'projected'),
  'modeled_ordinary_clean_restore':ordinary(cleanp,tt,'clean'),
  'rates':rates,
  'scope':'One dropped root at one original port; other 110 ports and all native supplies unchanged. Formal clean scratch uses two extra grade-one queries. Precision and physical embedding remain open.'},sort_keys=True,indent=2))

if __name__=='__main__':main()
