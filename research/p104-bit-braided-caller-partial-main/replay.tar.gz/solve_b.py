#!/usr/bin/env python3
"""Synthesize the six-QUERY arm-bridge control, then verify both operators."""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import gzip, importlib.util, json, random, sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
sys.path.insert(0,str(ROOT))
import common as C
import caller as B
import screen as S

def independent_columns(matrix):
 piv={};cols=[]
 for j in range(38):
  v=sum(((row>>j)&1)<<i for i,row in enumerate(matrix));x=v
  while x and x.bit_length() in piv:x^=piv[x.bit_length()][0]
  if x:
   k=len(cols);cols.append(v);piv[x.bit_length()]=(x,1<<k)
 # Rebuild labeled elimination so that each pivot is an actual combination.
 piv={}
 for k,v in enumerate(cols):
  x=v;label=1<<k
  while x and x.bit_length() in piv:
   z,l=piv[x.bit_length()];x^=z;label^=l
  assert x;piv[x.bit_length()]=(x,label)
 vs=[0]*len(cols)
 for j in range(38):
  x=sum(((row>>j)&1)<<i for i,row in enumerate(matrix));label=0
  while x:
   z,l=piv[x.bit_length()];x^=z;label^=l
  for k in S.bits(label):vs[k]|=1<<j
 reconstructed=[0]*38
 for u,v in zip(cols,vs):
  for i in S.bits(u):reconstructed[i]^=v
 assert reconstructed==matrix
 return cols,vs

def squarezero_factors(matrix):
 u0,v0=independent_columns(matrix);n=len(u0)
 assert n==6
 rnd=random.Random(340318)
 for attempt in range(30000):
  u,v=u0.copy(),v0.copy()
  for _ in range(24+attempt%16):
   a,b=rnd.sample(range(n),2)
   if rnd.randrange(2):u[a],u[b]=u[b],u[a];v[a],v[b]=v[b],v[a]
   else:u[a]^=u[b];v[b]^=v[a]
  if all((a&b).bit_count()%2==0 for a,b in zip(u,v)):
   return u,v,attempt+1
 raise ValueError('no six square-zero rank-one factorization found')

def main():
 original=json.loads(gzip.decompress((ROOT/'source/CALLER.json.gz').read_bytes()))
 c=deepcopy(original);S.set_first_contact(c,8,27);body=S.body_diagonal(c)
 pre=deepcopy(c);pre['events']=pre['events'][:S.CUT];prefix=S.body_diagonal(pre)
 suffix=[]
 for x,y in zip(body,prefix):
  suffix.append(C.literal.caller_monomial(sorted(set(S.stages(x))-set(S.stages(y)))))
 cells=S.eps_cells(S.bare(c),body,[1]*38);matrix=[0]*38
 for (i,j),values in cells.items():
  assert values=={prefix[j]+suffix[i]}
  matrix[i]^=1<<j
 assert S.rank(matrix)==6
 u,v,attempts=squarezero_factors(matrix)
 seam=B.compact(sum((B.query(a,b) for a,b in zip(u,v)),[]))
 assert Counter(e[0] for e in seam)['QUERY']==6
 c['events']=c['events'][:88]+seam+c['events'][236:]
 c['diagonal']=[{'q':1,'stages':S.stages(m)} for m in body]
 raw=json.dumps(c,sort_keys=True,separators=(',',':')).encode()
 expected=[{C.literal.caller_monomial(x['stages'])|x['q']:1<<i} for i,x in enumerate(c['diagonal'])]
 assert C.literal.caller_rows(c)==expected==C.literal.caller_rows(c,True)
 word,old,_,np,nt,P,T,rat=C.baseline();ops=Counter(e[0] for e in c['events'])
 p,t=C.literal.paired_invoice(c,np,nt,ops)
 res=C.literal.ordinary(word,c,ops,p,t)
 spec=importlib.util.spec_from_file_location('r',ROOT/'independent/replay_caller.py')
 r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
 _,calls=r.validate_structure(c)
 assert len(calls)==36 and r.symbolic(c)==38**2 and r.symbolic(c,True)==38**2
 inf=r.base.frames(word); p2,t2,calls2,_,_=r.base.invoice(word,inf,c)
 assert p2==p and t2==t and len(calls2)==36
 rates={}
 for k in C.RATES:
  mm=C.moment(p,t,k); orig=C.moment(P,T,k)
  rates[str(k)]={'changed_bit':S.show(mm),'delta_vs_original':S.show(C.minus(mm,orig)),
                  'rational_companion':S.show(C.moment(rat['signed']['paid'],rat['signed']['productive'],k))}
  assert mm[1]<0
 (ROOT/'BRIDGE-CALLER.json').write_bytes(raw+b'\n')
 print(json.dumps({'status':'EXACT_FORMAL_BRAID_BUT_NEGATIVE_INVOICE',
   'scope':'one changed stage-1 native contact, six-query explicit seam; changed terminal masks, unchanged fixed supplier charges, physical rebinding unproved',
   'caller_canonical_sha256':sha256(raw).hexdigest(), 'events':len(c['events']), 'event_counts':dict(ops),
   'query_factors':[[list(S.bits(a)),list(S.bits(b))] for a,b in zip(u,v)],
   'deterministic_basis_trials':attempts,'epsilon_seam_rank':6,
   'forward_adjoint_formal_coefficients_each':38**2,'native_calls':calls,
   'native_forward_adjoint_rows_each':680,'paid':dict(sorted(p.items())),
   'productive':dict(sorted(t.items())),'ordinary':res,'rates':rates,
   'precision':'Rational 48-call precision is unchanged. Exact new bit/caller precision and physical owner/chart binding are not established.'},indent=2,sort_keys=True))

if __name__=='__main__':main()
