#!/usr/bin/env python3
"""Two concrete changed-LOCAL caller designs and bounded necessary tests."""
from collections import Counter
from copy import deepcopy
from itertools import combinations
from pathlib import Path
from hashlib import sha256
import gzip, json, sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
import common as C

N=38
RATES=C.RATES
CUT=88

def rank(rows):
 p={}
 for r in rows:
  while r and r.bit_length() in p:r^=p[r.bit_length()]
  if r:p[r.bit_length()]=r
 return len(p)

def bits(x):
 while x:
  b=x&-x;yield b.bit_length()-1;x^=b

def bare(c):
 c=deepcopy(c);ev=c['events'];remove=set()
 for i,e in enumerate(ev):
  if e[0]=='QUERY':
   assert ev[i+1]==['ADD',*e[1:]];remove.update((i,i+1))
 c['events']=[e for i,e in enumerate(ev) if i not in remove]
 return c

def q1(rows):
 out=[]
 for row in rows:
  d={}
  for m,v in row.items():
   m &= ~1;d[m]=d.get(m,0)^v
   if not d[m]:del d[m]
  out.append(d)
 return out

def body_diagonal(c):
 rows=q1(C.literal.caller_rows(c))
 mon=[]
 for i,row in enumerate(rows):
  assert len(row)==1
  (m,v),=row.items();assert v==1<<i;mon.append(m)
 return mon

def stages(m):
 assert not m&1
 a=[(m>>(1+10*i))&1023 for i in range(18)]
 assert all(t in (0,1) for t in a)
 return [i+1 for i,x in enumerate(a) if x]

def set_first_contact(c,a,b):
 ev=c['events']
 assert ev[:4]==[['ADD',0,1],['LOCAL',1,0,1],['ADD',1,0],['ADD',0,1]]
 ev[:4]=[['ADD',a,b],['LOCAL',1,a,b],['ADD',b,a],['ADD',a,b]]
 locals=[e for e in ev if e[0]=='LOCAL'];assert len(locals)==36
 for s in range(1,19):
  pair=[e for e in locals if e[1]==s];assert len(pair)==2
  assert len(set(pair[0][2:]+pair[1][2:]))==4

def eps_cells(c, body, heads):
 rows=C.literal.caller_rows(c); cells={}
 for i,row in enumerate(rows):
  for m,v in row.items():
   if m&1:
    for j in bits(v):
     key=(i,j);cells.setdefault(key,set()).symmetric_difference_update([m&~1])
  if heads[i]:cells.setdefault((i,i),set()).symmetric_difference_update([body[i]])
 return {k:v for k,v in cells.items() if v}

def eps_rank(cells):
 rows=[0]*N
 for (i,j),mm in cells.items():
  if len(mm)%2:rows[i]^=1<<j
 return rank(rows)

def seam_obstruction(original, candidate, body, heads):
 """Any arbitrary same-seam epsilon operator is constant in caller registers."""
 pre=deepcopy(candidate);pre['events']=pre['events'][:CUT]
 p=body_diagonal(pre)
 suffix=[]
 for x,y in zip(body,p):
  bs=set(stages(x));ps=set(stages(y));assert ps<=bs
  suffix.append(C.literal.caller_monomial(sorted(bs-ps)))
 actual=eps_cells(bare(candidate),body,heads)
 wrong=[];allowed=[[0]*N for _ in range(N)]
 for (i,j),vals in actual.items():
  expected=p[j]+suffix[i]
  if vals != {expected}:
   wrong.append({'output':i,'input':j,'actual_epsilon_monomials':[stages(m) for m in sorted(vals)],
                 'only_seam_query_monomial':stages(expected)})
  else:allowed[i][j]=1
 return p,suffix,wrong,rank([sum(x<<j for j,x in enumerate(row)) for row in allowed])

def show(v):return [str(x) for x in v]

def main():
 raw=gzip.decompress((ROOT/'source/CALLER.json.gz').read_bytes());caller=json.loads(raw)
 assert sha256(raw).hexdigest()=='9de443fa08e766e5b054c6100398ffe11341a8c27dec5c5303573ec6d467cd8b'
 word,old,_,np,nt,paid,targets,rat=C.baseline()
 assert C.literal.caller_rows(caller)==C.literal.caller_rows(old)
 assert C.literal.caller_rows(caller,True)==C.literal.caller_rows(old,True)
 basebody=body_diagonal(caller);base_scores={str(k):C.moment(paid,targets,k) for k in RATES}
 rationals={str(k):C.moment(rat['signed']['paid'],rat['signed']['productive'],k) for k in RATES}
 designs=[('cross_chain_shared_arm',(0,27)),('bypassed_hub_arm_bridge',(8,27))]
 out={}
 for name,edge in designs:
  c=deepcopy(caller);set_first_contact(c,*edge)
  body=body_diagonal(c)
  targ=Counter({int(k):v*36 for k,v in nt.items()})
  rootgrades=[1+7*len(stages(m)) for m in body]
  for g in rootgrades:targ[g]+=111
  price0=paid.copy();price0[1]-=444
  allhead=[1]*N
  cells=eps_cells(bare(c),body,allhead);r0=eps_rank(cells)
  prefix,suffix,wrong,allowedrank=seam_obstruction(caller,c,body,allhead)
  # Candidate head omissions up to three, a bounded optimistic option.
  hist=Counter();bests={str(k):None for k in RATES}
  increments={str(k):[C.minus(C.power(g,k),C.power(g-1,k)) for g in rootgrades] for k in RATES}
  deltas={}
  for k in RATES:
   p=price0.copy();p[1]+=111*r0
   deltas[str(k)]=C.minus(C.moment(p,targ,k),base_scores[str(k)])
  for cnt in range(4):
   for omitted in combinations(range(N),cnt):
    heads=allhead.copy()
    for i in omitted:heads[i]=0
    changed={k:set(v) for k,v in cells.items()}
    for i in omitted:
     changed.setdefault((i,i),set()).symmetric_difference_update([body[i]])
    changed={k:v for k,v in changed.items() if v};r=eps_rank(changed);hist[(cnt,r)]+=1
    for k in RATES:
     val=deltas[str(k)]
     for i in omitted:val=C.minus(val,C.scale(increments[str(k)][i],111))
     val=C.minus(val,(C.D(111*(r-r0)),C.D(111*(r-r0))))
     key=(val[1],tuple(-x for x in omitted))
     if bests[str(k)] is None or key>bests[str(k)]['key']:
      bests[str(k)]={'key':key,'omitted_heads':omitted,'necessary_queries':r,'delta':val}
  for k in RATES:
   b=bests[str(k)];b.pop('key');b['delta']=show(b['delta'])
  initial={}
  for k in RATES:
   p=price0.copy();p[1]+=111*r0
   initial[str(k)]={'minimum_query_price_with_all_heads':r0,
                    'bit_margin_if_rank_sufficient':show(C.moment(p,targ,k)),
                    'delta_vs_7952_if_rank_sufficient':show(deltas[str(k)]),
                    'rational_unchanged':show(rationals[str(k)])}
  # Off-diagonal mismatch cannot be changed by surrendering an output head.
  offdiag=[w for w in wrong if w['output']!=w['input']]
  out[name]={'stage1_new_local_pair':list(edge),'stage1_other_pair':[19,20],
             'changed_roles':[{'owner':i,'before':stages(a),'after':stages(b),
                                'old_grade':1+7*len(stages(a)),'new_grade':rootgrades[i]}
                               for i,(a,b) in enumerate(zip(basebody,body)) if a!=b],
             'root_head_body_grade_histogram':dict(sorted(Counter(rootgrades).items())),
             'all_head_unqueried_specialized_epsilon_rank':r0,
             'necessary_rank_based_prices':initial,
             'head_omission_scan_up_to_three':{'count':sum(hist.values()),
                'count_by_omitted_heads_and_rank':{str(k):v for k,v in sorted(hist.items())},
                'best_by_rate':bests},
             'seam_arbitrary_constant_epsilon_query_mismatch_count':len(wrong),
             'seam_offdiagonal_mismatch_count':len(offdiag),
             'seam_first_mismatches':wrong[:16],
             'rank_of_cells_with_matching_monomials_only':allowedrank,
             'same_native_calls_and_idle_grades':True}
 print(json.dumps({'pinned_head_pr7952':'755fcee748d4e90feda281f27d06e7bc66ecf954',
   'pinned_head_pr7964':'1f90b620855e08b6a941a304ed25eda5600c0deb',
   'pinned_head_pr7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
   'scope':'Two specific changed true native contacts with frozen idle schedule and same-seam corrections; root head omissions are optimistic and do not establish consumer admissibility.',
   'formal_ring':'F2[q,D1,...,D18]/(q^2-1); epsilon=q+1, exact non-inverted body monomials',
   'designs':out},sort_keys=True,indent=2))

if __name__=='__main__':main()
