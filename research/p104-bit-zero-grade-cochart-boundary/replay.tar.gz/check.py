#!/usr/bin/env python3
"""Pinned scalar chart-collapse and dirty-sentinel controls; not a physical supplier."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha1,sha256
from itertools import product
from pathlib import Path
from types import SimpleNamespace
import ast
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent
PINS={
 'inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'source/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'source/independent.py':'a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
 'source/ternary_frames.py':'ffe3dfc1098fadba9f17ecb4d8338d07d78a73e1bf202def81312780345f3976',
 'source/raw_binary.py':'9629a92d7383640ccbe9cb5b86972bee7901e63162d691b4fba8056624501ae2',
 'source/powered.py':'2cd55d3cd17e5f4ad10fcc1d534393d0ca9c709dd1b08f9e43d223ea15ba19f7',
 'source/periodic.py':'6233e1806d29bd386ce39fab398fee4f6b73b11d4bdc1e3608bcccde15d71b19',
}
def need(v,why):
 if not v:raise ValueError(why)


for p,h in PINS.items():need(sha256((HERE/p).read_bytes()).hexdigest()==h,'bad input '+p)
sys.path.insert(0,str(HERE/'source'))
import literal
import independent as arithmetic
from periodic import Job,Rule
from powered import PoweredWord,Port
from ternary_frames import identity,inverse,multiply,projector,residue,transpose,frame_at_three


def canonical(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def readgz(name):return json.loads(gzip.decompress((HERE/'inputs'/name).read_bytes()))
def positions(n):return [i for i in range(n.bit_length()) if (n>>i)&1]


def mutate_word(w,oldchart,newchart,repair=False):
 mapped=[];zeros=[]
 for clock,row in enumerate(w['program']):
  op,*tail=row;entry=list(row)
  if repair and clock==9070:
   need(entry==['INIT',2613,399],'moved INIT source')
   continue
  if repair and clock==2567:
   need(entry==['INIT',1402,136],'source open')
   mapped.append(('moved-init-2613',['INIT',2613,136]))
  if op in ('INIT','CLEAR','ADD') and entry[-1]==oldchart:entry[-1]=newchart
  if op=='MOVE':
   entry[2:]=[newchart if q==oldchart else q for q in entry[2:]]
   if entry[2]==entry[3]:zeros.append((clock,entry[1]));continue
  mapped.append((clock,entry))
  if repair and clock==2567:mapped.append(('balancing-add',['ADD',2613,1402,136]))
  if repair and clock==9071:
   need(entry==['ADD',2613,1402,136],'post-collapse source contact')
   mapped.append(('cleanup-add',['ADD',1402,775,136]))
 starts=[newchart if x==oldchart else x for x in w['start']]
 ends=[newchart if x==oldchart else x for x in w['final']]
 return mapped,starts,ends,zeros


def direct_program(w):return [(clock,list(row)) for clock,row in enumerate(w['program'])]


def tape(w,program,starts,ends,reverse=False):
 n=w['public'];total=n+w['owned_fields']
 valid_charts=set(map(int,w['frames']))
 banks=[1<<j for j in range(n)]+[0]*w['owned_fields']
 tags=list(ends if reverse else starts)+[None]*w['owned_fields']
 expected=list(starts if reverse else ends)+[None]*w['owned_fields']
 retired={};dirty=0;peak=0;live=0
 for clock,row in (reversed(program) if reverse else program):
  op,a,*args=row;need(0<=a<total,'bank address')
  if op in ('INIT','CLEAR'):
   need(a>=n and args[0] in valid_charts,'private lifetime')
   opening=(op=='CLEAR') if reverse else (op=='INIT')
   if opening:
    need(tags[a] is None,'live bank opened twice')
    tags[a]=args[0];banks[a]=0;live+=1;peak=max(peak,live)
   else:
    need(tags[a]==args[0],'retirement chart');dirty+=bool(banks[a]);retired[a]=banks[a]
    tags[a]=None;banks[a]=0;live-=1
  elif op=='ADD':
   b,c=args;need(a!=b and 0<=b<total and tags[a]==tags[b]==c,'cochart ADD')
   if reverse:banks[b]^=banks[a]
   else:banks[a]^=banks[b]
  elif op=='SWAP':
   b,=args;need(a!=b and tags[a] is not None and tags[b] is not None,'distinct SWAP owners')
   banks[a],banks[b]=banks[b],banks[a];tags[a],tags[b]=tags[b],tags[a]
  elif op=='MOVE':
   src,dst=args[::-1] if reverse else args
   need(a>=n and tags[a]==src,'MOVE chronology')
   need(src!=dst,'zero MOVE must be compiled out');tags[a]=dst
  else:raise ValueError('unknown opcode')
 need(tags==expected and not live and not any(banks[n:]),'literal endpoint and lifetime')
 rows=[1<<i for i in range(n)]
 for i in range(111):
  if reverse:rows[i]^=1<<(i+111)
  else:rows[i+111]^=1<<i
 need(banks[:n]==rows,'680 arbitrary public operator coefficients')
 return {'outputs':banks[:n],'dirty':dirty,'peak':peak,'retired':retired}


def source_occurrences(w,c):
 p=w['program'];need(c['events'][4]==['LOCAL',1,1,0],'actual caller clock')
 need(p[2567:2570]==[['INIT',1402,136],['ADD',1402,775,136],['MOVE',1402,136,399]],'source first contact')
 need(p[9070:9075]==[['INIT',2613,399],['ADD',2613,1402,399],['ADD',2613,2018,399],
                      ['ADD',2613,2143,399],['MOVE',2613,399,546]],'actual second contact')
 need(p[40179]==['CLEAR',775,136] and p[40806]==['CLEAR',1402,399],'actual retirements')
 writes=lambda b:[(i,row) for i,row in enumerate(p) if row[1]==b or row[0]=='SWAP' and row[2]==b]
 reads=lambda b:[(i,row) for i,row in enumerate(p) if row[0]=='ADD' and row[2]==b]
 need([i for i,_ in writes(2613)][:1]==[9070] and not [1 for i,_ in reads(2613) if i<9070],'early y owner is unused')
 need(not [1 for i,_ in writes(775) if 2568<i<9072],'donor unchanged during local delivery')
 need([i for i,_ in reads(1402)]==[9071],'only payload reader')
 need(not [1 for i,_ in writes(1402) if 2569<i<40806],'only payload retirement')
 need(sum(e[0]=='LOCAL' for e in c['events'])==36,'complete caller local count')


def scalar_tests(w):
 old=direct_program(w);x,starts,ends,z=mutate_word(w,399,136,False)
 xclean,s2,e2,z2=mutate_word(w,399,136,True)
 need(z==z2==[(2569,1402)] and (starts,ends)==(s2,e2),'only zero move identity')
 out={}
 for reverse in (False,True):
  a=tape(w,old,w['start'],w['final'],reverse)
  b=tape(w,x,starts,ends,reverse)
  d=tape(w,xclean,s2,e2,reverse)
  need(a['outputs']==b['outputs']==d['outputs'],'complete coefficient equivalence')
  need(a['retired'][1402] and b['retired'][1402] and not d['retired'][1402],'local dirty retirement')
  need(a['retired'][775]==d['retired'][775] and a['retired'][2613]==d['retired'][2613],
       'source and receiver retirement values preserved')
  need({k:v for k,v in a['retired'].items() if k!=1402}==
       {k:v for k,v in d['retired'].items() if k!=1402},'all other retirement rows preserved')
  out['adjoint' if reverse else 'forward']={
   'public_rows':len(a['outputs']),'source_dirty_1402_bits':positions(a['retired'][1402]),
   'plain_collapse_dirty_1402_bits':positions(b['retired'][1402]),
   'cleaned_1402_bits':positions(d['retired'][1402]),
   'source_dirty_count':a['dirty'],'plain_collapse_dirty_count':b['dirty'],
   'changed_dirty_count':d['dirty'],'source_peak_live_private':a['peak'],'changed_peak_live_private':d['peak']}
 return out


def eval_ops(ops,state,reverse=False):
 d=dict(state)
 for op,a,b in (reversed(ops) if reverse else ops):
  if op=='SWAP':d[a],d[b]=d[b],d[a]
  elif reverse:d[b]^=d[a]
  else:d[a]^=d[b]
 return d


def borrowed_dirty():
 # y^=s at initial zero, original s^=x and y^=s, then s^=x.
 # s and e are independent owners. The two swaps expose and restore escrow.
 roles=('x','y','s','e','spectator');need(len(set(roles))==5,'independent roles')
 ops=[('SWAP','s','e'),('ADD','y','s'),('ADD','s','x'),
      ('ADD','y','s'),('ADD','s','x'),('SWAP','s','e')]
 independent={k:1<<i for i,k in enumerate(roles)}
 fw=eval_ops(ops,independent);ad=eval_ops(ops,independent,True)
 wantf=dict(independent);wantf['y']^=independent['x']
 wanta=dict(independent);wanta['x']^=independent['y']
 need(fw==wantf and ad==wanta,'symbolic dirty sentinel and transpose')
 for values in product(range(2),repeat=len(roles)):
  data=dict(zip(roles,values,strict=True))
  f=eval_ops(ops,data);a=eval_ops(ops,data,True)
  expectf=dict(data);expectf['y']^=data['x']
  expecta=dict(data);expecta['x']^=data['y']
  need(f==expectf and a==expecta,'exhaustive GF2 independent values')
 # Delete the first balancing ADD: dirty escrow leaks into the destination,
 # and its transpose corrupts the corresponding independent sentinel.
 bad=ops[:1]+ops[2:]
 need(eval_ops(bad,independent)!=wantf and eval_ops(bad,independent,True)!=wanta,'missing balancing control')
 try:
  need(len(set(('x','y','x','e','spectator')))==5,'alias of source and scratch')
 except ValueError:pass
 else:raise ValueError('owner alias accepted')
 return {'symbolic_independent_roles':list(roles),'all_boolean_inputs_each_orientation':2**len(roles),
         'forward':'y ^= x; x,s,e,spectator restored',
         'adjoint':'x ^= y; y,s,e,spectator restored',
         'actual_source_registers':{'x':775,'y':2613,'s':1402},
         'additional_test_escrow':'e is separate and arbitrary; can be zero',
         'missing_balance_and_alias_rejected':True}


def native_projector(w):
 f=w['frames']['136'];F=transpose(f['B']+f['A']);d=f['dim']
 P=projector(F,d);fp=[r[:] for r in F]
 for row in fp:row[0],row[1]=row[1],row[0]
 Pp=projector(fp,d);need(P==Pp and fp!=F,'equal projector distinct basis')
 adapter=multiply(inverse(F),fp);permutation=identity(8)
 permutation[0][0]=permutation[1][1]=0;permutation[0][1]=permutation[1][0]=1
 need(adapter==permutation,'same subspace distinct basis adapter')
 vec=[1,2]+[0]*6
 changed=[sum(residue(adapter[i][j],3)*vec[j] for j in range(8))%3 for i in range(8)]
 need(changed!=vec,'basis naming negative control')
 zero=[[p-q for p,q in zip(x,y,strict=True)] for x,y in zip(P,Pp,strict=True)]
 need(all(x==0 for row in zero for x in row),'zero difference projector')
 zero_frame,zero_rank=frame_at_three(zero)
 need(zero_rank==0 and zero_frame==identity(8),'zero projector catalogue has empty mask')
 tests=0
 for m in (3,9,27):
  for i in range(16):
   x=[int(i==j) for j in range(8)];y=[int(i==8+j) for j in range(8)]
   delta=[sum(residue(zero[j][k],m)*(y[k]-x[k]) for k in range(8))%m for j in range(8)]
   out=([(x[j]+delta[j])%m for j in range(8)],[(y[j]-delta[j])%m for j in range(8)])
   need(out==(x,y),'D(0) identity');tests+=1
 return {'chart':136,'frame_rank':d,'frame_determinant':str(literal.determinant([[Fraction(x) for x in row] for row in f['B']+f['A']])),
         'same_subspace_same_projector_different_basis':True,'adapter':'swap first two basis coordinates',
         'moduli':[3,9,27],'D_zero_basis_tests':tests,'zero_projector_catalogue_rank':zero_rank,
         'scope':'address identity for identical projectors; arbitrary basis representation needs adapter or canonical binding'}


def edge_report(w,c,atlas):
 original=[(i,r) for i,r in enumerate(w['program']) if r[0]=='MOVE']
 cases={}
 for source,dest in ((399,136),(506,1)):
  edges=[];bad=[];zero=[];reversed_direction=[];old=Counter();new=Counter()
  for clock,row in original:
   a,b=row[2:]
   if source not in (a,b):continue
   before=atlas.leg(a,b);old[before]+=1
   aa=dest if a==source else a;bb=dest if b==source else b
   if (atlas.rank[b]-atlas.rank[a])*(atlas.rank[bb]-atlas.rank[aa])<0:
    reversed_direction.append([clock,row[1],a,b,aa,bb])
   if aa==bb:after=0;zero.append([clock,row[1]])
   else:
    try:after=atlas.leg(aa,bb);new[after]+=1
    except ValueError:
     after=None;bad.append([clock,row[1],aa,bb])
   edges.append([clock,row[1],a,b,before,aa,bb,after])
  helpers=[]
  for owner,(a,b) in enumerate(zip(w['start'],w['final'],strict=True)):
   if owner<222 or source not in (a,b):continue
   before=atlas.leg(a,b);aa=dest if a==source else a;bb=dest if b==source else b
   after=0 if aa==bb else atlas.leg(aa,bb)
   helpers.append([owner,a,b,before,aa,bb,after])
  cases[str(source)]={'replacement_chart':dest,'old_paid':dict(old),'new_positive_paid':dict(new),
                     'zero_moves':zero,'failed_nesting':bad,'direction_reversals':reversed_direction,
                     'paid_occurrences':edges,'affected_helpers':helpers}
 a=cases['399'];need(a['zero_moves']==[[2569,1402]] and
   [row[0] for row in a['failed_nesting']]==[5174,6010] and
   [row[0] for row in a['direction_reversals']]==[5174,6010] and not a['affected_helpers'],'399 local geometry failure')
 # Only the six old 399 edges: assume hypothetically that both failed
 # incoming edges can be rebuilt at their original grade two.
 a['six_edge_partial_signed_delta']='36*(H(4)+2*H(1)+H(2)-2*H(5)-H(6))'
 a['six_edge_partial_scope']='assumes both failed incoming edges rebuilt at grade two; excludes every other effect and is not a global upper bound'
 coeff399=Counter({4:1,1:2,2:1,5:-2,6:-1})
 a['six_edge_partial_directed']={k:arithmetic.report_interval(arithmetic.scale(arithmetic.moment(coeff399,1-Fraction(k)),36))
                                 for k in ('0.003879928046156','0.003879929046155')}
 b=cases['506'];need(not b['failed_nesting'] and b['zero_moves']==[[11347,3266],[11351,3267]],'506 paid nesting')
 need(len(b['direction_reversals'])==15,'506 does not preserve directed containments')
 need(Counter(b['old_paid'])==Counter({2:27,4:5}) and Counter(b['new_positive_paid'])==Counter({2:15,6:12,8:3}),'506 paid histogram')
 need([(r[0],r[3],r[6]) for r in b['affected_helpers']]==[(331,4,8),(334,4,8),
      (633,4,0),(634,4,0),(648,4,0),(649,4,0)],'all affected helper occurrences')
 need(atlas.main_contacts(w['start'],w['final'])==111,'baseline main quartet geometry')
 all_old_paid=[atlas.leg(row[2],row[3]) for _,row in original]
 all_old_helpers=[atlas.leg(a,b) for a,b in zip(w['start'][222:],w['final'][222:],strict=True)]
 need(len(all_old_paid)==2874 and len(all_old_helpers)==458,'all original nested paid/helper sites')
 # All untouched 506 edges and helper endpoints remain the source pairs.
 # Every changed nonzero pair has been checked above.
 need(len(original)-len(b['zero_moves'])==2872 and len(all_old_helpers)-4==454,'506 positive census')
 b['complete_per_native_counts']={'original_moves':2874,'remaining_positive_moves':2872,
                                  'original_helpers':458,'positive_helpers':454,'zero_helpers':4,
                                  'original_main_quartets':111}
 changed,s,e,z=mutate_word(w,506,1)
 oldt,oldt2=tape(w,direct_program(w),w['start'],w['final']),tape(w,direct_program(w),w['start'],w['final'],True)
 newt,newt2=tape(w,changed,s,e),tape(w,changed,s,e,True)
 need(oldt['outputs']==newt['outputs'] and oldt2['outputs']==newt2['outputs'],'506 complete scalar operators')
 need(w['start'][:222]==s[:222] and w['final'][:222]==e[:222] and (w['start'][411],w['final'][411])==(s[411],e[411]),'main endpoints and bridge label')
 coeff=Counter({2:12,4:-1,6:-12,8:-1});rates={}
 for k in ('0.003879928046156','0.003879929046155'):
  moment=arithmetic.scale(arithmetic.moment(coeff,1-Fraction(k)),36)
  need(moment[1]<0,'negative full 506 rank change')
  rates[k]=arithmetic.report_interval(moment)
 b['complete_36_call_signed_delta']='36*(12*H(2)-H(4)-12*H(6)-H(8)), H(r)=r^(1-k)'
 b['directed_signed_delta']=rates
 b['scalar_680_rows_each_orientation_preserved']=True
 b['scope']='chart-only rank screen; deleted zero labels and retained zero-rank helpers require compiler and physical requalification'
 return cases


def helper_information():
 # A state (owner, escrow) must remain injective. Even a zero target quotient
 # leaves an arbitrary owner payload on the cochart spectator.
 states=[(h,0) for h in range(2)]
 swapped=[(e,h) for h,e in states]
 need(swapped==[(0,0),(0,1)] and len(set(swapped))==2,'preserve owner in escrow')
 need(len({(0,0) for _ in states})<len(states),'erasing arbitrary owner loses information')
 return {'same_chart_quotient_rank':0,'owner_states':states,'zero_via_swap_states':swapped,
         'destructive_retirement_noninjective':True,'scope':'one-bit local information test; not a global space lower bound'}


def compiler_boundary(caller):
 raw=(HERE/'source/raw_binary.py').read_bytes()
 need(sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==
      '46932a83c41284bb178f17d0250ab6754e01a55b','exact #7914 raw compiler blob')
 tree=ast.parse(raw.decode(),filename='raw_binary.py')
 job_node=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='job_frame')
 klass=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='BinarySource')
 fresh_node=next(x for x in klass.body if isinstance(x,ast.FunctionDef) and x.name=='fresh')
 raw_node=next(x for x in klass.body if isinstance(x,ast.FunctionDef) and x.name=='raw')
 class FakeFrame:
  def __init__(self,*args):pass
  def matcher_to(self,other):return ()
 ns={'Frame':FakeFrame,'Job':Job}
 for f in (job_node,fresh_node):
  module=ast.fix_missing_locations(ast.Module(body=[f],type_ignores=[]))
  exec(compile(module,'raw_binary.py','exec'),ns)
 job_frame=ns['job_frame']
 Rule(100,(16,),(11,))
 for targets,paid in (((16,),(0,)),((0,),(1,))):
  try:Rule(100,targets,paid)
  except ValueError:pass
  else:raise ValueError('strict periodic Rule unexpectedly admitted zero rank')
 class Banks:
  dimension=134
  def zero(self):return 77
  def route(self,*args):pass
  def swap(self,*args):pass
  def xor(self,*args):pass
 class Physical:
  fresh=ns['fresh']
  def __init__(self):self.banks=Banks();self.sizes=[]
  def raw(self,inputs,columns):
   for tag,job in inputs:
    self.sizes.append([list(tag),len(job.axes)])
    job_frame(job,134)
   yield None
  def retire(self,job):pass
 # Reduce only the tensor count to one to expose the inherited failure; the
 # actual #7914 native, fresh and job_frame bodies are unchanged.
 word=PoweredWord(2,(Port(('positive',),2),Port(('helper',4,633),0)),
                  (Port(('paid',),1),),1,2,1,1)
 p=Physical()
 try:list(word.native([Job(0,(0,1))],1,p))
 except IndexError:pass
 else:raise ValueError('inherited empty-axis job unexpectedly accepted')
 need(p.sizes==[[['positive'],2],[['helper',4,633],0]],'actual zero-target call chain')
 # A distinct failure when one drops a helper owner: run the exact extracted
 # raw method with the four actual root roles and actual first five events.
 class Cat:
  ports=111
  graph={'public':680}
  root={'events':caller['events'][:5]}
  def target(self,tag):return FakeFrame()
  def port_stage(self,p,stage):return ()
 ns['raw_catalogue']=lambda dimension,columns:Cat()
 module=ast.fix_missing_locations(ast.Module(body=[raw_node],type_ignores=[]))
 exec(compile(module,'raw_binary.py','exec'),ns)
 roots=[(('root',role,port),Job(role*111+port,(0,))) for role in (0,1,19,20) for port in range(111)]
 roots += [(('helper',4,i),Job(10000+i,(0,))) for i in range(222,680) if i!=633]
 try:next(ns['raw'](SimpleNamespace(banks=Banks()),roots,1))
 except KeyError as err:need(err.args==(('helper',4,633),),'first missing owner key')
 else:raise ValueError('dropping zero helper unexpectedly accepted')
 return {'raw_binary_git_blob':'46932a83c41284bb178f17d0250ab6754e01a55b',
         'strict_periodic_rule':'zero paid and zero target rank rejected',
         'zero_target':'actual PoweredWord.native -> actual BinarySource.fresh -> actual job_frame: IndexError on empty axes',
         'dropped_owner':'actual BinarySource.raw method raises KeyError for (helper,4,633)',
         'fixture_scope':'one-factor control and mocked bank I/O; actual caller prefix, source methods and missing key'}


def main():
 w,c=readgz('WORD.json.gz'),readgz('EFREE-CALLER.json.gz')
 need(canonical(w)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','source word')
 source_occurrences(w,c);atlas=literal.Charts(w['frames'])
 try:atlas.leg(136,136)
 except ValueError as err:need('positive nested rational' in str(err),'strict source rule')
 else:raise ValueError('source accepted zero-rank paid MOVE')
 out={'status':'PASS_LOCAL_SCALAR_COGRADE_BOUNDARY_NO_PHYSICAL_SUPPLIER',
      'source_word_sha256':canonical(w),'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
      'strict_literal_source_rejects_grade_zero':True,'projector':native_projector(w),
      'nonaliasing_dirty_word':borrowed_dirty(),'actual_scalar_retiming':scalar_tests(w),
      'actual_global_chart_screens':edge_report(w,c,atlas),'helper_owner_information':helper_information(),
      'inherited_compiler_boundary':compiler_boundary(c),
      'limitations':['399-to-136 global rank geometry has two invalid nested edges',
                     '506-to-1 global rank accounting is negative and its physical compiler is not constructed',
                     'scalar MOVE is a chart-label change, not a graded physical native operation',
                     'two added ADD contacts, early owner lifetime and clean escrows require a full physical bill',
                     'no general 656-component conclusion or new kappa']}
 print(json.dumps(out,sort_keys=True,indent=2))


if __name__=='__main__':main()
