#!/usr/bin/env python3
"""Cold replay and corruption controls for the cochart boundary."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def main():
 expected=(ROOT/'RESULT.json').read_bytes();rejected=[]
 with TemporaryDirectory(prefix='p104-cochart-cold-') as directory:
  tmp=Path(directory)/'packet'
  shutil.copytree(ROOT,tmp,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  def run(*flags):
   return subprocess.run([sys.executable,*flags,str(tmp/'check.py')],cwd=tmp,
                         stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
  for flags in (('-I','-B'),('-I','-B','-O')):
   p=run(*flags)
   if p.returncode or p.stdout!=expected:
    raise ValueError('cold replay differs: '+p.stderr.decode(errors='replace'))
  for name in ('inputs/WORD.json.gz','inputs/EFREE-CALLER.json.gz','source/raw_binary.py'):
   path=tmp/name;old=path.read_bytes();bad=bytearray(old);bad[len(bad)//2]^=1;path.write_bytes(bad)
   p=run('-I','-B')
   if p.returncode==0 or ('bad input '+name).encode() not in p.stderr:
    raise ValueError('corrupt source not rejected: '+name)
   path.write_bytes(old);rejected.append(name)
 print(json.dumps({'status':'PASS_COLD_NORMAL_OPTIMIZED_AND_CORRUPTION_CONTROLS',
                   'rejected_inputs':rejected},indent=2,sort_keys=True))


if __name__=='__main__':main()
