# Zero-grade cochart boundaries in the pinned BIT word

**A zero projector difference gives an identity address operation, but the
inherited literal and compiler interfaces do not accept zero-rank paid or
productive occurrences.** A nonaliasing local replacement can preserve an
arbitrary dirty scratch field in forward and adjoint, under an exact common
chart binding. The actual regradings checked here do not yield an admissible
positive supplier or a new κ.

The literal source is [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830),
with canonical word `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`
and paired caller `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`.
The installed source interface is from [#7914 at `46783fbbfc219a3faffbea76f60a2810b85ab75a`](https://github.com/CrocSwap/integer-mult-bounds/pull/7914).
Original licenses and attribution are retained. All source bytes used by
`check.py` have fixed SHA-256 pins; the copied #7914 `raw_binary.py` also has
its exact Git-blob identity checked.

## What is legal at a zero chart difference

The source `Charts.leg` requires a **strictly positive** nested rational
grade. The separate pinned native interpreter also requires `grade > 0`.
The inherited periodic `Rule` rejects zero paid and zero target ranks.
Consequently, `MOVE(s,C,C)` cannot be left as an ordinary paid MOVE with
grade zero. A normalized candidate can delete that instruction if all of
the following hold:

1. The two actual physical address projectors are equal, including their
   caller and product placement; the native address map then has
   `D(0)(x,y)=(x,y)` in both directions.
2. The surrounding operations are retagged or rebound to the **same**
   physical chart representation, every intervening cochart contact remains
   legal, and each independent owner and spectator retains its own data.
3. The altered literal word, complete owner inventory, forward and adjoint
   operators, all affected signed grades, work, stock and retirement are
   rechecked. A zero local move does not discharge the existing
   `owned_erasure` or precision premises.

Same rational subspace is not automatically the same coordinate encoding.
For the actual chart 136, the checker swaps the two basis vectors spanning
its rank-two subspace. The projector remains exactly equal, but the
coordinate adapter is a nontrivial transposition. One may use a single
canonical physical frame or implement and price the necessary adapter; the
bare equality of spans does not make different encodings identical.

For equal projectors the difference matrix is exactly zero, and the native
address formula is the identity. This is checked on all 16 input basis vectors
of the two eight-coordinate fields modulo 3, 9 and 27. It is an algebraic
local operation, not a materialized full 451-factor route.

## A real source contact with a dirty sentinel

Caller clock 4 is an actual LOCAL call. In the original word:

```
2567  INIT  1402, chart 136
2568  ADD   1402 ^= 775, chart 136
2569  MOVE  1402, 136 -> 399              # original grade 4
9070  INIT  2613, chart 399
9071  ADD   2613 ^= 1402, chart 399
...
40179 CLEAR 775, chart 136
40806 CLEAR 1402, chart 399
```

Bank 2613 has no earlier touch or source read. Bank 775 remains live and
unchanged from 2568 through 9071. Bank 1402 has exactly one source read,
at 9071, and no later state modification before CLEAR. Pretend for this
test that the entire local route has been validly rebound to one chart `C`
and that all owners have the same physical coordinate encoding. Write
`x=775`, `y=2613`, and `s=1402`. Move the `INIT` of 2613 to immediately
before 2567, insert the first ADD below immediately after `INIT 1402`, delete
the now-equal-chart MOVE, and insert the last ADD immediately after 9071:

```
y ^= s            # added; source INIT makes s zero in the forward literal
s ^= x            # original 2568
y ^= s            # original 9071
s ^= x            # added cleanup
```

The four ADDs, on **distinct** cocharted owners, implement `y ^= x` and
restore an arbitrary original `s`. Their exact reverse-order transposes
implement `x ^= y` and restore that same `s`. A separate fixture places a
distinct escrow `e` around `s` by swaps and checks all 32 independent bit
assignments to `x,y,s,e,spectator` in each orientation. It also checks the
symbolic matrix, rejects an owner alias, and shows that omitting the first
balancing ADD leaks dirty data in forward and adjoint. If a literal INIT
needs zero, use a separately owned clean `e`; the swaps restore the original
sentinel and return `e` to zero. The four-ADD identity itself even holds for
an arbitrary independent `e`.

The checker also runs the **entire** original 680-owner scalar word, a
chart-label collapse with the zero MOVE deleted, and the retimed/augmented
word in forward and formal adjoint. Both changed scalar traces preserve all
680 original arbitrary-input endpoint rows. In the original scalar word,
bank 1402's retirement has forward row `x15` and adjoint row
`x15 XOR x132 XOR x260 XOR x261 XOR x450`. The added local contacts make it
zero in both orientations. Every other private owner's exact retirement row
is unchanged, and the number of dirty retirements falls from 3,554 to 3,553
in each orientation. The observed peak private-owner count remains 3,554.
The two added ADDs per native call and the 6,503-clock earlier activation of
2613 still require their full tape and concurrent-storage prices.

This full-word replay deliberately models MOVE as a chart-tag change and
CLEAR as literal discard. It establishes the two scalar operators and the
one local retirement, not a physical chart-aware supplier or the other 3,553
dirty retirements. In particular, the required chart merger has not been
constructed within the direction-preserving geometry.

## The actual global geometry blocks these simple mergers

Globally replacing chart 399 by chart 136 makes clock 2569 zero, but the
remaining source edges `282 -> 399` and `303 -> 399` become nonnested and
reverse their original containment direction. The three edges from 399 to
546, 619 and 1 change from grades `1,1,2` to `5,5,6`. Even if the two
invalid incoming edges were hypothetically rebuilt at their former grade 2,
the **six affected edge subtotal** at K would be approximately
`−285.228411`; this is not a global upper bound because such a rebuild can
alter other edges. No helper endpoint uses original chart 399.

For a separate global replacement `506 -> 1`, all changed nonzero pairs are
nested, but **15 reverse their original containment direction**, so this is
outside a direction-preserving regrading. There are two zero MOVE sites,
`(11347,3266)` and `(11351,3267)`. All affected source bins, per native
call, are:

| Occurrences | Original | After global substitution |
| --- | --- | --- |
| Paid MOVE ranks | 27 of 2; 5 of 4 | 15 of 2; 12 of 6; 3 of 8; 2 zero |
| Helper ranks | 6 of 4 | 2 of 8; 4 zero |

The six helpers are original owners 331, 334, 633, 634, 648 and 649.
Those four zero-rank helpers remain distinct owner locations. At the actual
36 LOCAL calls, the complete changed signed rank expression is

```
36 * (12 H(2) - H(4) - 12 H(6) - H(8)),  H(r)=r^(1-k).
```

At `k=0.003879928046156` it is in the directed interval
`[-2141.276940119970104539025982959481824882590751425695,
  -2141.276940119970104539025982959481824882590751425694]`.
The original 111 main endpoint quartets and owner-411 endpoint labels are
unchanged; the global label substitution with zero MOVEs deleted preserves
all 680 scalar rows in both orientations. This is still only a rank and
literal-label screen. It does not establish an all-column physical
realization, physical helper lifecycle, or any claim about independent
cochart-component assignments.

## A same-chart helper remains an owner

The difference projector of a helper whose start and end charts coincide
has rank zero and contributes **no positive productive target rank**. Its
full independently valued cochart/spectator payload can still be nonzero
and must remain in its own owner or be transported to a distinct owner.
If an original grade `r` is removed this way in every LOCAL call, the
productive moment loses exactly `36 r^(1-k)` unless another actual target
replaces it. A paid grade removal has its own, separately counted credit.

Free-zeroing and retirement are additional state operations. A one-bit
control maps `(owner, clean escrow)=(0,0),(1,0)` to `(0,0),(0,1)` by an
injective swap: the owner is zero but the arbitrary old value is held
elsewhere. Mapping both inputs to `(0,0)` is noninjective. One may instead
prove that the actual value is already zero or uncompute it, or preserve it
in other charged state. This is a local information example, not a universal
lower bound on all possible algorithms or storage schedules.

There is also a concrete inherited compiler interface failure. In a bounded
one-factor control, the **actual** #7914 `PoweredWord.native` and
`BinarySource.fresh` send the zero-rank tag `(helper,4,633)` as a job with
empty axes; the actual `job_frame` accesses `job.axes[0]` and raises
`IndexError`. If the owner is dropped instead, the actual `BinarySource.raw`
method, with the real first five caller events and the other 457 helper
owners supplied, raises `KeyError` for `(helper,4,633)`. Bank I/O is mocked
in these small controls. A real changed supplier needs a zero-extent owner
adapter, physical lifecycle and retirement proof, or a separately rebuilt
source; simply deleting a histogram row does not supply either.

## Reproduction

From this directory, with Python 3.10+ and the standard library:

```
sha256sum -c SHA256SUMS
python3 -I -B check.py > /tmp/p104-cochart-check.json
cmp RESULT.json /tmp/p104-cochart-check.json
python3 -I -B verify.py
```

The clean-copy verifier regenerates the receipt and rejects mutated word,
caller and compiler bytes. No upstream, IntegerGraph or other application
write is performed.
