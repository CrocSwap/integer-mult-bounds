#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Reconstruct the restored-side branch and two diagnostic chart-635 transfers."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import *

RATE=prices.D('0.00388')
TARG=op.expected_operator(False)
BASE_BAD=set([111,112,113,114,116,117,118,119,120,121,122,124,127,128,129,130,131,132,133,135,137,139,141,142,144,145,146,148,150,151,152,153,154,156,157,158,161,162,163,165,166,167,168,169,170,171,172,173,174,176,177,178,179,180,181,183,184,185,186,187,188,189,190,191,192,193,195,196,197,198,200,202,203,204,205,206,207,208,210,211,212,213,214,215,216,217,218,219,549])

def branch():
 m=dict(R);r=dict(ROWS);m[3410]=(421,0);r[3410]=r[3409];del r[3409],m[3409];r[789]=1<<17
 for k in (785,1584,1934):
  for p in r:r[p]&=~(1<<k)
 r.update({785:1<<679,1584:1<<785,1934:1<<1584,~679:1<<1934,1583:(1<<17)^(1<<781),1585:(1<<1583)^(1<<813),1586:1<<1583});m[1583]=(19,182)
 return m,r

def simulate(m,r):
 init=dict(enumerate(W['start']));final=dict(enumerate(W['final']));seq=bit_native.schedule(init,final,m,r)
 val={i:1<<i for i in init};st=defaultdict(list)
 for i,c in init.items():st[c].append(i)
 for p in seq:
  val[p]=xsum(val[j] for j in labels(r[p]));st[m[p][1]].append(p)
 return init,final,seq,val,st

def basis(ids,val):
 s=Span()
 for p in ids:s.add(val[p],1<<p)
 return s

def evaluate(m,r):
 init,fin,seq,val,st=simulate(m,r);banks={c:basis(ids,val) for c,ids in st.items()};missing=[]
 for i,c in fin.items():
  q=banks[c].express(TARG[i])
  if q is None:missing.append(i)
  else:r[~i]=q
 word=bit_native.emit_word(W,init,fin,m,r,seq);tapes=[op.run_tape(word,ATLAS,reverse) for reverse in (False,True)]
 errors=[[i for i,(x,y) in enumerate(zip(t.output,op.expected_operator(reverse))) if x!=y] for reverse,t in zip((False,True),tapes)]
 assert errors[0]==missing
 _,caller,_,_,helpers,_,productive,rat=prices.baseline()
 grades=Counter(p.grade for p in tapes[0].packets.values())
 assert grades==Counter(p.grade for p in tapes[1].packets.values())
 paid,actual_targets=prices.literal.paired_invoice(caller,grades,helpers,Counter(event[0] for event in caller['events']))
 assert actual_targets==productive
 margin=prices.moment(paid,actual_targets,RATE)
 rational=prices.moment({int(k):v for k,v in rat['signed']['paid'].items()},{int(k):v for k,v in rat['signed']['productive'].items()},RATE)
 return dict(forward=errors[0],adjoint=errors[1],grades=dict(sorted(grades.items())),margin=prices.display(margin),rational_margin=prices.display(rational),word=op.canonical_hash(word),chart1_rank=len(banks[1].rows),chart1_missing=[i for i in errors[0] if fin[i]==1],owner221_correct=221 not in errors[0],dirty=[t.dirty for t in tapes]),(val,st)

m,r=branch();init,fin,seq,values,banks=simulate(m,r)
assert len(banks[1])==537 and banks[635]==[2876,2882,2885,3408]
assert [m[p] for p in banks[635]]==[(490,635),(492,635),(493,635),(107,635)]
assert [CLOCK[p] for p in banks[635]]==[10115,10139,10151,19907]
assert [ATLAS.grade(*m[p]) for p in banks[635]]==[1,1,1,6]
assert all(values[p]==X[p] for p in banks[635])
assert xsum(values[p] for p in banks[635])==(1<<221)^(1<<110)
# Chart 635's three early relays each remain essential to the current final chart-1 rank.
old1=banks[1];ranks={str(drop):len(basis([p for p in old1 if p not in drop],values).rows) for drop in ((),(3262,),(3263,),(3264,),(3262,3263,3264))}
assert list(ranks.values())==[536,535,535,535,533]
redundant=[p for p in old1 if len(basis([q for q in old1 if p!=q],values).rows)==536]
assert redundant==[2678] and values[2678]==0 and CLOCK[2678]<CLOCK[2876]
# Full final actual stocks at the 3408 cut, and exact named source-bank checks.
before=defaultdict(list)
for i,c in init.items():before[c].append(i)
source_checks={};target_before=None
for p in sorted(m,key=CLOCK.get):
 a,b=m[p]
 if p in (2876,2882,2885,3408):
  ss=before[a]+before[635];s=basis(ss,values)
  source_checks[str(p)]={'source':a,'source_stock':list(before[a]),'prefix635':list(before[635]),'old1584_available':s.express(X[1584]) is not None,'e549_available':s.express(1<<549) is not None}
 if p==3408:target_before={c:list(v) for c,v in before.items()};break
 before[b].append(p)
assert all(not q['old1584_available'] and not q['e549_available'] for q in source_checks.values())
pre=target_before[635];Q=(1<<221)^(1<<110);findq=[];find549=[]
for c,ids in target_before.items():
 if c==635:continue
 g=ATLAS.grade(c,635)
 if not g:continue
 s=basis(ids+pre,values)
 if s.express(Q) is not None:findq.append([c,g])
 if s.express(1<<549) is not None:find549.append([c,g])
assert findq==[[107,6]] and find549==[[0,7]]
orig,_=evaluate(*branch());assert set(orig['forward'])==BASE_BAD and len(orig['adjoint'])==29

# 3-hop fixed-clock transfer: 2291 and 2320's former consumers are explicitly cut.
def transfer(with719=False):
 m,r=branch();m[2291]=(0,490);r[2291]=1<<549;m[2320]=(490,635);r[2320]=1<<2291;m[2678]=(635,1);r[2678]=1<<2320
 r[2300]&=~(1<<2291);r[~662]&=~(1<<2320)
 if with719:
  m[719]=(0,507);r[719]=1<<639;r[2300]^=1<<719;r[~664]&=~(1<<719)
 return evaluate(m,r)

three,(v3,s3)=transfer();four,(v4,s4)=transfer(True)
assert (three['word'],four['word'])==('2e6947e1a4d739ad11fd4a632fb4bba62151e3becf796047d4d708560bb02dea','a41cdefa40c4d4e509c39ae7e1d17a28138e182c545ee0e66ec14c9439eaafff')
assert set(three['forward'])==(BASE_BAD-{549})|{639,662}
assert set(four['forward'])==(BASE_BAD-{549})|{662,664}
assert len(three['adjoint'])==33 and len(four['adjoint'])==34
assert three['chart1_missing']==[639] and three['chart1_rank']==536
assert not four['chart1_missing'] and four['chart1_rank']==537
assert all(q['owner221_correct'] for q in (three,four))
for q,approx in ((orig,prices.D('36.1548')),(three,prices.D('107.9129')),(four,prices.D('0.6854'))):
 lo,hi=map(prices.D,q['margin']);assert lo<=hi and abs(lo-approx)<prices.D('0.0001')
assert v3[2291]==v3[2320]==v3[2678]==v4[2291]==v4[2320]==v4[2678]==1<<549
# Single additional message with all donor final stocks free and arbitrary local terminal redecoding.
contact={}
for owner in (639,662):
 dst=fin[owner];dest=s3[dst];hits=[]
 for c,ids in s3.items():
  if c==dst:continue
  g=ATLAS.grade(c,dst)
  if g and basis(dest+ids,v3).express(1<<owner) is not None:hits.append([c,g])
 contact[str(owner)]=hits
assert contact=={'639':[[0,8]],'662':[[0,4]]}

# Recount the 410 native-clock affordable attempts to restore reader 2300 with
# another chart-0 send.  Allow all other old rows intact (an optimistic grant).
counts=Counter();events=[];oldorder=sorted(m,key=CLOCK.get)
def stock(c,t,without):
 return [i for i,x in init.items() if x==c]+[q for q in oldorder if m[q][1]==c and CLOCK[q]<t and q!=without]
for p in oldorder:
 if CLOCK[p]>=CLOCK[2300] or p in (2291,2320,2678,1583,785,1584,1934,3553) or m[p][0]!=0:continue
 oldg=ATLAS.grade(*m[p]);margin=price([5,1,2,4,4,2,oldg],[6,1,6,1,1,4])
 if margin[0]<=prices.D('0.02771136020'):continue
 dst=m[p][1];readers=[q for q in oldorder if r[q]>>p&1];terms=[i for i in init if r[~i]>>p&1]
 badreads=[q for q in readers if basis(stock(dst,CLOCK[q],p),values).express(values[p]) is None]
 badterms=terms if basis(stock(dst,10**9,p),values).express(values[p]) is None else []
 counts[(len(badreads),len(badterms))]+=1
 if len(badreads)+len(badterms)==0:events.append(p)
assert counts=={(1,0):386,(2,1):16,(0,1):8} and not events
result=dict(source='restored-side literal branch from #7830 native word',cash_rate=str(RATE),incidence=source_checks,rank_chart1=ranks,only_redundant_receipt=redundant,eligible_3408_replacement=findq,eligible_e549_to_635=find549,original=orig,three_hop=three,four_hop=four,additional_one_message=contact,earlier_sender_screen={'count':sum(counts.values()),'unresolved_firstreaders_and_terminals':{str(k):v for k,v in counts.items()},'fully_restored':events})
expected=HERE9/'RESULT.json'
if '--write' in sys.argv:expected.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
else:assert json.loads(expected.read_text())==json.loads(json.dumps(result)),'receipt mismatch'
print('PASS native input, grade and cash, exact local stocks, 3408 donor roster, chart-1 rank')
print('PASS 680-row two-orientation replay of baseline and two diagnostic changed words')
print('PASS source-collateral checks, 410 earlier sender tests, one-message final-stock overgrant')
