# Chart 635 paid-transfer diagnostic

This is a bounded investigation of the restored-side literal word from the chart-268 repair. Its native source is the #7830 word pinned by `source/SOURCES.json`, compressed SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`. The restored-side construction is rebuilt by `verify.py` from this source. All clocks below are observations in the pinned native tape; the changed schedules respect their stated order. No MOVE 3409 is retimed.

Chart 635's actual stock is 2876 `(490→635, grade 1, clock 10115)`, 2882 `(492→635, grade 1, clock 10139)`, 2885 `(493→635, grade 1, clock 10151)`, and 3408 `(107→635, grade 6, clock 19907)`. All four have exactly their native values in this branch and XOR to the correct terminal row `x221+x110`. Each of the first three also feeds a distinct chart-1 receipt. At these exact source times, neither native `X1584` nor `x549` is in the actual source stock plus previously arrived chart-635 stock. At 3408's clock, granting the complete actual preclock stock at every eligible sender and chart 635's three early rows, only original sender 107 can supply the owner-221 quotient, at grade 6. In the same relaxed test, only sender 0 can supply `x549`, at grade 7. This is a fixed-history screen, not a statement about altered sources.

Chart 1 has 537 receipts of rank 536. Removing any one of 3262, 3263 or 3264 leaves rank 535; removing all three leaves rank 533. They cannot, as three one-bit receipts, alone give 537 independent rows to chart 1. Only receipt 2678 is individually redundant, and its branch value is zero; its native clock 9330 precedes the first original receipt at chart 635.

## Literal controls and full prices

At `κ=0.00388`, the baseline native 36-call binary signed margin is approximately `−0.02771136019021759`. The following signed margins are full paid and productive invoice recounts, rather than changes from that baseline. None of these altered words is a valid full operator, so each positive margin is hypothetical.

| Word | Changed native MOVE slots | All 680 forward / adjoint errors | 36-call margin |
| --- | --- | ---: | ---: |
| Restored-side branch | 785, 789, 1583, 1584, 1934, 3410; old 3409 removed | 89 / 29 | +36.1548121756985078 |
| Three-slot 635 transfer | 2291 `0→490` g6 at 7018; 2320 `490→635` g1 at 7260; 2678 `635→1` g1 at 9330 | 90 / 33 | +107.9129228076624351 |
| Four-slot transfer | The preceding three plus 719 `0→507` g4 at 137 | 90 / 34 | +0.6853938385636526 |

In the three-slot word, each of 2291, 2320 and 2678 carries the actual full direction `x549` and owner 549 is restored. The former 2291 carried `x639` to chart 507 and fed 2300, so cutting that donor loses owner 639 at chart 1. The former 2320 carried `x645+x662+x663` to chart 509 and fed terminal owner 662, which also becomes wrong. All other sender equations are fixed, and all terminal rows are redecoded in their final actual stock. Owner 221 stays correct.

For the four-slot word, the repurposed 719 carries `x639` to chart 507 and 2300 reads it; every chart-1 output is then correct. But 719 formerly carried `x240+x664` into chart 8, whose terminal owner 664 now fails. New forward failures relative to the restored-side word are exactly `{662,664}` and 549 is healed; all 88 other original forward failures remain. Owner 221 remains correct. The forward and adjoint checks inspect every output, and both changed words have 3,553 dirty private retirements. A separate erasure construction and physical compiler have not been established.

For the three-slot word, granting each sender its entire final *actual* stock, and free terminal decoding, a single added message can supply owner 639 only from chart 0 at grade 8; it can supply owner 662 only from chart 0 at grade 4. This overgrant rules out a single added grade-1 repair for either owner in the fixed word. Joint source recodings, multiple added messages and other incidence changes remain open.

The verifier also exhausts the 410 price-surviving native-clock chart-0 slots that could be retargeted to chart 507 by the clock of reader 2300. For each, it asks whether the displaced original packet can be reconstructed at each old direct reader and old terminal using all other original branch values, granted intact. None passes. The `(failed readers, failed terminals)` counts are `(1,0): 386`, `(2,1): 16`, and `(0,1): 8`. This is a necessary test for preserving those exact former packet values, not an exclusion of joint changes or redecoding away all downstream disturbances.

## Reproduce

From the extracted directory, using Python 3.11 or newer:

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```

The verifier reconstructs the branch and both changed words, checks exact atlas containment grades, both 680-row operators, chart-1 ranks, chart-635 output and source stocks, enumerates legal fixed-clock senders, counts displaced duties, and rebuilds the complete binary and rational invoices from pinned sources. It compares the computed results with `RESULT.json` without rewriting it. Supplying `--write` intentionally regenerates the receipt and is not part of the read-only verification command.

No new κ value, valid application, clean retirement, or price-qualified complete supplier follows from these diagnostics.
