# Weighted 2-adic decoder subsets

For one fixed rational P104 decoder, a family of separately gaugeable subsets
can be combined when its weighted restricted binary ranks fit **each paid
row's full-support rank**. [RESULT.md](RESULT.md) states the condition and
proof, describes a strict exact example, and records the limits and controls.

The package includes two exact examples:

- A constructed 208-row P104 decoder has mass 208. Its largest common-gauge
  subset has 52 ports, while two disjoint 52-port sets satisfy the shared row
  budgets and certify 104.
- The specific eight-row #7852 E8 decoder has mass 69. Its largest
  common-gauge subset has 6 ports; 17 individually gaugeable ports at unit
  weight satisfy all shared row budgets and certify 17.

Neither example proves the general decoder wall. The 2-adic and weighted
arguments are mathematical proofs, not newly built Lean theorems. No claim is
made about a network or word wall, a caller invoice, kappa or frontier
selection. The #7869 DEN4 note already contains a related deep-port lemma;
the comparison and explicit author credit are in [RESULT.md](RESULT.md) and
[NOTICE.md](NOTICE.md).

From the extracted package directory, run:

```
python3 -I -B verify.py
```

Python 3.10 or newer and the standard library are sufficient. This checks
the complete file manifest and source blob/byte hashes, then runs the exact
fraction, rank, gauge, decoder-law, and negative-control checks from a fresh
temporary working directory and compares their output with the committed
receipts. No network, solver, Git checkout, or Lean build is needed.
[COLD-REPLAY.md](COLD-REPLAY.md) records the separate cold replay performed
for this packet. [SOURCES.json](SOURCES.json) distinguishes live input data
from inert source snapshots; [SOURCE-COVERAGE.md](SOURCE-COVERAGE.md) records
the included evidence and remaining obligations.

The repository contribution is prepared for Clear1nsight with substantial
OpenAI Codex assistance. The preserved upstream sources and attribution are
licensed under [Apache-2.0](LICENSE).
