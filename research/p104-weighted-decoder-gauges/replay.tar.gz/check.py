#!/usr/bin/env python3
"""Exact rational, binary-rank, and 2-adic checks for a P104 example.

Inputs are the pinned PR #7852 label source used by first-round #7855.
No Lean theorem, minimization over all decoders, or kappa claim is made.
"""
import ast
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import itertools
import json
import re

source = Path(__file__).resolve().parent / 'sources' / '7852' / 'LinP104Base.lean'
raw = source.read_bytes()
assert sha256(raw).hexdigest() == '20a8474716ae87b22a325b524b826ba7b354239e36a36c78c1b76e8106d3952d'
match = re.search(r'^def labMasks\s*:[^\n]*?:=\s*(\[.*\])$', raw.decode(), re.M)
assert match
lab = ast.literal_eval(match.group(1))
n = len(lab)
assert n == 104 and all(x.bit_count() % 2 == 1 for x in lab)
q = [[(x & y).bit_count() & 1 for y in lab] for x in lab]
assert all(q[t][s] == q[s][t] for t in range(n) for s in range(n))


def packed_rank(a):
    basis = {}
    for x in a:
        while x:
            j = x.bit_length() - 1
            if j not in basis:
                basis[j] = x
                break
            x ^= basis[j]
    return len(basis)


def dense_rank(a):
    a = [list(x) for x in a]
    if not a:
        return 0
    p = 0
    for j in range(len(a[0])):
        z = next((i for i in range(p, len(a)) if a[i][j]), None)
        if z is None:
            continue
        a[p], a[z] = a[z], a[p]
        for i in range(p + 1, len(a)):
            if a[i][j]:
                a[i] = [x ^ y for x, y in zip(a[i], a[p])]
        p += 1
    return p


def rank_rectangle(ds, gs):
    ds, gs = sorted(ds), sorted(gs)
    rows = [[q[t][s] for s in gs] for t in ds]
    p = packed_rank([sum(v << j for j, v in enumerate(row)) for row in rows])
    assert p == dense_rank(rows)
    return p


def v2(x):
    assert x
    x = F(x)
    a, b = abs(x.numerator), x.denominator
    return (a & -a).bit_length() - (b & -b).bit_length()


def p2(e):
    return F(2 ** e) if e >= 0 else F(1, 2 ** -e)


# Build a live-edge perfect matching. If the final greedy pair is not live,
# repair using any earlier pair. Dense P104 data allow this finite procedure.
unused = set(range(n))
pairs = []
while len(unused) > 2:
    a = min(unused)
    available = sorted(b for b in unused if b != a and q[a][b])
    assert available
    b = available[0]
    unused -= {a, b}
    pairs.append((a, b))
a, b = sorted(unused)
if not q[a][b]:
    for j, (c, d) in enumerate(pairs):
        if q[a][c] and q[b][d]:
            pairs[j] = (a, c)
            a, b = b, d
            break
        if q[a][d] and q[b][c]:
            pairs[j] = (a, d)
            a, b = b, c
            break
    else:
        raise AssertionError('unable to repair the final matching pair')
pairs.append((a, b))
assert len(pairs) == 52
assert sorted(itertools.chain.from_iterable(pairs)) == list(range(n))
assert all(q[a][b] for a, b in pairs)

# Every coefficient here occurs in a live pattern cell. On a matched pair,
# the four row outer products sum exactly to the 2x2 identity.
w, u = [], []
for a, b in pairs:
    w.extend([{a: F(1, 2), b: F(1)},
              {a: F(1), b: F(1, 2)},
              {a: F(1, 2)},
              {b: F(1, 2)}])
    u.extend([{b: F(1)}, {a: F(1)}, {b: F(-1)}, {a: F(-1)}])
m = len(w)
assert m == 208

total = [[F(0) for _ in range(n)] for _ in range(n)]
for wi, ui in zip(w, u):
    for t, x in wi.items():
        for s, y in ui.items():
            assert q[t][s] == 1
            total[t][s] += x * y
assert all(q[t][s] * total[t][s] == int(t == s)
           for t in range(n) for s in range(n))
assert all(total[t][s] == int(t == s)
           for t in range(n) for s in range(n))

# Mutation control: break the first live cross-cancellation and check that
# the rational decoder law detects it rather than only checking diagonal cells.
mut_w = [dict(row) for row in w]
mut_w[0][pairs[0][0]] += 1
mut_errors = [(t, s) for t in range(n) for s in range(n)
              if q[t][s] * sum(a.get(t, 0) * b.get(s, 0) for a, b in zip(mut_w, u)) != int(t == s)]
assert mut_errors == [pairs[0]]

sa = {a for a, b in pairs}
sb = {b for a, b in pairs}
assert not (sa & sb) and sa | sb == set(range(n))


def rank_list(s=None):
    if s is None:
        s = set(range(n))
    return [rank_rectangle(set(wi) & s, set(ui) & s) for wi, ui in zip(w, u)]


full, ra, rb = rank_list(), rank_list(sa), rank_list(sb)
assert full == [1] * m
assert all(ra[k] + rb[k] <= full[k] for k in range(m))
assert [ra[:4], rb[:4]] == [[0, 1, 0, 0], [1, 0, 0, 0]]


def gauge_ok(s, lam):
    """Check all exact first-round difference constraints."""
    for t in s:
        for i, wi in enumerate(w):
            if t not in wi:
                continue
            for j, uj in enumerate(u):
                if t in uj and lam[j] - lam[i] > v2(wi[t]) + v2(uj[t]):
                    return False
    return True


lambda_a = [v for _ in pairs for v in (0, -1, 0, -1)]
lambda_b = [v for _ in pairs for v in (-1, 0, -1, 0)]
assert gauge_ok(sa, lambda_a) and gauge_ok(sb, lambda_b)
lambda_a_mut = list(lambda_a)
lambda_a_mut[0] = -1
assert not gauge_ok(sa, lambda_a_mut)


def reduce_and_verify(s, lam):
    """Check normalized exact valuations and reduced pattern identity."""
    a = {t: min(v2(w[k][t]) + lam[k] for k in range(m) if t in w[k]) for t in s}
    def bit(x):
        x = F(x)
        assert x.denominator % 2 == 1
        return x.numerator % 2
    wd, ud = [], []
    for k in range(m):
        wk = {t: c * p2(lam[k] - a[t]) for t, c in w[k].items() if t in s}
        uk = {t: c * p2(-lam[k] + a[t]) for t, c in u[k].items() if t in s}
        assert all(v2(x) >= 0 for x in list(wk.values()) + list(uk.values()))
        wd.append({t: bit(x) for t, x in wk.items()})
        ud.append({t: bit(x) for t, x in uk.items()})
    assert all(q[t][r] * (sum(wd[k].get(t, 0) * ud[k].get(r, 0)
                               for k in range(m)) % 2) == int(t == r)
               for t in s for r in s)


reduce_and_verify(sa, lambda_a)
reduce_and_verify(sb, lambda_b)

# The rows 4j and 4j+1 form a negative two-cycle whenever both
# endpoints of pair j are included. Thus no gaugeable set can contain both.
for j, (a, b) in enumerate(pairs):
    i, h = 4*j, 4*j + 1
    assert v2(w[i][a]) + v2(u[h][a]) == -1  # lambda_h - lambda_i <= -1
    assert v2(w[h][b]) + v2(u[i][b]) == -1  # lambda_i - lambda_h <= -1

# The smallest row-wise overlap obstruction is a valid 2-port rational decoder:
# both complete-support rows cost one, while each singleton costs one per row.
# Each port appears in only one subset, yet its singleton prices double charge.
counter_w = [[F(1), F(1)], [F(1), F(2)]]
counter_u = [[F(2), F(-1)], [F(-1), F(1)]]  # columns are (A^-1)^T
assert all(sum(counter_w[t][k] * counter_u[s][k] for k in range(2)) == int(t == s)
           for t in range(2) for s in range(2))
assert packed_rank([0b11, 0b11]) == 1
assert packed_rank([0b1]) + packed_rank([0b1]) == 2
assert all(v2(x) >= 0 for row in counter_w + counter_u for x in row)
ca, cb = pairs[0]
cws = [{ca: counter_w[0][k], cb: counter_w[1][k]} for k in range(2)]
cus = [{ca: counter_u[0][k], cb: counter_u[1][k]} for k in range(2)]
for t in set(range(n)) - {ca, cb}:
    cws.append({t: F(1)})
    cus.append({t: F(1)})
assert all(q[t][s] * sum(a.get(t, 0) * b.get(s, 0) for a, b in zip(cws, cus)) == int(t == s)
           for t in range(n) for s in range(n))
assert sum(rank_rectangle(a, b) for a, b in zip(cws, cus)) == 104

# Even the set function S -> rank(Q[D∩S,G∩S]) need not be submodular.
# Use a 3x3 principal P104 pattern, and an actual decoder whose first row has
# D=G equal to those three ports. W=I+2J and U=I-(2/7)J are mutual inverses.
i, j, k = 0, 6, 11
tri = {i, j, k}
assert [[q[t][s] for s in (i, j, k)] for t in (i, j, k)] == [[1,1,0],[1,1,1],[0,1,1]]
aa, bb = {i, j}, {j, k}
subranks = [rank_rectangle(aa, aa), rank_rectangle(bb, bb),
            rank_rectangle(aa & bb, aa & bb), rank_rectangle(aa | bb, aa | bb)]
assert subranks == [1, 1, 1, 3] and subranks[0] + subranks[1] < subranks[2] + subranks[3]
tw, tu = [], []
tri_order = [i, j, k]
for column in range(3):
    tw.append({t: F(int(r == column) + 2) for r, t in enumerate(tri_order)})
    tu.append({t: F(int(r == column)) - F(2, 7) for r, t in enumerate(tri_order)})
for t in set(range(n)) - tri:
    tw.append({t: F(1)})
    tu.append({t: F(1)})
assert all(q[t][s] * sum(a.get(t, 0) * b.get(s, 0) for a, b in zip(tw, tu)) == int(t == s)
           for t in range(n) for s in range(n))
assert set(tw[0]) == set(tu[0]) == tri
assert all(v2(c) >= 0 for row in tw + tu for c in row.values())

result = {
    'label_source_sha256': sha256(raw).hexdigest(),
    'n_ports': n,
    'pairs': pairs,
    'live_pair_count': len(pairs),
    'rational_rows': m,
    'decoder_law_exact_all_cells': True,
    'decoder_mutation_detected_on_live_cell': mut_errors,
    'every_factor_entry_occurs_in_a_live_cell': True,
    'full_row_prices': {'one': sum(x == 1 for x in full), 'total_mass': sum(full)},
    'set_sizes': [len(sa), len(sb)],
    'weighted_set_coefficients': [1, 1],
    'restricted_rank_sums': [sum(ra), sum(rb)],
    'rows_with_exactly_one_budget_used': sum(x+y == z for x, y, z in zip(ra, rb, full)),
    'rows_with_unused_budget': sum(x+y < z for x, y, z in zip(ra, rb, full)),
    'valid_weighted_lower_bound': len(sa) + len(sb),
    'exact_maximum_single_gaugeable_set': len(pairs),
    'maximality_reason': '52 disjoint negative cycles, one for each matched pair',
    'gauges_and_mod2_identities_verified': True,
    'incompatible_gauge_mutation_rejected': True,
    'single_row_overlap_counterexample': {
        'labels_are_first_matched_P104_pair': list(pairs[0]),
        'full_pattern': [[1, 1], [1, 1]],
        'rational_decoder_W_by_port': [[str(x) for x in row] for row in counter_w],
        'rational_decoder_U_by_port': [[str(x) for x in row] for row in counter_u],
        'full_price_of_each_row': 1,
        'two_singleton_prices_for_each_row': [1, 1],
        'decoder_total_price': 2,
        'p104_extension_price': 104,
        'p104_extension_decoder_law_all_cells': True,
        'singleton_weighted_size_sum': 2,
        'note': 'The naive row budget is false; the final global cost inequality happens to hold in this small example.'
    },
    'principal_restriction_non_submodularity': {
        'p104_ports': [i, j, k],
        'r_A_r_B_r_intersection_r_union': subranks,
        'a_full_support_row_occurs_in_an_integral_gaugeable_p104_decoder': True,
        'p104_extension_decoder_law_all_cells': True
    }
}
print(json.dumps(result, indent=2))
