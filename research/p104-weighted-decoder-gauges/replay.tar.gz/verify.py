#!/usr/bin/env python3
"""Offline integrity, source identity, and exact replay for this packet."""
from hashlib import sha1, sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
if sys.version_info < (3, 10):
    raise SystemExit('Python 3.10 or newer is required')


def safe_path(name):
    rel = Path(name)
    if rel.is_absolute() or '..' in rel.parts:
        raise SystemExit(f'unsafe path: {name}')
    result = ROOT / rel
    if result.is_symlink() or not result.is_file() or not result.resolve().is_relative_to(ROOT):
        raise SystemExit(f'missing or unsafe file: {name}')
    return result


lines = (ROOT / 'SHA256SUMS').read_text().splitlines()
manifest = {}
for line in lines:
    digest, sep, name = line.partition('  ')
    if not sep or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest) or name in manifest:
        raise SystemExit('malformed checksum manifest')
    manifest[name] = digest
actual_files = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()} - {'SHA256SUMS'}
if set(manifest) != actual_files:
    raise SystemExit(f'manifest coverage mismatch: missing={sorted(actual_files-set(manifest))}, extra={sorted(set(manifest)-actual_files)}')
for name, digest in manifest.items():
    if sha256(safe_path(name).read_bytes()).hexdigest() != digest:
        raise SystemExit(f'checksum mismatch: {name}')
print(f'PASS manifest: {len(manifest)} files')

source_map = json.loads((ROOT / 'SOURCES.json').read_text())
for item in source_map['files']:
    raw = safe_path(item['local_path']).read_bytes()
    if sha256(raw).hexdigest() != item['sha256']:
        raise SystemExit(f'source byte mismatch: {item["local_path"]}')
    blob = sha1(b'blob ' + str(len(raw)).encode() + b'\x00' + raw).hexdigest()
    if blob != item['git_blob']:
        raise SystemExit(f'source blob mismatch: {item["local_path"]}')
    if item['ref'] != source_map['pins'][str(item['pr'])]['head']:
        raise SystemExit(f'source pin mismatch: {item["local_path"]}')
print(f'PASS source byte and Git blob identities: {len(source_map["files"])} mappings')

with tempfile.TemporaryDirectory(prefix='weighted-decoder-replay-') as cwd:
    for script, expected in [('check.py', 'results/result.json'), ('e8_check.py', 'results/e8_result.json')]:
        proc = subprocess.run([sys.executable, '-I', '-B', str(ROOT / script)],
                              cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              check=False)
        if proc.returncode or proc.stderr:
            raise SystemExit(f'{script} failed ({proc.returncode}): {proc.stderr.decode(errors="replace")}')
        if proc.stdout != safe_path(expected).read_bytes():
            raise SystemExit(f'exact result differs: {script}')
        print(f'PASS exact replay: {script} == {expected}')
print('PASS decoder mutation, gauge mutation, row overlap and non-submodularity controls')
