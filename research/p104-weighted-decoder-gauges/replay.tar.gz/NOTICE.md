The archived P104 model, data, and rank-lemma source are from PR #7852,
head 41beda1d6435760dc99e38bd7e65f36798aad212: DreamingOfClouds with
Claude Opus 5.5 (Anthropic), via Claude Code. Its unmodified notice is
sources/7852/NOTICE.md.

The predecessor gaugeable-subset argument is from PR #7855, head
3a12128490d09cd2070678b989c647169c81c255: Clear1nsight with substantial
OpenAI Codex assistance. The unchanged predecessor README, source metadata,
and preserved underlying #7852 notice are in sources/7855/.

The related all-denominator DEN4 carry/rank and single-gauge deep-port note
is from PR #7869, head 06c207a9feb3994a4b987dc3010657b6e85b7956:
DreamingOfClouds with Claude Opus 5.5 (Anthropic), via Claude Code. Its
unmodified note and notice are in sources/7869/. That note is not replayed.

The new weighted row-budget derivation, examples, and exact controls were
prepared for Clear1nsight with substantial OpenAI Codex assistance. Source
authorship, mathematical proof, executable checks, Lean formalization, and
the stronger network/word obligations are distinct. No contributor's work
is represented as endorsing another's conclusions. See SOURCES.json for
exact upstream file paths, object IDs, hashes, and inclusion boundaries.

The Apache-2.0 license text in LICENSE is byte-identical in the three cited
packages. All retained predecessor notices remain applicable.
