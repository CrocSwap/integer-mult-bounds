#!/usr/bin/env python3
"""Exact weighted certificates on the pinned #7852 eight-row E8 example.

This is a factorization-specific finite check, not a proof for all decoders.
The scripts are single-process and the only inputs are the pinned Lean files.
"""
import ast
import contextlib
from fractions import Fraction as F
from hashlib import sha256
import io
import itertools
import json
from pathlib import Path
import re
import runpy

here = Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    x = runpy.run_path(str(here / 'check.py'))
q, n = x['q'], x['n']
rank_rectangle, v2, p2 = x['rank_rectangle'], x['v2'], x['p2']
inst = here / 'sources' / '7852' / 'LinP104FreeInstBase.lean'
raw = inst.read_bytes()
assert sha256(raw).hexdigest() == '161d8c08505f6e09d275555027f14fdad6aec04f7a855a637a178352e35c9b8e'


def table(name):
    m = re.search(r'^def ' + re.escape(name) + r'\s*:[^\n]*?:=\s*(\[.*\])$', raw.decode(), re.M)
    assert m
    return ast.literal_eval(m.group(1))


ct, gram = table('ctL'), table('GbL')
assert len(ct) == n and len(gram) == 8
w = [{t: F(ct[t][k], 2) for t in range(n) if ct[t][k]} for k in range(8)]
v = [[sum(gram[k][i] * ct[t][i] for i in range(8)) for t in range(n)] for k in range(8)]
u = [{t: F(v[k][t]) for t in range(n) if v[k][t]} for k in range(8)]
assert all(q[t][s] * sum(a.get(t, 0) * b.get(s, 0) for a, b in zip(w, u)) == int(t == s)
           for t in range(n) for s in range(n))
price = [rank_rectangle(a, b) for a, b in zip(w, u)]
assert price == [9, 9, 9, 8, 7, 9, 9, 9]
assert sum(price) == 69


def edges_at(t):
    return [(i, j, v2(wi[t]) + v2(uj[t]))
            for i, wi in enumerate(w) for j, uj in enumerate(u)
            if t in wi and t in uj]


edges = {t: edges_at(t) for t in range(n)}


def gauge(subset):
    ee = [e for t in subset for e in edges[t]]
    d = [0] * 8
    for iteration in range(8):
        changed = False
        for a, b, weight in ee:
            if d[b] > d[a] + weight:
                d[b] = d[a] + weight
                changed = True
        if not changed:
            assert all(d[b] - d[a] <= weight for a, b, weight in ee)
            return d
    return None


bad = {t for t in range(n)
       if any(a == b and weight < 0 for a, b, weight in edges[t])}
good = sorted(set(range(n)) - bad)
assert len(bad) == 87 and len(good) == 17
assert all(gauge([t]) is not None for t in good)
assert all(gauge([t]) is None for t in bad)

# Pairwise incompatibility gives an upper bound on ANY feasible set, including
# sets for which longer cycles could create additional obstructions.
bad_pairs = {(a, b) for a, b in itertools.combinations(good, 2)
             if gauge((a, b)) is None}
assert len(bad_pairs) == 59
neighbors = [0] * len(good)
for i, a in enumerate(good):
    for j, b in enumerate(good):
        if i != j and (min(a, b), max(a, b)) in bad_pairs:
            neighbors[i] |= 1 << j
max_independent = 0
max_witness = None
for mask in range(1 << len(good)):
    size = mask.bit_count()
    if size <= max_independent:
        continue
    if all(not (mask & neighbors[i]) for i in range(len(good)) if (mask >> i) & 1):
        max_independent = size
        max_witness = [good[i] for i in range(len(good)) if (mask >> i) & 1]
assert max_independent == 6
assert max_witness == [3, 36, 56, 62, 77, 93]
gw = gauge(max_witness)
assert gw == [-1, 0, 0, -2, -1, -2, -1, 0]


def verify_reduction(t):
    d = gauge([t])
    assert d is not None
    alpha = min(v2(w[k][t]) + d[k] for k in range(8) if t in w[k])
    wnormal = [w[k].get(t, 0) * p2(d[k] - alpha) for k in range(8)]
    unormal = [u[k].get(t, 0) * p2(alpha - d[k]) for k in range(8)]
    assert all(not c or v2(c) >= 0 for c in wnormal + unormal)
    def mod2(c):
        c = F(c)
        assert c.denominator % 2
        return c.numerator % 2
    assert sum(mod2(wnormal[k]) * mod2(unormal[k]) for k in range(8)) % 2 == 1


for t in good:
    verify_reduction(t)

# Unit weights on every individually feasible singleton obey even the
# additional per-port packing condition, and obey every row budget exactly.
singleton_rank = {t: [rank_rectangle(set(w[k]) & {t}, set(u[k]) & {t})
                      for k in range(8)] for t in good}
assert all(sum(singleton_rank[t]) == 1 for t in good)
used = [sum(singleton_rank[t][k] for t in good) for k in range(8)]
assert used == [3, 2, 2, 1, 0, 2, 2, 5]
assert all(used[k] <= price[k] for k in range(8))

# There is no mathematical requirement that a row-budget coefficient be <=1.
# Saturate seven distinct full-row budgets using one singleton for each row.
weighted_ports = {12: 9, 62: 9, 3: 9, 93: 8, 49: 9, 36: 9, 7: 9}
assert all(t in good for t in weighted_ports)
weighted_used = [sum(weight * singleton_rank[t][k] for t, weight in weighted_ports.items())
                 for k in range(8)]
assert weighted_used == [9, 9, 9, 8, 0, 9, 9, 9]
assert all(weighted_used[k] <= price[k] for k in range(8))
assert sum(weighted_ports.values()) == 62

print(json.dumps({
    'label_source_sha256': sha256(x['raw']).hexdigest(),
    'e8_instance_source_sha256': sha256(raw).hexdigest(),
    'decoder_law_all_10816_cells': True,
    'full_row_prices': price,
    'full_decoder_mass': sum(price),
    'intrinsically_ineligible_ports': len(bad),
    'individually_gaugeable_ports': good,
    'incompatible_port_pairs': len(bad_pairs),
    'incompatible_port_pair_list': sorted(bad_pairs),
    'max_independent_set': max_witness,
    'independent_set_gauge': gw,
    'maximum_single_gaugeable_subset_size': max_independent,
    'singleton_rank_row_use_weight_one': used,
    'unit_singleton_weighted_lower_bound': len(good),
    'unrestricted_integer_weighted_singletons': weighted_ports,
    'integer_weighted_row_use': weighted_used,
    'integer_weighted_lower_bound': sum(weighted_ports.values()),
    'singleton_reductions_all_verified': True,
    'scope': 'This one decoder factorization, with its actual full row ranks; no universal wall claim.'
}, indent=2))
