# Cold offline replay receipt

On 2026-11-21 UTC, a fresh copy of this packet was made in a temporary
directory and run with `/usr/bin/python3 -I -B verify.py`, CPython 3.12.3,
under an empty environment except `PATH=/usr/bin:/bin` and `LANG=C.UTF-8`.
The replay used only the copied packet and Python's standard library; it
did not request network access or use the original research directories.
The first run completed in about 10 seconds and returned:

```
PASS manifest: 19 files
PASS source byte and Git blob identities: 12 mappings
PASS exact replay: check.py == results/result.json
PASS exact replay: e8_check.py == results/e8_result.json
PASS decoder mutation, gauge mutation, row overlap and non-submodularity controls
```

That run preceded the addition of this receipt and the source-coverage note.
The final package was replayed again with the updated
manifest. In a separate copy, appending a newline to the pinned label input
caused the integrity check to fail with `checksum mismatch` for that file.
The decoder coefficient and gauge mutations are also rejected by the exact
checks; the two-port overlap and three-port non-submodularity examples are
positive counterexamples to proposed shortcuts, each extended to a valid
full P104 decoder.

Expected output SHA-256:

```
d6fa1018007bd58aa30a5812f4a96ba6e8091e76e6a90e6487356d12cad3d742  results/result.json
e3e4ef416728924025b85e8388032400826a183ea5f73238881d8df373eacffb  results/e8_result.json
```

These checks do not build Lean or independently certify all the theorems in
the archived upstream notes. Exact input bytes and the limited source coverage
are given in SOURCES.json; all packet files except SHA256SUMS itself appear in
the checksum manifest.
