# Chart-339 reader cut and 48-call pullback

For the pinned #7830 rational word, the three original scalar arrivals at
chart 339 have **joint rank 144 in the actual closed 48-call caller**. The
three original immediate reader values also have joint rank 144. A fixed-reader
replacement with only two scalar arrivals per call can supply at most 96
scalar directions, even if those 96 values are freely and jointly recoded.
At least 48 further scalar directions are needed in that model.

This is a statement about scalar information. **It is not a lower bound on
the geometric grade or tariff of a physical repair.** The grade of a paid job
is determined by its chart geometry; it does not automatically equal the
number of independent scalar values. This result constructs no shared repair,
changed caller, changed invoice, or κ bound. A proposed repair needs its own
two-sided routing, orientation, owner-field, deadline, grade, and full price
check. The fixed-reader conclusion does not cover changed reader operators,
different target fields, or a different caller.

## The three readers

The literal arrivals, in order, are `92034: 333 → 339` (grade 1, native
clock 2024), `92035: 333 → 339` (grade 1, native clock 2157), and
`92032: 50 → 339` (grade 2, native clock 1482). Chart 339 has no initial
fields and no other paid arrivals. The first old reader is slot 98755 at clock
2755. The three immediate readers are slots 98755, 89065 and 92041; their
coefficient matrix on the listed arrivals is

```text
  1   0   4
  0  -4   4
 -1   1  -4
```

Its determinant is `−4`. The retained [predecessor package](predecessor/README.md)
checks the full native chronology, source authentication, the old local
independent-input minor and a forward omission control. It also includes a
conditional `H(48)` arithmetic comparison. That number uses an **additional
assumption relating scalar repair dimensions to tariff rank**. The new caller
calculation establishes the scalar dimensions, but does not establish that
additional physical price assumption.

## Actual caller pullback

The emitted closed caller has 48 native calls and 840,912 rows. Its exact stream
hash is `156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858`.
The first two call clocks in that stream are **9977** and **22836**, with
zero-based numbering. The complete first-two affected main-owner bindings and
their immediate mathematical predecessors appear in
[PULLBACK-RESULT.json](PULLBACK-RESULT.json); they are derived from the actual
emitted stream and physical-port allocation.

Use native input indices `(21, 320, 151)`, whose retained source labels are
`(21, 334, 151)`. They are distinct helper inputs on the empty initial chart.
At call `t` the caller allocates the distinct entrance owners
`('helper', t, 21)`, `('helper', t, 334)`, `('helper', t, 151)`. The exact
native arrival map on those helper directions is

```text
             helper index 21   320    151
  slot 92034              1   -1/2   -1/4
  slot 92035              0    1/2      0
  slot 92032              0    1/2   1/16
```

The determinant is `1/32`. Forward evaluation of the literal native tape
checks all 1,289 terminal rows on these three columns. The selected helper
terminals have their respective input values and **all 400 main terminals
are zero**. The other helper outputs are distinct same-owner terminals and
are not caller-root inputs. Set all 9,840 independent main-root inputs to
zero. The caller's linear operations and views preserve that zero state, so
induction through the actual calls leaves every main entrance zero while the
fresh helper triples vary independently.

The first two real calls therefore contain `diag(M,M)` as a `6 × 6` pullback
minor, with determinant `1/1024` and exact row rank 6. Over all 48 calls the
same argument gives a `144 × 144` block-diagonal minor with determinant
`(1/32)^48`; 144 rows give an upper bound of 144, hence exact rank 144.
The helper pulses `(1,0,0)`, `(-3,2,-16)` and `(4,0,16)` produce the three
arrival basis vectors, in the helper-index order above. In particular, the
second pulse varies 92035 while the other two literal arrivals are zero.
These pulses may be scaled to the inherited exact grid. This witness uses a
small actual caller subspace; it does not assert independence of every input
in 48 complete native domains.

## Sources and replay

The word and application are retained from #7830 head
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The caller code is retained from
`4f7c67ae387cc91580f469aeda4d508b372b9ec1`; exact source paths, Git blob IDs,
hashes and original notices are in [caller/provenance](caller/provenance) and
[predecessor/SOURCE-LOCK.json](predecessor/SOURCE-LOCK.json). #7852 head
`41beda1d6435760dc99e38bd7e65f36798aad212` and main
`e54523517d0f03e58352e647c403a5af3e525a57` are contextual pins; no theorem from
them is invoked here.

With Python 3.11 or later and the standard library, run:

```sh
python3 -I -B replay.py
```

The replay authenticates the packaged files, runs the retained reader-cut
verifier, binds and hashes the actual caller stream, independently evaluates
the native tape forward and expands its arrival forms backward, verifies all
1,289 terminal responses on the three helper directions, and compares the
first-two and all-call image receipts. It reads only the package and makes no
network request. Its computational controls are not independent human review.
The five inherited premises `native_all_columns`, `owned_erasure`, `compiler`,
`precision_tape`, and `analytic_recovery` remain. See [NOTICE.md](NOTICE.md)
for credit and retained notices.
