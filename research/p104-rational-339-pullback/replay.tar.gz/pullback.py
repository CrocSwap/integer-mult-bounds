#!/usr/bin/env python3
"""Rank witness for chart-339 arrivals in the actual closed 48-call owner binding.

The exhibited 144-dimensional caller-input subspace turns all root main owners
off and uses three fresh, empty-chart helpers per call.  Thus this is an exact
image witness, not an assumption that complete native input domains are
independent.  It does not implement or price a physical shared repair.
"""
import gzip
import hashlib
import json
import sys
import time
from collections import Counter
from fractions import Fraction as Q
from pathlib import Path

T0=time.process_time()
HERE=Path(__file__).resolve().parent
NATIVE=HERE/'predecessor'
SRC=HERE/'caller'
sys.path[:0]=[str(SRC),str(SRC/'retained')]

PINS={
 NATIVE/'inputs/DOUBLE-CANDIDATE.json.gz':'1b1b3294e86979f1f41076fb056f3c0a08ace6df7bf80f2886bc579a22962f4b',
 NATIVE/'inputs/LAYOUT.json.gz':'b0f3ebc5710e469f3e8fc5ce159cbba048b563944182b50993431ef94f4fedbf',
 NATIVE/'inputs/DOUBLE-APPLICATION.json':'1b2d87e93ae023f5ffd464546af53281b6cb4963dfd76ae4742e0a5540b752fa',
 SRC/'closed_caller.py':'b82b9710d85d62e0f98aa1a1d7c70f97bdbdd64a6e4c92406019ca580a8c52ce',
 SRC/'retained/mixed_caller.py':'4824b2aaadb592550d3a25c16ff0a453705e10b8868f5c22fe10c2874bcb9bae',
 SRC/'retained/data/CALLER.json.gz':'d889996a337f648087208ab51c98eaf052705d4fca88b5d01b6e9257a829897a',
 SRC/'retained/data/CONJUGATE-CALLER.json.gz':'80009663da460229a57f09bde90e35294329a210ae7fc7ef6d1f05b61ffccbf4',
}
def digest(b):return hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
def load(p):
    b=p.read_bytes()
    return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b)
for path,sha in PINS.items(): assert digest(path.read_bytes())==sha,path
caller_pins=load(SRC/'provenance/SOURCE-PINS.json')
upstream_lock=load(SRC/'provenance/7786-SOURCE-LOCK.json')['sources']['source']
assert upstream_lock['commit']=='4f7c67ae387cc91580f469aeda4d508b372b9ec1'
assert len(caller_pins['files'])==4
for item in caller_pins['files']:
    path=HERE/item['file'];raw=path.read_bytes();source=item['source']
    original=upstream_lock['files'][source['path']]
    assert source['commit']==upstream_lock['commit'] and source['repo']==upstream_lock['repository']
    assert digest(raw)==item['sha256']==original['sha256']
    assert hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==item['git_blob']==original['blob']
from closed_caller import CALLS, placement, templates
from mixed_caller import instructions, layout_bindings
graph=load(NATIVE/'inputs/DOUBLE-CANDIDATE.json.gz')
layout=load(NATIVE/'inputs/LAYOUT.json.gz')
app=load(NATIVE/'inputs/DOUBLE-APPLICATION.json')
caller=load(SRC/'retained/data/CALLER.json.gz')
assert digest(canon(graph))==app['word_sha256']=='7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
assert digest(canon(layout))==app['layout_sha256']=='f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7'
assert app['caller']=='156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858'

words=templates(caller); roots=placement(caller)
bindings,offsets,receipt=layout_bindings(words,roots,layout,CALLS)
assert receipt==app['caller_census']['finite_binding']
hosted=layout['hosted']
second=dict(zip(hosted['Dports'],zip(hosted['X2'],hosted['Y2'],strict=True),strict=True))
slots={p:(x,x+112)+second.get(p,()) for p,x in enumerate(layout['live'])}
mains={r for z in slots.values() for r in z}
helpers=set(range(layout['public']))-mains
assert (CALLS,len(mains),len(helpers))==(48,400,889)
axes=[21,320,151]  # ordered to make the determinant evident
assert len(set(axes))==3 and set(axes)<=helpers
assert [layout['source_labels'][i] for i in axes]==[21,334,151]
assert all(graph['frames'][graph['initial'][i]]==[] for i in axes)

forms={i:{j:Q(q) for j,q in row} for i,row in graph['forms']}
order=graph['schedule']; at={slot:i for i,slot in enumerate(order)}
arrivals=[92034,92035,92032]
moves={i:(a,b) for i,a,b in graph['moves']}
assert [moves[i] for i in arrivals]==[(333,339),(333,339),(50,339)]
assert [at[i] for i in arrivals]==[2024,2157,1482]
assert [abs(len(graph['frames'][a])-len(graph['frames'][b])) for a,b in (moves[i] for i in arrivals)]==[1,1,2]

# Independent forward evaluation of the complete native tape on all three
# helper basis impulses at once. Each tuple is an exact input-column vector.
zero=(Q(0),)*3
values={~a:tuple(Q(i==j) for i in range(3)) for j,a in enumerate(axes)}
for key in order:
    out=[Q(0)]*3
    for source,coef in forms[key].items():
        src=values.get(source,zero)
        for j in range(3): out[j]+=coef*src[j]
    if any(out): values[key]=tuple(out)
matrix=[[values.get(k,zero)[j] for j in range(3)] for k in arrivals]
want=[[Q(1),-Q(1,2),-Q(1,4)],[Q(0),Q(1,2),Q(0)],[Q(0),Q(1,2),Q(1,16)]]
assert matrix==want
inverse=[[Q(1),-Q(3),Q(4)],[Q(0),Q(2),Q(0)],[Q(0),-Q(16),Q(16)]]
assert [[sum(matrix[i][k]*inverse[k][j] for k in range(3)) for j in range(3)] for i in range(3)]==[[Q(i==j) for j in range(3)] for i in range(3)]
two_call_minor=[[matrix[i%3][j%3] if i//3==j//3 else Q(0) for j in range(6)] for i in range(6)]
first=graph['first_output']
for i in range(layout['public']):
    expect=tuple(Q(i==a) for a in axes)
    assert values.get(first+i,zero)==expect, i
assert all(values.get(first+i,zero)==zero for i in mains)
det=matrix[0][0]*(matrix[1][1]*matrix[2][2]-matrix[1][2]*matrix[2][1])-matrix[0][1]*(matrix[1][0]*matrix[2][2]-matrix[1][2]*matrix[2][0])+matrix[0][2]*(matrix[1][0]*matrix[2][1]-matrix[1][1]*matrix[2][0])
assert det==Q(1,32)

# Replay the actual emitted caller *address and opcode stream* and authenticate
# every emitted row. In addition to the 48 native clocks, retain the complete
# immediate producer for every main coordinate touched by an arrival in the
# first two calls. PORT_VIEWS are accounted for as views, not scalar writes.
backward=[]
for target in arrivals:
    pending={target:Q(1)}
    for key in reversed(order):
        q=pending.pop(key,Q(0))
        if q:
            for j,c in forms[key].items():
                z=pending.get(j,Q(0))+q*c
                if z:pending[j]=z
                else:pending.pop(j,None)
    assert all(k<0 for k in pending)
    backward.append({~k:q for k,q in pending.items()})
assert [[r.get(j,Q(0)) for j in axes] for r in backward]==matrix
affected=sorted(set().union(*(set(r)&mains for r in backward)))
owners={start+i:(root,i) for root,start in offsets.items() for i in range(len(words[root[0]][1]))}
last={}; clocks=[]; maps=[]; direct_two_call_rows=[]; count=Counter(); h=hashlib.sha256()
native_seen=0; view_state='ENTER'
for clock,row in enumerate(instructions(words,roots,bindings,offsets)):
    h.update(json.dumps(row,separators=(',',':')).encode())
    op,*args=row;count[op]+=1
    if op=='PORT_VIEWS':
        direction,t,ports=args
        assert direction==view_state and ports==[bindings[t][p] for p in range(104)]
        view_state='NATIVE' if direction=='ENTER' else 'ENTER'
    elif op=='NATIVE':
        t,color,ports=args
        assert view_state=='NATIVE' and t==native_seen and color==t%16
        assert ports==[bindings[t][p] for p in range(104)]
        clocks.append(clock)
        if t<2:
            mapping={idx:(p,owner) for p,z in slots.items() for idx,owner in zip(z,ports[p],strict=True)}
            assert set(mapping)==mains and len({v[1] for v in mapping.values()})==400
            # Drive the real native word in six columns at the real first two
            # call positions. All main predecessors are zero on this chosen
            # subspace; the caller's intervening operations preserve zero.
            zero6=(Q(0),)*6
            local={~a:tuple(Q(k==3*t+j) for k in range(6)) for j,a in enumerate(axes)}
            for key in order:
                out=[Q(0)]*6
                for source,coef in forms[key].items():
                    if source in local:
                        for j,v in enumerate(local[source]):out[j]+=coef*v
                if any(out):local[key]=tuple(out)
            direct_two_call_rows.extend([local.get(slot,zero6) for slot in arrivals])
            assert all(local.get(first+i,zero6)==zero6 for i in mains)
            native_map=[]
            for idx in affected:
                p,o=mapping[idx]; root,role=owners[o]
                native_map.append({'native_index':idx,'port':p,'root':root,'role':role,'absolute_owner':o,
                                   'last_math_writer':last.get(o,{'kind':'independent_root_input'})})
            maps.append({'call':t,'color':color,'stream_clock':clock,
                         'fresh_helper_owners':[['helper',t,layout['source_labels'][a]] for a in axes],
                         'main_inputs':native_map})
        for p,port in enumerate(ports):
            for owner in port:last[owner]={'kind':'native_output','call':t,'port':p,'stream_clock':clock}
        native_seen+=1;view_state='EXIT'
    else:
        assert view_state=='ENTER'
        assert op in ('ADD','SCALE','SWAP','QUERY','LAMBDA','IDLE_ONE','IDLE_ODD')
        targets=args[:2] if op=='SWAP' else args[:1]
        for owner in targets:last[owner]={'kind':'caller_operation','event':row,'stream_clock':clock}
assert native_seen==48 and view_state=='ENTER'
assert sum(count.values())==840912 and h.hexdigest()==app['caller']
assert dict(count)==app['caller_proof']['readback']['op_counts']
assert direct_two_call_rows==[tuple(row) for row in two_call_minor]

report={
 'scope':'exact image witness for literal arrivals under the pinned closed caller; no proposed physical repair or channel-price claim',
 'pin_7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'comparison_7852':'41beda1d6435760dc99e38bd7e65f36798aad212 (context only)',
 'comparison_main':'e54523517d0f03e58352e647c403a5af3e525a57 (context only)',
 'word_sha256':app['word_sha256'],'layout_sha256':app['layout_sha256'],
 'caller_stream_sha256':h.hexdigest(),'caller_stream_events':sum(count.values()),
 'binding':receipt,'native_arrivals':arrivals,'native_arrival_clocks':[at[x] for x in arrivals],
 'native_routes':[list(moves[i]) for i in arrivals],'native_grades':[1,1,2],
 'helper_native_indices':axes,'helper_source_labels':[layout['source_labels'][a] for a in axes],
 'helper_initial_frames':[graph['frames'][graph['initial'][a]] for a in axes],
 'arrival_helper_minor':[[str(q) for q in row] for row in matrix],
 'arrival_basis_probes_on_helpers':[[str(q) for q in row] for row in inverse],
 'arrival_native_main_coefficients':[{str(i):str(row[i]) for i in sorted(set(row)&mains)} for row in backward],
 'two_call_minor':[[str(q) for q in row] for row in two_call_minor],
 'minor_determinant':str(det),'forward_checked_all_1289_terminal_rows':True,
 'forward_main_output_responses_nonzero':0,
 'first_two_call_mapping':maps,'all_call_stream_clocks':clocks,
 'two_call_subspace_minor_determinant':str(det**2),'two_call_row_rank':6,
 'all_calls_subspace_minor_determinant':str(det**48),'all_calls_row_rank':144,
 'argument':('At each call independently set only the three distinct fresh helper entrance owners. '
             'The tape sends them through the stated invertible minor while all 400 main outputs are zero. '
             'All other helper terminal outputs are same-owner outputs and are not caller inputs. '
             'With all 9840 initial main owners zero, linear caller operations and view changes preserve zero; '
             'induction gives a block-diagonal image minor for 48 calls. This is an exact restriction '
             'of the closed caller input domain, not a model of independent complete native input domains.'),
 'remaining_limits':['No full 144-row formula on every caller input is needed or claimed.',
                     'Rank counts independent scalar field values, not geometric channel grades or physical routing cost.',
                     'Changed readers, downstream operators, target fields or changed callers are outside scope.'],
}
if '--write-result' in sys.argv[1:]:
    (HERE/'PULLBACK-RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
else:
    assert canon(json.loads((HERE/'PULLBACK-RESULT.json').read_text()))==canon(report), 'pullback receipt mismatch'
print('PASS actual caller stream',len(clocks),'calls,',sum(count.values()),'events')
print('first native event clocks',clocks[:2])
print('native helper 3x3 determinant',det,'; first 2 rank 6 ; 48 rank 144')
print('fresh helper axes',axes,'labels',[layout['source_labels'][a] for a in axes])
print('all terminal rows checked on helper impulses; 400 main outputs zero')
print('CPU seconds',round(time.process_time()-T0,3))
