#!/usr/bin/env python3
"""Verify the chart-339 input minor and independently replay its pulse controls."""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha1,sha256
from pathlib import Path
import gzip,json
from common import margin,enclose

HERE=Path(__file__).resolve().parent
TARGET='0.003884928046155'
WORD='7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
LAYOUT='f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7'
CALLER='156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858'

def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def det(m):return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0])

def main():
 lock=json.loads((HERE/'SOURCE-LOCK.json').read_bytes());assert len(lock)==3
 for item in lock:
  raw=(HERE/item['file']).read_bytes()
  assert sha256(raw).hexdigest()==item['sha256']
  assert sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==item['git_blob']
 graph=json.loads(gzip.decompress((HERE/'inputs/DOUBLE-CANDIDATE.json.gz').read_bytes()))
 layout=json.loads(gzip.decompress((HERE/'inputs/LAYOUT.json.gz').read_bytes()))
 app=json.loads((HERE/'inputs/DOUBLE-APPLICATION.json').read_bytes())
 assert sha256(canon(graph)).hexdigest()==WORD==app['word_sha256']
 assert sha256(canon(layout)).hexdigest()==LAYOUT==app['layout_sha256']
 assert app['caller']==CALLER and graph['frames']==layout['frames']
 n=len(graph['initial']);first=graph['first_output'];assert n==len(graph['final'])==1289
 moves={i:(a,b) for i,a,b in graph['moves']};forms={i:{k:F(v) for k,v in row} for i,row in graph['forms']};order=graph['schedule'];at={i:t for t,i in enumerate(order)}
 assert len(moves)==5707 and len(forms)==len(order)==len(at)==6996
 # Independently check all 220217 scalar local reads, not merely the named rows.
 source={i:a for i,(a,b) in moves.items()}|{first+i:c for i,c in enumerate(graph['final'])}
 deposit={~i:c for i,c in enumerate(graph['initial'])}|{i:b for i,(a,b) in moves.items()}
 assert set(source)==set(forms)==set(order)
 terms=0
 for i in order:
  for k,q in forms[i].items():
   assert q and k in deposit and deposit[k]==source[i]
   assert k<0 or at[k]<at[i]
   terms+=1
 assert terms==220217
 trio=[92034,92035,92032];readers=[98755,89065,92041]
 assert [moves[i] for i in trio]==[(333,339),(333,339),(50,339)]
 assert [abs(len(graph['frames'][a])-len(graph['frames'][b])) for a,b in (moves[i] for i in trio)]==[1,1,2]
 assert [at[i] for i in trio]==[2024,2157,1482] and [at[i] for i in readers]==[2755,2895,2896]
 assert not [i for i,a in enumerate(graph['initial']) if a==339]
 assert sorted(i for i,(a,b) in moves.items() if b==339)==sorted(trio)
 assert [i for i in order if any(k in forms[i] for k in trio)]==readers
 assert all(set(forms[i])<=set(trio) for i in readers)
 M=[[forms[i].get(k,F(0)) for k in trio] for i in readers]
 assert M==[[F(1),F(0),F(4)],[F(0),F(-4),F(4)],[F(-1),F(1),F(-4)]] and det(M)==-4
 # Exact backward pullback for each paid arrival to all independent input axes.
 def expand(target):
  pending={target:F(1)}
  for i in reversed(order):
   q=pending.pop(i,F(0))
   if q:
    for k,v in forms[i].items():
     t=pending.get(k,F(0))+q*v
     if t:pending[k]=t
     else:pending.pop(k,None)
  assert all(k<0 for k in pending)
  return {~k:v for k,v in pending.items()}
 rows=[expand(i) for i in trio]
 assert [len(row) for row in rows]==[233,17,31]
 axes=[21,54,320];N=[[row.get(i,F(0)) for i in axes] for row in rows]
 assert N==[[F(1),F(0),F(-1,2)],[F(0),F(0),F(1,2)],[F(0),F(1,4),F(1,2)]] and det(N)==F(-1,8)
 probes=[{21:F(1)},{21:F(1),54:F(-4),320:F(2)},{54:F(4)}]
 # Direct forward tape replay is separate from the backward coefficient expansion.
 def replay(probe,withhold=None):
  vals={~i:q for i,q in probe.items() if q}
  for i in order:
   z=F(0) if i==withhold else sum((q*vals.get(k,F(0)) for k,q in forms[i].items()),F(0))
   if z:vals[i]=z
  return vals
 results=[]
 for j,probe in enumerate(probes):
  vals=replay(probe);arrivals=[vals.get(i,F(0)) for i in trio];observed=[vals.get(i,F(0)) for i in readers]
  assert arrivals==[F(i==j) for i in range(3)] and observed==[row[j] for row in M]
  results.append(vals)
 omitted=replay(probes[1],92035);baseline=results[1]
 assert [baseline.get(i,F(0)) for i in readers]==[0,-4,1]
 assert [omitted.get(i,F(0)) for i in readers]==[0,0,0]
 changed=[{'slot':i,'coordinate':i-first,'before':str(baseline.get(i,F(0))),'after':str(omitted.get(i,F(0)))} for i in range(first,first+n) if baseline.get(i,F(0))!=omitted.get(i,F(0))]
 assert len(changed)==309 and sha256(canon(changed)).hexdigest()=='2cc89e73d7a1ffba5414b62aa9d3472ef9eb196dcb9dea3711a55be90e6ad387'
 # Reprice the full 48-call rational baseline and the hypothetical rank-48 restore.
 paid=Counter({int(k):v for k,v in app['application']['invoice']['paid'].items()})
 targets=Counter({int(k):v for k,v in app['application']['invoice']['targets'].items()})
 base=margin(paid,targets,TARGET)
 assert enclose(base)==['-4.880391089954707282632121322599412665463258252','-4.880391089954707282632121322599412665463258251']
 h48=margin(Counter(),Counter({48:1}),TARGET)
 assert enclose(h48)==['47.283513054861679563349761123481154105727322888','47.283513054861679563349761123481154105727322889']
 gain=(F(48)-h48[1],F(48)-h48[0]);short=(-base[1]-gain[1],-base[0]-gain[0])
 assert enclose(gain)==['0.716486945138320436650238876518845894272677111','0.716486945138320436650238876518845894272677112']
 assert enclose(short)==['4.163904144816386845981882446080566771190581139','4.163904144816386845981882446080566771190581140']
 result=json.loads((HERE/'RESULT.json').read_bytes())
 assert result['source']['word_sha256']==WORD and result['reader_determinant']=='-4' and result['arrival_minor_determinant']=='-1/8'
 assert result['withheld_probe']['changed_terminals']==309 and result['price']['conditional_joint_48']['remaining_shortfall_lower']=='4.163904144816386845981882446080566771190581139'
 print('PASS: authenticated source, chronology and all 220217 local scalar reads')
 print('PASS: exact all-input rank-three arrival minor and rank-three protected readers')
 print('PASS: independent forward pulse replay; withheld slot changes 309 terminals')
 print('PASS: original full price and arithmetic under the hypothesized grade-48 repair')

if __name__=='__main__':main()
