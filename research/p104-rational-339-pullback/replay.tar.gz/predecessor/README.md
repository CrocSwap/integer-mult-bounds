# Chart-339 paid-arrival reader cut

> **Combined-package update.** This predecessor establishes the local cut.
> The [48-call pullback](../README.md) establishes the actual caller's joint
> scalar image rank. The conditional `H(48)` comparison below additionally
> assumes that the repair's total charged geometric grade is at least its
> scalar information dimension; neither the predecessor nor the new pullback
> proves that physical assumption.

Three scalar arrivals in the pinned #7830 rational word cannot be replaced by only two rational-linear arrivals while preserving their three original immediate reader values. The statement holds for arbitrary independent rational public inputs, even if both retained arrivals are granted arbitrary rational-linear access to every public input and are available before the first reader. It is a local reader cut, not a general supplier wall or a new κ bound.

The three original arrivals are:

| Slot | Route | Grade | Native clock |
| --- | --- | ---: | ---: |
| 92034 | 333 → 339 | 1 | 2024 |
| 92035 | 333 → 339 | 1 | 2157 |
| 92032 | 50 → 339 | 2 | 1482 |

Chart 339 has no initial fields and these are its only paid arrivals in the original word. Its first old reader is slot 98755 at clock 2755, after all three arrivals. The only immediate readers of the three arrivals are 98755, 89065 and 92041, at clocks 2755, 2895 and 2896. In the arrival order above, their exact coefficient matrix is

```text
  1   0   4
  0  -4   4
 -1   1  -4
```

This matrix has determinant `−4`. Exact backward expansion of the three paid forms on the 1,289 independent public inputs produces the following minor on coordinates 21, 54 and 320:

```text
 1   0   -1/2
 0   0    1/2
 0  1/4   1/2
```

Its determinant is `−1/8`. Hence all three arrival values vary independently, and the three protected reader forms have rank three. Two scalar arrivals, even with unrestricted rational-linear source functions, can transmit at most two independent directions. Granting all other original chart-339 stock at any time does not change the argument because the pinned word has none.

An independent **forward tape evaluation**, separate from the backward coefficient expansion, checks three explicit sparse input probes. The probe `x21 = 1`, `x54 = −4`, `x320 = 2` makes the original arrival triple `(0, 1, 0)`. Withholding slot 92035 on this probe changes the three old reader values from `(0, −4, 1)` to `(0, 0, 0)` and changes **309 of 1,289 terminal values**. This is a negative control on one probe, not an exhaustive all-column replay of a replacement word. The exact minor proves the local rank claim for all inputs.

The scope fixes the three original reader values and treats other old paid and productive bills as unchanged. It does not exclude changing downstream reader operators, adding differently funded traffic, changing target fields, a different global caller, or correlated caller inputs. There is no new candidate word or full finite application here.

## Conditional price comparison

At `κ = 0.003884928046155`, the complete original 48-call rational invoice has signed margin between `−4.880391089954707282632121322599412665463258252` and `−4.880391089954707282632121322599412665463258251`. Retiring one of the grade-one arrivals saves `48 H(1) = 48` units across the original 48 calls, with `H(r)=r^(1−κ)`. If each native call restores its missing direction through an additional grade-one paid transfer, its minimum cost is also 48, leaving no improvement before other costs.

For a more generous hypothetical, **assume 48 independent native input domains**, unrestricted joint linear coding, free placement, and that any repair must have total charged geometric grade at least its number of independent scalar directions. The last premise is an additional physical-price assumption: scalar direction count alone does not establish channel grade. Under all of these assumptions, restoring the missing direction requires total charged grade at least 48; concavity of `H` then gives a lower bound of `H(48)` on the sum of those tariffs. Directed dyadic arithmetic encloses `H(48)` between `47.283513054861679563349761123481154105727322888` and `47.283513054861679563349761123481154105727322889`. The maximum favorable net gain is therefore at most `0.716486945138320436650238876518845894272677112`, leaving rational shortfall at least `4.163904144816386845981882446080566771190581139` under these assumptions and fixed other bills.

The predecessor calculation did not prove the actual complete caller's pullback independent. The combined-package update proves the required 144-dimensional **scalar image subspace** for that caller; it does not prove the additional scalar-dimension-to-geometric-grade price premise. A changed caller needs its own global rank and price replay. The binary side is separate. This comparison makes no κ claim and does not discharge any inherited framework premise.

## Reproduce

With Python 3.11 or later, run from this directory:

```sh
python3 -B verify.py
```

The package requires only the Python standard library and has no network or workstation-path dependency. The verifier authenticates the three public inputs using SHA-256 and Git blob identifiers; rebuilds the complete chronology and checks all 220,217 local scalar reads for stock residence and earlier availability; verifies both exact `3 × 3` minors; evaluates the three probes in a forward pass; verifies the 309 changed-terminal count and the canonical changed-list hash; and recomputes the full rational baseline and conditional rank-48 price with directed arithmetic. [RESULT.json](RESULT.json) contains the machine-readable claims. The forward control and backward pullback are separate implementations of the calculation, not an independent human review.

The pinned rational word has canonical SHA-256 `7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48`; layout canonical SHA-256 `f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7`; unchanged caller macro `156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858`; and complete rational application SHA-256 `1b2d87e93ae023f5ffd464546af53281b6cb4963dfd76ae4742e0a5540b752fa`. The predecessor public exports and blob hashes are in [SOURCE-LOCK.json](SOURCE-LOCK.json). The rational word is retained in #7830 head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`.

## Credit

Credit the source #7786/#7781, Ali Romman's #7776 carrier, tariff and caller, #7774 restored chain, and Clear1nsight's #7830 double-chain construction. This scoped chart-339 cut and the separate computational control were prepared with OpenAI Codex assistance. The existing conditional construction retains `native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery`.
