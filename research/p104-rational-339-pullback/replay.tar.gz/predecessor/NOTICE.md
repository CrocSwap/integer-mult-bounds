# Source and attribution

The selected #7830 rational word and complete 48-call application are by Clear1nsight with OpenAI Codex assistance. They build on #7786/#7781, Ali Romman's #7776 carrier, tariff and caller, and #7774's restored chain. Exact predecessor paths, compressed SHA-256 and Git blob identifiers are in SOURCE-LOCK.json. The three input files are retained unmodified.

The directed dyadic price routine in `common.py` is retained from earlier local comparator review work. The chart-339 local rank cut and independent forward control are new computational work prepared with OpenAI Codex assistance. No contributor is represented as having independently reviewed this extension. The repository Apache-2.0 license is retained in LICENSE.
