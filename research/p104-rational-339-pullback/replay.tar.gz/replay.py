#!/usr/bin/env python3
"""Read-only verification of the combined chart-339 package."""
from hashlib import sha256
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
for line in (HERE/'SHA256SUMS').read_text().splitlines():
    expected,path=line.split('  ',1)
    p=HERE/path
    assert p.is_file() and sha256(p.read_bytes()).hexdigest()==expected,path
print('PASS package SHA-256 manifest',flush=True)
subprocess.run([sys.executable,'-B',str(HERE/'predecessor/verify.py')],cwd=HERE/'predecessor',check=True)
subprocess.run([sys.executable,'-B',str(HERE/'pullback.py')],cwd=HERE,check=True)
print('PASS combined reader cut and caller pullback',flush=True)
