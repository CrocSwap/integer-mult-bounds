# Credit and retained sources

The #7830 rational word and application are by Clear1nsight with OpenAI Codex
assistance and build on #7786/#7781, Ali Romman's #7776 carrier, tariff and
caller, and the #7774 restored chain. The retained chart-339 reader cut and
its controls are described and credited in [predecessor/NOTICE.md](predecessor/NOTICE.md).
The combined package updates that predecessor's interpretation text, result
condition, and verifier's final print message to distinguish the additional
geometric-grade pricing assumption; its source inputs and rank computations
are retained.

Ali Romman prepared the 48-call cyclic seam, finite placement and integration
with substantial OpenAI Codex assistance. The retained signed caller and
predecessor contributions are credited in [caller/provenance/CALLER.md](caller/provenance/CALLER.md),
[caller/provenance/CREDITS.md](caller/provenance/CREDITS.md), and the original
notices in [caller/provenance/credits](caller/provenance/credits). The included
[caller/provenance/SOURCE-PINS.json](caller/provenance/SOURCE-PINS.json) is
derived from the retained #7786 source lock and maps the copied caller files to
their original source paths, Git blob IDs, and SHA-256 hashes.

The actual-caller pullback and its computational controls were prepared with
OpenAI Codex assistance. No contributor is represented as having independently
reviewed this extension. Apache-2.0; see [LICENSE](LICENSE).
