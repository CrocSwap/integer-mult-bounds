#!/usr/bin/env python3
"""Independent exact 451-factor arithmetic on the actual incumbent histogram."""
import hashlib,json,importlib.util
from collections import Counter
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base',H/'replay_bit.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
need=b.need
pins={'BIT-451.json':'538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749','CLEAN-CONSUMER.json':'ba826926d913ba7826679332e650d23b7d0c7272a5503e8e7d65a55f00e3bcbe'}
def load(n):
 x=(H/'inputs'/n).read_bytes();need(hashlib.sha256(x).hexdigest()==pins[n],'source pin');return json.loads(x)
def main():
 src=load('BIT-451.json');consumer=load('CLEAN-CONSUMER.json');bit=b.load('BIT.json')['native']
 paid=Counter({int(k):v for k,v in bit['paid'].items()});prod=Counter({int(k):v for k,v in bit['targets'].items()})
 need(paid==Counter({int(k):v for k,v in src['native']['paid'].items()}) and prod==Counter({int(k):v for k,v in src['native']['targets'].items()}),'same actual complete native caller invoice')
 sep=src['separation'];trial=Decimal('0.003879928046148');wanted=b.hist(prod,Decimal(1)-trial)
 ratios={'alpha':b.div(b.hist(paid,Decimal(1)-trial),wanted),'gamma':b.div(b.hist(paid,Decimal(1)-trial+Decimal('0.26')),b.mul(b.pow_interval(11,Decimal('0.26')),wanted)),'lambda':b.div(b.mul(b.pow_interval(16,Decimal('0.34')),b.hist(prod,Decimal(1)-trial-Decimal('0.34'))),wanted)}
 caps={k:Fraction(v) for k,v in sep['caps'].items()};need(all(Fraction(v[1])<=caps[k]<1 for k,v in ratios.items()),'candidate directed ratios')
 def surplus(v):return 1-(1/(1+v*(1-caps['alpha']))+2*caps['gamma']**v+caps['lambda']**v)
 gap=surplus(451);need(gap>Fraction('0.000000000000584806244632162134') and surplus(448)<0,'exact finite 451 success/448 failure')
 u=src['uniform'];h=u['H'];step=400000000000
 need(h==step*3006 and (h+1)**60<2**3006 and (h-step+1)**60>=2**3005,'uniform integer grid')
 theta=Fraction(13,15);need(11**15<16**13 and 2**2*11**(451*15)<=134**(451*13),'separated cutoff and ambient')
 ambient=b.pow_interval(134,trial*451);eta=b.div((Decimal(1)-trial,Decimal(1)-trial),ambient)
 need(theta**60<Fraction(eta[0]) and Fraction(eta[1])<=theta**59 and Fraction(ambient[1])<2**60,'independent ambient log-power interval')
 c=src['cover_and_stock'];d=Fraction(c['loss']);need(Fraction(64,2**52)<d/4 and Fraction(64,2**51)>=d/4,'whole-cover q threshold')
 prev=Fraction(c['seed']);rho=Fraction(c['rho']);covered=Fraction(c['covered'])
 for x in c['stages']:
  env=rho*prev+(1-rho)*covered;new=Fraction(x['claim']);need(Fraction(x['previous'])==prev and env==Fraction(x['envelope_exact']) and env-new==Fraction(x['strict_gap_exact']) and env>new>prev,'strict funded ordinary stage');prev=new
 need(prev==Fraction(c['ordinary_admitted']) and len(c['stages'])==7,'seven stage cap')
 need(consumer['binary_receipt_sha256']==pins['BIT-451.json'] and consumer['binary_ordinary']==c['ordinary_admitted'] and consumer['application_and_audit_byte_equal'],'bound source consumer receipt')
 claim=Fraction(consumer['claim']);tested=Fraction(consumer['outer']['tested']);need(prev-tested==Fraction(consumer['outer']['cap_headroom']) and claim<tested<prev,'source outer cap headroom')
 need(consumer['premises']==src['premises']==['native_all_columns','owned_erasure','compiler','precision_tape','analytic_recovery'],'named premises')
 print(json.dumps({'status':'PASS_451_INCUMBENT_FINITE_ARITHMETIC','source_head':'b3e4412fe01f07dc58305616fabf96345f49a781','source_sha256':pins,'unchanged_36_call_invoice':True,'trial':str(trial),'power':451,'strict_normalized_surplus_gt':'0.000000000000584806244632162134','448_control_negative':True,'directed_ratio_upper_valid':list(ratios),'uniform_H':h,'log_power':60,'q_exponent':52,'ordinary_stages':7,'binary_ordinary_cap':str(c['ordinary_admitted']),'outer_claim_source_receipt_only':consumer['claim'],'outer_tested_source_receipt_only':str(tested),'outer_headroom':consumer['outer']['cap_headroom'],'outer_checks_source_receipt_only':{'strict':consumer['outer']['strict_count'],'functional':consumer['outer']['functional_count']},'premises':consumer['premises'],'scope':'Independent finite numeric inequalities and actual histogram equality. The pinned consumer is a prior isolated replay, not rerun by this script. Tensor, cover, stock and physical/precision contracts are not materialized or independently proved.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
