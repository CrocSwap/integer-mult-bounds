# Independent Round 5 replay: incumbent, caller, and sink

All results here are read-only, source-pinned checks. They establish no new κ
bound. The incumbent word and the #7912 changed word are interpreted using
literal `CLEAR` discard semantics; dirty retirement is not a physical
uncomputation proof. The conditional results retain the five premises
`native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and
`analytic_recovery`.

## Pinned incumbent and zero-price control

`replay_bit.py` reads #7830 head
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, canonical native word
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`,
and the actual paired caller. It reconstructs each native arbitrary-input
operator and transpose and enumerates all actual caller events, targets and
paid positions. The #7912 head is
`83ece5a62d3addbee45bad9594ef4809851b833b`, with canonical changed word
`09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be`.
Its complete 36-call paid and productive histograms each lose 36 grade-4
entries. The signed change is exactly zero. The word has 3,552 dirty private
retirements in each literal orientation. The reconstruction binds every
call-specific helper and paid address and rejects a same-grade swap of
original helper owners 222 and 223. Candidate address 649 is original owner
650, not deleted owner 649. The reconstruction authenticates and reproduces
the full Round 4 36-call tables.

At K `0.003879928046156`, the original and zero-control BIT margins are
`−0.0000000007670015024311302614639995…`; at the near trial
`0.003879929046155` they are `−0.000385127316613866441054139472…`.
All printed bounds in `BIT-REPLAY.json` are outward 90-digit Decimal intervals.
The 480-factor #7830 finite arithmetic also passes: all six independently
repriced ratio caps, strict normalized surplus above
`0.0000000000012309863319385`, uniform grid, and five ordinary stage
inequalities. This is finite arithmetic under the stated premises, not a
materialized tensor or stock.

## Rational side and bounded scalar precision

`replay_rational.py` independently parses the original 1,289-owner rational
graph and exact chronology, checks all 1,289 arbitrary-input rational rows
and their adjoint rows, and constructs the actual 48-call schedule. Each call
has 400 distinct main bindings and 889 helper owners; the schedule binds 120
A and 192 rotated roots. Its paid and productive counts exactly reproduce the
source audit. At K the rational margin is
`+0.212262470163346755368717273679…`; at the near trial it is
`+0.211243929926514344381566367581…`.

The program checks each of 13,030,044 basis products, including 7,535,400
products with a nonunit literal denominator, on the exact grid
`3203382489907091224335482880000`. An odd scaled product identifies why
halving the grid fails. Incumbent address 324 binds original owner 338;
a label swap with unchanged inventory is rejected by that binding. These are
exact rational-scalar and caller-binding checks, not a full multidimensional
Gaussian field execution, physical erasure, or analytic recovery theorem.

## 451-factor incumbent arithmetic and receiver boundary

`replay_451.py` independently reprices #7863 head
`b3e4412fe01f07dc58305616fabf96345f49a781` against the actual original
36-call histogram. The three directed caps pass, the exact 451-factor
normalized surplus exceeds `0.000000000000584806244632162134`, and the 448
control fails. The uniform carrier integer inequality, recorded large-prime
cover threshold, and seven strict stage envelopes pass; the binary cap is
`0.00387992804354799998`. A byte-pinned earlier isolated consumer receipt
reports conditional κ `0.00387992804346`; this package does not rerun that
outer consumer or materialize its finite tensor, cover, stock, or tape.

`replay_interface.py` independently verifies the relevant #7914 Git blobs
and traces the installed SourceRule through `binary_ports`, `bit_word`, and
the `Weighted` receiver. The installed rule is 480 factors, floor 16, cuts
10 and 11, ternary stock and six stages. The #7863 receipt instead describes
451 factors, the all-11 cut and a particular prime `q > 2^(6012000000000052)`.
The installed sixth rate is exactly `3907/500000000000000` below the
candidate consumer rate. A pinned real rank-4-by-14^450 paid path and the
#7912 product-floor owner crossing independently agree with the source
receipts. This shows an interface mismatch between these implementations; it
does not exclude a new 3-local proof, a different prime receiver, or another
properly funded construction.

## Four-query caller

`replay_caller.py` uses the separately produced candidate gzip SHA-256
`f38ad467dc02450f35a57d6e5868bc91e34d356576c926ea839f0a55894bef21`.
It directly checks all 1,444 formal forward and transpose coefficients in
`F2[q,D1,…,D18]/(q²−1)`, without specializing q or inverting any D. It
recounts the actual 36 disjoint per-stage local calls, 111 ports per call,
32 idles, four queries and complete paid/productive bins. Those bins are
identical to the incumbent and the signed change is zero. The inherited raw
tariff gives ordinary records `934181764128`, versus `934182831504` for
the old caller; it is a modeled ordinary saving only. Missing ADD, LOCAL,
QUERY, or IDLE operations, QUERY→ADD, lost root head and an overlapping main
owner are all rejected. All-width cochart/off-plane embedding, physical
QUERY lifecycle, dirty erasure, stock and precision are separate obligations.

## Terminal sink matroid

`replay_sink.py` independently reconstructs the source tape using low-bit
pivots and pre-reduced stock bases; it does not invoke the producer's matroid
or intersection routines. At the original chart-1 terminal decoder, all
537 input/arrival rows form an independent basis. Exactly 97 of those
positions can be omitted without touching a protected one of the 222 main
outputs or owner 411. Their exact labels match the independently pinned
`SINK-MATROID.json` receipt.

A candidate may omit any subset of those 97 arrivals and retarget helper
outputs, using an arbitrary decoder and invertible source-basis changes within
one original start chart. Other paid packet values/routes and their original
stock are fixed; the relaxation grants the whole historical stock of each
existing non-sink chart for free, even when real timing or storage would make
it unavailable. It introduces no extra paid route. For every source chart and
allowable terminal chart, the checker obtains the entire intersection of
available stock with original same-start input coordinates. Each stock
intersection is priced by `H(old grade)−H(new grade)` and each retained
packet by `H(old paid grade)`, where `H(r)=r^(1−κ)`.

The minimum-cost 97-dimensional binary matroid basis gives an upper bound on
savings over every one of the `2^97` omission subsets. At both rates its
rank-by-price filtration is `47, 93, 93, 97, 97, 97, 97` and its best signed
change is exactly zero. In addition, 2,158 directed price/coordinate checks
show that each available intersection vector detecting a removed coordinate
costs at least that packet's credit; this extends to all XOR combinations by
linearity and gives the corresponding matching proof. A synthetic *free* new
observation yields a positive change, confirming the checker detects one.

For retargeting more than k helpers after k omitted ingress rows, the proof
selects a spanning subset of the retargets and charges the remainder. The
checker also enumerates **unprojected** stock-intersection bases for every
source group, including alternatives with no projection on the 97-space. No
allowed alternative has a greater new grade than its original sink grade,
so every extra retarget has nonnegative debit. This extension still assumes
the stated fixed-stock, same-start, no-new-paid-route model; source actions
crossing groups, altered exterior packet values, new routes, timing changes,
or a new native construction are outside the conclusion. A raw zero price is
not a physical supplier or a κ improvement.

## Funded combined sink replacement

`replay_combined.py` independently extends the cut to **all 537** original
sink positions. It computes the input-space duals of the original sink rows
from the literal public operator, verifies the 537×537 identity, and checks
that every unchanged non-sink terminal annihilates these directions. The
original sink's native paid ranks are 342 of grade 1, 189 of grade 2 and six
of grade 4.

The stronger relaxation allows any number of newly paid direct ingresses
from any existing non-sink chart into chart 1, as well as same-start helper
retargets, in the same proposed change. Every such ingress can use the entire
frozen historical stock of its chart for free. The checker tests 2,969
nonzero projected old-stock rows for paid routes and 929 independently
reduced same-start intersection rows for retargets, as well as the 537
original arrivals. These reduced basis counts need not equal those of a
checker using unreduced stock. Across both trial rates, 26,610 directed
cost-class/old-grade comparisons find no available row cheaper than an
original direction on which it has nonzero pairing. The exact weighted
rank filtration reaches 342, 531, 531 and then 537; all later classes
remain at 537. A full-rank set has a nonzero determinant term and therefore
a matching to all 537 original directions. Every matched row costs at least
its matched original packet, and all extra retarget costs are nonnegative.
Thus the full 36-call signed change is at most zero in this combined model.
A synthetic free direct route gives +1 per native call and is detected.

This result fixes the other native packet payloads/routes and terminal chart,
protects the main and 411 outputs, and allows same-start but not cross-start
input action. It does not establish a physically realizable changed word or
exclude new exterior stock, altered non-sink packets or more general caller
and supplier changes.

## Reproduction and sources

Run with Python 3.10+ standard library and assertions enabled:

```sh
sha256sum -c SHA256SUMS
python3 -I -B replay_bit.py > /tmp/p104-bit-check.json
python3 -I -B replay_rational.py > /tmp/p104-rational-check.json
python3 -I -B replay_caller.py > /tmp/p104-caller-check.json
python3 -I -B replay_451.py > /tmp/p104-finite-check.json
python3 -I -B replay_interface.py > /tmp/p104-interface-check.json
python3 -I -B replay_sink.py > /tmp/p104-sink-check.json
python3 -I -B replay_combined.py > /tmp/p104-combined-check.json
```

The seven receipts were rerun in a fresh copy and match byte for byte; see
`CLEAN-REPLAY.json`. The complete rational run took under 20 seconds and
under 200 MiB on this machine. The input filenames are local copies of the
pinned source bytes and published/reviewed receipts. `inputs/peer/NOTICE.md`
retains the #7914 predecessor's notices. The R5 sink input receipt was
produced by the separate Astra research stream and independently checked
here. These checks do not constitute human review or maintainer selection.
