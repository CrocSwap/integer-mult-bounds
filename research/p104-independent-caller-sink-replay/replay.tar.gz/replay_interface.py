#!/usr/bin/env python3
"""Independent source-interface and exact one-path screen, not a physical compiler."""
import ast,hashlib,importlib.util,json
from fractions import Fraction
from pathlib import Path
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base',H/'replay_bit.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
need=b.need
P={'compiler_cut.py':'c4c4ef3f5ec8a7dc4a8853110adf445117c77d0c','ordinary.py':'a24d49ec18f76c6a454c79c4d7cb008b0b35f49b','growing_binary.py':'a004121c0914deb8f91766479a2a049937c07fb6','bound.py':'66328e3fd615038d11894e7e7b7c799bdbe0e41d','OUTER.md':'c4367a5cdcb9030140d577a5c66cc66ac7463669','powered.py':'e492c67e1a941f9a8ebabd9efc2613752f659664','tagged_sources.py':'a3caf3390ead8cee7753a8b6e43b1d8f6643f0dc'}
def read(n):
 x=(H/'inputs/peer'/n).read_bytes();need(hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()==P[n],'pinned Git blob '+n);return x.decode()
def function(tree,name):
 xs=[x for x in ast.walk(tree) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name==name];need(len(xs)==1,'unique function '+name);return xs[0]
def calls(fn,name):return [x for x in ast.walk(fn) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name) and x.func.id==name]
def main():
 text={n:read(n) for n in P};trees={n:ast.parse(s) for n,s in text.items() if n.endswith('.py')}
 power=function(trees['powered.py'],'bit_word');ret=next(x for x in ast.walk(power) if isinstance(x,ast.Return)).value
 need(isinstance(ret,ast.Call) and isinstance(ret.func,ast.Name) and ret.func.id=='PoweredWord','source returned actual powered class')
 args=ret.args;shape=[ast.literal_eval(args[i]) for i in (0,3,4,5,6)];need(shape==[134,480,16,10,11],'installed actual powered shape')
 portfn=function(trees['tagged_sources.py'],'binary_ports');need(len(calls(portfn,'bit_word'))==1,'source routes binary ports into bit_word')
 sourceclass=next(x for x in trees['compiler_cut.py'].body if isinstance(x,ast.ClassDef) and x.name=='SourceRule');init=function(sourceclass,'__init__');need(len(calls(init,'binary_ports'))==1,'source rule uses binary ports')
 weighted=next(x for x in trees['growing_binary.py'].body if isinstance(x,ast.ClassDef) and x.name=='Weighted');wi=function(weighted,'__init__');need(len(calls(wi,'source_rule'))==1,'receiver consumes source rule')
 assign={x.targets[0].attr:x.value for x in wi.body if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Attribute)}
 need(isinstance(assign['modulus'],ast.BinOp) and isinstance(assign['modulus'].op,ast.Pow) and ast.literal_eval(assign['modulus'].left)==3,'installed modulus is base three')
 swap=function(trees['ordinary.py'],'ordinary_swap');sw=calls(swap,'exchange_binary');need(len(sw)==1 and isinstance(sw[0].args[-2],ast.Name) and sw[0].args[-2].id=='H' and ast.literal_eval(sw[0].args[-1])==6,'installed stage six entry')
 spec2=importlib.util.spec_from_file_location('peer_bound',H/'inputs/peer/bound.py');peer=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(peer)
 candidate=json.loads((H/'inputs/BIT-451.json').read_bytes());need(hashlib.sha256((H/'inputs/BIT-451.json').read_bytes()).hexdigest()=='538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749','451 pin')
 f=451;hh=candidate['uniform']['H'];need((f,hh,peer.H)==(451,1202400000000000,240000000000000),'source ranks')
 need(candidate['cover_and_stock']['q_condition']=='odd prime q > 2^52*N^5 avoiding frozen finite catalogue witnesses' and 3<2**52,'ternary prime does not meet 451 proof')
 oldend=peer.STAGES[-1];requested=Fraction('0.00387992804346');need(requested-oldend==Fraction(3907,500000000000000),'finite requested gap')
 old=b.load('WORD.json.gz');new=b.load('ZERO-CONTROL-WORD.json.gz');c=b.load('EFREE-CALLER.json.gz');f0=b.frames(old);fn=b.frames(new)
 need(c['events'][4][0]=='LOCAL' and old['program'][2569][:2]==['MOVE',1402] and b.leg(f0,*old['program'][2569][2:])==4,'actual rank-four paid occurrence')
 need(c['events'][91][0]=='IDLE_ONE' and 7*len(c['events'][91][2])==14,'actual grade-fourteen idle occurrence')
 raw=4*14**450
 def ceiling(a,d):return (a+d-1)//d
 slab11=ceiling(raw,11**451);slab10=ceiling(raw,10**451)
 need(str(slab11)==candidate['partition']['witness']['all11_calls'] and str(slab10)==candidate['partition']['witness']['baseline_calls'] and slab11<slab10,'exact physical-label split arithmetic')
 helperold=b.leg(f0,old['start'][649],old['final'][649]);helpernew=b.leg(fn,new['start'][649],new['final'][649]);other=b.leg(f0,old['start'][241],old['final'][241]);roots=[1+7*len(c['diagonal'][i]['stages']) for i in (9,1)]
 oldprod=helperold*other**223*roots[0]**2*roots[1]**225;newprod=helpernew*other**223*roots[0]**2*roots[1]**225
 need((helperold,helpernew,other,roots)==(4,2,4,[8,64]) and oldprod==16**451 and 2*newprod==oldprod,'exact old/new floor crossing')
 need('144/B^2<1/2' in text['OUTER.md'] and Fraction(144,2**10)==Fraction(9,64)<Fraction(1,2) and Fraction(144,2**8)==Fraction(9,16)>Fraction(1,2),'source sufficient recovery bound arithmetic')
 print(json.dumps({'status':'PASS_INDEPENDENT_INSTALLED_480_VERSUS_451_INTERFACE_CHECK','peer_head':'46783fbbfc219a3faffbea76f60a2810b85ab75a','candidate_head':'b3e4412fe01f07dc58305616fabf96345f49a781','source_git_blobs':P,'installed_receiver_shape':shape,'requested_451_shape':[134,451,16,11,11],'installed_receiver_field':3,'candidate_recorded_prime_lower_exponent':52+5*hh,'installed_q_satisfies_recorded_cover':False,'installed_sixth_rate':str(oldend),'source_consumer_claim':str(requested),'rate_shortfall':str(requested-oldend),'paid_path':{'first':['move',4,2569,1402],'tail':['IDLE_ONE',91,0],'tail_repeats':450,'slabs_with_11_cutoff':str(slab11),'slabs_with_10_cutoff':str(slab10)},'target_floor_crossing':{'old_owner':649,'new_owner':650,'old_grade':helperold,'new_grade':helpernew,'old_rank':'16^451','new_rank':'16^451/2'},'stated_sufficient_rounding_bound':{'b4':'9/16','b5':'9/64','b4_does_not_certify':'not a proven concrete failure'},'scope':'Actual installed source interfaces do not match the recorded candidate 451 rule, its large-q certificate or candidate consumer rate. A new three-local proof, general-q receiver or other modified implementation is not excluded. No physical 451 tensor, candidate reserve or outer proof is produced.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
