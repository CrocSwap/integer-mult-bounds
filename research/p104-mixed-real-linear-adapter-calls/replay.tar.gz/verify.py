"""Small algebraic controls and exact frozen mixed-price headroom."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
import interval80 as interval


def gaussian_mul(x, y):
    a, b = x
    c, d = y
    return a*c - b*d, a*d + b*c


def entry(rank, i, j):
    """Numerator of the C tensor entry, with denominator 2**rank."""
    value = (1, 0)
    diff = i ^ j
    for bit in range(rank):
        value = gaussian_mul(value, (1, -1 if diff >> bit & 1 else 1))
    return value


def check_matrix():
    for rank in range(1, 5):
        mask = (1 << rank) - 1
        labels = range(mask+1)
        for i in labels:
            for j in labels:
                # Divide the phase by row and column parity phases. The phase
                # remaining relative to entry(…,0,0) is always real.
                phase = [(1,0),(0,1),(-1,0),(0,-1)][(i.bit_count()+j.bit_count()) % 4]
                adjusted = gaussian_mul(entry(rank, i, j), phase)
                a, b = entry(rank, 0, 0)
                assert gaussian_mul(adjusted, (a,-b))[1] == 0
                # Squaring the one paid call always yields the flip.
                terms = [gaussian_mul(entry(rank,i,k),entry(rank,k,j)) for k in labels]
                assert (sum(x for x,_ in terms),sum(y for _,y in terms)) == (
                    ((1 << (2*rank)) if i ^ j == mask else 0), 0)
                if rank == 2:
                    # Identity + i(Cx−conj(Cx)) for real input.
                    predicted = 2**rank*(i == j)-2*entry(rank,i,j)[1]
                    assert predicted == 2**rank*(i ^ j == mask)
                if rank >= 3 and i != j:
                    assert any(k not in {i,j,i^mask,j^mask} for k in labels)
    assert (2**3-2*entry(3,0,0)[1]) != 0  # rank-two formula fails at rank three


def check_price():
    b = (here/'BASELINE.json').read_bytes()
    assert sha256(b).hexdigest() == 'a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a'
    data = json.loads(b)
    kappa = Fraction('0.00388')
    tb,pb,tr,pr = [interval.moment(data[side][kind],kappa) for side in ('binary','rational') for kind in ('targets','paid')]
    product = interval.mul(tb,tr)
    extra_b = interval.sub(interval.div(product,pr),pb)
    extra_r = interval.sub(interval.div(product,pb),pr)
    gain = interval.sub(product,interval.mul(pb,pr))
    for low,high,expected_lo,expected_hi in [
        (*extra_b,'0.02678','0.02679'),(*extra_r,'0.06830','0.06831'),
        (*gain,'19762.81','19762.83')
    ]:
        assert Fraction(expected_lo) < Fraction(low,interval.B) <= Fraction(high,interval.B) < Fraction(expected_hi)
    return {'component_additive_paid_headroom_binary': interval.value(extra_b),
            'component_additive_paid_headroom_rational':interval.value(extra_r),
            'unfactored_raw_product_headroom':interval.value(gain)}


if __name__ == '__main__':
    if not __debug__:
        raise RuntimeError('Assertion checks are required')
    check_matrix()
    print(json.dumps(check_price(),indent=2))
