# Minimum call count for the addresswise complex-to-BIT adapter

This strengthens the adapter scope in [#7998](https://github.com/CrocSwap/integer-mult-bounds/pull/7998), head `3a98d46694f354fb46ef76c9392ed168943a797c`. It distinguishes real input from arbitrary Gaussian input. The model permits arbitrary real-linear preparation and readout at each address, together with a retained same-address input. The only cross-address operations are complete calls to the positive complex transform or its adjoint.

For $r\ge1$, let $C=((1+i)I+(1-i)X)/2$, $C_r=C^{\otimes r}$, and $D_r=X^{\otimes r}$. The minimum number of whole calls in this model is:

| Payload at each address | Rank 1 | Rank 2 | Rank at least 3 |
|---|---|---|---|
| Arbitrary complex amplitude | 1 | 2 | 2 |
| Real amplitude | 1 | 1 | 2 |

Two calls always suffice by $C^2=X$. Zero cannot move any off-address input. One call at rank one uses $D_1=(1+i)C_1-iI$. For real rank-two input,
$$
C_2=(iI+X_1+X_2-i X_1X_2)/2,qquad
D_2x=x+i(C_2x-\overline{C_2x}).
$$
The rank-two identity uses real-linear extraction and the retained input. It does not establish a physical two-chart realization, owned storage, an exact grid or use by the complete caller. It does not extend to arbitrary complex rank-two inputs or to still higher real ranks.

For arbitrary complex amplitudes, write the linear effect of a one-call adapter in real $2\times2$ blocks. Its off-diagonal block at row $j$, column $k$, is $A_j M_{jk} B_k$, where every block $M_{jk}$ of the complex call is multiplication by a nonzero scalar. The antipodal flip requires this product to be invertible at every desired block. It forces every $A_j$ and $B_k$ to be invertible. For $r\ge2$ there is a different off-diagonal block in each row, whose product is then invertible despite the desired zero. Same-address retained effects cannot alter those blocks.

For real amplitudes, factor the phases of $C_r[j,k]$ as a common nonzero complex factor times $(-i)^{|j|}(-i)^{|k|}$ times a real sign, since $|j\oplus k|=|j|+|k|-2|j\wedge k|$. Its adjoint has the conjugate factorization. Absorb these row and column phases into the real-linear readout and preparation. Each nonzero prepared real amplitude spans an input line in the complex plane. Each output readout must kill every input line except its own address and its antipode, and must retain its antipode's line. For $2^r\ge8$, for every two columns choose a row other than those columns or either antipode. Its nonzero readout must kill both lines, so they coincide. Hence all lines coincide and the desired antipode is also killed. This proves the stated minimum. The argument leaves cross-address preparations, different physical contact shapes and integrated reuse of an existing call outside the adapter model.

## Complete mixed raw headroom

The same #7830 frozen binary and rational caller receipts, with #7863/#7973's outer premises still unbound for mixed products, have mixed raw room at 0.00388 of approximately `19,762.81775` in unfactored product units. If one factor retains all of its target labels and the other factor remains unchanged, the binary factor can add less than `0.02679` paid mass, or the rational factor less than `0.06831`. This follows from the directed quantities $T_BT_R/P_R-P_B$ and $T_BT_R/P_B-P_R$, respectively. One added grade-one occurrence in either entire factor, repeated under the unchanged product histogram, already exceeds the respective threshold. Integrated nonuniform changes and genuinely new target labels require separate pricing.

Source files retain the attributed rank-one coordinate shape from #7868 head `3f7c3c1f2a9a0963736562037e01fe41aec46b8c` and the earlier BIT erasure and stock proof used by #7998. The complete invoice receipt pins #7830 head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. Its SHA-256 is `a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a`. The compiler, ownership, precision and ordinary BIT consumer obligations remain open. This is an exact scoped minimum and price obstruction, without an improved κ.

Verify with `sha256sum -c SHA256SUMS` and `python3 -I -B verify.py`. The standard-library checker controls the tensor identities and phase factorization at ranks one through four, an invalid rank-three use of the rank-two identity, and the exact directed price intervals.
