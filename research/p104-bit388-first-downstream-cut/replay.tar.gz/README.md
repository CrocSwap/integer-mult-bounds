# Chart 388: propagated-exit stock cut

This is a bounded negative result, not a new κ bound. With the #7924
recoding `1496=x43`, its six chart-283 ingress slots fixed, and the four
affected chart-283 packets allowed to change, each of the four first
downstream recipients lacks information required by its first original
outgoing packet. This remains true after granting it *every live row* of all
three of its original senders for free, rather than only the three scalars
those senders actually transmitted. The test allows arbitrary linear recoding
of those arrivals and of the recipient. It freezes sender stock, original
contacts and the first outgoing packet from each recipient; it does not rule
out changing more distant exterior packets, source banks or the atlas.

The inputs are [#7924 at `c83039ac63874fa9f9a2fd0bb650469886076dc6`](https://github.com/CrocSwap/integer-mult-bounds/tree/c83039ac63874fa9f9a2fd0bb650469886076dc6/research/p104-bit388-paid-relay)
and the [#7830 comparator `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15).
The source archive and the Round 5 fixed-six control are recorded in
`receipts/source-provenance.json` and `receipts/fixed-six-control.json`.
All clocks below index the original 42,958-event #7830 word from zero.

## The four affected routes

The unrestored recoding replaces original `1496=x43+D` by `x43`, where
`D=x74+x321+x405+x527`. All five other chart-283 input payloads stay fixed.
Of outgoing packets 2021–2026, exactly 2021, 2022, 2025 and 2026 change,
each by `D`; 2023 and 2024 stay unchanged. The literal scan includes the
uncorrected `283→560→388` relay carrying `x43`, including its actual timing.

| Exit | First recipient | First ADD | First original departure | Live rank → rank with old first output | Entire three-sender union rank → rank with old departure |
| --- | --- | --- | --- | --- | --- |
| `2021:283→334` | 334 | `ADD 2429,2021` at 8347 | `2429:334→571` at 8348 | 3 → 4 | 26 → 27 |
| `2022:283→353` | 353 | `ADD 2482,2022` at 8554 | `2482:353→587` at 8556 | 3 → 4 | 28 → 29 |
| `2025:283→468` | 468 | `ADD 2811,2025` at 9854 | `2811:468→553` at 9856 | 3 → 4 | 28 → 29 |
| `2026:283→477` | 477 | `ADD 2838,2026` at 9962 | `2838:477→539` at 9965 | 3 → 4 | 26 → 27 |

Each destination has exactly three original arrivals and no initial public
stock. At the first reader, even free shadows of **all nonzero values ever
seen** on that recipient have rank three and fail to supply `D` or the old
first output. For the stronger last column, we grant the complete live sender
bank at each of its three original arrivals, and grant all local operations
for free. Every such source row has zero coefficient of public coordinate 74;
the required first departure has coefficient one. The separating coordinate
proves the result regardless of how the three original packet payloads are
recoded within those sender banks. All eight non-283 arrivals precede the
first departure of any of the four recipients, so these changed chart-283
packets cannot have influenced those sender banks without an extra contact.
Granting `D` as a free extra independent row is a positive control and makes
the old first departure expressible in each union. This is not an actual
funded route for `D`.

`source/downstream_screen.py` records all relevant source supports, the
live/history stock, exact ranks, original first outputs and first departures.
`source/parity_verify.py` independently replays only coordinate 74 and
recomputes the union ranks using low-pivot elimination. The inherited
`source/fixed_six_control.py` also regenerates the Round 5 control: six old
outgoing rows have rank six, while those rows plus the retained `x43` have
rank seven, excluding any one arbitrary exterior-input replacement when all
six old exits must remain fixed. The new result opens the four affected exits
and their first recipients, subject to the narrower exterior conditions above.

## Whole-map control and price

The literal unrestored word implements the two stated recodes and the two
relay moves with no correction. It has legal ownership and positive-grade
routes, but the full public map is wrong: nine of 680 forward output rows
and four of 680 adjoint output rows differ. The nonzero forward differences
are all `D`; the adjoint mismatch is their transpose. Thus the positive
price of that word is not an admissible result. `receipts/literal-price.json`
records every mismatch, both complete histograms and the ordinary account.

For the unchanged complete 36-call productive histogram and all other paid
occurrences fixed, let `H(r)=r^(1−κ)`. The unrestored physical relay changes
the paid histogram by `+36 H(1)+36 H(3)−36 H(5)`. Any added positive-grade
scalar contact costs at least 36 in the 36-call invoice. If one shared added
scalar supplies the missing information, **even granting its source,
routing, local work and all other restoration for free**, the directed
complete signed margin is at most the one-contact row below. If four distinct
added grade-one contacts are required, the corresponding four-contact row
applies. A single shared correction may serve several recipients, so the
four-contact row is not asserted as a universal lower bound on contacts.

| Complete signed balance | κ = 0.003879928046156 | κ = 0.003879929046155 |
| --- | ---: | ---: |
| Original word | −0.0000000007670015 | −0.000385127316614 |
| Unrestored **invalid** relay | +35.338865767409 | +35.338480471109 |
| Optimistic upper bound with one added grade-1 contact | −0.661134232591 | −0.661519528891 |
| Optimistic upper bound with four added grade-1 contacts | −108.661134232591 | −108.661519528891 |

Both trials are enclosed by outward fixed-point rational-log/Taylor and
independent directed integer-square-root engines. These price bounds assume
the other paid and productive terms are frozen; an unrelated invoice saving,
different target, or changed source/atlas requires a fresh analysis. The
fixed-source separator requires new independent information, but does not
itself establish a route or a four-contact necessity.

The copied #7924 verifier reproduces both corrected controls, their full
680² forward and adjoint maps, 38² caller polynomial checks, 36-call
paid/productive recounts, owner-411 bridge omission control and dirty private
retirements. Both corrected complete margins are negative. This mathematical
check is not a compiled finite-precision tape, an erasure construction, or an
outer-application qualification; inherited supplier and application premises
remain open. No new literal rewrite, precision tape, erasure saving or κ
improvement is claimed here.

## Replay

From this directory, using Python 3 and the standard library:

```sh
(cd sources/pr7924 && sha256sum -c SHA256SUMS && python3 -I -B verify_relay.py)
python3 -I -B source/fixed_six_control.py
cmp receipts/stock-screen.json receipts/fixed-six-control.json
python3 -I -B source/downstream_screen.py
python3 -I -B source/parity_verify.py
python3 -I -B source/literal_price.py
```

Scripts recreate the deterministic JSON receipts in `receipts/` and the
deliberately invalid negative-control word. Source licenses and notices are
retained in `sources/pr7924/`. This work was prepared with OpenAI Codex
assistance.
