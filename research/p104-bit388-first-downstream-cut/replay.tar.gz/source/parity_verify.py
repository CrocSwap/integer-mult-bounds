#!/usr/bin/env python3
"""Independently replay coordinate 74 and use low-pivot rank elimination."""
import gzip,json
from hashlib import sha256
from pathlib import Path

H=Path(__file__).resolve().parents[1]
raw=(H/'sources/pr7924/WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));p=w['program'];n=w['public'];N=n+w['owned_fields']
data=json.loads((H/'receipts/downstream-screen.json').read_text())
source_clocks={5195,5201,5221,5228,5154,7066,5282,6970,6459,8121,6665,7892}
departures={8348:334,8556:353,9856:468,9965:477}
assert max(source_clocks) < min(departures)

def inc(e,t,b):
    op,r,*a=e
    if op=='INIT':
        assert t[r] is None;t[r]=a[0];b[r]=False
    elif op=='CLEAR':
        assert t[r]==a[0];t[r]=None;b[r]=False
    elif op=='ADD':
        s,c=a;assert t[r]==t[s]==c;b[r]^=b[s]
    elif op=='MOVE':
        src,dst=a;assert t[r]==src;t[r]=dst
    elif op=='SWAP':
        s=a[0];t[r],t[s]=t[s],t[r];b[r],b[s]=b[s],b[r]
    else:raise AssertionError(op)

t0=w['start'][:]+[None]*w['owned_fields'];t1=t0[:]
b0=[i==74 for i in range(n)]+[False]*w['owned_fields'];b1=b0[:]
observed={}
for i,e in enumerate(p):
    if i in source_clocks:
        assert e[0]=='MOVE'
        src=e[2]
        assert not any(b1[j] for j in range(N) if t1[j]==src)
        observed[i]={'sender_chart':src,'all_sender_stock_has_zero_x74':True}
    if i in departures:
        assert e[0]=='MOVE' and e[2]==departures[i]
        assert b0[e[1]] is True and b1[e[1]] is False
    inc(e,t0,b0)
    if i not in (878,879,880,2920):
        inc(['ADD',1495,321,0] if i==2916 else e,t1,b1)
    if i==2922:
        assert b1[1496] is False
        for a in (['INIT',927,283],['ADD',927,1496,283],['MOVE',927,283,560]):inc(a,t1,b1)
    if i==8949:inc(['MOVE',927,560,388],t1,b1)
    if i==9965:break
assert set(observed)==source_clocks

# Independent elimination chooses the lowest set bit rather than the main
# screen's highest bit. It reconstructs ranks using saved row supports.
def val(s):return sum(1<<x for x in s)
def rank(rows):
    piv={}
    for x in rows:
        while x:
            low=x&-x
            if low in piv:x^=piv[low]
            else:piv[low]=x;break
    return len(piv)

verification=[];D=val([74,321,405,527])
for row in data['readers']:
    banks=[row['arbitrary_283_exit_free_full_sender_bank'],*row['replace_one_other_arrival_free_full_sender_bank']]
    values=[val(f['support']) for bank in banks for f in bank['sender_live_fields']]
    old=val(row['first_original_departure']['support'])
    assert all(not v&(1<<74) for v in values) and old&(1<<74)
    a,b=rank(values),rank(values+[old])
    assert b==a+1
    assert rank(values+[D,old])==rank(values+[D])
    receipt=row['all_three_sender_banks_free_simultaneously']
    assert (a,b)==(receipt['union_rank'],receipt['rank_plus_original_first_departure'])
    verification.append({'chart':row['chart'],'rank':a,'rank_plus_first_old_departure':b,
                         'free_D_positive_control':True})
out={'status':'PASS_SEPARATE_SINGLE_COORDINATE_REPLAY_AND_LOW_PIVOT_RANK',
     'zero_coordinate_at_every_sender_clock':observed,
     'old_first_departures_each_have_x74_and_unrestored_each_lack_it':True,
     'independent_ranks':verification,
     'scope':'Checks the named linear word and sender banks; no physical restoration or broader exterior change is certified.'}
(H/'receipts/parity-verify.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('12 sender banks have no x74; four original first departures have x74, unrestored departures do not')
print('independent low-pivot ranks',[(x['chart'],x['rank'],x['rank_plus_first_old_departure']) for x in verification])
