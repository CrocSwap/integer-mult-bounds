#!/usr/bin/env python3
"""Exact first-reader screens for four unrestored chart-283 exits.

Original clock labels are preserved. This is a symbolic, optimistic stock
screen, not a constructed rewrite; the uncorrected 927 relay is included so
the later cut sees its actual propagation. Live shadows are assumed free only
when explicitly described; historical shadows are an even weaker bound.
"""
import gzip
import json
from hashlib import sha256
from pathlib import Path

H = Path(__file__).resolve().parents[1]
RAW = (H / 'sources/pr7924/WORD.json.gz').read_bytes()
assert sha256(RAW).hexdigest() == 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w = json.loads(gzip.decompress(RAW))
p, n = w['program'], w['public']
N = n + w['owned_fields']
assert n == 680 and len(p) == 42958
events = [(2021,5195,334,8347,2429), (2022,5201,353,8554,2482),
          (2025,5221,468,9854,2811), (2026,5228,477,9962,2838)]
assert all(p[m] == ['MOVE', r, 283, c] and p[k] == ['ADD', dst, r, c]
           for r,m,c,k,dst in events)
checkpoints = {q[3]:q for q in events}
other_arrivals = {334:[5154,7066],353:[5282,6970],468:[6459,8121],477:[6665,7892]}
first_departures = {334:8348,353:8556,468:9856,477:9965}
source_clocks = set(sum(other_arrivals.values(),[])) | {q[1] for q in events}
assert all(c not in w['start'] for c in first_departures)
assert all([i for i,e in enumerate(p) if e[0]=='MOVE' and e[3]==chart]
           == sorted([move,*other_arrivals[chart]])
           for _,move,chart,_,_ in events)
assert all(next(i for i,e in enumerate(p) if e[0]=='MOVE' and e[2]==chart)
           == first_departures[chart] for chart in first_departures)
assert [i for i,e in enumerate(p[:5229]) if e[0]=='MOVE' and e[3]==283] == [1095,1534,2922,3327,3897,4122]

def support(v):
    return [i for i in range(n) if v >> i & 1]

def basis(rows):
    out = {}
    for i,v in rows:
        comb = 1 << i
        while v:
            lead = v.bit_length()-1
            if lead in out:
                q, c = out[lead]; v ^= q; comb ^= c
            else:
                out[lead] = (v, comb); break
    return out

def solve(b,v):
    comb = 0
    while v:
        lead = v.bit_length()-1
        if lead not in b: return None
        q,c = b[lead]; v ^= q; comb ^= c
    return comb

def rank(vals): return len(basis(enumerate(vals)))

class Run:
    def __init__(self):
        self.tags = w['start'][:] + [None] * w['owned_fields']
        self.vals = [1 << i for i in range(n)] + [0] * w['owned_fields']
        self.history = {c: [] for _,_,c,_,_ in events}
        for i,chart in enumerate(self.tags):
            if chart in self.history and self.vals[i]:
                self.history[chart].append((f'initial:{i}', self.vals[i]))
    def step(self,e,label):
        code,r,*a = e
        if code == 'INIT':
            assert self.tags[r] is None
            self.tags[r],self.vals[r] = a[0],0
        elif code == 'CLEAR':
            assert self.tags[r] == a[0]
            self.tags[r],self.vals[r] = None,0
        elif code == 'ADD':
            s,c = a; assert self.tags[r] == self.tags[s] == c
            self.vals[r] ^= self.vals[s]
        elif code == 'SWAP':
            s=a[0]; self.tags[r],self.tags[s] = self.tags[s],self.tags[r]
            self.vals[r],self.vals[s] = self.vals[s],self.vals[r]
        elif code == 'MOVE':
            src,dst=a; assert self.tags[r] == src
            self.tags[r] = dst
        else: raise AssertionError(code)
        for j in ([r,s] if code == 'SWAP' else [r]):
            chart = self.tags[j]
            if chart in self.history and self.vals[j]:
                self.history[chart].append((f'{label}:{j}',self.vals[j]))
    def bank(self,chart):
        return [(r,self.vals[r]) for r in range(N) if self.tags[r] == chart and self.vals[r]]

orig,new = Run(),Run()
delta = sum(1 << i for i in (74,321,405,527))
snap = []
entry,leaves,senders,departures = {},{},{},{}
for clock,e in enumerate(p):
    if clock in source_clocks:
        assert e[0] == 'MOVE'
        senders[clock] = new.bank(e[2])
    if clock in checkpoints:
        role,move,chart,_,dst = checkpoints[clock]
        before0,before1=orig.bank(chart),new.bank(chart)
        assert orig.tags[role] == new.tags[role] == chart
        # The original ADD's target after the event, and the repair needed
        # after applying the unchanged ADD to the disturbed current bank.
        wanted = orig.vals[dst] ^ orig.vals[role]
        actual = new.vals[dst] ^ new.vals[role]
        repair = wanted ^ actual
        live_basis = basis(before1)
        other_basis = basis([(r,v) for r,v in before1 if r != dst])
        history = new.history[chart]
        h_basis = basis(enumerate(v for _,v in history))
        def result(z,b): return solve(b,z) is not None
        snap.append({'exit_role':role,'exit_clock':move,'chart':chart,
          'first_reader_clock':clock,'first_reader':e,
          'original_packet_support':support(orig.vals[role]),
          'disturbed_packet_support':support(new.vals[role]),
          'packet_difference_support':support(orig.vals[role]^new.vals[role]),
          'original_destination_before_support':support(orig.vals[dst]),
          'disturbed_destination_before_support':support(new.vals[dst]),
          'original_first_output_support':support(wanted),
          'disturbed_first_output_support':support(actual),
          'necessary_output_repair_support':support(repair),
          'live_nonzero_fields':[{'field':r,'support':support(v)} for r,v in before1],
          'live_rank':len(live_basis), 'original_live_rank':rank([v for _,v in before0]),
          'rank_with_original_packet':rank([v for _,v in before1]+[orig.vals[role]]),
          'rank_with_original_first_output':rank([v for _,v in before1]+[wanted]),
          'rank_with_output_repair':rank([v for _,v in before1]+[repair]),
          'free_live_decoder':{'original_packet_in_span':result(orig.vals[role],live_basis),
            'original_first_output_in_span':result(wanted,live_basis),
            'repair_in_live_span':result(repair,live_basis),
            'repair_in_other_fields_span':result(repair,other_basis)},
          'free_history':{'rows_seen':len(history),'rank':len(h_basis),
            'original_packet_in_span':result(orig.vals[role],h_basis),
            'original_first_output_in_span':result(wanted,h_basis),
            'repair_in_span':result(repair,h_basis)},
          'minimum_new_independent_rows_for_this_one_output':int(not result(wanted,live_basis))})
    # Original comparison remains unchanged. Recoded run deletes the original
    # 927 ingress, switches the two specified operations, and routes x43 via
    # the nested 283->560->388 relay with no reader correction.
    orig.step(e,f'o{clock}')
    if clock not in (878,879,880,2920):
        z=['ADD',1495,321,0] if clock == 2916 else e
        new.step(z,f'n{clock}')
    if clock == 2922:
        assert new.vals[1496] == 1 << 43
        for k,z in enumerate((['INIT',927,283],['ADD',927,1496,283],['MOVE',927,283,560])):
            new.step(z,f'injected2922.{k}')
    if clock == 8949:
        new.step(['MOVE',927,560,388],'injected8949')
    if clock in (1095,1534,2922,3327,3897,4122):
        role=e[1];entry[role]={'old':support(orig.vals[role]),'new':support(new.vals[role])}
    if clock in (5195,5201,5207,5214,5221,5228):
        role=e[1];leaves[role]={'old':support(orig.vals[role]),'new':support(new.vals[role]),
                                'xor':support(orig.vals[role]^new.vals[role])}
    if clock in first_departures.values():
        assert e[0] == 'MOVE'
        departures[e[2]] = {'clock':clock,'event':e,'value':orig.vals[e[1]]}
    if clock == 9972: break
assert set(entry) == {988,1111,1496,1604,1756,1816}
assert all(entry[r]['old']==entry[r]['new'] for r in entry if r != 1496)
assert entry[1496]['new'] == [43]
assert all(leaves[r]['xor'] == support(delta) for r in (2021,2022,2025,2026))
assert all(leaves[r]['xor'] == [] for r in (2023,2024))
for row in snap:
    role,chart,move = row['exit_role'],row['chart'],row['exit_clock']
    receiver = [(z['field'],sum(1 << i for i in z['support'])) for z in row['live_nonzero_fields']]
    desired = departures[chart]['value']
    # Optimistically supply the receiver with all source-side information,
    # not merely one transmitted scalar. Retain all other receiver fields.
    def test(clock, replaced):
        sender = senders[clock]
        fixed = [(r,v) for r,v in receiver if r != replaced]
        rows = [v for _,v in sender+fixed]
        b=basis(enumerate(rows))
        assert all(not (v>>74)&1 for v in rows)
        assert (desired>>74)&1
        return {'incoming_clock':clock,'replaced_field':replaced,
          'sender_chart':p[clock][2],'sender_live_rank':rank([v for _,v in sender]),
          'sender_live_fields':[{'field':r,'support':support(v)} for r,v in sender],
          'receiver_other_fields':[r for r,v in fixed],
          'free_union_rank':len(b),'rank_plus_original_first_departure':rank(rows+[desired]),
          'original_first_departure_in_union':solve(b,desired) is not None,
          'separator':'input coordinate 74'}
    row['first_original_departure']={'clock':departures[chart]['clock'],
      'event':departures[chart]['event'],'support':support(desired)}
    row['arbitrary_283_exit_free_full_sender_bank']=test(move,role)
    row['replace_one_other_arrival_free_full_sender_bank']=[test(c,p[c][1]) for c in other_arrivals[chart]]
    # Stronger: grant the ENTIRE source banks for all three original
    # incoming contacts, simultaneously and for free. Before the first of
    # these four receivers emits anything, all eight other incoming contacts
    # have occurred. Thus changing any of the four chart-283 payloads cannot
    # have propagated out of those receivers into these source banks yet.
    all_sender_rows = [v for c in [move,*other_arrivals[chart]] for _,v in senders[c]]
    assert all(not (v>>74)&1 for v in all_sender_rows)
    assert solve(basis(enumerate(all_sender_rows)),desired) is None
    assert solve(basis(enumerate(all_sender_rows+[delta])),desired) is not None
    row['all_three_sender_banks_free_simultaneously']={
      'arrival_clocks':[move,*other_arrivals[chart]],
      'union_rank':rank(all_sender_rows),
      'rank_plus_original_first_departure':rank(all_sender_rows+[desired]),
      'original_first_departure_in_span':False,
      'original_first_departure_in_span_after_free_correction_D':True,
      'separator':'input coordinate 74'}
assert max(sum(other_arrivals.values(),[])) < min(first_departures.values())
out={'status':'EXACT_FIRST_READER_STOCK_SCREEN',
 'source_word_sha256':sha256(RAW).hexdigest(),
 'scope':'Unchanged six chart-283 ingress slots and uncorrected recoding 1496=x43. First the actual unchanged packet computations and ADDs are run through each first reader, including all prior propagation. Each bank grants arbitrary free linear decoding from simultaneously live fields; the history comparison additionally grants a free shadow of every nonzero field ever recorded on that same chart, whether retained or not. Sender-side tests grant all three live sender banks for free: none contains coordinate 74, so arbitrarily recoding all three arrivals, combined local XORs, or relaxing all three scalar packets into their entire sender banks cannot reproduce the original first packet departing that recipient, which contains coordinate 74. All eight other source contacts precede the first of the four recipient departures, so payloads from 283 cannot affect those sender banks without an additional communication. This excludes changes of other source banks, extra contacts, recharting, downstream altered exterior departures, or nonlinear coding. No changed candidate or global impossibility is implied.',
 'ingresses':entry,'six_outgoing':leaves,'correction_support':support(delta),'readers':snap}
path=H/'receipts/downstream-screen.json'
path.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
for x in snap:
    print('exit',x['exit_role'],'chart',x['chart'],'reader',x['first_reader_clock'],
          'live rank',x['live_rank'],'+ packet',x['rank_with_original_packet'],
          '+ output',x['rank_with_original_first_output'],'+ repair',x['rank_with_output_repair'],
          'live',x['free_live_decoder'],'history',x['free_history'])
    print('  full sender-bank tests:',[(y['incoming_clock'],y['sender_live_rank'],y['free_union_rank'],y['rank_plus_original_first_departure']) for y in [x['arbitrary_283_exit_free_full_sender_bank'],*x['replace_one_other_arrival_free_full_sender_bank']]])
    print('  all three sender banks union/+target:',x['all_three_sender_banks_free_simultaneously']['union_rank'],x['all_three_sender_banks_free_simultaneously']['rank_plus_original_first_departure'])
