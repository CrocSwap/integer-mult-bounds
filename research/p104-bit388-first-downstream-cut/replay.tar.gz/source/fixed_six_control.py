#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""An exact single exterior-packet chart-283 information cut.

Only price survivors from price_screen.py are relevant. No modified word is
claimed by this screen; all source/output rows below are symbolic GF(2) rows.
"""
import gzip,json,sys
from itertools import permutations
from pathlib import Path
from hashlib import sha256
HERE=Path(__file__).resolve().parents[1]
P=HERE/'sources/pr7924'
w=json.loads(gzip.decompress((P/'WORD.json.gz').read_bytes()));p=w['program'];n=w['public'];N=n+w['owned_fields']
assert n==680 and len(p)==42958
price=json.loads((HERE/'receipts/price-screen.json').read_text())
assert price['status']=='PRICE_GATE_COMPLETE' and price['assignments_surviving_both_trials']==17
clocks=[1095,1534,2922,3327,3897,4122]
roles=[988,1111,1496,1604,1756,1816]
exits=[5195,5201,5207,5214,5221,5228]
assert not [i for i,c in enumerate(w['start']) if c==283]
assert [i for i,e in enumerate(p[:5229]) if e[0]=='MOVE' and e[3]==283]==clocks
assert [p[i][1] for i in clocks]==roles
assert [p[i][1] for i in exits]==[2021,2022,2023,2024,2025,2026]

def members(x):return [i for i in range(n) if x>>i&1]
def basis(rows):
 out={}
 for label,v in rows:
  r=v; combo=1<<label
  while r:
   t=r.bit_length()-1
   if t in out:r^=out[t][0];combo^=out[t][1]
   else:out[t]=(r,combo);break
 return out
def solve(b,x):
 c=0
 while x:
  t=x.bit_length()-1
  if t not in b:return None
  a,d=b[t];x^=a;c^=d
 return c
def rank(rows):return len(basis(enumerate(rows)))
def replay(recode):
 vals=[1<<i for i in range(n)]+[0]*w['owned_fields'];tag=w['start'][:]+[None]*w['owned_fields'];arr={};leaves={};sender={}
 for clock,e in enumerate(p[:5229]):
  if recode and clock in (878,879,880,2920):continue
  code,r,*a=e
  if recode and clock==2916:code,r,a='ADD',1495,[321,0]
  if code=='MOVE' and clock in clocks:
   src=a[0];sender[clock]=[(i,vals[i]) for i in range(N) if tag[i]==src and vals[i]]
  if code=='INIT':assert tag[r] is None;tag[r]=a[0];vals[r]=0
  elif code=='CLEAR':assert tag[r]==a[0];tag[r]=None;vals[r]=0
  elif code=='ADD':
   s,c=a;assert tag[r]==tag[s]==c;vals[r]^=vals[s]
  elif code=='SWAP':s=a[0];tag[r],tag[s]=tag[s],tag[r];vals[r],vals[s]=vals[s],vals[r]
  elif code=='MOVE':
   src,dst=a;assert tag[r]==src;tag[r]=dst
   if clock in clocks:arr[r]=vals[r]
   if clock in exits:leaves[r]=vals[r]
  else:raise ValueError(code)
 return arr,leaves,sender
old,oldout,oldsources=replay(False)
new,newout,sources=replay(True)
assert set(old)==set(new)==set(roles) and set(oldout)==set(newout)==set(range(2021,2027))
delta=old[1496]^new[1496]
assert members(old[1496])==[43,74,321,405,527]
assert members(new[1496])==[43] and members(delta)==[74,321,405,527]
assert all(old[r]==new[r] for r in roles if r!=1496)
oldin=[old[r] for r in roles];newin=[new[r] for r in roles];outvals=[oldout[r] for r in range(2021,2027)]
assert rank(oldin)==rank(newin)==rank(outvals)==6
assert rank(outvals+[new[1496]])==7
assert all(solve(basis(enumerate(oldin)),z) is not None for z in outvals)
assert all(solve(basis(enumerate(outvals)),z) is not None for z in oldin)
assert solve(basis(enumerate(outvals)),new[1496]) is None
mix=[solve(basis(enumerate(oldin)),z) for z in outvals]
assert all(m is not None for m in mix) and rank(mix)==6
# Independent, inspectable rank certificate: the six original input rows
# have a 6x6 identity coordinate minor, and the output matrix has odd
# determinant, evaluated by the Leibniz formula in F_2.
identity_owners=[54,72,43,33,25,20]
assert [[(row>>j)&1 for j in identity_owners] for row in oldin]==[[int(i==j) for j in range(6)] for i in range(6)]
det_mod2=sum(all((mix[i]>>perm[i])&1 for i in range(6)) for perm in permutations(range(6)))%2
assert det_mod2==1
# A two-bit exact separating linear functional valid on all fixed output rows.
ell=lambda x: ((x>>43)^(x>>74))&1
assert all(ell(z)==0 for z in outvals) and ell(new[1496])==1
assert rank(newin+[delta])==7
assert all(solve(basis(enumerate(newin+[delta])),z) is not None for z in outvals)
# Actual same-endpoint stock check for each exterior packet.  Even granting
# free retained shadows of the other five chart-283 inputs, test every coset
# of their span for y such that y + local shadow = original packet + delta.
# This target is deliberately optimistic: it asks for one compensated
# accumulator output and does not yet preserve all six output rows.
stock=[]
for clock,role in zip(clocks,roles):
 if role==1496:continue
 sb=basis(sources[clock]); others=[new[r] for r in roles if r!=role]
 candidate=old[role]^delta; found=[]
 for mask in range(1<<len(others)):
  v=candidate
  for j,z in enumerate(others):
   if mask>>j&1:v^=z
  sol=solve(sb,v)
  if sol is not None:found.append({'receiver_other_mask':mask,'sender_roles':[i for i in range(N) if sol>>i&1],'sender_payload_support':members(v)})
 # An independently inspectable one-coordinate separator proves every coset
 # fails: x74 is absent from the whole live source bank and the free five
 # receiver shadows, but present in the desired p + correction.
 assert all(not (row>>74)&1 for _,row in sources[clock])
 assert all(not (row>>74)&1 for row in others)
 assert (candidate>>74)&1 and not found
 stock.append({'role':role,'source_clock':clock,'sender_chart':p[clock][2],'sender_nonzero_live_count':len(sources[clock]),'sender_stock_rank':len(sb),
  'sender_live_nonzero_rows':[{'role':r,'support':members(v)} for r,v in sources[clock]],
  'receiver_free_shadow_roles':[r for r in roles if r!=role], 'receiver_cosets_tested':1<<len(others),
  'separating_input_owner':74,
  'optimistic_single_compensated_read_witness_count':len(found),'witnesses':found})
# In every one-replacement proposal, the five unchanged rows include x43.
# Five fixed inputs plus one arbitrary replacement give at most six rows,
# while six independent old output rows plus x43 require seven dimensions.
checks=[]
for role in roles:
 if role==1496:continue
 fixed=[new[r] for r in roles if r!=role]
 assert len(fixed)==5 and new[1496] in fixed and rank(fixed)==5
 assert rank(outvals+[new[1496]])==7
 checks.append({'replaced_role':role,'unmodified_recoded_input_roles':[r for r in roles if r!=role],
  'fixed_input_rank':rank(fixed),'maximum_rank_after_one_arbitrary_replacement':6,
  'required_old_exits_plus_unchanged_1496_rank':7,'all_six_original_exit_rows_simultaneously_possible':False,
  'proof':'the unchanged x43 is present in the available input span; the six independent preserved exits plus x43 have rank seven, exceeding six received scalar rows'})
out={'status':'SINGLE_EXTERIOR_REPLACEMENT_CUT',
 'scope':'For original source clocks through 5228, hold six original chart-283 outgoing payloads 2021–2026 fixed, hold recoded 1496=x43 needed by relay fixed, keep four other original ingress scalars fixed, and permit exactly one of the other five original ingress scalar payloads to be replaced arbitrarily. No additional independent inbound scalar or earlier altered input. One new payload may be any F2 row regardless of sender, grade, precision or chronology. Local XOR work and retaining free shadows are granted. With these conditions no one-packet replacement can preserve all six original outgoing payloads. A grade-zero rechart that makes extra sender stock locally accessible changes this six-scalar interface and is excluded. This is an exact information cut on this named roster, not an exclusion of jointly changing two packets, outputs/receivers or broader program.',
 'frozen_source_gzip_sha256':sha256((P/'WORD.json.gz').read_bytes()).hexdigest(),
 'roster':checks,'surviving_price_assignment_count':price['assignments_surviving_both_trials'],
 'price_survivors_all_fail_the_information_cut':True,
 'original_incoming': [{'clock':c,'role':r,'support':members(old[r]),'recoded_support':members(new[r])} for c,r in zip(clocks,roles)],
 'original_six_outgoing': [{'clock':c,'role':r,'support':members(oldout[r])} for c,r in zip(exits,range(2021,2027))],
 'rank_certificate':{'old_inputs_rank':rank(oldin),'old_six_outputs_rank':rank(outvals),'old_six_outputs_plus_x43_rank':rank(outvals+[new[1496]]),
 'identity_input_coordinate_minor':identity_owners,'output_mixing_determinant_mod_2':det_mod2,
 'outgoing_input_masks':[{'outgoing_role':r,'incoming_roles':[roles[j] for j in range(6) if m>>j&1]} for r,m in zip(range(2021,2027),mix)],
 'separator':'coefficient of x43 XOR coefficient of x74','separator_on_each_original_outgoing':[ell(z) for z in outvals],'separator_on_recoded_1496':ell(new[1496]),
 'seven_input_positive_control':{'added_correction_support':members(delta),'rank_after_granting_correction':rank(newin+[delta]),'all_old_exits_in_span':True}},
 'sender_stock_control':stock,
 'reading':'Each old outgoing packet is observed at its own named MOVE; the result holds even if internal ADDs are freely rewritten before these MOVEs. Later downstream receiver rewrites are outside this fixed-exit contract.'}
(HERE/'receipts/stock-screen.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('old input and output ranks',rank(oldin),rank(outvals),'six outputs plus x43 rank',rank(outvals+[new[1496]]))
for x in stock:print('role',x['role'],'sender rank',x['sender_stock_rank'],'receiver cosets',x['receiver_cosets_tested'],'optimistic compensated single-read witnesses',x['optimistic_single_compensated_read_witness_count'])
print('all five arbitrary-payload replacements fail fixed-six-exits cut; granting correction is positive control')
