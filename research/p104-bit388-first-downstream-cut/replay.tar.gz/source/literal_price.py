#!/usr/bin/env python3
"""Unrestored full-map negative control and complete caller price bounds."""
import gzip,json,sys
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path

H=Path(__file__).resolve().parents[1]
S=H/'sources/pr7924'
sys.path.insert(0,str(S/'independent'))
import changed_bit_replay as rep
import target_exact as exact
sys.path.insert(0,str(S/'source'))
import verify as sv

def read(path):
    b=path.read_bytes()
    return json.loads(gzip.decompress(b) if path.suffix=='.gz' else b)
def support(row):return [i for i in range(680) if row>>i&1]
def counts(x):return {str(k):v for k,v in sorted(x.items()) if v}
def want(reverse):
    y=[1<<i for i in range(680)]
    for i in range(111):
        dest,src=(i,i+111) if reverse else (i+111,i)
        y[dest]^=1<<src
    return y
def diff(rows,expected):
    return [{'output':i,'difference_support':support(a^b)}
            for i,(a,b) in enumerate(zip(rows,expected)) if a!=b]

w=read(S/'WORD.json.gz');p=w['program']
assert p[878:881]==[['INIT',927,45],['ADD',927,43,45],['MOVE',927,45,388]]
assert p[2916]==['ADD',1495,527,0] and p[2920]==['ADD',1496,1122,160]
assert p[2922]==['MOVE',1496,160,283] and p[8949]==['MOVE',2581,387,560]
q=deepcopy(w);out=[];origin=[]
def add(e,o):out.append(e);origin.append(o)
for i,e in enumerate(p):
    if i in (878,879,880,2920):continue
    add(['ADD',1495,321,0] if i==2916 else e,i)
    if i==2922:
        for z in (['INIT',927,283],['ADD',927,1496,283],['MOVE',927,283,560]):add(z,None)
    if i==8949:add(['MOVE',927,560,388],None)
q['program']=out
raw=json.dumps(q,sort_keys=True,separators=(',',':')).encode()
(H/'receipts/unrestored-negative-word.json.gz').write_bytes(gzip.compress(raw,mtime=0))
caller=read(S/'source/inputs/EFREE-CALLER.json.gz')
charts=rep.Charts(w['frames'])
truth=read(S/'source/inputs/BIT.json')['native']

def run(word,valid):
    packed=[];dirty=[];mismatch=[]
    for reverse in (False,True):
        packets,d,rows=rep.run_word(word,charts,reverse,check_operator=False)
        m=diff(rows,want(reverse))
        assert (not m) == valid
        packed.append(packets);dirty.append(d);mismatch.append(m)
    assert set(packed[0]) == set(packed[1])
    for k,(address,src,dst,grade) in packed[0].items():
        assert packed[1][k] == (address,dst,src,grade)
    paid,targets,labels=rep.invoice(word,caller,charts,packed[0])
    return {'packets':packed[0],'dirty':dirty,'mismatches':mismatch,'paid':paid,
            'targets':targets,'labels':labels,'ordinary':rep.ordinary(word,caller,paid,targets)}

base=run(w,True);negative=run(q,False)
assert base['paid']==Counter({int(k):v for k,v in truth['paid'].items()})
assert base['targets']==negative['targets']==Counter({int(k):v for k,v in truth['targets'].items()})
pd=negative['paid'].copy();pd.subtract(base['paid'])
assert pd==Counter({1:36,3:36,5:-36})
assert base['dirty']==[3554,3554]
actual_new=[{'clock':i,'event':q['program'][i],'grade':negative['packets'][i][3]}
            for i in negative['packets'] if origin[i] is None]
assert [(x['event'][2],x['event'][3],x['grade']) for x in actual_new]==[(283,560,3),(560,388,1)]

def primary(paid,targets,k):
    h=Counter(targets);h.subtract(paid);lo=hi=F(0)
    for rank,v in h.items():
        if not v:continue
        a,b=sv.power_bounds(rank,1-F(k),204)
        lo+=v*(a if v>0 else b);hi+=v*(b if v>0 else a)
    return lo,hi
def check(paid,targets,k):
    z=exact.signed(paid,targets,k);lo,hi=primary(paid,targets,k)
    assert F(z[0],exact.GRID)<=hi and lo<=F(z[1],exact.GRID)
    return exact.interval_output(z)
trials=['0.003879928046156','0.003879929046155']
prices={}
for k in trials:
    plus1=negative['paid'].copy();plus1[1]+=36
    plus4=negative['paid'].copy();plus4[1]+=144
    B=check(base['paid'],base['targets'],k)
    gross=check(negative['paid'],negative['targets'],k)
    one=check(plus1,negative['targets'],k);four=check(plus4,negative['targets'],k)
    assert F(gross[0])>0 and F(one[1])<0 and F(four[1])<0
    prices[k]={'baseline_complete_signed':B,'unrestored_invalid_complete_signed':gross,
               'optimistic_one_grade1_restoration_complete_upper':one,
               'optimistic_four_grade1_restorations_complete_upper':four}
result={'status':'UNCORRECTED_LITERAL_FAILS_WHOLE_PUBLIC_MAP',
 'scope':'Uncorrected physical relay is a deliberately invalid control; its full forward and adjoint native operators are compared at all 680 squared coefficients. Both complete invoices are occurrence-recounted with the unchanged 36-call caller, and fixed paid/productive histograms are priced with independent directed arithmetic engines. The one- and four-grade-1 rows are price upper bounds assuming that many extra positive-grade scalar MOVE occurrences, all other charges and targets frozen, and free local repair; they are not constructed legal words. No finite-precision tape, erasure implementation, compiler or application theorem is certified.',
 'negative_word_canonical_sha256':sha256(raw).hexdigest(),
 'negative_word_gzip_sha256':sha256((H/'receipts/unrestored-negative-word.json.gz').read_bytes()).hexdigest(),
 'negative_event_count':len(out),'new_paid_packets':actual_new,
 'baseline_paid':counts(base['paid']),'negative_paid':counts(negative['paid']),
 'productive':counts(base['targets']),'paid_delta_36_calls':counts(pd),
 'baseline_dirty':base['dirty'],'negative_dirty':negative['dirty'],
 'negative_forward_mismatches':negative['mismatches'][0],
 'negative_adjoint_mismatches':negative['mismatches'][1],
 'negative_ordinary_account':negative['ordinary'],'prices':prices,
 'crosscheck':'fixed-point rational atanh/Taylor and directed integer-square-root bounds overlap at both trials'}
(H/'receipts/literal-price.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('baseline matches all 680x680 coefficients forward and adjoint; unrestored mismatch counts',*[len(a) for a in negative['mismatches']])
print('dirty baseline / unrestored',base['dirty'],negative['dirty'],'36-call paid delta',counts(pd))
for k,z in prices.items():
 print(k,'baseline',z['baseline_complete_signed'],'unrestored INVALID',z['unrestored_invalid_complete_signed'],
       'one minimum',z['optimistic_one_grade1_restoration_complete_upper'],
       'four minimum',z['optimistic_four_grade1_restorations_complete_upper'])
