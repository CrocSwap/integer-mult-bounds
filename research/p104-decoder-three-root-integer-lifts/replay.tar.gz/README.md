# Three-root exchanges of the f = 22 loose decoder

For the stated P104 decoder family, all **3,136** three-root exchanges are
classified. Of these, **2,392 cannot cover the selected equations** with the
single allowed loose row. The remaining **744** have exact minimum
modulo-four row prices 63, 64, 65, 66, 67, occurring respectively 24, 240,
288, 144, 48 times. Each minimum is also attained by an explicitly
reconstructible **full integer Gram identity**, with an appropriate integer
representative of each allowed mod-four loose input class. The extra multiples
of four in those integer representatives are not priced as integer operations:
the quoted price is the defined sum of mod-four support ranks. No full source
construction, source-operation cost, caller saving, or κ improvement is claimed.

This extends [#7936](https://github.com/CrocSwap/integer-mult-bounds/pull/7936)
at exact commit `8b8ae593d6e3a3fb87c81d47c4edee0e0b3e2c14`. The
104-port data and source license are from
[#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) at
`41beda1d6435760dc99e38bd7e65f36798aad212`. The exact Git blob and archive
checks are recorded in `PROVENANCE.json`. Pins identify source snapshots and do
not imply maintainer selection.

## Family and roster

Start from the tight indices `[4,5,7,8,9,11,12,15]`; replace exactly three by
three of `[0,1,2,3,6,10,13,14]`. For the eight ordered tight input roots,
allow arbitrary mod-four output coefficients. Add exactly one B-linear
order-four loose input with parity `f = 22`, represented in root coordinates
by `F = (0,1,1,0,1,0,0,0)`. Its actual mod-four output support `D` has
homogeneous span dimension three and is efficient (`|D| >= 4`). There are no
extra rows or exemptions. Each row is charged `rank_F2 Q[D,S]`, using its
actual mod-four output and input supports. All 256 mod-four lifts of `F`,
nonzero output coefficients 1, 2, 3, and selected-equation target signs are
included. The loose input is order four even when all its outputs equal 2.

| Classification | Cases | Result |
| --- | ---: | --- |
| Binary rank 5 | 32 | At least 52 uncovered ports; impossible |
| Binary rank 6 | 432 | At least 52 uncovered ports; impossible |
| Binary rank 7 | 1,928 | At least 52 uncovered ports; impossible |
| Binary rank 8, det ±1 | 600 | Exact prices 63–66; integer Gram witnesses |
| Binary rank 8, det ±3 | 144 | Exact prices 65–67; integer Gram witnesses as below |

`SCREEN.json` gives the complete determinant, mod-2 rank and missing-port
roster. `FIBERS.json` gives each exact mod-four image and its port fibers.
`PRICE.json` gives every surviving row baseline, distance, per-plane census,
price, and witness recipe. `INTEGER_SAME_CLASS.json` and
`INTEGER_ALL_CLASSES.json` extend the integer-Gram witnesses to det ±3.

## Coverage and modulo-four fibers

For every port, the direct selected-equation kernel modulo four is
`{0, 2 c_t}`. A represented target must therefore be `+c_t` or `-c_t`.
Each homogeneous 3-space contains at most four port labels; efficiency makes
`|D|=4`. In every non-full-rank case, at least 52 ports are missing even
modulo two, so a four-port loose row cannot repair them.

Independently, `fibers.py` expresses everything in the original unimodular
basis, projects to the three exchanged coordinates and enumerates all
`4^3 = 64` replacement coefficient vectors. It checks both target signs,
all determinants, image sizes and fibers for every exchange. Kernel sizes
1, 2, 4, 8, 16 occur 744, 936, 1,136, 296, 24 times. The mod-four
missing-port count is zero for exactly the 744 odd-determinant cases; every
other count is at least 52. This does not infer mod-four fibers from rank.

## Price lower bound and attainment

For a surviving matrix `A`, put `a_t=A^(-1)c_t` and `z=A^(-1)x` modulo four.
The verifier enumerates all 17,958 four-port affine planes. Every permitted
loose input class has a support spanning the nine-dimensional homogeneous
space, so the loose row price is exactly 3. The bare tight-row baseline ranks
are 7 or 8. Their binary column-code minimum distances are at least 11;
removing the four ports in a loose plane therefore cannot lower any baseline
rank, including with arbitrary target signs.

For a tight row, call a port *bad* if its `Q` row lies outside the baseline
row space. Such a port has zero coefficient in that bare row. If the same
coordinate of `z` is odd, any nonzero loose coefficient forces that tight
row to be nonzero on that bad port. The union of forced bad rows over a plane
gives an additional lower bound. Each full tight input has rank 8 on all
ports, so setting the loose coefficient to 2 on that plane and correcting
the tight outputs attains exactly this lower bound. This works for all 256
mod-four lifts. The complete censuses yield:

| Tight baseline | Least forced surcharge | Loose price | Exact minimum | Cases |
| ---: | ---: | ---: | ---: | ---: |
| 59 | 1 | 3 | 63 | 24 |
| 60 | 1 | 3 | 64 | 48 |
| 61 | 0 | 3 | 64 | 192 |
| 62 | 0 | 3 | 65 | 288 |
| 63 | 0 | 3 | 66 | 144 |
| 64 | 0 | 3 | 67 | 48 |

As an example attaining 63, remove `[4,5,7]`, add `[2,3,10]`, and use plane
`[0,6,17,93]`. The resulting determinant is -1 and the row prices are
`[7,7,8,8,7,7,8,8,3]`. Set `u_t=2` on the plane and zero otherwise,
`W[t,i]=(A^(-1)(c_t-u_t F))[i]`, and
`V[s,i]=<c_s,z_i>`, with the final row's input `<c_s,F>`. All 10,816 integer
Gram equalities are checked by two independently structured verifiers.

## Integer representatives for determinant ±3

`PRICE.json` directly constructs full-Gram **mod-four** witnesses in all
744 cases and verifies full integer Gram identities for the 600 unit cases.
Its `full_integer_gram_witness=false` for determinant ±3 means only that this
particular initial construction did not supply an integer identity. It does
not assert impossibility. The separate `integer_lift_same_class.py` and
`verify_integer_recipes.py` supply and independently check an exact integer
identity and actual mod-four row prices for each of the remaining 144.

The reason is an index-three lattice argument. For `|det A|=3`, the map
`q(v)=3 A^(-1)v (mod 3)` identifies the quotient `Z^8/A Z^8`. Given any
one of the 256 mod-four input classes, choose a representative `x` outside
the tight lattice. If the canonical `F+2b` is inside, adding `4e_j` for a
basis direction outside the lattice changes its quotient class while leaving
its input *unchanged modulo four*. For each port, there is then a unique
`k` in `{0,1,2}` such that, with `u0=2` on the chosen plane and zero
elsewhere, `c_t-(u0+4k)x` lies in `A Z^8`. Its tight coefficients are
integers. The loose and tight output residues remain the original mod-four
witness, so all charged supports and prices remain the same. The checker
verifies all **36,864** input-class/three-exchange combinations by this
quotient argument. It independently checks all 10,816 full integer Gram cells
for 144 concrete original-mod-four-input representatives.

For 102 of these 144, the literal integer vector `F` itself works. In the
other 42, `F` belongs to the tight lattice and 75 or 76 port vectors do not;
no exact integer Gram identity using that *fixed literal input vector* can
cover them: the port roots span the ambient eight-space and the Gram form is
nondegenerate, so equality of all Gram cells forces equality of the roots. The construction instead uses `F+4e_0` for 31 and `F+4e_1` for
11, preserving the same mod-four input. `INTEGER_LIFTS.json` records this
fixed-representative obstruction, and is not an impossibility statement for
other integer representatives.

The extra multiples of four can be nonzero as integers. Therefore a full
integer Gram identity with these representatives is an algebraic lift of the
mod-four decoder; no cost model for supplying or computing those larger
integer coefficients has been verified here.

## Replay and controls

Only Python 3's standard library is needed. Run serially from this directory:

```sh
sha256sum -c SHA256SUMS
mkdir -p .replay
python3 -B screen.py > .replay/SCREEN.json && cmp SCREEN.json .replay/SCREEN.json
python3 -B fibers.py > .replay/FIBERS.json && cmp FIBERS.json .replay/FIBERS.json
python3 -B price.py > .replay/PRICE.json && cmp PRICE.json .replay/PRICE.json
python3 -B crosscheck.py
python3 -B integer_lifts.py > .replay/INTEGER_LIFTS.json && cmp INTEGER_LIFTS.json .replay/INTEGER_LIFTS.json
python3 -B integer_lift_same_class.py > .replay/INTEGER_SAME_CLASS.json && cmp INTEGER_SAME_CLASS.json .replay/INTEGER_SAME_CLASS.json
python3 -B integer_all_classes.py > .replay/INTEGER_ALL_CLASSES.json && cmp INTEGER_ALL_CLASSES.json .replay/INTEGER_ALL_CLASSES.json
python3 -B verify_integer_recipes.py
python3 -B controls.py
python3 -B gram_controls.py > .replay/GRAM_CONTROLS.json && cmp GRAM_CONTROLS.json .replay/GRAM_CONTROLS.json
python3 -B parent_controls.py > .replay/PARENT_CONTROLS.json && cmp PARENT_CONTROLS.json .replay/PARENT_CONTROLS.json
```

`crosscheck.py` uses independent three-coordinate modulo-four fibers and
pair-difference plane enumeration, and recomputes all 744 price censuses.
`verify_integer_recipes.py` uses three-by-three Cramer minors rather than the
full inverse used by the constructor. `controls.py` rejects a corrupted
integer recipe, price, plane, source byte and coverage roster; the pricing
replay also checks, per survivor, that omitting the tight correction or
removing one selected loose output breaks selected equations. `parent_controls.py`
replays #7936's exact pinned archive, reproduces all 580 exclusions and checks
the price-63, price-65 and determinant-three examples independently.
`gram_controls.py` replaces one port's coefficients, flips a tight-row sign,
and changes a loose lift without repairing its integer outputs. Those three
damages break 71, 52 and 3,724 integer Gram cells respectively. The first two
also break 24 and 28 selected mod-four cells. The allowed lift change breaks
no mod-four selected cell because this witness's loose outputs are 0 or 2
modulo four; its *unrepaired integer identity* is what fails.

The conclusions are confined to exactly this three-exchange, single-loose-row
family and its specified row charge. Other complements, loose orbits or
support dimensions, extra or order-two rows, exemptions, nonlinear decoders,
source realization, and a general decoder wall are open. The E8 data and
original decoder research are by DreamingOfClouds with Claude Opus 5.5; the
finite screen, price analysis, lattice lifts and replay were developed with
OpenAI Codex assistance. See `source/LICENSE`.
