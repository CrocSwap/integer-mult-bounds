#!/usr/bin/env python3
"""Reject corrupted result fields, coverage fibers, and pinned source bytes."""
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile

P=Path(__file__).resolve().parent
def expect_fail(command):
    q=subprocess.run(command,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    assert q.returncode!=0, command
with tempfile.TemporaryDirectory(prefix='p104-decoder-controls-',dir=P) as name:
    t=Path(name)
    recipes=json.loads((P/'INTEGER_SAME_CLASS.json').read_text())
    recipes['cases'][0]['u_k_by_port'][0]=(recipes['cases'][0]['u_k_by_port'][0]+1)%3
    (t/'bad-integer-recipe.json').write_text(json.dumps(recipes))
    expect_fail([sys.executable,'-B',str(P/'verify_integer_recipes.py'),str(t/'bad-integer-recipe.json')])
    result=json.loads((P/'PRICE.json').read_text())
    result['cases'][0]['minimum_price']+=1
    (t/'bad-price.json').write_text(json.dumps(result))
    expect_fail([sys.executable,'-B',str(P/'crosscheck.py'),str(t/'bad-price.json')])
    result=json.loads((P/'PRICE.json').read_text())
    result['cases'][0]['first_optimal_plane']=[0,0,0,0]
    (t/'bad-plane.json').write_text(json.dumps(result))
    expect_fail([sys.executable,'-B',str(P/'crosscheck.py'),str(t/'bad-plane.json')])
    shutil.copytree(P/'source',t/'source')
    shutil.copy(P/'price.py',t/'price.py')
    shutil.copy(P/'SCREEN.json',t/'SCREEN.json')
    with (t/'source/labels.txt').open('a') as f:f.write('\n')
    expect_fail([sys.executable,'-B',str(t/'price.py')])
    shutil.copy(P/'fibers.py',t/'fibers.py')
    scan=json.loads((t/'SCREEN.json').read_text())
    scan['cases'][1]['uncovered_mod_2']=[-1]
    (t/'SCREEN.json').write_text(json.dumps(scan))
    expect_fail([sys.executable,'-B',str(t/'fibers.py')])
print('PASS: corrupted integer recipe, price, plane, source bytes and mod-2 coverage rejected')
