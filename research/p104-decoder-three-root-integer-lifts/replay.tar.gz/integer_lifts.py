#!/usr/bin/env python3
"""Seek integer Gram identities for det ±3 witnesses without changing mod-4 supports.

For each tight basis A and plane from PRICE.json, let the loose coefficient
be u0=0 or 2. Try u=u0+4*k for k=0,1,2, and solve A*a=c-u*F exactly.
The three trials exhaust all residue classes modulo the index-three lattice.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import json

P=Path(__file__).resolve().parent
E=json.loads((P/'source/e8base.json').read_text());C,Z,G=E['C'][:104],E['C'][104:],E['Gb']
data=json.loads((P/'PRICE.json').read_text());F=[0,1,1,0,1,0,0,0]
def mv(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
def ip(a,b):return sum(a[i]*G[i][j]*b[j] for i in range(8) for j in range(8))
def inv(a):
    n=len(a);r=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(n)] for i in range(n)]
    for j in range(n):
        k=next(i for i in range(j,n) if r[i][j]);r[j],r[k]=r[k],r[j]
        z=r[j][j];r[j]=[x/z for x in r[j]]
        for i in range(n):
            if i!=j:
                z=r[i][j];r[i]=[x-z*y for x,y in zip(r[i],r[j])]
    return [r[i][n:] for i in range(n)]
GRAM=[[ip(a,b) for b in C] for a in C]
out=[]
for c in data['cases']:
    if abs(c['determinant'])!=3:continue
    active=c['active'];A=[[Z[j][i] for j in active] for i in range(8)];ai=inv(A)
    fc=mv(ai,F);coeff=[mv(ai,x) for x in C];plane=set(c['first_optimal_plane'])
    assert all(x.denominator in (1,3) for row in ai for x in row)
    ks=[];W=[];unsolved=[]
    for t in range(104):
        u0=2*int(t in plane)
        options=[]
        for k in range(3):
            v=[coeff[t][i]-(u0+4*k)*fc[i] for i in range(8)]
            if all(x.denominator==1 for x in v):options.append((k,v))
        if not options:
            unsolved.append(t);continue
        k,v=options[0];ks.append(k)
        W.append([int(x) for x in v]+[u0+4*k])
    case={'removed':c['removed'],'added':c['added'],'determinant':c['determinant'],
          'loose_inverse_integral':all(x.denominator==1 for x in fc),
          'unliftable_port_count':len(unsolved),'unliftable_ports':unsolved,
          'full_integer_gram_witness':not unsolved}
    if not unsolved:
        V=[[ip(x,Z[j]) for j in active]+[ip(x,F)] for x in C]
        assert len(W)==104
        assert all(sum(W[t][k]*V[s][k] for k in range(9))==GRAM[t][s] for t in range(104) for s in range(104))
        assert all(W[t][8]%4==2*int(t in plane) for t in range(104))
        # Uniqueness of mod-4 active coordinates reproduces PRICE.json witness;
        # checking the congruence directly ensures support and prices unchanged.
        def mod4(q):return (q.numerator*pow(q.denominator,-1,4))%4
        for t in range(104):
            assert all((sum(A[i][j]*W[t][j] for j in range(8)) + W[t][8]*F[i]-C[t][i])%4==0 for i in range(8))
            assert all(W[t][j]%4 == (mod4(coeff[t][j])-2*int(t in plane)*mod4(fc[j]))%4 for j in range(8))
        case['k_values']=ks
        case['k_histogram']=dict(sorted(Counter(ks).items()))
    out.append(case)
assert len(out)==144
result={'status':'PASS','scope':'determinant ±3 cases and f=(0,1,1,0,1,0,0,0); modifies only integer representatives by multiples of four',
        'cases_checked':len(out),'lifted_count':sum(c['full_integer_gram_witness'] for c in out),
        'unliftable_count':sum(not c['full_integer_gram_witness'] for c in out),
        'unliftable_port_count_histogram':dict(sorted(Counter(c['unliftable_port_count'] for c in out).items())),
        'cases':out}
print(json.dumps(result,indent=2,sort_keys=True))
