#!/usr/bin/env python3
"""Damage a reconstructed integer witness and report mod-4 and integer failures."""
from fractions import Fraction
from pathlib import Path
import json
P=Path(__file__).resolve().parent
E=json.loads((P/'source/e8base.json').read_text());C,Z,G=E['C'][:104],E['C'][104:],E['Gb']
records=json.loads((P/'INTEGER_SAME_CLASS.json').read_text())['cases']
r=next(c for c in records if c['representative_adjustment']==1)
O={4,5,7,8,9,11,12,15};active=sorted((O-set(r['removed']))|set(r['added']))
A=[[Z[j][i] for j in active] for i in range(8)];X=r['loose_root'];plane=set(r['plane'])
def ip(a,b):return sum(a[i]*G[i][j]*b[j] for i in range(8) for j in range(8))
def inv(a):
    n=len(a);v=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(n)] for i in range(n)]
    for j in range(n):
        k=next(k for k in range(j,n) if v[k][j]);v[j],v[k]=v[k],v[j]
        p=v[j][j];v[j]=[x/p for x in v[j]]
        for i in range(n):
            if i!=j:
                p=v[i][j];v[i]=[x-p*y for x,y in zip(v[i],v[j])]
    return [row[n:] for row in v]
def mv(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
ai=inv(A);W=[]
for t in range(104):
    u=2*(t in plane)+4*r['u_k_by_port'][t]
    v=mv(ai,[C[t][i]-u*X[i] for i in range(8)])
    assert all(x.denominator==1 for x in v)
    W.append([int(x) for x in v]+[u])
GRAM=[[ip(a,b) for b in C] for a in C]
Q=[[bool((1+GRAM[t][s])&1) for s in range(104)] for t in range(104)]
def makeV(x):return [[ip(c,Z[j]) for j in active]+[ip(c,x)] for c in C]
def failures(w,x):
    V=makeV(x);full=selected=0
    for t in range(104):
        for s in range(104):
            v=sum(w[t][k]*V[s][k] for k in range(9))
            full+=v!=GRAM[t][s]
            if Q[t][s]:selected+=(v-(2 if t==s else 0))%4!=0
    return {'integer_gram_cells':full,'selected_mod4_cells':selected}
base=failures(W,X);assert base=={'integer_gram_cells':0,'selected_mod4_cells':0}
bad=[row[:] for row in W];bad[0]=bad[1][:]
port=failures(bad,X);assert port['integer_gram_cells']>0 and port['selected_mod4_cells']>0
# Pick the first actual sign mutation that breaks a selected equation.
sign=None
for t in range(104):
    if sign:break
    for i in range(8):
        if not W[t][i]:continue
        bad=[row[:] for row in W];bad[t][i]*=-1
        counts=failures(bad,X)
        if counts['selected_mod4_cells']:
            sign={'port':t,'row':i,**counts};break
assert sign is not None
# Changing the valid parity lift but not correcting its integer output rows
# leaves the mod-4 identity intact (u is 0 or 2 mod 4) but breaks integer Gram.
changed=X[:];changed[0]+=2
lift=failures(W,changed)
assert lift['integer_gram_cells']>0 and lift['selected_mod4_cells']==0
out={'status':'PASS','removed':r['removed'],'added':r['added'],
     'baseline':base,'replace_port_0_coefficients_by_port_1':port,
     'flip_one_tight_output_sign':sign,'change_loose_lift_by_2e0_without_repair':lift,
     'qualification':'The last mutation is an allowed mod-4 parity lift and stays mod-4 valid; it breaks this unrepaired exact integer witness.'}
print(json.dumps(out,sort_keys=True,indent=2))
