#!/usr/bin/env python3
"""Independent 3x3-minor replay of the determinant-three integer recipes."""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent
for name,digest in {'e8base.json':'b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41','labels.txt':'8e6220f83b17ef0686dea27fc285ceb0f8f992a780287b12456792a5fb4aa4d5','LICENSE':'c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4'}.items():
    assert sha256((P/'source'/name).read_bytes()).hexdigest()==digest
E=json.loads((P/'source/e8base.json').read_text());C,Z,G=E['C'][:104],E['C'][104:],E['Gb']
R=json.loads((Path(sys.argv[1]) if len(sys.argv)>1 else P/'INTEGER_SAME_CLASS.json').read_text())
price=json.loads((P/'PRICE.json').read_text())
O=[4,5,7,8,9,11,12,15];F=[0,1,1,0,1,0,0,0]
def mv(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
def ip(a,b):return sum(a[i]*G[i][j]*b[j] for i in range(8) for j in range(8))
def determinant(m):
    return (m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])
        -m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])
        +m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]))
def inverse(a):
    n=len(a);v=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(n)] for i in range(n)]
    for j in range(n):
        k=next(k for k in range(j,n) if v[k][j]);v[j],v[k]=v[k],v[j]
        a=v[j][j];v[j]=[x/a for x in v[j]]
        for i in range(n):
            if i!=j:
                b=v[i][j];v[i]=[x-b*y for x,y in zip(v[i],v[j])]
    assert all(q.denominator==1 for row in v for q in row)
    return [[int(q) for q in row[n:]] for row in v]
def rank(v):
    basis=[]
    for x in v:
        for y in basis:x=min(x,x^y)
        if x:basis.append(x);basis.sort(reverse=True)
    return len(basis)
def hom(c):return 1|sum((v&1)<<(j+1) for j,v in enumerate(c))
old=[[Z[j][i] for j in O] for i in range(8)];bi=inverse(old)
T=[mv(bi,c) for c in C];U=[mv(bi,z) for z in Z]
GRAM=[[ip(a,b) for b in C] for a in C]
Q=[sum(((1+GRAM[t][s])&1)<<s for s in range(104)) for t in range(104)]
ref={(tuple(c['removed']),tuple(c['added'])):c for c in price['cases'] if abs(c['determinant'])==3}
assert len(ref)==len(R['cases'])==144
seen=set()
for rec in R['cases']:
    key=(tuple(rec['removed']),tuple(rec['added']));assert key in ref and key not in seen;seen.add(key)
    p=ref[key];removed,added=key
    active=sorted((set(O)-set(removed))|set(added));assert active==p['active']
    ri=[O.index(j) for j in removed]
    M=[[U[added[j]][ri[i]] for j in range(3)] for i in range(3)]
    d=determinant(M);assert abs(d)==3
    if 'representative_adjustment' in rec:
        j=rec['representative_adjustment'];assert 0<=j<=8
        x=[F[i]+4*int(j>0 and i==j-1) for i in range(8)]
    else:
        b=rec['lift_mask'];assert 0<=b<256
        x=[F[i]+2*((b>>i)&1) for i in range(8)]
    assert rec['loose_root']==x
    tx=mv(bi,x);plane=set(rec['plane']);assert sorted(plane)==p['first_optimal_plane']
    ks=rec['u_k_by_port'];assert len(ks)==104 and all(k in (0,1,2) for k in ks)
    W=[]
    for t in range(104):
        u=2*(t in plane)+4*ks[t]
        target=[T[t][i]-u*tx[i] for i in range(8)]
        rem=[target[i] for i in ri]
        numer=[determinant([[rem[i] if j==k else M[i][j] for j in range(3)] for i in range(3)]) for k in range(3)]
        assert all(n%d==0 for n in numer)
        a=[n//d for n in numer]
        vals={j:target[i]-sum(a[q]*U[added[q]][i] for q in range(3)) for i,j in enumerate(O) if j not in removed}
        vals.update(dict(zip(added,a)))
        w=[vals[j] for j in active]+[u];W.append(w)
        assert all(sum(Z[active[j]][i]*w[j] for j in range(8))+u*x[i]==C[t][i] for i in range(8))
    V=[[ip(y,Z[j]) for j in active]+[ip(y,x)] for y in C]
    assert rank(hom(C[s]) for s in range(104) if V[s][8]%4)==9
    assert all(sum(W[t][k]*V[s][k] for k in range(9))==GRAM[t][s] for t in range(104) for s in range(104))
    actual=[];sizes=[]
    for k in range(9):
        D=[t for t in range(104) if W[t][k]%4]
        smask=sum((V[s][k]%4!=0)<<s for s in range(104))
        actual.append(rank(Q[t]&smask for t in D));sizes.append([len(D),smask.bit_count()])
    assert actual==p['witness_row_prices']==rec['actual_row_prices']
    assert sizes==rec['actual_D_S_sizes']
    assert sum(actual)==p['minimum_price']==rec['minimum_price']
assert set(ref)==seen
print('PASS: 144 independent three-minor integer recipes, exact Gram and row costs')
