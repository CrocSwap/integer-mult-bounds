#!/usr/bin/env python3
"""Finite index-three proof for each of the 256 loose mod-4 input classes.

For each determinant-three tight matrix A, q(v)=3*A^-1*v mod 3 has
three image classes and ker(q)=A Z^8. An input representative x with
q(x)!=0 generates the quotient. For every port and either u0 in {0,2},
exactly one of u=u0+4*k (k=0,1,2) places c-u*x in A Z^8. If a canonical
representative F+2*b has q=0, add 4*e_j for the first e_j with q(e_j)!=0;
this leaves the mod-4 source and its charge unchanged.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
P=Path(__file__).resolve().parent
assert sha256((P/'source/e8base.json').read_bytes()).hexdigest()=='b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41'
E=json.loads((P/'source/e8base.json').read_text());C,Z,G=E['C'][:104],E['C'][104:],E['Gb']
Pdata=json.loads((P/'PRICE.json').read_text());F=[0,1,1,0,1,0,0,0]
def mv(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
def inv(a):
    n=len(a);r=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(n)] for i in range(n)]
    for j in range(n):
        k=next(i for i in range(j,n) if r[i][j]);r[j],r[k]=r[k],r[j]
        v=r[j][j];r[j]=[x/v for x in r[j]]
        for i in range(n):
            if i!=j:
                v=r[i][j];r[i]=[x-v*y for x,y in zip(r[i],r[j])]
    return [r[i][n:] for i in range(n)]
def qmat(a):
    assert all((3*x).denominator==1 for row in a for x in row)
    return [[int(3*x)%3 for x in row] for row in a]
def q(M,v):return tuple(x%3 for x in mv(M,v))
def mult(k,v):return tuple((k*x)%3 for x in v)
def add(*vs):return tuple(sum(v[i] for v in vs)%3 for i in range(8))
zero=(0,)*8
out=[]
for case in Pdata['cases']:
    if abs(case['determinant'])!=3:continue
    active=case['active'];A=[[Z[j][i] for j in active] for i in range(8)];ai=inv(A)
    M=qmat(ai)
    # Full inverse independently verifies denominators and lattice kernel.
    assert all(sum(A[i][k]*ai[k][j] for k in range(8))==int(i==j) for i in range(8) for j in range(8))
    qe=[tuple(M[i][j] for i in range(8)) for j in range(8)]
    j=next(j for j,x in enumerate(qe) if x!=zero);generator=qe[j]
    group={zero,generator,mult(2,generator)}
    assert len(group)==3 and all(x in group for x in qe)
    assert all(q(M,z) in group for z in C)
    qf=q(M,F);assert qf in group
    need=0;directions=Counter()
    for b in range(256):
        canonical=add(qf,*(mult(2,qe[i]) for i in range(8) if (b>>i)&1))
        adjusted=(canonical==zero);need+=adjusted
        qx=add(canonical,qe[j]) if adjusted else canonical # 4 = 1 mod 3
        assert qx in group and qx!=zero
        directions[0 if qx==generator else 1]+=1
        # For a prescribed mod-4 output u0, varying k over 0..2 gives the
        # three quotient classes, hence represents every target c exactly.
        for u0 in (0,2):
            assert {mult(u0+4*k,qx) for k in range(3)}==group
    assert sum(directions.values())==256
    out.append({'removed':case['removed'],'added':case['added'],
                'determinant':case['determinant'],'price':case['minimum_price'],
                'adjustment_basis_index':j,'classes_requiring_plus_4e':need,
                'classes_requiring_no_adjustment':256-need,
                'canonical_f_in_tight_integer_lattice':qf==zero})
assert len(out)==144
result={'status':'PASS','cases_checked':len(out),'mod4_input_classes_per_case':256,
        'classes_checked':256*len(out),
        'per_case_adjustment_count_histogram':dict(sorted(Counter(x['classes_requiring_plus_4e'] for x in out).items())),
        'proof':'For each input class choose x outside the index-3 tight lattice without changing x mod 4; each port has a unique u=u0+4*k in the needed quotient class. The original tight coefficients follow by exact division. All mod-4 supports and prices remain those in PRICE.json.',
        'cases':out}
print(json.dumps(result,indent=2,sort_keys=True))
