#!/usr/bin/env python3
"""Exhaustive mod-2 coverage screen for exactly three E8-root exchanges."""

from collections import Counter
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PINS = {
    'e8base.json': 'b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41',
    'labels.txt': '8e6220f83b17ef0686dea27fc285ceb0f8f992a780287b12456792a5fb4aa4d5',
    'LICENSE': 'c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4',
}
for name, digest in PINS.items():
    assert sha256((ROOT/'source'/name).read_bytes()).hexdigest() == digest
E = json.loads((ROOT/'source'/'e8base.json').read_text())
C, Z = E['C'][:104], E['C'][104:]
ORIGINAL = (4, 5, 7, 8, 9, 11, 12, 15)
INACTIVE = tuple(i for i in range(16) if i not in ORIGINAL)
assert INACTIVE == (0, 1, 2, 3, 6, 10, 13, 14)

def bits(v):
    return sum((x & 1) << i for i, x in enumerate(v))

def det(a):
    """Exact fraction-free determinant (including singular matrices)."""
    a = [row[:] for row in a]
    n, sign, prev = len(a), 1, 1
    for k in range(n-1):
        pivot = next((i for i in range(k,n) if a[i][k]), None)
        if pivot is None:
            return 0
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            sign *= -1
        v = a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                numerator = a[i][j]*v - a[i][k]*a[k][j]
                assert numerator % prev == 0
                a[i][j] = numerator // prev
            a[i][k] = 0
        prev = v
    return sign*a[-1][-1]

def image(vectors):
    values = {0}
    for v in vectors:
        values |= {x ^ v for x in values}
    assert len(values) in (1,2,4,8,16,32,64,128,256)
    return values

cases=[]
for removed in combinations(ORIGINAL,3):
    for added in combinations(INACTIVE,3):
        active = sorted((set(ORIGINAL)-set(removed)) | set(added))
        A = [[Z[j][i] for j in active] for i in range(8)]
        determinant = det(A)
        img = image([bits(Z[j]) for j in active])
        rank = len(img).bit_length()-1
        missing = [t for t,c in enumerate(C) if bits(c) not in img]
        assert (determinant % 2 != 0) == (rank == 8)
        assert len(missing) > 4 or rank == 8, (active, missing)
        cases.append({'removed': removed, 'added': added, 'active': active,
                      'determinant': determinant, 'rank_mod_2': rank,
                      'uncovered_mod_2': missing,
                      'uncovered_mod_2_count': len(missing),
                      'status': 'EXCLUDED_MOD2_COVERAGE' if missing else 'SURVIVES_MOD2'})

assert len(cases) == 56*56
out={'status':'PASS',
     'scope':'Exactly three original tight roots replaced by three inactive tight roots; fixed efficient f=22 loose row of span three.',
     'source_heads': {'7936':'8b8ae593d6e3a3fb87c81d47c4edee0e0b3e2c14', '7917':'fa126cdae49f9e827f21d254cb68fd748fdcc864',
                      '7902':'354bd1471b8e6e31fc222ca622a178207b79133d',
                      '7852':'41beda1d6435760dc99e38bd7e65f36798aad212'},
     'count':len(cases),
     'determinant_histogram':dict(sorted(Counter(c['determinant'] for c in cases).items())),
     'rank_histogram':dict(sorted(Counter(c['rank_mod_2'] for c in cases).items())),
     'uncovered_count_histogram':dict(sorted(Counter(c['uncovered_mod_2_count'] for c in cases).items())),
     'status_histogram':dict(sorted(Counter(c['status'] for c in cases).items())),
     'cases':cases}
print(json.dumps(out,indent=2,sort_keys=True))
