#!/usr/bin/env python3
"""Serially replay the exact pinned two-exchange parent and chosen controls."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json,subprocess,sys,tarfile,tempfile
P=Path(__file__).resolve().parent
archive=P/'parent/replay.tar.gz'
assert sha256(archive.read_bytes()).hexdigest()=='a46757f03d4d1244e5c24f9ae1b88b5405539aab0d3d304eb5aa4f12c9a59256'
with tempfile.TemporaryDirectory(prefix='parent-control-',dir=P) as d:
    d=Path(d)
    with tarfile.open(archive,'r:gz') as tf:
        for m in tf.getmembers():
            target=(d/m.name).resolve()
            assert target==d or d in target.parents
            assert m.isfile() or m.isdir()
        tf.extractall(d)
    subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=d,check=True,stdout=subprocess.DEVNULL)
    for name in ('screen','fibers','price'):
        p=subprocess.run([sys.executable,'-B',str(d/f'{name}.py')],cwd=d,check=True,stdout=subprocess.PIPE)
        assert p.stdout==(d/f'{name.upper()}.json').read_bytes(), name
    q=subprocess.run([sys.executable,'-B',str(d/'crosscheck.py')],cwd=d,check=True,stdout=subprocess.PIPE)
    S=json.loads((d/'SCREEN.json').read_text());D=json.loads((d/'PRICE.json').read_text())
    assert len(S['cases'])==784 and S['status_histogram']['EXCLUDED_MOD2_COVERAGE']==580
    assert D['price_histogram']=={'63':36,'64':120,'65':48}
    pick=[]
    for label,predicate in [
      ('price63_unit',lambda c:c['minimum_price']==63 and abs(c['determinant'])==1),
      ('price65_unit',lambda c:c['minimum_price']==65 and abs(c['determinant'])==1),
      ('price65_det3_mod4',lambda c:c['minimum_price']==65 and abs(c['determinant'])==3)]:
        c=next(c for c in D['cases'] if predicate(c))
        pick.append({'control':label,'removed':c['removed'],'added':c['added'],
                     'determinant':c['determinant'],'minimum_price':c['minimum_price'],
                     'full_integer_gram_witness_in_parent':c['full_integer_gram_witness']})
    out={'status':'PASS','parent_cases':784,'parent_excluded':580,
         'parent_price_histogram':D['price_histogram'],'selected_controls':pick,
         'parent_independent_crosscheck':q.stdout.decode().strip()}
    print(json.dumps(out,sort_keys=True,indent=2))
