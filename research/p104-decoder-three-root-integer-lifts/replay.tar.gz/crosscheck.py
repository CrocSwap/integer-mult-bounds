#!/usr/bin/env python3
"""Independent three-coordinate, pair-plane verification of PRICE.json."""
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import combinations,product
import json
from pathlib import Path
import sys

P=Path(__file__).resolve().parent
ledger=Path(sys.argv[1]) if len(sys.argv)>1 else P/'PRICE.json'
data=json.loads(ledger.read_text())
E=json.loads((P/'source/e8base.json').read_text());C,Z,G=E['C'][:104],E['C'][104:],E['Gb']
O=[4,5,7,8,9,11,12,15]
F=[0,1,1,0,1,0,0,0]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def mv(a,v):return [dot(r,v) for r in a]
def gram(a,b):return dot(a,mv(G,b))
def span(vectors):
    piv=[]
    for value in vectors:
        for v in piv:value=min(value,value^v)
        if value:
            piv.append(value);piv.sort(reverse=True)
    return piv
def member(x,piv):
    for v in piv:x=min(x,x^v)
    return x==0
def inverse(a):
    r=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(8)] for i in range(8)]
    for j in range(8):
        k=next(k for k in range(j,8) if r[k][j]);r[j],r[k]=r[k],r[j]
        d=r[j][j];r[j]=[x/d for x in r[j]]
        for i in range(8):
            if i!=j:
                d=r[i][j];r[i]=[a-d*b for a,b in zip(r[i],r[j])]
    assert all(v.denominator==1 for row in r for v in row)
    return [[int(x) for x in r[i][8:]] for i in range(8)]

old=[[Z[j][i] for j in O] for i in range(8)];old_inv=inverse(old)
assert all(mv(old,mv(old_inv,c))==c for c in C+Z)
oldports=[mv(old_inv,c) for c in C]
oldf=mv(old_inv,F)
hom=[1|sum((v&1)<<(j+1) for j,v in enumerate(c)) for c in C]
GRAM=[[gram(a,b) for b in C] for a in C]
Q=[sum(((1+GRAM[t][s])&1)<<s for s in range(104)) for t in range(104)]
bucket=defaultdict(list)
for i,j in combinations(range(104),2):bucket[hom[i]^hom[j]].append((i,j))
triples=Counter()
for pairs in bucket.values():
    for a,b in combinations(pairs,2):
        p=tuple(sorted(a+b));assert len(set(p))==4
        triples[p]+=1
assert len(triples)==17958 and set(triples.values())=={3}
planes=sorted(triples)
assert len(data['cases'])==744 and data['planes_per_survivor']==len(planes)

counts=Counter()
for case in data['cases']:
    removed,added,active=case['removed'],case['added'],case['active']
    ri=[O.index(j) for j in removed]
    u=[mv(old_inv,Z[j]) for j in added]
    matrix=[[u[j][ri[i]] for j in range(3)] for i in range(3)]
    lookup={tuple(sum(matrix[i][j]*a[j] for j in range(3))%4 for i in range(3)):a
            for a in product(range(4),repeat=3)}
    assert len(lookup)==64
    def coeff(target):
        a=lookup[tuple(target[i]%4 for i in ri)]
        remaining={j:(target[k]-sum(a[q]*u[q][k] for q in range(3)))%4
                   for k,j in enumerate(O) if j not in removed}
        remaining.update(dict(zip(added,a)))
        out=[remaining[j] for j in active]
        assert all((sum(Z[j][i]*out[k] for k,j in enumerate(active))-mv(old,target)[i])%4==0 for i in range(8))
        return out
    A=[coeff(v) for v in oldports];fc=coeff(oldf)
    assert fc==case['f_coordinates_mod4']
    smasks=[sum((gram(c,Z[j])%4!=0)<<i for i,c in enumerate(C)) for j in active]
    prices=[];dist=[];bad=[0]*104
    for i in range(8):
        D=[t for t in range(104) if A[t][i]]
        piv=span(Q[t]&smasks[i] for t in D)
        prices.append(len(piv));assert len(D)==case['tight_basis_support_sizes'][i]
        assert len(span(Q[t]&smasks[i] for t in range(104)))==8
        for t in range(104):
            if not member(Q[t]&smasks[i],piv):
                assert A[t][i]==0
                bad[t]|=1<<i
        cols=[sum(((Q[t]>>s)&1)<<j for j,t in enumerate(D)) for s in range(104) if (smasks[i]>>s)&1]
        code=span(cols);words=[0]
        for v in code:words.extend(w^v for w in words[:])
        assert len(code)==prices[-1]
        dist.append(min(w.bit_count() for w in words if w))
    assert prices==case['tight_basis_row_prices'] and dist==case['tight_column_code_distances']
    assert min(dist)>4 and sum(prices)==case['tight_basis_price']
    hist=Counter()
    for p in planes:
        union=0
        for t in p:union|=bad[t]
        n=sum(1 for i in range(8) if (union>>i)&1 and fc[i]%2)
        hist[n]+=1
    assert {str(k):v for k,v in sorted(hist.items())}==case['plane_surcharge_histogram']
    best=min(hist);p=tuple(case['first_optimal_plane'])
    assert p in triples and hist[best]==case['optimal_plane_count']
    union=0
    for t in p:union|=bad[t]
    assert sum(1 for i in range(8) if (union>>i)&1 and fc[i]%2)==best
    V=[[gram(c,Z[j]) for j in active]+[gram(c,F)] for c in C]
    W=[[ (A[t][i]-2*(t in p)*fc[i])%4 for i in range(8)] +[2*(t in p)] for t in range(104)]
    assert all((dot(W[t],V[s])-GRAM[t][s])%4==0 for t in range(104) for s in range(104))
    actual=[];sizes=[]
    for i in range(9):
        D=[t for t in range(104) if W[t][i]%4]
        smask=sum((V[s][i]%4!=0)<<s for s in range(104))
        actual.append(len(span(Q[t]&smask for t in D)))
        sizes.append([len(D),smask.bit_count()])
    assert actual==case['witness_row_prices'] and sizes==case['witness_D_S_sizes']
    assert sum(actual)==sum(prices)+3+best==case['minimum_price']
    if abs(case['determinant'])==1:
        # Independently invert the complete active 8-by-8 matrix over integers.
        active_integer_inverse=inverse([[Z[j][i] for j in active] for i in range(8)])
        def integer_coeff(target):
            return mv(active_integer_inverse,mv(old,target))
        ai=[integer_coeff(c) for c in oldports];fi=integer_coeff(oldf)
        Wi=[[ai[t][i]-2*(t in p)*fi[i] for i in range(8)]+[2*(t in p)] for t in range(104)]
        assert all(dot(Wi[t],V[s])==GRAM[t][s] for t in range(104) for s in range(104))
        assert case['full_integer_gram_witness'] is True
    else:assert abs(case['determinant'])==3 and case['full_integer_gram_witness'] is False
    counts[case['minimum_price']]+=1

assert {str(k):v for k,v in sorted(counts.items())}==data['price_histogram']
print('PASS: 744 independent three-coordinate fibers, pair-plane censuses, exact prices and full Gram witnesses')
