#!/usr/bin/env python3
"""Exact prices and witnesses after the 3,136-complement coverage screen.

Pure Python.  The finite lower-bound proof is recorded in README-RESULT.md.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from hashlib import sha256
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
for name,digest in {
 'e8base.json':'b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41',
 'labels.txt':'8e6220f83b17ef0686dea27fc285ceb0f8f992a780287b12456792a5fb4aa4d5',
 'LICENSE':'c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4'}.items():
    assert sha256((ROOT/'source'/name).read_bytes()).hexdigest()==digest
E=json.loads((ROOT/'source/e8base.json').read_text())
C,Z,G=E['C'][:104],E['C'][104:],E['Gb']
LAB=list(map(int,(ROOT/'source/labels.txt').read_text().split()))
SCREEN=json.loads((ROOT/'SCREEN.json').read_text())

def bits(v):return sum((int(x)&1)<<i for i,x in enumerate(v))
def basis(vectors):
    piv={}
    for x in vectors:
        while x:
            j=x.bit_length()-1
            if j in piv:x^=piv[j]
            else:
                piv[j]=x
                break
    return piv
def rank(v):return len(basis(v))
def outside(x,piv):
    while x:
        j=x.bit_length()-1
        if j not in piv:return True
        x^=piv[j]
    return False
def ip(a,b):return sum(a[i]*G[i][j]*b[j] for i in range(8) for j in range(8))
def mv(a,v):return [sum(x*y for x,y in zip(r,v)) for r in a]
def inv4(a):
    n=len(a);r=[[(x%4) for x in a[i]]+[int(i==j) for j in range(n)] for i in range(n)]
    for j in range(n):
        k=next(i for i in range(j,n) if r[i][j]%2)
        r[j],r[k]=r[k],r[j]
        z=pow(r[j][j],-1,4)
        r[j]=[(x*z)%4 for x in r[j]]
        for i in range(n):
            if i!=j:
                z=r[i][j]
                r[i]=[(x-z*y)%4 for x,y in zip(r[i],r[j])]
    return [r[i][n:] for i in range(n)]
def inverse_integer(a):
    n=len(a);r=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(n)] for i in range(n)]
    for j in range(n):
        k=next(i for i in range(j,n) if r[i][j]);r[j],r[k]=r[k],r[j]
        z=r[j][j];r[j]=[x/z for x in r[j]]
        for i in range(n):
            if i!=j:
                z=r[i][j];r[i]=[x-z*y for x,y in zip(r[i],r[j])]
    assert all(x.denominator==1 for row in r for x in row)
    return [[int(x) for x in row[n:]] for row in r]

H=[1|(bits(c)<<1) for c in C];hix={h:i for i,h in enumerate(H)}
assert len(hix)==104
Q=[sum(((a&b).bit_count()&1)<<s for s,b in enumerate(LAB)) for a in LAB]
GRAM=[[ip(C[t],C[s]) for s in range(104)] for t in range(104)]
assert all(((Q[t]>>s)&1)==((1+GRAM[t][s])&1) for t in range(104) for s in range(104))
assert all(GRAM[t][s]==(2 if t==s else 0) for t in range(104) for s in range(104) if (Q[t]>>s)&1)
planes=[]
for a,b,c in combinations(range(104),3):
    d=hix.get(H[a]^H[b]^H[c])
    if d is not None and d>c:planes.append((a,b,c,d))
assert len(planes)==17958 and all(rank(H[t] for t in p)==3 for p in planes)

# Recheck the selected-equation kernels directly, not just an assumed cover.
forms=[[sum(G[i][j]*c[j] for j in range(8))%4 for i in range(8)] for c in C]
forms2=[bits(v) for v in forms]
for t in range(104):
    sel=[s for s in range(104) if (Q[t]>>s)&1]
    assert rank(forms2[s] for s in sel)==7
    ct=[x&1 for x in C[t]]
    assert bits(ct) and all((forms2[s]&bits(ct)).bit_count()%2==0 for s in sel)
    kernel=set()
    for b in ([0]*8,ct):
        values=[sum(forms[s][i]*b[i] for i in range(8))%4 for s in sel]
        assert all(v%2==0 for v in values)
        for u in range(256):
            if all(((forms2[s]&u).bit_count()&1)==values[j]//2 for j,s in enumerate(sel)):
                kernel.add(tuple((b[i]+2*((u>>i)&1))%4 for i in range(8)))
    assert kernel=={(0,)*8,tuple(2*v for v in ct)}

F=[0,1,1,0,1,0,0,0]
lift_sizes=Counter()
for b in range(256):
    x=[F[i]+2*((b>>i)&1) for i in range(8)]
    supp=[s for s in range(104) if ip(C[s],x)%4]
    assert rank(H[s] for s in supp)==9
    lift_sizes[len(supp)]+=1
assert dict(sorted(lift_sizes.items()))=={62:16,76:128,78:112}

def code_distance(smask,ports):
    columns=[sum(((Q[t]>>s)&1)<<k for k,t in enumerate(ports))
             for s in range(104) if (smask>>s)&1]
    vectors=list(basis(columns).values())
    words=[0]
    for v in vectors:words += [x^v for x in words]
    return len(vectors),min(x.bit_count() for x in words if x)

cases=[]
survivors=[c for c in SCREEN['cases'] if c['status']=='SURVIVES_MOD2']
assert len(survivors)==744
for case in survivors:
    active=case['active'];A=[[Z[j][i] for j in active] for i in range(8)]
    ai=inv4(A)
    assert all(sum(A[i][k]*ai[k][j] for k in range(8))%4==int(i==j) for i in range(8) for j in range(8))
    coeff=[[x%4 for x in mv(ai,c)] for c in C]
    fc=[x%4 for x in mv(ai,F)]
    assert all(all((u-v)%4==0 for u,v in zip(mv(A,a),c)) for a,c in zip(coeff,C))
    # All 256 lifts have 2 A^-1 x = 2 A^-1 f mod 4.
    for b in range(256):
        x=[F[i]+2*((b>>i)&1) for i in range(8)]
        lc=mv(ai,x)
        assert all((2*lc[i]-2*fc[i])%4==0 for i in range(8))
    smasks=[sum((ip(c,Z[j])%4!=0)<<s for s,c in enumerate(C)) for j in active]
    prices=[];dist=[];bad=[0]*104;supports=[]
    for i in range(8):
        ports=[t for t in range(104) if coeff[t][i]%4]
        supports.append(len(ports))
        rowbasis=basis(Q[t]&smasks[i] for t in ports)
        r=len(rowbasis);dim,d=code_distance(smasks[i],ports)
        assert r==dim and d>4 and r in (7,8)
        assert rank(Q[t]&smasks[i] for t in range(104))==8
        prices.append(r);dist.append(d)
        for t in range(104):
            if outside(Q[t]&smasks[i],rowbasis):
                assert coeff[t][i]%4==0
                bad[t]|=1<<i
    fmask=bits(fc);hist=Counter();best=9;optimal=[]
    for p in planes:
        union=bad[p[0]]|bad[p[1]]|bad[p[2]]|bad[p[3]]
        n=(union&fmask).bit_count();hist[n]+=1
        if n<best:best=n;optimal=[p]
        elif n==best:optimal.append(p)
    assert sum(hist.values())==len(planes)
    plane=optimal[0];plane_set=set(plane)
    # Residues provide an exact integer, mod-4 decoder; unit determinants also
    # admit an integer witness for every full Gram cell (checked separately).
    V=[[ip(c,Z[j]) for j in active]+[ip(c,F)] for c in C]
    W=[[ (coeff[t][i]-(2 if t in plane_set else 0)*fc[i])%4 for i in range(8)]
       +[2 if t in plane_set else 0] for t in range(104)]
    for t in range(104):
        for s in range(104):
            q=sum(W[t][k]*V[s][k] for k in range(9))
            assert (q-GRAM[t][s])%4==0
    row_prices=[];sizes=[]
    for k in range(9):
        ports=[t for t in range(104) if W[t][k]%4]
        smask=sum((V[s][k]%4!=0)<<s for s in range(104))
        row_prices.append(rank(Q[t]&smask for t in ports))
        sizes.append([len(ports),smask.bit_count()])
    union=bad[plane[0]]|bad[plane[1]]|bad[plane[2]]|bad[plane[3]]
    assert row_prices[:8]==[prices[i]+((union&fmask)>>i&1) for i in range(8)]
    assert row_prices[8]==3 and sum(row_prices)==sum(prices)+3+best
    full_integer=(abs(case['determinant'])==1)
    if full_integer:
        zi=inverse_integer(A);ci=[mv(zi,c) for c in C];fi=mv(zi,F)
        Wi=[[ci[t][i]-(2 if t in plane_set else 0)*fi[i] for i in range(8)]
            +[2 if t in plane_set else 0] for t in range(104)]
        assert all(sum(Wi[t][k]*V[s][k] for k in range(9))==GRAM[t][s]
                   for t in range(104) for s in range(104))
        assert all((Wi[t][i]-W[t][i])%4==0 for t in range(104) for i in range(9))
    # Independent negative controls: omit correction or remove one loose output.
    naive=[[coeff[t][i] for i in range(8)]+[2 if t in plane_set else 0] for t in range(104)]
    bad_naive=sum(1 for t in plane for s in range(104) if (Q[t]>>s)&1
                  and (sum(naive[t][k]*V[s][k] for k in range(9))-(2 if t==s else 0))%4)
    deleted_errors={t:sum(1 for s in range(104) if (Q[t]>>s)&1
                    and (sum(W[t][k]*V[s][k] for k in range(8))-(2 if t==s else 0))%4) for t in plane}
    t=max(deleted_errors,key=deleted_errors.get);bad_deleted=deleted_errors[t]
    assert bad_naive>0 and bad_deleted>0
    cases.append({'removed':case['removed'],'added':case['added'],'active':active,
        'determinant':case['determinant'],'tight_basis_price':sum(prices),
        'tight_basis_row_prices':prices,'tight_basis_support_sizes':supports,
        'tight_column_code_distances':dist,'f_coordinates_mod4':fc,
        'plane_surcharge_histogram':dict(sorted(hist.items())),
        'optimal_plane_count':len(optimal),'first_optimal_plane':plane,
        'minimum_price':sum(row_prices),'witness_row_prices':row_prices,
        'witness_D_S_sizes':sizes,'full_integer_gram_witness':full_integer,
        'uncorrected_control_failed_selected_cells':bad_naive,
        'deleted_loose_output_control_port':t,
        'deleted_loose_output_control_failed_selected_cells':bad_deleted})

out={'status':'PASS','survivor_count':len(cases),'planes_per_survivor':len(planes),
     'loose_lift_input_sizes':dict(sorted(lift_sizes.items())),
     'selected_equation_kernels_verified':104,
     'price_histogram':dict(sorted(Counter(c['minimum_price'] for c in cases).items())),
     'baseline_histogram':dict(sorted(Counter(c['tight_basis_price'] for c in cases).items())),
     'minimum_surcharge_histogram':dict(sorted(Counter(min(map(int,c['plane_surcharge_histogram'])) for c in cases).items())),
     'all_cases_full_gram_mod4':True,
     'integer_gram_witness_count':sum(c['full_integer_gram_witness'] for c in cases),
     'cases':cases}
print(json.dumps(out,indent=2,sort_keys=True))
