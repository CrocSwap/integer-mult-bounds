#!/usr/bin/env python3
"""Lift each det ±3 price witness to an integer full-Gram identity.

Change the integer representative x from f to f+4*e_j if necessary. For each port
u=u0+4*k (k in 0,1,2) leaves the mod-4 support and tight coefficients fixed.
All source prices are recomputed on the actual mod-4 output/input supports.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import json

P=Path(__file__).resolve().parent
E=json.loads((P/'source/e8base.json').read_text());C,Z,G=E['C'][:104],E['C'][104:],E['Gb']
labels=list(map(int,(P/'source/labels.txt').read_text().split()))
data=json.loads((P/'PRICE.json').read_text());F=[0,1,1,0,1,0,0,0]
def mv(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
def ip(a,b):return sum(a[i]*G[i][j]*b[j] for i in range(8) for j in range(8))
def bits(v):return sum((int(x)&1)<<i for i,x in enumerate(v))
def rank(vec):
    piv={}
    for v in vec:
        while v:
            j=v.bit_length()-1
            if j in piv:v^=piv[j]
            else:piv[j]=v;break
    return len(piv)
def inv(a):
    n=len(a);r=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(n)] for i in range(n)]
    for j in range(n):
        k=next(i for i in range(j,n) if r[i][j]);r[j],r[k]=r[k],r[j]
        z=r[j][j];r[j]=[x/z for x in r[j]]
        for i in range(n):
            if i!=j:
                z=r[i][j];r[i]=[x-z*y for x,y in zip(r[i],r[j])]
    return [r[i][n:] for i in range(n)]
def mod4(q):return (q.numerator*pow(q.denominator,-1,4))%4
GRAM=[[ip(a,b) for b in C] for a in C]
Q=[sum(((a&b).bit_count()&1)<<s for s,b in enumerate(labels)) for a in labels]
H=[1|(bits(c)<<1) for c in C]
out=[]
for c in data['cases']:
    if abs(c['determinant'])!=3:continue
    active=c['active'];A=[[Z[j][i] for j in active] for i in range(8)];ai=inv(A)
    coeff=[mv(ai,x) for x in C];base_fc=mv(ai,F);plane=set(c['first_optimal_plane'])
    assert all(x.denominator in (1,3) for row in ai for x in row)
    for j in range(9):
        x=[F[i]+4*int(j>0 and i==j-1) for i in range(8)];fc=mv(ai,x)
        if any(q.denominator==3 for q in fc):break
    else:raise AssertionError('No permitted nontrivial quotient representative')
    W=[];ks=[]
    for t in range(104):
        u0=2*int(t in plane)
        options=[]
        for k in range(3):
            a=[coeff[t][i]-(u0+4*k)*fc[i] for i in range(8)]
            if all(q.denominator==1 for q in a):options.append((k,a))
        assert len(options)==1
        k,a=options[0];ks.append(k)
        W.append([int(q) for q in a]+[u0+4*k])
    V=[[ip(y,Z[j]) for j in active]+[ip(y,x)] for y in C]
    assert rank(H[s] for s in range(104) if V[s][8]%4)==9
    for t in range(104):
        assert W[t][8]%4==2*int(t in plane)
        assert all(sum(A[i][j]*W[t][j] for j in range(8))+W[t][8]*x[i]==C[t][i] for i in range(8))
        assert all(W[t][j]%4==(mod4(coeff[t][j])-2*int(t in plane)*mod4(base_fc[j]))%4 for j in range(8))
    assert all(sum(W[t][k]*V[s][k] for k in range(9))==GRAM[t][s] for t in range(104) for s in range(104))
    row_prices=[];row_sizes=[]
    for k in range(9):
        D=[t for t in range(104) if W[t][k]%4]
        smask=sum((V[s][k]%4!=0)<<s for s in range(104))
        row_prices.append(rank(Q[t]&smask for t in D));row_sizes.append([len(D),smask.bit_count()])
    assert row_prices==c['witness_row_prices'] and sum(row_prices)==c['minimum_price']
    out.append({'removed':c['removed'],'added':c['added'],'determinant':c['determinant'],
                'minimum_price':c['minimum_price'],'plane':sorted(plane),'representative_adjustment':j,'loose_root':x,
                'u_k_by_port':ks,'k_histogram':dict(sorted(Counter(ks).items())),
                'actual_row_prices':row_prices,'actual_D_S_sizes':row_sizes,
                'full_integer_gram_witness':True})
assert len(out)==144
result={'status':'PASS','scope':'determinant ±3 price witnesses, original mod-4 f input; integer representatives may differ by multiples of four',
        'cases_checked':len(out),'integer_gram_witness_count':len(out),
        'representative_adjustment_histogram':dict(sorted(Counter(c['representative_adjustment'] for c in out).items())),
        'cases':out}
print(json.dumps(result,indent=2,sort_keys=True))
