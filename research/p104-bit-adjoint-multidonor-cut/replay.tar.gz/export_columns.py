#!/usr/bin/env python3
"""Export exact adjoint sender-bank reverse pulses as 11 little-endian limbs."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import project as p
forward,rows,_=p.physical.packet_word(p.w)
_,u=p.physical.evaluate(p.w['start'],p.w['final'],forward,rows,False)
out=HERE/'ADJOINT-COLUMNS.tsv'
with out.open('w') as stream:
 for k,(src,dst) in sorted(p.moves.items()):
  if k==3553:continue
  limbs=[(u[k]>>(64*i))&((1<<64)-1) for i in range(11)]
  stream.write(' '.join(map(str,(k,src,*limbs)))+'\n')
print('exported',len(p.moves)-1,'source-pinned columns')
