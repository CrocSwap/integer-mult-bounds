#!/usr/bin/env python3
"""Reject a literal live-XOR omission and an omitted private retirement."""
from hashlib import sha256
from pathlib import Path
import gzip,json,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'inputs'))
import literal

raw=gzip.decompress((HERE/'ZERO-CONTROL-WORD.json.gz').read_bytes())
assert sha256(raw).hexdigest()=='09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be'
word=json.loads(raw)
charts=literal.Charts(word['frames'])
paid_banks={e[1] for e in word['program'] if e[0]=='MOVE'}
controls=literal.held_out(word,charts,paid_banks)
assert controls['omitted_ADD_clock']==389 and controls['changed_coefficients']==64
assert controls['omitted_CLEAR_clock']==38717
result={'status':'PASS_LITERAL_CORRUPTION_CONTROLS',
        'scope':'A separately selected live ADD omission changes the literal public map in both orientations; omission of a CLEAR violates terminal private retirement.',
        'candidate_sha256':sha256(raw).hexdigest(),'controls':controls}
(HERE/'LITERAL-CONTROLS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(result['status'],'changed coefficients',controls['changed_coefficients'])
