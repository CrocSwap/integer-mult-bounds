// Exhaustive unordered triples within each adjoint sender bank.
// One chosen item is the retired packet; the other two are retained donors.
// Reject all relations touching the 222 main outputs or protected owner 411.
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
struct P { int id, bank; std::array<std::uint64_t,11> x; };
int main(int argc,char **argv){
 if(argc!=3){std::cerr<<"usage: pairs input output\n";return 2;}
 std::ifstream in(argv[1]);std::ofstream out(argv[2]); if(!in||!out)return 3;
 std::map<int,std::vector<P>> banks; P x;std::uint64_t count=0;
 while(in>>x.id>>x.bank){for(auto &w:x.x)if(!(in>>w))return 4;banks[x.bank].push_back(x);++count;}
 if(count!=2873)return 5;
 std::uint64_t triples=0,mainfree=0,ownerfree=0,small=0;
 std::array<std::uint64_t,4> bysize{};
 for(const auto &[bank,ps]:banks){const std::size_t n=ps.size();
  for(std::size_t a=0;a<n;++a)for(std::size_t b=a+1;b<n;++b)for(std::size_t c=b+1;c<n;++c){
   ++triples; const auto &u=ps[a].x,&v=ps[b].x,&w=ps[c].x;
   if((u[0]^v[0]^w[0])||(u[1]^v[1]^w[1])||(u[2]^v[2]^w[2])||
      ((u[3]^v[3]^w[3])&((std::uint64_t{1}<<30)-1)))continue;
   ++mainfree;
   if((u[6]^v[6]^w[6])&(std::uint64_t{1}<<27))continue; // public owner 411
   ++ownerfree;std::array<std::uint64_t,11> r{};int bits=0;
   for(int i=3;i<11;++i){r[i]=u[i]^v[i]^w[i];if(i==3)r[i]&=~((std::uint64_t{1}<<30)-1);
    bits+=std::popcount(r[i]);if(bits>3)break;}
   if(bits>3)continue;
   ++small;++bysize[bits];
   out<<bank<<' '<<ps[a].id<<' '<<ps[b].id<<' '<<ps[c].id<<' '<<bits;
   for(int i=3;i<11;++i){auto z=r[i];while(z){auto low=std::countr_zero(z);out<<' '<<(i*64+low);z&=z-1;}}
   out<<'\n';
  }
 }
 std::cout<<"banks "<<banks.size()<<" packets "<<count<<" unordered_triples "<<triples
 <<" main_free "<<mainfree<<" owner411_free "<<ownerfree<<" helper_support_le3 "<<small
 <<" by_size "<<bysize[0]<<' '<<bysize[1]<<' '<<bysize[2]<<' '<<bysize[3]<<'\n';
}
