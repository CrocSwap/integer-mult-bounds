#!/usr/bin/env python3
"""Exercise owner protection and exact no-double-count billing controls."""
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import project as p
controls={}
for name,owners in [('main_owner_43',{43}),('protected_owner_411',{411}),('empty_set',set())]:
 try:p.project(owners)
 except ValueError as e:
  if str(e)!='protected owner':raise
  controls[name]='rejected'
 else:raise ValueError(f'{name} accepted')
# The source example loses its designated alias as the unique pure-input
# packet if freely pruned. If retained until its rewrite, it must not be
# counted as an already removed packet.
a=p.project({649});b=p.project({649},keep={3266,2926,2982})
assert (a['erased']>>3266)&1 and not ((b['erased']>>3266)&1)
assert all(k in b['alive'] for k in (3266,2926,2982))
controls['retained_seed_alias_not_double_counted']='pass'
out={'status':'PASS_OWNER_AND_ACCOUNTING_CONTROLS','controls':controls,
     'scope':'Owner guards and one pre-recode retention control, not a general causal proof.'}
(HERE/'GUARD-CONTROLS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['status'],controls)
