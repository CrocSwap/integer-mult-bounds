#!/usr/bin/env python3
"""Try exact causal and literal realization of a zero-gain retained-donor control."""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip,importlib.util,json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import project as p
sys.path.insert(0,str(HERE/'inputs'));import literal,price
src=HERE/'inputs/bit_native.py'
spec=importlib.util.spec_from_file_location('bit_native_zero',src);bit=importlib.util.module_from_spec(spec);sys.modules[spec.name]=bit;spec.loader.exec_module(bit)

def make(x,k,donors):
 S=x['S'];erased=x['erased']|sum(1<<h for h in S)
 init={i:c for i,c in p.initial.items() if i not in S};end={i:c for i,c in p.final.items() if i not in S}
 moves={i:p.moves[i] for i in x['alive'] if i!=k};rows={i:p.orig[i]&~erased for i in x['alive'] if i!=k}
 rows.update({~i:p.orig[~i]&~erased for i in end})
 donor_row=p.orig[k]&~erased&~(1<<k)
 for d in donors:rows[d]^=donor_row
 for j in rows:rows[j]&=~(1<<k)
 return init,end,moves,rows,donor_row

def check(init,end,moves,rows):
 try:
  order=bit.schedule(init,end,moves,rows);vals={i:1<<i for i in init}
  for q in order:vals[q]=bit.combine(rows[q],vals)
  bad=[]
  for i in end:
   want=1<<i
   if i<111:want^=1<<(i+111)
   if bit.combine(rows[~i],vals)!=want:bad.append(i)
  return order,bad,None
 except (ValueError,KeyError) as e:return None,None,str(e)

report=json.loads((HERE/'PAIR-RETAINED-SCREEN.json').read_bytes())
zeros=[(entry,a) for entry in report['details'] for a in entry['aliases'] if not a.get('net_histogram')]
assert len(zeros)==28
summary=Counter();chosen=None
for entry,a in zeros:
 S=set(entry['surrendered']);k=a['alias'];donors=a['donors'];triple={k,*donors}
 x=p.project(S,keep=triple)
 init,end,moves,rows,dr=make(x,k,donors)
 order,bad,error=check(init,end,moves,rows)
 if error:summary['noncausal']+=1;continue
 if bad:summary['endpoint_failure']+=1;continue
 summary['projected_adjoint_pass']+=1
 if chosen is None:chosen=(entry,a,x,init,end,moves,rows,dr,order)
if chosen:
 entry,a,x,init,end,moves,rows,dr,order=chosen
 forward,frows=p.physical.dual(p.n,moves,rows)
 forward_init=end;forward_final=init
 ford=bit.schedule(forward_init,forward_final,forward,frows)
 bit.basis(forward_init,forward,frows,ford)
 w=bit.emit_word(p.w,forward_init,forward_final,forward,frows,ford)
 charts=literal.Charts(w['frames'])
 f,fl,_=literal.tape(w,charts);b,bl,_=literal.tape(w,charts,adjoint=True)
 assert f==literal.expected_rows(w['public'],False) and b==literal.expected_rows(w['public'],True)
 assert w['public']==p.n-len(x['S']) and 411 in forward_init
 caller=literal.pinned(HERE/'inputs/EFREE-CALLER.json.gz',literal.CALLER_SHA)
 nt=Counter(charts.leg(w['start'][j],w['final'][j]) for j in range(222,w['public']))
 events=Counter(e[0] for e in caller['events'])
 paid,targets=literal.paired_invoice(caller,fl['paid'],nt,events)
 ordinary=literal.ordinary(w,caller,events,paid,targets)
 old=json.loads((HERE/'inputs/BIT.json').read_bytes())['native']
 oldp=Counter({int(k):v for k,v in old['paid'].items()});oldt=Counter({int(k):v for k,v in old['targets'].items()})
 paid_delta=Counter(paid);paid_delta.subtract(oldp)
 target_delta=Counter(targets);target_delta.subtract(oldt)
 paid_delta={g:v for g,v in paid_delta.items() if v}
 target_delta={g:v for g,v in target_delta.items() if v}
 assert paid_delta==target_delta=={4:-36}
 net=Counter(targets);net.subtract(oldt);net.subtract(paid);net.update(oldp)
 net={g:v for g,v in net.items() if v}
 assert not net,'expected zero complete 36-call signed delta'
 old_ordinary=old['ordinary']
 assert old_ordinary['ordinary_records']==934182831504 and ordinary['ordinary_records']==933664973520
 assert old_ordinary['owned_backing']==6998544 and ordinary['owned_backing']==6998472
 assert ordinary['ordinary_records']<ordinary['raw_ordinary_allowance']
 assert ordinary['owned_backing']<ordinary['raw_owned_allowance']
 encoded=json.dumps(w,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(encoded,mtime=0)
 (HERE/'ZERO-CONTROL-WORD.json.gz').write_bytes(packed)
 # Test both individual omissions and removing both donor rewrites.
 controls={}
 for key,omitted in [('first',[a['donors'][0]]),('second',[a['donors'][1]]),('both',a['donors'])]:
  wrong=dict(rows)
  for donor in omitted:wrong[donor]^=dr
  _,bad,error=check(init,end,moves,wrong)
  controls[key]={'rejected':bool(error or bad),'error':error,'bad_owners':bad}
 clean={'status':'PASS_ZERO_GAIN_CONTROL','source_word':p.physical.TREE_WORD,
   'scope':'A zero-price control only, not a positive candidate; original helper is surrendered.',
   'surrendered':entry['surrendered'],'alias':a['alias'],'donors':a['donors'],
   'pre_recode_pruned':entry['pruned'],'candidate_sha256':sha256(encoded).hexdigest(),
   'candidate_gzip_sha256':sha256(packed).hexdigest(),'old_public':p.n,'new_public':w['public'],
   'protected_original_owner_411_survives':True,'both_exact_public_orientations':True,
   'ordinary_before':old_ordinary,'ordinary':ordinary,
   'paired_paid_histogram_delta':paid_delta,'paired_target_histogram_delta':target_delta,
   'complete_signed_histogram_delta':net,
   'omitted_transfer_controls':controls,
   'screened_zero_seed_outcomes':dict(summary)}
 (HERE/'ZERO-CONTROL.json').write_text(json.dumps(clean,indent=2,sort_keys=True)+'\n')
 print('PASS_ZERO_GAIN_CONTROL',entry['surrendered'],a['alias'],a['donors'],len(order),flush=True)
else:
 (HERE/'ZERO-CONTROL.json').write_text(json.dumps({'status':'NO_CAUSAL_ZERO_CONTROL',
    'screened_zero_seeds':len(zeros),'outcomes':dict(summary)},indent=2,sort_keys=True)+'\n')
 print('NO_CAUSAL_ZERO_CONTROL',dict(summary),flush=True)
