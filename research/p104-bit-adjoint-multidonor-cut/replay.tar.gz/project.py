#!/usr/bin/env python3
"""Specialize helper owners, sequentially prune zero/dead adjoint packets.

Packet-indexed GF(2) graph; original native inputs and charts remain pinned.
Each simplification round validates every surviving arbitrary-input endpoint.
This is a necessary input-quotient screen, not a compiled physical word.
"""
from collections import Counter,defaultdict
from hashlib import sha256
from heapq import heappush,heappop
from pathlib import Path
import gzip,json,sys,time

HERE=Path(__file__).resolve().parent
SRC=HERE/'inputs'
WORD=HERE/'inputs/WORD.json.gz'
sys.path.insert(0,str(SRC));import physical
raw=WORD.read_bytes()
if sha256(raw).hexdigest()!=physical.TREE_GZIP:raise ValueError('word gzip pin')
w=json.loads(gzip.decompress(raw));n=w['public']
if sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()!=physical.TREE_WORD:raise ValueError('word canonical pin')
moves,orig,clocks=physical.packet_word(w)
moves,orig=physical.dual(n,moves,orig)
order,_=physical.evaluate(w['final'],w['start'],moves,orig,True)
assert n==680 and len(moves)==2874
initial=dict(enumerate(w['final']));final=dict(enumerate(w['start']))
grades={p:abs(w['frames'][str(a)]['dim']-w['frames'][str(b)]['dim']) for p,(a,b) in moves.items()}
hg={h:w['frames'][str(w['final'][h])]['dim']-w['frames'][str(w['start'][h])]['dim'] for h in range(222,n)}

def labels(m):return physical.labels(m)
def xor_values(mask,values):
 value=0
 for j in labels(mask):value ^= values[j]
 return value

def evaluate(S, erased):
 """Retain the original DAG order while deleting only specified nodes/owners."""
 alive=[k for k in order if not (erased>>k)&1]
 owner_mask=sum(1<<h for h in S)
 erase=erased|owner_mask
 vals={j:1<<j for j in initial if j not in S}
 for k in alive:
  vals[k]=xor_values(orig[k]&~erase,vals)
 for j in initial:
  if j in S:continue
  value=xor_values(orig[~j]&~erase,vals)
  desired=1<<j
  if j<111:desired ^= 1<<(j+111)
  if value!=desired:raise ValueError(f'protected adjoint output {j}')
 return alive,vals

def reverse_columns(S,erased,alive):
 erase=erased|sum(1<<h for h in S)
 cols=dict.fromkeys(alive,0)
 for j in initial:
  if j in S:continue
  for i in labels(orig[~j]&~erase):
   if i>=n:cols[i] ^= 1<<j
 for k in reversed(alive):
  for i in labels(orig[k]&~erase):
   if i>=n:cols[i]^=cols[k]
 return cols

def project(S, max_rounds=5, keep=frozenset()):
 if not S or any(h<222 or h==411 or h>=n for h in S):raise ValueError('protected owner')
 S=frozenset(S); erased=0; steps=[]
 for iteration in range(max_rounds):
  alive,vals=evaluate(S,erased)
  # All zero-valued nodes can be simultaneously removed at this phase.
  z=[k for k in alive if vals[k]==0 and k!=3553 and k not in keep]
  if z:
   for k in z:erased |= 1<<k
   alive,vals=evaluate(S,erased)
  # Recompute sensitivities AFTER the zero phase; dead nodes can then be removed.
  col=reverse_columns(S,erased,alive)
  dead=[k for k in alive if col[k]==0 and k!=3553 and k not in keep]
  for k in dead:erased |= 1<<k
  steps.append({'iteration':iteration,'zero':len(z),'dead':len(dead)})
  if not z and not dead:break
 else:raise ValueError('did not reach bounded pruning fixed point')
 alive,vals=evaluate(S,erased);col=reverse_columns(S,erased,alive)
 return {'S':S,'erased':erased,'alive':alive,'values':vals,'columns':col,'steps':steps}

if __name__=='__main__':
 owners=[int(a) for a in sys.argv[1:]] or [274,648,649,650,662,664,665,666,667,668]
 for h in owners:
  start=time.monotonic();x=project({h});ks=[i for i in order if x['erased']>>i&1]
  print(json.dumps({'h':h,'helper_grade':hg[h], 'deleted_packets':len(ks),
                    'deleted_grades':dict(Counter(grades[k] for k in ks)),
                    'steps':x['steps'],'seconds':round(time.monotonic()-start,3)}),flush=True)
