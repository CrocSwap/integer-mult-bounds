#!/usr/bin/env python3
"""Offline, serial reproduction in a disposable copy of this package."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse,shutil,subprocess,sys

HERE=Path(__file__).resolve().parent
PINNED={
 'inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'inputs/BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
 'inputs/physical.py':'34dbf131f9d305d8e98b7284476dab2d2a250a28a02d3cf4c55b4232cfd0d435',
 'inputs/finite.py':'c780cea060f4a9efef064b239636162a7e8e84e40369abc1a1c4679dfbeb3041',
 'inputs/bit_native.py':'4368c62a5d42f81189d6776b8dba8c85a311b6a199b816244b545c6bb7d3dc1e',
 'inputs/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'inputs/price.py':'d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b',
 'PAIR-SUPPORTS.tsv':'95e68a4a7dd320477b51e0f04295ef6d7c0788de83647b262069db3ffa86b134',
}
OUTPUTS=('PACKET-2947.json','PAIR-CENSUS-REVIEW.json','PAIR-RETAINED-SCREEN.json',
         'PRICE-REVIEW.json','SUPERSET-GATE.json','GUARD-CONTROLS.json',
         'ZERO-CONTROL.json','ZERO-CONTROL-WORD.json.gz','LITERAL-CONTROLS.json')
PROGRAMS=('packet2947.py','verify_pair_census.py','scan_pairs_retained.py',
          'price_recount.py','superset_gate.py','guard_controls.py',
          'zero_control.py','literal_controls.py')

def digest(path):return sha256(path.read_bytes()).hexdigest()

def check(root):
    entries={}
    for line in (root/'SHA256SUMS').read_text().splitlines():
        expected,relative=line.split('  ',1)
        path=Path(relative)
        if path.is_absolute() or '..' in path.parts or relative in entries:
            raise ValueError('invalid manifest entry')
        entries[relative]=expected
        if digest(root/path)!=expected:
            raise ValueError('manifest mismatch: '+relative)
    for relative,expected in PINNED.items():
        if entries.get(relative)!=expected or digest(root/relative)!=expected:
            raise ValueError('source pin mismatch: '+relative)
    if any(output not in entries for output in OUTPUTS):raise ValueError('missing fixture pin')

def run(command,cwd):
    result=subprocess.run(command,cwd=cwd,text=True,stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT,timeout=120)
    if result.returncode:raise RuntimeError('failed '+command[0]+'\n'+result.stdout)
    return result.stdout

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cpp',action='store_true',help='also compile and run exhaustive C++ triple loop')
    args=parser.parse_args()
    check(HERE)
    with TemporaryDirectory(prefix='bit-adjoint-replay-') as temporary:
        work=Path(temporary)/'package'
        shutil.copytree(HERE,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        for program in PROGRAMS:
            run([sys.executable,'-IB',program],work)
            print('PASS',program,flush=True)
        for output in OUTPUTS:
            if (work/output).read_bytes()!=(HERE/output).read_bytes():
                raise ValueError('recomputed fixture differs: '+output)
        print('PASS all nine exact fixtures',flush=True)
        if args.cpp:
            compiler=shutil.which('g++')
            if not compiler:raise RuntimeError('--cpp needs g++ with C++20 support')
            run([sys.executable,'-IB','export_columns.py'],work)
            run([compiler,'-O2','-std=c++20','-Wall','-Wextra','-Werror','-o','pairs-checked','pairs.cpp'],work)
            result=run([str(work/'pairs-checked'),'ADJOINT-COLUMNS.tsv','PAIRS-CHECKED.tsv'],work)
            if sorted((work/'PAIRS-CHECKED.tsv').read_text().splitlines())!=sorted((work/'PAIR-SUPPORTS.tsv').read_text().splitlines()):
                raise ValueError('C++ triple loop disagrees with support fixture')
            if 'unordered_triples 25527581' not in result or 'helper_support_le3 137' not in result:
                raise ValueError('C++ triple counts')
            print('PASS exhaustive C++ triple loop and independent hash join',flush=True)
        # Alter bytes in place in the disposable copy only, then require rejection.
        for relative in ('inputs/WORD.json.gz','inputs/BIT.json','PAIR-SUPPORTS.tsv',
                         'PAIR-RETAINED-SCREEN.json','ZERO-CONTROL-WORD.json.gz'):
            path=work/relative
            original=path.read_bytes()
            path.write_bytes(original+b'\n')
            try:
                check(work)
            except ValueError:
                pass
            else:
                raise ValueError('altered artifact accepted: '+relative)
            finally:
                path.write_bytes(original)
        print('PASS five source and fixture corruption rejections',flush=True)
    print('PASS offline adjoint package')

if __name__=='__main__':main()
