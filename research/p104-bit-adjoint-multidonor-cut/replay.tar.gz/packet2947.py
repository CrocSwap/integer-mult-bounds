#!/usr/bin/env python3
"""Recompute original-pulse donor-subset controls for packet 2947."""
from itertools import combinations
from pathlib import Path
import json,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import project as p

forward,rows,clocks=p.physical.packet_word(p.w)
_,u=p.physical.evaluate(p.w['start'],p.w['final'],forward,rows,False)
_,v=p.physical.evaluate(p.w['final'],p.w['start'],p.moves,p.orig,True)
packet=2947
orientations={}
for name,moves,columns in [('forward',forward,v),('adjoint',p.moves,u)]:
    bank=moves[packet][0]
    donors=sorted(k for k,(a,b) in moves.items() if a==bank and k not in (packet,3553))
    cases=[]
    for size in range(2,len(donors)+1):
        for ds in combinations(donors,size):
            value=columns[packet]
            for d in ds:value ^= columns[d]
            labels=list(p.physical.labels(value))
            main=[j for j in labels if j<222]
            cases.append({'donors':ds,'protected_main_count':len(main),
                          'first_main':main[0] if main else None,
                          'owner411_exposed':411 in labels,
                          'helper_count':sum(j>=222 for j in labels)})
    assert len(cases)==(1 if name=='forward' else 4)
    assert all(case['protected_main_count'] for case in cases)
    orientations[name]={'route':moves[packet],'donors_available':donors,'cases':cases}
result={'status':'PASS_PACKET2947_ORIGINAL_PULSE_SCREEN',
        'source_word':p.physical.TREE_WORD,'packet':packet,'clock':clocks[packet],
        'grade':p.grades[packet],'orientations':orientations,
        'scope':'All same-sender donor subsets of size at least two on the original unpruned packet graph; no exclusion of relations appearing after specialization or other changes.'}
(HERE/'PACKET-2947.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(result['status'],'patterns',sum(len(x['cases']) for x in orientations.values()))
