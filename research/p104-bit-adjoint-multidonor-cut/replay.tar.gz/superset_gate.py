#!/usr/bin/env python3
"""Optimistic original-pulse gate for one extra surrendered helper.

Directly credit every original packet whose input or output pulse is supported
on the paid helper set, excluding the two donor packets that must remain paid.
This is an exploratory gate only: new zero/dead packets can appear after other
edits, so a negative direct-pulse budget is not a universal impossibility.
"""
from collections import Counter,defaultdict
from fractions import Fraction as Q
from pathlib import Path
import itertools,json,sys,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import project as p
sys.path.insert(0,str(HERE/'inputs'));import price
fw,rows,_=p.physical.packet_word(p.w);_,u=p.physical.evaluate(p.w['start'],p.w['final'],fw,rows,False)
_,v=p.physical.evaluate(p.w['final'],p.w['start'],p.moves,p.orig,True)
protected=((1<<222)-1)|(1<<411)
support_to_paid=defaultdict(set)
for k in p.moves:
 if k==3553:continue
 for signal in (u[k],v[k]):
  if signal&protected or signal.bit_count()>3:continue
  support_to_paid[frozenset(p.labels(signal))].add(k)
G={g:price.price(g,Q('0.003879928046156')) for g in range(1,9)}
def cost(removed,S):
 c=Counter(p.grades[k] for k in removed)
 for h in S:c[p.hg[h]]-=1
 lo=hi=0
 for grade,n in c.items():
  lo+=n*(G[grade][0] if n>0 else G[grade][1])
  hi+=n*(G[grade][1] if n>0 else G[grade][0])
 return (lo,hi),{g:n for g,n in c.items() if n}

def direct(S):
 out=set()
 for size in range(len(S)+1):
  for r in itertools.combinations(S,size):out.update(support_to_paid.get(frozenset(r),()))
 return out
rows=[list(map(int,line.split())) for line in (HERE/'PAIR-SUPPORTS.tsv').read_text().splitlines()]
base=[x for x in rows if x[4]<3]
counts=Counter();best=[];start=time.monotonic()
for row in base:
 bank,aa,bb,cc,k,*baseowners=row;triple=(aa,bb,cc);baseS=frozenset(baseowners)
 for extra in range(222,680):
  if extra==411 or extra in baseS:continue
  S=baseS|{extra};free=direct(S);counts['extended_owner_sets']+=1
  for alias in triple:
   counts['alias_patterns']+=1
   donors={d for d in triple if d!=alias};removed=(free-donors)|{alias};bounds,net=cost(removed,S)
   if bounds[0]>0:
    counts['strict_optimistic_positive']+=1
    best.append({'bank':bank,'triple':triple,'alias':alias,'donors':[d for d in triple if d!=alias],
                 'base_support':sorted(baseS),'charged_helpers':sorted(S),'extra_helper':extra,
                 'direct_credited_packets':sorted(free),'net_histogram':net,
                 'gain_interval':price.decimal_interval(bounds,30)})
   elif bounds[1]<0:counts['strict_optimistic_negative']+=1
   elif not net:counts['exact_zero']+=1
   else:counts['interval_ambiguous']+=1
print('DONE',dict(counts),'elapsed',round(time.monotonic()-start,3),flush=True)
(HERE/'SUPERSET-GATE.json').write_text(json.dumps({'scope':'One extra charged helper added to each original-pulse residual support of size 1 or 2; grant all original pure-input and pure-output packet deletions excluding the retained donor packets, plus one removed alias; ignore new post-edit cascades, causality, ordinary work and restoration. Negative budgets do not exclude cascades.',
 'word':p.physical.TREE_WORD,'trial':'0.003879928046156','counts':dict(counts),'positive':best},indent=2,sort_keys=True)+'\n')
