#!/usr/bin/env python3
"""Independent hash-join verification of the adjoint two-donor support census."""
from collections import Counter,defaultdict
from hashlib import sha256
from math import comb
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import project as p
forward,rows,_=p.physical.packet_word(p.w)
_,pulse=p.physical.evaluate(p.w['start'],p.w['final'],forward,rows,False)
banks=defaultdict(list)
for k,(source,dest) in p.moves.items():
 if k!=3553:banks[source].append(k)
main=(1<<222)-1; owner411=1<<411
full_count=sum(comb(len(v),3) for v in banks.values() if len(v)>=3)
seen=[];main_count=owner_count=0;total_pairs=0
for bank,ids in sorted(banks.items()):
 ids.sort();signatures=[pulse[k]&main for k in ids]
 lookup=defaultdict(list)
 for position,signature in enumerate(signatures):lookup[signature].append(position)
 for ai in range(len(ids)):
  for bi in range(ai+1,len(ids)):
   total_pairs+=1;want=signatures[ai]^signatures[bi]
   for ci in lookup.get(want,()):
    if ci<=bi:continue
    main_count+=1;r=pulse[ids[ai]]^pulse[ids[bi]]^pulse[ids[ci]]
    if r&owner411:continue
    owner_count+=1
    if r.bit_count()>3:continue
    indices=list(p.labels(r))
    seen.append([bank,ids[ai],ids[bi],ids[ci],len(indices),*indices])
expected=[list(map(int,line.split())) for line in (HERE/'PAIR-SUPPORTS.tsv').read_text().splitlines()]
if sorted(seen)!=sorted(expected):raise ValueError('independent hash join disagrees with triple loop')
counts=Counter(row[4] for row in seen)
if (len(banks),full_count,main_count,owner_count,len(seen),dict(counts))!=(636,25527581,145,145,137,{1:13,2:9,3:115}):
 raise ValueError('exact combinatorial census')
# The first accepted triple loses protected-main cancellation if one source
# column is corrupted in a main coordinate.
a,b,c=seen[0][1:4];r=(pulse[a]^1)^pulse[b]^pulse[c]
if not r&main:raise ValueError('flipped-main-pulse control not rejected')
out={'status':'PASS_INDEPENDENT_SENDER_TRIPLE_SUPPORT_JOIN','word':p.physical.TREE_WORD,
 'banks':len(banks),'packet_count':sum(map(len,banks.values())),'unordered_triples':full_count,
 'designated_alias_patterns':3*full_count,'main_free':main_count,'owner411_free':owner_count,
 'residual_support_le3':len(seen),'helper_support_sizes':dict(counts),
 'hash_join_pair_iterations':total_pairs,'support_file_sha256':sha256((HERE/'PAIR-SUPPORTS.tsv').read_bytes()).hexdigest(),
 'flipped_main_pulse_control':'rejected',
 'scope':'All original-pulse unordered same-adjoint-sender triples excluding protected packet 3553; no chronology restriction. Not a screen of >2 donors or pulse relations that become valid only after graph edits.'}
(HERE/'PAIR-CENSUS-REVIEW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['status'],out['unordered_triples'],out['helper_support_sizes'])
