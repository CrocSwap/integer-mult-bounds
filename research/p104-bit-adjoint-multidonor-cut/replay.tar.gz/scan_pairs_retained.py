#!/usr/bin/env python3
"""Reprice all <=3-helper adjoint sender triples after sequential specialization."""
from collections import Counter,defaultdict
from fractions import Fraction as Q
from pathlib import Path
from hashlib import sha256
import importlib.util,json,sys,time
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import project as p
sys.path.insert(0,str(HERE/'inputs'));import price
src=HERE/'inputs/bit_native.py'
spec=importlib.util.spec_from_file_location('bit_native_sweep',src)
bit=importlib.util.module_from_spec(spec);sys.modules[spec.name]=bit;spec.loader.exec_module(bit)
TRIAL=Q('0.003879928046156');G={g:price.price(g,TRIAL) for g in range(1,9)}

def bounds(removed,S,alias=None):
 c=Counter(p.grades[k] for k in removed)
 if alias is not None:c[p.grades[alias]]+=1
 for h in S:c[p.hg[h]]-=1
 lo=hi=0
 for grade,n in c.items():
  lo+=n*(G[grade][0] if n>0 else G[grade][1])
  hi+=n*(G[grade][1] if n>0 else G[grade][0])
 return (lo,hi),{g:n for g,n in c.items() if n}

def causal(x,k,donors):
 S=x['S'];erased=x['erased']|sum(1<<h for h in S)
 init={i:c for i,c in p.initial.items() if i not in S}
 end={i:c for i,c in p.final.items() if i not in S}
 moves={i:p.moves[i] for i in x['alive'] if i!=k}
 rows={i:p.orig[i]&~erased for i in x['alive'] if i!=k}
 rows.update({~i:p.orig[~i]&~erased for i in end})
 donor_row=p.orig[k]&~erased&~(1<<k)
 for d in donors:rows[d]^=donor_row
 for j in rows:rows[j]&=~(1<<k)
 try:
  order=bit.schedule(init,end,moves,rows)
  vals={i:1<<i for i in init}
  for z in order:vals[z]=bit.combine(rows[z],vals)
  for i in end:
   expected=1<<i
   if i<111:expected ^= 1<<(i+111)
   if bit.combine(rows[~i],vals)!=expected:
    return {'status':'endpoint_failure','owner':i}
  return {'status':'causal_projected_adjoint_pass','initial':init,'final':end,'moves':moves,'rows':rows,'order':order}
 except (ValueError,KeyError) as e:return {'status':'invalid_causal_graph','reason':str(e)}

source=HERE/'PAIR-SUPPORTS.tsv'
lines=[list(map(int,r.split())) for r in source.read_text().splitlines()]
assert len(lines)==137
stats=Counter();details=[];positive=[];start=time.monotonic()
for idx,row in enumerate(lines,1):
 bank,*z=row
 triple=z[:3];k=z[3];S=frozenset(z[4:])
 assert len(S)==k and 1<=k<=3 and 411 not in S and all(h>=222 for h in S)
 x=p.project(S,keep=frozenset(triple));removed=[q for q in p.order if x['erased']>>q&1];alive=set(x['alive'])
 base,net=bounds(removed,S)
 if base[0]>0:stats['projected_pruning_alone_positive']+=1
 entry={'bank':bank,'packets':triple,'surrendered':sorted(S),'pruned':removed,
        'pruned_grades':dict(Counter(p.grades[q] for q in removed)),
        'prune_only_net_histogram':net,'prune_only_gain':price.decimal_interval(base,30),
        'steps':x['steps'],'aliases':[]}
 for alias in triple:
  donors=[q for q in triple if q!=alias];stats['aliases_considered']+=1
  a={'alias':alias,'donors':donors}
  if alias not in alive:a['status']='alias_pruned';stats[a['status']]+=1
  elif not set(donors)<=alive:a['status']='retained_donor_pruned';stats[a['status']]+=1
  else:
   score,hist=bounds(removed,S,alias)
   a['net_histogram']=hist;a['optimistic_gain']=price.decimal_interval(score,30)
   if score[1]<=0:a['status']='optimistic_nonpositive';stats[a['status']]+=1
   else:
    a['status']='optimistic_positive';stats[a['status']]+=1
    residual=x['columns'][alias]
    for d in donors:residual ^= x['columns'][d]
    a['recomputed_pulse_residual_weight']=residual.bit_count()
    attempt=causal(x,alias,donors);a['causal_status']=attempt['status'];stats[attempt['status']]+=1
    if attempt['status']!='causal_projected_adjoint_pass':a['causal_reason']=attempt.get('reason',attempt.get('owner'))
    else:
     assert score[0]>0,'strict directed positive margin needed'
     candidate={'record':a,'bank':bank,'surrendered':sorted(S),'pruned':removed,
         'initial':attempt['initial'],'final':attempt['final'],'moves':attempt['moves'],
         'rows':{str(k):str(v) for k,v in attempt['rows'].items()},'order':attempt['order']}
     (HERE/'PAIR-RETAINED-CAUSAL-CANDIDATE.json').write_text(json.dumps(candidate,indent=2)+'\n')
     positive.append({'bank':bank,'surrendered':sorted(S),'pruned':removed,**a})
     print('POSITIVE_CAUSAL',json.dumps(positive[-1]),flush=True)
  entry['aliases'].append(a)
  if positive:break
 details.append(entry);stats['sets_checked']+=1
 if idx%20==0:print('PROGRESS',idx,dict(stats),'elapsed',round(time.monotonic()-start,1),flush=True)
 if positive:break
out={'scope':'Adjoint two-donor same-sender triples, original reverse pulse XOR supported on one to three surrendered helpers, excluding 3553 and owner411; complete static support census then bounded fixed-point projection with all three packets retained until rewrite and exact full signed grade charge. No claims for >2 donors, >3 helpers, or initially protected pulse residuals.',
 'source_word':p.physical.TREE_WORD,'support_sha256':sha256(source.read_bytes()).hexdigest(),
 'trial':str(TRIAL),'total_triples':len(lines),'stats':dict(stats),'positive':positive,
 'details':details}
(HERE/'PAIR-RETAINED-SCREEN.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('DONE',json.dumps(out['stats']),'positive',len(positive),'elapsed',round(time.monotonic()-start,3),flush=True)
