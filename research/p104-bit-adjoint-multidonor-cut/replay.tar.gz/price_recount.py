#!/usr/bin/env python3
"""Reconstruct and reprice every per-native-call retained-pair histogram."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import json,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import project as p
sys.path.insert(0,str(HERE/'inputs'))
import price

report=json.loads((HERE/'PAIR-RETAINED-SCREEN.json').read_bytes())
trial=Fraction('0.003879928046156')
assert report['trial']==str(trial) and len(report['details'])==137
result=Counter()
for entry in report['details']:
    surrendered=entry['surrendered']
    for alias in entry['aliases']:
        assert alias['status']=='optimistic_nonpositive'
        hist=Counter(p.grades[k] for k in entry['pruned'])
        hist[p.grades[alias['alias']]]+=1
        for h in surrendered:hist[p.hg[h]]-=1
        hist={k:v for k,v in hist.items() if v}
        assert {str(k):v for k,v in hist.items()}==alias['net_histogram']
        bound=price.moment(hist,trial)
        assert price.decimal_interval(bound,30)==alias['optimistic_gain']
        assert bound[1]<=0
        result['aliases']+=1
        if not hist:
            assert bound==(0,0)
            result['exact_zero']+=1
        else:
            assert bound[1]<0
            result['strictly_negative']+=1
assert dict(result)=={'aliases':411,'exact_zero':28,'strictly_negative':383}
# A missing debit changes one true zero case into a fictitious positive gain.
zero=next((e,a) for e in report['details'] for a in e['aliases'] if not a['net_histogram'])
owner=zero[0]['surrendered'][0]
fabricated=price.moment({p.hg[owner]:1},trial)
assert fabricated[0]>0
out={'status':'PASS_INDEPENDENT_SIGNED_PRICE_RECOUNT','trial':str(trial),
     'counts':dict(result),'missing_productive_debit_control':'false gain detected',
     'scope':'Reconstructs all 411 fixed-screen histograms at one native-call scale; the inherited complete paired caller uses 36 native calls. Does not account for new post-recode cascades or establish a realizable gain.'}
(HERE/'PRICE-REVIEW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['status'],dict(result))
