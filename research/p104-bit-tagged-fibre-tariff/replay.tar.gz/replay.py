#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Verify the portable packet, recorded source hashes and exact receipt."""
from hashlib import sha1,sha256
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent

def need(ok,what):
    if not ok: raise ValueError(what)

for line in (HERE/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    path=(HERE/name).resolve()
    need(path.is_relative_to(HERE),'manifest path outside packet')
    need(sha256(path.read_bytes()).hexdigest()==digest,'manifest mismatch: '+name)
print('packet manifest PASS')

source=json.loads((HERE/'SOURCES.json').read_bytes())
for item in source['inputs']+source['physical_contract_sources']+source['prior_local_receipts']:
    if 'path' not in item: continue
    path=(HERE/item['path']).resolve()
    need(path.is_relative_to(HERE),'source path outside packet')
    raw=path.read_bytes()
    need(sha256(raw).hexdigest()==item['sha256'],'source SHA-256: '+item['path'])
    if 'git_blob' in item:
        blob=sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()
        need(blob==item['git_blob'],'source git blob: '+item['path'])
print('source hashes and recorded git blobs PASS')

out=subprocess.check_output([sys.executable,'-I','-B',str(HERE/'check.py')],cwd=HERE)
need(out==(HERE/'RESULT.json').read_bytes(),'regenerated result differs')
print('exact finite control and directed receipt PASS')
print('PASS scoped route and volume comparator; no physical or kappa claim')
