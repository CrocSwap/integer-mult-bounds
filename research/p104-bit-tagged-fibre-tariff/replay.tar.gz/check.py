#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Exact tagged-fibre control and volume-normalized invoice comparison.

The field entries are bits, but addresses are residue vectors over Z/3.
This is a finite/operator and conditional pricing screen, not native replay.
"""
import copy
from fractions import Fraction
import gzip
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE/'inputs'))
import caller_eval
import tariff


def need(ok,why):
    if not ok:
        raise ValueError(why)


def pinned(name,digest):
    raw=(HERE/name).read_bytes()
    need(sha256(raw).hexdigest()==digest,'wrong source: '+name)
    return raw


pins={
'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
'inputs/BIT-WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
'inputs/7830-REVIEW.json':'077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d',
'inputs/tariff.py':'f5da41a1fc18d1e8cdf79a7d35454922c6f81ffa1272ee7d7e4f16027a45dfb4'}
blobs={name:pinned(name,digest) for name,digest in pins.items()}
w=json.loads(gzip.decompress(blobs['inputs/EFREE-CALLER.json.gz']))
native=json.loads(gzip.decompress(blobs['inputs/BIT-WORD.json.gz']))
review=json.loads(blobs['inputs/7830-REVIEW.json'])
canonical=sha256(json.dumps(native,sort_keys=True,separators=(',',':')).encode()).hexdigest()
need(canonical==review['headline']['binary_word']=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','native canonical binding')
need(review['binary']['physical']['caller']==pins['inputs/EFREE-CALLER.json.gz'],'caller binding')
need((w['ports'],w['roles'],w['stages'],len(w['events']))==(111,38,18,798),'caller dimensions')
need(w['events'][103:105]==[['IDLE_ONE',9,[9]],['SWAP',9,8]],'clock 103 and first reader')

# Verify the pinned old body bases; the fresh-stage matching below is a
# specifically chosen admissible model, not a claim about an emitted route.
def onehot(vec):
    need(all(v in (0,1) for v in vec) and sum(vec)==1,'axis basis')
    return vec.index(1)
heads=[]
bodies=[]
for j in (0,1):
    h=native['frames'][str(native['start'][j])]
    b=native['frames'][str(native['final'][111+j])]
    need((h['dim'],b['dim'])==(1,7),'head and body dimensions')
    heads.append(onehot(h['B'][0]))
    bodies.append([onehot(x) for x in b['B']])
need(heads==[0,1] and bodies==[[1,2,3,4,5,6,7],[0,2,3,4,5,6,7]],'pinned native frames')
need(caller_eval.rows(w)==caller_eval.expected(w)==caller_eval.rows(w,reverse=True),'formal caller forward and adjoint')
bad=copy.deepcopy(w)
del bad['events'][103]
need([i for i,(a,b) in enumerate(zip(caller_eval.rows(w),caller_eval.rows(bad))) if a!=b]==[0,8],'idle sensitivity')

# Build all actual addressed operators for the finite control.  There are 27
# addresses per complete field, *not* merely three one-hot axis coordinates.
m=3
points=list(product(range(m),repeat=3))  # (e0,e1,f)
index={v:i for i,v in enumerate(points)}
N=len(points)

def coordperm(pairs):
    output=[]
    for v in points:
        v=list(v)
        for a,b in pairs:
            v[a],v[b]=v[b],v[a]
        output.append(index[tuple(v)])
    need(sorted(output)==list(range(N)),'address map bijective')
    return output

P0=coordperm([(1,2)])
P1=coordperm([(0,2)])
A=coordperm([(0,1)])
need(all(P1[i]==A[P0[A[i]]] for i in range(N)),'tag 1 conjugacy on every complete residue address')

def apply(mask,permutation):
    result=0
    while mask:
        low=mask & -mask
        source=low.bit_length()-1
        result |= 1<<permutation[source]
        mask-=low
    return result


def route2(values,*,adapt=True):
    """Swap owners into two dirty tag fibres; complete Q C Q; swap back."""
    x0,x1,z0,z1=values
    x0,z0=z0,x0
    x1,z1=z1,x1
    if adapt: z1=apply(z1,A)
    z0,z1=apply(z0,P0),apply(z1,P0)
    if adapt: z1=apply(z1,A)
    x0,z0=z0,x0
    x1,z1=z1,x1
    return x0,x1,z0,z1


def route3(values,*,repair_dirty_k=False):
    """Three full F3 tag fibres, arbitrary dirty stock and auxiliary K.

    Without repair the six-field operator acts as diag(P0,P1,I,I,I,P0).
    When K=0 it is restored.  A separate P0 on K also repairs arbitrary K.
    """
    x0,x1,z0,z1,z2,k=values
    x0,z0=z0,x0
    x1,z1=z1,x1
    z2,k=k,z2
    z1=apply(z1,A)
    z0,z1,z2=(apply(z,P0) for z in (z0,z1,z2))
    z1=apply(z1,A)
    z2,k=k,z2
    x0,z0=z0,x0
    x1,z1=z1,x1
    if repair_dirty_k:
        k=apply(k,P0)
    return x0,x1,z0,z1,z2,k


def expect2(v):
    return (apply(v[0],P0),apply(v[1],P1),v[2],v[3])


def expect3(v):
    return (apply(v[0],P0),apply(v[1],P1),v[2],v[3],v[4],v[5])


def pack(values):
    return sum(v<<(N*j) for j,v in enumerate(values))


def rank(columns):
    pivots={}
    for col in columns:
        while col:
            k=col.bit_length()-1
            if k in pivots: col^=pivots[k]
            else:
                pivots[k]=col
                break
    return len(pivots)


def columns(num,fn):
    result=[]
    for i in range(num*N):
        v=[0]*num
        v[i//N]=1<<(i%N)
        result.append(pack(fn(v)))
    return result

c2=columns(4,route2)
c2want=columns(4,expect2)
need(c2==c2want,'two tags exact full input and dirty-stock operator')
need(rank(c2)==4*N,'two tags full operator rank')
need(rank([v^(1<<i) for i,v in enumerate(c2)])==18,'full-array difference rank')
need(all(v.bit_count()==1 for v in c2) and len(set(c2))==len(c2),'complete operator is a permutation')
need(all(route2(route2([int(i==j//N) << (j%N) for i in range(4)]))==tuple(int(i==j//N) << (j%N) for i in range(4)) for j in range(4*N)),'full operator involution')

badcols=columns(4,lambda v: route2(v,adapt=False))
need(sum(a!=b for a,b in zip(badcols,c2want))==24,'omitted-port-selector negative control')

# All 27^2 pairs of independent one-address input pulses, with both packet
# fibres holding nonzero arbitrary dirty masks.  The column check above proves
# the stronger statement for every combination of all 108 input bits.
z0=int('101011001001110101101011011',2)
z1=int('111000101101001100110001011',2)
need(z0 and z1 and z0 < 1<<N and z1 < 1<<N,'dirty patterns')
for i in range(N):
    for j in range(N):
        v=(1<<i,1<<j,z0,z1)
        need(route2(v)==expect2(v),'both input pulses with dirty packet')

f=index[(0,0,1)]
e0=index[(1,0,0)]
e1=index[(0,1,0)]
simultaneous=route2((1<<f,1<<f,z0,z1))
need(simultaneous==(1<<e1,1<<e0,z0,z1),'equal-pulse tag separation')
need((1<<f)^(1<<f)==0,'naive input XOR fault control')

c3raw=columns(6,route3)
c3repair=columns(6,lambda v:route3(v,repair_dirty_k=True))
c3want=columns(6,expect3)
need(c3repair==c3want,'three tags repaired dirty whole operator')
need(c3raw[:5*N]==c3want[:5*N] and sum(c3raw[i]!=c3want[i] for i in range(5*N,6*N))==18,'clean auxiliary requirement and dirty negative control')
need(rank([v^(1<<i) for i,v in enumerate(c3raw)])==27,'three-tag raw operator difference rank')
need(rank([v^(1<<i) for i,v in enumerate(c3repair)])==18,'three-tag repaired operator difference rank')

# Q(t,v)=(t,v) at t=0,2 and Q(1,v)=(1,A v).  It is not one F3-linear
# matcher: Q(2,2e0) != 2 Q(1,e0).
q_of_scaled=(2,(2,0,0))
scaled_q=(2,(0,2,0))
need(q_of_scaled!=scaled_q,'tag-selective route is not one linear matcher')

# Explicit chosen seven-axis extension in the frame from the source. Axis
# permutations prove equality on all 15 address coordinates, not on sample
# payloads. Untouched source axes/columns tensor with identity.
def swapaxes(n,pairs):
    p=list(range(n))
    for a,b in pairs:
        p[a],p[b]=p[b],p[a]
    return p

p0=swapaxes(15,[(i+1,8+i) for i in range(7)])
p1=swapaxes(15,[(0,8)]+[(i,7+i) for i in range(2,8)])
a=swapaxes(15,[(0,1)])
need(all(p1[i]==a[p0[a[i]]] for i in range(15)),'seven-axis conjugacy')
V3=3**15
fix3=3**8
r3=(V3-fix3)//2
need(V3==14348907 and fix3==6561 and r3==7171173,'seven-axis complete-address cycle count')

# Directed invoice comparisons.  A tagged service is not in the native
# schema.  The following is the explicit volume-linear comparator, granting
# zero route/selector/stock/clear charges and leaving productive bins intact.
binrec=review['binary']['signed']
paid={int(k):v for k,v in binrec['paid'].items()}
productive={int(k):v for k,v in binrec['productive'].items()}
rat=review['rational']['signed']
rpaid={int(k):v for k,v in rat['paid'].items()}
rprod={int(k):v for k,v in rat['productive'].items()}
need((sum(paid.values()),sum(productive.values()),paid[7])==(107460,20706,444),'complete old BIT invoice')
fmt=lambda v:tariff.decimal_interval(v,45)
pricing=[]
for dec in ('0.003879929046155','0.003884928046155'):
    c=Fraction(dec)
    before=tariff.moment(tariff.signed_profile(productive,paid),c)
    pp3=paid.copy(); pp3[7]+=1
    pp4=paid.copy(); pp4[7]+=2
    b3=tariff.moment(tariff.signed_profile(productive,pp3),c)
    b4=tariff.moment(tariff.signed_profile(productive,pp4),c)
    rational=tariff.moment(tariff.signed_profile(rprod,rpaid),c)
    h7=tariff.price(7,c)
    ideal=tariff.sub(tariff.scale(h7,2),tariff.price(14,c))
    need(ideal[0]>0 and h7[0]>0 and b3[1]<before[0] and b4[1]<b3[0],'directed pricing signs')
    pricing.append({'kappa':dec,'H7':fmt(h7),'old_full_BIT_margin':fmt(before),
      'two_tag_volume_linear_paid_delta':{'7':0},'two_tag_signed_increment_exact':'0',
      'three_tag_clean_aux_optimistic_paid_delta':{'7':1},'three_tag_clean_aux_signed_increment':fmt(tariff.scale(h7,-1)),
      'three_tag_clean_aux_hypothetical_full_BIT_margin':fmt(b3),
      'three_tag_dirty_aux_repair_optimistic_paid_delta':{'7':2},'three_tag_dirty_aux_repair_signed_increment':fmt(tariff.scale(h7,-2)),
      'three_tag_dirty_aux_repair_hypothetical_full_BIT_margin':fmt(b4),
      'unchanged_full_rational_margin':fmt(rational),'unconstructed_one_volume_H14_credit':fmt(ideal)})

out={
 'status':'PASS_TAGGED_FINITE_CONTROL_AND_CONDITIONAL_VOLUME_LOSS_NO_NATIVE_CANDIDATE',
 'pins_sha256':pins,'source_pr7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'caller':{'event_clock_zero_based':103,'event':w['events'][103],'next_clock':104,'next_event':w['events'][104],
           'ports':[0,1],'head_frames':[native['start'][j] for j in (0,1)],
           'body_frames':[native['final'][111+j] for j in (0,1)],'body_bases':bodies,
           'formal_forward_and_adjoint_expected_rows_each':38,'removed_idle_changes_final_rows':[0,8]},
 'finite_control':{'residue_ring':'Z/3','payload_field':'F2','address_coordinates':['e0','e1','fresh_f'],
    'addresses_per_field':N,'explicit_external_tags':[0,1],'external_tag_address_domain':2*N,
    'tag0_address_map':'swap(e1,f)','tag1_address_map':'swap(e0,f)',
    'tag1_conjugator':'swap(e0,e1)','route':'swap input owners with dirty tag fibres; Q; common S0; Q; swap back',
    'complete_linear_operator':'diag(P0,P1,I_27,I_27) on (owner0,owner1,dirty_tag0,dirty_tag1)',
    'complete_operator_shape':[4*N,4*N],'complete_operator_rank':rank(c2),
    'complete_operator_minus_identity_rank':rank([v^(1<<i) for i,v in enumerate(c2)]),
    'basis_columns_exhaustively_checked':len(c2),'input_pulse_pairs_with_dirty_stock_checked':N*N,
    'omitted_Q_bad_basis_columns':24,'equal_input_pulse_address':[0,0,1],
    'tag0_output_pulse_address':[0,1,0],'tag1_output_pulse_address':[1,0,0],
    'naive_xor_equal_pulses':0,'both_dirty_masks_restored':True},
 'full_residue_tag_control':{'tag_coordinate':'Z/3, all values 0,1,2',
    'packet_field_address_count':3*N,'input_owner_addresses':2*N,'extra_K_addresses':N,'whole_state_addresses':6*N,
    'raw_complete_operator':'diag(P0,P1,I_27,I_27,I_27,P0) on (owner0,owner1,z0,z1,z2,K)',
    'raw_minus_identity_rank':27,'raw_requires_K_zero_for_clean_restoration':True,
    'dirty_K_basis_columns_failed_without_repair':18,'repaired_operator':'diag(P0,P1,I_27,I_27,I_27,I_27)',
    'repaired_minus_identity_rank':18,'separate_one_fibre_P0_repair':True,
    'selector_Q_is_a_single_F3_linear_matcher':False,
    'nonlinearity_witness':{'Q_of_2_times_1_e0':q_of_scaled,'2_times_Q_of_1_e0':scaled_q}},
 'baseline_invoices':{'BIT':{'paid':paid,'productive':productive},'rational':{'paid':rpaid,'productive':rprod},
    'qualification':'Original pinned complete histograms. No changed physical caller or native histogram has been validated.'},
 'seven_axis_lift':{'matching_status':'illustrative stored-basis order; not emitted native matching',
    'selected_axes':15,'coordinate_matching_verified_all_axes':15,'m3_address_count_per_field':V3,
    'm3_fixed_addresses_per_field':fix3,'m3_difference_rank_per_field':r3,
    'm3_two_tags_difference_rank':2*r3,'m3_two_tags_address_count':2*V3,
    'm3_three_residue_tags_address_count':3*V3,
    'with_untouched_spectators':'multiply all address volumes and difference ranks by their cardinality',
    'ambient_f_scaling':'one field V=m^(134*f); rank(I+P0)=(m^(134*f)-m^(127*f))/2; two external tags use 2V; a full new residue coordinate has mV (m=3 gives 3V)',
    'general_full_residue_tag_route':'m-2 unused dirty tag fibres: swap each with one clean auxiliary for mH7 total; if auxiliaries are arbitrary dirty, repair each with a separate H7 service for (2m-2)H7 total',
    'scope':'coordinate-permutation extension of the finite model, not a compiled full native caller'},
 'volume_linear_invoice_comparisons':pricing,
 'limitations':['The causal route requires a barrier where both port-9 values are available before either clock-104 reader; the actual serial tape schedule has not been reconstructed.',
    'The tag-selective route is not one common linear address matcher; no source compiler, selector cost, co-live allocation, or native permitted tagged child is established.',
    'Volume-linear comparison counts complete operated fibres with the same external weight and grants all additional routing, initialization, stock and erasure zero; a tagged-child invoice is not provided by the original source schema, and this is not a universal algorithmic lower bound.',
    'An F3 tag coordinate is a finite control; the selected application requires its own chosen sufficiently large admissible cover prime.',
    'The written native seven-axis matching is illustrative and neither native forward/adjoint execution nor the modified 680-column word was rebuilt.',
    'No changed full physical productive/paid invoice, supplier, compiler, precision, tape, or conditional transfer has been certified; no kappa gain is claimed.']}
print(json.dumps(out,indent=2,sort_keys=True))
