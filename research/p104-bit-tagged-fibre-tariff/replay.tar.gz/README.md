# Tagged fibres for the BIT clock-103 idle

**Result: an abstract two-fibre construction works, but it has no gain in the stated volume-linear comparison.** Its grade-7 core operates over twice the volume of one original field, so its optimistic bill is `2 H(7)`, the cost of the two original idles, before paying for its tag-dependent routes. A full new residue tag coordinate is still larger: for the finite `m=3` control it has three fibres and an optimistic core bill `3 H(7)`. The parent compiler does not already admit this tagged service, and no physical replacement, complete changed-caller invoice, or new κ result is claimed.

The comparison is #7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. At zero-based caller clock 103, ports 0 and 1 each have `IDLE_ONE` on role 9 for stage 9. Clock 104 is `SWAP 9 8`. The pinned heads are frames 2 and 3; the bodies are 525 and 526, with coordinate bases `(e1,e2,...,e7)` and `(e0,e2,...,e7)`. The script separately checks the original 38 formal output rows in each orientation and finds that deleting the idle changes final rows 0 and 8. These formal checks do not replay the native word or prove that two simultaneous tape instructions exist. The copied [clock-103 port-batch receipt](inputs/prior-round2/bit-port-batch-receipt.json) concerns a one-field scalar-mixing screen. The separate [clock-131/196 mixed-packet receipt](inputs/prior-round2/bit-mixed-packet-result.json) found that two full fibres are necessary by rank in its one-owner setting. This packet studies a different question: two clock-103 ports placed in independent tags of a larger address domain.

## Exact complete-address control over Z/3

Use `R=Z/3`, binary-valued payloads, and **all 27** addresses `(e0,e1,f) ∈ R³` of each field. Let

```
S0: swap e1 with f       S1: swap e0 with f
A:  swap e0 with e1      S1 = A S0 A.
```

Allocate an external two-valued tag `t ∈ {0,1}`. Its packet domain is the disjoint union of two complete fields, with **54 addresses**. Denote its initially arbitrary dirty contents by `(z0,z1)` and the independently varying owner fields by `(x0,x1)`. Let `Q` apply `A` to the tag-1 fibre and identity to tag 0; let `C` apply `S0` uniformly to both tags. A complete abstract route is

1. Swap `x0` with `z0`, and `x1` with `z1`.
2. Apply `Q`, then `C`, then `Q` to the packet.
3. Swap the two owner/packet pairs back.

After the first pair of swaps, the original owners temporarily hold the dirty packet values, so no original input is lost. The final **whole-state operator** on the ordered four fields is exactly

```
diag(P0, P1, I27, I27),
```

where `Pj` is the 27-by-27 permutation matrix induced by `Sj` on complete-address payloads. It is a 108-by-108 binary linear operator of rank 108; `rank(I+U)=18`. Thus both original fields receive their own required map and both dirty packet fields are restored, for every possible combination of values. The replay checks all 108 individual columns, all 729 pairs of one-address input pulses with nonzero dirty masks, and all 27 addresses of `A S0 A = S1`. In particular, the same pulse at address `(0,0,1)` in **both** input fields is carried to `(0,1,0)` in tag 0 and `(1,0,0)` in tag 1; the two values are not XOR-merged. Omitting `Q` changes 24 basis columns and is rejected.

A logical causal schedule is to complete all work through clock 102, obtain both role-9 inputs at a common barrier, perform the **entire** tagged route, return both transformed values, and only then execute the clock-104 role-9/role-8 swaps. All other owners are to remain untouched during the route. The pinned source does not itself establish the needed common barrier, the tag selector, or a completed route at the serial-bank instruction level. This is a proposed cut-level schedule, not a reconstructed physical tape.

## Why a residue tag costs more than two fibres

The external two-element set is a useful exact model; it is not automatically one free native linear coordinate. If the tag is represented by an extra full `R=Z/3` coordinate, its values are `0,1,2`, so the complete packet has **81 addresses**, including tag 2. A common `S0` core touches all three fibres. Ignoring the tag-2 contents would not preserve arbitrary stock.

One exact route swaps the two owners with tags 0 and 1, swaps the arbitrary tag-2 field into an additional full field `K`, applies `Q C Q` to all three tag fibres, and reverses the swaps. On `(x0,x1,z0,z1,z2,K)` its exact 162-by-162 operator is

```
diag(P0, P1, I27, I27, I27, P0).
```

If `K` begins at zero, it returns to zero and all three arbitrary dirty packet fibres are restored. If `K` itself is arbitrary, it receives `P0 K`; the replay finds 18 dirty-`K` basis columns that fail restoration. Applying one additional separate `P0` service on `K` yields exactly `diag(P0,P1,I27,I27,I27,I27)` for **arbitrary** inputs and stock. This proves the stated route's operation, not that it is an optimized physical circuit.

The selector `Q` is itself a significant unresolved interface. It branches on the tag and is not a single linear matcher on `(t,e0,e1,f) ∈ R⁴`: `Q(2,2e0)=(2,2e0)` but `2Q(1,e0)=(2,2e1)`. Splitting and joining lanes, conditional routing and restoration need an explicit allowed physical implementation. The source's whole-job and routing contracts are preserved in the included framework files. This construction does not identify the tag with Ali's separate address-reversal convention.

## Lift and complete-volume comparison

For a concrete seven-axis lift, pair the stored port-0 body directions with fresh stage axes `f0,...,f6` in the listed order; do the same for port 1. Then `A` exchanges `e0,e1`, the two seven-axis permutations obey `S1=A S0 A`, and all remaining source coordinates are spectators. The script verifies this equality on each of the 15 coordinate axes. This is a fully specified **illustrative matching**: the matching actually emitted by the pinned compiler was not recovered.

At `m=3`, on those 15 active axes alone, each complete field has `3^15 = 14,348,907` address points. Each swap fixes `3^8 = 6,561` addresses, and the complete array difference rank is `(3^15-3^8)/2 = 7,171,173`. Two separate tags contain 28,697,814 points and have difference rank 14,342,346. A full ternary tag coordinate gives 43,046,721 packet points. These are complete-address counts, not the previous restricted 15-coordinate pulse-space rank. Every untouched spectator multiplies both the volume and these difference ranks by its cardinality.

At column multiplicity `f`, in the illustrative 134-axis ambient model, let `V=m^(134f)`. A grade-7 stage permutation fixes `m^(127f)` points and has difference rank `(V-m^(127f))/2`. Two external tags contain `2V`. One additional full residue tag coordinate contains `mV`; if tags 0 and 1 are the two active ones, the other `m-2` complete fibres must also be accounted for. The analogue of the above protection uses `m-2` clean full-field auxiliaries. Restoring arbitrary dirty auxiliaries by the displayed repair uses another `m-2` one-fibre services. If a construction replicates a tag coordinate across multiple tensor columns, its complete tag volume must be counted accordingly.

Write `H(r)=r^(1-κ)`. The pinned original invoice has two `H(7)` charges at these two occurrences, each normalized to one complete field volume. For this screen's explicit **volume-linear comparator**, a rank-7 core on `a` full fibres is billed `a H(7)`, all fibres use the same external weight, and routes, selectors, initialization, stock and erasure are granted zero cost. Under those deliberately favorable assumptions:

| Tested route | Core and repair bill | Signed credit relative to two old idles |
| --- | ---: | ---: |
| Two external tags, arbitrary dirty packet | `2 H(7)` | `0` |
| Full ternary tag, clean `K` | `3 H(7)` | `−H(7)` |
| Full ternary tag, arbitrary dirty `K` and explicit repair | `4 H(7)` | `−2 H(7)` |

This table is a comparison for these exact routes, **not** a theorem that every possible enlarged-domain implementation has this cost. In particular, #7830's finite invoice does not itself provide a new admissible tagged-child schema; volume-weighted billing and common external weight are assumptions of this screen, not a separately certified native invoice. A different selector, compressed domain, changed surrounding events or different child needs its own admissible operator and complete bill.

The retained prior hypothetical `2H(7)−H(14)` assumes one grade-14 service at **one** original field volume. The construction here uses a two-volume grade-7 core and does not establish that hypothetical. At `κ=0.003884928046155`, directed evaluation gives `H(7)` in `[6.947281473349702962113488481742799704322757736, 6.947281473349702962113488481742799704322757737]`. Keeping all old productive positions and granting the rest of each route free, the clean ternary option gives signed increment `−6.9472814733497...`; the arbitrary-dirty repair gives `−13.8945629466994...`. The complete original BIT signed margin there is `−1.9256152907092...`, and the unchanged rational margin is `−4.8803910899547...`. Full original paid/productive histograms and outward interval results at this and a nearer trial are in [RESULT.json](RESULT.json). The modified ternary margins in that file are **hypothetical** reweightings, not a discovered physical invoice.

## Reproduction and remaining requirements

Run from this directory with Python 3.10 or later:

```sh
python3 -I -B replay.py
```

The source-pinned, single-process script checks the complete finite operator, pulse and dirty-stock controls, illustrative lift, formal caller orientations, and directed price calculations. It verifies the included source hashes and regenerates the result byte for byte. The `m=3` example is an algebraic control, not the selected application's sufficiently large cover prime.

To claim a gain, a follow-up would need an actual native path in **both** orientations with source-valid physical selection and co-liveness; arbitrary dirty-stock and spectator handling; complete changed paid and productive histograms including volume, routes and clears; and the conditional supplier, compiler, precision/tape and outer transfer. None is established here.

Credit DreamingOfClouds for the chain-root BIT and E-free caller, CubeJerry for the QUERY-only caller, zxv and retained authors for integral transfer and the admission framework, Ali Romman and Cinna Davis for root/native lineage, and Clear1nsight, Dugongue, Rohan Arun and retained P104 contributors for the comparator and supplier. Notices under [inputs](inputs/) retain further attribution. This bounded local analysis used OpenAI Codex assistance; it is not independent human review.
