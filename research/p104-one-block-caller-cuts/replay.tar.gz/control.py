#!/usr/bin/env python3
"""Independent column-by-column witness check over F4[epsilon]/epsilon^2."""
import gzip
from hashlib import sha256
import json
from pathlib import Path

source = Path(__file__).resolve().parent / 'inputs/EFREE-CALLER.json.gz'
assert sha256(source.read_bytes()).hexdigest() == '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
w = json.loads(gzip.decompress(source.read_bytes()))
records = json.loads((Path(__file__).resolve().parent / 'RESULT.json').read_text())['pairs']

# F4 = F2[z]/(z^2+z+1), z=2; epsilon is the upper two bits.
def f4(a, b):
    c = 0
    while b:
        if b & 1:
            c ^= a
        b >>= 1
        a <<= 1
        if a & 4:
            a ^= 7
    return c

def mul(a, b):
    u, v, x, y = a & 3, a >> 2, b & 3, b >> 2
    return f4(u, x) | ((f4(u, y) ^ f4(v, x)) << 2)

assert f4(2, 3) == 1
assert mul(4, 4) == 0

def evaluate(column, q=5, d=2, substitutions=frozenset(), start=0, end=798):
    a = [int(i == column) for i in range(38)]
    for j in range(start, end):
        op, *v = w['events'][j]
        if op in ('ADD', 'QUERY'):
            x, y = v
            a[x] ^= mul(q if op == 'QUERY' and j not in substitutions else 1, a[y])
        elif op == 'SWAP':
            x, y = v
            a[x], a[y] = a[y], a[x]
        elif op == 'IDLE_ONE':
            x, stages = v
            a[x] = mul(d if 9 in stages and j not in substitutions else 1, a[x])
        elif op == 'LOCAL':
            stage, x, y = v
            a[y] ^= mul(q, a[x])
            a[x] = mul(d if stage == 9 else 1, a[x])
            a[y] = mul(d if stage == 9 else 1, a[y])
        else:
            raise ValueError(op)
    return a

def minor(record, field, start, end, q=5, d=2):
    witness = record[field]
    c1, c2 = witness['entry_columns']
    r1, r2 = witness['exit_rows']
    removed = frozenset((record['query_clock'], record['idle_clock']))
    left = evaluate(c1, q, d, start=start, end=end)
    left0 = evaluate(c1, q, d, removed, start, end)
    right = evaluate(c2, q, d, start=start, end=end)
    right0 = evaluate(c2, q, d, removed, start, end)
    return mul(left[r1] ^ left0[r1], right[r2] ^ right0[r2]) ^ mul(left[r2] ^ left0[r2], right[r1] ^ right0[r1])

checked = []
for record in records:
    assert minor(record, 'nonzero_exit_minor', 102, 394) == 12  # epsilon*(1+z)
    assert minor(record, 'full_caller_specialized_exit_minor', 0, 798) == 4  # epsilon*z*(1+z)
    # Either degenerate substitution removes one difference and kills the minor.
    assert minor(record, 'full_caller_specialized_exit_minor', 0, 798, q=1) == 0
    assert minor(record, 'full_caller_specialized_exit_minor', 0, 798, d=1) == 0
    checked.append([record['query_clock'], record['idle_clock']])

print(json.dumps({'checked_pairs': checked, 'block_minor': 'epsilon*(1+z)',
                  'full_word_minor': 'epsilon', 'controls_q1_d1': 'all 16 zero',
                  'field': 'F4[epsilon]/(epsilon^2), z^2+z+1=0',
                  'method': 'independent forward column propagation'}, indent=2))
