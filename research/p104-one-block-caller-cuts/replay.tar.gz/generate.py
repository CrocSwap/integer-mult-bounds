#!/usr/bin/env python3
"""Regenerate compact receipts and gzip-preserved exact transfer traces."""
from pathlib import Path
import gzip
import subprocess
import sys

H=Path(__file__).resolve().parent
sys.path.insert(0,str(H))
from compact import compact
def run(script):
    return subprocess.check_output([sys.executable,'-I','-B',str(H/script)],cwd=H)

for script,kind,receipt,trace,control,control_receipt in [
    ('screen.py','bit','RESULT.json','BIT-FULL.json.gz','control.py','CONTROL.json'),
    ('rational_screen.py','rational','RATIONAL-RESULT.json','RATIONAL-FULL.json.gz','rational_control.py','RATIONAL-CONTROL.json')]:
    raw=run(script)
    (H/'traces'/trace).write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))
    (H/receipt).write_bytes(compact(raw,kind))
    (H/control_receipt).write_bytes(run(control))
    print(f'{kind}: regenerated trace, compact result and independent control')

(H/'TWO-FIELD.json').write_bytes(run('two_field.py'))
print('two-field: regenerated split-idle screen')
