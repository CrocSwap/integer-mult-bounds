#!/usr/bin/env python3
"""Column-wise GF(5) controls, interpreting the original A/J records directly."""
from fractions import Fraction
import gzip
from hashlib import sha256
import json
from pathlib import Path

H = Path(__file__).resolve().parent
p = H/'inputs/RATIONAL-CALLER.json.gz'
assert sha256(p.read_bytes()).hexdigest() == 'd889996a337f648087208ab51c98eaf052705d4fca88b5d01b6e9257a829897a'
data = json.loads(gzip.decompress(p.read_bytes()))
source = [r for r in data['events'] if r[0] in ('J', 'A')]
assert len(source) == 984
records = json.loads((H/'RATIONAL-RESULT.json').read_text())['paired_results']

def rat(x):
    x = Fraction(x)
    return x.numerator * pow(x.denominator, -1, 5) % 5

def evalcolumn(col, body, swaps, start, end, q=2, d=2):
    r = [int(i == col) for i in range(34)]
    for clock in range(start,end):
        item = source[clock]
        if item[0] == 'J':
            _, stage, (x,y,u,v), _ = item
            r[y] = (r[y]+pow(q,-1,5)*r[x])%5
            r[u] = (r[u]-q*r[v])%5
            factor = d if stage-1 == body else 1
            for row in (x,y,u,v): r[row] = r[row]*factor%5
            continue
        _, op, a, *v = item
        if op == 'ADD': r[a] = (r[a]+rat(v[1])*r[v[0]])%5
        elif op == 'SCALE': r[a] = rat(v[0])*r[a]%5
        elif op == 'SWAP': r[a],r[v[0]] = r[v[0]],r[a]
        elif op == 'QUERY': r[a] = (r[a]+(1 if clock in swaps else pow(q,v[1],5))*r[v[0]])%5
        elif op == 'IDLE_ONE': r[a] = r[a]*(d if clock not in swaps and body+1 in v[0] else 1)%5
        elif op == 'LAMBDA':
            sign = v[0]
            lam = ((1+2*sign)+(1-2*sign)*q*q)*3%5
            r[a] = lam*r[a]%5
        else: raise ValueError(item)
    return r

def detpair(item, field, start, end, q=2, d=2):
    m = item[field]
    rows, cols = m['rows'], m['columns']
    changes = frozenset((item['query_clock'],item['idle_clock']))
    vec = []
    for col in cols:
        base = evalcolumn(col,item['body_color_zero_based'],frozenset(),start,end,q,d)
        edit = evalcolumn(col,item['body_color_zero_based'],changes,start,end,q,d)
        vec.append([(base[row]-edit[row])%5 for row in rows])
    return (vec[0][0]*vec[1][1]-vec[1][0]*vec[0][1])%5

for item in records:
    assert detpair(item,'block_minor',225,723) == item['block_minor']['det_mod_5'] != 0
    assert detpair(item,'full_exit_minor',0,984) == item['full_exit_minor']['det_mod_5'] != 0
    assert detpair(item,'full_exit_minor',0,984,q=1) == 0
    assert detpair(item,'full_exit_minor',0,984,d=1) == 0
print(json.dumps({'pairs_checked':len(records), 'block_and_full_minors':'all 224 matched',
                  'controls_q1_d1':'all 224 zero',
                  'method':'column-wise interpreter directly over original A/J records',
                  'field':'GF(5), sqrt(-1)=2'},indent=2))
