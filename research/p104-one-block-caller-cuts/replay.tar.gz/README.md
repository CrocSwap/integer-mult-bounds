# P104 one-block QUERY/idle screens

Local finite obstructions for [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. **No changed caller, new κ lower bound, physical implementation or publication is claimed.** [#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) at `41beda1d6435760dc99e38bd7e65f36798aad212` motivated the broader question; this package applies no theorem from it.

The exact exclusions concern replacing one QUERY and one IDLE_ONE by **one rank-one owner-field correction**, with every other literal operation and the existing caller endpoints fixed. A paid packet that multiplexes independently addressable fields, altered operations or readers, a different target contract, and different channel grades are outside this scope. No universal two-field or caller lower bound is claimed.

## Baseline and source binding

The reported #7830 conditional lower is `0.00387992803556`; the BIT raw crossing is in `[0.003879928046154, 0.003879928046155]`. The latter is an upper endpoint for this raw signed moment, not an established lower bound. Five framework assumptions remain: `native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery`.

The published exact-head independent review has SHA-256 `077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d`. Its complete rational and BIT paid/productive histograms are repriced here. The input pins, original public URLs, Git blob identifiers and attribution links are in [SOURCES.json](SOURCES.json); the original notices are under [inputs](inputs/). The review binds the rational native word `7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48`, BIT native word `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`, rational caller `156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858` and BIT caller `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`. Full price histograms appear in [RESULT.json](RESULT.json). Repricing them does not independently replay the native supplier, physical compiler, tensor theorem or outer theorem.

## Transfer obstruction

For a selected pair, replace QUERY with ordinary ADD and IDLE_ONE with identity. The difference between the actual transfer and this reference must be supplied by the new paid operation. A single owner-field packet gives an outer product `u vᵀ` after the unchanged earlier and later maps, and every 2×2 minor must vanish. The independent tests below find nonzero minors even when the full caller is started on its actual independent inputs.

The BIT word has 111 paired 38-role groups. Between its stage-9 and stage-10 native visits, the half-open interval `[102,394)` has four QUERYs and two grade-7 idles, giving eight pairs. With `q=1+ε` in `F₂[d,ε]/(ε²)`, each block-exit difference has a nonzero 2×2 minor `ε(1+d)`. From the actual 38 caller inputs, the full 798-event endpoint has a nonzero minor `εd(1+d)` for every pair after other body variables are set to 1. The unchanged operator satisfies all 38 prescribed diagonal rows in this ring.

The rational homogeneous A word occurs in 120 roots. Between J/HOST_A events 224 and 723, the interval `[225,723)` contains four QUERYs and 28 idles. For all 112 pairs, setting `i=q=2` in `F₅`, one named body variable to 2 and the remaining bodies to 1 yields a nonzero minor both at the interval exit and after the full 984-event caller. The unchanged caller satisfies all 34 prescribed diagonal rows under each selected specialization. The 192 rotated roots contain no QUERY in this source.

The compact receipts retain each pair, its block and final minor, and digests of all read differences and full exit matrices. The complete exact traces are compressed in [traces](traces/); these include every affected intervening read for each pair. A missing-pair reference first differs at BIT idle readers 104 or 132; this does not assume a different repaired word would retain that disturbance. Independent column interpreters reproduce all BIT and rational witnesses and their head/body specialization controls.

## Complete signed prices

Write `H(r)=r^(1−κ)`. A hypothetical joint grade-`r+1` job replacing a grade-1 QUERY and grade-`r` idle has paid delta `{1:-1, r:-1, r+1:+1}`, with zero target delta only if all prior targets really survive. The tests do not establish such a job. Any changed productive target, restoration, erase, precision, routing and ordinary costs must be accounted for in an actual replacement.

At `κ=0.003879928046155`, the complete BIT baseline margin is approximately `−0.000000000381875`. One ideal grade-8 bundle in all 111 groups would credit `1.29138055065230`, so this operator question matters near the raw upper. At the enrolled `0.003889928046155` comparison, even the two disjoint ideal grade-8 bundles per BIT group leave margin `−1.26180867141707`; even four ideal grade-57 bundles per A root leave rational margin `−0.661071670265925`. These favorable numerical checks are limited to the stated grade replacement and omit further physical expenses; they are not attained savings.

If one independently paid grade-1 restoration is added per group to an ideal grade-8 bundle, its BIT incremental credit at the near upper becomes approximately `−109.70861944935`. Thus that priced two-field repair cannot improve the baseline; other two-field encodings or cheaper legal channel grades need their own construction and complete bill.

We also screened a different, economically favorable **6+1 factor model**: suppose a grade-7 body idle factors as `D=UV`, where `U` is a grade-6 job and `V` represents the omitted axis. At the original idle clock apply `U`, replace the selected QUERY by ADD, keep every other literal unchanged, and permit one arbitrary rank-one field correction at any clock to supply the missing effects. Hypothetically retaining all productive targets would change the complete BIT paid bins by `{7:-111, 6:+111}` and credit about `109.76965416080668` at #7830's trial `0.003879928046148`. The unchanged rational margin at that trial is positive. These are favorable prices, not a constructed replacement.

For each of the eight pairs, [TWO-FIELD.json](TWO-FIELD.json) checks six values of `U,V` in `F₄[ε]/(ε²)`, with the same actual caller inputs and all other body variables 1. All 48 block-exit and full-caller 2×2 minors are nonzero. Consequently **this specific fixed-literal 6+1 repair cannot use one rank-one second field**, even granting that field arbitrary linear coefficients and placement. This is a necessary-condition check under the explicit `D=UV` factor model; it does not prove a physical grade-6 job exists or exclude other two-field codings, retimed partial idles, or changed operations. No restore, erase or precision price is asserted for a nonexistent candidate.

## Clean replay

Python 3.12 or newer, standard library only:

```sh
python3 -I -B replay.py
```

The replay checks [SHA256SUMS](SHA256SUMS), authenticates the copied source bytes, independently regenerates each full transfer, compares the compressed trace and compact receipt, reruns the two separate column controls, and reproduces the 6+1 screen. It writes no result files. To regenerate the receipts, run `python3 -I -B generate.py` and then update the manifest; compare every changed byte before relying on it. No network or private host path is needed.

Credit DreamingOfClouds for chain-root BIT and E-free roots, CubeJerry for the QUERY-only replacement, zxv and retained authors for integral transfer, Ali Romman and Cinna Davis for the root/native lineage, SYLforge for the homogeneous A source, Rohan Arun for the mirrored caller, and Clear1nsight, Dugongue, Rohan Arun and the retained P104 contributors for the comparator and supplier. The transferred notices record additional contributors and Apache-2.0 terms. This local screen was prepared with OpenAI Codex assistance; its computational controls are not independent human review.
