#!/usr/bin/env python3
"""Reduce transfer traces to pairwise minors plus authenticated trace digests."""
from copy import deepcopy
from hashlib import sha256
import json

def serial(value):
    return (json.dumps(value, indent=2, sort_keys=True)+'\n').encode()

def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def compact(raw, kind):
    obj = json.loads(raw)
    result = deepcopy(obj)
    if kind == 'bit':
        for row in result['pairs']:
            for name in ('affected_intermediate_reads','block_exit_difference',
                         'full_caller_specialized_exit_difference'):
                value=row.pop(name)
                row[name+'_sha256']=digest(value)
                row[name+'_count']=len(value)
    elif kind == 'rational':
        for row in result['paired_results']:
            for name in ('affected_block_reads_mod5','block_exit_difference_mod5'):
                value=row.pop(name)
                row[name+'_sha256']=digest(value)
                row[name+'_count']=len(value)
    else:
        raise ValueError(kind)
    result['full_trace_sha256']=sha256(raw).hexdigest()
    return serial(result)
