#!/usr/bin/env python3
"""Read-only regeneration and verification of both compact and full receipts."""
from hashlib import sha256
from pathlib import Path
import gzip
import json
import subprocess
import sys

H=Path(__file__).resolve().parent
sys.path.insert(0,str(H))
from compact import compact
for line in (H/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    path=H/name
    assert path.resolve().is_relative_to(H), name
    assert sha256(path.read_bytes()).hexdigest()==expected,name

def run(script):
    return subprocess.check_output([sys.executable,'-I','-B',str(H/script)],cwd=H)

for script,kind,receipt,trace,control,control_receipt in [
    ('screen.py','bit','RESULT.json','BIT-FULL.json.gz','control.py','CONTROL.json'),
    ('rational_screen.py','rational','RATIONAL-RESULT.json','RATIONAL-FULL.json.gz','rational_control.py','RATIONAL-CONTROL.json')]:
    raw=run(script)
    assert raw==gzip.decompress((H/'traces'/trace).read_bytes()),f'{kind} full transfer'
    assert compact(raw,kind)==(H/receipt).read_bytes(),f'{kind} compact receipt'
    assert run(control)==(H/control_receipt).read_bytes(),f'{kind} independent control'
    parsed=json.loads((H/receipt).read_bytes())
    if kind=='bit':
        assert parsed['per_group_pair_count']==8
        assert len(parsed['pairs'])==8
    else:
        assert parsed['pair_count']==parsed['nonzero_block_minors']==parsed['nonzero_full_exit_minors']==112
    print(f'{kind}: pinned inputs, full transfer, compact receipt and independent controls PASS')

assert run('two_field.py')==(H/'TWO-FIELD.json').read_bytes()
assert json.loads((H/'TWO-FIELD.json').read_bytes())['checked_cases']==48
print('two-field: split-idle operator and price screen PASS')
