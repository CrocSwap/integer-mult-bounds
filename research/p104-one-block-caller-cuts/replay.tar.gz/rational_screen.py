#!/usr/bin/env python3
"""Same fixed-literal one-packet screen in the #7830 pure-A J interval.

Each nonzero minor is an exact necessary-condition witness under an explicit
homomorphism from the Gaussian Laurent/body ring to GF(5), not a complete
generic rank calculation. See README for the exact scope.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

H = Path(__file__).resolve().parent
p = H / 'inputs/RATIONAL-CALLER.json.gz'
assert sha256(p.read_bytes()).hexdigest() == 'd889996a337f648087208ab51c98eaf052705d4fca88b5d01b6e9257a829897a'
caller = json.loads(gzip.decompress(p.read_bytes()))
spec = caller['types']['A']
assert spec['offset'] == 0 and spec['roles'] == 34
es = []
for source in caller['events']:
    if source[0] == 'J':
        assert (Fraction(spec['alpha2']), Fraction(spec['beta2'])) == (-1, 0)
        es.append(['HOST_A', source[1]-1, *source[2]])
    elif source[0] == 'A':
        op, dst, *args = source[1:]
        if op == 'ADD': args = [args[0], [args[1], '0']]
        elif op == 'SCALE': args = [[args[0], '0']]
        elif op in ('IDLE_ONE', 'IDLE_ODD'): args[0] = [j-1 for j in args[0]]
        else: assert op in ('QUERY', 'SWAP', 'LAMBDA')
        es.append([op, dst, *args])
diagonal = [[phase, [j for j, x in enumerate(mask) if x]]
            for phase, scalar, *mask in spec['diagonal'] if scalar == 0]
assert len(diagonal) == 34
assert sha256(json.dumps([es, diagonal], separators=(',', ':')).encode()).hexdigest() == '2d7fd07ad9305539e67119239b3db3b0efa61bd3ac8fdddd7276a963afaea540'
assert len(es) == 984 and es[224][0] == es[723][0] == 'HOST_A'
Q = [i for i in range(225, 723) if es[i][0] == 'QUERY']
I = [i for i in range(225, 723) if es[i][0] == 'IDLE_ONE']
assert Q == [325, 431, 554, 633] and len(I) == 28
assert not any(e[0] == 'QUERY' for e in es[:225] + es[723:])

N, PRIME, SQRT_MINUS_ONE = 34, 5, 2
def f(x):
    x = Fraction(x)
    return x.numerator * pow(x.denominator, -1, PRIME) % PRIME
def cx(c):
    return (f(c[0]) + SQRT_MINUS_ONE * f(c[1])) % PRIME
def eye():
    return [[int(r == c) for c in range(N)] for r in range(N)]
def add(a, b, c):
    return [(x + c*y) % PRIME for x, y in zip(a, b)]
def scalar(a, c):
    return [(x*c) % PRIME for x in a]
def operate(rows, event, body, replace=False):
    op, *a = event
    if op == 'HOST_A':
        s, x, y, u, v = a
        rows[y] = add(rows[y], rows[x], pow(SQRT_MINUS_ONE, -1, PRIME))
        rows[u] = add(rows[u], rows[v], -SQRT_MINUS_ONE)
        t = 2 if s == body else 1
        for r in (x, y, u, v): rows[r] = scalar(rows[r], t)
    elif op == 'ADD':
        dst, src, c = a
        rows[dst] = add(rows[dst], rows[src], cx(c))
    elif op == 'SCALE':
        dst, c = a
        rows[dst] = scalar(rows[dst], cx(c))
    elif op == 'SWAP':
        x, y = a
        rows[x], rows[y] = rows[y], rows[x]
    elif op == 'LAMBDA':
        dst, sign = a
        z = ((1 + sign*SQRT_MINUS_ONE) + (1 - sign*SQRT_MINUS_ONE)*SQRT_MINUS_ONE**2) * pow(2, -1, PRIME)
        rows[dst] = scalar(rows[dst], z % PRIME)
    elif op == 'QUERY':
        dst, src, phase = a
        rows[dst] = add(rows[dst], rows[src], 1 if replace else pow(SQRT_MINUS_ONE, phase, PRIME))
    elif op == 'IDLE_ONE':
        dst, mask = a
        rows[dst] = scalar(rows[dst], 1 if replace or body not in mask else 2)
    else:
        raise ValueError(event)
def operands(e):
    if e[0] == 'HOST_A': return e[2:]
    if e[0] in ('ADD', 'QUERY', 'SWAP'): return e[1:3]
    return [e[1]]
def delta(a, b):
    return [[(x-y) % PRIME for x, y in zip(ar, br)] for ar, br in zip(a, b)]
def witness(mat):
    for r in range(N):
        for c in range(N):
            if mat[r][c]:
                for s in range(N):
                    if s == r: continue
                    for t in range(N):
                        if t == c: continue
                        det = (mat[r][c]*mat[s][t] - mat[r][t]*mat[s][c]) % PRIME
                        if det:
                            return {'rows': [r,s], 'columns':[c,t], 'det_mod_5':det,
                                    'minor':[[mat[r][c], mat[r][t]],[mat[s][c],mat[s][t]]]}
                return None  # a nonzero pivot suffices to test rank > 1
    return None
def run(qclock, iclock, start, end, collect=False):
    body = es[iclock][2][0]
    left, right = eye(), eye()
    reads = []
    for clock in range(start, end):
        event = es[clock]
        if collect:
            changed = []
            for owner in operands(event):
                if left[owner] != right[owner]:
                    changed.append([owner, ''.join(str((x-y)%5) for x,y in zip(left[owner], right[owner]))])
            if changed: reads.append([clock, changed])
        operate(left, event, body)
        operate(right, event, body, clock in (qclock, iclock))
    return left, right, reads

items = []
for q in Q:
    for idle in I:
        left, right, reads = run(q, idle, 225, 723, True)
        out = delta(left, right)
        block = witness(out)
        leftf, rightf, _ = run(q, idle, 0, len(es))
        end = witness(delta(leftf, rightf))
        # If zero, the specialization is inconclusive; no rank claim follows.
        items.append({'query_clock': q, 'idle_clock': idle, 'idle': es[idle],
                      'body_color_zero_based': es[idle][2][0],
                      'block_minor': block, 'full_exit_minor': end,
                      'block_exit_difference_mod5': [''.join(str(v) for v in row) for row in out],
                      'affected_block_reads_mod5': reads})

# Actual unchanged full operator must be the prescribed 34-row diagonal.
for color in set(es[i][2][0] for i in I):
    # The body specialization is checked directly without a chosen edit.
    rows = eye()
    for e in es: operate(rows, e, color)
    for r, (phase, mask) in enumerate(diagonal):
        expected = pow(SQRT_MINUS_ONE, phase, PRIME) * (2 if color in mask else 1) % PRIME
        assert rows[r] == [expected if r == c else 0 for c in range(N)]

for name, expected in {'tariff.py':'f5da41a1fc18d1e8cdf79a7d35454922c6f81ffa1272ee7d7e4f16027a45dfb4'}.items():
    assert sha256((H/'inputs'/name).read_bytes()).hexdigest() == expected
sys.path.insert(0, str(H/'inputs'))
import tariff as price
receipt_path = H/'inputs/7830-REVIEW.json'
assert sha256(receipt_path.read_bytes()).hexdigest() == '077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d'
r = json.loads(receipt_path.read_text())
assert r['headline']['rational_word'] == '7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
invoice = r['rational']['signed']
paid = {int(k):v for k,v in invoice['paid'].items()}
targets = {int(k):v for k,v in invoice['productive'].items()}
fmt = lambda x: price.decimal_interval(x, 42)
def economics(kstr):
    k = Fraction(kstr)
    tariffs = {8*n: price.scale(price.sub(price.add(price.price(1,k),price.price(8*n,k)),price.price(8*n+1,k)),120)
               for n in range(1,8)}
    # Four occurrences of each grade among the 28 idles per root. The
    # four rank-56 jobs give the best disjoint paid-only upper.
    assert all(tariffs[8*j][1] < tariffs[8*(j+1)][0] for j in range(1,7))
    optimal = price.scale(tariffs[56], 4)
    margin = price.moment(price.signed_profile(targets, paid), k)
    return {'baseline_margin': fmt(margin), 'per_grade_one_pair_120_roots': {str(g):fmt(t) for g,t in tariffs.items()},
            'four_pair_optimistic_credit':fmt(optimal), 'four_pair_optimistic_margin':fmt(price.add(margin,optimal)),
            'extra_rank1_per_root_for_one_pair':fmt(price.sub(tariffs[56],price.scale(price.price(1,k),120)))}

print(json.dumps({'source_sha256': sha256(p.read_bytes()).hexdigest(),
                  'pure_A_compact_sha256':'2d7fd07ad9305539e67119239b3db3b0efa61bd3ac8fdddd7276a963afaea540',
                  'scope':'120 A roots; fixed other literals; one rank-one owner-field correction',
                  'half_open_block':[225,723], 'query_clocks':Q, 'idle_clocks':I,
                  'idle_length_census':dict(sorted(Counter(len(es[i][2]) for i in I).items())),
                  'field':'GF(5), head=i=2, selected body D=2, other bodies=1',
                  'pair_count':len(items),
                  'nonzero_block_minors':sum(v['block_minor'] is not None for v in items),
                  'nonzero_full_exit_minors':sum(v['full_exit_minor'] is not None for v in items),
                  'unchanged_full_diagonal_check':'PASS for every selected body specialization',
                  'paired_results':items,
                  'hypothetical_economics':{'upper_crossing':economics('0.003879928046155'),
                                             'enrolled_target':economics('0.003889928046155')},
                  'limitations':['a zero minor here is inconclusive, not a candidate',
                                 'multiplexed packet fields, changed protected literals or exits are outside scope',
                                 'pricing is only an optimistic paid-only hypothetical, with no earned target change',
                                 'no changed candidate or physical replay']}, indent=2, sort_keys=True))
