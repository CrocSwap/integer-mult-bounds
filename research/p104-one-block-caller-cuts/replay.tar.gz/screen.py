#!/usr/bin/env python3
"""Exact fixed-literal QUERY+idle pair screen in the #7830 BIT caller.

This treats one replacement packet as one rank-one change on the vector of
38 owner fields. It does not rule out a packet with independently multiplexed
subfields, another interface, or edits to the other operations.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
CALLER = HERE / 'inputs/EFREE-CALLER.json.gz'
INVOICE = HERE / 'inputs/7830-REVIEW.json'
WORD = HERE / 'inputs/BIT-WORD.json.gz'
PRICE_DIR = HERE / 'inputs'
PINS = {
    CALLER: '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
    INVOICE: '077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d',
    WORD: 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
    PRICE_DIR / 'tariff.py': 'f5da41a1fc18d1e8cdf79a7d35454922c6f81ffa1272ee7d7e4f16027a45dfb4',
}
for path, digest in PINS.items():
    assert sha256(path.read_bytes()).hexdigest() == digest, path
sys.path.insert(0, str(PRICE_DIR))
import tariff as price

w = json.loads(gzip.decompress(CALLER.read_bytes()))
events = w['events']
receipt = json.loads(INVOICE.read_text())
assert receipt['headline']['binary_word'] == 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
native = json.loads(gzip.decompress(WORD.read_bytes()))
assert sha256(json.dumps(native, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == receipt['headline']['binary_word']
assert (w['roles'], w['ports'], len(events)) == (38, 111, 798)
assert events[100:102] == [['LOCAL', 9, 1, 0], ['LOCAL', 9, 20, 19]]
assert events[394:396] == [['LOCAL', 10, 1, 0], ['LOCAL', 10, 20, 19]]
START, END, N = 102, 394, 38  # [START, END), after stage 9 and before stage 10
query = [i for i in range(START, END) if events[i][0] == 'QUERY']
idle = [i for i in range(START, END) if events[i][0] == 'IDLE_ONE']
assert query == [196, 198, 201, 349]
assert idle == [103, 131]
assert all(events[i][2] == [9] for i in idle)

# Ring GF(2)[d,e]/(e^2), where q=1+e and d denotes the stage-9
# body monomial. Each coefficient is (polynomial-in-d bits, e-part bits).
# The whole block only uses d from paid idles. Other q uses stay intact.
ZERO = (0, 0)
ONE = (1, 0)
Q = (1, 1)
D = (2, 0)

def xor(a, b):
    return a[0] ^ b[0], a[1] ^ b[1]

def pmul(a, b):
    out = 0
    while b:
        low = b & -b
        out ^= a << (low.bit_length() - 1)
        b ^= low
    return out

def mul(a, b):
    return pmul(a[0], b[0]), pmul(a[0], b[1]) ^ pmul(a[1], b[0])

def mat_identity():
    return [[ONE if i == j else ZERO for j in range(N)] for i in range(N)]

def apply(rows, e, replacement=False):
    op, *a = e
    if op in ('ADD', 'QUERY'):
        dest, src = a
        c = Q if op == 'QUERY' and not replacement else ONE
        rows[dest] = [xor(x, mul(c, y)) for x, y in zip(rows[dest], rows[src])]
    elif op == 'SWAP':
        r, s = a
        rows[r], rows[s] = rows[s], rows[r]
    elif op == 'IDLE_ONE':
        r, mask = a
        c = ONE if replacement or 9 not in mask else D
        rows[r] = [mul(x, c) for x in rows[r]]
    elif op == 'LOCAL':
        stage, src, dest = a
        assert not replacement
        rows[dest] = [xor(x, mul(Q, y)) for x, y in zip(rows[dest], rows[src])]
        c = D if stage == 9 else ONE
        rows[src] = [mul(x, c) for x in rows[src]]
        rows[dest] = [mul(x, c) for x in rows[dest]]
    else:
        raise ValueError(e)

def used(e):
    op = e[0]
    if op in ('ADD', 'QUERY', 'SWAP'):
        return [e[1], e[2]]
    if op == 'LOCAL':
        return [e[2], e[3]]
    assert op == 'IDLE_ONE'
    return [e[1]]

def delta(a, b):
    return [[xor(x, y) for x, y in zip(ar, br)] for ar, br in zip(a, b)]

def polytext(bits):
    return [j for j in range(bits.bit_length()) if bits >> j & 1]

def encode(c):
    return {'constant_d_powers': polytext(c[0]), 'epsilon_d_powers': polytext(c[1])}

def sparse(row):
    return [{'input': c, 'coefficient': encode(value)} for c, value in enumerate(row) if value != ZERO]

def sparse_matrix(matrix):
    return [{'output': r, 'terms': sparse(row)} for r, row in enumerate(matrix)
            if any(value != ZERO for value in row)]

def first_minor(x):
    for r, s in combinations(range(N), 2):
        for c, d in combinations(range(N), 2):
            det = xor(mul(x[r][c], x[s][d]), mul(x[r][d], x[s][c]))
            if det != ZERO:
                return {'exit_rows': [r, s], 'entry_columns': [c, d],
                        'determinant': encode(det),
                        'matrix': [[encode(x[r][c]), encode(x[r][d])],
                                   [encode(x[s][c]), encode(x[s][d])]]}
    return None

def run_pair(qclock, iclock):
    actual, base = mat_identity(), mat_identity()
    affected = []
    for clock in range(START, END):
        e = events[clock]
        rows = used(e)
        prior = [r for r in rows if actual[r] != base[r]]
        if prior:
            affected.append({'clock': clock, 'event': e,
                             'affected_input_differences': {
                                 str(r): sparse([xor(x, y) for x, y in zip(actual[r], base[r])])
                                 for r in prior}})
        apply(actual, e)
        apply(base, e, clock in (qclock, iclock))
    diff = delta(actual, base)
    witness = first_minor(diff)
    # A nonzero 2x2 minor rules out a single rank-one scalar-field
    # correction at any point with all other gates held fixed.
    assert witness is not None
    return {'query_clock': qclock, 'query': events[qclock], 'idle_clock': iclock,
            'idle': events[iclock], 'affected_intermediate_reads': affected,
            'changed_exit_rows': [r for r in range(N) if actual[r] != base[r]],
            'block_exit_difference': sparse_matrix(diff),
            'nonzero_exit_minor': witness}

pairs = [run_pair(q, i) for q in query for i in idle]

# Replay the whole 798-event word on its actual 38 independent input fields.
# All other body monomials are specialized to 1, while d=D9 and q=1+e
# remain formal. This retains a necessary condition of the real interface,
# and avoids assuming that arbitrary block-entry forms are reachable.
def complete(replacements):
    a, b = mat_identity(), mat_identity()
    for clock, e in enumerate(events):
        apply(a, e)
        apply(b, e, clock in replacements)
    return a, b

actual, unchanged = complete(set())
assert actual == unchanged
for row, expected in enumerate(w['diagonal']):
    c = mul(Q, D if 9 in expected['stages'] else ONE)
    assert expected['q'] == 1
    assert actual[row] == [c if row == col else ZERO for col in range(N)]
for item in pairs:
    a, b = complete({item['query_clock'], item['idle_clock']})
    full_diff = delta(a, b)
    witness = first_minor(full_diff)
    assert witness is not None
    item['full_caller_specialized_exit_minor'] = witness
    item['full_caller_specialized_exit_difference'] = sparse_matrix(full_diff)

# Controls: the block's pair-free identity comparison, a single missing paid
# idle, and a single QUERY specialized to ADD have no nonzero 2x2 minors.
def get_diff(replacements):
    a, b = mat_identity(), mat_identity()
    for clock in range(START, END):
        apply(a, events[clock])
        apply(b, events[clock], clock in replacements)
    return delta(a, b)
assert first_minor(get_diff(set())) is None
for c in query + idle:
    diff = get_diff({c})
    assert any(any(x != ZERO for x in row) for row in diff)
    assert first_minor(diff) is None

binv = receipt['binary']['signed']
paid = {int(k): v for k, v in binv['paid'].items()}
targets = {int(k): v for k, v in binv['productive'].items()}
rinv = receipt['rational']['signed']
rpaid = {int(k): v for k, v in rinv['paid'].items()}
rtargets = {int(k): v for k, v in rinv['productive'].items()}
assert sum(paid.values()) == 107460
assert sum(targets.values()) == 20706
signed = price.signed_profile(targets, paid)

def fmt(z):
    return price.decimal_interval(z, 42)

def price_at(kstr):
    k = Fraction(kstr)
    base = price.moment(signed, k)
    # A merely hypothetical direct-sum rank-8 service with unchanged targets.
    one = price.scale(price.sub(price.add(price.price(1, k), price.price(7, k)),
                                price.price(8, k)), 111)
    two = price.scale(one, 2)
    p1 = price.scale(price.price(1, k), 111)
    return {'baseline_binary_signed_margin': fmt(base),
            'baseline_rational_signed_margin': fmt(price.moment(price.signed_profile(rtargets, rpaid), k)),
            'one_pair_optimistic_credit': fmt(one),
            'two_disjoint_pairs_optimistic_credit': fmt(two),
            'one_pair_with_one_extra_grade1_per_group': fmt(price.sub(one, p1)),
            'two_pairs_optimistic_margin': fmt(price.add(base, two))}

out = {
    'scope': 'one fixed 38-role BIT interval, one query and one idle, all other literals fixed',
    'pins_sha256': {str(k.relative_to(HERE)): v for k, v in PINS.items()},
    'binary_word_canonical_sha256': receipt['headline']['binary_word'],
    'rational_word_canonical_sha256': receipt['headline']['rational_word'],
    'comparator_head': '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
    'mixed_application_sha256': receipt['replay_sha256']['APPLICATION.json'],
    'rational_caller_sha256': receipt['rational']['caller'],
    'complete_baseline_binary_paid': paid,
    'complete_baseline_binary_productive': targets,
    'complete_baseline_rational_paid': rpaid,
    'complete_baseline_rational_productive': rtargets,
    'block_half_open': [START, END], 'queries': query, 'idles': idle,
    'per_group_pair_count': len(pairs),
    'disjoint_pair_maximum': min(len(query), len(idle)),
    'ring': 'GF(2)[d,e]/(e^2), q=1+e',
    'baseline_replacements': 'selected QUERY becomes ADD; selected IDLE becomes identity',
    'pairs': pairs,
    'controls': {'unchanged_comparison_zero': True, 'each_single_edit_nonzero_rank_at_most_one': True},
    'full_caller_control': 'all 38 prescribed diagonal output rows hold with q=1+e, D9=d, and all other D=1',
    'hypothetical_price': {'upper_crossing': price_at('0.003879928046155'),
                           'enrolled_target': price_at('0.003889928046155')},
    'hypothetical_paid_delta_per_111_groups_for_one_pair': {'1': -111, '7': -111, '8': 111},
    'hypothetical_productive_delta': {},
    'price_qualification': 'hypothetical service only; no packet or complete signed candidate is constructed',
    'limitations': ['one replacement is a single rank-one owner-field correction',
                    'the comparison fixes all other events',
                    'no independently multiplexed subfield interface is assumed',
                    'ordinary, physical, restore, erase and precision costs are not priced as zero in a claimed candidate',
                    'no changed candidate, full replay or kappa gain is claimed'],
}
print(json.dumps(out, indent=2, sort_keys=True))
