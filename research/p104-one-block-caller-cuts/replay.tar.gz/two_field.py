#!/usr/bin/env python3
"""Screen a distinct 6+1 two-field BIT repair under an explicit factor model.

At the original grade-7 idle write D=UV, with U grade 6 and V grade 1.
Shorten the idle to U, replace the chosen QUERY by ADD, and allow one
additional arbitrary rank-one correction anywhere. If the resulting final
residual has a nonzero 2x2 minor, that correction cannot supply it.

Specializations into F4[e]/e^2 are only necessary conditions for the
abstract factorization model; no physical grade-6 compiler is assumed.
"""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

H=Path(__file__).resolve().parent
p=H/'inputs/EFREE-CALLER.json.gz'
assert sha256(p.read_bytes()).hexdigest()=='757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
w=json.loads(gzip.decompress(p.read_bytes()))
records=json.loads((H/'RESULT.json').read_text())['pairs']
review=H/'inputs/7830-REVIEW.json'
assert sha256(review.read_bytes()).hexdigest()=='077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d'
review=json.loads(review.read_text())
assert sha256((H/'inputs/tariff.py').read_bytes()).hexdigest()=='f5da41a1fc18d1e8cdf79a7d35454922c6f81ffa1272ee7d7e4f16027a45dfb4'
sys.path.insert(0,str(H/'inputs'))
import tariff

def f4(a,b):
    out=0
    while b:
        if b&1: out^=a
        b>>=1
        a<<=1
        if a&4: a^=7
    return out

def mul(a,b):
    u,v,x,y=a&3,a>>2,b&3,b>>2
    return f4(u,x)|((f4(u,y)^f4(v,x))<<2)

def evaluate(column, query, idle, u, v, modified=False, start=0, end=798):
    a=[int(i==column) for i in range(38)]
    d=f4(u,v)
    for t in range(start,end):
        op,*z=w['events'][t]
        if op in ('ADD','QUERY'):
            dst,src=z
            a[dst]^=mul(1 if op=='ADD' or (modified and t==query) else 5,a[src])
        elif op=='SWAP':
            a[z[0]],a[z[1]]=a[z[1]],a[z[0]]
        elif op=='IDLE_ONE':
            dst,stages=z
            factor=(u if modified and t==idle else d) if 9 in stages else 1
            a[dst]=mul(factor,a[dst])
        elif op=='LOCAL':
            stage,src,dst=z
            a[dst]^=mul(5,a[src])
            factor=d if stage==9 else 1
            a[src],a[dst]=mul(factor,a[src]),mul(factor,a[dst])
        else: raise ValueError(op)
    return a

def witness(item,which,u,v,start,end):
    info=item[which]
    rows=info['exit_rows']
    cols=info['entry_columns']
    vec=[]
    for col in cols:
        good=evaluate(col,item['query_clock'],item['idle_clock'],u,v,False,start,end)
        changed=evaluate(col,item['query_clock'],item['idle_clock'],u,v,True,start,end)
        vec.append([good[r]^changed[r] for r in rows])
    return mul(vec[0][0],vec[1][1])^mul(vec[1][0],vec[0][1])

# Both 1 and the two nontrivial nonzero F4 choices for U are used.  V is
# nontrivial, so the omitted body factor is not silently specialized away.
cases=[]
for item in records:
    for u,v in [(1,2),(2,2),(3,2),(1,3),(2,3),(3,3)]:
        block=witness(item,'nonzero_exit_minor',u,v,102,394)
        whole=witness(item,'full_caller_specialized_exit_minor',u,v,0,798)
        assert block and whole
        cases.append({'query_clock':item['query_clock'],'idle_clock':item['idle_clock'],
                      'U_F4':u,'V_F4':v,'block_minor':block,'full_caller_minor':whole})

def prices(ktext):
    k=Fraction(ktext)
    # Hypothetical replacement: original grade 7 idle plus grade 1 query,
    # versus a grade 6 idle plus one grade 1 correction, unchanged targets.
    credit=tariff.scale(tariff.sub(tariff.price(7,k),tariff.price(6,k)),111)
    def hist(part):
        return {int(rank):count for rank,count in review[part]['signed']['productive'].items()}, {int(rank):count for rank,count in review[part]['signed']['paid'].items()}
    bt,bp=hist('binary')
    rt,rp=hist('rational')
    binary=tariff.moment(tariff.signed_profile(bt,bp),k)
    rational=tariff.moment(tariff.signed_profile(rt,rp),k)
    return {'optimistic_credit':tariff.decimal_interval(credit,42),
            'complete_baseline_bit_margin':tariff.decimal_interval(binary,42),
            'hypothetical_bit_margin':tariff.decimal_interval(tariff.add(binary,credit),42),
            'unchanged_rational_margin':tariff.decimal_interval(rational,42)}

out={'model':'D=U*V; U is the six-axis idle at its original clock; one further rank-one field anywhere',
     'query_replacement':'QUERY becomes ADD',
     'pair_count':len(records),'specializations_per_pair':6,'checked_cases':len(cases),
     'all_block_and_full_minors_nonzero':True,'cases':cases,
     'hypothetical_paid_delta_per_111_groups':{'7':-111,'6':111},
     'hypothetical_productive_delta':{},
     'optimistic_6_plus_1_credit':{
         'trial_0.003879928046148':prices('0.003879928046148'),
         'raw_upper_0.003879928046155':prices('0.003879928046155'),
         'enrolled_0.003889928046155':prices('0.003889928046155')},
     'limitations':['shortened idle must factor as D=UV and all other operations remain fixed',
                    'the hypothetical new paid positions are not physically constructed',
                    'other two-field interfaces, retimed shortened idles or extra changed operations remain open',
                    'ordinary, restore, erase and precision costs require their own complete bill'],
     'status':'NO_SINGLE_RANK_ONE_SECOND_FIELD_IN_THIS_FACTOR_MODEL'}
print(json.dumps(out,indent=2,sort_keys=True))
