# The seven-dimensional low-depositor rank cut

This is a **paper proof, not a Lean theorem**, at [P104 PR #7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) head
`41beda1d6435760dc99e38bd7e65f36798aad212`. It uses the pinned 8-row
[rigidity and normal-basis restriction](PARENT-RESULT.md), and the preceding
[ancestor-cut note](next/README.md).
Credit for the underlying P104 package and its 8-row rigidity belongs to
DreamingOfClouds with Claude Opus 5.5. It does **not** settle the NET-D56
question for general networks or establish legal-word realizability.

## Claim and exact scope

Assume a P104 `NetW` has `b_k <= a_k` at every node, exactly nine
active gatherers with chart dimensions `7,7,>=8,>=8,>=8,>=8,>=8,>=8,>=8`,
and exactly eight active depositors. Assume no depositor reaches a
different depositor in the directed H-support graph. If **every** depositor
has `dim a >= 7`, then `D >= 56`.

Consequently, under these same gatherer and antichain assumptions, any
counterexample with `D <= 55` must have **at least one depositor with
`dim a <= 6`**. Such a counterexample may also have 7D low depositors.
A separate, independently reviewed [6D/7D two-low-depositor theorem](TWO-LOW-6-7.md)
also rules out `D <= 55` when exactly two depositors have dimensions 6 and 7.
The remaining profiles involving dimension at most 6, and depositor-to-depositor
relay paths, are not covered. The results apply to
all 8,766 admissible eight-element bases of depositor normal masks; it does
not assert that all those normal bases can be realized by networks.

## Proof

Let `N=(I-H)^(-1)`. The odd/diagonal transfer conditions and the P104
8-clique give rank `M=8`; with exactly eight depositors, the 8-by-9 matrix
`N[dep,gat]` has row rank eight. Its unique column dependence has nonzero
coefficients for both 7D gatherers; their 7D input charts are distinct,
since their sum has dimension at least eight. These facts follow from the
pinned 8-row rigidity as in the preceding notes. Each depositor has
`dim b <= 1`.

Suppose `D <= 55`. Write `m` for the number of depositors with `dim a=7`,
`B` for the number with `dim b=0`, `E=sum_d max(dim a_d-8,0)`, and
`T` for the total drop of nondepositors. Nestedness gives exactly

```
D = 56 - m + E + B + T.                                  (1)
```

If `m=0`, (1) gives `D>=56`. If `m=1`, the ancestor-cone cut in the
preceding note gives `T>=1`, and (1) again gives `D>=56`. For `m>=2`,
let `L` be the `m` low depositors, let `C` be `N[L,gat]`, and let `C_H`
be its seven columns for the high gatherers. The rows of `C` are
independent. The unique relation among all nine gatherer columns has a
nonzero coefficient on each low gatherer, so the two low columns together
add at most one dimension modulo the high columns. Therefore

```
rank(C_H) >= m-1.                                         (2)
```

Let `X` be the set of positive-drop nondepositors. Every high-gatherer to
`L` support path meets `X`. Otherwise, antichain forbids any intermediate
depositor and also forbids the high gatherer from being a different
source-depositor. All nodes before its low-depositor endpoint have zero
drop, so relay inclusion propagates the high gatherer's chart of dimension
at least eight into the endpoint's 7D chart, a contradiction. This includes
the length-zero case: a high gatherer cannot itself be a 7D depositor.
The usual path factorization therefore gives `rank(C_H)<=|X|`. Since each
node in `X` has integral drop at least one, (1) and (2) yield

```
m-1 <= rank(C_H) <= |X| <= T <= m-1-E-B.
```

All inequalities are equalities. Thus `E=B=0`, `|X|=T=m-1`, every
`x in X` has drop exactly one, and `rank(C_H)=m-1`.

For the finer path factorization, enumerate `X` in topological order.
Let `U[d,x]` be the signed sum of paths from `x` to `d in L` having no
other X vertex; let `K[y,x]` be the sum of paths from `x` to a later
`y in X` having no other X vertex; let `E_X[x,g]` be the sum of paths from
`g` to `x` having no X vertex except their endpoint `x`. A length-zero
path is included when `g=x`. Because the graph is acyclic, `K` is strictly
lower triangular. For the seven high gatherers, exact partition of paths
by their successive X vertices gives

```
C_H = U (I-K)^(-1) E_X.                                   (3)
```

These are sums over rational path weights; cancellations are allowed. The
rank equality and `|X|=m-1` imply that `U` has full column rank and `E_X`
has full row rank. In particular, each `x` has at least one actual
high-gatherer-to-`x` path with no other X vertex, and at least one actual
`x`-to-low-depositor path with no other X vertex. Their concatenation is
an H-support path. Antichain prevents any depositor before its endpoint;
if the high gatherer is itself `x`, it is a nondepositor. Zero-drop
propagation along the first segment implies `dim a_x>=8`. Propagation
along the second implies `b_x <= a_d`, where `dim a_d=7`. As `x` has
drop one, this forces

```
dim a_x=8,  dim b_x=7,  b_x=a_d.                         (4)
```

For every nonzero `U[d,x]`, an actual path establishes the same inclusion
`b_x<=a_d`; hence **each column of U is supported only on low depositors
with one and the same 7D chart**. Partition the coordinates of `Q^m` into
groups by identical depositor chart. Each U column lies in one group, so
`im(U)` is the direct sum of its intersections with these coordinate
groups. The quotient `Q^m/im(U)` consequently splits by the same groups.

For a low gatherer `g`, write its column in `C` as a through-X part and a
bypass part. Equation (3)'s same path partition places the through-X part
in `im(U)`. A bypass path avoids all X vertices. If `g` is not a
depositor, all vertices before the endpoint are zero-drop nondepositors,
so `a_g <= a_d`, and both have dimension seven; thus `a_g=a_d`. If `g`
is a depositor, the antichain allows only the zero-length bypass to itself,
which has the same property. If `g in X`, no bypass exists. Thus the
bypass vector is supported only on the group of depositors whose chart
equals `a_g`.

The two low-gatherer charts are distinct, so their bypass images in
`Q^m/im(U)` lie in distinct direct summands. Every high column lies in
`im(U)`. Projecting the unique gatherer relation into the quotient, and
using its two nonzero low coefficients, forces both bypass images to
vanish. Hence all nine columns of `C` lie in `im(U)`, contradicting
`rank(C)=m>|X|=m-1`. This completes the proof. ∎

## Exact controls and limits

Run

```
timeout 90s python3 -B check_three_low.py
```

The one-core control uses rational/integer arithmetic, checks the pinned
fixture SHA-256 and the two source Git blob IDs, and reruns the enumeration
of 8,766 admissible normal bases. It builds a 13-node P104 antichain
network with exactly nine gathers, two 7D gathers, eight depositors, three
7D depositors, three positive-drop nondepositors and `D=56`. Its depositor
normals are `67,137,266,289,97,127,52,82`; the three 7D depositors use
`67,137,266`. The checker verifies the complete exact transfer against the
pinned Gram matrix, all P104 odd/diagonal cells, nested charts, supports,
causal relay constraints and the depositor antichain. It independently
reconstructs the path factorization; the three low-depot rows have full
rank 3, whereas their seven high-gather columns have rank 2. The drop
count 3 is one higher than the hypothetical `D=55` budget.

A separate synthetic rational DAG checks (3) with a high gatherer equal to
an X node, multiple successive X nodes, and exact cancellation of paths.
An independent forward evaluator checks every odd transfer cell, detects
1,462 failing odd cells including 28 diagonals after deleting relay (6,7),
and passes again after that relay is restored.
The P104 example is a nonvacuity and equality control; neither control
exhaustively enumerates networks. A run used about 4 seconds on one core. The proof depends on P104 rigidity and is not
a Lean kernel replay. The companion [6D/7D theorem](TWO-LOW-6-7.md)
has its own exact 13-node `D=56` control. Remaining profiles with depot
dimension at most 6, depositor relay paths, other gatherer dimension
profiles, and legal words are untested.

The earlier, stricter two-7D-depositor paper proof is preserved in
[candidate_two_depots.md](next/candidate_two_depots.md), alongside its
[ancestor-cut derivation](next/README.md) and controls. Both were developed
in the original P104 network lane and independently reviewed there. The
current m-depositor argument extends their scope; the copied data and source
tables retain the pinned upstream attribution and [license](LICENSE-7852).
The included source tables have the Git blob hashes recorded in the checker.
The original lane fixture and Python controls are included for replay.

Two independent network-lane reviewers examined the path factorization,
cancellation, source-depositor cases and chart-group quotient and found no
gap. This is independent paper and code review, not a kernel proof.
