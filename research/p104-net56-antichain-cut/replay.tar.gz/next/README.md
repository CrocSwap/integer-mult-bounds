# A 9/8 ancestor-cone cut at the D=55 boundary

This is a paper proof with exact finite controls, not a Lean theorem. It
does **not** resolve NET-D56. On 2026-11-21 the live head of
[PR #7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) was
rechecked at `41beda1d6435760dc99e38bd7e65f36798aad212`, the same head as
the preceding lane-01 results. Source credit: DreamingOfClouds with Claude
Opus 5.5 for the pinned P104 package and its 8-row rigidity; campaign lane 02
for support-saturation normalization. The network and basis certificates
used below are either alongside this note or in the parent directory; the
portable packet also includes the precursor proof as `PARENT-RESULT.md`.

## Exact scope and result

Let a P104 `NetW` satisfy the word bridge's extra condition `b_j≤a_j` at
every node. Assume:

* exactly nine gatherers: two have `dim a=7` and seven have `dim a≥8`;
* exactly eight depositors; and
* no depositor reaches a *different* depositor in the directed support
  graph of H. We call this the **depositor antichain** condition. A
  depositor may still have an outgoing relay which does not reach another
  depositor.

For a depositor d, write `r_d=dim a_d`, `β_d=dim b_d`,
`δ_d=max(0,8−r_d)`, and let `A_d` be the set of non-depositing ancestors
of d. Let `drop_j=dim a_j−dim b_j`. The **ancestor-cone cut** is

```
sum_{j in A_d} drop_j >= δ_d.                    (1)
```

It follows that `D≥56` if the sets of **positive-drop** nondepositing
ancestors of distinct depositors with `r_d<8` are pairwise disjoint. In
particular, this holds if at most one depositor has `dim a<8`, or if every
non-depositor has zero drop. The proof applies to all possible depositor
bases, including all 8,766 bases admitted by the earlier finite screen;
it does not claim that those bases are all realizable as networks.

For a necessary condition without the disjointness assumption, set

```
S = sum_d max(0,8-r_d),   E = sum_d max(0,r_d-8),
B = #{d : beta_d=0},      m_j = #{d : r_d<8 and j reaches d}.
```

The eight-depositor rigidity theorem gives `β_d≤1`. Therefore

```
sum_{j nondep} m_j drop_j >= S,
D = 56 - S + E + B + sum_{j nondep} drop_j.
```

Any `D≤55` example satisfying the antichain hypothesis must consequently
obey

```
sum_{j nondep} (m_j-1) drop_j >= E+B+1.          (2)
```

In particular it must have **at least two low depositors** and at least
one positive-drop nondepositor which reaches two distinct low depositors.
The earlier level cuts already give D≥55 for the specified gatherer
dimensions; if D=55, they also force every `β_d=1` and exclude a
depositor with `r_d=9`. Thus every hypothetical D=55 antichain example has
eight distinct one-dimensional depositor masks among the 16 pinned masks,
with independent null vectors, and has a shared positive-drop ancestor.
No claim is made that these necessary conditions are sufficient.

A further rank argument closes the first shared-ancestor pattern: if
exactly two depositors have `dim a=7` and the other six have `dim a=8`,
then `D≥56` even when their cones overlap. The proof is in
[`candidate_two_depots.md`](candidate_two_depots.md), independently reviewed
by lane 02. Its key step partitions rational path sums at the one possible
charged nondepositor and uses the nonzero coefficients of both 7D
gatherers in their unique dependence. Hence any D=55 network within the
antichain scope must have **at least three low depositors or a depositor
with `dim a≤6`**.

## Proof of the cut

Let `N=(I−H)⁻¹`. The P104 clique and the eight depositors force
`rank M=rank G_dep=rank (NF)_dep=8`. In particular every effective input row
`(NF)_d` is nonzero. Since `M=(GN)_gat F_gat`, the effective transfer
columns of the nine gatherers have rank 8 and a unique dependence. By the
8-row rigidity proof in the parent note, both 7-dimensional gatherers lie
in the support of that dependence, and their input charts satisfy

```
dim(a_low1 + a_low2) >= 8.                      (3)
```

As the eight columns of `G_dep` are independent, the same dependence holds
among the nine columns `N[dep,g]`. Fix a low depositor d. There are two
cases.

1. If `N[d,g]≠0` for some high gatherer, a nonzero support path runs from
   g to d. For a path `k_0,...,k_t`, the relay inclusions give
   `dim b_{k_i}≤dim a_{k_{i+1}}`, so the path's drop sum is at least
   `dim a_{k_0}−dim b_d≥8−β_d`.
2. Otherwise all high coordinates `N[d,g]` vanish. Since `(NF)_d` is
   nonzero, a low coordinate is nonzero; the unique dependence has nonzero
   coefficients at *both* low gatherers, so both coordinates are nonzero.
   Pick support paths from them to d and combine their prefixes at their
   first common vertex into a directed in-tree rooted at d. For any such
   in-tree, nested charts and `b_child≤a_parent` give

   ```
   sum_{j in tree} drop_j
       >= dim(sum of source a-charts) − dim b_d.
   ```

   To see this, start at d and add leaves in reverse tree order. Adding a
   child increases the span by at most `dim a_child−dim b_child`, because
   its `b` already lies in its parent's `a`. Equation (3) gives a tree
   invoice of at least `8−β_d`.

By the depositor-antichain hypothesis, every vertex of either chosen
structure other than d is a nondepositor ancestor of d. Subtract d's own
drop `r_d−β_d` to obtain (1). The disjoint-cone claim follows by summing
(1) for the low depositors and adding the eight depositor drops. Equation
(2) follows by counting how often each nondepositor's drop is included in
the left-hand sides of (1). This is a paper argument using the pinned
rigidity theorem; it has not been formalized in Lean.

## Support saturation and sharp controls

Lane 02's sequential support-saturation operation preserves `F,G,H`, the
graph and all transfer entries, never increases drop, and keeps every
zero-drop nondepositor at zero. Thus it preserves the graph antichain and
the zero-drop property, but may shrink gatherer charts and need not preserve
the exact 7/8 gatherer-dimension split. The ancestor-cone argument is
proved directly, without normalizing first; it permits positive-drop
intermediates when their charged ancestor cones do not overlap.

`check_cut.py` independently recomputes the chart saturation conditions
and replays all source and basis checks. It verifies these exact P104
controls, with arbitrary-precision rational arithmetic:

* The parent lane's saturated two-low 9/8 equality network has antichain
  depositors, all of dimension 8, zero nondepositor drop, and D=56.
* Move one unit of drop upstream: insert a nondepositor with `(dim a,
  dim b)=(8,7)` between the two low gatherers and their old depositor, and
  replace that depositor's `a` by the 7-dimensional shared chart. The
  depot has `(dim a,dim b)=(7,1)`, its charged ancestor invoice is 1,
  and the total remains D=56. The complete transfer is unchanged and the
  resulting network is still support-saturated. This shows the local
  ancestor invoice can be sharp, and that requiring every nondepositor to
  have zero drop is not necessary for the theorem.
* Moving a second unit upstream produces a saturated P104 network with
  **two 7D depositors**, six 8D depositors, and D=56. Their positive-drop
  ancestor cones are disjoint, each paying one unit; the full 104-by-104
  rational transfer is still unchanged. This is a sharp non-vacuity
  control for the two-depot theorem, not an example with shared cones.
* Two tempting edits that would each remove one unit from that example are
  rejected. Expanding the intermediate's `b` to dimension 8 violates its
  outgoing relay inclusion into the 7-dimensional depot; expanding the
  depot's `b` beyond dimension 1 violates an actual nonzero G-support label.

Run from this directory, with `check_separator.py`, `check_hyperplanes.py`
and `p104_roots.json` either here or in the parent lane's directory:

```
timeout 80s python3 check_cut.py
```

The final completed run took 2.09 seconds wall time and 2.08 seconds CPU
time on one core, below the assigned 90-second bound, and ended
`ALL ANCESTOR-CUT CONTROLS PASSED`; see `replay.log`. That source-attached
run checked both pinned Lean source files by Git blob ID. A portable run
without those files checks the fixture digest but does not independently
recheck its provenance; its output is `clean-replay.log`. The
calculation enumerates 8,766 admissible normal bases only for the
independent basis restriction; it does not enumerate network graphs,
rational coefficients, or the counterexample conditions in (2).

Lane 02 independently reviewed the ancestor cut, overlap bookkeeping and
two-depot rank argument, and replayed the earlier version of the exact
controls. This is a paper/code review, not a Lean or legal-word replay.

## Open cases

* Depositors with relay paths to one another are not covered by (1): such
  paths can put another depositor's paid drop inside d's ancestor cone.
* Overlapping charged nondepositor ancestor cones may pay several local
  deficits with shared drop. The rank proof excludes two 7D depositors,
  but a candidate with three or more low depositors or a depot of
  dimension at most 6 remains open. Equation (2) does not produce a legal
  example with D=55.
* The exact controls are `NetW` instances, not legal-word realizations.
  No new Wall56, hosted-rise, aggregate or κ claim is made.
