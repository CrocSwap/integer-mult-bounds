# Candidate shared-ancestor closure: exactly two 7D depositor charts

**Review status: paper argument independently reviewed by lane 02; not
Lean-checked.** The review covered source/depositor overlap, cancellation
in the through-x path partition, and the two chart cases.
The pinned sources, nested-network model, exactly two 7D gathers and seven
other gathers of dimension at least 8, eight depositors, depositor-antichain
hypothesis, unique gather-column relation and ancestor cut are as in
`README.md`. This note does not cover arbitrary depositor dimensions.

## Claim

Under these hypotheses, if exactly two depositors have `dim a=7` and the
other six have `dim a=8`, then `D≥56`.

## Argument

The established level cuts give D≥55. Suppose D=55. Every depositor has
`dim b≤1`; a depositor with `b=0` would force D≥56 by the level-1 argument
in the parent note. Thus all eight have `dim b=1`. The eight depositor drops
sum to `2·6+6·7=54`, leaving exactly one unit for all nondepositors. There
is therefore exactly one positive-drop nondepositor `x`, of drop one.
The ancestor cut gives an invoice of at least 1 upstream of each 7D
depositor, so `x` is a support-graph ancestor of both.

Write the two 7D depositors as d,e with charts A,B. Let `N=(I−H)⁻¹` and
restrict its rows to d,e and columns to the nine gatherers. This 2×9
matrix has row rank 2 because the full eight-depositor-by-nine-gatherer
matrix has row rank 8. Define

```
t = (N[d,x], N[e,x])^T.
```

For every gathering node g, partition its DAG path sum according to
whether it visits x. Exact multiplication of the two path sums before and
after x gives

```
(N[d,g], N[e,g])^T = t N[x,g] + u_g,           (4)
```

where `u_g` is the two-row contribution from paths avoiding x. This holds
with arbitrary rational coefficients and cancellations, including when g=x
(`u_g=0`).

All nondepositors except x have zero drop. On an x-avoiding path from a
gatherer g to d or e, nesting and relay inclusion make `a_g` a subspace of
the destination's chart. If g is a depositor, antichain permits the path
only when g is its destination, and the same inclusion is equality. Thus
every high gatherer has `u_g=0`; a 7D gatherer can have a nonzero
x-avoiding d coordinate only if its `a` equals A, and can have a nonzero
x-avoiding e coordinate only if its `a` equals B.

**If A and B are distinct**, their intersection has dimension at most 6.
Choose support paths from x to d and e. Their internal nodes are
nondepositors, hence zero-drop, so `b_x≤A∩B` and `dim b_x≤6`. Since x has
drop 1, `dim a_x≤7`. No high gatherer can reach x: such a path would have
to enter x through zero-drop nondepositors, and an earlier depositor on it
would violate the antichain. Consequently `N[x,g]=0` for all seven high
gatherers, so their restrictions in (4) vanish. The unique gather-column
dependence has nonzero coefficients at both low gatherers, so their two
2-vectors are proportional. The 2×9 matrix has rank at most 1, a
contradiction.

**If A=B**, their 7D chart equals at most one of the two low gatherer
charts, since those two charts have span dimension at least 8. Every high
gatherer and every other low gatherer has `u_g=0`, so (4) puts its two-row
column in the line `span(t)`. If there is one exceptional low gatherer,
its coefficient in the unique dependence is nonzero; all other columns
lie in `span(t)`, so the dependence forces that exceptional column into
`span(t)` as well. Again the 2×9 matrix has rank at most 1, a contradiction.
This includes `t=0`.

Both cases rule out D=55. Therefore D≥56. ∎

Under the broader antichain hypotheses, an alleged D=55 network cannot
have no low depositor (cost already ≥56), one low depositor (ancestor cut),
or exactly two low depositors both of dimension 7 (the candidate claim).
It must therefore have **at least three low depositors or a depositor of
dimension at most 6**. Depositor-to-depositor paths remain outside scope.

## Bounded controls

`python3 check_path_control.py` verifies (4) on an exact rational DAG with
cancelling paths, including the case g=x. It also checks the final 2-row
rank implications over F5 and has a negative control showing why the
nonzero low coefficient is required. This finite-field calculation is a
sanity check, not a P104 instance or a proof of the rational theorem; the
argument above is the claimed proof. The control used 0.08 CPU seconds on
Python 3.12.3.
