#!/usr/bin/env python3
"""Exact controls for the through-x path partition and 2-row rank step.

The finite-field loop is a sanity control, not a proof over Q or a P104
network. The accompanying candidate note contains the algebraic argument.
"""
from fractions import Fraction as Q
from itertools import product


def inv_dag(H):
    n = len(H)
    N = [[Q(i == j) for j in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            N[i][j] = Q(i == j) + sum(H[i][k] * N[k][j] for k in range(i))
    return N


n, x = 6, 2
H = [[Q(0) for _ in range(n)] for _ in range(n)]
H[2][0] = Q(1)
H[2][1] = Q(2)
H[4][2] = Q(1)
H[4][0] = Q(-1)  # cancels the through-x route from source 0 to output 4
H[5][2] = Q(3, 2)
H[5][1] = Q(-1)
H[3][0] = Q(4)
H[5][3] = Q(1, 2)
N = inv_dag(H)
H0 = [[Q(0) if i == x or j == x else H[i][j] for j in range(n)] for i in range(n)]
N0 = inv_dag(H0)
for d in (4, 5):
    for g in range(n):
        avoid = Q(0) if g == x else N0[d][g]
        assert N[d][g] == N[d][x] * N[x][g] + avoid
assert N[4][0] == 0 and N[4][x] * N[x][0] == 1 and N0[4][0] == -1
print("DAG through-x decomposition: exact with cancellation and source=x")


p = 5
vectors = list(product(range(p), repeat=2))
def det(u, v):
    return (u[0]*v[1] - u[1]*v[0]) % p
def add(*vs):
    return tuple(sum(v[i] for v in vs) % p for i in range(2))
def mul(c, v):
    return tuple((c * x) % p for x in v)

# Equal-depot-chart case: all other columns and one low column lie in span t;
# the other low column has a nonzero coefficient in the unique relation.
equal_checked = 0
for t, exceptional, alpha, mu in product(vectors, vectors, range(1, p), range(p)):
    if add(mul(alpha, exceptional), mul(mu, t)) == (0, 0):
        assert det(t, exceptional) == 0
        equal_checked += 1

# Distinct-depot-chart case: high columns vanish on the two rows; the two
# low coefficients are nonzero and their relation forces proportionality.
distinct_checked = 0
for a, b, alpha, beta in product(vectors, vectors, range(1, p), range(1, p)):
    if add(mul(alpha, a), mul(beta, b)) == (0, 0):
        assert det(a, b) == 0
        distinct_checked += 1

# A zero coefficient would not force the exceptional column into span(t).
assert det((1, 0), (0, 1)) != 0 and add(mul(0, (0, 1)), mul(0, (1, 0))) == (0, 0)
print(f"GF(5) algebra sanity: equal-chart {equal_checked}, distinct-chart {distinct_checked}; "
      "zero-coefficient control rejected")
print("ALL PATH-PARTITION CONTROLS PASSED")
