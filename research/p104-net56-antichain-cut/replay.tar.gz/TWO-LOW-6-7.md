# The 6D and 7D low-depositor case

**Paper argument independently reviewed by two network lanes; not Lean-checked.** P104,
nested charts, exactly two 7D and seven >=8D gatherers, exactly eight
depositors, antichain and notation are as in [README.md](README.md). This does not
claim the general dim<=6 case.

## Scoped theorem

If exactly two depositors have dimension below 8, with dimensions 6 and 7
respectively, then `D>=56`.

## Argument

Suppose `D<=55`. Write `d6,d7` for the low depositors with charts `A6,A7`,
and `X` for the positive-drop nondepositors. The ancestor cut of
[ancestor-cut note](next/README.md) gives nondepositor drop `T>=2` for `d6`. Accounting gives
`D=53+E+B+T`, with `E,B>=0` as in [README.md](README.md). Hence `T=2`, `E=B=0`, and
all depositor output charts are one-dimensional.

Let `C=N[{d6,d7},gat]`; its two rows are independent, and its seven
high-gather columns have rank at least one because the unique gatherer
relation has nonzero coefficients on both low gathers. As in [README.md](README.md),
every high-to-low path meets `X`. Factor paths at their last X node to
obtain an `U` with `|X|` columns through which all high columns factor.
A low-gatherer bypass of X cannot reach `d6`, and it can reach `d7` only
if its 7D chart equals `A7`. The low gatherer charts are distinct. Thus
at most one bypass can be nonzero, and the unique relation forces that
bypass into `im U`. All of `C` lies in `im U`, so `rank U=2` and
`|X|>=2`. Since `T=2`, `X` consists of exactly two nodes, each with drop
one, and `U` has rank 2.

Choose an actual high-to-low path with nonzero aggregate high transfer,
and call its first X vertex `y`. The segment before `y` contains no other
X and no depositor, so `dim a_y>=8`. A depositor on that segment would
reach the eventual different low depot, violating antichain; the eventual
depot itself cannot occur there without a directed cycle. Since `U` has rank 2, column `y`
is nonzero: `y` has an X-free path to one of the low depositors, giving
`b_y<=A6` or `b_y<=A7`. The drop is one, and the first possibility is
impossible. Therefore

```
a_y has dimension 8, b_y=A7, U[d6,y]=0, U[d7,y]!=0.
```

Let `x` be the other positive-drop node. Full rank of `U` forces
`U[d6,x]!=0`, so `b_x<=A6` and `dim a_x<=7`.

Put `t=N[{d6,d7},y]`. Every high-gather-to-low path avoiding `y` must
meet `x` first; zero-drop propagation would give `dim a_x>=8`, impossible.
Thus all seven high columns lie in `span(t)`. Their rank is at least one,
so `t!=0`. As usual, for either low gatherer, split its column into a
through-`y` part in `span(t)` and a `y`-avoiding part. Such a path which
visits `x` can start only at a low gatherer with `a_g<=a_x`; since
`dim a_g=7` and `dim a_x<=7`, this can happen for at most one of the
two low gatherers. A `y`-avoiding path which also avoids `x` can only end
at `d7`, and only from a gatherer with `a_g=A7`.

* If `a_x=A7`, the same single low gatherer is the only one whose
  `y`-avoiding contribution can be nonzero. The other low gather column
  and all high columns lie in `span(t)`; the nonzero coefficient of the
  exceptional low gatherer in the unique relation forces its column into
  that line too, contradicting `rank C=2`.
* If `a_x!=A7`, `y` cannot reach `x`: such a path has no other positive
  node and would force `b_y=A7<=a_x`, hence equality in dimension 7.
  Any intervening depositor on such a path would reach `d6` through `x`,
  violating antichain (or create a cycle if it were `d6`). Likewise, a
  path `y→d6` avoiding `x` would force `A7<=A6`, impossible.
  Thus `t` is nonzero only at `d7` and spans that coordinate line. Every
  `y`-avoiding path that avoids `x` lands in this line; at most one low
  gatherer can have any other `y`-avoiding contribution. The gatherer
  relation again forces both low columns into `span(t)`, contradiction.

This concludes the 6/7 subcase paper proof. The exact 13-node control in
`check_three_low.py` has depot dimensions 6,7, three upstream drops and
`D=56`; it verifies all odd/diagonal transfers, but is not a D=55 search.
The rest of the dim<=6 and depositor-relay cases remain open.

Both independent network-lane reviewers checked path cancellation, source
depositors, first/last-X factorization and the two chart cases, and found
no gap. The argument remains a paper proof, not a Lean kernel replay.
