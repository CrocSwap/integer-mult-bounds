#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Find an actual pair of pinned paid maps without a common axis permutation basis."""
from argparse import ArgumentParser
from fractions import Fraction as F
from functools import lru_cache
import gzip
from hashlib import sha256
import json
from math import lcm
from pathlib import Path

FILE = Path(__file__).resolve().parent/'source/WORD.json.gz'
raw = FILE.read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
word = json.loads(gzip.decompress(raw))
frames = {int(i):v for i,v in word['frames'].items()}


def product(a,b):
    return [[sum(x*y for x,y in zip(row,col,strict=True)) for col in zip(*b)] for row in a]


def inverse(a):
    dim=len(a)
    r=[list(row)+[F(i==j) for j in range(dim)] for i,row in enumerate(a)]
    for i in range(dim):
        pivot=next(j for j in range(i,dim) if r[j][i])
        r[i],r[pivot]=r[pivot],r[i]
        div=r[i][i]
        r[i]=[v/div for v in r[i]]
        for j in range(dim):
            if i==j:
                continue
            v=r[j][i]
            r[j]=[a-v*b for a,b in zip(r[j],r[i],strict=True)]
    return [row[dim:] for row in r]


@lru_cache(None)
def projector(chart):
    rows=[[F(v) for v in row] for row in frames[chart]['B']]
    if not rows:
        return [[F(0)]*8 for _ in range(8)]
    transpose=list(zip(*rows))
    mult=product(product(transpose,inverse(product(rows,transpose))),rows)
    assert product(mult,mult)==mult
    assert sum(mult[i][i] for i in range(8))==frames[chart]['dim']
    return mult


def moves(grade):
    reps={}
    for clock,(op,address,*args) in enumerate(word['program']):
        if op=='MOVE':
            a,b=args
            if abs(frames[a]['dim']-frames[b]['dim'])==grade:
                reps.setdefault(tuple(sorted((a,b))),(clock,address,a,b))
    return reps.values()


def difference(move):
    a,b=sorted(move[2:],key=lambda i:frames[i]['dim'])
    x,y=projector(a),projector(b)
    z=[[y[i][j]-x[i][j] for j in range(8)] for i in range(8)]
    assert product(z,z)==z
    return z


def reflection(move):
    p=difference(move)
    result=[[F(i==j)-2*p[i][j] for j in range(8)] for i in range(8)]
    scale=lcm(*(v.denominator for row in result for v in row))
    return scale,[[int(scale*v) for v in row] for row in result]


def product_control(p,q):
    pd,pm=p
    qd,qm=q
    denominator=pd*qd
    a=product(pm,qm)
    power=a
    traces=[]
    for exponent in range(1,49):
        scale=denominator**exponent
        trace=8+F(sum(power[i][i] for i in range(8)),scale)
        traces.append(trace)
        if trace.denominator!=1:
            return dict(nonintegral_trace_power=exponent,trace=str(trace))
        if all(power[i][j]==(scale if i==j else 0) for i in range(8) for j in range(8)):
            cycles={}
            for d in range(1,exponent+1):
                if exponent%d!=0:
                    continue
                cycles[d]=(traces[d-1]-sum(e*c for e,c in cycles.items() if d%e==0))/d
                if cycles[d]<0 or cycles[d].denominator!=1:
                    return dict(product_order=exponent,invalid_cycle_length=d,forced_cycle_count=str(cycles[d]),
                                traces=[str(v) for v in traces])
            return None
        power=product(power,a)
    return None


def two_chunk_move(move):
    p=difference(move)
    idle=[[F(i==j)-p[i][j] for j in range(8)] for i in range(8)]
    return [u+v for u,v in zip(idle,p,strict=True)] + [u+v for u,v in zip(p,idle,strict=True)]


def search():
    firsts=[(m,reflection(m)) for m in list(moves(2))[:50]]
    seconds=[(m,reflection(m)) for m in list(moves(3))[:50]]
    tested=0
    for first,p in firsts:
        for second,q in seconds:
            tested+=1
            witness=product_control(p,q)
            if witness:
                return first,second,tested,witness
    raise AssertionError('pinned witness missing')


def main():
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--emit',action='store_true')
    args=ap.parse_args()
    first,second,tested,witness=search()
    assert (first,second) == ((2212,1307,0,113),(1238,1028,62,313))
    a,b=two_chunk_move(first),two_chunk_move(second)
    identity=[[F(i==j) for j in range(16)] for i in range(16)]
    assert product(a,a)==product(b,b)==identity
    step=product(a,b)
    power=identity
    traces=[]
    for _ in range(4):
        power=product(power,step)
        traces.append(sum(power[i][i] for i in range(16)))
    assert power==identity and traces==[10,8,10,16]
    assert witness['forced_cycle_count']=='-1'
    # Additional spectator axes add the same number to both traces. The
    # impossible two-cycle count is therefore unchanged at ambient 134.
    result=dict(grade2_move=first,grade3_move=second,pairs_tested=tested, **witness,
                columns=['clock','owned_field','source_chart','destination_chart'],
                lifted_traces_on_268_axes=[int(v+252) for v in traces],
                scope='Two actual old maps escape any common coordinate permutation basis; no paid profile realization asserted.')
    text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if args.emit:
        print(text,end='')
    else:
        assert Path(__file__).with_name('GEOMETRY-BRIDGE.json').read_text()==text
        print('PASS: exact two-chunk traces force negative coordinate-permutation cycle count')


if __name__=='__main__':
    main()
