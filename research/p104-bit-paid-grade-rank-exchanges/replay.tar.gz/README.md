# Same-count BIT grade exchanges that pass abstract rank and price

Replacing `(1,5,6)` by `(2,2,8)` preserves the number of paid fields and the sum of grades. In the unrestricted neutral linear model it has enough rank to reproduce the old changes for every integer address width `m≥2`. On the exact published signed profiles, the nominal saving is `0.0023360563483981355…` per use at `κ=0.00388`. Twelve uses would clear the incumbent negative BIT margin. All 36 uses would yield a formal margin of `+0.056386668352115289…`, with the separate rational margin still `+0.138974522334252709…`. The proof establishes a rank factorization and a directed price threshold. It does not supply legal native routes or a new κ bound.

## Rank model and constructive control

For a grade-g two-chunk interchange `P_g` on one N-site field, exactly `Nm^-g` addresses are fixed. Each nontrivial two-cycle contributes one rank to `P_g−I`, so the rank is `N(1−m^-g)/2`. In the neutral model where the old blocked operation is preserved and arbitrary address-dependent linear wiring is free, `A=LKR` is possible for a target difference A through the replacement difference K exactly when `rank(A)≤rank(K)`. Rank gives necessity. For sufficiency choose a basis of the old image, independent image vectors of K for those basis vectors, preimages under K, and linear extensions. For coordinate-aligned block swaps this can be implemented directly by assigning a distinct replacement two-cycle to each old two-cycle, writing its two original coordinates there and copying the resulting parity back to both old coordinates.

For `(1,5,6)` to `(2,2,8)`, write `x=1/m`. The exact rank advantage divided by `N/2` is `x−2x²+x⁵+x⁶−x⁸`, positive for `0<x≤1/2`. The pure rank realization on three 65,536-site binary address arrays has old rank 80,384 and new rank 81,792. The verifier checks all 196,608 input basis vectors in the forward and literal adjoint maps, with a deliberately omitted encoding column as a failure control. The toy address array illustrates the algebra. The all-width formula establishes the rank claim on arbitrary common dimensions with enough axes for both chunks.

## Complete finite grade census and signed price

Use sorted old grades 1–6 and sorted new grades 1–8. Compare two, three and four paid fields with equal grade sums and unequal grade lists. This gives 41, 357 and 1,932 ordered old/new multiset pairs. For each pair compute `f(m) = sum(m^-old)−sum(m^-new)`. If the first nonzero Laurent coefficient is c, all later terms divided by its power are bounded by `sum(abs(other coefficients))/m`. Beyond that integer threshold the sign is the sign of c. At all smaller integer widths the verifier checks signs as exact fractions. It then enforces the directed price of the full 36 calls at the requested trial point. Zero pairs, three triples and 32 quadruples pass the rank-and-price conditions. Each passing portfolio records the smallest number of uses that would cross the incumbent deficit if all other charges and targets were preserved.

| Old grades | New grades | Minimum uses | Formal 36-use BIT margin |
| --- | --- | ---: | ---: |
| `1,5,6` | `2,2,8` | 12 | `+0.05638666835211529` |
| `2,6,6` | `3,3,8` | 22 | `+0.01911877990183870` |
| `1,5,5` | `2,2,7` | 25 | `+0.01345379697137370` |

The intervals are recomputed from the complete published #7830 36-call BIT and 48-call rational bins at their exact source hashes. They include the stated grade changes alone. Cross-field routing, stock, initialization, retirement and compiler charges for an actual implementation remain open. The native atlas has unique rank-zero chart 0 and unique rank-eight chart 1, so a native grade-eight call can only connect those two charts. The grade-seven triple avoids that unique pair.

## Why pointwise mixing alone cannot implement these changes

Suppose all paid primitives are distinct linear address permutations on a full finite-field address space, along with the identity. Suppose the field size is larger than the number of pairs of distinct maps. There is an address at which all maps have different images. Each pair agrees on a proper linear subspace, whose size is at most a `1/q` fraction of the domain, and the union of the coincidence subspaces cannot cover the domain. Acting on the unit vector at the separating address proves independence of the corresponding permutation matrices over the binary payload field. Subtracting the identity gives independent nonidentity difference matrices. For the aligned binary block swaps in the finite control, the address with all left digits 0 and all right digits 1 already separates all 256 subsets of eight axes, including identity.

If preprocessing and readout mix fields with scalar matrices constant across address, their neutral difference map is a sum of each paid difference operator tensored with a rank-one field coefficient matrix. Comparing the independent operator coefficients forces every distinct required old permutation to occur in the new menu, with at least its original number of independent copies. Thus this constant-mixing contract cannot realize the grade changes above. The checked abstract factorization explicitly uses address-dependent maps. A physical successor needs a stock-preserving way to pay for those maps, change the blocked baseline, or find a different realization outside the contract. This scope differs from earlier two-contact fusion and fixed chart-basis screens.

## Stronger obstruction for polynomial mixing of aligned address swaps

Let G be the group generated by the independent two-chunk coordinate swaps on r aligned axes. The action of its group algebra over the binary payload field is faithful on a full address array: choose unequal paired digits on every axis, giving an orbit with all `2^r` distinct states. In that algebra put `e_i=P_i−I` for axis i. These generators identify the algebra with the commutative polynomial ring with `e_i²=0`; both have the `2^r` monomials indexed by subsets. The ideal J that they generate has first quotient `J/J²` with independent `e_i` coordinates. The difference from identity of the swap on an axis subset S has linear term its incidence vector `s` in this quotient.

Allow both mixing matrices to have any polynomial entries in these already aligned address swaps. Assume the old blocked baseline is kept, there are equally many old and replacement paid lanes, and each old swap is nonempty. Reducing a proposed factorization modulo `J²` and applying any binary linear functional `l` on `J/J²` gives

```
diag(l(s_old)) = L_0 diag(l(s_new)) R_0,
```

where `L_0,R_0` are the constant parts of the two mixing matrices, independent of `l`. For every old lane some `l` makes its diagonal entry one. The joint images of the left-hand matrices therefore span the whole old output space, and their kernels have trivial intersection. This forces both square constant matrices to be invertible. Hence for every `l`, the number of old masks on which `l` is one equals the corresponding new number. The character sums `sum_s (−1)^(l(s))` agree for every `l`, so finite Fourier inversion gives equality of the two multisets of axis masks. In particular their grade multisets must agree. For all three priced triples a single functional, the sum of all axis coefficients, already separates the odd-grade counts.

Even allowing all these aligned address-shift polynomials for free cannot realize a same-count grade exchange. The unrestricted rank construction is outside this result because its selectors depend on the address and do not belong to the swap group algebra. The argument does not cover different axis layouts on different fields, noncommuting physical maps, changed blocked baselines, or extraction that is not a polynomial in the common aligned swaps. These are explicit conditions a successor can change.

## Two tests beyond commuting maps

**Coordinate permutations on a common basis.** Allow arbitrary finite sums of coordinate permutations, including noncommuting ones, in the mixing matrices. Take a residue alphabet larger than the number M of coordinate axes. An address with all distinct digits has a free orbit for the permutation group, so the address action of the group algebra is faithful. A whole-field identity therefore gives the corresponding identity in that algebra. Apply its representation on unordered pairs of axes. A grade-g swap fixes exactly `choose(M−2g,2)+g` such pairs, so the rank of the difference from identity is `g(M−1−g)`. A proposed replacement must have at least the total required rank in this representation. For equal grade sums this says `sum(new grades squared) ≤ sum(old grades squared)`. The actual census shows the strict reverse inequality for **all 35** abstractly profitable triples and quadruples. Thus even free noncommuting coordinate-permutation mixing on a common axis basis does not realize these portfolios.

**General rational address-linear maps.** Allow any fixed finite sums of invertible rational linear address maps. Use the all-width contract with sufficiently large good primes. After clearing denominators and excluding the finite set of primes that identify any two maps in the expanded identity, pairwise coincidence loci are proper linear spaces. A large enough prime leaves a separating address. A physical equality on the full address domain then implies its finite-support rational group-algebra equality. Map each rational matrix to its determinant sign and take the resulting group-algebra map to `F₂[e]/(e²)`. Each nonidentity old grade-g defect maps to `e` if g is odd and to zero otherwise. Comparison of the coefficient of `e` shows that the number of odd grades cannot decrease, even with noncommuting rational address maps and singular constant mixing matrices. This removes two of the three triples, including `(1,5,6)→(2,2,8)`, and 16 of the 32 quadruples.

The remaining triple is `(2,6,6)→(3,3,8)`. Four quadruples also satisfy this determinant-sign test without using the unique grade-eight contact. The best of those four is **`(1,4,4,5)→(2,2,3,7)`**, with a 14-use threshold and formal 36-use BIT margin **`+0.04842360493697922…`**. The checker constructs its unrestricted difference map and tests every forward and adjoint basis column on four 65,536-site fields. It loses eight ranks in the unordered-axis-pair representation, so a legal successor needs genuinely non-coordinate rational geometry, address-dependent extraction, or a changed neutral baseline. Passing determinant parity alone gives no rational factorization or physical caller.

## A native source witness outside a common coordinate basis

The pinned word contains a grade-two MOVE `0→113` at clock 2212, owned field 1307, and a grade-three MOVE `62→313` at clock 1238, owned field 1028. Compute the rational orthogonal row-space projector of each chart directly as `Bᵀ(BBᵀ)⁻¹B`. The differences between the two nested charts in each MOVE are projectors of ranks two and three. We check their actual two-chunk interchange matrices from the source data. Each map is involutive. Let A be their product in the checked order. Its four successive traces on 16 address axes are **10, 8, 10, 16**, and its fourth power is identity. For a coordinate permutation the difference `tr(A²)−tr(A)` would equal twice the number of two-cycles. Here it is **−2**. Thus these actual paid maps cannot be simultaneously conjugated to coordinate permutations. Adding the fixed spectator axes to ambient 134 per chunk adds the same amount to both traces and leaves the contradiction intact.

This supplies a concrete geometric feature of grades two and three in the source that is outside the preceding coordinate-permutation theorem. It does not combine the four contacts or preserve their full paid and productive observations. The `geometry_bridge.py` proof finds the witness after 32 pairs in a fixed roster of the first 50 different grade-two and grade-three unordered chart contacts, then rechecks the actual 16×16 interchange matrices by direct rational multiplication. It compares the regenerated receipt and preserves the exact original MOVE labels and clocks.

## Sources and replay

Native word from #7786 `89a67c404226d51028e135de2b9169e9020d57af` with gzip SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`. Signed source profiles from [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830). Main context `e54523517d0f03e58352e647c403a5af3e525a57`. Scoped companion calculations preserve [#7863](https://github.com/CrocSwap/integer-mult-bounds/pull/7863) and [#7973](https://github.com/CrocSwap/integer-mult-bounds/pull/7973) as the comparable published lower bound and replay.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify_profiles.py
python3 -I -B geometry_bridge.py
```
