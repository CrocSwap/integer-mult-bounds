#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Enumerate rank-compatible grade changes and check one abstract realization."""
from argparse import ArgumentParser
from collections import Counter
from decimal import Context, Decimal as D, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
from functools import lru_cache
import gzip
from hashlib import sha256
from itertools import combinations_with_replacement, permutations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TARGET = D('0.00388')
LO = Context(prec=90, rounding=ROUND_FLOOR)
HI = Context(prec=90, rounding=ROUND_CEILING)
NEAR = Context(prec=90)
MAX_WIDTH = 8


def read_source(name, digest):
    raw = (ROOT/'source'/name).read_bytes()
    assert sha256(raw).hexdigest() == digest, name
    return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)


@lru_cache(None)
def power(grade):
    if grade == 1:
        return D(1), D(1)
    log = NEAR.ln(D(grade))
    exponent = D(1)-TARGET
    lower = NEAR.exp(LO.multiply(exponent, NEAR.next_minus(log)))
    upper = NEAR.exp(HI.multiply(exponent, NEAR.next_plus(log)))
    return NEAR.next_minus(lower), NEAR.next_plus(upper)


def change(plus, minus):
    lo, hi = D(0), D(0)
    for grade, count in plus.items():
        low, high = power(grade)
        lo, hi = LO.add(lo, LO.multiply(low, count)), HI.add(hi, HI.multiply(high, count))
    for grade, count in minus.items():
        low, high = power(grade)
        lo, hi = LO.subtract(lo, HI.multiply(high, count)), HI.subtract(hi, LO.multiply(low, count))
    return lo, hi


def rank_comparison(old, new):
    weights = Counter(old)
    weights.subtract(new)
    weights = {g:c for g,c in weights.items() if c}
    if not weights:
        return True, None
    first = min(weights)
    # All terms after the leading one are bounded in modulus by L/m.
    # Above this threshold the sign is that of the first coefficient.
    threshold = max(2, 1+sum(abs(c) for g,c in weights.items() if g != first))
    sign = weights[first] > 0
    finite = [sum(Fraction(c,m**g) for g,c in weights.items()) for m in range(2,threshold)]
    return sign and all(x >= 0 for x in finite), threshold


def enumerate_pairs(size, base):
    old_groups = list(combinations_with_replacement(range(1,7),size))
    new_groups = list(combinations_with_replacement(range(1,9),size))
    eligible, hits = 0, []
    for a in old_groups:
        for b in new_groups:
            if sum(a) != sum(b) or a == b:
                continue
            eligible += 1
            s, t = change(Counter(a),Counter(b))
            lo = LO.add(base[0], LO.multiply(s,D(36)))
            hi = HI.add(base[1], HI.multiply(t,D(36)))
            if hi < 0:
                continue
            assert lo > 0, 'price sign unresolved'
            rank_ok, threshold = rank_comparison(a,b)
            if not rank_ok:
                continue
            required = next(n for n in range(1,37) if LO.add(base[0],LO.multiply(s,D(n))) > 0)
            assert required == 1 or HI.add(base[1],HI.multiply(t,D(required-1))) < 0
            hits.append(dict(old=a,new=b,minimum_calls=required,
                             saving_per_call=[str(s),str(t)], formal_36_call_margin=[str(lo),str(hi)],
                             exact_rank_tail_from_width=threshold,
                             odd_grade_counts=[sum(g%2 for g in a),sum(g%2 for g in b)],
                             axis_pair_rank_deficit=sum(g*g for g in b)-sum(g*g for g in a),
                             effective_rank_gain_at_binary_width=str(sum(Fraction(1,2**g) for g in a)-sum(Fraction(1,2**g) for g in b)),
                             any_single_channel_matching=any(all(x<=y for x,y in zip(a,p,strict=True)) for p in permutations(b))))
    return eligible, sorted(hits, key=lambda p:D(p['saving_per_call'][0]),reverse=True)


def pair_coordinates(grades):
    """The independent nontrivial orbits of grade-g binary block swaps."""
    dim = 1 << (2*MAX_WIDTH)
    for channel, grade in enumerate(grades):
        mask = (1 << grade)-1
        for address in range(dim):
            difference = (address ^ (address>>MAX_WIDTH)) & mask
            image = address ^ difference ^ (difference << MAX_WIDTH)
            reverse_difference = (image ^ (image>>MAX_WIDTH)) & mask
            assert image ^ reverse_difference ^ (reverse_difference << MAX_WIDTH) == address
            if address < image:
                yield channel*dim+address, channel*dim+image


def abstract_match(old, new):
    old_pairs = list(pair_coordinates(old))
    new_pairs = list(pair_coordinates(new))
    assert len(new_pairs) >= len(old_pairs)
    size = len(old)*(1<<(2*MAX_WIDTH))
    old_response = {i:pair for pair in old_pairs for i in pair}
    new_response = {i:pair for pair in new_pairs for i in pair}
    matches = list(zip(old_pairs,new_pairs[:len(old_pairs)],strict=True))
    encode = {i:j for old_pair,new_pair in matches for i,j in zip(old_pair,new_pair,strict=True)}
    unencode = {j:i for i,j in encode.items()}
    readout = {new_pair[0]:old_pair for old_pair,new_pair in matches}
    approach = {i:new_pair[0] for old_pair,new_pair in matches for i in old_pair}
    for address in range(size):
        expect = old_response.get(address,())
        f = tuple(y for v in new_response.get(encode.get(address),()) for y in readout.get(v,()))
        g = tuple(unencode[v] for v in new_response.get(approach.get(address),()))
        assert f == g == expect
    # With one mapped input erased its required nontrivial response is lost.
    omitted = old_pairs[0][0]
    encode.pop(omitted)
    assert not new_response.get(encode.get(omitted),()) and old_response[omitted]
    # A common first address distinguishes the 255 nonempty masks plus identity.
    address = ((1 << MAX_WIDTH)-1) << MAX_WIDTH
    footprints = {address ^ mask ^ (mask << MAX_WIDTH) for mask in range(1 << MAX_WIDTH)}
    assert len(footprints) == 256
    return dict(address_width=2, ambient_axes=2*MAX_WIDTH, checked_input_basis_size=size,
                old_difference_rank=len(old_pairs), new_difference_rank=len(new_pairs),
                matched_forward_and_adjoint=True, corrupted_encoder_rejected=True,
                distinct_aligned_interchanges_at_one_address=len(footprints))


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--emit',action='store_true')
    args = parser.parse_args()
    bit = read_source('BIT.json','8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d')
    rat = read_source('AUDIT.json','a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376')
    word = read_source('WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9')
    B = change({int(g):c for g,c in bit['native']['targets'].items()},
               {int(g):c for g,c in bit['native']['paid'].items()})
    R = change({int(g):c for g,c in rat['signed']['productive'].items()},
               {int(g):c for g,c in rat['signed']['paid'].items()})
    assert B[1] < 0 < R[0]
    results = [enumerate_pairs(n,B) for n in (2,3,4)]
    assert [len(hit) for _,hit in results] == [0,3,32]
    assert all(len(set(row['odd_grade_counts']))==2 for row in results[1][1])
    assert all(x['axis_pair_rank_deficit']>0 for _, rows in results for x in rows)
    best = results[1][1][0]
    assert best['old'] == (1,5,6) and best['new'] == (2,2,8)
    assert best['minimum_calls'] == 12 and not best['any_single_channel_matching']
    control = abstract_match(best['old'],best['new'])
    survivors = {n:[x for x in rows if x['odd_grade_counts'][0]<=x['odd_grade_counts'][1]]
                 for n,(_,rows) in zip((2,3,4),results,strict=True)}
    assert [len(survivors[n]) for n in (2,3,4)]==[0,1,16]
    no8 = [x for x in survivors[4] if max(x['new'])<8]
    assert len(no8)==4 and no8[0]['old']==(1,4,4,5) and no8[0]['new']==(2,2,3,7)
    assert no8[0]['minimum_calls']==14
    no8_control = abstract_match(no8[0]['old'],no8[0]['new'])
    atlas_extremes = {r:[int(c) for c,f in word['frames'].items() if f['dim']==r] for r in (0,8)}
    assert atlas_extremes == {0:[0],8:[1]}
    out = dict(trial=str(TARGET),base_bit=[str(v) for v in B],base_rational=[str(v) for v in R],
               positive_sets={n:dict(tested_equipriced_grade_sum=number,qualifying_rank_price=hit) for n,(number,hit) in zip((2,3,4),results,strict=True)},
               rational_address_parity_survivors=survivors,
               grade8_only_between_charts=[0,1], abstract_witness=control,
               best_no_grade8_parity_survivor=no8[0], best_no_grade8_abstract_witness=no8_control,
               scope='Unrestricted neutral rank-factorization model. Actual paid physical replacements and compiler admission are open.')
    rendered = json.dumps(out,indent=2,sort_keys=True)+'\n'
    if args.emit:
        print(rendered,end='')
    else:
        assert rendered == (ROOT/'RESULT.json').read_text()
        print('PASS: exact grade-pair census, directed 36/48-call price and full forward/adjoint abstract match.')


if __name__ == '__main__':
    main()
