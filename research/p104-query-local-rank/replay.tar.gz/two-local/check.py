#!/usr/bin/env python3
"""Exact two-neighboring-LOCAL continuation of the BIT seam rank screen."""
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import gzip
import json
import sys
HERE = Path(__file__).resolve().parent
INPUT = HERE / 'inputs'
reference_path = HERE / 'reference_check.py'
if sha256(reference_path.read_bytes()).hexdigest() != '9c2d3fe3dd1ebc9122a50c2bffd57ca6dab89d6665004928fb776da99293040f':
    raise ValueError('reference script pin')
reference_spec = spec_from_file_location('reference_check', reference_path)
first = module_from_spec(reference_spec)
sys.modules[reference_spec.name] = first
reference_spec.loader.exec_module(first)


def need(ok, why):
    if not ok:
        raise ValueError(why)


def main():
    for name, digest in first.PINS.items():
        need(sha256((INPUT/name).read_bytes()).hexdigest() == digest, f'input pin {name}')
    caller = json.loads(gzip.decompress((INPUT/'EFREE-CALLER.json.gz').read_bytes()))
    word = json.loads(gzip.decompress((INPUT/'WORD.json.gz').read_bytes()))
    spec = spec_from_file_location('pinned_two_local_operator', INPUT/'binary_operator.py')
    op = module_from_spec(spec); sys.modules[spec.name] = op; spec.loader.exec_module(op)
    need(op.canonical_hash(word) == op.WORD, 'canonical native word')
    events=caller['events']; n=caller['roles']; a,b=132,396
    indexed=list(enumerate(events[a:b],a))
    need(n==38 and caller['ports']==111, 'roles and ports')
    need(events[394]==['LOCAL',10,1,0] and events[395]==['LOCAL',10,20,19], 'two local calls')
    need(events[a-1]==['IDLE_ONE',28,[9]] and events[b]==['ADD',0,1], 'adjacent original events')
    queries=[i for i,e in indexed if e[0]=='QUERY']
    need(queries == [196,198,201,349], 'query clocks')
    A,B=first.matrows(indexed[:-1],n)
    C,D=first.matrows(indexed,n)
    need(first.rank(A)==38 and first.rank(C)==38 and first.rank(B)==5 and first.rank(D)==6,
         'two LOCAL boundaries and epsilon ranks')
    source=(1<<19)|(1<<20)|(1<<29)
    need(A[20]==source, 'source row into second LOCAL')
    querychannel=B.copy(); querychannel[19]^=querychannel[20]
    nativechannel=[0]*n; nativechannel[19]=source
    need([x^y for x,y in zip(querychannel,nativechannel)]==D, 'second LOCAL decomposition')
    need(first.rank(querychannel)==5 and first.rank(nativechannel)==1, 'independent channel ranks')
    u=(1<<19)|(1<<21); v=(1<<21)|(1<<29)
    left=0
    for i in range(n):
        if u>>i&1:left ^= B[i]
    need(left==0 and (u>>19&1)==1,'output independence witness')
    need(all((row&v).bit_count()%2==0 for row in B) and (source&v).bit_count()%2==1,
         'input independence witness')
    mr=[0,1,2,19,20,21]; mc=[0,1,10,19,20,29]
    minor=[[D[i]>>j&1 for j in mc] for i in mr]
    need(first.rank([sum(x<<k for k,x in enumerate(row)) for row in minor])==6,'rank-six minor')

    # Independent #7830 evaluator, retaining t_10 rather than setting it to 1.
    polys=op.caller_operator({'roles':n,'events':events[a:b]}, False)
    z=(0,)*19; q=(1,)+(0,)*18
    t=(0,)+(0,)*9+(1,)+(0,)*8; qt=(1,)+(0,)*9+(1,)+(0,)*8
    for i,p in enumerate(polys):
        need(set(p)<={z,q,t,qt},f'formal stage support row {i}')
        base0=p.get(z,0)^p.get(q,0); eps0=p.get(q,0)
        base1=p.get(t,0)^p.get(qt,0); eps1=p.get(qt,0)
        if i in (0,1,19,20):
            need(base0==eps0==0 and base1==C[i] and eps1==D[i],f'formal stage row {i}')
        else:
            need(base1==eps1==0 and base0==C[i] and eps0==D[i],f'formal stage row {i}')
    prefix,_=first.matrows(list(enumerate(events[:a])),n)
    suffix,_=first.matrows(list(enumerate(events[b:],b)),n)
    need(first.rank(prefix)==first.rank(suffix)==n,'unchanged prefix and suffix invertible')
    controls=[]
    for clock in queries:
        x,y=first.matrows(indexed,n,demote=clock)
        need(x==C and y!=D and first.rank(y)==5,f'QUERY demotion {clock}')
        controls.append({'clock':clock,'constant_unchanged':True,'epsilon_rank':5,'mismatch':True})
    for clock in (394,395):
        changed=[]
        for i,event in indexed:
            if i==clock:
                _,_,s,d=event
                changed.append((i,['ADD',d,s]))  # stage specialization t=1
            else:
                changed.append((i,event))
        x,y=first.matrows(changed,n)
        need(x==C and y!=D and first.rank(y)==5,f'LOCAL epsilon demotion {clock}')
        controls.append({'clock':clock,'mutation':'LOCAL q shear to q-independent shear, t=1',
                         'constant_unchanged':True,'epsilon_rank':5,'mismatch':True})
    native=[first.native_endpoint(word,False),first.native_endpoint(word,True)]
    result={
      'status':'PASS_FORMAL_QUERY_PLUS_TWO_LOCAL_RANK_OBSTRUCTION',
      'scope':'Universal arbitrary-input 38-role boundary and fixed exterior for pinned caller clocks [132,396); two unchanged standard LOCAL calls plus QUERY and q-independent operations over F2[q]/(q^2-1), stage factors specialized to 1. Does not cover changed native epsilon behavior, access to native helper/scratch as extra channel, added q-dependent gates, altered exterior, or representation-specific identities.',
      'upstream_pins':{'construction_7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
                       'round_7852':'41beda1d6435760dc99e38bd7e65f36798aad212',
                       'round_main':'e54523517d0f03e58352e647c403a5af3e525a57',
                       'input_sha256':first.PINS},
      'window':{'clock_interval_half_open':[a,b], 'events':dict(Counter(e[0] for _,e in indexed)),
                'query_clocks':queries, 'locals':[events[394],events[395]], 'roles':n, 'ports':111},
      'boundary':{'before_second_local_epsilon_rank':first.rank(B), 'after_second_local_epsilon_rank':first.rank(D),
                  'source_row_20_hex':format(source,'x'),'second_local_output_role':19,
                  'prior_channel_after_local_rank':first.rank(querychannel),'second_local_channel_rank':1,
                  'left_annihilator_basis':[19,21],'right_annihilator_basis':[21,29],
                  'minor_rows':mr,'minor_columns':mc,'minor':minor,
                  'constant_rank':first.rank(C),'epsilon_rows_hex':[format(x,'x') for x in D],
                  'epsilon_rows_sha256':first.rows_hash(D), 'prefix_rank':first.rank(prefix),
                  'suffix_rank':first.rank(suffix),
                  'independent_polynomial_evaluator_agrees_at_formal_stage_10':True},
      'lower_bound':{'current_query_events_per_port':4,'local_events_per_port':2,
                     'minimum_query_events_with_two_locals_per_port':4,
                     'required_epsilon_rank_per_port':6,
                     'max_epsilon_rank_with_three_queries_and_two_locals_per_port':5,
                     'parallel_ports_required_epsilon_rank':666,
                     'parallel_ports_max_epsilon_rank_with_three_queries_and_two_locals':555},
      'native_literal_replay':native, 'negative_controls':controls,
      'invoice':{'valid_replacement_found':False,'full_stack_price':None,
                 'requested_trial':'0.003879929046155','claimed_saving':None},
      'proof':'At q=1+epsilon, each QUERY or standard LOCAL contributes at most one to epsilon rank per port. A product of 3 QUERY and 2 LOCAL contributes at most rank 5, but the pinned two-LOCAL boundary has rank 6. The fixed outer prefix and suffix specialize to invertible matrices. The two-LOCAL full expression is also compared with the pinned polynomial evaluator retaining formal t10.'
    }
    (HERE/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('PASS QUERY+2 LOCAL boundary',a,b,'epsilon rank',first.rank(D),'max(3 QUERY+2 LOCAL)',5,
          'controls',len(controls),flush=True)


if __name__=='__main__':main()
