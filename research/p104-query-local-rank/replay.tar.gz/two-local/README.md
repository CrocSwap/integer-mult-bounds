# Exact obstruction through both neighboring LOCAL calls

This portable continuation tests the pinned BIT caller interval `[132,396)`,
including **both** adjacent funded calls `LOCAL [10,1,0]` and
`LOCAL [10,20,19]`.  The original interval contains 228 ADDs, 30 SWAPs, four
QUERYs and the two LOCAL calls.  It has ε-rank **6 per port** in the specified
formal specialization.  Therefore no universal arbitrary-input replacement
can use three QUERYs and two unchanged standard LOCALs within the stated
q-dependent grammar: their ε-rank is at most 5 per port.  This extends the
rank-five result through the first LOCAL; it does not establish a new κ bound.

The covered domain is the original 38-role boundary over
`F₂[q]/(q²−1)`, or the complete caller output with its exterior fixed, with
q-independent operations and exactly those two standard LOCAL interfaces.
The prefix and suffix are invertible in the specialization, so a boundary
mismatch cannot be hidden by the unchanged exterior.  The result includes
arbitrary q-independent linear mixing across the 111 ports: the original
ε-rank is 666, while 3 QUERY and 2 LOCAL events have combined ε-rank at most
555.  The rank bound does not cover altered q-dependent native interfaces,
using native helpers or scratch as an extra q-dependent channel, additional
q-dependent primitives, a changed exterior, or identities that hold only in a
specific physical representation.

## Exact check

Write `q=1+ε` with `ε²=0`, and specialize the stage variable to 1 solely for
the rank lower bound.  Let `A+εB` be the full transfer through the first LOCAL,
interval `[132,395)`.  It has `rank(B)=5`.  On entering the second LOCAL,
`A` row 20 is `e19ᵀ+e20ᵀ+e29ᵀ`.  In the caller model the second LOCAL is
`N0+εE`, with `N0=I+e19 e20ᵀ` and `E=e19 e20ᵀ`.  Its added channel is

```
E A = e19 (e19ᵀ+e20ᵀ+e29ᵀ).
```

Both independence tests hold:

```
(e19+e21)ᵀ B = 0,     (e19+e21)ᵀ e19 = 1,
B (e21+e29) = 0,      (e19ᵀ+e20ᵀ+e29ᵀ)(e21+e29) = 1.
```

Since `N0` is invertible and fixes `e19`, the updated ε-rank is 6.  Direct
elimination certifies it using rows `[0,1,2,19,20,21]` and columns
`[0,1,10,19,20,29]`:

```
1 1 0 0 0 0
0 1 1 0 0 0
1 0 0 0 0 0
0 0 0 1 0 0
0 0 0 1 0 1
0 0 0 1 1 0
```

Under `q=1+ε`, a product's ε coefficient is a sum of terms, one per gate,
with each term surrounded by constant matrices.  A QUERY or standard LOCAL
contributes ε-rank at most 1 per port and a q-independent operation contributes
zero.  Rank subadditivity gives the lower bound above.  The complete interval
is separately checked with stage-10 retained as a formal variable against the
pinned #7830 polynomial caller evaluator.

Four query-to-ADD demotions and each of the two LOCAL q-channel demotions
preserve the constant matrix but reduce the ε-rank to 5.  These are six
targeted mutation controls, not an exhaustive mutation test.

## Source pins and reproduction

Context pins: #7830 `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, #7852
`41beda1d6435760dc99e38bd7e65f36798aad212`, main
`e54523517d0f03e58352e647c403a5af3e525a57`.  The local #7830 and main
checkouts were checked at those heads; #7852 is round context supplied to this
screen.  The exact frozen caller, native word, and #7830 polynomial evaluator
are bundled with the original license and notice.  Input hashes and the
one-LOCAL reference script hash are verified by `check.py` before use.  Run:

```sh
python3 -IB check.py
sha256sum -c SHA256SUMS
```

The deterministic `RESULT.json` also records independent scalar replay of all
680 public native rows forward and reverse, with 462,400 coefficients and
3,554 dirty retirements each way.  This replay does not redo the source frame
geometry; the native LOCAL q/stage formula remains the inherited common-head
interface, not a newly established physical realization.  The full polynomial
cross-check reuses the pinned source evaluator.

No replacement, new complete invoice, or saving is claimed at trial
`0.003879929046155`.  The remaining route would require a concrete changed
native or reader interface outside this restricted formal grammar, followed by
physical, adjoint, retirement and full-stack price checks.

## Open next questions

* Can an altered native/helper boundary expose a q-dependent direction that
  replaces a QUERY while restoring all exterior readers?
* Can a concrete-representation identity evade this universal-ring screen, and
  if so, what is the exact full changed-candidate invoice?
