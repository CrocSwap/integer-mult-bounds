# A four-query obstruction for a frozen paired BIT caller block

The 38-role paired BIT caller at the pinned source below has a maximal middle
block of 228 ADD, 30 SWAP and four QUERY events. In the formal caller model
over `F₂[q]/(q²−1)`, every arbitrary-input, boundary-equivalent replacement of
that block using only rank-one QUERY gates and q-independent invertible
`F₂`-linear gates needs **at least four QUERY gates per port**. The existing
four attain this lower bound. The [proof](PROOF.md) gives a displayed identity
minor and the rank argument; this is a scoped mathematical obstruction plus a
finite source-bound certificate, not a universal BIT wall or a κ improvement.

The investigation was motivated by the pricing questions in
[#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852), pinned at
`41beda1d6435760dc99e38bd7e65f36798aad212`. This package analyzes the
binary caller's characteristic-two quotient directly; it neither asserts an
equivalence with #7852's rational signed-word model nor supplies a Lean proof
of the result. Its middle interval contains no IDLE_ONE, so the obstruction
does not settle a joint QUERY-and-IDLE_ONE rewrite.

At saving `0.003879929046155`, the rank-one signed-moment price is exactly
`1`. Under the inherited full-port tariff and with all non-QUERY paid and
productive inventory fixed, the existing four events cost `4 × 111 = 444`
rank-one positions. A replacement with `m` full-port events has exact signed
margin change `111(4−m) ≤ 0`, so its maximum possible signed gain is `0` in
this grammar. This calculation alone does not price changes to other inventory,
ordinary work, or a complete modified caller.

The only bundled source is the exact caller file from
`aliromman/integer-mult-bounds` at
`4f7c67ae387cc91580f469aeda4d508b372b9ec1`, path
`research/paired-query-only-bit/EFREE-CALLER.json.gz`. It has SHA-256
`757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b` and Git
blob `f022272a8d51ede841778dec76e2bfb24b614d04`; both are checked by the
verifier. The contextual full-port tariff is attributed to the independent
BIT review in #7830, head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; that
external file is identified in [SOURCES.json](SOURCES.json), but is not bundled
or authenticated by the verifier. The byte identity of the bundled caller with
its stated pinned GitHub source was also checked at package preparation time.

## Reproduce

This source archive is self-contained and requires only CPython 3.12 and its
standard library. It is not registered as a repository replay hook.

```sh
sha256sum -c SHA256SUMS
python3 -IB verify.py --out /tmp/query-rank-result.json
cmp RESULT.json /tmp/query-rank-result.json
```

The verifier runs independent polynomial and dual-number transfer recurrences,
checks the 4×4 identity minor and exact source hashes, and rejects source-byte,
three-query and minor perturbations. Replacing each of the four QUERY events by
an ADD preserves the constant transfer but changes the epsilon transfer, whose
rank falls from four to three. `RESULT.json` is the observed deterministic
receipt. No network access or `.pyc` files are required.

## Boundaries and open next questions

This proof is for one formal port and fixes the 38-role boundary and allowed
gates. The 444-position accounting additionally assumes independent ports and
the existing all-port rank-one tariff. It does not cover other q-dependent
operations, changes crossing the neighboring IDLE_ONE or LOCAL events,
cross-port mixing or shared physical queries, or identities that hold only in
a particular concrete representation. It does not establish a complete
signed-caller ceiling, discharge a framework premise, or claim an improved κ.

1. Can a q-dependent operation outside this restricted grammar preserve the
   actual block transfer at lower **fully charged** cost? First specify its
   exact gate semantics and price, and identify all boundary readers. The
   blocker is the missing physical and invoice accounting.
2. Does an identity specific to the physical port representation permit a
   cheaper edit even though the universal formal polynomial changes? First
   identify the representation and derive its kernel on arbitrary legal input;
   the formal-ring rank certificate alone does not address that specialization.

## Credit

The caller byte is pinned at Ali Romman's fork; source identity alone does not
establish individual authorship. The surrounding supplier work credits Ali
Romman and other predecessors in [NOTICE](NOTICE). Clear1nsight's #7830
construction and independent reviewer provide the comparable full BIT invoice
and tariff. The formal derivative screen and standalone replay were prepared
with substantial OpenAI Codex assistance. New material is offered under
Apache-2.0; see [LICENSE](LICENSE).
