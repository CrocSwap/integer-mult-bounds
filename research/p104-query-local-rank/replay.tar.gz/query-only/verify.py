#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Check the pinned BIT caller's formal QUERY rank and explicit controls.

Run from any directory with Python 3.12: python3 -IB path/to/verify.py.
The pinned caller file is the only nonstandard input; no network is used.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha1, sha256
from pathlib import Path
import argparse
import gzip
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'inputs/EFREE-CALLER.json.gz'
SOURCE_SHA256 = '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
SOURCE_GIT_BLOB = 'f022272a8d51ede841778dec76e2bfb24b614d04'
TARGET = Fraction('0.003879929046155')
START, STOP = 132, 394
QUERIES = [196, 198, 201, 349]
ROWS = [0, 1, 19, 20]
COLS = [0, 1, 20, 21]


def need(condition, description):
    if not condition:
        raise ValueError(description)


def authenticate(data):
    blob = sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    need(sha256(data).hexdigest() == SOURCE_SHA256 and blob == SOURCE_GIT_BLOB,
         'pinned caller source digest')


def gf2_rank(rows):
    pivots = {}
    for row in rows:
        while row:
            col = row.bit_length() - 1
            if col in pivots:
                row ^= pivots[col]
            else:
                pivots[col] = row
                break
    return len(pivots)


def dual_transfer(indexed, count, demote=None):
    """q=1+epsilon; matrix rows are bitsets (constant, epsilon)."""
    constant = [1 << i for i in range(count)]
    epsilon = [0] * count
    for clock, (op, target, source) in indexed:
        need(0 <= target < count and 0 <= source < count and target != source,
             f'valid distinct roles at clock {clock}')
        if op == 'SWAP':
            constant[target], constant[source] = constant[source], constant[target]
            epsilon[target], epsilon[source] = epsilon[source], epsilon[target]
        elif op == 'ADD' or (op == 'QUERY' and clock == demote):
            constant[target] ^= constant[source]
            epsilon[target] ^= epsilon[source]
        elif op == 'QUERY':
            epsilon[target] ^= epsilon[source] ^ constant[source]
            constant[target] ^= constant[source]
        else:
            raise ValueError(f'unsupported event {op} at {clock}')
    return constant, epsilon


def polynomial_transfer(indexed, count):
    """Separate recurrence for a+bq in F2[q]/(q²-1), then substitute q=1+ε."""
    a = [1 << i for i in range(count)]
    b = [0] * count
    for _, (op, target, source) in indexed:
        if op == 'SWAP':
            a[target], a[source] = a[source], a[target]
            b[target], b[source] = b[source], b[target]
        elif op == 'ADD':
            a[target] ^= a[source]
            b[target] ^= b[source]
        elif op == 'QUERY':
            a[target] ^= b[source]
            b[target] ^= a[source]
        else:
            raise ValueError(f'unsupported polynomial event {op}')
    return [x ^ y for x, y in zip(a, b)], b


def minor(rows):
    return [[(rows[r] >> c) & 1 for c in COLS] for r in ROWS]


def must_reject(action, expected):
    try:
        action()
    except ValueError as exc:
        need(str(exc) == expected, f'unexpected rejection: {exc}')
        return
    raise ValueError(f'corruption not rejected: {expected}')


def enough_queries(derivative_rank, query_count):
    need(query_count >= derivative_rank, 'claimed query count below derivative rank')


def run():
    source = SOURCE.read_bytes()
    authenticate(source)
    corrupted_source = bytearray(source)
    corrupted_source[-1] ^= 1
    must_reject(lambda: authenticate(corrupted_source), 'pinned caller source digest')

    caller = json.loads(gzip.decompress(source))
    need(caller['roles'] == 38 and caller['ports'] == 111, 'pinned caller dimensions')
    events = caller['events']
    need(events[START - 1] == ['IDLE_ONE', 28, [9]]
         and events[STOP] == ['LOCAL', 10, 1, 0], 'exact maximal-block boundaries')
    window = list(enumerate(events[START:STOP], start=START))
    kinds = Counter(event[0] for _, event in window)
    need(kinds == Counter({'ADD': 228, 'SWAP': 30, 'QUERY': 4}), 'complete block event census')
    clocks = [clock for clock, event in window if event[0] == 'QUERY']
    need(clocks == QUERIES, 'exact chronological QUERY clocks')
    constant, epsilon = dual_transfer(window, caller['roles'])
    poly_constant, poly_epsilon = polynomial_transfer(window, caller['roles'])
    need((constant, epsilon) == (poly_constant, poly_epsilon),
         'independent polynomial and dual-number recurrences')
    need(gf2_rank(constant) == 38 and gf2_rank(epsilon) == 4,
         'constant invertibility and exact epsilon rank')
    identity = [[int(i == j) for j in range(4)] for i in range(4)]
    need(minor(epsilon) == identity, 'explicit identity minor')
    corrupted_epsilon = epsilon.copy()
    corrupted_epsilon[0] ^= 1
    need(minor(corrupted_epsilon) != identity, 'identity-minor mutation')

    changes = []
    for clock in clocks:
        altered_constant, altered_epsilon = dual_transfer(window, caller['roles'], demote=clock)
        need(altered_constant == constant and gf2_rank(altered_epsilon) == 3
             and altered_epsilon != epsilon, f'QUERY-to-ADD mutation at {clock}')
        changes.append({'clock': clock, 'constant_part_unchanged': True,
                        'epsilon_rank': 3, 'target_transfer_rejected': True})
    must_reject(lambda: enough_queries(gf2_rank(epsilon), 3),
                'claimed query count below derivative rank')
    enough_queries(gf2_rank(epsilon), 4)
    need(TARGET == Fraction(775985809231, 200000000000000), 'exact target saving')
    exponent = 1 - TARGET
    need(exponent == Fraction(199224014190769, 200000000000000), 'exact moment exponent')
    need(0 < exponent < 1, 'positive moment exponent')
    # Rank one has exact real power 1 for every real exponent; no numerical
    # evaluation of a fractional power is needed.

    result = {
        'status': 'PASS_FORMAL_QUERY_RANK_OBSTRUCTION',
        'scope': 'One port, pinned 38-role middle block, universal arbitrary-input F2[q]/(q^2-1), q-independent invertible linear gates, rank-one QUERY gates.',
        'source': {'sha256': SOURCE_SHA256, 'git_blob_sha1': SOURCE_GIT_BLOB,
                   'repository': 'aliromman/integer-mult-bounds',
                   'commit': '4f7c67ae387cc91580f469aeda4d508b372b9ec1',
                   'path': 'research/paired-query-only-bit/EFREE-CALLER.json.gz'},
        'clock_interval_half_open': [START, STOP], 'roles': caller['roles'], 'ports': caller['ports'],
        'event_counts': dict(sorted(kinds.items())), 'query_clocks': clocks,
        'constant_rank': gf2_rank(constant), 'epsilon_rank': gf2_rank(epsilon),
        'epsilon_rows_hex': [format(row, 'x') for row in epsilon],
        'identity_minor': {'rows': ROWS, 'columns': COLS, 'matrix': identity},
        'query_demotions': changes,
        'controls': {'bad_source_bytes_rejected': True, 'one_bit_minor_mutation_detected': True,
                     'three_query_claim_rejected': True, 'two_transfer_recurrences_agree': True},
        'signed_effect': {'saving': '0.003879929046155', 'moment_exponent': str(exponent),
                          'query_price_per_rank_one_port': '1', 'current_query_events': 4,
                          'current_rank_one_charges': 444,
                          'max_signed_gain_given_unchanged_other_invoice_terms': '0',
                          'formula_for_m_full_port_queries': '111*(4-m), for m >= 4'},
        'limits': ['other q-dependent operations', 'rewrites crossing LOCAL or IDLE_ONE boundaries',
                   'cross-port mixing or shared physical queries', 'concrete representation-specific identities',
                   'changes to non-QUERY paid or productive inventory'],
    }
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, help='optional path for the generated JSON receipt')
    args = parser.parse_args()
    result = run()
    encoded = json.dumps(result, indent=2, sort_keys=True) + '\n'
    if args.out:
        args.out.write_text(encoded)
    print('PASS_FORMAL_QUERY_RANK_OBSTRUCTION rank=4 current_queries=4 max_signed_gain=0')
