# Proof of the formal block obstruction

Work at one port with 38 roles over
`R = F₂[q]/(q²−1)`. In characteristic two, the substitution
`q = 1 + ε` identifies `R` with `F₂[ε]/(ε²)`. Matrices act on column states;
the verifier stores their rows as bitsets. The event `QUERY d s` is the
transvection `I + q E_ds`, with `d ≠ s`. An ADD or SWAP is an invertible
q-independent `F₂`-linear map. We even allow an arbitrary q-independent
invertible linear map in place of any number of ADD and SWAP events.

For an arbitrary finite product of permitted gates, write each gate as
`A_i + ε B_i`. Every `A_i` is invertible. A q-independent gate has `B_i = 0`;
a QUERY has `A_i = I + E_ds` and `B_i = E_ds`, which has rank one. Since
`ε² = 0`, the coefficient `D` of ε in the product is the sum, over QUERY
gates, of

```text
A_last ··· A_(i+1) B_i A_(i−1) ··· A_first.
```

Each summand has rank at most one. Rank subadditivity gives
`rank_F₂(D) ≤ number of QUERY gates`. This argument applies to every length
and placement of q-independent invertible gates and to every arbitrary-input
replacement that has the same complete 38-role boundary transfer over `R`.

For the pinned block `[132,394)`, the verifier derives `rank(D) = 4` and
exhibits the identity minor with zero-based rows `0, 1, 19, 20` and columns
`0, 1, 20, 21`. The existing block has four QUERY events, at clocks `196`,
`198`, `201` and `349`. The four QUERY summands give the matching upper bound,
and the identity minor gives the lower bound. Hence the bound is attained.

The check computes the matrix twice: first using `(constant, epsilon)` rows,
then directly as `(coefficient of 1, coefficient of q)` modulo `q²=1`, before
substituting `q=1+ε`. Replacing each QUERY with an ADD leaves the constant
part unchanged but gives an epsilon coefficient of rank 3, so the changed
block fails the full boundary transfer. The script also detects a changed
input byte, a flipped minor bit, and an attempted three-QUERY certificate.

## Exact signed effect under the declared accounting

The contextual #7830 BIT pricing counts each QUERY at rank one for each of 111
ports. At `κ = 0.003879929046155`, `s = 1−κ` is the exact rational
`199224014190769/200000000000000`, and `1^s = 1` exactly. The old paid
contribution is therefore `444`. For a full-port replacement with `m ≥ 4`
QUERY events and unchanged other paid and productive terms,

```text
new signed margin − old signed margin = 444 − 111m ≤ 0.
```

With port-local counts `m_p`, the corresponding expression is
`444 − Σ_p m_p ≤ 0`, provided each of the 111 ports independently has the
same formal boundary transfer and queries cannot be shared across ports. The
unmodified block attains zero change. This does not rule out editing the
productive inventory or reducing other paid terms, and it does not establish
the complete signed invoice or a κ bound.
