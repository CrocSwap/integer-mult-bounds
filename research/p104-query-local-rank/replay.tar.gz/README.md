# The exact BIT QUERY rank through two LOCAL calls

The three checks use #7830's standard native interface and nested
intervals of the same caller. The formal epsilon coefficient rank
is four, five and six. See the exact reproduction instructions in
[query-only](query-only/README.md), [one LOCAL](one-local/README.md)
and [two LOCALs](two-local/README.md). Each was checked in isolation.
Additional funded helper directions and changed q-dependent interfaces
remain separate questions that require an actual signed replay.
