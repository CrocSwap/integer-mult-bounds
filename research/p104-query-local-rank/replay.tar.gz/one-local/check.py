#!/usr/bin/env python3
"""Exact bounded BIT QUERY + one funded LOCAL boundary screen.

Only the caller's formal q-involution semantics are claimed.  This independently
propagates F2 epsilon rows, then compares to #7830's pinned polynomial evaluator.
"""
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
INPUT = HERE / 'inputs'
PINS = {
    'EFREE-CALLER.json.gz': '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
    'WORD.json.gz': 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
    'binary_operator.py': '36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349',
}


def need(ok, description):
    if not ok:
        raise ValueError(description)


def rank(rows):
    pivots = {}
    for row in rows:
        while row:
            k = row.bit_length() - 1
            if k in pivots:
                row ^= pivots[k]
            else:
                pivots[k] = row
                break
    return len(pivots)


def rows_hash(rows):
    return sha256(json.dumps([format(v, 'x') for v in rows], separators=(',', ':')).encode()).hexdigest()


def matrows(events, n, demote=None, demote_local=False):
    """t=1; B, D describe M(q)=B+(q+1)D in the 38 role basis."""
    B = [1 << i for i in range(n)]
    D = [0] * n
    for clk, event in events:
        op, *args = event
        if op == 'SWAP':
            a, b = args
            B[a], B[b] = B[b], B[a]
            D[a], D[b] = D[b], D[a]
        elif op in ('ADD', 'QUERY'):
            a, b = args
            if op == 'QUERY' and clk != demote:
                D[a] ^= B[b]
            D[a] ^= D[b]
            B[a] ^= B[b]
        elif op == 'LOCAL':
            _, s, d = args
            if not demote_local:
                D[d] ^= B[s]
            D[d] ^= D[s]
            B[d] ^= B[s]
        elif op == 'IDLE_ONE':
            pass  # q-independent body factors specialize to 1
        else:
            raise ValueError(f'unsupported opcode {op}')
    return B, D


def native_endpoint(word, reverse):
    """Independently replay the literal scalar word; frames remain inherited.

    A live cell is its coefficient row; None is an inactive owned cell.  MOVE
    changes a field's chart, not its scalar row.  The full physical chart and
    frame checks are not repeated by this lightweight endpoint replay.
    """
    public, private = word['public'], word['owned_fields']
    cells = [1 << i for i in range(public)] + [None] * private
    ops = word['program']
    order = range(len(ops)-1, -1, -1) if reverse else range(len(ops))
    opened, retired = ('CLEAR', 'INIT') if reverse else ('INIT', 'CLEAR')
    dirty = 0
    for clk in order:
        op, a, *args = ops[clk]
        if op == opened:
            need(a >= public and cells[a] is None, f'bad activation {clk}')
            cells[a] = 0
        elif op == retired:
            need(a >= public and cells[a] is not None, f'bad retirement {clk}')
            dirty += bool(cells[a])
            cells[a] = None
        elif op == 'ADD':
            b, _ = args
            need(a != b and cells[a] is not None and cells[b] is not None, f'bad add {clk}')
            if reverse:
                cells[b] ^= cells[a]
            else:
                cells[a] ^= cells[b]
        elif op == 'SWAP':
            b, = args
            need(cells[a] is not None and cells[b] is not None, f'bad swap {clk}')
            cells[a], cells[b] = cells[b], cells[a]
        elif op == 'MOVE':
            need(cells[a] is not None, f'bad move {clk}')
        else:
            raise ValueError(f'bad word operation {op}')
    need(all(x is None for x in cells[public:]), 'unretired owned cells')
    expected = [1 << i for i in range(public)]
    for i in range(111):
        dst, src = (i, i+111) if reverse else (i+111, i)
        expected[dst] ^= 1 << src
    need(cells[:public] == expected, 'native all-column scalar boundary')
    need(dirty == 3554, 'native dirty retirements')
    return {'directions': 'reverse' if reverse else 'forward',
            'public_rows': public, 'checked_coefficients': public**2,
            'dirty_retirements': dirty, 'output_rows_sha256': rows_hash(cells[:public])}


def main():
    for file, digest in PINS.items():
        need(sha256((INPUT / file).read_bytes()).hexdigest() == digest, f'bad source pin {file}')
    caller = json.loads(gzip.decompress((INPUT / 'EFREE-CALLER.json.gz').read_bytes()))
    word = json.loads(gzip.decompress((INPUT / 'WORD.json.gz').read_bytes()))
    spec = spec_from_file_location('pinned_binary_operator', INPUT / 'binary_operator.py')
    op = module_from_spec(spec)
    sys.modules[spec.name] = op
    spec.loader.exec_module(op)
    need(op.canonical_hash(word) == op.WORD, 'canonical native word')
    need(caller['roles'] == 38 and caller['ports'] == 111, 'caller dimensions')
    events = caller['events']; n = caller['roles']; start, stop = 132, 395
    indexed = list(enumerate(events[start:stop], start))
    need(events[start-1] == ['IDLE_ONE', 28, [9]], 'original left exterior event')
    need(events[394] == ['LOCAL', 10, 1, 0], 'funded local boundary')
    need(events[395] == ['LOCAL', 10, 20, 19], 'original right exterior event')
    queries = [i for i, e in indexed if e[0] == 'QUERY']
    need(queries == [196, 198, 201, 349], 'exact query clocks')
    need(set(e[0] for _, e in indexed) <= {'ADD', 'SWAP', 'QUERY', 'LOCAL'}, 'window grammar')

    A, B = matrows(indexed[:-1], n)
    C, D = matrows(indexed, n)
    need(rank(A) == 38 and rank(B) == 4 and rank(C) == 38 and rank(D) == 5,
         'exact four-to-five rank')
    need(A[1] == 1 << 10, 'source row entering LOCAL')

    # LOCAL0 = I + e_0 e_1^T, LOCAL1 = e_0 e_1^T.  Hence
    # LOCAL1*A = e_0 e_10^T and LOCAL0*B is the old query channel.
    nb = B.copy(); nb[0] ^= nb[1]
    la = [0] * n; la[0] = A[1]
    need([x ^ y for x, y in zip(nb, la)] == D, 'Leibniz channel decomposition')
    need(rank(nb) == 4 and rank(la) == 1, 'native and query channel ranks')
    # Since LOCAL0 is invertible and fixes e0, rank(D)=rank(B+e0 e10^T).
    # Explicit dual witnesses: (e0+e2)^T B=0 and B(e1+e10)=0,
    # while they pair to 1 with e0 and e10 respectively.
    u = (1 << 0) | (1 << 2)
    v = (1 << 1) | (1 << 10)
    left = 0
    for i in range(n):
        if u >> i & 1:
            left ^= B[i]
    need(left == 0 and u & 1, 'native output outside query column span')
    need(all((row & v).bit_count() % 2 == 0 for row in B) and (A[1] & v).bit_count() % 2 == 1,
         'native input row outside query row span')
    mr = [0, 1, 2, 19, 20]; mc = [0, 1, 10, 19, 20]
    minor = [[D[i] >> j & 1 for j in mc] for i in mr]
    need(rank([sum(x << k for k,x in enumerate(row)) for row in minor]) == 5, 'rank-5 minor')

    # Stage-10 is retained as a formal indeterminate here, not specialized.
    # Independent #7830 polynomial code runs all window events and reduces q²=1.
    polys = op.caller_operator({'roles': n, 'events': events[start:stop]}, False)
    z = (0,)*19; q = (1,)+(0,)*18
    t = (0,)+(0,)*9+(1,)+(0,)*8
    qt = (1,)+(0,)*9+(1,)+(0,)*8
    need(len(t) == len(qt) == 19, 'monomial length')
    for i, poly in enumerate(polys):
        need(set(poly) <= {z, q, t, qt}, 'only expected stage and query symbols')
        # Independently derive LOCAL's formal-stage polynomial by placing the
        # specialized constant and epsilon rows on t exactly for roles 0,1.
        unscaled_base = poly.get(z, 0) ^ poly.get(q, 0)
        unscaled_eps = poly.get(q, 0)
        scaled_base = poly.get(t, 0) ^ poly.get(qt, 0)
        scaled_eps = poly.get(qt, 0)
        if i in (0, 1):
            need(unscaled_base == unscaled_eps == 0 and scaled_base == C[i] and scaled_eps == D[i],
                 f'polynomial evaluator (t-scaled row {i})')
        else:
            need(scaled_base == scaled_eps == 0 and unscaled_base == C[i] and unscaled_eps == D[i],
                 f'polynomial evaluator (unscaled row {i})')

    prefix_b, _ = matrows(list(enumerate(events[:start])), n)
    suffix_b, _ = matrows(list(enumerate(events[stop:], start=stop)), n)
    need(rank(prefix_b) == rank(suffix_b) == n, 'fixed outer prefix and suffix invertibility')
    controls = []
    for clk in queries:
        b, d = matrows(indexed, n, demote=clk)
        need(b == C and d != D and rank(d) == 4, f'query demotion control {clk}')
        controls.append({'clock': clk, 'constant_unchanged': True,
                         'epsilon_rank': rank(d), 'full_boundary_mismatch': True})
    b, d = matrows(indexed, n, demote_local=True)
    need(b == C and d != D and rank(d) == 4, 'native channel demotion control')
    controls.append({'clock': 394, 'mutation': 'LOCAL q shear replaced by q-independent shear',
                     'constant_unchanged': True, 'epsilon_rank': rank(d), 'full_boundary_mismatch': True})

    native = [native_endpoint(word, False), native_endpoint(word, True)]
    out = {
        'status': 'PASS_FORMAL_QUERY_PLUS_LOCAL_RANK_OBSTRUCTION',
        'scope': 'Universal arbitrary-input boundary of pinned caller clocks [132,395), and unchanged outer prefix/suffix, with one standard funded LOCAL and q-independent operations plus QUERY, over F2[q]/(q^2-1), stage factors specialized to 1 for the rank obstruction. Does not cover altered native epsilon behavior, use of native helper/scratch or other q-dependent operations, changed outer callers, or representation-specific identities.',
        'upstream_pins': {'construction_7830': '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
                          'round_7852': '41beda1d6435760dc99e38bd7e65f36798aad212',
                          'round_main': 'e54523517d0f03e58352e647c403a5af3e525a57',
                          'input_sha256': PINS},
        'window': {'clock_interval_half_open': [start, stop], 'events': dict(Counter(e[0] for _, e in indexed)),
                   'query_clocks': queries, 'local': events[394],
                   'right_exterior_first': events[395], 'roles': n, 'ports': caller['ports']},
        'native_literal_replay': native,
        'boundary': {'prefix_constant_rank': rank(prefix_b), 'suffix_constant_rank': rank(suffix_b),
                     'query_block_constant_rank': rank(A), 'query_block_epsilon_rank': rank(B),
                     'query_block_source_row_1_hex': format(A[1], 'x'),
                     'post_local_constant_rank': rank(C), 'post_local_epsilon_rank': rank(D),
                     'query_channel_after_local_rank': rank(nb), 'local_channel_rank': rank(la),
                     'local_input_row_hex': format(A[1], 'x'), 'local_output_role': 0,
                     'post_local_epsilon_rows_hex': [format(x, 'x') for x in D],
                     'post_local_epsilon_sha256': rows_hash(D),
                     'minor_rows': mr, 'minor_columns': mc, 'minor': minor,
                     'left_annihilator_query_channel_basis': [0,2],
                     'right_annihilator_query_channel_basis': [1,10],
                     'independent_polynomial_evaluator_agrees_at_formal_stage_10': True},
        'lower_bound': {'current_query_events_per_port': 4, 'local_events_per_port': 1,
                        'minimum_queries_with_one_local_per_port': 4,
                        'required_epsilon_rank_per_port': 5,
                        'max_epsilon_rank_with_three_queries_and_one_local_per_port': 4,
                        'parallel_ports_required_epsilon_rank': 555,
                        'parallel_ports_max_epsilon_rank_with_three_queries_and_one_local': 444},
        'negative_controls': controls,
        'invoice': {'valid_replacement_found': False, 'full_stack_price': None,
                    'requested_trial': '0.003879929046155',
                    'claimed_saving': None},
        'proof': 'Writing q=1+epsilon, every QUERY has epsilon coefficient of rank 1 per port and an unchanged standard LOCAL has rank 1 per port. The epsilon coefficient of a product is a sum of its gates\u2019 constant-prefixed/suffixed epsilon coefficients; rank is at most their sum. The rank-5 minor excludes 3 QUERY plus 1 LOCAL with the specified universal boundary. The fixed outer maps remain invertible after stage specialization, so their readers cannot hide the mismatch. The formal variable t10 is separately checked against the pinned evaluator.'
    }
    (HERE / 'RESULT.json').write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print('PASS QUERY+LOCAL boundary', start, stop, 'epsilon rank', rank(D),
          'max(3 QUERY+1 LOCAL)', 4, 'controls', len(controls), flush=True)


if __name__ == '__main__':
    main()
