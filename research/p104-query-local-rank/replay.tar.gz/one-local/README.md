# Exact formal obstruction across one funded LOCAL

This is a local research screen for the pinned BIT caller, **not a new κ
bound or a full application proof**.  It extends the earlier query-only
`[132,394)` rank screen to the strictly larger interval `[132,395)`, which
includes the funded `LOCAL [10,1,0]` at clock 394.  The frozen interval has
228 ADDs, 30 SWAPs, four QUERY events, and this one LOCAL.  The following
`LOCAL [10,20,19]` is outside the interval.

Within the stated formal grammar, a replacement for the entire interval that
preserves its arbitrary-input 38-role boundary while retaining one standard
LOCAL cannot use only three QUERY events.  The same conclusion applies if the
outer caller is kept fixed and one asks only for its complete 38-role output:
after the specialization used below, both the original prefix and suffix are
invertible.  The result also holds for 111 ports and arbitrary **q-independent**
linear mixing between ports.  It does not rule out a change to native helper or
scratch use, a modified LOCAL with a different q-dependent boundary, an added
q-dependent primitive, changing the outer caller, or a concrete-representation
identity absent from the universal formal ring.

## Calculation

The caller's pinned semantic ring is `F₂[q]/(q²−1)`; write `q = 1 + ε`, so
`ε² = 0`.  Stage-10's body variable is specialized to 1 for the rank argument.
This is a necessary specialization of any claimed universal identity and is
not an assertion that the physical body map is the identity.

Let `W = A + εB` be the interval `[132,394)` and let `e_i` denote role `i`.
For the neighboring funded LOCAL, the source caller model gives

```
N = N0 + εE,     N0 = I + e0 e1ᵀ,     E = e0 e1ᵀ.
N W = N0 A + ε (N0 B + E A).
```

The exact calculation has `rank(B)=4`, `A` row 1 equal to `e10ᵀ`, and
`EA = e0 e10ᵀ`.  The new native ε channel is independent of the old query
channel on both sides:

* `(e0+e2)ᵀ B = 0` but `(e0+e2)ᵀ e0 = 1`;
* `B (e1+e10) = 0` but `e10ᵀ (e1+e10) = 1`.

Because `N0` is invertible and fixes `e0`, these identities imply
`rank(N0 B + EA) = 5`.  Direct elimination verifies the full 38×38 coefficient
and the rank-five minor on rows `[0,1,2,19,20]` and columns `[0,1,10,19,20]`:

```
1 1 0 0 0
0 1 1 0 0
1 0 0 0 0
0 0 0 1 1
0 0 0 1 0
```

For a product `G_m … G_1`, its ε coefficient is the sum of the ε coefficient
of each gate, surrounded by the other gates' constant parts.  Left and right
multiplication cannot increase rank.  In the specialized grammar a QUERY has
ε-rank at most 1 per port, the unchanged standard LOCAL has ε-rank at most 1
per port, and each other allowed operation is q-independent.  Thus three
QUERYs and one LOCAL can supply at most rank 4, whereas this boundary needs
rank 5.  Over all 111 ports these ranks become at most 444 and exactly 555,
respectively; arbitrary q-independent inter-port mixing does not alter the
rank upper bound.  This is a lower bound on the stated grammar, not a lower
bound on all possible implementations.

The stage-10 variable is kept formal in a separate exact comparison with the
pinned #7830 polynomial evaluator: all rows, including both LOCAL-scaled rows,
match the independently written dual-number recurrence.  As controls, replacing
each of the four QUERYs in turn by ADD leaves the constant matrix unchanged but
drops the extended ε rank to 4.  The same happens when the LOCAL q-shear is
replaced by a q-independent shear.  These are targeted mutation controls.

## Sources and reproduction

Context pins: #7830 `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, #7852
`41beda1d6435760dc99e38bd7e65f36798aad212`, main
`e54523517d0f03e58352e647c403a5af3e525a57`.  The first and main were checked
against their local source checkouts; #7852 is the supplied round context and
is not fetched by this check.  The pinned caller, native word and source
`binary_operator.py` are in `inputs/`; their SHA-256 pins are checked before
running.  The operator is byte-identical to the #7830 checkout's
`research/p104-mixed-rank-supplier/review/binary_operator.py`.  Copyright and
license from that checkout are retained in `inputs/NOTICE` and `inputs/LICENSE`.

From this directory, on Python 3.12:

```sh
python3 -IB check.py
```

The script writes `RESULT.json`.  It replays the native scalar word with
arbitrary 680-dimensional inputs, forward and reverse, and checks all 462,400
coefficients each way and all 3,554 dirty retirements in each direction.  This
lightweight scalar replay does **not** redo physical frame geometry or prove the
retained all-width common-head interface theorem.  The LOCAL q/stage formula
is the pinned caller's normalization under that inherited interface, not a new
physical realization.  The independent polynomial cross-check reuses the
pinned evaluator and is not an independent native compiler.

No candidate in this restricted class exists, so there is no candidate
invoice, complete-stack saving, or achieved gain to compare with the trial
`0.003879929046155`.  The source profiles and other inherited assumptions are
unchanged by this screen.

## Open next questions

* Can a concrete construction introduce a different funded q-dependent channel
  by changing the native helper or scratch boundary while still restoring every
  exterior reader?  It would be outside this screen and require a complete
  physical, adjoint, retirement and invoice replay.
* Can a less restrictive concrete-representation identity preserve the caller
  without being an identity in this universal formal ring?  Any such proposal
  needs an explicit witness and full changed-candidate price.
