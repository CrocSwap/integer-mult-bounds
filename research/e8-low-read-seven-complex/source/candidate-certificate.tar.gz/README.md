# PR370 low-read chain candidate

This candidate changes only phase B of the frozen PR370 word at commit
`b7fe9cdf2da009c947ff6b334c562bc190b30373`. The original E8 construction,
compiler and checker are Dylan Crow's work with Anthropic Claude assistance;
their notices are retained under `upstream/` and in the copied source headers.
The bounded low-read selection and comparison certificate were prepared with
OpenAI Codex assistance. No optimality or novel E8 construction is claimed.

The search considered all nested low-read chains among each target's symbols
of dimension below 7, using the original compiler. Two coordinate rounds
evaluated 2,544 candidates, accepting 19 changes; the second round accepted
none. It reduced low reads from 352 to 306 while keeping 865 helpers.

Run `PYTHONDONTWRITEBYTECODE=1 python3 verify.py` from this directory. It
reconstructs both frozen and candidate words from the pinned parameters and
selection, checks their exact serialized identities, derives paid profiles
from exact nested frame transitions, and encloses the moment difference with
two independent rational engines. `RESULT.json` records the resulting facts.
Run `PYTHONDONTWRITEBYTECODE=1 python3 upstream/checkword.py candidate-word.json.gz upstream`
for the upstream independent source checker.

Every serialized field except B is equal, including the 944 frame definitions.
The two B schedules contain the same multiset of 592 scalar additions, all
targeting output registers and reading registers outside the outputs. These
integer elementary additions commute, proving that the rewritten schedule
preserves the complete upstream abstract linear operator. This does not assert
that the upstream all-positive integer operator is the required signed bit map.
The separately audited D/C sign repair can transfer because D and C are equal.

The per-invocation paid-step delta is
`{1:+20, 2:-12, 3:+6, 4:-28, 7:+14}`. The five-stage census has 22,020 calls,
rank mass 53,680, stock 1,345, and deficit 120, all unchanged. At the frozen
coarse exponent, the normalized moment difference is strictly less than
`-0.000003245531462114143750447468`. The inherited fallback cancels because
the count and stock are unchanged. Under that inherited envelope, the
candidate coarse root lies between `0.000905388584776183837372` and
`0.000905388584776183837373`.

These are source-level equivalence, legality and exact pricing results.
Signed defining semantics, reflected ledgers, native checker admission,
chart/finite/assembly obligations, and a final composed kappa remain the
responsibility of the separate admission and composition lanes.
