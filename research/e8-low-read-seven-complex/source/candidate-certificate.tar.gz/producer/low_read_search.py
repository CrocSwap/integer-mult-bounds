"""Bounded low-read-chain producer search, OpenAI Codex assistance.
Upstream Dylan Crow files/notices retained. F2/paid-profile exploration only.
"""
import os,sys,time,json,ast,random,math,hashlib
from pathlib import Path
os.environ['E8COORD']='ham';sys.dont_write_bytecode=True
import ham2,compile2 as C2,compile as C,frames as Fm,fullword
D=Path(__file__).resolve().parent;OUT=D/'low-read-search';OUT.mkdir(exist_ok=True)
ham2.P.update({ast.literal_eval(k):v for k,v in json.load(open(D/'params-r865.json'))})
t0=time.monotonic();h=ham2.build(0,True);needed=C2.needed_symbols(h);ph=C2.phases(h,needed);cur=C2.choose_low(h,needed,ph)
def evaluate(low):
 w=C2.compile2(h,lowset=low);c,deficit,den,steps=C.evaluate(w);assert deficit==120
 return c,w,steps
best,W,H=evaluate(cur);base=(best,W.stats,dict(H));print('baseline',best,W.stats,flush=True)
options={}
for t in range(120):
 nodes=sorted([u for u in h.need[t]if h.dim[u]<7],key=lambda u:(h.dim[u],u))
 paths=[()]
 for u in nodes:
  paths += [p+(u,)for p in list(paths)if not p or (h.dim[p[-1]]<h.dim[u]and Fm.inside(h.frame[p[-1]],h.frame[u]))]
 options[t]=paths
rng=random.Random(370);history=[];evaluated=0;rounds=0
while rounds<4 and time.monotonic()-t0<240:
 rounds+=1;improvements=0;order=list(range(120));rng.shuffle(order)
 for t in order:
  remain={p for p in cur if p[0]!=t};winner=None
  for chain in options[t]:
   candidate=remain|{(t,u)for u in chain}
   if candidate==cur:continue
   c,w,Hnew=evaluate(candidate);evaluated+=1
   if c>best+1e-15:
    best,winner=c,(candidate,w,Hnew,chain)
  if winner:
   cur,W,H,chain=winner;improvements+=1
   bad=C.f2_check(W);assert not bad[0]and not bad[1]
   row=dict(round=rounds,target=t,low_chain=list(chain),c_float=best,R=W.nh,steps=dict(H),stats=W.stats)
   history.append(row);print('IMPROVE',json.dumps(row,sort_keys=True),flush=True)
   (OUT/'selection.json').write_text(json.dumps({'lowset':sorted([list(x)for x in cur]),'params_sha256':hashlib.sha256((D/'params-r865.json').read_bytes()).hexdigest()},sort_keys=True,indent=2)+'\n')
   fullword.save(fullword.build(W),str(OUT/'candidate-word.json.gz'))
  if time.monotonic()-t0>=240:break
 print('round',rounds,'improvements',improvements,'evaluated',evaluated,'elapsed',time.monotonic()-t0,flush=True)
 if not improvements:break
out=dict(status='PASS_BOUNDED_LOW_READ_CHAIN_SCREEN',baseline={'c_float':base[0],'stats':base[1],'steps':base[2]},best={'c_float':best,'stats':W.stats,'steps':dict(H)},evaluated=evaluated,rounds=rounds,seconds=time.monotonic()-t0,history=history,scope='Finite producer search using source-F2 identity and exact nested root-frame masks; floating moment roots nominate candidates. No signed-integer, all-column, reflected-ledger/native/chart/invoice/assembly or finalkappa admission.')
(OUT/'RESULT.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k!='history'},sort_keys=True),flush=True)
