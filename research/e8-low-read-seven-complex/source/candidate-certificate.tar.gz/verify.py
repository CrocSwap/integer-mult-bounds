#!/usr/bin/env python3
"""Compare PR370 source and low-read selection. OpenAI Codex assistance.

Local operator/profile evidence only; not signed-integer or native admission.
Upstream notices and source files are retained under upstream/ and producer/.
"""
import ast
from collections import Counter
from fractions import Fraction as Q
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode = True
os.environ['E8COORD'] = 'ham'
D = Path(__file__).resolve().parent
sys.path[:0] = [str(D / 'producer'), str(D / 'upstream')]
import compile as C
import compile2 as C2
import frames as Fm
import fullword
import ham2
import moment
import base_two_moment as independent_moment

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(gzip.decompress(p.read_bytes()))

def interval(a, b):
    return {'lower': str(a), 'upper': str(b),
            'lower_decimal': moment.decimal(a), 'upper_decimal': moment.decimal(b)}

baseline = read(D / 'baseline-word.json.gz')
candidate = read(D / 'candidate-word.json.gz')
selection = json.loads((D / 'selection.json').read_text())
assert sha(D / 'producer/params-r865.json') == selection['params_sha256']
ham2.P.clear()
ham2.P.update({ast.literal_eval(k): v for k, v in json.loads((D / 'producer/params-r865.json').read_text())})
hierarchy = ham2.build(0, True)
base_compiled = C2.compile2(hierarchy)
cand_compiled = C2.compile2(hierarchy, lowset={tuple(x) for x in selection['lowset']})
assert fullword.build(base_compiled) == baseline
assert fullword.build(cand_compiled) == candidate
assert all(not x for x in C.f2_check(base_compiled))
assert all(not x for x in C.f2_check(cand_compiled))

# These conditions prove equality of the all-positive integer-linear operators:
# only B differs, every B source is unwritten within B, and each (dst, src)
# elementary transvection has exactly the same multiplicity in both words.
equal_fields = [k for k in baseline if baseline[k] == candidate[k]]
assert set(equal_fields) == set(baseline) - {'B'}
def scalar_B(w):
    return Counter((d, s) for _, d, ss in w['B'] for s in ss)
assert scalar_B(baseline) == scalar_B(candidate)
for w in (baseline, candidate):
    assert all(w['v'] <= d < 2*w['v'] for _, d, _ in w['B'])
    assert all(s < w['v'] or s >= 2*w['v'] for _, _, ss in w['B'] for s in ss)

# Re-census the serialized words, including exact nested frame transitions.
frame_masks = [sum(1 << i for i in f) for f in baseline['frames']]
frame_dims = [Fm.dim(f) for f in frame_masks]
assert all(Fm.closure(f)[0] == f for f in frame_masks)
def census(w):
    cur = w['start'].copy()
    H = Counter()
    def climb(r, f):
        if cur[r] == f:
            return
        assert Fm.inside(frame_masks[cur[r]], frame_masks[f])
        delta = frame_dims[f] - frame_dims[cur[r]]
        assert delta > 0
        H[delta] += 1
        cur[r] = f
    centers = None
    for tag in ('D', 'A', 'B', 'C'):
        if tag == 'B':
            centers = [frame_dims[cur[r]] for r in w['ret']]
            assert all(frame_dims[cur[w['v']+t]] == 0 for t in range(w['v']))
        for f, d, ss in w[tag]:
            for r in [d] + ss:
                climb(r, f)
    for r, f in enumerate(w['final']):
        climb(r, f)
    steps = H.copy()
    H.update(centers)
    five = Counter({r: 5*n for r, n in H.items()})
    five.update({r: 2*w['v'] for r in (14, 7, 18, 4)})
    return steps, H, five

bs, bl, bh = census(baseline)
cs, cl, ch = census(candidate)
delta = {r: cs[r] - bs[r] for r in sorted(bs.keys() | cs.keys()) if cs[r] != bs[r]}
assert delta == {1: 20, 2: -12, 3: 6, 4: -28, 7: 14}
assert sum(bh.values()) == sum(ch.values())
mass = sum(r*n for r, n in bh.items())
assert mass == sum(r*n for r, n in ch.items())
m, W = 40, 1345
assert m*W-mass == 120

# Same count, stock, m and bad envelope: the inherited fallback cancels.
rate = Q(452036410121261, 500000000000000000)
old = moment.moment(bh, m, W, rate, True)
new = moment.moment(ch, m, W, rate, True)
difference = (new[0] - old[1], new[1] - old[0])
assert difference[1] < 0
alt_old = independent_moment.moment(m, W, sorted(bh.items()), rate)
alt_new = independent_moment.moment(m, W, sorted(ch.items()), rate)
alt_difference = (alt_new[0] - alt_old[1], alt_new[1] - alt_old[0])
assert alt_difference[1] < 0
roots = {name: moment.certify(H, m, W, True) for name, H in [('baseline', bh), ('candidate', ch)]}
result = {
    'status': 'PASS_SOURCE_REPLAY_OPERATOR_EQUALITY_AND_EXACT_PAID_MOMENT',
    'scope': 'Preserves the upstream abstract all-positive integer operator. Desired signed bit semantics, reflected ledgers, native admission, and final kappa are not certified here.',
    'source_head': 'b7fe9cdf2da009c947ff6b334c562bc190b30373',
    'baseline_sha256': sha(D / 'baseline-word.json.gz'),
    'candidate_sha256': sha(D / 'candidate-word.json.gz'),
    'selection_sha256': sha(D / 'selection.json'),
    'replayed_both_serialized_words': True,
    'all_equal_fields_except_B': equal_fields,
    'operator_equivalence': {'B_scalar_multisets_equal': True, 'scalar_B_adds': sum(scalar_B(baseline).values()),
        'destinations_outputs_only': True, 'sources_outside_outputs': True, 'B_integer_transvections_commute': True},
    'baseline_steps': dict(sorted(bs.items())), 'candidate_steps': dict(sorted(cs.items())),
    'delta_steps': delta, 'baseline_five_stage_histogram': dict(sorted(bh.items())),
    'candidate_five_stage_histogram': dict(sorted(ch.items())),
    'physical_R': 865, 'm': m, 'W': W, 'calls': sum(ch.values()), 'rank_mass': mass,
    'deficit': m*W-mass, 'comparison_rate': str(rate),
    'exact_normalized_moment_delta': interval(*difference),
    'independent_base_two_moment_delta': interval(*alt_difference),
    'fallback_cancels_because_count_and_stock_unchanged': True,
    'conditional_coarse_roots_with_inherited_bad_envelope': roots,
}
(D / 'RESULT.json').write_text(json.dumps(result, sort_keys=True, indent=2) + '\n')
print(json.dumps(result, sort_keys=True, indent=2))
