# P104 binary packet rewrite: independent local audit

## Result

The Pro archive's specified three-mutable-send template is **UNSAT** in its
retained-stock packet relaxation. This is a scoped negative result, not a
constructive κ bound or evidence that all other templates fail. All 128
coefficient assignments were rejected; an independently implemented literal
replay establishes the same separator for all 128 at once. The retained
packets give each chart at least the linear information supplied by the
declared fixed sends; final local decoders are unrestricted in this model.
The rejection therefore cannot be explained away by a fixed final decoder.

Pins and inputs:

* Downloaded `p104_binary_rewrite.zip` SHA-256
  `4036b9121ee484c1bd283b480ffdea995e354f0920358bb89b8191a73aeb73ab`.
  All 16 archive-manifest entries match; the ZIP has no symlink or escaping
  path entries. Static inspection found only standard-library imports and no
  dynamic execution, shell, network, or deletion calls in the three scripts.
* #7830 head supplied for the task: `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`.
  Its `research/p104-mixed-rank-supplier/SOURCES.json` locks the native input
  below and also refers to older #7830 source snapshot `14c74c6a…` for its
  chart-306 artifacts. The live-head identification was separately checked
  by the coordinating agent; this audit checks the Git object and blobs.
* Native scientific source `89a67c404226d51028e135de2b9169e9020d57af`,
  `research/p104-iterated-returns/binary/WORD.json.gz`. The archive word is
  byte-identical to this Git blob: SHA-256
  `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.
  Canonical sorted JSON SHA-256 is
  `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
* The archive's baseline `AUDIT.json` and `BIT.json` match their parsed JSON
  from head `87fbf4f7…`; baseline `REPLAY.json` matches the native source.
  Each archive file has exactly one extra terminal newline versus its Git
  blob, so the archive README's claim that these files are unchanged is true
  semantically, but **not byte-for-byte**. Exact hashes are in
  `source-pin-check.json`.

## Scope and literal evidence

Remove send 2418, clock 8305, chart 330→510, grade 1. Re-encode 2421 at
clock 8318, 331→510, and 2921 at clock 10292, 510→328. Repurpose 2922 at
clock 10295, originally 510→1 grade 1, as 330→1 grade 2. Other send
incidences and equations remain fixed; packets are retained for the
relaxation; bridge label 3553 and owner 411 are preserved. All 138 final
charts may freely re-decode their respective own output demands.

Independent code `independent_audit.py` interprets the pinned literal
instruction stream without importing the archive's code. It checked original
ADD/MOVE chart locality, no pre-output post-send mutation, all 680 baseline
output rows and final chart assignments, and re-extracted and compared every
formal row and label in the 3 sender stocks and 138 terminal stocks. Its
independent bit-sliced replay evaluates all 128 tuples of source choices:

* 2421 stock labels `[1979, 1985, 2295]`: 8 XOR choices;
* 2921 stock `[2421]`: 2 XOR choices;
* new 2922 stock `[1967, 1973, 2294]`: 8 XOR choices.

For `h` with only `h113 = h621 = 1`, the removed original 2418 has value 1.
The three 2421 inputs and the single 2921 input all have value 0 for every
choice. New 2922's inputs are `(1,0,0)`, but its destination chart 1 has no
paid outgoing sends. At chart 527 all local stock labels
`[2817,2820,2823,3414]` evaluate to zero for every one of the 128 choices;
the required owner-113 output `x113 + x2` evaluates to 1. On zero input, the
same stock and output evaluate to 0. Thus even an arbitrary (not merely
linear) final function of that stock cannot decode this demand for any of
the 128 linear sender assignments. Formal stock rows show 3414 has `q=0x2`
and zero input part on `h`; its only mutable port contribution is 2921.

This says nothing about a template with extra recoded fixed senders, altered
incidences, added upstream information, different deadlines, or another
omission. It is a packet-model obstruction: it does not reproduce the full
literal transpose, dirty cleanup, finite compiler, or outer application.

## Generic three-send theorem and controls

Let a sender's formal stock space be `S ≤ GF(2)^n ⊕ GF(2)^k`. Project `S` to
the mutable-send coordinates to obtain `U`, and let `F` be the input parts
of `S ∩ (GF(2)^n ⊕ 0)`. Choose a linear section `a: U→GF(2)^n` so that
`(a(b), b) ∈ S`. Every permitted local payload is exactly

`z_i = (a_i(b_i) + f_i) x + b_i z`, with `f_i ∈ F_i`.

For a chronological stock, `b_i` only has coordinates before `i`. Fixing the
three `b_i` gives strictly lower triangular `B`, so
`z = (I-B)^(-1) A x`. The resulting `z` is affine-linear in the free
coefficients for the `f_i`; each frozen observation is therefore a linear
system. Since `rank U_i ≤ i`, sender-dependency choices total at most
`2^(0+1+2)=8`. This bound alone does **not** count choices for unrestricted
terminal decoders.

At one terminal, use its own `F`, `U`, and section. If the demand space is
`D`, set `q = dim((D+F)/F)` and choose demand representatives forming a
basis of `(D+F)/F`. After evaluating `z`, the local available space is
`F + {a(h)+h z : h∈U}`. The full demand space is available if and only if
each representative is available: the rest differ from their combinations
by elements of `F`, which remain available for every choice of sends.
Each representative needs one mask `h ∈ U`; for fixed masks the constraints
remain linear modulo `F`. A necessary early cut is `q ≤ rank(U)`; it is not
alone sufficient. There are at most `2^(q·rank(U))` mask choices at that
terminal. Across terminals, multiply these factors without pooling their
stocks. This proves the representative reduction and branch bound for the
supplied fixed causal template; it does not prove that the template was
extracted or priced correctly in an unrelated instance.

`theorem_controls.py` independently enumerates sender coefficients and
terminal stock spans for 800 seeded, small three-send cases and compares both
solver backends. It independently enumerates formal row spaces to compare
quotient and port dimensions: 626 cases have a quotient rank at least two,
255 have multiple terminals, and 550 combine fixed and free observations.
There were 170 SAT and 630 UNSAT; 20 instances whose algebraic branch count
exceeded the explicit test budget were skipped. The archive's separate
self-test passes 300 random cases against exhaustive coefficients.

A concrete frozen-versus-free control shares the same three sender stocks,
terminal stock and demanded row space: a frozen readout `z0 = x0+x3` is
UNSAT, while unrestricted local decoding is SAT with payloads
`(z0,z1,z2)=(x0,x2,x2)` and decoder masks `(5,6,3)`. The three demands have
quotient rank 2 modulo `F=span(x3)`, and terminal port rank 2. This confirms
that fixed-readout UNSAT does not generally imply free-decoder UNSAT; the
literal P104 two-input separator above independently resolves that caveat
for the tested template. A zeroed actual P104 rejection separator was
rejected, as was a self-dependent first sender. The package chain and bypass
controls both returned SAT with checked witnesses.

## Primary literature

The relevant passages of both cited papers were reviewed directly:

* [Koetter and Médard, *An Algebraic Approach to Network Coding*](https://www.mit.edu/~medard/mpapers/networkcoding.pdf),
  Sections III–V: transfer-matrix algebra, general demand feasibility, and
  a failed-edge model. Their existence results over suitable or extension
  fields do not by themselves prove scalar GF(2) feasibility here.
* [Byrne and Calderini, *Error Correction for Index Coding With Coded Side Information*](https://arxiv.org/pdf/1506.00785),
  Lemma III.5 and Definition III.8/Lemma III.9: a common-broadcast decoding
  row-space condition and generalized min-rank. This is related context,
  not a proof of this distributed, chronological packet-template theorem.
  Their notation `κ(I)` is not the P104 saving parameter.

## Reproduction

From this directory, with Python 3 and the local Git object store available:

```sh
python3 -I -B source_pin_check.py --repo /absolute/path/to/pinned/git-checkout
python3 -I -B independent_audit.py
python3 -I -B p104_binary_rewrite/causal_core.py self-test
python3 -I -B p104_binary_rewrite/causal_core.py solve p104_binary_rewrite/core.json fresh-core-result.json --max-branches 128
python3 -I -B p104_binary_rewrite/causal_core.py verify p104_binary_rewrite/core.json fresh-core-result.json
python3 -I -B p104_binary_rewrite/verify_diamond_certificates.py
python3 -I -B p104_binary_rewrite/verify_diamond_certificates.py --common-probe
python3 -I -B p104_binary_rewrite/causal_core.py solve p104_binary_rewrite/toy-chain.json chain-control.json
python3 -I -B p104_binary_rewrite/causal_core.py solve p104_binary_rewrite/toy-bypass.json bypass-control.json
python3 -I -B theorem_controls.py
```

`source_pin_check.py --repo PATH` can specify another local Git object store.
`fresh-core-result.json` is the package's 128-branch certificate; the other
JSONs and logs record the independent controls. No upstream publication or
other external mutation was performed.
