#!/usr/bin/env python3
"""Independently replay pinned literal inputs and the two-coordinate probe.

Does not import code from the consulted archive. The stored arrival stocks
are intentionally retained, making them a relaxation of physical lifetimes.
"""
import collections
import gzip
import hashlib
import itertools
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE / 'p104_binary_rewrite'
raw = (PKG / 'WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
word = json.loads(gzip.decompress(raw))
core = json.loads((PKG / 'core.json').read_text())
n = 680
assert len(word['start']) == len(word['final']) == n
assert core['n'] == n and core['fixed'] == []
program = word['program']
cutoff = next(i for i, op in enumerate(program) if op[0] == 'SWAP')
assert cutoff == 38724

# Baseline literal evaluation on all 680 basis columns packed in integers.
# Check chart locality, original pre-output values, and actual SWAP owners.
v = {i: 1 << i for i in range(n)}
where = dict(enumerate(word['start']))
already_moved = set()
for clock, op in enumerate(program[:cutoff]):
    kind, dest, *args = op
    if kind == 'INIT':
        assert dest not in v
        v[dest], where[dest] = 0, args[0]
    elif kind == 'ADD':
        donor, site = args
        assert dest not in already_moved
        assert where[dest] == where[donor] == site
        v[dest] ^= v[donor]
    elif kind == 'MOVE':
        src, dst = args
        assert dest not in already_moved and where[dest] == src
        where[dest] = dst
        already_moved.add(dest)
    else:
        raise AssertionError((clock, op))

swaps = [op for op in program[cutoff:] if op[0] == 'SWAP']
assert len(swaps) == n
for owner, op in enumerate(swaps):
    assert op[:2] == ['SWAP', owner]
    scratch = op[2]
    desired = (1 << owner) ^ ((1 << (owner - 111)) if 111 <= owner < 222 else 0)
    assert v[scratch] == desired, (owner, scratch)
    assert where[scratch] == word['final'][owner]

# Replay the relaxation with 3 additional formal coordinates packed above x.
# Recording stock values at time of arrival avoids aliasing by later writes.
signal = {i: 1 << i for i in range(n)}
stock = collections.defaultdict(list)
for i, site in enumerate(word['start']):
    stock[site].append((i, signal[i]))
mutable = {2421: 0, 2921: 1, 2922: 2}
senders = []
for clock, op in enumerate(program[:cutoff]):
    kind, target, *args = op
    if kind == 'INIT':
        signal[target] = 0
    elif kind == 'ADD':
        signal[target] ^= signal[args[0]]
    elif kind == 'MOVE':
        src, dst = args
        if target == 2418:
            signal[target] = 0
            continue
        if target in mutable:
            if target == 2922:
                src = 330
            senders.append((target, clock, src, dst, list(stock[src])))
            signal[target] = 1 << (n + mutable[target])
        stock[dst].append((target, signal[target]))
    else:
        raise AssertionError((clock, op))

assert [(a, b, c, d) for a, b, c, d, _ in senders] == [
    (2421, 8318, 331, 510), (2921, 10292, 510, 328),
    (2922, 10295, 330, 1)]
for got, expected in zip(senders, core['senders']):
    label, clock, src, dst, rows = got
    assert (expected['label'], expected['clock'], expected['source'], expected['destination']) == (label, clock, src, dst)
    assert expected['stock_ids'] == [i for i, _ in rows]
    assert [(int(r['p'], 0) | (int(r['q'], 0) << n)) for r in expected['rows']] == [value for _, value in rows]

final_sites = sorted(set(word['final']))
assert len(final_sites) == len(core['terminals']) == 138
for site, terminal in zip(final_sites, core['terminals']):
    assert terminal['chart'] == site
    assert terminal['stock_ids'] == [i for i, _ in stock[site]]
    assert [(int(r['p'], 0) | (int(r['q'], 0) << n)) for r in terminal['rows']] == [x for _, x in stock[site]]
    owners = [i for i, dest in enumerate(word['final']) if dest == site]
    assert terminal['owners'] == owners
    assert [int(d, 0) for d in terminal['demands']] == [(1 << i) ^ ((1 << (i - 111)) if 111 <= i < 222 else 0) for i in owners]

# 128 scalar cases, evaluated at once in independent 128-bit lanes. Each lane
# corresponds to one assignment to the three local sender coefficient masks.
choices = list(itertools.product(range(8), range(2), range(8)))
lanes = (1 << len(choices)) - 1
def choice_mask(which, bit):
    return sum(1 << i for i, item in enumerate(choices) if item[which] & (1 << bit))

values = {i: lanes if i in (113, 621) else 0 for i in range(n)}
seen = collections.defaultdict(list)
for i, site in enumerate(word['start']):
    seen[site].append(i)
allzero = 0
notes = {}
for clock, op in enumerate(program[:cutoff]):
    kind, target, *args = op
    if kind == 'INIT':
        values[target] = 0
    elif kind == 'ADD':
        values[target] ^= values[args[0]]
    elif kind == 'MOVE':
        src, dst = args
        if target == 2418:
            assert values[target] == lanes
            values[target] = 0
            continue
        if target in mutable:
            if target == 2922:
                src = 330
            ids = seen[src]
            expected_ids = {2421: [1979, 1985, 2295], 2921: [2421], 2922: [1967, 1973, 2294]}[target]
            assert ids == expected_ids
            prior = [values[i] for i in ids]
            notes[str(target)] = ['all 1' if x == lanes else 'all 0' if x == 0 else 'mixed' for x in prior]
            signal_value = 0
            for bit, x in enumerate(prior):
                signal_value ^= x & choice_mask(mutable[target], bit)
            values[target] = signal_value
        seen[dst].append(target)
    else:
        raise AssertionError((clock, op))

assert notes == {'2421': ['all 0'] * 3, '2921': ['all 0'], '2922': ['all 1', 'all 0', 'all 0']}
assert seen[527] == [2817, 2820, 2823, 3414]
assert all(values[i] == allzero for i in seen[527])
assert not [op for op in program if op[0] == 'MOVE' and op[2] == 1]
assert word['final'][113] == 527
assert (1 ^ 0) == 1  # x113 + x2 on the h113=h621=1 probe

out = {
    'literal_word_sha256': hashlib.sha256(raw).hexdigest(),
    'literal_program_cutoff': cutoff,
    'literal_add_and_move_chart_locality': 'PASS',
    'baseline_desired_owner_rows_and_final_charts': len(swaps),
    'retained_stock_formal_sender_rows_exact_match': len(senders),
    'retained_stock_formal_terminal_rows_exact_match': len(final_sites),
    'source_ids': {str(i): [a for a, _ in rows] for i, _, _, _, rows in senders},
    'common_probe_input_ones': [113, 621],
    'choice_lanes': len(choices),
    'source_values': notes,
    'omitted_2418_original_probe_value': 1,
    'chart527_ids': seen[527],
    'chart527_values_every_lane': [0] * len(seen[527]),
    'chart527_owner_113_demand_on_probe': 1,
    'chart1_paid_outgoing_edges': 0,
}
(HERE / 'independent-audit.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, sort_keys=True))
