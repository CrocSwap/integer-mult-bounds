P104 exact binary local rewrite consultation
==========================================

Result and scope
----------------
This package contains an executable exact GF(2) solver for nominated local
chronological packet templates, and a checked negative certificate for one
concrete cost-decreasing template from the public pinned word. It does not
contain a constructive kappa >= 0.00388 witness. No upstream mutation was made.

The generic solver is causal_core.py and needs only Python 3. Its input schema
and commands are documented in its opening docstring. The extraction of a
formal core from a primitive source is an explicit separate obligation.

Run from this extracted directory
--------------------------------
python3 causal_core.py self-test
python3 export_core.py
python3 causal_core.py solve core.json fresh-result.json --max-branches 128
python3 causal_core.py verify core.json fresh-result.json
python3 verify_diamond_certificates.py
python3 verify_diamond_certificates.py --common-probe
python3 causal_core.py solve toy-chain.json chain-result.json
python3 causal_core.py solve toy-bypass.json bypass-result.json

The pinned core returns UNSAT with backend enumerate after all 128 source
assignments. Both toy cores return SAT. The common-probe verifier evaluates
the original instruction list directly on separating inputs. It does not
rely on the source project's verifier or on the solver's Gaussian elimination.

The self-test compares all three solver backends with exhaustive original
coefficient search on 300 deterministic small random cores. It also checks
the multiplicative chain example, forbidden future/self dependencies, damaged
separators, and incomplete certificate coverage. These checks support the
implementation; the mathematical proof below establishes the family theorem.

The searched instance-level family
---------------------------------
Zero-based program clocks and packet/owner labels are used throughout.
Remove packet 2418 at clock 8305, originally chart 330 -> 510, grade 1.
Change the equation of surviving packet 2421 at clock 8318, 331 -> 510.
Change the equation of surviving packet 2921 at clock 10292, 510 -> 328.
Repurpose the old 2922 slot at clock 10295 as chart 330 -> 1, grade 2,
instead of the original 510 -> 1, grade 1.
Keep all other sender equations and all other incidences fixed. Allow all
138 final charts to re-decode from their own final stock. Protect bridge
3553 and owner 411. Source stocks are exactly

  2421    {1979, 1985, 2295}, any of 8 XOR combinations;
  2921    {2421}, either 0 or 2421;
  new2922 {1967, 1973, 2294}, any of 8 XOR combinations.

There are 128 choices. The first failing demands under the search order are
x3 at chart 1 for 64 choices, x222 at chart 1 for 32, and x2+x113 at chart
527 for 32. The displayed search order has no mathematical significance.
All 128 choices have the same stronger causal obstruction below.

The common separating input
---------------------------
Let h have coordinates h113=h621=1 and all other coordinates zero.
The original packet 2418 evaluates to 1. Every stock row available to the
mutable 2421 sender evaluates to zero, so every possible 2421 evaluates to
zero. Mutable 2921 can use only that zero arrival. New 2922 can be nonzero,
but goes to chart 1, which has no paid outgoing packet, and cannot affect
chart 527. Its source stock evaluates to 1,0,0, not all zero.

The available chart-527 packets are 2817,2820,2823,3414. In the formal core
their evaluations on h are 0,0,0,z1, where z1 is mutable packet 2921.
Consequently all four values are zero for every encoding choice, while
the required output y113=x113+x2 is 1. The zero input gives the same stock
with required output 0. No decoder can distinguish these inputs.

This certificate rules out the specified packet relaxation. It therefore
also rules out physical implementations inside that template. It does not
rule out other incidences, additional changed senders, or other contractions.

Exact generic method
--------------------
After the declared omissions, replace k selected send payloads by formal
symbols z0,...,z(k-1) in actual chronological order. Replay fixed equations
over GF(2)^(n+k). At sender i its available stock is P_i*x + Q_i*z, where
Q_i has no coordinate at i or later. Basis reduction must use the complete
formal rows [P_i | Q_i], not just baseline realised input rows.

Define F_i={lambda*P_i : lambda*Q_i=0}. Choose a linear section a_i0(b)
such that [a_i0(b) | b] is in the formal stock space, for b in rowspace Q_i.
Then every legal scalar equation is, exactly,

  z_i = (a_i0(b_i)+f_i)*x + b_i*z,  f_i in F_i.

Branch on b_i only. There are at most 2^(k(k-1)/2) sender dependency branches,
hence at most 2 for two selected sends and 8 for three. With B the strictly
lower triangular matrix of b_i and A the rows a_i0(b_i)+f_i,

  z = (I-B)^(-1) A x.

Fixing B leaves every frozen observation equality linear in the free F_i
coefficients. An infeasible system L*theta=r exports a dual y with yL=0 and
yr=1. The result verifier checks every branch and its contradiction.

For a re-decoded terminal c use the same split on its actual local stock
[P_c | Q_c]. Let q_c=dim((D_c+F_c)/F_c), where D_c is its required row space.
Reject immediately if q_c > rank Q_c. Otherwise choose q_c representative
demands and branch on their dependency masks h in rowspace Q_c. Their
equations d=a_c0(h)+f_c+h*(I-B)^(-1)A are linear after the masks are fixed.
The branch bound is 2^(sum rank Q_i + sum q_c rank Q_c). Decoder basis
changes stay within a single chart and deadline; no cross-chart stock is
pooled. Original labelled decoders are reconstructed and verified.

For frozen observation Y=R*x+C*z with target T*x, the safe first cut is
rank[C | T+R]=rank C. A zero C row with a nonzero residual is a certificate.
This cut must not freeze an observation whose readout is being changed.

All 138 free decoders make the section/readout branch count 2^68 for this
particular core. However, all source choices number only 128. The automatic
backend chooses full source enumeration instead and tests each chart's
actual evaluated stock span. Every failure exports a separating input.
The branch budget has an explicit INCOMPLETE outcome, never a false UNSAT.

The theorem is a derivation in this consultation, not a theorem attributed
to either cited paper. It is exact for a fixed causal packet template and
the source/readout spaces supplied by its extractor.

Price and the remaining positive obligations
-------------------------------------------
The two-grade-1 to one-grade-2 saving at kappa=.00388 is
2-2^(.99612), approximately .00537159566904415576936040448099 per native call.
It exceeds the raw binary deficit per call, approximately
.00076976000528382195558. With 36 repetitions the hypothetical raw binary
margin would be approximately +.1656660838953720173. No tested candidate
achieves it because every candidate fails the exact packet equations.

The 70-digit ordinary profile computations reproduce the supplied binary
and rational margins. They are not new directed interval certificates.
The binary and rational gates remain separate, with 36 and 48 calls.

Any SAT result from this solver is only a packet nominee. Its literal
primitive must preserve each productive owner, respect chart containment
and chronology, pay for every transfer and scratch lifecycle, restore the
required clean and dirty state, and independently realise the literal
transpose. Candidate-specific separation, stock, erasure, precision, and
the complete conditional outer application remain to be checked. The five
inherited conditions remain native_all_columns, owned_erasure, compiler,
precision_tape, and analytic_recovery.

Pinned public sources and credit
--------------------------------
Canonical main
e54523517d0f03e58352e647c403a5af3e525a57

Native word at scientific source commit
89a67c404226d51028e135de2b9169e9020d57af
https://github.com/CrocSwap/integer-mult-bounds/blob/89a67c404226d51028e135de2b9169e9020d57af/research/p104-iterated-returns/binary/WORD.json.gz

Compressed SHA256
d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9
Canonical sorted JSON SHA256
d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d
Decompressed bytes SHA256
3bf6e12edfc00aa2ec72d65c83c850d09de377c47fe97b9cf8c2b1b4161741f5

Baseline audit and profiles
https://github.com/Clear1nsight/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier
baseline-AUDIT.json and baseline-BIT.json are from this audit.
baseline-REPLAY.json is from the native binary directory above.

Reviews inspected for their declared scopes
https://github.com/CrocSwap/integer-mult-bounds/pull/7985
https://github.com/CrocSwap/integer-mult-bounds/pull/7978
https://github.com/CrocSwap/integer-mult-bounds/pull/7983
https://github.com/CrocSwap/integer-mult-bounds/pull/7975
https://github.com/CrocSwap/integer-mult-bounds/pull/7973

The native source, caller, and underlying construction retain the credit
of their original repository authors. This consultation supplies a new
local method and scoped negative test, not the underlying construction.
The included WORD.json.gz and baseline receipts are unchanged public data.
The repository identifies its licence as Apache-2.0.

Primary academic references
---------------------------
Ralf Koetter and Muriel Medard. An Algebraic Approach to Network Coding.
IEEE/ACM Transactions on Networking 11(5), 782-795, 2003.
https://www.mit.edu/~medard/mpapers/networkcoding.pdf
Sections III-A, IV-B, and V give transfer algebra, general-demand
polynomial feasibility, and failed-edge modelling. Extension-field
multicast results do not imply scalar GF(2) feasibility here.

Eimear Byrne and Marco Calderini. Error Correction for Index Coding With
Coded Side Information. arXiv:1506.00785v2, 2016.
https://arxiv.org/pdf/1506.00785
Lemma III.5 and Definition III.8/Lemma III.9 give row-space decoding and
generalised minrank for a common broadcast with coded side information.
Distributed sender incidence and timing must be imposed separately here.
