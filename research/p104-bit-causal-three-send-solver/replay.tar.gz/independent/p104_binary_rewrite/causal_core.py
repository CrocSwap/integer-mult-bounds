#!/usr/bin/env python3
"""Exact GF(2) synthesis for a small chronological scalar-send core.

This is a PACKET solver, not a primitive/ownership/price certification tool.
No third-party dependencies. Input JSON describes an already extracted core.

Each row {"p": "0x...", "q": "0x..."} means p*x + q*z. The n low
coordinates of p are original independent inputs. Bit i of q is the selected
send z_i. At sender i only bits below i are legal. Stock rows MUST be formed
by causal symbolic replay of the fixed network, after the declared omissions.
Chart legality and physical lifetimes are obligations of that extractor.

Schema
  n: input dimension
  senders: [{name, rows:[{p,q},...]}], in actual chronological order
  fixed: [{name,p,q,target}], literal observations required to equal target*x
  terminals: [{name,rows:[{p,q},...],demands:["0x...",...]}]
  meta: arbitrary provenance, family and chart metadata (retained in digest)

For each stock decompose rowspace[P|Q] into a pure-input space F and a
section of rowspace Q. Branch on only the section choices. All remaining
coefficients in F are solved by binary Gaussian elimination. Fixed readouts
need at most 2^(k*(k-1)/2) branches. Terminal redecoding adds at most
2^sum(q_c*rank(Q_c)), q_c=dim((F_c+D_c)/F_c).

When enumerating all source choices is cheaper, the adaptive backend does
that instead and checks each terminal's actual stock span directly. Each
failed assignment exports either a fixed-observation mismatch or a vector
annihilating the terminal stock but not its required demand. This avoids
branching over terminal decoder masks without relaxing the decoder rules.

Commands
  python3 causal_core.py solve core.json result.json --max-branches 65536
  python3 causal_core.py verify core.json result.json
  python3 causal_core.py self-test

UNSAT includes a dual contradiction for every branch, or a sufficient rank
cut. INCOMPLETE never means UNSAT. A SAT result includes concrete source
coefficients and a decoder for every demand, replayed against the core.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
from pathlib import Path
import random

if not __debug__:
    raise RuntimeError("Certificate checks require Python without -O or -OO")


def number(x):
    return int(x, 0) if isinstance(x, str) else int(x)


def bits(x):
    while x:
        low = x & -x
        yield low.bit_length() - 1
        x ^= low


def xor_all(xs):
    result = 0
    for x in xs:
        result ^= x
    return result


def canonical_hash(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def basis(rows):
    pivots = {}
    for row in rows:
        r = row
        while r:
            p = r.bit_length() - 1
            if p not in pivots:
                pivots[p] = r
                break
            r ^= pivots[p]
    return [pivots[p] for p in sorted(pivots, reverse=True)]


def reduce_row(row, bs):
    for b in bs:
        if not row:
            break
        if row & (1 << (b.bit_length() - 1)):
            row ^= b
    return row


def representation(row, rows):
    pivots = {}
    for i, r in enumerate(rows):
        mask = 1 << i
        while r:
            p = r.bit_length() - 1
            if p not in pivots:
                pivots[p] = (r, mask)
                break
            v, m = pivots[p]
            r ^= v
            mask ^= m
    result = 0
    while row:
        p = row.bit_length() - 1
        if p not in pivots:
            return None
        v, m = pivots[p]
        row ^= v
        result ^= m
    return result


def split_stock(rows):
    """Return F=kernel(Q)*P and a linear section of the attainable Q rows."""
    qpivots, pure = {}, []
    for p, q in rows:
        while q:
            j = q.bit_length() - 1
            if j not in qpivots:
                qpivots[j] = (p, q)
                break
            a, b = qpivots[j]
            p ^= a
            q ^= b
        if not q:
            pure.append(p)
    f = basis(pure)
    sections = [(reduce_row(p, f), q) for _, (p, q) in sorted(qpivots.items())]
    return f, sections


def section_choices(sections):
    return [(xor_all(sections[j][0] for j in bits(mask)),
             xor_all(sections[j][1] for j in bits(mask)))
            for mask in range(1 << len(sections))]


def parse_core(core):
    n = core["n"]
    if not isinstance(n, int) or n <= 0:
        raise ValueError("n must be a positive integer")
    k = len(core["senders"])
    def row(r, causal=k):
        p, q = number(r["p"]), number(r["q"])
        if p < 0 or p >> n or q < 0 or q >> causal:
            raise ValueError("out-of-range coordinate or future/self port in sender stock")
        return p, q
    sources = [[row(r, i) for r in s["rows"]] for i, s in enumerate(core["senders"])]
    fixed = []
    for r in core.get("fixed", []):
        p, q = row(r)
        target = number(r["target"])
        if target < 0 or target >> n:
            raise ValueError("invalid target")
        fixed.append((p ^ target, q))
    terminals = []
    for t in core.get("terminals", []):
        ds = [number(d) for d in t["demands"]]
        if any(d < 0 or d >> n for d in ds):
            raise ValueError("invalid demand")
        terminals.append(([row(r) for r in t["rows"]], ds))
    return n, k, sources, fixed, terminals


def prepare(core):
    n, k, sources, fixed, terminals = parse_core(core)
    # Eliminate the port incidence of literal constraints. This does not
    # physically pool chart stocks; it only row-reduces equations to check.
    pivots = {}
    for i, (p, q) in enumerate(fixed):
        combination = 1 << i
        while q:
            j = q.bit_length() - 1
            if j not in pivots:
                pivots[j] = (p, q, combination)
                break
            a, b, c = pivots[j]
            p ^= a
            q ^= b
            combination ^= c
        if not q and p:
            return {"cut": {"kind": "fixed_incidence", "combination": hex(combination), "residual": hex(p)}}
    fixed_reduced = [(p, q) for p, q, _ in pivots.values()]
    sn = [split_stock(s) for s in sources]
    tn = []
    for ti, (rows, demands) in enumerate(terminals):
        f, sections = split_stock(rows)
        accum = f[:]
        representatives = []
        for d in demands:
            if reduce_row(d, accum):
                representatives.append(d)
                accum = basis(accum + [d])
        if len(representatives) > len(sections):
            return {"cut": {"kind": "terminal_quotient", "terminal": ti,
                            "pure_basis": list(map(hex, f)),
                            "demand_quotient_rank": len(representatives),
                            "port_rank": len(sections)}}
        tn.append((f, sections, representatives))
    choices = [section_choices(s) for _, s in sn]
    terminal_indices = []
    for ti, (f, s, reps) in enumerate(tn):
        for d in reps:
            terminal_indices.append((ti, d))
            choices.append(section_choices(s))
    count = 1
    for c in choices:
        count *= len(c)
    return dict(n=n, k=k, sources=sources, fixed=fixed_reduced, fixed_all=fixed,
                terminals=terminals,
                sn=sn, tn=tn, choices=choices, terminal_indices=terminal_indices,
                total_branches=count, variables=sum(len(f) for f, _ in sn))


def branch_equations(prepared, choice):
    n, k = prepared["n"], prepared["k"]
    zconst, zcoefs = [], []
    var_offset = 0
    for i, (f, _) in enumerate(prepared["sn"]):
        a, b = choice[i]
        coefs = {var_offset + j: v for j, v in enumerate(f)}
        var_offset += len(f)
        for j in bits(b):
            a ^= zconst[j]
            for v, value in zcoefs[j].items():
                coefs[v] = coefs.get(v, 0) ^ value
        zconst.append(a)
        zcoefs.append({j: v for j, v in coefs.items() if v})
    equations = []
    def append_equation(p, q, quotient=()):
        const, coefs = p, {}
        for j in bits(q):
            const ^= zconst[j]
            for v, value in zcoefs[j].items():
                coefs[v] = coefs.get(v, 0) ^ value
        const = reduce_row(const, quotient)
        masks = {}
        for v, value in coefs.items():
            for bit in bits(reduce_row(value, quotient)):
                masks[bit] = masks.get(bit, 0) ^ (1 << v)
        for bit in sorted(set(masks) | set(bits(const))):
            mask, rhs = masks.get(bit, 0), (const >> bit) & 1
            if mask or rhs:
                equations.append((mask, rhs))
    for p, q in prepared["fixed"]:
        append_equation(p, q)
    for j, (ti, demand) in enumerate(prepared["terminal_indices"]):
        a, b = choice[k + j]
        append_equation(demand ^ a, b, prepared["tn"][ti][0])
    return equations


def gaussian(equations):
    pivots = {}
    for i, (row, rhs) in enumerate(equations):
        dual = 1 << i
        while row:
            p = row.bit_length() - 1
            if p not in pivots:
                pivots[p] = (row, rhs, dual)
                break
            r, b, d = pivots[p]
            row ^= r
            rhs ^= b
            dual ^= d
        if not row and rhs:
            return None, dual
    solution = 0
    for p in sorted(pivots):
        row, rhs, _ = pivots[p]
        if ((row & solution).bit_count() & 1) ^ rhs:
            solution |= 1 << p
    assert all(((row & solution).bit_count() & 1) == rhs for row, rhs in equations)
    return solution, None


def make_witness(core, pr, choice, solution):
    z, coefficients = [], []
    offset = 0
    for i, (f, _) in enumerate(pr["sn"]):
        p, q = choice[i]
        for j, value in enumerate(f):
            if (solution >> (offset + j)) & 1:
                p ^= value
        offset += len(f)
        coefficient = representation(p | (q << pr["n"]),
                                     [a | (b << pr["n"]) for a, b in pr["sources"][i]])
        assert coefficient is not None
        coefficients.append(hex(coefficient))
        z.append(p ^ xor_all(z[j] for j in bits(q)))
    decoders = []
    for rows, demands in pr["terminals"]:
        evaluated = [p ^ xor_all(z[j] for j in bits(q)) for p, q in rows]
        masks = [representation(d, evaluated) for d in demands]
        assert all(m is not None for m in masks)
        decoders.append(list(map(hex, masks)))
    witness = {"sender_coefficients": coefficients, "payload_rows": list(map(hex, z)),
               "terminal_decoders": decoders}
    verify_witness(core, witness)
    return witness


def verify_witness(core, witness):
    n, k, sources, fixed, terminals = parse_core(core)
    coeff = list(map(number, witness["sender_coefficients"]))
    assert len(coeff) == k
    z = []
    for i, rows in enumerate(sources):
        assert coeff[i] >= 0 and not coeff[i] >> len(rows)
        evaluated = [p ^ xor_all(z[j] for j in bits(q)) for p, q in rows]
        z.append(xor_all(evaluated[j] for j in bits(coeff[i])))
    assert z == list(map(number, witness["payload_rows"]))
    assert all(p == xor_all(z[j] for j in bits(q)) for p, q in fixed)
    assert len(witness["terminal_decoders"]) == len(terminals)
    for (rows, demands), masks in zip(terminals, witness["terminal_decoders"]):
        assert len(masks) == len(demands)
        values = [p ^ xor_all(z[j] for j in bits(q)) for p, q in rows]
        for demand, mask in zip(demands, map(number, masks)):
            assert mask >= 0 and not mask >> len(rows)
            assert xor_all(values[j] for j in bits(mask)) == demand
    return True


def source_assignment_count(pr):
    return (1 << pr["variables"]) * (1 << sum(len(s) for _, s in pr["sn"]))


def source_assignments(pr):
    """Enumerate every section/pure-space source choice, in a fixed order."""
    for choice in itertools.product(*pr["choices"][:pr["k"]]):
        for solution in range(1 << pr["variables"]):
            z, offset = [], 0
            for i, (f, _) in enumerate(pr["sn"]):
                p, q = choice[i]
                p ^= xor_all(value for j, value in enumerate(f)
                             if (solution >> (offset + j)) & 1)
                offset += len(f)
                z.append(p ^ xor_all(z[j] for j in bits(q)))
            yield choice, solution, z


def assignment_failure(core, pr, z):
    """Return a concrete separation certificate, or None if all demands fit."""
    for fi, (p, q) in enumerate(pr["fixed_all"]):
        residual = p ^ xor_all(z[j] for j in bits(q))
        if residual:
            return {"kind": "fixed_mismatch", "observation": fi,
                    "residual": hex(residual), "input": hex(residual & -residual)}
    for ti, (rows, demands) in enumerate(pr["terminals"]):
        evaluated = [p ^ xor_all(z[j] for j in bits(q)) for p, q in rows]
        stock_basis = basis(evaluated)
        for di, demand in enumerate(demands):
            if reduce_row(demand, stock_basis):
                separator, dual = gaussian([(r, 0) for r in stock_basis] + [(demand, 1)])
                assert separator is not None and dual is None
                return {"kind": "terminal_separation", "terminal": ti,
                        "terminal_name": core["terminals"][ti].get("name", str(ti)),
                        "demand": di, "separator": hex(separator)}
    return None


def verify_assignment_failure(core, pr, z, failure):
    if failure["kind"] == "fixed_mismatch":
        fi = failure["observation"]
        assert isinstance(fi, int) and 0 <= fi < len(pr["fixed_all"])
        p, q = pr["fixed_all"][fi]
        residual = p ^ xor_all(z[j] for j in bits(q))
        assert residual and number(failure["residual"]) == residual
        input_row = number(failure["input"])
        assert input_row >= 0 and not input_row >> pr["n"]
        assert (input_row & residual).bit_count() & 1
    else:
        assert failure["kind"] == "terminal_separation"
        ti, di = failure["terminal"], failure["demand"]
        assert isinstance(ti, int) and 0 <= ti < len(pr["terminals"])
        rows, demands = pr["terminals"][ti]
        assert isinstance(di, int) and 0 <= di < len(demands)
        assert failure["terminal_name"] == core["terminals"][ti].get("name", str(ti))
        separator = number(failure["separator"])
        assert separator >= 0 and not separator >> pr["n"]
        assert (separator & demands[di]).bit_count() & 1
        for p, q in rows:
            value = p ^ xor_all(z[j] for j in bits(q))
            assert not ((separator & value).bit_count() & 1)
    return True


def solve(core, max_branches=65536, backend="auto"):
    if max_branches < 0:
        raise ValueError("max_branches must be nonnegative")
    if backend not in ("auto", "gaussian", "enumerate"):
        raise ValueError("unknown backend")
    pr = prepare(core)
    result = {"schema": "P104-causal-core-result/1", "core_sha256": canonical_hash(core)}
    if "cut" in pr:
        return dict(result, status="UNSAT", cut=pr["cut"], branches_checked=0)
    source_count = source_assignment_count(pr)
    use_enumeration = backend == "enumerate" or (
        backend == "auto" and source_count < pr["total_branches"] and source_count <= max_branches)
    result.update(total_branches=source_count if use_enumeration else pr["total_branches"],
                  variables=pr["variables"], algebraic_branches=pr["total_branches"],
                  source_assignments=source_count,
                  backend="source_enumeration" if use_enumeration else "branch_gaussian")
    rejected = []
    if use_enumeration:
        for idx, (choice, solution, z) in enumerate(source_assignments(pr)):
            if idx >= max_branches:
                return dict(result, status="INCOMPLETE", branches_checked=idx, rejected=rejected)
            failure = assignment_failure(core, pr, z)
            if failure is None:
                return dict(result, status="SAT", branch=idx, branches_checked=idx+1,
                            witness=make_witness(core, pr, choice, solution), rejected=rejected)
            rejected.append(dict(assignment=idx, **failure))
        return dict(result, status="UNSAT", branches_checked=len(rejected), rejected=rejected)
    for idx, choice in enumerate(itertools.product(*pr["choices"])):
        if idx >= max_branches:
            return dict(result, status="INCOMPLETE", branches_checked=idx, rejected=rejected)
        equations = branch_equations(pr, choice)
        solution, dual = gaussian(equations)
        if solution is not None:
            return dict(result, status="SAT", branch=idx, branches_checked=idx+1,
                        witness=make_witness(core, pr, choice, solution), rejected=rejected)
        rejected.append({"branch": idx, "dual": hex(dual)})
    return dict(result, status="UNSAT", branches_checked=len(rejected), rejected=rejected)


def verify_result(core, result):
    assert result["core_sha256"] == canonical_hash(core)
    pr = prepare(core)
    if result["status"] == "SAT":
        return verify_witness(core, result["witness"])
    if "cut" in result:
        assert result["status"] == "UNSAT" and pr.get("cut") == result["cut"]
        return True
    assert "cut" not in pr
    rejected = result["rejected"]
    backend = result.get("backend", "branch_gaussian")
    assert backend in ("branch_gaussian", "source_enumeration")
    total = source_assignment_count(pr) if backend == "source_enumeration" else pr["total_branches"]
    assert result["total_branches"] == total
    assert result["branches_checked"] == len(rejected)
    if result["status"] == "UNSAT":
        assert len(rejected) == total
    else:
        assert result["status"] == "INCOMPLETE"
        assert len(rejected) < total
    if backend == "source_enumeration":
        for idx, (item, (_, _, z)) in enumerate(zip(rejected, source_assignments(pr))):
            assert item["assignment"] == idx
            verify_assignment_failure(core, pr, z, item)
        return True
    for idx, (item, choice) in enumerate(zip(rejected, itertools.product(*pr["choices"]))):
        assert item["branch"] == idx
        eqs = branch_equations(pr, choice)
        dual = number(item["dual"])
        assert dual >= 0 and not dual >> len(eqs)
        assert xor_all(eqs[j][0] for j in bits(dual)) == 0
        assert xor_all(eqs[j][1] for j in bits(dual)) == 1
    return True


def brute_feasible(core):
    _, k, sources, fixed, terminals = parse_core(core)
    for masks in itertools.product(*(range(1 << len(s)) for s in sources)):
        z = []
        for i, rows in enumerate(sources):
            values = [p ^ xor_all(z[j] for j in bits(q)) for p, q in rows]
            z.append(xor_all(values[j] for j in bits(masks[i])))
        if any(p != xor_all(z[j] for j in bits(q)) for p, q in fixed):
            continue
        if all(all(representation(d, [p ^ xor_all(z[j] for j in bits(q)) for p, q in rows])
                       is not None for d in ds) for rows, ds in terminals):
            return True
    return False


def self_test():
    rng = random.Random(20261121)
    outcomes = {"SAT": 0, "UNSAT": 0}
    for trial in range(300):
        n, k = 3, 3
        row = lambda i: {"p": hex(rng.randrange(1 << n)), "q": hex(rng.randrange(1 << i))}
        core = {"n": n, "senders": [{"name": str(i), "rows": [row(i) for _ in range(2)]} for i in range(k)],
                "fixed": [], "terminals": []}
        if trial % 2:
            core["fixed"] = [dict(row(k), name="o", target=hex(rng.randrange(1 << n))) for _ in range(2)]
        else:
            core["terminals"] = [{"name": "c", "rows": [row(k) for _ in range(3)],
                                   "demands": [hex(rng.randrange(1 << n)) for _ in range(2)]}]
        expected = brute_feasible(core)
        for backend in ("auto", "gaussian", "enumerate"):
            result = solve(core, backend=backend)
            assert (result["status"] == "SAT") == expected
            verify_result(core, result)
        outcomes[result["status"]] += 1
    # Chronology-sensitive cross term: second send can only retransmit first.
    chain = {"n": 1, "senders": [{"name": "A_B", "rows": [{"p": 1, "q": 0}]},
                                  {"name": "B_C", "rows": [{"p": 0, "q": 1}]}],
             "fixed": [{"name": "at_C", "p": 0, "q": 2, "target": 1}]}
    result = solve(chain)
    assert result["status"] == "SAT" and result["witness"]["sender_coefficients"] == ["0x1", "0x1"]
    assert len(result["rejected"]) == 1
    bad = copy.deepcopy(chain)
    bad["senders"][1]["rows"][0]["q"] = 2
    try:
        solve(bad)
        raise AssertionError("accepted a self/future dependency")
    except ValueError:
        pass
    # A local separator must reject a missing demand; corruption and incomplete
    # enumeration must never become a complete family certificate.
    missing = {"n": 2, "senders": [{"name": "s", "rows": [{"p": 1, "q": 0}]}],
               "terminals": [{"name": "c", "rows": [{"p": 0, "q": 1}],
                              "demands": [2]}]}
    result = solve(missing, backend="enumerate")
    assert result["status"] == "UNSAT" and result["branches_checked"] == 2
    verify_result(missing, result)
    corrupted = copy.deepcopy(result)
    corrupted["rejected"][0]["separator"] = "0x0"
    try:
        verify_result(missing, corrupted)
        raise RuntimeError("accepted corrupt separator")
    except AssertionError:
        pass
    partial = solve(missing, max_branches=1, backend="enumerate")
    assert partial["status"] == "INCOMPLETE"
    verify_result(missing, partial)
    partial["status"] = "UNSAT"
    try:
        verify_result(missing, partial)
        raise RuntimeError("accepted incomplete coverage as UNSAT")
    except AssertionError:
        pass
    print(json.dumps({"self_test": "PASS", "random_cores_vs_exhaustive_coefficients": 300,
                      "backends_checked": ["auto", "gaussian", "enumerate"],
                      "outcomes": outcomes, "chain_cross_term": "PASS", "future_port_rejected": True,
                      "separation_and_coverage_faults_rejected": True}))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("self-test")
    for name in ("solve", "verify"):
        p = sub.add_parser(name)
        p.add_argument("core", type=Path)
        p.add_argument("result", type=Path)
        if name == "solve":
            p.add_argument("--max-branches", type=int, default=65536)
            p.add_argument("--backend", choices=("auto", "gaussian", "enumerate"), default="auto")
    args = parser.parse_args()
    if args.command == "self-test":
        self_test()
        return
    core = json.loads(args.core.read_text())
    if args.command == "solve":
        result = solve(core, args.max_branches, args.backend)
        args.result.write_text(json.dumps(result, indent=2) + "\n")
        verify_result(core, result)
        print(json.dumps({k: v for k, v in result.items() if k not in ("rejected", "witness")}))
    else:
        verify_result(core, json.loads(args.result.read_text()))
        print("PASS_CORE_CERTIFICATE")


if __name__ == "__main__":
    main()
