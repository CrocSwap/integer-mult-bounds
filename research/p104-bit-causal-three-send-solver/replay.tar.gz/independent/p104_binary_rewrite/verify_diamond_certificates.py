"""Check rejection witnesses by scalar replay of the pinned instruction list.

This verifier does not use packets.json, the search Gaussian elimination,
or any source-project verifier. It verifies the declared packet relaxation,
not a replacement physical primitive program.
"""
import collections,gzip,hashlib,itertools,json,pathlib,sys
if not __debug__:
 raise RuntimeError('Certificate checks require Python without -O or -OO')
P=pathlib.Path(__file__).resolve().parent
raw=(P/'WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));r=json.loads((P/'diamond-result.json').read_text())
common='--common-probe' in sys.argv
if common:
 r=dict(branches=128,positive=[],rejections=[dict(sender2421_mask=b,relay2921=t,new2922_mask=a,chart=527,owner=113,separator=hex((1<<113)|(1<<621))) for b,t,a in itertools.product(range(8),range(2),range(8))])
assert r['branches']==128 and not r['positive'] and len(r['rejections'])==128
expected=set(itertools.product(range(8),range(2),range(8)));observed=set()
for a in r['rejections']:
 key=(a['sender2421_mask'],a['relay2921'],a['new2922_mask']);assert key not in observed;observed.add(key)
 probe=int(a['separator'],16);v={i:(probe>>i)&1 for i in range(680)};chart={i:c for i,c in enumerate(w['start'])};stock=collections.defaultdict(list)
 for i,c in chart.items():stock[c].append(i)
 def combine(ids,mask,source):
  out=0
  for k,i in enumerate(ids):
   assert i in stock[source]
   if mask>>k&1:out^=v[i]
  return out
 for clock,op in enumerate(w['program']):
  kind,i,*q=op
  if kind=='SWAP':break
  if kind=='INIT':v[i]=0;chart[i]=q[0]
  elif kind=='ADD':v[i]^=v[q[0]]
  elif kind=='MOVE':
   source,dest=q
   if i==2418:
    if common:assert v[i]==1
    v[i]=0;continue
   if i==2421:
    if common:assert [v[j] for j in [1979,1985,2295]]==[0,0,0]
    v[i]=combine([1979,1985,2295],key[0],331)
   elif i==2921:
    if common:assert stock[510]==[2421] and v[2421]==0
    v[i]=combine([2421],key[1],510)
   elif i==2922:
    if common:assert [v[j] for j in [1967,1973,2294]]==[1,0,0]
    v[i]=combine([1967,1973,2294],key[2],330);source=330
   assert abs(w['frames'][str(source)]['dim']-w['frames'][str(dest)]['dim'])>0
   chart[i]=dest;stock[dest].append(i)
 c=a['chart'];owner=a['owner'];assert w['final'][owner]==c
 assert all(v[i]==0 for i in stock[c]), ('nonzero observed stock',key,c)
 demand=((probe>>owner)&1)^(((probe>>(owner-111))&1) if 111<=owner<222 else 0)
 assert demand==1,('nonseparating demand',key,c,owner)
 if common:assert stock[527]==[2817,2820,2823,3414]
assert observed==expected
if common:
 assert not [op for op in w['program'] if op[0]=='MOVE' and op[2]==1]
 canonical=hashlib.sha256(json.dumps(w,separators=(',',':'),sort_keys=True).encode()).hexdigest()
 assert canonical=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
 selected=[2418,2921,3297,3298,3413,3414]
 path=[dict(label=op[1],clock=clock,source=op[2],destination=op[3]) for clock,op in enumerate(w['program']) if op[0]=='MOVE' and op[1] in selected]
 result=dict(status='PASS_COMMON_TWO_COORDINATE_PROBE_ALL_128_BRANCHES',source_commit='89a67c404226d51028e135de2b9169e9020d57af',word_gzip_sha256=hashlib.sha256(raw).hexdigest(),word_canonical_sha256=canonical,input_ones=[113,621],other_inputs=0,branches_verified=128,source2421_stock_ids=[1979,1985,2295],source2421_values=[0,0,0],source2921_stock_ids=[2421],source2921_values=[0],new2922_stock_ids=[1967,1973,2294],new2922_source_values=[1,0,0],original2418_value=1,chart1_paid_outdegree=0,chart527_stock_ids=[2817,2820,2823,3414],chart527_values=[0,0,0,0],demand_owner=113,demand_inputs=[113,2],demand_value=1,protected_labels=[3553,411],original_dependency_path=path,price_delta=dict(removed_grades=[1,1],added_grades=[2]),scope='exact packet-model obstruction for omitted2418, recoded2421 and2921, and repurposed2922 source330 at originalclock; arbitrary terminal decoders; no physical candidate claimed')
 (P/'common-probe-result.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS_COMMON_TWO_COORDINATE_PROBE_ALL_128_BRANCHES' if common else 'PASS_128_REJECTION_CERTIFICATES_FROM_SCALAR_WORD_REPLAY')
