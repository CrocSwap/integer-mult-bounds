import collections,gzip,hashlib,json,pathlib
if not __debug__:
 raise RuntimeError('Certificate checks require Python without -O or -OO')
P=pathlib.Path(__file__).resolve().parent
raw=(P/'WORD.json.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));assert hashlib.sha256(json.dumps(w,separators=(',',':'),sort_keys=True).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
v={i:(1<<i,0) for i in range(680)};chart={i:c for i,c in enumerate(w['start'])};stock=collections.defaultdict(list)
for i,c in chart.items():stock[c].append(i)
senders=[];order={2421:0,2921:1,2922:2};moves=[]
def row(i):return dict(label=i,p=hex(v[i][0]),q=hex(v[i][1]))
for clock,op in enumerate(w['program']):
 k,i,*a=op
 if k=='SWAP':break
 if k=='INIT':v[i]=(0,0);chart[i]=a[0]
 elif k=='ADD':
  j,c=a;v[i]=(v[i][0]^v[j][0],v[i][1]^v[j][1])
 elif k=='MOVE':
  s,d=a
  if i==2418:v[i]=(0,0);continue
  if i in order:
   source=330 if i==2922 else s
   senders.append(dict(name=str(i),label=i,clock=clock,source=source,destination=d,stock_ids=stock[source].copy(),rows=[row(j) for j in stock[source]]))
   v[i]=(0,1<<order[i])
  chart[i]=d;stock[d].append(i);moves.append(dict(label=i,clock=clock,source=330 if i==2922 else s,destination=d))
terms=[]
for c in sorted(set(w['final'])):
 owners=[i for i,d in enumerate(w['final']) if d==c]
 terms.append(dict(name=str(c),chart=c,stock_ids=stock[c],rows=[row(i) for i in stock[c]],owners=owners,demands=[hex((1<<i)^((1<<(i-111)) if 111<=i<222 else 0)) for i in owners]))
core=dict(n=680,senders=senders,fixed=[],terminals=terms,meta=dict(source_commit='89a67c404226d51028e135de2b9169e9020d57af',word_gzip_sha256=hashlib.sha256(raw).hexdigest(),word_canonical_sha256='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d',omitted=[2418],repurposed=[2922],protected=[3553,411],charts={str(c):w['frames'][str(c)] for c in [330,331,510,328,1,527]},method='formal sender-payload variables z0,z1,z2; fixed direct-donor equations propagated chronologically; terminal stocks taken before first SWAP; packet retention relaxation'))
(P/'core.json').write_text(json.dumps(core,indent=2)+'\n')
print('core',len(senders),len(terms),'source rows',[len(s['rows']) for s in senders],'sha256',hashlib.sha256((P/'core.json').read_bytes()).hexdigest())
