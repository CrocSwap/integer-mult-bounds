#!/usr/bin/env python3
"""Verify archive manifest and baseline inputs against the two pinned Git commits."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

here = Path(__file__).resolve().parent
pkg = here / 'p104_binary_rewrite'
p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
args = p.parse_args()
zipbytes = (here / 'p104_binary_rewrite.zip').read_bytes()
assert hashlib.sha256(zipbytes).hexdigest() == '4036b9121ee484c1bd283b480ffdea995e354f0920358bb89b8191a73aeb73ab'
manifest = json.loads((pkg / 'SHA256SUMS.json').read_text())
names = {x.name for x in pkg.iterdir() if x.is_file()} - {'SHA256SUMS.json'}
assert names == set(manifest)
for name, digest in manifest.items():
    assert hashlib.sha256((pkg / name).read_bytes()).hexdigest() == digest, name
items = [
    ('89a67c404226d51028e135de2b9169e9020d57af', 'research/p104-iterated-returns/binary/WORD.json.gz', 'WORD.json.gz'),
    ('89a67c404226d51028e135de2b9169e9020d57af', 'research/p104-iterated-returns/binary/REPLAY.json', 'baseline-REPLAY.json'),
    ('87fbf4f7b35b0f18ab12b5767775a9a424cf0b15', 'research/p104-mixed-rank-supplier/AUDIT.json', 'baseline-AUDIT.json'),
    ('87fbf4f7b35b0f18ab12b5767775a9a424cf0b15', 'research/p104-mixed-rank-supplier/BIT.json', 'baseline-BIT.json'),
]
results = []
for commit, path, filename in items:
    original = subprocess.check_output(['git', '-C', args.repo, 'show', f'{commit}:{path}'])
    archived = (pkg / filename).read_bytes()
    same_bytes = archived == original
    added_newline = archived == original + b'\n'
    assert same_bytes if filename == 'WORD.json.gz' else added_newline
    if filename != 'WORD.json.gz':
        assert json.loads(archived) == json.loads(original)
    results.append({'commit': commit, 'git_path': path, 'archive_file': filename,
                    'pinned_git_sha256': hashlib.sha256(original).hexdigest(),
                    'archive_sha256': hashlib.sha256(archived).hexdigest(),
                    'byte_identical': same_bytes, 'exactly_one_extra_newline': added_newline})
out = {'zip_sha256': hashlib.sha256(zipbytes).hexdigest(), 'manifest_entries_checked': len(names), 'inputs': results}
(here / 'source-pin-check.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, sort_keys=True))
