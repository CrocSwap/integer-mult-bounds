#!/usr/bin/env python3
"""Independent exhaustive controls for the GF(2) 3-send solver."""
import copy
import importlib.util
import itertools
import json
import random
from pathlib import Path

HERE = Path(__file__).resolve().parent
PKG = HERE / 'p104_binary_rewrite'
spec = importlib.util.spec_from_file_location('checked_package_solver', PKG / 'causal_core.py')
solver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(solver)

def integer(v):
    return int(v, 0) if isinstance(v, str) else int(v)

def span(rows):
    result = {0}
    for row in rows:
        result |= {item ^ row for item in result}
    return result

def linear_pairs(rows):
    result = {(0, 0)}
    for row in rows:
        p, q = integer(row['p']), integer(row['q'])
        result |= {(a ^ p, b ^ q) for a, b in result}
    return result

def independently_feasible(core):
    senders = core['senders']
    ranges = [range(1 << len(s['rows'])) for s in senders]
    for coeffs in itertools.product(*ranges):
        values = []
        for sender, mask in zip(senders, coeffs):
            z = 0
            for j, row in enumerate(sender['rows']):
                if (mask >> j) & 1:
                    value = integer(row['p'])
                    q = integer(row['q'])
                    for k, earlier in enumerate(values):
                        if (q >> k) & 1:
                            value ^= earlier
                    z ^= value
            values.append(z)
        def evaluate(row):
            result, q = integer(row['p']), integer(row['q'])
            for i, value in enumerate(values):
                if (q >> i) & 1:
                    result ^= value
            return result
        if any(evaluate(row) != integer(row['target']) for row in core.get('fixed', [])):
            continue
        if any(not all(integer(d) in span([evaluate(r) for r in term['rows']])
                       for d in term['demands']) for term in core.get('terminals', [])):
            continue
        return True
    return False

# A real counterexample to equating frozen-output failure with free-decoder
# failure. Both variants have exactly the same three sender stocks and local
# terminal stock. In the free variant, the three labelled requests span only
# two dimensions modulo the terminal's pure-input space.
free = {
    'n': 4,
    'senders': [
        {'name': 's0', 'rows': [{'p': 1, 'q': 0}]},
        {'name': 's1', 'rows': [{'p': 4, 'q': 0}, {'p': 0, 'q': 1}]},
        {'name': 's2', 'rows': [{'p': 0, 'q': 2}]},
    ],
    'fixed': [],
    'terminals': [{'name': 'c', 'rows': [{'p': 0, 'q': 1}, {'p': 0, 'q': 4}, {'p': 8, 'q': 0}],
                   'demands': [9, 12, 5]}],
}
frozen = copy.deepcopy(free)
frozen['fixed'] = [{'name': 'original_readout_z0', 'p': 0, 'q': 1, 'target': 9}]
assert independently_feasible(free) and not independently_feasible(frozen)
pr = solver.prepare(free)
assert len(pr['tn'][0][0]) == 1  # pure F = span(x3)
assert len(pr['tn'][0][1]) == 2  # projected port rank
assert len(pr['tn'][0][2]) == 2  # 3 demands, quotient rank 2
free_result = solver.solve(free, backend='gaussian')
frozen_result = solver.solve(frozen, backend='gaussian')
assert free_result['status'] == 'SAT' and frozen_result['status'] == 'UNSAT'
solver.verify_result(free, free_result)
solver.verify_result(frozen, frozen_result)

# Recheck the representative quotient dimension independently by enumerating
# formal (p,q) row combinations; compare both solving backends with independent
# exhaustive direct coefficient search in varied three-sender, multi-terminal
# cores with fixed and free observations present together.
rng = random.Random(0x1047830)
counts = {'trials': 0, 'sat': 0, 'unsat': 0, 'quotient_rank_ge_2': 0,
          'multi_terminal': 0, 'fixed_plus_terminal': 0, 'too_many_branches_skipped': 0}
while counts['trials'] < 800:
    n, k = rng.choice((3, 4)), 3
    def row(qbits):
        return {'p': rng.randrange(1 << n), 'q': rng.randrange(1 << qbits)}
    case = {'n': n,
            'senders': [{'name': str(i), 'rows': [row(i), row(i)]} for i in range(k)],
            'fixed': [], 'terminals': []}
    for j in range(rng.randrange(3)):
        case['fixed'].append(dict(row(k), name=str(j), target=rng.randrange(1 << n)))
    for j in range(rng.choice((1, 1, 2))):
        case['terminals'].append({'name': str(j), 'rows': [row(k) for _ in range(rng.choice((2, 3)))],
                                  'demands': [rng.randrange(1 << n) for _ in range(rng.choice((2, 3)))]})
    local_dims = []
    for term in case['terminals']:
        formal = linear_pairs(term['rows'])
        pure = {p for p, q in formal if q == 0}
        port_rank = (len({q for _, q in formal})).bit_length() - 1
        quotient_size = len(span(list(pure) + term['demands'])) // len(pure)
        assert quotient_size and quotient_size & (quotient_size - 1) == 0
        quotient_rank = quotient_size.bit_length() - 1
        local_dims.append((len(pure).bit_length() - 1, port_rank, quotient_rank))
    prepared = solver.prepare(case)
    if 'cut' not in prepared:
        if prepared['total_branches'] > 4096:
            counts['too_many_branches_skipped'] += 1
            continue
        for (f, sections, reps), dims in zip(prepared['tn'], local_dims):
            assert (len(f), len(sections), len(reps)) == dims
    elif prepared['cut']['kind'] == 'terminal_quotient':
        ti = prepared['cut']['terminal']
        assert local_dims[ti][2] > local_dims[ti][1]
    expected = independently_feasible(case)
    for backend in ('gaussian', 'enumerate'):
        result = solver.solve(case, max_branches=4096, backend=backend)
        assert result['status'] in ('SAT', 'UNSAT')
        assert (result['status'] == 'SAT') == expected, (case, result)
        solver.verify_result(case, result)
    counts['trials'] += 1
    counts['sat' if expected else 'unsat'] += 1
    counts['quotient_rank_ge_2'] += int(any(q >= 2 for _, _, q in local_dims))
    counts['multi_terminal'] += int(len(case['terminals']) > 1)
    counts['fixed_plus_terminal'] += int(bool(case['fixed']))

core = json.loads((PKG / 'core.json').read_text())
certificate = json.loads((HERE / 'fresh-core-result.json').read_text())
bad = copy.deepcopy(certificate)
assert bad['rejected'][0]['kind'] == 'terminal_separation'
bad['rejected'][0]['separator'] = '0x0'
try:
    solver.verify_result(core, bad)
except AssertionError:
    separator_mutation_rejected = True
else:
    raise AssertionError('zero separator accepted')
badcore = copy.deepcopy(free)
badcore['senders'][0]['rows'][0]['q'] = 1
try:
    solver.solve(badcore)
except ValueError:
    self_port_rejected = True
else:
    raise AssertionError('self dependency accepted')

out = {'fixed_vs_free_control': {'same_sender_and_terminal_stocks': True,
       'frozen_status': frozen_result['status'], 'free_status': free_result['status'],
       'pure_dimension': 1, 'port_rank': 2, 'demand_quotient_rank': 2,
       'free_witness': free_result['witness']},
       'independent_random_exhaustive_comparison': counts,
       'mutated_p104_zero_separator_rejected': separator_mutation_rejected,
       'self_causality_violation_rejected': self_port_rejected}
(HERE / 'theorem-controls.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, sort_keys=True))
