# A causal binary template solver and a paid contraction obstruction

With three mutable scalar sends and fixed readouts, a causal packet
template reduces to at most eight linear systems over GF(2). With free
local decoding, branch separately over the dependence masks of a basis
of demanded rows modulo fixed stock. The exact proof and a control
where freeing a decoder changes feasibility are in the independent audit.

The concrete template drops packet 2418, retargets 2922 as a grade-two
MOVE 330→1, and allows 2421, 2921 and all final decoders to change. All
128 assignments fail. With coordinates 113 and 621 set to one, the whole
chart-527 stock is the same as on zero input while the required owner-113
output differs. The independent replay checks all 680 original rows and
extracts all 138 final chart stocks from the primitive tape.

The companion permits one additional recoded sender. A candidate change
to 3413 still leaves an exterior defect in all 128 assignments. Across
53 earlier sender choices and 6,784 upstream assignments, the two local
demands are incompatible or require a pulse absent from the sender's
actual earlier stock. Other senders and changed routing remain open.

The native word is byte-identical to the source at
`89a67c404226d51028e135de2b9169e9020d57af`, compressed hash
`d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.
The signed baseline is #7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`.
Three baseline JSON receipts include one additional trailing newline and
agree as parsed JSON. The in-scope failure precedes physical cleanup,
adjoint realization, finite compilation and any complete κ admission.

## Reproduce

Use Python 3.12 in an empty extraction. Run `sha256sum -c SHA256SUMS`.
Inside `independent/` check `sha256sum -c SHA256SUMS-AUDIT` and run the
commands in `AUDIT.md`. Pass a checkout containing both exact source
commits to the optional Git provenance command. In a separate empty
directory extract `source-sender-boundary.tar.gz`, verify its
`SHA256SUMS`, and run its README commands using the included sources.

## Open next questions

Change the information that reaches both affected banks while keeping the
paid grade saving. A candidate also needs both literal orientations,
ownership and the complete finite application.
