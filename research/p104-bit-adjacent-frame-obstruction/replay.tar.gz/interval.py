#!/usr/bin/env python3
"""Extend the rebuilt fixed-incidence roster proof over the trial interval."""
from collections import Counter
from contextlib import redirect_stdout
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
from io import StringIO
from pathlib import Path
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
with redirect_stdout(StringIO()):
    import arbitrary as model

low = Fraction("0.003879928046155")
high = model.K
assert high-low == Fraction(1,10**9)
roster = model.histogram_roster
directions = Counter()
for row in roster:
    if not row:
        directions["zero"] += 1
        continue
    lower, upper = model.v.signed(row)
    if lower > 0:
        directions["positive_then_geometry_excluded"] += 1
        continue
    # For 1 <= rank <= 8 and 0 < kappa < 1, |H'| < 8*3.
    assert all(1 <= rank <= 8 for rank, _ in row)
    variation = 24 * sum(abs(count) for _, count in row) * (high-low)
    assert upper + variation < 0
    directions["negative_throughout"] += 1
assert len(roster) == 267
assert directions == {"zero": 1, "positive_then_geometry_excluded": 5, "negative_throughout": 261}

# Exact-power sign and monotonicity of the complete unchanged BIT invoice.
# Decimal ln is correctly rounded to nearest; the adjacent representable
# endpoints enclose it. Powers and all exponent inputs are exact rationals.
raw = model.v.read("inputs/BIT.json")["native"]
paid = {int(k): v for k,v in raw["paid"].items()}
target = {int(k): v for k,v in raw["targets"].items()}
assert (sum(paid.values()), sum(target.values())) == (107460,20706)
signed = Counter(target)
signed.subtract(paid)
low_powers = {r: model.v.power_bounds(r,1-low) for r in signed}
def upper_term(r, c):
    a,b = low_powers[r]
    return c*(b if c>=0 else a)
assert sum(upper_term(r,c) for r,c in signed.items()) < 0
N = Context(prec=90)
L = Context(prec=90, rounding=ROUND_FLOOR)
U = Context(prec=90, rounding=ROUND_CEILING)
def dec(value, context):
    return context.divide(Decimal(value.numerator), Decimal(value.denominator))
upper_slope = Decimal(0)
for rank, count in sorted(signed.items()):
    if not count or rank == 1:
        continue
    ln = N.ln(Decimal(rank))
    if count > 0:
        a,_ = model.v.power_bounds(rank,1-high)
        term = L.multiply(L.multiply(N.next_minus(ln),dec(a,L)),Decimal(count))
        upper_slope = U.subtract(upper_slope,term)
    else:
        _,b = low_powers[rank]
        term = U.multiply(U.multiply(N.next_plus(ln),dec(b,U)),Decimal(-count))
        upper_slope = U.add(upper_slope,term)
assert upper_slope < Decimal("-385126.93")
print(json.dumps({"status":"PASS_UNIFORM_PRICE_SIGN_INTERVAL",
 "kappa_interval":["0.003879928046155","0.003879929046155"],
 "classes":directions,"rank_histograms":len(roster),
 "baseline_at_interval_left":"strictly negative",
 "baseline_derivative_upper":"-385126.93",
 "positive_rank_cases_excluded":50},indent=2,sort_keys=True))
