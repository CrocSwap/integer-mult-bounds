#!/usr/bin/env python3
"""Exact unit-incidence min cuts with checkable edge-disjoint path witnesses."""
from collections import deque
from hashlib import sha256
from pathlib import Path
import gzip,json,os
H=Path(__file__).resolve().parent
if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
raw=(H/'sources/caller/EFREE-CALLER.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
c=json.loads(gzip.decompress(raw));cur=list(range(38)); edges=[];idles=[]
for clock,(op,*args) in enumerate(c['events']):
 if op in ('ADD','QUERY'):
  dst,src=args; edges.append({'clock':clock,'op':op,'dst':dst,'src':src,'u':cur[dst],'v':cur[src]})
 elif op=='LOCAL':
  stage,src,dst=args; edges.append({'clock':clock,'op':op,'stage':stage,'dst':dst,'src':src,'u':cur[dst],'v':cur[src]})
 elif op=='SWAP':cur[args[0]],cur[args[1]]=cur[args[1]],cur[args[0]]
 elif op=='IDLE_ONE':
  r,stages=args;before=cur[r];after=38+len(idles);cur[r]=after
  idles.append({'clock':clock,'role':r,'stages':stages,'before':before,'after':after})
 else:raise AssertionError(op)
assert len(edges)==402 and len(idles)==32 and idles[0]['clock']==19 and idles[16]['clock']==397
terminal=cur

# Every edge has integral upper capacities in both directions. Flow is signed
# so an undirected incidence can occur in at most one path of the packing.
def maxflow(start,end,anchors=()):
 ee=[(e['u'],e['v'],1,1,e['clock']) for e in edges]
 for a in anchors:ee.append((a,end,403,0,None))
 adj=[[] for _ in range(71)]
 for j,(u,v,cu,cv,_) in enumerate(ee):adj[u].append((j,1));adj[v].append((j,-1))
 flow=[0]*len(ee)
 def find(s,t,residual):
  pred={s:None};q=deque([s])
  while q:
   x=q.popleft()
   if x==t:break
   for i,d in adj[x]:
    u,v,cu,cv,_=ee[i];y=v if d==1 else u
    available=(cu-flow[i] if d==1 else cv+flow[i]) if residual else (flow[i]*d)
    if available>0 and y not in pred:pred[y]=(x,i,d);q.append(y)
  if t not in pred:return None,set(pred)
  path=[];x=t
  while x!=s:
   prev,i,d=pred[x];path.append((i,d));x=prev
  return list(reversed(path)),set(pred)
 value=0
 while True:
  p,reachable=find(start,end,True)
  if p is None:break
  for i,d in p:flow[i]+=d
  value+=1
 cut=[e for e in edges if (e['u'] in reachable)!=(e['v'] in reachable)]
 assert len(cut)==value and all(a not in reachable for a in anchors)
 # Decompose into value one-unit edge-disjoint paths, preserving clock labels.
 paths=[]
 for _ in range(value):
  p,_=find(start,end,False);assert p is not None
  vertices=[start];clocks=[]
  for i,d in p:
   u,v,_,_,clock=ee[i];vertices.append(v if d==1 else u)
   if clock is not None:clocks.append(clock)
   flow[i]-=d
  paths.append({'vertices':vertices,'clocks':clocks})
 used=[x for p in paths for x in p['clocks']]
 assert len(used)==len(set(used))
 return {'value':value,'selected_vertices':sorted(x for x in reachable if x<70),
         'cut':[e['clock'] for e in cut],'paths':paths}
results={
 'idle19_pair':maxflow(38,0),
 'idle397_pair':maxflow(54,11),
 'idle19_all_inputs':maxflow(38,70,range(38)),
 'idle397_all_inputs':maxflow(54,70,range(38)),
}
assert [results[x]['value'] for x in results]==[4,5,60,5]
assert results['idle397_all_inputs']['selected_vertices']==[54]
assert results['idle397_all_inputs']['cut']==[420,452,470,472,473]
# Checkable independent path validity and capacity: each clock is a graph
# incidence, each path follows its endpoints, no edge repeats across paths.
by_clock={e['clock']:e for e in edges}
for name,r in results.items():
 seen=set()
 for p in r['paths']:
  verts=p['vertices'];clocks=p['clocks'];assert len(verts)==len(clocks)+(2 if name.endswith('all_inputs') else 1)
  for i,clock in enumerate(clocks):
   assert clock not in seen;seen.add(clock);e=by_clock[clock]
   assert {e['u'],e['v']}=={verts[i],verts[i+1]}
  if name.endswith('all_inputs'):assert verts[-1]==70 and verts[-2] in range(38)
 assert len(r['cut'])==len(r['paths'])==r['value']
# Minimal positive-monomial stage-10 obstruction: read the named incidence
# endpoints directly from the reconstructed graph and source idles. The algebra
# and its assumptions are stated in README; this does not assume D10^2=1.
e={x['clock']:x for x in edges};j={x['clock']:x for x in idles}
assert (j[19]['before'],j[19]['after'])==(0,38) and 10 not in j[19]['stages']
assert (e[165]['u'],e[165]['v'])==(1,38) and e[165]['op']=='ADD'
assert (j[397]['before'],j[397]['after'])==(11,54) and j[397]['stages']==[10]
assert (e[452]['u'],e[452]['v'],e[452]['stage'])==(54,38,11)
out={'status':'PASS_UNIT_INCIDENCE_CUTS_AND_EDGE_DISJOINT_PATH_WITNESSES',
 'caller_sha256':sha256(raw).hexdigest(),'vertices':70,'shear_incidence_edges':402,'results':results,
 'fixed_grammar_stage10_witness':{'idle19':j[19],'add165':e[165],'idle397':j[397],'local452':e[452],
  'constraint_summary':'For input exponents b0=b1=b11=0, square-free idle masks and nonnegative off-diagonal stage exponents give b38>=0 (idle19), b38<=0 (ADD165), b54>=b38 (LOCAL452), and b54<=0 (idle397).',
  'limit':'Only retained positive-monomial gate grammar; no exclusion of inverses or other paid implementations.'}}
(H/'results/CUT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS 70 vertices 402 edges; pair cuts 4/5; all-input cuts 60/5; certified path packings')
