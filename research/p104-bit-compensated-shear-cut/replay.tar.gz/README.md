# A compensated head-selector cut in the pinned BIT caller

This is a bounded, offline check of a compensated diagonal gauge in the #7830 BIT caller, pinned at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. It gives a complete macro-level changed caller and exact forward and adjoint algebra. It does **not** improve κ: the only priced construction increases the full bill by **777 rank-one paid positions**, with no changed productive position. No body-stage inverse or unproved identity `D_s² = 1` is used. The surrounding campaign's #7904 reference is outside the calculation; its result is not used as evidence here.

## The minimum cut

Open all 32 idle scalars in the original 798-clock word. A compact vertex follows one role gauge through wire propagation; `SWAP` exchanges the vertices and each opened idle starts a fresh vertex. Every `ADD`, `QUERY`, or `LOCAL` has one shear-equality incidence. The resulting multigraph has 70 vertices and 402 incidences. Parallel edges at different clocks remain separate paid compensation obligations.

The target idle at clock 19 separates vertices 0 and 38; clock 397 separates 11 and 54. With no other constraints their exact minimum incidence cuts are 4 and 5 respectively. The 4-edge cut for clock 19 is `[0, 4, 6, 9]`. With **all 38 input gauges fixed to 1**, the minima for changing vertex 38 or 54 are instead 60 and 5. The minimum for vertex 54 isolates `{54}` and cuts clocks `[420, 452, 470, 472, 473]`.

[results/CUT.json](results/CUT.json) contains each full cut and a matching packing of edge-disjoint paths: 4, 5, 60, and 5 paths respectively. `verify_cut.py` independently checks that removing each listed cut disconnects the relevant endpoints and that all paths use valid distinct incidences. These are minimum numbers of **shear incidences to compensate**, not prices, and they do not assert that arbitrary compensations are physically available. Initial gauges must be fixed for an exact arbitrary-input caller. The result leaves terminal gauges free until explicitly restored.

## A legal involutory head gauge and its cost

Use the head selector `q`, for which the retained BIT algebra explicitly has `q² = 1`. Set the compact gauge to `q` on vertex 54 and to 1 everywhere else. This changes the multiplier immediately after idle 397 and the shear coefficients on the five cut clocks. It leaves the other 397 shear incidences unchanged. A final rank-one `q` job on output role 11 restores its terminal gauge. The compensations use only retained same-chart `ADD`, rank-one `QUERY`, full native `LOCAL`, and one-field rank-one positive `q` jobs (`QONE` in the emitted caller):

| Original zero-based clock | Concrete replacement |
| ---: | --- |
| 397 | retain `IDLE_ONE 2,[10]`, then `QONE 2` |
| 420 | `QUERY 1,2` |
| 452 | retain `LOCAL 11,1,0`; then `QUERY 0,1`; then `ADD 0,1` |
| 470 | `QUERY 0,2` |
| 472 | `QUERY 0,1` |
| 473 | `QUERY 1,0` |
| after 797 | `QONE 11` |

An operand list for `ADD` or `QUERY` is destination, source. For `LOCAL 11,1,0`, the original output is `(D11*x, D11*(y+q*x))`. The extra query cancels `q*x` and the subsequent same-chart ADD supplies `x`, giving `(D11*x, D11*(y+x))` as required by the gauge. Each QUERY acts on the source through the normal separately owned query bank, with one rank-one job per physical port; `QONE` applies the same rank-one head transform to the stated whole owner. The two `QONE` jobs add no productive target. They are genuine paid jobs; no imaginary free selector is used. The emitted 802-event macro word is [results/CALLER-COMPENSATED.json.gz](results/CALLER-COMPENSATED.json.gz). It is a real sequence of the retained interfaces, but does not expand each one of the 36 unchanged native calls to its serial-bank tape.

Both the original and emitted caller replay to the **same 38 diagonal roots**, on all 1,444 scalar coefficients in each of the forward and adjoint directions. This is an exact computation in `F₂[q,D1,...,D18]/(q²−1)`, with all body variables free and commuting. An independently written tuple-exponent interpreter repeats both replays without calling the source interpreter. Separate faults omitting the idle correction, terminal correction, one compensated shear, or the local query are rejected in both directions. The caller-level algebra uses the retained native endpoint, physical chart interface, arbitrary payload and owned-erasure contracts; it is not a cold replay of the 680-public-field native word.

The original complete invoice includes all 36 native occurrences, four queries, 32 idles and all independent native and root targets. The changed caller has nine queries and two single-field head jobs, so the paid delta is exactly `7 * 111 = 777` rank-one positions. Every original idle, native paid position and productive target remains. The independently recounted totals are 108,237 paid positions and 20,706 productive fields. Directed rational-grid intervals from the pinned engine, checked by a separate 100-digit Decimal engine, give:

| κ trial | Complete productive minus paid |
| --- | --- |
| `0.003879928046155` | `[−777.000000000381874566916336446611, −777.000000000381874566916336446610]` |
| `0.003879928046156` | `[−777.000000000767001502431130261464, −777.000000000767001502431130261463]` |
| `0.003879929046155` | `[−777.000385127316613866441054139473, −777.000385127316613866441054139472]` |

The changed margin is the source margin minus exactly 777 at every κ. A conservative extension of the retained ordinary accounting charges all seven new paid jobs at all 111 ports, their route groups, the extra four event clocks, and the added query and one-field operations. It gives `941,251,152,552 < 10^12` ordinary records and `7,044,720 < 10^7` owned fields. This remains an upper account under the pinned framework, not a separate finite-product, stock, precision or outer-multiplier proof.

## Stage-10 caveat and a narrower exact obstruction

A head-selector control is **not** a stage-10 idle saving. The separately retained BIT audit says repeated body variables are not silently made involutions. The involutory rational coordinate matcher that places a stage's axes is a different object from the formal positive body job. Replacing `D10⁻¹` by `D10`, deleting the clock-397 `D10`, or pricing its inverse as a rank-seven positive job would require additional proof.

There is a short exact obstruction inside the retained **positive-monomial grammar**, if a proposed one-body-selector gauge uses integral `D10` exponents, fixes all input gauges, keeps stage masks square-free, and requires every new off-diagonal coefficient to have nonnegative `D10` exponent. Let `b_v` be the exponent at compact vertex `v`. The initial vertices 0, 1 and 11 have exponent zero. Clock 19 has no `D10`, so its new idle mask requires `b38 ≥ 0`; ADD 165 has source vertex 38 and destination initial vertex 1, so its compensated coefficient requires `b38 ≤ 0`. LOCAL 452 has source vertex 38, destination vertex 54 and stage 11, so its compensated off-diagonal requires `b54 ≥ b38`. Finally, clock 397 already has one `D10`; a square-free new mask requires `b54 ≤ 0`. Hence `b38 = b54 = 0`.

This formal result does not rule out a separately constructed inverse-bearing physical gate, a more general gate decomposition, matrix gauges, changed masks outside the stated square-free grammar, a changed exterior, or another caller. In particular, it does not equate a formal negative exponent with a proof that every physical inverse is impossible or too costly.

## Reproduce

Python 3.9 or newer, standard library only:

```sh
python3 -I -B check.py
```

The command verifies source and artifact hashes, copies the package to a fresh temporary directory, regenerates the cuts and changed macro caller, compares the stored certificates, checks the separately authored path verifier and tuple-polynomial interpreter, and compares the compressed caller by decompressed canonical bytes. Each computation pins itself to one available CPU where the operating system provides affinity. No repository checkout, network, or original campaign directory is needed.

The caller hash is `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b` and the #7830 BIT receipt hash is `8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d`. The snapshots and inherited notices are under [sources/](sources/); [LICENSE](LICENSE) and [NOTICE](NOTICE) retain source credit. This check was prepared with Codex assistance and has not received independent human review.
