#!/usr/bin/env python3
"""Independently replay expanded q caller and recount every paid owner."""
from collections import Counter
from decimal import Decimal,Context,ROUND_CEILING,ROUND_FLOOR,ROUND_HALF_EVEN
from hashlib import sha256
from pathlib import Path
import gzip,json,os
P=Path(__file__).resolve().parent
if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def loadgz(p):return json.loads(gzip.decompress(p.read_bytes()))
orig=loadgz(P/'sources/caller/EFREE-CALLER.json.gz')
new=loadgz(P/'results/CALLER-COMPENSATED.json.gz')
r=json.loads((P/'results/COMPENSATED.json').read_bytes())
b=json.loads((P/'sources/7830/BIT.json').read_bytes())['native']
assert {k:v for k,v in new.items() if k!='events'}=={k:v for k,v in orig.items() if k!='events'}
assert len(orig['events'])==798 and len(new['events'])==802
# Monomials are tuples of 18 body exponents plus the q exponent modulo two.
# Coefficients are bit vectors of arbitrary inputs, added over F2.
def plus(a,b):
 o=a.copy()
 for m,coeff in b.items():
  o[m]=o.get(m,0)^coeff
  if not o[m]:del o[m]
 return o
def times(a,stages=(),q=0):
 out={}
 for m,coeff in a.items():
  m=list(m)
  for s in stages:m[s-1]+=1
  m[18]^=q;out[tuple(m)]=coeff
 return out
def replay(c,adj=False):
 rows=[{(0,)*19:1<<i} for i in range(c['roles'])]
 order=reversed(c['events']) if adj else c['events']
 for op,*a in order:
  if op in ('ADD','QUERY'):
   d,s=a[::-1] if adj else a
   rows[d]=plus(rows[d],times(rows[s],q=op=='QUERY'))
  elif op=='SWAP':x,y=a;rows[x],rows[y]=rows[y],rows[x]
  elif op=='IDLE_ONE':x,st=a;rows[x]=times(rows[x],st)
  elif op=='QONE':rows[a[0]]=times(rows[a[0]],q=1)
  elif op=='LOCAL':
   s,x,y=a
   if adj:x,y=y,x
   beforex=rows[x];rows[y]=times(plus(rows[y],times(beforex,q=1)),[s]);rows[x]=times(beforex,[s])
  else:raise AssertionError(op)
 return rows
root=[]
for i,d in enumerate(orig['diagonal']):
 m=[0]*19
 for s in d['stages']:m[s-1]+=1
 m[18]=d['q'];root.append({tuple(m):1<<i})
assert all(replay(c,a)==root for c in (orig,new) for a in (False,True))
# Full receipt regenerated event by event, not a delta-only calculation.
paid=Counter();productive=Counter(); native_paid={int(k):v for k,v in b['native_paid'].items()}; native_prod={int(k):v for k,v in b['native_targets'].items()}
for op,*a in new['events']:
 if op=='LOCAL':paid.update(native_paid);productive.update(native_prod)
 elif op=='QUERY' or op=='QONE':paid[1]+=111
 elif op=='IDLE_ONE':paid[7*len(a[1])]+=111
 elif op not in ('ADD','SWAP'):raise AssertionError(op)
for d in new['diagonal']:productive[7*len(d['stages'])+d['q']]+=111
asjson=lambda c:{str(k):v for k,v in sorted(c.items()) if v}
assert asjson(paid)==r['changed_paid'] and asjson(productive)==r['productive']
base=Counter({int(k):v for k,v in b['paid'].items()});delta=paid.copy();delta.subtract(base)
assert {k:v for k,v in delta.items() if v}=={1:777}
# Independent high-precision directed moment check, no reuse of price.py.
near=Context(prec=100,rounding=ROUND_HALF_EVEN);down=Context(prec=100,rounding=ROUND_FLOOR);up=Context(prec=100,rounding=ROUND_CEILING)
def power(rank,exp):
 if rank==1:return Decimal(1),Decimal(1)
 x=near.ln(Decimal(rank));lo=down.multiply(near.next_minus(x),exp);hi=up.multiply(near.next_plus(x),exp)
 return near.next_minus(near.exp(lo)),near.next_plus(near.exp(hi))
def moment(hist,exp):
 lo=hi=Decimal(0)
 for k,n in sorted(hist.items()):
  a,b=power(k,exp);lo=down.add(lo,down.multiply(a,Decimal(n)));hi=up.add(hi,up.multiply(b,Decimal(n)))
 return lo,hi
trial={}
for k,row in r['trials'].items():
 exp=down.subtract(Decimal(1),Decimal(k));a=moment(productive,exp);b=moment(paid,exp)
 diff=(down.subtract(a[0],b[1]),up.subtract(a[1],b[0]));reported=tuple(map(Decimal,row['productive_minus_paid']))
 assert reported[0]<=diff[0]<=diff[1]<=reported[1]<0
 trial[k]=list(map(str,diff))
out={'status':'PASS_INDEPENDENT_POLYNOMIAL_REPLAY_FULL_INVOICE_DECIMAL',
 'original_and_emitted_coefficients_each_way':38**2,'body_variables_free':'yes','only_q_is_involutory':True,
 'events_recounted':len(new['events']),'native_calls':36,'paid_positions':sum(paid.values()),'productive_positions':sum(productive.values()),
 'changed_caller_canonical_sha256':sha256(gzip.decompress((P/'results/CALLER-COMPENSATED.json.gz').read_bytes())).hexdigest(),
 'paid_delta':{'1':777},'trials':trial}
(P/'results/INDEPENDENT.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print('PASS independent tuple-polynomial original and changed forward/adjoint, full invoice, Decimal checks')
