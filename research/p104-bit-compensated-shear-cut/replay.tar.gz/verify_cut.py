#!/usr/bin/env python3
"""Verify stored cuts and edge-disjoint paths without using the flow solver."""
from collections import deque
from pathlib import Path
import gzip,json,os
P=Path(__file__).resolve().parent
if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
c=json.loads(gzip.decompress((P/'sources/caller/EFREE-CALLER.json.gz').read_bytes()))
cert=json.loads((P/'results/CUT.json').read_bytes())
labels=list(range(38));edge={};n=38
for clock,row in enumerate(c['events']):
 op,*a=row
 if op in ('ADD','QUERY','LOCAL'):
  p,q=a[-2:];edge[clock]=(labels[p],labels[q])
 elif op=='SWAP':p,q=a;labels[p],labels[q]=labels[q],labels[p]
 elif op=='IDLE_ONE':labels[a[0]]=n;n+=1
 else:raise AssertionError(op)
assert n==70 and len(edge)==402
expected={'idle19_pair':(38,{0},4),'idle397_pair':(54,{11},5),
          'idle19_all_inputs':(38,set(range(38)),60),'idle397_all_inputs':(54,set(range(38)),5)}
for name,(start,targets,k) in expected.items():
 r=cert['results'][name];cut=set(r['cut']);assert len(cut)==k==r['value']
 adj=[[] for _ in range(70)]
 for clock,(u,v) in edge.items():
  if clock not in cut:adj[u].append(v);adj[v].append(u)
 seen={start};q=deque([start])
 while q:
  for y in adj[q.popleft()]:
   if y not in seen:seen.add(y);q.append(y)
 assert not (targets&seen)
 used=set();assert len(r['paths'])==k
 for p in r['paths']:
  verts=p['vertices'];clocks=p['clocks']
  if name.endswith('all_inputs'):assert verts[-1]==70;verts=verts[:-1]
  assert verts[0]==start and verts[-1] in targets and len(verts)==len(clocks)+1
  for clock,u,v in zip(clocks,verts,verts[1:]):
   assert clock not in used and {u,v}==set(edge[clock]);used.add(clock)
print('PASS independently verified four disconnecting cuts and their edge-disjoint lower-bound paths')
