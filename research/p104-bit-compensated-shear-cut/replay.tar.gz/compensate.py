#!/usr/bin/env python3
"""Emit and check a q-compensated version of the pinned 798-clock caller.

The gauge is q on the compact post-idle vertex 54 and 1 elsewhere. q^2=1,
while stage bodies remain free commuting variables. Clocks name the input
caller; new QUERY/ADD/QONE instructions are fully invoiced.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip, json, os, sys

HERE=Path(__file__).resolve().parent
if hasattr(os,'sched_getaffinity'): os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
source=HERE/'sources'
paths={
 'caller/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'parent/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'parent/price.py':'d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b',
 '7830/BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
}
for p,expected in paths.items(): assert sha256((source/p).read_bytes()).hexdigest()==expected,p
sys.path.insert(0,str(source/'parent'))
import literal,price
caller=json.loads(gzip.decompress((source/'caller/EFREE-CALLER.json.gz').read_bytes()))
bit=json.loads((source/'7830/BIT.json').read_bytes())['native']
assert len(caller['events'])==798 and caller['roles']==38 and caller['ports']==111
assert caller['events'][397]==['IDLE_ONE',2,[10]]

# Explicit complete q gauge, tracked chronologically through all 798 clocks.
# A new compact vertex is opened at each idle, never at a shear or swap.
current=list(range(38)); next_vertex=38; events=[]; changes=[]; gauge_idle=[]
for clock,row in enumerate(caller['events']):
 op,*a=row
 if op in ('ADD','QUERY'):
  dst,src=a; unequal=(current[dst]==54) != (current[src]==54)
  new=['QUERY' if op=='ADD' else 'ADD',dst,src] if unequal else row.copy()
  events.append(new)
  if unequal: changes.append({'clock':clock,'original':row,'replacement':[new],'emitted_index':len(events)-1,'vertices':[current[dst],current[src]]})
 elif op=='LOCAL':
  stage,src,dst=a; unequal=(current[dst]==54) != (current[src]==54)
  # The unchanged native outputs are Ds*source and Ds*(destination+q*source).
  # Follow it with +q*source and then +source, obtaining the desired
  # Ds*(destination+source). Each extra query is a real charged query.
  repl=[row.copy(),['QUERY',dst,src],['ADD',dst,src]] if unequal else [row.copy()]
  events.extend(repl)
  if unequal: changes.append({'clock':clock,'original':row,'replacement':repl,'emitted_index':len(events)-len(repl),'vertices':[current[dst],current[src]]})
 elif op=='SWAP':
  events.append(row.copy()); current[a[0]],current[a[1]]=current[a[1]],current[a[0]]
 elif op=='IDLE_ONE':
  owner,stages=a; before=current[owner]; after=next_vertex; next_vertex+=1; current[owner]=after
  events.append(row.copy())
  if (before==54)!=(after==54):
   events.append(['QONE',owner]);gauge_idle.append({'clock':clock,'owner':owner,'before':before,'after':after})
 else: raise AssertionError((clock,row))
assert next_vertex==70
assert [x['clock'] for x in changes]==[420,452,470,472,473]
assert gauge_idle==[{'clock':397,'owner':2,'before':11,'after':54}]
terminal_owners=[r for r,v in enumerate(current) if v==54]
assert terminal_owners==[11]
for owner in terminal_owners:events.append(['QONE',owner])
changed=deepcopy(caller);changed['events']=events
assert len(events)==802
assert Counter(x[0] for x in events)=={'ADD':359,'SWAP':364,'QUERY':9,'LOCAL':36,'IDLE_ONE':32,'QONE':2}

# This evaluator is independent of source.caller_rows for the added QONE.
def rows(source,adjoint=False):
 n=source['roles'];r=[{0:1<<j} for j in range(n)]
 order=reversed(source['events']) if adjoint else source['events']
 for op,*a in order:
  if op in ('ADD','QUERY'):
   d,s=a[::-1] if adjoint else a
   r[d]=literal.add(r[d],literal.shift(r[s],0,op=='QUERY'))
  elif op=='SWAP':
   i,j=a;r[i],r[j]=r[j],r[i]
  elif op=='LOCAL':
   s,i,j=a
   if adjoint:i,j=j,i
   v=literal.caller_monomial([s]);r[i],r[j]=literal.shift(r[i],v),literal.shift(literal.add(r[j],literal.shift(r[i],0,True)),v)
  elif op=='IDLE_ONE':
   i,stages=a;r[i]=literal.shift(r[i],literal.caller_monomial(stages))
  elif op=='QONE':r[a[0]]=literal.shift(r[a[0]],0,True)
  else:raise AssertionError(op)
 return r
roots=[{literal.caller_monomial(d['stages'])|d['q']:1<<j} for j,d in enumerate(caller['diagonal'])]
assert rows(caller)==literal.caller_rows(caller)==roots
assert rows(caller,True)==literal.caller_rows(caller,True)==roots
assert rows(changed)==roots and rows(changed,True)==roots
# Faults: undo a replacement or leave the terminal gauge unrestored.
miss=deepcopy(changed);miss['events'].pop(); assert rows(miss)!=roots and rows(miss,True)!=roots
# Forgetting the additional q after idle 397 must fail too.
miss2=deepcopy(changed);qidx=next(i for i,e in enumerate(miss2['events'][:-1]) if e==['QONE',2]);miss2['events'].pop(qidx)
assert rows(miss2)!=roots and rows(miss2,True)!=roots
miss3=deepcopy(changed); miss3['events'][changes[0]['emitted_index']]=changes[0]['original']
assert rows(miss3)!=roots and rows(miss3,True)!=roots
miss4=deepcopy(changed); miss4['events'].pop(changes[1]['emitted_index']+1)
assert rows(miss4)!=roots and rows(miss4,True)!=roots

paid=Counter({int(k):v for k,v in bit['paid'].items()})
targets=Counter({int(k):v for k,v in bit['targets'].items()})
assert sum(paid.values())==107460 and sum(targets.values())==20706
changed_paid=paid.copy();changed_paid[1]+=7*caller['ports']
assert sum(changed_paid.values())==108237
signed=Counter(targets);signed.subtract(changed_paid)
def hist(h):return {str(k):v for k,v in sorted(h.items()) if v}
trials={}
for k in ('0.003879928046155','0.003879928046156','0.003879929046155'):
 p=price.moment(changed_paid,Fraction(k));t=price.moment(targets,Fraction(k));m=price.sub(t,p)
 old=price.sub(price.moment(targets,Fraction(k)),price.moment(paid,Fraction(k)))
 assert price.sub(m,old)[0] <= -777*price.GRID <= price.sub(m,old)[1]
 assert m[1]<0
 trials[k]={'paid':price.decimal_interval(p,30),'productive':price.decimal_interval(t,30),
            'productive_minus_paid':price.decimal_interval(m,30),
            'old_productive_minus_paid':price.decimal_interval(old,30),
            'signed_change_exact':'-777'}
# Conservative extension of the pinned ordinary account; count all four
# extra actual event clocks, 5 additional queries, two QONE single-field
# paid jobs and their route/setup work, and 777 paid positions.
o=bit['ordinary'];assert o['ordinary_records']==934182831504 and o['owned_backing']==6998544
new_query=5;new_qone=2;new_events=4; delta_add=-3; ports=caller['ports'];roles=caller['roles']
extra_transit=ports*(8*delta_add+256*(new_query+new_qone))
extra_groups=4*777+8*ports*new_qone
extra_routes=extra_groups*80*(134**2+134)
extra_owned=2*ports*roles*new_events+16*ports*(new_query+new_qone)
new_ordinary=o['ordinary_records']+extra_transit+extra_routes
new_owned=o['owned_backing']+extra_owned
assert new_ordinary<10**12 and new_owned<10**7
receipt={'status':'PASS_Q_GAUGE_COMPENSATED_CONTROL_NOT_A_GAIN',
 'scope':'One input-anchored q-valued diagonal gauge on compact vertex 54; all other vertices 1; q^2=1 and stage body variables are free.',
 'source_caller_sha256':paths['caller/EFREE-CALLER.json.gz'],'source_bit_sha256':paths['7830/BIT.json'],
 'original_clocks':798,'changed_emitted_events':len(events),'selected_vertex':54,
 'gauge_idle_changes':gauge_idle,'compensated_shear_sites':changes,'terminal_restored_owners':terminal_owners,
 'event_counts':dict(sorted(Counter(x[0] for x in events).items())),
 'forward_original_and_changed_equal_all_diagonal_roots':True,
 'adjoint_original_and_changed_equal_all_diagonal_roots':True,
 'caller_coefficients_checked_each_way':38**2,
 'fault_missing_terminal_q_rejected_both_ways':True,'fault_missing_idle_q_rejected_both_ways':True,
 'fault_uncompensated_add_rejected_both_ways':True,'fault_missing_local_query_rejected_both_ways':True,
 'original_paid':hist(paid),'changed_paid':hist(changed_paid),'productive':hist(targets),
 'delta_paid':{'1':777},'delta_productive':{},'trials':trials,
 'ordinary_estimate':{'source_ordinary_records':o['ordinary_records'],'source_owned_backing':o['owned_backing'],
  'extra_transits':extra_transit,'extra_route_groups':extra_groups,'extra_route_records':extra_routes,
  'extra_owned_backing':extra_owned,'ordinary_records':new_ordinary,'owned_backing':new_owned,
  'ordinary_allowance':10**12,'owned_allowance':10**7}}
(HERE/'results/COMPENSATED.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
payload=(json.dumps(changed,sort_keys=True,separators=(',',':'))+'\n').encode()
(HERE/'results/CALLER-COMPENSATED.json.gz').write_bytes(gzip.compress(payload,mtime=0))
print('PASS 798 original clocks; 802 emitted events; 1444 coefficients each orientation')
print('new paid rank-1 jobs 777, target delta 0, ordinary',new_ordinary,'owned',new_owned)
for k,v in trials.items():print(k,v['productive_minus_paid'])
