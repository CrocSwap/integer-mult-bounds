#!/usr/bin/env python3
"""Verify this package and recompute all receipts in a clean temporary copy."""
from hashlib import sha256
from pathlib import Path
import gzip,os,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
if hasattr(os,'sched_getaffinity'):os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
assert sys.version_info >= (3,9)
entries={}
for line in (HERE/'SHA256SUMS').read_text().splitlines():
 h,name=line.split('  ',1);p=Path(name)
 assert not p.is_absolute() and '..' not in p.parts and name not in entries
 entries[name]=h
present={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file() and p.name!='SHA256SUMS' and '__pycache__' not in p.parts}
assert present==set(entries),(sorted(present-set(entries)),sorted(set(entries)-present))
for name,h in entries.items():assert sha256((HERE/name).read_bytes()).hexdigest()==h,name
with tempfile.TemporaryDirectory(prefix='bit-compensated-') as tmp:
 p=Path(tmp)/'public';shutil.copytree(HERE,p)
 for script in ('graph.py','compensate.py','verify_cut.py','independent.py'):
  subprocess.run([sys.executable,'-I','-B',script],cwd=p,check=True)
 for f in ('CUT.json','COMPENSATED.json','INDEPENDENT.json'):
  assert (p/'results'/f).read_bytes()==(HERE/'results'/f).read_bytes(),f
 f='CALLER-COMPENSATED.json.gz'
 assert gzip.decompress((p/'results'/f).read_bytes())==gzip.decompress((HERE/'results'/f).read_bytes())
print('PASS hashes, clean-copy recomputation, independent checks and emitted caller')
