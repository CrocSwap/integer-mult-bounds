#!/usr/bin/env python3
"""Verify inert source snapshots against pinned predecessor source identities.

The #7909 SOURCES.json blob identity was independently obtained at its pinned
commit. This checks byte identities, not the predecessor's theorems.
"""
from hashlib import sha1,sha256
from pathlib import Path
from tarfile import open as taropen
import json
P=Path(__file__).resolve().parent
blob=lambda b:sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
sources=(P/'source/p7909/SOURCES.json').read_bytes()
assert blob(sources)=='5b088dc5262472353684efc38274e4817433e6ca'
data=json.loads(sources)
archive=(P/'source/p7909/replay.tar.gz').read_bytes()
assert sha256(archive).hexdigest()==data['archive_file_sha256']['replay.tar.gz']=='a3eac1cff485e6f7ee62c4d0fc066b866d4303a8fc9afc25f8a376c2ee71d346'
expected={
 './source/p7852/CallerEv.lean':'ad5aba9f52bd1d4b60c3023a8325ff68310c5561',
 './source/p7852/CallerThin.lean':'f85fc659414297e2444489f9982bf966d5fadb9f',
 './source/p7852/CallerWord.lean':'4d8d2ab8e4a1338cb172b35dc45d8070c3c3270c',
 './source/p7852/CallerWordD.lean':'6d1b7ae061de0d0e93a8720f0c81b79a4dbf8347',
 './source/p7852/SchemaCostB.lean':'b6a1c4b03a81a99e59c433d110871f605bef9694',
 './source/p7861/SHARED-HUB-PROOF.md':'14d37abc0ff73ca77935aea5c8906b57fea38d82',
 './source/p7883/PROOF.md':'9b82c2a317841dd70dd0e02edac40776e0a56f93',
}
with taropen(P/'source/p7909/replay.tar.gz','r:gz') as tf:
 for name,sha in expected.items():
  member=tf.getmember(name)
  assert member.isfile()
  b=tf.extractfile(member).read()
  assert blob(b)==sha,(name,blob(b),sha)
 readme=tf.extractfile('./README.md').read()
 assert sha256(readme).hexdigest()=='c663b4fa6a96ffb8dcf8a5751f47353d9a91a798a3b410fef72da895e09684c9'
print('PASS #7909 pinned SOURCES.json git blob, replay archive SHA-256, seven predecessor source blobs, and replay README identity.')
print('The snapshots are inert; identity verification is not a re-proof.')
