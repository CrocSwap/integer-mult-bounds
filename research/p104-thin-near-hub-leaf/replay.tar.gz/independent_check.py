#!/usr/bin/env python3
"""Independent finite audit: Newton roots, forbidden signature types, DP, duals.

Rebuilds the numerical rows without calling check.py or any floating solver.
It does not prove the paper frame, global-partition or legal-word arguments.
"""
from itertools import combinations_with_replacement,product
from math import comb
from fractions import Fraction
from pathlib import Path
import json
S=10**15
M=10**18
BAR=Fraction(128891,1000)
R={}
def root(b):
 if b not in R:
  n=b**99*S**100
  x=(b+1)*S
  while True:
   y=(99*x+n//x**99)//100
   if y>=x:break
   x=y
  while (x+1)**100<=n:x+=1
  while x**100>n:x-=1
  assert x**100<=n<(x+1)**100
  R[b]=(x,x+(x**100<n))
 return R[b]
def calc(terms,upper=False):
 return sum(c*root(k)[1 if (upper==(c>0)) else 0] for k,c in terms if c)
def sloss(d,up=False):return calc([(17,1),(16,-1),(8*d+1,-1),(8*d,1)],up)
def split(d,up=False):return calc([(17,1),(16,-1),(8*d+1,-1),(8,1),(8*d-8,1)],up)
def delta(d,up=False):return calc([(8,1),(8*d-8,1),(8*d,-1)],up)
def power_baseline(up=False):
 return calc([(609,1),(601,1),(9,76),(17,73),(8,-227),(16,-73),(1,-1)],up)
def ceil(loss_scaled):return Fraction(104*(power_baseline(True)*(M//S)-loss_scaled),76*M)
def pen(d):return comb(d,2)*(75-d)-73
def graph(n,a):
 q,r=divmod(n,a);return (a-r)*comb(q,2)+r*comb(q+1,2)
def rows(L):
 out=[]
 for m,alpha in enumerate((2,3,4,7)):
  q=L-m
  if q>0:
   cap=max(n for n in range(76) if graph(n,alpha)<=72-L)
   out.append((q,75-cap))
 return out
def independent_max(m):
 n=1<<m
 forbidden=[]
 for tr in combinations_with_replacement(range(n),3):
  if not any(sum((t>>j)&1 for t in tr)==2 for j in range(m)):
   forbidden.append(tuple(tr.count(i) for i in range(n)))
 maxsize=0
 for ns in product(range(3),repeat=n):
  if any(all(ns[i]>=c for i,c in enumerate(need)) for need in forbidden):continue
  maxsize=max(maxsize,sum(ns))
 return maxsize

def main():
 assert tuple(independent_max(m) for m in range(4))==(2,3,4,7)
 assert all(graph(75,(2,3,4,7)[L])>72-L for L in range(4))
 assert all(sloss(d,True)<sloss(d+1) for d in range(3,76))
 assert all(split(d,True)<split(d+1) for d in range(2,76))
 assert comb(75,3)-72*73==62269
 # Five fractional degree positions satisfy the weaker unanchored relaxation
 # while their root-enclosed modeled price remains above the bar.
 mean=Fraction(411,20)
 assert all(q*mean>=b for q,b in rows(5))
 assert Fraction(5*(11*pen(3)+9*pen(42)),20)>=62269
 fractional_loss=Fraction(5*(11*sloss(3,True)+9*sloss(42,True)),20)
 fractional_price=Fraction(104,76*S)*(power_baseline(False)-split(76,True)-fractional_loss)
 assert fractional_price>BAR
 costs={d:split(d) for d in range(2,77)}
 # A separate DP organizes states by exact total coverage before clipping.
 # Adding roles after coverage already reaches 75 can only increase price.
 dp={0:0}; best=None
 for count in range(1,74):
  nxt={}
  for x,c in dp.items():
   for d in range(2,77):
    y=min(75,x+d-1);v=c+costs[d]
    if y not in nxt or v<nxt[y]:nxt[y]=v
  dp=nxt
  if count>=2 and (best is None or dp[75]<best[0]):best=(dp[75],count)
 assert best[1]==2 and best[0]==costs[75]+costs[2]
 assert ceil(best[0]*(M//S))<BAR
 assert ceil((costs[76]+delta(75))*(M//S))<BAR
 assert ceil((costs[76]+21*sloss(3))*(M//S))<BAR
 data=json.loads(Path(__file__).with_name('duals.json').read_text())
 assert data['scale']==M
 dual={(r['long_count'],r['anchor']):r['mu'] for r in data['rows']}
 counts={'impossible':0,'simple':0,'dual':0};worst=None;used=set()
 for L in range(4,21):
  bs=rows(L);q=L-3
  for a in range(3,76):
   if q*a<dict(bs)[q]:counts['impossible']+=1;continue
   cheap=((q-1)*sloss(3)+4*sloss(a))*(M//S)
   if ceil(costs[76]*(M//S)+cheap)<BAR:
    counts['simple']+=1;loss=cheap
   else:
    key=(L,a);mu=dual[key]
    assert len(mu)==5 and all(type(v) is int and v>=0 for v in mu)
    used.add(key);counts['dual']+=1
    # Reorganize as one reduced-cost minimum for each of four groups.
    v=mu[4]*(62269-pen(a))+sum(mu[i]*(need-a) for i,(_,need) in enumerate(bs))+sloss(a)*(M//S)
    if q>1:
     v+=(q-1)*min(sloss(d)*(M//S)-d*sum(mu[:4])-mu[4]*pen(d) for d in range(3,a+1))
    for j in range(1,4):
     w=sum(mu[i] for i,(end,_) in enumerate(bs) if q+j<=end)
     v+=min(sloss(d)*(M//S)-d*w-mu[4]*pen(d) for d in range(a,76))
    assert ceil(costs[76]*(M//S)+v)<BAR,(key,v)
    loss=v
   result=ceil(costs[76]*(M//S)+loss)
   if worst is None or result>worst[0]:worst=(result,L,a)
 assert len(used)==23 and counts=={'impossible':99,'simple':1119,'dual':23}
 overall=max(worst[0],ceil(best[0]*(M//S)),ceil((costs[76]+delta(75))*(M//S)),ceil((costs[76]+21*sloss(3))*(M//S)))
 assert overall<BAR
 print('PASS independent Newton-enclosed power roots:',len(R))
 print('PASS signature maxima:',(2,3,4,7),'and exact coverage dynamic program',best)
 print('PASS anchored dual rows:',counts,'used',len(used))
 print('PASS overall upper:',overall,'=',float(overall),'<',BAR)
 print('PASS fractional degree-only control above bar:',fractional_price,'=',float(fractional_price))
 print('Paper structure and legal-word bridge are not checked by this arithmetic audit.')
if __name__=='__main__':main()
