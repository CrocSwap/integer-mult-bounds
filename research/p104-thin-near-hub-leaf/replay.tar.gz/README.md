# One near-hub, with the exceptional HOST incidence assigned to a leaf

## Conditional result and boundaries

Under the hypotheses below, the **actual** type-B caller invoice satisfies

\[
 \frac{104}{76}\operatorname{repo}
 \le \frac{122446218640655481}{950000000000000}
 < 128.890756463848 < 128.891.
\]

The rational ceiling is an outward enclosure, not an attained value. Its
margin below the bar is greater than `0.00024353615212`. This is a **paper
proof of a conditional slice**, plus a standard-library exact arithmetic
checker; the new implications here are not Lean-checked. The result does not
establish the stronger global event/role assignment from ordinary per-stage
matching, produce a legal caller word, establish a bound for all k=76 words,
or improve kappa. The HOST-to-leaf ownership is an explicit hypothesis about
the global assignment, not a fact implied by a leaf's presence.

This extends the approach of [#7909 at
`623d108a514bf9723be0f80e0231f50526155d7e`](https://github.com/CrocSwap/integer-mult-bounds/commit/623d108a514bf9723be0f80e0231f50526155d7e)
and [#7883 at `ddb2499be243594c8165c7508c457782c1a4af3b`](https://github.com/CrocSwap/integer-mult-bounds/commit/ddb2499be243594c8165c7508c457782c1a4af3b),
which assumed **two universal hubs**. Here one hub misses one stage; their
results cannot simply be applied to 76 stages. The common-kernel sign
obstruction used below is from
[#7861](https://github.com/CrocSwap/integer-mult-bounds/pull/7861), and the
frame/word/invoice infrastructure is from
[#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852).

Assume all of the following.

1. There are 76 distinct ordered type-B two-column HOST stages, 151
   positive-degree odd-target roles, and `T=Q=1`. The signed frame is over a
   field of characteristic not 2, `P=-I`, and every host's diagonal block of
   `K` is invertible. Hence `rank K <= 2`, and every cross-host Gram block is
   invertible. Host A and B columns vanish on roles whose target masks miss
   the corresponding stage.
2. There is a **single global bijection** from nonempty charged stage-incidence
   events to role pieces, in which each role's nonempty pieces partition its
   target stage mask. The events satisfy the `CallerEv` support, multi-stage
   kernel and shared-stage biorthogonality laws. This global partition is
   stronger than ordinary per-stage `CallerEv.Match`.
3. There are exactly 76 degree-one roles (leaves), and two distinct nonleaf
   hubs `h` and `g`. The universal `h` meets all stages; `g` meets all but
   one exceptional stage `e`. The two singleton HOST incidence events at
   every common stage are assigned, one each, to `h` and `g`. At `e`, the
   two singleton HOST events are assigned to `h` and a leaf. Thus the
   remaining 73 roles each have degree at least 2 and may initially have
   arbitrary nonempty event partitions.
4. The frame and event data come from a SPEC-legal type-B caller word via the
   [CallerWord](https://github.com/CrocSwap/integer-mult-bounds/blob/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit/lean/Nov15/CallerWord.lean)
   and [CallerWordD](https://github.com/CrocSwap/integer-mult-bounds/blob/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit/lean/Nov15/CallerWordD.lean)
   bridges. The sole thin is an odd QUERY or odd IDLE at its own time slot,
   and the actual invoice has the `SchemaCostB.repo_eq` correction. The
   distinction from an abstract `EvData` configuration is essential for the
   zero-correction argument below.

The first three hypotheses support the frame and partition cuts. The fourth
is the additional real-word qualification needed for the stated **actual**
invoice. None of the finite arithmetic constitutes an independent proof of
those structural hypotheses or the word bridge.

## The odd-idle correction is zero in this word slice

The `CallerThin.leaf_rank` lemma, together with target-mask host support,
forces at most one leaf at each host. Therefore the 76 leaves occupy the 76
stages, including exactly one at `e`. For each leaf, `CallerThin.leaf_zero`
forces a nonzero B-entry in the unique thin column: otherwise the basis vector
of that leaf is invisible to every other stage and the sole thin, contradicting
the nondegenerate host block and `P=-I`.

Suppose instead that the thin were an odd IDLE with nonempty stage mask
`S`, and choose `t` in `S`. Its word-level q-odd B-vector is the D-incidence
vector `incW`: at `q=1, D=1`, `idle_base` gives an identity base event, and
`CallerWord.terms` gives the odd factor. The `CallerWordD.legal_masks`
support theorem makes `incW` zero on a leaf whose target mask is `{u}` for
any `u != t`, contradicting that leaf's nonzero thin entry. Thus the odd IDLE
has empty `S`, or the thin is a QUERY. Both have zero odd-idle correction in
`SchemaCostB.repo_eq`. This argument uses the actual word, separate HOST and
thin time slots, and the D-incidence bridge; **abstract `EvData` alone does
not imply zero correction**. The particular HOST ownership at `e` is not used
here.

## A new pair cut at the exceptional stage

Fix any common stage `s`, and let `H` be the set of roles whose masks contain
both `e` and `s`. It contains `h` and no other hub; no leaf lies in `H`.
Suppose for contradiction that every other role `r` in `H` has one assigned
piece containing **both** `e` and `s`.

The corresponding distinct event vectors `x_r` are supported in `H`, since
their full pieces contain `e` and `s`. They annihilate both columns of the
HOST B-block at `e` by the multi-event kernel law, and are linearly
independent by biorthogonality at the shared stage `e`. There are `|H|-1` of
them. However the map `B_e^T` restricted to `H` has rank two: the
cross-host Gram block `B_e^T A_s` is invertible and has no contribution from
roles outside `H`. Its kernel on `H` has dimension `|H|-2`, a contradiction.

Thus, for **each** `s != e`, some nonleaf role contains both `e` and `s`
but has them in **different** pieces. For a role `r` containing `e`, let
`P_r(e)` be its unique piece containing `e`, and let `D_r=|M_r|`. Taking the
union of these separating sets gives the necessary coverage inequality

\[
 \sum_{r:\,e\in M_r\text{ and }r\text{ split}}
       \left(D_r-|P_r(e)|\right)\ge75.\tag{1}
\]

The leaves do not contribute, and `h` is not split. Every split contributes
at most `D_r-1`. This cut is about an actual *global* role-to-event partition;
it does not follow from being able to match events separately at each stage.

## The exceptional event is billed once

Let `p(x)=x^(99/100)`, `v(d)=p(8d+1)-p(8d)`,
`s(d)=v(2)-v(d)`, and

\[
 \Delta(d)=p(8)+p(8d-8)-p(8d),\qquad
 c(d)=s(d)+\Delta(d).
\]

As a favorable baseline, charge every one of the 73 other nonleaves as an
unsplit degree-two role. With correction zero, the normalized baseline is

\[
 B_{\rm near}=\frac{104}{76}\bigl[
 p(609)-76p(8)+p(601)-75p(8)+76v(1)+73v(2)-1\bigr]
 <129.598161831605.\tag{2}
\]

The 76 leaf pieces in `76v(1)` include the HOST incidence assigned to the
exceptional leaf. The coefficient of `p(8)` after expansion is `-227`,
consisting of `76+75+76` assigned singleton events. It already includes all
152 native HOST incidences: `76` on `h`, `75` on `g`, and one on the
exceptional leaf. It would be wrong to subtract the exceptional HOST again.
The final `-1` is the `Q=1` charge in the exact event-form identity.

A role of degree `d>=2` split into any two or more pieces loses at least
`c(d)` against its baseline `v(2)`. This follows from concavity and merging
all but the smallest piece: fragmentation costs at least `Delta(d)`.
Unsplit roles lose `s(d)>=0`. The checker verifies finite root-enclosed
monotonicity and the two-piece comparisons needed for these 76 degrees.

If at least two of the 73 nonleaves split, relax (1) by giving **every**
split role `d-1` units of coverage, whether or not its mask contains `e`.
The exact dynamic program, allowing all 73 roles and clipping excess at 75,
finds a minimum of `c(75)+c(2)` and the ceiling

\[
 (104/76)\operatorname{repo}<128.848444082169.
\]

If exactly one role splits, (1) forces `D=76` and `P(e)={e}`. If it has at
least three pieces, merging its common-stage pieces until two remain shows
an additional loss at least `Delta(75)` beyond `c(76)`, giving
`128.439963491591`. The only case that remains near the target is therefore
one degree-76 role with exactly two pieces `{e}` and `C`, the set of all 75
common stages; the other 72 nonleaves have one full-mask event each.

## Triple and cell constraints on the 75 common stages

In this last case, for every triple of common stages at least one of the
other 72 nonleaves has a mask containing exactly two members of the triple.
Otherwise all pairwise mask intersections for the triple are the same set
`H`. In `H` are `h`, `g`, the special degree-76 role, and the other
nonleaves that contain all three. For each role except `h,g`, select its
piece containing all three: `C` for the special role, or the full mask for an
unsplit role. The corresponding `|H|-2` event vectors are independent,
supported on `H`, and annihilated by each of the three B-blocks. Since each
B map has rank 2 on `H`, these vectors give a common kernel of codimension 2.
The #7861 signed common-kernel three-stage obstruction rules out that triple.
The special role is essential in the kernel count; it has no differentiating
mask on the 75 stages.

For the other 72 roles, write `d=|M_r ∩ C|`. A common-degree-2 mask gives a
pair edge; common degrees 0 or 1 give none. If `L` roles have common degree
at least 3, at most `72-L` pair edges exist, and their sorted common degrees
satisfy `3 <= d_1 <= ... <= d_L <= 75`. The actual degree is at least the
common degree, so the real price loses at least `s(d_i)` for each long role.
In particular, roles that also include `e` can only cost more than this
relaxation.

Each common degree `d` differentiates exactly
`f(d)=binom(d,2)*(75-d)` common-stage triples. Counting with multiplicity
and giving every non-long role the favorable capacity `f(2)=73` gives

\[
 \sum_{i=1}^{L}\left[\binom{d_i}{2}(75-d_i)-73\right]
 \ge \binom{75}{3}-72\cdot73 = 62269.\tag{3}
\]

Also remove the `q` smallest long masks. For `m=L-q` in `0,1,2,3`, the
remaining long-mask signatures on an independent set in the pair graph have
maximum sizes `a_m=(2,3,4,7)`, respectively: every triple must have a
signature bit appearing exactly twice. These values are exhaustively
checked, including all `3^8=6561` multiplicity vectors at `m=3`. Let
`T(n,a)` be the minimum edges in an n-vertex graph with independence number
at most `a`, and let

\[
 N_m(L)=\max\{n\le75:T(n,a_m)\le72-L\}.
\]

Then every actual profile obeys

\[
 \sum_{i=1}^{L-m}d_i\ge75-N_m(L),\qquad m=0,1,2,3.\tag{4}
\]

For `L<=3`, the whole graph already violates the corresponding bound.
For signature cells of the long roles, the local ordered CROSS restriction
also survives: for `a<b<c<d` in one cell, at least two pair-role events
cross `{a,c}` to `{b,d}`. The common-piece kernels (including `C`) reduce
the common-role contribution to rank at most 2, while the alternating
unsigned cross block has rank 4; each pair role contributes rank at most 1.
More generally, a cut of cyclic alternation number `c` requires at least
`2c-2` pair roles. The price certificate below does not spend this further
restriction, and the diagonal-pair control in the checker shows it is
stronger than simply covering every triple locally.

## Finite price certificate

For `L>=21`, the checker charges `21*s(3)` on top of `c(76)`. For
`4<=L<=20`, set `q=L-3` and condition on the **integer** anchor
`a=d_q`. The first `q-1` degrees lie in `[3,a]`, the anchor is `a`, and the
last three lie in `[a,75]`. Impossible anchors fail (4); many others pass
by monotonicity alone. For the remaining 23 anchors, `duals.json` supplies
nonnegative rational multipliers for (3) and the four instances of (4).
The checker independently minimizes the Lagrangian over each integer
position's allowed range, so the multiplier values are verified by weak
duality rather than trusted from their numerical search.

All power intervals are checked using integer 100th powers at scale `10^14`;
all duals have denominator `10^18`. The worst resulting outward ceiling is

\[
 \frac{122446218640655481}{950000000000000}
 =128.890756463847874\ldots<128.891,
\]

at the `L=15, a=5` relaxation. No mask placement, signed-frame realization,
or legal word attaining this number is asserted.

A deliberately weaker *fractional degree-only* control lies **above** the
bar: five long positions each take `11/20` of degree 3 and `9/20` of
degree 42, with 67 other pair roles. Their fractional prefix and triple rows
pass, and the root-enclosed modeled price is greater than `128.892711657`.
This is not a role-mask construction, a global assignment, a signed frame,
or a legal word. It shows why dropping the integer-anchor step would not
prove this ceiling.

```sh
python3 -I -B check.py
python3 -I -B independent_check.py
python3 -I -B review_check.py
python3 -I -B verify_sources.py
```

`search_duals.py` is an optional SciPy-based search heuristic and is not
needed or trusted for verification. `RESULT.json` is generated by the exact
checker. The separately authored review is in [REVIEW.md](REVIEW.md); its
checker uses the same candidate duals but independently verifies them.
The checkers prove only their finite arithmetic; the sign, support,
partition, matching, host-word and repo-cost implications above are outside
those checks. The byte-pinned [#7909 replay archive](source/p7909/replay.tar.gz)
contains the #7852, #7861 and #7883 source snapshots and their original
notices. Its `SOURCES.json` is the byte-identical Git blob from the pinned
#7909 head. `verify_sources.py` checks the archive hash and selected source
blobs; it does not re-prove or fully replay those predecessor results.
