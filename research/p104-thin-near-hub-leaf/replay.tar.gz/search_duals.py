#!/usr/bin/env python3
"""Search candidate LP multipliers; independent exact checker verifies output."""
from pathlib import Path
import json
from math import comb
import numpy as np
from scipy.optimize import linprog

p=lambda x:x**.99
v=lambda d:p(8*d+1)-p(8*d)
s=lambda d:v(2)-v(d)
def f(d):return comb(d,2)*(75-d)-73
def g(n,a):
 t,r=divmod(n,a);return (a-r)*comb(t,2)+r*comb(t+1,2)
def bounds(L):
 return [(L-m,75-max(n for n in range(76) if g(n,alpha)<=72-L)) for m,alpha in enumerate((2,3,4,7)) if L-m>0]
def run(L,a):
 q=L-3; small=list(range(3,a+1)); large=list(range(a,76))
 groups=([small] if q>1 else [])+[large]*3
 cols=[(j,d) for j,group in enumerate(groups) for d in group]
 shift=1 if q>1 else 0
 c=np.array([s(d) for _,d in cols])
 E=np.array([[int(j==idx) for j,d in cols] for idx in range(len(groups))])
 eb=np.array(([q-1] if q>1 else [])+[1]*3)
 A=[];bb=[]
 for pfx,b in bounds(L):
  row=[]
  for j,d in cols:
   coeff=1 if q>1 and j==0 else int(pfx>=q+1+j-shift)
   row.append(-coeff*d)
  A.append(row);bb.append(-b+a)
 A.append([-f(d) for j,d in cols]);bb.append(-(comb(75,3)-72*73)+f(a))
 res=linprog(c,A_ub=np.array(A),b_ub=np.array(bb),A_eq=E,b_eq=eb,bounds=(0,None),method='highs')
 return (res.fun+s(a),res) if res.success else (float('inf'),res)

# Inflated by 1e-8 relative to exact needed threshold to avoid omissions.
baseline=104/76*(p(609)-76*p(8)+p(601)-75*p(8)+76*(p(9)-p(8))+73*v(2)-1)
c76=s(76)+p(8)+p(600)-p(608)
BUD=(baseline-128.891)*76/104-c76+1e-8
print('baseline',baseline,'c76',c76,'threshold',BUD,flush=True)
M=10**18;rows=[];bad=[]
for L in range(4,21):
 q=L-3;b=dict(bounds(L))[q]
 for a in range(3,76):
  if q*a<b or (q-1)*s(3)+4*s(a)>BUD:continue
  value,res=run(L,a)
  if not res.success or value<=BUD:
   bad.append((L,a,value,res.message));continue
  mu=[max(0,round(-float(x)*M)) for x in res.ineqlin.marginals]
  rows.append({'long_count':L,'anchor':a,'mu':mu,'numerical_loss':value})
 print('L',L,'rows',len(rows),'bad',bad[-4:],flush=True)
Path(__file__).with_name('duals.json').write_text(json.dumps({'scale':M,'rows':rows},indent=2)+'\n')
print('wrote',len(rows),'bad',len(bad),flush=True)
if bad:print(bad)
