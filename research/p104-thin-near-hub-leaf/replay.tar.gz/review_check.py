#!/usr/bin/env python3
"""Independent rational check of near-hub split-cover/degree certificates.

The signed-frame, common-kernel, price identity and legal-word deductions
are assumptions of the mathematical argument, not established by this code.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import combinations_with_replacement,product
from math import comb
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
S=10**14
M=10**18
BAR=Fraction(128891,1000)
assert M%S==0
ROOT={}

def root(b):
 if b not in ROOT:
  rhs=b**99*S**100;lo,hi=0,(b+1)*S
  while lo+1<hi:
   mid=(lo+hi)//2
   if mid**100<=rhs:lo=mid
   else:hi=mid
  assert lo**100<=rhs<(lo+1)**100
  ROOT[b]=(lo,lo if lo**100==rhs else lo+1)
 return ROOT[b]

def bound(t,upper):
 ans=0
 for b,c in t.items():
  a,z=root(b);ans+=c*(z if ((c>0)==upper) else a)
 return ans

def subt(d):
 p=Counter({17:1,16:-1});p[8*d+1]-=1;p[8*d]+=1;return p

def splitt(d):
 p=Counter();p[8]+=1;p[8*(d-1)]+=1;p[8*d]-=1;return p

def s(d):return bound(subt(d),False)
def split(d):return bound(splitt(d),False)
def value(d):return s(d)+split(d)
def surplus(d):return comb(d,2)*(75-d)-73

def independence_alpha(m):
 n=1<<m;bad=[]
 for triple in combinations_with_replacement(range(n),3):
  if not any(sum((v>>j)&1 for v in triple)==2 for j in range(m)):
   counts=Counter(triple);bad.append(counts)
 optimum=0
 for counts in product(range(3),repeat=n):
  if any(all(counts[i]>=q for i,q in badrow.items()) for badrow in bad):continue
  optimum=max(optimum,sum(counts))
 return optimum

def turan(n,a):
 q,r=divmod(n,a);return (a-r)*comb(q,2)+r*comb(q+1,2)

def prefix_bounds(L,alphas):
 out=[]
 for m,alpha in enumerate(alphas):
  q=L-m
  if q>0:
   nmax=max(n for n in range(76) if turan(n,alpha)<=72-L)
   out.append((q,75-nmax))
 return out

def arbitrary_cost_atleast(w,lo):
 # Any number of roles. Recurrence indexed by unmet coverage, unlike the
 # source's role-count/saturation dynamic program. Allows >73 roles, a
 # harmless relaxation; every weight is >=1 and each lower cost positive.
 dp=[0]+[None]*w
 for need in range(1,w+1):
  dp[need]=min(lo[d]+dp[max(0,need-(d-1))] for d in range(2,77))
 return dp

def main():
 raw=(HERE/'duals.json').read_bytes()
 assert sha256(raw).hexdigest()=='3344a0a5b12621a80bf4699d26a655d2ce5253e9cf3077c7d34e100d288a69c6'
 cert=json.loads(raw);assert cert['scale']==M
 duals={(r['long_count'],r['anchor']):r['mu'] for r in cert['rows']}
 assert len(duals)==len(cert['rows'])
 alpha=tuple(independence_alpha(m) for m in range(4))
 assert alpha==(2,3,4,7)
 for L in range(4):assert turan(75,alpha[L])>72-L
 # A degree-two role {e,s} becomes a singleton after excluding e. Treating
 # all common-side degrees <=2 as pair roles can only overstate capacities.
 assert [comb(d,2)*(75-d) for d in range(3)]==[0,0,73]
 slo={d:s(d) for d in range(3,77)}
 assert all(v>0 for v in slo.values())
 assert all(bound(subt(d),True)<slo[d+1] for d in range(3,76))
 c={d:value(d) for d in range(2,77)}
 assert all(c[d]>0 for d in c)
 # Independent sum of the two separate lower enclosures is conservative.
 base=Counter({609:1,601:1,9:76,17:73,8:-227,16:-73,1:-1})
 raw_upper=bound(base,True)
 def ceiling(costM):return Fraction(104*(raw_upper*(M//S)-costM),76*M)
 def fromS(costS):return ceiling(costS*(M//S))
 best=arbitrary_cost_atleast(75,c)
 # At least two roles: select two explicitly and allow arbitrary extras.
 one=[min(c[d]+best[max(0,w-(d-1))] for d in range(2,77)) for w in range(76)]
 two=min(c[d]+one[max(0,75-(d-1))] for d in range(2,77))
 assert two==c[75]+c[2]
 two_bound=fromS(two);assert two_bound<BAR
 # A single degree-76 split with >=3 pieces has one singleton plus at
 # least two common-side parts, hence pays an extra split(75).
 special=c[76]
 multi_bound=fromS(special+split(75));assert multi_bound<BAR
 def special_upper(extra):return ceiling(special*(M//S)+extra)
 large=special_upper(21*slo[3]*(M//S));assert large<BAR
 F=comb(75,3)-72*73;assert F==62269
 seen=set();counts=Counter();worst=None
 for L in range(4,21):
  q=L-3;bs=prefix_bounds(L,alpha);assert len(bs)==4
  for a in range(3,76):
   if q*a<dict(bs)[q]:counts['impossible']+=1;continue
   simple=((q-1)*slo[3]+4*slo[a])*(M//S)
   if special_upper(simple)<BAR:
    counts['simple']+=1;v=simple
   else:
    mu=duals[(L,a)];assert len(mu)==5 and all(isinstance(t,int) and t>=0 for t in mu)
    seen.add((L,a));counts['dual']+=1
    v=slo[a]*(M//S)+sum(u*(need-a) for u,(_,need) in zip(mu[:4],bs))+mu[4]*(F-surplus(a))
    small=min(slo[d]*(M//S)-sum(mu[:4])*d-mu[4]*surplus(d) for d in range(3,a+1))
    v+=(q-1)*small
    for i in range(q+1,L+1):
     weight=sum(u for u,(end,_) in zip(mu[:4],bs) if i<=end)
     v+=min(slo[d]*(M//S)-weight*d-mu[4]*surplus(d) for d in range(a,76))
    assert special_upper(v)<BAR,(L,a,special_upper(v))
   answer=special_upper(v)
   if worst is None or answer>worst[0]:worst=(answer,L,a)
 assert seen.issubset(duals)
 overall=max(two_bound,multi_bound,large,worst[0]);assert overall<BAR
 print('PASS independent signature multiplicity enumeration:',alpha)
 print('PASS unbounded-role coverage DP: 2+ split minimum from degrees (75,2)')
 print('PASS grouped rational duals:',dict(counts),'checked',len(seen),'unused',len(duals)-len(seen))
 print('multiple roles ceiling:',two_bound)
 print('three-plus pieces ceiling:',multi_bound)
 print('one-role dual worst:',worst)
 print('L>=21 ceiling:',large)
 print('overall exact independent enclosure:',overall)
 print('overall decimal (display only):',float(overall))
 print('PASS strict bound under the documented paper hypotheses')

if __name__=='__main__':main()
