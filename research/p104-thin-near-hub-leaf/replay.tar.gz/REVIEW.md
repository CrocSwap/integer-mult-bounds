# Independent review of the k=76 exceptional near-hub branch

No gap was found in the submitted near-hub argument **under the explicit
hypotheses below**. The lane's exact checker was copied and replayed here; its
recreated `RESULT.json` matched the source byte-for-byte. A separate checker
also verifies the rational bound, using independent signature enumeration,
an unbounded-role coverage dynamic program, independently rounded loss
terms and grouped weak-duality evaluations:

```sh
python3 -I -B review_check.py
```

Its slightly more conservative maximum is

\[
(104/76)\,\mathrm{repo}\le
\frac{61223109320327747}{475000000000000}
=128.8907564638478884\ldots<128.891.
\]

The strict gap is approximately `0.0002435361521116`. The new check uses the
lane's candidate duals, whose copied SHA-256 is
`3344a0a5b12621a80bf4699d26a655d2ce5253e9cf3077c7d34e100d288a69c6`; it does
not independently generate these duals. Its case counts are 99 impossible,
1119 simple-price and 23 dual-certified. The other ceilings are at most
`128.848444082169` for at least two split roles and `128.439963491591` for
one split role with three or more pieces. Numerical checks do not prove the
signed-frame, common-kernel, event-partition, legal-word or invoice bridges.
As a failure control, setting one required dual vector to zero was rejected
even after updating the checker's expected hash in a temporary copy.

## Scope and exceptional-stage accounting

Assume an actual type-B `CallerWord.Legal` word, 76 ordered hosts, 151 odd
target roles, `Q=T=1`, signed `P=-I`, and invertible host `K` diagonals.
There is one role `h` on all stages and one role `g` on all stages except
an exceptional stage `e`; the assigned native singleton incidences belong
to `h,g` on the 75 common stages and to `h` and the unique degree-one leaf
at `e` on the exceptional stage. There are 76 degree-one leaves, one per
stage, and 73 remaining roles of degree at least two. Actual nonempty events
are globally and bijectively assigned to pieces partitioning each role mask,
with the supported event kernels and shared-stage biorthogonality required
by #7852. In particular, **the HOST-to-leaf assignment at `e` is a branch
hypothesis**, not a consequence of merely knowing the role masks.

With `p(x)=x^(99/100)` and `v(d)=p(8d+1)-p(8d)`, the baseline before
split and larger-degree losses is

`(104/76) * [p(609)-76p(8)+p(601)-75p(8)+76v(1)+73v(2)-1]`.

The total coefficient of `p(8)` is `-227`: `76+75` for the assigned hubs
and `76` for the leaves, including the native `e` HOST incidence once. It
must not be subtracted again as an independent contact. This baseline and
the zero correction both require the actual event/invoice attribution, not
just a mask-level relaxation.

## Split coverage and common stages

For any common stage `s`, let `H` contain the roles whose masks include both
`e` and `s`. The global hub `h` is in `H`; the near hub `g` and the
exceptional-stage leaf are not. Rank two and nondegenerate host blocks give
an invertible cross Gram block, hence the `B_e` map on `H` has rank two.
If the assigned `e`-piece of every role in `H` besides `h` also contains
`s`, then those distinct events supply `|H|-1` independent kernel vectors
supported in `H` and killed by `B_e`. Its kernel has dimension `|H|-2`, a
contradiction. Thus at least one of the 73 other roles puts `e` and `s` in
different pieces.

For a split role of degree `D` whose `e`-piece has size `a`, it covers at
most `D-a <= D-1` common stages by this rule. The union over such roles
covers all 75 common stages. The independent checker lowers the price of a
split role to `s(D)+Delta(D)`, gives every split role the optimistic capacity
`D-1` even when it misses `e`, permits arbitrarily many roles, and still
finds a minimum at the two-degree profile `(75,2)`. Here

`s(D)=v(2)-v(D)` and `Delta(D)=p(8)+p(8D-8)-p(8D)`.

With only one split role, `D-a>=75` forces `D=76` and `a=1`. Exactly two
pieces are `{e}` and the full 75 common stages. With at least three pieces,
those common stages are themselves split and incur an extra `Delta(75)`.

In the cheap two-piece case, the special 75-stage event supplies a common
kernel vector on any selected triple of common stages, in addition to the
full-event vectors from the 72 unsplit remaining roles. Thus the
common-kernel sign argument applies with `h,g` as the two universal roles on
those 75 stages, and every such triple must be met in **exactly two**
stages by a remaining role.

A role that was nonleaf before restriction can become degree 1 on the 75
common stages, for example mask `{e,s}`; degree 0 is also harmless to allow
as a relaxation. Group all restricted degrees at most two into the pair
budget: each contributes at most one pair edge and at most the degree-two
triple capacity `73`. For common restricted degree `d>=3`, its full degree
is at least `d`, so monotonicity charges at least `s(d)`. Its full event may
include `e`; its kernel support is still contained in the common overlap
set for a triple contained in that event.

The checker independently enumerates signature maxima `(2,3,4,7)`, derives
the four relevant Turan prefix cuts and the triple surplus requirement
`binom(75,3)-72*73 = 62269`, and checks the proposed nonnegative duals with
integer/rational arithmetic. For `L>=21` long restricted roles, 21 times
the degree-three loss suffices; the other cases use an integer anchor and
the checked prefix/triple duals. Degrees and graph incidences are relaxed,
so the computed ceiling is not a construction.

## Actual odd-idle correction

The source `CallerWordD.legal_masks` forces the `Bw` column of an odd
IDLE on nonempty stage mask `S` to vanish on every target role missing a
stage of `S`: `CallerWord.terms` and `CallerWordD.idle_base` identify its
`Bw` with the incidence vector `incW`. Since singleton leaves occupy
different stages, choose a leaf at a stage outside any chosen `t in S`.
That `Bw` component must vanish, but `CallerThin.leaf_zero` says every leaf
must have a nonzero entry in the unique thin column when the host and thin
are separate event slots. Contradiction. Thus the unique odd IDLE, if any,
has empty stage mask, and its correction is zero; QUERY also has zero
correction. This word-level step needs SPEC legality, target-mask-to-host
support, and the separate event-time/nondegeneracy hypotheses. It is not a
conclusion of abstract per-stage matching alone.

The result does not cover the other exceptional HOST-ownership branch,
near-hub patterns without the global event partition, or general k=76
callers. No legal caller, Lean proof or kappa improvement is established.
