# Validation

The following ran successfully with Python's standard library only:

```text
python3 -I -B check.py
python3 -I -B independent_check.py
python3 -I -B review_check.py
python3 -I -B verify_sources.py
```

`check.py` produces the exact rational enclosure
`122446218640655481/950000000000000 < 128.891`, and enumerates 99 impossible,
1119 elementary, and 23 independently checked dual cases. `independent_check.py`
uses integer Newton root bounds at scale 10^15 and separately reconstructs all
rows; its slightly tighter enclosure is
`244892437281303357/1900000000000000`. `review_check.py`, authored separately,
uses a different unbounded-role coverage dynamic program and separate outward
rounding. Its independently checked enclosure is
`61223109320327747/475000000000000 < 128.891`. It also confirms the dual
file's SHA-256. See [REVIEW.md](REVIEW.md) for structural review and a negative
control in which a necessary dual was zeroed and rejected.

`verify_sources.py` checks that the supplied #7909 source manifest has the
Git blob identity `5b088dc5262472353684efc38274e4817433e6ca` observed at
commit `623d108a514bf9723be0f80e0231f50526155d7e`, that its replay archive
matches the committed manifest's SHA-256, and that seven selected upstream
source files inside it have their pinned Git blob identities. It does not
replay or independently prove those upstream sources. The optional dual
searcher uses SciPy only to find multipliers; no SciPy or numerical solver is
used by the verification scripts.

The new rank, event-partition, legal-word, and price arguments remain paper
proofs under the explicit assumptions in [README.md](README.md). The checks
above do not prove those assumptions, construct a legal caller, prove a
result for all k=76 callers, or establish a kappa improvement.
