#!/usr/bin/env python3
"""Exact arithmetic for the near-hub, exceptional leaf-HOST branch.

Conditional on the hypotheses and paper implications in README.md.  This does
not establish a legal word, the global partition, or the linear algebra.
SciPy is NOT used in the verification; candidate duals are simply checked.
"""
from collections import Counter
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction
from itertools import combinations,product
from math import comb
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
S=10**14
M=10**18
BAR=Fraction(128891,1000)
ALPHAS=(2,3,4,7)
CACHE={}
def root(b):
 if b not in CACHE:
  target=b**99*S**100
  lo,hi=0,(b+1)*S
  while lo+1<hi:
   m=(lo+hi)//2
   if m**100<=target:lo=m
   else:hi=m
  assert lo**100<=target<(lo+1)**100
  CACHE[b]=(lo,lo if lo**100==target else lo+1)
 return CACHE[b]
def enclosure(terms,upper=False):
 return sum(c*root(b)[int((c>0)==upper)] for b,c in terms.items() if c)
def lower(terms):return enclosure(terms,False)
def upper(terms):return enclosure(terms,True)
def add(d,k,v):d[k]+=v
def s_terms(d):
 t=Counter({17:1,16:-1});add(t,8*d+1,-1);add(t,8*d,1);return t
def c_terms(d):
 # s(d) + p(8) + p(8d-8) - p(8d)
 t=Counter({17:1,16:-1});add(t,8*d+1,-1);add(t,8,1);add(t,8*d-8,1);return t
def delta_terms(d):
 t=Counter();add(t,8,1);add(t,8*d-8,1);add(t,8*d,-1);return t
def loss(d):return lower(s_terms(d))
def f(d):return comb(d,2)*(75-d)-73
def graph_floor(n,a):
 t,r=divmod(n,a);return (a-r)*comb(t,2)+r*comb(t+1,2)
def bounds(L):
 return [(L-m,75-max(n for n in range(76) if graph_floor(n,a)<=72-L)) for m,a in enumerate(ALPHAS) if L>m]
def distinguishes(tup,m):
 return any(sum((x>>i)&1 for x in tup)==2 for i in range(m))
def signature_max(m):
 best=0;winner=None
 for count in product(range(3),repeat=1<<m):
  if sum(count)<=best:continue
  seq=[x for x,c in enumerate(count) for _ in range(c)]
  if all(distinguishes(t,m) for t in combinations(seq,3)):
   best=sum(count);winner=seq
 return best,winner

def dec_up(frac):
 with localcontext() as c:
  c.prec=65;c.rounding=ROUND_CEILING
  return str((Decimal(frac.numerator)/Decimal(frac.denominator)).quantize(Decimal('0.000000000001')))

def main():
 assert M%S==0
 sig=[]
 for m,expected in enumerate(ALPHAS):
  got,winner=signature_max(m);assert got==expected
  sig.append({'bits':m,'max':got,'witness':winner,'vectors':3**(1<<m)})
 assert all(graph_floor(75,ALPHAS[L])>72-L for L in range(4))
 # Finite root enclosures make monotonicity of relevant degree losses exact.
 lo={d:loss(d) for d in range(3,77)}
 assert all(x>0 for x in lo.values())
 assert all(upper(s_terms(d))<lo[d+1] for d in range(3,76))
 cost={d:lower(c_terms(d)) for d in range(2,77)}
 assert all(cost[d]>0 for d in cost)
 assert all(upper(c_terms(d))<cost[d+1] for d in range(2,76))
 # Two-piece fragmentation: least loss occurs at 1 + (d-1).
 for d in range(4,77):
  for a in range(2,d-1):
   term=Counter();add(term,8*a,1);add(term,8*(d-a),1);add(term,8*d,-1)
   assert lower(term)>upper(delta_terms(d))
 base=Counter();add(base,609,1);add(base,601,1);add(base,9,76);add(base,17,73);add(base,8,-227);add(base,16,-73);add(base,1,-1)
 base_up=upper(base)
 def ceiling_scaled(lossM):return Fraction(104*(base_up*(M//S)-lossM),76*M)
 def ceiling_loss(lossS):return ceiling_scaled(lossS*(M//S))
 # Give every split role d-1 units of coverage, even if it does not meet e.
 # DP allows 73 roles and clips any excess at 75; r>=2 includes any split
 # outside the e-cover. This is a lower bound for the true total loss.
 INF=10**100
 dp=[INF]*76;dp[0]=0;least=INF;best_r=None
 for r in range(1,74):
  nxt=[INF]*76
  for n,x in enumerate(dp):
   if x==INF:continue
   for d in range(2,77):
    j=min(75,n+d-1);nxt[j]=min(nxt[j],x+cost[d])
  dp=nxt
  if r>=2 and dp[75]<least:least=dp[75];best_r=r
 assert best_r==2 and least==cost[75]+cost[2]
 cover_ceiling=ceiling_loss(least);assert cover_ceiling<BAR
 # A single split must cover all 75, so D=76 and the e-piece has size 1.
 # If there are >=3 pieces, merging all common-stage pieces down to two
 # gives the extra Delta(75), on top of c(76).
 special=cost[76]
 multiece=special+lower(delta_terms(75))
 multiple_piece_ceiling=ceiling_loss(multiece);assert multiple_piece_ceiling<BAR
 # One exact 2-piece exceptional role: on common stages its 75-piece is
 # whole.  The other 72 roles obey triple + prefix constraints.
 special_ceiling=lambda z:ceiling_scaled(special*(M//S)+z)
 assert special_ceiling(21*lo[3]*(M//S))<BAR
 required=comb(75,3)-72*73;assert required==62269
 # Fractional degree-only control: each of five long positions mixes 11/20
 # of degree 3 with 9/20 of degree 42.  This is a relaxation, not a mask,
 # frame, assignment, or legal word; it shows why integer anchoring matters.
 mean=Fraction(11*3+9*42,20)
 assert all(q*mean>=need for q,need in bounds(5))
 assert Fraction(5*(11*f(3)+9*f(42)),20)>=required
 loss_hi=Fraction(5*(11*upper(s_terms(3))+9*upper(s_terms(42))),20)
 control=Fraction(104,76*S)*(lower(base)-upper(c_terms(76))-loss_hi)
 assert control>BAR
 obj=json.loads((HERE/'duals.json').read_text());assert obj['scale']==M
 rows={(r['long_count'],r['anchor']):r['mu'] for r in obj['rows']}
 assert len(rows)==len(obj['rows'])
 used=set();evaluated=[];counts=Counter()
 for L in range(4,21):
  q=L-3;bs=bounds(L);assert len(bs)==4
  b=dict(bs)[q]
  for a in range(3,76):
   if q*a<b:counts['impossible']+=1;continue
   z=((q-1)*lo[3]+4*lo[a])*(M//S)
   if special_ceiling(z)<BAR:
    counts['simple']+=1;result=special_ceiling(z)
   else:
    key=(L,a);assert key in rows,('missing',key)
    mu=rows[key];assert len(mu)==5 and all(isinstance(t,int) and t>=0 for t in mu)
    used.add(key);counts['dual']+=1
    # Independent per-position minimization of the exact dual Lagrangian.
    z=sum(u*need for u,(_,need) in zip(mu[:4],bs))+mu[4]*required
    for i in range(1,L+1):
     domain=range(3,a+1) if i<q else ([a] if i==q else range(a,76))
     weight=sum(u for u,(end,_) in zip(mu[:4],bs) if i<=end)
     z+=min(lo[d]*(M//S)-weight*d-mu[4]*f(d) for d in domain)
    result=special_ceiling(z);assert result<BAR,(key,str(result),dec_up(result))
   evaluated.append((result,L,a))
 # Generator may include redundant near-threshold rows due to conservative float screen.
 assert used.issubset(rows)
 worst=max(evaluated)
 large=special_ceiling(21*lo[3]*(M//S))
 overall=max(cover_ceiling,multiple_piece_ceiling,worst[0],large)
 assert overall<BAR
 # Local CROSS control: pair diagonals meet all triples, but zero alternating edges.
 edges={(0,2),(1,3)}
 assert all(any(set(e).issubset(t) for e in edges) for t in combinations(range(4),3))
 assert sum((a%2)!=(b%2) for a,b in edges)==0
 report={
  'scope':'conditional k76 near-hub e-leaf HOST branch; global role/event partition, singleton hub contact assignments, P=-I nondegenerate signed frame, SPEC-legal type-B word bridge',
  'precision_root_scale':S,'dual_scale':M,'root_count':len(CACHE),
  'base_upper':str(ceiling_loss(0)),'base_upper_decimal':dec_up(ceiling_loss(0)),
  'two_or_more_split_roles':{'coverage_relaxation_minimum':str(Fraction(least,S)),'worst_role_count':best_r,'ceiling':str(cover_ceiling),'ceiling_decimal':dec_up(cover_ceiling)},
  'one_split_three_or_more_pieces':{'ceiling':str(multiple_piece_ceiling),'ceiling_decimal':dec_up(multiple_piece_ceiling)},
  'one_split_two_pieces':{'required_triple_surplus':required,'L4_through20_worst':str(worst[0]),'L4_through20_worst_decimal':dec_up(worst[0]),'worst_L':worst[1],'worst_anchor':worst[2],'L21_plus_ceiling':str(large),'L21_plus_ceiling_decimal':dec_up(large),'case_counts':dict(counts),'exact_duals_verified':len(used),'signature_controls':sig},
  'fractional_degree_only_control':{'long_roles':5,'degree_mix':{'3':'11/20','42':'9/20'},'other_nonleaf_roles':67,'modeled_price_lower':str(control),'above_bar':True,'meaning':'fractional degree-only control; no role masks, signed frame, event assignment, or legal caller word'},
  'overall_ceiling':str(overall),'overall_ceiling_decimal':dec_up(overall),'bar':str(BAR),'strict_bar_passed':True,
  'proof_status':'finite arithmetic only; paper structural lemmas and legal bridge not kernel checked by this checker',
  'local_cross_control':{'pair_edges':[[0,2],[1,3]],'triple_control':'pass','alternating_cross_edges':0,'required_alternating_edges':2}
 }
 (HERE/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))

if __name__=='__main__':main()
