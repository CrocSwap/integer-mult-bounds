This packet is distributed under Apache License 2.0; see LICENSE. It was
prepared with substantial OpenAI Codex assistance. Its exceptional-stage
pair cut, conditional price certificate and finite checkers are paper and
computer arguments; they are not represented as Lean theorems.

The original P104 signed-frame, event and invoice definitions and the #7869
LP certificate are credited to DreamingOfClouds with Claude Opus 5.5 via
Claude Code. The #7861 common-kernel/shared-hub rank work, #7858 odd-idle
mask-price package, #7883 corrected split-family packet and #7909 zero-split
packet were prepared by Clear1nsight with substantial OpenAI Codex assistance
and credit DreamingOfClouds and Rohan Arun for underlying source material
and caller data. The original notices are preserved inside the byte-pinned
#7909 replay archive under source/p7909/.

The independent finite review was performed by a separate Codex agent. No
claim is made for all k=76 callers, a legal word, or a kappa improvement.
