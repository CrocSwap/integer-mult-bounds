#!/usr/bin/env python3
"""All-beta two-direct-receipt cut for the 32 #7966 paired-pulse starts.

Grant every original non-sink live row at every clock as historical stock,
allow arbitrary free XORs even across charts of the same direct price, and
retain the original two-pulse clocks and all other paid arrivals. Two original
sink arrivals are removed; each is paired with a strictly cheaper positive
direct ingress. All original output rows must be produced at their endpoints.
"""
from collections import Counter
from pathlib import Path
import hashlib,json,sys
H=Path(__file__).resolve().parent;sys.path[:0]=[str(H/'vendor'),str(H)]
import binary_operator as op
PINNED={'PR-7966.json':'4327664f7eaf8d2c225b954f979fb785836c500f9bf06a5a1a72d054d359a459','R6-ALL-BETA-CUT.json':'135a761f88c75e2980b38ea19a02d9042e4c3338fe86e735c7f7943cf70ef44e','R6-PAIRED-SCREEN.json':'88067384ccaaeddaac933c5125453721a1c570622cae631a9e60ad5e82563a7b'}
for name,digest in PINNED.items():assert hashlib.sha256((H/'inputs'/name).read_bytes()).hexdigest()==digest
pub=json.loads((H/'inputs/PR-7966.json').read_bytes());assert pub['pr']==7966 and pub['head']=='3171fd2375ec8330109b9622b91e3949898cfb70'
from common_beta import bits,basis_labeled,solve_labeled

def add(B,z):
 while z:
  p=z.bit_length()
  if p not in B:B[p]=z;return
  z^=B[p]

w=op.load_json(H/'inputs/WORD.json.gz',op.WORD_GZIP,True);assert op.canonical_hash(w)==op.WORD
atlas=op.Atlas(w['frames']);f,rev,bridge_omit=op.native_checks(w,atlas)
inc=f.stock[1];assert len(inc)==537 and len(f.demand[1])==537 and w['start'].count(1)==0
bas=basis_labeled((o.row,1<<i) for i,o in enumerate(inc));assert len(bas)==537
idx={o.label:i for i,o in enumerate(inc)};G=[f.packets[o.label].grade for o in inc]
assert Counter(G)=={1:342,2:189,4:6}
D=[0]*len(inc)
for o in f.demand[1]:
 coords=solve_labeled(bas,o.row);assert coords is not None
 for i in bits(coords):D[i]|=1<<~o.label
X=[d^((d&((1<<111)-1))<<111) for d in D]
for i,o in enumerate(inc):
 for j,x in enumerate(X):assert ((o.row&x).bit_count()&1)==int(i==j)
P=sum(1<<j for j,c in enumerate(w['final']) if c!=1)|((1<<222)-1)|(1<<411)
S=json.loads((H/'inputs/R6-PAIRED-SCREEN.json').read_bytes());cases=[]
for rec in S['visible_witnesses']:
 for target in rec['passing_targets']:cases.append((rec,target))
assert len(cases)==32
old=json.loads((H/'inputs/R6-ALL-BETA-CUT.json').read_bytes())
new_starts={(r['upstream'],r['partner'],t['old_sink_packet']) for r,t in cases}
old_starts={(x['first'],x['partner'],x['old_sink']) for x in old['cases']}
assert len(new_starts)==len(old_starts)==32 and new_starts==old_starts
labels=sorted({i for rec,t in cases for i in (rec['upstream'],rec['partner'])});tag={i:1<<j for j,i in enumerate(labels)}
grades={c:atlas.grade(c,1) for c in atlas.body if c!=1};assert set(grades.values())=={1,2,4,6,7,8}
firstswap=next(i for i,e in enumerate(w['program']) if e[0]=='SWAP')
assert all(e[0] in ('SWAP','CLEAR') for e in w['program'][firstswap:])
assert all(e[1]>=680 for e in w['program'][:firstswap])
fields=[(c,1<<i,0) for i,c in enumerate(w['start'])]+[None]*w['owned_fields'];sourcebases={1:{},2:{}};occ=Counter();before={};arrival_tags={};qstate=None;mid=680;point=max(i for i,e in enumerate(w['program']) if e[0]=='SWAP')+1
assert all(e[0]=='CLEAR' for e in w['program'][point:])
def stock(addr):
 z=fields[addr]
 if z is None or z[0]==1:return
 g=grades[z[0]]
 if g in (1,2):
  occ[g]+=1;add(sourcebases[g],z[1] | (z[2]<<680))
for i in range(len(fields)):stock(i)
for clock,e in enumerate(w['program']):
 if clock==point:qstate=[fields[o.label] for o in inc]
 code,addr,*ar=e
 if code=='INIT':assert fields[addr] is None;fields[addr]=(ar[0],0,0)
 elif code=='CLEAR':assert fields[addr][0]==ar[0];fields[addr]=None
 elif code=='ADD':
  j,c=ar;x=fields[addr];y=fields[j];assert x[0]==y[0]==c and j!=addr
  fields[addr]=(c,x[1]^y[1],x[2]^y[2])
 elif code=='SWAP':j=ar[0];fields[addr],fields[j]=fields[j],fields[addr]
 else:
  s,t=ar;x=fields[addr];assert code=='MOVE' and x[0]==s and s!=1 and mid==addr and f.packets[mid].clock==clock
  if mid in tag:before[mid]=x[2]
  if t==1:arrival_tags[mid]=x[2]
  fields[addr]=(t,x[1],x[2]^tag.get(mid,0));mid+=1
 stock(addr)
 if code=='SWAP':stock(j)
assert qstate is not None and all(z is not None and z[:2]==(1,o.row) for z,o in zip(qstate,inc))
assert set(arrival_tags)=={o.label for o in inc}
assert all(z[2]==arrival_tags[o.label] for z,o in zip(qstate,inc))
assert [c for c,row,t in fields[:680]]==w['final']
assert [row for c,row,t in fields[:680]]==f.output
# A spanning set of the union of all grade-g field occurrences, including the
# formal tags, grants impossible cross-chart and cross-time XORs. Fixed-stock
# matching is checked for every forbidden old sink coordinate on this basis.
static_checks=Counter();violations=[]
for g,bb in sourcebases.items():
 for z in bb.values():
  v=z&((1<<680)-1)
  for i,x in enumerate(X):
   if G[i]>g:
    static_checks[g]+=1
    if (v&x).bit_count()&1:violations.append([g,inc[i].label])
assert not violations
eligible=[i for i,g in enumerate(G) if g in (2,4)]
assert len(eligible)==195
out=[];counts=Counter()
for n,(rec,ta) in enumerate(cases):
 k,j=rec['upstream'],rec['partner'];target=ta['old_sink_packet'];ri=idx[target];assert ri in eligible
 early,late=sorted((k,j),key=lambda x:f.packets[x].clock)
 assert not(before[late]&tag[early])
 assert (rev.packets[k].arrival.row&P)==(rev.packets[j].arrival.row&P)!=0
 q=sum(((bool(z[2]&tag[k])!=bool(z[2]&tag[j]))<<i) for i,z in enumerate(qstate))
 retained_g1=[inc[i].label for i in bits(q) if G[i]==1];assert retained_g1
 dual=0
 for i in bits(q):dual^=X[i]
 checked=Counter();bad=[]
 for g,bb in sourcebases.items():
  for z in bb.values():
   v=z&((1<<680)-1);tags=z>>680;lam=bool(tags&tag[k])!=bool(tags&tag[j]);alpha=lam^bool((v&dual).bit_count()&1);checked[g]+=1
   if alpha:bad.append(g)
 assert not bad
 # Exhaust possible second original removals and grade assignments. A source
 # grade g can have an old coordinate only at original grade <= g, so no
 # permitted two-by-two support pattern has a nonzero determinant.
 pairnum=patterns=0;support_perms=0
 for si in eligible:
  if si==ri:continue
  pairnum+=1
  for g1 in (g for g in (1,2) if g<G[ri]):
   for g2 in (g for g in (1,2) if g<G[si]):
    patterns+=1
    a,b,c,d=G[ri]<=g1,G[si]<=g1,G[ri]<=g2,G[si]<=g2
    support_perms+=int((a and d) or (b and c))
 assert support_perms==0 and pairnum==194
 counts['named_starts']+=1;counts['anchored_second_removals']+=pairnum;counts['cheaper_grade_patterns']+=patterns
 out.append({'case':n,'first':k,'partner':j,'first_clock':f.packets[k].clock,'partner_clock':f.packets[j].clock,'target':target,'target_grade':G[ri], 'q_sink_labels':[inc[i].label for i in bits(q)],'q_retained_grade_one_labels':retained_g1,'alpha_basis_checks':dict(checked),'alpha_nonzero':bad,'second_removals':pairnum,'strictly_cheaper_grade_patterns':patterns,'support_permutations':support_perms,'old_target_first_read':ta['original_first_touch']})
# Mutation controls: the same alpha and old-coordinate tests must reject a
# synthetic one-bit pulse tag and a grade-one row carrying grade-four stock.
rec0=cases[0][0];k0,j0=rec0['upstream'],rec0['partner'];state0=qstate
q0=sum(((bool(z[2]&tag[k0])!=bool(z[2]&tag[j0]))<<i) for i,z in enumerate(state0))
dual0=0
for i in bits(q0):dual0^=X[i]
def alpha(z,k,j,dual):
 v=z&((1<<680)-1);t=z>>680
 return int(bool(t&tag[k])!=bool(t&tag[j])) ^ ((v&dual).bit_count()&1)
def prohibited(g,v):return any(G[i]>g and (v&x).bit_count()&1 for i,x in enumerate(X))
assert alpha(tag[k0]<<680,k0,j0,dual0)==1
old4=next(i for i,g in enumerate(G) if g==4);assert prohibited(1,inc[old4].row)
# Off-diagonal support is a real determinant, but this cut forbids the needed
# two entries for all the enumerated cheaper grade pairs.
assert (0*0)^(1*1)==1
r={'status':'PASS_ALL_BETA_TWO_CHEAPER_RECEIPT_CUT','sources':{'pr7966_head':'3171fd2375ec8330109b9622b91e3949898cfb70','pr7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','word_gzip_sha256':op.WORD_GZIP,'word_canonical_sha256':op.WORD,'r6_32_start_receipt_sha256':hashlib.sha256((H/'inputs/R6-PAIRED-SCREEN.json').read_bytes()).hexdigest()},'original_controls':{'native_forward_transpose_all_680_rows':'PASS','bridge_411_add_omission_both_orientations':'PASS','bridge_411_add_clock':bridge_omit,'dirty_retirements_each_direction':3554,'original_sink_basis_rank':537,'sink_original_paid_grade_counts':dict(Counter(G)),'paid_move_never_starts_at_sink':'PASS','all_public_writes_are_terminal_swaps':'PASS','after_first_swap_only_swaps_and_clears':'PASS','sink_arrival_tags_persist_to_terminal':'PASS'},'source_stock':{'scope':'Every field in every grade-1/2 nonsink chart at every native clock, including zero-original states and initial public fields. The augmented source bases additionally grant free cross-time/cross-chart XOR inside each grade.','live_field_occurrences_by_grade':dict(occ),'augmented_basis_rank_by_grade':{str(g):len(b) for g,b in sourcebases.items()},'fixed_stock_forbidden_coordinate_checks':dict(static_checks),'violations':violations},'counts':dict(counts),'cases':out,'controls':{'synthetic_nonzero_pulse_tag_is_detected':'PASS','synthetic_grade_one_source_with_grade_four_coordinate_is_detected':'PASS','off_diagonal_nonzero_control':'PASS'},'scope':'For the 32 named R6 starts, inject an arbitrary common beta into two original independent nonsink MOVE outputs at their original clocks. Remove the named old sink packet and any second old sink packet; replace each by one individually strictly cheaper positive-grade direct chart-1 receipt, with any chronology and any source banks. All other paid receipts remain, all 537 sink terminal equations stay required, and source XOR, retention, local correction and decoding are free. Up to two direct paid replacements only; cross-chart new paid routes, changed source slots or pulse vectors, different tariffs, retargeted terminal outputs, extra ingress, and caller changes are not covered.'}
blob=json.dumps(r,indent=2,sort_keys=True)+'\n'
if '--verify' in sys.argv:assert (H/'TWO-RECEIPT-CUT.json').read_text()==blob,'frozen result differs'
else:(H/'TWO-RECEIPT-CUT.json').write_text(blob)
print(json.dumps({'status':r['status'],'source_stock':r['source_stock'],'counts':r['counts'],'first':out[0]},indent=2))
