#!/usr/bin/env python3
"""Pinned #7830: equal protected footprint, actual live sender stock, two independent pulses.

Necessary condition only. Source-local XOR, pulse insertion and sink ingress
are granted free except that live nonzero vectors must exist at clocks and
paired MOVEs cannot have a directed GF(2) dependence. Recorded sink routes are
only potential ingress directions, not constructed changed words.
"""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib,json,sys

ROOT=Path(__file__).resolve().parent
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
import binary_operator as op

def bits(x):
 while x:
  y=x&-x; yield y.bit_length()-1; x^=y

def basis_labeled(pairs):
 b={}
 for row,lab in pairs:
  while row:
   p=row.bit_length()
   if p not in b:
    b[p]=(row,lab);break
   s,t=b[p];row^=s;lab^=t
 return b

def solve_labeled(b,x):
 lab=0
 while x:
  p=x.bit_length()
  if p not in b:return None
  y,z=b[p];x^=y;lab^=z
 return lab

def common(left,right):
 """Returns basis of intersection, with field XOR witnesses on both sides."""
 rb=basis_labeled(right); quotient={};common=[]
 for row,lab in basis_labeled(left).values():
  q=row
  for p,(v,_) in sorted(rb.items(),reverse=True):
   if q>>(p-1)&1:q^=v
  while q:
   p=q.bit_length()
   if p not in quotient:
    quotient[p]=(q,row,lab);break
   v,x,y=quotient[p];q^=v;row^=x;lab^=y
  if not q and row:
   witness=solve_labeled(rb,row); assert witness is not None
   common.append((row,lab,witness))
 return common

def sender_space(snapshot,earlier=None,exclude_moved=False):
 # The first pulse may contaminate later live fields. An even-parity
 # combination of their old rows is unchanged by that pulse; odd ones are
 # paired with an anchor. Grant those combinations at no local cost.
 clean=[];odd=[]
 for addr,row,tag in snapshot['stock']:
  if exclude_moved and addr==snapshot['address']:continue
  pair=(row,1<<addr)
  if earlier is not None and tag>>earlier&1:odd.append(pair)
  else:clean.append(pair)
 if odd:
  a,lab=odd[0]
  clean += [(a^b,lab^m) for b,m in odd[1:]]
 return clean

def first_touch(program,p):
 # Field addresses here match the packet identifiers (checked below).
 for i,e in enumerate(program[p.clock+1:],p.clock+1):
  if e[1]==p.arrival.label or e[0] in ('ADD','SWAP') and e[2]==p.arrival.label:
   return {'clock':i,'event':e}
 return None

def main():
 raw=(ROOT/'inputs/WORD.json.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()==op.WORD_GZIP
 w=op.load_json(ROOT/'inputs/WORD.json.gz',op.WORD_GZIP,True);assert op.canonical_hash(w)==op.WORD
 A=op.Atlas(w['frames']);f=op.run_tape(w,A,False);rev=op.run_tape(w,A,True)
 assert f.output==op.expected_operator(False) and rev.output==op.expected_operator(True)
 assert f.dirty==rev.dirty==3554
 P=sum(1<<i for i,c in enumerate(w['final']) if c!=1)|((1<<222)-1)|(1<<411)
 groups=defaultdict(list);nonsink=[]
 for k,p in f.packets.items():
  if p.receiver!=1:
   nonsink.append(k);groups[rev.packets[k].arrival.row&P].append(k)
 data=((ROOT/'inputs/UPSTREAM-FIRST.json')).read_bytes();first=json.loads(data)['all']
 byfirst=defaultdict(list)
 for e in first:byfirst[e['upstream_packet']].append(e)
 assert len(byfirst)==512 and len(first)==1029 and len(nonsink)==2337
 pairs={(k,j) for k in byfirst for j in groups[rev.packets[k].arrival.row&P] if k!=j and rev.packets[k].arrival.row&P}
 needed={j for p in pairs for j in p}
 # Exact linear influence of injected pulses in original forward circuit.
 cells=[(c,1<<j,0) for j,c in enumerate(w['start'])]+[None]*w['owned_fields'];snap={};mid=w['public']
 for clock,e in enumerate(w['program']):
  code,addr,*arg=e
  if code=='INIT':assert cells[addr] is None;cells[addr]=(arg[0],0,0)
  elif code=='CLEAR':assert cells[addr][0]==arg[0];cells[addr]=None
  elif code=='ADD':
   src,chart=arg;x=cells[addr];y=cells[src];assert x[0]==y[0]==chart
   cells[addr]=(chart,x[1]^y[1],x[2]^y[2])
  elif code=='SWAP':
   src=arg[0];cells[addr],cells[src]=cells[src],cells[addr]
  else:
   assert code=='MOVE';source,dest=arg;x=cells[addr];assert x[0]==source
   assert f.packets[mid].clock==clock and f.packets[mid].arrival.row==x[1] and mid==addr
   if mid in needed:
    snap[mid]={'address':addr,'clock':clock,'tag':x[2],'stock':[(i,y[1],y[2]) for i,y in enumerate(cells) if y is not None and y[0]==source]}
   # A symbolic independent unit perturbation is injected after this MOVE.
   cells[addr]=(dest,x[1],x[2]^(1<<mid));mid+=1
 assert len(snap)==len(needed)
 assert [x[1] for x in cells[:w['public']]]==f.output
 # Exact sink dual direction X_i paired against upstream stock rows.
 inc=f.stock[1];B=basis_labeled((o.row,1<<i) for i,o in enumerate(inc));assert len(B)==537
 D=[0]*len(inc)
 for o in f.demand[1]:
  co=solve_labeled(B,o.row);assert co is not None
  for i in bits(co):D[i]|=1<<~o.label
 X={o.label:d^((d&((1<<111)-1))<<111) for o,d in zip(inc,D)}
 for o in inc:assert sum(((o.row&v).bit_count()&1)<<i for i,v in enumerate(X.values()))==(1<<inc.index(o))
 c=Counter();results=[];witnesses=[]
 for k,j in sorted(pairs):
  pk,pj=f.packets[k],f.packets[j]
  early,late=sorted((k,j),key=lambda q:f.packets[q].clock)
  dependence=bool(snap[late]['tag']>>early&1)
  c['equal_protected_directed_pairs']+=1
  if dependence:
   c['dependent_pairs']+=1;continue
  c['independent_pairs']+=1
  left=sender_space(snap[early]);right=sender_space(snap[late],early)
  cc=common(left,right)
  if not cc:c['no_common_live_sender_vector']+=1;continue
  c['common_nonzero_live_vector']+=1
  passing=[]
  for item in byfirst[k]:
   target=item['removed_sink_packet'];x=X[target]
   v=next((abc for abc in cc if (abc[0]&x).bit_count()&1),None)
   if v is None:continue
   touch=first_touch(w['program'],f.packets[target]);before=bool(touch and pk.clock<touch['clock'])
   c['visible_target_pairs']+=1;c['visible_target_before_original_first_touch']+=before
   beta,le,ri=v
   passing.append({'old_sink_packet':target,'new_grade':item['new_to_sink_grade'],'old_grade':item['old_sink_grade'],'original_first_touch':touch,'pulse_arrives_before_first_touch':before,
     'beta_input_coordinates':list(bits(beta)),'earlier_source_field_xor':list(bits(le)),'later_source_field_xor':list(bits(ri))})
  rec={'upstream':k,'partner':j,'early':early,'late':late,'first':{'route':[pk.source,pk.receiver],'clock':pk.clock,'grade':pk.grade},'partner_detail':{'route':[pj.source,pj.receiver],'clock':pj.clock,'grade':pj.grade},'protected_footprint':list(bits(rev.packets[k].arrival.row&P)), 'full_output_difference':list(bits(rev.packets[k].arrival.row^rev.packets[j].arrival.row)), 'actual_live_source_sizes':[len(snap[early]['stock']),len(snap[late]['stock'])],'intersection_rank':len(cc),'intersection_basis': [{'beta_input_coordinates':list(bits(v)),'early_fields':list(bits(a)),'late_fields':list(bits(b))} for v,a,b in cc], 'passing_targets':passing}
  results.append(rec)
  if passing:witnesses.append(rec)
 c['independent_pairs_with_visible_target']=len(witnesses)
 data3295=next(o for o in inc if o.label==3295);i=inc.index(data3295)
 target={'upstream':3373,'old_sink_packet':3295,'protected_footprint':list(bits(rev.packets[3373].arrival.row&P)), 'matching_partner_packets':groups[rev.packets[3373].arrival.row&P], 'partner_3372_to_3373_dependency':bool(snap[3373]['tag']>>3372&1), 'first_read_3295':first_touch(w['program'],f.packets[3295]),'first_read_3372':first_touch(w['program'],f.packets[3372]),'first_read_3373':first_touch(w['program'],f.packets[3373]),'sink_output_dependence_of_3295':list(bits(D[i])), 'bridge_packet_3553':{'clock':f.packets[3553].clock,'route':[f.packets[3553].source,f.packets[3553].receiver],'grade':f.packets[3553].grade,'payload_input_coordinates':list(bits(f.packets[3553].arrival.row))},'bridge_owner':411}
 receipt={'status':'BOUNDED_NECESSARY_CONDITION_SCREEN','sources':{'7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','word_gzip_sha256':op.WORD_GZIP,'word_canonical_sha256':op.WORD,'upstream_first_sha256':hashlib.sha256(data).hexdigest()},'model':'Two original nonsink MOVE output injections of identical input-space beta; protected footprints agree and are nonzero, no earlier pulse may influence the later original MOVE field. Beta is in both actual live cochart sender spans immediately before each MOVE, and the later combination has even sensitivity to the earlier pulse. The 512 first MOVEs are those in the 1029 R5 source/old-sink pairs, and the second ranges over all 2337 original nonsink MOVEs. All actual live cells, including the in-flight field, are granted as arbitrary free XOR sources. An otherwise unchanged original sink packet may be exchanged for one direct paid ingress from the first receiver. No insertion schedule, dirty-state cleanup, terminal restoration, or complete price is claimed.', 'word_checks':{'original_forward_and_transpose_680_squared':'PASS','original_dirty_retirements_each_orientation':3554,'protected_owner_411_original_row':list(bits(f.output[411]))},'counts':dict(c),'target_3373_3295':target,'independent_with_common_stock':results,'visible_witnesses':witnesses}
 (OUT/'COMMON-BETA.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'counts':dict(c),'target_3373_3295':target,'sample_visible':witnesses[:3]},indent=2))
if __name__=='__main__':main()
