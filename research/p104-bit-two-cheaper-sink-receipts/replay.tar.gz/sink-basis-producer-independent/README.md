# Independent audit: two cheaper sink receipts

The sealed R7 cut survives independent audit in its stated model. **Counting qualification:** the 32 starts are directed first/partner/target records, representing **20 unordered pulse-pair/target starts** and 11 unordered pulse pairs. The stated 6,208 second removals and 11,152 cheaper-grade patterns count directed, anchored records; they are not counts of distinct physical configurations. The result covers the common-β, two-pulse starts inherited from [#7966 at `3171fd2375ec8330109b9622b91e3949898cfb70`](https://github.com/CrocSwap/integer-mult-bounds/pull/7966), with the other native paid routes fixed and exactly two individually cheaper positive-grade direct sink receipts replacing two original receipts. All original sink terminal outputs, including owner 411, are required. No changed word, new price improvement or κ bound is asserted.

## Independent source and stock check

The sealed producer source tarball's SHA-256 is `3657dd74b075c1465352844d03e682ef6b5fe7978477573acac5164bf26312a4`. This packet retains its unmodified producer, frozen receipt, exact source notices and required inputs. The audit was written without importing its interpreter, producer or low-pivot verifier. The pinned native word has canonical SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. Read-only GitHub metadata identified the requested #7966 head, and its pinned published `SOURCES.json` Git blob authenticates the outer archive. The outer archive authenticates the original paired archive, whose two R6 receipts match the sealed R7 inputs byte for byte. [PROVENANCE.json](PROVENANCE.json) records the independently checked provenance hashes. It is a snapshot of the read-only source check; the published upstream archives can be obtained through the linked PR.

The new raw-tape interpreter independently checked all 680 original public output equations and endpoints, all 636 rational frames, and the exact nested direct grades to the full 8D sink: `{1,2,4,6,7,8}`. There is no grade-3 source. Before any terminal SWAP, public fields are not written; after the first, the original tape has only CLEAR and SWAP. All 680 terminal swaps are disjoint public/private pairs. Thus, in this fixed-route model, a new sink arrival cannot be carried into a nonsink source by a later original operation.

For every grade-1 or grade-2 bank, the audit captures the initial state and each new or changed live field through the full tape. It separately checks 2,505 grade-1 and 3,341 grade-2 pre-contact operand uses were already captured. Any unchanged live field still has the value captured when it was last modified, so the historical span includes every original contact. Giving each grade the XOR-span of **all** its captured rows across banks and clocks is an optimistic relaxation. The independent augmented bases have ranks **453 and 549**; respectively **88,335 and 3,294** higher-price coordinate tests are zero, as in the sealed receipt. Every one of the 4,063 captured states also satisfies the common-pulse tag invariant for every one of the 32 directed records.

## All-β argument and owner 411

Let `T` be the original 537-dimensional sink-output space with basis `e_i` given by the old ingress rows, and complement it with the 143 original nonsink output rows. Let `q_i` be the joint pulse parity at sink ingress `i`. A retained old ingress is `e_i + q_i β`; a source occurrence is `v + λβ`. Independent coordinate reconstruction verifies the invariant `λ = q·v_T` on every captured source state, where `v_T` is the `T` component. It also verifies a grade-1 source has no coordinate on an old grade-2/4 ingress, and a grade-2 source has none on an old grade-4 ingress. Both statements persist under the granted cross-bank and cross-time XORs.

- **β outside T.** Every case has a grade-1 ingress with `q_i=1`. Such an ingress cannot be one of the two removed rows because its replacement must have strictly smaller positive grade. Its changed row lies outside `T`. Exactly 537 retained-plus-new scalar ingresses would have to span the 537 independent output rows, hence their span would have to equal `T`; the outside row makes that impossible.
- **β inside T and `q·β=1`.** The nonzero linear functional `q` annihilates every changed old ingress and every changed source row. It does not annihilate all original sink outputs, so the required rank cannot be reached.
- **β inside T and `q·β=0`.** The changed old rows form a basis. The invariant gives every changed source row the same `T` coordinates as its old row when expressed in that moving basis. A source outside `T` cannot be among exactly 537 ingresses spanning `T`. For two deletions, a nonzero 2×2 minor is necessary. If the anchored old grade is 4, both new sources have grade at most 2 and the grade-4 column vanishes. If the anchored grade is 2, its paired source is grade 1 and that source's entire row over the two deleted grade-2/4 coordinates vanishes. The off-diagonal permutation is therefore covered.

This is a proof for arbitrary β from the checked linear invariants, not an inference from the three examples. The code additionally instantiates all three branches for every directed start, including `β = input 411` in the invertible branch. Packet **3553 is exactly the independent owner-411 output row**, not an optional discarded helper. Its pulse parity is zero in all 32 cases. When it is the second removed ingress, the invertible branch leaves its moving-basis direction absent from both cheaper source grades and all retained basis rows, so owner 411 cannot be restored. The singular and outside-`T` arguments retain all 537 outputs and apply to that omission as well.

A mutation adds the protected bridge coordinate to a real grade-1 source. Together with an actual grade-2 source that detects a grade-2 target, the otherwise forbidden off-diagonal matrix becomes `[[0,1],[1,0]]`, with determinant one over GF(2). The historical-stock filter rejects the mutated grade-1 row. This is an explicit failure control for the matrix step; it does not describe a permitted source.

## Counting qualification

There are 32 directed `(first, partner, named old ingress)` records: 24 have grade-4 anchors and 8 have grade-2 anchors. Each has 194 eligible second removals, giving `32 × 194 = 6,208`. A grade-4 anchor has 398 cheaper-grade pairings and a grade-2 anchor 200, giving `24 × 398 + 8 × 200 = 11,152`. These exact numbers reproduce the sealed receipt.

Some reversed pairs describe the same common-β events. Deduplicating pulse order gives 11 unordered pulse pairs and 20 unordered `(pulse pair, named anchor)` starts: **3,880 anchored second-removal cases and 6,376 anchored grade assignments**. If both omitted ingress labels are also treated as an unordered pair, the coverage is **3,850 distinct `(pulse pair, omitted pair)` combinations**, with **6,340** distinct assignments of a cheaper grade to each omitted label, or **6,282** grade multisets per such combination. These deduplicated figures are supplementary coverage descriptions; the theorem itself is unaffected.

## Replay

The package contains the original producer and frozen receipt, the separate independent verifier and receipt, required #7830/#7966 input bytes, and the original source notices and license. CPython 3.12 and the standard library suffice:

```sh
sha256sum -c SHA256SUMS
(cd paired-sink-basis && python3 -IB two_receipt_cut.py --verify)
python3 -IB audit.py | cmp - RESULT.json
```

[RESULT.json](RESULT.json) has the per-case counts, direct grades, branch checks, protected bridge and mutation result. The GitHub observation is a timestamped read, not a guarantee about later PR status. The proof does not cover different pulse forms, new charts, additional non-sink transfers, altered paid routes, a changed caller or removal of the owner-411 obligation.
