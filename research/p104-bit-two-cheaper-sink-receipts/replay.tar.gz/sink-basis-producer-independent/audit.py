#!/usr/bin/env python3
"""Independent raw-tape audit of the sealed R7 two-receipt cut.
No producer or bundled verifier imports; uses original integer field rows,
formal pulse tags, an input-space 680-vector basis, and actual frame ranks.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip,json
H=Path(__file__).resolve().parent;S=H/'paired-sink-basis';I=S/'inputs'
need=lambda v,m: None if v else (_ for _ in ()).throw(AssertionError(m))
raw=(I/'WORD.json.gz').read_bytes();need(sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9','pinned word gzip')
w=json.loads(gzip.decompress(raw));canon=sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest();need(canon=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','canonical word')
D=json.loads((I/'R6-ALL-BETA-CUT.json').read_bytes());cases=[(r['first'],r['partner'],r['old_sink']) for r in D['cases']];need(len(cases)==len(set(cases))==32,'32 directed starts')
R=json.loads((I/'R6-PAIRED-SCREEN.json').read_bytes());other={(r['upstream'],r['partner'],t['old_sink_packet']) for r in R['visible_witnesses'] for t in r['passing_targets']};need(set(cases)==other,'32 starts match both saved R6 receipts')
sealed=json.loads((S/'TWO-RECEIPT-CUT.json').read_bytes())
N=w['public'];need(N==680,'native width');frames={int(c):v for c,v in w['frames'].items()}
def rank(rows):
 a=[[Fraction(x) for x in row] for row in rows];r=0
 for j in range(8):
  p=next((i for i in range(r,len(a)) if a[i][j]),None)
  if p is None:continue
  a[r],a[p]=a[p],a[r];v=a[r][j]
  for i in range(r+1,len(a)):
   if a[i][j]:
    k=a[i][j]/v;a[i]=[x-k*y for x,y in zip(a[i],a[r])]
  r+=1
 return r
need(frames[1]['dim']==8 and not frames[1]['A'] and rank(frames[1]['B'])==8,'sink full eight-space')
for c,z in frames.items():
 b,a=z['B'],z['A'];need(len(b)==z['dim'] and len(b)+len(a)==8 and rank(b+a)==8,'frame '+str(c))
 need(all(sum(Fraction(x)*Fraction(y) for x,y in zip(v,u))==0 for v in b for u in a),'frame orthogonality')
grade={c:8-z['dim'] for c,z in frames.items() if c!=1};need(set(grade.values())=={1,2,4,6,7,8},'all direct grades to 8D sink')
P=w['program'];first_swap=next(i for i,e in enumerate(P) if e[0]=='SWAP');need(all(e[1]>=N for e in P[:first_swap]),'no public writes before terminal swaps');need(all(e[0] in ('SWAP','CLEAR') for e in P[first_swap:]),'no moves/adds after first swap')
swaps=[e for e in P if e[0]=='SWAP'];flat=[x for e in swaps for x in e[1:]];need(len(swaps)==680 and len(flat)==len(set(flat))==1360 and all(e[1]<680<=e[2] for e in swaps),'680 disjoint public/private terminal swaps')
labels=sorted({x for a,b,_ in cases for x in (a,b)});tag={x:1<<i for i,x in enumerate(labels)}
fields=[(c,1<<i,0) for i,c in enumerate(w['start'])]+[None]*w['owned_fields'];need(w['start'].count(1)==0,'no chart-1 initial stock')
hist={1:[],2:[]};seen={1:set(),2:set()};sink=[];moves={};before={};precontacts=Counter();mid=N

def capture(x,clock,addr):
 if x is None or x[0]==1:return
 g=grade[x[0]]
 if g in (1,2):hist[g].append((x[1],x[2],clock,addr,x[0]));seen[g].add((x[1],x[2]))
def had(x):
 if x is None or x[0]==1:return
 g=grade[x[0]]
 if g in (1,2):need((x[1],x[2]) in seen[g],'pre-contact field omitted');precontacts[g]+=1
for j,x in enumerate(fields):capture(x,-1,j)
for clock,e in enumerate(P):
 op,addr,*args=e;x=fields[addr]
 if op=='INIT':need(x is None,'duplicate init');fields[addr]=(args[0],0,0)
 elif op=='CLEAR':need(x is not None and x[0]==args[0],'retirement');had(x);fields[addr]=None
 elif op=='ADD':
  j,c=args;y=fields[j];need(x is not None and y is not None and x[0]==y[0]==c and j!=addr,'cochart add');had(x);had(y);fields[addr]=(c,x[1]^y[1],x[2]^y[2])
 elif op=='SWAP':
  j=args[0];need(x is not None and fields[j] is not None,'live swap');had(x);had(fields[j]);fields[addr],fields[j]=fields[j],fields[addr]
 elif op=='MOVE':
  a,b=args;need(x is not None and x[0]==a and a!=1 and addr==mid,'paid move identity');had(x);moves[mid]=(clock,a,b);before[mid]=x[2]
  if b==1:sink.append((mid,x[1],x[2],grade[a]))
  fields[addr]=(b,x[1],x[2]^tag.get(mid,0));mid+=1
 else:raise ValueError(op)
 capture(fields[addr],clock,addr)
 if op=='SWAP':capture(fields[j],clock,j)
need(len(sink)==537 and Counter(x[3] for x in sink)=={1:342,2:189,4:6},'original ingress census')
output=[x[1] for x in fields[:N]];outputs=[(1<<j)^((1<<(j-111)) if 111<=j<222 else 0) for j in range(N)]
need(output==outputs and [x[0] for x in fields[:N]]==w['final'],'all native output equations and charts')

# Independent labelled elimination, low pivot; complement the sink basis by
# every nonsink terminal output. Coordinates are exact in this complete basis.
def insert(B,row,label):
 while row:
  bit=(row&-row).bit_length()-1
  if bit not in B:B[bit]=(row,label);return True
  r,m=B[bit];row^=r;label^=m
 return False
def coords(B,row):
 out=0
 while row:
  bit=(row&-row).bit_length()-1
  if bit not in B:return None
  v,k=B[bit];row^=v;out^=k
 return out
basis={}
for i,(_,row,_,_) in enumerate(sink):need(insert(basis,row,1<<i),'sink independent')
need(len(basis)==537,'sink rank')
for j in range(N):
 if w['final'][j]==1:need(coords(basis,outputs[j]) is not None,'all sink outputs in T')
need(sum(c==1 for c in w['final'])==537,'537 sink terminal obligations')
pos=537
for j in range(N):
 if w['final'][j]!=1:
  need(insert(basis,outputs[j],1<<pos),'nonsink output complement independent');pos+=1
need(pos==680 and len(basis)==680,'full native output basis')
mask=(1<<537)-1;ng={1:[],2:[]};aug={1:{},2:{}}
for g,obs in hist.items():
 for row,t,clock,addr,c in obs:
  z=coords(basis,row);need(z is not None,'680 input coordinates');ng[g].append((z,t,clock,addr,c,row))
  insert(aug[g],row|(t<<680),0)
need({g:len(aug[g]) for g in aug}=={1:453,2:549},'complete augmented stock ranks')
grades=[s[3] for s in sink];idx={s[0]:i for i,s in enumerate(sink)}
blocked={g:sum(1<<i for i,r in enumerate(grades) if r>g) for g in (1,2)}
for g,rows in ng.items():
 for c,t,_,_,_,_ in rows:need(not(c&blocked[g]),'cheap source detects expensive sink coordinate')
need(len(blocked[1].to_bytes(68,'little'))==68,'sink bit width')
bridge=idx[3553];need(grades[bridge]==4 and sink[bridge][1]==1<<411,'bridge 3553 is owner 411')
need(sum((s[1]>>411)&1 for s in sink)==1 and coords(basis,outputs[411])==1<<bridge,'owner 411 is an independent required terminal direction')
need(sum(1 for j,c in enumerate(w['final']) if c==1 and j!=411)==536,'536 other sink obligations')

rows=[];patterns=0;anchored=0;synthetic=0;branch=Counter();case_grade=Counter()
qrows={}
for case,(a,b,old) in enumerate(cases):
 need(old in idx and grades[idx[old]] in (2,4),'eligible first sink removal')
 early,late=sorted((a,b),key=lambda z:moves[z][0]);need(not(before[late]&tag[early]),'causally independent paired slots')
 for j,x in enumerate(fields[:N]):
  if x[0]!=1 or j<222 or j==411:need(bool(x[2]&tag[a])==bool(x[2]&tag[b]),'protected terminal pulse cancellation')
 q=sum((int(bool(s[2]&tag[a])!=bool(s[2]&tag[b]))<<i) for i,s in enumerate(sink));qrows[(a,b,old)]=q
 need(q and not(q>>bridge&1),'protected bridge has no pulse parity')
 expected=sealed['cases'][case]
 need((expected['first'],expected['partner'],expected['target'])==(a,b,old),'sealed case identity')
 need(expected['q_sink_labels']==[s[0] for i,s in enumerate(sink) if q>>i&1],'sealed q parity')
 q1=[i for i,g in enumerate(grades) if g==1 and (q>>i)&1];need(q1,'retained grade-1 pulse witness')
 for g,source in ng.items():
  for co,t,_,_,_,_ in source:
   lam=bool(t&tag[a])!=bool(t&tag[b]);need(lam==bool((co&q).bit_count()&1),'source invariant over all field occurrences')
 # The branch controls instantiate beta outside T, inside T singular, and beta
 # equal to the removed bridge owner (inside T with q dot beta zero).
 outside=outputs[next(j for j,c in enumerate(w['final']) if c!=1)];outc=coords(basis,outside)
 need(outc>>537,'beta outside T')
 outside_row=sink[q1[0]][1]^outside;need(coords(basis,outside_row)>>537,'outside-T retained witness')
 singular=1<<q1[0];need((q&singular).bit_count()%2==1,'singular beta')
 for i in range(537):
  if i not in (idx[old],bridge):
   changed=(1<<i)^(singular if (q>>i)&1 else 0)
   need(not((changed&q).bit_count()%2),'singular hyperplane retained sink row')
 need(any(((coords(basis,outputs[j])&q).bit_count()%2) for j,c in enumerate(w['final']) if c==1),'singular hyperplane misses a required sink output')
 for g,source in ng.items():
  for co,t,_,_,_,_ in source:
   lam=int(bool(t&tag[a])!=bool(t&tag[b]));need(((co^(singular if lam else 0))&q).bit_count()%2==0,'singular hyperplane')
 invertible=1<<bridge;need(not(q&invertible),'owner-411 beta invertible')
 for g,source in ng.items():
  for co,t,_,_,_,_ in source:
   lam=int(bool(t&tag[a])!=bool(t&tag[b]));new=co^(invertible if lam else 0);moving=new^(invertible if (new&q).bit_count()%2 else 0)
   need(moving==co,'moving basis inverse identity')
   need(not(moving>>bridge&1),'omitted bridge not recoverable in non-singular beta=411 test')
 case_grade[grades[idx[old]]]+=1;pc=0;sc=0
 for j,gold in enumerate(grades):
  if j==idx[old] or gold not in (2,4):continue
  sc+=1
  for x in (1,2):
   for y in (1,2):
    if x>=grades[idx[old]] or y>=gold:continue
    pc+=1
    mat=(int(grades[idx[old]]<=x),int(gold<=x),int(grades[idx[old]]<=y),int(gold<=y))
    need(not(mat[0]*mat[3] or mat[1]*mat[2]),'off-diagonal determinant support')
 anchored+=sc;patterns+=pc;branch['outside_T']+=1;branch['singular']+=1;branch['invertible_owner411']+=1
 need(expected['second_removals']==sc and expected['strictly_cheaper_grade_patterns']==pc,'sealed per-case counts')
 rows.append({'first':a,'partner':b,'old_sink':old,'old_grade':grades[idx[old]],'second_choices':sc,'grade_patterns':pc,'q_grade1_count':len(q1),'q_bridge':0})
need(anchored==6208 and patterns==11152 and case_grade=={4:24,2:8},'directed pattern counts')
unique={}
for row in rows:
 key=(min(row['first'],row['partner']),max(row['first'],row['partner']),row['old_sink']);unique[key]=row
need(len(unique)==20 and len({k[:2] for k in unique})==11,'physical pulse-pair deduplication')
need(sum(x['second_choices'] for x in unique.values())==3880 and sum(x['grade_patterns'] for x in unique.values())==6376,'dedup counts')
physical=set();assigned=set();grade_multisets=set()
for row in rows:
 pair=tuple(sorted((row['first'],row['partner'])));a=row['old_sink'];ga=grades[idx[a]]
 for b,_,_,gb in sink:
  if a==b or gb not in (2,4):continue
  physical.add((pair,tuple(sorted((a,b)))))
  for g1 in (1,2):
   for g2 in (1,2):
    if g1>=ga or g2>=gb:continue
    assigned.add((pair,tuple(sorted(((a,g1),(b,g2))))))
    grade_multisets.add((pair,tuple(sorted((a,b))),tuple(sorted((g1,g2)))))
need((len(physical),len(assigned),len(grade_multisets))==(3850,6340,6282),'fully deduplicated physical counts')
# Genuine off-diagonal mutation: allow a grade-1 source to see the protected
# bridge and pair it with an actual grade-2 source seeing a grade-2 anchor.
case2=next(r for r in rows if r['old_grade']==2);oi=idx[case2['old_sink']]
source2=next(x for x in ng[2] if x[0]>>oi&1);source1=ng[1][0]
a1=(source1[0]>>oi)&1;b1=(source1[0]>>bridge)&1;a2=(source2[0]>>oi)&1;b2=(source2[0]>>bridge)&1
need((a1,b1,a2,b2)==(0,0,1,0),'actual source pre-mutation support')
mutated=source1[0]^(1<<bridge);matrix=[[(mutated>>oi)&1,(mutated>>bridge)&1],[a2,b2]]
need(matrix==[[0,1],[1,0]] and (matrix[0][0]*matrix[1][1])^(matrix[0][1]*matrix[1][0])==1,'offdiagonal mutation')
need(bool(mutated&blocked[1]),'stock filter rejects synthetic bridge leak')
r={'status':'PASS_INDEPENDENT_TWO_RECEIPT_AUDIT','source_tar_sha256':'3657dd74b075c1465352844d03e682ef6b5fe7978477573acac5164bf26312a4','source_word_sha256':canon,
 'scope':'Common arbitrary beta at the 32 directed fixed slots, old named sink plus one other sink receipt removed, only two individually strictly cheaper positive direct chart-1 payments, original other routes and all 537 sink outputs including 411 kept. Historical same-grade sources and local XOR are granted freely; no new charts or rerouting.',
 'frame_count':len(frames),'direct_grades':sorted(set(grade.values())),'full_sink_dim':8,'actual_source_state_occurrences':{str(g):len(x) for g,x in hist.items()},'precontact_accesses_checked':dict(precontacts),'augmented_grade_basis_ranks':{str(g):len(x) for g,x in aug.items()},'forbidden_basis_coordinate_check_counts':{'1':len(aug[1])*195,'2':len(aug[2])*6},
 'original_ingress_grade_counts':dict(Counter(grades)),'required_sink_rank':537,'nonsink_complement_rank':143,'native_outputs_verified':680,'terminal_swaps_disjoint':680,
 'owner411':{'old_bridge_field':3553,'is_independent_required_output':True,'other_sink_output_count':536,'bridge_pulse_parity_zero_cases':32,'bridge_omission_branch_checked':32},
 'directed_records':len(rows),'directed_anchor_grade_counts':dict(case_grade),'directed_anchored_second_removals':anchored,'directed_strictly_cheaper_grade_patterns':patterns,
 'unordered_pulse_pairs':11,'unordered_pulse_pair_and_anchored_old_sink':len(unique),'unordered_anchored_second_removals':3880,'unordered_start_grade_patterns':6376,
 'distinct_unordered_pulse_pair_and_omission_pair':len(physical),'distinct_price_pairings_to_removed_labels':len(assigned),'distinct_price_multisets_per_unordered_physical_pair':len(grade_multisets),
 'branch_checks':dict(branch),'mutated_bridge_leak':{'first_grade2_anchor':case2['old_sink'],'mutated_grade1_row_is_forbidden':True,'post_mutation_offdiagonal_matrix':matrix,'determinant_mod2':1},'cases':rows}
print(json.dumps(r,indent=2,sort_keys=True))
