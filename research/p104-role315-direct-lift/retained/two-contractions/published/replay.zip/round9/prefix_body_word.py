# SPDX-License-Identifier: Apache-2.0
"""Build and exactly replay grouped saturated Type A bodies in the prefix basis."""

import argparse
from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("clock", HERE.parent / "round8/recurrence/verify_even_clock_balance.py")
CLOCK = module_from_spec(SPEC)
SPEC.loader.exec_module(CLOCK)
CORE, NEED = CLOCK.CORE, CLOCK.need
WIDTH = 192


def outer(column,row):
    return [[u*v for v in row] for u in column]


def col(n,i):
    return [int(i==j) for j in range(n)]


def support(values):
    return {i for i,x in enumerate(values) if x}


def stage(i,L):
    # Coordinate k=0..n-1 represents a_{k+1} = sum_{j<k+1} (-1)^j U_j.
    n=L-1
    u = [(-1)**i*(int(k+1==i+1)-int(k+1==i)) for k in range(n)]
    v = [-2*int(((k+1)%2==1 and k+1<=i) or ((k+1)%2==0 and k+1>i))
         for k in range(n)]
    F=support(u)|support(v)
    hub=0 if i else 1
    pivot=max(support(u)-{hub})
    NEED(v[hub]==-2 and u[pivot] in (1,-1) and sum(x*y for x,y in zip(u,v,strict=True))==0,
         "dyadic active rank-two clock")
    dual_u=[int(k==pivot)*u[pivot] for k in range(n)]
    eta=[int(k==hub)*-1 for k in range(n)]
    pairs=[(u,dual_u),(eta,[x//2 for x in v])]
    idles={}
    for k in range(n):
        if k==hub or k==pivot:
            continue
        w=[int(j==k)-int(j==hub and v[k]!=0) for j in range(n)]
        f=[int(j==k)-u[k]*dual_u[j] for j in range(n)]
        pairs.append((w,f))
        if k in F:
            idles[k]=(w,f)
    U,V=list(zip(*(w for w,_ in pairs))),[f for _,f in pairs]
    return u,v,F,idles,U,V


def idle_word(stages):
    L,n=len(stages),len(stages)-1
    at=defaultdict(list)
    for k in range(n):
        available={i:stage[3][k] for i,stage in enumerate(stages) if k in stage[3]}
        interval=range(1,k) if (k+1)%2==0 else range(k+2,L)
        eligible=[i for i in interval if i in available]
        NEED(not eligible or eligible==list(range(eligible[0],eligible[-1]+1)),
             "retimed same-projector jobs must occupy a solid interval")
        if eligible:
            group=tuple(eligible)
            projector=available[eligible[0]]
            NEED(all(available[i]==projector for i in eligible),"constant idle projector")
            at[group[0]].append((group,projector))
        for i,p in available.items():
            if i not in eligible:
                at[i].append(((i,),p))
    return at


def moment(L, stages, schedule, paid,helpers):
    a_targets=Counter(8*sum(k in stage[2] for stage in stages)+1 for k in range(L-1))
    a_paid=Counter(8*len(group) for jobs in schedule.values() for group,_ in jobs)
    whole_paid=Counter({k:L*v for k,v in paid.items()})
    whole_paid.update({k:WIDTH*v for k,v in a_paid.items()})
    whole_targets=Counter({k:L*v for k,v in helpers.items()})
    whole_targets.update({k:WIDTH*v for k,v in a_targets.items()})
    # One disjoint pair of full hosts returns two odd rank-17 targets per B edge.
    # The L-cycle with four edges per adjacent pair assigns eight B ports per clock.
    synthetic_B=Counter({17:8*L})
    optimistic_B=Counter({1:8*L,8:8*L,9:8*L})
    margins={}
    for p in ((363005817,100000000000),(364841129479,100000000000000),(5,1000),(227,10000)):
        hist=whole_targets.copy()
        hist.subtract(whole_paid)
        exact=hist.copy()
        exact.update(synthetic_B)
        hist.update(optimistic_B)
        margins[str(p)]={"with_B_cycle":CORE.format_bounds(CORE.moment(exact,*p)),
                         "with_B_optimistic_credit":CORE.format_bounds(CORE.moment(hist,*p))}
    return {"A_idle_rank_counts_per_chain":dict(a_paid),"A_target_rank_counts_per_chain":dict(a_targets),
            "B_cycle_no_external_calls_targets":dict(synthetic_B),
            "whole_paid_count":sum(whole_paid.values()),
            "whole_productive_count":sum(whole_targets.values())+sum(synthetic_B.values()),
            "moments":margins}


def mul_sparse(left,right,field=None):
    n=len(left)
    prod=[[0]*n for _ in range(n)]
    for i,row in enumerate(left):
        for j,x in enumerate(row):
            if x:
                for k,y in enumerate(right[j]):
                    if y:
                        prod[i][k]+=x*y
    return [[x%field for x in row] for row in prod] if field else prod


def replay(L,stages,schedule):
    n=L-1
    I=CLOCK.identity(n)
    W=[]
    prefix=I
    route_nonzeros=0
    for i,(u,v,F,idles,T,S) in enumerate(stages):
        gate=CLOCK.plus(I,outer(u,v))
        W.append(gate)
        NEED(mul_sparse(T,S)==I and mul_sparse(S,T)==I,"complete ordinary changed basis")
        NEED(all(prefix[a][b]==0 for a in range(n) for b in range(n) if (a in F)!=(b in F)),
             "body projector commutes with relative prefix")
        NEED(all(a==b or a==i-1 or prefix[a][b]==0 for a in range(n) for b in range(n)),
             "relative prefix has one nondiagonal row")
        prefix=mul_sparse(gate,prefix)
        route_nonzeros+=sum(x!=0 for mat in (T,S) for row in mat for x in row)
    NEED(prefix==[[-x for x in row] for row in I],"complete relative sign")
    multi=[(first,group,p) for first,jobs in schedule.items() for group,p in jobs if len(group)>1]
    for first,group,(w,f) in multi:
        P=outer(w,f)
        for i in group:
            NEED(mul_sparse(P,W[i])==mul_sparse(W[i],P),"grouped idle commutes with signed clock")
            NEED(all(P[a][b]==0 for a in range(n) for b in range(n) if (a in stages[i][2])!=(b in stages[i][2])),
                 "grouped idle commutes with full stage body")
        for _,_,(z,g) in multi:
            NEED(mul_sparse(P,outer(z,g))==mul_sparse(outer(z,g),P),"all retimed idle projectors commute")
        for i in range(first+1,group[-1]+1):
            for z,g in stages[i][3].values():
                NEED(mul_sparse(P,outer(z,g))==mul_sparse(outer(z,g),P),
                     "retimed factors commute with every crossed idle")
        NEED(first==group[0],"first use is paid cut")

    field=257
    imag=16
    NEED(imag*imag%field==field-1,"Gaussian phase test")
    verified=wrong=0
    for fixture in range(5):
        body=[imag**((i*(fixture+1)+fixture)%4)%field for i in range(L)]
        if fixture==4:
            body=[(7*i+2)%field for i in range(L)]
        for q in (1,imag,field-1,field-imag):
            h=1 if q*q%field==1 else imag
            t=(1-q*pow(h,-1,field))*pow(2,-1,field)%field
            full=I
            mutated=I
            for i,(u,v,F,idles,T,S) in enumerate(stages):
                modified=I
                for group,(w,f) in schedule[i]:
                    D=1
                    for k in group:
                        D=D*body[k]%field
                    modified=mul_sparse(CLOCK.plus(I,outer(w,f),D-1),modified,field)
                local=CLOCK.identity(n)
                local[0][0]=local[1][1]=body[i]
                local[0][1]=2*t*body[i]
                supplied = Counter((tuple(w),tuple(f)) for jobs in schedule.values() for group,(w,f) in jobs
                                   if i in group)
                NEED(supplied==Counter((tuple(w),tuple(f)) for w,f in idles.values()),
                     "all phase projections are charged once at the correct label")
                # Grouped and singleton idles were materialized before the real local native.
                host=mul_sparse(mul_sparse(T,local,field),S,field)
                full=mul_sparse(mul_sparse(host,modified,field),full,field)
                bad=I if fixture==4 and i==2 else modified
                mutated=mul_sparse(mul_sparse(host,bad,field),mutated,field)
            expected=[]
            for k in range(n):
                endpoint=q
                for i,z in enumerate(body):
                    if k in stages[i][2]:
                        endpoint=endpoint*z%field
                expected.append(endpoint)
            actual=[[h*x%field for x in row] for row in full]
            NEED(actual==[[a if i==j else 0 for j in range(n)] for i,a in enumerate(expected)],
                 f"full multivariate four-phase endpoint L={L} fixture={fixture} q={q}")
            verified+=n*n
            if fixture==4:
                wrong+=mutated!=full
    return {"exact_finite_field_coefficients":verified,"dropped_group_negatives":wrong,
            "absolute_nonzeros_of_scalar_wiring_both_directions":route_nonzeros,"multi_stage_jobs":len(multi)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    args=parser.parse_args()
    paid,helpers=CLOCK.JOINT.read_complex(args.complex_pack)
    rows={}
    for L in (5,9,17,19,21,23):
        word=[stage(i,L) for i in range(L)]
        groups=idle_word(word)
        rows[L]={"coefficient_replay":replay(L,word,groups),
                 "complete_source_invoice":moment(L,word,groups,paid,helpers)}
    print(json.dumps({"status":"PASS_PREFIX_BODY_WORD","depths":rows},indent=2,sort_keys=True))


if __name__=="__main__":
    main()
