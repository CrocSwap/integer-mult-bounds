# Exact cyclic Type B caller and its two-incidence bound

The eight Type B ports of each #7546 native can supply 136 independent rank-17 targets over the 17-stage #7113 clock, with zero external recursive calls within Type B. A loopless degree-eight multigraph on the stage labels assigns dirty owner pairs to those ports. The same simple incidence accounting proves optimality in the separated, positive-label, no-external-recursion class. The exact new margin is −76.9973337802 at the repository-selected κ=.00363005817. The literal #7546 recurrence has +7.1100183905 at that test price. [#7546 at the source head](https://github.com/CrocSwap/integer-mult-bounds/tree/99438c43df7aac1e5dbcc43c1578fcd886c119ec) · [#7113 caller application](https://github.com/CrocSwap/integer-mult-bounds/blob/07a76c5e2738882c0cb322278e56f6cae3c9885d/research/signed-caller-8x9/APPLICATION.md)

## Exact two- and three-stage words

Use the common physical Type B head-axis normalization from Round 8. On one arbitrary dirty pair the normalized local HOST at stage \(j\) is \(B_j M(q)\), with central operator \(q^4=1\), the commuting body \(B_j\) on its own eight axes, and

\[
M(q)=\begin{pmatrix}1&-q\\q^{-1}/2&1/2\end{pmatrix},
\qquad D(u)=\operatorname{diag}(1,u).
\]

The body scalar commutes with every local gate. The forward identities are

\[
\begin{aligned}
M(q)D(2)M(q)&=\begin{pmatrix}0&-2q\\q^{-1}&0\end{pmatrix},\\
M(q)D(-2)M(q)&=\operatorname{diag}(2,-1),\\
M(q)D(-2i)M(q)D(2i)M(q)&=
  \begin{pmatrix}0&(-2-2i)q\\(1-i)q^{-1}&0\end{pmatrix}.
\end{aligned}
\]

The first and third require an ordinary SWAP, exact Gaussian-dyadic scales, and a translation by \(q^2\) on the second output. The two-stage postscale coefficients are \(1,-1/2\). The three-stage coefficients are \((1+i)/2,(-1+i)/4\). Both give the chosen \(q^{-1}\) on each input, and the middle identity imposes no odd head. Every target contains every body whose stage touches that pair, once. Gaussian unit multiplication is signed real/imaginary exchange. A coefficient such as \((1+i)/2\) takes a signed component exchange, two component sums or differences and exact binary shifts, with an ordinary temporary for the old components. The multiplier is a scalar on the complete Gaussian field, while \(q\) and the bodies are the tensor powers of signed address operators. All scalar divisions are powers of two.

For just one stage, the two paid lower thin queries \(L(q^{-1})\) followed later by \(L(q^{-1}/2)\) enclose the HOST. This gives the antidiagonal with entries \(-q,q^{-1}\), then an ordinary swap, sign and \(q^2\) map finish it. A grouped variant uses \(E=M(q^2)\), for which \(M(q)\operatorname{diag}(q^{-1},1)E^{-1}=\operatorname{diag}(q^{-1},1)\). Apply \(E^{-1}\), an odd grouped idle on the first rail, an even grouped idle on the second, the HOST, and a rank-one odd idle on the second. For residual body rank \(r>0\), charge \(H_{r+1}+H_r+H_1\). For \(r=0\), charge \(2H_1\).

With real diagonal bridges, a three-stage antidiagonal would require \(w+t=0\) and \(wt=4\) from the two vanishing diagonal entries of \(M(q)D(t)M(q)D(w)M(q)\). This is impossible over the real scalars at \(q=1,-1\). The opposed orientation obeys \(M(q^{-1})=J M(q)J\) for \(J=\operatorname{diag}(q^2,1)\) and coincides there. The Gaussian-dyadic example gives an exact exception.

The real obstruction extends to arbitrary square real sector-even bridges on this isolated two-role pair. Each of the three relative factors \(J_1,J_2,J_3\) for \(q=1,-1\) squares to \(-I\). Endpoint relative \(-I\) requires \(J_2 J_1=J_3\). Conjugate \(J_1\) over the reals to \(\left(\begin{smallmatrix}0&-1\\1&0\end{smallmatrix}\right)\) and write \(J_2=\left(\begin{smallmatrix}a&b\\c&-a\end{smallmatrix}\right)\). Now \(bc=-1-a^2\), so \(\lvert\operatorname{tr}(J_2J_1)\rvert=\lvert b-c\rvert\ge2\). Yet \(\operatorname{tr}(J_3)=0\). The argument also excludes real sector-even bridges specialized at \(q^2=1\) and any choice of opposed HOST orientations on the pair.

## Two incidences per output

Allow arbitrary invertible, sector-even ordinary scalar maps across the B roots. On the two compared opposite \(q\) sectors let \(U^+_j,U^-_j\) be the prefixes just before stage \(j\), with all bodies specialized to one. Their ordinary generators are the same in both sectors. Let \(P_j\) be the active coordinate projector of the full B part of stage \(j\). The \(j\)-th body enters only through \(I-P_j+B_jP_j\). Comparing its coefficient in the formal diagonal target after specializing the other bodies to one yields

\[
(U_j^+)^{-1}P_j U_j^+=(U_j^-)^{-1}P_j U_j^-=E_j,
\]

where \(E_j\) selects exactly the target coordinates containing body \(B_j\). This follows by factoring the endpoint at the \(j\)-th HOST and left-multiplying by the inverse all-bodies-one endpoint. The same argument applies if sector-even ordinary maps depend on the common head through \(q^2\). The assumption is that they are independent of the formal body labels.

The relative prefix \(C_j=(U_j^+)^{-1} U_j^-\) changes at each HOST by left multiplication with a conjugate of \(M(q)^{-1}M(-q)\) on the active port pairs. Its support is \(E_j\), it is the identity outside \(E_j\), and its square on \(E_j\) is \(-I\). Common ordinary maps cancel in the relative prefix. A target coordinate with exactly one active incidence passes through its unique relative factor inside \(E_j\). All later factors fix that coordinate and keep its coordinate complement invariant, so that factor would need the common basis vector as an eigenvector with eigenvalue \(+1\) or \(-1\). The only eigenvalues on \(E_j\) are \(i,-i\). A zero-incidence coordinate has relative eigenvalue +1 and carries no body, hence contributes no nonzero-rank target. This gives the incidence requirement even if both even and odd heads are admitted among the targets.

Each full B stage has 16 active coordinates, hence 272 incidences across 17 stages. For target degree \(k\ge2\) grant rank \(8k+1\) to every target, with \(H_r=r^{1-\kappa}\). Since \(8k+1\le 17k/2\) and \(H_{\alpha r}\le\alpha H_r\) for \(\alpha\ge1\), \(H_{8k+1}/k\le H_{17}/2\). The absolute total cap within this class is \(136H_{17}\). Auxiliary idles invalidate the single-occurrence projection identity, so the result leaves paid-idle Type B constructions such as #7113 open. It also assumes separated A/B/helper scalar spaces, matched opposite sectors, and a square independent diagonal endpoint.

## Attainment and full tariff

Give each edge of the 17-cycle four dirty pairs. Every stage sees four pairs attached to each incident edge, so the cross-port schedule uses all eight physical B ports. Each of the 68 pairs occupies two full HOSTs on distinct stages and different ports. Normalize the ports to the same head coordinate and place the two-stage odd word on each pair. More generally any loopless regular clock multigraph with degree equal to the number of B ports gives the same exact transport. An odd number of clocks needs even degree for full saturation.

The exact chronological Laurent replay verifies the 136 arbitrary root owners, unique ownership at each contact and all formal body labels. The finite additional controls exercise all four header and body phases, checking 1,600 matrix coefficients. At least one phase fixture rejects each omitted operation. An omission of one central translation corrupts exactly one root in the complete word. On all eight pinned port geometries the replay checks 32 signed canonical interfaces and 136 signed stage wrappers. Priced counts retain all 17 actual native invoices with their independent helpers and the full old A branch, and replace the old B paid and productive entries. [Full #7546 verification job](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050)

| Test κ | Full B, literal #7113 | Full B, 17-cycle | Prior optimistic B allowance | Full recurrence, 17-cycle |
|---|---:|---:|---:|---:|
| .00363005817 | 2372.4509166912 | 2288.3435645205 | 2430.0942995825 | −76.9973337802 |
| .003648411294790 | 2372.1527370079 | 2288.2245775976 | 2430.0041240830 | −83.9281594103 |
| .005 | 2350.2730873562 | 2279.4789453097 | 2423.3730232865 | −592.9288979206 |
| .0227 | 2077.7559194443 | 2167.9868279715 | 2338.2840875171 | −7008.4534199420 |

The cyclic word changes B stock from 288 to 136 dirty independent roots. It has 109,956 paid positions and 22,309 productive positions overall. The conditional raw crossing is in [0.003426257384,0.003426257385]. Keeping B ports isolated and using either seven two-stage words and a three-stage word or eight two-stage words and one paid singleton per port costs more. The exact checker also exhausts every compatible stage subset on each of the old 18 symmetric B masks per port, restricting each dirty pair to its private clock words and grouping the residual exact bodies on that same pair. An assignment of size at least two uses one odd block of length two or three plus even pairs. Unused pairs receive direct odd grouped work for each old input. The best same-mask branch at both the open #7546 crossing and .005 preserves all 22,461 productive positions and pays 110,212 positions, with a complete .005 margin of −616.7636841334. It loses despite reducing the number of bills because the charged child ranks rise. The source B-only .005 credit per port is 293.7841359195. The best in this restricted same-mask family is 281.9555198871.

The cycle adds 68 complete-array role swaps, 136 scales/signs and 68 header translations. A conservative unfused accounting adds 6,528 elementary nine-axis XOR/swap passes for the normalized port wrappers, before the retained original stage routes. These are ordinary movement and arithmetic on complete arrays, with the source movement primitive costs. The two-stage normalized rows have dyadic height at most 1 and Laurent coefficient mass at most 2. Ordinary shifts therefore need a carrier guard for one extra dyadic bit above the exterior Clifford grid. The body and head Cliffords have their physical Gaussian-dyadic grid debt, already separate from the Laurent coefficient bound. The cycle uses the same endogenous native helpers from their own arbitrary stocks and preserves all pinned native input and output contracts. Its numeric guards and ordinary macro counts here are local to the altered B caller. Short changed-word arithmetic, complete directed recursive tariffs, and bounded address rebindings are covered. A fixed tape execution, complete allocation/padding compiler, composite common-grid proof, and outer admission for the changed word remain unverified. No new κ follows from these negative prices.

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$pack = '..\integer-mult-local-recovery\work'
& $py -I -B -S -W error .\work\round9\independent\type_b_clock.py "$pack\7546-word.json.gz" "$pack\phase-7481-inputs\caller.json" "$pack\7546-whole.json" .\work\round9\independent\type-b-clock.json --expect
~~~

The standard-library checker has a 24-second deadline for the source proof, same-mask enumeration and directed prices. The repeated normal test took under two seconds, and the JSON SHA-256 is `704cbc0e1fa036f5428f4df3e9749be1dee420c5187dc453a419000089e50825`. The test processes terminate normally and retain no worker, GPU or persistent service.

## Literal singleton idle merge check

The old B branch charges two rank-eight singleton directions per label, plus 26 multi-label even idles and four rank-nine isolated odd jobs. For the identical round-tripped #7113 caller, the probe replays the entire signed B prefix and inverse over the rationals at \(q=1,-1\) with bodies specialized to one. It checks the inverse at each actual host and external idle. An idle at coordinate \(x\) and prefix \(F\) has pulled projector \((F^{-1}e_x)(e_x^\mathsf T F)\). No two of the 60 existing even idle projectors coincide in either sector.

Also allow replacing the singleton basis for each of two labels by any columns and dual rows within their existing rank-two spans. A common rank-one replacement requires a vector and covector in the respective intersections with nonzero pairing in each sector. All 136 distinct stage pairs fail this necessary condition before the common-cut test. The checker retains 3,878 B/joint cuts and omits 906 cuts at independent Type A-only operations. The positive control plants a shared rank-one projector and the negative control gives intersecting individual subspaces with zero pairing. This local screen allows re-basing within singleton spans. It leaves regrouping through the existing multi-label idle projector spaces or changed native masks open.

~~~powershell
& $py -I -B -S -W error .\work\round9\independent\audit_literal_idle.py "$pack\phase-7481-inputs\caller.json" .\work\round9\independent\literal-idle-screen.json --expect
~~~

The probe has a 14-second budget and completed in under 1.5 seconds on CPU. Its reproducible JSON SHA-256 is `d1376af09070fb0b72eb41ae943d8aee52e58021f96f7095e5237a087088b576`.
