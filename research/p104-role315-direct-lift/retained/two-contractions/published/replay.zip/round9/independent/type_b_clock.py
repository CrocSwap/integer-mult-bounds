"""Exact B-clock identities, owner assignment, and conditional complete tariff."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
GAUGE = run_path(str(HERE.parents[1] / "round8" / "independent" / "port_gauge.py"))
BASE, DIRECT, NEED = (GAUGE[k] for k in ("BASE", "DIRECT", "NEED"))
PRICE = BASE["price_engine"]()
SELECTED = ".00363005817"
OPEN = ".003648411294790"
SAVINGS = ("0", SELECTED, OPEN, ".005", ".0227")
ONE, I, MINUS, MI = UNITS = tuple((Q(x), Q(y)) for x, y in ((1, 0), (0, 1), (-1, 0), (0, -1)))
ZERO = (Q(0), Q(0))


def gaussian(x, y=0):
    return Q(x), Q(y)


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def mul(a, b):
    return a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0]


def scale(a, x):
    return a[0]*x, a[1]*x


def compose(a, b):
    return tuple(tuple(add(mul(a[i][0], b[0][j]), mul(a[i][1], b[1][j]))
                       for j in range(2)) for i in range(2))


def diag(a, b):
    return ((a, ZERO), (ZERO, b))


IDENTITY = diag(ONE, ONE)
SWAP = ((ZERO, ONE), (ONE, ZERO))


def host(p):
    return ((ONE, scale(UNITS[p], -1)), (scale(UNITS[-p % 4], Q(1, 2)), gaussian(Q(1, 2))))


def inv_host(p):
    return ((gaussian(Q(1, 2)), UNITS[p]), (scale(UNITS[-p % 4], Q(-1, 2)), ONE))


def basic_word(kind, phases):
    """Chronological gates around positive independent body atoms."""
    if kind == "odd2":
        return [("HOST", phases[0]), ("SCALE", 1, gaussian(2)), ("HOST", phases[1]),
                ("SWAP",), ("SCALE", 1, gaussian(Q(-1, 2))), ("X_HEAD", 1)]
    if kind == "even2":
        return [("HOST", phases[0]), ("SCALE", 1, gaussian(-2)), ("HOST", phases[1]),
                ("SCALE", 0, gaussian(Q(1, 2))), ("SCALE", 1, MINUS)]
    if kind == "odd3":
        return [("HOST", phases[0]), ("SCALE", 1, gaussian(0, 2)), ("HOST", phases[1]),
                ("SCALE", 1, gaussian(0, -2)), ("HOST", phases[2]), ("SWAP",),
                ("SCALE", 0, gaussian(Q(1, 2), Q(1, 2))),
                ("SCALE", 1, gaussian(Q(-1, 4), Q(1, 4))), ("X_HEAD", 1)]
    NEED(kind == "odd1", "Undefined B word")
    return [("QUERY", Q(1)), ("HOST", phases[0]), ("QUERY", Q(1, 2)), ("SWAP",),
            ("SCALE", 1, MINUS), ("X_HEAD", 1)]


def evaluate_gate(gate, p):
    name, *a = gate
    if name == "HOST":
        body = UNITS[a[0]]
        return tuple(tuple(mul(body, z) for z in row) for row in host(p))
    if name == "SCALE":
        j, c = a
        return diag(c, ONE) if j == 0 else diag(ONE, c)
    if name == "SWAP":
        return SWAP
    if name == "X_HEAD":
        return diag(UNITS[2*p % 4], ONE) if a[0] == 0 else diag(ONE, UNITS[2*p % 4])
    NEED(name == "QUERY", "Undefined outer gate")
    return ((ONE, ZERO), (scale(UNITS[-p % 4], a[0]), ONE))


def grid_height(value):
    NEED(value.denominator.bit_count() == 1, "Non-dyadic coefficient")
    return value.denominator.bit_length()-1


def typed_endpoint(word, p, controls=None):
    out = IDENTITY
    max_height = 0
    max_mass = Q(1)
    for j, op in enumerate(word):
        if controls is not None and controls == j:
            continue
        out = compose(evaluate_gate(op, p), out)
        for row in out:
            max_height = max(max_height, max(grid_height(x) for z in row for x in z))
            max_mass = max(max_mass, sum(abs(x) for z in row for x in z))
    return out, max_height, max_mass


def replay_identities():
    results = {}
    for kind, count in (("odd1", 1), ("odd2", 2), ("even2", 2), ("odd3", 3)):
        height = 0
        mass = Q(1)
        rejected = set()
        checked = 0
        for p, *bodies in product(range(4), repeat=count+1):
            word = basic_word(kind, bodies)
            target = UNITS[(sum(bodies) - (p if kind.startswith("odd") else 0)) % 4]
            actual, h, m = typed_endpoint(word, p)
            NEED(actual == diag(target, target), "Two independent arbitrary dirty inputs")
            height, mass = max(height, h), max(mass, m)
            checked += 4
            for j in range(len(word)):
                if j in rejected:
                    continue
                if typed_endpoint(word, p, controls=j)[0] != actual:
                    rejected.add(j)
        NEED(len(rejected) == len(word), "Every omission fails for a tested character")
        results[kind] = {"exact_coefficients": checked, "failed_omissions": len(rejected),
                         "peak_character_dyadic_height": height, "peak_character_l1_mass": str(mass)}
    # Both opposite center signs can be used, via charged ordinary translations.
    for p in range(4):
        j = diag(UNITS[2*p % 4], ONE)
        NEED(compose(j, compose(host(p), j)) == host(-p % 4), "Opposed signed B orientation")
        NEED(compose(inv_host(p), host(p)) == IDENTITY, "Whole local inverse identity")
        rel = compose(inv_host(p), host((p+2) % 4))
        NEED(compose(rel, rel) == diag(MINUS, MINUS), "Quarter rotation on active two fields")
    # A one-native singleton uses the even E^-1, one grouped odd first-role
    # request, one even second-role request, HOST, then a second-role odd request.
    for p, residual, body in product(range(4), repeat=3):
        d = UNITS[residual]
        qi = UNITS[-p % 4]
        even_inv = inv_host(2*p % 4)
        grouped = diag(mul(qi, d), d)
        post = diag(ONE, qi)
        m = evaluate_gate(("HOST", body), p)
        goal = UNITS[(body+residual-p) % 4]
        NEED(compose(post, compose(m, compose(grouped, even_inv))) == diag(goal, goal),
             "Exact compound singleton restoration")
    return results


def old_b(caller):
    b = caller["types"]["B"]
    offset = b["offset"]
    pairs = []
    for j, (x, y) in enumerate(zip(b["diagonal"][::2], b["diagonal"][1::2], strict=True)):
        NEED(x == y and x[:2] == [-1, 0], "Old actual symmetric target pairs")
        mask = tuple(i for i, on in enumerate(x[2:], 1) if on)
        pairs.append((offset+2*j, offset+2*j+1, mask))
    p = Counter()
    t = Counter({8*len(mask)+1: 0 for _, _, mask in pairs})
    for _, _, mask in pairs:
        t[8*len(mask)+1] += 2
    for event in caller["events"]:
        if event[0] == "J":
            NEED(event[3] == [offset, offset+1, "-1", "1/2"], "Pinned chronological B host")
        elif event[0] == "B" and event[1] in ("IDLE_ONE", "IDLE_ODD"):
            p[8*len(event[3])+int(event[1] == "IDLE_ODD")] += 1
        elif event[0] == "B":
            NEED(event[1] in ("ADD", "SWAP", "SCALE", "LAMBDA"), "No remaining hidden B query")
    NEED(p == {8:34, 9:4, 16:4, 24:4, 32:4, 40:4, 48:4, 56:4, 64:2},
         "Baseline rank histogram changed")
    return pairs, p, t


def residual_bill(target_mask, assigned):
    rest = 8*(len(target_mask)-len(assigned))
    if not assigned:
        return Counter({rest+1:2})
    if len(assigned) == 1:
        return Counter([rest+1, rest, 1] if rest else [1, 1])
    return Counter({rest:2}) if rest else Counter()


def interval(a):
    return {"value": PRICE.value(a), "bounds": PRICE.show(a)}


def net(p, t):
    result = t.copy()
    result.subtract(p)
    return {r:q for r, q in sorted(result.items()) if q}


def formal_clock_order(schedule):
    groups = {}
    for stage, port, pair in schedule:
        NEED(stage not in groups.setdefault(port, {}), "One role pair per physical B port per stage")
        groups[port][stage] = pair
    return groups


def cyclic(caller):
    l, ports = caller["stages"], caller["types"]["B"]["ports"]
    NEED(l >= 3 and len(ports) % 2 == 0, "An even-degree clock cycle with distinct edges")
    half = len(ports)//2
    plan = []
    schedule = []
    for a in range(1, l+1):
        b = a+1 if a < l else 1
        stages = tuple(sorted((a, b)))
        for port in range(half):
            n = len(plan)
            pair = (2*n, 2*n+1)
            first, second = ((ports[port+half], ports[port]) if a < l else
                             (ports[port], ports[port+half]))
            plan.append({"roles":pair, "hosts":stages, "ports":(first, second), "macro":"odd2"})
            schedule.extend(((stages[0], first, pair), (stages[1], second, pair)))
    table = formal_clock_order(schedule)
    NEED(set(table) == set(ports) and all(len(c) == l for c in table.values()), "All physical B contacts")
    public = [r for edge in plan for r in edge["roles"]]
    NEED(sorted(public) == list(range(l*len(ports))), "Distinct arbitrary dirty roots")
    return plan, [{"stage":j, "ports":{p:table[p][j] for p in ports}} for j in range(1,l+1)]


def shift_row(row, coefficient=ONE, phase=0, body=0):
    output = {}
    for (source,power,mask), x in row.items():
        NEED(not (mask & body), "A positive stage body appears twice on one path")
        loc = source,(power+phase)%4,mask|body
        y = mul(coefficient,x)
        if y != ZERO:
            output[loc] = y
    return output


def merge(a,b):
    out = a.copy()
    for key, x in b.items():
        z = add(out.get(key,ZERO),x)
        if z == ZERO:
            out.pop(key,None)
        else:
            out[key] = z
    return out


def formal_gate(rows, pair, op):
    a, b = pair
    x, y = rows[a], rows[b]
    name, *args = op
    if name == "HOST":
        mask = 1 << (args[0]-1)
        rows[a] = merge(shift_row(x,body=mask),shift_row(y,MINUS,1,mask))
        half = gaussian(Q(1, 2))
        rows[b] = merge(shift_row(x,half,3,mask),shift_row(y,half,0,mask))
    elif name == "SCALE":
        r, coeff = args
        rows[pair[r]] = shift_row(rows[pair[r]],coeff)
    elif name == "SWAP":
        rows[a], rows[b] = y,x
    elif name == "X_HEAD":
        r, = args
        rows[pair[r]] = shift_row(rows[pair[r]],phase=2)
    elif name == "QUERY":
        coeff, = args
        rows[b] = merge(y,shift_row(x,gaussian(coeff),3))
    elif name == "BODY":
        r, body, phase = args
        rows[pair[r]] = shift_row(rows[pair[r]],phase=phase,body=body)
    else:
        NEED(name == "EVEN_INV", "Unrecognized repair gate")
        rows[a] = merge(shift_row(x,gaussian(Q(1,2))),shift_row(y,phase=2))
        rows[b] = merge(shift_row(x,gaussian(Q(-1,2)),2),y)


def sweep_cyclic_word(edges, layout, omit_translation=False):
    bank = {r:{(r,0,0):ONE} for edge in edges for r in edge["roles"]}
    macros = {edge["roles"]:basic_word("odd2",edge["hosts"]) for edge in edges}
    terminal_stages = {edge["roles"]:edge["hosts"][-1] for edge in edges}
    offsets = Counter()
    ops = Counter()
    height = 0
    mass = Q(1)

    def apply(pair, op):
        nonlocal height, mass
        formal_gate(bank,pair,op)
        ops[op[0]] += 1
        for r in pair:
            field = bank[r]
            height = max(height, max((grid_height(x) for z in field.values() for x in z), default=0))
            mass = max(mass, sum(abs(x) for z in field.values() for x in z))

    for stage in layout:
        pairs = stage["ports"].values()
        NEED(len({r for pair in pairs for r in pair}) == 2*len(pairs), "All dirty B port owners disjoint within J")
        for pair in pairs:
            macro = macros[pair]
            i = offsets[pair]
            while macro[i][0] != "HOST":
                apply(pair,macro[i])
                i += 1
            NEED(macro[i][1] == stage["stage"], "Scheduled B host on the right body")
            apply(pair,macro[i])
            offsets[pair] = i+1
        for pair in pairs:
            if stage["stage"] == terminal_stages[pair]:
                for op in macros[pair][offsets[pair]:]:
                    if op[0] == "X_HEAD" and omit_translation:
                        omit_translation = False
                        continue
                    apply(pair,op)
    negative = 0
    for edge in edges:
        mask = sum(1 << (k-1) for k in edge["hosts"])
        for r in edge["roles"]:
            negative += bank[r] != {(r,3,mask):ONE}
    return negative,ops,{"dyadic_height":height,"laurent_l1_mass":str(mass)}


def pair_word(record):
    hosts = record["hosts"]
    target = sum(1 << (s-1) for s in record["target_mask"])
    rest = sum(1 << (s-1) for s in record["residual"])
    out = []
    if len(hosts) <= 1:
        if not hosts:
            return [("BODY",0,target,3),("BODY",1,target,3)]
        return [("EVEN_INV",),("BODY",0,rest,3),("BODY",1,rest,0),("HOST",hosts[0]),("BODY",1,0,3)]
    odd_length = 3 if len(hosts) % 2 else 2
    out.extend(basic_word(f"odd{odd_length}",hosts[:odd_length]))
    for x,y in zip(hosts[odd_length::2],hosts[odd_length+1::2],strict=True):
        out.extend(basic_word("even2",(x,y)))
    if rest:
        out.extend((("BODY",0,rest,0),("BODY",1,rest,0)))
    return out


def verify_same_mask(plan, demands):
    rows = {}
    gates = Counter()
    bills = Counter()
    stages = []
    emitted = []
    for r in plan:
        a,b = r["roles"]
        pair = a,b
        NEED(a not in rows and b not in rows, "Arbitrary original role input never aliases a replacement")
        rows[a], rows[b] = {(a,0,0):ONE}, {(b,0,0):ONE}
        controls = pair_word(r)
        for op in controls:
            formal_gate(rows,pair,op)
            gates[op[0]] += 1
            if op[0] == "HOST":
                stages.append(op[1])
            elif op[0] == "BODY" and (rank := 8*op[2].bit_count()+op[3]%2):
                bills[rank] += 1
        m = sum(1 << (s-1) for s in r["target_mask"])
        for j in pair:
            NEED(rows[j] == {(j,3,m):ONE}, "Every original exact signed endpoint")
        emitted.append({"roles":pair,"word":controls})
    NEED(sorted(stages) == list(range(1,18)) and bills == demands, "Each full J unchanged with all auxiliary ranks charged")
    return {"operations_per_port":dict(gates),"ordinary_and_ranked_macros":emitted}


def invoice(word, caller, whole, p0, t0, paid, targets, split_by_port=True):
    n = caller["stages"]
    native = Counter(abs(len(word["frames"][e[3]])-len(word["frames"][e[2]]))
                     for e in word["program"] if e[0] == "MOVE")
    width = len(caller["types"]["B"]["ports"])
    factor = width if split_by_port else 1
    keep = Counter({int(r):n*q for r, q in whole["signed_profile"]["native_productive"].items()})
    keep.update({r:factor*q for r, q in targets.items()})
    keep.subtract({r:width*q for r, q in t0.items()})
    delta = Counter({r:factor*q for r, q in paid.items()})
    delta.subtract({r:width*q for r, q in p0.items()})
    result = DIRECT["signed_price"](native, whole, n, delta, keep)
    p = Counter({int(r):c for r, c in result["complete_paid"].items() if c})
    t = Counter({int(r):c for r, c in result["complete_productive"].items() if c})
    h = net(p, t)
    result["complete_paid"], result["complete_productive"] = dict(sorted(p.items())), dict(sorted(t.items()))
    result["complete_margin_selected_kappa"] = interval(PRICE.moment(h,Q(SELECTED)))
    result["raw_rank_balance"] = sum(r*q for r,q in h.items())
    # Under the source assumptions a negative moment has a unique crossing
    # because the derivative has a strict interval upper bound on [0, .0227].
    derivative = (0, 0)
    for r, coef in h.items():
        pwr = PRICE.power(r, Q(".0227") if coef > 0 else Q(0))
        derivative = PRICE.add(derivative, PRICE.smul(PRICE.mul(PRICE.log(r), pwr), -coef))
    if derivative[1] < 0 and PRICE.moment(h, Q(0))[0] > 0 > PRICE.moment(h, Q(".0227"))[1]:
        lo, hi = 0, 22_700_000_000
        den = 10**12
        while hi-lo > 1:
            mid = (hi+lo)//2
            m = PRICE.moment(h, Q(mid, den))
            NEED(m[0]*m[1] > 0, "Unresolved root sign")
            if m[0] > 0:
                lo = mid
            else:
                hi = mid
        result["formal_root_bracket"] = [f"0.{k:012d}" for k in (lo, hi)]
    return result


def same_mask(pairs, saving, deadline):
    """Exhaust all per-pair stage subsets, separating the sole full mask."""
    def to_bits(xs):
        return sum(1 << (q-1) for q in xs)

    full = to_bits(pairs[0][2])
    left = to_bits(pairs[1][2])
    right = to_bits(pairs[8][2])
    NEED(left & right == 0 and left | right == full, "Expected two genuinely disjoint clock halves")
    scores = {}
    for m in range(1, 18):
        for k in range(m+1):
            mask = range(m)
            bill = residual_bill(mask, range(k))
            scores[m,k] = PRICE.moment(net(bill, Counter({8*m+1:2})), Q(saving))

    def table(entries):
        @lru_cache(maxsize=None)
        def solve(j, remaining):
            if j == len(entries):
                return ((0,0),()) if not remaining else None
            mask = to_bits(entries[j][2]) & remaining
            subset = mask
            chosen, best_hi = None, None
            while True:
                solution = solve(j+1, remaining ^ subset)
                if solution is not None:
                    prior, assignments = solution
                    bounds = PRICE.add(prior, scores[len(entries[j][2]), subset.bit_count()])
                    if chosen is None or bounds[0] > chosen[0][0]:
                        chosen = (bounds, (subset, *assignments))
                    if best_hi is None or bounds[1] > best_hi:
                        best_hi = bounds[1]
                if not subset:
                    break
                subset = (subset-1) & mask
            if chosen is None:
                return None
            return (chosen[0][0], best_hi), chosen[1]
        return solve

    lsolve, rsolve = table(pairs[1:8] + [pairs[16]]), table(pairs[8:16] + [pairs[17]])
    best, upper = None, None
    for assigned in range(full+1):
        if assigned % 1024 == 0:
            NEED(monotonic() < deadline, "Bounded same-mask allocation")
        left_result = lsolve(0, left & ~assigned)
        right_result = rsolve(0, right & ~assigned)
        NEED(left_result is not None and right_result is not None, "At least the old full half mask fits")
        le, lx = left_result
        ri, rx = right_result
        here = PRICE.add(PRICE.add(le,ri), scores[len(pairs[0][2]), assigned.bit_count()])
        if best is None or here[0] > best[0][0]:
            best = here, (assigned, *lx[:-1], *rx[:-1], lx[-1], rx[-1])
        if upper is None or here[1]>upper:
            upper = here[1]
    out = []
    p, t = Counter(), Counter()
    used = 0
    for (x,y,mask), b in zip(pairs, best[1], strict=True):
        assigned = tuple(i for i in mask if b >> (i-1) & 1)
        NEED(to_bits(assigned) == b and used & b == 0, "Unique compatible hosted mark")
        used |= b
        p.update(residual_bill(mask, assigned))
        t[8*len(mask)+1] += 2
        out.append({"roles":(x,y), "target_mask":mask, "hosts":assigned, "residual":
                    tuple(i for i in mask if i not in assigned)})
    NEED(used == full, "All stages allocated")
    winner = PRICE.moment(net(p,t), Q(saving))
    NEED(winner[0] <= upper and upper-winner[0] < PRICE.B//10**30, "Directed optimal envelope for this family")
    return out, p, t, interval((winner[0],upper))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    for arg in ("word","caller","whole","output"):
        cli.add_argument(arg,type=Path)
    cli.add_argument("--expect",action="store_true")
    args = cli.parse_args()
    start = monotonic()
    deadline = start+24
    compiler, word = GAUGE["PHYSICAL"]["load_pins"](args.word)
    caller = json.loads(BASE["pin"](args.caller,BASE["CALLER"]))
    whole = json.loads(BASE["pin"](args.whole,BASE["WHOLE"]))
    pairs,p,t = old_b(caller)
    checks = replay_identities()
    circle, layout = cyclic(caller)
    bad, clock_operations, grid = sweep_cyclic_word(circle,layout)
    mutant, _, _ = sweep_cyclic_word(circle,layout,omit_translation=True)
    NEED(not bad and mutant == 1, "Full chronological Laurent endpoint and a one-output translation control")
    per_port = caller["types"]["B"]["ports"]
    gauge = []
    for port in per_port:
        basis = GAUGE["orthonormal"](word, port)
        mat = compiler.perm(9, basis)
        q = word["ports"][port]
        slopes = GAUGE["FLOOR"]["translation"](GAUGE["FLOOR"]["terms"](
            [*((GAUGE["transform_address"](basis,1<<i),1) for i in range(9)),
             *((1<<i,-1) for i in range(9))]))
        GAUGE["canonical_boundary"](compiler, word, port, mat, slopes)
        for stage in range(1, caller["stages"]+1):
            GAUGE["composed_stage_wrapper"](basis, stage)
        gauge.append({"port":port, "q":q, "round8_route_xor_swaps":len(GAUGE["factor_linear"](basis))})
    old = invoice(word,caller,whole,p,t,p,t)
    NEED(old["complete_paid_count"] == 110_468 and old["complete_productive_count"] == 22_461,
         "Complete baseline source comparison")
    l, b = caller["stages"], len(per_port)
    cyc_p, cyc_t = Counter(), Counter({17:l*b})
    combo_p, combo_t = Counter(), Counter({17:14,25:2})
    one_p, one_t = Counter({1:2}), Counter({17:16,9:2})
    same_plans = {}
    for point in (OPEN, ".005"):
        same, sp, st, bound = same_mask(pairs, point, deadline)
        NEED(st == t, "Every original dirty input/output target retained")
        same_plans[point] = {"role_allocation":same, "optimal_interval_per_port":bound, "paid_per_port":dict(sp),
                             "full_invoice":invoice(word,caller,whole,p,t,sp,st),
                             "exact_same_mask_word":verify_same_mask(same,sp)}
    allowances = {}
    for point in SAVINGS:
        k = Q(point)
        old_b_value = PRICE.moment({r:q*b for r,q in net(p,t).items()}, k)
        cyc_value = PRICE.moment(cyc_t, k)
        bound = PRICE.moment({1:l*b,8:l*b,9:l*b}, k)
        allowances[point] = {"old_full_B":interval(old_b_value), "cycle_full_B":interval(cyc_value),
                             "cycle_delta_vs_old":interval(PRICE.sub(cyc_value,old_b_value)),
                             "optimistic_full_B":interval(bound),
                             "cycle_delta_vs_optimistic":interval(PRICE.sub(cyc_value,bound)),
                             "ported_singleton_per_port":interval(PRICE.moment(net(one_p,one_t),k)),
                             "ported_odd3_per_port":interval(PRICE.moment(combo_t,k))}
    branches = {
        "literal_old": old,
        "cycle_all_type_B": invoice(word,caller,whole,p,t,cyc_p,cyc_t,split_by_port=False),
        "per_port_seven_pairs_and_triple": invoice(word,caller,whole,p,t,combo_p,combo_t),
        "per_port_eight_pairs_and_singleton": invoice(word,caller,whole,p,t,one_p,one_t),
    }
    control = next(j for j, row in enumerate(circle) if row["hosts"] == (1, l))
    NEED(circle[control]["ports"][0] != circle[control]["ports"][1], "Genuine seam crossing across ports")
    words = {"stage_cross_port_map":layout, "disjoint_dirty_owners":circle, "ports":gauge,
             "operations":dict(clock_operations), "omitted_translation_wrong_outputs":mutant,
             "checked_dirty_roots":l*b, "tensor_periodic_laurent_endpoint":True, "clock_grid":grid,
             "gauge_extra_unfused_elementary_route_passes":4*l*sum(p["round8_route_xor_swaps"] for p in gauge)}
    data = {"status":"PASS_EXACT_B_CLOCK_IDENTITIES_AND_TARIFFS", "source_head":DIRECT["ADJ"]["NATIVE_HEAD"],
            "phase_controls":checks, "signed_port_stage_routes":words, "tariff_allowances":allowances,
            "same_old_masks_isolated_pair_scope":same_plans, "changed_bank_conditional_prices":branches}
    payload = json.dumps(data,indent=2,sort_keys=True,default=str)+"\n"
    NEED(monotonic()<deadline, "Exact B caller branch exceeded finite budget")
    if args.expect:
        NEED(payload == args.output.read_text(encoding="utf-8"), "Receipt changed")
    else:
        args.output.write_text(payload,encoding="utf-8")
    print(data["status"], f"{monotonic()-start:.2f}s", flush=True)


if __name__ == "__main__":
    main()
