"""Audit common physical cuts for the exact #7113 Type B idle directions."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
SUPPORT = run_path(str(HERE/"type_b_clock.py"))
BASE, NEED = SUPPORT["BASE"], SUPPORT["NEED"]
N = 36


def increment(row, other, factor):
    for i, c in other.items():
        value = row.get(i, Q(0)) + factor*c
        if value:
            row[i] = value
        else:
            row.pop(i, None)


def mult(a,b):
    out = {}
    for j, factor in a.items():
        increment(out,b[j],factor)
    return out


def pair(x,y):
    return sum(a*y.get(j,0) for j,a in x.items())


def series(caller, sign):
    f = [{i:Q(1)} for i in range(N)]
    fi = [{i:Q(1)} for i in range(N)]  # Column j of F inverse.
    offset = caller["types"]["B"]["offset"]
    cuts, marks = [], {}
    events = caller["events"]
    counts = Counter()
    for at, e in enumerate(events):
        if e[0]=="A":
            continue
        cuts.append((at,[v.copy() for v in f],[v.copy() for v in fi]))
        if e[0] == "J":
            x,y,*_ = e[3]
            x-=offset; y-=offset
            fx,fy = f[x].copy(),f[y].copy()
            f[x] = fx.copy()
            increment(f[x],fy,-sign)
            f[y] = {k:v/2 for k,v in fy.items()}
            increment(f[y],fx,Q(sign,2))
            rx,ry = fi[x].copy(),fi[y].copy()
            fi[x] = {k:v/2 for k,v in rx.items()}
            increment(fi[x],ry,Q(-sign,2))
            fi[y] = ry.copy()
            increment(fi[y],rx,sign)
        else:
            _,op,x,*a = e
            x-=offset
            if op == "SWAP":
                y=a[0]-offset
                f[x],f[y]=f[y],f[x]
                fi[x],fi[y]=fi[y],fi[x]
            elif op == "ADD":
                y=a[0]-offset
                factor=Q(a[1])
                increment(f[x],f[y],factor)
                increment(fi[y],fi[x],-factor)
            elif op in ("LAMBDA","SCALE","IDLE_ODD"):
                factor = Q(1 if op=="LAMBDA" else a[0] if op=="SCALE" else sign)
                f[x] = {k:v*factor for k,v in f[x].items()}
                fi[x] = {k:v/factor for k,v in fi[x].items()}
            else:
                NEED(op == "IDLE_ONE", "Unexpected B-domain primitive")
                marks[at] = (fi[x].copy(),f[x].copy(),tuple(a[0]))
                counts[len(a[0])] += 1
        if e[0]=="J" or (e[0]=="B" and e[1] in ("IDLE_ONE","IDLE_ODD")):
            NEED(all(pair(f[i],fi[j])==int(i==j) for i in range(N) for j in range(N)),
                 "All staged prefix inverse columns")
    cuts.append((len(events),f,fi))
    want = [{i:Q(sign)} for i in range(N)]
    NEED(f==want and fi==want and counts[1]==34,"Pinned signed final root and literal singleton inventory")
    return cuts,marks


def projectors(marks):
    groups={}
    for i,(u,v,labels) in marks.items():
        NEED(pair(u,v)==1,"One independent rank-one idle component")
        law=tuple(sorted((a,b,c*d) for a,c in u.items() for b,d in v.items()))
        groups.setdefault(law,[]).append((i,labels))
    return groups


def equal_direction_groups(groups):
    out=[]
    for records in groups.values():
        labels=set()
        overlap=0
        for _,mask in records:
            overlap+=len(labels.intersection(mask))
            labels.update(mask)
        if len(records)>1:
            out.append({"events":records,"distinct_labels":len(labels),"duplicate_marks":overlap})
    return out


def expr_basis(columns):
    """Independent row generators of column space, all over Q."""
    basis={}
    for original in columns:
        w=original.copy()
        while w:
            j=min(w)
            value=w[j]
            if j not in basis:
                basis[j]={i:a/value for i,a in w.items()}
                break
            increment(w,basis[j],-value)
    return list(basis.values())


def intersects(cols, rows, other_cols, other_rows):
    """Return columns and rows of their respective exact intersections."""
    return intersection(cols,other_cols),intersection(rows,other_rows)


def intersection(a,b):
    basis={}
    common=[]
    for i, orig in enumerate((*a,*b)):
        w=orig.copy()
        used={i:Q(1)}
        while w:
            j=min(w)
            value=w[j]
            if j not in basis:
                basis[j]=({k:x/value for k,x in w.items()},{k:x/value for k,x in used.items()})
                break
            v,rel=basis[j]
            increment(w,v,-value)
            increment(used,rel,-value)
        if not w:
            f=mult({k:v for k,v in used.items() if k<len(a)},a)
            if f:
                common.append(f)
    return expr_basis(common)


def pooled(marks):
    out={}
    for u,v,labels in marks.values():
        if len(labels)==1:
            x,y = out.setdefault(labels[0],([],[]))
            x.append(u)
            y.append(v)
    for j,(x,y) in out.items():
        NEED(len(expr_basis(x))==len(expr_basis(y))==2,"Two paid rank-eight directions per fresh body label")
    return out


def coupled_cuts(cuts, cols, rows, other_cols, other_rows, deadline):
    out=[]
    for i,((at,f,fi),(other,g,gi)) in enumerate(zip(*cuts,strict=True)):
        if i%128==0:
            NEED(monotonic() < deadline, "Bounded exact cut intersection")
        NEED(at==other,"Matched literal cut")
        # Physical u = Fplus * common_plus_coordinate. The same vector
        # pulls back to Cminus=Fminus^-1 Fplus * common_plus_coordinate.
        x = [mult({j:pair(r,v) for j,r in enumerate(f) if pair(r,v)},gi) for v in cols]
        y = [mult({j:pair(v,r) for j,r in enumerate(fi) if pair(v,r)},g) for v in rows]
        a,b = intersects(x,y,other_cols,other_rows)
        if any(pair(v,w) for v in a for w in b):
            out.append(at)
    return out


def controls():
    a,b=({0:Q(1)},{1:Q(1)})
    # Exact positive and negative controls for compatible row/column intersection.
    x,y=intersects([a,b],[a,b],[b],[b])
    NEED(x==y==[b] and pair(x[0],y[0])==1, "Planted same-owner fibre")
    x,y=intersects([a,b],[a,b],[b],[a])
    NEED(not any(pair(u,v) for u in x for v in y),"Disjoint covector fixture")
    props={0:(a,a,(1,)),1:(a,a,(2,)),2:(b,b,(3,))}
    result=equal_direction_groups(projectors(props))
    NEED(result==[{"events":[(0,(1,)),(1,(2,))],"distinct_labels":2,"duplicate_marks":0}],
         "Exact regrouping fixture must be found")
    return 3


def run(caller):
    deadline = monotonic()+14
    fixture_count=controls()
    s1,t1=series(caller,1)
    s2,t2=series(caller,-1)
    groups = [equal_direction_groups(projectors(t)) for t in (t1,t2)]
    lp, rp=pooled(t1),pooled(t2)
    pairs = 0
    joint = []
    for j,k in combinations(lp,2):
        x,y=intersects(*lp[j],*lp[k])
        a,b=intersects(*rp[j],*rp[k])
        if not any(pair(v,w) for v in x for w in y) or not any(pair(v,w) for v in a for w in b):
            continue
        pairs+=1
        ok=coupled_cuts((s1,s2),x,y,a,b,deadline)
        joint.append({"stages":[j,k],"common_physical_cuts":len(ok),"first_cut":ok[0] if ok else None})
    NEED(monotonic() < deadline,"Bounded complete singleton merge screen")
    return {"status":"PASS_EXACT_LITERAL_B_SINGLETON_SCREEN","existing_type_b_and_joint_cuts":len(s1),
            "type_a_only_cuts_omit_unchanged_B_prefix":len(caller["events"])+1-len(s1),
            "stage_pair_tests":len(tuple(combinations(lp,2))),
            "paired_input_output_intersections":pairs,"simultaneous_sector_candidates":joint,
            "equal_existing_projector_groups_in_either_sector":groups,"verified_controls":fixture_count}


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("caller",type=Path)
    p.add_argument("out",type=Path)
    p.add_argument("--expect",action="store_true")
    args=p.parse_args()
    result=run(json.loads(BASE["pin"](args.caller,BASE["CALLER"])))
    payload=json.dumps(result,sort_keys=True,indent=2)+"\n"
    if args.expect:
        NEED(args.out.read_text(encoding="utf-8")==payload, "Receipt changed")
    else:
        args.out.write_text(payload,encoding="utf-8")
    print(result["status"],result["paired_input_output_intersections"],result["simultaneous_sector_candidates"])
