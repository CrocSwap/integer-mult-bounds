# Independent price of even-clock and all-stage idle constraints

The signed Type A model has a common center, \(L\) full hosts of \(r=192\) disjoint odd shears, and \(c\) paid one-role compound odd idles whose sector-relative factors are rank-one reflections. Let \(d\) be the additional complement defect beyond \(r\). The number of independent odd roots is \(n=r(L-1)+c-d\), and comparison of determinants gives \(d\) even. Type A and Type B use separate scalar spaces. The \(L\) bodies are positive independent unit labels of width eight and every completed output is diagonal on its arbitrary initial input. Ordinary scalar maps are square, invertible and sector-even. This is a changed caller model from the original signed tape. [#7546 native candidate](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

The mandatory even-clock bound is taken from the opposite-sector span proof in IDLE-RESIDUE, in its arbitrary odd \(L\) form. Write \(h=(L-3)/2\). If \(d=0\), at least \(M=\max(0,2rh-2h\lfloor c/2\rfloor)\) grouped idle incidences are required on even interior labels. If \(d>0\), use
\[
M=\max\left(0,2rh-d\left[4h+2\sum_{i=2,4,\ldots,L-3}\min(i,L-1-i)\right]-2\lfloor hc/2\rfloor\right).
\]
To see the last reflection term, at mirror positions use the shorter prefixes and suffixes. Their counted reflection sets are disjoint. At a middle clock use the smaller side by reflection count. The full-body pulse rank cap and positive-unit support argument apply also to reflections whose body job carries several labels. The count is of incidences, not total recursive calls.

The larger formal model may use an idle of size \(a\le L\). The pure-width cap \(L-3\) is only asserted for \(c=d=0\). For a single role with \(k=x+y\le L\), \(y>0\), put
\[
G_a=\min_{k\ge a}\left\{\frac{\ell(x)-H_{8(x+y)+1}}{y}
                        +\frac{H_{8a}}a\right\},
\quad \ell(x)=H_{17}+(x-2)(H_{25}-H_{17}).
\]
The minimum also ranges over all \(x,y\ge0\) with the given conditions. Every gram of body cost here is charged once through the matching: a group of size \(a\) supplies \(a\) separately allocated mark penalties of at least \(G_a\). The \(c\) odd phases each pay at least \(H_{8L+1}-H_{8L}\) after their group body part has been charged.

Let \(\lambda=\min_aG_a\), \(\mu=\min_{a<L}G_a-\lambda\), and \(\nu=\min_a aG_a/\min(h,a)\). At most \(c\) idle calls have full mask \(a=L\), by the independent-native source-annihilation theorem. Thus a complete body debit of at least \(\lambda M+\mu\max(0,M-Lc)\) follows. The per-even-incidence bound instead gives \(\nu M\). Use their **maximum** because both calculations charge the same body work. This interval computation keeps all actual #7546 paid moves and independent helper returns and grants the eight Type B ports their entire optimistic joint allowance. It does not infer any matching operator at a positive endpoint.

| Case at κ=.005 | Complete upper endpoint |
| --- | ---: |
| \(L=17,c=105\), maximum over all even \(d\) | **−0.0634744836599** |
| \(L=17,c=106\), maximum at \(d=20\) | +0.1674686380067 |
| \(L=19,c=0,d=8\) | **−0.0773088159187** |
| \(L=19,c=0,d=10\) | +0.7405443031075 |
| \(L=19,c=0\), maximum over even \(d\) at 26 | +7.2833692553167 |
| \(L=19,c=16,d=0\) | +0.1235403294802 |

For \(L=17\) all sampled \(c\le105\) fail even maximizing over \(d\). For \(L=19,d=0\), all sampled \(c\le15\) fail. For \(L=19,c=0\), the first even \(d\) with nonnegative envelope is 10. The displayed full defect search allows \(n\ge0\), including dimensions below the actual host width, as a favorable relaxation. These are price screens at one value of κ, with the earlier arbitrary-signed joint cut providing the separate rejection at .0227 for the retained native alphabet.

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round9\recurrence\verify_combined_price.py $complexPack --expect .\work\round9\recurrence\combined-price.json
~~~

The checker independently constructs the directed per-mask charge and enumerates 260,866 even-defect rows. It uses adjacent verify_seam_price.py for the same pinned source and interval machinery. Both normal and optimized replays completed within 1.16 seconds under 15-second caps. Their identical receipt SHA-256 is `1af5498a7e76931eafa00ede356fc158b3262fbc5e28b01e767ed745a70ecca8`. AST parsing and tabnanny passed.
