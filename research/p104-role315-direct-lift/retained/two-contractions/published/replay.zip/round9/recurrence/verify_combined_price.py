"""Independently recompute the max of the two proved grouped-idle debits."""

import argparse
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("seam", HERE / "verify_seam_price.py")
SEAM = module_from_spec(SPEC)
SPEC.loader.exec_module(SEAM)
CORE = SEAM.CORE
need = CORE.need
WIDTH = 192


def modes(stages, point):
    def h(n):
        return CORE.price(n,*point)

    l0 = SEAM.subtract(CORE.scaled(h(17),3),CORE.scaled(h(25),2))
    l1 = SEAM.subtract(h(25),h(17))
    g = []
    for a in range(1,stages+1):
        fee = CORE.scaled(h(8*a),1,a)
        possibilities = []
        for k in range(a,stages+1):
            target = h(8*k+1)
            for y in range(1,k+1):
                line = CORE.add(l0,CORE.scaled(l1,k-y))
                credit = CORE.scaled(SEAM.subtract(line,target),1,y)
                possibilities.append(CORE.add(fee,credit))
        g.append((min(x[0] for x in possibilities),min(x[1] for x in possibilities)))
    lam = min(g)
    need(lam == g[-1],"Unexpected minimum group profile")
    short0,short1 = min(x[0] for x in g[:-1]),min(x[1] for x in g[:-1])
    mu = SEAM.subtract((short0,short1),lam)
    even = [CORE.scaled(v,a,min(a,(stages-3)//2)) for a,v in enumerate(g,1)]
    nu = (min(x[0] for x in even),min(x[1] for x in even))
    need(min(lam[0],mu[0],nu[0])>0,"A required dual charge has uncertain positivity")
    head = SEAM.subtract(h(8*stages+1),h(8*stages))
    return l0,l1,head,lam,mu,nu


def minimum_even_usage(stages,c,d):
    even = tuple(range(2,stages-1,2))
    count = len(even)
    pure = 2*WIDTH*count
    if d==0:
        return max(0,pure-2*count*(c//2))
    clock_debit = sum(min(i,stages-1-i) for i in even)
    damage = (4*count+2*clock_debit)*d+2*(count*c//2)
    return max(0,pure-damage)


def row(stages,c,d,terms,source):
    l0,l1,head,lam,mu,nu = terms
    roots = WIDTH*(stages-1)+c-d
    marks = minimum_even_usage(stages,c,d)
    native = CORE.add(CORE.scaled(l0,roots),CORE.scaled(l1,2*WIDTH*stages))
    upper = SEAM.subtract(CORE.add(source,native),CORE.scaled(head,c))
    short = CORE.add(CORE.scaled(lam,marks),CORE.scaled(mu,max(0,marks-stages*c)))
    clock = CORE.scaled(nu,marks)
    debit = max(short[0],clock[0]),max(short[1],clock[1])
    return SEAM.subtract(upper,debit),roots,marks


def sweep(stages,p,paid,helper,c_values):
    terms = modes(stages,p)
    native = SEAM.source_cost(stages,p,paid,helper)
    all_cases = {}
    for c in c_values:
        ceiling = WIDTH*(stages-1)+c
        props = [(row(stages,c,d,terms,native),d) for d in range(0,ceiling+1,2)]
        ((grade,roots,m),win) = max(props,key=lambda item:item[0][0][1])
        d0 = props[0][0][0]
        first = next((d for ((value,_,_),d) in props if value[1]>=0),None)
        all_cases[c] = {"maximum_defect_sweep_upper":CORE.format_bounds(grade)[1],"maximizing_defect":win,
                        "maximum_defect_sweep_roots":roots,"mandatory_even_incidences_at_maximum":m,
                        "least_sampled_defect_not_excluded":first,"d0_upper":CORE.format_bounds(d0)[1],
                        "defects_checked":len(props)}
    return all_cases


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack",type=Path)
    cli.add_argument("--expect",type=Path)
    args=cli.parse_args()
    paid,helper=SEAM.CLOCK.JOINT.read_complex(args.complex_pack)
    point=(5,1000)
    s17=sweep(17,point,paid,helper,range(121))
    s19=sweep(19,point,paid,helper,range(41))
    first17=next(c for c,vals in s17.items() if Fraction(vals["maximum_defect_sweep_upper"])>=0)
    first19=next(c for c,vals in s19.items() if Fraction(vals["d0_upper"])>=0)
    need(first17==106 and s17[first17]["maximizing_defect"]==20,"17-host opening changed")
    need(first19==16 and s19[0]["least_sampled_defect_not_excluded"]==10 and
         s19[0]["maximizing_defect"]==26,"19-host opening changed")
    t19=modes(19,point)
    p19=SEAM.source_cost(19,point,paid,helper)
    excesses={d:CORE.format_bounds(row(19,0,d,t19,p19)[0])[1] for d in (0,2,4,6,8,10,26)}
    payload=json.dumps({"status":"PASS_COMBINED_GROUPED_IDLE_PRICE", "L17":s17,"L19":s19,
        "L19_Q0_selected_extra_defects":excesses,
        "first_sampled_nonnegative_17_host_odd_idle_count":first17,
        "first_sampled_nonnegative_19_host_odd_idle_count_at_d0":first19,
        "full_even_defect_records_checked":sum(a["defects_checked"] for S in (s17,s19) for a in S.values())},
        indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Price receipt changed")
    print(payload)


if __name__ == "__main__":
    main()
