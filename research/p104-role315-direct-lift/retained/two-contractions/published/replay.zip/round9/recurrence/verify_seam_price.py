"""Exact source-priced rank bound from body-idle cyclic omission cuts."""

import argparse
from collections import Counter
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / "round8" / "recurrence" / "verify_even_clock_balance.py"
SPEC = spec_from_file_location("even_clock_balance", SOURCE)
CLOCK = module_from_spec(SPEC)
SPEC.loader.exec_module(CLOCK)
CORE = CLOCK.CORE
need = CORE.need


def subtract(a, b):
    return CORE.add(a, CORE.scaled(b,-1))


def source_cost(stages, point, paid, helpers):
    full = Counter({j:v*stages for j,v in helpers.items()})
    full.subtract({j:v*stages for j,v in paid.items()})
    full.update({1:8*stages,8:8*stages,9:8*stages})
    return CORE.moment(full,*point)


def seam_dual(stages, point):
    h = lambda n: CORE.price(n,*point)
    r = 192
    roots = r*(stages-1)
    native = 2*r*stages
    mandatory = r*(stages-3)
    seam_width = (stages-3)//2
    l0 = subtract(CORE.scaled(h(17),3),CORE.scaled(h(25),2))
    l1 = subtract(h(25),h(17))
    contenders = []
    check_nonseam = 0
    for x in range(stages+1):
        line = CORE.add(l0,CORE.scaled(l1,x))
        for y in range(stages-x+1):
            k = x+y
            if y == 0:
                if x not in (2,3):
                    need(subtract(line,h(8*k+1))[0]>0,"Zero-idle affine line not dominating")
                continue
            unbilled_share = CORE.scaled(subtract(line,h(8*k+1)),1,y)
            for a in range(1,min(stages-3,k)+1):
                debit = CORE.add(unbilled_share,CORE.scaled(h(8*a),1,a))
                need(debit[0]>0,"A non-seam mark could consume the upper envelope")
                check_nonseam += 1
                best_e = min(a,seam_width)
                cost = CORE.scaled(debit,a,best_e)
                contenders.append((cost,x,y,a,best_e))
    best,x,y,a,e = min(contenders)
    need(all((u,v,p,q)==(x,y,a,e) or score[0]>best[1] for score,u,v,p,q in contenders),
         "The directed comparison does not isolate the best mask profile")
    return {"roots":roots,"native_marks":native,"compulsory_even_incidences":mandatory,
            "searched_local_tariff_profiles":check_nonseam,"minimizing_profile":[x,y,a,e],
            "per_even_mark_floor":CORE.format_bounds(best),
            "raw_balance_expression":CORE.add(CORE.scaled(l0,roots),CORE.scaled(l1,native)),
            "necessary_even_debit":CORE.scaled(best,mandatory)}


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack",type=Path)
    cli.add_argument("--expect",type=Path)
    args=cli.parse_args()
    paid,helper=CLOCK.JOINT.read_complex(args.complex_pack)
    scopes={}
    for saving,point in ((".005",(5,1000)),(".0227",(227,10000))):
        for stages in (17,19,21):
            record=seam_dual(stages,point)
            debit=record.pop("necessary_even_debit")
            core=CORE.add(record.pop("raw_balance_expression"),source_cost(stages,point,paid,helper))
            record["new_upper"]=CORE.format_bounds(subtract(core,debit))
            record["without_charge"]=CORE.format_bounds(core)
            record["even_debit"]=CORE.format_bounds(debit)
            scopes[f"{saving}_L{stages}"]=record
    need(Fraction(scopes[".005_L19"]["new_upper"][1])<-3,"The 19-stage price failed to reject")
    payload=json.dumps({"status":"PASS_CYCLIC_SEAM_PRICE", "profiles":scopes},indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Price receipt changed")
    print(payload)


if __name__ == "__main__":
    main()
