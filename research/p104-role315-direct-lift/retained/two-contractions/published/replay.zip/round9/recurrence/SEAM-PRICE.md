# Independent check of the cyclic omission and even-clock price

A Type A body idle in an exact-defect signed caller cannot touch all but two clocks. With 19 hosts and zero additional odd events, the tighter even-clock tariff excludes a positive margin at \(\kappa=.005\), with full upper endpoint **−3.3487212920233**. The independent price keeps the complete paid native and helper inventory from the open #7546 candidate, while granting Type B its entire joint-cut allowance. It covers the globally mixed Type A model after normalization to a common center, with A/B separation, square sector-even ordinary mixing, positive unit independent body labels, and no thin queries or compound odd idles. It does not describe the literal #7113 schedule. [Open #7546 candidate](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

## Two sectors, idle support and cyclic re-cutting

Let \(L\) be odd, \(r\) the number of disjoint shears per full host and \(n=r(L-1)\). In the normalized clock, \(V_iU_j=2\operatorname{sgn}(j-i) I_r\) and \(R_b=(I+U_{b-1}V_{b-1})\cdots(I+U_0V_0)\). There is a unique nondegenerate alternating form \(J\) such that \(V_i=U_i^{T}J\). In fact the displayed skew Gram prescribes the form on the spanning columns, and its only kernel in host-index coordinates is the alternating relation. Each \(I+U_iV_i\) preserves \(J\), using \(V_iU_i=0\). This canonical saturated sign-Gram clock has a scalar precedent in [the saturated header braid analysis](https://github.com/CrocSwap/integer-mult-bounds/tree/e54523517d0f03e58352e647c403a5af3e525a57/research/p104-header-braid-classification).

Write a paid rank-one body idle in the nominal input basis as \(w f\), with \(f(w)=1\), and let its chronological cut \(b\) be before clock \(b\). Its opposite-sector projector is \(R_b^{-1}w f R_b\). For each body label \(i\) in its mask \(T\), the complete positive-body determinant degree and first derivative yield independent native and idle preserving spaces in both sectors. Their total projector has rank equal to the sum of constituent ranks. Factoring the totals as \(UV\) gives \(VU=I\) on the constituent columns, by idempotence. Thus the native and idle constituents annihilate each other in each sector. In particular the covector \(f\) kills \(U_i\) and \(R_bR_i^{-1}U_i\), and \(w\) is killed by \(V_i\) and \(V_iR_iR_b^{-1}\). With \(g=w^TJ\), the latter conditions are the same dual covector equations on \(g\), because every \(R_i\) preserves \(J\). This transport assumes the body-one ordinary map at the cut is actually absorbed into the nominal basis.

The independent sign calculation for \(i<b\) is
\[
R_bR_i^{-1}U_i=U_i+2\sum_{i<j<b}(-1)^{j-i}U_j,
\]
and for \(i\ge b\) it is
\[
R_bR_i^{-1}U_i=U_i+2\sum_{b\le j<i}(-1)^{i-j}U_j.
\]
The first expansion goes forward starting with the host at \(i\), which fixes \(U_i\), and the alternating coefficients follow from its sign Gram. The second goes backward starting with the inverse of host \(i-1\). Put \(s_j=(-1)^j fU_j\), and similarly \(t_j=(-1)^j gU_j\). The sums of both weighted lists are zero. The idle conditions are that \(s_i=0\) at \(i\in T\), and that the prefix of \(s\) from cut \(b\) to each such \(i\), excluding \(i\), has sum zero using the order cyclically cut at \(b\). For \(i<b\) one uses the zero total to replace the reversed interval by the forward wrap interval. These conditions say the vector is supported in the missing runs, with sum zero in every such run. A missing cyclic run is cut into two separate runs if it crosses \(b\). Its total is zero regardless.

To calculate the row-column pairing, write \(w=\sum_k U_k a_k\), \(B_k=(-1)^k a_k\). The sign Gram gives \(B_{k+1}-B_k=(t_k+t_{k+1})^T/2\). The indeterminacy in \(B_0\) is constant across the list, so drops out of \(f(w)\). This gives
\[
f(w)=\tfrac12\sum_j s_j t_j^T+\sum_{k<j}s_jt_k^T .
\]
The formula stays the same on zero-sum vectors under cyclic re-cutting. For example, moving the first coordinate to the last changes the prefix expression by zero after using both total sums. One keeps the original weights \((-1)^j\) when reordering the weighted list.

For a missing run of size \(h\), adjacent differences give a basis of its zero-sum space. The form in that basis is skew tridiagonal with off-diagonal entries of magnitude \(1/2\), tensored by \(I_r\). Its rank is \(2r\lfloor(h-1)/2\rfloor\). Distinct runs are mutually orthogonal by their separate zero sums. Hence one productive idle needs a run of at least length three in the **cut** list. Its mask size is at most \(L-3\). At \(L=19\), a width-16 mask omits one cyclic triple of consecutive clocks and cannot have its chronological cut strictly inside that triple.

There is also an all-cut capacity bound. Fix any nonempty \(T\) and consider every paid idle whose mask contains \(T\), at arbitrary cuts. Their nominal \(f_a,w_b\) satisfy \(f_a(w_b)=\delta_{ab}\), because the constituent projectors for any selected common label are pairwise annihilating. Their weighted rows and columns all have zero sums on the missing **cyclic** runs of \(T\). Thus their total count is at most \(\sum_h 2r\lfloor (h-1)/2\rfloor\), where the sum is over those runs independent of cut. The two seam-spanning width-16 omission triples at \(L=19\) jointly occupy one four-coordinate run, and the combined capacity for both masks is at most \(2r\). Both masks share labels, so this follows by the same argument.

## Compulsory cyclic-boundary-crossing idles

For an even interior clock \(i\), the earlier round's exact proof gives the \(2r\)-dimensional columns \([U_i,A_i]\), \(A_i=R_i^{-1}U_i\), and the \(2r\)-dimensional covectors \([V_i;B_i]\), \(B_i=V_iR_i=A_i^TJ\). These two spaces are mutually annihilating over the signed coefficient field. For even \(i\), the inverse expansion gives
\[
A_i=U_i+2\sum_{a<i}(-1)^aU_a .
\]

Consider an idle covering \(i\) whose mask's omitted cyclic runs do not cross the original boundary between clocks \(L-1\) and \(0\). Its \(f,g\) annihilate \(U_i\), and their weighted prefixes to \(i\) are sums of complete missing runs, each of zero sum. Thus \(fA_i=gA_i=0\), so that nominal idle annihilates both preserving stacks, including the opposite-sector span, on both sides. Removing all such idles from the nominal full projector decomposition for label \(i\) leaves both stacks inside the remaining native and boundary-crossing idle projection. Its rank must be at least \(4r\), by the mutually annihilating \(2r\)-dimensional row and column spaces. The native's own rank is \(2r\). Therefore every even interior clock is covered by at least \(2r\) paid idles with a missing cyclic component crossing the original boundary. This extra support condition is useful when designing schedules. The price below only uses \(2r\) incidences on each even interior clock.

## Pricing every paid group once

On any output role, let \(x\) be its allocated native marks, \(y\) its paid idle marks, and \(k=x+y\). The determinant-saturated nominal columns give a matching, separately for each label, to distinct output coordinate incidences. When a body idle of size \(a\) is assigned to a coordinate for one label, that coordinate also carries its other \(a-1\) labels. Thus \(a\le k\) on every assigned mark. The idle pays \(H_{8a}/a\) per mark, with \(H_j=j^{1-\kappa}\).

The affine line \(\ell(x)=H_{17}+(x-2)(H_{25}-H_{17})\) is a valid upper bound when \(y=0\). For \(y>0\), split the difference from the raw target credit equally across the \(y\) marks. The resulting debit per mark for that idle is at least
\[
\eta_a(x,y)=\frac{\ell(x)-H_{8k+1}}y+\frac{H_{8a}}a .
\]
This is nonnegative: replace \(a\le k\) by \(k\) in the per-mark body fee, then use \(xH_{8k}/k\le H_{8x}\), decreasing header increments, and the affine bound. The exact code checks this on every enumerated profile.

Let \(e\) be the number of even interior clocks in this idle's mask. Since \(e\le\min(a,(L-3)/2)\), every idle with \(e>0\) pays debit at least \(e\lambda_*\), where
\[
\lambda_*=\min_{\substack{y>0,\ k=x+y\le L\\1\le a\le\min(k,L-3)}}
  \frac{a}{\min(a,(L-3)/2)}\,\eta_a(x,y).
\]
For \(e=0\) use only the nonnegative floor. Summing credits counts every idle once. The even interior clocks force \(r(L-3)\) charged incidences. The bound contains \(n\ell(0)+2rL(H_{25}-H_{17})\) of baseline Type A credit, less \(\lambda_*r(L-3)\), plus the full signed native-and-helper invoice and optimistic Type B amount \(8L(H_8+H_9+1)\).

| \(L\) | Compulsory even incidences | Complete upper at .005 |
| ---: | ---: | ---: |
| 17 | 2,688 | −28.8954181537894 |
| 19 | 3,072 | **−3.3487212920233** |
| 21 | 3,456 | +22.2271300960780 |

At \(L=19\), 2,360 local inequalities isolate the least pressure at \(x=0,y=8,a=8,e=8\). Its directed interval is \([.0133020373655,.0133020373656]\). The full minimum debit is between 40.8638587868223 and 40.8638587868224. The \(L=21\) entry remains a relaxation and supplies no feasible full word. All signed precision and ordinary routing costs external to this upper estimate remain obligations, even when the exact finite phase operator is used.

## Replay

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round9\recurrence\verify_seam_price.py $complexPack --expect .\work\round9\recurrence\seam-price.json
~~~

The replay imports round8/recurrence/verify_even_clock_balance.py and its existing source and interval closure. Use the same pinned three-file complex pack. The local script checks the finite directed integer grid and source invoice independently of the parent's cyclic geometry replay. Normal and optimized runs took 0.165 and 0.170 seconds inside their 15-second limits. The output was identical, with SHA-256 `cc5e190d4ade96dc4772d439ccf12a29c4ef63cb3937d15e1fa8e81be245d781`. AST parsing and tabnanny passed.
