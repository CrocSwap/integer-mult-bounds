"""Certify the source-bound tariff from all pairs of signed body clocks."""

import argparse
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("combined", HERE / "verify_combined_price.py")
COMBINED = module_from_spec(SPEC)
SPEC.loader.exec_module(COMBINED)
SEAM = COMBINED.SEAM
CORE = SEAM.CORE
need = CORE.need
WIDTH = COMBINED.WIDTH
DENOMINATOR = 100000
PURE = {
    5: (0, 4987), 7: (318, 2577), 9: (318, 1881), 11: (318, 1530),
    13: (291, 1449), 15: (269, 1427), 17: (255, 1336), 19: (244, 1236),
    21: (244, 863), 23: (244, 442), 25: (243, 2), 27: (221, 16),
    29: (203, 13), 31: (188, 3), 33: (174, 17), 35: (163, 0),
    37: (152, 18), 39: (143, 15), 41: (135, 11), 43: (128, 4),
    45: (121, 15), 47: (115, 17), 49: (110, 5), 51: (105, 6),
    53: (100, 19), 55: (96, 14), 57: (92, 18),
}
MIXED = {17: (289, 554, 922), 19: (276, 407, 936), 21: (264, 272, 916)}


def exact_weight(value):
    weight, remainder = divmod(CORE.SCALE * value, DENOMINATOR)
    need(remainder == 0, "Weight is not an exact point at the interval scale")
    return weight, weight


def certify_local(stages, point, pair_weight, even_weight, pure):
    h = [CORE.price(j, *point) for j in range(8 * stages + 2)]
    intercept = SEAM.subtract(CORE.scaled(h[17], 3), CORE.scaled(h[25], 2))
    slope = SEAM.subtract(h[25], h[17])
    head = SEAM.subtract(h[8 * stages + 1], h[8 * stages])
    max_mask = stages - 3 if pure else stages
    even_clocks = (stages - 3) // 2
    profiles = 0
    minimum = None
    for k in range(stages + 1):
        possible_fees = []
        for a in range(1, min(k, max_mask) + 1):
            possible_fees.append(
                CORE.add(CORE.scaled(h[8 * a], 1, a), CORE.scaled(pair_weight, a - 1))
            )
        for x in range(k + 1):
            y = k - x
            if y == 0 and x in (2, 3):
                # The affine line equals the target here, so evaluate the exact cancellation.
                need(k * (k - 1) - 2 * x <= 0, "Invalid adjusted pressure at equality")
                continue
            numerator = SEAM.subtract(CORE.add(intercept, CORE.scaled(slope, x)), h[8 * k + 1])
            numerator = SEAM.subtract(numerator, CORE.scaled(pair_weight, k * (k - 1) - 2 * x))
            numerator = SEAM.subtract(numerator, CORE.scaled(even_weight, min(even_clocks, y)))
            for fee in possible_fees if y else ((0, 0),):
                remainder = CORE.add(numerator, CORE.scaled(fee, y))
                need(remainder[0] > 0, f"Unverified tariff at L={stages}, x={x}, y={y}")
                profiles += 1
                minimum = remainder if minimum is None else min(minimum, remainder)
    need(intercept[0] > 0, "The large-defect extension requires a positive intercept")
    return intercept, slope, head, profiles, minimum


def full_margin(stages, c, d, line, source, pair_weight, even_weight):
    intercept, slope, head = line
    roots = WIDTH * (stages - 1) + c - d
    native_marks = 2 * WIDTH * stages
    pair_floor = max(0, WIDTH - d) * stages * (stages - 1) - 2 * native_marks
    even_floor = COMBINED.minimum_even_usage(stages, c, d)
    margin = CORE.add(source, CORE.scaled(intercept, roots))
    margin = CORE.add(margin, CORE.scaled(slope, native_marks))
    margin = SEAM.subtract(margin, CORE.scaled(head, c))
    margin = SEAM.subtract(margin, CORE.scaled(pair_weight, pair_floor))
    return SEAM.subtract(margin, CORE.scaled(even_weight, even_floor))


def pure_result(stages, point, raw_weights, paid, helpers):
    w, nu = map(exact_weight, raw_weights)
    *line, profiles, minimum = certify_local(stages, point, w, nu, pure=True)
    source = SEAM.source_cost(stages, point, paid, helpers)
    upper = full_margin(stages, 0, 0, line, source, w, nu)
    return {
        "pair_and_even_weight_numerators": raw_weights,
        "profiles_checked": profiles,
        "strictly_positive_local_gap": CORE.format_bounds(minimum),
        "full_upper": CORE.format_bounds(upper),
    }, upper


def mixed_result(stages, point, raw_weights, search_limit, paid, helpers):
    w, nu = map(exact_weight, raw_weights)
    *line, profiles, minimum = certify_local(stages, point, w, nu, pure=False)
    source = SEAM.source_cost(stages, point, paid, helpers)
    best = {}
    for c in range(search_limit + 1):
        # At d >= WIDTH both lower bounds are constant and the price falls by ell(0) per d.
        need(COMBINED.minimum_even_usage(stages, c, WIDTH) == 0, "Invalid large-d tail")
        options = [
            (full_margin(stages, c, d, line, source, w, nu), d)
            for d in range(0, WIDTH + 1, 2)
        ]
        best[c] = max(options, key=lambda item: item[0][1])
    first = next((c for c, (bound, _) in best.items() if bound[1] >= 0), None)
    result = {
        "pair_and_even_weight_numerators": raw_weights,
        "profiles_checked": profiles,
        "strictly_positive_local_gap": CORE.format_bounds(minimum),
        "cases_checked_before_monotone_tail": len(best) * (WIDTH // 2 + 1),
        "first_c_not_excluded_by_this_bound": first,
        "monotone_defect_tail_begins_at": WIDTH,
    }
    for c in (0, 401, search_limit - 1, search_limit):
        bound, d = best[c]
        result[f"c={c}"] = {"full_upper": CORE.format_bounds(bound), "maximizing_d": d}
    return result, first


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack", type=Path)
    cli.add_argument("--expect", type=Path)
    args = cli.parse_args()
    paid, helpers = SEAM.CLOCK.JOINT.read_complex(args.complex_pack)
    point = (5, 1000)
    pure = {}
    for stages, weights in PURE.items():
        pure[stages], bound = pure_result(stages, point, weights, paid, helpers)
        if stages < 57:
            need(bound[1] < 0, f"Unrejected pure case L={stages}")
        else:
            need(bound[0] > 0, "Relaxed 57-clock control did not open")
    mixed = {}
    for stages, (w, nu, cut) in MIXED.items():
        mixed[stages], first = mixed_result(stages, point, (w, nu), cut, paid, helpers)
        need(first == cut, f"Unexpected compound-idle envelope at L={stages}")
    long_point = (227, 10000)
    long = {}
    for stages in (17, 19, 21, 55, 57):
        long[stages], bound = pure_result(stages, long_point, PURE[stages], paid, helpers)
        need(bound[1] < 0, f"Long-target saving control failed at L={stages}")
    summary = {
        "status": "PASS_ALL_CLOCK_PAIR_PRICE",
        "weight_denominator": DENOMINATOR,
        "pure_at_.005": pure,
        "mixed_at_.005": mixed,
        "selected_pure_at_.0227": long,
    }
    payload = json.dumps(summary, indent=2, sort_keys=True)
    if args.expect:
        need(payload == args.expect.read_text(encoding="utf-8").rstrip("\n"), "Receipt differs")
    print(payload)


if __name__ == "__main__":
    main()
