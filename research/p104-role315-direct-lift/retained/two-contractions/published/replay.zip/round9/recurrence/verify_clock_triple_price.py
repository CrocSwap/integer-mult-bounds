"""Certify the 57-clock price after enforcing the ordered triple constraint."""

import argparse
from itertools import combinations
from importlib.util import module_from_spec, spec_from_file_location
import json
from math import comb
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("pairs", HERE / "verify_clock_pair_price.py")
PAIR = module_from_spec(SPEC)
SPEC.loader.exec_module(PAIR)
SEAM = PAIR.SEAM
CORE = PAIR.CORE
need = CORE.need


def certify_triple_count():
    checked = 0
    for length in range(5, 12):
        triples = tuple(combinations(range(length), 3))
        for mask in range(1 << length):
            chosen = {j for j in range(length) if mask & (1 << j)}
            k = len(chosen)
            number = sum(i in chosen and (j in chosen or b in chosen) for j, i, b in triples)
            pair_sum = sum(length - 1 - (b - j) for j, b in combinations(sorted(chosen), 2))
            maximum = k * (k - 1) * (3 * length - 2 * k - 2) // 6
            need(number == pair_sum - comb(k, 3) <= maximum, "Triple counting control failed")
            if k > 0 and max(chosen) - min(chosen) == k - 1:
                need(number == maximum, "Contiguous equality control failed")
            checked += 1
    return checked


def price_at_57(paid, helpers):
    length, point, r = 57, (5, 1000), PAIR.WIDTH
    pair = PAIR.exact_weight(80)
    even = PAIR.exact_weight(30)
    triple = CORE.scaled((CORE.SCALE, CORE.SCALE), 72, 10**7)
    h = [CORE.price(j, *point) for j in range(8 * length + 2)]
    intercept = SEAM.subtract(CORE.scaled(h[17], 3), CORE.scaled(h[25], 2))
    slope = SEAM.subtract(h[25], h[17])
    even_clocks = (length - 3) // 2
    profiles = 0
    minimum = None
    for k in range(length + 1):
        fees = []
        for a in range(1, min(k, length - 3) + 1):
            fee = CORE.add(CORE.scaled(h[8 * a], 1, a), CORE.scaled(pair, a - 1))
            fees.append(CORE.add(fee, CORE.scaled(triple, (a - 1) * (a - 2), 6)))
        for x in range(k + 1):
            y = k - x
            pair_count = k * (k - 1) - 2 * x
            triple_count_times_three = k * (k - 1) * (3 * length - 2 * k - 2) // 2
            triple_count_times_three -= (3 * length - 8) * x
            if y == 0 and x in (2, 3):
                need(pair_count <= 0 and triple_count_times_three <= 0, "Affine equality failed")
                continue
            with_no_paid_fees = SEAM.subtract(CORE.add(intercept, CORE.scaled(slope, x)), h[8 * k + 1])
            with_no_paid_fees = SEAM.subtract(with_no_paid_fees, CORE.scaled(pair, pair_count))
            with_no_paid_fees = SEAM.subtract(
                with_no_paid_fees, CORE.scaled(triple, triple_count_times_three, 3)
            )
            with_no_paid_fees = SEAM.subtract(with_no_paid_fees, CORE.scaled(even, min(y, even_clocks)))
            for fee in fees if y else ((0, 0),):
                slack = CORE.add(with_no_paid_fees, CORE.scaled(fee, y))
                need(slack[0] > 0, f"Unverified triple tariff at x={x}, y={y}")
                profiles += 1
                minimum = slack if minimum is None else min(minimum, slack)
    native_marks = 2 * r * length
    pair_floor = r * length * (length - 5)
    triple_floor_times_three = 6 * r * comb(length, 3) - (3 * length - 8) * native_marks
    even_floor = r * (length - 3)
    source = SEAM.source_cost(length, point, paid, helpers)
    upper = CORE.add(source, CORE.scaled(intercept, r * (length - 1)))
    upper = CORE.add(upper, CORE.scaled(slope, native_marks))
    upper = SEAM.subtract(upper, CORE.scaled(pair, pair_floor))
    upper = SEAM.subtract(upper, CORE.scaled(triple, triple_floor_times_three, 3))
    upper = SEAM.subtract(upper, CORE.scaled(even, even_floor))
    need(upper[1] < 0, "The 57-clock upper bound did not reject")
    return {
        "length": length,
        "saving": ".005",
        "pair_weight": ".0008",
        "triple_weight": ".0000072",
        "even_weight": ".00030",
        "local_tariff_profiles": profiles,
        "strict_local_gap": CORE.format_bounds(minimum),
        "pair_floor": pair_floor,
        "triple_floor_times_three": triple_floor_times_three,
        "even_floor": even_floor,
        "full_upper": CORE.format_bounds(upper),
    }


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack", type=Path)
    cli.add_argument("--expect", type=Path)
    args = cli.parse_args()
    checked = certify_triple_count()
    paid, helpers = SEAM.CLOCK.JOINT.read_complex(args.complex_pack)
    result = {
        "status": "PASS_ORDERED_CLOCK_TRIPLE_PRICE",
        "cyclic_label_subset_counting_controls": checked,
        "profile": price_at_57(paid, helpers),
    }
    payload = json.dumps(result, indent=2, sort_keys=True)
    if args.expect:
        need(payload == args.expect.read_text(encoding="utf-8").rstrip("\n"), "The receipt changed")
    print(payload)


if __name__ == "__main__":
    main()
