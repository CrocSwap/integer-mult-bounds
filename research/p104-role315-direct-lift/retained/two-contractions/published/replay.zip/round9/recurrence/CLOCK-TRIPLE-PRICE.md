# Ordered triples of signed Type A clocks

The pairwise overlap constraint and the even-clock tariff leave a positive relaxed cap at \(L=57\). The ordered-triple response adds a further independent geometric constraint. Pricing all three together gives the complete margin upper endpoint **−3.1046257531121** at \(\kappa=.005\). This extends the consecutive rejection for the zero-extra exact-defect model to odd depths 5 through 57. The host inventory, helpers, and Type B allowance are the same as in [the pair-price proof](CLOCK-PAIR-PRICE.md).

## Earlier and later clocks require two separate response directions

Use the normalized signed clock \(V_aU_b=2\operatorname{sgn}(b-a)I_r\), the prefix \(R_i\) before \(i\), and \(A_i=R_i^{-1}U_i\). Here \(i\) is a strict interior clock. The proof of [the two-sector span penalty](../../round8/recurrence/EVEN-CLOCK-BALANCE.md) gives

\[
A_i=U_i+\sum_{a<i}U_a t_a,\qquad
t_a=-2(-1)^{i-1-a}I_r.
\]

Set \(t=\sum_{a<i}t_a\), a scalar times \(I_r\). For \(j<i\), the signed response \(V_j A_i/2\) is \(I_r+t-t_j-2\sum_{a<j}t_a=t-I_r\), using \(t_j+2\sum_{a<j}t_a=2I_r\). For \(k>i\), \(V_k A_i/(-2)=I_r+t\). Thus the normalized block responses of \([V_j;V_k]\) on \([U_i,A_i]\) are

\[
\begin{pmatrix}I_r&t-I_r\\I_r&t+I_r\end{pmatrix}.
\]

This map has rank \(2r\). The two columns blocks are supported on \(S_i\), and the responding rows are supported on \(S_j\cup S_k\). Projecting the columns onto the intersection preserves their responses. Every nominal idle column for a group containing all three labels is also in that intersection. These columns are independent by single-label determinant saturation, and are killed by both \(V_j\) and \(V_k\). If \(m_{jik}\) is their number, then

\[
|S_i\cap(S_j\cup S_k)|\ge 2r+m_{jik}.
\]

Only masks carrying all three labels are counted in \(m_{jik}\).

## Counting the obligations on output roles

For a role carrying \(k\) of the \(L\) labels, each pair of included labels \(a<b\) lies in \(L-1-(b-a)\) chronological triples in which they occupy adjacent positions, either the first two or last two. A triple whose three labels all lie on that role was counted twice. Therefore the left side summed over all chronological triples contributes, on this role, exactly

\[
\sum_{\substack{a<b\\a,b\text{ on role}}}\big(L-1-(b-a)\big)-\binom{k}{3}.
\]

The sum of pair distances is minimized by a contiguous run of \(k\) labels, because the distance between the \(u\)-th and \(v\)-th included labels is at least \(v-u\). The resulting maximum number of triples on the role is

\[
T(k)=\frac{k(k-1)(3L-2k-2)}{6}.
\]

An idle of mask size \(a\) appears in \(\binom a3\) of the required triple intersections. As in the pair certificate, transfer this term to its matching with the per-mark amount \(\binom{a}{3}/a=(a-1)(a-2)/6\). Subtract \((L-8/3)x_v\) from each role's contribution, where \(x_v\) is its native marks. At zero-idle affine equality \(x_v=k_v\in\{2,3\}\), this adjusted contribution is nonpositive. Over all roles the resulting triple expression is at least

\[
D=2r\binom L3-(L-8/3)2rL.
\]

For the complete price, use the pair and even-clock weights \(w,\nu\) from the same local inequality as before. Add weight \(\tau\) to the triple obligation by increasing each fee candidate in that local inequality by \(\tau(a-1)(a-2)/6\), and subtracting \(\tau[T(k)-(L-8/3)x]\) on its left. A single bound then gives the combined debit \(wB+\nu M+\tau D\). This avoids using the same local deficit multiple times.

At \(L=57\), use \(w=.0008,\tau=.0000072,\nu=.00030\). The proof checks 63,083 directed local tariff profiles and uses the full source invoice including the optimistic Type B allowance. The resulting upper margin lies in \([-3.1046257531122,-3.1046257531121]\). The certificate covers the common-center, sign-normalized, zero-extra exact-defect word with independent positive body labels, as in the pair proof.

## Replay

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round9\recurrence\verify_clock_triple_price.py $complexPack --expect .\work\round9\recurrence\clock-triple-price.json
~~~

The checker imports the previous pair-price verifier and its pinned source and interval closure. It includes 4,064 small exhaustive label-subset controls for the chronological triple count and the contiguous equality. Normal and optimized receipts matched SHA-256 508c3111124aa40e54bae99578b596b1351286693fe9ad2ba0a77e8818a2d3f2. Each run finished in about half a second inside a 30-second budget. AST parsing and tabnanny passed.
