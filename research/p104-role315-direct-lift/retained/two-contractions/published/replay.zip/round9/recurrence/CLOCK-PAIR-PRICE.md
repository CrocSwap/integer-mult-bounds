# Pairwise body support and the full caller price

Every two full Type A clocks occupy common target coordinates beyond the coordinates needed to accommodate their shared body idles. Charging that overlap closes the 21-host opening at \(\kappa=.005\). With zero additional odd events and exact defect, the same calculation rejects every odd depth from 5 to 55. The source inventory comes from the open #7546 candidate, with all its native moves paid, its independent helpers credited, and Type B granted its full optimistic allowance. [Open #7546 candidate](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

## The pairwise coordinate constraint

Use the common-center signed Type A model in [the two-sector span proof](../../round8/recurrence/EVEN-CLOCK-BALANCE.md) and [the odd-idle extension](../../round8/SIGNED-IDLE-DEFECT.md). There are \(L\) full clocks, \(r\) disjoint rank-one odd shears per clock, and \(c\) additional one-role compound odd idles. Every clock has its own positive independent body with eight axes. Every completed root is an arbitrary independent input returned with one odd center and a set of distinct body labels. Ordinary scalar maps are square, invertible, body-independent and equal in the two signed sectors. Type A and B use separate scalar root spaces.

Write \(F_i\) for the coordinate projector onto the endpoint support \(S_i\) of label \(i\). In the nominal sector \(q=+i\), set all other labels to one. After removing the body-one endpoint, the coefficient of \(D_i-1\) is a sum of the transported constituent projectors. Their total rank equals \(\operatorname{rank}F_i\) by comparing positive determinant degrees. For any full-column and full-row factorizations of the constituents, concatenate their columns in \(U_*\) and their rows in \(V_*\). Then \(F_i=U_*V_*\), both factors have full rank, and \(F_i^2=F_i\) gives \(V_*U_*=I\). Thus distinct constituents for label \(i\) annihilate each other on both sides. These statements also hold when an odd idle carries a positive body mask, by incorporating its fixed nominal scalar phase in the body-one transport. Every constituent's columns and rows lie on \(S_i\).

Let \(U_i,V_i\) denote the relative shear columns and rows for full clock \(i\). Its own nominal rank-\(2r\) body projector fixes \(U_i\) on the left and \(V_i\) on the right. If an idle carries both \(i\) and \(j\), its nominal column \(w_g\) lies in \(S_i\cap S_j\) and \(V_iw_g=0\). All such \(w_g\) are independent by the preceding single-label identity. Meanwhile \(F_i U_j\) is supported on \(S_i\cap S_j\), and \(V_i F_i U_j=V_iU_j\). It follows that

\[
|S_i\cap S_j|\ge m_{ij}+\operatorname{rank}(V_iU_j),
\]

where \(m_{ij}\) is the number of paid idle groups carrying both labels. In the exact-defect normalized clock the cross pairing has rank \(r\) for \(i\ne j\). With additional defect \(d\), the sequential complement factors through dimension \(r+d\) as \(K=XY\). Its full diagonal blocks satisfy \(X_iY_i=I_r\). For distinct full clocks \(V_iU_j=\pm2X_iY_j\), so the cross rank is at least \(\max(r-d,0)\) by Sylvester's inequality. This conclusion allows compound odd idles before, after or between the full clocks. In this case the number of odd roots is \(n=r(L-1)+c-d\), and determinant parity requires even \(d\) for odd \(L\).

## One tariff for all overlap and even-clock incidences

For each label, match the determinant-saturated nominal columns bijectively to the coordinates of that label. A determinant summand gives such a matching and sends each idle column to a coordinate carrying its whole mask. An idle can be assigned to different coordinates for different labels. Write \(x_v,y_v\) for the native and idle marks assigned to coordinate \(v\), \(k_v=x_v+y_v\), and \(a_g\) for the number of labels in a paid idle group \(g\). Every assigned mark from group \(g\) satisfies \(a_g\le k_v\). Summing the pair bound over directed pairs of distinct full clocks gives

\[
\sum_v k_v(k_v-1)-\sum_g a_g(a_g-1)
 \ge \max(r-d,0)L(L-1).
\]

Every paid group appears exactly \(a_g\) times among the matched idle marks. Also \(\sum_v x_v=2rL\). Hence the adjusted expression

\[
A_v=k_v(k_v-1)-2x_v-\sum_{g\text{ assigned to }v}(a_g-1)
\]

satisfies \(\sum_v A_v\ge B=\max(r-d,0)L(L-1)-4rL\). Subtracting \(2x_v\) leaves a nonpositive adjusted term at the zero-idle affine equality cases \(x_v=2,3\). A coordinate can cover at most \(p=(L-3)/2\) even interior clocks, so its even idle marks are at most \(\min(p,y_v)\). Write \(M\) for any proven lower bound on the total of those marks. In the zero-extra exact-defect case \(M=r(L-3)\), and each mask has size at most \(L-3\) by the cyclic omission law. In the widened model grant up to \(L\) labels per mask and use the lower bound from [the mixed-defect price](COMBINED-PRICE.md).

Set \(H_t=t^{1-\kappa}\) and \(\ell(x)=\ell_0+x\ell_1=H_{17}+(x-2)(H_{25}-H_{17})\). For fixed rational weights \(w,\nu\ge0\) the checker verifies every integer profile \(0\le x\le k\le L\), including the allowable group sizes \(1\le a\le \min(k,\text{mask cap})\), for the inequality

\[
\ell(x)-H_{8k+1}
+(k-x)\min_a\left(\frac{H_{8a}}{a}+w(a-1)\right)
-w\big(k(k-1)-2x\big)
\ge \nu\min(p,k-x).
\]

The minimum term is zero when there are no idles. Substituting each assigned group's fee can only increase the left side. Hence the target deficit below \(\sum_v\ell(x_v)\), after subtracting each body idle's full cost from its credit, is at least \(wB+\nu M\). Both charges come from the same local inequality. Every paid odd idle still owes at least \(H_{8L+1}-H_{8L}\) for its header, by decreasing increments of \(H\). The complete upper margin is

\[
L(T_0-P_0)+8L(H_8+H_9+1)
+n\ell_0+2rL\ell_1
-c(H_{8L+1}-H_{8L})-wB-\nu M.
\]

Here \(P_0\) is the entire #7546 paid rank inventory and \(T_0\) is the entire independent helper credit per native host. The allowance \(8L(H_8+H_9+1)\) grants the eight Type B ports their full joint-cut remainder. Scalar routing and precision can introduce further costs.

## Exact comparisons

The zero-extra exact-defect calculations use \(r=192\). At \(.005\), \(L=21\) with \(w=.00244,\nu=.00863\) gives upper endpoint **−123.9248699182489**. At \(L=55\) it gives **−6.4606759400641** using \(w=.00096,\nu=.00014\). The first sampled depth after this rejected interval, \(L=57\), has a relaxed upper endpoint \(+2.1844366468879\). At \(.0227\), the exact-defect \(L=21\) upper endpoint is −6154.1587162075650.

For the widened model the checker sweeps every even \(d\le192\). For \(d\ge192\) both price debits become constant at fixed \(c\), while the \(-d\ell_0\) term strictly decreases. All reported rejections are therefore for every admissible \(d\).

| \(L\) | \(w,\nu\) | Last rejected \(c\) | Maximizing \(d\) at that \(c\) | Upper endpoint |
| ---: | --- | ---: | ---: | ---: |
| 17 | .00289, .00554 | 921 | 0 | −.1076855722413 |
| 19 | .00276, .00407 | 935 | 0 | −.0325334925486 |
| 21 | .00264, .00272 | 915 | 192 | −.0036659511288 |

The following \(c\) in each row remains open under these fixed weights. Neither a positive relaxed cap nor the required number of compound idles supplies a feasible word. The result uses independent positive body labels, separated Type A and B, and the declared common-header operator model. Thin shears, reused or signed body labels, other natives and other output shapes need separate arguments.

## Replay

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round9\recurrence\verify_clock_pair_price.py $complexPack --expect .\work\round9\recurrence\clock-pair-price.json
~~~

The verifier imports the combined, seam and earlier pinned source and interval verification code. It reads the fixed three-file complex pack, checks positive local slack by directed integer arithmetic, sums the complete source invoice and checks all 269,369 mixed defect points before the monotone tail. The normal and optimized replays took roughly two seconds each with 30-second process limits. Their receipts were identical, with SHA-256 a3f01b2aee095111d68572f5df2b46fb23cffeef02829dfda82522957a5f0b87. AST parsing and tabnanny passed. The workstation reported 34.12% RAM and 777 of 16,303 MiB VRAM during the bounded CPU run.
