# SPDX-License-Identifier: Apache-2.0
"""Certify a long saturated depth range with the no-auxiliary Type B price."""

import argparse
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("pairs", HERE / "recurrence/verify_clock_pair_price.py")
PAIR = module_from_spec(SPEC)
SPEC.loader.exec_module(PAIR)
CORE, NEED, SEAM = PAIR.CORE, PAIR.need, PAIR.SEAM
WIDTH = PAIR.WIDTH
CUTOFF = 10**39-1
POINT = (5, 1000)
PIVOT = Fraction(25,1000)


def sub(a,b):
    return SEAM.subtract(a,b)


def price(rank):
    return CORE.price(rank,*POINT)


def analytical_cap(L,ell0,source_slope):
    w=CORE.scaled((CORE.SCALE,CORE.SCALE),PIVOT.numerator,PIVOT.denominator*L)
    return sub(CORE.add(CORE.scaled(source_slope,L),CORE.scaled(ell0,-WIDTH)),
               CORE.scaled(w,WIDTH*L*(L-5)))


def calibrate_local(ell0,ell1):
    # k is integral. z(k)=ell(k)−H_(8k+1) has roots 2,3 and z'' is
    # completely monotone on k≥0. For k≥4, z(k)/(k(k−3)) is bounded
    # checked explicitly below 21. At larger k, use a secant bound.
    weight=CORE.scaled((CORE.SCALE,CORE.SCALE),PIVOT.numerator,PIVOT.denominator)
    D = CORE.scaled(price(8),*POINT)
    derivative_at_cut = CORE.scaled(price(8*CUTOFF),POINT[0],POINT[1]*CUTOFF)
    NEED(derivative_at_cut[0]>weight[1],"all paid masks are worst at full size through cutoff")
    NEED(sub(ell0,sub(price(9),price(8)))[0]>0,"all-idle even tariff gap")
    # With all-idle profiles certified, the only other endpoint is x=k.
    # For k≥21, extrapolating the real chord from 3 through 21 stays below z(k).
    # For k≤L, w k(k−3) ≤ .025 (k−3).
    secant=CORE.scaled(sub(CORE.add(ell0,CORE.scaled(ell1,21)),price(169)),1,18)
    NEED(secant[0]>weight[1],"large k no-idle secant")
    small=0
    for k in range(4,21):
        slack=sub(sub(CORE.add(ell0,CORE.scaled(ell1,k)),price(8*k+1)),CORE.scaled(weight,k*(k-3),35))
        NEED(slack[0]>0,"every small k no-idle row")
        small+=1
    return {"finite_small_k_rows":small,"pair_weight_times_depth":CORE.format_bounds(weight),
            "derivative_times_depth_at_cut":CORE.format_bounds(derivative_at_cut),
            "small_to_large_chord":CORE.format_bounds(secant),
            "base_derivative_coefficient":CORE.format_bounds(D)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    args=parser.parse_args()
    paid,helpers=SEAM.CLOCK.JOINT.read_complex(args.complex_pack)
    O=CORE.add(CORE.add(price(8),price(9)),price(1))
    change=CORE.scaled(sub(price(17),O),8)
    source=CORE.add(SEAM.source_cost(1,POINT,paid,helpers),change)
    ell0=sub(CORE.scaled(price(17),3),CORE.scaled(price(25),2))
    ell1=sub(price(25),price(17))
    slope=CORE.add(source,CORE.scaled(CORE.add(ell0,CORE.scaled(ell1,2)),WIDTH))
    calibrate=calibrate_local(ell0,ell1)
    coefficient=CORE.scaled((CORE.SCALE,CORE.SCALE),WIDTH*PIVOT.numerator,PIVOT.denominator)
    NEED(sub(slope,coefficient)[1]<0,"the verified tail is decreasing")
    cap=analytical_cap(35,ell0,slope)
    NEED(cap[1]<0,"analytical price begins with negative slack")
    receipt={"status":"PASS_LONG_CLOCK_CERTIFICATE","saving":".005",
             "complementary_scope":"zero compound odd idles, exact defect, separated no-external-recursion Type B",
             "verified_odd_depths":[35,CUTOFF],
             "strict_cap_at_first":CORE.format_bounds(cap),"local_certificate":calibrate,
             "near_frontier":{str(L):CORE.format_bounds(analytical_cap(L,ell0,slope)) for L in (35,57,59,81,129,511,1023,8193)},
             "negative_slope_per_clock":CORE.format_bounds(sub(slope,coefficient))}
    print(json.dumps(receipt,indent=2,sort_keys=True))


if __name__=="__main__":
    main()
