# SPDX-License-Identifier: Apache-2.0
"""Use exact tariff certificates after a common integer CPU/D3D11 dual search."""

import argparse
from array import array
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import islice, product
import json
from math import comb
from pathlib import Path
import sys
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("tail", HERE / "long_clock_tail.py")
TAIL = module_from_spec(SPEC)
SPEC.loader.exec_module(TAIL)
CORE, NEED, PAIR = TAIL.CORE, TAIL.NEED, TAIL.PAIR
LENGTHS = (17,19,21,27,35,43,51,55,57,59,61,63,67,71,81,91,101,113,127)
P_COUNT, T_COUNT = 128, 64
SCALE = 1_000_000
WIDTH = PAIR.WIDTH
HEADER = 5
NEGATIVE = -(1 << 30)


HLSL=r"""
StructuredBuffer<uint> data : register(t0);
StructuredBuffer<uint> jobs : register(t1);
RWStructuredBuffer<uint> score : register(u0);
RWStructuredBuffer<uint> evenWeight : register(u1);
[numthreads(64,1,1)]
void main(uint z : SV_DispatchThreadID) {
    uint base=jobs[z*2];
    uint id=jobs[z*2+1];
    if (base==0) { score[z]=0; evenWeight[z]=0; return; }
    int L=int(data[base]);
    int h=(L-3)/2, stride=L+1;
    int a=asint(data[base+1]), b=asint(data[base+2]);
    int wp=int(id & 255u), wt=int(id>>8);
    uint target=base+5u, fee=target+stride;
    uint pairBlock=fee+stride+wp*(2+2*stride);
    uint trBlock=fee+stride+128*(2+2*stride)+wt*(2+2*stride);
    int best=1<<30, even=1000000;
    int trend=b+asint(data[pairBlock+1])+asint(data[trBlock+1]);
    for(int k=1;k<=L;k++) {
        if (k<=L-3) {
            int next=asint(data[fee+k])+asint(data[pairBlock+2+k])+asint(data[trBlock+2+k]);
            best=min(best,next);
        }
        int d=a-asint(data[target+k])-asint(data[pairBlock+2+stride+k])-asint(data[trBlock+2+stride+k]);
        // The affine line goes through the zero-idle profiles at widths 2 and 3.
        if (k!=2&&k!=3&&d+trend*k<0) { score[z]=asuint(-(1<<30)); evenWeight[z]=0; return; }
        int middle=min(k,h);
        int first=d+trend*(k-1)+best;
        int part=d+trend*(k-middle)+best*middle;
        int whole=d+best*k;
        if(min(first,min(part,whole))<0){ score[z]=asuint(-(1<<30)); evenWeight[z]=0; return; }
        even=min(even,min(first,min(part/middle,whole/middle)));
    }
    int credit=asint(data[pairBlock])+asint(data[trBlock])+even*(L-3);
    score[z]=asuint(credit);
    evenWeight[z]=asuint(even);
}
"""


def coefficients(L, p, t):
    return (500+60*p,100_000*L),(18*t,10_000*L*L)


def encode_signed(x):
    NEED(-(1<<31)<=x<1<<31,"D3D signed input")
    return x & 0xffffffff


def line_and_rank(L):
    H=[TAIL.price(j) for j in range(8*L+2)]
    return TAIL.sub(CORE.scaled(H[17],3),CORE.scaled(H[25],2)),TAIL.sub(H[25],H[17]),H


def floors(L):
    return L*(L-5), (6*comb(L,3)-2*(3*L-8)*L)


def tables(L):
    ell0,ell1,H=line_and_rank(L)
    def approx(v):
        return (v[0]*SCALE+CORE.SCALE//2)//CORE.SCALE
    def evaluate(weights,apply):
        n,q=weights
        return (SCALE*n*apply[0] + q*apply[1]//2)//(q*apply[1])
    def weighted(p, triple):
        wp,wt=coefficients(L,0,p) if triple else coefficients(L,p,0)
        w=wt if triple else wp
        Q,T=floors(L)
        if triple:
            endpoints=[evaluate(w,v) for v in ((T,3),(3*L-8,3))]
            by_a=[evaluate(w,((a-1)*(a-2),6)) for a in range(L+1)]
            by_k=[evaluate(w,(k*(k-1)*(3*L-2*k-2),6)) for k in range(L+1)]
        else:
            endpoints=[evaluate(w,v) for v in ((Q,1),(2,1))]
            by_a=[evaluate(w,(a-1,1)) for a in range(L+1)]
            by_k=[evaluate(w,(k*(k-1),1)) for k in range(L+1)]
        return (*endpoints,*by_a,*by_k)
    targets=tuple(approx(H[8*k+1]) for k in range(L+1))
    fees=(0,*(approx(CORE.scaled(H[8*a],1,a)) for a in range(1,L+1)))
    w=tuple(weighted(i,False) for i in range(P_COUNT))
    t=tuple(weighted(i,True) for i in range(T_COUNT))
    return (L,approx(ell0),approx(ell1),0,0,*targets,*fees,*[x for a in (*w,*t) for x in a]),(L,approx(ell0),approx(ell1),targets,fees,w,t)


def cpu_one(table,code):
    L,a,b,H,fee,w,t=table
    wp,wt=w[code&255],t[code>>8]
    stride=L+1
    h=(L-3)//2
    best=1<<30
    even=SCALE
    trend=b+wp[1]+wt[1]
    for k in range(1,L+1):
        if k<=L-3:
            best=min(best,fee[k]+wp[2+k]+wt[2+k])
        d=a-H[k]-wp[stride+2+k]-wt[stride+2+k]
        if k not in (2,3) and d+trend*k<0:
            return NEGATIVE,0
        middle=min(k,h)
        first,part,whole=d+trend*(k-1)+best,d+trend*(k-middle)+best*middle,d+best*k
        if min(first,part,whole)<0:
            return NEGATIVE,0
        even=min(even,first,part//middle,whole//middle)
    return wp[0]+wt[0]+even*(L-3),even


def exact_profile(L,code,paid,helpers):
    wp,wt=coefficients(L,code&255,code>>8)
    one=(CORE.SCALE,CORE.SCALE)
    w,t=CORE.scaled(one,*wp),CORE.scaled(one,*wt)
    ell0,ell1,H=line_and_rank(L)
    trend=CORE.add(CORE.add(ell1,CORE.scaled(w,2)),CORE.scaled(t,3*L-8,3))
    best,nu=None,CORE.SCALE
    for k in range(1,L+1):
        if k<=L-3:
            f=CORE.add(CORE.scaled(H[8*k],1,k),CORE.scaled(w,k-1))
            f=CORE.add(f,CORE.scaled(t,(k-1)*(k-2),6))
            best=f[0] if best is None else min(best,f[0])
        d=TAIL.sub(ell0,H[8*k+1])
        d=TAIL.sub(d,CORE.scaled(w,k*(k-1)))
        d=TAIL.sub(d,CORE.scaled(t,k*(k-1)*(3*L-2*k-2),6))
        if k not in (2,3) and CORE.add(d,CORE.scaled(trend,k))[0]<0:
            return None
        middle=min(k,(L-3)//2)
        for y in (1,middle,k):
            z=CORE.add(CORE.add(d,CORE.scaled(trend,k-y)),CORE.scaled((best,best),y))
            nu=min(nu,CORE.scaled(z,1,min(y,middle))[0])
    if nu<0:
        return None
    q,T=floors(L)
    debit=CORE.add(CORE.scaled(w,WIDTH*q),CORE.scaled(t,WIDTH*T,3))
    debit=CORE.add(debit,CORE.scaled((nu,nu),WIDTH*(L-3)))
    price=PAIR.SEAM.source_cost(L,TAIL.POINT,paid,helpers)
    base=CORE.add(CORE.add(price,CORE.scaled(ell0,WIDTH*(L-1))),CORE.scaled(ell1,2*WIDTH*L))
    return {"cap":CORE.format_bounds(TAIL.sub(base,debit)),"w":wp,"triple_weight":wt,
            "even_weight_lower":CORE.format_bounds((nu,nu))[0],"strictly_negative":base[1]<debit[0]},debit[0]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    parser.add_argument("backend",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--cpu-only",action="store_true")
    args=parser.parse_args()
    limit=monotonic()+52
    gpu=None
    resources=None
    if sys.platform=="win32":
        sys.path.insert(0,str(HERE.parent))
        from benchmark_helper_cohorts import BACKEND_SHA, Limit, gpu_batch
        resources=Limit()
        resources.poll("before clock grid")
    if not args.cpu_only:
        NEED(resources is not None,"D3D11 requires Windows")
        resources.sample("before GPU clock grid")
    cpu_tables,table_map={},{}
    packed=array("I",[0])
    for L in LENGTHS:
        block,table=tables(L)
        at=len(packed)
        packed.extend(encode_signed(x) for x in block)
        cpu_tables[at]=table
        table_map[at]=L
    jobs=((pos,i | (j<<8)) for pos in cpu_tables for j,i in product(range(T_COUNT),range(P_COUNT)))
    CPU=GPU=setup=0.
    specs={}
    ranked={L:[] for L in LENGTHS}
    checksum=sha256()
    count=0
    try:
        if not args.cpu_only:
            NEED(sha256(args.backend.read_bytes()).hexdigest()==BACKEND_SHA,"pinned D3D backend")
            spec=spec_from_file_location("gpu",args.backend)
            backend=module_from_spec(spec)
            spec.loader.exec_module(backend)
            backend.HLSL=HLSL
            gpu=backend.D3D11()
            start=perf_counter()
            gpu.open()
            gpu.compile()
            setup=(perf_counter()-start)*1000
            resources.sample("after clock shader compile")
        batch=list(islice(jobs,256))
        while batch:
            NEED(monotonic()<limit,"finite clock search deadline")
            if resources is not None:
                resources.poll("CPU/GPU clock batch")
            results=array("I")
            even=array("I")
            start=perf_counter()
            for pos,code in batch:
                score,nu=cpu_one(cpu_tables[pos],code)
                results.append(encode_signed(score))
                even.append(nu)
            c_ms=(perf_counter()-start)*1000
            g_ms=0.0
            if gpu is not None:
                got,g_ms=gpu_batch(backend,gpu,packed,batch,resources)
                if got!=(results,even):
                    off=next(i for i,row in enumerate(zip(*got,results,even,strict=True))
                             if row[:2]!=row[2:])
                    raise ValueError(("first CPU/GPU arithmetic discrepancy",batch[off],
                                      (got[0][off],got[1][off]),(results[off],even[off])))
            if not specs:
                specs={"cases":len(batch),"cpu_ms":c_ms,"gpu_ms":g_ms}
            CPU+=c_ms
            GPU+=g_ms
            count+=len(batch)
            checksum.update(results.tobytes())
            checksum.update(even.tobytes())
            for (pos,c),score in zip(batch,results,strict=True):
                if score < (1<<31):
                    ranked[table_map[pos]].append((score,c))
            batch=list(islice(jobs,32768))
    finally:
        if gpu is not None:
            gpu.close()
            resources.sample("after clock device release")
    NEED(count==len(LENGTHS)*P_COUNT*T_COUNT,"complete dual search")
    paid,helpers=PAIR.SEAM.CLOCK.JOINT.read_complex(args.complex_pack)
    out={}
    checked=0
    begin=perf_counter()
    for L,guesses in ranked.items():
        best=None
        for guess in sorted(guesses,reverse=True)[:16]:
            x=exact_profile(L,guess[1],paid,helpers)
            checked+=1
            if x and (best is None or x[1]>best[1]):
                best=x
        NEED(best is not None,"exact CPU validates at least one screened local certificate")
        out[L]=best[0]
    data={"status":"PASS_CLOCK_DUAL_SCREEN","cases":count,"integer_sha256":checksum.hexdigest(),
          "cpu_ms":CPU,"gpu_ms":GPU,"gpu_setup_ms":setup,"small":specs,
          "directed_candidates":checked,"directed_ms":(perf_counter()-begin)*1000,
          "resources":resources.samples if resources else [],
          "strongest_directed_margin_among_retained_grid_candidates":out}
    args.output.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(data["status"],count,data["integer_sha256"],f"CPU {CPU:.2f} ms, GPU {GPU:.2f} ms, setup {setup:.2f} ms")


if __name__=="__main__":
    main()
