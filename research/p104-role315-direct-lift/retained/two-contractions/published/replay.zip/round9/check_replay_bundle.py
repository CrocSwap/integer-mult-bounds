# SPDX-License-Identifier: Apache-2.0
"""Authenticate and independently replay ninth-round research receipts."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from runpy import run_path
import subprocess
import sys
from time import perf_counter


JOBS=(
    ("prefix_body_word","prefix-body-word","pack"),
    ("recurrence/verify_clock_pair_price","recurrence/clock-pair-price","expect"),
    ("recurrence/verify_clock_triple_price","recurrence/clock-triple-price","expect"),
    ("long_clock_tail","long-clock-tail","pack"),
    ("clock_dual_screen","clock-dual-screen","gpu"),
    ("independent/type_b_clock","independent/type-b-clock","type_b"),
    ("independent/audit_literal_idle","independent/literal-idle-screen","literal"),
    ("algebra/odd_relay_defect","algebra/odd-relay-defect-results","stdout"),
    ("algebra/selected_pair_bypass","algebra/selected-pair-bypass-results","stdout"),
    ("audit_upstream_7601","audit-upstream-7601","7601"),
    ("../round8/clock_capacity","../round8/clock-capacity","pack"),
    ("recurrence/verify_combined_price","recurrence/combined-price","expect"),
)
GPU_KEYS=("status","cases","integer_sha256","directed_candidates","strongest_directed_margin_among_retained_grid_candidates")


def replay(dest,job,want_gpu):
    file,receipt,mode=job
    source=(dest/"round9"/f"{file}.py").resolve()
    expected=(dest/"round9"/f"{receipt}.json").resolve()
    output=dest/"run"/f"{Path(receipt).name}.json"
    caller="inputs/7113-caller.json"
    args={
        "stdout":[],
        "pack":["inputs"],
        "expect":["inputs","--expect",str(expected)],
        "type_b":["inputs/7546-word.json.gz",caller,"inputs/7546-whole.json",str(expected),"--expect"],
        "literal":[caller,str(expected),"--expect"],
        "gpu":["inputs","inputs/benchmark-d3d11-backend.py",str(output)]+([] if want_gpu else ["--cpu-only"]),
        "7601":["inputs","round9/upstream-7601"],
    }
    start=perf_counter()
    run=subprocess.run([sys.executable,"-I","-B","-S","-W","error",str(source),*args[mode]],
                       cwd=dest,capture_output=True,timeout=57)
    if run.returncode or run.stderr:
        raise RuntimeError((file,run.returncode,run.stderr.decode(errors="replace")))
    if mode in ("type_b","literal"):
        if not run.stdout.startswith(b"PASS_"):
            raise ValueError(f"{file} did not confirm its matching receipt")
    else:
        actual=json.loads(output.read_bytes() if output.is_file() else run.stdout)
        baseline=json.loads(expected.read_bytes())
        if mode=="gpu":
            actual,baseline=({key:z[key] for key in GPU_KEYS} for z in (actual,baseline))
        if baseline!=actual:
            raise ValueError(f"{file} differs from the archived exact receipt")
    return file,perf_counter()-start


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("archive",type=Path)
    cli.add_argument("dest",type=Path)
    cli.add_argument("--workers",type=int,default=6)
    cli.add_argument("--gpu",action="store_true")
    args=cli.parse_args()
    dest=args.dest.resolve()
    dest.mkdir()
    helper=Path(__file__).resolve().parents[1]/"round7"/"check_replay_bundle.py"
    hashes=run_path(str(helper))["extract"](args.archive,dest)
    (dest/"run").mkdir()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        jobs=[pool.submit(replay,dest,job,args.gpu) for job in JOBS]
        for fut in jobs:
            file,elapsed=fut.result()
            print(f"PASS {file} {elapsed:.2f}s",flush=True)
    print(f"PASS_ROUND9_REPLAY {len(JOBS)} fresh receipts and {hashes} archived hashes")


if __name__=="__main__":
    main()
