# SPDX-License-Identifier: Apache-2.0
"""Independently bind two open P104 fusions to the pinned source and exact cost."""

import argparse
from collections import Counter
from hashlib import sha256
import gzip
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
BASE = run_path(str(HERE.parent / "round7/independent/direct_complex_native.py"))
ROWS, PHYS, NEED = BASE["ROWS"], BASE["PHYSICAL"], BASE["NEED"]
CORE = run_path(str(HERE.parent / "round9/long_clock_tail.py"))["CORE"]
OLD = "6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32"
NEW = "be97530506ab633c2a76a173a51d13f58b581ee7249338821e6e4994e3104675"
HEAD = "eccf3d1fe814ea86a373d37a783105ceb853c390"


def checked(path, digest=None):
    blob = path.read_bytes()
    if digest:
        NEED(sha256(blob).hexdigest()==digest,f"source pin for {path.name}")
    return json.loads(gzip.decompress(blob) if path.suffix==".gz" else blob)


def apply_edits(word, edits):
    old = word["program"]
    NEED(len(old)==edits["base_events"],"source program event count")
    delete = dict(edits["delete"])
    insert = dict(edits["insert_before"])
    NEED(len(delete)==len(edits["delete"]) and len(insert)==len(edits["insert_before"]),"distinct edit cuts")
    result=[]
    for i,op in enumerate(old):
        result.extend(insert.get(i,()))
        if i in delete:
            NEED(op==delete[i],"deleted event identity")
        else:
            result.append(op)
    result.extend(edits["append"])
    return {**word,"program":result}


def trace(word, deadline):
    n,owned = word["public"],word["owned_fields"]
    live = word["initial"][:]+[None]*owned
    rows = [ROWS["unit"](i) for i in range(n)]+[ROWS["NONE"]]*owned
    slots = []
    histogram = Counter()
    for i,(op,j,*args) in enumerate(word["program"]):
        if i%1024==0:
            NEED(monotonic()<deadline,"bounded rational source replay")
        if op=="INIT":
            NEED(j>=n and live[j] is None and not rows[j][1],"owned birth")
            live[j]=args[0]
            slots.append((op,j,live[j]))
        elif op=="CLEAR":
            NEED(j>=n and live[j]==args[0],"owned retirement")
            slots.append((op,j,live[j],rows[j]))
            live[j],rows[j]=None,ROWS["NONE"]
        elif op=="MOVE":
            a,b,is_owned=args
            NEED(live[j]==a and is_owned==(j>=n),"paid role owner and coframe")
            if is_owned:
                slots.append((op,j,a,b))
            live[j]=b
            histogram[abs(len(word["frames"][a])-len(word["frames"][b]))]+=1
        elif op=="SCALE":
            factor,k=args
            NEED(live[j]==k,"scale in live frame")
            rows[j]=ROWS["scale"](rows[j],ROWS["ratio"](factor))
        else:
            source,factor,k=args
            NEED(source!=j and live[j]==live[source]==k,"ordinary coframe contact")
            if op=="COPY":
                NEED(j>=n and not rows[j][1],"COPY onto live zero owner")
                rows[j]=ROWS["scale"](rows[source],ROWS["ratio"](factor))
            else:
                NEED(op=="ADD","known arithmetic opcode")
                rows[j]=ROWS["increment"](rows[j],rows[source],ROWS["ratio"](factor))
    NEED(rows[:n]==ROWS["target"](word)[1] and not any(z[1] for z in rows[n:]),"original independent target rows")
    NEED(live==word["final"]+[None]*owned,"literal final charts")
    return histogram,slots,n,rows


def physical_pairs(compiler,word,edits):
    new_moves=[ev for _,ins in edits["insert_before"] for ev in ins if ev[0]=="MOVE"]
    old_moves=[ev for _,ev in edits["delete"] if ev[0]=="MOVE"]
    got=[]
    for _,role,a,c,_ in new_moves:
        [old_a,old_b]=[ev for ev in old_moves if ev[1]==role]
        NEED(old_a[2:4]==[a,old_b[2]] and old_b[3]==c,"adjacent chain replacement")
        b=old_b[2]
        A,B,C=(compiler.canonical_frame(9,word["frames"][i]) for i in (a,b,c))
        source=A.adjoint().then(C)
        via=A.adjoint().then(B).then(B.adjoint()).then(C)
        PHYS["equal_signed_clifford"](source,via,True)
        move,restored=compiler.lower_child(source)
        PHYS["equal_signed_clifford"](source,restored,True)
        got.append({"role":role,"direct_physical_child_rank":move["rank"],
                    "old_boundary_ranks":[len(word["frames"][j]) for j in (a,b,c)],
                    "coherent_absolute_phase":True})
        NEED(move["rank"]==3,"each collapsed signed operation has actual rank three")
    return got


def price_audit(old_whole,claimed,delta):
    saved=old_whole["signed_profile"]
    old=Counter({int(r):c for r,c in saved["signed_paid"].items()})
    targets=Counter({int(r):c for r,c in saved["signed_productive"].items()})
    new=old.copy()
    new.update({r:17*c for r,c in delta.items()})
    NEED(new==Counter({int(r):c for r,c in claimed["paid"].items()})
         and targets==Counter({int(r):c for r,c in claimed["targets"].items()}),
         "full rank invoice independently recovered")
    x = targets.copy()
    x.subtract(new)
    signs={}
    for n in (36490213053,36490213054):
        value=CORE.moment(x,n,10**13)
        signs[str(n)]=CORE.format_bounds(value)
    NEED(CORE.moment(x,36490213053,10**13)[0]>0 and CORE.moment(x,36490213054,10**13)[1]<0,
         "advertised raw crossing with complete tariff")
    return {"paid":sum(new.values()),"targets":sum(targets.values()),"moments_at_n_over_1e13":signs}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    parser.add_argument("candidate",type=Path)
    args=parser.parse_args()
    deadline=monotonic()+45
    compiler,word=PHYS["load_pins"](args.complex_pack/"7546-word.json.gz")
    NEED(word==checked(args.complex_pack/"7546-word.json.gz",OLD),"same base input in replay and compiler")
    new=checked(args.candidate/"word.json.gz",NEW)
    edits=checked(args.candidate/"edits.json")
    NEED(new==apply_edits(word,edits),"edited word and published source are identical")
    before, life,n,target = trace(word,deadline)
    after, new_life,n2,target2 = trace(new,deadline)
    NEED(n==n2 and target==target2 and life==new_life,"equal all roles, owners, and erased contents")
    delta=after.copy()
    delta.subtract(before)
    delta={r:c for r,c in delta.items() if c}
    NEED(delta=={1:-2,2:-2,3:2},"two exact rank-three fusions")
    moves=physical_pairs(compiler,word,edits)
    whole=checked(args.complex_pack/"7546-whole.json",BASE["ADJ"]["WHOLE_SHA"])
    inv=price_audit(whole,checked(args.candidate/"invoice-new.json"),delta)
    added=Counter(e[0] for e in new["program"])
    added.subtract(e[0] for e in word["program"])
    print(json.dumps({"status":"PASS_INDEPENDENT_OPEN_7601_BOUNDARY_AND_PRICE","head":HEAD,
                      "all_public_rows":n,"owned_lifetimes":sum(x[0]=="CLEAR" for x in life),
                      "native_opcode_delta":{k:v for k,v in added.items() if v},
                      "native_paid_delta":delta,"physical_pairs":moves,"complete_invoice":inv,
                      "scope":"exact operator, frames, lifetimes and tariff; modified precision, tape and external application are still open"},
                     indent=2,sort_keys=True))


if __name__=="__main__":
    main()
