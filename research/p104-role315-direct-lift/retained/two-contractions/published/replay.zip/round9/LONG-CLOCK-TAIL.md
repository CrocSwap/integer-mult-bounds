# Analytic long-depth exclusion with the exact separated Type B credit

In the saturated common-center Type A model, with no extra odd idles or thin odd shears, the round-nine all-pair price excludes all odd depths 5 through 55 even after granting Type B its optimistic joint cut. The ordered-triple price also excludes 57. For the more specific case in which separated Type B uses no external recursive jobs, the exact upper allowance is \(8L H_{17}\). The same all-pair inequality can then exclude **every odd depth from 35 through \(10^{39}-1\)** without enumerating individual clocks. Combined with the original small-depth price, this applied class is excluded for all odd depths 5 through \(10^{39}-1\) at \(\kappa=.005\).

Write \(b=1/40\) and \(w=b/L\). For a target with \(x\) native marks and \(y\) idle marks put \(k=x+y\), \(k\le L\). For any idle group width \(a\le k\), the derivative of

\[
  \phi(a)=H_{8a}/a+w(a-1)
\]

is \(-\kappa H_8 a^{-1-\kappa}+w\), which is negative for \(1\le a\le L\) if \(b<\kappa H_{8L}/L\). Using exact directed arithmetic at \(L=10^{39}-1\) proves this condition for the entire claimed range. Thus allowing even an idle of width \(k\) only reduces the local debit. For the affine line \(\ell(x)=H_{17}+(x-2)(H_{25}-H_{17})\), it remains to check

\[
\ell(x)-H_{8k+1}+(k-x)\phi(k)-w(k(k-1)-2x)\ge0.
\]

The expression is affine in \(x\), so only its two ends need checking. At \(x=0\) the debit equals \(\ell(0)-(H_{8k+1}-H_{8k})\) and is positive by the directed \(k=1\) check and concavity. At \(x=k\) the debit is \(\ell(k)-H_{8k+1}-wk(k-3)\). The cases \(k=0,1,2,3\) hold by the affine line and the sign of the quadratic. For \(4\le k\le20\), checking \(w=b/35\) suffices. For \(k\ge21\), the convex function \(z(k)=\ell(k)-H_{8k+1}\) vanishes at 3 and its extrapolated chord from 3 to 21 gives \(z(k)\ge z(21)(k-3)/18\). This slope exceeds \(b\) and \(wk(k-3)\le b(k-3)\).

The local debit applies to the complete operand inventory. Summed over the roles it is at least \(w rL(L-5)=br(L-5)\) by the existing all-pair rank proof. With the actual no-auxiliary B upper allowance, the remaining complete upper is linear in \(L\), negative already at 35 and decreasing. At \(L=59\) its upper endpoint is below \(-205\). This inference uses independent positive body labels, exact defect and A/B separation. Models with paid Type B auxiliary calls can have larger credit and require a different certificate. Depths beyond the analytic derivative range also require a separate argument.

`long_clock_tail.py` reproduces the entire monotonic argument's exact numerical hypotheses, 17 small local inequalities and several representative full margins from the pinned #7546 tariff. Use `python -I -B -S -W error round9/long_clock_tail.py inputs` after extraction.
