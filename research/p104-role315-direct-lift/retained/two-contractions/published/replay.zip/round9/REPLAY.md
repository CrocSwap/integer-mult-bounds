# Ninth-round reproducibility

The archive contains the complete fixed inputs for the proofs, the root rank invoices and the finite counterexamples. The recurrence and BIT programs use the Python standard library. Use an empty extraction destination and Python 3.12 or later.

~~~powershell
Expand-Archive -LiteralPath .\kappa-research-round9-replay.zip -DestinationPath .\round9-source
python -I -B -S -W error .\round9-source\round9\check_replay_bundle.py .\kappa-research-round9-replay.zip .\round9-fresh
~~~

Append `--gpu` to repeat the directed-weight benchmark in both standard-library CPU code and Direct3D 11 on Windows. A driver with `nvidia-smi` is required for this route. A CPU-only reproduction is the default and uses the same grid, exact selected certificates and complete source invoice. Scores from the coarse fixed-point search can lose plausible candidates. The separate directed price inequalities certify selected witnesses. Timings and memory belong to the benchmark rather than the deterministic receipts.

The new proofs are `PREFIX-BODY-WORD.md`, `LONG-CLOCK-TAIL.md`, `recurrence/CLOCK-PAIR-PRICE.md`, and `recurrence/CLOCK-TRIPLE-PRICE.md`. The Type B regular clock graph, BIT reciprocal moves and failed BIT contraction are in `independent` and `algebra`. The separately scoped audit of public #7601 rebuilds its advertised word from the pinned #7546 base, verifies the precise two fusions and pricing, and keeps open-PR check status distinct.
