"""A rank-one odd direct transport and the mixed BIT derivative deficit."""

from collections import Counter
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
sys.path[:0]=[str(BASE/"round8"/"algebra"),str(BASE/"round6"),str(BASE/"round6"/"algebra"),
              str(BASE/"algebra")]
from reciprocal_relay import ALG
from scan_bit_move_runs import load_word
from scan_bit_fixed_graph import supported_interval
from staged_two_way_routes import binary_rank, xor_selection
from syndrome_packets import require
from permute_head_frames import head_geometry, dot


def prod(a,b):
    return [xor_selection(b,r) for r in a]


def outer(u,v,n):
    return [v if u>>i&1 else 0 for i in range(n)]


def trace(a):
    return sum(v>>i&1 for i,v in enumerate(a))%2


def polynomial_sum(x,y):
    return [a^b for a,b in zip(x,y,strict=True)]


def physical_child(a, frame, rank):
    n=len(frame)
    order=sorted(range(n), key=lambda j:(frame[j][j]==1,j))
    move=a.matrix([[frame[i][j] for j in order]for i in order])
    op=ALG["split_operator"](a,move,[1]*n)
    left,child,right=ALG["compile_one"](a,op,rank)
    require(a.mul(a.mul(left,op),right)==child,"bad grouped odd child")
    return 2*n


def one_lane_transport(body):
    # Equal ending frame for both arbitrary roots. An ordinary SWAP
    # afterward restores original role labels and leaves the odd word
    # on exactly the first original. Third field is an untouched dirty input.
    A=ALG["Arithmetic"]()
    d=body+1
    I=A.eye(d)
    Q=A.matrix([[int(i==j==0)for j in range(d)]for i in range(d)])
    start=[A.scale(I,0),Q]
    after=[I,I]
    got=[A.mul(A.combine(I,A.scale(p,2),-1),A.combine(I,A.scale(q,2),-1))
         for p,q in zip(after,start,strict=True)]
    expected=[A.scale(I,-1),A.combine(A.scale(I,-1),A.scale(Q,2))]
    require(got==expected,"wrong physical paired shifts")
    columns=0
    for modulus in (101,1009**2):
        a=ALG["Arithmetic"](modulus)
        for r,frame in zip((body+1,body),got,strict=True):
            if not r:
                require(frame==I,"zero width must be identity")
                continue
            columns+=physical_child(a,frame,r)
    maps=[1,2,4]
    maps[0],maps[1]=maps[1],maps[0]
    maps[0],maps[1]=maps[1],maps[0]
    require(maps==[1,2,4],"nominal row alias changed arbitrary dirty input")
    bill=Counter(r for r in (body,body+1) if r)
    return {"body":body,"rank_profile":dict(sorted(bill.items())),"productive":dict(sorted(bill.items())),
            "verified_address_columns":columns,"arbitrary_roles":3}


def two_head_transport(word):
    # h0,h1 use the same E8 cap receptor and are orthogonal. The incoming
    # branch points are h0,h1, the common outer six-space supplies the body.
    A=ALG["Arithmetic"]()
    heads,_,P=head_geometry(word)
    require(not dot(heads[0],heads[1]),"pinned orthogonal pair changed")
    I=A.eye(8)
    cap=A.combine(I,P[1],-1)
    R=lambda p:A.combine(I,A.scale(p,2),-1)
    G0=A.mul(R(cap),R(P[0]))
    G1=A.mul(R(cap),R(P[1]))
    expected0=A.combine(A.scale(I,-1),A.scale(A.combine(P[0],P[1]),2))
    require(G0==expected0 and G1==A.scale(I,-1),"wrong two-head compound action")
    columns=0
    for mod in (101,1009**2):
        a=ALG["Arithmetic"](mod)
        for u,r in ((G0,6),(G1,8)):
            columns+=physical_child(a,u,r)
    return {"source_ports":[0,1],"paid":{6:1,8:1},"productive":{6:1,8:1},
            "odd_head_occurrences_on_roles":[0,2],"verified_address_columns":columns}


def derivative_inventory():
    # Every rank-one square-zero piece has trace 0; rank-one diagonal
    # reflection derivatives have trace 1 and are idempotent. Conjugates
    # span the same enumeration. Positive witness N1+N2+P gives odd x.
    count=Counter()
    for n in (2,3):
        rows=[outer(u,v,n) for u in range(1,1<<n) for v in range(1,1<<n)]
        I=[1<<i for i in range(n)]
        for a,b in product(rows,repeat=2):
            endpoint=polynomial_sum(a,b)
            if any(E and E!=I[i] for i,E in enumerate(endpoint)):
                continue
            out=binary_rank(endpoint)
            require((out-trace(a)-trace(b))%2==0,"trace and header parity disagree")
            if out==2:
                require(trace(a)==trace(b)==1,"saturation admits a transvection")
            count[(n,out,trace(a)+trace(b))]+=1
    p=[1,0,0]
    n1=[2,0,0]
    n2=n1.copy()
    want=polynomial_sum(polynomial_sum(n1,n2),p)
    require(want==p and trace(n1)==0 and trace(p)==1,"exact rank-one odd witness")
    # All states are two coefficient matrices A+B(q+1), with (q+1)^2=0.
    i=[1,2,4]
    v,vprime=i,[0,0,0]
    for h in [n1,n2,p]:
        vprime=polynomial_sum(prod(i,vprime),prod(h,v))
        v=prod(i,v)
    require(v==i and vprime==p,"full three-role dual-number operator")
    missing=polynomial_sum(n1,p)
    require(missing!=p,"drop-one transvection mutation overlooked")
    return {"checked_diagonal_pair_endpoints":sum(count.values()),
            "cases":[[n,r,p,v]for (n,r,p),v in sorted(count.items())],
            "witness_role_count":3,"odd_root_count":1,"all_other_columns_return":True}


def put_body_shift(rows, active, power_bit):
    return [{u^power_bit for u in row} if i in active else row
            for i,row in enumerate(rows)]


def coupled_body_word(events, n=4, augment=False):
    """Polynomials over F2 with literal per-role input columns."""
    rows = [{2*i} for i in range(n)]
    for datum in events:
        op,a,b,body = datum
        if op in ("LOCAL","QUERY"):
            rows[a] ^= {u^(0 if augment else 1)for u in rows[b]}
        if op == "LOCAL":
            rows = put_body_shift(rows,(a,b),body)
        if op == "ODD":
            rows = put_body_shift(rows,(a,),body^(0 if augment else 1))
        if op == "XOR":
            rows[a] ^= rows[b]
        if op == "SWAP":
            rows[a],rows[b] = rows[b],rows[a]
    return rows


def body_localization():
    # Simultaneous q-and-body check. Every native's own body is fresh,
    # each direct mover carries its own fresh body and q. No body-one
    # specialization erases the distinction between those schedules.
    body = (1<<4,1<<5,1<<6,1<<7,1<<8)
    forward = [
        ("ODD",2,2,body[3]),("LOCAL",0,1,body[0]),("LOCAL",1,0,body[1]),
        ("LOCAL",0,1,body[2]),("SWAP",0,1,0),("ODD",3,3,body[4])]
    want_body = body[0]^body[1]^body[2]
    expected = [{0^1^want_body},{2^1^want_body},{4^1^body[3]},{6^1^body[4]}]
    require(coupled_body_word(forward)==expected,"mixed charged odd movers with braid")
    require(coupled_body_word(forward[1:])!=expected,"omitted paid odd transfer")
    require(coupled_body_word(forward[:3]+forward[4:])!=expected,"omitted native header")
    # q=1 is unable to see replacement of the native q payload with an
    # ordinary shear, if the same body transfer still occurs.
    mutated = forward.copy()
    mut_index=2
    _,a,b,h=mutated[mut_index]
    fragment = [("XOR",a,b,0),("LOCAL",a,b,h),("QUERY",a,b,0)]
    mutated[mut_index:mut_index+1] = fragment
    require(coupled_body_word(mutated,augment=True)==coupled_body_word(forward,augment=True),
            "mutation must bind the nominal body profile")
    require(coupled_body_word(mutated)!=expected,"q=1 blindness control did not bite")
    published=[]
    for q,s in ((0,1),(1,2),(2,3)):
        # At an a,b coordinate pair, the only distinct rank-one square-zero
        # matrices are E_ab, E_ba and J_ab. All even multiples cancel.
        a=outer(1<<q,1<<s,4)
        b=outer(1<<s,1<<q,4)
        both=outer((1<<q)|(1<<s),(1<<q)|(1<<s),4)
        other = polynomial_sum(polynomial_sum(a,b),both)
        require(other==[1<<t if t in (q,s) else 0 for t in range(4)],
                "one active pair must return exactly both diagonal factors")
        published.append((q,s))
    return {"actual_native_calls":3,"fresh_direct_odd_moves":2,"arbitrary_roles":4,
            "all_polynomial_columns":16,"two_outputs_with_three_body_labels":2,
            "fresh_standalone_odd_returns":2,"distinct_pair_triples":published,
            "negative_controls":3}


def native_pricing(word):
    d={int(k):f["dim"] for k,f in word["frames"].items()}
    p=Counter(abs(d[b]-d[a]) for op,_,*r in word["program"] if op=="MOVE" for a,b in [r])
    t=Counter(d[b]-d[a] for a,b in zip(word["start"][222:],word["final"][222:],strict=True))
    require(sum(p.values())==2871 and sum(t.values())==437,"pinned full native bill")
    response=[]
    for s in (".005",".0227"):
        H={r:supported_interval(r,Fraction(s)) for r in (*range(1,9),22)}
        # Price optimistic independent closed body/odd output read with
        # H1 or H8-H7 incremental header on each actual native odd unit.
        intervals={}
        scale=2**80
        for name,factor in (("any_header_root",1),("body_root",0)):
            raw=Counter(t)
            raw.subtract(p)
            raw[7]+=222
            if factor:
                raw[1]+=111
            else:
                raw[8]+=111
                raw[7]-=111
            bounds=[sum(c*H[r][k if c>=0 else 1-k] for r,c in raw.items()) for k in (0,1)]
            intervals[name]={"directed":bounds,"upper":bounds[1]/scale}
        response.append({"s":s,"per_native_after_full_paid_idles":intervals,
                         "new_direct_odd_moves_net_alone":0,
                         "one_use_native_body_everywhere_upper_margin":one_use_price(p,t,H),
                         "separately_funded_direct_body_odd_capacity":mixed_pair_cap(p,t,H)})
    return {"paid":p,"helpers":t,"pricing":response}


def one_use_price(p,t,H):
    # Whole equal native pairs carry k bodies. A native-origin odd pair
    # needs k>=3 independent shears. No other body label participates on
    # its two roles except separately funded direct moves.
    raw=Counter({22:222})
    raw.update({r:3*c for r,c in t.items()})
    raw.subtract({r:3*c for r,c in p.items()})
    num=[sum(c*H[r][i if c>=0 else 1-i] for r,c in raw.items()) for i in (0,1)]
    require(num[1]<0,"priced first eligible triple must have negative margin")
    return {"triple_directed_2pow80":num,"triple_upper":num[1]/2**80,
            "per_native_upper":num[1]/(3*2**80)}


def mixed_pair_cap(p,t,H):
    # For a native pair that completes no odd header of its own, fuse
    # all its k body widths first. Removing separately funded head/body
    # shifts cannot increase that incremental credit by concavity.
    # For a pair that completes both native headers, k>=3; the same
    # concavity makes (2 H_(7k+1))/k greatest at k=3.
    raw=Counter(t)
    raw.subtract(p)
    raw[7]+=222
    body=[sum(c*H[r][i if c>=0 else 1-i]for r,c in raw.items())for i in (0,1)]
    odd=one_use_price(p,t,H)["triple_directed_2pow80"]
    normalized=[max(3*body[i],odd[i])for i in (0,1)]
    require(normalized[1]<0,"complete mixed locality cap must be negative")
    return {"directed_denominator":3*2**80,"all_pair_types_directed":normalized,
            "ordinary_body_pair_upper":body[1]/2**80,
            "all_pair_types_upper":normalized[1]/(3*2**80)}


if __name__=="__main__":
    w=load_word()
    print(json.dumps({"status":"PASS_ODD_PAIR_TRANSPORT_AND_DEFECT",
                      "one_odd_head":[one_lane_transport(b)for b in (0,1,2,7)],
                      "two_distinct_heads":two_head_transport(w),
                      "mixed_rank_one_derivatives":derivative_inventory(),
                      "distinct_body_localization":body_localization(),
                      "selected_native_invoice":native_pricing(w)},indent=2))
