"""Exact old-input witness for the 0→2→4 equal-suffix relay candidate."""

from collections import Counter, defaultdict
from fractions import Fraction
import json
from pathlib import Path
import sys
from time import monotonic

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
sys.path[:0]=[str(BASE/"round6"),str(BASE/"algebra")]
from selected_contact_ports import LOAD, endpoint, extend, replay, sensitivities
from scan_bit_fixed_graph import supported_interval


def need(ok,msg):
    if not ok:
        raise ValueError(msg)


def fit(rows,target):
    pivots={}
    for r in rows:
        extend(pivots,r)
    return not extend(pivots,target,False)


def candidate_census(word, deadline):
    pref,*_=replay(word,deadline)
    suffix=sensitivities(word,deadline)
    by_suffix=defaultdict(list)
    dims={int(i):v["dim"] for i,v in word["frames"].items()}
    tape=word["program"]
    for j,q in suffix.items():
        by_suffix[q].append(j)
    report = []
    for i,r in sorted(pref.items()):
        _,x,a,b=tape[i]
        if dims[a]!=0 or dims[b]!=2:
            continue
        matches=[j for j in by_suffix[suffix[i]] if i<j and tape[j][2]==b and
                 dims[tape[j][3]]==4]
        if not matches:
            continue
        j=min(matches)
        f=tape[j][1]
        need(x<word["public"] and r==(1<<x),"zero up carries pure arbitrary old helper")
        need(pref[j]>>x&1,"equal-suffix exit needs that helper")
        report.append({"a":i,"b":j,"helper":x,"receiver":f,"middle":b,
                       "cap":tape[j][3],"missing":pref[j]^r,"sensitivity":suffix[i]})
    need(len(report)==153,"complete selected short 0→2→4 census")
    return report,suffix


def ingress_census(word, candidates, deadline):
    n=word["public"]
    frames=word["start"]+[None]*word["owned_fields"]
    rhs=[1<<i for i in range(n)]+[None]*word["owned_fields"]
    banks=defaultdict(set)
    for i,f in enumerate(frames[:n]):
        banks[f].add(i)
    groups=defaultdict(list)
    for z in candidates:
        groups[z["cap"]].append(z)
    watch=defaultdict(list)
    for i,(op,r,*a) in enumerate(word["program"]):
        if i%2048==0:
            need(monotonic()<deadline,"bounded destination-span census")
        if op=="ADD":
            s,f=a
            for z in groups.get(f,()):
                if i > z["b"]:
                    # The missing term must come from other active fields.
                    rows=[rhs[k] for k in banks[f] if k!=z["receiver"]]
                    if fit(rows,z["missing"]):
                        watch[z["a"]].append(i)
            rhs[r]^=rhs[s]
        elif op=="MOVE":
            f,g=a
            banks[f].remove(r)
            banks[g].add(r)
            frames[r]=g
        elif op=="SWAP":
            s,=a
            f,g=frames[r],frames[s]
            if f!=g:
                banks[f].remove(r)
                banks[g].remove(s)
                banks[g].add(r)
                banks[f].add(s)
                frames[s],frames[r]=f,g
            rhs[r],rhs[s]=rhs[s],rhs[r]
        elif op=="INIT":
            f,=a
            frames[r],rhs[r]=f,0
            banks[f].add(r)
        elif op=="CLEAR":
            f,=a
            banks[f].remove(r)
            rhs[r]=frames[r]=None
        else:
            raise ValueError(op)
    need(rhs[:n]==endpoint(n),"selected arbitrary-helper baseline")
    return {str(k):v for k,v in sorted(watch.items())}


def witness_word(word, h, u, v):
    # Replace local three-owner gate. P=u+v must eventually also reach 297.
    # Public owner slot relabels preserve the original role names at all exits.
    a,b,c,d,z=264,297,315,524,0
    orig=[
        ["MOVE",h,z,a],["ADD",u,h,a],["ADD",u,v,a],
        ["ADD",h,v,a],["ADD",v,h,a],["ADD",h,v,a],["ADD",v,u,a],
        ["MOVE",u,a,b],["MOVE",v,a,c],["MOVE",h,a,d],
    ]
    raw=word["program"]
    need(raw[22470:22480]==orig,"source chronology changed")
    # (u,v,h) -> (h,u+v,v), and all four physical return frames unchanged.
    alt=[
        ["ADD",u,v,a], ["MOVE",u,a,c], ["MOVE",v,a,d], ["MOVE",h,z,b],
        ["SWAP",u,h], ["SWAP",v,h],
    ]
    return {**word,"program":raw[:22470]+alt+raw[22480:]}


def build_counterfactual(word, recipient, deadline, later_repair=False):
    n=word["public"]
    h,u,v=(631,327,413)
    bad=witness_word(word,h,u,v)
    frames=word["start"]+[None]*word["owned_fields"]
    rhs=[1<<i for i in range(n)]+[None]*word["owned_fields"]
    program=bad["program"]
    if later_repair:
        j=next(i for i,e in enumerate(program) if e==["ADD",u,v,501])
        program=program[:j]+[["ADD",u,v,501]]+program[j:]
    postage=Counter()
    for k,(op,i,*a) in enumerate(program):
        if k%2048==0:
            need(monotonic()<deadline,"bounded exact local mutation")
        if op=="ADD":
            need(frames[i]==frames[a[0]]==a[1],"wrong coframe in actual counterfactual word")
            rhs[i]^=rhs[a[0]]
        elif op=="MOVE":
            p,q=a
            need(frames[i]==p,"wrong literal source frame")
            frames[i]=q
            postage[abs(word["frames"][str(p)]["dim"]-word["frames"][str(q)]["dim"])]+=1
        elif op=="INIT":
            need(i>=n and frames[i] is None,"wrong birth")
            frames[i],rhs[i]=a[0],0
        elif op=="CLEAR":
            need(i>=n and frames[i]==a[0],"wrong retirement")
            frames[i]=rhs[i]=None
        elif op=="SWAP":
            j,=a
            frames[i],frames[j]=frames[j],frames[i]
            rhs[i],rhs[j]=rhs[j],rhs[i]
    target=endpoint(n)
    need(frames[:n]==word["final"] and all(f is None for f in frames[n:]),"all public frames return")
    changed={i:row^target[i] for i,row in enumerate(rhs[:n]) if row!=target[i]}
    need(changed,"wrong-priced mutation silently admitted")
    if not later_repair:
        need(set(changed.values())=={recipient["missing"]} and len(changed)==recipient["sensitivity"].bit_count(),
             "omitted row injection is not rank-one")
    return {"all_public_coefficients":n*n,"failed_ledgers":len(changed),
            "altered_input_count":len(set(i for r in changed.values() for i in range(n) if r>>i&1)),
            "prices":postage,"later_repair_attempt":later_repair}


def funded_repair(word, recipient, deadline):
    """Return every input exactly, funding the extra independent arrival of p."""
    h,u,v=(631,327,413)
    w=witness_word(word,h,u,v)
    n=w["public"]
    extra=n+w["owned_fields"]
    plan=w["program"]
    copy=[["INIT",extra,315],["ADD",extra,v,315],
          ["MOVE",extra,315,264],["MOVE",extra,264,297],
          ["ADD",u,extra,297],["CLEAR",extra,297]]
    # The two caps of these rank-four branches share the original rank-two
    # rotation contact. Do not quote nonnested rank difference here.
    U={int(j):z for j,z in w["frames"].items()}
    for small,large in ((264,315),(264,297)):
        need(all(sum(Fraction(x)*Fraction(y) for x,y in zip(a,b,strict=True))==0
                 for a in U[small]["B"] for b in U[large]["A"]),"paid repair is not nested")
    # The forward order after the two SWAPs really has p at role 413.
    k=22470+6
    alt={**w,"owned_fields":w["owned_fields"]+1,"program":plan[:k]+copy+plan[k:]}
    before,_,_,_,old=replay(word,deadline)
    after,_,_,_,paid=replay(alt,deadline)
    s1,s2=sensitivities(word,deadline),sensitivities(alt,deadline)
    need(sum(old.values())+1==sum(paid.values()) and paid-old=={4:1} and not(old-paid),
         "all recursive repair tariff exact")
    need(len(before)==len(s1) and len(after)==len(s2),"independent both-column replays")
    return {"paid":paid,"extra_native_rank":{4:1},"owned_extra_max":1,
            "all_forward_reverse_coefficients_each":n*n,
            "actual_received_old_payload_is_restored":True}


def tariff():
    ans=[]
    for s in (".005",".0227"):
        h2=supported_interval(2,Fraction(s))
        h4=supported_interval(4,Fraction(s))
        a=[153*(2*h2[k]-h4[1-k]) for k in (0,1)]
        ans.append({"s":s,"most_favorable_153_disjoint_2pow80":a,
                    "upper_if_every_age_could_be_repaired_free":a[1]/2**80})
    return ans


if __name__=="__main__":
    end=monotonic()+20
    w=LOAD()
    tests,ss=candidate_census(w,end)
    case=next(o for o in tests if o["a"]==22470)
    fit_all=ingress_census(w,tests,end)
    case={**case,"earliest_reconstruction_same_chart":fit_all.get("22470",[]),
          "later_move_influence":ss[23421].bit_count()}
    print(json.dumps({"status":"PASS_FROZEN_PAIR_LOCAL_BYPASS_COUNTEREXAMPLE",
                      "candidate_count":len(tests),"interval_lengths":dict(Counter(v["b"]-v["a"]for v in tests)),
                      "coframed_stock_fit":fit_all,"literal_control":case,
                      "missing_pair_compensation":build_counterfactual(w,case,end),
                      "simple_later_cap_compensation":build_counterfactual(w,case,end,True),
                      "funded_exact_pair_compensation":funded_repair(w,case,end),
                      "tariffs":tariff()},indent=2))
