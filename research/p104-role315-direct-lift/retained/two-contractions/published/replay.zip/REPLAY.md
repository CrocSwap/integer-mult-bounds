# Reproduce the local integer multiplication research checks

Use CPython 3.11 or newer. DESKTOP-CHKL6QL ran CPython 3.13.14 from the existing ComfyUI-DaSiWa portable Python. The exact replays require the standard library. The benchmark requires Windows, `nvidia-smi`, Direct3D 11, and the supplied backend. The compressed inputs retain the bytes of their original pinned sources.

| Input | SHA-256 | Source |
| --- | --- | --- |
| `inputs/7546-word.json.gz` | `6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32` | [#7546 exact head](https://github.com/ToikY/integer-mult-bounds/blob/99438c43df7aac1e5dbcc43c1578fcd886c119ec/research/p104-role902-direct-lift/expected/role902-WORD.json.gz) |
| `inputs/7113-caller.json` | `255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc` | [#7113 source](https://github.com/rohanarun/integer-mult-bounds/tree/07a76c5e2738882c0cb322278e56f6cae3c9885d/research/signed-caller-8x9) |
| `algebra/native.json.gz` | `51203e7fc75ba10bd3ac3f8e675759f47e13d262bea66b6600d1e515095cad78` | [#7001 native preserved on main](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/research/paired-query-only-bit/retained/inputs/BIT-NATIVE-WORD.json.gz) |
| `inputs/benchmark-d3d11-backend.py` | `7cbd7711df73af91f2514af91a6364f31b822955e4b3614e7eec4c5c81a289a2` | Prior local `integer-mult-local-recovery` GPU benchmark |

Run these commands from the extracted directory. Existing JSON receipts are under `receipts/`. Example commands write fresh receipt files in the current directory. The directed integers in a result are divided by its `unit_denominator` or `scale`.

```powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$repo = 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
$word = 'inputs/7546-word.json.gz'
$caller = 'inputs/7113-caller.json'
$bit = 'algebra/native.json.gz'
& $py -I -B -S temporal_helper_floor.py --self-test
& $py -I -B -S temporal_helper_floor.py --word $word --caller $caller --output temporal-raw-new.json
& $py -I -B -S helper_price.py temporal-raw-new.json temporal-priced-new.json
& $py -I -O -B -S bit_swap_transport.py $bit bit-swap-new.json
& $py -I -B -S bit_geometry_ledger.py $bit bit-ledger-new.json
& $py -I -B -S recurrence/verify_bit_caller_bound.py $repo
& $py -I -B -S recurrence/check_bit_native_cuts.py $repo
& $py -I -B -S independent/spectator_batch.py $word $caller
& $py -I -O -B -S independent/receiver_side_information.py $word --all-cuts --one-donor --two-donors --tariff-floor
& $py -I -B -S benchmark_helper_cohorts.py --word $word --backend inputs/benchmark-d3d11-backend.py --bounds temporal-priced-new.json --output gpu-benchmark-new.json
```

Algebraic quotient and chart checks run from `algebra/`. See `algebra/bit-orthogonal-quotient-proof.md` for commands and the distinct cover and compiler assumptions. The `--help` text of each script lists its switches. The checkout argument to the recurrence scripts is read-only. They read exact named Git blobs at `e54523517d0f03e58352e647c403a5af3e525a57`, so the user's sparse checkout is sufficient if Git can access the pinned objects.

## Temporal helper floor

Fix the values and times of the selected main and owned observations. Project away every public helper token. For a chart and a prefix, let `K` be the span of the fixed inputs that have arrived and the fixed values that have already been observed. Let `B` span all helper arrivals so far. Every fixed observation lies in `K+B` by the common-frame rule. The potential `dim(K+B)−dim(K)` is initially zero. Each helper arrival adds at most one. A fixed arrival can only shrink the potential or leave it unchanged. A fixed observation that enlarges `K` decreases it by exactly one, since that observation already belongs to `K+B`. Thus the number of rank-increasing fixed observations is a lower bound on the cumulative helper arrivals. It dominates the maximum instantaneous deficit `rank(inputs and observations)−rank(inputs)`. Repeated visits to the same chart by a strictly increasing helper are impossible.

The reverse argument uses the invertible complete scalar transformations. COPY acts as ADD on its valid zero destination and can be reversed on the actual states. INIT and CLEAR are dual in reverse, with each fixed nonzero CLEAR value admitted as a known external arrival. The projected final helper values are zero, since the helper input tokens are independently restored. Reverse arrivals count forward departures. Subtract helpers whose fixed endpoints account for arrivals on only one side, then take the larger bound per chart. This yields 909 interior visits. Between fixed helper boundary dimensions, each strict interior visit contributes at least `H(1)+H(1)−H(2)` to the net paid moment. For positive integers `a,b`, `H(a)+H(b)−H(a+b)` is minimized at `a=b=1` by diminishing increments. Telescoping the strict path gives the sum over its stops. This applies when the fixed observations and helper entries and exits remain the same. It leaves open changes to the required observations, the main and owned paths, or the productive boundary.

## BIT transport obstruction

For any set of charts, project each live row onto the input coordinates initially outside that set. Starting data inside carry zero such projection. A common-frame gate, INIT, or CLEAR cannot increase the historical span of the projected rows inside. A MOVE from outside to inside contributes at most one row. A routing rename that carries the frame and value together leaves this span unchanged. Hence the cut has a rank bound using only the multiset of MOVE transitions. For each selected head, the charts containing its line are upward closed. For monotone public motion, the number of public cut entries is the number of final public fields inside minus the number of initial public fields inside, regardless of their individual trajectories.

The old source has zero owned entrances in these cuts. In the old scalar shear the `x_i` contribution to `y_i+x_i` leaves the cut of its own head, and the `y_i` input itself does not enter that cut. In the desired exchange the `y_i` input enters that cut on the corresponding full-frame output. For other heads, the rank demand depends on which head and complement contain the direction. The exact block census demonstrates one extra independent arrival at every head cut. With a single additional rank-one transition, the destination would have to contain all heads, hence be the full space. The source hyperplane must avoid every head. The literal chart inventory has no such hyperplane and there is no initial public value or original MOVE supplying a fresh hyperplane. The new-chart positive control shows geometry alone permits such a hyperplane. An old MOVE could be repurposed only by changing more of the transport program. The optional early Boolean reachability model serves as a control and allows every same-chart dependency to spread free. It passes even while the rank cut excludes the target.

## Validation scope

The root scripts reconstruct exact scalar endpoints, transport profiles, rank and signed prices or a specified necessary condition. They do not materialize a new all-width native swap, recursive compiler, or integer multiplier. The ordinary CPU/GPU exact match is a performance result for finite candidate screening. No external publication is required to reproduce this package.
