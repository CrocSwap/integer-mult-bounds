# Round 3 exact replay

This package pins the #7001 BIT word and the #7546 complex word. It also
includes the #7113 caller and the complete #7546 price receipt. Verify the
SHA-256 manifest before using the artifacts. Scripts use only Python 3.11+
standard-library modules. Commands below run from the extracted ZIP root.
`python` may be replaced by the full path of the portable Python interpreter.

```powershell
$bit = 'algebra/native.json.gz'
$complex = 'inputs/7546-word.json.gz'
$caller = 'inputs/7113-caller.json'
$whole = 'inputs/7546-whole.json'
$out = New-Item -ItemType Directory -Path 'run' -Force
python -I -B -S -W error round3/chart_552_retime.py $bit "$out/chart-552.json" --emit "$out/chart-552-word.json"
python -I -B -S -W error round3/bit_complemented_adjoint.py $bit "$out/bit-adjoint.json" --emit "$out/bit-adjoint-word.json"
python -I -B -S -W error round3/type_b_axis_cut.py $complex $caller $whole "$out/type-b-axis-cut.json" --emit "$out/type-b-lifted-word.json"
python -I -B -S -W error round3/complex_swap_directions.py $complex "$out/type-b-swap.json"
python -I -B -S -W error round3/independent/fresh_axis_lift.py --word $complex --output "$out/fresh-lift.json"
python -I -B -S -W error round3/independent/j1_fresh_axis_floor.py $caller $whole
python -I -B -S -W error round3/independent/shared_body.py $complex $caller $whole
python -I -B -S -W error round3/independent/spectator_quotient.py $complex
python -I -B -S -W error round3/independent/body_rank_deformation.py $caller $whole
python -I -B -S -W error round3/algebra/staged_two_way_routes.py
python -I -B -S -W error round3/algebra/nine_cut_geometry.py
python -I -B -S -W error round3/algebra/concentrated_descents.py
python -I -B -S -W error round3/algebra/permute_head_frames.py
```

The multi-header verifier uses Git to read three authenticated objects from the
canonical commit. It does not modify the checkout. Use its real path as the
argument. The output is included for a reader without that checkout.

```powershell
python -I -B -S -W error round3/recurrence/verify_header_feedback.py 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
```

Run the complex interval engine and Clifford replay with assertions enabled.
Some of the included probe receipts record wall time, so compare proof-relevant
fields in those outputs. Chart 552, general BIT geometry and main axis-cut
receipts omit wall time, and can be compared byte for byte. The frozen inputs
and scripts are included. The three generated words are produced by `--emit`.

The complemented BIT adjoint has the same tariff and logical interface under
the inherited arbitrary-input, coframe and owned-erasure contracts. The 552
word exchanges one coordinate after an explicit three-XOR change of basis and
restores all independent helpers. Its lower-address cross term has rank six.
The complex cut solves the exact integer capacity instance with outward tariff
intervals. The emitted nested 10D word is priced as a losing candidate. These
artifacts do not emit an improved fixed-tape integer-multiplication algorithm.

The P111 geometry replay regenerates the pinned upstream rigidity CNFs and
reads the retained SAT results. It does not run the missing asymmetric DRAT
trace. Its unconditional count floor uses the separate exact parity witness.
The mass proof can be used with canonical fitting matrix B0 as an explicit
hypothesis. See `algebra/bidirectional-cut-proof.md`.

Source credits and license are included at the ZIP root. The frozen inputs
retain their original digests. The Type B implementation also uses the exact
Gaussian-dyadic Clifford engine from the upstream work.
