# SPDX-License-Identifier: Apache-2.0
"""Optimize one fresh Fourier axis on a pinned complex native's exact coframe graph."""

import argparse
from collections import Counter
from fractions import Fraction
import gzip
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
SOURCE = run_path(str(HERE / "independent/body_rank_deformation.py"))
FLOW = run_path(str(HERE.parent / "algebra/scan_bit_coalitions.py"))["directed_cut"]
NATIVE = run_path(str(HERE / "independent/spectator_quotient.py"))
NEED = SOURCE["require"]
FOURIER_AXIS = 1 << 9
INCUMBENT = Fraction("0.003648411294790")


def add(counter, rank, diff):
    if rank:
        counter[rank] += diff


def helper_roles(word):
    n = word["public"]
    x = set(word["live"])
    hosted = word["hosted"]
    ordinary = x | {r + 112 for r in x} | set(hosted["X2"]) | set(hosted["Y2"])
    b = {word["live"][j] for j in range(len(word["ports"])) if j not in hosted["Dports"]}
    both = b | {r + 112 for r in b}
    NEED(len(both) == 16, "eight Type B ports, two rails each")
    return set(range(n)) - ordinary, both


def graph(word):
    """Contract lifetimes between moves plus every coframe scalar contact."""
    n = word["public"]
    current = [*range(n)] + [-1] * (1 + max(e[1] for e in word["program"]) - n)
    charts = {i: f for i, f in enumerate(word["initial"])}
    roots = list(range(n))
    current_frames = word["initial"][:] + [None] * (len(current) - n)
    births, deaths, moves = [], [], []
    steps = []

    def root(v):
        while roots[v] != v:
            roots[v] = roots[roots[v]]
            v = roots[v]
        return v

    def separate(frame):
        slot = len(roots)
        roots.append(slot)
        charts[slot] = frame
        return slot

    for i, (op, r, *rest) in enumerate(word["program"]):
        if op == "MOVE":
            a, b, owned = rest
            NEED(current_frames[r] == a and owned == (r >= n), "exact owned and public MOVE source")
            dest = separate(b)
            moves.append((current[r], dest, a, b, i, owned))
            current[r], current_frames[r] = dest, b
            steps.append((dest, a, b))
        elif op == "INIT":
            frame, = rest
            NEED(r >= n and current[r] < 0, "owned start")
            dest = separate(frame)
            current[r], current_frames[r] = dest, frame
            births.append(dest)
            steps.append((dest, frame))
        elif op == "CLEAR":
            frame, = rest
            NEED(r >= n and current_frames[r] == frame, "owned return")
            deaths.append(current[r])
            steps.append((current[r], frame))
            current[r], current_frames[r] = -1, None
        elif op in ("ADD", "COPY"):
            source, scalar, f = rest
            NEED(current_frames[r] == current_frames[source] == f and current[r] >= 0 and current[source] >= 0,
                 "every required coframe equality")
            roots[root(current[r])] = root(current[source])
            steps.append((current[r], f))
        elif op == "SCALE":
            scalar, f = rest
            NEED(current_frames[r] == f and current[r] >= 0, "bounded live SCALE")
            steps.append((current[r], f))
        else:
            raise ValueError(f"Unknown native gate {op}")

    NEED(current_frames[:n] == word["final"] and all(f is None for f in current_frames[n:]), "all literal boundary charts")
    ids = {r: j for j, r in enumerate(sorted({root(i) for i in range(len(roots))}))}
    component = [ids[root(v)] for v in range(len(roots))]
    for v, f in charts.items():
        NEED(charts[root(v)] == f, "components never identify distinct source chart labels")
    dims = list(map(len, word["frames"]))
    edges = [(component[a], component[b], abs(dims[f] - dims[g]), i, owned) for a, b, f, g, i, owned in moves]
    return {"n": len(ids), "starts": component[:n], "ends": [component[v] for v in current[:n]],
            "starts_owned": [component[v] for v in births], "ends_owned": [component[v] for v in deaths],
            "edges": edges, "contact_steps": steps, "components": component, "charts": charts, "slots": len(roots)}


def solve_cut(word, g, flags, s, price, options):
    """An exact mincut with downward capacities gives a certified lower bound."""
    p, b = helper_roles(word)
    dim = list(map(len, word["frames"]))
    h_rank = {r: dim[word["final"][r]] - dim[word["initial"][r]] for r in p}
    source, sink = g["n"], g["n"] + 1
    inc = {r: price.sub(price.power(r+1, s), price.power(r, s)) for r in range(1, 10)}
    net = []
    reward = 0
    helper_links = []
    for r, rank in h_rank.items():
        NEED(rank in inc, "exact independent helper difference")
        if options["helpers"]:
            cost_lower, cost_upper = inc[rank]
            reward += cost_upper
            net.append((source, g["ends"][r], cost_upper))
            if options["free_helper_input_prephase"]:
                net.append((g["starts"][r], sink, cost_lower))
                helper_links.append((g["starts"][r], g["ends"][r]))
    for a, h, r, _, _ in g["edges"]:
        NEED(r in inc and a != h, "paid native edge has a positive old rank")
        c, _ = inc[r]
        net += [(a, h, c), (h, a, c)]
    preserve = [v for r, v in enumerate(g["starts"]) if r not in h_rank or not options["free_helper_input_prephase"]]
    if options["fixed_owned"]:
        preserve.extend(g["starts_owned"] + g["ends_owned"])
    adapters = []
    for r, v in enumerate(g["ends"]):
        if r in p and options["helpers"]:
            continue
        if options["endpoint_adapters"]:
            a, h = (source, v) if r in flags else (v, sink)
            net.append((a, h, price.B))
            adapters.append((r, v, int(r in flags)))
        elif r not in flags:
            preserve.append(v)
    funded = [] if options["endpoint_adapters"] else [g["ends"][r] for r in flags]
    inf = sum(c for _, _, c in net) + 1
    net += [(q, sink, inf) for q in set(preserve)]
    net += [(source, q, inf) for q in set(funded)]
    for a, h, _, i, own in g["edges"]:
        old = word["program"][i]
        if options["no_new_owned_ascent"] and own:
            net.append((h, a, inf))
        if options["nested"]:
            x, y = (a, h) if dim[old[2]] < dim[old[3]] else (h, a)
            net.append((x, y, inf))
    net.extend((start, end, inf) for start, end in helper_links)
    value, chosen = FLOW(g["n"] + 2, net, source, sink)
    if value >= inf:
        return {"status": "infeasible with given boundary flags", "fixed_conflicts": len(set(preserve) & set(funded))}, None
    chosen.remove(source)
    NEED(value == sum(c for u, v, c in net if (u in chosen or u == source) and (v not in chosen and v != source)),
         "exact min-cut certificate")
    NEED(not set(preserve) & chosen and set(funded) <= chosen, "fixed boundary and productive charges")
    paid, productive = Counter(), Counter()
    paid_moves = []
    for a, h, r, i, owned in g["edges"]:
        if (a in chosen) != (h in chosen):
            add(paid, r, -1)
            add(paid, r+1, 1)
            paid_moves.append((i, 1 if h in chosen else -1, r, owned))
    returned = [(r, requested) for r, comp, requested in adapters if int(comp in chosen) != requested]
    paid[1] += len(returned)
    credited = [r for r in sorted(p) if options["helpers"] and g["ends"][r] in chosen and g["starts"][r] not in chosen]
    for r in credited:
        rank = h_rank[r]
        add(productive, rank, -1)
        add(productive, rank+1, 1)
    mp, mt = price.moment(paid, s), price.moment(productive, s)
    delta = price.sub(mp, mt)
    NEED(value - reward <= delta[1] and delta[0] <= delta[1], "conservative cut and reconstructed moment intervals intersect")
    return {"status": "exact cut with directed coefficient intervals", "active_components": len(chosen),
            "paid_MOVEs_crossing": len(paid_moves), "paid_new_ascents": sum(d > 0 for _, d, _, _ in paid_moves),
            "paid_delta": {r: v for r, v in paid.items() if v},
            "owned_new_ascents": sum(d > 0 and o for _, d, _, o in paid_moves),
            "credited_helpers": len(credited), "credited_helper_roles": credited,
            "axis_flags_at_unchanged_helper_pairs": sum(a in chosen and h in chosen for a, h in helper_links),
            "target_delta": {r: v for r, v in productive.items() if v},
            "native_paid_minus_helper_increment": price.show(delta), "native_increment_float": price.value(delta),
            "native_increment_certified_lower": price.show((value - reward, value - reward))[0],
            "changes": paid_moves, "endpoint_adapters": returned, "funded_main_end_components": sorted(set(funded))}, chosen


def caller_deltas(caller, stage, price, s):
    kind = caller["types"]["B"]
    count = len(kind["ports"])
    p, t = Counter(), Counter()
    for e in caller["events"]:
        if e[0] == "B" and e[1] in ("IDLE_ONE", "IDLE_ODD") and stage + 1 in e[3]:
            r = 8*len(e[3]) + (e[1] == "IDLE_ODD")
            add(p, r, -count)
            add(p, r+1, count)
    for phase, z, *mask in kind["diagonal"]:
        NEED(phase == -1 and z == 0, "odd Type B external return")
        if mask[stage]:
            r = 8*sum(mask) + 1
            add(t, r, -count)
            add(t, r+1, count)
    delta = price.sub(price.moment(t, s), price.moment(p, s))
    return {"stage": stage+1, "caller_paid_delta": dict(p), "caller_target_delta": dict(t),
            "caller_headroom": price.show(delta), "caller_headroom_float": price.value(delta)}


def expand_word(word, g, chosen, adapters):
    """Emit exact 10D frame labels and assert all edges have the claimed tensor form."""
    def flag(slot):
        return int(g["components"][slot] in chosen)

    n = word["public"]
    live = list(range(n)) + [-1] * max(0, (1 + max(e[1] for e in word["program"]) - n))
    base = [x[:] for x in word["frames"]]
    count = len(base)
    frames = base + [x + [FOURIER_AXIS] for x in base]

    def label(f, slot):
        NEED(g["charts"][slot] == f, "expanded word frame source is pinned")
        return f + flag(slot)*count

    program = []
    for old, step in zip(word["program"], g["contact_steps"], strict=True):
        op, r, *rest = old
        item = old[:]
        if op == "MOVE":
            _, f, h = step
            item[2], item[3] = label(f, live[r]), label(h, step[0])
            live[r] = step[0]
        elif op == "INIT":
            live[r] = step[0]
            item[-1] = label(rest[0], live[r])
        elif op == "CLEAR":
            item[-1] = label(rest[0], live[r])
            live[r] = -1
        elif op in ("ADD", "COPY"):
            peer, _, f = rest
            item[-1] = label(f, live[r])
            NEED(item[-1] == label(f, live[peer]), "full coframe verified at every scalar edge")
        elif op == "SCALE":
            item[-1] = label(rest[1], live[r])
        program.append(item)
    initial = [label(f, role) for role, f in enumerate(word["initial"])]
    final = [label(f, live[role]) for role, f in enumerate(word["final"])]
    for r, requested in adapters:
        f = word["final"][r] + requested*count
        NEED(f != final[r], "endpoint adapter is an actual rank-one tensor factor")
        program.append(["MOVE", r, final[r], f, False])
        final[r] = f
    return {**word, "frames": frames, "program": program, "initial": initial, "final": final}


def control():
    """Parallel arcs and a productive return can fund an otherwise paid edge."""
    a = [(1, 0, 2), (0, 1, 2), (1, 0, 3), (2, 1, 10), (2, 0, 4), (0, 3, 10)]
    val, reached = FLOW(4, a, 2, 3)
    NEED(val == 9 and reached == {1, 2}, "exact product-credit mincut control")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("caller", type=Path)
    parser.add_argument("whole", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--emit", type=Path, help="serialize the best constrained 10D candidate for binding")
    args = parser.parse_args()
    start, stop = perf_counter(), monotonic() + 50
    control()
    raw = gzip.decompress(args.word.read_bytes())
    NEED(sha256(raw).hexdigest() == NATIVE["WORD"], "source #7546 word hash")
    native = json.loads(raw)
    caller = json.loads(SOURCE["pin"](args.caller, SOURCE["CALLER"]))
    whole = json.loads(SOURCE["pin"](args.whole, SOURCE["WHOLE"]))
    g = graph(native)
    productive, type_b = helper_roles(native)
    NEED(Counter(len(native["frames"][native["final"][r]]) - len(native["frames"][native["initial"][r]]) for r in productive) ==
         Counter({int(r): k for r, k in whole["signed_profile"]["native_productive"].items()}), "all priced helpers match #7546")
    old_paid = Counter(r for _, _, r, _, _ in g["edges"])
    need_old = Counter({1: 3999, 2: 852, 3: 827, 4: 223, 5: 343, 6: 16, 7: 11, 8: 5})
    NEED(old_paid == need_old, "all 6276 original moves included")
    price = SOURCE["price_engine"]()
    nested = dict(helpers=True, fixed_owned=True, no_new_owned_ascent=True, nested=True, endpoint_adapters=True,
                  free_helper_input_prephase=False)
    signed = dict(helpers=True, fixed_owned=False, no_new_owned_ascent=False, nested=False, endpoint_adapters=True,
                  free_helper_input_prephase=False)
    constraints = {"nested_with_end_adapters": nested,
                   "signed_tensor_with_end_adapters": signed,
                   "nested_with_helper_boundary_gauges": {**nested, "free_helper_input_prephase": True},
                   "signed_tensor_with_helper_boundary_gauges": {**signed, "free_helper_input_prephase": True},
                   "signed_tensor_with_frozen_helpers_and_end_adapters": {**signed, "helpers": False},
                   "strict_no_end_adapters": {**signed, "endpoint_adapters": False}}
    outputs = {}
    for saving in (INCUMBENT, Fraction(".005"), Fraction(".0227")):
        NEED(monotonic() < stop, "complex cuts complete within 50 seconds")
        row = {k: solve_cut(native, g, type_b, saving, price, opts)[0] for k, opts in constraints.items()}
        cds = [caller_deltas(caller, stage, price, saving) for stage in range(caller["stages"])]
        p0 = whole["signed_profile"]["signed_paid"]
        t0 = whole["signed_profile"]["signed_productive"]
        for entry in row.values():
            if "changes" not in entry:
                continue
            d_paid, d_target = entry["paid_delta"], entry["target_delta"]
            invoice_t = Counter({int(r): n for r, n in t0.items()})
            invoice_p = Counter({int(r): n for r, n in p0.items()})
            invoice_p.update(d_paid)
            invoice_t.update(d_target)
            trial = []
            for data in cds:
                p, t = invoice_p.copy(), invoice_t.copy()
                p.update(data["caller_paid_delta"])
                t.update(data["caller_target_delta"])
                net = price.sub(price.moment(t, saving), price.moment(p, saving))
                up = Fraction(data["caller_headroom"][1]) - Fraction(entry["native_increment_certified_lower"])
                inc = price.sub(price.moment(data["caller_target_delta"], saving), price.moment(data["caller_paid_delta"], saving))
                raw_delta = price.sub(inc, price.sub(price.moment(d_paid, saving), price.moment(d_target, saving)))
                trial.append({"stage": data["stage"], "complete_margin": price.value(net), "delta": price.value(raw_delta),
                              "delta_certified_upper": str(up), "paid_count": p.total(), "productive_count": t.total()})
            entry["stages"] = trial
        outputs[str(saving)] = row
    if args.emit:
        result, chosen = solve_cut(native, g, type_b, INCUMBENT, price, nested)
        if chosen is not None:
            changed = expand_word(native, g, chosen, result["endpoint_adapters"])
            args.emit.write_text(json.dumps(changed, separators=(",", ":")) + "\n", encoding="utf-8")
    result = {"status": "PASS_TYPE_B_AUGMENTED_FRAME_CUT", "source_word_sha256": NATIVE["WORD"],
              "visited_frames": g["slots"], "scalar_contact_components": g["n"], "required_Type_B_output_roles": sorted(type_b),
              "full_signed_invoice_count": [sum(whole["signed_profile"][k].values()) for k in ("signed_paid", "signed_productive")],
              "scope": "one orthogonal external factor with exact old chronology, ordinary contacts and all starting flags fixed zero",
              "results": outputs}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(result["status"], f"{g['n']} separate components; {perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
