# SPDX-License-Identifier: Apache-2.0
"""Test rank-neutral reassignment of one native Fourier direction by a global cut."""

import argparse
from collections import Counter
from fractions import Fraction
import gzip
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
AXIS = run_path(str(HERE / "type_b_axis_cut.py"))
SOURCE, NATIVE, FLOW, NEED = (AXIS[name] for name in ("SOURCE", "NATIVE", "FLOW", "NEED"))
INCUMBENT = AXIS["INCUMBENT"]


def constrained_check(word, g, frame_spaces, axis, price, saving, allow_adapters):
    """Expand or shrink existing body directions with exactly one global coordinate exchange."""
    p, b = AXIS["helper_roles"](word)
    # The axis is one explicit norm-one direction of original ambient. A
    # chart containing it can replace it by the same new orthogonal axis.
    NEED(axis.bit_count() % 2 == 1 and axis not in set(word["ports"]), "off-head norm-one candidate")
    component_frame = {}
    for i, v in enumerate(g["components"]):
        component_frame[v] = g["charts"][i]
    contains = {j for j, f in component_frame.items() if axis in frame_spaces[f]}
    source, sink = g["n"], g["n"] + 1
    net = []
    inc = {}
    for r in range(1, 10):
        inc[r] = price.sub(price.power(r+2, saving), price.power(r, saving))
    # Non-containing eligible frames are physically identical under both
    # flags. Reset them to zero so an edge whose original f-membership
    # differs cannot receive a spurious extra charge.
    for a, h, r, i, own in g["edges"]:
        if a in contains and h in contains:
            n = inc[r][0]
            net += [(a, h, n), (h, a, n)]
    # For a helper with both endpoints containing f, swapping exactly one
    # endpoint adds two rank units. That would be a distinct two-axis family
    # of helper returns. The test preserves equality of these endpoint flags.
    equal = []
    fixed_zero = list(set(range(g["n"])) - contains)
    for r, (start, end) in enumerate(zip(g["starts"], g["ends"], strict=True)):
        if r in p:
            if start in contains and end in contains:
                equal += [(start, end), (end, start)]
            continue
        fixed_zero.append(start)
        if r not in b:
            fixed_zero.append(end)
    fixed_one, unresolved = [], []
    wanted = []
    for r in b:
        end = g["ends"][r]
        if end in contains:
            fixed_one.append(end)
            wanted.append((r, end))
        else:
            unresolved.append(r)
    if allow_adapters:
        rate = price.power(2, saving)[0]
        net += [(source, v, rate) for _, v in wanted]
        fixed_one = []
    inf = sum(c for _, _, c in net) + 1
    net += [(source, v, inf) for v in set(fixed_one)]
    net += [(v, sink, inf) for v in set(fixed_zero)]
    net += [(a, h, inf) for a, h in equal]
    value, chosen = FLOW(g["n"]+2, net, source, sink)
    if value >= inf or unresolved:
        return {"feasible": False, "target_without_f_at_final_boundary": unresolved,
                "terminal_flag_conflicts": len(set(fixed_one) & set(fixed_zero))}
    chosen.remove(source)
    return {"feasible": True, "axis_reassignments": len(chosen),
            "cost_lower": price.show((value, value))[0], "cost_estimate": price.value((value, value))[0],
            "moves_with_two_extra_axes": sum((a in chosen) != (h in chosen) for a, h, _, _, _ in g["edges"]
                                            if a in contains and h in contains),
            "remaining_adapters": sorted(r for r, v in wanted if v not in chosen)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    start = perf_counter()
    stop = monotonic() + 50
    raw = gzip.decompress(args.word.read_bytes())
    NEED(sha256(raw).hexdigest() == NATIVE["WORD"], "pinned native")
    word = json.loads(raw)
    g = AXIS["graph"](word)
    bases = [NATIVE["span"](u) for u in word["frames"]]
    central_b = [word["ports"][j] for j in range(len(word["ports"])) if j not in word["hosted"]["Dports"]]
    ranks = {}
    # Switching direction is rank-neutral precisely when it is present on
    # the high side and missing on the low side of an already-paid MOVE.
    # Enumerate all norm-one directions in the two-dimensional W_B complement.
    for f in range(1, 512):
        if f.bit_count()%2 == 0 or any((q & f).bit_count()%2 for q in central_b):
            continue
        NEED(monotonic() < stop, "exact coordinate replacement scan reached deadline")
        price = SOURCE["price_engine"]()
        out = {"fixed_native": constrained_check(word, g, bases, f, price, INCUMBENT, False),
               "with_end_adapters": constrained_check(word, g, bases, f, price, INCUMBENT, True)}
        ranks[f] = out
    NEED(set(ranks) == {331, 372}, "the only norm-one Type B preserving directions")
    result = {"status": "PASS_TYPE_B_ONE_AXIS_REPLACEMENT_SCREEN", "axes": ranks, "source_sha256": NATIVE["WORD"],
              "scope": "replace one existing canonical B body coordinate by a common fresh orthogonal coordinate; preserve all A outputs and helper pairs starting/ending with that axis"}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(result["status"], f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
