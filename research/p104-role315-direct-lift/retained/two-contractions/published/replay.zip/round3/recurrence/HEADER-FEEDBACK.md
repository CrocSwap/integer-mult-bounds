# BIT feedback with independent headers

An exact forward/inverse feedback word combines two commuting header
involutions into one cross-lane shear while restoring an arbitrary dirty
carrier. With the complete #7001 native inputs and charges it has negative
recursive margin at 0.005. A character bound also prices all schedules in
the specified alphabet, including arbitrary restored dirty inputs. Under that
bound even an optimistic body-bearing construction needs at least eight
forward native calls for one independent used header, or sixteen for two.

The source is canonical commit `e54523517d0f03e58352e647c403a5af3e525a57`.
The replay reconstructs the audited native paid and target histograms from
the literal tape of [#7001](https://github.com/CrocSwap/integer-mult-bounds/pull/7001).

## Model and header bound

The caller has finitely many independent binary root arrays, including
arbitrary dirty spectators. Grant free ordinary invertible scalar mixers.
For each formal header `q_j` impose `q_j²=1`; headers commute and
have no additional dependencies. A LOCAL applies `D_s(I+q_j N)` on its
two-dimensional active plane, with N a rank-one square-zero scalar
operator and `D_s` the body on seven fresh axes. Its formal inverse is
allowed with its full native cost and separate inverse helper fields. A
thin QUERY contributes a single `I+q_j N` with the same square-zero
condition. Body-only paid idles carry no header. Products or conjugations
by additional address maps that merge or identify distinct q labels are
outside the alphabet. An arbitrary scalar basis change within the root
space is included. The endpoint on each productive input is a diagonal
monomial in those formal variables, and each dirty spectator returns
unchanged with all other output columns independent of its value.

For any header label j set every other label and every body to one and
write `q_j=1+ε` over the dual numbers with `ε²=0`. Factoring out the
invertible nominal prefix at each occurrence leaves a derivative
`u_i v_i`, where `v_i u_i=0`. Inversion has the same first derivative,
since changing the sign has no effect in characteristic two. A caller
over this ring gives

```text
U_j V_j = E_j,
```

where E_j is the coordinate projector onto the `o_j` outputs containing
that header. Taking traces proves o_j is even. If the header occurs
on m_j constituents, then rank implies m_j ≥ o_j. At equality the two
matrices have rank m_j and their image and quotient are precisely the
image of E_j. Consequently `V_j U_j=I`, contradicting the zero
diagonal when o_j>0. The argument also follows from
`ker(I−V_j U_j)=V_j(im E_j)`, with no assumption on a fixed number
of restored catalysts. Thus `m_j≥o_j+1` for each used header. If an
ordinary row alias merges two dirty fields, its map is singular and it
does not satisfy the arbitrary-input contract.

Each native or thin pulse bears at most one formal header. Summing the
individual inequalities over the u used labels gives

```text
sum_j o_j − Q <= L − u ,
```

where L counts every native pulse and Q counts the thin pulses. All
coefficients are taken per port before multiplying by 111. This leaves
room for multiple labels in one output, because each occurrence is counted
with its own first-order projection. A pulse that is a joint product
`q_i q_j` is outside this count until it has a charged implementation.

Matching these individual character tests is not enough to prove an
operator identity. The replay uses a control adding the term
`(1+q_1)(1+q_2)x` to one returned lane. Each single-header specialization
accepts it, and the unspecialized polynomial exposes its four terms.

## Complete pricing implications

Put `H_r=r^(1−κ)`, and let `P_0,T_0` be the complete #7001 native paid
and helper credit moments, per native invocation. The following two body
models suffice for the numeric ceiling:

- With nonnegative formal body powers, each output carries each stage
  at most once. Grouped positive IDLE_ONE passes are charged in full.
  For any stage the number of derivative image columns equals the
  rank of the output stage projector by determinant degree. Columns
  therefore form a basis of that coordinate subspace. An idle with mask
  of size a has the same pulled-back image column at every stage in its
  mask. All its nonzero rows belong to a target carrying its whole
  mask. A nonzero minor matches those idle marks injectively to targets
  at each stage; each mark's assigned credit `H_7 k^(−κ)` with
  target body size k≥a is bounded by the charged idle contribution
  `H_7 a^(−κ)`. This is the earlier audit's injection applied after
  setting every header to 1. Its argument does not assume a single header.
- When inverse orientations are allowed and there are no external
  body-only idles, use independent Laurent variables D_s. The
  determinant tracks their signed exponents. With L_+ forward and
  L_- inverse natives, the total number of productive body incidences
  is `2(L_+−L_-)`, hence no more than `2L_+`. All output body powers
  have nonnegative exponent. This body argument gives no price exemption
  for inverse pulses. If they use the same helper channels as the earlier
  forward call, at most one of the two receives an independent helper
  credit. Even granting a fresh inverse helper inventory with the same
  invoice can only favor the relaxation. The source does not certify
  the physical inverse adapters or apply the first model's injection to
  signed, partially cancelling grouped idles.

The body credit after grouped idles is at most `2L H_7` per port in
the first model. The second model uses L_+ in that term. By concavity the
increment per header is at most 1, or at most `δ=H_8−H_7` if every
credited main receiving a header has at least one body. The native
helpers are already counted in T_0. A thin query costs 1, so
`δ sum o_j−Q <= δ(L−u)` for δ≤1, and similarly with δ=1.
The overall envelope for the first model is

```text
L [T_0 − P_0 + 111(2 H_7 + δ)] − 111 δ u .
```

Including inverse natives without external body-only idles adds
`L_- [T_0 − P_0 + 111 δ − 222 H_7]` to the envelope computed with
L_+. The bracket is negative at both tested savings, even when every
native helper has a fresh independent input. Thus the same reported
limits lower-bound L_+ in that model. They do not require physical
realizability of any optimistic target allocation.

| Saving | Per-forward-call margin cap with arbitrary roots | With a body on every header-bearing root |
|---:|---:|---:|
| 0.005 | 15.8676246657099 | 14.2059384513111 |
| 0.0227 | −94.7103720928230 | −102.0782323506313 |

These are outward interval upper endpoints before the per-label debit.
At 0.005 that debit forces the following minimum counts of forward native
stages. A lower count fails even in this favorable relaxation.

| Used independent labels | Arbitrary roots | All header-bearing roots have bodies |
|---:|---:|---:|
| 1 | 7 | 8 |
| 2 | 14 | 16 |

The count gate is necessary, with no claimed attainment. It cannot exclude
larger callers at 0.005. It excludes positive margin at 0.0227 for either of
the stated body models. Signed grouped idles combining different positive and
negative body shifts with monotone output masks are outside the priced bound.

## Exact dirty feedback construction

Use three active lanes x,y,z and one arbitrary untouched input. Set
`A=I+q_1 e_y e_x^T` and `B=I+q_2 e_z e_y^T`. The chronological word
`A,B,A,B` gives

```text
(x,y,z) -> (x,y,z+q_1 q_2 x).
```

It is a commutator because A²=B²=I. The z update depends on the dirty
value y twice and cancels it exactly, so y restores for every initial y.

To instantiate algebraic natives, assign forward LOCALs their independent
bodies D₁ and D₂, then use the inverse LOCALs in the same order. The body
of each LOCAL is also applied to its third active spectator by one paid
rank-seven operation. This makes each body factor uniform on the three
active lanes so it commutes with both A and B. The forward and inverse
body powers cancel, and the complete finite formal result is the shear
above even when D₁,D₂ are unrestricted commuting Laurent variables.
The fourth arbitrary wire is never read or changed. Omitting one body
pass, dropping one inverse, or moving both inverses to the opposite
order changes the endpoint and is rejected.

There are four complete native invocations and 444 additional whole
rank-seven passes across 111 ports. The only new endpoint is an
off-diagonal shear. It cannot receive ordinary positive diagonal target
credit. Granting it one hypothetical rank-two credit per port and
granting every native helper a separate productive input still gives an
outward interval `[-9393.0191283226038,-9393.0191283226037]` at
κ=0.005. This figure is a generous upper margin. No dirty payload is
silently initialized, surrendered recursive calls are not erased, and
the reverse body charges are counted. Finite routing, storage, precision,
and compiler application remain additional obligations. This word is
an exact algebraic transfer control, not an admitted supplier or scale
improvement.

## Reproduction

```powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
& $py -I -B -S .\work\round3\recurrence\verify_header_feedback.py C:\Users\cuchu\Documents\Codex\integer-mult-bounds
```

The verifier imports the prior isolated `work/recurrence` source verifier
for pinned tapes, exact histograms, and directed integer arithmetic.
The command writes its JSON result to stdout. CPython 3.13.14 syntax
and tabnanny passed. Normal and optimized exact replays are bounded at
45 seconds, using small serial CPU workers. No GPU computation was used.
