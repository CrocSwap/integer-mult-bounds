"""Exact prices, independent-header interactions, and a dirty feedback word."""

import argparse
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


previous = Path(__file__).resolve().parents[2] / "recurrence" / "verify_bit_caller_bound.py"
spec = spec_from_file_location("previous_bit_research", previous)
stock = module_from_spec(spec)
spec.loader.exec_module(stock)
need = stock.need


G = 0b01
H = 0b10
D1 = (1, 0)
D2 = (0, 1)
ZERO = (0, 0)


def transform(row, header, body, direction):
    return {
        (col, bits ^ header, p + direction * body[0], q + direction * body[1])
        for col, bits, p, q in row
    }


def replay(word, dimension):
    rows = [{(i, 0, 0, 0)} for i in range(dimension)]
    for opcode, source, destination, header, body, direction in word:
        if opcode == "NATIVE":
            rows[destination] ^= transform(rows[source], header, ZERO, 1)
            for i in (source, destination):
                rows[i] = transform(rows[i], 0, body, direction)
        elif opcode == "BODY":
            rows[destination] = transform(rows[destination], 0, body, direction)
        elif opcode == "THIN":
            rows[destination] ^= transform(rows[source], header, ZERO, 1)
        else:
            raise ValueError(f"Unknown operation {opcode}")
    return rows


def echo(a, b):
    # D1 and D2 apply on different active pairs. Pay the body's unused
    # coordinate parity on the third lane at every occurrence to make
    # its physical body global. Those paid slots allow chronological
    # integration of actual LOCAL+inverse without an illegal D/q commute.
    return [
        ["NATIVE", 0, 1, a, D1, 1],
        ["BODY", 0, 2, 0, D1, 1],
        ["NATIVE", 1, 2, b, D2, 1],
        ["BODY", 0, 0, 0, D2, 1],
        ["NATIVE", 0, 1, a, D1, -1],
        ["BODY", 0, 2, 0, D1, -1],
        ["NATIVE", 1, 2, b, D2, -1],
        ["BODY", 0, 0, 0, D2, -1],
    ]


def rows_json(rows):
    return [sorted(row) for row in rows]


def physical_feedback(native_paid, native_target):
    word = echo(G, H)
    observed = replay(word, 4)
    needed = [{(i, 0, 0, 0)} for i in range(4)]
    needed[2].add((0, G ^ H, 0, 0))
    need(observed == needed, "Independent signed-body echo did not restore")
    dropped_body = word[:]
    dropped_body.pop(1)
    need(replay(dropped_body, 4) != needed, "Omitted body pass was invisible")
    dropped_inverse = word[:]
    dropped_inverse.pop(4)
    need(replay(dropped_inverse, 4) != needed, "Omitted inverse was invisible")
    swapped_closures = word[:4] + word[6:8] + word[4:6]
    need(replay(swapped_closures, 4) != needed, "Commuting native calls would lose header")

    # Formal four-lane exact target is a cross-lane shear, not a
    # standalone whole reflector. A deliberately favorable product
    # allowance is its two-header shift H2 for each of 111 port pairs.
    optimistic = Counter({2: 111})
    cost = Counter({r: n * 4 for r, n in native_paid.items()})
    cost[7] += 444
    for r, n in native_target.items():
        optimistic[r] += n * 4
    optimistic.subtract(cost)
    margin_test = stock.moment(optimistic, 1, 200)
    need(margin_test[1] < 0, "Unexpected favorable echo")
    return dict(word=word, finite_output_monomials=rows_json(observed),
                generous_extra_native_target={2: 111},
                body_passes_rank7=444,
                independent_native_invocations=4,
                optimistic_raw_margin_005=stock.format_bounds(margin_test))


def rank_lower_bound_example():
    # Each first-order character misses a dependence requiring both.
    first = [{(i, 0, 0, 0)} for i in range(4)]
    mutant = first[:]
    mutant[2] = first[2] | {(0, b, 0, 0) for b in (0, G, H, G ^ H)}
    need(mutant != first, "Typed higher-order negative control")
    for character in (G, H):
        specialized = set()
        for col, bits, x, y in mutant[2]:
            specialized ^= {(col, bits & character, x, y)}
        need(specialized == first[2], "Single-header character detected joint defect")
    return dict(independent_header_labels=[G, H],
                invisible_joint_defect=rows_json(mutant))


def ceil_by_intervals(numerator, denominator):
    n = numerator[0] // denominator[1] + 1
    need((n - 1) * denominator[1] < numerator[0], "Underdetermined lower threshold")
    need(n * denominator[0] > numerator[1], "Underdetermined upper threshold")
    return n


def one_price(native_paid, native_target, key, saving_num, saving_den):
    signed = native_target.copy()
    signed.subtract(native_paid)
    signed[7] += 222
    body = stock.moment(signed, saving_num, saving_den)
    arbitrary = stock.add(body, (111 * stock.SCALE, 111 * stock.SCALE))
    marginal = stock.add(
        stock.price(8, saving_num, saving_den),
        stock.scaled(stock.price(7, saving_num, saving_den), -1),
    )
    nonempty = stock.add(body, stock.scaled(marginal, 111))
    inverse_fee = stock.add(body, stock.scaled(stock.price(7, saving_num, saving_den), -444))
    inverse_fee = stock.add(inverse_fee, (111 * stock.SCALE, 111 * stock.SCALE))
    need(inverse_fee[1] < 0, "Inverse native lost nonpositive margin control")
    out = dict(saving=key, per_native_margin_arbitrary_roots=stock.format_bounds(arbitrary),
               per_native_margin_all_body_bearing=stock.format_bounds(nonempty),
               max_header_tariff_on_nonempty_root=stock.format_bounds(marginal),
               max_additive_inverse_margin_without_idles=stock.format_bounds(inverse_fee))
    if key == "0.005":
        base = (111 * stock.SCALE, 111 * stock.SCALE)
        head = stock.scaled(marginal, 111)
        out["minimum_forward_natives_for_arbitrary_roots"] = [
            ceil_by_intervals(stock.scaled(base, j), arbitrary) for j in (1, 2)
        ]
        out["minimum_forward_natives_for_body_bearing_roots"] = [
            ceil_by_intervals(stock.scaled(head, j), nonempty) for j in (1, 2)
        ]
    else:
        need(arbitrary[1] < 0 and nonempty[1] < 0, "Target signed ceiling failed")
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    args = parser.parse_args()
    _, ph, th, _, _ = stock.verify_sources(args.repo)
    out = dict(git_head=stock.HEAD,
               finite_feedback=physical_feedback(ph, th),
               independent_label_control=rank_lower_bound_example(),
               ledgers=[one_price(ph, th, "0.005", 1, 200),
                        one_price(ph, th, "0.0227", 227, 10000)])
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
