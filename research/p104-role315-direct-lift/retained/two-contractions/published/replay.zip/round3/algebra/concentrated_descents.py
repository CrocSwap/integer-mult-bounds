"""Exact native-frame realization of the concentrated nine-descent profile."""

from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
from nine_cut_geometry import fitting_calibration, hamming_roots
from permute_head_frames import dot, require
from staged_two_way_routes import binary_rank, xor_selection
sys.path.insert(0, str(here.parents[1] / "algebra"))
from scan_bit_fixed_graph import supported_interval
from scan_bit_move_runs import load_word


def ordered_pairs(c):
    counts = Counter()
    example = {}

    def extend(pairs, used, blocked):
        counts[len(pairs)] += 1
        example[len(pairs)] = pairs
        for s, row in enumerate(c):
            if used >> s & 1:
                continue
            available = row & ~(used | blocked | (1 << s))
            while available:
                bit = available & -available
                available ^= bit
                r = bit.bit_length() - 1
                extend(pairs + [(s, r)], used | bit | (1 << s), blocked | row)

    extend([], 0, 0)
    require(counts == {0: 1, 1: 44, 2: 448, 3: 816, 4: 144}, "pair search changed")
    return counts, example[4]


def phase_bases(heads, missing):
    c = [sum(1 << j for j, t in enumerate(missing) if i == j or not dot(h, t))
         for i, h in enumerate(missing)]
    counts, pairs = ordered_pairs(c)
    s = [1 << a for a, _ in pairs]
    r = [1 << b for _, b in pairs]
    spare = next(i for i in range(9) if all(i not in pair for pair in pairs))
    s.append(1 << spare)
    for mask in range(1, 512):
        a = xor_selection(c, mask)
        if all(not (a & read) for read in r) and binary_rank(s + [mask]) > len(s):
            s.append(mask)
        if len(s) == 9:
            break
    require(len(s) == 9, "annihilator did not complete the source basis")
    row = [xor_selection(c, source) for source in s]
    directions = {sum(((a & mask).bit_count() % 2) << i for i, a in enumerate(row)): mask
                  for mask in range(512)}
    require(len(directions) == 512, "singular completed dual basis")
    r.extend(directions[1 << i] for i in range(4, 9))
    t = [sum(((a & b).bit_count() % 2) << j for j, b in enumerate(r)) ^ (1 << i)
         for i, a in enumerate(row)]
    require(all(x >> i == 0 for i, x in enumerate(t)), "new dual factor is not chronological")
    cap = [sum(1 << i for i, v in enumerate(heads) if not dot(p, v)) for p in missing]
    sends = [xor_selection(cap, a) for a in s]
    reads = [xor_selection(cap, a) for a in r]
    carried = []
    for i, prev in enumerate(t):
        carried.append(sends[i] ^ xor_selection(carried, prev))
    for i, p in enumerate(heads):
        take = sum(((inside >> i) & 1) << j for j, inside in enumerate(reads))
        expect = sum(1 << j for j, q in enumerate(heads) if i == j or not dot(p, q))
        require(xor_selection(carried, take) == expect, "concentrated dual factor differs from B0")
    return counts, pairs, spare, s, r, t, sends, reads


def program(word):
    heads, puncture, *_ = fitting_calibration(word)
    roots = hamming_roots()
    missing = [roots[i] for i in puncture]
    counts, pairs, spare, s, r, t, sends, reads = phase_bases(heads, missing)
    frames = {}
    for k, f in word["frames"].items():
        b = [tuple(map(Fraction, v)) for v in f["B"]]
        a = [tuple(map(Fraction, v)) for v in f["A"]]
        frames[int(k)] = (b, a)
    fresh = max(frames) + 1
    for j, normal in enumerate(missing):
        pivot = next(i for i, val in enumerate(normal) if val)
        complement = [tuple(Fraction(i == k) -
                            Fraction(int(i == pivot) * normal[k], normal[pivot])
                            for i in range(8)) for k in range(8) if k != pivot]
        frames[fresh + 2*j] = (complement, [normal])
        frames[fresh + 2*j + 1] = ([normal], complement)
    n = len(heads)
    zero, full = word["start"][n], word["final"][0]
    a = word["start"][:n]
    b = word["final"][n:2*n]
    upper = [fresh + 2*j for j, _ in pairs] + [fresh + 2*spare] + [full]*4
    lower = [fresh + 2*j + 1 for _, j in pairs] + [zero]*5
    receiver = list(range(2*n, 3*n))
    carrier = list(range(3*n, 3*n + 9))
    scratch = carrier[-1] + 1
    steps = []

    def copy(dst, stop, src, start):
        steps.extend([("INIT", scratch, start), ("ADD", scratch, src, start)])
        if start != stop:
            steps.append(("MOVE", scratch, start, stop))
        steps.extend([("ADD", dst, scratch, stop), ("CLEAR", scratch, stop)])

    for i in range(n):
        steps.append(("INIT", receiver[i], b[i]))
    # Monotone complement of the exceptional transfer at all off-diagonal
    # contacts. These literal arcs deliberately keep the complete cost.
    for i, j in product(range(n), repeat=2):
        if not dot(heads[i], heads[j]):
            copy(receiver[i], b[i], j, a[j])
    for j, c in enumerate(carrier):
        start, stop = upper[j], lower[j]
        steps.append(("INIT", c, start))
        for i in range(n):
            if sends[j] >> i & 1:
                copy(c, start, i, a[i])
        for i in range(j):
            if t[j] >> i & 1:
                copy(c, start, carrier[i], lower[i])
        steps.append(("MOVE", c, start, stop))
    for j, c in enumerate(carrier):
        for i in range(n):
            if reads[j] >> i & 1:
                copy(receiver[i], b[i], c, lower[j])
        steps.append(("CLEAR", c, lower[j]))
    for i in range(n):
        steps.extend([("MOVE", n+i, zero, full), ("SWAP", i, n+i),
                      ("SWAP", n+i, receiver[i]), ("CLEAR", receiver[i], a[i])])
    return (frames, steps, a + [zero]*n, [full]*n + b, scratch + 1,
            {"ordered_pair_counts": dict(counts), "reduced_pairs": pairs, "fifth_source": spare,
             "source_coefficients": s, "reader_coefficients": r, "direct_T": t})


def replay(frames, steps, start, finish, slots):
    n = len(start)
    at = start + [None]*(slots - n)
    rows = [1 << i for i in range(n)] + [None]*(slots - n)
    moves, downs, ops = Counter(), Counter(), Counter()
    live = peak = nonzero = 0

    @lru_cache(None)
    def included(source, destination):
        return all(not dot(v, w) for v, w in product(frames[source][0], frames[destination][1]))

    for name, i, *args in steps:
        ops[name] += 1
        if name == "INIT":
            require(i >= n and at[i] is None, "invalid owned birth")
            at[i], rows[i] = args[0], 0
            live += 1
            peak = max(peak, live)
        elif name == "CLEAR":
            require(i >= n and at[i] == args[0], "wrong owned retirement")
            nonzero += bool(rows[i])
            at[i] = rows[i] = None
            live -= 1
        elif name == "MOVE":
            a, b = args
            da, db = len(frames[a][0]), len(frames[b][0])
            require(at[i] == a and da != db and (included(a, b) if da < db else included(b, a)),
                    "wrong or nonnested movement")
            if da > db:
                downs[da - db] += 1
            moves[abs(da - db)] += 1
            at[i] = b
        elif name == "ADD":
            j, frame = args
            require(i != j and at[i] == at[j] == frame, "unequal ADD contact")
            rows[i] ^= rows[j]
        elif name == "SWAP":
            j, = args
            require(i != j and None not in (at[i], at[j]), "dead SWAP role")
            at[i], at[j] = at[j], at[i]
            rows[i], rows[j] = rows[j], rows[i]
        else:
            raise ValueError(name)
    require(at == finish + [None]*(slots - n) and live == 0, "wrong final frames or live stock")
    expected = [1 << ((i + n//2) % n) for i in range(n)]
    require(rows == expected + [None]*(slots - n), "wrong arbitrary-input two-way output")
    reverse_coefficients = 0
    for output, expected_row in enumerate(expected):
        dual = 1 << output
        for name, i, *args in reversed(steps):
            if name == "ADD" and dual >> i & 1:
                dual ^= 1 << args[0]
            elif name == "SWAP":
                j = args[0]
                if (dual >> i ^ dual >> j) & 1:
                    dual ^= (1 << i) | (1 << j)
            elif name == "INIT":
                dual &= ~(1 << i)
            elif name == "CLEAR":
                require(not (dual >> i & 1), "reverse pass uses a retired owned role")
        require(dual == expected_row, "reverse arbitrary-input endpoint disagrees")
        reverse_coefficients += n
    require(downs == {6: 4, 7: 1, 8: 4}, "unexpected descent profile")
    tariffs = []
    for s in (".005", ".0227"):
        h = [None] + [supported_interval(i, Fraction(s)) for i in range(1, 9)]
        cost = [sum(c*h[r][k] for r, c in moves.items()) for k in (0, 1)]
        target = [n*b for b in h[8]]
        shortfall = [cost[0] - target[1], cost[1] - target[0]]
        require(shortfall[0] > 0, "all-job control was unexpectedly profitable")
        tariffs.append({"s": s, "paid_minus_generous_targets_2pow80": shortfall,
                        "paid_minus_generous_targets_lower": shortfall[0]/2**80})
    return {"paid_moves": dict(sorted(moves.items())), "descents": dict(sorted(downs.items())),
            "clear_nonzero": nonzero, "operation_counts": dict(ops), "owned_peak": peak,
            "exact_forward_public_coefficients": n*n,
            "exact_reverse_public_coefficients": reverse_coefficients,
            "generous_productive_target_profile": {8: n}, "tariff": tariffs}


if __name__ == "__main__":
    *input_data, geometry = program(load_word())
    summary = replay(*input_data)
    print(json.dumps({"status": "PASS_CONCENTRATED_DESCENT_TWO_WAY_CONTROL",
                      "geometry": geometry, "receipt": summary}, indent=2))
