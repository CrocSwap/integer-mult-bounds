"""Source-bound calibration for chronological nine-descent rank rigidity."""

from collections import Counter
from fractions import Fraction
import gzip
import hashlib
from itertools import combinations, product
import json
from math import gcd
from pathlib import Path
import sys
from types import ModuleType

sys.path.insert(0, str(Path(__file__).resolve().parent))
from permute_head_frames import head_geometry, dot, require
from staged_two_way_routes import binary_rank, dirty_dependency_cut, suffix_sensitivity
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "algebra"))
from scan_bit_move_runs import basis, load_word
from scan_bit_fixed_graph import supported_interval


def primitive(v):
    vals = []
    denominator = 1
    for x in v:
        denominator *= x.denominator // gcd(x.denominator, denominator)
    for x in v:
        vals.append(x.numerator * (denominator // x.denominator))
    g = 0
    for x in vals:
        g = gcd(g, x)
    first = next(x for x in vals if x)
    return tuple(x // g if first > 0 else -x // g for x in vals)


def hamming_roots():
    rows = [int(x, 2) for x in ("11110000", "00111100", "00001111", "01010101")]
    words = {0}
    for pattern in rows:
        words |= {w ^ pattern for w in words}
    bases = [tuple((x >> j) & 1 for j in range(7, -1, -1))
             for x in words if x.bit_count() == 4]
    result = [tuple(2 * int(i == j) for j in range(8)) for i in range(8)]
    for pattern in sorted(bases):
        indices = [i for i, x in enumerate(pattern) if x]
        for signs in product((1, -1), repeat=3):
            row = list(pattern)
            for i, s in zip(indices[1:], signs):
                row[i] = s
            result.append(tuple(row))
    return result


def normalized_roots(first):
    from fractions import Fraction as Q
    return {primitive(tuple(map(Q, row))): i for i, row in enumerate(first)}


def fitting_calibration(word):
    heads, _, _ = head_geometry(word)
    arch = hamming_roots()
    order = normalized_roots(arch)
    current = [order.get(primitive(x), -1) for x in heads]
    require(-1 not in current and len(set(current)) == 111, "P111 source and canonical roots disagree")
    puncture = sorted(set(range(120)) - set(current))
    archived = [39, 52, 57, 71, 76, 78, 103, 109, 114]
    same_puncture = puncture == archived
    missing = [arch[i] for i in puncture]
    a = [arch[j] for j in archived]
    missing_graph = [{j for j, v in enumerate(missing) if i != j and not dot(u, v)}
                     for i, u in enumerate(missing)]
    archive_graph = [{j for j, v in enumerate(a) if i != j and not dot(u, v)}
                     for i, u in enumerate(a)]
    archive_degree = sorted(map(len, archive_graph))
    actual_degree = sorted(map(len, missing_graph))
    return heads, puncture, same_puncture, current, archive_degree, actual_degree


def verified_rank_floor_fixture(heads):
    base = Path(__file__).resolve().with_name("source")
    receipt = (base / "P111-VERIFIED.json").read_bytes()
    prior_geometry = (base / "bitE8mut-p111-tuned.json.gz").read_bytes()
    require(hashlib.sha256(receipt).hexdigest()
            == "c20eb805031f69fea42c6613e58be58b336a96d1279a143346b26262b774250e",
            "induced 14-vertex witness changed")
    require(hashlib.sha256(prior_geometry).hexdigest()
            == "e3e301e62bc2b41dbf1ceac0acf3d35824ebeab1848c5a2142d4577b109da52f",
            "old P111 chart binding changed")
    before = json.loads(gzip.decompress(prior_geometry))["lines"]
    normalize = normalized_roots(heads)
    mapping = [normalize.get(primitive(tuple(map(Fraction, r))), -1) for r in before]
    require(-1 not in mapping and len(set(mapping)) == 111,
            "older all-field floor did not transfer to actual #7001 by the identity isometry")
    prior = json.loads(receipt)
    cliques = [[mapping[old] for old in row] for row in prior["cliques"]]
    odd = [i for i, n in Counter(j for row in cliques for j in row).items() if n % 2]
    require(sorted(odd) == sorted(mapping[old] for old in prior["odd_incidence"]),
            "incorrect mapped incidence")
    for row in cliques + [odd]:
        require(all(i == j or dot(heads[i], heads[j]) != 0 for i, j in product(row, repeat=2)),
                "mapped nonorthogonality clique fails")
    return {"literal_port_permutation": mapping, "mapped_eight_cliques": cliques,
            "odd_incidence_four_clique": sorted(odd), "rank_floor_F2": 9}


def check_exact_recorded_rigidity(heads):
    source = Path(__file__).resolve().with_name("source")
    files = {
        "p111_lines.json": "2b492989fd574f557533e237267bc6693d6917ce5b32e2ccdad7fa9de81a07f9",
        "results.jsonl": "d7115712b22dca41e37813ac1236a91c198210b089651f0ec5cced78f6bdf296",
        "rigid.py": "378f20d152d1c4c53c9bd528bd2e661fa75b68bbeaa1fecaa498af4acda9b0f9",
    }
    for name, digest in files.items():
        require(hashlib.sha256((source / name).read_bytes()).hexdigest() == digest,
                f"matching-puncture rigidity input {name} changed")
    lines = json.loads((source / "p111_lines.json").read_bytes())["lines"]
    selected = normalized_roots(heads)
    mapping = [selected.get(primitive(tuple(map(Fraction, row))), -1) for row in lines]
    require(-1 not in mapping and len(set(mapping)) == len(heads) == len(lines),
            "recorded general rigidity uses a different head set")
    dots = [[dot(a, b) for b in lines] for a in lines]
    records = [json.loads(row) for row in (source / "results.jsonl").read_text().splitlines()]
    orthogonal = lambda i, j: dots[i][j] == 0
    # Feed the isolated, unmodified upstream CNF constructor the pinned
    # geometry. The unrelated unit definitions are never called for P111.
    original_units = sys.modules.get("units")
    original_path = sys.path.copy()
    stub = ModuleType("units")
    sys.modules["units"] = stub
    rigid = ModuleType("pinned_p111_rigid")
    rigid.__file__ = str(source / "rigid.py")
    try:
        exec(compile((source / "rigid.py").read_bytes(), rigid.__file__, "exec"),
             rigid.__dict__)
    finally:
        sys.path[:] = original_path
        if original_units is None:
            del sys.modules["units"]
        else:
            sys.modules["units"] = original_units
    check = []
    for sym in (True, False):
        tag = "sym" if sym else "gen"
        rec = next(r for r in records if r["name"] == f"P111_{tag}_h9_alt")
        require(all(not orthogonal(i, j) for i, j in product(rec["gauge"], repeat=2)),
                "recorded gauge is not a nonorthogonality clique")
        nv, clauses, info, *_ = rigid.build("P111", 9, sym, "alt", rec["gauge"],
                                           V=list(range(111)), orthf=orthogonal)
        digest = rigid.sha(rigid.dimacs(nv, clauses))
        require((nv, info["ncls"], info["orth"], digest) ==
                (rec["nv"], rec["ncls"], rec["orth"], rec["cnf_sha256"]),
                "matching-puncture CNF did not reproduce")
        check.append({"model": tag, "variables": nv, "clauses": info["ncls"],
                      "formula_sha256": digest, "recorded_status": rec["status"],
                      "recorded_drat_status": rec["drat"], "local_drat_replay": False})
    return {"head_lines_match": len(mapping), "exact_port_order": mapping == list(range(111)),
            "verified_formula_bindings": check}


def codewords(heads):
    rows = [sum(1 << j for j, q in enumerate(heads) if i == j or dot(p, q) == 0)
            for i, p in enumerate(heads)]
    code = {0}
    for row in rows:
        if row not in code:
            code |= {t ^ row for t in code}
    require(len(code) == 512 and binary_rank(rows) == 9, "wrong selected B0")
    return code


def support_dim(code, heads):
    out = {}
    for row in code:
        if not row:
            continue
        v = [heads[i] for i in range(111) if row >> i & 1]
        out[row] = len(basis(v))
    return out


def canonical_hyperplane_basis(heads, puncture, code):
    roots = hamming_roots()
    missing = [roots[i] for i in puncture]
    within = []
    for r in missing:
        selector = sum(1 << i for i, q in enumerate(heads) if not dot(r, q))
        require(code.get(selector) == 7, "missing-line cap does not have support rank seven")
        sources = [h for i, h in enumerate(heads) if selector >> i & 1]
        require(all(dot(r, v) == 0 for v in sources),
                "a reduced codeword span does not lie in missing-line cap")
        within.append(selector)
    require(binary_rank(within) == 9, "nine reduced vectors are not a code basis")
    want = {x for x, rank in code.items() if rank == 7}
    require(set(within) == want, "reduced support cap types not reconstructed")
    c = [sum(1 << j for j, t in enumerate(missing) if i == j or not dot(h, t))
         for i, h in enumerate(missing)]
    require(binary_rank(c) == 9, "puncture Gram matrix not invertible")
    wrows = [sum(1 << j for j, h in enumerate(missing) if not dot(h, q)) for q in heads]
    # RREF [C|I] and literal C^-1 bilinear fit on 12,321 ordered pairs.
    a = [row | (1 << (i + 9)) for i, row in enumerate(c)]
    for j in range(9):
        ix = next(i for i in range(j, 9) if a[i] >> j & 1)
        a[j], a[ix] = a[ix], a[j]
        for i in range(9):
            if i != j and a[i] >> j & 1:
                a[i] ^= a[j]
    inv = [x >> 9 for x in a]
    from staged_two_way_routes import xor_selection
    for i, r in enumerate(wrows):
        tmp = xor_selection(inv, r)
        for j, s in enumerate(wrows):
            expect = int(i == j or not dot(heads[i], heads[j]))
            require((tmp & s).bit_count() % 2 == expect, "actual canonical block pairing mismatch")
    cliques = [sum(all(c[i] >> j & 1 for i, j in combinations(g, 2))
                   for g in combinations(range(9), k)) for k in range(1, 10)]
    require(cliques == [9, 22, 16, 2, 0, 0, 0, 0, 0], "puncture orthogonal cliques changed")
    return {"rank7_basis_vectors": len(within), "puncture_diagonal_ones": 9,
            "canonical_bilinear_pairs": len(wrows)**2, "C_rows": c,
            "puncture_orthogonal_clique_census": cliques}


def frame_binding(word, out):
    _, cuts = dirty_dependency_cut(word)
    last, _ = suffix_sensitivity(word, cuts, cut_exceptions=True)
    counts = Counter()
    for j, _, r, s in cuts.values():
        t = sum((int(x >> j & 1) << i) for i, x in enumerate(last))
        sd = out[s]
        td = out[t]
        counts[(sd, td, r)] += 1
    return dict((str(k), v) for k, v in sorted(counts.items()))


def rank_budget(heads, code):
    reduced = [row for row, dr in code.items() if dr == 7]
    for s, r in product(reduced, repeat=2):
        # If both conditions are met, the minimum nested descent is
        # 6 iff the two codimension-one source and reader flats have
        # orthogonal normals. This direct bilinear computation does
        # not use the puncture order or label factor presentation.
        a = basis([h for i, h in enumerate(heads) if s >> i & 1])
        b = basis([h for i, h in enumerate(heads) if r >> i & 1])
        require(len(basis([[dot(x, y) for y in b] for x in a])) >= 6,
                "pairing rank less than six")
    return len(reduced)**2


def descents_tariff():
    profiles = []
    for six in range(10):
        for seven in range(10 - six):
            eight = 9 - six - seven
            if 6 * six + 7 * seven + 8 * eight >= 63:
                profiles.append((six, seven, eight))
    caps = []
    for value in (".005", ".0227"):
        exp = Fraction(value)
        h = [supported_interval(k, exp) for k in (6, 7, 8)]
        interval = [(sum(n * a[0] for n, a in zip(hist, h)),
                     sum(n * a[1] for n, a in zip(hist, h))) for hist in profiles]
        i = profiles.index((4, 1, 4))
        require(interval[i][1] < min(lo for j, (lo, hi) in enumerate(interval) if j != i),
                "wrong concentrated mass profile")
        source = [9 * a for a in h[1]]
        caps.append({"s": value,
                     "relaxed_min_cost_2pow80": interval[i],
                     "source_9H7_2pow80": source,
                     "largest_possible_saving_2pow80": [source[0] - interval[i][1],
                                                        source[1] - interval[i][0]],
                     "saving_upper_display": (source[1] - interval[i][0]) / 2**80})
    return {"number_of_integer_profiles": len(profiles), "best_relaxed_profile": [4, 1, 4],
            "ordered_ranks": [6, 7, 8], "rows": caps}


def lower_triangular_saturation_control():
    # In any temporal chain, a nonzero later edge from low to high
    # is possible for an orthogonal pair of codimension-one normals.
    # A transitive reach along consecutive edges may invalidate the
    # usual static basis counting proof. Test a literal 3x3 factor.
    T = [0, 0b001, 0b010]
    inverse = [1, 2, 4]
    for i, rows in enumerate(T):
        for j in range(i):
            if rows >> j & 1:
                inverse[i] ^= inverse[j]
    require(inverse == [1, 3, 7], "triangular transfer failed")
    p = [0, 0, 0]
    for i, row in enumerate(inverse):
        p[i] = row ^ (1 << i)
    require(p[2] >> 0 & 1 and not (T[2] >> 0 & 1), "transitive correction was omitted")
    return {"direct_transfer": T, "cumulative_transfer": inverse}


def main():
    word = load_word()
    heads, puncture, binding, order, prev_degree, after_degree = fitting_calibration(word)
    code = codewords(heads)
    ranks = support_dim(code, heads)
    h = Counter(ranks.values())
    require(h == {7: 9, 8: 502}, "unexpected minimum-label support spans")
    report = {
        "status": "PASS_NINE_CUT_GEOMETRY_BASE",
        "canonical_heads_bound": len(heads),
        "puncture_in_archived_sorted_order": puncture,
        "archive_exact_match": binding,
        "puncture_orthogonal_degrees": after_degree,
        "archived_puncture_orthogonal_degrees": prev_degree,
        "selected_order_to_archived": order,
        "old_selected_P111_block_rank_witness_transfer": verified_rank_floor_fixture(heads),
        "matching_puncture_rank_nine_rigidity": check_exact_recorded_rigidity(heads),
        "canonical_decoder_nonzero_support_ranks": dict(sorted(h.items())),
        "canonical_dual_basis_binding": canonical_hyperplane_basis(heads, puncture, ranks),
        "phase_descent_source_reader_paid_dims": frame_binding(word, ranks),
        "all_rank_seven_pairings_checked": rank_budget(heads, ranks),
        "temporal_factor_control": lower_triangular_saturation_control(),
        "tariff_fence": descents_tariff(),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
