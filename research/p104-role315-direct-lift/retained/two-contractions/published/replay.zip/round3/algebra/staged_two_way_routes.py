"""Proof-oriented causal cut and exact two-way transit geometry tests."""

from collections import Counter
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from permute_head_frames import head_geometry, dot, require
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "algebra"))
from scan_bit_move_runs import load_word


def is_descending(a, b, dim):
    return dim[a] > dim[b]


def dirty_dependency_cut(word):
    n = word["public"]
    dims = {int(a): f["dim"] for a, f in word["frames"].items()}
    rows = [1 << i for i in range(n)] + [None] * word["owned_fields"]
    after_no_descent = rows.copy()
    descriptor = {}
    for i, action in enumerate(word["program"]):
        op, field, *rest = action
        if op == "ADD":
            source = rest[0]
            rows[field] ^= rows[source]
            after_no_descent[field] ^= after_no_descent[source]
        elif op == "SWAP":
            source = rest[0]
            rows[field], rows[source] = rows[source], rows[field]
            after_no_descent[field], after_no_descent[source] = (
                after_no_descent[source], after_no_descent[field])
        elif op == "INIT":
            require(rows[field] is None, "owned spawn collision")
            rows[field] = after_no_descent[field] = 0
        elif op == "CLEAR":
            require(rows[field] is not None, "clear absent owned field")
            rows[field] = after_no_descent[field] = None
        elif op == "MOVE":
            # At the first descending cut remove its whole scalar coefficient
            # row from monotone paths only. Further descents are excluded in
            # the prefix of later one-edge correction factors, not the suffix.
            a, b = rest
            if is_descending(a, b, dims):
                j = len(descriptor)
                x_mask = after_no_descent[field] & ((1 << 111) - 1)
                descriptor[i] = (j, field, dims[a] - dims[b], x_mask)
                after_no_descent[field] = 0
        else:
            raise ValueError(op)
    heads, _, _ = head_geometry(word)
    mat = [rows[i + 111] & ((1 << 111) - 1) for i in range(111)]
    without = [after_no_descent[i + 111] & ((1 << 111) - 1) for i in range(111)]
    require(mat == [1 << i for i in range(111)], "selected native scalar debit changed")
    finish = [rows[i] & ((1 << 111) - 1) for i in range(111)]
    require(finish == mat, "X return changed")
    for i, row in enumerate(without):
        require(all(not (row >> j & 1) or dot(heads[i], heads[j]) == 0 for j in range(111)),
                "orthogonal mask false on monotone-only path")
    return without, descriptor


def suffix_sensitivity(word, descents, *, cut_exceptions=False):
    # Simultaneously inject basis perturbations at each selected cut and
    # propagate them through exactly the same remaining ADDs and erasures.
    n = word["public"]
    rows = [0] * n + [None] * word["owned_fields"]
    transfer = [0] * len(descents)
    for i, action in enumerate(word["program"]):
        op, field, *rest = action
        if op == "ADD":
            rows[field] ^= rows[rest[0]]
        elif op == "SWAP":
            other = rest[0]
            rows[field], rows[other] = rows[other], rows[field]
        elif op == "INIT":
            rows[field] = 0
        elif op == "CLEAR":
            rows[field] = None
        elif op == "MOVE" and i in descents:
            j, claimed_field, _, _ = descents[i]
            require(field == claimed_field, "wrong tagged descent")
            if cut_exceptions:
                transfer[j] = rows[field]
                rows[field] = 1 << j
            else:
                rows[field] ^= 1 << j
    return rows[111:222], transfer


def binary_rank(rows):
    basis = {}
    for row in rows:
        while row:
            p = row.bit_length() - 1
            if p not in basis:
                basis[p] = row
                break
            row ^= basis[p]
    return len(basis)


def first_descent_factorization(word):
    without, cuts = dirty_dependency_cut(word)
    top, _ = suffix_sensitivity(word, cuts)
    last_only, transitions = suffix_sensitivity(word, cuts, cut_exceptions=True)
    source_rows = [row[3] for row in cuts.values()]
    licensed = []
    for i, series in enumerate(top):
        result = 0
        for j, source in enumerate(source_rows):
            if series >> j & 1:
                result ^= source
        require(result == ((1 << i) ^ without[i]), "first-descent partition false")
        licensed.append(result)
    require(all(x >> i & 1 for i, x in enumerate(licensed)), "descent fit lacks diagonal")
    heads, _, _ = head_geometry(word)
    canonical = [sum(1 << j for j in range(111) if i == j or dot(p, heads[j]) == 0)
                 for i, p in enumerate(heads)]
    require(licensed == canonical, "first-descent reconstruction differs from canonical fitting mask")
    recovered = source_rows[:]
    for j, connect in enumerate(transitions):
        require(connect >> j == 0, "inter-descent transfer is not strictly chronological")
        recovered[j] ^= xor_selection(recovered, connect)
    require([xor_selection(recovered, row) for row in last_only] == canonical,
            "chronological first/last factorization differs")
    exact = binary_rank(licensed)
    require(exact == 9, "selected word's fitting rank changed")
    used = Counter((rank, bool(source), bool(any(a >> j & 1 for a in top)))
                   for j, _, rank, source in cuts.values())
    return {
        "raw_exceptions": len(cuts),
        "first_descent_outer_products": len(source_rows),
        "fitting_rank": exact,
        "equals_canonical_orthogonality_fit": True,
        "pairs_checked": len(licensed)**2,
        "chronological_inter_descent_edges": sum(row.bit_count() for row in transitions),
        "first_basis_rank": binary_rank(source_rows),
        "last_basis_rank": binary_rank(last_only),
        "descents": [{"rank": key[0], "sources_nonzero": key[1],
                      "reader_nonzero": key[2], "count": value} for key, value in sorted(used.items())],
        "native_sha256_prefix": "51203e7f",
    }


def xor_selection(rows, select):
    result = 0
    while select:
        low = select & -select
        select ^= low
        result ^= rows[low.bit_length() - 1]
    return result


def multiple_descents_control():
    # Data forwarded through two descending events must be assigned to the
    # first only -- counting both independently with the uncut prefix cancels
    # it over F2. The path coefficient is one.
    values = [1, 0, 0, 0]
    first, later = 0, 0
    values[1] ^= values[0]
    first ^= values[1]
    values[2] ^= values[1]
    later ^= values[2]
    values[3] ^= values[2]
    require(values[3] == 1 and first ^ later == 0, "multi-crossing control not biting")
    return {"correct": 1, "bad_uncut_source_sum": 0}


if __name__ == "__main__":
    print(json.dumps({"status": "PASS_P111_FIRST_DESCENT_FACTORIZATION",
                      "selected_word": first_descent_factorization(load_word()),
                      "multiple_descents_control": multiple_descents_control()}, indent=2))
