"""Exact geometry of monotone cross-delivery and covariant row routes."""

from collections import Counter
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "algebra"))
from scan_bit_fixed_graph import projector_frame
from scan_bit_move_runs import load_word


def require(p, message):
    if not p:
        raise ValueError(message)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def mul(a, b):
    return [[dot(r, c) for c in zip(*b)] for r in a]


def eye(n):
    return [[Fraction(i == j) for j in range(n)] for i in range(n)]


def minus(a, b):
    return [[x - y for x, y in zip(u, v)] for u, v in zip(a, b)]


def swap(p):
    s = minus(eye(len(p)), p)
    return [u + v for u, v in zip(s, p)] + [u + v for u, v in zip(p, s)]


def rank_one(head):
    norm = dot(head, head)
    return [[a * b / norm for b in head] for a in head]


def head_geometry(word):
    head = [tuple(map(Fraction, word["frames"][str(f)]["B"][0]))
            for f in word["start"][:111]]
    cap = [projector_frame(word["frames"][str(f)]["B"]) for f in word["final"][111:222]]
    p = [rank_one(v) for v in head]
    for i in range(111):
        require(cap[i] == minus(eye(8), p[i]), "actual cap did not complement its head")
    return head, cap, p


def contact_census(word):
    heads, caps, operators = head_geometry(word)
    full = swap(eye(8))
    stats = Counter()
    direct_by_rank = {}
    sampled = 0
    for i, j in product(range(111), repeat=2):
        orthogonal = dot(heads[i], heads[j]) == 0
        diagonal = i == j
        if diagonal or orthogonal:
            a, b = caps[i], operators[j]
            q = mul(a, b)
            # D_A D_B = D_(A+B−2AB) for commuting projectors.  Check
            # the selected 16x16 product on each diagonal and a few
            # off-diagonal controls; check the complete 8x8 identity.
            summed = [[x + y - 2 * z for x, y, z in zip(u, v, w)]
                      for u, v, w in zip(a, b, q)]
            if diagonal:
                require(summed == eye(8) and mul(swap(a), swap(b)) == full,
                        "same-head off diagonal was not whole")
            else:
                dif = minus(a, b)
                require(q == b and summed == dif, "orthogonal off port did not preserve line drop")
                if sampled < 16:
                    require(mul(swap(a), swap(b)) == swap(dif), "literal matrix mismatch")
                    sampled += 1
                # Source line contained in this cap. Therefore a monotone
                # path exists in isolation, but its product rank is 7-1=6.
                require(sum(dif[k][k] for k in range(8)) == 6, "credit rank mismatch")
                direct_by_rank[(i, j)] = dif
        stats[f"{'diagonal' if diagonal else 'orthogonal' if orthogonal else 'oblique'} pairs"] += 1
    return dict(stats), heads, direct_by_rank


def inverse_householder(u, v):
    """A rational orthogonal map taking the unit vector u to v."""
    require(dot(u, u) == dot(v, v) == 1, "unmatched root norm")
    w = tuple(x - y for x, y in zip(u, v))
    n = len(w)
    if not any(w):
        return eye(n)
    p = rank_one(w)
    h = [[Fraction(i == j) - 2 * el for j, el in enumerate(row)]
         for i, row in enumerate(p)]
    require(tuple(dot(row, u) for row in h) == v, "wrong direction map")
    require(mul(h, h) == eye(n), "Householder did not square to identity")
    return h


def normalized(v):
    from math import isqrt
    s = dot(v, v)
    a, b = isqrt(s.numerator), isqrt(s.denominator)
    require(a*a == s.numerator and b*b == s.denominator, "nonsquare actual root norm")
    return tuple(x * b / a for x in v)


def orbit_invariant(heads, direct):
    stats = Counter()
    for i, j in direct:
        stats[2] += 1
        if stats[2] > 64:
            continue
        h = inverse_householder(normalized(heads[j]), normalized(heads[i]))
        a = direct[i, j]
        got = mul(mul(h, a), h)
        require(sum(got[r][r] for r in range(8)) == 6, "whole-cover matching changed rank")
        x = eye(8)
        # The missing axes can be accounted for at the destination but
        # cannot be manufactured solely by a conjugation of the rank-six map.
        require(mul(swap(got), swap(minus(x, got))) == swap(x), "failed complementary repair")
        require(mul(got, got) == got, "route did not preserve projector algebra")
    return dict(stats)


def two_way_free_geometry_control():
    # Choose two orthogonal endpoint labels.  X can travel into the
    # opposite cap, Y at zero can travel into full. Using one coframe on
    # both directions realizes a labelled swap, but loses 2 rank credits
    # relative to the required complement. A literal repair adds them back.
    p = [[1, 0, 0], [0, 0, 0], [0, 0, 0]]
    q = [[0, 0, 0], [0, 1, 0], [0, 0, 0]]
    c = minus(eye(3), q)
    same = mul(swap(c), swap(p))
    require(same != swap(eye(3)), "false monotone whole-rank endpoint")
    d = minus(c, p)
    require(mul(swap(d), swap(minus(eye(3), d))) == swap(eye(3)),
            "exact affine repair failed")
    return {"external_dimension": 3, "transport_rank": 1, "full_repair_rank": 2}


def read_write_pair():
    # One nested ascent on each data owner, with arbitrary old arrays and
    # no work fields. If X and Y can meet, the monotone comparison
    # is an address residual of rank dim(Yout)-dim(Xin), not an extra
    # productive rank hidden in the bank swap.  Rank does not distinguish
    # two different affine maps, so compare the full addressing operator.
    n = 3
    p = [[Fraction(i == j == 0) for j in range(n)] for i in range(n)]
    f = [[Fraction(i == j < 2) for j in range(n)] for i in range(n)]
    endpoint = [1, 2]
    batches = [(1, 0), (0, 1), (1, 0)]
    for dst, src in batches:
        endpoint[dst] ^= endpoint[src]
    require(endpoint == [2, 1], "three coframe XORs failed independent inputs")
    cross = mul(swap(f), swap(p))
    complementary = swap(minus(eye(n), minus(f, p)))
    require(mul(cross, complementary) == swap(eye(n)), "wrong composed endpoint")
    return {"literal_boolean_columns": 2, "coframe_xor": 3, "paid_repair_rank": 2}


if __name__ == "__main__":
    census, heads, direct = contact_census(load_word())
    print(json.dumps({"status": "PASS_FRAME_ROUTE_INVARIANT", "selected_pairs": census,
                      "source_normalized_port_count": len(heads),
                      "whole_cover_reframe_repair_rank": orbit_invariant(heads, direct),
                      "primitive_positive_control": two_way_free_geometry_control(),
                      "actual_arbitrary_input_two_array_swap": read_write_pair()}, indent=2))
