# SPDX-License-Identifier: Apache-2.0
"""Build an exact complementary transpose of a BIT word, then screen local returns."""

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


WORK = Path(__file__).resolve().parents[1]
TERMINAL = run_path(str(WORK / "round2/terminal_multiflow.py"))
SWAP, PORTS = TERMINAL["SWAP"], TERMINAL["PORTS"]
BASE, NEED = SWAP["BASE"], SWAP["need"]
X_MASK = (1 << PORTS) - 1
Y_MASK = X_MASK << PORTS


def adjoint(word, chart_map, role_map, complement=True):
    """Transpose rectangular lifetime operations as well as square XOR gates."""
    n = word["public"]

    def frames_of(boundary):
        result = [None] * n
        for r, chart in enumerate(boundary):
            result[role_map[r]] = chart_map[chart]
        return result

    frames = {str(chart_map[int(f)]): ({"B": data["A"], "A": data["B"], "dim": 8 - data["dim"]}
                                      if complement else data) for f, data in word["frames"].items()}
    result = []
    for op, role, *rest in reversed(word["program"]):
        r = role_map[role]
        if op == "MOVE":
            a, b = rest
            result.append([op, r, chart_map[b], chart_map[a]])
        elif op == "ADD":
            source, frame = rest
            result.append([op, role_map[source], r, chart_map[frame]])
        elif op == "SWAP":
            result.append([op, r, role_map[rest[0]]])
        elif op == "CLEAR":
            result.append(["INIT", r, chart_map[rest[0]]])
        elif op == "INIT":
            result.append(["CLEAR", r, chart_map[rest[0]]])
        else:
            raise ValueError(f"Unknown opcode {op}")
    return {"schema": "bit-complemented-adjoint/v1", "frames": frames, "public": n,
            "owned_fields": word["owned_fields"], "start": frames_of(word["final"]),
            "final": frames_of(word["start"]), "program": result}


def dual_maps(word):
    charts = {int(f): int(f) for f in word["frames"]}
    charts.update({0: 1, 1: 0})
    for a, b in zip(word["start"][:PORTS], word["final"][PORTS:2 * PORTS], strict=True):
        charts.update({a: b, b: a})
    NEED(len(charts) == len(set(charts.values())), "dual chart labels are a permutation")
    n = word["public"] + word["owned_fields"]
    roles = list(range(PORTS, 2 * PORTS)) + list(range(PORTS)) + list(range(2 * PORTS, n))
    return charts, roles


def endpoint_primitives(word, dual, frames, roles, original_paid):
    """Check all public physical projectors on the same eight coordinate axes."""
    payload, moves, paid = BASE["prepare"](dual)
    NEED(paid == original_paid, "the complete recursive debit is invariant")
    BASE["verify_boundary_shapes"](dual, payload)
    old = {int(f): data for f, data in word["frames"].items()}
    for f, a in old.items():
        b = payload[frames[f]]
        NEED(b["A"] == a["B"] and b["B"] == a["A"] and a["dim"] + b["dim"] == 8,
             "all frames are the exact rational orthogonal complement")
    # The theorem D_(V^perp) = D_full·D_V reduces the dual physical map to
    # the original transpose, with the one global D_full cancelling on both sides.
    helper_ranks = Counter()
    for r in range(2 * PORTS, word["public"]):
        si, ti = old[word["start"][r]], old[word["final"][r]]
        sd, td = payload[dual["start"][roles[r]]], payload[dual["final"][roles[r]]]
        gap = ti["dim"] - si["dim"]
        NEED(gap == td["dim"] - sd["dim"] and BASE["rational_rank"](ti["B"] + si["B"]) == ti["dim"],
             "old and new helper differences are the same projection")
        helper_ranks[gap] += 1
    NEED(helper_ranks == {2: 1, 4: 25, 6: 1, 8: 410}, "all independent productive helpers counted")
    return moves, helper_ranks


def local_terminal_options(word):
    """Search unchanged prefix exposures at the two directed boundary cuts."""
    n = word["public"]
    rows = [1 << i for i in range(n)] + [0] * word["owned_fields"]
    frames = word["start"][:] + [None] * word["owned_fields"]
    resident = defaultdict(set)
    for r, f in enumerate(frames):
        if f is not None:
            resident[f].add(r)
    target = {f: r for r, f in enumerate(word["final"][PORTS:2 * PORTS], PORTS)}
    ever, y_used, x_top = set(), set(), set()
    charts_history = defaultdict(set)
    repair, full_with_y = {}, []
    active_states = Counter()
    top_roles = {r for r, f in enumerate(word["final"]) if f == 1}
    need_after_final = 0

    def inspect(frame, index):
        if frame not in target:
            return
        r = target[frame]
        chart_rows = [rows[p] for p in resident[frame] if p != r and rows[p]]
        charts_history[r].update(chart_rows)
        if r not in resident[frame]:
            return
        active_states[r] += 1
        basis = TERMINAL["rank_with_witness"](chart_rows)
        remaining_difference = rows[r] ^ 1 << (r - PORTS)
        if TERMINAL["span_contains"](basis, remaining_difference):
            repair.setdefault(r, index)
        if TERMINAL["span_contains"](basis, 1 << r):
            ever.add(r)

    for i, (op, r, *rest) in enumerate(word["program"]):
        if op == "MOVE":
            a, b = rest
            if b == 1 and rows[r] & Y_MASK:
                full_with_y.append((i, r, rows[r] & Y_MASK))
            if a == 1:
                need_after_final += 1
            resident[a].remove(r)
            resident[b].add(r)
            frames[r] = b
            inspect(a, i)
            inspect(b, i)
        elif op == "ADD":
            s, f = rest
            if rows[s] & Y_MASK:
                y_used.add(s)
            rows[r] ^= rows[s]
            if f == 1 and r in top_roles and rows[r] & Y_MASK:
                x_top.add(r)
            inspect(f, i)
        elif op == "SWAP":
            s, = rest
            a, b = frames[r], frames[s]
            resident[a].remove(r)
            resident[b].remove(s)
            resident[a].add(s)
            resident[b].add(r)
            frames[r], frames[s] = b, a
            rows[r], rows[s] = rows[s], rows[r]
            inspect(a, i)
            inspect(b, i)
        else:
            f, = rest
            rows[r] = 0
            if op == "INIT":
                resident[f].add(r)
                frames[r] = f
            else:
                resident[f].remove(r)
                frames[r] = None
            inspect(f, i)
    NEED(rows[:n] == BASE["endpoint"](word, False), "complete dual scalar endpoint")
    histories = {r: TERMINAL["rank_with_witness"](data) for r, data in charts_history.items()}
    return {"whole_chart_ingresses_with_original_Y": len(full_with_y), "whole_chart_nonzero_Y_temporary_owners": len(x_top),
            "nonzero_Y_forward_sources": len(y_used), "moves_out_of_full": need_after_final,
            "coframe_states_of_Y_at_final_chart": sum(active_states.values()),
            "final_chart_free_local_repair_witnesses": [[r - PORTS, i] for r, i in sorted(repair.items())],
            "final_chart_pure_original_Y_from_live_peers": sorted(r - PORTS for r in ever),
            "relaxed_final_chart_pure_X_from_all_peers": sorted(r - PORTS for r, h in histories.items()
                                                               if TERMINAL["span_contains"](h, 1 << (r - PORTS))),
            "relaxed_final_chart_pure_Y_from_all_peers": sorted(r - PORTS for r, h in histories.items()
                                                               if TERMINAL["span_contains"](h, 1 << r))}


def control():
    z, q = {"B": [], "A": [[1]], "dim": 0}, {"B": [[1]], "A": [], "dim": 8}
    word = {"frames": {"0": z, "1": q}, "public": 2, "owned_fields": 1, "start": [0, 0], "final": [1, 0],
            "program": [["INIT", 2, 0], ["ADD", 2, 0, 0], ["ADD", 1, 2, 0], ["CLEAR", 2, 0], ["MOVE", 0, 0, 1]]}
    forward = SWAP["rail_replay"](word)
    reverse = adjoint(word, {0: 1, 1: 0}, [0, 1, 2])
    backward = SWAP["rail_replay"](reverse)
    NEED(forward[0] == [1, 3] and backward[0] == [3, 2] and forward[1] == backward[1], "transpose is neither a formal inverse nor a reversal of dirty values")
    mutated = {**reverse, "program": reverse["program"][:2] + [["ADD", 1, 2, 1]] + reverse["program"][3:]}
    NEED(SWAP["rail_replay"](mutated)[0] != backward[0], "changing transpose direction fails")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--emit", type=Path, help="serialize the exact complementary-adjoint word")
    args = parser.parse_args()
    start = perf_counter()
    deadline = monotonic() + 45
    control()
    word = SWAP["load"](args.word)
    _, _, paid = BASE["prepare"](word)
    charts, roles = dual_maps(word)
    dual = adjoint(word, charts, roles)
    observed, dual_paid, ops, peak, _, _ = SWAP["rail_replay"](dual)
    NEED(dual_paid == paid and observed == BASE["endpoint"](dual, False),
         "transpose and relabeling produce the original shear on independent arrays")
    moves, helper_ranks = endpoint_primitives(word, dual, charts, roles, paid)
    orig_options, dual_options = local_terminal_options(word), local_terminal_options(dual)
    twice = adjoint(dual, charts, roles)
    NEED(all(twice[key] == word[key] for key in ("program", "start", "final", "frames")), "exact involution on encoded primitives")
    NEED(monotonic() < deadline, "adjoint and boundary screening has a 45-second budget")
    result = {"status": "PASS_BIT_COMPLEMENTED_ADJOINT", "source_sha256": BASE["SOURCE_SHA"],
              "same_full_mixed_rank_invoice": paid, "same_helper_ranks": helper_ranks, "dual_operations": ops,
              "peak_owned": peak, "independent_scalar_coefficients": dual["public"] ** 2,
              "unchanged_ordinary_counts": ops == Counter(e[0] for e in word["program"]),
              "dual_public_upward_moves": sum(payload_owner < dual["public"] and
                                              dual["frames"][str(a)]["dim"] < dual["frames"][str(b)]["dim"]
                                              for _, payload_owner, a, b, _ in moves),
              "primal_terminal_options": orig_options, "dual_terminal_options": dual_options}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.emit is not None:
        args.emit.write_text(json.dumps(dual, separators=(",", ":")) + "\n", encoding="utf-8")
    print(result["status"], f"all {dual['public'] ** 2:,} scalar coefficients and dual charts; {perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
