"""Check the independent correction floor of a fresh axis in Type B J1."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from time import monotonic


CALLER = "255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc"
WHOLE = "a0beec65810ba6be75053761eeab6a763506ac224e53c6187d8c8e977e1eefb9"
PRICE = "60a743d13f668ef86db4b8215b4d5d04430a671ba6f1fe06d9c1c4c3dfe86da5"
HERE = Path(__file__).resolve().parent


def require(condition, label):
    if not condition:
        raise ValueError(label)


def load(path, expected):
    data = path.read_bytes()
    require(sha256(data).hexdigest() == expected, f"exact SHA256 for {path}")
    return data


def plus(left, right, scale=1):
    return [x + scale*y for x, y in zip(left, right, strict=True)]


def mult(row, scale):
    return [v*scale for v in row]


def unit(role, width):
    return [Q(i == role) for i in range(width)]


def rank(rows):
    pivots = {}
    for row in rows:
        a = row.copy()
        for i in range(len(a)):
            if not a[i]:
                continue
            if i not in pivots:
                pivots[i] = mult(a, 1/a[i])
                break
            a = plus(a, pivots[i], -a[i])
    return len(pivots)


def signed_caller(caller, sector, give_host, give_idles, omit_idle=None):
    """Specialize all old phases to 1 and evolve all 36 dirty basis inputs."""
    b = caller["types"]["B"]
    width, off = b["roles"], b["offset"]
    rows = [unit(i, width) for i in range(width)]
    axes, idles = [], []
    for ix, event in enumerate(caller["events"]):
        if event[0] == "J":
            stage = event[1]
            x, y, aa, bb = event[3]
            x, y, a, c = x-off, y-off, Q(aa), Q(bb)
            # At q=1 all central sign/q^-1 factors equal 1.
            xx = plus(rows[x], rows[y], a)
            yy = plus(mult(rows[y], 1+a*c), rows[x], c)
            scale = sector if stage == 1 and give_host else 1
            rows[x], rows[y] = mult(xx,scale), mult(yy,scale)
            if stage == 1:
                axes.append((ix, (x+off,y+off), rank((xx,yy))))
        elif event[0] == "B":
            op, r, *data = event[1:]
            r -= off
            if op == "ADD":
                rows[r] = plus(rows[r], rows[data[0]-off], Q(data[1]))
            elif op == "SWAP":
                s = data[0]-off
                rows[r],rows[s] = rows[s],rows[r]
            elif op == "SCALE":
                rows[r] = mult(rows[r], Q(data[0]))
            elif op == "QUERY":
                rows[r] = plus(rows[r], rows[data[0]-off])
            elif op in ("IDLE_ONE","IDLE_ODD"):
                if 1 in data[0]:
                    idles.append((ix, r+off, op, len(data[0]) * 8 + (op == "IDLE_ODD")))
                    if give_idles and ix != omit_idle:
                        rows[r] = mult(rows[r], sector)
            else:
                require(op == "LAMBDA", "literal Type B opcode")
    return rows, axes, idles


def changed(rows1, rows2):
    return [plus(a,b,-1) for a,b in zip(rows1,rows2,strict=True)]


def sector_receipt(caller):
    plus_sector, host_axes, traversed_idles = signed_caller(caller,1,True,True)
    minus_sector, _, _ = signed_caller(caller,-1,True,True)
    old_host, _, _ = signed_caller(caller,-1,False,True)
    lost_idle, _, _ = signed_caller(caller,-1,True,True,omit_idle=traversed_idles[0][0])
    ports = len(caller["types"]["B"]["ports"])
    masks = caller["types"]["B"]["diagonal"]
    width, off = caller["types"]["B"]["roles"],caller["types"]["B"]["offset"]
    require(ports == 8 and width == 36, "source port/role widths")
    require(host_axes == [(43,(36,37),2)], "literal independent host rail pair")
    require(traversed_idles == [(7,36,"IDLE_ONE",8),(19,37,"IDLE_ONE",8)], "only two existing J1 body idles")
    require(plus_sector == [unit(i,width) for i in range(width)], "positive sector arbitrary-input endpoint")
    expected = [mult(unit(i,width), -1 if row[2] else 1) for i,row in enumerate(masks)]
    require(minus_sector == expected, "negative sector complete output diagonal")
    require(lost_idle != minus_sector, "omitted first body-idle signal mutant")
    target_rank = rank(changed(plus_sector, minus_sector))
    retained_rank = rank(changed(plus_sector, old_host))
    correction_rank = rank(changed(old_host, minus_sector))
    require((target_rank, retained_rank, correction_rank) == (4, 2, 2), "exact J1 demand and restoration ranks")
    return {"host":host_axes, "idles":traversed_idles, "ports":ports,
            "first_stage_target_roles":[i+off for i,d in enumerate(masks) if d[2]],
            "target_sector_difference_rank":ports*target_rank,
            "frozen_body_idle_sector_rank":ports*retained_rank,
            "necessary_new_field_directions":ports*(target_rank-retained_rank),
            "explicit_correction_rank":ports*correction_rank,
            "dropped_idle_control_rejected":True}


def priced_floor(caller, whole, max_paid_rank):
    path = HERE/"pinned"/"interval_gate.py"
    load(path,PRICE)
    spec=spec_from_file_location("interval_gate",path)
    restricted=module_from_spec(spec)
    spec.loader.exec_module(restricted)
    k = Q(".003648411294790")
    added = Counter()
    for row in caller["types"]["B"]["diagonal"]:
        if row[2]:
            original_rank = 1 + 8*sum(row[2:])
            added[original_rank] -= 8
            added[original_rank + 1] += 8
    body_idles = Counter()
    for event in caller["events"]:
        if event[:2] == ["B","IDLE_ONE"] and 1 in event[3]:
            original_rank = 8*len(event[3])
            body_idles[original_rank] -= 8
            body_idles[original_rank + 1] += 8
    added.subtract(body_idles)
    margin = restricted.moment(added,k)
    signed_paid = {int(r):n for r,n in whole["signed_profile"]["signed_paid"].items()}
    require(max(signed_paid) == max_paid_rank == 64, "source maximum paid rank")
    standalone = restricted.sub(margin,restricted.exact(16))
    one_call_per_max = restricted.moment(Counter({max_paid_rank+1:16,max_paid_rank:-16}),k)
    optimistically_concentrated = restricted.moment(Counter({max_paid_rank+16:1,max_paid_rank:-1}),k)
    floor = restricted.sub(margin,optimistically_concentrated)
    require(standalone[1]<0 and floor[1]<0, "still loses under optimistic paid concentration")
    return {"new_margin_before_host_corrections":restricted.value(margin),
            "standalone_16_rank_1_corrections_delta":restricted.value(standalone),
            "optimistic_cost_16_rank64_extensions":restricted.value(one_call_per_max),
            "optimistic_cost_all_16_attached_to_one_rank64":restricted.value(optimistically_concentrated),
            "best_rank_extending_delta_upper":restricted.value(floor),
            "best_rank_extending_delta_exact_interval":restricted.show(floor)}


def main():
    start=monotonic()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("caller",type=Path)
    parser.add_argument("whole",type=Path)
    args=parser.parse_args()
    caller=json.loads(load(args.caller,CALLER))
    whole=json.loads(load(args.whole,WHOLE))
    data={"caller_sha256":CALLER,"receipt_sha256":WHOLE,"sector":sector_receipt(caller),
          "pricing":priced_floor(caller,whole,64)}
    require(monotonic()-start<10,"10 second replay bound")
    data["seconds"]=monotonic()-start
    print(json.dumps(data,indent=2))


if __name__=="__main__":
    main()
