# A physical Type-B common-body realization and its cost

Use the pinned #7546 native word `99438c43df7aac1e5dbcc43c1578fcd886c119ec` and signed #7113 caller `07a76c5e2738882c0cb322278e56f6cae3c9885d`. This changed operator embedding retains the original exact all-width native word. Its priced candidates lose to the original full invoice.

## Where the common factor lives

The eight Type-B central directions span a nondegenerate seven-dimensional subspace \(W\) of \(\mathbf F_2^9\). The common perpendicular two-space \(S\) admits orthonormal directions encoded by binary masks 331 and 372. Every actual Type-B X/Y input frame contains zero of these directions and every return frame contains both. Thus they form a common body action \(C_S\), where \(C_S\) is the product of their two quarter turns. They do not form an identity spectator factor in the native action.

The distinction is visible in the source. Only 115 of 1,096 native frame subspaces decompose as sums of their intersections with \(W\) and \(S\). The 6,276 MOVEs include 625 with both charts split, of which eight have a nontrivial S transition. Projecting every native chart onto W would decrease 1,952 MOVE ranks, counting 909 rank-zero outcomes. That projection also changes productive helper ranks and removes components of 76 of the 96 Type-A central directions. A B-only decomposition of the original native is not warranted even before considering 855 scalar ADD contacts between Type-B main fields and other fields. These are exact inventory checks in `spectator_quotient.py`; the projected counts are not a signed caller invoice.

## Exact changed embedding

For each B port direction q, choose six orthonormal vectors spanning \(W\cap q^\perp\), with \(q\) and the basis of S completing the nine-dimensional orthonormal basis. At any selected stage, exchange only those six vectors with six fresh independent stage axes. Fix q and both S directions. At unselected stages exchange all eight vectors of \(q^\perp\) as in #7113. Keep the original 145-coordinate envelope for the joint A/B word, since A retains all seventeen eight-axis blocks.

The exact before/after contact phase polynomials under this involutory binary route differ from the physical caller phases by translations. This follows either from direct quadratic coefficient verification or from comparing two orthonormal bases of the same subspace. They have the same binary projector, so the difference of the sums of parity-linear terms modulo four has even linear terms and zero quadratic part. The zero-address phase is zero for both. Add the resulting fixed ordinary translation at the relevant input or output. The verifier checks all 544 forward contact residuals and their 544 exact inverse equations for eight B ports and seventeen calls. The prescribed route fixes q, the retained S directions and every exterior spectator. A deliberately added odd residual must reject. The all-width transfer uses the inherited ability to tensor the complete physical identity with all spectators, and the exact #7113 polynomial identity in commuting body generators independently of their disjointness.

The Type-B generator at a selected stage is therefore \(D_{6,j}C_S\), with the original scalar host map and q. These generators commute with each other and q. On any complete target or paid-idle body mask of size k, if s of the stages share one coordinate, that coordinate contributes only \(s\bmod2\) to Fourier rank. Its even phase is a known translation or identity with an ordinary movement charge. With both S directions shared at all stages this gives consecutive body rank \(6k+2(k\bmod2)\). Include the central rank when an idle or returned target has an odd q power. The fixed #7113 Laurent-ring endpoint therefore remains valid after this substitution. No trial assumes that a chart projection by itself changes an admissible main endpoint.

## Complete recursive balance

The literal native paid and target lists, all A events and target masks, and the B scalar/query routes retain their proven chronology. Repricing every B idle and target gives the following counts and incumbent-exponent differences, with incumbent κ=0.003648411294790.

| Realization | Paid positions | Productive fields | Rank surplus | Change in target-minus-paid moment |
| --- | ---: | ---: | ---: | ---: |
| #7546 on #7113 | 110,468 | 22,461 | 1,424 | 0 |
| One B-only direction shared by the best pair of stages (e.g. 8,17) | 110,468 | 22,461 | 1,392 | −31.3168868252484 |
| Two B-only directions shared by all 17 stages | 110,468 | 22,461 | 400 | −1,003.65005692741 |

The directed interval checker tests all 136 single-coordinate stage pairs; every pair loses. The general cause is the same mask pairing as in the preceding phase-incidence calculus, restricted to eight ports. The unmatched full and two half-chain masks have multiplicity 16 each, and the matched multibody masks retain 208 paid/target pairs. One overlapped coordinate with active stage set M loses at least \(32(|M|-1)\) linear rank. For κ between zero and .01, the per-unit matched credit is at most .06 while unpaired loss is at least .94, which gives a strictly negative moment change for any nontrivial M. This extends to multiple overlapping coordinates by summing losses within each mask before integrating slopes. Tape width, routing, fresh-field preparation, positive power signs, completed helpers and recovery do not act as free compensation. The complete moment is already lost with new ordinary costs waived, so a fresh physical tape/precision/outer replay was not attempted.

## A closer changed interface

One can alternatively append a new commuting fresh direction to a chosen B stage body and keep the #7546 native unchanged. Apply one additional rank-one map on each of the two native B output rails after the original J. The new factor is exact, fixes all other addresses and preserves the Laurent identity when every affected future idle and target uses the enlarged body block. At stage J1 this requires 16 paid rank-one maps across the eight B ports. The checker verifies its phase binding and the complete typed tariff. Baseline ambient 145 becomes 146. The native helper/paid chronology remains unchanged and linear surplus stays 1,424. The complete directed raw moment loses .459619996776439 at the incumbent value. J1 is the closest of all seventeen places for one extra direction. Giving one new distinct direction to each stage costs 272 paid rank-one corrections and loses 8.0645117461553 moment units. Uniform widths 4 through 16 also lose after independently charging removal or addition for every affected native rail.

This identifies an actual break-even interface. A rank-mass reduction of one in the sixteen J1 corrections would make their isolated economic screen positive. An equal-mass swap of two rank-one jobs to one rank-two job on any one complete port saves only \(2-2^{1-\kappa}\), too little. A lawful new shared correction must deliver the required arbitrary independent fields or earn a distinct productive return. Four independent B phase-only rails 68–71 each have exactly one direct IDLE_ODD and no other contact. Their target and paid contributions cancel identically. Dropping one from the paid list while crediting its target would be an unearned gain.

The obvious two-cut #7244 witness is also present in the current architecture at the same role identities: donor 988 and 991 already return at full chart127, and the original pivot 998 ends at chart1091. Its earlier positive construction cannot be counted anew. A changed route must use other data or a genuinely different dependency. [#7244 two-cut proof](https://github.com/CrocSwap/integer-mult-bounds/blob/215f67247f395c0e15f5ea3980f6a3e4aed155af/research/p104-two-cut-funded-split/PROOF.md)

## Replay

Use CPython 3.13.14 standard library. The existing prior-work inputs are `7546-word.json.gz`, `phase-7481-inputs/caller.json` and `7546-whole.json` under `integer-mult-local-recovery/work`. The scripts pin them and import only the read-only pinned standard-library price engine where needed. Retained proof and source hashes are in the JSON records.

```powershell
& $python -I -O -B -W error .\spectator_quotient.py $word
& $python -I -B -W error .\shared_body.py $word $caller $whole
& $python -I -B -W error .\body_rank_deformation.py $caller $whole
```

The longest run took about 3.3 seconds, within its 20-second bound, and all three processes exited. #7565 and #7568 describe useful independent tape interfaces but neither exact head has a successful hosted replay: both planning jobs failed and the replay jobs were skipped. #7565 retains native, initialization, format and primitive premises; #7568 verifies one selected MOVE on a once-rounded widened path and still needs an exact-layer caller error transfer. Neither supports substituting the changed caller here. [#7565 planning job](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43543334498/job/132288695167) · [#7568 planning job](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43543733743/job/132289987030)
