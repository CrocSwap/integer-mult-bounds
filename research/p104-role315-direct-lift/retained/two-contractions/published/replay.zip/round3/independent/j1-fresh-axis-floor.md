# Independent fresh-axis corrections at Type B J1

This checks the closest economic screen from the Type-B body study. Keep the #7546 native and the #7113 caller's logical endpoint. Append one fresh commuting address direction to the first B stage and retain the other seventeen-stage invoices. The before/after value for the full recursive moment still favors #7546.

Specialize the old body generators and central quarter turn to their common +1 eigen-sector. On the fresh axis compare its +1 and −1 sectors. The verifier propagates each of the 36 independent B input coordinates at both signs. The typed endpoint changes exactly roles 36, 37, 38 and 39, giving difference rank four per port and 32 across eight B ports. Without changing the native host, the only already-priced J1 body-idle call sites are literal events 7 and 19. They each act on one field per port. The computed difference rank contributed by these two sites is sixteen; the missing host correction between the idle-only word and target is also exactly sixteen. Omitting one literal idle breaks the expected diagonal.

If the retained native operators and rank-zero scalar/route adapters are blind to the fresh sign and do not convert one sector into the other, then any changed sign dependence has to come from a corrected paid occurrence. For two product matrices with factor lists \(A_i^+,A_i^-\), subtract them by replacing one factor at a time. Rank subadditivity gives

\[
\operatorname{rank}(\mathop{\prod} A_i^+-\mathop{\prod} A_i^-)
\leq \sum_i \operatorname{rank}(A_i^+-A_i^-).
\]

This also holds for rectangular common interfaces whenever the respective composites are defined. Each one-field correction contributes at most one to the right side. The unchanged host and other old-factor calls contribute zero. The already repriced body idles allow up to sixteen. Consequently at least sixteen additional independent fresh-sector field directions are required. Interleaving corrections, introducing zero work fields, using arbitrary sign-even couplings, or moving a sign-bearing row before or after a visible read cannot lower this count while preserving the sector-blind interface. The construction charging sixteen rank-one calls attains the count.

At the incumbent κ, the enlarged targets minus enlarged existing idles fund exactly about 15.54038000322356 raw moment units. Standalone rank-one corrections cost 16, losing 0.45961999677644. Suppose all additional fresh-sector field directions may be appended to existing recursive child jobs at one positive rank unit per direction. The largest existing paid rank in the #7546 source-bound receipt is 64. For a concave increasing tariff \(H_r=r^{1-\kappa}\), attaching all sixteen rank units to one already rank-64 job is an optimistic lower charge even if physical fusion across all eight ports is granted. To see this, set \(g(t)=H_{64+t}-H_{64}\). For every smaller starting rank the incremental charge is at least \(g(t)\), and \(g\) is increasing, concave, and vanishes at zero, so it is subadditive. The resulting lower charge \(g(16)=H_{80}-H_{64}\) is about 15.69493682035937. Thus the revised target-minus-paid moment has certified upper bound approximately **−0.15455681713581**. Assigning the sixteen units separately to sixteen rank-64 jobs costs slightly more.

The cost conclusion assumes every fresh field direction requires a new paid rank unit and keeps every previous paid direction and independent target funded. A genuine rank-neutral replacement of an old axis could escape. So could a new provider or physical encoding whose relative fresh-sector action changes several data fields under a different accounting rule. Trading for easier, fewer, or correlated targets would require a new signed invoice. This result does not treat sign-mixing address gates or arbitrary direct sums as free. No new κ or tape/stock/precision application follows.

Run with assertions enabled under CPython 3.13.14, from the current scratch directory. Earlier local research pins the inputs `phase-7481-inputs/caller.json` and `7546-whole.json`. The script authenticates their bytes and the frozen exact interval engine. It took 0.40 CPU seconds under a 10-second bound and exited normally.

```powershell
& $python -I -B -W error .\j1_fresh_axis_floor.py $caller $whole
```

The exact integer interval and independent-column result are in `j1-fresh-axis-floor-result.json`. [Signed source #7113](https://github.com/CrocSwap/integer-mult-bounds/pull/7113) · [#7546 exact-head replay](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050)
