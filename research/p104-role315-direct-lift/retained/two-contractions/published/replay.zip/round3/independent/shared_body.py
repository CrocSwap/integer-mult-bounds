"""Pin and price exact Type B reuse of its two common body directions."""

import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
import gzip
import json
from pathlib import Path
from time import monotonic


WORD = 'bdecd5cc1cb9f164dc695ce07a07d5d44e9961996fcdfa4d77b4092fecbda745'
CALLER = '255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc'
PRICE = '60a743d13f668ef86db4b8215b4d5d04430a671ba6f1fe06d9c1c4c3dfe86da5'
WHOLE = 'a0beec65810ba6be75053761eeab6a763506ac224e53c6187d8c8e977e1eefb9'
S = (331,372)


def require(condition,label):
    if not condition:
        raise ValueError(label)


def input_bytes(path,digest,compressed=False):
    raw=path.read_bytes()
    if compressed:
        raw=gzip.decompress(raw)
    require(sha256(raw).hexdigest()==digest,f'exact input {path.name}')
    return raw


def dot(a,b):
    return (a&b).bit_count()&1


def orthogonal_reps(W,n):
    if not n:
        return []
    for v in sorted(W):
        if dot(v,v):
            rem=orthogonal_reps({w for w in W if not dot(v,w)},n-1)
            if rem is not None:
                return [v,*rem]
    return None


def bi_poly(directions):
    coeff=Counter()
    for x,a in directions:
        bits=[n for n in range(x.bit_length()) if x>>n&1]
        for b in bits:
            coeff[(b,)]+=a
        for b,c in combinations(bits,2):
            coeff[b,c]-=2*a
    return {p:c%4 for p,c in coeff.items() if c%4}


def orthonormal(basis):
    return all(dot(a,b)==(i==j) for i,a in enumerate(basis) for j,b in enumerate(basis))


def translation(poly):
    require(all(len(k)==1 and v==2 for k,v in poly.items()),'boundary residual is exactly an ordinary translation')
    return sum(1<<key[0] for key in poly)


def phase_control():
    require(translation(bi_poly([(3,2)]))==3,'ordinary translation check')
    try:
        translation(bi_poly([(1,1)]))
    except ValueError:
        return
    raise ValueError('odd phase mutant accepted')


def phase_binding(word,caller,selection=(1<<17)-1,dimension=2,dilation=()):
    expected=sorted(set(range(104))-set(word['hosted']['Dports']))
    require(caller['types']['B']['ports']==expected,'exact B ports')
    all_coords=[1<<j for j in range(9)]
    bases={}
    for pi in expected:
        q=word['ports'][pi]
        require(all(not dot(q,s) for s in S),'common basis preserved by central projector')
        C={v for v in range(512) if all(not dot(v,z) for z in (q,*S))}
        B=orthogonal_reps(C,6)
        # A norm-one direction can be characteristic for its nonalternating
        # odd-dimensional space. Then its six-dimensional complement is
        # alternating; it still has a full basis and an exact Clifford action.
        if B is None:
            B=[]
            width={0}
            for v in sorted(C):
                if v not in width:
                    B.append(v)
                    width|={u^v for u in width}
            require(len(B)==6,'alternating six-axis representative')
        bases[pi]=B
    records=[]
    for stage in range(1,caller['stages']+1):
        fixed=S[:dimension] if selection>>(stage-1)&1 else ()
        swapped_count=8-len(fixed)
        moved=[1<<(9+8*(stage-1)+j) for j in range(swapped_count)]
        unused=[1<<(9+8*(stage-1)+j) for j in range(swapped_count,8)]
        for pi,B in bases.items():
            q=word['ports'][pi]
            require(orthonormal((q,*S,*B)),'this literal route requires an orthonormal six-axis basis')
            swapped=(*B,*S[len(fixed):])
            def route(x):
                y=x
                for old,new in zip(swapped,moved,strict=True):
                    if dot(x,old)!=dot(x,new):
                        y^=old^new
                return y

            require(all(route(route(1<<i))==1<<i for i in range(caller['ambient_rank'])), 'ordinal full inverse')
            require(all(route(v)==v for v in (q,*fixed,*unused)), 'common S, center, and outside spectators fixed')
            want_body=[(r,1) for r in (*fixed,*moved)]
            actual=[(route(x),1) for x in [*S,*B]]
            require(not bi_poly(actual+[(x,-v) for x,v in want_body]),'exact routed native body phase')
            # Same four boundary differences as the retained physical verifier,
            # with port S stayed and only the six displayed coordinates swapped.
            input_ambient=all_coords
            before_x=[(x,1) for x in input_ambient]
            before_y=before_x+[(q,-1)]
            # The normalized caller gauge retains C_S throughout. Its
            # physical binding needs C_S on both entrance spectators and
            # exit spectators in addition to the local chart where present.
            spectator=[(x,1) for x in (*moved,*fixed)]
            phys_before_x=spectator+[(q,1)]
            phys_before_y=spectator
            native_x_out=before_x+spectator
            native_y_out=native_x_out+[(q,-1)]
            # Keep the old common-gauge body mask aligned before undoing
            # the port route. The S factor in the logical product is not
            # a second independent coordinate; C_S^2 is an ordinary tag.
            logical_after_x=before_x+[(x,1) for x in moved]+[(s,1) for s in fixed]
            logical_after_y=logical_after_x+[(q,-1)]
            shifts=[]
            contacts=((before_x,phys_before_x),(before_y,phys_before_y),
                      (logical_after_x,native_x_out),(logical_after_y,native_y_out))
            for ci,(logical,native) in enumerate(contacts):
                residue=bi_poly(native+[(route(x),-v) for x,v in logical])
                shift=translation(residue)
                inv=bi_poly(logical+[(route(x),-v) for x,v in native]+[(route(shift),2)])
                require(not inv,f'inverse restores exact phase including translation, contact {ci}')
                shifts.append(shift)
            if stage in dilation:
                # Add one independent body direction to both host output
                # rails. Existing spectator input is arbitrary and retained;
                # this is an extra paid rank-one request for each rail.
                extra=1<<caller['ambient_rank']
                require(not dot(extra,q) and not any(dot(extra,x) for x in (*S,*moved)),
                        'fresh independent body expansion')
                expected=want_body+[(extra,1)]
                changed=actual+[(route(extra),1)]
                require(not bi_poly(changed+[(v,-u) for v,u in expected]),
                        'exact full enlarged stage action')
            records.append((stage,pi,shifts))
    return {'boundaries':len(records)*4,'orthogonal_bases':bases,'dilated_stages':dilation,
            'sample_forward_translations':records[:4],
            'phase_record_sha256':sha256(json.dumps(records,separators=(',',':')).encode()).hexdigest()}


def body_mask(stages):
    return sum(1<<(j-1) for j in stages)


def invoices(caller,whole,selection=(1<<17)-1,dimension=2):
    p0=Counter({int(r):qty for r,qty in whole['signed_profile']['signed_paid'].items()})
    t0=Counter({int(r):qty for r,qty in whole['signed_profile']['signed_productive'].items()})
    p,t=p0.copy(),t0.copy()
    for e in caller['events']:
        if e[:2]==['B','IDLE_ONE']:
            k=len(e[3]);r=8*k;new=r-dimension*2*((body_mask(e[3])&selection).bit_count()//2)
            p[r]-=8;p[new]+=8
    for phase,z,*mask in caller['types']['B']['diagonal']:
        require(phase==-1 and not z,'one retained central axis per B target')
        k=sum(mask);r=1+8*k
        selected=body_mask(j+1 for j,x in enumerate(mask) if x)
        new=r-dimension*2*((selected & selection).bit_count()//2)
        t[r]-=8;t[new]+=8
    require(min(p.values())>=0 and min(t.values())>=0,'paid/target ownership remains nonnegative')
    return +p,+t,p0,t0


def tariff(p,t,p0,t0):
    source=Path(__file__).resolve().parent/'pinned'/'interval_gate.py'
    input_bytes(source,PRICE)
    spec=spec_from_file_location('price',source)
    price=module_from_spec(spec);spec.loader.exec_module(price)
    delta=t.copy()
    delta.subtract(p)
    delta.update(p0)
    delta.subtract(t0)
    k=Fraction('.003648411294790')
    moment=price.moment(delta,k)
    require(moment[1]<0,'full substituted caller loses at incumbent value')
    surplus=sum(r*(t[r]-p[r]) for r in t.keys()|p.keys())
    return {'before_raw_surplus':sum(r*(t0[r]-p0[r]) for r in t0.keys()|p0.keys()),
            'shared_body_surplus':surplus,'delta_moment':price.value(moment),'delta_directed':price.show(moment),
            'paid':p,'targets':t,'paid_count':sum(p.values()),'productive_count':sum(t.values())}


def optimise_pairs(word,caller,whole):
    choices=[]
    # Exact directed arithmetic for one shared body direction on any two
    # specified stages. More extensive masks have an analytic bound.
    for pair in combinations(range(1,caller['stages']+1),2):
        mask=body_mask(pair)
        bill=tariff(*invoices(caller,whole,mask,1))
        choices.append((Fraction(bill['delta_directed'][0]),pair,bill['shared_body_surplus']))
    moment,pair,surplus=max(choices)
    geometry=phase_binding(word,caller,body_mask(pair),1)
    return {'stages':pair,'moment_delta_lower':str(moment),'moment_delta_display':float(moment),
            'raw_surplus':surplus,'geometry':geometry,'tested_stage_pairs':len(choices)}


def main():
    start=monotonic()
    parser=argparse.ArgumentParser(description=__doc__)
    for arg in ('word','caller','whole'):
        parser.add_argument(arg,type=Path)
    args=parser.parse_args()
    w,c,r=(json.loads(input_bytes(path,sha,compressed)) for path,sha,compressed in (
        (args.word,WORD,True),(args.caller,CALLER,False),(args.whole,WHOLE,False)))
    phase_control()
    geometry=phase_binding(w,c)
    bill=tariff(*invoices(c,r))
    near=optimise_pairs(w,c,r)
    dilated=phase_binding(w,c,0,0,(1,))
    require(monotonic()-start<20,'bounded verifier')
    print(json.dumps({'source_heads':['99438c43df7aac1e5dbcc43c1578fcd886c119ec',
        '07a76c5e2738882c0cb322278e56f6cae3c9885d'],'geometry':geometry,'paid_and_targets':bill,
        'best_partial_overlap':near,'one_axis_dilation_phase_binding':dilated,
        'seconds':monotonic()-start},indent=2))


if __name__=='__main__':
    main()
