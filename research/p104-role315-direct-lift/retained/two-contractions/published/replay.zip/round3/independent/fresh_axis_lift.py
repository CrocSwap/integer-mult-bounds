"""Bounded exact physical check of an orthogonal-axis #7546 native extension."""

import argparse
import gzip
import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path


HERE = Path(__file__).resolve().parent
WORD = HERE.parents[3] / "integer-mult-local-recovery" / "work" / "7546-word.json.gz"
WORD_SHA = "6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32"
PIN = HERE / "pinned" / "clifford_exact.py"
PIN_SHA = "2982ead07721e83358dc67c6f49c2b4c16a236a6bebdfd72f58221be1f5d0962"
N = 9
E = 1 << N


def load_pins(word_path):
    assert hashlib.sha256(PIN.read_bytes()).hexdigest() == PIN_SHA
    spec = importlib.util.spec_from_file_location("clifford_exact", PIN)
    compiler = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = compiler
    spec.loader.exec_module(compiler)
    compressed = word_path.read_bytes()
    assert hashlib.sha256(compressed).hexdigest() == WORD_SHA
    return compiler, json.loads(gzip.decompress(compressed))


def embed(compiler, operator):
    """Tensor an exactly signed 9-bit operation with spectator identity."""
    assert operator.n == N
    gates = []
    for gate in operator.circuit:
        if gate[0] == "P":
            gate = ("P", (*gate[1], E))
        elif gate[0] == "D":
            gate = ("D", (*gate[1], 0), (*gate[2], 0))
        else:
            assert gate[0] in {"C", "X", "phase"}
        gates.append(gate)
    table = (*operator.tab[:N], (E, 0, 0), *operator.tab[N:], (0, E, 0))
    return compiler.Op(N + 1, table, gates)


def kernel(compiler, gate):
    """Use the signed gate constructors to rebuild a literal circuit."""
    n = N + 1
    if gate[0] == "P":
        return compiler.perm(n, gate[1])
    if gate[0] == "D":
        return compiler.diag(n, *gate[1:])
    if gate[0] == "C":
        return compiler.cgate(n, *gate[1:])
    if gate[0] == "X":
        return compiler.xgate(n, gate[1])
    assert gate[0] == "phase"
    return compiler.Op(n, compiler.identity(n), [gate])


def combine_with_fresh(compiler, lowered, old_rank, delta):
    """Fuse a commuting fresh quarter-turn into the single lowered call."""
    source = embed(compiler, lowered).circuit
    axes = [i for i, gate in enumerate(source) if gate[0] == "C"]
    assert len(axes) == old_rank
    assert axes == list(range(axes[0], axes[0] + old_rank))
    assert all(source[i] == ("C", 1 << (i - axes[0]), 1) for i in axes)
    prefix = source[: axes[0]]
    core = source[axes[0] : axes[-1] + 1]
    suffix = source[axes[-1] + 1 :]
    if delta:
        core.append(("C", E, 1))
    if delta == -1:
        # In the pinned quarter-turn convention X_e C_e = C_e^{-1} exactly.
        suffix.append(("X", E))
    result = compiler.ident(N + 1)
    for gate in (*prefix, *core, *suffix):
        result = result.then(kernel(compiler, gate))
    assert sum(gate[0] == "C" for gate in result.circuit) == old_rank + abs(delta)
    return result


def equal_signed_clifford(left, right, check_column):
    assert left.tab == right.tab
    if check_column:
        # The signed Pauli automorphism fixes the Clifford matrix up to a scalar.
        # Checking one full column fixes that scalar, with no floating point.
        assert left.zero_state() == right.zero_state()


def inverse_tensor_controls(compiler):
    """Check translation and an independent phase-based inverse at widths 1–3."""
    for f in (1, 2, 3):
        all_axes = (1 << f) - 1
        positive = compiler.fourier(f)
        translated = positive.then(compiler.xgate(f, all_axes))
        equal_signed_clifford(translated, positive.adjoint(), True)
        zero = (0,) * f
        z = compiler.diag(f, zero, (2,) * f)
        unphased = z.then(positive).then(z)
        phase = compiler.Op(f, compiler.identity(f), [("phase", (-f) % 4)])
        equal_signed_clifford(unphased.then(phase), positive.adjoint(), True)
        assert unphased.tab == positive.adjoint().tab
        assert unphased.zero_state() != positive.adjoint().zero_state()
        assert positive.zero_state() != positive.adjoint().zero_state()


def actual_examples(frames, program):
    """Take shortest and longest actual MOVE of each ownership/orientation class."""
    options = {}
    histogram = Counter()
    for at, row in enumerate(program):
        if row[0] != "MOVE":
            continue
        _, reg, start, stop, owned = row
        step = len(frames[stop]) - len(frames[start])
        assert step and (step > 0 or owned)
        key = owned, step > 0
        entry = abs(step), at, reg, start, stop
        options.setdefault(key, []).append(entry)
        histogram[f"{'owned' if owned else 'public'}:{step:+d}"] += 1
    examples = [pair for group in options.values() for pair in (min(group), max(group))]
    return tuple(dict.fromkeys(examples)), dict(sorted(histogram.items()))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--word", type=Path, default=WORD)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    compiler, word = load_pins(args.word)
    inverse_tensor_controls(compiler)
    frames = word["frames"]
    examples, histogram = actual_examples(frames, word["program"])
    column_checks = {frame for _, _, _, a, b in examples for frame in (a, b)}
    column_checks.update({3, 127})
    old = [compiler.canonical_frame(N, frame) for frame in frames]
    all_lifts = []
    for index, (frame, operator) in enumerate(zip(frames, old, strict=True)):
        lifted = tuple(
            compiler.canonical_frame(N + 1, [*frame, *([E] if flag else [])])
            for flag in (0, 1)
        )
        spectator = embed(compiler, operator)
        expected = spectator, spectator.then(compiler.cgate(N + 1, E))
        for physical, factorized in zip(lifted, expected, strict=True):
            equal_signed_clifford(physical, factorized, index in column_checks)
        all_lifts.append(lifted)

    signed_checks = []
    witnessed_translation_control = False
    for rank, at, reg, start, stop in examples:
        original = old[start].adjoint().then(old[stop])
        recipe, lowered = compiler.lower_child(original)
        assert recipe["rank"] == rank
        for old_flag, new_flag in ((0, 0), (0, 1), (1, 0), (1, 1)):
            delta = new_flag - old_flag
            expected = all_lifts[start][old_flag].adjoint().then(all_lifts[stop][new_flag])
            actual = combine_with_fresh(compiler, lowered, rank, delta)
            equal_signed_clifford(actual, expected, True)
            equal_signed_clifford(actual.adjoint(), expected.adjoint(), True)
            assert compiler.rank([x for x, _, _ in expected.tab[N + 1 :]]) == rank + abs(delta)
            if delta == -1 and not witnessed_translation_control:
                assert actual.circuit[-1] == ("X", E)
                wrong = combine_with_fresh(compiler, lowered, rank, 1)
                assert wrong.zero_state() != expected.zero_state()
                witnessed_translation_control = True
        signed_checks.append({"event": at, "reg": reg, "pair": [start, stop], "rank": rank})
    assert witnessed_translation_control
    payload = json.dumps({
        "compressed_word_sha256": WORD_SHA,
        "compiler_sha256": PIN_SHA,
        "canonical_frames": len(frames),
        "exact_lifted_tableaux": 2 * len(frames),
        "exact_lifted_frame_columns": 2 * len(column_checks),
        "move_histogram": histogram,
        "move_examples": signed_checks,
        "exact_compiled_move_and_adjoint_checks": 8 * len(signed_checks),
        "translation_inverse_verified_at_tensor_widths": [1, 2, 3],
        "dropping_inverse_translation_fails": witnessed_translation_control,
        "dropping_inverse_global_phase_in_alternate_wrapper_fails_at_widths": [1, 2, 3],
    }, indent=2) + "\n"
    if args.output is not None:
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
