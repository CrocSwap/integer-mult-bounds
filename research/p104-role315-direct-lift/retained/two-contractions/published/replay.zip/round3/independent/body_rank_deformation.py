"""Reprice a #7546 Type-B body dilation funded by exactly charged roof adapters."""

import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from time import monotonic


PRICE = '60a743d13f668ef86db4b8215b4d5d04430a671ba6f1fe06d9c1c4c3dfe86da5'
CALLER = '255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc'
WHOLE = 'a0beec65810ba6be75053761eeab6a763506ac224e53c6187d8c8e977e1eefb9'
HERE=Path(__file__).resolve().parent


def require(condition,label):
    if not condition:
        raise ValueError(label)


def pin(path,sha):
    raw=path.read_bytes()
    require(sha256(raw).hexdigest()==sha,f'input pin {path}')
    return raw


def price_engine():
    path=HERE/'pinned'/'interval_gate.py'
    pin(path,PRICE)
    spec=spec_from_file_location('pricing',path)
    module=module_from_spec(spec);spec.loader.exec_module(module)
    return module


def stage_profile(caller,whole,body_width,assignment=None):
    """Change the stage body widths, with independently charged rail corrections."""
    p0=Counter({int(r):qty for r,qty in whole['signed_profile']['signed_paid'].items()})
    t0=Counter({int(r):qty for r,qty in whole['signed_profile']['signed_productive'].items()})
    p,t=p0.copy(),t0.copy()
    kind=caller['types']['B']
    scale=len(kind['ports'])
    stages=caller['stages']
    widths=[body_width]*stages if assignment is None else assignment
    require(len(widths)==stages, 'each changed stage has one positive width')
    for e in caller['events']:
        if e[0]=='B' and e[1] in ('IDLE_ONE','IDLE_ODD'):
            k=len(e[3])
            odd=e[1]=='IDLE_ODD'
            p[8*k+odd]-=scale
            rank=sum(widths[s-1] for s in e[3])+odd
            if rank:
                p[rank]+=scale
    for phase,z,*mask in kind['diagonal']:
        require(phase==-1 and z==0,'signed B target orientation')
        k=sum(mask)
        t[8*k+1]-=scale
        t[sum(q for q,on in zip(widths,mask,strict=True) if on)+1]+=scale
    # Supply or remove every independent missing axis per native rail.
    for width in widths:
        delta=abs(width-8)
        if delta:
            p[delta]+=2*scale
    net=t.copy()
    net.subtract(p)
    surplus=sum(r*count for r,count in net.items())
    net.update(p0)
    net.subtract(t0)
    net={r:count for r,count in net.items() if count}
    require(min(t.values())>=0 and min(p.values())>=0,'literal profile stock')
    return {'surplus':surplus,'delta':net}


def main():
    start=monotonic()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('caller',type=Path)
    parser.add_argument('whole',type=Path)
    args=parser.parse_args()
    caller=json.loads(pin(args.caller,CALLER))
    whole=json.loads(pin(args.whole,WHOLE))
    p=price_engine()
    k=Fraction('.003648411294790')
    out={}
    for width in range(4,17):
        data=stage_profile(caller,whole,width)
        value=p.moment(data['delta'],k)
        data['signed_moment_delta']=p.value(value)
        data['sign']=-1 if value[1]<0 else (1 if value[0]>0 else 0)
        out[width]=data
    isolated_roles={e[2] for e in caller['events'] if e[:2]==['B','IDLE_ODD']}
    require(isolated_roles=={68,69,70,71},'literal four isolated phase roles')
    for role in isolated_roles:
        uses=[]
        for e in caller['events']:
            if e[0]=='J':
                if role in e[3][:2]:uses.append(e)
            elif e[0]=='B' and (e[2]==role or e[1] in ('ADD','SWAP','QUERY') and e[3]==role):
                uses.append(e)
        require(len(uses)==1 and uses[0][1]=='IDLE_ODD','one complete direct phase job per rail')
    single=[]
    for stage in range(17):
        widths=[8]*17;widths[stage]=9
        data=stage_profile(caller,whole,8,widths)
        value=p.moment(data['delta'],k)
        single.append({'stage':stage+1,'surplus':data['surplus'],'sign':-1 if value[1]<0 else (1 if value[0]>0 else 0),
                       'delta':p.value(value)})
    require(out[8]['surplus']==1424,'known-answer baseline surplus')
    require(out[8]['signed_moment_delta']==[0.0,0.0],'known-answer baseline moment')
    print(json.dumps({'typed':'screen for complete corrected B body per rail, admitted native unchanged',
        'cases':out,'single_stage_dilations':single,'isolated_phase_jobs_per_port':len(isolated_roles),
        'seconds':monotonic()-start},indent=2))


if __name__=='__main__':
    main()
