"""Recover Type-B common spectators and 7-axis projective restriction of #7546."""

import argparse
from collections import Counter
import gzip
from hashlib import sha256
import json
from pathlib import Path
from time import monotonic


WORD = 'bdecd5cc1cb9f164dc695ce07a07d5d44e9961996fcdfa4d77b4092fecbda745'


def require(test, label):
    if not test:
        raise ValueError(label)


def parity(x):
    return x.bit_count() & 1


def dot(a,b):
    return parity(a & b)


def span(vectors):
    values = {0}
    for v in vectors:
        values |= {u ^ v for u in values}
    return values


def rank(vectors):
    pivots={}
    for v in vectors:
        while v:
            p=v.bit_length()-1
            if p not in pivots:
                pivots[p]=v
                break
            v^=pivots[p]
    return len(pivots)


def frame_space(frames):
    return tuple(span(b) for b in frames)


def compress(v, coordinate_vectors):
    return sum(dot(v,x) << i for i,x in enumerate(coordinate_vectors))


def orthonormal_basis(W, n):
    """Find one orthonormal basis or prove no such ordered basis over the small field."""
    if not n:
        return []
    for u in sorted(W):
        if dot(u,u):
            tail = orthonormal_basis({w for w in W if not dot(w,u)}, n-1)
            if tail is not None:
                return [u, *tail]
    return None


def contact_edges(program):
    counts=Counter()
    for e in program:
        if e[0] in ('ADD','COPY'):
            if e[1]!=e[2]:counts[e[1],e[2]] += 1
    return counts


def analyze(word, deadline):
    n=9
    public=word['public']
    main_B=sorted(set(range(len(word['ports'])))-set(word['hosted']['Dports']))
    x_B={word['live'][j] for j in main_B}
    all_B_roles=sorted(x_B|{112+r for r in x_B})
    B=[word['ports'][j] for j in main_B]
    W=span(B)
    S={x for x in range(1<<n) if all(not dot(x,b) for b in B)}
    require(len(W)==128 and len(S)==4 and W&S=={0},'nondegenerate rank-7 span and two-axis complement')
    basis_W=orthonormal_basis(W,7)
    basis_S=orthonormal_basis(S,2)
    require(basis_W and basis_S,'orthonormal spectator split')
    H=(*basis_W,*basis_S)
    require(rank(H)==9 and all(dot(u,v)==(i==j) for i,u in enumerate(H) for j,v in enumerate(H)),
            'unimodular orthogonal frame for both sectors')
    fits={u:compress(u,basis_W) for u in W}
    W_frames=[span(compress(x,basis_W) for x in frame) for frame in word['frames']]
    frames=frame_space(word['frames'])
    pure={i for i,frame in enumerate(frames) if len(frame)==len(frame&W)*len(frame&S)}
    native_moves=Counter((e[2],e[3]) for e in word['program'] if e[0]=='MOVE')
    counts=Counter()
    defect_hist=Counter()
    examples=[]
    for (u,v),n in sorted(native_moves.items()):
        require(monotonic()<deadline,'native projection census deadline')
        a,b=frames[u],frames[v]
        c,d=W_frames[u],W_frames[v]
        e,f=a&S,b&S
        old_r=(len(a)).bit_length()+(len(b)).bit_length()-2*(len(a&b)).bit_length()
        new_r=(len(c)).bit_length()+(len(d)).bit_length()-2*(len(c&d)).bit_length()
        spectator_r=(len(e)).bit_length()+(len(f)).bit_length()-2*(len(e&f)).bit_length()
        require(old_r==abs(len(word['frames'][u])-len(word['frames'][v])), 'retained MOVE rank and nesting')
        require(0<=new_r<=old_r,'orthogonal projection of nested MOVE cannot increase rank')
        counts['all_moves']+=n
        if u in pure and v in pure:
            require(old_r==new_r+spectator_r,'exact split ranks add on block diagonal chart pair')
            counts['both_charts_factor']+=n
            if spectator_r:
                counts['both_factor_and_spectator_move']+=n
        else:
            counts['at_least_one_chart_mixed']+=n
        if old_r!=new_r:
            counts['projected_rank_decrease']+=n
            defect_hist[old_r-new_r]+=n
            if len(examples)<6:
                examples.append({'pair':[u,v],'old_rank':old_r,'projected_rank':new_r,
                                 'factorable_charts':[u in pure,v in pure],'occurrences':n})

    kept_targets=Counter()
    helper_moves=Counter()
    productive=set(range(public)) - (set(word['live'])|{112+i for i in word['live']}|set(word['hosted']['X2'])|set(word['hosted']['Y2']))
    for r in sorted(productive):
        u,v=word['initial'][r],word['final'][r]
        a,b=frames[u],frames[v]
        require(a<=b,'productive helper nesting')
        old_r=len(word['frames'][v])-len(word['frames'][u])
        new_r=len(W_frames[v]).bit_length()-len(W_frames[u]).bit_length()
        kept_targets[old_r,new_r]+=1
    for u,v in native_moves:
        old_r=abs(len(word['frames'][v])-len(word['frames'][u]))
        new_r=abs(len(W_frames[v]).bit_length()-len(W_frames[u]).bit_length())
        helper_moves[old_r,new_r]+=native_moves[u,v]

    e=contact_edges(word['program'])
    B_roles=set(all_B_roles)
    contact_B=Counter()
    for (dst,src),n in e.items():
        if dst in B_roles or src in B_roles:
            key = 'B_B' if dst in B_roles and src in B_roles else 'B_out' if dst in B_roles else 'out_B'
            contact_B[key]+=n
    A_live=set(word['hosted']['Dports'])
    bad_A=[]
    for a in sorted(A_live):
        p=word['ports'][a]
        if dot(p,p) and p not in W:
            bad_A.append([a,p,fits.get(p, compress(p,basis_W)),compress(p,basis_S)])
    b_port_frame=[]
    for idx in main_B:
        for r in (word['live'][idx],112+word['live'][idx]):
            i,j=word['initial'][r],word['final'][r]
            require(i in pure and j in pure, 'every Type B main endpoint splits')
            b_port_frame.append({'role':r,'input_chart':i,'output_chart':j,
                                 'spectator_input_rank':len(frames[i]&S).bit_length()-1,
                                 'spectator_output_rank':len(frames[j]&S).bit_length()-1})
    spectator_x_to_y=Counter((v['spectator_input_rank'],v['spectator_output_rank']) for v in b_port_frame)
    return {'type_B_ports':main_B,'type_B_port_vectors':B,'W_basis':basis_W,'S_basis':basis_S,
            'literal_total_frames':len(frames),'factorable_frames':len(pure),
            'move_projection_counts':counts,'rank_drop_occurrences':defect_hist,
            'move_examples':examples,'source_quotient_paid_by_rank':{f'{a}:{b}':v for (a,b),v in sorted(helper_moves.items())},
            'source_quotient_targets_by_rank':{f'{a}:{b}':v for (a,b),v in sorted(kept_targets.items())},
            'type_B_main_endpoint_examples':b_port_frame, 'B_port_spectator_endpoint_types':{f'{a}:{b}':n for (a,b),n in spectator_x_to_y.items()},
            'B_main_direct_contacts':contact_B,'A_ports_mixed_or_spectator_component':len(bad_A),
            'A_port_projection_examples':bad_A[:8]}


def main():
    start=monotonic()
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('word',type=Path)
    args=p.parse_args()
    raw=gzip.decompress(args.word.read_bytes())
    require(sha256(raw).hexdigest()==WORD,'exact #7546 source word')
    report=analyze(json.loads(raw),start+20)
    print(json.dumps({'word_sha256':WORD,**report,'seconds':monotonic()-start},indent=2))


if __name__=='__main__':
    main()
