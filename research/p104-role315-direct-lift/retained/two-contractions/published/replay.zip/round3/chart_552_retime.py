# SPDX-License-Identifier: Apache-2.0
"""Chronological two-cut BIT routing using an existing rank-one top ingress."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


WORK = Path(__file__).resolve().parents[1]
STOCK = run_path(str(WORK / "round2/top_ingress_stock.py"))
INVERSE = run_path(str(WORK / "round2/inverse_complement.py"))
TERMINAL = STOCK["TERMINAL"]
SWAP, PORTS, X = STOCK["SWAP"], STOCK["PORTS"], STOCK["MASK"]
BASE, PRICE = SWAP["BASE"], SWAP["PRICE"]
need, rank, contains = SWAP["need"], TERMINAL["rank_with_witness"], TERMINAL["span_contains"]
bits, solve = int.bit_count, INVERSE["solve"]

CHART, Y_PORT = 552, 27
Y, FULL = PORTS + Y_PORT, 1
PAIRING = (33, 38, 77, 87)
MODE = sum(1 << p for p in PAIRING)
FIRST_EXIT, CUT = 27122, 33174


def top_space(word, stock):
    """Rank needed beyond frozen nonterminal arrivals, allowing all terminal arrivals to change."""
    frames = set(word["final"][PORTS:2 * PORTS])
    fixed = [row for chart, row, _ in stock if chart not in frames]
    desired = BASE["endpoint"](word, True)
    wanted = [row for row, frame in zip(desired, word["final"], strict=True) if frame == FULL]
    old = [row for _, row, _ in stock]
    baseline = BASE["endpoint"](word, False)
    baseline_top = [row for row, frame in zip(baseline, word["final"], strict=True) if frame == FULL]
    need(len(rank(old + baseline_top)) == len(rank(old)) == len(baseline_top) == 545,
         "all top rows remain on top, including the public ownership swaps")
    need(len(fixed) == 212 and len(rank(row & X for row in fixed)) == 94,
         "rank of unchanged ingress projections")
    need(len(rank(wanted + fixed)) - len(rank(wanted)) == 94,
         "the extra 94 dimensions include arbitrary high helper returns")
    need(all(any((row >> i) & 1 for row in fixed) for i in range(PORTS)),
         "every individual X coordinate survives in unchanged top arrivals")
    return {"free_terminal_ingresses": len(stock) - len(fixed), "fixed_ingresses": len(fixed),
            "full_swap_top_rank": len(rank(wanted)), "top_rank_with_fixed_old_rows": len(rank(wanted + fixed)),
            "extra_top_ingresses_at_least": 94}


def joint_source_rows(word, stock):
    """Verify composition at both ends of the retimed same-frame contact."""
    exits = [(i, word["program"][i][1], row) for f, row, i in stock if f == CHART]
    survivors = [row for f, row, _ in stock if f != CHART]
    need([i for i, _, _ in exits] == list(range(FIRST_EXIT, FIRST_EXIT + 3)), "actual consecutive exits")
    need([bits(row & MODE) % 2 for _, _, row in exits] == [1, 0, 1], "exact null-side witness")
    need(not any(bits(row & MODE) % 2 for row in survivors), "other arrivals annihilate mode")
    need(not STOCK["raw_pure_x_modes"]([r for _, _, r in exits], 7), "clipped rows are all dirty")
    need(Y == 138 and word["program"][CUT - 2] == ["MOVE", Y, 99, CHART] and
         word["program"][CUT - 1] == ["ADD", Y, 806, CHART], "target Y is resident and decoded")
    need(not any(e[0] == "MOVE" and e[2] == FULL for e in word["program"]), "full is a sink for values")
    origin, _, _ = exits[0]
    need(all(e[0] != "SWAP" for e in word["program"][origin:CUT]), "no owner swaps in the commute window")
    return exits


def retime(word, exits, exchange):
    """Buffer one ingress below full and commute only old full-chart ADDs."""
    result, delayed = [], []
    origin, carrier, _ = exits[0]
    paired = exits[-1][1]
    for i, event in enumerate(word["program"]):
        if i == origin:
            if exchange:
                result.append(["ADD", paired, carrier, CHART])
            continue
        if origin < i < CUT and event[0] == "ADD" and event[-1] == FULL:
            delayed.append(event)
            continue
        if i == CUT:
            if exchange:
                result.extend([["ADD", carrier, Y, CHART], ["ADD", Y, carrier, CHART],
                               ["ADD", carrier, Y, CHART]])
            result += [word["program"][origin], *delayed]
        result.append(event)
    return {**word, "program": result}, len(delayed)


def change_basis(current, desired, roles, frame):
    """Synthesize a coframed invertible GF(2) basis change by exact row elimination."""
    indexed = list(enumerate(current))
    coeffs = [solve(indexed, value) for value in desired]
    need(all(row is not None for row in coeffs), "every requested full row is reconstructible")
    matrix = [sum(1 << i for i in row) for row in coeffs]
    undo = []
    for col, dst in enumerate(roles):
        key = 1 << col
        pivot = next((r for r in range(col, len(roles)) if matrix[r] & key), None)
        need(pivot is not None, "requested row transformation is invertible")
        if pivot != col:
            matrix[col], matrix[pivot] = matrix[pivot], matrix[col]
            undo.append(["SWAP", dst, roles[pivot]])
        for i, row in enumerate(matrix):
            if i != col and row & key:
                matrix[i] ^= matrix[col]
                undo.append(["ADD", roles[i], dst, frame])
    need(matrix == [1 << j for j in range(len(roles))], "basis-to-identity replay")
    return undo[::-1]


def complete_exchange(raw, cut_rows, drop, p):
    """Return the one X-mode in the lower rail, while restoring both helper banks."""
    expected = BASE["endpoint"](raw, False)
    for j in PAIRING:
        expected[j] ^= 1 << p
    expected[p], expected[Y] = 1 << Y, 1 << p
    n = raw["public"]
    slot = n + raw["owned_fields"]
    roles = [r for r, f in enumerate(raw["final"]) if f == FULL]
    current = [cut_rows[r] for r in roles]
    wanted = [expected[r] for r in roles]
    suffix = change_basis(current, wanted, roles, FULL)
    recipe = solve(zip(roles, wanted, strict=True), drop ^ 1 << p)
    need(recipe is not None and len(recipe) > 0, "independent dirty term must be returned")
    suffix += [["INIT", slot, FULL]]
    suffix += [["ADD", slot, q, FULL] for q in recipe]
    suffix += [["MOVE", slot, FULL, CHART], ["ADD", Y, slot, CHART], ["CLEAR", slot, CHART]]
    return {**raw, "owned_fields": raw["owned_fields"] + 1, "program": raw["program"] + suffix}, expected, len(recipe)


def scoped_price(paid):
    """A favorable complete-dual-output comparison, not credit assigned to this endpoint."""
    targets = Counter({2: 1, 4: 25, 6: 1, 8: 632})
    moment, sub = PRICE["power_sum"], PRICE["subtract"]
    result = {}
    for saving in ("0.005", "0.0227"):
        s = Fraction(saving)
        # If every port still requires a dedicated correction down after the
        # frozen-terminal substitutions, with all those corrections rank one.
        two_directions = paid + Counter({1: 94 + PORTS})
        result[saving] = {"94_ingresses_only": sub(moment(targets, s), moment(paid + Counter({1: 94}), s)),
                          "94_ingresses_and_111_dedicated_returns": sub(moment(targets, s), moment(two_directions, s))}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--emit", type=Path, help="also serialize the first changed word for independent replay")
    args = parser.parse_args()
    start = perf_counter()
    stop = monotonic() + 45
    word = SWAP["load"](args.word)
    stock = STOCK["pack_top_rows"](word)
    space = top_space(word, stock)
    _, _, paid = BASE["prepare"](word)
    exits = joint_source_rows(word, stock)
    baseline = BASE["endpoint"](word, False)
    drop = exits[0][2]
    shifted, gates = retime(word, exits, False)
    need(SWAP["rail_replay"](shifted)[0] == baseline, "reordering alone preserves every coefficient")
    raw, _ = retime(word, exits, True)
    exposed, raw_paid, _, _, _, _ = SWAP["rail_replay"](raw)
    need(raw_paid == paid and len(rank(exposed)) == word["public"] and exposed[Y] == drop,
         "one ingress repurposed with no paid change and no global loss of dimension")
    in_full = [row for r, row in enumerate(exposed) if word["final"][r] == FULL]
    need(not any(bits(row & MODE) % 2 for row in in_full), "old X null direction is removed from full")
    need(contains(rank(in_full), 1 << Y), "original Y is now pure at full")
    variants = []
    H = word["frames"][str(CHART)]
    for port in PAIRING:
        need(monotonic() < stop, "end-to-end routing replay reached its 45 second budget")
        changed, target, correction_adds = complete_exchange(raw, exposed, drop, port)
        observed, invoice, ops, peak, _, _ = SWAP["rail_replay"](changed)
        need(observed == target and invoice - paid == {1: 1} and len(rank(observed)) == word["public"],
             "exchange mode, all independent inputs, exact Y output and arbitrary helper returns")
        need(observed[2 * PORTS:] == baseline[2 * PORTS:], "every independent helper restored")
        broken = {**changed, "program": changed["program"][:-2] + changed["program"][-1:]}
        wrong = SWAP["rail_replay"](broken)[0]
        need([i for i, (a, b) in enumerate(zip(wrong, target, strict=True)) if a != b] == [Y],
             "dirty-helper cancellation controls the lower output")
        L = word["frames"][str(word["start"][port])]
        need(BASE["rational_rank"](L["B"] + H["B"]) == 7, "this source line lies inside the receiving hyperplane")
        variants.append({"pivot_X": port, "other_X_rows_add_pivot": [j for j in PAIRING if j != port],
                         "down_cleanup_sources": correction_adds, "ops": ops, "peak_owned": peak,
                         "paid": invoice, "physical_rank_of_Y_from_X": 6})
        if args.emit is not None and port == PAIRING[0]:
            args.emit.write_text(json.dumps(changed, separators=(",", ":")) + "\n", encoding="utf-8")
    result = {"status": "PASS_BIT_TWO_CUT_MODE_EXCHANGE", "source_sha256": BASE["SOURCE_SHA"],
              "chart": CHART, "target_Y": Y_PORT, "mode_X": list(PAIRING), "old_egress": [i for i, _, _ in exits],
              "held_exit_until": CUT, "retimed_full_gates": gates, "replaced_row_X_bits": bits(drop & X),
              "replaced_row_helper_bits": bits(drop >> (2 * PORTS)), "source_top": space, "controls":
              ["zero-change retiming", "no-cleanup mutation at all four pivots", "rational boundary inclusions"],
              "variants": variants, "interval_denominator": PRICE["SCALE"], "relaxed_full_swap": scoped_price(paid)}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(result["status"], f"one paid rank-one descent for four exact pivot variants; {perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
