# Hamming tetrad packets for BIT incidence

The exact #7001 head geometry has eight coordinate lines and 103 signed lines on the 14 weight-four supports of the extended Hamming code. The two-way boundary has 111 independent X inputs at their head lines and 111 independent Y inputs at zero. Its outputs are the swapped values at the full X frames and the complementary Y hyperplanes. The chronological nine-descent proof supplies the same canonical fitting correction B0 for every variant below. This round changes the monotone orthogonal complement of B0. [Selected BIT word](https://github.com/CrocSwap/integer-mult-bounds/pull/7001)

## Orthogonality as a sign table

Two distinct tetrads have disjoint supports or meet in a coordinate pair. For disjoint supports, every pair of signed roots is orthogonal. For a pair intersection {a,b}, all roots have equal magnitude at both common coordinates. The dot product vanishes precisely when their sign products on a,b are opposite. Each pair-intersection block is the sum of two disjoint rank-one rectangles over F2. The source roots of each rectangle lie in the three-dimensional frame spanned by the two nonshared axes and e_a±e_b. This frame lies inside every intended recipient cap.

For a fixed tetrad S each of its six pairs occurs in two intersection blocks. Compute each sign-class XOR once and distribute it to both receiver blocks. Complementary blocks use the four-dimensional coordinate frame on S. Axis recipients disjoint from S can read the same all-sign packet. Eight axis donors have singleton packets. Within each live tetrad, retain direct edges for orthogonal pairs.

The same formula applies to any signed coordinate-support family whose crossing sizes are zero or two and whose magnitudes agree on each crossing. The number of recipients reusing a packet depends on the count of supports meeting the source support in the same coordinate pair.

## Exact finite words and prices

The verifier enumerates the 196 ordered tetrad pairs. Counts for overlaps zero, two and four are 14, 168 and 14. The first two classes give 350 literal rectangles. Before fusing the coordinate-axis edges they give 182 packets and 1,166 direct edges. Axis fusion produces **190 packets and 286 direct edges**, accounting for all 6,470 directed orthogonal pairs once.

Gather each zero-owned packet through legal nested MOVEs, send its payload to the required caps through explicit nested MOVEs, and clear the owned fields. The completed complement cancels the off-diagonal part of the unchanged B0 correction. A final Y move from zero to full and two role swaps put the two values in their prescribed rails. Forward whole-input rows and independently followed reverse functionals each check all 49,284 public coefficients. The forward replay also checks exact rational frame containment and all owned lifetimes.

| Word | Paid MOVEs | XORs | Raw shortfall at s=.005 | Raw shortfall at s=.0227 |
|---|---:|---:|---:|---:|
| Direct 6,470 pairs | 7,644 | 15,048 | >44,441.46 | >43,048.72 |
| Tetrad rectangles | 4,400 | 8,560 | >19,657.48 | >19,103.45 |
| Axis fusion | 4,044 | 7,864 | >17,374.61 | >16,893.83 |

The best literal word pays 618 H2 + 262 H3 + 1236 H4 + 1288 H6 + 525 H7 + 115 H8, where H_r=r^(1−s). It saves over 27,066.85 and 26,154.88 raw units relative to the direct control. Both comparisons give the same generous 222 rank-eight target credits. They charge every move of the respective finite words, credit zero owned stock and compare directed power intervals with denominator 2^80. The direct control is simpler than the transport of the selected optimized supplier, which already uses a D4 cell and quad hierarchy. [D4 carrier skeleton](https://github.com/CrocSwap/integer-mult-bounds/tree/e54523517d0f03e58352e647c403a5af3e525a57/research/e8-bit-carrier-skeleton)

## Arbitrary productive stock

A packet owner can have its own independent private value d at public input. Add d to every owned recipient at frame zero before the packet moves. When the completed packet d plus the source XOR arrives, its dirt cancels. For the chronological correction owners, first propagate the dirty coordinates through the actual inter-cut terms and compensate that complete rectangular dirt response at zero. Bring original X values and final correction owners to full before recovery. Recover the correction owners in reverse causal order using the same predecessor XORs. Recover each ordinary packet by adding its original X inputs.

The exact control tests an all-owned baseline, only 182 productive tetrad packets, only nine productive correction carriers, and both. The last checks 170,569 public coefficients in each direction, including all 191 independent dirty originals, and uses peak 112 owned slots. Independent packet promotion increases the net gap by about 4.79 at .005 or 21.11 at .0227 including exact rank-eight product credits. This is the split tariff for 168 paths of shape 0→3→8 and 14 paths of shape 0→4→8. New correction roles incur the same kind of split charge. The explicit restoration and compensation are included. The all-productive control has a raw gap over 21,263.62 and 20,671.69 after all its helper credits.

## Terminal-chain prerequisite

Keep the 190 fused packets and their frames fixed, and deliver each packet directly to each of its recipients along one monotone recipient chain. For a given target, the frames of all contacts before the cap lie within a single proper subspace of its rank-seven hyperplane. Therefore the maximum number of contacts below the cap equals the largest subset of prescribed packet frames whose joint span has rank at most six. The verifier checks the maximum on all 111 target incidence lists in 22 sign-conjugate classes, using 862,009 rank trials. Rank seven modulo 251 certifies rational independence. Each surviving deficient witness is checked by rational elimination.

The eight axis recipients have 14 packet occurrences, of which at most nine fit below the cap. The 103 tetrad recipients have 17 each. Forty-five fit at most eight below the cap and 58 fit at most nine. Thus at least 8(14−9)+45(17−8)+58(17−9)=**909** of 1,863 occurrences must enter their unique rank-seven caps in this model. These are arrival obligations. A general circuit can change them by combining packets before the recipient, using a different first response, or breaking monotonicity.

## A second packet tier

Let two first-tier packets have source frames (U,V) of ranks (u,v).
If at least two independent receivers request both packets, every common
receiver cap contains (W=U+V). Two distinct rank-seven caps intersect in
dimension at most six, so the pair sum can enter rank (w=\dim W\le6)
before being sent to every common receiver. For (m) cap recipients, if
both packets fit strictly below (W), the old and new prices differ by

\[
m\bigl(H_{7-u}+H_{7-v}-H_{7-w}\bigr)-H_{w-u}-H_{w-v}.
\]

This is a structural rule for any packets with common receiver subspaces.
In characteristic two only the sum needs to arrive. The original paid
collection calls constructing each first-tier packet are still charged.
The same pre-add works in any linear coefficient field if the desired
two coefficients, including their signs, match across the recipients.

The exact search considers 4,172 strict pair choices with positive lower
gain at .005. It greedily assigns disjoint packet-recipient occurrences,
using exact rational frame joins and outward price intervals. The selected
202 pairs replace 1,760 separate arrivals by 880 paired arrivals and add
404 paid joins. The nine fitting-correction descents and all public
boundaries stay fixed. Birth at first use and clearance at last use keep
peak owned stock at 121, verified by the literal execution. Forward and
reverse each check all 49,284 independent input/output coefficients.
No existing #7001 auxiliary helper inventory is substituted in this control.

| Two-tier transport result | Value |
| --- | --- |
| Paid MOVEs and XORs | 3,568 and 6,912 |
| Raw reduction from the constructed one-tier word at .005 | >4,674.03 |
| Raw gap to 222 generous rank-eight output credits at .005 | >12,700.57 |
| Raw gap with the same credits at .0227 | >12,372.51 |

This route uses a second tier and therefore escapes the fixed-packet
delivery premise in the previous section. The price still falls short
before physical rounding, compilation, storage routing or outer assembly.

The GPU and integer CPU agree on all 1,125,180 candidate triples. Exactly
23,484 share at least two recipients. The best 20 by overlap share 13
recipients and have rational join rank three. The physical rank search
checks every one of the 23,484 with at least two common recipients.
Allowing the same second-tier merge to accept either two or three base
packets gives 170 pairs and 31 triples after priced greedy assignment.
It replaces 1,832 separate occurrences with 864 arrivals and requires
433 moves into the join frames. The complete literal word pays 3,509
MOVEs and 6,794 XORs, with 122 peak owned fields and the same 49,284
coefficients verified independently in both directions. At .005 it saves
over 200.82 raw units relative to the pair-only route and falls short of
the generous output credit by over 12,499.75. At .0227 the remaining gap
is over 12,175.80. Larger and recursive joins are outside this search.

## Reproduce

From this directory run the five scripts with CPython 3.11 or later and
flags -I -B -S -W error. The names are tetrad_rectangles.py,
affine_incidence.py, receipt_chain_floor.py, packet_pair_transport.py and
packet_group_transport.py. The optional packet_triple_screen.py replays
the candidate overlap arithmetic on an exact CPU backend and on Windows
D3D11 when the graphics adapter is available.
They use the pinned original compressed #7001 source and the round-three
exact nine-cut code. The results concern finite native action and rank
prices. The bill already fails before whole-width physical compilation
and precision.
