"""Check recipient proper-flat packet coverage with exact modular rank witnesses."""

from collections import Counter, defaultdict
from itertools import combinations
import json
from math import lcm
from pathlib import Path
import sys

here=Path(__file__).resolve().parent
sys.path.insert(0,str(here))
from tetrad_rectangles import fitting_calibration, load_word, require, support, tetrad_blocks


def primitive_vector(entry):
    d=lcm(*(x.denominator for x in entry))
    return tuple(int(d*x) for x in entry)


def integer_rank(vectors, modulus=251):
    pivots={}
    for entry in vectors:
        row=[x%modulus for x in entry]
        for j,x in enumerate(row):
            if not x:
                continue
            if j in pivots:
                row=[(a-x*b)%modulus for a,b in zip(row,pivots[j])]
            else:
                inv=pow(x,-1,modulus)
                pivots[j]=[a*inv%modulus for a in row]
                if len(pivots)==7:
                    return 7
                break
    return len(pivots)


def max_packets_in_proper_flat(msgs):
    # Each packet lies in target's exact ambient seven-space. A rank-seven
    # witness modulo p excludes every rational proper subspace.
    r=len(msgs)
    msgs=[tuple(primitive_vector(v) for v in group) for group in msgs]
    examined=0
    for size in range(r,0,-1):
        for aa in combinations(msgs,size):
            examined+=1
            deck=tuple(v for group in aa for v in group)
            v=integer_rank(deck)
            if v < 7:
                # Independent rational confirmation of the first surviving
                # candidate and guard against a modular determinant accident.
                from scan_bit_move_runs import basis
                if len(basis(deck)) < 7:
                    return size,examined
    return 0,examined


def exact_chain_census(heads):
    packets,singles,_=tetrad_blocks(heads,True)
    msgs=defaultdict(list)
    for src,dst,frame in packets:
        for i in dst:
            msgs[i].append(frame[0])
    # The same maximal-subset decision is checked across all terminals; each
    # full-size, empty coefficient dual is the exact negative control.
    counts=Counter()
    work=0
    cap_routed=0
    n=len(heads)
    groups=defaultdict(list)
    for i in range(n):
        # All live roots with the same Hamming support differ by a diagonal
        # coordinate sign flip. The frame set can be transported to the
        # representative because packet frames depend only on support and the
        # opposing sign-product, and no entire sign half is punctured.
        a=tuple(1 if v<0 else 0 for v in heads[i])
        coset=tuple(sorted(tuple(sorted(tuple(int(x)*(-1 if a[k] else 1)
                                               for k,x in enumerate(row)) for row in sh))
                           for sh in msgs[i]))
        # Opposite line signs define the same geometry.
        def line(v):
            return v if next(x for x in v if x) > 0 else tuple(-x for x in v)
        canonical=tuple(sorted(tuple(sorted(line(v) for v in sh)) for sh in coset))
        groups[support(heads[i]),canonical].append(i)
    for group in groups.values():
        i=group[0]
        allowed,examined=max_packets_in_proper_flat(msgs[i])
        k=len(group)
        counts[(support(heads[i]).bit_count(),len(msgs[i]),allowed)]+=k
        cap_routed+=k*(len(msgs[i])-allowed)
        work+=examined
    return {"rank_witness_trials":work,"sign_conjugate_groups":len(groups),
            "minimum_terminal_packet_arrivals":cap_routed,
            "terrain":[{"support":s,"packets":p,"max_below_cap":a,"terminals":q}
                       for (s,p,a),q in sorted(counts.items())]}


if __name__=="__main__":
    heads,_,*_=fitting_calibration(load_word())
    print(json.dumps({"status":"PASS_EXACT_RECTANGLE_TERMINAL_CHAIN_FLOOR",
                      **exact_chain_census(heads)},indent=2))
