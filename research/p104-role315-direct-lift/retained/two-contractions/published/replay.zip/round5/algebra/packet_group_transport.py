# SPDX-License-Identifier: Apache-2.0
"""Compile a joint pair-and-triple choice for the Hamming packet circuit."""

from collections import Counter
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys
from time import monotonic


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from packet_pair_transport import (basis, compile_word, compose, fitting_calibration, load_word,
                                   pick_pairs, prices, replay, require, select_packets,
                                   supported_interval, tetrad_blocks)


def offers(packets, deadline):
    widths = [len(f[0]) for _,_,f in packets]
    masks = [sum(1 << i for i in r) for _,r,_ in packets]
    tariffs = {d:supported_interval(d,Fraction(".005")) for d in range(1,8)}
    cache = {}
    result = []
    trials = Counter()
    for group_size in (2,3):
        for group in combinations(range(len(packets)),group_size):
            if group_size==2:
                i,j = group
                mask = masks[i] & masks[j]
                if mask.bit_count()>=2:
                    vectors = basis(packets[i][2][0]+packets[j][2][0])
                    cache[i,j] = mask,vectors
                else:
                    continue
            else:
                i,j,k = group
                if (i,j) not in cache:
                    continue
                mask,vectors = cache[i,j]
                mask &= masks[k]
                if mask.bit_count()<2:
                    continue
                vectors = basis((*vectors,*packets[k][2][0]))
            trials[group_size] += 1
            rank = len(vectors)
            ds = [widths[p] for p in group]
            require(rank<=6,"common proper subspace of two distinct receiver caps")
            if rank in ds:
                continue
            recipients = frozenset(r for r in range(111) if mask>>r&1)
            per_recipient = sum(tariffs[7-d][0] for d in ds)-tariffs[7-rank][1]
            correction = sum(tariffs[rank-d][1] for d in ds)
            lower_gain = len(recipients)*per_recipient-correction
            if lower_gain>0:
                result.append((lower_gain,group,recipients,vectors,per_recipient,correction))
            if trials[group_size]%1024==0:
                require(monotonic()<deadline,"fixed pair and triple search deadline")
    return result,trials


def main():
    deadline=monotonic()+40
    w=load_word()
    h,*_=fitting_calibration(w)
    packets,singles,_=tetrad_blocks(h,True)
    all_options, trials = offers(packets,deadline)
    pairs = [row for row in all_options if len(row[1])==2]
    pair_choice,pair_cover = select_packets(pairs,len(packets))
    previous_count, previous_choice, previous_cover = pick_pairs(packets,deadline)
    require(len(pairs)==previous_count and pair_choice==previous_choice and pair_cover==previous_cover,
            "independent pair-only search reproduces the exact selection")
    merged, cover = select_packets(all_options,len(packets))
    *baseline,_,_ = compile_word(w,fuse_residual=True)
    dual_paid, dual_check = replay(*compose(baseline,packets,singles,pair_choice,pair_cover))
    work = compose(baseline,packets,singles,merged,cover)
    paid, check = replay(*work)
    require(trials[3]==23484,"every GPU/CPU-confirmed triple with at least two readers is admitted to the exact rank test")
    unique = sum(map(len,cover))
    require(unique==sum(len(ps)*len(rs) for ps,rs,_ in merged),"no incidence is duplicated in the groups")
    comparisons = prices(paid,dual_paid,111)
    require(sum(paid.values())<sum(dual_paid.values()) and monotonic()<deadline,
            "strict fresh recursive gains and bounded test")
    group_sizes = Counter(len(g) for g,_,_ in merged)
    need_counts = Counter((len(g),len(v)) for g,_,v in merged)
    out = {"status":"PASS_JOINT_PAIR_AND_TRIPLE_PACKET_TRANSPORT", "shared_receiver_groups":trials,
           "positive_priced_groups":dict(Counter(len(g) for _,g,_,_,_,_ in all_options)),
           "selected_groups_by_size":group_sizes,"ranks_by_size":{f"{s}:{r}":c for (s,r),c in sorted(need_counts.items())},
           "original_deliveries_reassigned":unique,"merged_deliveries":sum(len(rs) for _,rs,_ in merged),
           "pair_only":{"paid":dict(sorted(dual_paid.items())),"exact":dual_check},
           "mixed_group":{"paid":dict(sorted(paid.items())),"exact":check},"prices_vs_pair_only":comparisons,
           "scope":"two-tier Hamming transport; one join of two or three original packets; fixed canonical nine-descents and arbitrary independent 222 public rails"}
    print(json.dumps(out,indent=2))


if __name__=="__main__":
    main()
