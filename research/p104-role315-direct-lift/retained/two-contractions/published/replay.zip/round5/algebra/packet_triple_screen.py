# SPDX-License-Identifier: Apache-2.0
"""Screen every three-packet common-recipient mask on CPU and D3D11."""

from array import array
import argparse
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import chain, combinations, islice
import json
from pathlib import Path
import sys
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parents[1])]
from tetrad_rectangles import dot, fitting_calibration, load_word, require, tetrad_blocks
from scan_bit_move_runs import basis
from benchmark_helper_cohorts import BACKEND_SHA, Limit, gpu_batch


HLSL = r"""
StructuredBuffer<uint> masks : register(t0);
StructuredBuffer<uint> pairs : register(t1);
RWStructuredBuffer<uint> hits : register(u0);
RWStructuredBuffer<uint> first : register(u1);
[numthreads(64,1,1)]
void main(uint i : SV_DispatchThreadID) {
    const uint p = pairs[i*2];
    const uint c = pairs[i*2+1];
    const uint a = p >> 8;
    const uint b = p & 255u;
    uint n = 0;
    uint least = 0xffffffffu;
    if (a != b && b != c && a != c) {
        for (uint j=0; j<4; ++j) {
            const uint common = masks[a*4+j] & masks[b*4+j] & masks[c*4+j];
            n += countbits(common);
            if (common && least == 0xffffffffu) least = j*32 + firstbitlow(common);
        }
    }
    hits[i] = n;
    first[i] = least;
}
"""


def cpu_batch(masks, rows):
    counts, first = array("I"), array("I")
    for pair, c in rows:
        a,b = pair>>8,pair&255
        common = masks[a]&masks[b]&masks[c]
        counts.append(common.bit_count())
        first.append((common&-common).bit_length()-1 if common else 0xFFFFFFFF)
    return counts,first


def top_records(heads, packets, masks, high):
    out = []
    for count,a,b,c in high:
        components = [packets[p] for p in (a,b,c)]
        recipients = sorted(set.intersection(*(set(r) for _,r,_ in components)))
        joined = basis(v for _,_,f in components for v in f[0])
        require(len(recipients)==count and count==(masks[a]&masks[b]&masks[c]).bit_count(),
                "check recipient set directly")
        require(all(not dot(v,heads[r]) for v in joined for r in recipients) and len(joined)<=6,
                "independently verify exact join rank and every receiver cap")
        out.append({"packets":[a,b,c], "common_recipients":count,"join_rank":len(joined),
                    "recipient_roles":recipients})
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("backend",type=Path);ap.add_argument("output",type=Path)
    ap.add_argument("--cpu-only",action="store_true")
    args = ap.parse_args()
    deadline = monotonic()+30
    guard = Limit() if not args.cpu_only else None
    device = backend = None
    if guard is not None:
        guard.sample("before launch")
        require(sha256(args.backend.read_bytes()).hexdigest()==BACKEND_SHA,"pinned D3D11 backend")
        spec = spec_from_file_location("d3d11",args.backend)
        backend = module_from_spec(spec)
        spec.loader.exec_module(backend)
        backend.HLSL = HLSL
        device = backend.D3D11()
    heads,*_ = fitting_calibration(load_word())
    packets,_,_ = tetrad_blocks(heads,True)
    masks = [sum(1<<i for i in r) for _,r,_ in packets]
    packed = array("I",((m>>(32*j))&0xFFFFFFFF for m in masks for j in range(4)))
    stats, longest = Counter(),[]
    sha = sha256()
    cpu_ms=gpu_ms=0.0
    small={}
    setup_ms=0.0
    try:
        if device is not None:
            start = perf_counter()
            device.open()
            device.compile()
            setup_ms=(perf_counter()-start)*1000
            guard.sample("shader initialized")

        def run(batch):
            nonlocal cpu_ms,gpu_ms
            start = perf_counter()
            expected = cpu_batch(masks,batch)
            cpu = (perf_counter()-start)*1000
            gpu = 0
            if device is not None:
                got,gpu = gpu_batch(backend,device,packed,batch,guard)
                require(expected==got,"GPU and exact unbounded CPU bit masks agree on every result")
            cpu_ms += cpu
            gpu_ms += gpu
            return expected,cpu,gpu

        candidates=((a*256+b,c) for a,b,c in combinations(range(len(masks)),3))
        batches = chain((list(islice(candidates,256)),), iter(lambda: list(islice(candidates,262144)), []))
        for number,batch in enumerate(batches):
            require(monotonic()<deadline,"bounded packet triple screen")
            if guard is not None:
                guard.sample(f"before {number+1} comparison")
            expected,cpu,gpu=run(batch)
            if number==0:
                small={"cases":len(batch),"cpu_ms":cpu,"gpu_ms":gpu}
            sha.update(expected[0].tobytes())
            sha.update(expected[1].tobytes())
            stats.update(expected[0])
            local=sorted((n, p>>8, p&255, c) for n,(p,c) in zip(expected[0],batch,strict=True) if n>=10)[-20:]
            longest=sorted(longest+local)[-20:]
        require(sum(stats.values())==len(masks)*(len(masks)-1)*(len(masks)-2)//6,"all distinct triples checked")
    finally:
        if device is not None:
            device.close()
    if guard is not None:
        guard.sample("GPU context released")
    require(monotonic()<deadline,"bounded triple witness replay")
    result={"status":"PASS_EXACT_TRIPLE_RECIPIENT_SCREEN","device":device.adapter_name if device else "CPU only",
            "packets":len(masks),"cases":sum(stats.values()),"cases_with_two_or_more":sum(v for k,v in stats.items() if k>=2),
            "histogram":dict(sorted(stats.items())),"small":small,"cpu_ms":cpu_ms,"gpu_ms":gpu_ms,
            "gpu_setup_ms":setup_ms,"counts_and_first_sha256":sha.hexdigest(),"resource_samples":guard.samples if guard else [],
            "strongest_exact_frame_witnesses":top_records(heads,packets,masks,longest),
            "scope":"recipient overlap screen for a third packet tier; no join or whole circuit prices are inferred from overlap alone"}
    args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(result["status"],result["cases"],result["cases_with_two_or_more"],f"CPU {cpu_ms:.1f}ms GPU {gpu_ms:.1f}ms setup {setup_ms:.1f}ms")


if __name__=="__main__":
    main()
