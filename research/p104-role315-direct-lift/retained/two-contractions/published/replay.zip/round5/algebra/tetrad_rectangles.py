"""Exact tiled E8 orthogonality circuit and three-LOCAL tariff comparison."""

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here.parents[1] / "algebra"))
from scan_bit_move_runs import load_word
from scan_bit_fixed_graph import supported_interval
sys.path.insert(0, str(here.parents[1] / "round3" / "algebra"))
from concentrated_descents import phase_bases
from nine_cut_geometry import fitting_calibration, hamming_roots
from permute_head_frames import dot, require


def support(row):
    return sum(1 << i for i, v in enumerate(row) if v)


def members(mask):
    while mask:
        low = mask & -mask
        mask ^= low
        yield low.bit_length()-1


def one_space(row, want_hyperplane):
    p = next(i for i,v in enumerate(row) if v)
    cap = tuple(tuple(Fraction(i == j) - (row[j]/row[p] if i == p else 0)
                      for i in range(8)) for j in range(8) if j != p)
    return (cap,(row,)) if want_hyperplane else ((row,),cap)


def coordinate_cut(s, pair=0, parity=None):
    """Frame spanning a tetrad or the class with sign-pair product parity."""
    p = list(members(pair))
    k = -1 if parity else 1
    vec = lambda i,coef=1: tuple(Fraction(coef * (j == i)) for j in range(8))
    src = [vec(i) for i in members(s ^ pair)]
    dual = [vec(i) for i in range(8) if not(s >> i & 1)]
    if pair:
        a,b = p
        src.append(tuple(x+y for x,y in zip(vec(a),vec(b,k))))
        dual.append(tuple(x+y for x,y in zip(vec(a),vec(b,-k))))
    return tuple(src), tuple(dual)


def signed_class(heads, ports, pair, parity):
    a,b = list(members(pair))
    return tuple(i for i in ports if (heads[i][a]*heads[i][b] < 0) == parity)


def tetrad_blocks(heads, fuse_residual=False):
    blocks = defaultdict(list)
    for i, a in enumerate(heads):
        blocks[support(a)].append(i)
    axes = [g[0] for s,g in blocks.items() if s.bit_count() == 1]
    blocks = {s:g for s,g in blocks.items() if s.bit_count() == 4}
    require(len(axes) == 8 and len(blocks) == 14, "unexpected Hamming structure")
    recipes = []
    by_pair = defaultdict(list)
    pair_count = Counter()
    for s,t in product(blocks, repeat=2):
        overlap = s&t
        steps = overlap.bit_count()
        pair_count[steps] += 1
        if steps not in (0,2):
            require(s == t, "wrong tetrad pairing")
            continue
        for sign in range(2 if steps else 1):
            left = signed_class(heads, blocks[s], overlap, sign) if steps else tuple(blocks[s])
            right = signed_class(heads, blocks[t], overlap, 1-sign) if steps else tuple(blocks[t])
            if left and right:
                key = s,overlap,sign
                by_pair[key].extend(right)
                recipes.append((left, right, key))
    used = Counter()
    for left,right,_ in recipes:
        for i,j in product(left,right):
            require(not dot(heads[i],heads[j]), "tetrad rectangle contains a nonorthogonal pair")
            used[i,j] += 1
    direct = []
    for i,j in product(range(len(heads)), repeat=2):
        if i in axes or j in axes or support(heads[i]) == support(heads[j]):
            if not dot(heads[i],heads[j]):
                direct.append((i,j))
                used[i,j] += 1
        require(used[i,j] == int(not dot(heads[i],heads[j])), "orthogonality partition disagrees")
    packets = []
    for key, dst in by_pair.items():
        s,p,a = key
        src = signed_class(heads, blocks[s], p, a) if p else tuple(blocks[s])
        if fuse_residual and not p:
            dst.extend(i for i in axes if not (support(heads[i]) & s))
        require(len(dst) == len(set(dst)), "duplicated reader for a packet")
        packets.append((src,tuple(dst),coordinate_cut(s,p,a)))
    if fuse_residual:
        for i in axes:
            a = support(heads[i])
            reads = tuple(j for j in range(len(heads)) if not support(heads[j]) & a)
            if reads:
                packets.append(((i,),reads,coordinate_cut(a)))
        direct = [(i,j) for i,j in direct if i not in axes and j not in axes]
        merged = Counter(direct)
        for src,dst,_ in packets:
            merged.update(product(src,dst))
        require(merged == used, "axis packets changed the exact matrix")
    return packets,direct,{"ordered_tetrad_pairs":dict(pair_count), "tiled_rectangles":len(recipes),
                           "reusable_packets":len(packets),"individual_edges":len(direct),
                           "orthogonal_edges":sum(used.values())}


def compile_word(word, projected=True, fuse_residual=False):
    heads, puncture, *_ = fitting_calibration(word)
    n = len(heads)
    frames = {int(k): (tuple(tuple(map(Fraction,r)) for r in v["B"]),
                       tuple(tuple(map(Fraction,r)) for r in v["A"]))
              for k,v in word["frames"].items()}
    zero, full = word["start"][n], word["final"][0]
    start = word["start"][:n]
    end = word["final"][n:2*n]
    packets, singles, structure = tetrad_blocks(heads, fuse_residual)
    steps = []
    phases = Counter()
    rec = list(range(2*n,3*n))
    cut = list(range(3*n,3*n+9))
    packet, scratch = cut[-1]+1,cut[-1]+2

    def frame(x):
        i = max(frames)+1
        frames[i] = x
        return i

    def copy(dst, df, src, sf, phase):
        steps.extend([("INIT",scratch,sf),("ADD",scratch,src,sf)])
        if sf != df:
            steps.append(("MOVE",scratch,sf,df))
            phases[phase] += 1
        steps.extend([("ADD",dst,scratch,df),("CLEAR",scratch,df)])

    for i in range(n):
        steps.append(("INIT",rec[i],end[i]))
    if not projected:
        singles = [(i,j) for i,j in product(range(n),repeat=2) if not dot(heads[i],heads[j])]
        packets=[]
    for i,j in singles:
        copy(rec[j],end[j],i,start[i],"orthogonal single")
    for src,dst,space in packets:
        q = start[src[0]] if len(space[0]) == 1 else frame(space)
        steps.append(("INIT",packet,q))
        for i in src:
            copy(packet,q,i,start[i],"orthogonal collect")
        for i in dst:
            copy(rec[i],end[i],packet,q,"orthogonal distribute")
        steps.append(("CLEAR",packet,q))
    roots = hamming_roots()
    missing = [roots[i] for i in puncture]
    _, pairs, spare, _, _, t, s, r = phase_bases(heads,missing)
    high = [frame(one_space(tuple(map(Fraction,missing[i])),True)) for i,_ in pairs] + [
        frame(one_space(tuple(map(Fraction,missing[spare])),True))]+[full]*4
    low = [frame(one_space(tuple(map(Fraction,missing[j])),False)) for _,j in pairs]+[zero]*5
    for i,c in enumerate(cut):
        steps.append(("INIT",c,high[i]))
        for j in members(s[i]):
            copy(c,high[i],j,start[j],"correction collect")
        for j in members(t[i]):
            copy(c,high[i],cut[j],low[j],"correction transit")
        steps.append(("MOVE",c,high[i],low[i]))
        phases["correction descent"] += 1
    for i,c in enumerate(cut):
        for j in members(r[i]):
            copy(rec[j],end[j],c,low[i],"correction distribute")
        steps.append(("CLEAR",c,low[i]))
    for i in range(n):
        steps.extend([("MOVE",n+i,zero,full),("SWAP",i,n+i),("SWAP",n+i,rec[i]),
                      ("CLEAR",rec[i],start[i])])
        phases["main Y ascent"] += 1
    return frames,steps,start+[zero]*n,[full]*n+end,scratch+1,structure,dict(phases)


def replay(frames, steps, start, final, count):
    n = len(start)
    at = start+[None]*(count-n)
    rows = [1 << i for i in range(n)]+[None]*(count-n)
    hist, ops, high = Counter(),Counter(),0
    lives = cleared_dirty = 0
    cache = {}

    def included(a,b):
        if (a,b) not in cache:
            cache[a,b] = all(not dot(x,y) for x,y in product(frames[a][0],frames[b][1]))
        return cache[a,b]

    for op,i,*rest in steps:
        ops[op] += 1
        if op == "INIT":
            require(i >= n and at[i] is None,"invalid owned birth")
            at[i],rows[i] = rest[0],0
            lives += 1
            high = max(high,lives)
        elif op == "CLEAR":
            require(i >= n and at[i] == rest[0],"invalid owned retirement")
            cleared_dirty += bool(rows[i])
            at[i],rows[i] = None,None
            lives -= 1
        elif op == "MOVE":
            a,b = rest
            d = len(frames[b][0])-len(frames[a][0])
            require(at[i] == a and d and (included(a,b) if d > 0 else included(b,a)),
                    "invalid nested movement")
            at[i] = b
            hist[abs(d)] += 1
        elif op == "ADD":
            j,f = rest
            require(i != j and at[i] == at[j] == f,"wrong ADD coframe")
            rows[i] ^= rows[j]
        elif op == "SWAP":
            j, = rest
            require(i != j and None not in (at[i],at[j]),"invalid swap")
            at[i],at[j] = at[j],at[i]
            rows[i],rows[j] = rows[j],rows[i]
        else:
            raise ValueError(op)
    swap = [1 << ((i+n//2)%n) for i in range(n)]
    require(at == final+[None]*(count-n) and rows == swap+[None]*(count-n) and not lives,
            "all-input endpoint or lifetime failure")
    for i,expected in enumerate(swap):
        d = 1 << i
        for op,j,*rest in reversed(steps):
            if op == "ADD" and d >> j & 1:
                d ^= 1 << rest[0]
            elif op == "SWAP" and ((d >> j) ^ (d >> rest[0])) & 1:
                d ^= (1 << j) | (1 << rest[0])
            elif op == "INIT":
                d &= ~(1 << j)
            elif op == "CLEAR":
                require(not (d >> j & 1), "reverse uses retired stock")
        require(d == expected, "reverse endpoint disagrees")
    return hist,{"ops":dict(ops),"peak_owned":high,"nonzero_erasures":cleared_dirty,
                 "each_forward_reverse_coefficients":n*n}


def prices(actual, direct, ports):
    out = []
    for s in (".005",".0227"):
        tariffs = {r:supported_interval(r,Fraction(s)) for r in range(1,9)}
        vals = [sum(v*tariffs[r][k] for r,v in actual.items()) for k in (0,1)]
        old = [sum(v*tariffs[r][k] for r,v in direct.items()) for k in (0,1)]
        gain = [old[k]-vals[1-k] for k in (0,1)]
        gap = [vals[k]-2*ports*tariffs[8][1-k] for k in (0,1)]
        require(gain[0] > 0 and gap[0] > 0,"cost comparison sign failed")
        out.append({"s":s,"paid_saving_from_direct_2pow80":gain,
                    "paid_saving_lower":gain[0]/2**80,"paid_gap_to_2nH8_2pow80":gap,
                    "paid_gap_lower":gap[0]/2**80})
    return out


if __name__ == "__main__":
    word = load_word()
    *tiled,info,tiled_moves = compile_word(word)
    *fused,fused_info,fused_moves = compile_word(word,fuse_residual=True)
    *direct,_,direct_moves = compile_word(word,projected=False)
    pay, checks = replay(*tiled)
    fuse, fused_checks = replay(*fused)
    old, old_checks = replay(*direct)
    print(json.dumps({"status":"PASS_TETRAD_RECTANGLE_WORD", "geometry":info,
                      "tiled_move_roles":tiled_moves,"direct_move_roles":direct_moves,
                      "tiled_paid":dict(sorted(pay.items())),"direct_paid":dict(sorted(old.items())),
                      "tiled_checks":checks,"direct_checks":old_checks,"prices":prices(pay,old,111),
                      "axis_fused_geometry":fused_info,"axis_fused_roles":fused_moves,
                      "axis_fused_paid":dict(sorted(fuse.items())),"axis_fused_checks":fused_checks,
                      "axis_fused_prices":prices(fuse,old,111)},indent=2))
