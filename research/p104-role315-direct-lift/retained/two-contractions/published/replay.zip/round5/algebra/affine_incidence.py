"""One or two dirty productive owners per orthogonal sign packet."""

from collections import Counter
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here))
from tetrad_rectangles import (
    dot, fitting_calibration, hamming_roots, load_word, members,
    one_space, phase_bases, require, supported_interval, tetrad_blocks,
)


def compiler(word, mode=0):
    heads, puncture, *_ = fitting_calibration(word)
    n = len(heads)
    frames = {int(k): (tuple(tuple(map(Fraction,r)) for r in v["B"]),
                       tuple(tuple(map(Fraction,r)) for r in v["A"]))
              for k,v in word["frames"].items()}
    zero, full = word["start"][n], word["final"][0]
    start = word["start"][:n]
    yframe = word["final"][n:2*n]
    packets, singles, structure = tetrad_blocks(heads)
    require(all(j < n for _,j in singles), "bad direct residual")
    steps = []
    stages = Counter()
    public = 2*n
    owner_specs = []
    p_next = public

    def frame(f):
        q = max(frames)+1
        frames[q] = f
        return q

    def role(path, inputs, dst, *args):
        nonlocal p_next
        p = p_next
        p_next += 1
        owner_specs.append((p,path,tuple(inputs),tuple(dst),args))
        return p

    def move(i,a,b,stage):
        if a != b:
            steps.append(("MOVE",i,a,b))
            d = abs(len(frames[b][0])-len(frames[a][0]))
            stages[(stage,d)] += 1

    plan = []
    for src,dst,space in packets:
        q = frame(space)
        if mode in (1,3):
            p = role([zero,q,full],src,dst,"orth packet")
        else:
            p = None
        plan.append((src,dst,q,p))
    roots = hamming_roots()
    omitted = [roots[i] for i in puncture]
    _,pairs,spare,_,_,t,s,r = phase_bases(heads,omitted)
    upper = [frame(one_space(tuple(map(Fraction,omitted[i])),True)) for i,_ in pairs]+ [
        frame(one_space(tuple(map(Fraction,omitted[spare])),True))]+[full]*4
    lower = [frame(one_space(tuple(map(Fraction,omitted[j])),False)) for _,j in pairs]+[zero]*5
    corrections = []
    for j, (a,b) in enumerate(zip(upper,lower)):
        if mode in (2,3):
            p = role([zero,a,b,full],list(members(s[j])),list(members(r[j])),"correction",j)
        else:
            p = None
        corrections.append((j,p))
    # Owned receivers start at frame zero. Public Y stay intact as independent
    # columns until the final paid ascent and coframe role relabeling.
    rec = list(range(p_next,p_next+n))
    carriers = list(range(p_next+n,p_next+n+len(corrections)))
    packet, scratch = carriers[-1]+1,carriers[-1]+2
    # Compute transitive dirt from public correction carriers.
    dirt = []
    for j,p in corrections:
        h = ([] if p is None else [p])
        for i in members(t[j]):
            h.extend(dirt[i])
        dc = Counter(h)
        dirt.append([x for x,q in dc.items() if q % 2])
    for i in range(n):
        steps.append(("INIT",rec[i],zero))
    for src,dst,q,p in plan:
        if p is not None:
            for j in dst:
                steps.append(("ADD",rec[j],p,zero))
    for j,p in corrections:
        for i in members(r[j]):
            for h in dirt[j]:
                steps.append(("ADD",rec[i],h,zero))
    for i in range(n):
        move(rec[i],zero,yframe[i],"receiver init")

    def copy(dst,df,src,sf,stage):
        steps.extend([("INIT",scratch,sf),("ADD",scratch,src,sf)])
        move(scratch,sf,df,stage)
        steps.extend([("ADD",dst,scratch,df),("CLEAR",scratch,df)])

    for i,j in singles:
        copy(rec[j],yframe[j],i,start[i],"single")
    for src,dst,q,p in plan:
        if p is None:
            p = packet
            steps.append(("INIT",p,q))
        else:
            move(p,zero,q,"orth productive")
        for i in src:
            copy(p,q,i,start[i],"orth collect")
        for i in dst:
            copy(rec[i],yframe[i],p,q,"orth distribute")
        if p == packet:
            steps.append(("CLEAR",p,q))
        else:
            move(p,q,full,"orth productive")
    for j,p in corrections:
        a,b = upper[j],lower[j]
        if p is None:
            p = carriers[j]
            steps.append(("INIT",p,a))
        else:
            move(p,zero,a,"correction productive")
        for i in members(s[j]):
            copy(p,a,i,start[i],"correction collect")
        for i in members(t[j]):
            prior = corrections[i][1]
            copy(p,a,carriers[i] if prior is None else prior,lower[i],"correction transit")
        move(p,a,b,"correction descent")
    for j,p in corrections:
        if p is None:
            p = carriers[j]
        for i in members(r[j]):
            copy(rec[i],yframe[i],p,lower[j],"correction distribute")
        if corrections[j][1] is None:
            steps.append(("CLEAR",p,lower[j]))
        else:
            move(p,lower[j],full,"correction productive")
    # The all-input wrapper preserves original x in public X until each helper
    # is uncomputed. Moving x to full is explicit extra cost in this primitive.
    for i in range(n):
        move(i,start[i],full,"source restoration")
    for p,path,src,dst,info in reversed(owner_specs):
        if info[0] == "correction":
            j = info[1]
            for i in members(t[j]):
                prior = corrections[i][1]
                require(prior is not None, "repair of an owned correction carrier")
                steps.append(("ADD",p,prior,full))
        for i in src:
            steps.append(("ADD",p,i,full))
    for i in range(n):
        move(n+i,zero,full,"public y to x")
        steps.extend([("SWAP",i,n+i),("SWAP",n+i,rec[i]),("CLEAR",rec[i],full)])
    return (frames,steps,start+[zero]*(p_next-n),[full]*n+yframe+[full]*(p_next-2*n),
            scratch+1,structure,owner_specs,stages)


def replay(frames, steps, start, final, slots):
    n = len(start)
    live = start+[None]*(slots-n)
    rows = [1 << i for i in range(n)]+[None]*(slots-n)
    moves,ops,left,peak = Counter(),Counter(),0,0
    local = {}

    def subset(a,b):
        if (a,b) not in local:
            local[a,b] = all(not dot(x,y) for x,y in product(frames[a][0],frames[b][1]))
        return local[a,b]

    for op,i,*a in steps:
        ops[op] += 1
        if op == "INIT":
            require(i >= n and live[i] is None,"occupied birth slot")
            live[i],rows[i] = a[0],0
            left += 1
            peak = max(peak,left)
        elif op == "CLEAR":
            require(i >= n and live[i] == a[0],"unlicensed erasure")
            live[i] = rows[i] = None
            left -= 1
        elif op == "MOVE":
            x,y = a
            d = len(frames[y][0])-len(frames[x][0])
            require(live[i] == x and d and (subset(x,y) if d > 0 else subset(y,x)),
                    "unnested move or wrong frame")
            moves[abs(d)] += 1
            live[i] = y
        elif op == "SWAP":
            j, = a
            require(live[i] is not None and live[j] is not None,"absent swap")
            live[i],live[j] = live[j],live[i]
            rows[i],rows[j] = rows[j],rows[i]
        elif op == "ADD":
            j,f = a
            require(i != j and live[i] == live[j] == f,"invalid ADD")
            rows[i] ^= rows[j]
        else:
            raise ValueError(op)
    ports=111
    expect=[1 << ((i+ports) % (2*ports) if i < 2*ports else i) for i in range(n)]
    require(live == final+[None]*(slots-n) and left == 0 and rows == expect+[None]*(slots-n),
            "independent public data or frames not restored")
    for i,target in enumerate(expect):
        d=1 << i
        for op,j,*a in reversed(steps):
            if op == "ADD" and d >> j & 1:
                d ^= 1 << a[0]
            elif op == "SWAP" and ((d >> j) ^ (d >> a[0])) & 1:
                d ^= (1 << j) | (1 << a[0])
            elif op == "INIT":
                d &= ~(1 << j)
            elif op == "CLEAR":
                require(not(d >> j & 1),"reverse functional used dead stock")
        require(d == target,"reverse all-column endpoint")
    return moves, ops, peak, n*n


def price(moves, owners):
    out = []
    for s in (".005",".0227"):
        h = {r:supported_interval(r,Fraction(s)) for r in range(1,9)}
        price_gap = [sum(v*h[r][k] for r,v in moves.items()) - (222+owners)*h[8][1-k] for k in (0,1)]
        out.append({"s":s,"paid_gap_upper_credit":price_gap[0]/2**80, "exact_gap_2pow80":price_gap})
    return out


if __name__ == "__main__":
    w=load_word()
    results=[]
    for mode in (0,1,2,3):
        *literal,geometry,owners,stages = compiler(w,mode)
        moves,ops,peak,comp = replay(*literal)
        results.append({"mode":mode,"input_coefficients":comp,"helpers":len(owners),
                        "paid":dict(sorted(moves.items())),"operations":dict(ops),"peak_owned":peak,
                        "prices":price(moves,len(owners)),
                        "move_roles":{f"{label} rank {rank}":q for (label,rank),q in stages.items()}})
    print(json.dumps({"status":"PASS_PRODUCTIVE_PACKET_RESTORATION","geometry":geometry,"cases":results},indent=2))
