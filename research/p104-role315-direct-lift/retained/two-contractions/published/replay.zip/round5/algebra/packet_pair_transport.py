# SPDX-License-Identifier: Apache-2.0
"""Construct a two-level Hamming packet transport with exact rank prices."""

from collections import Counter
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys
from time import monotonic


HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from tetrad_rectangles import (compile_word, dot, fitting_calibration, load_word,
                               prices, replay, require, supported_interval, tetrad_blocks)
from scan_bit_move_runs import basis


def pick_pairs(packets, deadline):
    """Greedily fund pair packets using their unassigned common recipients."""
    saving = Fraction(".005")
    tariffs = {d: supported_interval(d,saving) for d in range(1,9)}
    tariffs[0] = (0,0)
    readers = [frozenset(r) for _,r,_ in packets]
    dimensions = [len(frame[0]) for _,_,frame in packets]
    pairs = []
    for i,j in combinations(range(len(packets)),2):
        common = readers[i] & readers[j]
        if len(common)<2:
            continue
        vectors = basis(packets[i][2][0]+packets[j][2][0])
        d = len(vectors)
        require(d <= 6, "two distinct recipient caps can intersect in at most six dimensions")
        a,b = dimensions[i],dimensions[j]
        if d in (a,b):
            continue
        line_gain = tariffs[7-a][0]+tariffs[7-b][0]-tariffs[7-d][1]
        fixed = tariffs[d-a][1]+tariffs[d-b][1]
        lower_gain = len(common)*line_gain-fixed
        if lower_gain>0:
            pairs.append((lower_gain,(i,j),common,vectors,line_gain,fixed))
    chosen, covered = select_packets(pairs, len(packets))
    require(monotonic()<deadline,"the first shared pair search is bounded")
    return len(pairs), chosen, covered


def select_packets(offers, packet_count):
    """Assign each packet-to-receiver occurrence to at most one group."""
    chosen = []
    covered = [set() for _ in range(packet_count)]
    for _,group,common,vectors,slope,fixed in sorted(offers,key=lambda z:(-z[0],z[1])):
        recipients = sorted(common - set().union(*(covered[p] for p in group)))
        if len(recipients)<2 or len(recipients)*slope<=fixed:
            continue
        for p in group:
            covered[p].update(recipients)
        chosen.append((group,recipients,vectors))
    return chosen,covered


def compose(literal, packets, singles, chosen, covered):
    """Keep the exact first/last boundaries and replace only packet distribution."""
    frames,original,start,final,slots = literal
    n = len(start)//2
    cut = 3*n
    packet,scratch = cut+9,cut+10
    # Source and receiver roles are unchanged. The original compiler allocates
    # one private first-tier frame per nonaxis packet, before its nine cuts.
    prefix = next(i for i,e in enumerate(original) if e[:2]==("INIT",packet))
    boundary = next(i for i,e in enumerate(original) if e[:2]==("INIT",cut))
    require(original[:n] == [("INIT",2*n+j,final[n+j]) for j in range(n)], "original receiver boundary")
    require(prefix == n + 5*len(singles), "all same-tetrad residues use one paid MOVE")
    first = original[:prefix]
    packet_fields = list(range(slots,slots+len(packets)))
    merge = slots+len(packets)
    packet_charts = []

    def copy(dst, target, src, source):
        first.extend([("INIT",scratch,source),("ADD",scratch,src,source)])
        if source!=target:
            first.append(("MOVE",scratch,source,target))
        first.extend([("ADD",dst,scratch,target),("CLEAR",scratch,target)])

    at = prefix
    for sources,recipients,_ in packets:
        birth,old,chart = original[at]
        require((birth,old)==("INIT",packet),"capture a literal packet collection block")
        packet_charts.append(chart)
        at += 1
        for i in sources:
            at += 4+int(chart!=start[i])
        for j in recipients:
            at += 4+int(chart!=final[n+j])
        require(original[at]==("CLEAR",packet,chart),"original packet's exact owned lifetime")
        at += 1
    require(at==boundary,"exact compilation partition")

    def collect(p):
        sources, recipients, _ = packets[p]
        owner,chart = packet_fields[p],packet_charts[p]
        first.append(("INIT",owner,chart))
        for i in sources:
            copy(owner,chart,i,start[i])
        for j in recipients:
            if j not in covered[p]:
                copy(2*n+j,final[n+j],owner,chart)

    future = Counter(p for group,_,_ in chosen for p in group)
    for p,(owner,chart) in enumerate(zip(packet_fields,packet_charts,strict=True)):
        if not future[p]:
            collect(p)
            first.append(("CLEAR",owner,chart))
    # Process the already selected pairs as a graph on base-packet owners.
    # Create each base packet at first use and clear it at last use.
    live = set()
    pending = list(chosen)
    while pending:
        index = min(range(len(pending)), key=lambda k:(sum((p not in live)-(future[p]==1) for p in pending[k][0]),
                                                       sum(p not in live for p in pending[k][0]), k))
        group,rs,vectors = pending.pop(index)
        for p in group:
            if p not in live:
                collect(p)
                live.add(p)
        d = len(vectors)
        require(all(not dot(v, a) for v in vectors for r in rs for a in frames[final[n+r]][1]), "group fits every recipient")
        chart = max(frames)+1
        inverse = nullspace(vectors)
        require(len(inverse)==8-d,"rank of the complement")
        frames[chart] = (vectors,inverse)
        first.append(("INIT",merge,chart))
        for p in group:
            old = packet_charts[p]
            copy(merge,chart,packet_fields[p],old)
        for r in rs:
            copy(2*n+r,final[n+r],merge,chart)
        first.append(("CLEAR",merge,chart))
        for p in group:
            future[p] -= 1
            if not future[p]:
                first.append(("CLEAR",packet_fields[p],packet_charts[p]))
                live.remove(p)
    require(not live,"paired payload bank closes")
    return frames,first+original[boundary:],start,final,merge+1


def nullspace(rows):
    """Return an exact rational basis for the orthogonal complement."""
    echelon = basis(rows)
    pivots = [(next(i for i,x in enumerate(row) if x), row) for row in echelon]
    free = sorted(set(range(8))-{i for i,_ in pivots})
    result = []
    for i in free:
        vec = [Fraction(j==i) for j in range(8)]
        for p,row in sorted(pivots,reverse=True):
            vec[p] = -sum(row[j]*vec[j] for j in range(p+1,8))
        require(all(not dot(row,vec) for row in rows),"new chart's exact rational annihilator")
        result.append(tuple(vec))
    return tuple(result)


def main():
    deadline=monotonic()+25
    word = load_word()
    heads,*_ = fitting_calibration(word)
    packets,singles,geometry = tetrad_blocks(heads,True)
    *baseline,_,_ = compile_word(word,fuse_residual=True)
    options,chosen,cover = pick_pairs(packets,deadline)
    old_paid, old_checks = replay(*baseline)
    new = compose(baseline,packets,singles,chosen,cover)
    paid, checks = replay(*new)
    total = sum(map(len,cover))
    require(total==2*sum(len(r) for _,r,_ in chosen),"each source occurrence either stays single or enters one pair")
    require(sum(paid.values())<sum(old_paid.values()) and monotonic()<deadline,"exact two-level move gain and deadline")
    out = {"status":"PASS_TWO_LEVEL_ORTHOGONAL_PACKET_TRANSPORT", "geometry":geometry,
           "eligible_pairs":options,"selected_pairs":len(chosen),"old_separate_arrivals_replaced":total,
           "combined_recipient_arrivals":total//2,"source_packet_count":len(packets),
           "pair_dimension_histogram":dict(Counter(len(v) for _,_,v in chosen)),
           "baseline_paid":dict(sorted(old_paid.items())),"baseline":old_checks,
           "paid":dict(sorted(paid.items())),"checks":checks,"prices_relative_to_axis_fused":prices(paid,old_paid,111),
           "scope":"one extra shared packet tier, canonical nine-descents, owned packets; comparison is to the constructed exact one-tier transport"}
    print(json.dumps(out,indent=2))


if __name__ == "__main__":
    main()
