# SPDX-License-Identifier: Apache-2.0
"""Test all coframed input choices against arbitrary exact readout at chart 127."""

import argparse
from fractions import Fraction
from functools import cache
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
TAIL = run_path(str(HERE / "paired_tail_synthesis.py"))
ADJ, ROWS, TOP, NEED = (TAIL[k] for k in ("ADJ", "ROWS", "TOP", "NEED"))
H, EVENT, HIGH = (TAIL[k] for k in ("HELPER", "EVENT", "FULL"))
BAD = (799, 997, 999, 1003)


def build_quotient(word, full, suffix):
    """Convert from original input coordinates to a small terminal quotient."""
    _, _, inv = ROWS["target"](word)
    width = word["public"]
    forbidden = set(range(width)) - (full.keys() - {H})
    transform = []
    for den, row in inv:
        outside = {j: Fraction(c,den) for j,c in row.items() if j in forbidden}
        for k, r in enumerate(BAD,start=width):
            x = sum(c*suffix[j].get(r,0) for j,c in row.items() if j in full and j != H)
            if x:
                outside[k] = Fraction(x,den*TOP["GRID"])
        transform.append(outside)

    @cache
    def convert(raw):
        # Common nonzero scale of a row does not affect any of these spans.
        result = {}
        for j, x in raw:
            for k, b in transform[j].items():
                result[k] = result.get(k, 0) + x*b
        return {i:y for i,y in result.items() if y}

    @cache
    def blind_response(raw):
        return sum(x * Fraction(sum(c*suffix[j].get(H,0) for j,c in inv[k][1].items() if j in full),
                                inv[k][0]*TOP["GRID"]) for k,x in raw)

    return width, convert, blind_response


def screen(word, full, converts, deadline):
    width, convert, _ = converts
    ingress = {i:r for r,(i,_,_) in full.items() if i != EVENT}
    all_quotients, local = {}, {}
    solve = TAIL["solve_echelon"]

    def probe(i, chart, frames, data):
        if i not in ingress:
            return
        stock = [(j, z) for j,(f,z) in enumerate(zip(frames,data,strict=True)) if f==chart and z[1]]
        if chart==1091 and i>EVENT:
            stock.append((H, ROWS["unit"](H)))
        coframe = {}
        for j,row in stock:
            coords = convert(tuple(sorted(row[1].items())))
            if coords:
                solve(coframe, coords.copy(), {j:Fraction(1)})
        usable = {k:(v,c) for k,(v,c) in coframe.items() if k>=width}
        if usable:
            local[i] = {"carrier":ingress[i], "chart":chart,"quotient_rank":len(usable),
                        "sources":{str(k-width):{str(j):str(c) for j,c in sorted(recipe.items())}
                                   for k,(_,recipe) in usable.items()}}
        for k,(v,_) in usable.items():
            solve(all_quotients,v.copy(), {i:Fraction(1)})

    TAIL["record"](word,set(),deadline,probe=probe)
    return local, all_quotients, convert.cache_info().currsize


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("word",type=Path);ap.add_argument("output",type=Path)
    args = ap.parse_args()
    start, deadline = perf_counter(),monotonic()+45
    _, word = ADJ["PHYSICAL"]["load_pins"](args.word)
    full, suffix, _ = TOP["full_program"](word)
    _, _, old, _, _, _, _ = ROWS["capture"](word,deadline)
    width, convert, blind = norm = build_quotient(word, full, suffix)
    # The exact algebraic #7546 sink has 1,052 independent target rows and
    # therefore an invertible square transfer from its 1,052 ingress rows.
    # Dropping the helper row and projecting every other ingress across h
    # gives a basis for the 1,051 clean target rows. The clean original
    # ingresses occupy all but four of those basis directions.
    for r,(i,_,_) in full.items():
        d, x = old[i]
        z = convert(tuple(sorted(x.items())))
        wanted = ({H:d} if r==H else
                  {H:x[H], width+BAD.index(r):d} if r in BAD else {})
        NEED(z==wanted, "exact quotient sends each original ingress to its expected axis")
        NEED(blind(tuple(sorted(x.items()))) == (d if r==H else 0),
             "terminal sensitivity gives the actual unique blind input ray")
    local, space, cache_size = screen(word,full,norm,deadline)
    absent = sorted(set(range(width,width+len(BAD))) - space.keys())
    # Positive control gives the four exact clean directions as possible
    # replacement coframe rows. This is a separate algebraic control.
    control = {}
    for i,r in enumerate(BAD):
        den, coeffs = old[full[r][0]]
        clean = ROWS["increment"]((den,coeffs), ROWS["unit"](H), (-coeffs[H],den))
        control[width+i] = convert(tuple(sorted(clean[1].items())))
    NEED(all(len(v)==1 and v.get(k) for k,v in control.items()), "exact independent clean-row positive controls")
    out = {"status":"PASS_FROZEN_COFRAME_ARBITRARY_READOUT_SCREEN", "source_cuts":len(full)-1,
           "required_full_target_rank":len(full)-1, "ordinary_clean_ingress_rank":len(full)-1-len(BAD),
           "bad_original_ingress_roles":BAD, "coframed_routes_contributing_missing_span":local,
           "new_directions_in_clean_quotient":len(space),
           "quotient_rank_needed":len(BAD),"unfilled_rational_pivot_columns": [BAD[k-width] for k in absent],
           "positive_control_directions":len(control),
           "distinct_source_vectors_projected":cache_size,
           "scope":"arbitrary exact readout at top, arbitrary frozen coframe stock at the original MOVE instants, grant retained h at its later low frame; only already paid ingress roles, no joint changes to lower live stock"}
    NEED(monotonic()<deadline,"bounded exact full coframe screen")
    args.output.write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(out["status"],len(space),f"{perf_counter()-start:.2f}s")


if __name__=="__main__":
    main()
