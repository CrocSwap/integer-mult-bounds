"""Replay two constructive callers and the joint central/body cut arithmetic."""

import argparse
from collections import Counter, deque
from fractions import Fraction
import gzip
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SUPPORT = HERE.parents[1] / "recurrence" / "verify_bit_caller_bound.py"
SPEC = spec_from_file_location("bit_caller_verifier", SUPPORT)
CORE = module_from_spec(SPEC)
SPEC.loader.exec_module(CORE)
need = CORE.need


def ring_add(a, b, characteristic):
    terms = a.copy()
    for exponent, coefficient in b.items():
        terms[exponent] = terms.get(exponent, 0) + coefficient
        if characteristic:
            terms[exponent] %= characteristic
        if not terms[exponent]:
            terms.pop(exponent)
    return terms


def ring_mul(a, b, order, characteristic):
    terms = {}
    for (h, d1, d2, d3), x in a.items():
        for (k, e1, e2, e3), y in b.items():
            key = ((h + k) % order, d1 + e1, d2 + e2, d3 + e3)
            terms = ring_add(terms, {key: x * y}, characteristic)
    return terms


def scalar(c, h=0, bodies=(0, 0, 0)):
    return {(h, *bodies): Fraction(c)} if c else {}


def matmul(a, b, order, characteristic=0):
    return [[ring_add(ring_mul(a[i][0], b[0][j], order, characteristic),
                         ring_mul(a[i][1], b[1][j], order, characteristic),
                         characteristic) for j in range(2)] for i in range(2)]


def identity():
    return [[scalar(1), {}], [{}, scalar(1)]]


def diagonal(c, h, bodies):
    return [[scalar(c, h, bodies), {}], [{}, scalar(c, h, bodies)]]


def stage_body(stage, sign=1):
    return tuple(sign * int(stage == i) for i in range(3))


def verify_bit_word():
    steps = []
    for j in range(3):
        b = stage_body(j)
        n = diagonal(1, 0, b)
        n[int(j == 1)][int(j != 1)] = scalar(1, 1, b)
        inv = diagonal(1, 0, stage_body(j, -1))
        inv[int(j == 1)][int(j != 1)] = scalar(1, 1, stage_body(j, -1))
        steps.append((n, inv))
    swap = [[{}, scalar(1)], [scalar(1), {}]]
    steps.append((swap, swap))
    endpoint, inverse = identity(), identity()
    for forward, backward in steps:
        endpoint = matmul(forward, endpoint, 2, 2)
        inverse = matmul(inverse, backward, 2, 2)
    need(endpoint == diagonal(1, 1, (1, 1, 1)), "Wrong three-LOCAL BIT word")
    need(matmul(endpoint, inverse, 2, 2) == identity(), "BIT inverse failed")
    for omit in range(4):
        changed = identity()
        for i, (forward, _) in enumerate(steps):
            if i != omit:
                changed = matmul(forward, changed, 2, 2)
        need(changed != endpoint, "Missing BIT step went undetected")
    return {"native_calls": 3, "role_swaps_per_port": 3,
            "thin_queries": 0, "body_idles": 0, "basis_columns": 2,
            "omission_controls": 4, "full_formal_inverse": True}


def complex_stage(stage, inverse=False):
    b = stage_body(stage, -1 if inverse else 1)
    if inverse:
        return [[scalar(Fraction(1, 2), 0, b), scalar(1, 1, b)],
                [scalar(Fraction(-1, 2), 3, b), scalar(1, 0, b)]]
    return [[scalar(1, 0, b), scalar(-1, 1, b)],
            [scalar(Fraction(1, 2), 3, b), scalar(Fraction(1, 2), 0, b)]]


def verify_complex_word():
    swap = [[{}, scalar(1)], [scalar(1), {}]]
    first_scale = [[scalar(1), {}], [{}, scalar(2)]]
    last_scale = [[scalar(1), {}], [{}, scalar(Fraction(-1, 2))]]
    even_on_first = [[scalar(1, 2), {}], [{}, scalar(1)]]
    forward = [complex_stage(0), first_scale, complex_stage(1),
               swap, last_scale, even_on_first]
    backward = [even_on_first, [[scalar(1), {}], [{}, scalar(-2)]], swap,
                complex_stage(1, True), [[scalar(1), {}], [{}, scalar(Fraction(1, 2))]],
                complex_stage(0, True)]
    endpoint, inverse = identity(), identity()
    for gate in forward:
        endpoint = matmul(gate, endpoint, 4)
    for gate in backward:
        inverse = matmul(gate, inverse, 4)
    need(endpoint == diagonal(1, 1, (1, 1, 0)), "Wrong two-HOST complex B word")
    need(matmul(endpoint, inverse, 4) == identity(), "Complex B inverse failed")
    for omit in range(len(forward)):
        changed = identity()
        for i, gate in enumerate(forward):
            if i != omit:
                changed = matmul(gate, changed, 4)
        need(changed != endpoint, "Missing complex B SCALE or phase went undetected")
    return {"native_calls": 2, "role_swaps_per_port": 1,
            "dyadic_scales_per_port": 2, "even_phase_maps_per_port": 1,
            "thin_queries": 0, "body_idles": 0, "basis_columns": 2,
            "omission_controls": len(forward), "full_formal_inverse": True}


def crossing(rows, address_count, color):
    right = sum(color[i] << i for i in range(address_count))
    right |= right << address_count
    return CORE.rank(row & right for i, row in enumerate(rows)
                     if not color[i % address_count])


def ternary_host_crossing(rows, address_count, color):
    right = {j for j in range(2 * address_count) if color[j % address_count]}
    matrix = [{j: q % 3 for j, q in row.items() if j in right and q % 3}
              for i, row in enumerate(rows) if not color[i % address_count]]
    basis = {}
    for row in matrix:
        while row:
            k = min(row)
            q = row[k]
            if k not in basis:
                basis[k] = {j: q * x % 3 for j, x in row.items()}
                break
            for j, x in basis[k].items():
                value = (row.get(j, 0) - q * x) % 3
                if value:
                    row[j] = value
                else:
                    row.pop(j, None)
    return len(basis)


def cut_case(bs, hs, displacement, threshold, selector):
    addresses = tuple(product(range(bs), range(hs), range(2)))
    where = {point: i for i, point in enumerate(addresses)}
    n = len(addresses)
    body = [where[((b + displacement) % bs, h, f)] for b, h, f in addresses]
    header = [where[(b, (h + hs // 2) % hs if f < threshold else h, f)]
              for b, h, f in addresses]
    color = [((int(b >= bs // 2) & (selector & 1)) ^
              (int(h >= hs // 2) & ((selector >> 1) & 1))) for b, h, _ in addresses]
    actions = {k: [0] * (2 * n) for k in ("shear", "mixed", "dual", "host")}
    signed_host = [{} for _ in range(2 * n)]
    extras = 0
    for x, dx in enumerate(body):
        qx, dqx = header[x], body[header[x]]
        actions["shear"][dx] ^= 1 << x
        actions["shear"][n + dx] ^= 1 << (n + x)
        actions["shear"][n + dqx] ^= 1 << x
        actions["mixed"][dqx] ^= 1 << x
        actions["dual"][dqx] ^= 1 << x
        actions["dual"][n + dqx] ^= 1 << (n + x)
        actions["host"][dx] ^= (1 << x)
        actions["host"][n + dx] ^= (1 << (n + x))
        actions["host"][dqx] ^= (1 << (n + x))
        actions["host"][n + dqx] ^= (1 << x)
        signed_host[dx][x] = 1
        signed_host[n + dx][n + x] = 2
        signed_host[dqx][n + x] = -1
        signed_host[n + dqx][x] = 2
        extras += (color[x] and color[dx] and not color[qx] and not color[dqx])
    d = sum(bool(color[x] and not color[dx]) for x, dx in enumerate(body))
    need(crossing(actions["shear"], n, color) == 2 * d + extras,
         "Direct crossing rank disagrees with one-way shear formula")
    results = {k: crossing(value, n, color) for k, value in actions.items()}
    r = sum(bool(color[x] and not color[body[header[x]]]) for x in range(n))
    need(results["mixed"] == r and results["dual"] == 2 * r,
         "Mixed diagonal operators lost an independent input")
    # HOST fixture is the mod-2 matrix [[1,q],[q,1]]. Its full block is singular.
    # This is a deliberately failed stand-in for the signed Type B host.
    both_flips = sum(bool(color[x] and not color[dx] and color[header[x]] and
                          not color[body[header[x]]]) for x, dx in enumerate(body))
    need(results["host"] == 2 * d + 2 * extras - both_flips,
         "Singular Type B control did not lose its two-way block rank")
    host_rank = ternary_host_crossing(signed_host, n, color)
    need(host_rank == 2 * d + 2 * extras, "Signed Type B crossing rank does not match")
    return n, results, host_rank


def verify_crossings():
    checks, failed_hosts = 0, 0
    for b, h, delta, threshold in product((2, 4, 6, 8), (2, 4),
                                          (-3, -1, 0, 1, 4), (0, 1, 2)):
        totals = Counter()
        for selector in range(4):
            n, result, host = cut_case(b, h, delta, threshold, selector)
            totals.update(result)
            totals["expected_host"] += host
            failed_hosts += host != result["host"]
            checks += 1
        fb = Fraction(min(delta % b, (-delta) % b), b // 2)
        fh = Fraction(threshold, 2)
        fused = fb + fh - fb * fh
        need(Fraction(totals["shear"], n) == 2 * fb + fh - fb * fh / 2,
             "Average finite shear rank does not have the claimed kernel")
        need(Fraction(totals["mixed"], n) == fused and
             Fraction(totals["dual"], n) == 2 * fused,
             "Average finite diagonal rank does not have the product kernel")
        need(Fraction(totals["expected_host"], n) == 2 * fb + 2 * fh - fb * fh,
             "Average exact Type B rank does not have the claimed kernel")
    need(failed_hosts > 0, "Signed host singular-reduction control was untested")
    return {"finite_cut_matrices": checks, "singular_host_controls": failed_hosts}


def pinned_json(path, expected, compressed=False):
    raw = path.read_bytes()
    need(sha256(raw).hexdigest() == expected, f"Changed pin {path.name}")
    return json.loads(gzip.decompress(raw) if compressed else raw)


def read_complex(folder):
    word = pinned_json(folder / "7546-word.json.gz",
                       "6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32", True)
    whole = pinned_json(folder / "7546-whole.json",
                        "a0beec65810ba6be75053761eeab6a763506ac224e53c6187d8c8e977e1eefb9")
    caller = pinned_json(folder / "phase-7481-inputs" / "caller.json",
                         "255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc")
    paid = Counter(abs(len(word["frames"][rest[1]]) - len(word["frames"][rest[0]]))
                   for op, _, *rest in word["program"] if op == "MOVE")
    helpers = Counter({int(r): q for r, q in whole["signed_profile"]["native_productive"].items()})
    counts = {key: len(value["ports"]) for key, value in caller["types"].items()}
    need(counts == {"A": 96, "B": 8} and sum(paid.values()) == 6276,
         "Complex source paid/native split changed")
    return paid, helpers


def derivative_upper(hist):
    bound = (0, 0)
    for r, coefficient in hist.items():
        if coefficient:
            power = CORE.price(r, int(coefficient > 0), 32)
            bound = CORE.add(bound, CORE.scaled(
                CORE.multiply(power, CORE.log_integer(r)), -int(2 * coefficient), 2))
    need(bound[1] < 0, "Candidate is not certified decreasing on [0, 1/32]")
    # This interval encloses the endpoint sum used to bound the derivative above.
    return CORE.format_bounds(bound)[1]


def bracket(hist, lower, higher, digits):
    scale = 10**digits
    need(CORE.moment(hist, lower, scale)[0] > 0 and
         CORE.moment(hist, higher, scale)[1] < 0, "Initial root bracket signs are wrong")
    while higher - lower > 1:
        middle = (higher + lower) // 2
        value = CORE.moment(hist, middle, scale)
        if value[0] > 0:
            lower = middle
        elif value[1] < 0:
            higher = middle
        else:
            raise ValueError("Exact directed price could not certify bracket")
    return [f"0.{x:0{digits}d}" for x in (lower, higher)]


def invoice(paid, helpers, roots):
    out = helpers.copy()
    out.update(roots)
    out.subtract(paid)
    return out


def typed_prices(bit_paid, bit_helpers, complex_paid, complex_helpers):
    bit_complete = invoice(Counter({r: 3 * q for r, q in bit_paid.items()}),
                           Counter({r: 3 * q for r, q in bit_helpers.items()}), {})
    profiles = {f"BIT_three_LOCAL_width_{head}_body7":
                {**bit_complete, 21 + head: 222} for head in (1, 2, 3, 4)}
    profiles["BIT_joint_cut_upper_per_native"] = invoice(
        bit_paid, bit_helpers, {7: Fraction(333, 2), 8: Fraction(111, 2), 1: Fraction(111, 2)})
    profiles["complex_joint_cut_upper_per_native"] = invoice(
        complex_paid, complex_helpers, {8: 296, 9: 104, 1: 104})
    profiles["complex_two_B_HOSTs_optimistic_A_upper"] = invoice(
        Counter({r: 2 * q for r, q in complex_paid.items()}),
        Counter({r: 2 * q for r, q in complex_helpers.items()}),
        {17: 16, 8: 576, 9: 192, 1: 192})
    profiles["BIT_three_LOCAL_head2_with_minimum_splices"] = (
        Counter(profiles["BIT_three_LOCAL_width_2_body7"]))
    profiles["BIT_three_LOCAL_head2_with_minimum_splices"].subtract({1: 666})
    # CORE operates on fixed-grid integers. Clear the common denominator once.
    def directed_price(hist, fraction):
        scaled_hist = {r: int(2 * x) for r, x in hist.items()}
        return CORE.format_bounds(CORE.scaled(CORE.moment(scaled_hist, *fraction), 1, 2))
    points = {"0": (0, 1), ".005": (5, 1000), ".0227": (227, 10000)}
    out = {label: {k: directed_price(hist, f) for k, f in points.items()}
           for label, hist in profiles.items()}
    cut_names = ("BIT_joint_cut_upper_per_native", "complex_joint_cut_upper_per_native")
    out["root_brackets"] = {
        name: bracket({r: int(2 * x) for r, x in profiles[name].items()}, 0, 10**11, 13)
        for name in cut_names}
    out["derivative_upper_at_0_to_1_over_32"] = {
        name: derivative_upper(profiles[name]) for name in cut_names}
    return out


def finite_separation(bit_paid, bit_helpers):
    repeated_paid = Counter({r: 3 * q for r, q in bit_paid.items()})
    cases = []
    for head, sn, sd, lnum, lden in ((2, 5, 1000, 49, 50), (4, 227, 10000, 19, 20)):
        targets = Counter({r: 3 * q for r, q in bit_helpers.items()})
        targets[21 + head] = 222
        deadline_paid = CORE.moment(repeated_paid, sn, sd)
        total = CORE.moment(targets, sn, sd)
        log_cutoff = CORE.add(CORE.log_integer(15), CORE.scaled(CORE.log_integer(2), -1))
        tilted = (0, 0)
        for r, q in targets.items():
            log_ratio = CORE.add(log_cutoff, CORE.scaled(CORE.log_integer(r), -1))
            radius = CORE.scaled(log_ratio, 1, 100)
            need(radius[1] < CORE.SCALE, "Tilted Markov bound outside its domain")
            # exp(x) <= 1/(1-x) for x<1, including negative x, by 1-x <= exp(-x).
            divisor = (CORE.SCALE - radius[1], CORE.SCALE - radius[0])
            tilted = CORE.add(tilted, CORE.scaled(
                CORE.divide(CORE.price(r, sn, sd), divisor), q))
        alpha = CORE.divide(deadline_paid, total)
        theta = CORE.divide(tilted, total)
        need(alpha[1] < CORE.SCALE and theta[1] < CORE.SCALE, "Unfunded cover product")
        bound = paid_bound = CORE.SCALE
        first = None
        for depth in range(1, 2001):
            bound = CORE.ceil_div(bound * theta[1], CORE.SCALE)
            paid_bound = CORE.ceil_div(paid_bound * alpha[1], CORE.SCALE)
            if CORE.SCALE - bound > paid_bound and paid_bound * lden < lnum * CORE.SCALE:
                first = depth
                break
        need(first is not None, "No finite separation in declared 2000-power screen")
        cases.append({"header_width": head, "saving": str(Fraction(sn, sd)),
                      "source_paid_full_product_alpha": CORE.format_bounds(alpha),
                      "discarded_target_tail_factor": CORE.format_bounds(theta),
                      "first_power_in_this_bound": first,
                      "proved_paid_share_upper": CORE.format_bounds((0, paid_bound))[1],
                      "proved_discarded_share_upper": CORE.format_bounds((0, bound))[1],
                      "paid_rank_maximum": f"7^{first}",
                      "retained_target_rank_floor": f"ceil((15/2)^{first})",
                      "predicate": f"target moment retained > paid moment, paid share < {lnum}/{lden}"})
    return cases


def read_native_contacts(word):
    """Allow new paid one-axis splices on both sides of every literal ADD."""
    public, extra = word["public"], word["owned_fields"]
    dims = {int(frame): meta["dim"] for frame, meta in word["frames"].items()}
    points = list(range(public)) + [None] * extra
    n = public
    equalities, ranks = [], []
    for opcode, role, *args in word["program"]:
        if opcode == "MOVE":
            n += 1
            edge_rank = abs(dims[args[1]] - dims[args[0]])
            ranks.append((points[role], n - 1, edge_rank))
            points[role] = n - 1
        elif opcode == "ADD":
            for current in (role, args[0]):
                ranks.append((points[current], n, 0))
                points[current] = n
            n += 1
        elif opcode == "SWAP":
            points[role], points[args[0]] = points[args[0]], points[role]
        elif opcode == "INIT":
            need(points[role] is None, "Color lift encountered unclosed owned lifetime")
            points[role] = n
            n += 1
        else:
            need(opcode == "CLEAR" and points[role] is not None, "Unexpected native operation")
            points[role] = None
    need(all(x is None for x in points[public:]), "Color lift left an owned slot")
    for i in range(public):
        ranks.append((points[i], n, 0))
        points[i] = n
        n += 1
    return n, equalities, ranks, points[:public]


def union_find(n, equalities):
    parents = list(range(n))

    def root(x):
        while parents[x] != x:
            parents[x] = parents[parents[x]]
            x = parents[x]
        return x

    for first, second in equalities:
        r, s = root(first), root(second)
        if r != s:
            parents[r] = s
    return [root(i) for i in range(n)]


def mincut(n, edges, source, sink):
    residual = [Counter() for _ in range(n)]
    for u, v, cap in edges:
        if u != v:
            residual[u][v] += cap
            residual[v][u] += cap
    flow = 0
    while True:
        parents = {source: None}
        queue = deque([source])
        while queue and sink not in parents:
            u = queue.popleft()
            for v, cap in residual[u].items():
                if cap and v not in parents:
                    parents[v] = u
                    queue.append(v)
        if sink not in parents:
            return flow, frozenset(parents)
        path = []
        v = sink
        while v != source:
            u = parents[v]
            path.append((u, v))
            v = u
        delta = min(residual[u][v] for u, v in path)
        flow += delta
        for u, v in path:
            residual[u][v] -= delta
            residual[v][u] += delta


def color_lift(repo):
    word = CORE.read_git(repo, CORE.PREFIX + "retained/inputs/BIT-NATIVE-WORD.json.gz")
    n, equalities, moves, finals = read_native_contacts(word)
    ports = 111
    equalities.extend((i, finals[i]) for i in range(2 * ports, word["public"]))
    equalities.extend((i, finals[i]) for i in range(2 * ports))
    hard_components = union_find(n, equalities + [(u, v) for u, v, r in moves if not r])
    conflict = set(hard_components[:ports]) & set(hard_components[ports:2 * ports])
    need(conflict, "Existing MOVE-only lift should fail exact coframe equalities")
    components = union_find(n, equalities)
    pin1 = {components[i] for i in range(ports)}
    pin0 = {components[i] for i in range(ports, 2 * ports)}
    need(not pin1 & pin0, "ADD coframes force incompatible X and Y header boundaries")
    counts = []
    for strength in (0, 5, 227):
        den = 1000 if strength == 5 else 10000
        cost = {r: CORE.add(CORE.price(r + 1, strength, den),
                            CORE.scaled(CORE.price(r, strength, den), -1))
                for _, _, r in moves}
        whole = {r: lo for r, (lo, _) in cost.items()}
        edges = [(components[u], components[v], whole[r]) for u, v, r in moves]
        infinity = sum(cap for _, _, cap in edges) + 1
        edges.extend((n, i, infinity) for i in pin1)
        edges.extend((i, n + 1, infinity) for i in pin0)
        flow, one = mincut(n + 2, edges, n, n + 1)
        moves_cut = Counter(r for u, v, r in moves if
                            (components[u] in one) != (components[v] in one))
        need(sum(moves_cut.values()) >= ports and flow < infinity,
             "Added-head color lift violated its independent X/Y derivative bound")
        upper = sum(cost[r][1] * q for r, q in moves_cut.items())
        need(flow == sum(whole[r] * q for r, q in moves_cut.items()), "Cut != reachable flow")
        need(pin1 <= one and one.isdisjoint(pin0), "Certificate violates a main root pin")
        counts.append({"saving": str(Fraction(strength, den)),
                       "selected_old_MOVE_ranks": {r: q for r, q in moves_cut.items() if r},
                       "new_one_axis_splices": moves_cut[0],
                       "optimal_surcharge_interval": CORE.format_bounds((flow, upper))})
    return {"role_segments": n, "coframe_classes": len(set(components)),
            "one_boundary_classes": len(pin1), "zero_boundary_classes": len(pin0),
            "without_splices_conflicting_classes": len(conflict),
            "added_head_width": 1, "helper_boundary_modes_equal": True, "bills": counts}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("complex_pack", type=Path)
    parser.add_argument("--expect", type=Path)
    args = parser.parse_args()
    _, bit_paid, bit_helpers, _, _ = CORE.verify_sources(args.repo)
    complex_paid, complex_helpers = read_complex(args.complex_pack)
    report = {"status": "PASS_JOINT_BODY_HEADER", "bit_word": verify_bit_word(),
              "complex_B_word": verify_complex_word(),
              "cut_controls": verify_crossings(),
              "complete_moment_prices": typed_prices(bit_paid, bit_helpers, complex_paid, complex_helpers),
              "hypothetical_unequal_width_finite_separation": finite_separation(bit_paid, bit_helpers),
              "literal_added_head_cut": color_lift(args.repo)}
    payload = json.dumps(report, indent=2, sort_keys=True)
    if args.expect is not None:
        expected = args.expect.read_text(encoding="utf-8")
        need(expected.rstrip("\n") == payload, "Receipt differs from expected output")
    print(payload)


if __name__ == "__main__":
    main()
