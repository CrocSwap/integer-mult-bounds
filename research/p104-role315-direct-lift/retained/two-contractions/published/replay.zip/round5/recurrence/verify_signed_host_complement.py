"""Exact sector-complement controls for the two-native complex caller."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


SOURCE = Path(__file__).with_name("verify_joint_body_header.py")
SPEC = spec_from_file_location("verify_joint_body_header", SOURCE)
BASE = module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
need = BASE.need


def eye(n):
    return [[Q(int(i == j)) for j in range(n)] for i in range(n)]


def transvection(n, dst, src, coefficient):
    m = eye(n)
    m[dst][src] = Q(coefficient)
    return m


def multiply(a, b):
    cols = tuple(zip(*b))
    return [[sum(x * y for x, y in zip(row, col, strict=True))
             for col in cols] for row in a]


def rank(matrix):
    pivots = {}
    for source in matrix:
        row = source[:]
        for j in range(len(row)):
            x = row[j]
            if x == 0:
                continue
            if j not in pivots:
                pivots[j] = [entry / x for entry in row]
                break
            row = [y - x * z for y, z in zip(row, pivots[j], strict=True)]
    return len(pivots)


def relatives(tagged, n):
    nominal, inverse, actual, u, v = eye(n), eye(n), eye(n), [], []
    for is_odd, dst, src, c in tagged:
        plus = transvection(n, dst, src, c)
        minus = transvection(n, dst, src, -c if is_odd else c)
        if is_odd:
            u.append([-2 * c * row[dst] for row in inverse])
            v.append(nominal[src][:])
        nominal = multiply(plus, nominal)
        inverse = multiply(inverse, transvection(n, dst, src, -c))
        actual = multiply(minus, actual)
        need(multiply(nominal, inverse) == eye(n), "Lost nominal prefix inverse")
    relative = multiply(inverse, actual)
    by_factors = eye(n)
    for column, row in zip(u, v, strict=True):
        elementary = [[x + a * b for x, b in zip(unit, row, strict=True)]
                      for unit, a in zip(eye(n), column, strict=True)]
        by_factors = multiply(elementary, by_factors)
    need(relative == by_factors, "Both q sectors disagree with conjugated increments")
    return u, v, relative


def dimension_control():
    # Coefficients c are in a fixed coframe absorbing i: q^(-1)=-q at
    # q=±i, so both example native signs become opposite rational c.
    tagged = [(False, 0, 3, 2), (False, 1, 2, -1),
              (True, 1, 0, Q(-1, 2)), (True, 2, 3, Q(1, 2)),
              (False, 2, 3, Q(-1, 2)), (False, 1, 0, Q(1, 2))]
    for dst, src, sign in ((1, 0, 1), (2, 3, -1)):
        wanted = ((src, dst, -sign), (dst, src, 2 * sign),
                  (src, dst, -sign), (dst, src, sign))
        for target, source, relative in wanted:
            nominal = Q(-relative, 2)
            tagged.extend([(True, target, source, nominal),
                           (False, target, source, -nominal)])
    tagged.extend([(False, 1, 2, 1), (False, 0, 3, -2)])
    u, v, relative = relatives(tagged, 4)
    need(relative == [[-x for x in row] for row in eye(4)], "Expected nontrivial -I split")
    gram = multiply(v, list(map(list, zip(*u))))
    complement = [[Q(int(i == j)) + (Q(1, 2) - int(i > j)) * x
                   for j, x in enumerate(row)] for i, row in enumerate(gram)]
    need([row[:2] for row in complement[:2]] == eye(2), "Disjoint literal pair lost I2")
    require_rank = rank(complement)
    need(require_rank == len(u) - 4, f"Complement rank {require_rank} for {len(u)} factors")
    changed = tagged[:]
    changed[3] = (True, 0, 1, Q(1, 2))
    cu, cv, _ = relatives(changed, 4)
    crossed = sum(x * y for x, y in zip(cv[1], cu[0], strict=True))
    need(crossed != 0, "Overlapping adjacent-pair control retained silence")
    return {"basis_columns": 4, "relative_product_factors": len(u),
            "sector_complement_rank": rank(complement), "distinguished_silent_size": 2,
            "overlapping_pair_rejected": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack", type=Path)
    args = parser.parse_args()
    paid, helpers = BASE.read_complex(args.complex_pack)
    net = Counter({r: 2 * q for r, q in helpers.items()})
    net.update({17: 16, 8: 768, 1: 192})
    net.subtract({r: 2 * q for r, q in paid.items()})
    bill = {point: BASE.CORE.format_bounds(BASE.CORE.moment(net, sn, sd))
            for point, sn, sd in ((".005", 5, 1000), (".0227", 227, 10000))}
    need(all(Q(pair[1]) < 0 for pair in bill.values()), "Square sector envelope did not reject")
    print(json.dumps({"status": "PASS_SIGNED_HOST_COMPLEMENT", "control": dimension_control(),
                      "full_two_native_tariff_upper": bill}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
