# A signed header bound for the two-contact Type B caller

The exact two-contact Type B word in `JOINT-BODY-HEADER.md` produces both
rank-17 returns at its eight ports. With the pinned full #7546 invoice,
a separate square Type A caller using two such native contacts cannot pay
for the joint word at .005. The certified upper margin is
**−154.8595110344026** at .005 and **−632.3472810179635** at .0227.

## Signed sector rank complement

Set formal body variables to one and compare the central sectors (q=i)
and (q=-i) over a field of characteristic zero. Keep arbitrary square
invertible ordinary maps with the same action in both sectors. If (P)
is the nominal prefix at (q=i) before a transvection, its contribution
to the relative product is

\[
P^{-1}(I+cN)^{-1}(I-cN)P= I+u v,
\quad u=-2cP^{-1}e_x,\quad v=e_y^TP,\quad N=e_x e_y^T,\quad x\ne y .
\]

Here (c) includes the actual scalar (q) or (q^{-1}) from the nominal
sector. At both signs the inverse is exact because (N^2=0). The
substitution acts equally on all other address spectators. Multiplying
the relative factors in reverse chronological order gives the full
nominal-inverse times actual endpoint. If the endpoint is diagonal with
odd center on (o) independent roles and even center on every other
role, this product equals (I-2E\), where (E^2=E) is the corresponding
rank-(o) diagonal projector. Restored dirty roles are included.

For (m) transvections, put their columns in (U\) and rows in (V\).
Write (C=VU\), (L\) for its strict lower triangle, and
\(W=(I-L)^{-1}\). The expansion of the ordered product is

\[
\prod_{j=m}^{1}(I+u_j v_j)=I+UWV=I-2E.
\]

In fact (W=I+L+\cdots+L^{m-1}\), and a path of length \,(k\) through
strictly decreasing indices is exactly the coefficient of one selected
(k+1) element subset in the product. Thus

\[
\operatorname{rank}(I-L+C/2)
=\operatorname{rank}(I+WVU/2)=m-o.
\]

For the rank identity, factor (I-L+C/2=(I-L)(I+WVU/2)\). The kernel
of the second matrix is isomorphic under (U\) to \(\operatorname{im}E\).
If (z\) is in this kernel, (z=-(WV/2)Uz\) and \(Uz=EUz\).
Conversely (z=-(WV/2)x\) for (x=Ex\) has (Uz=x\) and is in the
kernel. These maps are inverse on the indicated spaces.

An actual Type A native gives two adjacent nominal transvections on
disjoint role pairs after body specialization. For the second one,
the nominal prefix is the first nominal transvection times the common
preceding prefix. On the second pair the first native transvection and
its inverse both act as the identity. Therefore the same preceding
prefix conjugates both relative increments, and both cross-pairings
(v_1u_2,v_2u_1\) are zero. The two indexes form a principal (I_2\) in
(I-L+C/2\). This argument also applies to the inverse orientation
if each inverse has its full independent paid/return bill. Consequently

\[
o\le m-2.
\]

For exactly two Type A hosts at a port, (m=4+Q\) with (Q\) the number
of paid odd thin queries. Hence (o-Q\le2\). No assumption about the
phase sector eigenvectors of the original full native is needed beyond
its verified normalized two-shear interface. The control computes both
sector products with rational coefficients after absorbing (i\) into
the test coframe. It includes a preceding and following ordinary basis,
two opposite nominal shear signs, ten relative transvections, all four
arbitrary input columns, and an overlapping-pair mutation. The actual
physical main boundary and its signed phases remain the source premise.

## Full two-contact consequence

Use two actual #7546 natives. Keep the Type B construction on its eight
ports with 16 rank-17 returns, both full independent native helper
inventories and all ordinary scalar, role and phase operations charged.
On Type A, grant arbitrary square sector-even role mixing within each
port (or a global Type A mixing with the 192 simultaneously disjoint
native odd sites at each contact). Grant arbitrary signed body-only
idles at their full charged ranks. The joint product-cut bound at
header weight zero leaves at most (8H_8\) in body credit less idle
fees per Type A port for two hosts. Each odd output adds at most one
unit of moment, so the sector bound leaves at most two extra units
after paying every thin query. For the global Type A form take the
whole simultaneously disjoint block, giving (o-Q\le192\) across
96 ports after normalizing their central labels consistently. The net
per-port upper bound (8H_8+2\) gives the same combined allowance.

The complete moment after optimistic allowances is therefore at most

\[
2(T_0-P_0) + 16H_{17}+ 768H_8+192 .
\]

The Type A and Type B caller work must be independent for this estimate.
Cross-type mixers, even–odd role projections at owned boundaries, and
compound paid odd idles are outside this sharpened bound. The joint
cut proof in `JOINT-BODY-HEADER.md` separately handles compound idles
with its weaker envelope. The full native is never replaced by a bank
containing only the eight inexpensive test ports.

## Replay

```powershell
& $py -I -O -B -S -W error .\work\round5\recurrence\verify_signed_host_complement.py $complex
```

Use the same CPython and complex input directory as the main replay.
The script imports its existing read-only source pins and directed price
engine. Its deterministic output is `signed-host-complement.json`.
