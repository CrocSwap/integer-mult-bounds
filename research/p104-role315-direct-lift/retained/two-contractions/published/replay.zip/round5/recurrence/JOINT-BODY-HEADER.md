# Joint address cuts and two short native callers

The joint body and header tariff closes the fixed-native loophole where an
arbitrary number of mixed odd idles might evade separate body and header
bounds. Under the operator assumptions below the complete per-native upper
margin at 0.0227 is **−98.3943022217272** for the selected BIT word and
**−216.7829886731843** for the open complex candidate. The calculation also
gives two exact small caller constructions and isolates a specific changed
BIT native interface with a positive arithmetic budget. Its literal frame
lift fails the complete recursive price.

The BIT baseline is #7001 at canonical commit
`e54523517d0f03e58352e647c403a5af3e525a57`. The complex baseline is open
#7546 at `99438c43df7aac1e5dbcc43c1578fcd886c119ec` on the signed #7113
caller at `07a76c5e2738882c0cb322278e56f6cae3c9885d`.
[Selected BIT interface](https://github.com/CrocSwap/integer-mult-bounds/pull/7001) ·
[Selected application review](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/docs/research/pr-intake-evidence/pr7000-application/PROOF-REVIEW.md) ·
[Open complex candidate](https://github.com/CrocSwap/integer-mult-bounds/pull/7546) ·
[Signed complex caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7113)

## Which operations can match body and header demand?

Let the body labels be independent commuting Laurent generators, and let
there be any finite number of additional independent commuting central
labels (q_j). Each (q_j) has order two over the BIT field, or order four
over the complex coefficient field. The cost of a scalar coordinate shift
is (H(b+h)), where (H(x)=x^t, 0<t<1), (b) is the weighted signed
\(\ell_1\) length of the body exponent and (h) is the sum of the weights of
the odd central factors. In the complex calculation we specialize

\[
q_j=iQ_j,\qquad Q_j^2=1,
\]

over a field containing (i). This retains all odd parts and makes an even
power scalar in this diagnostic representation. Even-sector maps have zero
crossing rank in the representation. A gated even map whose coefficients are
address-local has the same property. No inference back from this quotient to
full complex phase equality is needed. The separate two-contact witness
below is checked in the unquotiented order-four ring.

Paid single-field moves may carry both a signed body word and any finite
set of central factors. In a scalar basis the moving part is a coordinate
role, or (d) roles when the tariff is charged (d) times. Rectangular
ordinary maps may add zero roles or remove roles at legal owned boundaries.
Their maps are local to each address and have zero crossing rank. The
independent final target has a diagonal monomial on each original credited
input; all extra credited helper targets are counted once. Paid ranks must
dominate the indicated weighted length and target ranks must be at most
that length. Physical relations among different addressed axes, aliasing
of original inputs, an unpaid odd-sector address operation or a different
native invoice require a separate argument.

For one body of length (b) and a central label of weight (h), abbreviate
the following exact contributions to the cut bound:

| Native action on two arbitrary main roles | Contribution |
| --- | --- |
| Common body and one triangular central shear | \(J=\frac32H(b)+\frac12H(b+h)+\frac12H(h)\) |
| Common body and the full #7546 Type B host | \(K=H(b)+H(b+h)+H(h)\) |
| Common body with two diagonal odd returns | \(2H(b+h)\) |

For instance (J-2H(b+h)>0) precisely when the shear capacity exceeds
those two simultaneous target demands. The difference is
\(\tfrac12H(h)-\tfrac32[H(b+h)-H(b)]\). This is an implementable price
for a diagonal two-role shift only if both payloads actually return at
the declared compound addresses. One rank credited to two independent
roles would fail the corresponding finite cut. At (t=1), the one-way
shear supplies two body moves and one header move in this metric, whereas
the full two-way host supplies two of each. For (t<1), body/head fusion
lowers the cut tariff of the shear versus one separate query and two
separate body jobs.

For #7001 fix (b=7,h=1\) and let (P_0,T_0) be the full paid and
independent helper moments. The total main credit less the full tariff of
all paid idles and thin calls is at most (111J\) per full native, giving

\[
T_0-P_0+111\left(\tfrac32H_7+\tfrac12H_8+\tfrac12\right).
\]

For #7546 use (b=8,h=1\). Each of the 96 Type A contacts supplies two
disjoint shears, and each of the eight Type B contacts supplies one full
host, giving

\[
T_0-P_0+192J+8K=T_0-P_0+296H_8+104H_9+104.
\]

No additional correction is needed per mixed odd idle, in contrast to
using separate body and derivative constraints to price that idle.
Every native inverse is priced at its full paid histogram. Independent
helper returns may be granted even to an inverse for this favorable
bound. The inverse Type B host has four nonzero coefficients and an
invertible two-by-two block, just as the forward host does. An inverse
shear has the same corresponding cut rank. Other ordinary processing,
recovery, rounding and routing charges can only decrease these margins.

| Complete optimistic cap per native | κ = .005 | κ = .0227 | Certified zero bracket |
| --- | ---: | ---: | --- |
| Selected BIT word | +15.0367815585105 | −98.3943022217272 | (.0073017531566, .0073017531567) |
| Open complex native | +25.5382294887221 | −216.7829886731843 | (.0068280797776, .0068280797777) |

The rows are upper endpoints of directed arithmetic. Both displayed
upper functions strictly decrease on (0\le\kappa\le1/32\), as checked
with endpoint bounds on the signed derivative. Positive entries leave
cases open at .005. The actual pure-body-idle BIT caller substantially
underuses this per-native budget, even with ordinary routing cost ignored.

## Proof of the joint cut tariff

For a finite address set color each address (L) or (R), putting all
roles at a given address on its same side. Write (r(M)=\operatorname{rank}
M[L,R]). For compatible square or rectangular matrices,

\[
(MN)[L,R]=M[L,L]N[L,R]+M[L,R]N[R,R],\qquad r(MN)\le r(M)+r(N).
\]

Take a product of cycles for the Laurent body shifts, with one half-cycle
indicator for each. Use a separate per-header spectator selector and a
two-point indicator. The involution for that center flips its indicator
bit on an exact prescribed fraction of spectator values, fixing the
indicator on the rest. It leaves all other coordinates unchanged. Thus
its square is identity on every address. The color is the parity of an
independently selected subset of all body and center indicators. This is
a finite family of literal cuts, weighted uniformly.

For a body displacement let (f_b) denote the probability that at least
one body indicator changes, ignoring the choice of subset. For an active
label let (f_h) denote the analogous probability for its header indicator.
The probabilities are independent. For a product of several commuting
headers with independently chosen selectors (f_h=1-\prod_j(1-f_{h,j})).
The normalized mean crossing rank of a single-role permutation is
\((f_b+f_h-f_b f_h)/4\). Indeed, whenever at least one coordinate changes
the parity changes with probability one half over the random subset.
For each fixed cut, right-to-left and left-to-right traffic are equal by
bijectivity. This also handles finite cuts with unequal side sizes.

Now fix a cut and a one-way shear (\begin{pmatrix}D&0\\Dq&D\end{pmatrix}).
Let (c(D)) count the right-to-left crossings of (D). Eliminate the
two diagonal blocks' (c(D)) unit pivots each. The lower-left (Dq)
is a partial permutation. Its distinct residual pivots occur exactly at
addresses (x) satisfying

\[
x,Dx\in R,\qquad qx,Dqx\in L.
\]

The exclusion (Dx\notin L) removes columns already pivoted by the
first diagonal block. The exclusion (qx\notin R) removes rows already
pivoted by the second diagonal block. Because (Dq) is a permutation
each remaining entry contributes one independent pivot. The same proof
applies to a shear of the opposite orientation or either sign, and to
the nonzero scalar times (Q_j) obtained from a complex (q_j^{\pm1}).

The four membership conditions for a residual pivot say that the
selected body change is zero and the selected central change is one,
with initial color (R). Conditional on a central change the involution
pairs the two initial colors, so exactly half of such addresses start
on (R). A body change is selected with probability (f_b/2\), independent
of the center for these product cuts. Thus the mean rank divided by the
address count and multiplied by four is

\[
2f_b+(1-f_b/2)f_h.
\]

For a full Type B host, remove the harmless center phases by scalar
rephasing. Split each (Q_j)-orbit and the return orbit of (D) into the
two independent input pairs (first role at (x), second role at (Q_j x))
and (first role at (Q_j x), second role at (x)). Each two-input block
has an invertible two-by-two matrix with all four entries nonzero. The
crossing block is the row/column restriction selected by the colors.
It has the maximum possible rank for every such restriction. A fixed
point of (Q_j) has the full invertible same-address two-role matrix,
with no additional residual pivot. In a two-point orbit, if the input
orbit is all (R) and the output orbit is all (L), the two blocks each
have rank two. For two mixed-color orbits they each have rank one. For
one mixed-color orbit and one monochrome orbit, ranks are one if the
monochrome side is active and zero otherwise. These cases give exactly
the same pair of diagonal contributions plus *both* directional residual
terms. Equivalently the scaled average is

\[
2f_b+2(1-f_b/2)f_h.
\]

The supplied finite tests measure this via exact GF(3) rank; the standalone
two-by-two minors argument gives the exact formula in characteristic zero.
The all-one two-by-two matrix over GF(2) is a negative control. It loses
one pivot on a fully selected pair or fixed-point host as appropriate.

For any scale (s>0), replicate every body dimension in independent
cycle coordinates and choose cycle lengths so that
\(f_b\to1-e^{-b/s}\), as in `round4/WEIGHTED-L1-TARIFF.md`. For
completeness, for each body coordinate with weight (w_j>0) use (m)
copies of a length-(2K_j\) cycle. Translate its variable by (M) on each
copy and set (K_j/M\to ms/w_j) as (M\) increases. A signed exponent
(u_j) has half-indicator change probability
\(\operatorname{dist}(M u_j,2K_j\mathbb Z)/K_j\). Taking (M\) to infinity
and then (m\) to infinity gives the claim by independence and
\((1-w_j|u_j|/(ms))^m\to e^{-w_j|u_j|/s}\). A zero-weight variable may
map to the identity. For each independent header choose larger spectator
selectors so its activated fraction tends to (1-e^{-h_j/s}\).
All rank inequalities are applied before every limit, to an exact
representation on a finite address set. It is the explicit, evaluated
scalar formula that is passed to the limit. For a product head of total
weight (h), the independent selector product gives (f_h=1-e^{-h/s}\).

Put (F_s(x)=1-e^{-x/s}\). The body/head permutation kernel is now
\(F_s(b+h)\). The one-way shear kernel rewrites as
\(\tfrac32F_s(b)+\tfrac12F_s(b+h)+\tfrac12F_s(h)\), and the full host
kernel is (F_s(b)+F_s(b+h)+F_s(h)\). Integrate the occurrence inequality
using (s^{t-1}ds) on (0<s<\infty\). The integral exists because
\(F_s(x)\le1\) at small (s\), and (F_s(x)\le x/s\) at large (s\).
The change of variable (s=xu\) gives the same strictly positive constant
times (x^t\), with both sides zero at (x=0\). Dividing by this constant
proves the displayed tariff. The proof permits all finite chronological
orders, arbitrary signed body exponents, square or rectangular ordinary
operations, and every finite positive number of independently paid mixed
idle shifts. Choosing physical ranks from different weighted decompositions
for different words would leave the hypothesis of common weights.

For a thin query (b=0\) gives (J=H(h)\). Its full tariff therefore
cancels its contribution to the upper bound. This also holds for every
priced compound idle with the same native unchanged. A positive
bound at an integrated tariff supplies no word at that demand.

## A two-host complex return on arbitrary inputs

For the exact Type B interface used at eight ports, write

\[
M(q)=\begin{pmatrix}1&-q\\q^{-1}/2&1/2\end{pmatrix},\qquad
M(q)\operatorname{diag}(1,2)M(q)=
\begin{pmatrix}0&-2q\\q^{-1}&0\end{pmatrix}.
\]

Use two actual successive native invocations with distinct eight-axis
body labels. Between the hosts scale the second role by two. After the
second host use a role swap, multiply its second role by \,−1/2, and
apply (q^2\) to its first role. This gives exactly (qD_1D_2\) on both
independent inputs, with no thin odd query or odd idle. It preserves all
spectator addresses and uses only the inherited even-sector operation
on (q^2\). It holds in the full ring with (q^4=1\); setting (q^2=1\)
before checking would miss an entire required phase operation.

The per-pair price credits 16 rank-17 main fields across eight ports,
uses both full native paid histograms and both independent full helper
banks, and pays eight ordinary SWAPs, sixteen exact dyadic SCALEs and
eight even-phase maps. Each guard is an exact fixed-grid dyadic operation.
For old payload magnitude bound (R\), a host's normalized scalar map
is bounded by (2R\), the middle scale by (2\), and the last scale and
phase by one. This gives a finite scalar row-norm factor at most eight
on the B main boundary, with a factor of one half in its exact final
scale denominator. Native interior precision, fixed routing, storage,
and recovery still have their own bills.

The joint native must also service 96 Type A ports. Even granting them
their whole joint-cut allowance on both invocations, the two-host plan
has **−453.6009490576105** margin at .0227. At .005 that partial favorable
bound is **+34.1477439213506**. That last entry is a funding target for
the missing A protocol. A and B are separate public inputs, and the
bound does not silently erase Type A roles from the joint word. A
standalone Type B-only supplier would require a changed native price.

## A short BIT caller and the price of a thicker head

Let (U(q),L(q)\) be the opposite two-role transvections with header (q\)
over (\mathbf F_2\). Since (q^2=1\), exactly

\[
U(q)L(q)U(q)=\begin{pmatrix}0&q\\q&0\end{pmatrix}.
\]

Take three actual natives, change the orientation of the first and third
using ordinary role swaps, use seven disjoint body axes for each, and
swap the final role labels. The result is (qD_1D_2D_3\) on both arbitrary
data roots. This uses three exterior role swaps per port after canceling
the adjacent routing permutations. There are no thin queries, body idles,
or rank-one main targets. The three independent helper inventories and
all 711 owned lifetimes are charged. The formal inverse is exact on both
root columns and restores the independent helpers using the inverse of
their separately charged native contracts if an inverse is requested.

For the ordinary equal-width head, the complete raw main/helper bill
has surplus 33 at zero saving and margin −93.1608539614724 at .005.
The altered interface to test is **one coherent head permutation of
width (a\) plus seven body coordinates of unit width per call**, with
the *same* paid recursive and helper sizes as the source. Three calls
would then give 222 independent rank-((21+a)\) targets. All claims in
the altered columns below are requirements on a new native offer. The
algebra does not relabel an existing ordinary rank-one head as a free
thicker one.

| Header width (a) | Complete three-call raw margin at .005 | At .0227 |
| ---: | ---: | ---: |
| 1 | −93.1608539614724 | −524.6299450361496 |
| 2 | +124.3171419405641 | −322.4737010034489 |
| 3 | +341.7478502152655 | −120.5169415279217 |
| 4 | +559.1332519977043 | +81.2488349345496 |

The widths 2 and 4 run a finite-separation check in the attached receipt.
The full chronological product uses independent rank factors and keeps
exactly the targets with product rank at least \((15/2)^v\); every paid
product is at most (7^v\). For a single-factor productive rank (r\),
weight probability by its exact (H(r)\). The tail probability of a
discarded product is at most

\[
\left(\mathbf E[(15/(2r))^{1/100}]\right)^v,
\]

by Markov's inequality. Use \(e^x\le (1-x)^{-1}\) for (x<1\) to
enclose the moment with the already pinned directed logarithms. The
product paid moment is at most (\alpha^v\) of full target moment.
The verifier proves strict \,\(\alpha^v+\text{tail}<1\) and includes
all dropped targets in the reported tail. The test grants the new
multiwidth operator, the chronological product compiler's typed adapter
and spectator contracts, and its ordinary bootstrapping prerequisites.
It prices neither an implementation of the new native nor a mixed-width
recurrence solver that ignores those prerequisites.

| Case | Power (v\) | Paid-share upper bound | Discarded-target-share upper bound |
| --- | ---: | ---: | ---: |
| Width 2 at .005 | 119 | .3735683580950 | .6224763168958 |
| Width 4 at .0227 | 141 | .4615823905074 | .5365324757230 |

### Exact cheapest literal tensor lift, with the helper endpoints fixed

Add one orthogonal axis to the selected literal chart word and allow each
current chart either to include that axis or to omit it. When no physical
operation is performed, its inclusion bit cannot change. A scalar ADD
requires equal complete charts and hence equal bits on its two roles.
A scalar SWAP moves the bit along with the field and its frame. A MOVE
can change it at charge (H(r+1)-H(r)\) where the original rank is (r\).
Allow either sign of the extra-axis transition, and allow a new rank-one
splice before an ADD operand or at a final boundary. For the original
scalar endpoint (x\to x,y\to y+x\), the new axis must be present at both
boundaries of each X, and absent at both boundaries of each Y. This gives
only the additional factor of the off-diagonal head. Each independent
helper must return with its entrance bit to retain the price assumed
above. Each owned temporary stays zero at initialization and is cleared
only at its original owning lifetime boundary. The new copies of frame
axes are identity spectators outside their explicit optional factor.

Without splices, hard equalities alone give one class containing
oppositely pinned X and Y roles. No set of changes to the ranks of the
existing MOVEs can repair that conflict. With the allowed splices,
contract the hard equality graph and attach source and sink pins. Use
weight (H(r+1)-H(r)\) on each possible color transition, including
(r=0\) on the new splices. Exact max-flow/min-cut on lower directed
weights supplies a valid lower bound. The emitted reaching-side cut
has precisely 222 new unit-rank splices, widens zero existing MOVEs,
and is priced at **222 per native**. The upper and lower integers agree
at 0, .005 and .0227, so no rounding affects this optimum. Three
native invocations pay 666 extra rank-one calls; the .005 raw margin
after this payment is **−541.6828580594358**. Route and restoration
costs would increase that bill. Counting helper endpoint changes as
additional credit or replacing the scalar graph would change the
identified model and its price.

The constructive next gate is therefore a native with a thick coherent
head produced by internal shared routes or independent useful new
outputs, and less than 124.3171419405641 total extra recursive moment
across three width-two hosts at .005. Target .0227 in the width-four
case leaves less than 81.2488349345496 across the whole three-host group.
The alternative two-host complex interface leaves a distinct quantitative
Type A scheduling problem at .005. Neither circuit, after its current
fully paid physical options, establishes a larger multiplication κ.

## Replay

From the research workspace root, using the embedded CPython 3.13.14:

```powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$repo = 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
$complex = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round5\recurrence\verify_joint_body_header.py $repo $complex --expect .\work\round5\recurrence\joint-body-header.json
```

The script reads the selected #7001 tape and the existing local exact
#7546 and #7113 snapshots by SHA-256, replays the exact two-role words
and every basis column of their inverse, and checks 480 finite product
cut cases with independent GF(2) and GF(3) rank routines. It also rebuilds
the complete signed histogram prices and exact cut graph from source.
Ruff and uv are unavailable on this host. AST parsing and tabnanny
passed. No GPU computation or external write is part of the replay.
Normal and optimized launches took 22.758 and 23.365 seconds within
their 45-second process limits, and independently produced SHA-256
`726331947684d53151ae85af6e2b6da95ff03c679b2275b241a4bd37a3226435`.
A relocatable
package can omit the leading `work` directory. Keep `recurrence` and
`round5` as siblings, and point the second argument to a directory
containing the exact three complex inputs with their original filenames
and the `phase-7481-inputs` subdirectory.
