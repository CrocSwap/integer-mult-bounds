# Terminal helper recovery at the #7546 full chart

Pin the word at `99438c43df7aac1e5dbcc43c1578fcd886c119ec`. It acts on 1,501
arbitrary public fields, consisting of 400 main roles and 1,101 helpers. In
every calculation below these are independent. The owned zero stock closes
at its recorded boundaries. The notation describes exact normalized maps
at the stated Clifford coframes.
[Source replay](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050)

## An exact triangular output

Write (h=x_{993}), (x=x_{851}), and (y=x_{957}). The main roles (x,y)
are a Type A pair. The input chart of (h) is 3 of dimension zero. The
final lift of (h) is event 57999, from chart 1091 of dimension four to
chart 127 of dimension nine. At that event (h) is pure. Its two subsequent
uses are `799 -= 2h` and `851 += 2h`. The public suffix response to this
arrival has column (e_{993}+2e_{851}). All other public coefficients cancel.

One exact program defers the MOVE until the last operation and replaces the
two original ADDs by `851 += 2h` at chart 127. All 6,276 paid MOVE ranks and
every final chart are identical to the original. This removes one ADD.
Another exact program removes both original ADDs and the MOVE. It returns

\[
(h\text{ at }1091,\quad x-y-2h\text{ at }127),
\]

with every other public row exact, including the Type A mate (y). It pays
6,275 MOVEs. The two logical outputs are independent after fixing the mate.
Their distinct coframes prevent an ordinary coframed decode at the new
endpoint. With a free clean Type A restoration, the candidate's nominal
gain would be (H_4+H_5-H_9) where (H_r=r^{1-\kappa}). This is only
0.03062946 per native at .005. Any extra rank-one recursive job costs 1.

The suffix has 1,052 full arrivals. The other 1,051 are unchanged in the
triangular program. All annihilate the input variation 

\[
\Delta h=1,\quad \Delta x=2,\quad \Delta y=0,
\]

on which the original Type A X return has variation 2. Four of those
arrivals actually involve the pair and depend on one common linear form
in it. At the original event 47090 the value carried by role 851 has
neither of those coordinates. An exact eight-term coframed combination
already available at event 36662 reconstructs that entire dirty input
row, across all 1,501 original inputs. A separate literal control stores
the combination, displaces the old value at its MOVE, and pays the same
rank bill. The early stock does not supply the missing direction.

## Where can the missing payload travel?

For a terminal public owner with pure input at its final lift, let the
product of its incoming scalar amplitude and the off-owner suffix column
be \(\sum_j \lambda_j e_j\). If every affected output is an independent
identity helper, and all its input charts agree with the truncated owner's
input chart, one may precode those helpers by (x_j\leftarrow x_j+\lambda_j h).
After keeping (h) below the lift, evaluate its former high slot from an
owned zero field and use its original suffix. The precode cancels all
off-owner loss, restores the other roles and funds the shorter output.
The two-input positive control keeps an independent copy's paid rank-nine
MOVE and removes precisely one rank-five MOVE. Screening the 27 original
pure terminal #7546 helpers found that every outside response touches
at least one main role and every candidate meets a different entrance chart.
These facts exclude this ordinary same-chart helper precode on this list.

At 12 of the 1,051 other full arrivals, the literal available coframe rows
can isolate (h). All 12 departures are from chart 1091. Adding arbitrary
multiples of (h) to those arriving values gives a repair column in the span
of their 12 actual suffix columns. An exact dual annihilates them and pairs
to 2 with the missing column (2e_{851}). It has support on the six output
roles `17, 334, 344, 382, 397, 851`. The same dual applies if all 17 other
exits of chart 1091 after 36706 and ten lower public returns in chart 1091
are allowed to vary through the frozen suffix. These 27 directions are
independent, and the missing desired correction stays outside their span.

One can give the receiver an entirely new exact linear readout. Let the
original full ingress rows be (A), let the square full suffix be (S),
and let (T) be the exact invertible public map. Then (S A) is the set
of full output rows of (T). These 1,052 rows are independent, so (S)
is invertible on them. After the helper is stopped below the full chart,
the new target row space (E) consists of the 1,051 full output rows of
(T) other than (h). With only 1,051 arrivals, every replacement row
must lie in (E) for them to span (E). Grant all linear combinations
in the original coframed stock at each paid arrival, including (h) at its
retained lower frame after its old departure. Apply (T^{-1}) to test
membership in (E). Then apply the four columns of (S) corresponding
to the four original ingresses involving the pair. This tests whether the
resulting row contributes a new direction beyond the 1,047 original clean
rows in (E). The exact sweep examines 1,051 arrival coframes and 1,482
distinct source vectors, and gives **zero** of the four required quotient
directions. Four planted clean arrivals supply precisely these directions
in the positive control.

These tests fix the physical source frames of existing arrivals and keep
their coframed data stock from the original program. The larger receiver
test grants arbitrary new readout but requires the full roles to close down
to the same scalar endpoint. A construction changing both pre-arrival
stock and frames, jointly scheduling several native invocations, or changing
the caller interface can evade these premises. We have a finite triangular
native, legal coframe and owner lifetimes, and exact move ranks. We have no
new rounded provider, all-width precision/tape receipt, or complete
outer assembly using that endpoint. The original accepted target credits
cannot be taken for it without the Type A return repair.
