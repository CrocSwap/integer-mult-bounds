# SPDX-License-Identifier: Apache-2.0
"""Test whether a terminal helper lift can be replaced by an ordinary input shear."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
TAIL = run_path(str(HERE / "paired_tail_synthesis.py"))
ADJ, ROWS, PRICE, NEED = (TAIL[k] for k in ("ADJ", "ROWS", "PRICE", "NEED"))


def candidates(word, deadline):
    n = word["public"]
    main = ADJ["main_roles"](word)
    helpers, before, after = TAIL["SEAM"]["coframe_witnesses"](word, deadline)
    for entry in helpers:
        i, h = entry["event"], entry["role"]
        x, y = before[i], after[i]
        a = Fraction(x[1][h], x[0])
        losses = {j: a * Fraction(c, y[0]) for j, c in y[1].items() if j < n and j != h}
        needs_main = sorted(main & losses.keys())
        unlike = sorted(j for j in losses if word["initial"][j] != word["initial"][h])
        yield {**entry, "main_rows": needs_main, "different_input_charts": unlike, "leaks": losses}


def rewrite(word, event, h, losses):
    """Keep the last high-chart use on a zero owner and precode compatible inputs."""
    stage, final = word["initial"][:], word["final"][:]
    _, _, start, stop, _ = word["program"][event]
    shadow = word["public"] + word["owned_fields"]
    p = []
    for r, value in sorted(losses.items()):
        NEED(stage[r] == stage[h], "each independent helper precode is an ordinary same-chart ADD")
        p.append(["ADD", r, h, str(value), stage[h]])
    p += word["program"][:event]
    p += [["INIT", shadow, stop]]
    value = event_value(word, event, h)
    if value != 1:
        p.append(["SCALE", h, str(1/value), start])
    for op, r, *d in word["program"][event + 1:]:
        if r == h:
            NEED(op in ("ADD", "SCALE"), "terminal helper has no later frame change")
            r = shadow
        if op in ("ADD", "COPY") and d[0] == h:
            d[0] = shadow
        p.append([op, r, *d])
    p.append(["CLEAR", shadow, stop])
    final[h] = start
    return {**word, "program": p, "final": final, "owned_fields": word["owned_fields"] + 1}


def event_value(word, event, h):
    """Exact forward column for the single retained h value."""
    values = [Fraction(i == h) for i in range(word["public"] + word["owned_fields"])]
    for op, r, *d in word["program"][:event]:
        if op in ("INIT", "CLEAR"):
            values[r] = Fraction(0)
        elif op == "SCALE":
            values[r] *= Fraction(d[0])
        elif op in ("ADD", "COPY"):
            values[r] += Fraction(d[1]) * values[d[0]]
    NEED(values[h], "nonzero retained input column")
    return values[h]


def positive_control(word, received):
    """Use the pinned gate shapes in a two-helper native with a coframed input pair."""
    _, f, t = received["old_frames"]
    s = next(i for i, col in enumerate(word["frames"]) if not col)
    # The other original path cancels the high ADD. Keep its paid MOVE.
    p = [["INIT", 2, s], ["ADD", 2, 0, "1", s], ["MOVE", 2, s, t, True],
         ["MOVE", 0, s, f, False], ["SCALE", 0, "-1/2", f], ["MOVE", 1, s, t, False],
         ["MOVE", 0, f, t, False], ["SCALE", 0, "-2", t], ["ADD", 1, 2, "-2", t],
         ["ADD", 1, 0, "2", t], ["CLEAR", 2, t]]
    return {"public": 2, "owned_fields": 1, "initial": [s, s], "final": [t, t],
            "frames": word["frames"], "program": p}, 6


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("word", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()
    start, deadline = perf_counter(), monotonic() + 35
    _, word = ADJ["PHYSICAL"]["load_pins"](args.word)
    pool = list(candidates(word, deadline))
    g = next(e for e in pool if e["role"] == 993)
    NEED(g["leaks"] == {851: 2} and g["different_input_charts"] == [851] and g["main_rows"]==[851],
         "known unequal input interface and the actual Type A X output")
    control, at = positive_control(word, g)
    original = [ROWS["unit"](r) for r in range(2)]
    _, old_control, _ = TAIL["record"](control, set(), deadline, original)
    new_control = rewrite(control, at, 0, {1: Fraction(2)})
    _, new_bill, _ = TAIL["record"](new_control, set(), deadline, original)
    NEED(old_control - new_bill == {5: 1}, "coframed positive control omits only the selected rank-five child")
    result = {"status": "PASS_COFRAMED_HELPER_PRECODE_SCREEN", "pure_terminal_rows": len(pool),
              "helper_only_responses": sum(not e["main_rows"] for e in pool),
              "coframed_responses": sum(not e["different_input_charts"] for e in pool),
              "candidates": [], "verified_native_changes": [],
              "control": {"public_matrix_coefficients": 4, "paid_before": old_control,
                          "paid_after": new_bill,
                          "credits_before": [9, 9], "credits_after": [4, 9]}}
    _, old_bill, _ = TAIL["record"](word, set(), deadline)
    for e in pool:
        if not e["main_rows"] and not e["different_input_charts"]:
            changed = rewrite(word, e["event"], e["role"], e["leaks"])
            _, bill, terms = TAIL["record"](changed, set(), deadline)
            whole, step = e["target_rank"], e["step"]
            NEED(old_bill - bill == {step: 1} and not bill - old_bill, "exact removal of one paid MOVE")
            net = Counter([step, whole-step]); net[whole] -= 1
            price = {s: PRICE["power_sum"](net,Fraction(s)) for s in (".003648411294790",".005",".0227")}
            result["verified_native_changes"].append({"role": e["role"], "paid_after": bill,
                 "shorter_productive_rank": whole-step, "ops_after": terms, "moment_change": price})
        result["candidates"].append({**e, "leaks": {r:str(c) for r,c in sorted(e["leaks"].items())}})
    NEED(monotonic() < deadline, "bounded exact coframed endpoint search")
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(result["status"], len(result["verified_native_changes"]), f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
