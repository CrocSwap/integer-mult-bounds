"""Exact phase identities and pricing for a two-layer #7546 caller."""

import argparse
from collections import Counter
from fractions import Fraction as Q
import gzip
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
PRICE = run_path(str(HERE.parents[1] / "round3" / "independent" / "body_rank_deformation.py"))
NATIVE = run_path(str(HERE.parents[1] / "round4" / "independent" / "receiver_support.py"))
need = PRICE["require"]
INCUMBENT = Q(".003648411294790")


def identity(n):
    return [[Q(i == j) for j in range(n)] for i in range(n)]


def add(a, b, factor=1):
    return [[x + factor*y for x, y in zip(r, s, strict=True)] for r, s in zip(a, b, strict=True)]


def times(a, b):
    return [[sum(x*y for x, y in zip(row, column, strict=True)) for column in zip(*b)] for row in a]


def rank(a):
    return NATIVE["matrix_rank"]([tuple((j, x) for j, x in enumerate(row) if x) for row in integer_rows(a)])


def integer_rows(a):
    from math import lcm

    for row in a:
        d = lcm(*(Q(x).denominator for x in row))
        yield [int(x*d) for x in row]


def matrix_controls():
    # A,B are square-zero. For ab=-1 in this 2x2 family, P has one nonzero
    # -1 Jordan defect and rank(P-I)=2: the factor two in the lemma is sharp.
    a = [[0, 1], [0, 0]]
    b = [[0, 0], [-1, 0]]
    eye = identity(2)
    p = times(add(eye, b, -2), add(eye, a, -2))
    pinv = times(add(eye, a, 2), add(eye, b, 2))
    o, d = add(a, b), add(a, b, -1)
    need(times(p, pinv) == eye, "known inverse of square-zero product")
    need(add(p, eye, -1) == [[-2*x for x in row] for row in times(o, add(eye, a, -2))],
         "(P−I)=(−2O)(I−2A)")
    need(add(p, pinv, -1) == [[-4*x for x in row] for row in times(add(eye, d), o)],
         "(P−P⁻¹)=(−4)(I+A−B)O")
    need(rank(add(p, eye, -1)) == 2 and rank(add(p, pinv, -1)) == 1,
         "sharp factor-two Jordan pair")
    qodd = [[0, -1], [1, 0]]
    need(times(qodd, qodd) == [[-x for x in row] for row in eye], "odd sector can hide at one fiber")
    return {"rank_P_minus_I": 2, "rank_P_minus_inverse": 1, "noninvolutive_mutant_rejected": p != pinv}


def phase_factorizations():
    """Q(i) under q^4=1, using differences of exact Gaussian rationals."""
    rho_values = [((1, 0), (1, 0)), ((-1, 0), (-1, 0)), ((0, 1), (0, -1)), ((0, -1), (0, 1))]
    for q, qi in rho_values:
        eye = [[{0: Q(1)}, {}], [{}, {0: Q(1)}]]
        qq = {(0 if q[0] else 1): Q(q[0] or q[1])}
        qinv = {(0 if qi[0] else 1): Q(qi[0] or qi[1])}
        negq = {key: -value for key, value in qq.items()}
        low = [[eye[0][0], {}], [qinv, eye[1][1]]]
        up = [[eye[0][0], negq], [{}, eye[1][1]]]
        m = [[eye[0][0], negq], [{a: b/2 for a, b in qinv.items()}, {0: Q(1, 2)}]]
        j = [[{0: Q(1)}, {key: -value for key, value in qq.items()}], [{}, {0: Q(-1)}]]
        one_by_two = [[{0: Q(1, 2)}, qq], [{key: -value/2 for key, value in qinv.items()}, {0: Q(1)}]]
        odd = [[{}, negq], [qinv, {}]]
        rotated = [[qinv, {}], [{}, qq]]
        need(poly_times(low, poly_times(up, low)) == odd, "three lower/upper matching shears")
        need(poly_times(up, poly_times(low, up)) == odd, "three upper/lower matching shears")
        minus = [[{0: Q(1)}, {}], [{}, {0: Q(-1)}]]
        swap = [[{}, {0: Q(1)}], [{0: Q(1)}, {}]]
        need(poly_times(minus, poly_times(swap, odd)) == rotated,
             "ordinary row swap with typed sign")
        # J is the formal central-dependent involution; it is not a free physical gate.
        need(poly_times(j, j) == eye, "dyadic Laurent Type B involution")
        need(poly_times(j, poly_times(m, j)) == one_by_two, "exact Type B inversion")
        need(poly_times(m, one_by_two) == eye, "B arbitrary-input inverse")
    return {"tested_central_roots_of_unity": 4, "three_shear_A_swap": True,
            "type_b_formal_involution": [["1", "-q"], ["0", "-1"]],
            "formal_odd_query_in_type_b_inverter_is_not_free": True}


def selector_controls():
    """Confirm the allowed sign-controlled positive/inverse branch exactly."""
    expected_plus = [((1, 1), (1, -1)), ((1, -1), (1, 1))]
    expected_minus = [((a, -b), (c, -d)) for ((a, b), (c, d)) in expected_plus]
    need(list(reversed(expected_plus)) == expected_minus, "exact inverse is a row translation of the positive turn")
    exact_columns = []
    for source in range(4):
        lane, inner = divmod(source, 2)
        wanted = [None] * 4
        branch = expected_minus if lane else expected_plus
        for row in range(2):
            wanted[2*lane+row] = branch[row][inner]
        actual = [None] * 4
        for row in range(2):
            actual[2*lane + (row ^ lane)] = expected_plus[row][inner]
        need(actual == wanted, "controlled translation produces direct sum on every column")
        exact_columns.append(actual)
    return {"matrix_columns_over_two": exact_columns,
            "identity_and_positive_turn_differ_by_nonpauli_support": True,
            "two_independent_lanes_have_twice_the_address_volume": True}


def poly_times(a, b):
    """Small exact Gaussian rational matrix product with powers i^0/i^1."""
    result = []
    for row in a:
        out = []
        for column in zip(*b):
            value = Counter()
            for p, q in zip(row, column, strict=True):
                for u, x in p.items():
                    for v, y in q.items():
                        value[(u+v) % 2] += x*y * (-1 if u+v == 2 else 1)
            out.append({key: x for key, x in value.items() if x})
        result.append(out)
    return result


def counts_for(word, whole):
    dims = list(map(len, word["frames"]))
    paid = Counter(abs(dims[b] - dims[a]) for op, _, *args in word["program"]
                   if op == "MOVE" for a, b in [args[:2]])
    helper = Counter({int(k): v for k, v in whole["signed_profile"]["native_productive"].items()})
    h = word["hosted"]
    ports_a = len(h["Dports"])
    ports_b = len(word["ports"]) - ports_a
    n = 4*ports_a + 2*ports_b
    need((ports_a, ports_b, n, sum(paid.values()), sum(helper.values())) == (96, 8, 400, 6_276, 1_101),
         "literal hosted counts")
    need(sum(paid[r]*r for r in paid) == 11_004 and sum(helper[r]*r for r in helper) == 7_692,
         "literal native rank mass")
    return paid, helper, ports_a, ports_b, n, 8


def price_all(word, whole):
    p = PRICE["price_engine"]()
    paid, helper, a, b, mains, body = counts_for(word, whole)
    upper = 20*b

    def price(stages, odd, k):
        net = {r: stages*(helper[r]-paid[r]) for r in helper.keys() | paid.keys()}
        net[stages*body] = net.get(stages*body, 0) + mains - odd
        net[stages*body+1] = net.get(stages*body+1, 0) + odd
        return p.moment(net, k)

    def display(exact):
        return {"float": p.value(exact), "interval": p.show(exact)}

    def derivative_upper(stages, odd, cap):
        hist = {r: stages*(helper[r]-paid[r]) for r in helper.keys() | paid.keys()}
        for rank_value, count in ((stages*body, mains-odd), (stages*body+1, odd)):
            hist[rank_value] = hist.get(rank_value, 0) + count
        d = (0, 0)
        for r, count in hist.items():
            factor = p.power(r, cap if count > 0 else Q(0))
            d = p.add(d, p.smul(p.mul(factor, p.log(r)), -count))
        return d[1]

    checks = {}
    for k in (Q(0), Q(".0005"), INCUMBENT, Q(".005"), Q(".0227")):
        checks[str(k)] = {"one_stage_allodd": display(price(1, mains, k)),
                          "one_stage_upper_with_all_paid_pure_central_corrections": display(price(1, 2*b, k)),
                          "two_stage_body_only": display(price(2, 0, k)),
                          "two_stage_algebraic_upper": display(price(2, upper, k)),
                          "two_stage_free_allodd_screen": display(price(2, mains, k)),
                          "three_stage_free_allodd_screen": display(price(3, mains, k)),
                          "four_stage_free_allodd_screen": display(price(4, mains, k))}
    took = next(n for n in range(mains + 1) if price(2, n, INCUMBENT)[0] > 0)
    need(took == 346 and price(2, took-1, INCUMBENT)[1] < 0, "exact odd terminal funding threshold")
    need(price(2, upper, INCUMBENT)[1] < 0 and price(3, mains, INCUMBENT)[1] < 0, "incumbent screens")
    cap = Q(".0227")
    d1 = derivative_upper(1, 2*b, cap)
    d2 = derivative_upper(2, upper, cap)
    need(all(price(stages, odd, Q(0))[1] < 0 and d < 0
             for stages, odd, d in ((1, 2*b, d1), (2, upper, d2))),
         "certified one- and two-layer envelopes negative through the long-term reference")
    return {"A_ports": a, "B_ports": b, "main_owners": mains,
            "two_layer_ratio_change_rank_upper": 4*b, "two_layer_odd_owners_upper": upper,
            "native_paid": dict(sorted(paid.items())), "native_independent_helpers": dict(sorted(helper.items())),
            "native_rank_mass_over_helpers": 3_312, "nominal_body_mass_per_native": 3_200,
            "minimum_two_layer_odd_owners_at_incumbent": took,
            "one_layer_upper_envelope_derivative_upper_through_0_0227": str(Q(d1, p.B)),
            "two_layer_upper_envelope_derivative_upper_through_0_0227": str(Q(d2, p.B)),
            "two_layer_minimum_nonshear_ports_if_all_else_fixed": (took+19)//20,
            "exact_moment_checks": checks}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("word", type=Path)
    ap.add_argument("whole", type=Path)
    ap.add_argument("output", type=Path)
    a = ap.parse_args()
    start = monotonic()
    raw = PRICE["pin"](a.word, NATIVE["WORD_SHA"])
    word = json.loads(gzip.decompress(raw))
    whole = json.loads(PRICE["pin"](a.whole, PRICE["WHOLE"]))
    data = {"status": "PASS_SYNCHRONIZED_TYPE_AB_PRICE_AND_PHASE", "word_sha256": NATIVE["WORD_SHA"],
            "whole_receipt_sha256": PRICE["WHOLE"], "square_zero_lemma_controls": matrix_controls(),
            "phase_controls": phase_factorizations(), "selector_controls": selector_controls(),
            "signed_price": price_all(word, whole)}
    need(monotonic() < start + 15, "15-second CPU deadline")
    a.output.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    print(data["status"], f"in {monotonic()-start:.2f}s", flush=True)


if __name__ == "__main__":
    main()
