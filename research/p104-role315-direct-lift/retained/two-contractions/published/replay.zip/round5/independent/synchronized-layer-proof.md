# Synchronized caller layers for the #7546 complex native

Consider a replacement for the 17-stage #7113 caller. Each synchronized layer applies the fixed #7546 native to the same 400 independent main fields. A fresh common eight-axis body belongs to each layer. Allow any invertible basis changes on the main owners, including mixing Type A and Type B. These basis changes agree at the two common central characters `q=+1` and `q=−1`. Give all 1,101 independent helpers their original credit for every invocation. The desired clean main outputs have the whole body product and one common central exponent per owner. A positive or negative odd exponent has central rank one, and even powers are ordinary translations. This is a distinct architecture from the uneven bank shapes and paid body idles of #7113.

The comparison specializes the inherited Laurent operator identity at the two central values. Divide out the common body, which is allowed because it acts identically on every owner and commutes with the basis changes. In this model an ordinary `q`-even gate has the same matrix at both values. The ratio `T=M(-1) M(+1)^{-1}` of a clean endpoint is conjugate by a common basis to an involution. Its number of odd owners is `rank(T−I)`.

## One layer, including paid central corrections

With the eight Type B blocks replaced by identity, the 192 Type A shear pairs give the central ratio `I+N` with `N²=0`. Restoring the 16 Type B owner coordinates changes the ratio by rank at most 16. An additional paid odd-central call on one owner changes the relative ratio by rank at most one. This remains true for a call in a basis chosen by intervening operations. Telescoping at the two character values, and then using preservation of rank under left and right multiplication by each invertible matrix, incorporates all chronological interactions and arbitrary common coframe bases.

Let `E=ker(T+I)` denote the clean odd space. On `E` the difference `T−(I+N)` is `−2I−N`, which is invertible on the full space in characteristic zero. Thus `dim E≤16+m` if `m` additional paid rank-one corrections are used. Since `H_(r+1)−H_r≤1` for `H_r=r^(1−κ)` and `0≤κ<1`, each paid correction funds at most its own odd upgrade. This gives the optimistic pricing envelope of 16 odd upgrades and no additional calls.

## Two layers, including arbitrary mixing of the 400 owners

Replace the B blocks by identity in both layers and move common basis changes through the relative signs by conjugation. The two-layer ratio `P` is then a product of two square-zero factors,

\[
P=(I-2B)(I-2A),\qquad A^2=B^2=0.
\]

Here the symbols `A,B` name matrices in the two layers. They are not port types. Put `O=A+B` and `D=A−B`. Direct expansion gives

\[
P-I=-2O(I-2A),\qquad P-P^{-1}=-4(I+D)O,
\qquad D^2=-O^2.
\]

The generalized-zero and invertible subspaces of `O²` are invariant under `D` and `O`. On the generalized-zero subspace `D` is nilpotent and `I+D` is invertible. On the invertible subspace `O` is invertible and anticommutes with `D`, so it bijects `ker(D+I)` with `ker(D−I)`. The two kernels are disjoint, so `rank(I+D)` is at least half the dimension there. Consequently

\[
\operatorname{rank}(P-I)\le 2\operatorname{rank}(P-P^{-1}).
\]

The exact two-by-two control attains the factor two and rejects an invalid assumption that the product is already involutive. In particular two layers of pure square-zero shears and ordinary common bases can supply no odd clean output. The same proof bounds the possible gain from mixing the eight Type B blocks into the A bank. Each layer's relative ratio differs from the simplified layer by rank at most 16. One way to see that the combined change is at most 32 is to write the true ratio as `L₂⁺ R₂ R₁ (L₂⁺)⁻¹`, where `R_i=(L_i⁺)⁻¹ L_i⁻` with the first ratio expressed in the corresponding common basis. Replace each ratio by the square-zero ratio, retaining the true conjugating basis `L₂⁺`. This incurs total change rank at most 32. Inversion preserves the rank of a difference of invertible matrices. Since a clean `T` has `T=T⁻¹`,

\[
\operatorname{rank}(T-I)
\le \operatorname{rank}(T-P)+2\operatorname{rank}(P-P^{-1})
\le 32+2(64)=160.
\]

Even if the original eight B ports are freely recoded in both layers, at most 160 of the 400 owners can therefore receive an odd center without additional paid sign corrections. In general `b` nonshear two-owner blocks per layer give `odd≤20b` by the same proof.

## Full recursive moment in this architecture

One #7546 call pays 11,004 rank units and supplies 7,692 independent helper rank units. Its net debit before main credits is 3,312. Each common fresh body adds `400×8=3,200` main rank units. The exact interval engine reconstructs each paid and helper rank from the pinned source and price receipt. It then charges the full native invoice every time and assigns each of the 400 main owners its rank `8s` or `8s+1` when there are `s` layers. The following entries are upper envelopes, including a relaxed calculation where indicated.

| Architecture | Linear rank price | At κ=0.003648411294790 | At κ=0.0227 |
| --- | ---: | ---: | ---: |
| One layer with any number of separate pure-central rank-one corrections | −96 | −146.50050841 | −402.70839082 |
| Two layers, no extra paid calls, arbitrary common mixing and honest central-ratio cap | −64 | −182.88444436 | −783.78570581 |
| Two layers with the unproved assumption that all 400 outputs can be odd for free | +176 | +53.80681511 | −563.69393817 |
| Three layers, granting all 400 odd with free recovery | +64 | −131.14914641 | −1114.81695769 |

The first two envelopes are below zero throughout `[0,0.0227]`, certified by a directed derivative bound. Under the relaxed two-layer economics at the incumbent, a positive moment requires at least 346 odd owners. Given the unchanged 400-field and rank budgets, the matrix bound translates this into at least 18 two-owner nonshear blocks per layer. The unchanged native has eight. This is a necessary count in this model. It supplies no construction with 18 blocks.

On each Type A plane three shears do give the clean algebraic identity `L(q⁻¹) U(−q) L(q⁻¹)=U(−q) L(q⁻¹) U(−q)`, whose product is the signed central swap. An owner swap and one constant sign then give both odd targets. The check evaluates all four roots of unity exactly. The Type B block has an exact Laurent inverse conjugator `J(q)=[[1,−q],[0,−1]]`, with `J(q)²=I`. Its odd query is a separately chargeable operation unless another physical realization is supplied. These are algebraic identities. No new full three-layer tape is emitted. For four or more layers even the freely granted 400 odd outputs have negative linear rank mass.

## Direct-sum selector limit

Another way to try transporting independent lanes is a single wider Clifford with fixed computational selector bits. Suppose its branch on selector value `s` is `U_s` on a complete arbitrary payload. Conjugate the Pauli that flips one selector bit. Its block from `s` to `s+e_j` is `U_(s+e_j) U_s^†`, which must be a signed Pauli, as part of the output Pauli. Along paths across the selector cube every branch differs from a base branch by Pauli factors. Such factors preserve computational-basis support ranks. Thus no such single Clifford has branches with different recursive ranks or non-Pauli relative gate structure. The same argument applies to selector Pauli eigenspaces after a single common change of basis. The admissible example is a positive versus negative parallel quarter-turn: `C⁻¹=XC`, so a conditional ordinary translation after the common core implements it. The check compares all four columns of the one-axis/two-lane case exactly.

The retained recursive tariffs are per complete arbitrary payload. Concatenating two independent address streams doubles their total volume. A fixed selector carried as a spectator can share dispatch and monomial passes but alone yields no recursive-volume saving in this cost model. New data compression, non-Clifford routed providers, grouped body/central corrections, changed helper occupations, or lane-dependent body supports would need a separate cost and proof argument. Source background on binary quadratic Clifford representations is in Dehaene and De Moor. [Clifford group and binary quadratic forms](https://arxiv.org/abs/quant-ph/0304125)

## Reproducibility and provenance

The finite replay is standard-library Python, with exact rational matrix controls and the hash-pinned outward interval engine. It completed in 0.07 seconds under a 15-second bound. No new GPU batch was used. The checks are for necessary phase identities and rank pricing. They do not instantiate a rounded provider, a new signed full-width compiler tape or a new κ.

```powershell
python -I -B -S -W error round5/independent/synchronized_layers.py inputs/7546-word.json.gz inputs/7546-whole.json run/synchronized-layers.json
```

The command is relative to the replay bundle root. Source prices and port counts are bound to the #7546 word at `99438c43df7aac1e5dbcc43c1578fcd886c119ec`. The retained #7113 controller has deliberately asynchronous body outputs and is outside the synchronized restriction. [#7546 exact-head replay](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050) · [#7113 caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7113) · [Retained complete-fiber and caller conventions](https://github.com/CrocSwap/integer-mult-bounds/blob/bdcb34dd59a05c848e1c07cb3a680b575a35b44a/docs/research/pr-intake-evidence/pr7000-application/PROOF-REVIEW.md)
