# SPDX-License-Identifier: Apache-2.0
"""Detach the coupled 993/851 terminal response with exact normalized retiming."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
SEAM = run_path(str(HERE.parent / "round4/seam_rank_one.py"))
TOP = run_path(str(HERE.parent / "round4/complex_terminal_transport.py"))
ADJ, PRICE, NEED = (SEAM[k] for k in ("ADJ", "PRICE", "NEED"))
ROWS = ADJ["ROWS"]
HELPER, PEER, THROUGH, EVENT, FULL = 993, 851, 799, 57999, 127


def record(word, cuts, deadline, requirement=None, probe=None):
    """Record live rows at exact instruction boundaries and replay all input columns."""
    n, owned = word["public"], word["owned_fields"]
    f = word["initial"][:] + [None]*owned
    x = [ROWS["unit"](r) for r in range(n)] + [ROWS["NONE"]]*owned
    want = ROWS["target"](word)[1] if requirement is None else requirement
    out = {}
    bill = Counter()
    terms = Counter()
    for i, (op, r, *args) in enumerate(word["program"]):
        if i%512==0:
            NEED(monotonic()<deadline,"exact coframe and public-role replay deadline")
        if i in cuts:
            out[i] = (tuple(f), tuple(x))
        terms[op] += 1
        if op == "INIT":
            NEED(r>=n and f[r] is None and x[r]==ROWS["NONE"],"owned INIT")
            f[r], = args
        elif op == "CLEAR":
            NEED(r>=n and f[r]==args[0],"owned CLEAR")
            f[r], x[r] = None, ROWS["NONE"]
        elif op == "MOVE":
            a,b,is_owned = args
            NEED(f[r]==a and is_owned==(r>=n),"literal MOVE source")
            if probe is not None:
                probe(i, a, f, x)
            d = len(word["frames"][b])-len(word["frames"][a])
            NEED(d>0 or (is_owned and d<0),"paid rank and public orientation")
            bill[abs(d)] += 1
            f[r] = b
        elif op == "SCALE":
            c,h = args
            NEED(f[r]==h,"exact SCALE source frame")
            x[r] = ROWS["scale"](x[r],ROWS["ratio"](c))
        elif op in ("ADD","COPY"):
            j,c,h = args
            NEED(f[r]==f[j]==h and r!=j,"same-chart scalar gate")
            if op=="COPY": NEED(x[r]==ROWS["NONE"] and r>=n,"exact COPY prior zero")
            x[r] = ROWS["increment"](x[r],x[j],ROWS["ratio"](c))
        else:
            raise ValueError(f"unexpected gate {op}")
    NEED(x[:n] == want and f == word["final"]+[None]*owned,"all independent dirty inputs and final frames")
    NEED(all(r==ROWS["NONE"] for r in x[n:]),"all owned lifetimes close")
    return out,bill,terms


def full_detach(word, first, coefficient):
    """Conjugate affected ordinary gates, preserving the explicit off-owner correction."""
    old = word["program"]
    # Removing the two adjacent coframe uses and propagating a missing
    # e_993 input delta through the suffix yields e_993+2e_851. All other
    # public returns cancel exactly. Move the lift past that suffix and
    # append the sole needed ordinary correction in the original chart.
    NEED(old[first:first+3] == [["MOVE",HELPER,1091,FULL,False],
        ["ADD",THROUGH,HELPER,"-2",FULL],["ADD",PEER,HELPER,"2",FULL]],"literal boundary and two uses")
    omit = {first,first+1,first+2}
    NEED(not any(e[1]==HELPER or e[0] in ("ADD","COPY") and e[2]==HELPER for e in old[first+3:]),
         "helper has no further literal use after those two ADDs")
    p = [e for i,e in enumerate(old) if i not in omit]
    p += [old[first],["ADD",PEER,HELPER,str(coefficient),FULL]]
    return {**word,"program":p}


def coupled_terminal_change(word, first, coefficient):
    """Return h at its current chart and retain an invertible upper bank."""
    p=word["program"]
    out=[e for i,e in enumerate(p) if i not in (first,first+1,first+2)]
    f=word["final"][:]
    f[HELPER]=p[first][2]
    want=ROWS["target"](word)[1]
    want[PEER]=ROWS["increment"](want[PEER],want[HELPER],(-coefficient,1))
    return {**word,"program":out,"final":f},want


def scarcity(m, stock, exclude):
    compact = {}
    for role, row in sorted(stock.items()):
        if role==exclude: continue
        values = row[1]
        rs = {k: v for k,v in values.items() if k in m}
        if rs:
            compact[role] = {k: str(Fraction(a,row[0])) for k,a in sorted(rs.items())}
    return compact


def pure_pair_span(before, all_caps, dead):
    """Search one jointly usable coframe with the pure two-owner modes."""
    major = {}
    for event,(frames,rows) in before.items():
        NEED(monotonic()<dead,"paired helper coframe state")
        ports=[]
        for cap in all_caps:
            own=[ROWS["projective_key"](x, set()) for f,x in zip(frames,rows,strict=True) if f==cap and x[1]]
            r0=ROWS["matrix_rank"](own)
            r1=ROWS["matrix_rank"](own+[((HELPER,1),)])-r0
            r2=ROWS["matrix_rank"](own+[((PEER,1),)])-r0
            r12=ROWS["matrix_rank"](own+[((HELPER,1),),((PEER,1),)])-r0
            ports.append({"chart":cap,"stock_rank":r0,"missing_helper":r1,"missing_peer":r2,
                          "missing_two_owners":r12})
        major[event]=ports
    return major


def fund_early_replacement(before, at, target, deadline):
    """Represent a later dirty helper row by a genuinely available early bank."""
    candidates = sorted(r for r, (f,x) in enumerate(zip(*before[at],strict=True))
                        if f==1091 and r not in (HELPER,PEER) and x[1])
    prefix = {}
    for r in candidates:
        row = {j:Fraction(a,before[at][1][r][0]) for j,a in before[at][1][r][1].items()}
        solve_echelon(prefix,row,{r:Fraction(1)})
    den, atoms = target
    unrecovered, combo = solve_echelon(prefix,{j:Fraction(x,den) for j,x in atoms.items()},{},save=False)
    NEED(not unrecovered and combo and all(r in candidates for r in combo), "exactly funded source in early chart1091")
    combo = {r:-x for r,x in combo.items()}
    x = ROWS["NONE"]
    for r,c in combo.items():
        x=ROWS["increment"](x,before[at][1][r],c.as_integer_ratio())
    NEED(x == target,"the assembled preimage is the entire dirty row, across all inputs")
    NEED(monotonic()<deadline,"early independent basis deadline")
    return combo


def solve_echelon(basis,row, combo,save=True):
    """Reduce a sparse rational row and retain the operations on its coefficients."""
    while row:
        i = min(row)
        c = row[i]
        if i not in basis:
            if save:
                basis[i] = ({j:x/c for j,x in row.items()},{j:x/c for j,x in combo.items()})
            break
        a,b = basis[i]
        for dest,data in ((row,a),(combo,b)):
            for j,x in data.items():
                new = dest.get(j,Fraction(0)) - c*x
                if new: dest[j]=new
                else: dest.pop(j,None)
    return row,combo


def use_early_stock(word, combo, snapshot):
    """A positive coframed replay with a paid carrier and one displaced old owner."""
    n=word["public"]
    fresh=n+word["owned_fields"]
    chronological=[]
    # Materialize the successor's exact input before the old temporary
    # coframe is lost. At the old MOVE, exchange it with the same row and
    # remove the old copy while retaining every public role.
    found={r for r,f,d in zip(range(n+word["owned_fields"]),*snapshot,strict=True) if f==1091 and d[1]}
    NEED(set(combo)<=found,"every early recipe operand is physically coframed")
    p=word["program"]
    cut, move = 36662,47090
    NEED(p[move]==["MOVE",PEER,1091,FULL,False],"funded old receiver exit")
    for i,e in enumerate(p):
        if i==cut:
            chronological.append(["INIT",fresh,1091])
            chronological.extend(["ADD",fresh,r,str(c),1091] for r,c in sorted(combo.items()))
        if i==move:
            chronological.extend([["ADD",PEER,fresh,"1",1091], ["ADD",fresh,PEER,"-1",1091],
                                  ["ADD",PEER,fresh,"1",1091], ["CLEAR",fresh,1091]])
        chronological.append(e)
    return {**word,"owned_fields":word["owned_fields"]+1,"program":chronological}


def moment_step(s, R, d, paid_extra=None):
    price=PRICE["power_sum"]
    net=Counter({2*(R-d):1, d:2})
    net[R]-=2
    if paid_extra is not None:
        net.subtract(paid_extra)
    return price(net,s)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--emit",type=Path)
    parser.add_argument("--emit-coupled",type=Path)
    args=parser.parse_args()
    start, deadline = perf_counter(), monotonic()+40
    _,word=ADJ["PHYSICAL"]["load_pins"](args.word)
    n=word["public"]
    _,_,fwd,rev,_,_,_=ROWS["capture"](word,deadline)
    values=rev[EVENT]
    support = {r: Fraction(y,values[0]) for r,y in values[1].items() if r<n}
    NEED(fwd[EVENT]==ROWS["unit"](HELPER) and support=={HELPER:1,PEER:2},"exact normalized rank-one perturbation")
    candidate=full_detach(word,EVENT,support[PEER])
    cuts = {36662,36668,36706,47090,57999,62986}
    states, paid, ops=record(word,cuts,deadline)
    _, new_paid, new_ops=record(candidate,set(),deadline)
    NEED(new_paid==paid and new_ops["ADD"]==ops["ADD"]-1,"true tail refactor preserves all paid children and removes one ADD")
    recipe=fund_early_replacement(states,36662,fwd[47090],deadline)
    early=use_early_stock(word,recipe,states[36662])
    _, early_paid, _=record(early,set(),deadline)
    NEED(early_paid==paid,"carrying the existing dirty row early changes no paid MOVE")
    canceled,coupled=coupled_terminal_change(word,EVENT,2)
    _, coupled_paid, _=record(canceled,set(),deadline,coupled)
    NEED(paid-coupled_paid=={5:1},"constructive triangular endpoint deletes exactly the original rank-five move")
    NEED(PEER in word["hosted"]["X2"], "the other output is the X rail of a Type A pair")
    mate=word["hosted"]["Y2"][word["hosted"]["X2"].index(PEER)]
    NEED(ROWS["show"](coupled[PEER]) == {str(PEER):"1",str(mate):"-1",str(HELPER):"-2"},
         "retain the separate Type A shear term in the changed mixed output")
    caps={1091,264,650}
    span=pure_pair_span(states,sorted(caps),deadline)
    full, _, _=TOP["full_program"](word)
    stock={r:fwd[data[0]] for r,data in full.items()}
    terms=scarcity({HELPER,PEER,THROUGH},stock,None)
    off=[f[0] for r,f in full.items() if r!=HELPER and PEER in stock[r][1]]
    NEED(len(off)==4 and all(stock[r][1].get(HELPER,0)==-2*stock[r][1].get(PEER,0)
                            for r in stock if r!=HELPER),"paired inputs collapse to one ray on all other full ingresses")

    target_r, rank_step = 9,5
    price={}
    for s in (".003648411294790",".005",".0227"):
        k=Fraction(s)
        relax = moment_step(k,target_r,rank_step)
        restored = moment_step(k,target_r,rank_step,Counter({1:1}))
        NEED(relax[0]>0 and restored[1]<0,"a single additional paid rank-one repair already kills this local seam offer")
        price[s]={"ideal_change":relax,"with_one_rank_one_extra":restored}
    results={"status":"PASS_993_851_LOSSLESS_TAIL_DETACHMENT","events":[EVENT,58000,58001,62911],
             "public_map_coefficients":n**2,"pure_transfer_source":HELPER,"coefficient_leak":{"851":"2"},
             "through_role_with_zero_net_leak":THROUGH,"entire_native_paid":paid,"ordinary_ADD_reduction":1,
             "same_dirty_851_exit_value_available_at_event_36662":{r:str(a) for r,a in recipe.items()},
             "removed_rank_five_variant":{"paid_count":sum(coupled_paid.values()),
                 "terminal_rows":{r:ROWS["show"](coupled[r]) for r in (HELPER,PEER)},
                 "terminal_charts":{r:canceled["final"][r] for r in (HELPER,PEER)},
                 "independent_rank_two_quotient":True,"peer_type":"A-X2","peer_Y_role":mate,
                 "paid_delta":{5:-1},
                 "scope":"exact complete changed triangular native; caller must price clean helper recovery"},
             "relevant_stock":terms,"coframe_pure_modes":span,"signed_moment":price,"power_grid":PRICE["SCALE"],
             "replacement_events":candidate["program"][-2:],
             "scope":"exact ordinary refactor and triangular endpoint. A caller must restore the original Type A row to use its original credits"}
    NEED(monotonic()<deadline,"bounded source check")
    if args.emit is not None:
        args.emit.write_text(json.dumps(candidate,separators=(",",":"))+"\n",encoding="utf-8")
    if args.emit_coupled is not None:
        args.emit_coupled.write_text(json.dumps(canceled,separators=(",",":"))+"\n",encoding="utf-8")
    args.output.write_text(json.dumps(results,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(results["status"],f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
