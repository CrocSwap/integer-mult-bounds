# SPDX-License-Identifier: Apache-2.0
"""Prove the helper seam's rank-five central missing signal from a frozen cut."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
TAIL = run_path(str(HERE / "paired_tail_synthesis.py"))
TOP, ADJ, PRICE, NEED = (TAIL[k] for k in ("TOP", "ADJ", "PRICE", "NEED"))
ROWS, EXACT = ADJ["ROWS"], TOP["EXACT"]
H, P, EVENT = (TAIL[k] for k in ("HELPER", "PEER", "EVENT"))


def transfer_ports(word, before, ingress, suffix):
    """Separate a pure sector signal from full-rank but dependent observations."""
    observe = {}
    for r,(i,chart,rank) in sorted(ingress.items()):
        if i == EVENT:
            continue
        s,row=before[i]
        f=Fraction(row.get(H,0),s)
        g=Fraction(row.get(P,0),s)
        NEED(f + 2*g == 0, "every frozen high ingress has one blind direction")
        if f or g:
            observe[r]={"event":i,"origin":chart,"rank":rank,"input_signal":[str(f),str(g)],
                        "nonzero_public_suffix_rows":sum(r in row for row in suffix.values())}
    NEED(len(ingress)==1052 and len(observe)==4,"exact frozen cut source inventory")
    return observe


def ray_preparation(word, ops, at):
    """Check the hard two-dimensional normalizer on the rank-five quotient."""
    f,h = 1091,127
    n = 9
    U=EXACT["chart_space"](word["frames"][f])
    desired=EXACT["chart_space"](word["frames"][h])
    inv=ops.compose(ops.canonical_frame(n,word["frames"][h]).tab, ops.inverse(ops.canonical_frame(n,word["frames"][f]).tab))
    rank=ops.rank([x for x,z,p in inv[n:]])
    NEED(rank==5 and len(desired)//len(U)==1<<rank,"exact address width at the only blind-direction entry")
    # Any arbitrary signed Clifford on the retained fiber may be replaced
    # only after certifying what it does to both independent owner columns.
    children=ops.lower_child(ops.canonical_frame(n,word["frames"][f]).adjoint().then(
                             ops.canonical_frame(n,word["frames"][h])))
    symbolic, lowered=children
    NEED(symbolic["rank"]==rank, "one exact existing signed rank-five child")
    pair = [[Fraction(1),Fraction(0)], [Fraction(-2),Fraction(1)]]
    inverse = [[Fraction(1),Fraction(0)], [Fraction(2),Fraction(1)]]
    product2 = [[sum(pair[i][k]*inverse[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
    NEED(product2 == [[1,0],[0,1]],"ordinary logical decode is invertible at a common frame")
    return {"chart_pair":[f,h],"event":at,"actual_child_rank":rank,"common_chart_decoder": [[str(x) for x in row] for row in inverse],
            "cannot_apply_decoder_coframed_at_changed_endpoint":True}


def two_copy_price(children):
    """Compare actual typed returns with the optimistic merged-helper rank."""
    result={}
    for x in ("0.003648411294790",".005",".0227"):
        s=Fraction(x)
        # Options for the two clean helper pieces: independent ordinary
        # roles and an attached separate compensation, versus a single
        # concatenated owner whose physical seam still needs a rank-5
        # translation for the other helper return.
        require=children["actual_child_rank"]
        z0=PRICE["power_sum"]({4:1,5:1,9:-1},s)
        d=PRICE["power_sum"]({1:1},s)
        critical = TAIL["moment_step"](s,9,5,Counter({require:1}))
        NEED(critical[1]<0,"one literal repair pays far more than the hypothesized helper quotient")
        result[x]={"one_direction_price_if_no_repair":z0,"one_whole_rank_five_repair":critical,
                   "rank_one_shorts_local_optimism":PRICE["subtract"](TAIL["moment_step"](s,9,5),d)}
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("word",type=Path);ap.add_argument("output",type=Path)
    args=ap.parse_args()
    start,deadline=perf_counter(),monotonic()+20
    primitives, word=ADJ["PHYSICAL"]["load_pins"](args.word)
    _,_,old,reverse,_,_,_=ROWS["capture"](word,deadline)
    ingress,suffix,_=TOP["full_program"](word)
    table=transfer_ports(word,old,ingress,suffix)
    target=reverse[EVENT]
    NEED({k:Fraction(x,target[0]) for k,x in target[1].items() if k<word["public"]}=={H:1,P:2},
         "frozen branch and the actual upper correction")
    children=ray_preparation(word,primitives,EVENT)
    out={"status":"PASS_PAIRED_HELPER_BLIND_DIRECTION_CUT","full_ingress_count":len(ingress),
         "blind_variation":{"993":1,"851":2},"other_full_ingress_signals":table,
         "true_repair":children,"exact_tariffs":two_copy_price(children),"interval_scale":PRICE["SCALE"],
         "scope":"unchanged lower-side packet contents and rank-five split at 993; a jointly changed prefix can change the blind direction"}
    NEED(monotonic()<deadline,"bounded exact paired seam test")
    args.output.write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(out["status"],f"{perf_counter()-start:.2f}s")


if __name__=="__main__":
    main()
