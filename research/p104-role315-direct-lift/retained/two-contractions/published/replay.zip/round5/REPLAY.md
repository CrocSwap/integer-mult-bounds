# Round 5 exact replay

Extract the ZIP. Run these commands from its root with standard-library
CPython 3.11 or later and Git. Only the joint body/header replay needs
the read-only `integer-mult-bounds` Git checkout with object
`e54523517d0f03e58352e647c403a5af3e525a57`. The other inputs are in the ZIP.
`SHA256.json` binds the input, program, proof and recorded receipt bytes.

```powershell
$q = 'inputs/7546-word.json.gz'
$bill = 'inputs/7546-whole.json'
$repo = 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
$out = (New-Item -ItemType Directory -Path 'run' -Force).FullName
python -I -B -S -W error round5/paired_tail_synthesis.py $q "$out/tail.json" --emit "$out/detached-word.json" --emit-coupled "$out/coupled-word.json"
python -I -B -S -W error round5/port_seam_sector.py $q "$out/sector.json"
python -I -B -S -W error round5/coframed_precode.py $q "$out/precode.json"
python -I -B -S -W error round5/paid_carrier_repair.py $q "$out/carriers.json"
python -I -B -S -W error round5/terminal_stock_span.py $q "$out/stock.json"
python -I -B -S -W error round5/independent/synchronized_layers.py $q $bill "$out/layers.json"
python -I -B -S -W error round5/algebra/tetrad_rectangles.py
python -I -B -S -W error round5/algebra/affine_incidence.py
python -I -B -S -W error round5/algebra/receipt_chain_floor.py
python -I -B -S -W error round5/algebra/packet_pair_transport.py
python -I -B -S -W error round5/algebra/packet_group_transport.py
python -I -B -S -W error round5/recurrence/verify_joint_body_header.py $repo inputs --expect round5/recurrence/joint-body-header.json
python -I -B -S -W error round5/recurrence/verify_signed_host_complement.py inputs
python -I -B -S -W error round5/algebra/packet_triple_screen.py inputs/benchmark-d3d11-backend.py "$out/triples.json" --cpu-only
```

The seven commands before the triple screen print JSON for comparison with
the stored receipts.
Use the stored files in the respective source directories as the expected
JSON. Small differences in line endings do not affect the JSON structure.
The triple screen recorded timings and resource use on the RTX 5080. The
CPU-only replay must reproduce the counts, digest and exact top witnesses.
Omit `--cpu-only` on a suitable Windows system to rerun both backends.
The scripts marked as exact search in this folder each have a 25–45 second
internal deadline or a fixed finite domain. When orchestrating a batch,
give each subprocess its own 60-second timeout and wait for its exit.

`TERMINAL-HELPER.md`, `algebra/tetrad-incidence-proof.md`,
`independent/synchronized-layer-proof.md`, and the two `recurrence` proofs
give the mathematical scope and the corresponding recursive invoices.
The emitted triangular word has a different accepted endpoint. It does
not inherit the original Type A target credit. The counterexamples are to
specified frozen chart, phase and price models. The thick-head arithmetic
separation requires a distinct multiwidth provider. No new whole-width
provider tape or complete outer multiplication assembly is included.

The `upstream-checks.json` receipt records the read-only GitHub snapshot.
The `round3` and `round4` source files and their source attribution are
retained because the verifiers import them. All outputs are local.
