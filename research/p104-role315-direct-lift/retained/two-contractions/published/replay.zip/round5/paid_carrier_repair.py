# SPDX-License-Identifier: Apache-2.0
"""Test pure helper repair through already paid ingresses and their frozen suffix."""

import argparse
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
TAIL = run_path(str(HERE / "paired_tail_synthesis.py"))
ADJ, ROWS, PRICE, NEED = (TAIL[k] for k in ("ADJ", "ROWS", "PRICE", "NEED"))
H, X, EVENT = (TAIL[k] for k in ("HELPER", "PEER", "EVENT"))


def pure_emissions(word, ingresses, deadline):
    """Find every actual coframe stock that can isolate the arbitrary helper input."""
    events = {i: (r,f,d) for r, (i,f,d) in ingresses.items() if i != EVENT}
    ready = {}

    def probe(i, chart, frames, data):
        if i not in events:
            return
        rows = [row for f, row in zip(frames, data, strict=True) if f == chart and row[1]]
        if not any(H in row[1] for row in rows):
            return
        base = [ROWS["projective_key"](row, set()) for row in rows]
        rank = ROWS["matrix_rank"](base)
        if ROWS["matrix_rank"](base + [((H,1),)]) == rank:
            r,f,d = events[i]
            ready[i] = {"role": r, "coframe": f, "paid_rank": d, "coframed_stock_rank": rank}

    TAIL["record"](word, set(), deadline, probe=probe)
    return ready


def exact_row(row, valid):
    d, v = row
    return {j: Fraction(c,d) for j,c in v.items() if j in valid}


def dual(basis, terms):
    """Construct a right-null vector of the normalized forward echelon system."""
    out = dict(terms)
    for j, (row, _) in sorted(basis.items(), reverse=True):
        c = -sum(x*out.get(k,0) for k,x in row.items() if k != j)
        if c:
            out[j] = c
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("word", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()
    start, deadline = perf_counter(), monotonic()+25
    _, word = ADJ["PHYSICAL"]["load_pins"](args.word)
    _, _, _, reverse, _, guards, _ = ROWS["capture"](word, deadline)
    ingresses, _, _ = TAIL["TOP"]["full_program"](word)
    ready = pure_emissions(word, ingresses, deadline)
    NEED(len(ready) == 12 and all(e["coframe"]==1091 and e["paid_rank"]==5 for e in ready.values()),
         "pure h is locally available at only twelve other full ingresses")
    # A free splice h into one of those actual carrier rows adds the h
    # coefficient times its fixed suffix response at the full outputs.
    # Preserve all main and helper fields when comparing the responses.
    n = word["public"]
    proper = set(range(n))
    source = exact_row(reverse[EVENT], proper)
    NEED(source == {H:1, X:2}, "certificate is for the actual removed h event")
    target = {X: source[X]}
    solve = TAIL["solve_echelon"]
    rows = {i: exact_row(reverse[i], proper) for i in ready}
    basis = {}
    for i,row in rows.items():
        solve(basis, row.copy(), {i:Fraction(1)})
    control = exact_row(reverse[min(ready)], proper)
    remainder, _ = solve(basis, control.copy(), {}, save=False)
    NEED(control and not remainder, "an actual eligible moved direction is representable")
    gap, _ = solve(basis, target.copy(), {}, save=False)
    probe = dual(basis, {min(gap):Fraction(1)})
    dot = lambda u: sum(x*probe.get(j,0) for j,x in u.items())
    NEED(gap and not any(dot(row) for row in rows.values()) and dot(target),
         "explicit dual separates every pure splice from the isolated repair")
    # A larger scope allows h at any outgoing MOVE of the same rank-four
    # chart after h is pure, including carries that travel indirectly to top.
    # It even grants changes to public roles already ending in this chart.
    pinned = set(guards.values()) | proper
    relaxed = {i: exact_row(reverse[i], pinned) for i,e in enumerate(word["program"])
               if i >= 36706 and i != EVENT and e[0]=="MOVE" and e[2]==1091}
    for j,f in enumerate(word["final"]):
        if j != H and f == 1091:
            relaxed[f"lower_return_{j}"] = {j:Fraction(1)}
    system = {}
    for i,row in relaxed.items():
        solve(system,row.copy(),{i:Fraction(1)})
    residual, _ = solve(system,target.copy(),{},save=False)
    witness = dual(system, {min(residual):Fraction(1)})
    NEED(residual and len(relaxed)==27 and not any(sum(x*witness.get(j,0) for j,x in row.items())
         for row in relaxed.values()) and sum(x*witness.get(j,0) for j,x in target.items()),
         "existing same-chart departure roles and lower returns cannot provide the orthogonal repair")
    tariffs = {s: PRICE["power_sum"]({4:1,5:1,9:-1},Fraction(s)) for s in (".003648411294790",".005",".0227")}
    report = {"status":"PASS_FROZEN_PAID_CARRIER_REPAIR_CUT", "other_full_ingresses_checked":len(ingresses)-1,
              "pure_h_emissions":ready, "exact_suffix_span_rank":len(basis),
              "direct_dual_certificate":{j:str(c) for j,c in sorted(probe.items())},
              "direct_target_pairing":str(dot(target)),
              "enlarged_same_chart_directions":list(relaxed), "enlarged_span_rank":len(system),
              "enlarged_dual_certificate":{j:str(c) for j,c in sorted(witness.items())},
              "clean_one_helper_margin_if_repair_free":tariffs,"moment_unit":PRICE["SCALE"],
              "scope":"pure-h inputs added immediately before existing full arrivals or at old chart-1091 exits; fixed frames and downstream linear responses; dirty combinations or jointly changed upstream/downstream circuits can change the response space"}
    NEED(monotonic()<deadline,"exact bounded paid carrier repair check")
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(report["status"],len(ready), f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
