# SPDX-License-Identifier: Apache-2.0
"""Directed moment bounds for the temporal helper relaxation."""

import argparse
from fractions import Fraction as Q
from functools import cache
import json
from pathlib import Path


SCALE = 1 << 84


def rounded(value):
    scaled = value * SCALE
    return scaled.numerator // scaled.denominator, -(-scaled.numerator // scaled.denominator)


@cache
def log_bounds(rank):
    if rank == 1:
        return 0, 0
    exponent = rank.bit_length() - 1

    def series(value):
        y = (value - 1) / (value + 1)
        total = Q(0)
        power = y
        for index in range(48):
            total += 2 * power / (2 * index + 1)
            power *= y * y
        tail = 2 * power / (97 * (1 - y * y))
        return total, total + tail

    low_two, high_two = series(Q(2))
    low_tail, high_tail = series(Q(rank, 1 << exponent))
    return rounded(exponent * low_two + low_tail)[0], rounded(exponent * high_two + high_tail)[1]


@cache
def rank_power(rank, saving):
    log_low, log_high = log_bounds(rank)

    def exp_partial(log, index):
        x = -saving * Q(log, SCALE)
        if not -1 <= x <= 0:
            raise ValueError("alternating enclosure requires x in [-1, 0]")
        total = term = Q(1)
        for order in range(1, index + 1):
            term *= x / order
            total += term
        return total

    return rounded(rank * exp_partial(log_high, 27))[0], rounded(rank * exp_partial(log_low, 26))[1]


def power_sum(histogram, saving):
    lower = upper = 0
    for rank, multiplicity in histogram.items():
        lo, hi = rank_power(int(rank), saving)
        lower += multiplicity * (lo if multiplicity >= 0 else hi)
        upper += multiplicity * (hi if multiplicity >= 0 else lo)
    return lower, upper


def subtract(a, b):
    return a[0] - b[1], a[1] - b[0]


def priced_values(data, saving):
    calls = data["native_calls"]
    actual = subtract(power_sum(data["signed_targets"], saving), power_sum(data["signed_paid"], saving))
    helper = subtract(power_sum(data["helper_moves"], saving), power_sum(data["helper_targets"], saving))
    stops = data["totals"]["joint"]
    stop_floor = power_sum({1: 2 * stops, 2: -stops}, saving)
    helper_savings = subtract(helper, stop_floor)
    raw_upper = actual[0] + calls * helper_savings[0], actual[1] + calls * helper_savings[1]
    return {
        "literal_margin": actual,
        "literal_helper_loss_one_call": helper,
        "joint_helper_floor_one_call": stop_floor,
        "optimistic_replacement_margin_interval": raw_upper,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bounds", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    data = json.loads(args.bounds.read_bytes())
    if data["signed_mass_surplus"] != 1424:
        raise ValueError("wrong caller invoice")
    rows = {}
    for price in ("0.003648411294790", "0.00376669", "0.00385248", "0.004", "0.005", "0.006", "0.0227"):
        rows[price] = priced_values(data, Q(price))

    lo, hi = Q("0.003648411294790"), Q("0.0227")
    for _ in range(30):
        middle = (lo + hi) / 2
        left, right = priced_values(data, middle)["optimistic_replacement_margin_interval"]
        if left > 0:
            lo = middle
        elif right < 0:
            hi = middle
        else:
            break
    low = priced_values(data, lo)["optimistic_replacement_margin_interval"]
    high = priced_values(data, hi)["optimistic_replacement_margin_interval"]
    if not low[0] > 0 > high[1] or not rows["0.0227"]["optimistic_replacement_margin_interval"][1] < 0:
        raise ValueError("directed bracket and target rejection required")
    data["finite_upper_relaxation"] = {
        "meaning": "original signed margin plus the literal helper debit minus the minimum interior-stop debit",
        "unit_denominator": SCALE,
        "rows_scaled": rows,
        "sign_change_bracket": [str(lo), str(hi)],
        "sign_change_display": [float(lo), float(hi)],
        "only_fixed_price_exclusions": True,
    }
    args.output.write_text(json.dumps(data, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print("PASS_DIRECTED_TEMPORAL_FLOOR_PRICE", data["finite_upper_relaxation"]["sign_change_display"])


if __name__ == "__main__":
    main()
