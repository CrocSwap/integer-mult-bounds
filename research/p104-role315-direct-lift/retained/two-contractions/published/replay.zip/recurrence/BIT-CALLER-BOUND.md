# A rank bound for BIT callers at κ = 0.0227

For the native word used in #7001, a BIT caller with arbitrary scalar mixing
and arbitrary positive body masks cannot attain `κ=0.0227` using the
retained LOCAL, QUERY, and body-only IDLE_ONE operations. Even allowing free
scalar mixing, restoration, and tape setup, the signed moment budget is short
by more than **94.71037 per native invocation**. The upper envelope crosses in
`(0.0074922869597, 0.0074922869598)` in the current outer range
`0 <= κ <= 1/32`. The envelope gives a scoped ceiling with no attainment
claim. Changing the native invoice, the job interface, or the outer assembly
can invalidate its premises.

The calculation binds canonical commit
`e54523517d0f03e58352e647c403a5af3e525a57`. #7001 supplies the selected
ordinary BIT saving 0.00385248 and the exact native price inputs.
[Paired BIT supplier](https://github.com/CrocSwap/integer-mult-bounds/pull/7001).
[Selected application review](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/docs/research/pr-intake-evidence/pr7000-application/PROOF-REVIEW.md).

## Caller model

Let each root have `n` arbitrary independent input arrays. There are
`v=111` identical per-port tariffs, `L` native invocations and `Q` thin
queries per port, and symbolic commuting variables `q,D_1,...,D_s` with
`q²=1` over the field of two elements. Each `D_j` comprises `b=7` fresh
coordinate axes. The permitted operations at the caller boundary are

- constant invertible scalar matrices on the root roles
- LOCAL at stage `j` on two roles, acting as `D_j(I+q e_x e_y^T)` on
  those roles and fixing other roles
- QUERY on two roles, acting as `I+q e_x e_y^T` for `x≠y`
- IDLE_ONE on a role, acting as multiplication by `∏ D_j` for a nonempty
  set of stage indices. It costs one whole call of rank `b` times the set size.

The endpoint on each root role is `q^e∏ D_j` over its target mask with
`e∈{0,1}` and each stage present at most once. Separate native invocations
keep all their actual native paid jobs, productive helper inputs, and owned
lifetimes. The accounting grants arbitrary free constant invertible mixers
and does not charge additional ordinary work. Any defensible nonnegative
charge for precision, tape, restoration, and routing can only weaken the
optimistic bill. The root operations above are the actual #7001 formal
interface. Inverse body requests, paid odd-idles, extra initialized root
channels, output projections, repeated powers, and a different type or charge
for a native call are outside this model.

## How simultaneous independent calls cost one extra header each

Set `D_j=1` and `q=1+ε`, with `ε²=0`. At a cut let `A` be the invertible
nominal prefix at all variables equal to 1. Pulled back to the root input
basis, each odd operation contributes `ε u_i v_i`, where `u_i=A⁻¹e_x`
and `v_i=e_y^T A`. Its local trace `v_i u_i` vanishes. All constant scalar
and body-only operations contribute zero header derivative. With `U` the
matrix of columns `u_i` and `V` the matrix of rows `v_i`, the exact target
gives `UV=E`, the diagonal projector on the `o` odd root targets.

For `m=L+Q`, the kernel of `I_m−VU` is exactly `V(im E)`. In fact any
`z` in the kernel equals `VU z` and `Uz` lies in `im E`; conversely
`Vx` is fixed by `VU` and `U(Vx)=x` for `x∈im E`. The complementary
matrix therefore has rank `m−o`. A block of `h` odd operations for which
every cross-pairing `v_i u_j` vanishes gives an `I_h` principal block.
Thus `o−Q <= L−h`. Adjacent disjoint LOCALs are such a block.

The sharp case is strong over the two-element field. If `m=o+1`, the
complementary matrix has rank one and every diagonal entry is one. It must
be the all-one matrix, so every pair of distinct odd operations has both
cross-pairings equal to one. This explains why interleaving an overlapping
root architecture is a prerequisite for obtaining a single missing header
in this class. An actual #7001 role block has `L=36`, `o=38`,
`h=2`, and `Q=4`, so shortening it to three queries requires changing
the disjoint-pair premise.

## Why moving body marks between targets has a price floor

For one stage `j`, set all variables to 1 and take the first-order
derivative in `D_j`. A LOCAL on two roles contributes a conjugated
rank-two coordinate projector. An IDLE_ONE containing `j) contributes a
conjugated rank-one coordinate projector. Their sum is the diagonal
projector `E_j` on the root targets carrying that stage. The determinant
degree in `D_j` equals two per LOCAL at stage `j` and one per such idle;
constant mixers and QUERYs have degree zero. Therefore the number of
columns in all these rank factorizations equals `rank(E_j)` exactly.
Since the column space of their sum is inside their collective span,
their columns are independent and span `im E_j`. The idle columns alone
are also independent.

An independent subset of columns has a nonzero coordinate minor. A
nonzero permutation summand of that minor pairs each idle incidence at
stage `j` with a distinct target carrying `j`. Do this stage by stage.
An idle mark from an idle spanning `a` stages must be sent to a target
carrying at least `a` stages. To see this last inequality, the idle
contributes the *same* nominal image column at every stage in its set.
It lies in the intersection of all the respective `im E_j`, so every
coordinate where it is nonzero carries the entire idle mask.

For `t=1−κ∈(0,1)`, a target of body size `k>0` receives body credit
`(bk)^t` apportioned equally to its `k` incidence marks. Each mark
gets `b^t k^(t−1)`. An idle of size `a` pays `b^t a^(t−1)` per
assigned mark. Since `k>=a`, the idle payment covers that mark. Every
unassigned mark is worth at most `b^t`. The total unassigned count is
`2L` by determinant degree, including stages with two or more LOCALs.
For the header use `(bk+e)^t <= (bk)^t+e`, by subadditivity. Combining
the two cuts, the full target-minus-paid moment obeys

```text
margin(κ) <= L*[T_native(κ) - P_native(κ) + v*(1 + 2*b^(1-κ))] - v*h .
```

This argument includes arbitrary target masks and arbitrary conjugated
idle placements. The mask injection is the extra constraint beyond the
usual determinant trace count. Counting only the total number of body
marks would permit charging a long grouped idle while taking credit for
the same marks in unrelated small output targets. The image argument
excludes that unsupported concentration in the stated interface.

## Exact source and alternative checks

The standard-library replay reads three immutable source blobs, recounts
the native paid histograms from the source frame dimensions, reconstructs
the complete 107,352-paid / 19,950-target #7001 invoice, and independently
replays all columns of the 798-event caller over the formal body rings.
A control replaces one paid QUERY with ADD. The nominal root matrix
stays the identity and the header derivative and polynomial endpoint
both fail. The 18 body ranks and 144 concrete idle-mark assignments
pass. The header matrix has 40 rows and complementary rank two. The
silent pair comes from the first two LOCALs.

At κ=0.0227, `P_native−T_native` is in
`[1692.5608232261889,1692.5608232261890]`, against allowance approximately
`1597.850451133366` per native call. The 36-invocation relaxation with the
silent-pair debit yields
`[-3631.5733953416312,-3631.5733953416311]`; the literal full bill gives
`[-7040.5025634829713,-7040.5025634829712]`. Outward integer interval
arithmetic also bounds the derivative of the per-call margin with respect
to `t` below by `5867.0969510584439` on the current outer domain, so its
one crossing on that domain is certified. It follows that the fixed
interface requires a native net paid reduction exceeding 94.71037 before
κ=0.0227 can even clear the optimistic cost screen.

For an exact opposite test of the header constraint, take any even
`n>=2` and a simplex with columns `u_i=e_i` plus `u_*=1`, and dual
rows `v_i=1^T+e_i^T` plus `v_*=1^T`. The rank-one terms
`N_i=u_i v_i` square to zero, sum to the identity and have every cross
pairing equal to one. At each of `n+1` stages conjugate a native LOCAL
to the selected pair, cancel its constant shear with an ADD, and apply
`n−2` rank-seven idles to the complementary roles. Each stage is exactly
`D_j(I+εN_j)`; their product is `q∏D_j` on every arbitrary root
input. The verifier emits the actual GF(2) basis gates and checks this
operator for `n=2,4,6,8`. Five LOCALs, ten rank-seven idles, 37 ADDs
and 15 SWAPs give the four-field case with **zero** thin QUERYs.
Its full raw invoice crosses in `(0.0021817983760,0.0021817983761)`,
below the selected ordinary BIT saving. This failure prices the body
jobs that the header-only criterion leaves out. No compiler, native
all-width physical replay, outer application, or new κ is claimed for
this alternative.

## A target-scale changed native to test

Suppose a genuinely new BIT native word on the same 111 pairs had
boundary `D * [[0,q],[q,0]]` on each pair, with `D` supported on seven
body axes complementary to the central one. One ordinary role
exchange would then produce two independently transformed complete
rank-eight array jobs per pair, using zero thin queries and zero body
idles. This is an exact two-input operator calculation over the same
formal ring. If the hypothetical word had the exact selected native
paid and helper histograms, the **counterfactual** signed margin at
κ=0.0227 would be about **+1.5539074**. Its raw moment zero lies in
`(0.0229306339104, 0.0229306339105)`. This budget allows at most one
additional rank-one recursive charge across the entire 111-port native
at κ=0.0227. Even one added rank-two charge would consume it.

The selected native cannot supply that operator through constant
basis changes. Its coefficient of `q` has rank one on a pair, and
rank 111 on the full two-bank endpoint. The proposed coefficient has
rank two on a pair, and rank 222 on the full endpoint. Constant
invertible pre/post maps preserve that rank. The verifier checks all
36 choices of two-dimensional entry and exit isomorphisms as a finite
control. Any solution needs an actual new native carrier, frame,
query, or boundary mechanism, with arbitrary independent main and
helper inputs and all restored spectators. No implementation or
compiler admission is inferred from this counterfactual budget.

The low-rank productive helpers at ranks 2, 4, and 6 prevent a direct
separation from the rank-seven children. For this hypothetical histogram
only, the retained chronological product admits an exact finite pricing
screen. At `t=1−0.0227`, put `α=P_t/T_t` and
`λ=(15/2)^(1/2) T_(t−1/2)/T_t`. In power `d), discard target tuples of
product rank below `(15/2)^d`; their complete normalized moment is bounded
by `λ^d`, by entrywise comparison with the shifted product moment.
No paid job exceeds `7^d`, so no paid split is needed. The exact replay
gives `α<0.9996846469703`, `λ<0.9766948757216`, and
`α^135+λ^135<1`; the preceding power fails this sufficient test.
This counts every discarded target as a debit. It leaves a native word,
ownership and tape and cover realization, uniform compilation, raised
ordinary atom exponent and a strict saving above the outer target to prove.
For orientation, a hypothetical covered saving 0.02274 and atom exponent
0.023 can use the retained ordinary-wrapper formula
`(1−atom)·covered+atom·previous` to pass from 0.00385248 to 0.02230
and then 0.02272, with both stock inequalities strict. This is only a
rational parameter witness, separate from proving the covered saving
and inherited runtime terms.

### Source-bound reverse-transfer check

In the selected BIT native, logical X begins in its port's rank-one line
`P_i` and ends in the full frame. Logical Y begins in frame zero and ends
in `I−P_i`. A logical swap with these fixed endpoints would give the
two full transforms above after one ordinary role exchange. The existing
word instead restores X and adds it into Y. Simply promoting each Y
endpoint from `I−P_i` to the full frame needs a rank-one pad per pair,
which costs 111 units before any remaining change.

`check_bit_native_cuts.py` replays the entire 34,137-event native over
independent binary coefficient columns, including all 237 initial owned
columns, MOVE frames, common-frame ADDs and whole-role relabelings.
It verifies `x_i→x_i, y_i→y_i+x_i`, restores all 437 helpers and checks
the 237 owned lifecycles through their source clear points. The census
finds 2,330 literal ADDs into the X bank and none reads a form with any
original Y dependence. No original Y dependence visits the full frame.
For each X role the checker relaxes chronology and overlooks unwanted
coefficients. It forms the span of the Y projections seen at any time
in any frame on that fixed X path. These relaxed spaces have dimensions
0, 1, and 2 at 2, 56, and 53 X roles, respectively, and none contains its
required original matching `y_i`. Therefore direct repair using only
old observed donor values on those fixed paths cannot supply the reverse
direction. A new carrier, changed contact graph, altered source frames,
or a repair that creates new donor responses lies outside this check.

```powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
& $py -I -B -S .\verify_bit_caller_bound.py C:\Users\cuchu\Documents\Codex\integer-mult-bounds
& $py -I -B -S .\check_bit_native_cuts.py C:\Users\cuchu\Documents\Codex\integer-mult-bounds
```

Each script takes one repository path, does not edit it and prints a JSON
receipt. The loop sizes are fixed by four small alternative programs and
the named source words. Process limits were 12 seconds per Git read and
40–50 seconds per replay. Each check is a serial CPU program. The embedded
CPython 3.13.14 interpreter ran the exact checks. Tabnanny and AST parsing
passed. Ruff was unavailable in that interpreter.

## Open next question

The reusable next gate for a materially improved BIT supplier is a
reduction in the native net cost or a changed operator that yields more
simultaneously useful header and body marks per paid word. The rank-two
header pair above is one specific design target. A surviving construction
needs the actual all-width word and complete movement, ownership,
precision, compiler and outer invoice.
