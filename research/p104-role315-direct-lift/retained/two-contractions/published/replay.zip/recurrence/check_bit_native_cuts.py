"""Check reverse transfer cut obstructions on the selected BIT native."""

import argparse
from collections import Counter, defaultdict
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


support = Path(__file__).with_name("verify_bit_caller_bound.py")
spec = spec_from_file_location("verify_bit_caller_bound", support)
module = module_from_spec(spec)
spec.loader.exec_module(module)
PREFIX, need, read_git, rank = module.PREFIX, module.need, module.read_git, module.rank


PORTS = 111
ALL_PORTS = (1 << PORTS) - 1
Y_MASK = ALL_PORTS << PORTS


def verify_observation(word):
    """An ADD can first bring a Y source into X only at one of its visits."""
    public = word["public"]
    slots = public + word["owned_fields"]
    rows = [1 << i for i in range(slots)]
    labels = word["start"][:] + [None] * (slots - public)
    available_y_frames = defaultdict(set)
    native_adds_into_x = Counter()
    newly_crossed_terms = 0
    actions = Counter()

    def record(role):
        value = rows[role]
        if value & Y_MASK:
            available_y_frames[labels[role]].add((role, value))

    for role in range(PORTS, 2 * PORTS):
        record(role)
    for opcode, role, *args in word["program"]:
        actions[opcode] += 1
        if opcode == "ADD":
            source, frame = args
            need(labels[role] == labels[source] == frame, "ADD lacks common frame")
            if role < PORTS:
                native_adds_into_x[frame] += 1
                newly_crossed_terms += bool(rows[source] & Y_MASK)
            rows[role] ^= rows[source]
        elif opcode == "MOVE":
            need(labels[role] is not None and labels[role] == args[0], "MOVE source frame")
            labels[role] = args[1]
        elif opcode == "SWAP":
            [source] = args
            # The native SWAP opcode routes the entire current role with
            # its frame. It is distinct from a same-chart scalar gate.
            labels[role], labels[source] = labels[source], labels[role]
            rows[role], rows[source] = rows[source], rows[role]
            record(source)
        else:
            need(opcode in ("INIT", "CLEAR") and role >= public, "Bad ownership")
            if opcode == "CLEAR":
                need(labels[role] is not None and labels[role] == args[0], "CLEAR frame")
            else:
                need(labels[role] is None, "Owned lifetime restarted before CLEAR")
            labels[role] = args[0] if opcode == "INIT" else None
            rows[role] = 0
        record(role)
    need(labels[:public] == word["final"], "Wrong terminal frames")
    need(all(frame is None for frame in labels[public:]) and not any(rows[public:]),
         "Lost owned restoration")
    required = [((1 << r) | (1 << (r - PORTS))) if PORTS <= r < PORTS * 2 else 1 << r
                for r in range(public)]
    need(rows[:public] == required, "Wrong logical endpoint on arbitrary inputs")

    x_frames = [{word["start"][r]} for r in range(PORTS)]
    high_frames = set(word["final"][:PORTS])
    need(len(high_frames) == 1, "Expected one full terminal frame")
    high_frame = next(iter(high_frames))
    for event in word["program"]:
        if event[0] == "MOVE" and event[1] < PORTS:
            x_frames[event[1]].add(event[3])

    candidate_ids = []
    ranks = Counter()
    for r, frames in enumerate(x_frames):
        pool = set().union(*(available_y_frames[k] for k in frames))
        # Ignore chronology and all X/helper pollution to favor the candidate.
        projected = {((state & Y_MASK) >> PORTS) for _, state in pool}
        source = 1 << r
        ranks[len(projected)] += 1
        if rank(projected) == rank(projected | {source}):
            candidate_ids.append(r)

    return dict(
        owned_cycles=actions["CLEAR"],
        native_events=dict(actions),
        literal_native_adds_into_x=sum(native_adds_into_x.values()),
        literal_native_y_reads_into_x=newly_crossed_terms,
        source_odd_finite_endpoint="logical y <- y xor x, helpers and X restored",
        x_frame_count=len(set().union(*x_frames)),
        x_roles_with_matching_old_y_input=len(candidate_ids),
        x_matching_roles=candidate_ids,
        x_proxy_rank_census=dict(ranks),
        y_bearing_frames=len(available_y_frames),
        full_frame_y_bearing_roles=len({r for r, _ in available_y_frames[high_frame]}),
        scope="Projection onto baseline Y input variables, union over times. "
              "Allows ignoring contamination and temporal correlation; "
              "does not cover changed internal reads, routes or donors.",
    )


def main():
    cli = argparse.ArgumentParser()
    cli.add_argument("repo", type=Path)
    params = cli.parse_args()
    source = read_git(params.repo, PREFIX + "retained/inputs/BIT-NATIVE-WORD.json.gz")
    print(json.dumps(verify_observation(source), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
