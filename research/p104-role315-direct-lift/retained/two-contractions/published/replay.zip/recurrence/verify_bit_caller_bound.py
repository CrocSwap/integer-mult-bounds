"""Reproduce the BIT caller cut calculations using exact integer arithmetic."""

import argparse
from collections import Counter, defaultdict
from functools import cache
import gzip
from hashlib import sha256
import json
from math import isqrt
from pathlib import Path
import subprocess


HEAD = "e54523517d0f03e58352e647c403a5af3e525a57"
PREFIX = "research/paired-query-only-bit/"
PINS = {
    PREFIX + "EFREE-CALLER.json.gz": (
        "757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b"
    ),
    PREFIX + "retained/inputs/BIT-NATIVE-WORD.json.gz": (
        "51203e7fc75ba10bd3ac3f8e675759f47e13d262bea66b6600d1e515095cad78"
    ),
    "research/shared-wire-split-composition/data/bit-admission.json": (
        "a46b6c6040f75184cab5467656811ad988c216e3bc8e44d595a5015b6e49620b"
    ),
}
SCALE = 10**90


def need(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def read_git(repo, path):
    raw = subprocess.check_output(
        ["git", "-C", str(repo), "show", f"{HEAD}:{path}"], timeout=12
    )
    need(sha256(raw).hexdigest() == PINS[path], f"Changed source {path}")
    return json.loads(gzip.decompress(raw) if path.endswith(".gz") else raw)


def identity(size):
    return [1 << j for j in range(size)]


def selected(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length() - 1
        mask ^= low


def sum_rows(rows, selector):
    result = 0
    for i in selected(selector):
        result ^= rows[i]
    return result


def rank(rows):
    basis = {}
    for row in rows:
        while row:
            pivot = row.bit_length() - 1
            if pivot not in basis:
                basis[pivot] = row
                break
            row ^= basis[pivot]
    return len(basis)


def nominal_step(event, forward, inverse, odd_terms, body_terms):
    opcode, first, second, *rest = event
    if opcode == "IDLE_ONE":
        for stage in second:
            body_terms[stage].append((inverse[first], forward[first]))
        return
    if opcode == "LOCAL":
        for role in (second, rest[0]):
            body_terms[first].append((inverse[role], forward[role]))
        dest, src = rest[0], second
    else:
        dest, src = first, second
    if opcode == "SWAP":
        forward[dest], forward[src] = forward[src], forward[dest]
        inverse[dest], inverse[src] = inverse[src], inverse[dest]
        return
    need(opcode in ("ADD", "LOCAL", "QUERY"), f"Unknown nominal opcode {opcode}")
    if opcode in ("LOCAL", "QUERY"):
        odd_terms.append((inverse[dest], forward[src]))
    forward[dest] ^= forward[src]
    inverse[src] ^= inverse[dest]


def product_sum(terms, size):
    result = [0] * size
    for column, row in terms:
        for i in selected(column):
            result[i] ^= row
    return result


def parity(left, right):
    return (left & right).bit_count() % 2


def nominal_cuts(caller):
    size = caller["roles"]
    forward, inverse = identity(size), identity(size)
    odd, body = [], defaultdict(list)
    for event in caller["events"]:
        nominal_step(event, forward, inverse, odd, body)
        need(
            all(sum_rows(forward, sum(1 << j for j in range(size)
                                      if inverse[j] & (1 << k))) == 1 << k
                for k in range(size)),
            "Nominal inverse tracking failed",
        )
    need(forward == identity(size), "Expected nominal identity")
    diagonal = caller["diagonal"]
    odd_projector = [d["q"] << j for j, d in enumerate(diagonal)]
    need(product_sum(odd, size) == odd_projector, "Wrong header derivative")
    for stage, terms in body.items():
        wanted = [(int(stage in d["stages"])) << j for j, d in enumerate(diagonal)]
        need(product_sum(terms, size) == wanted, f"Wrong body derivative {stage}")
        need(rank(wanted) == len(terms), f"Body mark mismatch at {stage}")
        need(rank(column for column, _ in terms) == len(terms), "Lost body image")
    complement = [
        sum((parity(row, column) ^ int(i == j)) << j
            for j, (column, _) in enumerate(odd))
        for i, (_, row) in enumerate(odd)
    ]
    odd_rank = rank(odd_projector)
    need(rank(complement) == len(odd) - odd_rank, "Wrong header cut rank")
    return odd, complement, body


def full_caller_identity(caller):
    """Direct all-column polynomial replay with unbounded body powers."""
    size = caller["roles"]
    zero_power = (0,) * caller["stages"]
    rows = [{(j, 0, zero_power)} for j in range(size)]

    def body_shift(row, stages):
        model = tuple(int(k in stages) for k in range(1, caller["stages"] + 1))
        return {(j, q, tuple(a + b for a, b in zip(p, model))) for j, q, p in row}

    for opcode, a, b, *rest in caller["events"]:
        if opcode == "ADD":
            rows[a] ^= rows[b]
        elif opcode == "SWAP":
            rows[a], rows[b] = rows[b], rows[a]
        elif opcode == "QUERY":
            rows[a] ^= {(j, q ^ 1, p) for j, q, p in rows[b]}
        elif opcode == "IDLE_ONE":
            rows[a] = body_shift(rows[a], b)
        elif opcode == "LOCAL":
            dest, src = rest[0], b
            rows[dest] = body_shift(rows[dest], [a]) ^ {
                (j, q ^ 1, p) for j, q, p in body_shift(rows[src], [a])
            }
            rows[src] = body_shift(rows[src], [a])
        else:
            raise ValueError(f"Unknown opcode {opcode}")
    predicted = [
        body_shift({(j, d["q"], zero_power)}, d["stages"])
        for j, d in enumerate(caller["diagonal"])
    ]
    return rows == predicted


def recount_native(word):
    dims = {int(frame): meta["dim"] for frame, meta in word["frames"].items()}
    paid = Counter(
        abs(dims[event[3]] - dims[event[2]])
        for event in word["program"]
        if event[0] == "MOVE"
    )
    targets = Counter(
        dims[word["final"][r]] - dims[word["start"][r]]
        for r in range(222, word["public"])
    )
    return paid, targets


def histogram(raw):
    return Counter({int(r): count for r, count in raw.items()})


def recount_caller(caller, native_paid, native_targets):
    ports, body_rank = caller["ports"], caller["body_rank"]
    native_count = sum(event[0] == "LOCAL" for event in caller["events"])
    paid = Counter({r: n * native_count for r, n in native_paid.items()})
    targets = Counter({r: n * native_count for r, n in native_targets.items()})
    for d in caller["diagonal"]:
        targets[d["q"] + body_rank * len(d["stages"])] += ports
    for event in caller["events"]:
        if event[0] == "QUERY":
            paid[1] += ports
        elif event[0] == "IDLE_ONE":
            paid[body_rank * len(event[2])] += ports
    return paid, targets


def matching_members(eligible, stages):
    """Assign same-stage idle marks to distinct final coordinate indices."""
    def augment(mark, seen):
        for row in selected(eligible[mark]):
            if row in seen:
                continue
            seen.add(row)
            if row not in inverse or augment(inverse[row], seen):
                inverse[row] = mark
                return True
        return False

    assigned = []
    for stage, marks in sorted(stages.items()):
        inverse = {}
        for mark in marks:
            need(augment(mark, set()), f"No idle/body assignment at stage {stage}")
        assigned.extend((stage, mark, row) for row, mark in sorted(inverse.items()))
    return assigned


def idle_assignment(caller):
    size = caller["roles"]
    forward, inverse = identity(size), identity(size)
    mut_odd, mut_body = [], defaultdict(list)
    marks, eligible, lengths = defaultdict(list), {}, {}
    for i, event in enumerate(caller["events"]):
        if event[0] == "IDLE_ONE":
            lengths[i] = len(event[2])
            eligible[i] = inverse[event[1]]
            for stage in event[2]:
                marks[stage].append(i)
        nominal_step(event, forward, inverse, mut_odd, mut_body)
    assigned = matching_members(eligible, marks)
    for stage, ids, row in assigned:
        final = caller["diagonal"][row]["stages"]
        need(stage in final and lengths[ids] <= len(final), "Missing compatible target")
    return assigned


def ceil_div(numerator, denominator):
    return -(-numerator // denominator)


def multiply(a, b):
    products = [x * y for x in a for y in b]
    return min(products) // SCALE, ceil_div(max(products), SCALE)


def add(a, b):
    return a[0] + b[0], a[1] + b[1]


def divide(a, b):
    need(0 <= a[0] <= a[1] and 0 < b[0] <= b[1], "Unsupported interval ratio")
    return a[0] * SCALE // b[1], ceil_div(a[1] * SCALE, b[0])


def scaled(a, numerator, denominator=1):
    ends = [t * numerator for t in a]
    return min(ends) // denominator, ceil_div(max(ends), denominator)


@cache
def atanh_log(numerator, denominator):
    # 2 atanh(y) through y^(255)/255. Here 0 <= y <= 1/3.
    need(0 <= 3 * numerator <= denominator, "Log series outside its domain")
    y = scaled((SCALE, SCALE), numerator, denominator)
    square, term, total = multiply(y, y), y, (0, 0)
    for j in range(128):
        total = add(total, scaled(term, 2, 2 * j + 1))
        term = multiply(term, square)
    return total[0], total[1] + ceil_div(3 * SCALE, 3**257)


@cache
def log_integer(rank_value):
    need(rank_value > 0, "Invalid rank")
    if rank_value == 1:
        return 0, 0
    k = rank_value.bit_length() - 1
    power = 1 << k
    return add(
        scaled(atanh_log(1, 3), k),
        atanh_log(rank_value - power, rank_value + power),
    )


@cache
def price(rank_value, saving_num, saving_den):
    if rank_value == 0:
        return 0, 0
    x = scaled(log_integer(rank_value), saving_num, saving_den)
    need(0 <= x[0] <= x[1] < 2 * SCALE, "Exponential series outside its domain")
    square = x[1] >= SCALE
    if square:
        x = scaled(x, 1, 2)
    term = total = (SCALE, SCALE)
    for j in range(1, 81):
        term = scaled(multiply(term, x), 1, j)
        total = add(total, scaled(term, (-1) ** j))
    upper = total[1]
    lower = add(total, scaled(multiply(term, x), -1, 81))[0]
    enclosure = multiply((lower, upper), (lower, upper)) if square else (lower, upper)
    return scaled(enclosure, rank_value)


def moment(hist, saving_num, saving_den):
    result = (0, 0)
    for r, count in hist.items():
        result = add(result, scaled(price(r, saving_num, saving_den), count))
    return result


def format_bounds(bounds, places=13):
    factor = 10**places
    floor = bounds[0] * factor // SCALE
    ceil = ceil_div(bounds[1] * factor, SCALE)
    return [f"{'-' if i < 0 else ''}{abs(i) // factor}.{abs(i) % factor:0{places}d}"
            for i in (floor, ceil)]


def change_header_gate(caller):
    modified = caller.copy()
    modified["events"] = [event[:] for event in caller["events"]]
    event = next(event for event in modified["events"] if event[0] == "QUERY")
    event[0] = "ADD"
    return modified


def as_rows(columns):
    return [sum(int(column & (1 << row) != 0) << j for j, column in enumerate(columns))
            for row in range(len(columns))]


def inverse_rows(rows):
    size = len(rows)
    work = [row | 1 << (size + i) for i, row in enumerate(rows)]
    for i in range(size):
        pivot = next(j for j in range(i, size) if work[j] & (1 << i))
        work[i], work[pivot] = work[pivot], work[i]
        for j in range(size):
            if j != i and work[j] & (1 << i):
                work[j] ^= work[i]
    return [row >> size for row in work]


def lower_linear(rows):
    work = rows[:]
    operations = []
    for i in range(len(rows)):
        pivot = next(j for j in range(i, len(rows)) if work[j] & (1 << i))
        if i != pivot:
            work[i], work[pivot] = work[pivot], work[i]
            operations.append(["SWAP", i, pivot])
        for j in range(len(rows)):
            if j != i and work[j] & (1 << i):
                work[j] ^= work[i]
                operations.append(["ADD", j, i])
    return list(reversed(operations))


def transvection_basis(column, row, size):
    need(column != 0 and row != 0 and parity(column, row) == 0, "Not a transvection")
    # Choose first basis column equal to u; let the second pair to one with v.
    b = 1 << next(selected(row))
    columns = [column, b]
    for j in range(size):
        vector = (1 << j) ^ (b if row & (1 << j) else 0)
        if rank(columns + [vector]) > len(columns):
            columns.append(vector)
    need(len(columns) == size, "Incomplete transvection basis")
    return as_rows(columns)


def simplex_caller(size):
    need(size >= 2 and size % 2 == 0, "The simplex size is a positive even integer")
    ones = (1 << size) - 1
    terms = [(1 << i, ones ^ (1 << i)) for i in range(size)] + [(ones, ones)]
    events = []
    for stage, (column, row) in enumerate(terms, 1):
        basis = transvection_basis(column, row, size)
        events.extend(lower_linear(inverse_rows(basis)))
        events.append(["ADD", 0, 1])
        events.append(["LOCAL", stage, 1, 0])
        events.extend(["IDLE_ONE", j, [stage]] for j in range(2, size))
        events.extend(lower_linear(basis))
    diagonal = [{"q": 1, "stages": list(range(1, size + 2))} for _ in range(size)]
    return dict(roles=size, ports=111, body_rank=7, stages=size + 1,
                events=events, diagonal=diagonal)


def simplex_receipt(size, native_paid, native_targets):
    caller = simplex_caller(size)
    need(full_caller_identity(caller), f"Simplex {size} missed the full endpoint")
    odd, complement, _ = nominal_cuts(caller)
    need(all(x == (1 << len(odd)) - 1 for x in complement), "Not the simplex cut")
    ph, th = recount_caller(caller, native_paid, native_targets)
    signed = th.copy()
    signed.subtract(ph)
    at_baseline = moment(signed, 385248, 10**8)
    need(at_baseline[1] < 0, "Unexpected positive simplex at the admitted BIT cap")
    # All operations are emitted. This is the exact tariff including body idles.
    return dict(size=size, events=dict(Counter(e[0] for e in caller["events"])),
                native_calls=size + 1, paid=dict(sorted(ph.items())),
                targets=dict(sorted(th.items())),
                rank_surplus=sum(r * n for r, n in signed.items()),
                at_admitted_bit=format_bounds(at_baseline))


def two_header_budget(native_net_cost):
    # Multiplication by D hits both outputs throughout, so set D=1
    # when testing the exact q degree and the rank of the boundary.
    qodd_native = [2, 0]
    qodd_required = [2, 1]
    pairs = [[u, v] for u in range(1, 4) for v in range(1, 4) if u != v]
    for enter in pairs:
        for exit_rows in pairs:
            wrapped = [sum_rows([sum_rows(enter, row) for row in qodd_native], row)
                       for row in exit_rows]
            need(rank(wrapped) == 1, "Odd-rank invariance failed")
            need(wrapped != qodd_required, "Ordinary basis achieved a two-header native")
    signed = Counter({8: 222})
    signed.subtract(native_net_cost)
    lo = moment(signed, 229306339104, 10**13)
    hi = moment(signed, 229306339105, 10**13)
    need(lo[0] > 0 and hi[1] < 0, "Unexpected counterfactual price bracket")
    allowance = moment(signed, 227, 10000)
    need(allowance[0] > SCALE, "Response allowance is below rank one")
    need(allowance[1] < price(2, 227, 10000)[0], "Response allowance pays H2")
    return dict(
        assumed_native_implementation=False,
        assumed_native_schema="D*[[0,q],[q,0]]",
        failed_constant_wrappers=len(pairs) ** 2,
        root_targets={8: 222},
        raw_moment_zero_bracket=["0.0229306339104", "0.0229306339105"],
        extra_native_fee_allowance_at_0227=format_bounds(allowance),
        additional_rank1_calls_max_per_native=1,
    )


def two_header_finance(native_paid, native_targets):
    # All paid jobs are already below 7^d after the chronological product.
    # For retained target threshold (15/2)^d, drop a target only when its
    # product falls below that value and debit its entire credit.
    productive = native_targets.copy()
    productive[8] += 222
    target = moment(productive, 227, 10000)
    charged = moment(native_paid, 227, 10000)
    alpha = divide(charged, target)
    square_root_lo = isqrt(15 * SCALE**2 // 2)
    square_root_bound = square_root_lo, square_root_lo + 1
    lambda_ratio = divide(
        multiply(square_root_bound, moment(productive, 5227, 10000)), target
    )
    # Retaining exact directed rational grid values, integer powers prove
    # alpha**d + lambda**d < 1 independently of floating point.
    first = None
    for d in range(1, 513):
        need(0 < alpha[0] <= alpha[1] < SCALE, "Nonpositive funding slack")
        if alpha[1] ** d + lambda_ratio[1] ** d < SCALE**d:
            need(alpha[0] ** (d - 1) + lambda_ratio[0] ** (d - 1) >= SCALE ** (d - 1),
                 "Preceding directed power not separated")
            first = d
            break
    need(first is not None, "No funded power in bounded test")
    return dict(
        assumed_native_implementation=False,
        paid_ratio=format_bounds(alpha),
        discarded_target_ratio_upper=format_bounds(lambda_ratio)[1],
        first_funded_power_for_this_bound=first,
        largest_paid_rank=f"7^{first}",
        retained_target_filter=f"2^{first} * target_rank >= 15^{first}",
        no_paid_split=True,
        raw_saving_tested="0.0227",
        funding_covers="raw moment and finite separation only",
    )


def ordinary_budget():
    # Pure parameter witnesses. Covered saving is an assumption of this
    # ledger; a native word and the covered supplier would still be needed.
    from fractions import Fraction

    final = Fraction("0.0227")
    covered = Fraction("0.02274")
    atom = Fraction("0.023")
    steps = [
        Fraction("0.00385248"),
        Fraction("0.02230"),
        Fraction("0.02272"),
    ]
    envelopes = [(1 - atom) * covered + atom * old for old in steps[:-1]]
    need(all(new < cap < atom < 1 - cap for new, cap in zip(steps[1:], envelopes)),
         "Bad ordinary atom choice or bootstrap")
    need(steps[-1] > final, "No strict outer target slack")
    return dict(
        assumed_covered_saving=str(covered),
        ordinary_atom=str(atom),
        predecessor_and_steps=[str(q) for q in steps],
        strict_envelopes=[str(q) for q in envelopes],
    )


def verify_sources(repo):
    caller = read_git(repo, PREFIX + "EFREE-CALLER.json.gz")
    word = read_git(repo, PREFIX + "retained/inputs/BIT-NATIVE-WORD.json.gz")
    price_record = read_git(repo, "research/shared-wire-split-composition/data/bit-admission.json")
    native_paid, native_targets = recount_native(word)
    need(native_paid == histogram(price_record["native_paid"]), "Native paid bill differs")
    need(native_targets == histogram(price_record["native_helpers"]), "Native helper bill differs")
    paid, targets = recount_caller(caller, native_paid, native_targets)
    need(paid == histogram(price_record["paid"]), "Complete paid bill differs")
    need(targets == histogram(price_record["targets"]), "Complete target bill differs")
    need(full_caller_identity(caller), "Complete symbolic caller failed")
    mutant = change_header_gate(caller)
    need(not full_caller_identity(mutant), "Header removal went undetected")
    try:
        nominal_cuts(mutant)
    except ValueError as error:
        need(str(error) == "Wrong header derivative", "Mutation failed for wrong reason")
    else:
        raise ValueError("Header mutation retained the nominal rank constraints")
    return caller, native_paid, native_targets, paid, targets


def compute(repo):
    caller, native_paid, native_targets, paid, targets = verify_sources(repo)
    terms, complement, body = nominal_cuts(caller)
    needle = (1 << 0) | (1 << 1)
    need(complement[0] & needle == 1 and complement[1] & needle == 2,
         "First two literal odd events did not have the claimed silent cut")
    need(all(not parity(row, column) for column, row in terms), "Nonzero local trace")
    assignments = idle_assignment(caller)
    need(len(assignments) == 144 and len(body) == 18, "Missing body marks")
    # A clique in this compatibility graph is a silent principal block.
    compatible = [[not parity(row_i, column_j) and not parity(row_j, column_i)
                   for column_j, row_j in terms] for column_i, row_i in terms]
    need(not any(compatible[i][j] and compatible[i][k] and compatible[j][k]
                 for i in range(len(terms)) for j in range(i) for k in range(j)),
         "The rank-two complement cannot contain a silent triangle")

    cost = native_paid.copy()
    cost.subtract(native_targets)
    cap = Counter({1: caller["ports"], 7: 2 * caller["ports"]})
    cap.subtract(cost)
    lo = moment(cap, 74922869597, 10**13)
    hi = moment(cap, 74922869598, 10**13)
    need(lo[0] > 0 and hi[1] < 0, "Wrong universal cutoff bracket")
    derivative = (0, 0)
    for r, count in cap.items():
        # For negative counts take rank^1; for positive take rank^(31/32).
        lower = price(r, 1 if count > 0 else 0, 32)[0 if count > 0 else 1]
        derivative = add(derivative, scaled(multiply((lower, lower), log_integer(r)), count))
    need(derivative[0] > 0, "Nonmonotonic cutoff on current outer domain")

    requested = 227, 10000
    bill = targets.copy()
    bill.subtract(paid)
    cap_at_target = moment(cap, *requested)
    actual_at_target = moment(bill, *requested)
    need(actual_at_target[1] < 36 * cap_at_target[0] - 222 * SCALE < 0,
         "Wrong full and relaxed target bills")
    simplex_bill = recount_caller(simplex_caller(4), native_paid, native_targets)
    simplex_margin = simplex_bill[1].copy()
    simplex_margin.subtract(simplex_bill[0])
    simplex_lo = moment(simplex_margin, 21817983760, 10**13)
    simplex_hi = moment(simplex_margin, 21817983761, 10**13)
    need(simplex_lo[0] > 0 and simplex_hi[1] < 0, "Wrong simplex bracket")
    return dict(
        git_head=HEAD,
        source_sha256=PINS,
        caller=dict(events=len(caller["events"]), roles=caller["roles"], paid_jobs=sum(paid.values()),
                    targets=sum(targets.values()), paid_native_per_port=36,
                    paid_thin_per_port=4, odd_rank=38, header_complement_rank=2,
                    silent_term_indices=[0, 1], maximum_silent_block=2,
                    mutation_controls=1,
                    body_image_injections=len(body), body_idle_marks_assigned=len(assignments)),
        at_target=dict(saving="0.0227", native_net_paid=format_bounds(moment(cost, *requested)),
                       universal_per_call_margin=format_bounds(cap_at_target),
                       real_full_margin=format_bounds(actual_at_target),
                       relaxed_36_call_margin=format_bounds(
                           add(scaled(cap_at_target, 36), (-222 * SCALE, -222 * SCALE)))),
        universal_root_bracket=["0.0074922869597", "0.0074922869598"],
        derivative_lower_at_0_to_1_over_32=format_bounds(derivative)[0],
        changed_native_pricing=two_header_budget(cost),
        changed_native_finite_separation=two_header_finance(native_paid, native_targets),
        changed_native_ordinary_parameters=ordinary_budget(),
        simplex_raw_crossing_n4=["0.0021817983760", "0.0021817983761"],
        simplex=[simplex_receipt(n, native_paid, native_targets) for n in (2, 4, 6, 8)],
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=Path)
    args = parser.parse_args()
    receipt = compute(args.repo)
    print(json.dumps(receipt, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
