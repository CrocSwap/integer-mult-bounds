# SPDX-License-Identifier: Apache-2.0
"""Character-space rank budget for an 8-axis rational orthogonal BIT swap."""

import argparse
from collections import Counter
from fractions import Fraction as Q
import gzip
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


SUPPORT = run_path(str(Path(__file__).with_name("bit_swap_transport.py")))
ARITHMETIC = run_path(str(Path(__file__).with_name("helper_price.py")))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    blob = args.word.read_bytes()
    SUPPORT["need"](sha256(blob).hexdigest() == SUPPORT["SOURCE_SHA"], "BIT native hash changed")
    word = json.loads(gzip.decompress(blob))
    n, ports = word["public"], SUPPORT["N_PORTS"]
    dims = {int(f): v["dim"] for f, v in word["frames"].items()}
    main, helpers = 2 * ports, n - 2 * ports
    helper_ranks = Counter(dims[b] - dims[a] for a, b in zip(word["start"][main:n], word["final"][main:n], strict=True))
    public_ascending = sum(dims[b] - dims[a] for a, b in zip(word["start"], word["final"], strict=True))
    paid = Counter(abs(dims[e[2]] - dims[e[3]]) for e in word["program"] if e[0] == "MOVE")
    owned_mass = sum(r * n for r, n in paid.items()) - public_ascending
    target_mass = sum(r * n for r, n in helper_ranks.items()) + main * 8
    t = Q(".0227")
    cost = ARITHMETIC["power_sum"]
    targets = helper_ranks + Counter({8: main})
    upper = cost(targets, t)
    # Perfect telescoping lower bound: grant every independent helper and X/Y
    # a single endpoint move, and every owned job its entire original rank-7.
    ideal_public = helper_ranks + Counter({7: main})
    ideal_paid = ideal_public + Counter({7: 9})
    full_public_mass = sum(r * n for r, n in ideal_public.items())
    SUPPORT["need"](public_ascending == full_public_mass and owned_mass == 63, "rank mass controls")
    headroom = ARITHMETIC["subtract"](upper, cost(ideal_paid, t))
    owned_change_budgets = {}
    for target in (".004", ".005", ".0075", ".0227"):
        saving = Q(target)
        old = cost(paid, saving)
        ownership = cost({7: 9}, saving)
        public = ARITHMETIC["subtract"](old, ownership)
        allowed = ARITHMETIC["subtract"](cost(targets, saving), public)
        owned_change_budgets[target] = allowed
    result = {"status": "PASS_BIT_SWAP_RANK_LEDGER", "unit_denominator": ARITHMETIC["SCALE"],
              "main_fields": main, "helper_fields": helpers, "helpers": helper_ranks,
              "source_public_ascending_rank_mass": public_ascending, "source_owned_rank_mass": owned_mass,
              "swap_target_mass": target_mass, "owned_budget_keep_literal_public_at_savings": owned_change_budgets,
              "all_public_path_cost_relaxed_headroom_at_target": headroom}
    args.output.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
