# SPDX-License-Identifier: Apache-2.0
"""Check if the selected BIT final receiver donor is already a clean public mode."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE=Path(__file__).resolve().parent
CORE=run_path(str(HERE / "selected_contact_ports.py"))
HIST=run_path(str(HERE.parent / "helper_price.py"))
NEED,LOAD,EXTEND=(CORE[k] for k in ("NEED","LOAD","extend"))
PORTS=111


def exact_check(word, deadline):
    p=word["program"]
    n=word["public"]
    dims={int(k):v["dim"] for k,v in word["frames"].items()}
    histories=[[] for _ in range(n+word["owned_fields"])]
    starts=word["start"]+[None]*word["owned_fields"]
    data=[1<<i for i in range(n)]+[0]*word["owned_fields"]
    charts=starts[:]
    finish={}
    for i,e in enumerate(p):
        if i%2048==0:
            NEED(monotonic()<deadline,"bounded selected receiver contact replay")
        op,r,*a=e
        if op=="MOVE":
            f,g=a
            NEED(charts[r]==f,"literal source frame")
            charts[r]=g
            histories[r].append((i,f,g,data[r]))
            if f==0 and PORTS<=r<2*PORTS and chars_attach(p,i,r,g):
                donor=p[i+1][2]
                later=p[i+2]
                NEED(charts[donor]==g,"literal matching low donor")
                finish[r]=(i,g,later[3],donor,data[donor])
        elif op=="ADD":
            data[r] ^= data[a[0]]
        elif op=="SWAP":
            j=a[0]
            data[r],data[j]=data[j],data[r]
            charts[r],charts[j]=charts[j],charts[r]
        elif op=="INIT":
            charts[r],data[r]=a[0],0
        elif op=="CLEAR":
            charts[r],data[r]=None,0
    NEED(data[:n]==CORE["endpoint"](n) and charts[:n]==word["final"],"all independent public endpoints")
    shapes=Counter()
    seen=set()
    held_from_private=Counter()
    shared_select_return=[]
    candidates=[]
    for i,f,g,s,v in finish.values():
        NEED(v.bit_count()==1 and s>=n,"saved late low-coframe donor is a pure arbitrary input")
        j=v.bit_length()-1
        NEED(j not in seen,"independent donor labels")
        seen.add(j)
        capture=[t for t in histories[j] if t[2]==f and t[3]==v]
        before=[t for t in capture if t[0]<i]
        held_from_private[(dims[f],int(j<PORTS),len(before))]+=1
        if before:
            shared_select_return.append((i,j,before[-1][0]))
        shapes[dims[f]]+=1
        candidates.append((i,f,g,s,j,before))
    z={}
    for _,_,_,_,j,_ in candidates:
        EXTEND(z,1<<j)
    NEED(len(finish)==109 and len(z)==109,"all eligible terminal profiles captured")
    return shapes,candidates,held_from_private,shared_select_return


def chars_attach(p,i,r,g):
    return (i+2<len(p) and p[i+1][0:2]==["ADD",r] and p[i+1][3]==g
            and p[i+2][0:3]==["MOVE",r,g])


def main():
    deadline=monotonic()+25
    w=LOAD()
    shapes,candidates,sources,possible=exact_check(w,deadline)
    moment={}
    for s in (".00385248",".005",".0227"):
        heads=Counter()
        for d,c in shapes.items():
            heads[7]+=c
            heads[d]-=c
            heads[7-d]-=c
        # For comparison, combining the two Y legs and transporting its pure
        # donor separately would also need the second leg. A real carrier
        # sharing opportunity must fund or erase that donor.
        pure=Counter(heads)
        for d,c in shapes.items():
            pure[7-d]-=c
        unit=HIST["SCALE"]
        only=HIST["power_sum"](heads,Fraction(s))
        added=HIST["power_sum"](pure,Fraction(s))
        NEED(only[1]<0 and added[1]<0,"concavity and independently transporting the recipient's donor")
        moment[s]={"free_donor_upper":[v/unit for v in only],
                   "separate_donor_move":[v/unit for v in added]}
    print(json.dumps({"status":"PASS_SELECTED_TERMINAL_Y_PURE_DONORS",
                      "actual_two_leg_Y_ports":len(candidates),"shapes":dict(shapes),
                      "same_original_input_is_pure_on_prior_paid_route":possible,
                      "input_owner_and_prior_route_profile":{f"{d}:{x}:{n}":c for (d,x,n),c in sorted(sources.items())},
                      "relative_moment":moment,
                      "scope":"unchanged captured terminal scalar contributions and selected Y frames; compare the selected holder path with separately carrying each omitted donor"},sort_keys=True,indent=2))


if __name__=="__main__":
    main()
