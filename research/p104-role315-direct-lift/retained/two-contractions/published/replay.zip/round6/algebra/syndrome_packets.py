"""Share the orthogonal transport packets with all nine dense BIT corrections."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import sys
from time import monotonic

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "round5" / "algebra"))
from packet_group_transport import offers, select_packets
from packet_pair_transport import compose, nullspace
from affine_incidence import replay as replay_with_dirty
from tetrad_rectangles import (compile_word, dot, fitting_calibration, load_word,
                               members, replay, require, support,
                               supported_interval, tetrad_blocks)
from staged_two_way_routes import dirty_dependency_cut, suffix_sensitivity

PORTS = 111


def packet_syndromes(word, heads, packets):
    """Exact sparse correction descriptions on existing packet owners."""
    _, cuts = dirty_dependency_cut(word)
    rows, t = suffix_sensitivity(word, cuts, cut_exceptions=True)
    require(t == [0]*9, "selected correction has inter-cut edges")
    packet_bits = [sum(1<<i for i in src) for src,_,_ in packets]
    lookup = sorted(range(len(packets)), key=lambda k:(-packet_bits[k].bit_count(),k))
    feeders, tails, high = [], [], []
    selected = []
    for event, (_, _, rank, z) in cuts.items():
        _, _, src, dst = word["program"][event]
        require(rank == 7 and dst == 0, "unexpected original correction cut")
        high.append(src)
        selected.append(z)
        cap = tuple(tuple(map(Fraction,v)) for v in word["frames"][str(src)]["A"])
        require(len(cap) == 1, "selected cut requires a hyperplane")
        canonical = sum(1<<i for i,p in enumerate(heads) if not dot(p,cap[0]))
        require(canonical == z, "not the omitted-root support of the actual cut")
        rem = z
        pick = []
        for i in lookup:
            a = packet_bits[i]
            if a&rem == a and all(not dot(v,cap[0]) for v in packets[i][2][0]):
                pick.append(i)
                rem ^= a
        require(len(pick) == 17 and rem.bit_count() in (2,3), "tetrad syndrome support changed")
        require(all(support(heads[i]) == support(cap[0]) for i in members(rem)),
                "residue is outside the omitted root's own tetrad")
        feeders.append(pick)
        tails.append(list(members(rem)))
    for i,a in enumerate(heads):
        response = 0
        for j,s in enumerate(selected):
            if rows[i]>>j&1:
                response ^= s
        expected = sum(1<<j for j,b in enumerate(heads) if i==j or not dot(a,b))
        require(response == expected, "check every source-sink coefficient")
    return feeders, tails, high, rows


def cross_receiver_reuse(packets, common, covered, feeders):
    """Reuse joins already needed below the live cap at virtual receivers."""
    consumers = [set(j+PORTS for j,row in enumerate(feeders) if q in row)
                 for q in range(len(packets))]
    available = []
    for i,(group,_,shape) in enumerate(common):
        affected = set.intersection(*(consumers[q] for q in group))
        if affected:
            # Relative to separate observations, exact linear rank gain is
            # positive at any 0<s<1: all summands start in contained spaces.
            raw = sum(7-len(packets[q][2][0]) for q in group)-(7-len(shape))
            available.append((raw,i,affected))
    amended = [(g,list(r),f) for g,r,f in common]
    covered = [set(group) for group in covered]
    for _,i,affected in sorted(available, key=lambda row:(-row[0],row[1])):
        group, rs, shape = amended[i]
        fresh = sorted(affected - set.union(*(covered[q] for q in group)))
        rs.extend(fresh)
        for q in group:
            covered[q].update(fresh)
    return amended, covered


def shared_word(word, packets, common, covered, feeders, residue, highs, receive, *,
                retain_helpers=False, emit_packet=None, defer_residues=False):
    """Produce the complete literal two-way word, including optional dirty stock."""
    *literal, _, _ = compile_word(word, fuse_residual=True)
    frames, _, start, final, _ = literal
    n = PORTS
    zero, full = word["start"][n], word["final"][0]
    src_chart = start[:n]
    dst_chart = final[n:]
    pnext = 2*n
    # A fixed public dirty bank may own all 190 base packets. Its old data are
    # compensated from both monotone and exceptional paths, while at zero.
    if retain_helpers:
        pnext += len(packets)
    receivers = list(range(pnext,pnext+n))
    correction = list(range(pnext+n,pnext+n+9))
    scratch = correction[-1]+1
    packet_roles = list(range(2*n,pnext)) if retain_helpers else list(range(scratch+1,scratch+1+len(packets)))
    group_role = max(packet_roles + [scratch])+1
    zero_owner = group_role+1
    steps = []
    next_owned = zero_owner+1

    def allocate():
        nonlocal next_owned
        i = next_owned
        next_owned += 1
        return i

    def frame_chart(f):
        q = max(frames)+1
        frames[q] = f
        return q

    def copy(dst, df, src, sf):
        if df == sf:
            steps.append(("ADD",dst,src,df))
            return
        steps.extend([("INIT",scratch,sf),("ADD",scratch,src,sf),("MOVE",scratch,sf,df),
                      ("ADD",dst,scratch,df),("CLEAR",scratch,df)])

    packet_chart = [src_chart[src[0]] if len(f[0])==1 else frame_chart(f) for src,_,f in packets]
    recipient_dirt = [set() for _ in range(n)]
    if retain_helpers:
        for k,(_,read,_) in enumerate(packets):
            for i in read:
                recipient_dirt[i].symmetric_difference_update({k})
        for i,r in enumerate(receive):
            for d in members(r):
                recipient_dirt[i].symmetric_difference_update(feeders[d])

    for rho, f, remain in zip(correction,highs,residue,strict=True):
        steps.append(("INIT",rho,f))
        if not defer_residues:
            for i in remain:
                copy(rho,f,i,src_chart[i])
    for i in range(n):
        start_frame = zero if retain_helpers else dst_chart[i]
        steps.append(("INIT",receivers[i],start_frame))
        if retain_helpers:
            for q in sorted(recipient_dirt[i]):
                steps.append(("ADD",receivers[i],packet_roles[q],zero))
            steps.append(("MOVE",receivers[i],zero,dst_chart[i]))
    _heads, *_ = fitting_calibration(word)
    _, singles, _ = tetrad_blocks(_heads, True)
    if not defer_residues:
        for i,j in singles:
            copy(receivers[j],dst_chart[j],i,src_chart[i])

    # Interleave the actual phase-A packet owners and correction gathers.
    # Owned versions are born on first use, then retired at last use.
    group_counts = Counter(p for group,_,_ in common for p in group)
    live = set()

    def collect(q):
        out,f = packet_roles[q],packet_chart[q]
        steps.append(("MOVE",out,zero,f) if retain_helpers else ("INIT",out,f))
        sources, readers, _ = packets[q]
        if emit_packet is None:
            for i in sources:
                copy(out,f,i,src_chart[i])
        else:
            emit_packet(q,out,f,sources,src_chart,copy,frame_chart,steps,allocate,frames)
        for i,z in enumerate(feeders):
            if q in z and n+i not in covered[q]:
                copy(correction[i],highs[i],out,f)
        for i in readers:
            if i not in covered[q]:
                copy(receivers[i],dst_chart[i],out,f)
        live.add(q)

    def retire(q):
        shape = packet_chart[q]
        out = packet_roles[q]
        steps.append(("MOVE",out,shape,full) if retain_helpers else ("CLEAR",out,shape))
        live.remove(q)

    for q in range(len(packets)):
        if not group_counts[q]:
            collect(q)
            retire(q)
    pending = list(common)
    while pending:
        g = min(range(len(pending)),key=lambda k:(sum((p not in live)-(group_counts[p]==1)
                                                    for p in pending[k][0]),k))
        group, targets, shape = pending.pop(g)
        for q in group:
            if q not in live:
                collect(q)
        scope = frame_chart((tuple(tuple(x) for x in shape),nullspace(shape)))
        steps.append(("INIT",group_role,scope))
        for q in group:
            copy(group_role,scope,packet_roles[q],packet_chart[q])
        for i in targets:
            if i < n:
                copy(receivers[i],dst_chart[i],group_role,scope)
            else:
                a = i-n
                copy(correction[a],highs[a],group_role,scope)
        steps.append(("CLEAR",group_role,scope))
        for q in group:
            group_counts[q] -= 1
            if not group_counts[q]:
                retire(q)
    require(not live, "packet live bank was not closed")
    if defer_residues:
        require(emit_packet is not None,"a deferred residual emitter is required")
        emit_packet.emit_residues(correction, highs, residue, receivers, dst_chart, src_chart,
                                  singles, steps, allocate, frames)

    # The public Y must remain arbitrary and independent. Decode the
    # correction using a single reusable zero-owned slot, then merge it with
    # the complementary part already at each recipient's terminal cap.
    for rho,f in zip(correction,highs,strict=True):
        steps.append(("MOVE",rho,f,zero))
    if retain_helpers:
        for i in range(n):
            steps.append(("MOVE",i,src_chart[i],full))
        for q,(src,_,_) in enumerate(packets):
            steps.extend(("ADD",packet_roles[q],i,full) for i in src)
    for i,row in enumerate(receive):
        steps.append(("INIT",zero_owner,zero))
        for r in members(row):
            steps.append(("ADD",zero_owner,correction[r],zero))
        steps.extend([("MOVE",zero_owner,zero,dst_chart[i]),
                      ("ADD",receivers[i],zero_owner,dst_chart[i]),
                      ("CLEAR",zero_owner,dst_chart[i])])
        steps.extend([("MOVE",n+i,zero,full),("SWAP",i,n+i),("SWAP",n+i,receivers[i]),
                      ("CLEAR",receivers[i],full if retain_helpers else src_chart[i])])
    for rho in correction:
        steps.append(("CLEAR",rho,zero))
    return frames,steps,start+[zero]*(pnext-2*n),final+[full]*(pnext-2*n),next_owned


def compare(paid, baseline, targets):
    vals = []
    for s in (".005",".0227"):
        h = {r:supported_interval(r,Fraction(s)) for r in range(1,9)}
        price = lambda p,k:sum(v*h[r][k] for r,v in p.items())
        gain = [price(baseline,k)-price(paid,1-k) for k in (0,1)]
        gap = [price(paid,k)-price(targets,1-k) for k in (0,1)]
        vals.append({"s":s,"saving_2pow80":gain,"shortfall_2pow80":gap,
                     "saving_lower":gain[0]/2**80,"shortfall_lower":gap[0]/2**80})
    return vals


def main():
    deadline = monotonic()+55
    word = load_word()
    heads,*_ = fitting_calibration(word)
    packets,singles,geom = tetrad_blocks(heads,True)
    feeders,residue,highs,readers = packet_syndromes(word,heads,packets)
    raw,*_ = offers(packets,deadline)
    common,covered = select_packets(raw,len(packets))
    *literal,_,_ = compile_word(word,fuse_residual=True)
    before,old = replay(*compose(literal,packets,singles,common,covered))
    after,new = replay(*shared_word(word,packets,common,covered,feeders,residue,highs,readers))
    joined, joined_cover = cross_receiver_reuse(packets,common,covered,feeders)
    shared_literal = shared_word(word,packets,joined,joined_cover,feeders,residue,highs,readers)
    fused,fused_check = replay(*shared_literal)
    dirty = shared_word(word,packets,common,covered,feeders,residue,highs,readers,retain_helpers=True)
    dirty_paid,dirty_ops,dirty_peak,dirty_columns = replay_with_dirty(*dirty)
    require(sum(after.values()) < sum(before.values()) and monotonic()<deadline,
            "shared syndrome savings or resource deadline")
    print(json.dumps({"status":"PASS_SHARED_P111_NINE_SYNDROME_WORD",
                      "geometry":geom,"right_decoding_adds_at_zero":sum(r.bit_count() for r in readers),
                      "sources_per_syndrome_before":[sum(len(packets[j][0]) for j in p)+len(f)
                                                    for p,f in zip(feeders,residue,strict=True)],
                      "shared_packet_reuses":sum(map(len,feeders)),"residual_inputs":sum(map(len,residue)),
                      "share_fanout":dict(Counter(Counter(j for row in feeders for j in row).values())),
                      "old_moves":dict(sorted(before.items())),"new_moves":dict(sorted(after.items())),
                      "old_replay":old,"new_replay":new,
                      "price":compare(after,before,{8:222}),
                      "virtual_receiver_join":{
                          "shared_joint_dispatches":sum(sum(j>=PORTS for j in rr) for _,rr,_ in joined),
                          "replaced_syndrome_packet_dispatches":sum(sum(j>=PORTS for j in rr)
                                                                   for rr in joined_cover),
                          "replay":fused_check,"paid":dict(sorted(fused.items())),
                          "price":compare(fused,after,{8:222})},
                      "dirty_replay":{"public_helpers":len(packets),"ops":dict(dirty_ops),
                                      "paid":dict(sorted(dirty_paid.items())),"peak_owned":dirty_peak,
                                      "each_forward_reverse_coefficients":dirty_columns,
                                      "price":compare(dirty_paid,after+Counter({8:len(packets)}),
                                                      {8:222+len(packets)})}},indent=2))


if __name__ == "__main__":
    main()
