# Restoring arbitrary dirty packet owners without migrating every X

Use the nine-syndrome and joint live/omitted receiver word, with a declared independent public input for each of its 190 base packets. Let q be one of those packets, f_q the XOR of its source X values in its collection frame F_q, and d_q an arbitrary old value in the owner. The comparison holds the actual child routes, the two-way boundary and all 190 old dirty variables fixed.

## A same-frame snapshot erases the recovery ascent

Move the dirty owner from zero to F_q as before. Collect f_q independently into a zero-owned field at F_q. Before the first observer, XOR f_q into the dirty owner. After the last observer, XOR the same value back, clear the snapshot and take the now-restored dirty owner to full. Either available merge strategy sees exactly the same d_q+f_q while it collects. This acts pointwise on arbitrary bit arrays at the shared frame.

The original zero-frame correction compensates d_q through both the orthogonal route and the nine exceptional descents. The new words retain that compensation unchanged. Public X remain at their original input lines until the final swaps. The entire old independent X recovery ascent, 111 calls of rank seven, disappears. This generalizes to reusable packet owners with any same-frame aggregate and any finite collection of observers.

In the best joint incidence arrangement with the direct source collection, the two-way paid calls drop from 3,233 to 3,122. A separate combination with the round-six rank-two collector drops from 3,192 to 3,081. The latter reduces the raw charge by 769.47679 at s=.005 or 743.42522 at s=.0227. Including the 190 original rank-eight productive helper credits and the generous 222 rank-eight main credits, it still falls short by over 6,790.51 and 6,663.19.

## A directly licensed shear

For a shear, public Y can itself serve as the zero correction accumulator. Accumulate the decoder XORs into it at zero, move it to its terminal hyperplane and add the prior monotone accumulator with matching packet-dirt compensation. The public X retain their normal rank-seven ascents and remain unchanged as scalar data. This gives the same scalar-frame contract as the selected BIT shear. It removes the 111 zero-to-full Y moves required to exchange arbitrary original Y into X for the two-way contract. In this endpoint the productive main credit is 222 H7. The shear is priced separately.

## Moving the public helper origin to the actual collection frame

If a public helper can enter at F_q, it can remain untouched through each collection. All observers read the clean owned aggregate directly. There is no helper dirt in either route, so there is no precompensation or compensating receiver ascent. When the aggregate's uses finish, move the independent public owner from F_q to full. This produces a genuine return of rank 8−dim F_q, with a matching charge. The verified 190-helper histogram is 14 H4 + 168 H5 + 8 H7. Every added move in the two-way circuit has exactly one same-rank productive helper return. This creates an independent public inventory at zero net raw gain, subject to hosting the new origins as actual public boundaries.

With the optional rank-two collector this gives 2,780 paid moves and 190 peak owned roles. A forward whole-row audit and a separate reverse-functional audit each check all 169,744 coefficients across 412 public fields. After crediting the new helpers exactly, the raw gap remains 6,016.12169 at s=.005 or 5,898.12482 at s=.0227, with generous 222 H8 on the main two-way targets. The compatible shear's gaps with 222 H7 are 6,125.46000 and 6,001.75696. These profiles already lose before ordinary compilation or physical precision costs.

## Why a straightforward productive parent may fail

A genuinely useful dirty return could take an already paid movement F→G of an owned aggregate. Carry d+f as the dirty public field. The receiver needs f, so to restore d and keep the old observer response there must be an independent copy of f at G, possibly a linear combination of its other coframed rows. Two independently accumulated same-frame combinations can supply it. If all other rows annihilate one input perturbation with f equal to one, they cannot supply it.

The stock census binds the exact combined 2,590-MOVE clean word and canonicalizes equal rational subspaces, even when they have different chart IDs. It identifies all 335 paid parent-to-child edges from the 147 rank-two collectors. None has another live same-chart response combination after suppressing its own arrival. None has a prospective combination from all other paid arrivals to that same subspace, even when the rank check discards chronology and erasure. The replayer constructs an explicit input perturbation for every missing-span result. This excludes the corresponding one-edge dirty-parent promotions under unchanged arrival payloads. It leaves joint re-encoding or changing the destination frames open.

## Replay

Run snapshot_owner_shear.py or parent_return_stock.py from this directory with CPython 3.11+ and flags -I -B -O. For the combined invoice, instantiate the round-six packet_collectors.py PairInputs as described by its plans method and pass it to snapshot_owner_shear.run. All cost signs use directed power intervals. No additional dependency or external write is needed.
