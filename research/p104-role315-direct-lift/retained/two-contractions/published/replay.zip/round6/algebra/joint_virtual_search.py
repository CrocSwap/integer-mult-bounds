"""Select packet joins with live and omitted-root receivers together."""

from collections import Counter
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys
from time import monotonic

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from syndrome_packets import (PORTS, compare, cross_receiver_reuse, fitting_calibration, load_word,
                              offers, packet_syndromes, replay, require, select_packets, shared_word,
                              supported_interval, tetrad_blocks)
from scan_bit_move_runs import basis


def joint_choices(packets, feeders, deadline):
    tariff = [(0,0)] + [supported_interval(i,Fraction(".005")) for i in range(1,8)]
    readers = [sum(1<<j for j in r) for _,r,_ in packets]
    for i,roots in enumerate(feeders):
        for q in roots:
            readers[q] |= 1 << (PORTS+i)
    dims = [len(f[0]) for _,_,f in packets]
    two = {}
    count = Counter()
    options = []

    def offer(group, mask, e):
        ds = [dims[k] for k in group]
        d = len(e)
        require(d <= 6, "joined span is outside two different receiver caps")
        scope = frozenset(i for i in range(PORTS+9) if mask>>i&1)
        slope = sum(tariff[7-u][0] for u in ds)-tariff[7-d][1]
        # A component already at the union frame costs no MOVE and may join
        # an ADD at precisely the same rational frame.
        fixed = sum(tariff[d-u][1] for u in ds)
        gain = len(scope)*slope-fixed
        if gain > 0 and d not in ds:
            options.append((gain,group,scope,e,slope,fixed))

    for i,j in combinations(range(len(packets)),2):
        scope = readers[i]&readers[j]
        if scope.bit_count() < 2:
            continue
        e = basis(packets[i][2][0]+packets[j][2][0])
        two[i,j] = scope,e
        count[2] += 1
        offer((i,j),scope,e)
    for i,j,k in combinations(range(len(packets)),3):
        if (i,j) not in two:
            continue
        scope,e = two[i,j]
        scope &= readers[k]
        if scope.bit_count() < 2:
            continue
        count[3] += 1
        offer((i,j,k),scope,basis((*e,*packets[k][2][0])))
        if count[3]%1024 == 0:
            require(monotonic()<deadline, "joint virtual offer deadline")
    return count, options


def main():
    deadline = monotonic()+45
    w = load_word()
    heads,*_ = fitting_calibration(w)
    pk,singles,info = tetrad_blocks(heads,True)
    feed,residue,high,read = packet_syndromes(w,heads,pk)
    informed,positive = joint_choices(pk,feed,deadline)
    direct_choice,direct_cover = select_packets(positive,len(pk))
    same_offers,_ = offers(pk,deadline)
    past,past_cover = select_packets(same_offers,len(pk))
    amended,added_cover = cross_receiver_reuse(pk,past,past_cover,feed)
    before,base = replay(*shared_word(w,pk,amended,added_cover,feed,residue,high,read))
    after,checked = replay(*shared_word(w,pk,direct_choice,direct_cover,feed,residue,high,read))
    require(monotonic()<deadline,"joint virtual word deadline")
    comparison = compare(after,before,{8:222})
    require(all(r["saving_2pow80"][0]>0 for r in comparison),"joint selection lost priced benefit")
    print(json.dumps({"status":"PASS_JOINT_LIVE_AND_OMITTED_PACKET_SEARCH",
                      "two_or_three_packet_trials":dict(informed),
                      "positive_candidates":dict(Counter(len(group) for _,group,*_ in positive)),
                      "selected_groups":dict(Counter(len(g) for g,_,_ in direct_choice)),
                      "joint_virtual_receipts":sum(sum(i>=PORTS for i in r)
                                                   for _,r,_ in direct_choice),
                      "baseline":base,"baseline_paid":dict(sorted(before.items())),
                      "exact":checked,"paid":dict(sorted(after.items())),
                      "gain_relative_to_append_only":comparison},indent=2))


if __name__ == "__main__":
    main()
