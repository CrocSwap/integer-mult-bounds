"""Use the actual public X fields as the shared low-rank tetrad gather."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
import sys
from time import monotonic

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
from snapshot_owner_shear import clean_observation_transform, exact_replay, helper_tariff
from syndrome_packets import (PORTS, compare, fitting_calibration, load_word, packet_syndromes,
                              require, select_packets, shared_word, tetrad_blocks)
from joint_virtual_search import joint_choices
from tetrad_four_sums import TetradSums


def promote_public_x(literal, *, retained_hub_copies=False):
    frames,steps,start,final,slots = literal
    n=PORTS
    full=final[0]
    require(all(f==full for f in final[:n]),"the public shear must already return X at full")
    chart_by_source={}
    public_for_owned={}
    output=[]
    j=0
    while j<len(steps):
        old = steps[j]
        if old[0]=="CLEAR" and old[1] in public_for_owned:
            _,slot,f = old
            src=public_for_owned.pop(slot)
            require(chart_by_source[src]==f,"wrong frame when discarding the old owned source copy")
            j+=1
            continue
        if old[0]=="ADD" and old[2] in public_for_owned:
            op,i,alias,f=old
            old=(op,i,public_for_owned[alias],f)
        if j+2<len(steps) and old[0]=="INIT":
            slot,origin=old[1:]
            add,move=steps[j+1:j+3]
            if (add[:2]==("ADD",slot) and move[:3]==("MOVE",slot,origin) and
                    add[2]<n and add[3]==origin==start[add[2]] and
                    len(frames[move[3]][0])==4 and len(frames[origin][0])==1):
                source=add[2]
                # These actual 1→4 hub gathers are the only source moves
                # introduced by the tetrad callback. They can displace the
                # otherwise separate public line→full return.
                hub=move[3]
                require(source not in chart_by_source,"one source feeds two tetrad hubs")
                original_tail=j+3
                while steps[original_tail][0]=="ADD" and steps[original_tail][2:]==(slot,hub):
                    original_tail+=1
                require(original_tail>j+3,"wrong literal census of the public-source hub loads")
                output.append(("MOVE",source,origin,hub))
                for _,target,_,f in steps[j+3:original_tail]:
                    output.append(("ADD",target,source,f))
                chart_by_source[source]=hub
                if retained_hub_copies:
                    require(steps[original_tail]!=("CLEAR",slot,hub),"expected a hub copy retained to residual scatter")
                    public_for_owned[slot]=source
                    j=original_tail
                else:
                    require(steps[original_tail]==("CLEAR",slot,hub),"wrong original ownership")
                    j=original_tail+1
                continue
        if old[0]=="MOVE" and old[1] in chart_by_source:
            i,a,b=old[1:]
            require(a==start[i] and b==full,"unexpected later movement of a live original X")
            old=("MOVE",i,chart_by_source[i],full)
        if old[0]=="ADD" and old[2] in chart_by_source and old[3]!=full:
            require(old[3]==chart_by_source[old[2]],"public X leaves a later source-specific line contact")
        output.append(old)
        j+=1
    require(len(chart_by_source)==103 and not public_for_owned,"expected one gather per signed tetrad line")
    return (frames,output,start,final,slots),chart_by_source


def run(with_residue=False):
    deadline=monotonic()+60
    w=load_word()
    heads,*_=fitting_calibration(w)
    pk,_,_=tetrad_blocks(heads,True)
    feed,rem,high,read=packet_syndromes(w,heads,pk)
    _,opts=joint_choices(pk,feed,deadline)
    groups,covered=select_packets(opts,len(pk))
    omitted=[tuple(map(Fraction,w["frames"][str(f)]["A"][0])) for f in high] if with_residue else []
    c=TetradSums(heads,pk,omitted=omitted)
    source=shared_word(w,pk,groups,covered,feed,rem,high,read,retain_helpers=True,emit_packet=c,
                       defer_residues=with_residue)
    require(not c.bank and not any(c.remaining.values()),"tetrad aggregate owner remains live")
    old=clean_observation_transform(source,shear=True,keep_ascents=True)
    before,old_info=exact_replay(*old,shear=True)
    new,where=promote_public_x(old,retained_hub_copies=with_residue)
    after,checked=exact_replay(*new,shear=True)
    require(before-after=={7:103} and after-before=={4:103},"public-X same-endpoint movement difference")
    productive=Counter({7:2*PORTS})+helper_tariff(new[0],new[2],new[3])
    bound=compare(after,before,productive)
    require(all(r["saving_2pow80"][0]>0 for r in bound) and monotonic()<deadline,"priced gain and bounded replay")
    return {"status":"PASS_PUBLIC_X_TETRAD_HUB_SHEAR","source_gathers":len(where),
            "with_tetrad_residues":with_residue,
            "old":old_info,"old_paid":dict(sorted(before.items())),
            "new":checked,"new_paid":dict(sorted(after.items())),
            "productive":dict(sorted(productive.items())),"price":bound}


if __name__=="__main__":
    print(json.dumps({"direct_edge_residues":run(False),"tetrad_hub_residues":run(True)},indent=2))
