# The nine BIT syndromes can share the Hamming transport

Use the exact #7001 P111 geometry and the round-five two-way X/Y contract. The word has 222 independent public arrays. Write the desired transfer as I=O+B0 over F2. The incidence O is one on orthogonal pairs. The rank-nine correction B0 is one on those pairs and on the diagonal. [Selected BIT native #7001](https://github.com/CrocSwap/integer-mult-bounds/pull/7001)

## Simultaneous observation of omitted ports

Each selected #7001 cut has high chart p_a^⊥ and destination zero, where p_a is one of the nine omitted roots. Its X response is the XOR of all live X inputs orthogonal to p_a. The source-bound replay recovers the actual high frames, first responses, and the 111 nine-bit reader codes. The forward check covers all 12,321 coefficients of B0. The selected correction has zero direct inter-cut responses.

Treat each omitted signed tetrad root as a virtual receiver in the Hamming packet table. For each of twelve crossing tetrads it takes the compatible sign class on the common coordinate pair. It takes the all-sign packet from its complementary tetrad and the four coordinate singleton packets disjoint from its own support. The remaining terms are orthogonal roots from the same tetrad. Two or three survive the puncture.

The 17 packet supports and the remnants are disjoint and give exactly the whole omitted-root orthogonal set. Every complete packet frame lies in the syndrome's high chart. Add each reused payload to the high collector during its original packet lifetime. The nine syndromes use 153 shared observations and 23 direct remnants in place of 523 individual source arrivals in this cut basis. The mechanism extends to other signed support families satisfying the same crossing rule at omitted as well as live roots.

An existing joint packet can also feed an omitted-root collector when all its component packets are required there. Its union frame lies inside the omitted-root cap, so it is safe to send that joint payload without minting another merge owner. Each selected joint occurrence replaces its component arrivals. The exact assignment uses 72 existing joint packets to replace 144 separate syndrome arrivals. The remaining nine individual packet observations and the 23 same-tetrad copies are fully charged. This reuse adds no new joint packet setup.

## Zero-frame decoding and arbitrary independent inputs

Perform the nine rank-seven descents, and form each correction while they share frame zero. The independent public Y must remain available for the X return. A single reusable zero-owned rail forms the correction, moves it to the recipient cap, XORs it into the existing O value, then clears the copy. This charges one correction ascent per recipient. Original Y still moves directly from zero to full for the opposite return.

The executable also tests all 190 base packets as public owners with independent original data. Add the predicted response of their dirt in both O and B0 to every affected zero-phase receiver before its ascent. The two dirty responses cancel after the final correction XOR. Bring original X inputs and packet owners to full before running the literal inverse collection, which restores every independently dirty owner. The additional movements of X and the precompensated receivers are charged.

## Exact invoice

| Circuit | Paid MOVE | Peak owned | Coefficients per replay |
|---|---:|---:|---:|
| Round-five mixed-packet control | 3,509 | 122 | 49,284 |
| Shared syndromes, owned packet roles | 2,742 | 130 | 49,284 |
| Shared syndromes and joint virtual recipients | 2,670 | 130 | 49,284 |
| Jointly selected live and virtual receptors | 2,631 | 129 | 49,284 |
| Shared syndromes, 190 independently dirty public packet owners | 3,344 | 122 | 169,744 |

Both forward arbitrary-input rows and separate reverse functionals check the entire scalar map in each case. The forward replay checks every exact rational frame inclusion and owned lifetime.

The owned-packet bill is 76 H1 + 1605 H2 + 143 H3 + 112 H4 + 230 H5 + 345 H6 + 120 H7 + 111 H8, with H_r=r^(1−s). Directed power bounds prove improvement over the prior two-way control of more than 5,207.93 at s=.005 and 5,034.47 at s=.0227. After granting all 222 main targets rank-eight credit, the raw shortfalls still exceed 7,291.82 and 7,141.32. The public-owner variant's even larger invoice, with 190 additional independent rank-eight credits, has shortfalls of 8,835.68 and 8,649.82.

Adding the virtual recipients to the chosen joint packets decreases cost by 446.18 at s=.005 and 432.92 at s=.0227. Each coefficient and every move is checked again. One can also include the virtual recipients before choosing the joint packets. The search scores 5,096 eligible pairs and 26,964 eligible triples at s=.005 and greedily selects 156 pairs and 32 triples, charging every formation and recipient occurrence. It saves a further 74.74552 at s=.005 and 73.85156 at s=.0227. The best invoice is 65 H1 + 1644 H2 + 129 H3 + 3 H4 + 248 H5 + 311 H6 + 120 H7 + 111 H8. Its shortfalls are more than 6,770.89 and 6,634.55 after the generous 222 H8 credit. The greedy choice is a witnessed incidence assignment.

The selected #7001 shear already gathers each syndrome from three precomputed high-frame rows and uses 527 zero-frame correction XORs before Y moves. Its 2,871 priced calls have a different helper invoice. The 2,631 count applies to the finite two-way building block with owned packets. The exact paid-minus-productive gaps govern the comparison.

## Reproduce

Run syndrome_packets.py and joint_virtual_search.py from this directory with CPython 3.11+ and flags -I -B -O. Preserve the work/algebra, work/round3/algebra and work/round5/algebra paths relative to this file for the native word, exact geometry and original packet code. The optional collector callback can change first-tier packet realization while the syndrome, arbitrary-input and terminal audits remain active. The bounded replays each take under ten seconds on DESKTOP-CHKL6QL. The raw gaps already exclude these invoices before ordinary compilation, precision and recovery are charged.
