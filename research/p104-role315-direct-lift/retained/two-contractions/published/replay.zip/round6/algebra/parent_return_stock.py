"""Audit whether the already-paid pair collector arrivals can host dirty returns."""

from collections import Counter, defaultdict
from functools import cache
from itertools import product
import json
from pathlib import Path
import sys
from time import monotonic

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
sys.path.insert(0,str(HERE))
from packet_collectors import PairInputs, plans, basis
from snapshot_owner_shear import exact_replay
from syndrome_packets import (PORTS, dot, fitting_calibration, load_word, packet_syndromes,
                              require, select_packets, shared_word, tetrad_blocks)
from joint_virtual_search import joint_choices


class ObservedPairInputs(PairInputs):
    def __init__(self, active):
        super().__init__(active)
        self.roles = set()
        self.parent_port_sets = active

    def __call__(self, q, out, f, sources, sc, copy, frame, steps, allocate, frames):
        def owned_role():
            p = allocate()
            self.roles.add(p)
            return p
        super().__call__(q,out,f,sources,sc,copy,frame,steps,owned_role,frames)


def span_coefficients(vectors, desired):
    reduced = {}
    for item,row in enumerate(vectors):
        c = 1 << item
        while row:
            k = row.bit_length()-1
            if k not in reduced:
                reduced[k] = row,c
                break
            t,val = reduced[k]
            row ^= t
            c ^= val
    result = 0
    while desired:
        k = desired.bit_length()-1
        if k not in reduced:
            return None
        t,v = reduced[k]
        desired ^= t
        result ^= v
    return result


def event_incidences(literal, collector):
    frames,steps,start,_,slots = literal
    by_replay = defaultdict(list)
    same = Counter()
    endpoints = []
    # The live scalar word is unchanged. We additionally retain an optimistic
    # snapshot of every arrival through any numerically identical subspace.
    shape = {i:len(basis(f[0])) for i,f in frames.items()}
    @cache
    def eq_space(a,b):
        B,A=frames[b]
        return len(B)==shape[a] and all(not dot(v,x) for v,x in product(frames[a][0],A))
    by_dim = defaultdict(list)
    for i in frames:
        by_dim[shape[i]].append(i)
    canonical = {}
    for i in frames:
        canonical[i]=next(j for j in by_dim[shape[i]] if eq_space(i,j))
    active = list(start)+[None]*(slots-len(start))
    vals = [1<<i for i in range(len(start))]+[None]*(slots-len(start))
    parents = {}
    literal_edges = []
    for j,(op,i,*a) in enumerate(steps):
        if op=="INIT":
            active[i]=a[0]
            vals[i]=0
        elif op=="CLEAR":
            active[i]=None
            vals[i]=None
        elif op=="ADD":
            vals[i]^=vals[a[0]]
        elif op=="SWAP":
            k=a[0]
            active[i],active[k] = active[k],active[i]
            vals[i],vals[k] = vals[k],vals[i]
        elif op=="MOVE":
            f,g=a
            active[i]=g
            row=vals[i]
            by_replay[canonical[g]].append((j,row))
            if (j>1 and steps[j-2][:2]==("INIT",i) and steps[j-1][0:2]==("ADD",i)
                    and steps[j-1][2] in collector.roles and shape[f]==2 and shape[g] in (3,4)):
                src=steps[j-1][2]
                require(row.bit_count()==2 and row < (1<<PORTS),"pair payload is two public Xs")
                pair=tuple(k for k in range(PORTS) if row>>k&1)
                require(pair in collector.parent_port_sets,"pair collector role attribution")
                require(src not in parents or parents[src]==pair,"parent role has two meanings")
                parents[src]=pair
                require(steps[j+1][:1]==("ADD",) and steps[j+1][2]==i,"missing child deposit")
                child=steps[j+1][1]
                immediate=[(k,vals[k]) for k,f in enumerate(active)
                           if f is not None and k!=i and canonical[f]==canonical[g]]
                immediate_fit=span_coefficients([r for _,r in immediate],row)
                literal_edges.append((j,src,pair,canonical[f],canonical[g],row,
                                      None if immediate_fit is None else
                                      [immediate[k][0] for k in range(len(immediate)) if immediate_fit>>k&1],
                                      child))
    require(len(literal_edges)==sum(map(len,collector.parent_port_sets.values())),
            "all parent-to-child lifts present")
    parent_hist = Counter()
    least_span_escapes = []
    for event, p,pair,F,G,row,imm, child in literal_edges:
        alternate = [v for t,v in by_replay[G] if t!=event]
        static = span_coefficients(alternate,row)
        now = [v for t,v in by_replay[G] if t<event]
        prior = span_coefficients(now,row)
        # If a dirty owner uses the original paid edge, an external input variation
        # must annihilate every other paid arrival yet change the carried value.
        # A missing-span condition is equivalent to the existence of this probe.
        if static is None:
            deck = [*alternate,row]
            equations = [0]*len(alternate)+[1]
            columns = [sum(((x>>k)&1)<<i for i,x in enumerate(deck)) for k in range(PORTS)]
            want = sum(v<<i for i,v in enumerate(equations))
            probe = span_coefficients(columns,want)
            require(probe is not None and all(not (x&probe).bit_count()%2 for x in alternate)
                    and (row&probe).bit_count()%2==1,"annihilator witness must separate the pair")
            least_span_escapes.append({"event":event,"changed_input_count":probe.bit_count()})
        endpoints.append({"event":event,"source_pair":pair,"parent":p,"child":child,
                          "origin":F,"destination":G,"rank":shape[G]-shape[F],
                          "immediate_local_fit":imm,
                          "earlier_arrivals_fit":prior is not None,
                          "any_other_arrival_fit":static is not None})
        parent_hist[p, G] += 1
        same[(shape[G],imm is not None,prior is not None,static is not None)] += 1
    return {"parents":len(parents),
            "coframed_duplicates_by_parent":dict(Counter(parent_hist.values())),
            "event_summary":[{"destination_dimension":d,"immediate":im,"earlier":pr,
                              "ignoring_chronology":st,"count":v}
                             for (d,im,pr,st),v in sorted(same.items())],
            "representative_immediate_fits":[row for row in endpoints if row["immediate_local_fit"]][:8],
            "representative_static_fits":[row for row in endpoints if row["any_other_arrival_fit"]][:8],
            "exact_witness_change_count":dict(Counter(w["changed_input_count"] for w in least_span_escapes))}


def matrix_control():
    # Positive case reuses (x0+x2) and (x1+x2) to make the missing x0+x1.
    right = [0b101,0b110,0b1000]
    require(span_coefficients(right,0b011)==0b011,"positive aggregate cancellation fixture")
    require(span_coefficients([right[0],right[2]],0b011) is None,"drop-one-observation is biting")


def main():
    end = monotonic()+65
    w = load_word()
    h,*_ = fitting_calibration(w)
    p,_,_ = tetrad_blocks(h,True)
    f,res,hi,r = packet_syndromes(w,h,p)
    _,o = joint_choices(p,f,end)
    g,c = select_packets(o,len(p))
    a,_ = plans(p,end)
    choices = ObservedPairInputs(a)
    literal = shared_word(w,p,g,c,f,res,hi,r,emit_packet=choices)
    paid,replay = exact_replay(*literal)
    matrix_control()
    record = event_incidences(literal,choices)
    require(monotonic()<end,"stock census deadline")
    print(json.dumps({"status":"PASS_PAIR_PARENT_RESTORATION_STOCK_CENSUS",
                      "paid":dict(sorted(paid.items())),"endpoint":replay,**record},indent=2))


if __name__=="__main__":
    main()
