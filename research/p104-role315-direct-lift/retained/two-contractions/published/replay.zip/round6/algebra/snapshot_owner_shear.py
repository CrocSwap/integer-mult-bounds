"""Refactor shared-syndrome dirty packets by all-input same-frame snapshots."""

from collections import Counter
from functools import cache
from itertools import product
import json
from pathlib import Path
import sys
from time import monotonic

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from syndrome_packets import (PORTS, compare, fitting_calibration, load_word,
                              packet_syndromes, require, select_packets, shared_word, tetrad_blocks)
from joint_virtual_search import joint_choices
from permute_head_frames import dot


def identify(literal):
    frames, steps, start, final, slots = literal
    n = PORTS
    public = len(start)
    zero, full = start[n], final[0]
    receivers = list(range(public,public+n))
    end_frames = final[n:2*n]
    for i in range(n):
        require(("INIT",receivers[i],zero) in steps and
                ("MOVE",receivers[i],zero,end_frames[i]) in steps and
                ("CLEAR",receivers[i],full) in steps,
                "shared-word receiver form changed")
    out = {}
    for i in range(2*n,public):
        motions = [(j,*e[2:]) for j,e in enumerate(steps) if e[:2]==("MOVE",i)]
        require(len(motions) == 2 and motions[0][1] == zero and motions[1][2] == full
                and motions[0][2] == motions[1][1], "unexpected dirty packet journey")
        birth, _, mid = motions[0]
        retired, *_ = motions[1]
        out[i] = birth,retired,mid
    return out,receivers


def snapshot_transform(literal, *, shear=False, keep_ascents=False):
    frames, steps, start, final, slots = literal
    n = PORTS
    public = len(start)
    zero, full = start[n], final[0]
    high = final[n:2*n]
    schedule, r = identify(literal)
    stage = {i:0 for i in schedule}
    inverse_r = {a:i for i,a in enumerate(r)}
    post_scatter = set()
    phase = {}
    for p in schedule:
        entry, exit, frame = schedule[p]
        phase[p] = (slots+p-2*n, entry, exit, frame)
    passed = []
    after = []

    # Move only the accumulation destination from the public dirty rail to
    # a clean snapshot. Once the gathered payload is complete, XOR it into
    # the public rail for all observations, undo it at the same frame, then
    # move the clean original to full. Nothing about the old public value
    # enters the snapshot.
    for j,e in enumerate(steps):
        op,i,*args = e
        if i in phase:
            stock, birth, end, frame = phase[i]
            if j == birth:
                passed.append(e)
                passed.append(("INIT",stock,frame))
                continue
            if j == end:
                require(stage[i] == 1, "dirty packet has no observation")
                passed.extend([("ADD",i,stock,frame),("CLEAR",stock,frame),e])
                stage[i] = 2
                continue
            if op == "ADD":
                a, f = args
                if birth < j < end:
                    require(stage[i] == 0 and f == frame, "mutated packet after first observation")
                    passed.append(("ADD",stock,a,f))
                    continue
                if j > end:
                    require(f == full and a < n, "unknown dirty packet restoration")
                    continue
        if op == "ADD" and args[0] in phase:
            a, f = args
            stock,birth,end,frame = phase[a]
            if birth < j < end and stage[a] == 0:
                require(f == frame, "wrong frame at first packet observation")
                passed.append(("ADD",a,stock,frame))
                stage[a] = 1
        if not keep_ascents and op == "MOVE" and i < n and args == [start[i],full]:
            continue
        passed.append(e)
    require(all(x==2 for x in stage.values()), "unclosed dirty snapshot lifecycle")

    if not shear:
        finals = final
        if not keep_ascents:
            passed = [(op,i,start[inverse_r[i]]) if op=="CLEAR" and i in inverse_r
                      else (op,i,*a) for op,i,*a in passed]
        return frames,passed,start,finals,slots+public-2*n

    # The public Y can replace the zero-phase correction rail in a shear.
    # The earlier cap accumulator still carries the complement and the
    # matching dirty compensation. Both parts meet at the terminal cap.
    cut_drains = {i for op,i,*a in passed if op=="MOVE" and
                  i >= public+n and i < public+n+9 and a[1]==zero}
    require(len(cut_drains) == 9, "original correction carriers moved")
    zero_scatter = None
    for j,e in enumerate(passed):
        if (e[0] == "ADD" and e[2] in cut_drains and e[3] == zero):
            zero_scatter = e[1]
            break
    require(zero_scatter is not None,"missing reusable correction target")
    dsts = []
    for op,i,*a in passed:
        if i == zero_scatter:
            if op=="INIT":
                require(a == [zero],"unexpected correction birth")
                dsts = []
            elif op=="ADD":
                require(a[0] in cut_drains and a[1]==zero,"unexpected correction argument")
                dsts.append(a[0])
            elif op=="MOVE":
                require(dsts,"empty or unidentified correction")
            elif op=="CLEAR":
                pass
            else:
                raise ValueError(op)
            continue
        if op=="ADD" and a[0]==zero_scatter:
            require(i in inverse_r and a[1]==high[inverse_r[i]], "bad final correction consumer")
            t = inverse_r[i]
            y = n+t
            after.extend(("ADD",y,z,zero) for z in dsts)
            after.extend([("MOVE",y,zero,high[t]),("ADD",y,i,high[t])])
            continue
        if op=="MOVE" and n<=i<2*n:
            require(a == [zero,full],"unrelated old public Y movement")
            continue
        if op=="SWAP":
            require((i<n and a[0]==n+i) or (n<=i<2*n and a[0]==r[i-n]),
                    "unknown terminal relabeling")
            continue
        if op=="CLEAR" and i in inverse_r:
            after.append((op,i,high[inverse_r[i]]))
            post_scatter.add(i)
            continue
        after.append((op,i,*a))
    require(len(post_scatter)==n,"incomplete shear receiver cleanup")
    finals = (final[:n] if keep_ascents else start[:n])+final[n:]
    return frames,after,start,finals,slots+public-2*n


def clean_observation_transform(literal, *, shear=False, keep_ascents=False):
    """Transmit only the owned aggregate and return an untouched public owner."""
    frames,_,start,_,slots = literal
    first = snapshot_transform(literal,shear=shear,keep_ascents=keep_ascents)
    _,all_steps,old_start,old_final,extra_slots = first
    schedule,receivers = identify(literal)
    n = PORTS
    zero=old_start[n]
    new_start = start[:]
    ends = {r:old_final[i+n] for i,r in enumerate(receivers)}
    for i,(_,_,f) in schedule.items():
        new_start[i] = f
    seen=set()
    passed=[]
    for op,i,*a in all_steps:
        if i in schedule and op=="MOVE" and a[0]==zero:
            continue
        if op=="INIT" and i in ends:
            passed.append((op,i,ends[i]))
            continue
        if op=="MOVE" and i in receivers and a[0]==zero:
            continue
        if op=="ADD":
            j,f = a
            if i in schedule and j==slots+i-2*n:
                if i in seen:
                    seen.remove(i)
                else:
                    seen.add(i)
                continue
            if j in schedule:
                if f==zero:
                    require(i in receivers,"unexpected precompensating dirty port")
                    continue
                require(j in seen,"observation outside packet snapshot lifetime")
                passed.append((op,i,slots+j-2*n,f))
                continue
        passed.append((op,i,*a))
    require(not seen, "unclosed clean-packet substitution")
    return frames,passed,new_start,old_final,extra_slots


def exact_replay(frames, steps, start, final, slots, *, shear=False):
    n = len(start)
    expected = [1 << i for i in range(n)]
    for i in range(PORTS):
        if shear:
            expected[PORTS+i] ^= 1 << i
        else:
            expected[i],expected[PORTS+i] = expected[PORTS+i],expected[i]
    live = start+[None]*(slots-n)
    rows = [1 << i for i in range(n)]+[None]*(slots-n)
    paid, ops = Counter(),Counter()
    count, peak = 0,0

    @cache
    def inside(a,b):
        return all(not dot(x,y) for x,y in product(frames[a][0],frames[b][1]))

    for op,i,*a in steps:
        ops[op] += 1
        if op=="INIT":
            require(i>=n and live[i] is None,"invalid clean owned field")
            live[i],rows[i] = a[0],0
            count += 1
            peak = max(peak,count)
        elif op=="CLEAR":
            require(i>=n and live[i]==a[0],"invalid owned retirement")
            live[i]=rows[i]=None
            count -= 1
        elif op=="ADD":
            j,f=a
            require(i!=j and live[i]==live[j]==f,"noncoframed ADD")
            rows[i]^=rows[j]
        elif op=="SWAP":
            j,=a
            require(i!=j and None not in (live[i],live[j]),"illegal role relabeling")
            live[i],live[j]=live[j],live[i]
            rows[i],rows[j]=rows[j],rows[i]
        elif op=="MOVE":
            x,y=a
            d=len(frames[y][0])-len(frames[x][0])
            require(live[i]==x and d and (inside(x,y) if d>0 else inside(y,x)),
                    "wrong or nonnested movement on literal replay")
            live[i]=y
            paid[abs(d)] += 1
        else:
            raise ValueError(op)
    require(count==0 and live[:n]==final and all(x is None for x in live[n:]),"wrong frames")
    require(rows[:n] == expected,"wrong dirty or data endpoint")
    for i,want in enumerate(expected):
        d=1<<i
        for op,j,*a in reversed(steps):
            if op=="ADD" and d>>j&1:
                d^=1<<a[0]
            elif op=="SWAP" and ((d>>j)^(d>>a[0]))&1:
                d^=(1<<j)|(1<<a[0])
            elif op=="INIT":
                d&=~(1<<j)
            elif op=="CLEAR":
                require(not(d>>j&1),"reverse accesses dead stock")
        require(d==want,"reverse endpoint and public dirty restore disagree")
    return paid,{"operations":dict(ops),"peak_owned":peak,"public":n,
                 "forward_and_reverse_coefficients_each":n*n}


def helper_tariff(frames, start, final):
    out=Counter()
    for a,b in zip(start[2*PORTS:],final[2*PORTS:],strict=True):
        d=len(frames[b][0])-len(frames[a][0])
        require(d>0 and all(not dot(x,y) for x,y in product(frames[a][0],frames[b][1])),
                "helper is not a positive-rank nested output")
        out[d]+=1
    return out


def run(emit_packet=None):
    deadline = monotonic()+65
    word = load_word()
    heads,*_ = fitting_calibration(word)
    packets,_,_ = tetrad_blocks(heads,True)
    feeders,residue,high,read = packet_syndromes(word,heads,packets)
    _,options = joint_choices(packets,feeders,deadline)
    joined,covered = select_packets(options,len(packets))
    old = shared_word(word,packets,joined,covered,feeders,residue,high,read,
                      retain_helpers=True,emit_packet=emit_packet)
    old_paid,old_check = exact_replay(*old)
    twist = snapshot_transform(old)
    new_paid,new_check = exact_replay(*twist)
    single = snapshot_transform(old,shear=True,keep_ascents=True)
    shear_paid,shear_check = exact_replay(*single,shear=True)
    lifted = clean_observation_transform(old)
    pure,pure_check = exact_replay(*lifted)
    lifted_single = clean_observation_transform(old,shear=True,keep_ascents=True)
    pure_shear,pure_shear_check = exact_replay(*lifted_single,shear=True)
    require(old_paid-new_paid=={7:PORTS} and not(new_paid-old_paid),"exact two-way recovery savings")
    require(old_paid-shear_paid=={8:PORTS} and not(shear_paid-old_paid),"exact shear alias savings")
    lifted_helpers = helper_tariff(lifted[0],lifted[2],lifted[3])
    require(all(pure[r] >= c for r,c in lifted_helpers.items()), "unfunded productive field")
    require(monotonic()<deadline,"bounded replay")
    output = len(packets)
    return {"status":"PASS_SHARED_PACKET_DIRT_SNAPSHOTS",
            "old_paid":dict(sorted(old_paid.items())),"old_replay":old_check,
            "two_way":{"paid":dict(sorted(new_paid.items())),"replay":new_check,
                       "price":compare(new_paid,old_paid,{8:2*PORTS+output})},
            "shear":{"paid":dict(sorted(shear_paid.items())),"replay":shear_check,
                     "price_vs_different_two_way_output":compare(shear_paid,old_paid,{7:2*PORTS,8:output})},
            "clean_packet_owner_shapes":{"productive_profile":dict(sorted(lifted_helpers.items())),
                      "two_way":{"paid":dict(sorted(pure.items())),"replay":pure_check,
                                 "price":compare(pure,pure,Counter({8:2*PORTS})+lifted_helpers)},
                      "shear":{"paid":dict(sorted(pure_shear.items())),"replay":pure_shear_check,
                               "price":compare(pure_shear,pure_shear,Counter({7:2*PORTS})+lifted_helpers)}}}


if __name__ == "__main__":
    print(json.dumps(run(),indent=2))
