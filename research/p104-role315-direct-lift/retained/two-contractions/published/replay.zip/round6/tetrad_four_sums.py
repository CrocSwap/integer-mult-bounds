# SPDX-License-Identifier: Apache-2.0
"""Build four coframed parity sums per tetrad, then send the required packets."""

from collections import Counter, defaultdict
from fractions import Fraction
import json
from pathlib import Path
import sys
from time import monotonic


HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE / "algebra"))
from joint_virtual_search import joint_choices
from packet_pair_transport import nullspace
from scan_bit_move_runs import basis
from syndrome_packets import (compare, fitting_calibration, load_word, packet_syndromes, replay,
                              require, select_packets, shared_word, tetrad_blocks)
from tetrad_rectangles import coordinate_cut, dot, members, support


def layout(heads, packets):
    by_field = defaultdict(list)
    for i,row in enumerate(heads):
        if support(row).bit_count()==4:
            by_field[support(row)].append(i)
    recipes, output, frames, chart_groups = {}, {}, {}, {}
    for h, sources in by_field.items():
        support_indices = list(members(h))
        rows = [0]*4
        for j in sources:
            a = heads[j]
            signs = tuple(int(a[b]*a[support_indices[0]] < 0) for b in support_indices[1:])
            rows[0] |= 1 << j
            for k,u in enumerate(signs,1):
                rows[k] |= u << j
        forms = {}
        for subset in range(16):
            value = 0
            for k in members(subset):
                value ^= rows[k]
            forms[value] = subset
        require(len(forms)==16,"live sign labels have full affine span in each tetrad")
        chart_groups[h] = forms
        frames[h] = coordinate_cut(h)
        recipes[h] = rows
        for i in sources:
            readers = [j for j in sources if j!=i and not dot(heads[i],heads[j])]
            v = sum(1<<j for j in readers)
            # Two distinct full-support lines are orthogonal precisely when
            # their three-bit relative signs differ in two places.
            v |= 1<<i
            require(v in forms,"same-tetrad orthogonality plus self is one affine parity row")
            output[i] = forms[v]
    by_packet = {}
    for q,(src,_,f) in enumerate(packets):
        h = support(heads[src[0]])
        if h in recipes:
            val=sum(1<<j for j in src)
            require(val in chart_groups[h],"sign-class packet is an affine form")
            by_packet[q] = h,chart_groups[h][val]
    require(len(by_packet)==182 and len(recipes)==14,"exactly thirteen packets per tetrad")
    return by_packet, recipes, frames, output, chart_groups


class TetradSums:
    def __init__(self, heads, packets, *, omitted=()):
        self.packet,self.forms,self.frames,self.output,self.chart_groups = layout(heads,packets)
        self.heads=heads
        self.omitted=omitted
        self.remaining=Counter(h for h,_ in self.packet.values())
        self.bank={}
        self.immutable={}
        self.gather = 0
        self.cache_peak = 0
        self.descents = Counter()

    def prepare(self,h,initial,steps,allocate,frames):
        if h not in self.bank:
            hub = max(j for j,value in frames.items() if value==self.frames[h])
            totals = [allocate() for _ in range(4)]
            for target in totals:
                steps.append(("INIT",target,hub))
            transfer = allocate()
            for j in members(self.forms[h][0]):
                steps.extend([("INIT",transfer,initial[j]),("ADD",transfer,j,initial[j]),
                              ("MOVE",transfer,initial[j],hub)])
                self.gather += 1
                for k,v in enumerate(self.forms[h]):
                    if v>>j&1:
                        steps.append(("ADD",totals[k],transfer,hub))
                if self.omitted:
                    self.immutable[j]=transfer
                    transfer=allocate()
                else:
                    steps.append(("CLEAR",transfer,hub))
            self.bank[h] = hub,totals
            self.cache_peak=max(self.cache_peak,len(self.bank))
        return self.bank[h]

    def __call__(self, q, role, destination, sources, initial, copy, add_frame, steps, allocate, frames):
        if q not in self.packet:
            for j in sources:
                copy(role,destination,j,initial[j])
            return
        h, recipe = self.packet[q]
        hub,totals=self.prepare(h,initial,steps,allocate,frames)
        if len(frames[destination][0])==4:
            # A chart ID is only a label for its rational subspace. The
            # compiler registered this packet's same literal coordinate frame.
            require(frames[destination]==frames[hub],"all-sign packet is exactly the hub coframe")
            require(destination==hub,"all-sign packet label selected as the hub at birth")
            for k in members(recipe):
                steps.append(("ADD",role,totals[k],destination))
        else:
            atom=allocate()
            steps.append(("INIT",atom,hub))
            for k in members(recipe):
                steps.append(("ADD",atom,totals[k],hub))
            steps.extend([("MOVE",atom,hub,destination),("ADD",role,atom,destination),
                          ("CLEAR",atom,destination)])
            self.descents[len(frames[hub][0])-len(frames[destination][0])] += 1
        self.remaining[h] -= 1
        if self.remaining[h]==0 and not self.omitted:
            for i in totals:
                steps.append(("CLEAR",i,hub))
            del self.bank[h]

    def emit_residues(self, correction, highs, residual, receivers, target_charts, initial, singles, steps, allocate, frames):
        listed=defaultdict(set)
        for i,j in singles:
            listed[j].add(i)
        scratch=allocate()
        for j, sources in sorted(listed.items()):
            h=support(self.heads[j])
            hub,totals=self.bank[h]
            den=target_charts[j]
            recipe=self.output[j]
            v=1<<j
            for k in members(recipe):
                v ^= self.forms[h][k]
            require(set(members(v))==sources,"same-tetrad target includes exactly the orthogonal neighbors")
            chart=max(frames)+1
            frame=basis(tuple(tuple(self.heads[i][k] for k in range(8)) for i in sorted(sources)))
            frames[chart]=frame,nullspace(frame)
            # Re-use a cold value of x_j in the tetrad. The first gathering
            # has already paid its climb, so this source is immutable there.
            single=self.immutable[j]
            steps.append(("INIT",scratch,hub))
            for k in members(recipe):
                steps.append(("ADD",scratch,totals[k],hub))
            steps.append(("ADD",scratch,single,hub))
            steps.extend([("MOVE",scratch,hub,chart),("MOVE",scratch,chart,den),
                          ("ADD",receivers[j],scratch,den),("CLEAR",scratch,den)])
        for rho,den,res,q in zip(correction,highs,residual,self.omitted,strict=True):
            h=support(q)
            hub,totals=self.bank[h]
            v=sum(1<<j for j in res)
            positions=list(members(h))
            parity = sum(q[k]*q[positions[0]]<0 for k in positions[1:])%2
            formula=14 ^ (1 if not parity else 0)
            require(self.chart_groups[h][v]==formula,"punctured syndrome has the affine same-tetrad parity row")
            require(all(not dot(self.heads[j],q) for j in res),"omitted row has no self term")
            chart=max(frames)+1
            all_same = coordinate_cut(h)[0]
            frame = basis(tuple(tuple(self.heads[i][k] for k in range(8)) for i in res))
            require(len(frame) in (2,3) and len(all_same)==4,"actual omitted syndrome fragment spans two or three directions")
            frames[chart]=frame,nullspace(frame)
            steps.append(("INIT",scratch,hub))
            for k in members(formula):
                steps.append(("ADD",scratch,totals[k],hub))
            steps.extend([("MOVE",scratch,hub,chart),("MOVE",scratch,chart,den),
                          ("ADD",rho,scratch,den),("CLEAR",scratch,den)])
        for j, owner in sorted(self.immutable.items()):
            steps.append(("CLEAR",owner,self.bank[support(self.heads[j])][0]))
        self.immutable.clear()
        for hub,totals in self.bank.values():
            for i in totals:
                steps.append(("CLEAR",i,hub))
        self.bank.clear()


def main():
    deadline=monotonic()+45
    word=load_word()
    heads,*_=fitting_calibration(word)
    packets,_,_=tetrad_blocks(heads,True)
    f,z,h,r = packet_syndromes(word,heads,packets)
    _,opts = joint_choices(packets,f,deadline)
    g,c = select_packets(opts,len(packets))
    args=(word,packets,g,c,f,z,h,r)
    old,_=replay(*shared_word(*args))
    cache=TetradSums(heads,packets)
    paid, checked=replay(*shared_word(*args,emit_packet=cache))
    omitted=[tuple(map(Fraction,word["frames"][str(f0)]["A"][0])) for f0 in h]
    groups=TetradSums(heads,packets,omitted=omitted)
    reduced, checked_residual=replay(*shared_word(*args,emit_packet=groups,defer_residues=True))
    require(not cache.bank and not any(cache.remaining.values()),"close all tetrad accumulators")
    require(not groups.bank and not any(groups.remaining.values()) and not groups.immutable,"close all residual caches")
    require(sum(paid.values())<sum(old.values()) and monotonic()<deadline,"strict literal collector improvement")
    print(json.dumps({"status":"PASS_TETRAD_FOUR_AFFINE_SUM_WORD","rank_four_gathers":cache.gather,
                      "descent_rank_profile":cache.descents,"parity_sums":4*len(cache.frames),
                      "all_sign_and_signed_packets":len(cache.packet),
                      "max_simultaneously_live_tetrad_banks":cache.cache_peak,
                      "new_paid":paid,"old_paid":old,"replay":checked,"prices":compare(paid,old,{8:222}),
                      "shared_live_and_omitted_residues":{"paid":reduced,"replay":checked_residual,
                          "prices":compare(reduced,paid,{8:222})}},
                     sort_keys=True,indent=2))


if __name__=="__main__":
    main()
