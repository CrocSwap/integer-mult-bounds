# Shared affine collections and receiver paths for the P111 BIT shear

The fixed source is the 111-head BIT word in #7001, with 659 arbitrary
public inputs, 437 independently returned helpers, and 2,871 paid
MOVEs. Its main line (L_i) is orthogonal to the rank-seven final
chart of the corresponding Y role. The new constructions use the same
main scalar shear and the same head geometry, with a separately
specified helper inventory. [Selected native and outer admission](https://github.com/CrocSwap/integer-mult-bounds/pull/7001)

## Four linear functionals on a signed tetrad

Fix a coordinate tetrad (S\subseteq\{1,\ldots,8\}), and normalize a
line's first nonzero sign to (+1). Its other three signs give a label
\(a\in\mathbf F_2^3\). If the independent payload of each live line
is (x_a), form the four same-frame XORs

\[
A_0=\bigoplus_a x_a,\qquad
A_j=\bigoplus_{a_j=1}x_a\quad (1\le j\le3).
\]

Any affine sign test has indicator (b+\sum_j c_j a_j), so its
payload is (bA_0+\sum_j c_j A_j\). This works on punctured support
sets. All 14 selected tetrads have rank four on their surviving labels.
Each of the six coordinate pairs yields two sign-class packets, and
one all-sign packet gives thirteen per tetrad. The previous compiler
collected a source repeatedly into its separate rank-three packet
frames. The actual new circuit gathers all 103 live tetrad inputs
once at rank four. The 168 proper sign-class outputs use an explicit
rank-one descent to their rank-three frames.

For a given live root on (S), two distinct normalized roots on
(S) are orthogonal exactly when they differ in two signs. Thus its
same-tetrad partial sum is one even/odd parity class with the self
term removed. For an omitted root the same parity class has no self
term. Each combined payload descends to the actual span of those
independent live orthogonal roots. That span lies in the target cap.
One later nested MOVE brings the payload to the cap. The literal
sender retains each pure (x_i) in the rank-four hub until the self
removal is finished. This extra lifetime is priced and measured.

The omitted-root reception reuses the same live and virtual target
packets. The nine exact dense corrections move from their actual
rank-seven hyperplanes to zero, so their 527 parity contacts at zero
can be computed before Y ascends. This pattern was already used in
the selected word. The new overlap lies in sharing the same affine
packet collection and subsequent merges across both types of target.

The first one- and two-tier packet alternatives paid 3,509 MOVEs
before the shared syndromes. The now jointly chosen syndrome route
paid 2,631, the two-line collector 2,590, the four-XOR collector 2,181,
and reusing those sums for same-tetrad entries as well paid 2,096 for
the two-way exchange. These are finite exact all-input variants.
Their invoices are distinguished from the original #7001's helper
inventory. No external producer or caller is substituted silently.

## Finance one source or receiver path once

In the forward shear, each X tier returns the independently arbitrary
original field at its original full chart. It can use its own paid
rank-three ascent from (L_i) to the tetrad and read all coframed
linear forms there before completing the rank-four ascent. This
changes the paid profile by (103(H_4-H_7)). There are 190 separately
arbitrary helper roles. Each starts at a pure observation's own
packet chart and makes exactly one final MOVE on its untouched
original value. Its productive rank is the rank of that MOVE, so
these disconnected helper credits cancel their own cost. Both
relations are tested on every arbitrary input of the complete
412-role word.

Suppose a clean payload is at (F\subset H_i) with rank (d) and
has one paid copy to the Y cap (H_i) of rank seven. Save an ordinary
copy at (F) while the nine corrections finish. After adding the
exact correction at zero, send Y through (F) and add the saved
payload there, then finish its rank-seven ascent. The signed gain is
(H_7-H_d) for one such intermediate frame. For a strict nested
chain (F_1\subset\cdots\subset F_k\subset H_i), carrying one
already-funded payload from each (F_j) gives

\[
H_7+\sum_{j=1}^k H_{7-d_j}
-\left(H_{d_1}+\sum_{j=2}^k H_{d_j-d_{j-1}}+H_{7-d_k}\right).
\]

The longest-path selector uses exact rational inclusion and directed
tariff bounds whose order does not depend on floating comparison.
It chooses two intermediate frames for each of 111 public Y roles.
The common shapes are 103 of ranks (2,5), six of ranks (2,4), and
two of ranks (1,4). All 222 saved payloads remain live until their
use, increasing peak owned fields from 183 to 405 in this version.
The exact replay pays 2,286 MOVEs throughout. The two-step chains
lower the recursive moment by 777.52296 at .005 and 744.74419 at
.0227, after all split ranks are charged. The 412 independent
originals give 169,744 coefficients in each exact direction.

The best shear pays 324 H1 + 1160 H2 + 238 H3 + 209 H4 + 326 H5 +
4 H6 + 25 H7. Its exact main and helper credits total 14 H4 + 168
H5 + 230 H7, leaving a gap greater than 3507.02264 at .005 and
3471.74206 at .0227. The hypothetical substitution of all 36
natives in the selected BIT caller, while granting the unchanged
outer body labels and compiler, has raw moments (-123272.11297)
and (-124617.64359) at those values. That comparison uses the
original unchanged outer paid connectors and main production,
and each word's actual independent helper inventory.

## Limits of independent helper promotion

The obvious extra source of credit would be ownership promotion
on existing internal packet copies. Independently granting the
full endpoint rank once for *every* one-MOVE owned ascent, leaving
its cost in place and waiving all recoding/cleanup, still leaves
847.35837 at .005 and 855.19537 at .0227 in the version with
recipient chains. This excludes that inventory even when the
restoration theorem is waived. Physical sharing of several
different lifetimes or changing the transport mechanism is
outside the calculation.

For the lower-rank pair-collector control, the exact destination
space for 335 pair-to-packet ascents excludes the original pair
sum once its carried row is removed. The witness in each case
flips a single input even when time and other lifetimes are ignored
and every other arrival in the same rational chart is granted.
In the actual selected #7001 word all 2,871 incoming rows are new
in their own prior arrival spaces, and each same ordered-chart pair
has independent output sensitivity, with all public helpers
retained. The 109 original two-leg Y endpoints already do one
important version of the receiver-sharing trick. Their separate
coframed donors are pure independent inputs, 102 source X roles
and seven helpers, with no same-role paid pure donor route to
that intermediate chart at the earlier clock.

## A lower benchmark from independent rank-one descents

For each port, copy its original X from (L_i) to an owned field and
move the copy from (L_i) to zero. Add this exact donor to Y at zero,
then place Y in its target hyperplane and advance X to full. Both
public inputs are arbitrary. A single owned field is reused across
all 111 ports. This diagonal relay pays exactly (111H_1+222H_7)
with honest main credit (222H_7), for a deficit of **111** and no
additional productive helper. The two-way variant also pays 333
MOVEs, of ranks (111H_1+111H_7+111H_8).
Both pass all 49,284 coefficients in each direction.

This baseline isolates a tradeoff. Replacing 111 singleton descents
by nine rank-seven descents leaves only (111H_1-9H_7) for their
complete extra gathering, sending and restoration beyond the two
prescribed main ascents and any proved independent helper credits.
It is **48.60998** at .005 and **50.72227** at .0227. The expensive
affine network is valuable as an exact shared communication
construction, while the direct diagonal relay is far cheaper on the
current full price. The singleton route has always been allowed by
the nested MOVE model. Its role here is a faithful cost control.

Inserting that native profile into the selected 36-native caller and
retaining its exact paid connectors and main targets gives arithmetic
margin **−1015.29770** at .005 and **−3630.92916** at .0227. At .005 a
candidate on the same contract needs at least **28.20271** additional
net moment per native beyond the diagonal baseline. At .0227 it needs
at least **100.85914**. The augmentation must preserve each arbitrary
independent output. The diagonal control and the selected caller
substitution establish no new outer supplier.

## Physical checks and remaining cost

The best shear has 715 used frame labels. Each label is an exact
orthogonal direct sum of a rational frame and its supplied
complement. The verifier checks all 1,999 ordered MOVE templates
by exact difference of projectors, their signed ranks and
idempotence, and all 111 physical head/complement pairs.
Representative signed ranks each lower to one grouped weighted
child in two explicit odd finite rings, checking 352 address
columns. The maximum formal BIT input row support is 64.
This checks address rank and the payload map. It leaves a complete
all-width cover/label tape, stock bounds, word generation and
outer analytic recovery as separate obligations. The raw cost
already fails the stated test.

The next constructive question is whether overlapping recipient
paths can share lower-frame snapshots and replace enough of the
rank-two copy inventory by real independently returning traffic.
Changing the seed/output geometry or allowing an additional
address sector would change both scope and recurring price.
