# SPDX-License-Identifier: Apache-2.0
"""Exact input spans and public responses of the selected BIT MOVEs."""

from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
CORE = run_path(str(HERE.parent / "round5/algebra/tetrad_rectangles.py"))
NEED, LOAD = (CORE[k] for k in ("require","load_word"))
X = 111


def extend(table, row, insert=True):
    while row:
        pivot = row.bit_length()
        if pivot not in table:
            if insert:
                table[pivot] = row
            break
        row ^= table[pivot]
    return row


def endpoint(n):
    return [((1<<i)^(1<<(i-X))) if X<=i<2*X else 1<<i for i in range(n)]


def replay(word, deadline):
    n,extra = word["public"],word["owned_fields"]
    p = word["program"]
    frames = word["start"]+[None]*extra
    rhs = [1<<i for i in range(n)]+[None]*extra
    bank = defaultdict(set)
    for i,f in enumerate(frames[:n]):
        bank[f].add(i)
    new, old_by_chart = {}, defaultdict(dict)
    live_ready, historical_ready = [], []
    ranks = Counter()
    dimensions = {int(f):meta["dim"] for f,meta in word["frames"].items()}
    for t,(op,r,*a) in enumerate(p):
        if t%2048==0:
            NEED(monotonic()<deadline,"selected coframe stock replay")
        f,v = frames[r],rhs[r]
        if op=="MOVE":
            src,dst = a
            NEED(src==f and v is not None,"literal selected MOVE source")
            rank = abs(dimensions[src]-dimensions[dst])
            new[t]=v
            ranks[rank]+=1
            now = {}
            for s in sorted(bank[dst]):
                extend(now,rhs[s])
            if not extend(now,v,False):
                live_ready.append(t)
            if not extend(old_by_chart[dst],v):
                historical_ready.append(t)
            bank[src].remove(r)
            bank[dst].add(r)
            frames[r]=dst
        elif op=="ADD":
            s,o = a
            NEED(r!=s and f==frames[s]==o,"same-frame selected gate")
            rhs[r] ^= rhs[s]
        elif op=="SWAP":
            s, = a
            g=frames[s]
            NEED(f is not None and g is not None,"selected SWAP on live roles")
            if f!=g:
                bank[f].remove(r)
                bank[g].remove(s)
                bank[f].add(s)
                bank[g].add(r)
            rhs[r],rhs[s]=rhs[s],rhs[r]
            frames[r],frames[s]=g,f
        elif op=="INIT":
            NEED(r>=n and f is None,"zero owned input")
            frames[r],rhs[r]=a[0],0
            bank[a[0]].add(r)
        elif op=="CLEAR":
            NEED(r>=n and f==a[0],"selected owner closes at exact frame")
            frames[r],rhs[r]=None,None
            bank[f].remove(r)
        else:
            raise ValueError(op)
    NEED(frames==word["final"]+[None]*extra and all(x is None for x in rhs[n:]),"all selected boundary frames")
    NEED(rhs[:n]==endpoint(n),"all independent selected input checks")
    return new, old_by_chart, live_ready, historical_ready, ranks


def sensitivities(word, deadline):
    n=word["public"]
    out=[1<<i for i in range(n)]+[0]*word["owned_fields"]
    responses={}
    for t in range(len(word["program"])-1,-1,-1):
        if t%2048==0:
            NEED(monotonic()<deadline,"selected reverse coefficient replay")
        op,r,*a=word["program"][t]
        if op=="MOVE":
            responses[t]=out[r]
        elif op=="ADD":
            out[a[0]] ^= out[r]
        elif op=="SWAP":
            s, = a
            out[s],out[r]=out[r],out[s]
        elif op in {"CLEAR","INIT"}:
            out[r]=0
    want=[((1<<i)^(1<<(i+X))) if i<X else 1<<i for i in range(n)]
    NEED(out==want+[0]*word["owned_fields"],"independent reverse basis includes all dirty helpers")
    return responses


def pair_screen(prefix, suffix, word, deadline):
    """Rank of the exact destination responses and equal dependency pairs."""
    dim={int(f):m["dim"] for f,m in word["frames"].items()}
    colocated = defaultdict(list)
    by_output = defaultdict(list)
    equal_input_response = []
    colocated_equal_response = []
    for t in prefix:
        _,_,f,g=word["program"][t]
        colocated[f,g].append(t)
        by_output[suffix[t]].append(t)
    eq = [p for p in by_output.values() if len(p)>1]
    for events in eq:
        for t,u in combinations(events,2):
            if prefix[t]==prefix[u]:
                equal_input_response.append((t,u))
            if word["program"][t][2:]==word["program"][u][2:]:
                colocated_equal_response.append((t,u))
    deficient = []
    for (a,b), group in colocated.items():
        r = {}
        for i in group:
            extend(r,suffix[i])
        if len(r)<len(group):
            deficient.append([a,b,dim[a],dim[b],group,len(r)])
    NEED(monotonic()<deadline,"bounded selected contact screen")
    return {"distinct_ordered_chart_pairs":len(colocated),
            "multisize_source_destination_groups":sum(len(v)>1 for v in colocated.values()),
            "dependent_suffix_groups":deficient,
            "equal_projected_responses":len(eq),"equal_response_pairs":sum(len(g)*(len(g)-1)//2 for g in eq),
            "equal_input_and_equal_response_pairs":equal_input_response,
            "coframed_equal_response_pairs":colocated_equal_response}


def main():
    deadline=monotonic()+25
    w=LOAD()
    fresh,historical,live,history,rank = replay(w,deadline)
    suffix = sensitivities(w,deadline)
    NEED(len(fresh)==len(suffix)==2871,"literal selected word and two-sided receipt")
    d = {int(f):x["dim"] for f,x in w["frames"].items()}
    dirty = Counter(abs(d[b]-d[a]) for a,b in zip(w["start"][222:],w["final"][222:],strict=True))
    demand_hist=Counter((d[f],len(e)) for f,e in historical.items())
    large=max(historical,key=lambda f:len(historical[f]))
    out={"status":"PASS_SELECTED_BIT_COFRAME_DEPENDENCY_CENSUS","all_public_coefficients_each_direction":w["public"]**2,
         "selected_bill":{"paid_calls":dict(sorted(rank.items())),"helper_returns":dict(sorted(dirty.items()))},
         "direct_current_stock_recovered_moves":live,"ever_arrived_target_stock_recovered_moves":history,
         "coframe_ingress_rank_histogram":{f"{q}:{r}":c for (q,r),c in sorted(demand_hist.items())},
         "largest_ingress_bank":{"chart":large,"exact_rank":len(historical[large])},
         "null_inputs":sum(v==0 for v in fresh.values()),"null_public_responses":sum(v==0 for v in suffix.values()),
         "pair_screen":pair_screen(fresh,suffix,w,deadline),
         "scope":"frozen incoming scalar rows and original all-column output sensitivity, including arbitrary independent public helper stock"}
    print(json.dumps(out,sort_keys=True,indent=2))


if __name__=="__main__":
    main()
