# SPDX-License-Identifier: Apache-2.0
"""Test independently dirty productive credits on the new BIT transport."""

from collections import Counter
import json
from pathlib import Path
import sys
from time import monotonic


HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE / "algebra")]
from recipient_ascents import make_shear, schedule
from snapshot_owner_shear import exact_replay, helper_tariff
from syndrome_packets import compare, require


def word_stock(literal, deadline):
    frames,program,start,final,slots=literal
    n=len(start)
    shape={k:len(z[0]) for k,z in frames.items()}
    alive=start+[None]*(slots-n)
    rows=[1<<i for i in range(n)]+[0]*(slots-n)
    life={}
    moments=[]
    for at,(op,r,*args) in enumerate(program):
        if at%2048==0:
            require(monotonic()<deadline,"bounded carrier source and input movement replay")
        if op=="INIT":
            alive[r]=args[0]
            rows[r]=0
            life[r]=[at,args[0],[]]
        elif op=="MOVE":
            a,b=args
            if r>=n:
                life[r][2].append((at,a,b,rows[r]))
            alive[r]=b
        elif op=="ADD":
            rows[r]^=rows[args[0]]
        elif op=="CLEAR":
            birth,first,moves=life.pop(r)
            if len(moves)==1 and moves[0][1]==first and shape[args[0]]>shape[first]:
                moments.append((birth,at,r,*moves[0]))
            alive[r]=None
            rows[r]=0
        else:
            raise ValueError(op)
    require(not life and alive==final+[None]*(slots-n),"all literal ownership has closed")
    return moments


def free_credit_upper(literal,deadline):
    """Price each existing increasing one-MOVE lifetime as an optimistic credit."""
    frames,_,start,final,_=literal
    base,check=exact_replay(*literal,shear=True)
    moments=word_stock(literal,deadline)
    hist=Counter((len(frames[a][0]),len(frames[b][0])) for _,_,_,_,a,b,_ in moments)
    ph=Counter()
    for (a,b),c in hist.items():
        ph[b-a]+=c
    fund=helper_tariff(frames,start,final)+Counter({7:222})
    owned_zero=sum(c for (a,b),c in hist.items() if a==0)
    return {"eligible_lifetime_shapes":{f"{a}:{b}":c for (a,b),c in sorted(hist.items())},
            "owned_zero_start_lifetimes":owned_zero,"paid":dict(sorted(base.items())),
            "optimistic_independent_helper_profile":dict(sorted(ph.items())),
            "restored_actual_profile":dict(sorted(fund.items())),
            "existing_invoice":compare(base,base,fund),
            "all_lifetimes_free_restore_relaxation":compare(base,base,fund+ph),
            "endpoint":check}


def main():
    deadline=monotonic()+65
    original=make_shear(deadline)
    best,_,_=schedule(original,deadline,chain=True)
    report={"status":"PASS_PRODUCTIVE_CARRIERS_RANK_CREDIT_SCREEN",
            "unshared_recipient_path":free_credit_upper(original,deadline),
            "shared_recipient_chain":free_credit_upper(best,deadline),
            "scope":"independently seeded new owner on existing paid increasing one-MOVE lifetime, with explicitly optimistic free recoding and terminal restoration"}
    require(monotonic()<deadline,"bounded exact carrier audit")
    print(json.dumps(report,sort_keys=True,indent=2))


if __name__=="__main__":
    main()
