"""Use earlier/replayed stock at the complemented #7546 chart 1053."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from time import monotonic

HERE = Path(__file__).resolve().parent
PACKET = run_path(str(HERE / "owned_packet_coalescence.py"))
TAIL, ROWS, NEED = (PACKET[k] for k in ("TAIL", "ROWS", "NEED"))
EXPECTED_ADJOINT = "74722f7f052f8b61cb623ccc5640ba6eb8149208e5c3e702e5140a0402bd1a3f"
H, Y, CHART = 993, 957, 1053
LOAD, ARRIVE_H, ARRIVE_Y = 18_496, 18_498, 29_407


def root_word(path):
    compiler, raw = TAIL["ADJ"]["PHYSICAL"]["load_pins"](path)
    word, _, _ = TAIL["ADJ"]["build"](raw)
    digest = TAIL["ADJ"]["digest"](word)
    NEED(digest == EXPECTED_ADJOINT, "exact previously replayed complemented #7546 word")
    return compiler, word


def supported(word, deadline):
    """Read normalized rows at all actual H observations and stock arrivals."""
    p = word["program"]
    NEED(p[LOAD] == ["ADD", H, Y, "2", 3] and p[LOAD+1] == ["ADD", H, 907, "-2", 3],
         "original two adjoint precodes")
    NEED(p[ARRIVE_H] == ["MOVE", H, 3, CHART, False] and p[ARRIVE_Y] == ["MOVE", Y, 3, CHART, False],
         "matched paid ingress frame")
    h_events = [i for i,(op,r,*d) in enumerate(p) if i>ARRIVE_H and
                (r == H or (op in ("ADD","COPY") and d[0] == H))]
    chart_events = [i for i,e in enumerate(p) if e[0]=="MOVE" and e[3]==CHART]
    cuts = {LOAD, ARRIVE_H, ARRIVE_H+1, ARRIVE_Y, ARRIVE_Y+1, *chart_events, *h_events[:20]}
    stock, paid, _ = TAIL["record"](word, cuts, deadline)
    premature = [i for i in h_events if i < ARRIVE_Y]
    before = stock[LOAD][1][Y]
    after = stock[ARRIVE_Y][1][Y]
    NEED(before[1], "precode uses a nonzero form on the current Type A mate")
    NEED(before != after and not premature, "chronology allows a bridge but the mate's literal payload changes")
    repair = {}
    for i in sorted(cuts):
        if i <= ARRIVE_H:
            continue
        friends, terms = stock[i]
        basis = {}
        for id, (f, value) in enumerate(zip(friends, terms, strict=True)):
            if f == CHART and id != H and value[1]:
                d, coeff = value
                TAIL["solve_echelon"](basis, {j:Q(x,d) for j,x in coeff.items()}, {id:Q(1)})
        d, coeff = before
        desired = {j:Q(x,d) for j,x in coeff.items()}
        missing, combination = TAIL["solve_echelon"](basis, desired, {}, save=False)
        if not missing:
            repair[i] = {r:str(-c) for r,c in sorted(combination.items())}
    post = stock[ARRIVE_Y+1][1][Y]
    NEED(post == after and not repair, "paid mate alone and sampled coframed stock both miss the old precode")
    NEED(stock[ARRIVE_Y+1][0][Y] == CHART, "same chart and actual post-arrival payload retained")
    initial, pure = ROWS["show"](before), ROWS["show"](after)
    return {"helper_first_trace": [[i,p[i]] for i in h_events[:20]],
            "other_coframed_paid_arrivals": [[i,p[i][1],len(word["frames"][p[i][2]])] for i in chart_events],
            "first_later_original_957_form_recovery": min(repair) if repair else None,
            "exact_later_coframed_recovery": repair, "already_observed_before_mate": premature,
            "old_957_precode": initial, "mate_early_carrier_row": pure,
            "old_and_new_dirty_forms_differ": before != after,
            "mate_early_carrier_row_sha256": sha256(json.dumps(pure, sort_keys=True).encode()).hexdigest(),
            "unmodified_paid": paid}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    start = monotonic()
    _, word = root_word(args.word)
    out = {"status":"PASS_ADJOINT_1053_PREARRIVAL", "adjoint_sha256":EXPECTED_ADJOINT,
           **supported(word,start+15)}
    args.output.write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
    print(out["status"],f"in {monotonic()-start:.2f}s", flush=True)


if __name__ == "__main__":
    main()
