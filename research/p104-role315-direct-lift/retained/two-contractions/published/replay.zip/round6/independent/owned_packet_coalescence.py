"""Screen and reconstruct one #7546 cached-copy transport using exact coframe stock."""

import argparse
from collections import Counter
from fractions import Fraction as Q
import json
from math import lcm
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
TAIL = run_path(str(HERE.parents[1] / "round5" / "paired_tail_synthesis.py"))
ROWS, NEED = TAIL["ROWS"], TAIL["NEED"]


def life(log, n):
    spans, held = [], {}
    for i, (op, r, *d) in enumerate(log):
        if op == "INIT":
            NEED(r >= n and r not in held, "owned begin")
            rec = {"reg": r, "birth": i, "frame": d[0], "moves": [], "writes": [], "reads": []}
            held[r] = rec
        elif op == "CLEAR":
            rec = held.pop(r)
            rec.update(clear=i, final=d[0])
            spans.append(rec)
        elif op == "MOVE":
            if r >= n:
                held[r]["moves"].append((i, *d[:2]))
        else:
            if r >= n:
                held[r]["writes"].append(i)
            if op in ("ADD", "COPY") and d[0] >= n:
                held[d[0]]["reads"].append(i)
    NEED(not held, "all owned retirements")
    return sorted(spans, key=lambda k: k["birth"])


def projective(row):
    return ROWS["projective_key"](row, ())


def first_scalar(row):
    d, x = row
    return Q(x[min(x)], d)


def isolate(states, names, register):
    """Solve the complete exact local stock span for each original read."""
    bases = {}
    for at in names:
        frames, rows = states[at]
        f, row = frames[register], rows[register]
        goal = projective(row)
        if not goal:
            bases[at] = {}
            continue
        basis = {}
        for r, z in enumerate(frames):
            if r == register or z != f or not rows[r][1]:
                continue
            if projective(rows[r]) == goal:
                basis = None
                bases[at] = {r: str(first_scalar(row) / first_scalar(rows[r]))}
                break
            d, x = rows[r]
            vector = {i: Q(b, d) for i, b in x.items()}
            TAIL["solve_echelon"](basis, vector, {r:Q(1)})
        if basis is None:
            continue
        d, x = row
        remainder, coefficients = TAIL["solve_echelon"](basis, {i:Q(b, d) for i, b in x.items()}, {}, save=False)
        bases[at] = None if remainder else {r: str(-v) for r, v in coefficients.items()}
    return bases


def standalone(word, deadline):
    n, log = word["public"], word["program"]
    spans = life(log, n)
    eligible = [rec for rec in spans if rec["moves"] and rec["reads"]]
    reads = {i for rec in eligible for i in rec["reads"]}
    cuts, _, _ = TAIL["record"](word, reads, deadline)
    _, _, before, _, _, _, _ = ROWS["capture"](word, deadline)
    info = []
    candidates = []
    for rec in eligible:
        k = rec["reg"]
        reuse = isolate(cuts, rec["reads"], k)
        source_rows = [projective(before[i]) for i, _, _ in rec["moves"]]
        info.append({**rec, "each_move_support": [len(r) for r in source_rows], "equivalent_reads": reuse})
        if all(x is not None for x in reuse.values()):
            candidates.append((rec, reuse))
    return info, candidates


def funded_at_top(word, inventory, deadline):
    """Move lower repairs to their recipients' funded final coframe."""
    n, log = word["public"], word["program"]
    top_ingress, suffix, _ = TAIL["TOP"]["full_program"](word)
    _, inverse, before, _, _, _, _ = ROWS["capture"](word, deadline)
    tested = []
    for rec in inventory:
        mv = rec["moves"]
        if len(mv) != 1:
            continue
        event, a, b = mv[0]
        late = [i for i in rec["reads"] if i > event]
        if len(late) != 1:
            continue
        contact = late[0]
        _, receiver, _k, coeff, old_chart = log[contact]
        if receiver >= n or receiver not in top_ingress or old_chart != b:
            continue
        t, _, _ = top_ingress[receiver]
        if t <= contact or not all(rec["equivalent_reads"][i] is not None for i in rec["reads"] if i < event):
            continue
        other_contacts = [i for i, e in enumerate(log[contact+1:t], start=contact+1)
                          if receiver==e[1] or e[0] in ("ADD","COPY") and receiver==e[2]]
        if other_contacts:
            continue
        d, values = before[event]
        target = {i: Q(v, d) * Q(coeff) for i, v in values.items()}
        # Let T be the true complete scalar endpoint, A the independent top
        # ingress rows and S the exact full suffix, so that T_top=S A.
        # v T^{-1} determines immediately if v lies in span(A), and if yes
        # the unique representation on A is (v T^{-1})_top S.
        outside = Counter()
        for i, scale in target.items():
            den, row = inverse[i]
            for j, x in row.items():
                outside[j] += scale*Q(x,den)
        extras = {j: x for j, x in outside.items() if x and j not in top_ingress}
        parameters = {"owned": rec["reg"], "paid": event, "contact": contact, "receiver": receiver,
                      "receiver_old_top_ingress": t}
        if extras:
            tested.append({**parameters, "non_top_endpoint_terms": {j: str(x) for j,x in extras.items()}})
            continue
        recipe = Counter()
        for r, x in outside.items():
            if x:
                for a, z in suffix[r].items():
                    recipe[a] += x*Q(z,TAIL["TOP"]["GRID"])
        recipe = {r: x for r,x in recipe.items() if x}
        checked = Counter()
        for r, x in recipe.items():
            den, values = before[top_ingress[r][0]]
            for j, v in values.items():
                checked[j] += x*Q(v,den)
        NEED({j:v for j,v in checked.items() if v} == target, "exact inverse endpoint top-ingress coordinate change")
        tested.append({**parameters,
                       "receiver_basis_coefficient": str(recipe.get(receiver, 0)),
                       "earliest_sufficient_top_ingress": max(top_ingress[r][0] for r in recipe) if recipe else -1,
                       "recovered_from_top_ingress_rows": {r: str(c) for r,c in recipe.items()}})
    return tested


def synthesize(word, rec, reuse):
    log = word["program"]
    omit = {rec["birth"], rec["clear"], *rec["writes"], *(i for i, _, _ in rec["moves"])}
    replacement = {}
    for at, peers in sorted(reuse.items()):
        old = log[at]
        if not peers:
            omit.add(at)
            continue
        dst = old[1]
        coeff = Q(old[3])
        fragment = []
        self_term = Q(peers.get(dst, "0"))
        if self_term:
            NEED(old[0] == "ADD", "owned COPY destination starts zero")
            fragment.append(["SCALE", dst, str(1 + self_term*coeff), old[4]])
        fragment.extend(["ADD", dst, r, str(Q(c)*coeff), old[4]] for r, c in sorted(peers.items()) if r != dst)
        replacement[at] = fragment
    clean = [out for i, e in enumerate(log) if i not in omit for out in replacement.get(i, [e])]
    return {**word, "program": clean}, replacement


def full_owned_bypass(word, candidates):
    """Move repaired payloads directly to the full chart on their own fields."""
    full = TAIL["FULL"]
    program = word["program"]
    lookup = {r["reg"]:r for r in life(program, word["public"])}
    modifications = {}
    paid_delta = Counter()
    for row in candidates:
        own = row["owned"]
        rec = lookup[own]
        paid, read = row["paid"], row["contact"]
        at_top = row["receiver_old_top_ingress"]
        old_move = program[paid]
        NEED(old_move[:2] == ["MOVE", own] and old_move[-1], "one paid owned advance")
        NEED(rec["clear"] > read and rec["writes"][-1] < paid, "no writes after pivot drive")
        old_contact = program[read]
        receiver, source, coeff, old_chart = old_contact[1:]
        NEED(source == own and receiver == row["receiver"] and old_chart == old_move[3], "one exact lower contact")
        NEED(program[at_top] == ["MOVE", receiver, old_chart, full, False], "retained existing receiver advance")
        dim = [len(f) for f in word["frames"]]
        paid_delta[dim[old_move[3]]-dim[old_move[2]]] -= 1
        paid_delta[dim[full]-dim[old_move[2]]] += 1
        modifications[paid] = [["MOVE", own, old_move[2], full, True]]
        modifications[read] = []
        modifications[rec["clear"]] = []
        modifications[at_top] = [program[at_top], ["ADD", receiver, own, coeff, full], ["CLEAR", own, full]]
    out = [e for index, event in enumerate(program) for e in modifications.get(index, [event])]
    return {**word, "schema": "p104-delayed-owned-repair/1", "program":out}, dict(paid_delta)


def native_grid(word, deadline):
    """Exact rational normalized-grid and mass witnesses including ADD products."""
    n, o = word["public"], word["owned_fields"]
    rows = [ROWS["unit"](i) for i in range(n)] + [ROWS["NONE"]]*o
    odd_lcm = 1
    height = 0
    mass = Q(1)
    witness = None

    def observe(row, event, r, stage):
        nonlocal odd_lcm, height, mass, witness
        denominator, values = row
        order = (denominator & -denominator).bit_length()-1
        odd_lcm = lcm(odd_lcm,denominator>>order)
        height = max(height, order)
        size = sum(abs(x) for x in values.values())
        if size*mass.denominator > denominator*mass.numerator:
            mass = Q(size, denominator)
            witness = [event, r, stage]

    for i,(op, r, *args) in enumerate(word["program"]):
        if i % 1024 == 0:
            NEED(monotonic() < deadline, "normalized grid timebox")
        if op in ("INIT","CLEAR"):
            rows[r] = ROWS["NONE"]
        elif op == "SCALE":
            rows[r] = ROWS["scale"](rows[r], ROWS["ratio"](args[0]))
            observe(rows[r], i, r, "stored")
        elif op in ("ADD","COPY"):
            src, c, _ = args
            coeff = ROWS["ratio"](c)
            p = ROWS["scale"](rows[src], coeff)
            observe(p, i, r, "product")
            rows[r] = ROWS["increment"](rows[r], rows[src], coeff)
            observe(rows[r], i, r, "stored")
    return {"odd_denominator_lcm":odd_lcm, "dyadic_height":height, "row_l1_mass":str(mass), "mass_witness":witness}


def verify_bypass(compiler, word, altered, candidates, delta, deadline):
    """Bind the changed rank-five owned moves to exact physical and scalar checks."""
    _, paid, counts = TAIL["record"](altered, set(), deadline)
    old_paid = Counter(abs(len(word["frames"][b])-len(word["frames"][a]))
                       for op, _r, *data in word["program"] if op == "MOVE" for a,b in [data[:2]])
    old_paid.update(delta)
    NEED(old_paid == paid, "exact recursive debit with one moved owned repair")
    full = TAIL["FULL"]
    physics = []
    for rec in candidates:
        _, _, a, b, _ = word["program"][rec["paid"]]
        ops = [compiler.canonical_frame(9, word["frames"][i]) for i in (a,b,full)]
        start, old_join, stop = ops
        into = start.adjoint().then(old_join)
        out = old_join.adjoint().then(stop)
        direct = start.adjoint().then(stop)
        compiler_eq = TAIL["ADJ"]["PHYSICAL"]["equal_signed_clifford"]
        compiler_eq(into.then(out), direct, True)
        recipe, signed = compiler.lower_child(direct)
        NEED(recipe["rank"] == 5, "direct signed paid rank on original real payload")
        compiler_eq(signed.adjoint(), direct.adjoint(), True)
        physics.append([a,b,full])
    wrong = TAIL["ROWS"]["target"](word)[1]
    mutant = next(i for i,e in enumerate(altered["program"]) if e[:3] == ["ADD", candidates[0]["receiver"], candidates[0]["owned"]])
    bad = {**altered, "program": altered["program"][:mutant]+altered["program"][mutant+1:]}
    rejected = False
    try:
        TAIL["record"](bad, set(), deadline, requirement=wrong)
    except ValueError as error:
        rejected = str(error) == "all independent dirty inputs and final frames"
    NEED(rejected, "dropping late decoder is rejected by dirty endpoint")
    engine = TAIL["TOP"]["SOURCE"]["price_engine"]()
    prices = {k:{"float":engine.value(engine.moment(delta, Q(k))), "exact":engine.show(engine.moment(delta, Q(k)))}
              for k in (".003648411294790", ".005", ".0227")}
    return {"full_replay_roles":word["public"], "exact_coefficients":word["public"]**2,
            "native_paid_counts":dict(paid), "paid_delta":delta, "ordinary_counts":dict(counts),
            "paid_recursive_surcharge_per_native":prices, "exact_phase_moves":physics,
            "normalized_grid_original":native_grid(word,deadline),
            "normalized_grid_bypass":native_grid(altered,deadline),
            "missing_repair_mutant_rejected":rejected}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("word", type=Path)
    p.add_argument("output", type=Path)
    p.add_argument("--emit", type=Path)
    a = p.parse_args()
    start = monotonic()
    deadline = start + 30
    compiler, word = TAIL["ADJ"]["PHYSICAL"]["load_pins"](a.word)
    data, physical = standalone(word, deadline)
    forward_replacements = funded_at_top(word, data, deadline)
    NEED({r["owned"] for r in forward_replacements} == {1537, 1538, 1539}, "the three original rank-four repair paths")
    alt, delta = full_owned_bypass(word, forward_replacements)
    bypass = verify_bypass(compiler, word, alt, forward_replacements, delta, deadline)
    tested = []
    for rec, reuse in physical:
        candidate, changes = synthesize(word, rec, reuse)
        _, paid, _ = TAIL["record"](candidate, set(), deadline)
        tested.append({"birth": rec["birth"], "reg": rec["reg"], "changed_reads": changes, "paid": paid})
    NEED(monotonic() < deadline, "timebox")
    out = {"status": "PASS_OWNED_PACKET_COALESCENCE_SCREEN", "independent_word_sha256": ROWS["WORD_SHA"],
           "owned_cached_packets": len(data), "candidates": tested,
           "rank_preserving_forward_rebuilds": forward_replacements,
           "literal_paid_full_owned_bypass":bypass,"source": data}
    if a.emit:
        a.emit.write_text(json.dumps(alt, separators=(",", ":")) + "\n", encoding="utf-8")
    a.output.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(out["status"],f"{len(tested)} direct replacements, {monotonic()-start:.2f}s")


if __name__ == "__main__":
    main()
