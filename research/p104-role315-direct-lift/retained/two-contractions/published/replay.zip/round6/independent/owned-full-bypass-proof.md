# Rerouting three owned #7546 corrections to the full chart

The exact #7546 word has 38 owned lifetimes with at least one paid MOVE and one scalar consumer. There are 113 consumer contacts. For each contact, the verifier solves the changing coframe stock over the rationals on the 1,501 independently dirty inputs. No whole lifetime can replace all of its consumer rows by current coframe stock. This local screen motivates changing the physical receiver chart and chronology.

## A concrete different chart and schedule

Three owned fields are an exact fit for delayed recovery. Their last lower repairs and existing public receivers are:

| Owned field | Original lower MOVE | Source → old receiver frame | Receiver | Existing receiver ascent |
| ---: | ---: | ---: | ---: | ---: |
| 1537 | 41503 | 1090 → 477 | 1004 | 46143 |
| 1539 | 39563 | 243 → 517 | 781 | 46163 |
| 1538 | 39591 | 240 → 518 | 1020 | 46196 |

The three source frames each have rank four. Their old receiver frames have rank eight and sit below full chart 127 of rank nine. In each pair, the owned field has no further use after its lower repair, and the public receiver has no intervening contact before its funded ascent to chart 127. Move each owned field directly from its old rank-four chart to chart 127. Keep its payload until the public receiver enters chart 127. Apply the retimed ADD and CLEAR there immediately. This preserves the independently dirty receivers and other owned lifetimes. Roles 1004 and 1020 are independent helpers, while 781 is a Type A X2 field.

If the old owned route is `A→B` and the receiver route is `B→F`, the missing owned contribution is `T_F T_B† T_B T_A† z = T_F T_A† z` at the new receiver. ADD is linear and both operands now use the full frame `F`. The equation tensor-powers on all complete digital columns and arbitrary spectators. The source clock check validates all other data dependencies and the old owned bank's later availability. The verifier uses all exact signed Pauli generators and one exact Gaussian-dyadic column to compare each changed direct MOVE with its old two-factor action. It lowers the three new rank-five recipes and checks their adjoints. Omitting the retimed ADD is rejected by the complete public endpoint check.

The literal bypass replays all 2,253,001 public scalar coefficients, 74 INIT/CLEAR pairs, all original output labels and only the original 6,276 paid occurrences. ADD, COPY, SCALE, INIT and CLEAR counts match the old word. The paid profile changes by `P4 = −3`, `P5 = +3`, with unchanged target profile. All 17 baseline-call substitutions therefore have the charge `51(H5−H4)`. The per-native surcharges are **2.97271975** at the open #7546 κ, **2.96266659** at κ=.005, and **2.83362290** at κ=.0227. The fixed-tape and workspace route bills require fresh estimates for the altered lifetimes, so matching ordinary scalar counts alone is insufficient. This serves as a physically checked alternate route with a positive debit.

The exact normalized scalar grid includes every stored row and pre-ADD product. The odd denominator LCM remains **1125**, dyadic denominator height remains **25**, and maximum coefficient row L1 mass is **11218327601609/122880** on both words. This exact row calculation does not constitute a bound on physical Gaussian child interiors, rounding, tape stock, or all-size recovery.

## Why a free full-chart readout is unavailable here

Let `A` be the matrix of all 1,052 independent original full-chart ingress rows. Its square exact suffix is `S`. Write `T` for the full 1,501-owner scalar endpoint matrix of all returns. Then `T_top=S A`. For a desired repair source row `v`, the coordinates `v T⁻¹` decide whether it belongs to the span of the full arrivals. When it does, the exact ingress representation is `(v T⁻¹)_top S`. This checks a full terminal span without relying on an arbitrary chosen chronology or a numerical inverse. In each of the three cases above, `v T⁻¹` contains exactly 52 non-top owner coordinates. Therefore even the complete original full-chart input stock cannot generate that exact repair source. This check is separate from the successful literal reroute, which buys the missing direct transport. Changing pre-arrival stock on both sides of the cut or charging the combined lower and upper owners as one new interface could give another construction.

## Complemented-adjoint route for 993/851

The existing complemented adjoint turns the primal `851 += 2h` return leak into an input contact `993 += 2 × 957` at event 18496. The helper enters chart 1053 at event 18498. The Type A mate 957 enters that exact rank-five chart by its own paid MOVE at event 29407, and the helper has no scalar consumer until event 39792. This is an actual later carrier with enough time to provide the old precode. The earlier role 957 value is a nineteen-term dirty form on the 1,501 inputs, while its later carrier has just six terms and differs. The verifier rejects direct substitution and solves the rational stock span at 19 chart-1053 arrivals, along with the mate's immediate return and the first twenty events checking the helper. None of the sampled available coframes generates the missing nineteen-term form. The census concerns these literal event boundaries and leaves earlier producer changes open.

## Replay

The source is the pinned compressed #7546 word at head `99438c43df7aac1e5dbcc43c1578fcd886c119ec`. The standard-library replay restores its source digest and uses the exact signed Pauli compiler. One CPU process completed in 13.10 seconds, below the 30-second deadline. The optional emitted word is the actual alternate sequence. The verifier, complete JSON receipt and written proof are the durable replay sources. No GPU, shared checkout edits, or external writes were used.

```powershell
python -I -B -S -W error round6/independent/owned_packet_coalescence.py inputs/7546-word.json.gz run/owned-packet-coalescence.json --emit run/owned-full-bypass-word.json
python -I -B -S -W error round6/independent/adjoint_prearrival.py inputs/7546-word.json.gz run/adjoint-prearrival.json
```

The bundle needs the same `round5/paired_tail_synthesis.py`, `round4/complex_terminal_transport.py` and their pinned dependencies as the previous local exact cut work. [#7546 exact-head replay](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050) · [#7582 fixed-coframe archive scope](https://github.com/CrocSwap/integer-mult-bounds/pull/7582)
