# SPDX-License-Identifier: Apache-2.0
"""Reuse mandatory Y ascents to receive already-funded BIT payloads."""

from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from functools import cache
import json
from pathlib import Path
import sys
from time import monotonic


HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE / "algebra"))
from joint_virtual_search import joint_choices
from public_tetrad_shear import promote_public_x
from snapshot_owner_shear import clean_observation_transform, exact_replay, helper_tariff
from syndrome_packets import (compare, fitting_calibration, load_word, packet_syndromes,
                              require, select_packets, shared_word, supported_interval, tetrad_blocks)
from tetrad_four_sums import TetradSums
from tetrad_rectangles import dot


@dataclass(frozen=True)
class Delivery:
    receiver: int
    begin: int
    stop: int
    holder: int
    origin: int
    target: int
    retire: tuple


def make_shear(deadline, defer=True):
    """Construct the frozen independent-helper comparator using the original stages."""
    word=load_word()
    heads,*_ = fitting_calibration(word)
    packets,_,_=tetrad_blocks(heads,True)
    feed,res,high,read=packet_syndromes(word,heads,packets)
    _,offers=joint_choices(packets,feed,deadline)
    groups,covered=select_packets(offers,len(packets))
    omitted=[tuple(map(Fraction,word["frames"][str(f)]["A"][0])) for f in high] if defer else ()
    raw=shared_word(word,packets,groups,covered,feed,res,high,read,retain_helpers=True,
                    emit_packet=TetradSums(heads,packets,omitted=omitted),defer_residues=defer)
    dirty=clean_observation_transform(raw,shear=True,keep_ascents=True)
    return promote_public_x(dirty,retained_hub_copies=defer)[0]


def chart_copy_ends(steps,n,receiver,chart):
    """Recognize actual owned MOVE arrivals and last legs of already-paid descents."""
    found=defaultdict(list)
    for i,(op,r,*args) in enumerate(steps):
        if op!="ADD" or r not in receiver:
            continue
        carrier,f=args
        if carrier<n or i==0 or i+1==len(steps) or f!=chart[r]:
            continue
        last=steps[i-1]
        if last[:2]!=("MOVE",carrier) or last[3]!=f or steps[i+1]!=("CLEAR",carrier,f):
            continue
        u=last[2]
        if i>=3 and steps[i-3]==("INIT",carrier,u) and steps[i-2][:2]==("ADD",carrier):
            _,_,source,old=steps[i-2]
            require(old==u,"literal source for a copied delivery")
            found[r].append(Delivery(r,i-3,i+2,source,u,f,()))
        elif i>=2 and steps[i-2][:2]==("MOVE",carrier) and steps[i-2][3]==u:
            found[r].append(Delivery(r,i-1,i+2,carrier,u,f,(carrier,u)))
        else:
            raise ValueError("unexpected paid cap traffic")
    return found


def choose_deliveries(frames, rows, deadline, chain):
    """Find a directed longest path through strictly nested delivery coframes."""
    h={0:(0,0),**{r:supported_interval(r,Fraction(".005")) for r in range(1,8)}}
    dims={i:len(v[0]) for i,v in frames.items()}

    @cache
    def included(a,b):
        return all(not dot(u,v) for u in frames[a][0] for v in frames[b][1])

    found={}
    choices=Counter()
    for r,candidates in rows.items():
        best=(-1,(),(0,0))
        gain={}
        for a in sorted(candidates,key=lambda row:(dims[row.origin],row.begin)):
            da=dims[a.origin]
            require(0<da<7,"an internal funded coframe")
            partial=h[7-da][0]-h[da][1]
            seq=(a,)
            if chain:
                for b,(v,path) in gain.items():
                    db=dims[b.origin]
                    if db<da and included(b.origin,a.origin):
                        alt=v+h[7-da][0]-h[da-db][1]
                        if alt>partial:
                            partial,seq=alt,(*path,a)
            gain[a]=(partial,seq)
            score=partial+h[7][0]-h[7-da][1]
            key=(len(seq),-sum(bool(z.retire) for z in seq),-a.begin)
            if (score,key)>(best[0],best[2]):
                best=score,seq,key
        found[r]=best[1]
        choices[tuple(dims[z.origin] for z in best[1])]+=1
        require(monotonic()<deadline,"bounded final-delivery choice")
    return found,choices


def schedule(literal, deadline, *, chain=False):
    frames, steps, start, final, slots = literal
    n=len(start)
    roots=111
    recv={n+i:final[i+roots] for i in range(roots)}
    deliveries=chart_copy_ends(steps,n,recv,recv)
    selected,scope=choose_deliveries(frames,deliveries,deadline,chain)
    require(len(selected)==roots,"a funded last leg for each independent Y")
    cuts={r for op,r,*a in steps if op=="MOVE" and r in range(n+roots,n+roots+9) and a[1]==start[roots]}
    require(len(cuts)==9,"all nine cuts finish before productive Y ascents")
    changes={row.begin:row for path in selected.values() for row in path}
    registers={i:slots+k for k,i in enumerate(sorted(changes))}
    p=[]
    t=0
    sort=Counter()
    held=set()
    while t<len(steps):
        if t in changes:
            row=changes[t]
            unique=registers[t]
            if row.retire:
                require(row.retire==(row.holder,row.origin),"retained lower-stage packet")
                p.append(("INIT",unique,row.origin))
                p.append(("ADD",unique,row.holder,row.origin))
                p.append(("CLEAR",row.holder,row.origin))
                sort["directly_preserved_last_leg"]+=1
            else:
                p.append(("INIT",unique,row.origin))
                p.append(("ADD",unique,row.holder,row.origin))
                sort["ordinary_observers_saved_at_origin"]+=1
            held.add(t)
            t=row.stop
            continue
        op,r,*a=steps[t]
        if op=="MOVE" and roots<=r<2*roots:
            k=n+r-roots
            target=recv[k]
            require(a==[start[r],target] and not frames[start[r]][0],"original public Y leaves frame zero")
            prev=start[r]
            for row in selected[k]:
                held.remove(row.begin)
                frame=row.origin
                unique=registers[row.begin]
                p.extend([("MOVE",r,prev,frame),("ADD",r,unique,frame),("CLEAR",unique,frame)])
                prev=frame
            p.append(("MOVE",r,prev,target))
        else:
            p.append(steps[t])
        t+=1
    require(not held,"every re-routed paid delivery integrated")
    return (frames,p,start,final,slots+len(changes)),scope,sort


def main():
    deadline=monotonic()+40
    baseline=make_shear(deadline)
    old, old_replay=exact_replay(*baseline,shear=True)
    new, choices, contacts=schedule(baseline,deadline)
    paid, replay=exact_replay(*new,shear=True)
    multi, longer, moved=schedule(baseline,deadline,chain=True)
    reduced, mult_replay=exact_replay(*multi,shear=True)
    caps=Counter({7:222})+helper_tariff(new[0],new[2],new[3])
    require(sum(paid.values())==sum(reduced.values())==sum(old.values()) and monotonic()<deadline,
            "each paid arrival replaced by one nested ascent")
    receipt={"status":"PASS_RECIPIENT_ASCENTS_CARRY_ORTHOGONAL_PACKETS",
             "before":dict(sorted(old.items())),"after":dict(sorted(paid.items())),
             "before_replay":old_replay,"after_replay":replay,"productive":caps,
             "chosen_intermediate_ranks":{":".join(map(str,k)):v for k,v in choices.items()},"contacts":contacts,
             "signed_prices":compare(paid,old,caps),
             "all_nested_frames":{"chosen_paths":{":".join(map(str,k)):v for k,v in sorted(longer.items())},
                  "paid":dict(sorted(reduced.items())),"replay":mult_replay,"rerouted_contacts":moved,
                  "price_vs_one_step":compare(reduced,paid,caps),"price_vs_original":compare(reduced,old,caps)},
             "scope":"same P111 forward shear and 190 independently arbitrary productive helper returns"}
    print(json.dumps(receipt,indent=2,sort_keys=True))


if __name__=="__main__":
    main()
