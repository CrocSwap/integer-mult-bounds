# Round 6 exact replay

Extract the archive. Run from its root with standard-library CPython
3.11 or newer and Git. The two recurrence replays read Git blobs from
the canonical checkout and require object
`e54523517d0f03e58352e647c403a5af3e525a57`. The source pin receipts and
the other input files are in the ZIP. The main shear readouts produce
JSON on standard output for comparison with the receipts of the same names.

```powershell
$repo = 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
$q = 'inputs/7546-word.json.gz'
$out = (New-Item -ItemType Directory -Path 'run' -Force).FullName
python -I -B -S -W error round6/algebra/syndrome_packets.py
python -I -B -S -W error round6/algebra/joint_virtual_search.py
python -I -B -S -W error round6/packet_collectors.py
python -I -B -S -W error round6/algebra/snapshot_owner_shear.py
python -I -B -S -W error round6/algebra/parent_return_stock.py
python -I -B -S -W error round6/tetrad_four_sums.py
python -I -B -S -W error round6/algebra/public_tetrad_shear.py
python -I -B -S -W error round6/recipient_ascents.py
python -I -B -S -W error round6/productive_carriers.py
python -I -B -S -W error round6/invoice_context.py
python -I -B -S -W error round6/physical_projector_controls.py
python -I -B -S -W error round6/selected_contact_ports.py
python -I -B -S -W error round6/selected_receiver_edge.py
python -I -B -S -W error round6/singleton_relay.py
python -I -B -S -W error round6/independent/owned_packet_coalescence.py $q "$out/owned-bypass.json" --emit "$out/owned-full-bypass-word.json"
python -I -B -S -W error round6/independent/adjoint_prearrival.py $q "$out/adjoint-prearrival.json"
python -I -B -S -W error round6/recurrence/inspect_rank_metric.py $repo --expect round6/recurrence/inspect.json
python -I -B -S -W error round6/recurrence/verify_affine_provider.py $repo --expect round6/recurrence/affine-provider.json
```

The round-five triple screen and its recorded RTX 5080 comparison are
retained as earlier evidence. Current programs use exact CPU rational
arithmetic, scalar bit masks and finite public mutations. The common
frame rigidity and complex reroute have separate proof and bound scopes.
There is no new uniform multiplier or admission in this bundle.

Run a batch with bounded worker lifetimes and check output JSON equality,
not elapsed time or the status line alone. Modification of either checked
repository or the compressed source pins is unnecessary. The canonical
checkout is read-only in the replay.
