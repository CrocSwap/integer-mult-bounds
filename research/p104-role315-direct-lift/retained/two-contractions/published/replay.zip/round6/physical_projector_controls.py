# SPDX-License-Identifier: Apache-2.0
"""Check the new nested frame catalogue, prime-field samples and payload norm."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
import sys
from time import monotonic


HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE / "algebra")]
from recipient_ascents import make_shear, schedule
from scan_bit_move_runs import basis
from snapshot_owner_shear import exact_replay
from syndrome_packets import require
from tetrad_rectangles import dot
ALG=run_path(str(HERE.parent / "algebra/verify_bit_orthogonal_quotient.py"))


def inventory(literal,deadline):
    frames,steps,start,final,slots=literal
    active=set(start+final)
    used=Counter()
    for op,r,*a in steps:
        if op in {"MOVE","ADD","INIT","CLEAR"}:
            active.add(a[-1])
        if op=="MOVE":
            active.add(a[0])
            used[tuple(a)]+=1
    checks=Counter()
    for frame in sorted(active):
        b,a=frames[frame]
        require(len(b)+len(a)==8 and len(basis([*b,*a]))==8 and
                all(not dot(x,y) for x in b for y in a),
                "independent rational orthogonal canonical chart")
        checks[len(b)]+=1
        require(monotonic()<deadline,"bounded frame inventory")
    n=len(start)
    hold=[1<<j for j in range(n)]+[0]*(slots-n)
    peak=1
    for op,r,*a in steps:
        if op=="ADD":
            hold[r]^=hold[a[0]]
            peak=max(peak,hold[r].bit_count())
        elif op in {"INIT","CLEAR"}:
            hold[r]=0
    return checks, used, peak


def projector(frame):
    ar=ALG["Arithmetic"]()
    b=frame[0]
    if not b:
        return ar.scale(ar.eye(8),0)
    b=ar.matrix(b)
    c=ALG["transpose"](b)
    return ar.mul(c,ar.mul(ar.invert(ar.mul(b,c)),b))


def controls(literal,selected,deadline):
    frames,_,start,final,_=literal
    chart={}

    def q(f):
        if f not in chart:
            chart[f]=projector(frames[f])
        return chart[f]

    ar=ALG["Arithmetic"]()
    eye=ar.eye(8)
    examples={}
    for a,b in selected:
        d=len(frames[b][0])-len(frames[a][0])
        x=ar.combine(q(b),q(a),-1)
        require(len(basis(x))==abs(d),"exact matrix-rank price for every nested template")
        require(ar.mul(x,x)==ar.scale(x,1 if d>0 else -1),"signed nested difference is a projector")
        examples.setdefault(d,(a,b))
        require(monotonic()<deadline,"bounded all-edge signed projector check")
    require(all(ar.combine(q(start[i]),q(final[i+111]))==eye for i in range(111)),
            "each main boundary has the exact original complement head")
    # In sum/difference coordinates the physical field carry is diag(I,I-2P).
    # Verify the grouped reciprocal lowering in one pinned physical basis
    # over two representative odd local rings, per signed rank class.
    ring=0
    details=[]
    for d,(a,b) in sorted(examples.items()):
        diff=ar.combine(q(b),q(a),-1)
        if d<0:
            diff=ar.scale(diff,-1)
        for modulus in (1009**2,10007):
            mr=ALG["Arithmetic"](modulus)
            norm=mr.matrix(diff)
            # The chosen spanning/eigen-coordinate basis exposes a true
            # diagonal rank-|d| projector before the one-child operation.
            x=basis(diff)
            dual=basis(ar.combine(eye,diff,-1))
            embed=mr.matrix([*x,*dual])
            actual=mr.mul(embed,mr.mul(norm,mr.invert(embed)))
            wanted=mr.matrix([[int(i==j and i<abs(d)) for j in range(8)] for i in range(8)])
            require(actual==wanted,"finite-ring representative signed frame coordinates")
            U=mr.combine(mr.eye(8),mr.scale(wanted,2),-1)
            G=ALG["split_operator"](mr,U,[1]*8)
            ALG["compile_one"](mr,G,abs(d))
            ring+=16
        details.append({"signed_rank":d,"representative_charts":[a,b]})
    return chart,examples,ring,details


def main():
    deadline=monotonic()+45
    base=make_shear(deadline)
    candidate,_,_=schedule(base,deadline,chain=True)
    p,info=exact_replay(*candidate,shear=True)
    counts,templates,peak=inventory(candidate,deadline)
    charts,examples,ring,info2=controls(candidate,templates,deadline)
    require(monotonic()<deadline,"exact projector checks finish on time")
    print(json.dumps({"status":"PASS_BIT_TETRAD_NESTED_PROJECTORS",
       "distinct_used_chart_dimensions":counts,"ordered_move_template_count":len(templates),
       "actual_paid":p,"all_projector_differences_checked":len(templates),"projectors_materialized":len(charts),
       "all_main_complement_pairs":111,"representative_signed_rank_shapes":info2,
       "finite_ring_lowering_columns":ring,"max_normalized_BIT_row_support":peak,"all_public_coefficients":info,
       "scope":"exact rational orthogonal charts and selected local-ring grouped-child fixtures; fixed all-label stock/ordinary routing and global tape are open"},
       sort_keys=True,indent=2))


if __name__=="__main__":
    main()
