"""Find rank-preserving one-sided coframe border vectors over rationals."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


CORE_PATH = Path(__file__).resolve().parents[2] / "recurrence" / "verify_bit_caller_bound.py"
SPEC = spec_from_file_location("bit_caller_verifier", CORE_PATH)
CORE = module_from_spec(SPEC)
SPEC.loader.exec_module(CORE)


def finite_rank(rows):
    basis = {}
    for row in rows:
        current = [Q(x) for x in row]
        for j in range(len(current)):
            x = current[j]
            if not x:
                continue
            if j not in basis:
                basis[j] = [v / x for v in current]
                break
            current = [u - x * v for u, v in zip(current, basis[j], strict=True)]
    return len(basis)


def inverse(rows):
    n = len(rows)
    augmented = [[Q(x) for x in row] + [Q(int(i == j)) for j in range(n)]
                 for i, row in enumerate(rows)]
    for i in range(n):
        j = next(j for j in range(i, n) if augmented[j][i])
        augmented[i], augmented[j] = augmented[j], augmented[i]
        x = augmented[i][i]
        augmented[i] = [v / x for v in augmented[i]]
        for j in range(n):
            if j != i and augmented[j][i]:
                x = augmented[j][i]
                augmented[j] = [u - x * v for u, v in zip(augmented[j], augmented[i], strict=True)]
    return [row[n:] for row in augmented]


def matmul(a, b):
    return [[sum(x*y for x,y in zip(row, col, strict=True)) for col in zip(*b)] for row in a]


def projectors(frames):
    result = {}
    for label, frame in frames.items():
        k = frame["dim"]
        basis = [list(map(Q, col)) for col in zip(*(frame["B"] + frame["A"]))]
        dual = inverse(basis)
        p = matmul([row[:k] for row in basis], dual[:k]) if k else [[Q(0)] * 8 for _ in range(8)]
        CORE.need(matmul(p, p) == p and p == [list(row) for row in zip(*p)], "Not a symmetric projector")
        result[label] = p
    return result


def paired_embed(word, frames, moves):
    charts = projectors(frames)
    zero = word["start"][111]
    full = word["final"][0]
    e = [[Q(int(i == j)) for j in range(8)] for i in range(8)]
    CORE.need(charts[full] == e and not any(map(any, charts[zero])), "Wrong common top or bottom")
    q = word["start"][:111]
    caps = word["final"][111:222]
    CORE.need(all(add(charts[x], charts[y]) == e for x, y in zip(q, caps, strict=True)),
              "Main caps are not literal complements")
    for first, second in moves:
        change = add(charts[second], charts[first], -1)
        old_rank = abs(frames[first]["dim"] - frames[second]["dim"])
        CORE.need(finite_rank(change) == old_rank, "Actual additive MOVE rank disagrees")
        smaller, larger = sorted((frames[first], frames[second]), key=lambda ff: ff["dim"])
        annihilator = smaller["B"] + larger["A"]
        CORE.need(len(annihilator) == 8-old_rank and finite_rank(annihilator) == 8-old_rank,
                  "Incorrect number of independent kernel vectors")
        CORE.need(all(not any(map(any, matmul(change, [[Q(x)] for x in vector])))
                      for vector in annihilator), "Constraint is outside exact kernel")
    for first, second in zip(word["start"][222:], word["final"][222:], strict=True):
        CORE.need(finite_rank(add(charts[second], charts[first], -1)) ==
                  frames[second]["dim"] - frames[first]["dim"], "Wrong independent helper endpoint")
    return charts


def add(a, b, multiplier=1):
    return [[x + multiplier*y for x,y in zip(row, other, strict=True)]
            for row, other in zip(a, b, strict=True)]


def constraints(word, include_pairs):
    points, moves = {}, Counter()
    frames = {int(k): v for k, v in word["frames"].items()}
    for opcode, _, *data in word["program"]:
        if opcode == "MOVE":
            moves[tuple(data[:2])] += 1
    neighbours = defaultdict(set)
    for f, g in moves:
        neighbours[f].add(g)
        neighbours[g].add(f)
    queue = [next(iter(frames))]
    reached = set(queue)
    for f in queue:
        new = neighbours[f] - reached
        queue.extend(new)
        reached.update(new)
    CORE.need(reached == frames.keys(), "Literal chart graph is not connected")
    zero = next(j for j, a in frames.items() if a["dim"] == 0)
    full = next(j for j, a in frames.items() if a["dim"] == 8)
    for key in frames:
        if key not in (zero, full):
            points[key] = len(points) * 8
    basis = {}

    def add_row(values):
        values = {k: x for k, x in values.items() if x}
        while values:
            j = min(values)
            c = values[j]
            if j not in basis:
                basis[j] = {k: x / c for k, x in values.items()}
                return
            for k, x in basis[j].items():
                new = values.get(k, 0) - c * x
                if new:
                    values[k] = new
                else:
                    values.pop(k, None)

    def add_difference(first, second, direction):
        row = {}
        for frame, sign in ((first, -1), (second, 1)):
            if frame in points:
                for i, coeff in enumerate(direction):
                    key = points[frame] + i
                    row[key] = row.get(key, 0) + sign * Q(coeff)
        add_row(row)

    for first, second in moves:
        f, g = frames[first], frames[second]
        if f["dim"] > g["dim"]:
            f, g = g, f
        for vector in f["B"] + g["A"]:
            add_difference(first, second, vector)
    if include_pairs:
        for x in range(111):
            first, second = word["start"][x], word["final"][x + 111]
            for i in range(8):
                add_difference(first, second, [int(i == j) for j in range(8)])
    return frames, moves, points, basis


def census_ports(word, frames, moves):
    x, y = word["start"][:111], word["final"][111:222]
    zero = word["start"][111]
    full = word["final"][0]
    CORE.need(len(set(x)) == len(set(y)) == 111, "Main frame labels are not distinct")
    CORE.need(set(word["start"][111:222]) == {zero} and set(word["final"][:111]) == {full},
              "Incorrect core boundary")
    out = {}
    for key, select in {"head_entrances": set(x), "y_exits": set(y),
                        "head_entrances_and_zero": {*x, zero},
                        "y_exits_and_full": {*y, full}}.items():
        move_ranks = Counter()
        helper_ranks = Counter()
        for (first, second), n in moves.items():
            if (first in select) != (second in select):
                move_ranks[abs(frames[first]["dim"] - frames[second]["dim"])] += n
        for first, second in zip(word["start"][222:], word["final"][222:], strict=True):
            if (first in select) != (second in select):
                helper_ranks[abs(frames[first]["dim"] - frames[second]["dim"])] += 1
        out[key] = {"widened_paid_MOVE_histogram": move_ranks,
                    "widened_helper_histogram": helper_ranks}
    return out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--expect", type=Path)
    args = parser.parse_args()
    word = CORE.read_git(args.repo, CORE.PREFIX + "retained/inputs/BIT-NATIVE-WORD.json.gz")
    base = {}
    for include_pairs in (False, True):
        frames, moves, points, basis = constraints(word, include_pairs)
        free = set(range(len(points) * 8)) - basis.keys()
        CORE.need(len(basis) == 5072 and not free, "Chart border did not have full exact gauge-fixed rank")
        base[str(include_pairs)] = {"pair_controls": include_pairs,
                           "frames": len(frames), "ordered_move_pairs": len(moves),
                           "pivot_count": len(basis), "nullity_after_global_gauge": len(free),
                           "head_blocks_with_free_parameters": sum(any(
                               points[head] + k in free for k in range(8))
                               for head in word["start"][:111])}
    charts = paired_embed(word, frames, moves)
    payload = json.dumps({"systems": base, "census_ports": census_ports(word, frames, moves),
                          "physical_additive_chart_ranks": len(charts),
                          "distinct_additive_move_ranks": len(moves),
                          "connected_original_chart_graph": True,
                          "canonical_move_kernel_bases": len(moves),
                          "independent_additive_helper_ranks": 437}, indent=2, sort_keys=True)
    if args.expect:
        CORE.need(args.expect.read_text(encoding="utf-8").rstrip("\n") == payload, "Receipt changed")
    print(payload)


if __name__ == "__main__":
    main()
