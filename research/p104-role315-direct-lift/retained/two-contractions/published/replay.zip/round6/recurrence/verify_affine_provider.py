"""Two non-involutive BIT providers and their fully charged short caller."""

import argparse
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / "recurrence" / "verify_bit_caller_bound.py"
SPEC = spec_from_file_location("verify_bit_caller_bound", SOURCE)
CORE = module_from_spec(SPEC)
SPEC.loader.exec_module(CORE)
need = CORE.need


def add(*values):
    return tuple(sum(x) for x in zip(*values, strict=True))


def signed(s, a):
    return tuple(s*x for x in a)


def multiply(u, v):
    out = set()
    for a in u:
        for b in v:
            out.symmetric_difference_update({add(a, b)})
    return out


def matmul(a, b):
    return [[multiply(a[i][0], b[0][j]) ^ multiply(a[i][1], b[1][j])
             for j in range(2)] for i in range(2)]


def stage(q, d, s, upper, invert=False):
    x = signed(-s if invert else s, d)
    unit = [[{x}, set()], [set(), {x}]]
    unit[int(not upper)][int(upper)] = {add(x, signed(s, q))}
    return unit


def exact_formal_word():
    zero = (0,)*4
    directions = [tuple(int(i==j) for i in range(4)) for j in range(4)]
    head, *body = directions
    flip = [[set(), {zero}], [{zero}, set()]]
    identity = [[{zero}, set()], [set(), {zero}]]
    for signs in ((1, -1, 1), (-1, 1, -1)):
        program = [stage(head, d, s, j==1) for j, (d,s) in enumerate(zip(body,signs,strict=True))]
        inverses = [stage(head,d,s,j==1,True) for j,(d,s) in enumerate(zip(body,signs,strict=True))]
        out = matmul(flip, matmul(program[2], matmul(program[1], program[0])))
        delta = add(*(signed(s,d) for s,d in zip(signs,body,strict=True)))
        wanted = [[{add(delta,signed(signs[0],head))}, set()],
                  [set(), {add(delta,signed(-signs[0],head))}]]
        need(out == wanted, "Three signed providers failed exact formal target")
        back = matmul(inverses[0], matmul(inverses[1], matmul(inverses[2],flip)))
        need(matmul(back,out) == identity, "Full symbolic reverse operator failed")
        # An all-positive second host is generally wrong at odd radix.
        bad = stage(head, body[1], signs[0], True)
        need(matmul(flip,matmul(program[2],matmul(bad,program[0]))) != wanted,
             "Involution-valued substitution falsely accepted")
    return {"formal_orientations": 2, "arbitrary_basis_columns": 2,
            "native_requests": 3, "thin_calls": 0, "new_ordinary_scalar_divisions": 0}


def shift_rows(rows, exponent, radix):
    """Move finite affine shear addresses; retain sorted spectators."""
    data = [0]*len(rows)
    for index,value in enumerate(rows):
        prefix, encoded = divmod(index, radix**8)
        h, d = divmod(encoded, radix**4)
        target, weight = 0, 1
        for coefficient in exponent:
            hh, dd = h % radix, d % radix
            h, d = h // radix, d // radix
            target += ((hh + coefficient*dd) % radix)*weight
            weight *= radix
        data[prefix*radix**8+target*radix**4+encoded%radix**4] = value
    return data


def check_finite():
    total = 0
    for radix, spectator_count in ((3, 2), (4, 1)):
        n = radix**8*spectator_count
        # Each unique input record is an independent basis symbol. Store
        # two-element maps sparsely as Python ints in a single finite run.
        x, y = list(range(1,n+1)), list(range(n+1,2*n+1))
        left, right = x[:], y[:]
        for k, s in enumerate((1,-1,1)):
            base = tuple(s*int(i==k+1) for i in range(4))
            h = add(base,(s,0,0,0))
            if k == 1:
                left, right = right, left
            lower = shift_rows(right,base,radix)
            mix = shift_rows(left,h,radix)
            left, right = shift_rows(left,base,radix), [u ^ v for u,v in zip(lower,mix,strict=True)]
            if k == 1:
                left, right = right, left
        need(right == shift_rows(x,(1,1,-1,1),radix) and
             left == shift_rows(y,(-1,1,-1,1),radix), "Finite physical signed-shear caller disagrees")
        total += 2*n
    return total


def finite_chart_pairs(prime, width):
    modulus = prime**width
    for h in range(modulus):
        for d in range(modulus):
            for beta in (1, -1, 2, -2):
                inv = pow(beta, -1, modulus)
                early_scaled, late = h, beta*d % modulus
                # The signed response need not be the same on two rails.
                early_scaled = (early_scaled + inv*late) % modulus
                need((early_scaled, late*inv % modulus) == ((h+d)%modulus,d),
                     "Later sign gauge did not give positive early shear")
                x = (d-h) % modulus
                y = (h+x) % modulus
                z = (y-x) % modulus
                need((y,z) == (d,h), "Two later operations did not complete swap")
    return 4*modulus*modulus


def quote(bit_paid, bit_targets):
    net = Counter({r: 3*n for r,n in bit_targets.items()})
    net[22] += 222
    net.subtract(Counter({r: 3*n for r,n in bit_paid.items()}))
    return {str(s): CORE.format_bounds(CORE.moment(net, s, 10000)) for s in (0, 50, 227)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--expect", type=Path)
    args = parser.parse_args()
    _, paid, helpers, _, _ = CORE.verify_sources(args.repo)
    payload = json.dumps({"status": "PASS_AFFINE_BIT_PROVIDER", "word": exact_formal_word(),
                          "unchanged_paid_ranks": paid, "unchanged_helper_ranks": helpers,
                          "complete_margin_saving_grid_10000": quote(paid,helpers),
                          "finite_affine_records": check_finite(),
                          "finite_signed_to_ordinary_pairs": sum(finite_chart_pairs(p,w)
                              for p,w in ((3,1),(3,2),(5,1),(5,2),(7,1)))}, indent=2, sort_keys=True)
    if args.expect:
        need(args.expect.read_text(encoding="utf-8").rstrip("\n") == payload, "Receipt changed")
    print(payload)


if __name__ == "__main__":
    main()
