# An additive BIT provider and rank-preserving frame-border rigidity

The exact selected BIT scalar word supports a second physical address
representation using commuting **rational shears**. Its header has no
involution relation at odd radix. A signed three-call assembly gives
ordinary interchanges on the two independent main roles of each port
after fixed, streamed later-coordinate changes. It keeps the native child
histogram and independent helper ranks. The complete raw three-call margin
at .005 is **−93.1608539614724** even with these extra scans waived.

The relaxed shear frames also permit arbitrary off-diagonal extensions of
the original frame matrices. For one common extended matrix per original
chart, an exact source-bound rank calculation shows that **all extensions
preserving the original block and every literal MOVE rank are shared
embeddings**. In particular no port acquires a thicker head. This uses
rational column-space constraints, rather than the binary tensor-color
restriction of the previous round.

The source is #7001 at canonical pin
`e54523517d0f03e58352e647c403a5af3e525a57`. All statements refer to its
retained native tape and a changed interpretation of its chart variables.
[Selected native](https://github.com/CrocSwap/integer-mult-bounds/pull/7001) ·
[Source review](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/docs/research/pr-intake-evidence/pr7000-application/PROOF-REVIEW.md) ·
[Rational matrix-shear compiler](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/upstream/build/sections/04-swap.tex)

## A complete signed additive boundary

Split the address into earlier and later vectors (H,D\) over
\(\mathbf Z/p^f\mathbf Z\), for a fixed odd prime outside all denominators
and nonzero elementary minors of the finite rational catalogue. For a
rational matrix (A\), use the address action

\[
\Phi_A(H,D)=(H+AD,D),\quad
\Phi_A\Phi_B=\Phi_{A+B},\quad \Phi_A^{-1}=\Phi_{-A}.
\]

All payload coefficients are over \(\mathbf F_2\); odd radix applies to
address digits only. Each label (F\) of the source has an exact symmetric
rational projector (P_F\). In an address realization with embedding

\[
A_F=\sigma J P_F K,\qquad \sigma\in\{+1,-1\},
\]

take (J\) injective and (K\) surjective. For the local program first use
square invertible (J,K\), and later include the surrounding spectator
directions with zero matrix entries. A logical scalar row at frame (F\)
is interpreted as the physical row after (\Phi_{A_F}\). This changes
the interpretation of arbitrary inputs bijectively and performs no free
physical input map. A literal ADD continues to read and write one common
complete chart, so it is pointwise XOR. A literal SWAP moves the chart
with its role. MOVE from (F\) to (G\) is (\Phi_{A_G-A_F}\). The
retained owned initializations and clears are at their original times and
refer only to the original owned fields.

Every checked MOVE is a nested transition in its original direction,
or a rank-equivalent move whose exact projector difference has the
recorded dimension difference. The replay computes the rank of all
2,374 distinct ordered differences over \(\mathbf Q\). It also checks
the 437 independent helper differences with the original productive
ranks. Rank is unchanged under (J,K,\sigma\). The upstream Bruhat
lemma supplies (r\) ordinary (f\)-digit child interchanges plus (O(V)\)
ordinary work for a rational MOVE of rank (r\) on a stream of volume
(V\). This is the split-child price. An (H(r)\) price uses one grouped
interchange of the same (r\) pairs, when the host's lane service can
gather the selected (r\) pairs. The grouped price is favorable and needs
the grouped addressed caller, which is not established by the rank
calculation. Both interpretations charge the whole input stream and never
credit a private field. Section below reports this distinction explicitly.

Set (A_0=0,A_I=I\) initially, and use the original port charts
((P_i,0,I,I-P_i)\) on ((X_{in},Y_{in},X_{out},Y_{out})\).
The complete logical row sends ((x,y)\mapsto(x,y+x)\). Its physical
two-role operator in the chosen port basis is

\[
\Phi_{\sigma(I-P_i)}(I+\Phi_{-\sigma P_i}E_{yx}).
\]

Given the actual rational basis ([u_i,B_i]\), a common fixed chart sends
that port's head to one ambient coordinate, its seven complement axes to
seven designated fresh stage axes, and acts consistently on all helpers.
Putting the three seven-axis stage blocks on different coordinates keeps
outside spectators. A per-port rational routing and the corresponding
source chart changes are ordinary obligations at each contact. Within the
finite frame theorem the blockwise header and body labels are the exact
operators; a fully billed physical global router is outside this result.

Write (q=\Phi_{-P}\), (B_j=\Phi_{I-P}\) on fresh stage axes,
and use orientations (+,-,+\) with upper/lower/upper or its full
role-swapped version. The two-by-two group-algebra identity over
\(\mathbf F_2\), with (q\) any invertible element, is

\[
L(q)U(q^{-1})L(q)=\begin{pmatrix}0&q^{-1}\\q&0\end{pmatrix}.
\]

An ordinary role-swap gives (qB_1B_2^{-1}B_3\) and
(q^{-1}B_1B_2^{-1}B_3\) on the two independent main roots. This uses three
full native invocations with fresh helper banks, three external role
rebindings/swaps in the explicit lower/upper/lower implementation and no
thin queries or idles. The complementary orientations give the same ranks.
There is no Boolean assumption (q=q^{-1}\); a mutation imposing the wrong
second orientation is rejected by the exact formal replay.

The two main matrices are diagonal with the same 22-dimensional support
and entries ±1 there. Scaling the appropriate later components before and
after a signed shear by these fixed units reduces it to the positive
shear without moving spectators. The positive shear on a complete pair
of fields becomes an interchange by the ordinary later-coordinate
updates (D\gets D-H\) before and (D\gets H-D\) afterward. These are
legal streamed operations because the control coordinate precedes the
updated coordinate. They use bounded head-return and scratch routines in
the retained later-field lemma. The helper deltas are separately typed
same-owner rational shears of their actual positive ranks, with full
conversion/restoration work visible. No odd division in the Boolean
payload is introduced. The local script verifies a symbolic all-column
inverse on arbitrary main arrays, 157,316 finite record positions over
multiple radix/spectator shapes, and both stream sign corrections and
two-shear completion on 3,156 exact finite modular pairs with a specified
sign or scale.

## Complete recursive price of the new boundary

Each occurrence retains the full baseline paid and helper histograms

```text
paid:    {1:1386,2:1253,3:62,4:47,5:9,6:104,7:10}
helpers: {2:1,4:25,6:1,8:410}
```

Three occurrences add 222 rank-22 main fields and retain 1,311 distinct
productive helpers and 711 separate owned lifetimes. Under the more
favorable grouped-rank price the complete target-minus-paid moment is
exactly the earlier equal-width short caller's:

| Saving | Directed upper margin |
| --- | ---: |
| 0 | +33 |
| .005 | −93.1608539614724 |
| .0227 | −524.6299450361496 |

Splitting each rank-​(r\) MOVE into (r\) independent rank-one calls
only increases the paid moment, because (r^{1-\kappa}\le r\). Hence the
three-host split bill contains exactly 15,015 rank-one calls. The
changed short caller fails even before extra ordinary lane setup, grouping,
routing of different port bases, reset, fixed-tape return and compiler
charges. The local finite chart-to-shear identity does not yield a new
ordinary BIT saving. Its useful change is the available chart search over
arbitrary rank-metric matrices.

## Common bordered extensions of all chart matrices

For an arbitrary fixed number of extra inputs and outputs, replace
(P_F\) by a block matrix

\[
G_F=\begin{pmatrix}P_F&u_F\\v_F&c_F\end{pmatrix}.
\]

Any pair of labels used by a literal MOVE has original difference
(A=P_G-P_F\). An extension with exactly the old rank requires each
column of (u_G-u_F\) to lie in \(\operatorname{im}A\), and each row of
(v_G-v_F\) in the row space of (A\). These are necessary even without
commutation, symmetry, positivity or idempotence of the extended label.
When the first two conditions hold, eliminating the dependent border
row and column gives the extra necessary and sufficient corner condition

\[
\Delta c=\Delta v A^{-}\Delta u
\]

for any generalized inverse (A^{-}\) satisfying (AA^{-}A=A\). The
pairing is independent of the internal choice of generalized inverse.

Subtract (u_0\) as a fixed translation and (P_F(u_I-u_0)\) as a shared
change of basis. This sets (u_0=u_I=0\) and preserves all the MOVE
constraints. Since the (P_F\) are symmetric, the same normalization
applies row-wise to (v_F\). For each ordered difference the smaller
space's selected basis and larger space's annihilator form a basis of
the kernel of that difference. The replay checks this explicitly for
each of the 2,374 ordered pairs using rational ranks and the original
projectors. Impose its exact linear constraints on one column. There are
(8(636-2)=5,072\) unknowns after pinning the known bottom and top.
Sparse rational pivot elimination gives **5,072 independent pivots**
before any paired-boundary constraints are added. All such normalized
columns therefore vanish. The same is true of the rows.

Restoring the gauges gives (u_F=u_0+P_F U\),
(v_F=v_0+V P_F\) for fixed (U,V\). The corner constraint now gives

\[
c_G-c_F=V(P_G-P_F)U
\]

at every actual MOVE. The chart graph is connected, checked by the
replay, so the whole extension is

\[
G_F=G_*+\begin{pmatrix}I\\V\end{pmatrix}P_F\begin{pmatrix}I&U\end{pmatrix}
\]

for one constant matrix (G_*\). Every boundary difference, including
the physical head from the X-to-Y cross coefficient relative to the
Y diagonal, has its original rank. This excludes rank-neutral coherent
head thickening in every extension of the common-label old-block model,
even if some spare axes are assigned both off-diagonal blocks. It leaves
occurrence-dependent frames, changed top-left matrices, rank increases,
helper credits and changed scalar programs to other experiments.

Two direct perturbations quantify the scale. Add a decoupled diagonal
extra axis on all 111 X entrance labels and nowhere else. This widens
831 actual MOVEs, including 666 old rank-one MOVEs, and no helper
return. Using all 111 Y exit labels instead widens 777 actual MOVEs,
again including 666 old rank-one MOVEs, with zero helper credit. These
are precisely the two given patterns, without an optimization claim on
arbitrary changed boundaries. The useful next experiment would need an
actual changed core label matrix or chronological contact placement
whose paid rank increases and target credits are jointly small.

## Reproduce

From the research workspace, using the embedded CPython 3.13.14:

```powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$repo = 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
& $py -I -O -B -S -W error .\work\round6\recurrence\inspect_rank_metric.py $repo --expect .\work\round6\recurrence\inspect.json
& $py -I -O -B -S -W error .\work\round6\recurrence\verify_affine_provider.py $repo --expect .\work\round6\recurrence\affine-provider.json
```

Both scripts use the exact same `work/recurrence/verify_bit_caller_bound.py`
for read-only Git source pins and directed moment intervals. No external
write or GPU computation is used. Commands are CPU-only, serial and
bounded to 26 and 20 seconds respectively. AST parsing and tabnanny
passed. The example checkout has no uv, Ruff or pytest on its tool path.
Normal and optimized runs returned byte-identical receipts:

| Receipt | Normal / optimized seconds | SHA-256 |
| --- | ---: | --- |
| `inspect.json` | 5.592 / 5.818 | `2e9003d2ad56dd7a96a6300093239e36a935b4181a8469aae581ecd0d335f9be` |
| `affine-provider.json` | 0.777 / 0.810 | `032929793ba8f6519c4724abbed461fa4e3234fdd8517eb78a8352ea655b8035` |
