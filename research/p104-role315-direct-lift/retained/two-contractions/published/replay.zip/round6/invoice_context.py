# SPDX-License-Identifier: Apache-2.0
"""Put each actual local BIT candidate into the same finite outer caller invoice."""

from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE=Path(__file__).resolve().parent
PRICE=run_path(str(HERE.parent / "helper_price.py"))
NEED=run_path(str(HERE / "selected_contact_ports.py"))["NEED"]
RECEIPT_SHA="a46b6c6040f75184cab5467656811ad988c216e3bc8e44d595a5015b6e49620b"


def read(path):
    return json.loads(path.read_bytes())


def histogram(entries):
    return Counter({int(r):q for r,q in entries.items()})


def repeated(hist,copies):
    return Counter({r:n*copies for r,n in hist.items()})


def interval(p,n,saving):
    delta=Counter(p)
    delta.subtract(n)
    return PRICE["power_sum"](delta,saving)


def caller_report(old,pay,credit,count,deadline):
    total_paid=histogram(old["paid"])
    total_targets=histogram(old["targets"])
    old_paid=histogram(old["native_paid"])
    old_helpers=histogram(old["native_helpers"])
    paid=total_paid-repeated(old_paid,count)
    helpers=total_targets-repeated(old_helpers,count)
    NEED(paid+repeated(old_paid,count)==total_paid and helpers+repeated(old_helpers,count)==total_targets,
         "all original external production and priced connector counts remain")
    new_paid=paid+repeated(pay,count)
    new_targets=helpers+repeated(credit,count)
    bounds={}
    for s in (".00385248",".005",".0227"):
        saving=Fraction(s)
        trained=interval(total_targets,total_paid,saving)
        correct=interval(new_targets,new_paid,saving)
        helper_remainder=interval(credit,pay,saving)
        old_remainder=interval(old_helpers,old_paid,saving)
        improvement=PRICE["subtract"](helper_remainder,old_remainder)
        unit=PRICE["SCALE"]
        bounds[s]={"selected_complete_raw":trained,"changed_complete_raw":correct,
                   "one_native_net_delta":improvement,
                   "selected_complete_raw_approx":trained[0]/unit,
                   "changed_complete_raw_approx":correct[1]/unit,
                   "per_native_change_approx":improvement[1]/unit}
        NEED(correct[1]<0 and improvement[1]<0 and monotonic()<deadline,"complete scoped rank bill")
    return {"selected_paid_total":sum(total_paid.values()),"selected_production_total":sum(total_targets.values()),
            "changed_paid_total":sum(new_paid.values()),"changed_production_total":sum(new_targets.values()),
            "kept_root_targets":dict(sorted(helpers.items())), "kept_paid_connector_histogram":dict(sorted(paid.items())),
            "candidate_helper_credits":dict(sorted(credit.items())), "raw_margin_rows":bounds}


def main():
    deadline=monotonic()+25
    pin=HERE.parent / "algebra" / "result.json"
    NEED(sha256(pin.read_bytes()).hexdigest()==RECEIPT_SHA,"exact published source bytes")
    old=read(pin)
    new=read(HERE / "recipient-ascents.json")
    t=histogram(new["productive"])
    t[7]-=222
    count=old["native_calls"]
    NEED(count==36 and sum(t.values())==190,"all independent actual candidate helper returns")
    base=histogram(new["all_nested_frames"]["paid"])
    book=caller_report(old,base,t,count,deadline)
    print(json.dumps({"status":"PASS_NEW_BIT_NATIVE_WHOLE_CALLER_SENSITIVITY",
                      "native_instances":count,"price_unit":PRICE["SCALE"],"ordinary_family":book,
                      "scope":"same 111 scalar main poses and complete selected caller size table; grants unseen arbitrary-width route and common-label/tape agreements, lies below break-even already"},
                     indent=2,sort_keys=True))


if __name__=="__main__":
    main()
