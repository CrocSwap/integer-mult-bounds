# SPDX-License-Identifier: Apache-2.0
"""Reuse input pair sums between Hamming sign classes and an independent dirty bank."""

from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import sys
from time import monotonic


HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE / "algebra"))
from syndrome_packets import (compare, fitting_calibration, load_word,
                              packet_syndromes, replay, replay_with_dirty, require,
                              select_packets, shared_word, supported_interval, tetrad_blocks)
from joint_virtual_search import joint_choices
from packet_pair_transport import basis, nullspace


def plans(packets, deadline):
    """Select disjoint appearances of precomputed two-line sums."""
    widths = [len(f[0]) for _,_,f in packets]
    sources = defaultdict(list)
    for q,(src,_,_) in enumerate(packets):
        if widths[q] >= 3:
            for pair in combinations(sorted(src),2):
                sources[pair].append(q)
    tariffs = {r:supported_interval(r,Fraction(".005")) for r in range(1,8)}
    benefit = {d:2*tariffs[d-1][0]-tariffs[d-2][1] for d in (3,4)}
    local_loss = 2*tariffs[1][1]
    covered = [set() for _ in packets]
    chosen, remaining = {}, dict(sources)
    while remaining:
        best = 0,None,()
        for pair, subs in remaining.items():
            allowed = tuple(q for q in subs if not covered[q].intersection(pair))
            value = sum(benefit[widths[q]] for q in allowed)-local_loss
            if value > best[0] or (value == best[0] and best[1] is not None and pair < best[1]):
                best = value,pair,allowed
        _,pick,subs = best
        if pick is None:
            break
        for q in subs:
            covered[q].update(pick)
        chosen[pick] = subs
        del remaining[pick]
        require(monotonic()<deadline,"two-line collector selection is bounded")
    return chosen, Counter(map(len,sources.values()))


class PairInputs:
    def __init__(self, active):
        self.use_count = Counter({p:len(q) for p,q in active.items()})
        self.forward = defaultdict(list)
        for p,subs in active.items():
            for q in subs:
                self.forward[q].append(p)
        self.live = {}
        self.high = 0
        self.counts = Counter()

    def __call__(self, q, target, frame, source_roles, source_charts, copy, add_frame, steps, alloc, frames):
        remaining = set(source_roles)
        for pair in self.forward[q]:
            require(set(pair)<=remaining,"disjoint appearance in the packet input sum")
            remaining.difference_update(pair)
            if pair not in self.live:
                rows = basis(frames[source_charts[i]][0][0] for i in pair)
                require(len(rows)==2,"two different source lines give a rank-two join")
                shared_chart = add_frame((rows,nullspace(rows)))
                owner = alloc()
                steps.append(("INIT",owner,shared_chart))
                for i in pair:
                    copy(owner,shared_chart,i,source_charts[i])
                self.live[pair] = owner,shared_chart
                self.high = max(self.high,len(self.live))
                self.counts["rank_one_parent_collection"] += 2
            owner, shared_chart = self.live[pair]
            copy(target,frame,owner,shared_chart)
            self.counts[f"rank_{len(frames[frame][0])-2}_parent_to_packet"] += 1
            self.use_count[pair] -= 1
            if not self.use_count[pair]:
                steps.append(("CLEAR",owner,shared_chart))
                del self.live[pair]
        for i in sorted(remaining):
            copy(target,frame,i,source_charts[i])
            self.counts["direct_collections"] += source_charts[i]!=frame


def main():
    deadline = monotonic()+45
    word = load_word()
    heads,*_ = fitting_calibration(word)
    packets,_,_ = tetrad_blocks(heads,True)
    feeders,residues,highs,reads = packet_syndromes(word,heads,packets)
    _,raw = joint_choices(packets,feeders,deadline)
    groups,covered = select_packets(raw,len(packets))
    public = (word,packets,groups,covered,feeders,residues,highs,reads)
    active, source_stats = plans(packets,deadline)
    old, old_info = replay(*shared_word(*public))
    clean = PairInputs(active)
    new, new_info = replay(*shared_word(*public,emit_packet=clean))
    dirty = PairInputs(active)
    dirty_paid,dirty_ops,dirty_peak,checked = replay_with_dirty(*shared_word(*public,retain_helpers=True,emit_packet=dirty))
    require(not any((clean.live,dirty.live,any(clean.use_count.values()),any(dirty.use_count.values()))),
            "shared owned parent lifetimes close in both interfaces")
    require(clean.counts==dirty.counts and sum(new.values())<sum(old.values()),"strict exact paid movement cut")
    paid_count = sum(new.values())
    out = {"status":"PASS_SHARED_SIGN_PAIR_COLLECTORS", "pair_candidates_by_packet_fanout":source_stats,
           "emitted_pairs_by_packet_fanout":Counter(map(len,active.values())),"literal_parent_collection":dict(clean.counts),
           "maximum_live_pair_owners":clean.high, "old_paid":dict(sorted(old.items())),"old":old_info,
           "new_paid_count":paid_count,"new_paid":dict(sorted(new.items())),"new":new_info,
           "prices":compare(new,old,{8:222}),
           "dirty":{"public_helpers":len(packets),"paid_count":sum(dirty_paid.values()),"paid":dict(sorted(dirty_paid.items())),
                    "ops":dirty_ops,"peak_owned":dirty_peak,"each_forward_reverse_coefficients":checked,
                    "prices":compare(dirty_paid,new+Counter({8:len(packets)}),{8:222+len(packets)})},
           "scope":"fixed E8 P111 main exchange, exact nine-syndrome projection, 190 original packets; retained dirty identities tested independently"}
    require(monotonic()<deadline,"finite collection and exact replays finish within deadline")
    print(json.dumps(out,sort_keys=True,indent=2))


if __name__=="__main__":
    main()
