# SPDX-License-Identifier: Apache-2.0
"""An exact diagonal relay and a cost boundary for alternative descent banks."""

from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
import sys
from time import monotonic


HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/"algebra")]
from selected_contact_ports import LOAD,NEED,replay,sensitivities
from snapshot_owner_shear import exact_replay
from syndrome_packets import compare, fitting_calibration, supported_interval
PRICE=run_path(str(HERE.parent/"helper_price.py"))


def circuit(word, two_way=False):
    """Each paid rank-one descent carries the actual X donor independently."""
    p=111
    n=2*p
    all_frames={int(i):(tuple(tuple(map(Fraction,x)) for x in d["B"]),
                        tuple(tuple(map(Fraction,x)) for x in d["A"]))
                for i,d in word["frames"].items()}
    start=word["start"][:n]
    end=word["final"][:n]
    bottom,top=start[p],end[0]
    NEED(all(len(all_frames[x][0])==1 for x in start[:p]),"line inputs")
    steps=[]
    t=n
    for i,home in enumerate(start[:p]):
        y=i+p
        steps.extend([("INIT",t,home),("ADD",t,i,home),("MOVE",t,home,bottom)])
        if two_way:
            steps.append(("MOVE",t,bottom,end[y]))
            steps.extend([("MOVE",y,bottom,top),("SWAP",i,y),("SWAP",y,t),("CLEAR",t,home)])
        else:
            steps.extend([("ADD",y,t,bottom),("CLEAR",t,bottom),("MOVE",y,bottom,end[y]),
                          ("MOVE",i,home,top)])
    return all_frames,steps,start,end,t+1


def bill(source,native,deadline):
    paid,_,_,_,p=replay(source,deadline)
    responses=sensitivities(source,deadline)
    NEED(len(paid)==len(responses)==2871,"complete compared word")
    dims={int(i):v["dim"] for i,v in source["frames"].items()}
    helpers=Counter(dims[b]-dims[a] for a,b in zip(source["start"][222:],source["final"][222:],strict=True))
    receipt=HERE.parent/"algebra/result.json"
    NEED(sha256(receipt.read_bytes()).hexdigest()=="a46b6c6040f75184cab5467656811ad988c216e3bc8e44d595a5015b6e49620b",
         "original source-bound caller price")
    selected=json.loads(receipt.read_bytes())
    n=selected["native_calls"]
    NEED(n==36,"selected finite caller")
    inherited=Counter({int(i):v for i,v in selected["paid"].items()})
    target=Counter({int(i):v for i,v in selected["targets"].items()})
    for r,c in p.items():
        inherited[r]-=n*c
    for r,c in helpers.items():
        target[r]-=n*c
    NEED(all(c>=0 for c in inherited.values()) and all(c>=0 for c in target.values()),
         "all connector and main counts remain")
    net=Counter(target)
    for r,c in native.items():
        inherited[r]+=n*c
    net.subtract(inherited)
    band={}
    for k in (".00385248",".005",".0227"):
        s=Fraction(k)
        a=PRICE["power_sum"](net,s)
        NEED(a[1]<0,"full selected caller substitution and no unproven extra helpers")
        band[k]={"fixed_grid_interval":a,"unit_denominator":PRICE["SCALE"],
                 "score_approx":a[1]/PRICE["SCALE"]}
    return band


def main():
    deadline=monotonic()+20
    w=LOAD()
    h,*_=fitting_calibration(w)
    a,control=exact_replay(*circuit(w),shear=True)
    x,info=exact_replay(*circuit(w,two_way=True))
    NEED(a=={1:111,7:222} and x=={1:111,7:111,8:111},"complete diagonal-only word")
    controls={}
    needed={}
    outer=bill(w,a,deadline)
    selected_receipt=json.loads((HERE.parent/"algebra/result.json").read_bytes())
    copies=selected_receipt["native_calls"]
    for d in (".005",".0227"):
        s=Fraction(d)
        t=supported_interval(1,s)[0]
        q=supported_interval(7,s)
        allowed=[111*t-9*q[1],111*t-9*q[0]]
        NEED(allowed[0]>0,"strict crossover comparison")
        controls[d]={"net_non_diagonal_budget_for_nine_cut_2pow80":allowed,
                     "net_non_diagonal_budget_lower":allowed[0]/2**80}
        charged=outer[d]["fixed_grid_interval"]
        unit=PRICE["SCALE"]
        needed[d]={"recurring_native_saving_for_selected_caller_at_least":-charged[1]/(unit*copies),
                   "largest_local_deficit_to_clear_selected_caller_at_most":111+charged[1]/(unit*copies)}
    print(json.dumps({"status":"PASS_P111_SINGLETON_RELAY_BASELINE","head_ports":len(h),
                      "shear":{"paid":a,"all_inputs":control,"credited_output":{7:222},
                               "local_price":compare(a,a,{7:222}),
                               "complete_selected_caller_substitution":outer},
                      "exchange":{"paid":x,"all_inputs":info},
                      "nine_cut_budget_relative_to_individual_diagonal_relays":controls,
                      "necessary_native_improvements_under_selected_caller":needed,
                      "scope":"unchanged main scalar and physical frame endpoints, owned singleton relay per port, no productive helper inventory"},
                     indent=2,sort_keys=True))


if __name__=="__main__":
    main()
