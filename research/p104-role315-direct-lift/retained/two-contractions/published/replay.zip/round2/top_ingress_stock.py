# SPDX-License-Identifier: Apache-2.0
"""Exact binary rank of the removable X modes at the BIT top ingress frontier."""

import argparse
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from itertools import combinations
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


TERMINAL = run_path(str(Path(__file__).with_name("terminal_multiflow.py")))
SWAP, PORTS = TERMINAL["SWAP"], TERMINAL["PORTS"]
MASK = (1 << PORTS) - 1


def pack_top_rows(word):
    n = word["public"]
    rows = [1 << i for i in range(n)] + [0] * word["owned_fields"]
    arrivals = []
    for index, (opcode, role, *rest) in enumerate(word["program"]):
        if opcode == "MOVE" and rest[1] == 1:
            arrivals.append((rest[0], rows[role], index))
        elif opcode == "ADD":
            rows[role] ^= rows[rest[0]]
        elif opcode == "SWAP":
            other = rest[0]
            rows[role], rows[other] = rows[other], rows[role]
        elif opcode in ("INIT", "CLEAR"):
            rows[role] = 0
    rank = TERMINAL["rank_with_witness"]
    SWAP["need"](len(arrivals) == len(rank(r for _, r, _ in arrivals)) == 545, "independent top input rows")
    SWAP["need"](not any((r >> PORTS) & MASK for _, r, _ in arrivals), "original Y is invisible at top ingress")
    SWAP["need"](len(rank(r & MASK for _, r, _ in arrivals)) == PORTS, "all X columns have total rank 111")
    return arrivals


def rank_delta(vectors, removed):
    rank = TERMINAL["rank_with_witness"]
    return PORTS - len(rank(row for j, row in enumerate(vectors) if row and not (removed >> j) & 1))


def freed_coordinate(vectors, removed):
    """Find the erased X functional, assuming the certificate has one free pivot."""
    matrix = TERMINAL["rank_with_witness"](r for j, r in enumerate(vectors) if not (removed >> j) & 1)
    absent = sorted(set(range(PORTS)) - matrix.keys())
    if len(absent) != 1:
        raise ValueError("one lost X mode is expected in this census")
    direction = 1 << absent[0]
    for key, row in sorted(matrix.items()):
        if (direction & row).bit_count() % 2:
            direction ^= 1 << key
    if not all((direction & r).bit_count() % 2 == 0 for j, r in enumerate(vectors) if not (removed >> j) & 1):
        raise ValueError("candidate kernel vector does not annihilate the frozen rows")
    return direction


def raw_pure_x_modes(rows, chosen):
    """Combine one chart or chart pair without touching a dirty helper token."""
    pivots = {}
    modes = []
    while chosen:
        low = chosen & -chosen
        row = rows[low.bit_length() - 1]
        chosen ^= low
        while row >> (2 * PORTS):
            pivot = row.bit_length() - 1
            if pivot not in pivots:
                pivots[pivot] = row
                break
            row ^= pivots[pivot]
        else:
            if not row & MASK:
                raise ValueError("all whole rows were independently certified")
            modes.append(row & MASK)
    return modes


def check_chunk(job):
    rows, base_groups, pairs, deadline = job
    votes = Counter()
    witnesses = []
    for at, (a, b) in enumerate(pairs):
        if at % 128 == 0 and monotonic() >= deadline:
            raise TimeoutError("aggregate two-chart scan deadline")
        delta = rank_delta(rows, base_groups[a] | base_groups[b])
        votes[delta] += 1
        if delta:
            witnesses.append((a, b, delta))
    return votes, witnesses


def robust_bases(vectors, seed=7546):
    """Independent quick survivors: a disjoint certified basis avoids every removal."""
    from random import Random

    rng = Random(seed)
    bases = []
    indexes = list(range(len(vectors)))
    for _ in range(40):
        rng.shuffle(indexes)
        basis = {}
        selected = 0
        for i in indexes:
            value = vectors[i]
            while value:
                pivot = value.bit_length() - 1
                if pivot not in basis:
                    basis[pivot] = value
                    selected |= 1 << i
                    break
                value ^= basis[pivot]
        if len(basis) != PORTS:
            raise ValueError("source rank control")
        bases.append(selected)
    return bases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--direct", action="store_true", help="measure every rank reduction by elimination")
    args = parser.parse_args()
    deadline = monotonic() + 80
    word = SWAP["load"](args.word)
    arrived = pack_top_rows(word)
    chart_masks = defaultdict(int)
    for i, (chart, _, _) in enumerate(arrived):
        chart_masks[chart] |= 1 << i
    by_chart = dict(sorted(chart_masks.items()))
    vectors = [row & MASK for _, row, _ in arrived]
    whole_rows = [row for _, row, _ in arrived]
    group_rank = {group: rank_delta(vectors, mask) for group, mask in by_chart.items()}
    pairs = list(combinations(by_chart, 2))
    start = perf_counter()
    bases = [] if args.direct else robust_bases(vectors)
    remaining = [(a, b) for a, b in pairs if all(mask & (by_chart[a] | by_chart[b]) for mask in bases)]
    accepted = len(pairs) - len(remaining)
    serial_hist, serial_witnesses = check_chunk((vectors, by_chart, remaining, deadline))
    serial_hist[0] += accepted
    serial_seconds = perf_counter() - start
    start = perf_counter()
    with ProcessPoolExecutor(max_workers=min(8, max(1, len(remaining)))) as pool:
        parallel_parts = list(pool.map(check_chunk, [(vectors, by_chart, remaining[i::8], deadline) for i in range(8)], timeout=55))
    parallel_hist, parallel_witnesses = Counter({0: accepted}), []
    for hist, candidates in parallel_parts:
        parallel_hist.update(hist)
        parallel_witnesses.extend(candidates)
    SWAP["need"](parallel_hist == serial_hist and sorted(parallel_witnesses) == serial_witnesses, "serial/parallel consistency")

    singleton_total = sum(group_rank.values())
    single_lost = {str(chart): freed_coordinate(vectors, by_chart[chart]) for chart, loss in group_rank.items() if loss}
    lost_witnesses = Counter(freed_coordinate(vectors, by_chart[a] | by_chart[b]) for a, b, _ in serial_witnesses)
    pure_local = {str(chart): list(map(hex, result)) for chart, mask in by_chart.items()
                  if (result := raw_pure_x_modes(whole_rows, mask))}
    pure_pairs = Counter(len(raw_pure_x_modes(whole_rows, by_chart[a] | by_chart[b])) for a, b in pairs)
    delta_support = {j for mode in lost_witnesses for j in range(PORTS) if (mode >> j) & 1}
    # Controls: an unaliased 111-coordinate bank and a mixed two-port mode.
    unit_vectors = [1 << j for j in range(PORTS)]
    SWAP["need"](rank_delta(unit_vectors, 1) == 1 and rank_delta(unit_vectors + [1], 1) == 0,
                 "independent and duplicated coordinate controls")
    SWAP["need"](rank_delta(unit_vectors + [1], 1 | 1 << PORTS) == 1, "two blocks can hide a stock direction")
    report = {"status": "PASS_BIT_TOP_INGRESS_STOCK", "source_sha256": SWAP["BASE"]["SOURCE_SHA"],
              "ingresses": len(arrived), "origin_charts": len(by_chart), "stock_by_chart": group_rank,
              "stock_due_to_all_separate_groups": singleton_total, "pair_witnesses": serial_witnesses,
              "single_lost_mode_bitmasks": single_lost,
              "different_pair_lost_modes": {hex(bits): count for bits, count in sorted(lost_witnesses.items())},
              "pure_x_local_chart_modes": pure_local, "pure_x_chart_pair_dimension_counts": pure_pairs,
              "lost_mode_port_union": sorted(delta_support),
              "group_size_histogram": Counter(mask.bit_count() for mask in by_chart.values()),
              "pair_count_by_stock": serial_hist, "serial_seconds": serial_seconds,
              "pairs_requiring_separate_elimination": len(remaining), "full_rank_basis_certificates": len(bases),
              "eight_worker_seconds": perf_counter() - start,
              "scope": "fixed source prefix on old X/helper inputs, arbitrary linear block code at departure frontier, hypothesized Y side input"}
    report["single_chart_modes"] = {chart: [j for j in range(PORTS) if (mask >> j) & 1]
                                    for chart, mask in single_lost.items()}
    args.output.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(report["status"], len(by_chart), singleton_total, serial_hist, serial_seconds, report["eight_worker_seconds"])


if __name__ == "__main__":
    main()
