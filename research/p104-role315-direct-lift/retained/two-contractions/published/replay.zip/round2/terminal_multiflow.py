# SPDX-License-Identifier: Apache-2.0
"""Certificate for the size of the Y bank reaching its intended BIT suffix."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
import json
from pathlib import Path
from runpy import run_path


SWAP = run_path(str(Path(__file__).with_name("bit_carrier_reversal.py")))
PORTS, PRICE = SWAP["PORTS"], SWAP["PRICE"]


def rank_with_witness(rows):
    pivots = {}
    for value in rows:
        while value:
            pivot = value.bit_length() - 1
            if pivot in pivots:
                value ^= pivots[pivot]
            else:
                pivots[pivot] = value
                break
    return pivots


def span_contains(basis, value):
    while value:
        pivot = value.bit_length() - 1
        if pivot not in basis:
            return False
        value ^= basis[pivot]
    return True


def terminal_transparent_reset(word):
    """Test whether old frame-local rows can erase the independent Y input."""
    n = word["public"]
    role_count = n + word["owned_fields"]
    at = word["start"][:] + [None] * (role_count - n)
    rows = [1 << i for i in range(n)] + [0] * (role_count - n)
    resident = defaultdict(set)
    for role, frame in enumerate(at):
        if frame is not None:
            resident[frame].add(role)
    target = {f: port for port, f in enumerate(word["final"][PORTS:2 * PORTS])}
    histories = defaultdict(set)
    maximal = defaultdict(int)
    local_witnesses, difference_witnesses = {}, {}
    simultaneous = defaultdict(int)

    def capture(frame, event):
        if frame not in target:
            return
        port = target[frame]
        y = port + PORTS
        others = {rows[r] for r in resident[frame] if r != y and rows[r]}
        histories[frame].update(others)
        if y not in resident[frame]:
            return
        basis = rank_with_witness(others)
        maximal[port] = max(maximal[port], len(basis))
        simultaneous[port] += 1
        if span_contains(basis, 1 << port):
            local_witnesses.setdefault(port, event)
        # Preserve the old X lane and repair Y in its final frame.
        if span_contains(basis, rows[y] ^ (1 << port)):
            difference_witnesses.setdefault(port, event)

    for index, event in enumerate(word["program"]):
        op, role, *rest = event
        if op == "MOVE":
            old, new = rest
            resident[old].remove(role)
            resident[new].add(role)
            at[role] = new
            capture(old, index)
            capture(new, index)
        elif op == "INIT":
            chart = rest[0]
            resident[chart].add(role)
            at[role] = chart
        elif op == "CLEAR":
            chart = rest[0]
            resident[chart].remove(role)
            at[role] = None
            rows[role] = 0
        elif op == "ADD":
            other, chart = rest
            rows[role] ^= rows[other]
            capture(chart, index)
        elif op == "SWAP":
            other = rest[0]
            a, b = at[role], at[other]
            resident[a].remove(role)
            resident[b].remove(other)
            resident[a].add(other)
            resident[b].add(role)
            at[role], at[other] = b, a
            rows[role], rows[other] = rows[other], rows[role]
            capture(a, index)
            capture(b, index)
    historical = []
    old_y = []
    for chart, port in target.items():
        span = rank_with_witness(histories[chart])
        if span_contains(span, 1 << port):
            historical.append(port)
        if span_contains(span, 1 << (port + PORTS)):
            old_y.append(port)
    SWAP["need"](all(simultaneous[port] > 0 for port in range(PORTS)), "sample every Y terminal chart")
    return {"historical_pure_x_ports": historical, "same_cut_pure_x_witnesses": local_witnesses,
            "historical_pure_y_ports": old_y, "same_cut_required_correction_witnesses": difference_witnesses,
            "states_with_y_at_own_hyperplane": sum(simultaneous.values()),
            "maximum_simultaneous_peer_rank": max(maximal.values())}


def terminal_interface(word):
    """Bind the zero / top / individual final-chart time separation."""
    program = word["program"]
    n = word["public"]
    y_columns = (1 << (2 * PORTS)) - (1 << PORTS)
    target = {chart: role for role, chart in enumerate(word["final"][PORTS:2 * PORTS], PORTS)}
    incoming = {f: [] for f in target}
    outgoing = {f: [] for f in target}
    y_touches = {}
    state = [1 << i for i in range(n)] + [0] * word["owned_fields"]
    full_during_y = []
    owned_top_in = []
    for index, (op, r, *args) in enumerate(program):
        if op == "MOVE":
            origin, dest = args
            if origin in outgoing:
                outgoing[origin].append([index, r, dest])
            if dest in incoming:
                incoming[dest].append([index, r, origin])
                if r == target[dest]:
                    y_touches[dest] = index
            if dest == 1:
                full_during_y.append((index, r, state[r] & y_columns))
                if r >= n:
                    owned_top_in.append(index)
        elif op == "ADD":
            state[r] ^= state[args[0]]
        elif op == "SWAP":
            other = args[0]
            state[r], state[other] = state[other], state[r]
        elif op in ("CLEAR", "INIT"):
            state[r] = 0
    SWAP["need"](len(y_touches) == 111, "all original Y owner arrivals")
    SWAP["need"](not owned_top_in, "no original owned push into full")
    SWAP["need"](not any(x[2] for x in full_during_y), "literal old Y has no full-chart input")
    bill = Counter()
    for chart, port in target.items():
        old = incoming[chart]
        arrivals = [e for e in old if e[1] != port]
        departures = outgoing[chart]
        SWAP["need"](len(arrivals) == len(departures) == 3 and all(e[2] == 1 for e in departures),
                     "a triple of through paths per port")
        SWAP["need"](max(e[0] for e in departures) < y_touches[chart], "late Y after the through paths")
        bill["through_rows"] += len(departures)
        bill["first_Y_to_output_after_last_through_min"] = min(
            bill.get("first_Y_to_output_after_last_through_min", len(program)),
            y_touches[chart] - max(e[0] for e in departures),
        )
    return bill


def floor_for_terminal_only_wrap(word):
    """A two-way independent port cannot be repaired from one whole send."""
    # At terminal time distinct Y hyperplanes have no fixed nonzero peers.
    # There are two distinct cross-block dependencies in F2:
    # full <- prior Y has rank 1, and Y <- prior full has rank 1.  Y's prior
    # t=y+x contains one bit of each symbol and is an independent coordinate
    # together with the old full x.  Each directed crossing costs a child.
    states = {}
    x, y = 1, 2
    t = x ^ y
    for forward, backward in ((False, False), (True, False), (False, True), (True, True)):
        full_span = rank_with_witness([x, t] if forward else [x])
        y_span = rank_with_witness([t, x] if backward else [t])
        states[f"{int(forward)}{int(backward)}"] = span_contains(full_span, y) and span_contains(y_span, x)
    SWAP["need"](states == {"00": False, "10": False, "01": False, "11": True}, "two-bank rank lower bound")

    # At the level of an arbitrary logical permutation across final charts,
    # separate two-way demands across disjoint ports need one outgoing
    # direction per port. Nested descents into another Y hyperplane cannot
    # cover it for free. This weak converse only counts independent rows.
    final_charts = word["final"][PORTS:2 * PORTS]
    SWAP["need"](len(set(final_charts)) == PORTS, "there are 111 separate receiving charts")
    return states


def prefix_suffix_decoupling(word):
    """Inspect the old source-only top event block as a linear system."""
    n = word["public"]
    role_count = n + word["owned_fields"]
    at = word["start"][:] + [None] * (role_count - n)
    origins = [1 << i for i in range(n)] + [0] * (role_count - n)
    gate_ids = []
    incoming_at_top = []
    for index, (op, r, *rest) in enumerate(word["program"]):
        if op == "ADD":
            s, chart = rest
            if chart == 1:
                gate_ids.append(index)
            origins[r] ^= origins[s]
        elif op == "MOVE":
            a, b = rest
            if b == 1:
                incoming_at_top.append(origins[r])
            at[r] = b
        elif op == "SWAP":
            s = rest[0]
            origins[r], origins[s] = origins[s], origins[r]
            at[r], at[s] = at[s], at[r]
        elif op in ("INIT", "CLEAR"):
            origins[r] = 0
            at[r] = rest[0] if op == "INIT" else None
    old_nodes = [origins[i] for i in range(n) if at[i] == 1]
    rank = len(rank_with_witness(incoming_at_top))
    final_rank = len(rank_with_witness(old_nodes))
    SWAP["need"](rank == len(incoming_at_top) == final_rank == len(old_nodes) == 545,
                 "every top arrival is an independent source coordinate")
    # Exact span equality, rather than merely two equal ranks.
    SWAP["need"](len(rank_with_witness(old_nodes + incoming_at_top)) == rank, "top same-row span")
    return {"physical_rank": rank, "ordinary_top_adds": len(gate_ids),
            "earliest_top_add": min(gate_ids), "latest_top_add": max(gate_ids)}


def measured_margin(paid, target, saving):
    cost = PRICE["power_sum"]
    return PRICE["subtract"](cost(target, Q(saving)), cost(paid, Q(saving)))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("word", type=Path)
    cli.add_argument("output", type=Path)
    args = cli.parse_args()
    word = SWAP["load"](args.word)
    fixed = terminal_interface(word)
    top = prefix_suffix_decoupling(word)
    reset = terminal_transparent_reset(word)
    ports_control = floor_for_terminal_only_wrap(word)
    runs = SWAP["rail_replay"](word)
    paid = runs[1]
    targets = Counter({2: 1, 4: 25, 6: 1, 8: 632})
    rows = {}
    for saving in ("0.005", "0.0227"):
        max_count = 0
        while measured_margin(paid + Counter({1: max_count + 1}), targets, saving)[0] > 0:
            max_count += 1
        rows[saving] = {"rank_one_repair_allowance": max_count,
                        "obligation_for_extra_direction_each_port": PORTS,
                        "needed_redirected_rank_one_sends_even_if_return_free": max(0, PORTS - max_count),
                        "one_new_direction_per_port_signed_margin": measured_margin(paid + Counter({1: PORTS}), targets, saving)}
    report = {"status": "PASS_EXACT_BIT_TERMINAL_MULTIFLOW", "source_sha256": SWAP["BASE"]["SOURCE_SHA"],
              "top_chart": top, "port_charts": fixed, "terminal_reset": reset, "relaxed_cost": rows,
              "two_bank_directed_control": ports_control,
              "denominator": PRICE["SCALE"]}
    args.output.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
