# SPDX-License-Identifier: Apache-2.0
"""Turn the selected finite BIT shear into a complete two-way exchange."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
import gzip
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path


WORK = Path(__file__).resolve().parents[1]
BASE = run_path(str(WORK / "bit_swap_transport.py"))
PRICE = run_path(str(WORK / "helper_price.py"))
PORTS = 111


def need(ok, message):
    if not ok:
        raise ValueError(message)


def load(path):
    raw = path.read_bytes()
    need(sha256(raw).hexdigest() == BASE["SOURCE_SHA"], "frozen BIT source")
    return json.loads(gzip.decompress(raw))


def collect_hyperplane_groups(word):
    """Look at the last common-frame visit of each X before it enters full."""
    programs = word["program"]
    y_groups = defaultdict(list)
    x_groups = defaultdict(list)
    for i, event in enumerate(programs):
        op, role, *rest = event
        if op != "MOVE":
            continue
        a, b = rest
        if role < PORTS and b == 1:
            x_groups[a].append((role, i))
        # The output class is a port-specific hyperplane, but early lanes
        # may leave zero without being observed by any hop into the full chart.
        if PORTS <= role < 2 * PORTS and a == 0:
            y_groups[b].append((role - PORTS, i))
    return x_groups, y_groups


def rail_replay(word):
    """Replay the exact XOR program, optionally recording nontrivial Y support."""
    n = word["public"]
    rows = [1 << i for i in range(n)] + [0] * word["owned_fields"]
    active = word["start"][:] + [None] * word["owned_fields"]
    highs = defaultdict(list)
    by_frame = defaultdict(int)
    ymask = (1 << (2 * PORTS)) - (1 << PORTS)
    paid = Counter()
    ops = Counter()
    max_owned = current_owned = 0
    for i, (op, role, *rest) in enumerate(word["program"]):
        ops[op] += 1
        if op == "ADD":
            source, frame = rest
            need(active[role] == active[source] == frame, "ADD needs a common live chart")
            rows[role] ^= rows[source]
        elif op == "SWAP":
            other, = rest
            rows[role], rows[other] = rows[other], rows[role]
            active[role], active[other] = active[other], active[role]
        elif op == "MOVE":
            a, b = rest
            need(active[role] == a, "MOVE source chart")
            d = abs(word["frames"][str(a)]["dim"] - word["frames"][str(b)]["dim"])
            need(d > 0, "positive MOVE rank")
            paid[d] += 1
            if rows[role] & ymask:
                by_frame[b] |= rows[role] & ymask
            if b == 1:
                highs["main" if role < PORTS else "helper"].append((i, role, rows[role] & ymask))
            active[role] = b
        elif op == "INIT":
            f, = rest
            need(role >= n and active[role] is None and rows[role] == 0, "owned INIT")
            active[role] = f
            current_owned += 1
            max_owned = max(max_owned, current_owned)
        elif op == "CLEAR":
            f, = rest
            need(role >= n and active[role] == f, "owned CLEAR")
            rows[role] = 0
            active[role] = None
            current_owned -= 1
        else:
            raise ValueError(f"Unknown opcode {op}")
    need(active[:n] == word["final"] and all(x is None for x in active[n:]) and current_owned == 0,
         "output frames and all owned lifetimes")
    return rows[:n], paid, ops, max_owned, highs, by_frame


def terminal_clocks(word):
    by_chart = defaultdict(list)
    target_chart = {f: i for i, f in enumerate(word["final"][PORTS:2 * PORTS])}
    for index, event in enumerate(word["program"]):
        if event[0] == "MOVE" and event[2] in target_chart and event[3] == 1:
            by_chart[event[2]].append(index)
    witnesses = []
    for chart, port in target_chart.items():
        role = port + PORTS
        arrivals = [i for i, e in enumerate(word["program"]) if e[0] == "MOVE" and e[1] == role and e[3] == chart]
        need(len(arrivals) == 1 and len(by_chart[chart]) == 3 and max(by_chart[chart]) < arrivals[0],
             "every send leaves before the Y field arrives")
        witnesses.append([port, chart, arrivals[0], by_chart[chart]])
    return witnesses


def emit_complete_swap(word):
    """Complete the literal shear by two rank-one sends per port."""
    w = {**word, "frames": word["frames"].copy(), "program": word["program"][:]}
    n = word["public"]
    slot = n + word["owned_fields"]
    w["owned_fields"] += 1
    for port in range(PORTS):
        x, y = port, port + PORTS
        end = w["final"][y]
        # Send t=y+x to X and let X become y.  Then the same owned role
        # carries the new X back, so t+y=x in the lower chart.
        w["program"].extend([
            ["INIT", slot, end], ["ADD", slot, y, end], ["MOVE", slot, end, 1],
            ["ADD", x, slot, 1], ["CLEAR", slot, 1], ["INIT", slot, 1],
            ["ADD", slot, x, 1], ["MOVE", slot, 1, end], ["ADD", y, slot, end], ["CLEAR", slot, end],
        ])
    return w


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    word = load(args.word)
    rows, paid, ops, peak, highs, by_frame = rail_replay(word)
    need(rows == BASE["endpoint"](word, False), "literal complete scalar endpoint")
    need(not any((e[0] == "ADD" and PORTS <= e[2] < 2 * PORTS) or
                 (e[0] == "SWAP" and any(PORTS <= r < 2 * PORTS for r in e[1:])) for e in word["program"]),
         "every literal Y is a write-only accumulator")
    swap = emit_complete_swap(word)
    swapped, swap_paid, swap_ops, swap_peak, _, _ = rail_replay(swap)
    need(swapped == BASE["endpoint"](word, True), "complete exchange including 437 arbitrary helper inputs")
    need(swap_paid - paid == {1: 222}, "all added rank-one calls counted")
    mutated = {**swap, "program": swap["program"][:-2] + swap["program"][-1:]}
    need(rail_replay(mutated)[0] != swapped, "last repair is independently necessary")
    targets = {2: 1, 4: 25, 6: 1, 8: 632}
    margin = {s: PRICE["subtract"](PRICE["power_sum"](targets, Q(s)), PRICE["power_sum"](swap_paid, Q(s)))
              for s in ("0.005", "0.0227")}
    need(all(hi < 0 for _, hi in margin.values()), "complete rewrite has to be priced before admission")
    x_groups, y_groups = collect_hyperplane_groups(word)
    clocks = terminal_clocks(word)
    need(len(clocks) == PORTS, "all 111 terminal ports")
    report = {
        "status": "PASS_EXACT_BIT_TWO_BANK_TRANSPORT_INVENTORY",
        "source_sha256": BASE["SOURCE_SHA"],
        "paid": paid, "ops": ops, "peak_owned": peak,
        "x_terminal_ingress_by_rank": Counter(word["frames"][str(f)]["dim"] for f, group in x_groups.items() for _ in group),
        "y_first_move_by_rank": Counter(word["frames"][str(f)]["dim"] for f, group in y_groups.items() for _ in group),
        "old_y_symbols_at_full": by_frame[1].bit_count(),
        "Y_is_write_only": True,
        "full_ingress_count": {k: len(v) for k, v in highs.items()},
        "terminal_clocks": clocks,
        "literal_exchange": {"paid": swap_paid, "productive": targets, "ops": swap_ops, "owned_peak": swap_peak,
                             "moment_denominator": PRICE["SCALE"], "moment_intervals": margin,
                             "complete_scalar_endpoint": "111 swaps and 437 identity helper rows"},
    }
    args.output.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(report["status"], "literal paid", sum(swap_paid.values()), "ports", PORTS)


if __name__ == "__main__":
    main()
