# SPDX-License-Identifier: Apache-2.0
"""Check when a rollback can transpose an asymmetric BIT boundary via complementary charts."""

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
from runpy import run_path


SWAP = run_path(str(Path(__file__).with_name("bit_carrier_reversal.py")))
PORTS = SWAP["PORTS"]


def solve(rows, value):
    basis = {}
    for role, row in rows:
        use = 1 << role
        while row:
            pivot = row.bit_length()
            if pivot not in basis:
                basis[pivot] = row, use
                break
            prev, origin = basis[pivot]
            row ^= prev
            use ^= origin
    use = 0
    while value:
        pair = basis.get(value.bit_length())
        if pair is None:
            return None
        row, origin = pair
        value ^= row
        use ^= origin
    return [r for r in range(use.bit_length()) if (use >> r) & 1]


def scalar_record(word):
    n = word["public"]
    rows = [1 << r for r in range(n)] + [0] * word["owned_fields"]
    live = word["start"][:] + [None] * word["owned_fields"]
    present = defaultdict(set)
    for role, frame in enumerate(word["start"]):
        present[frame].add(role)
    clears = {}
    stats = Counter()
    for index, (op, role, *args) in enumerate(word["program"]):
        if op == "ADD":
            other, _ = args
            rows[role] ^= rows[other]
        elif op == "MOVE":
            old, new = args
            present[old].remove(role)
            present[new].add(role)
            live[role] = new
        elif op == "SWAP":
            other, = args
            a, b = live[role], live[other]
            present[a].remove(role)
            present[b].remove(other)
            present[a].add(other)
            present[b].add(role)
            live[role], live[other] = b, a
            rows[role], rows[other] = rows[other], rows[role]
        elif op == "INIT":
            frame, = args
            stats["init"] += 1
            present[frame].add(role)
            live[role] = frame
        elif op == "CLEAR":
            frame, = args
            present[frame].remove(role)
            recipe = solve([(peer, rows[peer]) for peer in sorted(present[frame])], rows[role])
            stats["clear"] += 1
            stats["nonzero"] += bool(rows[role])
            stats["reconstructible"] += recipe is not None
            stats["nonzero_reconstructible"] += recipe is not None and bool(rows[role])
            clears[index] = {"role": role, "chart": frame, "nonzero": bool(rows[role]), "recipe": recipe}
            rows[role] = 0
            live[role] = None
    SWAP["need"](rows[:n] == SWAP["BASE"]["endpoint"](word, False), "complete forward endpoint")
    return stats, clears


def complement(word, recipes):
    """Reverse every chronological gate with an exact coframed undo for CLEAR."""
    n = word["public"]
    frames = {}
    for chart, record in word["frames"].items():
        frames[chart] = {"B": record["A"], "A": record["B"], "dim": 8 - record["dim"]}
    result = {**word, "frames": frames, "start": word["final"], "final": word["start"], "program": []}
    emit = result["program"].append
    for index in range(len(word["program"]) - 1, -1, -1):
        op, role, *args = word["program"][index]
        if op == "MOVE":
            a, b = args
            emit([op, role, b, a])
        elif op == "INIT":
            emit(["CLEAR", role, *args])
        elif op == "CLEAR":
            chart, = args
            emit(["INIT", role, chart])
            recipe = recipes[index]["recipe"]
            if recipe is None:
                raise ValueError(f"cannot reconstruct owned value at original CLEAR {index}")
            for peer in recipe:
                emit(["ADD", role, peer, chart])
        else:
            emit([op, role, *args])
    SWAP["need"](len(result["start"]) == len(result["final"]) == n, "preserved owners")
    return result


def lower_bound(clears, word):
    # At each original reset, the added reverse birth must supply the old
    # chart-local value.  The explicit recipe above is sufficient with no
    # child. When it is unavailable, merely setting it to zero changes the
    # inverse chronological trajectory. It does not rule out a new inverse.
    ranks = Counter(word["frames"][str(record["chart"])]["dim"]
                    for record in clears.values() if record["recipe"] is None)
    return ranks


def self_test():
    toy = {"public": 2, "owned_fields": 1, "start": [0, 0], "final": [1, 1],
           "frames": {"0": {"dim": 0, "A": [], "B": []}, "1": {"dim": 8, "A": [], "B": []}},
           "program": [["INIT", 2, 0], ["ADD", 2, 0, 0], ["MOVE", 0, 0, 1],
                       ["MOVE", 1, 0, 1], ["MOVE", 2, 0, 1], ["CLEAR", 2, 1]]}
    reversed_word = complement(toy, {5: {"recipe": [0]}})
    reverse_rows = SWAP["rail_replay"](reversed_word)[0]
    SWAP["need"](reverse_rows == [1, 2], "coframed lifetime inversion control")
    SWAP["need"](solve([(0, 1), (1, 2)], 3) == [0, 1] and solve([(0, 1)], 2) is None,
                 "solvable and missing history control")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    self_test()
    word = SWAP["load"](args.word)
    counts, clears = scalar_record(word)
    failed = lower_bound(clears, word)
    reversal = None
    if not failed:
        reversed_word = complement(word, clears)
        output, paid, operations, peak, _, _ = SWAP["rail_replay"](reversed_word)
        SWAP["need"](output == SWAP["BASE"]["endpoint"](word, False), "complemented inverse endpoint")
        reversal = {"paid": paid, "ops": operations, "owned_peak": peak}
    report = {"status": "PASS_BIT_INVERSE_COMPLEMENT_RESET_SCREEN", "source_sha256": SWAP["BASE"]["SOURCE_SHA"],
              "reset_counts": counts, "unconstructible_erase_frame_dimensions": failed,
              "reconstructible_births": [i for i, r in clears.items() if r["recipe"] is not None],
              "complete_complemented_inverse": reversal,
              "scope": "restore the entire old state in reverse chronology with only unchanged colocated rows"}
    args.output.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
