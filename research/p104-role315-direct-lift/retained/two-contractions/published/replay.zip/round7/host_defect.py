# SPDX-License-Identifier: Apache-2.0
"""Exact sector controls for a saturated caller with disjoint-shear hosts."""

from itertools import combinations
import json


def need(ok, message):
    if not ok:
        raise ValueError(message)


def identity(n):
    return [[int(i == j) for j in range(n)] for i in range(n)]


def mm(a, b, p):
    return [[sum(x * y for x, y in zip(row, col, strict=True)) % p for col in zip(*b)] for row in a]


def add(a, b, p, factor=1):
    return [[(x + factor * y) % p for x, y in zip(row, other, strict=True)]
            for row, other in zip(a, b, strict=True)]


def transpose(a):
    return [list(row) for row in zip(*a)]


def take(a, rows, cols):
    return [[a[i][j] for j in cols] for i in rows]


def rank(rows, p):
    basis = {}
    for row in rows:
        v = row[:]
        for j in range(len(v)):
            x = v[j]
            x %= p
            if not x:
                continue
            if j not in basis:
                w = pow(x, -1, p)
                basis[j] = [(w * y) % p for y in v]
                break
            v = [(a - x * b) % p for a, b in zip(v, basis[j], strict=True)]
    return len(basis)


def kron_eye(a, width):
    size = len(a) * width
    return [[a[i // width][j // width] if i % width == j % width else 0
             for j in range(size)] for i in range(size)]


def factor_gram(a, p, n):
    """Factor a clock Gram into full-size role columns and rows."""
    pick = []
    for j, col in enumerate(transpose(a)):
        if rank((*pick, col), p) > len(pick):
            pick.append(col)
    b = transpose(pick)
    need(len(pick) == n, "unexpected full relative Gram rank")
    m = len(a)
    dense = [x[:] + y[:] for x, y in zip(b, a, strict=True)]
    for j in range(n):
        k = next(i for i in range(j, m) if dense[i][j])
        dense[j], dense[k] = dense[k], dense[j]
        h = pow(dense[j][j], -1, p)
        dense[j] = [(h*x) % p for x in dense[j]]
        for i in range(m):
            if i != j:
                c = dense[i][j]
                dense[i] = [(x - c*y) % p for x, y in zip(dense[i], dense[j], strict=True)]
    u = [row[n:] for row in dense[:n]]
    need(mm(b, u, p) == a, "inexact rank factorization")
    return u, b


def clock_fixture(r, groups, thin_at, thin_width, p):
    """Assign each of r defect coordinates an odd alternating sector clock."""
    full = list(range(r))
    pattern = []
    for i in range(groups + 1):
        if i == thin_at:
            # Add two thin events for every gauge coordinate in deliberately different order.
            thin = full[:thin_width]
            pattern.extend([j] for j in (*thin, *reversed(thin)))
        if i < groups:
            pattern.append(full)
    starts = []
    flat = []
    for axes in pattern:
        starts.append(tuple(range(len(flat), len(flat) + len(axes))))
        flat.extend(axes)
    m, n = len(flat), len(flat) - r
    gram = []
    for i, x in enumerate(flat):
        gram.append([((1 if p == 2 else 2 * (1 if j > i else -1)) % p)
                     if x == y and i != j else 0 for j, y in enumerate(flat)])
    u, v = factor_gram(gram, p, n)
    return pattern, starts, flat, u, v, gram


def replay(r, groups, thin_at, thin_width, p):
    clock, at, flat, u, v, gram = clock_fixture(r, groups, thin_at, thin_width, p)
    n = len(u)
    ident = identity(n)
    roles = tuple(range(n))
    axes = tuple(range(r))
    full = [j for j, g in enumerate(clock) if len(g) == r]
    need(len(full) == groups, "fixture uses an ambiguous block width")
    prefix = [[0] * n for _ in range(n)] if p == 2 else ident
    defect = [[0] * r for _ in range(r)]
    observed = []
    wrong = False
    for j, selected in enumerate(at):
        x, y = take(u, roles, selected), take(v, selected, roles)
        pair = mm(y, x, p)
        need(not any(map(any, pair)), "full block is not a simultaneous disjoint shear")
        if j in full:
            observed.append((j, prefix, defect))
        block = mm(x, y, p)
        counts = [int(i in clock[j]) for i in axes]
        e = [[c * int(i == k) for k in axes] for i, c in enumerate(counts)]
        if p == 2:
            prefix = add(prefix, block, p)
            defect = add(defect, e, p)
        else:
            prev = prefix
            prefix = mm(add(ident, block, p), prefix, p)
            if j == len(at) - 1:
                wrong = mm(add(ident, block, p, -1), prev, p) != prefix
            defect = add(defect, mm(e, add(identity(r), defect, p, -1), p), p, 2)
    need(prefix == [[int(a == b) * (1 if p == 2 else p - 1) for b in roles]
                    for a in roles], "wrong all-odd relative return")
    checks = 0
    for (j, _, _), (i, mid, s), (k, _, _) in combinations(observed, 3):
        subset = (*at[j], *at[i], *at[k])
        need(rank(take(gram, subset, subset), p) == 2*r, "wrong principal triple rank")
        cols, rows = take(u, roles, subset), take(v, subset, roles)
        ext = [flat[a] for a in range(len(flat)) if a not in subset]
        want = 2*r+len(set(ext))
        need(rank(cols, p) == rank(rows, p) == want, "external defect rank formula")
        x = take(u, roles, at[i])
        responses = [mm(take(v, at[b], roles), mm(mid, x, p), p) for b in (j, k)]
        if p == 2:
            need(responses == [add(s, identity(r), p), s], "binary middle chronological difference")
        else:
            theory = [add([[0] * r for _ in axes], add(s, identity(r), p, -1), p, 2),
                      add([[0] * r for _ in axes], add(s, identity(r), p), p, -2)]
            need(responses == theory, "signed middle chronological difference")
        checks += 1
    need(groups == 3 or checks >= 4, "missing overlapping chronology cases")
    need(p == 2 or wrong, "signed normalization mutation was not detected")
    return {"field": p, "block_width": r, "full_blocks": groups, "mixed_thin_clock": thin_at,
            "thin_width": thin_width, "roles": n, "principal_triples": checks,
            "last_orientation_rejected": wrong}


def minimal_counterexample(p, r):
    if p == 2:
        # Work over F2[eps]/eps² on one pair. The other pair has the same three contacts.
        upper = [[1, 1], [0, 1]]
        lower = [[1, 0], [1, 1]]
        du = [[0, 1], [0, 0]]
        dl = transpose(du)
        zero = [[0, 0], [0, 0]]
        nominal, odd = identity(2), zero
        for plain, derivative in ((upper, du), (lower, dl), (upper, du), ([[0, 1], [1, 0]], zero)):
            odd = add(mm(plain, odd, p), mm(derivative, nominal, p), p)
            nominal = mm(plain, nominal, p)
        need(nominal == odd == identity(2), "three-block BIT endpoint or derivative changed")
    else:
        q = next(x for x in range(1, p) if (x*x+1) % p == 0)
        for sector in (q, -q):
            upper = [[1, sector], [0, 1]]
            lower = [[1, 0], [sector, 1]]
            swap = [[0, 1], [1, 0]]
            actual = mm(swap, mm(upper, mm(lower, upper, p), p), p)
            want = [[sector % p, 0], [0, sector % p]]
            need(actual == want, "three-block signed endpoint changed")
    # All three Laurent factors act on the same 2r slots, so they factor out.
    return {"field": p, "full_blocks": 3, "width": r, "roots": 2*r, "distinct_single_use_bodies": 3}


def main():
    cases = [replay(r, count, at, width, p) for p in (2, 5, 13) for r in (2, 3, 4)
             for count, at, width in ((3, None, 0), (3, 1, 1), (3, 2, r),
                                      (5, None, 0), (5, 2, r))]
    positive = [minimal_counterexample(p, 2) for p in (2, 5, 13)]
    print(json.dumps({"status": "PASS_SATURATED_DISJOINT_HOST_DEFECT", "exact_finite_fields": cases,
                      "three_block_counterexample": positive,
                      "verified_clock_triples": sum(x["principal_triples"] for x in cases)}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
