# SPDX-License-Identifier: Apache-2.0
"""Source-bound obstruction to using only one central character across Type A ports."""

import argparse
from collections import Counter
import gzip
from hashlib import sha256
import json
from pathlib import Path


WORD = "6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32"
CALLER = "255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc"
DIM = 9


def require(ok, text):
    if not ok:
        raise ValueError(text)


def pin(path, expected):
    blob = path.read_bytes()
    require(sha256(blob).hexdigest() == expected, "changed source " + str(path))
    return blob


def bitdot(a, b):
    return (a & b).bit_count() % 2


def rank2(rows):
    basis = {}
    for row in rows:
        while row:
            j = row.bit_length() - 1
            if j not in basis:
                basis[j] = row
                break
            row ^= basis[j]
    return len(basis)


def candidate(heads, center):
    """A common character's worst blind sign toggle and total average deficit."""
    rows = []
    for v in range(1, 1 << DIM):
        if not bitdot(v, center):
            moved = sum(bitdot(v, q) for q in heads)
            rows.append((moved, v))
    return max(rows), sum(n for n, _ in rows), len(rows)


def rank_controls(heads):
    centers = list(range(1, 1 << DIM))
    rows = [(candidate(heads, u), u) for u in centers]
    w, best = min(rows)
    require(w[0][0] == 54 and best == 49, "candidate minimum")
    hist = Counter(score[0][0] for score, _ in rows)
    by_frequency = Counter(sum(bitdot(v, q) for q in heads) for v in centers)
    require(sum(hist.values()) == 511 and len(set(heads)) == 96, "full 9-dimensional central census")
    eligible = [(score, u) for score, u in rows if bitdot(u, u)]
    opt_score, opt_u = min(eligible)
    tied = [u for score, u in eligible if score[0][0] == opt_score[0][0]]
    _, toggle = opt_score[0]
    require(not bitdot(toggle, opt_u), "blind-sector certificate perturbs common character")
    require(hist == {54: 1, 55: 15, 57: 240, 96: 255}, "changed worst sector counts")
    return {"all_nonzero_characters": len(centers), "odd_norm_candidate_characters": len(eligible),
            "native_A_character_span": rank2(heads),
            "largest_blind_toggle_counts_by_common_character": dict(sorted(hist.items())),
            "character_response_weight_census": dict(sorted(by_frequency.items())),
            "best_unrestricted_common_character": best, "best_unrestricted_blind_ports": w[0][0],
            "minimum_odd_norm_worst_blind_ports": opt_score[0][0],
            "example_minimum_candidate": opt_u, "example_maximizing_blind_toggle": toggle,
            "minimum_odd_norm_candidates": tied,
            "normalized_endpoint_defect_rank_for_32_roots": 32 * opt_score[0][0]}


def two_port_controls(heads):
    """Literal pair control with separate phase multipliers on four addresses."""
    result = []
    for overlap in (0, 1):
        a, b = next((a, b) for a in heads for b in heads if a < b and bitdot(a, b) == overlap)
        # A physical common q equals a. Pick representatives of all four sign sectors.
        reps = {}
        for x in range(1 << DIM):
            reps.setdefault((bitdot(x, a), bitdot(x, b)), x)
        require(len(reps) == 4, "two distinct header characters must vary independently")
        # Over F5, i=2. Replay the upper/lower/upper word for arbitrary pairs.
        def pair(vec, q):
            x, y = vec
            x = (x + q*y) % 5
            y = (y + q*x) % 5
            x = (x + q*y) % 5
            return y, x

        columns = 0
        for z in reps:
            angles = tuple((2 * (-1)**e) % 5 for e in z)
            for j in range(4):
                v = tuple(int(j == i) for i in range(4))
                target = tuple(angles[i // 2] * x for i, x in enumerate(v))
                got = pair(v[:2], angles[0]) + pair(v[2:], angles[1])
                require(got == target, "arbitrary-input three-shear positive control")
                common = pair(v[:2], angles[0]) + pair(v[2:], angles[0])
                translation = (-1) ** (z[0] ^ z[1])
                repair = common[:2] + tuple(x * translation % 5 for x in common[2:])
                require(repair == target, "translated complete two-port returns")
                if j >= 2:
                    require((common != target) == (z[0] != z[1]), "second-port sign control")
                columns += 1
        required = {z: tuple(pow(2 * (-1)**e, -1, 5) for e in z) for z in reps}
        common = {z: (required[z][0], required[z][0]) for z in reps}
        mismatch = {z: tuple((x * pow(y, -1, 5)) % 5 for x, y in zip(required[z],common[z],strict=True))
                    for z in reps}
        require(all(x == (1, 4 if z[0] != z[1] else 1) for z, x in mismatch.items()),
                "literal common-header residual must be one translation character")
        for z in reps:
            require(tuple((x*y)%5 for x,y in zip(common[z],mismatch[z],strict=True)) == required[z],
                    "full independent phase pair repair")
        result.append({"original_axes": [a,b], "dot": overlap, "all_four_fibers": len(reps),
                       "all_column_checks": columns,
                       "changed_second_output_fibers_without_translation": sum(v != (1,1) for v in mismatch.values()),
                       "restoring_rank_zero_translation_mask": a ^ b})
    return result


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("word", type=Path)
    args.add_argument("caller", type=Path)
    options = args.parse_args()
    word = json.loads(gzip.decompress(pin(options.word, WORD)))
    caller = json.loads(pin(options.caller, CALLER))
    ports = caller["types"]["A"]["ports"]
    require(ports == word["hosted"]["Dports"] and caller["ambient_rank"] == 145, "Type A source binding")
    heads = [word["ports"][i] for i in ports]
    require(all(0 < q < 1 << DIM and bitdot(q,q) for q in heads), "actual rank-one phase axes")
    print(json.dumps({"status": "PASS_P104_CENTRAL_CHARACTER_CALIBRATION", "axis_census": rank_controls(heads),
                      "literal_two_port_center_phases": two_port_controls(heads)}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
