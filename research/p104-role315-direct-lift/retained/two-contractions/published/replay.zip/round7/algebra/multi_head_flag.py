"""Exact certification of small-group oriented parity crossing bounds."""

from fractions import Fraction
from functools import cache
from itertools import product
import json
from math import comb
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from directed_flag_dual import require, supported_interval


def selector(k):
    return [(a,b,s) for a in range(k+1) for b in range(9-k) if a+b for s in (0,1)]


def move_classes(k):
    for i in range(k+1):
        for d in range(k+1-i):
            for j in range(9-k):
                for e in range(9-k-j):
                    if d+e:
                        for up in (False,True):
                            yield (i,d,k-i-d), (j,e,8-k-j-e), up


@cache
def subcount(v, triple):
    inner,added,rest = triple
    out = [[0,0],[0,0]]
    for i in range(min(v,inner)+1):
        for j in range(min(v-i,added)+1):
            h=v-i-j
            if h <= rest:
                out[i%2][(i+j)%2] += comb(inner,i)*comb(added,j)*comb(rest,h)
    return tuple(tuple(r) for r in out)


def cross(move, selection):
    active,spectator,up = move
    a,b,side = selection
    r,s = subcount(a,active),subcount(b,spectator)
    num=0
    for i,j in product((0,1),repeat=2):
        u,v = i ^ side, 1 ^ j ^ side
        num += r[i][j]*s[u][v] if up else r[j][i]*s[v][u]
    return Fraction(num,comb(sum(active),a)*comb(sum(spectator),b))


def endpoint(k, selections):
    a,b,side = selections
    odd=(a+b)%2
    return a if side else 2*(k-a)*odd + a*(1-odd)


def main():
    pins=json.loads((HERE/"multi-head-flag-weights.json").read_text(encoding="utf-8-sig"))
    results=[]
    helper=[]
    caps={}
    helper_caps={}
    for entry in pins:
        k,s=entry["group"],entry["s"]
        constraints=list(move_classes(k))
        W=[(tuple(o),Fraction(w)) for o,w in entry["dual"]]
        require(all(o in selector(k) and v>0 for o,v in W),"positive allowed selector orbit weight")
        h=[(0,0)]+[supported_interval(i,Fraction(s)) for i in range(1,9)]
        slacks=[]
        example=[]
        for m in constraints:
            n=m[0][1]+m[1][1]
            d=sum(w*cross(m,q) for q,w in W)
            z=Fraction(h[n][0],2**80)-d
            require(z>=0,"floating scout serialization did not yield a certified dual")
            slacks.append(z)
            if m[0][0]==m[1][0]==0 and m[-1] and n==8:
                example.append(Fraction(h[n][1],2**80)-d)
        v=sum(w*endpoint(k,q) for q,w in W)
        simple=Fraction(k)+2*k*Fraction(h[7][1],2**80)
        caps[s]=max(caps.get(s,Fraction(0)),(simple-v)/k)
        results.append({"group":k,"s":s,"move_orbits":len(constraints),
                        "dual_terms":len(W),"minimum_feasibility_slack":float(min(slacks)),
                        "max_improvement_vs_singletons":float(simple-v),
                        "max_improvement_per_port":float((simple-v)/k)})
        require(len(example)==1, "unique zero→full helper return")
        helper_caps[s]=max(helper_caps.get(s,Fraction(0)),example[0])
        helper.append({"group":k,"s":s,"zero_to_full_credit_undetected":float(example[0])})
    require(set(caps)=={".005",".0227"} and len(results)==16,"all eight group sizes at both rates")
    relaxed={s:111*caps[s]+444*helper_caps[s] for s in caps}
    require(relaxed[".005"]<Fraction(".514") and relaxed[".0227"]<Fraction("2.251"),
            "combined host-sized helper allowance")
    doc={"status":"PASS_MULTI_HEAD_DIRECTED_FLAG_DUAL",
         "scope":"isolated mutually orthogonal main heads, arbitrary rational nested moves and independent 0→full helper returns",
         "groups":results,"helper":helper,
         "uniform_gain_cap_for_111":{s:float(111*v) for s,v in caps.items()},
         "uniform_gain_cap_for_111_and_444_helpers":{s:float(v) for s,v in relaxed.items()}}
    print(json.dumps(doc,indent=2))


if __name__=="__main__":
    main()
