"""Two-way contact permits only correspondingly priced off-diagonal travel."""

from collections import Counter
from itertools import combinations, product
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE.parents[1]/"round6"))
from directed_flag_dual import require, load_word
from syndrome_packets import fitting_calibration
from permute_head_frames import dot
from staged_two_way_routes import binary_rank


def fitting_rank_for_triplet(heads):
    edges = [(i,j) for i,j in combinations(range(3),2) if not dot(heads[i],heads[j])]
    available = list(edges)+[(b,a) for a,b in edges]
    best=3
    seen=0
    for flags in product((0,1),repeat=len(available)):
        A=[1<<i for i in range(3)]
        for z,(a,b) in zip(flags,available,strict=True):
            if z:
                A[a]|=1<<b
        best=min(best,binary_rank(A))
        seen+=1
    return len(edges),best,seen


def controls():
    h,*_=fitting_calibration(load_word())
    h=[tuple(int(x*2) for x in w)for w in h]
    all_types=Counter()
    for A in combinations(range(len(h)),3):
        lines=[h[i] for i in A]
        typ = tuple(sorted(sum(not dot(lines[i],lines[j]) for j in range(3) if i!=j)
                           for i in range(3)))
        all_types[typ]+=1
    reprs={}
    for c in combinations(range(len(h)),3):
        w=[h[i] for i in c]
        graph=tuple(sorted(sum(not dot(w[i],w[j]) for j in range(3) if i!=j)
                            for i in range(3)))
        if graph not in reprs:
            a,b,n=fitting_rank_for_triplet(w)
            require(b=={0:3,1:2,2:2,3:1}[a],"false minrank case")
            reprs[graph]={"ports":c,"orthogonal_edges":a,"minrank":b,
                          "fitting_matrices_checked":n}
        if len(reprs)==len(all_types):
            break
    return [{"orthogonal_degrees":kind,"triplet_count":all_types[kind],**value}
            for kind,value in sorted(reprs.items())]


if __name__=="__main__":
    print(json.dumps({"status":"PASS_P111_TRIPLE_FITTING_CENSUS","triples":controls()},indent=2))
