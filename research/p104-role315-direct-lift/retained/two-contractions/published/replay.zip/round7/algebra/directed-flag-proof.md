# A signed-direction cost bound for closed BIT relay groups

For this calculation a group is closed. Its only arbitrary inputs and outputs are the group’s own X and Y roles and its declared independent helper returns. All coframe arithmetic is over F2. Split the selected 111 heads into mutually orthogonal groups of size at most eight. A group may use any finite rational nested frame circuit. In particular, interior frame charts may rotate, and the argument allows arbitrary clean owned births, dirty owned erasure, and coframe role relabeling in the existing model. The original public endpoint is retain X and send Y to Y+X, with X moving from its head line to full and Y from zero to the orthogonal cap. The only helper-return endpoints covered by the main numerical bound are independently preserved 0→full helpers.

## Exact chart-to-flag reduction

Fix any complete rational flag 0 = F_0 ⊂ F_1 ⊂ ··· ⊂ F_8 = Q^8 that takes the mutually orthogonal heads as some of its coordinate axes. For each subspace U, mark j precisely when dim(U ∩ F_j) increases from the preceding value. Such a mark has a witness vector in U ∩ F_j outside F_(j−1), which remains a witness in any larger V. Hence nestedness preserves mark inclusion. There are dim U marks. Each nested MOVE of rank r changes exactly r marks. The boundary line of a marked head is its singleton mask. Its orthogonal cap has all marks except that head because the rational flag is completed with axes orthogonal to every head.

For a selector mask J color each field by the parity of the intersection of J and the field’s chart mask. At equal charts an ADD preserves color. A SWAP transports values with their chart tags and also preserves color. INIT introduces no original coefficient, and CLEAR removes a row. A paid MOVE that crosses from initial side b to its opposite transports a single scalar row. If all such directed edges are removed, the demanded block from initial color b to terminal opposite color vanishes. Reinsert them in time order. Their contributions factor through one injected row each, so that block’s F2 rank is a lower bound on the joint number of such crossings. An exact monotone-axis witness may equivalently be viewed as a cut on field occurrences rather than fixed role labels.

For a group with k orthogonal heads, let a selectors mark head axes, b mark other axes, and t be parity(a+b). Each port has its original x on side 1 if its axis was selected, and its y on side 0. Its output x has color t and y+x has color t XOR the head indicator. Exact rank of the corresponding two-column directed block gives a for source side 1, and 2(k−a)t + a(1−t) for source side 0. Independent 0→full helpers contribute one to the second rank for each odd selector. Existing helper dirt cannot replace the original x or y columns in this argument.

Sum these lower bounds with nonnegative weights while constraining the total weight charged to each MOVE shape to be at most its true H_r = r^(1−s). Because the graph uses nested masks, a move shape is specified by the unchanged, added and absent counts in the head and spectator classes plus direction. A selector’s crossing probability for that orbit is obtained by choosing from each class without replacement. The compressed inequalities are exact rational combinations of the H_r.

## Certified price bounds

The verifier checks every directed move orbit for each k=1 through 8 and for s=.005 and .0227. Scout optimization merely proposed weights. All final weights are downward-rounded rationals, and the replay uses rational arithmetic and directed power intervals. Selected weights leave an uncertified part of each independent H8 helper credit below 1e−9. With at most 444 such helpers in total, even grouping all 111 ports into closed orthogonal components can improve the original 111 deficit by at most **0.513576** at .005 or **2.250032** at .0227. This is far smaller than 28.20271 or 100.85914 required per native to rescue the existing caller at those two rates. The statement is a necessary cost constraint. It neither proves existence of any of these fractional orbits nor assumes the selected 111 heads admit a specific favorable group partition.

For one head and no helper credit there is an exactly sharp, more compact formula. The five nonzero selector classes (head selected, number of other coordinates selected, source side) are (0,1,0), (0,5,0), (1,0,1), (1,2,1), (1,4,1). Their total weights A,B,C,D,E have coefficients over denominator 32 in columns H1,H4,H5,H7 as follows.

| Weight | H1 | H4 | H5 | H7 |
|---|---:|---:|---:|---:|
| A | −35 | −35 | 63 | 12 |
| B | 35 | 35 | −63 | 20 |
| C | 25 | −35 | −21 | 36 |
| D | −28 | 140 | −84 | −16 |
| E | 35 | −105 | 105 | −20 |

The endpoint rank objective is 2(A+B)+C+D+E = H1+2H7 exactly, and the singleton relay attains that amount. There are 12,610 oriented nested mask pairs, reducing to 83 distinct slack forms. All nonzero slacks are strictly positive at both rates, with minima greater than .0015 and .0068. Symbolic equality rows are checked without floating arithmetic. This sharp single-head dual cannot simply be averaged across a larger group, since its weights give a smaller target contribution for a differently marked head. The multi-head verifier supplies distinct certificates for that reason.

## Grouped constructive controls and exclusions

Two- and three-head circuits can gather at their orthogonal span and move their XOR to zero in one rank-two or rank-three descent. Each recipient still needs every other head’s input along a chart inside its own cap to cancel the unwanted parity terms. The exact legal controls deliver these values on explicit individual line branches. All 49,284 public coefficients match both forward and backward. Their complete paid cost rises by 13.91458 or 47.68332 at .005 relative to singleton, even though the central parent descent in each group is shared.

For two nonorthogonal heads there is no cut-free path from either input to either cap. Deleting exceptional edges leaves a zero X-to-Y block, so the exceptional factor has rank two and requires two scalar descents. The triplet census also checks this contact obstruction on the actual 111 live heads. The graphs with zero, one, two and three orthogonal edges occur on 24,689, 71,576, 95,611 and 29,939 unordered triples. Their characteristic-two fitting ranks are 3, 2, 2 and 1. A common flag aligned with all heads need not exist for general oblique sets. In those groups, a head pivot and its cap’s missing pivot can differ. Higher-dimensional native moves carrying more than one independent field, co-encoded helper boundaries and helpers with changed origins or terminal ranks require a distinct cost analysis.

## Commands

From this directory with CPython 3.11+, run directed_flag_dual.py, multi_head_flag.py and path_contact_group.py with flags -I -B -O. The checkers use no optional numerical package. Preserve the original compressed #7001 word, the round-one exact rank intervals, and the earlier finite relay and replay helpers. No selected result or repository file is altered.
