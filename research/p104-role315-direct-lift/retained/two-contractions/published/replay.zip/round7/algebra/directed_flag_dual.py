"""Exact directed-flag tariff dual for closed orthogonal BIT groups."""

from fractions import Fraction
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "algebra"))
from scan_bit_fixed_graph import supported_interval
sys.path.insert(0, str(HERE.parents[1] / "round6" / "algebra"))
from syndrome_packets import compare, load_word, require
from snapshot_owner_shear import exact_replay
from tetrad_rectangles import coordinate_cut
from staged_two_way_routes import binary_rank

ORBITS = ((0, 1, 0), (0, 5, 0), (1, 0, 1), (1, 2, 1), (1, 4, 1))
TERMS = (1, 4, 5, 7)
WEIGHTS = tuple(tuple(Fraction(x,32) for x in v) for v in (
    (-35, -35, 63, 12), (35, 35, -63, 20), (25, -35, -21, 36),
    (-28, 140, -84, -16), (35, -105, 105, -20),
))


def integer_polynomial(terms):
    result = [Fraction(0)]*9
    for i,x in terms:
        result[i] += x
    return tuple(result)


def scarcity_slacks():
    """Symbolic move-price minus sum of directed crossing prices."""
    masks = {z:[j for j in range(256) if (j&1)==z[0] and (j>>1).bit_count()==z[1]] for z in ORBITS}
    out = {}
    count=0
    tight=0
    categories={}
    for smaller in range(256):
        available=255^smaller
        change=available
        while change:
            larger=smaller|change
            for a,b in ((smaller,larger),(larger,smaller)):
                pieces=[(change.bit_count(),1)]
                for orbit,weight in zip(ORBITS,WEIGHTS,strict=True):
                    hits=sum(((a&j).bit_count()%2)==orbit[2] and
                             ((b&j).bit_count()%2)!=orbit[2] for j in masks[orbit])
                    multiplier=Fraction(hits,len(masks[orbit]))
                    pieces.extend((i,-m*multiplier) for i,m in zip(TERMS,weight,strict=True))
                symbolic = integer_polynomial(pieces)
                out[symbolic] = (a,b)
                if not any(symbolic):
                    tight += 1
                    key = (a.bit_count(),b.bit_count(),a&1,b&1)
                    categories[key] = categories.get(key,0)+1
                count+=1
            change=(change-1)&available
    require(count==2*(3**8-2**8),"every strict nested pair of masks")
    require(integer_polynomial(()) in out,"symbolically tight moves")
    return out,count,tight,categories


def lower_value(poly, h):
    return sum(x*h[i][int(x<0)] for i,x in enumerate(poly))/2**80


def target_per_orbit():
    # For the chosen head bit, keep only inputs on the declared source
    # side. Within each other scalar port its two input symbols differ.
    result=[]
    for a,b,side in ORBITS:
        occupied=(a+b)%2
        x=1 if a==side else 0
        y=2 if side==0 else 0
        out=[]
        if occupied!=side:
            out.append(x)
        if occupied^a!=side:
            out.append(x|y)
        result.append(binary_rank(out))
    require(result==[2,2,1,1,1],"head centered crossing rank contribution")
    p=integer_polynomial((i,c*x) for c,w in zip(result,WEIGHTS,strict=True)
                         for i,x in zip(TERMS,w,strict=True))
    require(p==integer_polynomial(((1,1),(7,2))),"tight symbolic target weight")
    return result


def certified_cost():
    slacks,count,tight,categories = scarcity_slacks()
    goal=target_per_orbit()
    controls=[]
    for s in (".005",".0227"):
        h=[(0,0)]+[supported_interval(i,Fraction(s)) for i in range(1,9)]
        v=[lower_value(p,h) for p in slacks if any(p)]
        w=[lower_value(integer_polynomial(zip(TERMS,p,strict=True)),h) for p in WEIGHTS]
        require(min(v)>0 and min(w)>0,"directed dual positivity and all nontrivial slack")
        controls.append({"s":s,"symbolic_target":"H1+2H7",
                         "minimum_strict_slack":float(min(v)),
                         "minimum_weight":float(min(w)),
                         "optimized_status":"exact symbolic equality where slack equals zero"})
    return {"oriented_nested_masks":count,"distinct_slack_forms":len(slacks),
            "exact_zero_slack_form":1,"symbolically_tight_pairs":tight,
            "tight_moves":[{"before_dim":a,"after_dim":b,"before_head_bit":c,
                             "after_head_bit":d,"oriented_masks":n}
                            for (a,b,c,d),n in sorted(categories.items())],
            "target_crossings_per_head":goal,"rates":controls}


def descent_fixture(word, active=(0,1,2)):
    # As a control, the k main ascents fund one common parity descent, but
    # each independent old X needed at the opposite residual still travels
    # along a line branch.
    from singleton_relay import circuit
    frames,_,starts,finals,slots=circuit(word)
    n=111
    zero,full=starts[n],finals[0]
    require(set(active)<=set(range(8)),"coordinate orthogonal fixture")
    group=max(frames)+1
    frame=coordinate_cut(sum(1<<i for i in active))
    frames[group]=frame
    rho,copy=n*2,n*2+1
    steps=[("MOVE",i,starts[i],group) for i in active]
    steps.append(("INIT",rho,group))
    steps.extend(("ADD",rho,i,group) for i in active)
    steps.append(("MOVE",rho,group,zero))
    for i in active:
        steps.extend([("ADD",n+i,rho,zero),("MOVE",n+i,zero,finals[n+i])])
        needed=[j for j in active if j!=i]
        for j in needed:
            own=starts[j]
            steps.extend([("INIT",copy,group),("ADD",copy,j,group),
                          ("MOVE",copy,group,own),("MOVE",copy,own,finals[n+i]),
                          ("ADD",n+i,copy,finals[n+i]),("CLEAR",copy,finals[n+i])])
    for i in active:
        steps.append(("MOVE",i,group,full))
    steps.append(("CLEAR",rho,zero))
    for i,a in enumerate(starts[:n]):
        if i in active:
            continue
        y=n+i
        steps.extend([("INIT",rho,a),("ADD",rho,i,a),("MOVE",rho,a,zero),
                      ("ADD",y,rho,zero),("CLEAR",rho,zero),
                      ("MOVE",y,zero,finals[y]),("MOVE",i,a,full)])
    return frames,steps,starts,finals,copy+1


def run():
    from singleton_relay import circuit
    w=load_word()
    base,old = exact_replay(*circuit(w),shear=True)
    rates=certified_cost()
    group={}
    for size in (2,3):
        lit=descent_fixture(w,tuple(range(size)))
        paid,audit=exact_replay(*lit,shear=True)
        output=compare(paid,base,{7:222})
        require(all(d["saving_2pow80"][1]<0 for d in output),"grouped parity with branch surcharge loses")
        group[size]={"paid":paid,"audit":audit,"comparison":output}
    return {"status":"PASS_DIRECTED_FLAG_TARIFF_AND_GROUP_CONTROLS","certificate":rates,
            "singleton_profile":base,"singleton_replay":old,"grouped_controls":group}


if __name__=="__main__":
    sys.path.insert(0,str(HERE.parents[1] / "round6"))
    print(json.dumps(run(),indent=2))
