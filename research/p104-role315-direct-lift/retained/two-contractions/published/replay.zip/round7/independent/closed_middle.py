"""Attempt a cheaper closed owned path by moving its intervening scalar contact."""

import argparse
from fractions import Fraction as Q
import json
from pathlib import Path
from runpy import run_path
from time import monotonic

HERE = Path(__file__).resolve().parent
DIRECT = run_path(str(HERE / "direct_complex_native.py"))
TAIL, NEED, ROWS = (DIRECT[k] for k in ("TAIL", "NEED", "ROWS"))
PHYSICAL, PRICE = DIRECT["PHYSICAL"], DIRECT["BASE"]["price_engine"]


def stock(frame, snapshot, source, omit):
    frames, rows = snapshot
    basis = {}
    for reg, (chart, row) in enumerate(zip(frames, rows, strict=True)):
        if chart == frame and reg not in omit and row[1]:
            d, data = row
            TAIL["solve_echelon"](basis, {i:Q(v,d) for i,v in data.items()}, {reg:Q(1)})
    d,x = source
    rem, coeff = TAIL["solve_echelon"](basis,{i:Q(v,d) for i,v in x.items()},{},save=False)
    return {"rank":len(basis), "missing":{i:str(v) for i,v in rem.items()},
            "exact_recovery":{j:str(-v) for j,v in sorted(coeff.items())} if not rem else None}


def search(word, deadline):
    p = word["program"]
    move1, mid, move2, adj_mid = 40_573,40_574,40_577,39_886
    NEED(p[move1]==["MOVE",1501,549,115,True] and p[mid]==["ADD",1501,1525,"1/4",115]
         and p[move2]==["MOVE",1501,115,593,True], "literal singleton middle")
    NEED(p[adj_mid]==["ADD",1532,497,"4",520], "literal opposite owned path correction")
    cut={mid,move2+1,40_002,39_824,39_825,39_827,39_828,adj_mid,39_895,39_897,39_898,39_900,46_698,46_699,76_489}
    for i,e in enumerate(p):
        if 39_800<i<46_700 and e[0]=="MOVE" and (e[2] in (115,520,593,529,549) or e[3] in (115,520,593,529,549)):
            cut.add(i+1)
    snaps, _, _ = TAIL["record"](word,cut,deadline)
    goal = snaps[mid][1][1525]
    at = stock(593,snaps[move2+1],goal,{1501})
    reciprocal=stock(529,snaps[39_895],snaps[adj_mid][1][497],{1532,1503})
    key=stock(520,snaps[39825],snaps[39824][1][146],{1503,497})
    source_local=[(i,stock(593,snaps[i],goal,{1501})) for i in sorted(cut) if move1 < i <= move2+1]
    return {"own_1501_middle_to_late":at,"owned_1532_affine_return":reciprocal,
            "old_1503_outbound_payload_at_middle_without_copy":key,
            "owned_1501_recovery_early_cut_horizon":source_local}


def schur_recoding(word, deadline):
    """Push the rank-one B payload term into its coframed lower rectangle."""
    program = word["program"]
    n = word["public"]
    _, expected, _ = ROWS["target"](word)
    chosen = (44_103,44_550,44_679,44_689,45_162,45_435)
    before, substitutions, out = {}, {}, []
    contexts = []
    for first in chosen:
        e0,e1,e2,e3 = program[first:first+4]
        _, source, below, cap, _ = e0
        y = e1[1]
        _, helper, b, c, _ = e2
        NEED(e0[0]==e2[0]=="MOVE" and e0[-1] is False and e2[-1] is False and
             (b,c)==(below,cap) and e1==["ADD",y,source,"-2",cap] and e3==["ADD",helper,y,"-1",cap],
             "literal two-transport Schur rectangle")
        NEED(len(word["frames"][below])==7 and len(word["frames"][cap])==8, "one-axis shared cap rise")
        NEED(DIRECT["ADJ"]["span"](word["frames"][below]) < DIRECT["ADJ"]["span"](word["frames"][cap]),
             "lower triangle occupies a strict common subspace")
        # Old map: y <- y - 2s, t <- t - y(updated), hence t <- t - y(old) + 2s.
        # Load the Schur term into t while t and s still share the lower chart.
        before[first] = ["ADD",helper,source,"2",below]
        substitutions[first+1] = []
        substitutions[first+3] = [e3,e1]
        contexts.append({"first":first,"source":source,"helper":helper,"B_y":y,"old_chart":cap,"new_chart":below})
    for i,event in enumerate(program):
        if i in before:
            out.append(before[i])
        out += substitutions.get(i,[event])
    alt={**word,"schema":"p104-six-b-schur-groups/v1","program":out}
    _, paid, normal=TAIL["record"](alt,set(),deadline,requirement=expected)
    old_counts={op:sum(e[0]==op for e in program) for op in normal}
    old_counts["ADD"] += len(chosen)
    NEED(normal==old_counts and sum(paid.values())==6_276,"same paid count and exactly six additional ADDs")
    grid=DIRECT["ROUND6"]["native_grid"](alt,deadline)
    invalid_index=next(i for i,e in enumerate(out) if e==before[chosen[0]])
    bad={**alt,"program":out[:invalid_index]+out[invalid_index+1:]}
    rejected=False
    try:
        TAIL["record"](bad,set(),deadline,requirement=expected)
    except ValueError as exc:
        if str(exc) != "all independent dirty inputs and final frames":
            raise
        rejected=True
    NEED(rejected,"dropping the lower Schur correction fails full replay")
    return alt, {"directions":contexts,"public_coefficients":n**2,"native_paid":dict(paid),
                 "native_operations":dict(normal),"normalized_grid":grid,
                 "helper_targets_unchanged":1_101,"omitted_recode_rejected":rejected,
                 "changed_word_sha256":DIRECT["ADJ"]["digest"](alt)}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("word",type=Path)
    ap.add_argument("output",type=Path)
    ap.add_argument("--emit",type=Path)
    args=ap.parse_args()
    start=monotonic()
    _, word=PHYSICAL["load_pins"](args.word)
    result=search(word,start+22)
    alt, recoding=schur_recoding(word,start+42)
    price=PRICE()
    gain=price.moment({2:1,4:1,6:-1},Q(".005"))
    NEED(gain[0]>0,"certified concavity gain if fully funded")
    if args.emit:
        args.emit.write_text(json.dumps(alt,separators=(",",":"))+"\n",encoding="utf-8")
    args.output.write_text(json.dumps({"status":"PASS_CLOSED_OWNED_MIDDLE_SCREEN","rank_2_4_merge_upper_005":price.value(gain),
                                      "six_literal_schur_recodings":recoding, **result},indent=2)+"\n",encoding="utf-8")
    print("PASS_CLOSED_OWNED_MIDDLE_SCREEN",f"{monotonic()-start:.2f}s")


if __name__=="__main__":
    main()
