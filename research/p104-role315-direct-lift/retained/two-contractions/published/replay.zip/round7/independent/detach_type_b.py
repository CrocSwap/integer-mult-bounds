"""Detach the Type B domain and restore its outputs via exact direct jobs."""

import argparse
from collections import Counter
from fractions import Fraction as Q
import json
from pathlib import Path
from runpy import run_path
from time import monotonic

HERE = Path(__file__).resolve().parent
DIRECT = run_path(str(HERE / "direct_complex_native.py"))
TAIL, NEED, ROWS, PHYSICAL, BASE = (DIRECT[k] for k in ("TAIL", "NEED", "ROWS", "PHYSICAL", "BASE"))


def substitute_zero(word, direct_word, b_rails):
    """Use a private zero shadow per old B role; retain the public B inputs."""
    n, o = word["public"], word["owned_fields"]
    shadows = {r:n+o+i for i,r in enumerate(sorted(b_rails))}
    spare = n+o+len(shadows)
    y = list(word["initial"])+[None]*(o+len(shadows))
    rows = [ROWS["unit"](r) for r in range(n)]+[ROWS["NONE"]]*(o+len(shadows))
    candidate = []
    for r, shadow in shadows.items():
        f = y[r]
        y[shadow] = f
        candidate.append((-1,["INIT",shadow,f]))
    for i, (op, role, *args) in enumerate(word["program"]):
        dst = shadows.get(role,role)
        item = [op,dst,*args]
        put = True
        if op == "INIT":
            NEED(y[dst] is None and not rows[dst][1], "owned zero shadow starts disjoint")
            y[dst] = args[0]
        elif op == "CLEAR":
            NEED(y[dst] is not None,"clear a live owned bank")
            y[dst], rows[dst] = None,ROWS["NONE"]
        elif op == "MOVE":
            NEED(y[dst] == args[0], "normalized entrance retained")
            y[dst] = args[1]
            item[-1] = dst>=n
        elif op == "SCALE":
            put = bool(rows[dst][1])
            rows[dst] = ROWS["scale"](rows[dst],ROWS["ratio"](args[0]))
        else:
            src = shadows.get(args[0],args[0])
            NEED(y[src] == y[dst] == args[-1], "rewritten dirty coframe")
            if op == "COPY":
                NEED(not rows[dst][1], "retained COPY on exact zero")
            put = bool(rows[src][1])
            rows[dst] = ROWS["increment"](rows[dst],rows[src],ROWS["ratio"](args[1]))
            item[2] = src
        if put:
            candidate.append((i,item))
    for r, shadow in shadows.items():
        NEED(y[shadow] == word["final"][r] and not rows[shadow][1], "separate old B block vanishes when B inputs zero")
        candidate.append((-1,["CLEAR",shadow,y[shadow]]))

    b_paid = Counter()
    direct_old = [*direct_word["old_main_owner_mapping"],spare]
    # The exact direct producer uses one scratch and serial independent plane segments.
    segment = []
    n_move = 0
    for op,r,*args in direct_word["program"]:
        item = [op,direct_old[r],*args]
        if op in ("ADD","COPY"):
            item[2] = direct_old[args[0]]
        segment.append(item)
        if op == "MOVE" and r != direct_word["public"]:
            n_move += 1
            if n_move == 2:
                r1,r2 = [e[1] for e in segment if e[0]=="MOVE" and not e[-1]]
                if r1 in b_rails:
                    NEED(r2 in b_rails,"retain the complete Type B plane")
                    for e in segment:
                        candidate.append((-2,e))
                        if e[0]=="MOVE":
                            b_paid[abs(len(word["frames"][e[3]])-len(word["frames"][e[2]]))] += 1
                segment, n_move = [],0
    NEED(not segment and b_paid == {1:16,8:16}, "all eight disjoint B replacements")
    return candidate, spare + 1 - n


def exact_slice(word, annotated):
    """Trace value liveness, then rebuild lifetimes and preserve required charts."""
    n = word["public"]
    need_value = set(range(n))
    relaxed = []
    for i,(op,r,*a) in reversed(annotated):
        if op in ("INIT","CLEAR","MOVE"):
            # Geometry stays for this first pass. Later delete contactless lives.
            if op in ("INIT","CLEAR"):
                need_value.discard(r)
            relaxed.append((i,[op,r,*a]))
        elif r in need_value:
            if op == "SCALE":
                if not Q(a[0]):
                    need_value.remove(r)
            else:
                need_value.add(a[0])
                if op=="COPY":
                    need_value.remove(r)
            relaxed.append((i,[op,r,*a]))
    relaxed.reverse()
    lives = {}
    omit = set()
    for ix,(i,(op,r,*a)) in enumerate(relaxed):
        if op == "INIT":
            lives[r] = {"indices":[ix],"used":False}
        elif op == "CLEAR":
            d = lives.pop(r)
            if not d["used"]:
                omit.update([*d["indices"],ix])
        elif op == "MOVE":
            if r>=n:
                lives[r]["indices"].append(ix)
        else:
            if r>=n:
                lives[r]["used"] = True
            if op in ("ADD","COPY") and a[0]>=n:
                lives[a[0]]["used"] = True
    NEED(not lives,"all source and replacement lifetimes close")
    pared = [(i,e) for at,(i,e) in enumerate(relaxed) if at not in omit]
    last = {}
    edits = {}
    retired = []
    for at,(orig,e) in enumerate(pared):
        op,r,*a = e
        if op == "MOVE":
            if r in last:
                prev_id, prev_src, prev_origins = last[r]
                fs,ft = a[:2]
                old = edits.get(prev_id,pared[prev_id][1])
                NEED(old[3]==fs,"consecutive moves on the same field")
                if prev_src==ft:
                    edits[prev_id]=[]
                    edits[at]=[]
                    last.pop(r)
                else:
                    shapes = [DIRECT["ADJ"]["span"](word["frames"][f]) for f in (prev_src,ft)]
                    if shapes[0]<shapes[1] or (r>=n and shapes[1]<shapes[0]):
                        edits[prev_id]=[]
                        edits[at]=["MOVE",r,prev_src,ft,r>=n]
                        last[r]=(at,prev_src,[*prev_origins,orig])
                        retired.append({"sources":[*prev_origins,orig],"direct":[prev_src,ft],"role":r})
                    else:
                        last[r]=(at,a[0],[orig])
            else:
                last[r]=(at,a[0],[orig])
        else:
            last.pop(r,None)
            if op in ("ADD","COPY"):
                last.pop(a[0],None)
    return [out for at,(_,e) in enumerate(pared) if (out:=edits.get(at,e))], retired


def signed_fusions(compiler, word, merges):
    source = word["program"]
    bound = []
    for rec in merges:
        i,j = rec["sources"]
        first,second = source[i],source[j]
        NEED(first[1]==second[1] and first[3]==second[2] and [first[2],second[3]]==rec["direct"],
             "literal two-child source geometry")
        charts = [first[2],first[3],second[3]]
        a,b,c = [compiler.canonical_frame(9,word["frames"][f]) for f in charts]
        expected = a.adjoint().then(b).then(b.adjoint()).then(c)
        recipe, actual = compiler.lower_child(a.adjoint().then(c))
        NEED(recipe["rank"]==2,"changed child pays exactly rank two")
        PHYSICAL["equal_signed_clifford"](actual,expected,True)
        PHYSICAL["equal_signed_clifford"](actual.adjoint(),expected.adjoint(),True)
        bound.append(charts)
    return bound


def report(args):
    start = monotonic()
    deadline = start + 20
    compiler, word = PHYSICAL["load_pins"](args.word)
    b, expected, _ = ROWS["target"](word)
    direct_word, _, _ = DIRECT["build"](word)
    caller = json.loads(BASE["pin"](args.caller,BASE["CALLER"]))
    whole = json.loads(BASE["pin"](args.whole,BASE["WHOLE"]))
    ann, owned = substitute_zero(word,direct_word,b)
    program, merges = exact_slice(word,ann)
    new = {**word,"schema":"p104-detached-b-candidate/1","program":program,"owned_fields":owned}
    _, paid, ordinary = TAIL["record"](new,set(),deadline,requirement=expected)
    recipe_charts = signed_fusions(compiler,word,merges)
    wrong_idx=next(i for i, (op,r,*d) in enumerate(program) if op=="SCALE" and r in b and d[0]=="1/2")
    wrong={**new,"program":program[:wrong_idx]+program[wrong_idx+1:]}
    failure=False
    try:
        TAIL["record"](wrong,set(),deadline,requirement=expected)
    except ValueError as exc:
        failure=str(exc)=="all independent dirty inputs and final frames"
    NEED(failure,"detached Type B target fails without its normalization SCALE")
    old = Counter(abs(len(word["frames"][e[3]])-len(word["frames"][e[2]])) for e in word["program"] if e[0]=="MOVE")
    delta = paid.copy()
    delta.subtract(old)
    stage_count = caller["stages"]
    old_helper = {int(k):v*stage_count for k,v in whole["signed_profile"]["native_productive"].items()}
    moment = DIRECT["signed_price"](paid,whole,stage_count,extra_productive=old_helper)
    need_b = sum(r in b for r in set(word["live"])|{r+112 for r in word["live"]})
    NEED(need_b==16,"literal independent B domain")
    outcome = {"status":"PASS_P104_DERIVED_TYPE_B_DETACHMENT", "source_head":DIRECT["ADJ"]["NATIVE_HEAD"],
               "paid":dict(paid),"paid_delta":{r:v for r,v in delta.items() if v},
               "additional_private_labels":owned-word["owned_fields"],"new_ordinary":dict(ordinary),
               "merged_paid_paths":merges,"dirty_scalar_coefficients":word["public"]**2,"full_dirty_helper_outputs":1101,
               "signed_invoice":moment,"word_sha256":DIRECT["ADJ"]["digest"](new),
               "signed_fusion_witnesses":recipe_charts,"missing_b_normalizer_rejected":failure}
    if args.emit:
        args.emit.write_text(json.dumps(new,separators=(",",":"))+"\n",encoding="utf-8")
    args.output.write_text(json.dumps(outcome,indent=2)+"\n",encoding="utf-8")
    print(outcome["status"], f"{monotonic()-start:.2f}s",outcome["paid_delta"])


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    for a in ("word","caller","whole","output"):
        parser.add_argument(a,type=Path)
    parser.add_argument("--emit",type=Path)
    report(parser.parse_args())
