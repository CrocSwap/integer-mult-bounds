"""Construct and charge an independent portwise implementation of the #7546 interface."""

import argparse
from collections import Counter
from fractions import Fraction as Q
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
TAIL = run_path(str(HERE.parents[1] / "round5" / "paired_tail_synthesis.py"))
BASE = run_path(str(HERE.parents[1] / "round3" / "independent" / "body_rank_deformation.py"))
ROUND6 = run_path(str(HERE.parents[1] / "round6" / "independent" / "owned_packet_coalescence.py"))
ROWS, NEED = TAIL["ROWS"], TAIL["NEED"]
ADJ, PHYSICAL = TAIL["ADJ"], TAIL["ADJ"]["PHYSICAL"]


def build(word):
    hosted = word["hosted"]
    mappings = sorted(ADJ["main_roles"](word))
    labels = {r:i for i,r in enumerate(mappings)}
    start = [word["initial"][r] for r in mappings]
    final = [word["final"][r] for r in mappings]
    a_set = set(hosted["Dports"])
    n = len(start)
    full = TAIL["TOP"]["FULL"]
    zero, = [f for f, data in enumerate(word["frames"]) if not data]
    public, total = [], Counter()

    def append(old_x, old_y, species):
        x, y = labels[old_x], labels[old_y]
        line, cap = start[x], final[y]
        NEED(start[y] == zero and final[x] == full, "same source-bound port boundary")
        NEED(len(word["frames"][line]) == 1 and len(word["frames"][cap]) == 8,
             "rank-one central axis and eight-dimensional body")
        if species in ("A_lower", "B"):
            public.extend([["INIT",n,line],["ADD",n,x,"1",line],["MOVE",n,line,zero,True],
                           ["ADD",y,n,"1",zero],["CLEAR",n,zero]])
        if species == "B":
            public.append(["SCALE",y,"1/2",zero])
        if species in ("A_upper", "B"):
            public.extend([["INIT",n,zero],["ADD",n,y,"1",zero],["MOVE",n,zero,line,True]])
            if species == "B":
                public.append(["SCALE",x,"2",line])
            public.extend([["ADD",x,n,"-1" if species=="A_upper" else "-2",line],["CLEAR",n,line]])
        public.extend([["MOVE",x,line,full,False],["MOVE",y,zero,cap,False]])
        total[species] += 1

    for pi, r in enumerate(word["live"]):
        append(r, r+112, "A_lower" if pi in a_set else "B")
    for x,y in zip(hosted["X2"],hosted["Y2"],strict=True):
        append(x,y,"A_upper")
    _, original_rows, _ = ROWS["target"](word)
    expected = []
    for r in mappings:
        d, row = original_rows[r]
        NEED(set(row) <= labels.keys(), "every retained main row is independent of old helpers")
        expected.append((d, {labels[j]: x for j,x in row.items()}))
    NEED(total == {"A_lower":96,"A_upper":96,"B":8}, "type counts in the exact old word")
    return {"schema":"p104-direct-complex-native/1", "frames":word["frames"], "initial":start,
            "final":final, "public":n, "owned_fields":1,"program":public,
            "old_main_owner_mapping":mappings}, expected, total


def verify_physical(compiler, word, deadline):
    ops = {}
    spaces = {}
    for f in {g for op, _, *d in word["program"] if op=="MOVE" for g in d[:2]}:
        ops[f] = compiler.canonical_frame(9, word["frames"][f])
        spaces[f] = ADJ["span"](word["frames"][f])
    pairs = {(a,b) for op,_,*d in word["program"] if op=="MOVE" for a,b in [d[:2]]}
    main_inputs = 0
    hist = Counter()
    first_wrong = False
    for a,b in sorted(pairs):
        NEED(monotonic() < deadline, "exact signed direct port compilation deadline")
        fa, fb = spaces[a], spaces[b]
        NEED(fa < fb or fb < fa, "every direct child has truly nested address frames")
        desired = ops[a].adjoint().then(ops[b])
        rank = abs(len(word["frames"][a])-len(word["frames"][b]))
        hist[rank] += 1
        main_inputs += int(rank==8)
        # An exact tableau and one exact Gaussian-dyadic column determine the operator.
        compiled_recipe, compiled = compiler.lower_child(desired)
        NEED(compiled_recipe["rank"]==rank, "recursive rank from independent actual quotient")
        PHYSICAL["equal_signed_clifford"](desired,compiled,True)
        PHYSICAL["equal_signed_clifford"](desired.adjoint(),compiled.adjoint(),True)
        if not first_wrong:
            bad = compiler.Op(9,compiled.tab,[*compiled.circuit,("phase",1)])
            first_wrong = desired.zero_state()!=bad.zero_state()
    NEED(main_inputs==208 and first_wrong, "all live boundary jobs checked, omitting the exact phase is rejected")
    return {"distinct_port_source_frames":len(ops),"distinct_signed_moves":len(pairs),
            "distinct_ranks":dict(hist),"phase_error_rejected":first_wrong}


def signed_price(native_paid, whole, stages, extra_paid=None, extra_productive=None):
    """Recompute all old and changed native plus caller positions by exact tariff."""
    pres = whole["signed_profile"]
    key = lambda line: Counter({int(r):v for r,v in pres[line].items()})
    old_paid = key("signed_paid")
    old_fund = key("signed_productive")
    new_paid = key("pure_caller_paid")
    new_fund = key("pure_caller_productive")
    new_paid.update({r:stages*v for r,v in native_paid.items()})
    new_paid.update(extra_paid or {})
    new_fund.update(extra_productive or {})
    price = BASE["price_engine"]()
    old, new = old_fund.copy(), new_fund.copy()
    old.subtract(old_paid)
    new.subtract(new_paid)
    rows = {}
    for value in ("0", ".003648411294790", ".005", ".0227"):
        k = Q(value)
        m0,m1 = price.moment(old,k),price.moment(new,k)
        delta = price.sub(m1,m0)
        rows[value] = {"old_margin":price.value(m0)[0], "candidate_margin":price.value(m1)[0],
                       "candidate_margin_interval":price.show(m1), "vs_source_delta":price.value(delta)[0],
                       "per_native_net_needed_if_repeated":max(0,-price.value(m1)[0]/stages)}
    return {"stages":stages, "complete_paid":dict(new_paid), "complete_productive":dict(new_fund),
            "complete_paid_count":sum(new_paid.values()), "complete_productive_count":sum(new_fund.values()),
            "exact_moment":rows}


def run(args):
    start = monotonic()
    deadline = start+55
    compiler, old = PHYSICAL["load_pins"](args.word)
    whole = json.loads(BASE["pin"](args.whole,BASE["WHOLE"]))
    caller = json.loads(BASE["pin"](args.caller,BASE["CALLER"]))
    alt, expected, types = build(old)
    _, moves, ordinary = TAIL["record"](alt,set(),deadline,requirement=expected)
    NEED(moves == {1:208,8:400}, "exact new paid histogram")
    # Fail a complete endpoint replay if the signed B return factor is mistaken.
    wrong_b = next(i for i,e in enumerate(alt["program"]) if e[0]=="SCALE" and e[2]=="1/2")
    truncated = alt["program"][:wrong_b]+alt["program"][wrong_b+1:]
    reject = False
    try:
        TAIL["record"]({**alt,"program":truncated},set(),deadline,requirement=expected)
    except ValueError as exc:
        reject = str(exc)=="all independent dirty inputs and final frames"
    NEED(reject,"omitting the dyadic B normalization is detected")
    data = {"status":"PASS_EXACT_DIRECT_COMPLEX_NATIVE", "source_head":ADJ["NATIVE_HEAD"],
            "source_word_sha256":ROWS["WORD_SHA"], "type_counts":dict(types),
            "changed_normalized_word_sha256":ADJ["digest"](alt),
            "checked_scalar_coefficients":alt["public"]**2, "native_paid":dict(moves),
            "native_productive_helpers":{}, "ordinary_native_operations":dict(ordinary),
            "scalar_grid":ROUND6["native_grid"](alt,deadline),
            "physical":verify_physical(compiler,alt,deadline),
            "whole_caller_invoice":signed_price(moves,whole,caller["stages"]),
            "omit_B_dyadic_scale_rejected":reject}
    NEED(monotonic()<deadline,"bounded direct complex proof")
    if args.emit:
        args.emit.write_text(json.dumps(alt,separators=(",",":"))+"\n",encoding="utf-8")
    args.output.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    print(data["status"], f"{monotonic()-start:.2f}s")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    for arg in ("word","caller","whole","output"):
        p.add_argument(arg,type=Path)
    p.add_argument("--emit",type=Path)
    run(p.parse_args())
