# SPDX-License-Identifier: Apache-2.0
"""Extract an authenticated package and rerun the seventh-round receipts."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from time import perf_counter
from zipfile import ZipFile


JOBS = (
    ("flag_gram", "flag-gram", "stdout"),
    ("host_defect", "host-defect", "stdout"),
    ("central_characters", "central-characters", "caller"),
    ("algebra/directed_flag_dual", "algebra/directed-flag-dual-results", "stdout"),
    ("algebra/multi_head_flag", "algebra/multi-head-flag-results", "stdout"),
    ("algebra/path_contact_group", "algebra/path-contact-results", "stdout"),
    ("independent/direct_complex_native", "independent/direct-complex-native", "signed"),
    ("independent/detach_type_b", "independent/detach-type-b", "signed"),
    ("independent/closed_middle", "independent/closed-middle", "word"),
    ("recurrence/verify_saturated_body", "recurrence/saturated-body", "git"),
    ("recurrence/verify_signed_saturation", "recurrence/signed-saturation", "expect"),
    ("recurrence/host_balance", "recurrence/host-balance", "pack"),
    ("recurrence/verify_grouped_q0", "recurrence/grouped-q0", "pack"),
    ("../round6/singleton_relay", "../round6/singleton-relay", "stdout"),
    ("../round6/independent/adjoint_prearrival", "../round6/independent/adjoint-prearrival", "word"),
)


def replay(dest, repo, job):
    script, receipt, mode = job
    source = dest / "round7" / f"{script}.py"
    expected = dest / "round7" / f"{receipt}.json"
    output = dest / "run" / f"{Path(receipt).name}.json"
    word = "inputs/7546-word.json.gz"
    args = {
        "git": [str(repo), "--expect", str(expected)],
        "expect": ["--expect", str(expected)],
        "pack": ["inputs", "--expect", str(expected)],
        "signed": [word, "inputs/7113-caller.json", "inputs/7546-whole.json", str(output)],
        "word": [word, str(output)],
        "caller": [word, "inputs/7113-caller.json"],
        "stdout": [],
    }
    start = perf_counter()
    run = subprocess.run([sys.executable, "-I", "-B", "-S", "-W", "error",
                          str(source), *args[mode]], cwd=dest, capture_output=True, timeout=58)
    if run.returncode or run.stderr:
        raise RuntimeError((script, run.returncode, run.stderr.decode(errors="replace")))
    actual = output.read_bytes() if output.exists() else run.stdout
    if json.loads(actual) != json.loads(expected.read_bytes()):
        raise ValueError(f"{script} differs from the saved receipt")
    return script, perf_counter() - start


def extract(archive, dest):
    with ZipFile(archive) as bundle:
        names = bundle.namelist()
        manifest = json.loads(bundle.read("SHA256.json"))
        if len(names) != len(set(names)) or set(names) != set(manifest) | {"SHA256.json"}:
            raise ValueError("unbound or repeated archive member")
        for name, digest in manifest.items():
            if not (dest / name).resolve().is_relative_to(dest) or sha256(bundle.read(name)).hexdigest() != digest:
                raise ValueError(name)
        bundle.extractall(dest)
        return len(manifest)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--workers", type=int, default=6)
    args = parser.parse_args()
    dest = args.destination.resolve()
    dest.mkdir()
    hashes = extract(args.archive, dest)
    (dest / "run").mkdir()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        for job in [pool.submit(replay, dest, args.repo.resolve(), entry) for entry in JOBS]:
            script, elapsed = job.result()
            print(f"PASS {script} {elapsed:.2f}s", flush=True)
    print(f"PASS_ROUND7_REPLAY {len(JOBS)} fresh receipts and {hashes} archived hashes")


if __name__ == "__main__":
    main()
