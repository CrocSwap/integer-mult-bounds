# Grouped-idle price at 17 stages and zero Type A queries

For the independently portwise Type A calculation in HOST-BALANCE, allowing arbitrary grouped positive body idles still leaves the 17-host zero-thin-query design with a strictly negative margin at \(\kappa=.005\). The complete upper endpoint is **−0.0119883509271** across all 96 Type A ports and eight Type B ports. The price covers all 17 full #7546 native and helper inventories and gives Type B its entire optimistic joint allowance. The key remaining case after numerical relaxation is an idle whose every moved axis lies on the same output role. The signed-sector rank constraints make that idle detach as one fixed coordinate projector.

This note uses the grouped transport theorem proved alongside it. Each Type A port has 32 independent odd input/output roots and exactly \(17\cdot2\) odd transvections. The defect is two. Each stage uses one fresh independent positive body label of width eight. Target body labels have unit incidences. All auxiliary idles act on one role, carry any nonempty subset of those body labels, and have zero odd sector. Scalar role changes are square and sector-even. Type A does not mix across ports or with Type B. This is a redesigned portwise Type A subcase, distinct from the literal #7113 caller with mixed odd idles. [#7546 native](https://github.com/CrocSwap/integer-mult-bounds/pull/7546) · [#7113 caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7113)

## Simultaneous derivative spans in the two signed sectors

Fix a body label \(D_j\). For each sector separately, set all other body variables to one, and write \(M_\sigma(D_j)\) for the resulting operator at \(q=\sigma i\), \(\sigma=\pm1\). At \(D_j=1\), its base case is an invertible scalar matrix. Multiply its inverse on the left and pull each body projection into the common input basis using the scalar prefix in that sector. The output is \(I+(D_j-1)F_j\), where \(F_j\) is the *same* final coordinate projector in both sectors. This also follows directly from the diagonal target: the scalar factor on each coordinate cancels in the inverse. Therefore

\[
F_j=\sum_{\text{native and idle occurrences carrying }j}
                P_{\text{occurrence},\,\sigma}
\]

by the coefficient linear in \(D_j-1\). Each transported body projector still has its full rank, because every scalar prefix at all bodies one is invertible. For the native its rank is four. Each idle has rank one. The determinant of each transported body factor contributes precisely its rank to the degree of \(D_j\). The determinant of the final normalized operator has degree \(\operatorname{rank}F_j\). Hence this final rank equals the number of columns in the sum of rank factorizations for that sector. This uses the *exact determinant degree* in the formal variable, without relying on trace and without presuming either sector's internal row or column allocations agree.

The combined column span contains \(\operatorname{im}F_j\) and has dimension at most that rank, so equals it. The combined row span similarly equals the row space of \(F_j\). A grouped idle has the same pulled-back column and row at every label in its mask within a fixed sector, since the idle has one time and one scalar prefix in that sector. Both its column and its row are consequently supported in the common coordinate intersection of those target masks. The matching for the numerical budget uses only the nominal sector. The two-sided support deduction for the detachment step uses both sectors, independently.

## Exhaustive branches at one port

Write \(H_r=r^{1-\kappa}\). As in HOST-BALANCE, allocate each label's rank-factor columns bijectively to its output role marks by a nonzero determinant summand. Every target role then has \(x\) matched native marks and \(y\) matched idle marks, \(k=x+y\le17\). The total native count is exactly 68. The grouped saturation theorem forces at least 15 additional label uses, hence there are at least 15 idle marks overall. Each grouped idle of mask size \(a\) pays \(H_{8a}/a\) per assigned mark. Its target has \(k\ge a\), so its payment per mark is at least \(H_{8k}/k\). After that allocation the net target credit of this role is bounded by

\[
f(x,y)=H_{8(x+y)+1}-\frac{y}{x+y}H_{8(x+y)},
\quad f(0,0)=1.
\]

The function decreases with \(y\) at fixed \(x\). For \(k>0\), write it as \(x H_{8k}/k+H_{8k+1}-H_{8k}\). Both terms decrease in \(k\) for fixed \(x\); the step from \(f(0,0)\) also decreases.

1. **Idle marks occur on at least two roles, or they occur on one role that also carries a native mark.** Select just 15 idle marks while preserving one of those two features. Dropping other idle marks can only increase the bound \(f\). The independent DP balances 68 native and 15 selected idle marks among 32 roles, with \(k\le17\) and the one forbidden pair \((0,15)\). Every selection in this branch avoids that pair. The DP, using outward integer-grid upper endpoints and summation, gives complete margin upper **−1.8635439066834**.
2. **All idle marks are matched to one role \(t\) with no native marks, and some other role has at least four native marks.** Role \(t\) contributes at most \(H_{121}-H_{120}\). The other 31 roles carry 68 native marks, with one at least four. The largest sum by concavity places the constrained role at four marks and balances the rest, giving 26 rank-17, four rank-25 and one rank-33 credits. Indeed the constrained role at four exceeds the balanced values of the other roles, so increasing it cannot improve the bound. The complete margin is at most **−0.0119883509271**.
3. **All idle marks are matched to one native-empty role \(t\), every other role has at most three labels, and some idle has at most three labels.** All its assigned marks go to \(t\), whose actual \(k\) is at least 15. At least one short idle mark pays surplus at least \(H_{24}/3-H_{120}/15>0.0631083621987\). Role \(t\) otherwise contributes at most \(H_{121}-H_{120}\). The other 31 roles balance as 25 rank-17 and six rank-25 targets. Charging that one surplus gives complete margin upper **−4.8456679781836**.
4. **All idle marks are matched to one native-empty role \(t\), every other role has at most three labels, and all idles have at least four labels.** The target coordinate masks of every grouped idle have common intersection exactly the line of \(t\). Every label in its mask contains \(t\) by the matching. No other role can carry all four or more labels. The two-sided span argument forces each transported rank-one idempotent to be exactly \(E_{tt}\) in both sectors. Since each label's matching uses its target coordinate \(t\) at most once, every label has at most one such idle. For any label with an idle, the transported native projector therefore equals \(F_j-E_{tt}\) in both sectors. This is a fixed coordinate projector of rank four. For any label without an idle the transported native projector equals \(F_j\) in both sectors. All native projectors consequently satisfy the *coordinate and prefix-invariance conditions* used in the grouped saturation proof. That proof's geometric contradiction now applies to any three of the 17 natives, even though the original labels did contain idles. Equivalently, removing the detached body idles gives the same two normalized sector body coefficients, which already contradict the three-block argument. This branch is impossible.

The DP explicitly grants every integer mark count that satisfies its recurrence, whether its corresponding physical schedule exists or not. The cut and matching proof supplies the implication from actual schedule to a priced branch. Branches can vary across the 96 ports. Each per-port Type A allowance is no larger than the largest of the three per-port numerical allowances, since the common full native inventory and Type B term are the same in each displayed total. Therefore summing over nonuniform branches still gives at most **−0.0119883509271**.

## Reproduction

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round7\recurrence\verify_grouped_q0.py $complexPack --expect .\work\round7\recurrence\grouped-q0.json
~~~

The pricing replay imports adjacent host_balance.py and through it the same pinned complex source reader and directed arithmetic as HOST-BALANCE. It uses 2,953,186 exact DP transitions with a 10-second numerical deadline and a 14-second process bound. A separate control checks both-sided support detachment and exact product factors with one common coordinate, gives a counterexample to column-only support, and exhibits different sector projectors on a larger common intersection. Normal and optimized replays took 0.71 and 0.73 seconds, with identical SHA-256 `442f028b3bf1aacfd0f2ba0368fb0000d7e363828267c28fc6d1be1cb339b14e`. AST parsing and tabnanny passed.
