# Type A balanced-incidence pricing with the complete #7546 native bill

This price check uses the grouped rank-defect theorem as a hypothesis. It grants the complete independent helpers of the open #7546 native and charges every one of its paid moves. It gives the eight Type B ports their full joint-cut capacity \(8(H_8+H_9+H_1)\) per host. The actual Type B caller can only have less credit after paying its own auxiliary work. The estimates concern a redesigned Type A caller. The literal signed #7113 production word has additional mixed odd idles and needs its own price. [#7546 native](https://github.com/CrocSwap/integer-mult-bounds/pull/7546) · [#7113 caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7113)

Let \(L\) count actual complete natives, \(r\) be the number of disjoint Type A shears in one atomic A block, \(Q\) count separate thin odd queries in that same scalar role space, \(n\) count independently returned odd roots there, and \(d=8\) be the actual stage body width. The exact-defect hypothesis is \(rL+Q-n=r\). Set \(H_j=j^{1-\kappa}\).

Every stage has a distinct formal Laurent label and appears once on a native body. Target body exponents and body-idle exponents are positive unit incidences in their included labels. A role receives at most one incidence from each stage. A grouped body-only idle pays the power tariff of its complete rank on one role, while a single-label idle pays \(H_d\). The block theorem forces **at least \(L-2\) additional label uses**. A grouped idle can supply multiple such uses.

## Exact relaxed balance

For nonnegative integers \(x_1,\ldots,x_n\) summing to \(X\), any increasing concave tariff \(f\) has maximum \(\sum_i f(x_i)\) at \(n-s\) values \(a=\lfloor X/n\rfloor\) and \(s=X-na\) values \(a+1\). Transferring one unit from a value at least two higher to a lower value proves this by decreasing increments.

For independent positive stage bodies, set \(q=1\). The determinant degree is \(2r\) from a native body plus one from each containing idle. The transported derivative columns in a body label therefore form a basis of its final coordinate role space. A nonzero determinant minor gives a bijective allocation of those columns to output incidences for that label. In a grouped idle carrying \(a\) labels, one transported column is shared across those labels. Its support is contained in the intersection of their target coordinate subspaces. Thus each matching idle mark lands on a role with at least \(a\) total marks.

On a role carrying \(k\) total marks, allocate \(H_{dk}/k\) per mark. The price of a grouped idle covers its shares, since \(H_{da}/a\ge H_{dk}/k\) for \(a\le k\). If this role has \(x\) matching native marks, the remaining body credit is at most \(xH_{dk}/k\le H_{dx}\). Its odd header increment is at most \(H_{dx+1}-H_{dx}\), since \(k\ge x\). The net credit after all body-idle work is therefore at most \(f(x)=H_{dx+1}\), with \(X=2rL\) native marks overall.

When every actual root carries positive body, even a role with \(x=0\) has header increment at most \(H_{d+1}-H_d\). Replace \(f(0)=1\) by \(H_{d+1}-H_d\). This sequence remains increasing and concave: its first jump is \(H_d\), and its second jump is \(H_{2d+1}-H_{d+1}\le H_d\).

For only single-label idles, let \(M\) be their count. The exact total is \(2rL+M\) marks and their bill is \(MH_d\). Balance all these marks with \(f(x)=H_{dx+1}\), then subtract the idle bill. Each additional mark increases the balanced envelope by at most \(H_d\), so take the smallest permitted \(M=L-2\). When every root must carry body, first take \(M=\max(L-2,n-2rL)\), and all balanced entries then have \(x\ge1\). Every version charges the \(Q\) thin queries.

## Portwise and global hypotheses

* **Portwise.** Each of 96 Type A ports has its own scalar caller, one header \(q\) for that port, \(r=2\) disjoint shears per host, and exact defect two individually. Query and body-idle charges belong to that port. The duplicated query control multiplies its total by 96. If costs or query counts differ at individual ports, sum the respective per-port bounds and charge the same complete joint native and helper inventory once per host. A port with larger defect needs another bound.
* **Global Type A.** Only after all A ports have a common normalized \(q\) and one common stage body label, with one native contact atomic across them, grant arbitrary scalar mixing across those ports. This is a conditional changed realization with \(r=192\) and exact defect 192. The block theorem forces only \(L-2\) additional global label uses. Multiplying that idle lower bound by 96 would be incorrect. A different port label cannot be silently identified with this global \(q\).
* Type B remains independent of Type A in both prices. Its full host block is outside the rank-one transvection theorem. The paid scalar model grants square address-local ordinary gates and applies no new assumption about available clean roles. The theorem requires fresh formal stage labels and forbids compound odd idles in Type A. It does not automatically apply when centers, helpers, or odd-phase ports are mixed.

The source checker recounts all 6,276 paid native MOVEs, binds all 1,101 productive helper observations, and checks the 96/8 split. The scan covers \(L=4\) through 50 and query counts \(0,2,4,6,8,16,32,64\) per port. The separate global screen uses \(0,2,192,384,576,768\) queries. For \(L=17,Q=0\) per port, 68 matched native incidences balance as 28 rank-17 and four rank-25 credited roles. Single-label idles require 15 additional calls per port. The relaxed 83 marks then balance as 13 rank-17 and 19 rank-25 roles before charging those 15 rank-eight calls.

| Cost screen | κ=.005 upper endpoint | κ=.0227 upper endpoint |
| --- | ---: | ---: |
| \(L=17,Q=0\), per port, grouped | +11.7205849078470 | −4879.6062232959227 |
| \(L=17,Q=0\), per port, single-label | −99.5435568369589 | −5360.2749870308955 |
| \(L=17,Q=8\) per port, single-label | −37.4111085119770 | −5094.2549533451234 |
| \(L=17,Q=0\), global, single-label | +10.5615834313386 | In the exact receipt |

At \(L=17\) the per-port single-label cases with \(Q=0,2,4,6,8\) all fail at .005 even though Type B is granted its full optimistic contribution. The grouped and global positive upper endpoints leave those cases open. For the per-port \(L=4,Q=64\) grouped case, the estimate shifts from −107.8035523105925 allowing bodyless odd roots to −188.6076685052561 when every root carries body.

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round7\recurrence\host_balance.py $complexPack --expect .\work\round7\recurrence\host-balance.json
~~~

The pricing check imports the previously pinned round5/recurrence/verify_joint_body_header.py for source hashes and directed rational arithmetic. Keep that path and recurrence/verify_bit_caller_bound.py relative to the package root and pass the same three fixed complex inputs used by the joint-body replay. Normal and optimized replays took 0.19 and 0.21 seconds within 14-second process limits. Their receipts have the same SHA-256 `0fff3fe4a83b26118e00e7cb2453c3b201384c4121840905c6a9613172849a6a`. AST parsing and tabnanny passed.
