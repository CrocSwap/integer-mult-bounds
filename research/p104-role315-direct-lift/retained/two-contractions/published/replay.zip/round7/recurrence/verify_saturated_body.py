"""Exact tests and prices for saturated BIT body transport."""

import argparse
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / "recurrence" / "verify_bit_caller_bound.py"
SPEC = spec_from_file_location("selected_bit", SOURCE)
CORE = module_from_spec(SPEC)
SPEC.loader.exec_module(CORE)
need = CORE.need


def xor(values):
    out = 0
    for v in values:
        out ^= v
    return out


def outer(column, row, n):
    return tuple(row if column >> i & 1 else 0 for i in range(n))


def compose(a, b):
    return tuple(xor(b[i] for i in CORE.selected(mask)) for mask in a)


def add(a, b):
    return tuple(x ^ y for x, y in zip(a, b, strict=True))


def canonical_simplex(n):
    one = (1 << n) - 1
    return [(1 << i, one ^ (1 << i)) for i in range(n)] + [(one, one)]


def candidates(n, at, prefix, pairs):
    column, row = pairs[at]
    if at in (0, n):
        # At the first/last slot the nominal prefix is 0 or I+N.
        # Take im P=span(u,x) and row P=span(v,y), with v x=y u=1.
        # Projector P itself is u (y+(yx)v)+x v.
        xs = [x for x in range(1, 1 << n) if CORE.parity(row, x)]
        ys = [y for y in range(1, 1 << n) if CORE.parity(y, column)]
        return sorted({add(outer(column, y ^ (row if CORE.parity(y, x) else 0), n),
                           outer(x, row, n)) for x, y in product(xs, ys)})
    if not at % 2:
        return []
    b_col = sum(CORE.parity(r, column) << i for i, r in enumerate(prefix))
    row_b = xor(prefix[i] for i in CORE.selected(row))
    need(CORE.parity(row, b_col) and CORE.parity(row_b, column), "Wrong interior form")
    corner = row_b ^ (row if CORE.parity(row_b, b_col) else 0)
    return [add(outer(column, corner, n), outer(b_col, row, n))]


def clock_census(n):
    pairs = canonical_simplex(n)
    choices = []
    prefix = (0,) * n
    identity = tuple(CORE.identity(n))
    for i, (column,row) in enumerate(pairs):
        projectors = candidates(n,i,prefix,pairs)
        expected = 2**(2*n-4) if i in (0,n) else i % 2
        need(len(projectors) == expected, "Wrong number of commuting local rank-two frames")
        ng = outer(column,row,n)
        for p in projectors:
            need(CORE.rank(p) == 2 and compose(p,p) == p and
                 compose(p,ng) == compose(ng,p) == ng and
                 compose(p,prefix) == compose(prefix,p), "Wrong active frame")
        choices.append(projectors)
        prefix = add(prefix,ng)
    need(prefix == identity, "Header generators did not sum to I")
    # For a fixed stage triple there must be a pair of non-extreme clocks,
    # or one compulsory interior frame and both endpoint families. Check
    # all pairs with one of the compulsory interior frames before pairing
    # the two endpoint sets. The written theorem handles all even n>=4.
    tested = pair_checks = first_tests = second_tests = 0
    for i,j,k in combinations([s for s in range(n+1) if choices[s] and n >= 4],3):
        fixed = next(s for s in (i,j,k) if s not in (0,n))
        a,b = [s for s in (i,j,k) if s != fixed]
        p = choices[fixed][0]
        first_tests += len(choices[a])
        second_tests += len(choices[b])
        first = [x for x in choices[a] if compose(p,x) == compose(x,p)]
        second = [x for x in choices[b] if compose(p,x) == compose(x,p)]
        tested += 1
        for x,y in product(first,second):
            pair_checks += 1
            need(compose(x,y) != compose(y,x), "Three distinct idle-free native pulses found")
    need(any(compose(p,r) == compose(r,p) for p in choices[0] for r in choices[1]),
         "Two eligible masks should be possible")
    if n == 2:
        positive = choices[0][0] == choices[1][0] == choices[2][0] == identity
        need(positive,"The two-root exception should have three full-rank idle-free bodies")
    else:
        positive = False
    return {"roots":n,"choices_by_clock":list(map(len,choices)),"clock_triples":tested,
            "commuting_two_clock_control":True,"last_pair_tests":pair_checks,
            "first_pair_tests":first_tests+second_tests,"three_clock_n2_control":positive}


def add_pulse(events, n, pair, stage):
    u,v = pair
    basis = CORE.transvection_basis(u,v,n)
    events.extend(CORE.lower_linear(CORE.inverse_rows(basis)))
    events.append(["ADD",0,1])
    events.append(["LOCAL", stage,1,0] if stage else ["QUERY",0,1])
    events.extend(CORE.lower_linear(basis))


def unequal_relay_fixture(first, second):
    events = []
    n = 2
    add_pulse(events,n,(1,2),0)
    if first:
        events.extend([["IDLE_ONE",r,[2]] for r in range(n)])
    add_pulse(events,n,(2,1),1)
    add_pulse(events,n,(1,2),0)
    if second:
        events.extend([["IDLE_ONE",r,[3]] for r in range(n)])
    target = [1] + ([2] if first else []) + ([3] if second else [])
    caller = {"roles":n,"ports":111,"body_rank":7,"stages":3,"events":events,
              "diagonal":[{"q":1,"stages":target} for _ in range(n)]}
    # The 3 eps-shears have nominal identity and sum to a single
    # nilpotent (not I). Explicitly convert to the usual U,L,U word.
    for j,e in reversed(list(enumerate(events))):
        if e[0] in ("QUERY","LOCAL"):
            need(events[j-1] == ["ADD",0,1], "Pulse not normalized")
            events.pop(j-1)
    events.append(["SWAP",0,1])
    need(CORE.full_caller_identity(caller), "Unequal relay endpoint failed")
    mutant = {**caller,"events":events[:-1]}
    need(not CORE.full_caller_identity(mutant), "Missing exiting SWAP passed")
    return {"relay_widths":[first,second],"target_width":1+7+first+second,
            "body_idles":sum(e[0]=="IDLE_ONE" for e in events),"literal_events":events}


def net_profile(native_paid,native_targets,L):
    out = Counter({r:L*q for r,q in native_targets.items()})
    out.subtract({r:L*q for r,q in native_paid.items()})
    return out


def margin(hist,k):
    return CORE.format_bounds(CORE.moment(hist,k,10000))


def two_root_prices(native_paid,native_targets):
    cases = {}
    for a,b in ((0,0),(1,0),(1,1),(7,0),(7,7),(2,15),(3,32),(128,1)):
        whole = net_profile(native_paid,native_targets,1)
        whole[1] -= 222
        whole[8+a+b] += 222
        for d in (a,b):
            if d:
                whole[d] -= 222
        cases[f"{a},{b}"] = {str(k):margin(whole,k) for k in (0,50,227)}
    return cases


def upper_price(native_paid,native_targets,L,n,individual,all_body=False):
    # Actual Q = n+1-L, while all n roots are granted q even when bodyless.
    q = n+1-L
    need(n % 2 == 0 and q >= 0, "Invalid minimum header case")
    net = net_profile(native_paid,native_targets,L)
    mandatory_idle = max(0,L-2) if n >= 4 else 0
    loss_marks = max(0, 2*L+int(individual)*mandatory_idle-n)
    net[7] += 222*L-222*loss_marks
    net[14] += 111*loss_marks
    net[1] += 111*(n-q)
    if all_body:
        # Grant all n prefix fields a nonempty body (δ=H8−H7 instead of 1).
        net[1] -= 111*n
        net[7] -= 111*n
        net[8] += 111*n
    return net


def crown_prices(native_paid,native_targets):
    out={}
    for L in range(1,19):
        n = L-1 if L % 2 and L>1 else L
        if n % 2:
            n += 1
        if not n:
            continue
        grouped = upper_price(native_paid,native_targets,L,n,False)
        single = upper_price(native_paid,native_targets,L,n,True)
        single_body = upper_price(native_paid,native_targets,L,n,True,True)
        out[str(L)] = {"roots":n,"thin_queries":n+1-L,
                       "mandatory_active_labels_with_idles":max(0,L-2) if n>=4 else 0,
                       "arbitrary_grouped_body_upper":margin(grouped,50),
                       "single_body_upper":margin(single,50),
                       "single_body_with_no_bodyless_roots":margin(single_body,50),
                       "single_body_at_0227":margin(single,227)}
    return out


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("repo",type=Path)
    cli.add_argument("--expect",type=Path)
    args=cli.parse_args()
    _,paid,targets,_,_=CORE.verify_sources(args.repo)
    classes=[clock_census(n) for n in (2,4,6,8)]
    quotes=crown_prices(paid,targets)
    relays=two_root_prices(paid,targets)
    payload=json.dumps({"status":"PASS_SATURATED_BODY_TRANSPORT","census":classes,
                        "unequal_paid_quote":relays,"minimum_pulse_caps":quotes,
                        "fixtures":[unequal_relay_fixture(a,b) for a,b in ((0,0),(7,7),(2,15),(0,7))]},
                       indent=2,sort_keys=True)
    if args.expect:
        need(args.expect.read_text(encoding="utf-8").rstrip("\n")==payload,"Receipt changed")
    print(payload)


if __name__=="__main__":
    main()
