# Signed-sector analogue of the two-body limit

The two-idle-free-body limit also holds over a field of characteristic different from two when the complete word consists of \(n+1\) rank-one relative sector transvections and its relative endpoint is \(-I_n\), for even \(n\ge4\). This includes a one-shear complex host with the same rank-two body on its two active roles. The paired Type A host and the bidirectional Type B host of #7546 require other bounds. [Exact complex source candidate #7546](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

Set bodies to one and evaluate at \(q=i,-i\). Body-only movement specializes to identity when its formal variables are one. For each odd transvection, the ordinary nominal inverse followed by the opposite-sector operator is one rank-one unipotent increment \(I+u_jv_j\), as in the prior signed complement note. The nominal prefix brings the row and column into the common root basis. If a body label occurs only on this host, the nominal relative body at the \(i\) sector forces its rank-two role projector \(P_j\) to equal the final coordinate projector. For the body to agree in the other sector, \(P_j\) must commute also with the relative prefix \(R_j=(I+u_{j-1}v_{j-1})\cdots(I+u_1v_1)\). In both sectors it fixes its own supporting rows and columns, so \(P_j u_j=u_j\) and \(v_jP_j=v_j\).

## Signs replace binary equality

Let \(U,V\) be the column and row stacks, \(C=VU\), and \(L\) the strict lower triangle of \(C\). Expanding the relative product gives \(U(I-L)^{-1}V=-2I_n\). Thus \(K=I-L+C/2\) has rank one when the number of pulses is \(m=n+1\). Its diagonal is one. Write \(K=ab^T\) with \(a_i,b_i\ne0\). Rescale \(u_i\) by \(a_i\) and \(v_i\) by \(a_i^{-1}\), leaving each \(u_i v_i\) fixed. This diagonal similarity takes \(K\) to the all-one matrix. Consequently the renormalized pairings are

\[
v_i u_j=2\,\operatorname{sgn}(j-i).
\]

The principal \(n\)-by-\(n\) pairing matrix is invertible when \(n\) is even. More precisely the kernel of the full odd-size sign matrix is the one-dimensional alternating vector: subtracting its consecutive row equations gives \(z_{k+1}=-z_k\), and the alternating vector satisfies the first row. Every proper subset of columns of \(U\) and rows of \(V\) is independent. In fact \(U,V\) each have rank \(n\) by the endpoint identity, so their kernels must have the same one-dimensional relation as the sign matrix and its transpose.

## Three candidate body masks fail

As in BIT, their rank-two coordinate masks pairwise intersect, since all off-diagonal \(v_i u_j\) are nonzero. If the three masks together use at most three coordinates, independence forces all three columns and rows to be bases of that three-dimensional coordinate space. The corresponding principal three-by-three block \(C\) would be invertible. That block is skew-symmetric of odd size and has zero determinant. If they use four or more coordinates, they must be three distinct edges of one star.

For a star let \(j<i<k\) be those three pulses. On the active space of \(P_i\), \(v_j\) and \(v_k\) are both proportional to the hub coordinate. Their proportionality constants are nonzero because \(v_j u_i\) and \(v_k u_i\) are nonzero. Since \(R_i\) commutes with \(P_i\), \(R_i u_i\) is also in that plane. Therefore the following ratios must agree:

\[
\frac{v_j R_i u_i}{v_j u_i}=\frac{v_k R_i u_i}{v_k u_i}.
\]

The actual prefix expansion gives
\[
R_i u_i = u_i+\sum_{a<i} t_a u_a,\qquad t_a=2(-1)^{a-1}.
\]
Indeed a new earlier pulse \(a<i\) applies \(v_a\) to \(u_i+\sum_{b<a}t_bu_b\), giving \(2-2\sum_{b<a}t_b\) and hence the alternating sequence. Put \(S=\sum_{a<i}t_a\). For \(k>i\) the ratio is \(1+S\). For any \(j<i\) it is \(1+S-t_j-2\sum_{a<j}t_a=S-1\). The identity \(t_j+2\sum_{a<j}t_a=2\) follows from the same recurrence. The two ratios differ by two, completing the proof.

At \(n=2\), the 3-pulse full-plane witness is allowed. The standard-library replay constructs the canonical rational relative word in dimensions 2, 4, 6, 8, 10 and 12. It checks the literal nominal and opposite-sector products, the exact prefix coefficient, all earlier/middle/later triples, and the rejection of a last-shear sign change. The extrapolation is the written proof, not the finite test.

An actual Type A HOST2 contains an adjacent disjoint pair. Those pairings vanish, forcing complement rank at least two from the first host in the existing signed complement theorem. Type B is a full sector block, so its relative operator need not be a rank-one unipotent increment. The present saturation law applies if a new physical programme actually offers separate single-shear types at this minimum relative pulse count. It does not give a stronger invoice bound for the extant Type A plus Type B stage word.

~~~powershell
& $py -I -O -B -S -W error .\work\round7\recurrence\verify_signed_saturation.py --expect .\work\round7\recurrence\signed-saturation.json
~~~

This addendum uses no source executables and requires only the system's standard library.
