"""Source-bound balanced-incidence estimates for grouped saturation."""

import argparse
from collections import Counter
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / "round5" / "recurrence" / "verify_joint_body_header.py"
SPEC = spec_from_file_location("joint_body_header", SOURCE)
JOINT = module_from_spec(SPEC)
SPEC.loader.exec_module(JOINT)
CORE = JOINT.CORE
need = CORE.need


def balanced(incidence, roots, body, header, stages=None):
    need(stages is None or incidence <= roots*stages, "A target reused a stage label")
    a, b = divmod(incidence, roots)
    out = Counter({a*body+header:roots-b})
    if b:
        out[(a+1)*body+header] += b
    return out


def margin_interval(hist, point):
    return CORE.moment(hist, *point)


def profiles(paid, helpers, count, port_count, extra_queries, shape):
    # Retain the full joint native paid and helper accounts. Grant B its
    # exact kernel bound 8(H8+H9+H1) each host. Mix A only with A.
    body = 8
    block_rank = 2 if shape == "per_port" else 192
    bill_scale = port_count if shape == "per_port" else 1
    roots = block_rank*(count-1)+extra_queries
    need(roots % 2 == 0, "Relative endpoint determinant has wrong parity")
    common = Counter({r:q*count for r,q in helpers.items()})
    common.subtract({r:q*count for r,q in paid.items()})
    common.update({1:8*count,8:8*count,9:8*count})
    common[1] -= bill_scale*extra_queries
    out = {"roots":roots, "root_count_multiplier":bill_scale,
           "thin_queries":extra_queries, "mandatory_label_reuses":count-2}
    for variant in ("grouped", "one_label"):
        idle = count-2 if variant == "one_label" else 0
        marks = 2*block_rank*count+idle
        profile = balanced(marks,roots,body,1,count)
        actual = common.copy()
        actual.update({r:q*bill_scale for r,q in profile.items()})
        actual[body] -= bill_scale*idle
        # If every root carries a body, then the cutoff applies to the
        # real body width k, possibly with zero allocated native marks x.
        # This second linearized head bound is valuable when x=0 can occur.
        all_body = common.copy()
        if variant == "grouped":
            # k>=1 even when the determinant matching allots x=0 native marks.
            # Their header increase is at most H9-H8.
            for r,q in profile.items():
                if r == 1:
                    all_body[body+1] += q*bill_scale
                    all_body[body] -= q*bill_scale
                else:
                    all_body[r] += q*bill_scale
        else:
            raised_marks = max(roots,marks)
            for r,q in balanced(raised_marks,roots,body,1,count).items():
                all_body[r] += q*bill_scale
            all_body[body] -= (raised_marks-2*block_rank*count)*bill_scale
        result = {"credited_profile_envelope":profile, "separately_paid_single_label_idles":idle,
                  "minimum_total_marks":marks, "all_odd_margin":{}, "body_bearing_margin":{}}
        for k, point in ((".005",(5,1000)),(".0227",(227,10000))):
            a = margin_interval(actual, point)
            b = margin_interval(all_body, point)
            result["all_odd_margin"][k] = CORE.format_bounds(a)
            result["body_bearing_margin"][k] = CORE.format_bounds(b)
        if variant == "one_label":
            result["actual_total_body_marks_must_also_be_at_least_roots"] = True
        out[variant] = result
    return out


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack",type=Path)
    cli.add_argument("--expect",type=Path)
    args=cli.parse_args()
    paid,helpers=JOINT.read_complex(args.complex_pack)
    result = {"per_port":{}, "global_type_A":{}}
    for count in range(4,51):
        for q in (0,2,4,6,8,16,32,64):
            result["per_port"][f"L{count}_Q{q}"] = profiles(paid,helpers,count,96,q,"per_port")
        for q in (0,2,192,384,576,768):
            result["global_type_A"][f"L{count}_Q{q}"] = profiles(paid,helpers,count,96,q,"global_type_A")
    focus = result["per_port"]["L17_Q0"]
    need(focus["grouped"]["credited_profile_envelope"]=={17:28,25:4},
         "Grouped balanced marks changed")
    need(focus["one_label"]["credited_profile_envelope"]=={17:13,25:19},
         "Single-label balanced marks changed")
    need(Fraction(focus["one_label"]["all_odd_margin"][".005"][1]) < -99,
         "Material per-port single-label exclusion changed")
    need(Fraction(result["global_type_A"]["L17_Q0"]["one_label"]["all_odd_margin"][".005"][1]) > 0,
         "Global saturation must not claim the per-port exclusion")
    payload=json.dumps({"status":"PASS_SATURATED_COMPLEX_PRICE_ENVELOPE", "cases":result},
                       indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Price receipt changed")
    print(payload)


if __name__=="__main__":
    main()
