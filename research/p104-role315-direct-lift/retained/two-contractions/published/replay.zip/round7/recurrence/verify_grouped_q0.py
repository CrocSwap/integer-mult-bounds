"""Directed four-branch rejection of the grouped-idle, saturated A-Q0 bill."""

import argparse
from collections import Counter
from importlib.util import module_from_spec, spec_from_file_location
from itertools import product
import json
from pathlib import Path
from time import monotonic


SOURCE = Path(__file__).with_name("host_balance.py")
SPEC = spec_from_file_location("host_balance", SOURCE)
BALANCE = module_from_spec(SPEC)
SPEC.loader.exec_module(BALANCE)
CORE = BALANCE.CORE
need = CORE.need
ROOTS, NATIVE_MARKS, MIN_IDLE_MARKS, STAGES = 32, 68, 15, 17
SAVING = (5, 1000)


def h(rank):
    return CORE.price(rank, *SAVING)


def role_value(x, y):
    k = x+y
    if not k:
        return h(1)
    body = CORE.scaled(h(8*k), -(k-x), k)
    return CORE.add(h(8*k+1), body)


def dp(upper, deadline):
    """Independent small DP, in upper-directed integer grid units."""
    options = [(x,y,upper[x,y][1]) for (x,y) in sorted(upper) if (x,y)!=(0,15)]
    row_width = MIN_IDLE_MARKS+1
    area = (NATIVE_MARKS+1)*row_width
    start = [None]*area
    start[0] = 0
    completed = []
    visited = 0
    for m in range(ROOTS):
        need(monotonic()<deadline, "Grouped envelope DP exceeded its deadline")
        dest = [None]*area
        parents = [None]*area
        for idx, current in enumerate(start):
            if current is None:
                continue
            a,b = divmod(idx,row_width)
            for x,y,credit in options:
                if a+x>NATIVE_MARKS or b+y>MIN_IDLE_MARKS:
                    continue
                if (NATIVE_MARKS+MIN_IDLE_MARKS-a-b-x-y)>(ROOTS-m-1)*STAGES:
                    continue
                visited += 1
                j = (a+x)*row_width + b+y
                proposed = current+credit
                if dest[j] is None or proposed>dest[j]:
                    dest[j], parents[j] = proposed, (x,y)
        start = dest
        completed.append(parents)
    target = area-1
    top = start[target]
    need(top is not None,"No grouped relaxed DP state reached the target")
    profile = Counter()
    for parents in reversed(completed):
        x,y = parents[target]
        profile[x,y] += 1
        target -= x*row_width+y
    need(target == 0 and sum(profile.values())==ROOTS, "Wrong traceback")
    lower = sum(upper[pair][0]*count for pair,count in profile.items())
    return (lower,top),profile,visited


def native_common(paid,helper):
    hist = Counter({j:STAGES*v for j,v in helper.items()})
    hist.subtract({j:STAGES*v for j,v in paid.items()})
    hist.update({1:8*STAGES,8:8*STAGES,9:8*STAGES})
    return CORE.moment(hist,*SAVING)


def encode(native,port_value):
    interval = CORE.add(native, CORE.scaled(port_value,96))
    need(interval[1] < 0, "Branch no longer excludes a positive moment")
    return CORE.format_bounds(interval)


def matmul(a,b):
    return tuple(tuple(sum(x*y for x,y in zip(row,col,strict=True)) for col in zip(*b)) for row in a)


def matrix_sum(a,b):
    return tuple(tuple(x+y for x,y in zip(u,v,strict=True)) for u,v in zip(a,b,strict=True))


def outer(u,v):
    return tuple(tuple(a*b for b in v) for a in u)


def coordinate_projection(n,indices):
    return tuple(tuple(int(i==j and i in indices) for i in range(n)) for j in range(n))


def add_scaled_identity(a, exponent):
    n = len(a)
    return matrix_sum(coordinate_projection(n,range(n)),
                      tuple(tuple((exponent-1)*q for q in row) for row in a))


def controls():
    n = 7
    unit = coordinate_projection(n,(0,))
    masks = ((0,1,2,3,4),(0,1,2,3,5),(0,1,2,4,6),(0,3,4,5,6))
    targets = tuple(coordinate_projection(n,m) for m in masks)
    native = tuple(coordinate_projection(n,m[1:]) for m in masks)
    need(set.intersection(*map(set,masks)) == {0},"Detachment fixture must have unique common coordinate")
    options = tuple(product((-1,0,1),repeat=n))
    admissible = set()
    for column,row in product((u for u in options if u[1:]==(0,)*(n-1)),
                              (v for v in options if v[1:]==(0,)*(n-1))):
        if sum(x*y for x,y in zip(column,row,strict=True)) == 1:
            admissible.add(outer(column,row))
    need(admissible=={unit},"Both-sided rank-one support should force E_t")
    one_sided = outer((1,0,0,0,0,0,0),(1,1,0,0,0,0,0))
    need(matmul(one_sided,one_sided)==one_sided and one_sided!=unit,
         "Column-only support control should admit a noncoordinate idempotent")
    tested = 0
    for p,f in zip(native,targets,strict=True):
        need(matmul(p,unit)==matmul(unit,p)==coordinate_projection(n,()),"Zero overlap not forced")
        for d in (2,3,5):
            a=add_scaled_identity(p,d)
            b=add_scaled_identity(unit,d)
            need(matmul(a,b)==matmul(b,a)==add_scaled_identity(f,d),"Detachable whole label failed")
            tested += 1
    # A shared second coordinate can keep two different phase projections.
    # Their complements have identical combined body target in both sectors.
    plus=((1,0),(0,0)); minus=((1,1),(0,0)); identity=coordinate_projection(2,range(2))
    for p in (plus,minus):
        other=tuple(tuple(x-y for x,y in zip(row,q,strict=True)) for row,q in zip(identity,p,strict=True))
        need(matmul(add_scaled_identity(p,3),add_scaled_identity(other,3))==add_scaled_identity(identity,3),
             "Two-coordinate negative control must allow differing projectors")
    need(plus!=minus,"Shared second coordinate control lost sector change")
    return {"unique_common_coordinate":True,"coordinate_detachment_operator_checks":tested,
            "column_only_control_rejects":True,"larger_intersection_control_rejects":True}


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack",type=Path)
    cli.add_argument("--expect",type=Path)
    args=cli.parse_args()
    paid,helper=BALANCE.JOINT.read_complex(args.complex_pack)
    native=native_common(paid,helper)
    price = {(x,y):role_value(x,y) for x in range(STAGES+1)
             for y in range(min(MIN_IDLE_MARKS,STAGES-x)+1)}
    not_pure,profile,steps=dp(price,monotonic()+10)
    need(profile=={(1,15):1,(2,0):26,(3,0):5},"Unexpected dominating split/mixed profile")
    pure_delta = price[0,15]
    high_mark_roles = CORE.moment({17:26,25:4,33:1},*SAVING)
    pure_balanced_others = CORE.moment({17:25,25:6},*SAVING)
    one_short_surcharge = CORE.add(CORE.scaled(h(24),1,3),CORE.scaled(h(120),-1,15))
    need(one_short_surcharge[0]>0,"Grouped idle surcharge sign changed")
    leaf_values = {"split_or_mixed_assignment":not_pure,
                   "one_pure_role_another_at_least_four_marks":CORE.add(pure_delta,high_mark_roles),
                   "one_pure_role_other_degree_at_most_three_and_a_short_idle":CORE.add(
                       CORE.add(pure_delta,pure_balanced_others),CORE.scaled(one_short_surcharge,-1))}
    result={"status":"PASS_GROUPED_QUERIES_ZERO_TYPE_A_PRICING", "branch_margin":{
        label:encode(native,value) for label,value in leaf_values.items()},
        "detachment_controls":controls(),
        "remaining_algebraic_branch":"all grouped idles detach as the same coordinate role; forbidden by the saturation theorem",
        "earlier_looser_grouped_bound":CORE.format_bounds(CORE.add(native,CORE.scaled(
            CORE.moment({17:28,25:4},*SAVING),96))),
        "split_dp_argmax":{f"{x},{y}":c for (x,y),c in profile.items()},
        "split_dp_transitions":steps,
        "short_idle_surcharge_per_port":CORE.format_bounds(one_short_surcharge)}
    payload=json.dumps(result,indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Price receipt changed")
    print(payload)


if __name__=="__main__":
    main()
