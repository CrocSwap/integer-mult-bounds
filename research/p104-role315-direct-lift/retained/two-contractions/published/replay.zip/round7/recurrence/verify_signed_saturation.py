"""Exact finite recurrence controls for a signed sector saturation proof."""

import argparse
from itertools import combinations
from fractions import Fraction as Q
import json
from pathlib import Path


def eye(n):
    return [[int(i == j) for j in range(n)] for i in range(n)]


def add(a, b, scale=1):
    return [[x + scale * y for x, y in zip(row, other, strict=True)]
            for row, other in zip(a, b, strict=True)]


def mm(a, b):
    return [[sum(x*y for x,y in zip(row,col,strict=True)) for col in zip(*b)] for row in a]


def dot(a, b):
    return sum(x*y for x,y in zip(a,b,strict=True))


def outer(a, b):
    return [[x*y for y in b] for x in a]


def sg(i):
    return int(i>0)-int(i<0)


def need(ok, text):
    if not ok:
        raise ValueError(text)


def terms(n):
    u = eye(n) + [[(-1)**(n-j) for j in range(1,n+1)]]
    v = [[2*sg(j-i) for j in range(1,n+1)] for i in range(1,n+2)]
    need(all(dot(row,col)==2*sg(j-i) for i,row in enumerate(v)
             for j,col in enumerate(u)), "Wrong exact sequential Gram")
    return u,v


def check(n):
    u,v = terms(n)
    identity = eye(n)
    prefix = identity
    opposite_prefix = identity
    nominal_prefix = identity
    triples = zero_prefix_checks = 0
    prefixes = []
    for i in range(n+1):
        prefixes.append(prefix)
        value = [dot(row,u[i]) for row in prefix]
        want = [u[i][j]+sum(2*(-1)**a*u[a][j] for a in range(i)) for j in range(n)]
        need(value==want,"Chronological expansion of R_i u_i failed")
        for j,k in combinations([a for a in range(n+1) if a!=i],2):
            if j<i<k:
                left=Q(dot(v[j],value),dot(v[j],u[i]))
                right=Q(dot(v[k],value),dot(v[k],u[i]))
                need(right-left==2, "Middle-star ratio did not retain chronology")
                triples += 1
        generator = outer(u[i],v[i])
        if i%2==0:
            need(dot(v[i],value)==0,"Even prefix should annihilate this pairing")
            zero_prefix_checks += 1
        else:
            need(dot(v[i],value)==-4,"Odd prefix lost the bilinear pair")
        # Explicit ordinary pre-cancelled sector factors: between consecutive
        # odd pulses, apply the inverse of each nominal + sector map.
        plus=add(identity,generator,Q(-1,2))
        minus=add(identity,generator,Q(1,2))
        inverse_plus=minus
        nominal_prefix=mm(inverse_plus,mm(plus,nominal_prefix))
        opposite_prefix=mm(inverse_plus,mm(minus,opposite_prefix))
        prefix=mm(add(identity,generator),prefix)
    need(nominal_prefix==identity and opposite_prefix==prefix, "Sector fixture conjugation failed")
    need(prefix==[[int(i==j)*(-1) for j in range(n)] for i in range(n)], "Wrong −I endpoint")
    # Same pair sign specializations fail if reversed relative signs are waived.
    mutated=mm(add(identity,outer(u[-1],v[-1]),-1),prefixes[-1])
    need(mutated!=prefix,"Last pulse sign mutation escaped the endpoint test")
    return {"dimension":n,"pulses":n+1,"early_late_triples":triples,
            "even_prefix_pair_checks":zero_prefix_checks,"opposite_sign_rejected":True}


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--expect",type=Path)
    args=cli.parse_args()
    obj={"status":"PASS_SIGNED_SATURATION_CONTROLS", "controls":[check(n) for n in range(2,13,2)]}
    payload=json.dumps(obj,indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Receipt changed")
    print(payload)


if __name__=="__main__":
    main()
