# Saturated BIT headers force paid body transport

For a scalar BIT caller on \(n\ge4\) independent roots, obtaining an odd header on all roots with the minimum \(n+1\) odd pulses permits at most **two native calls whose distinct body labels are used nowhere else**. Consequently all but at most two of \(L\) distinct native labels need an additional use. With one-label positive body idles and at most one thin query, the resulting moment bound is negative at .005 for every \(L\le18\). Arbitrary grouped positive idles also fail in that minimum-query family through \(L=11\) under the weaker overlap debit.

A separate exact two-root caller uses one actual #7001 native and two arbitrary-width direct relays. Its strict best choice at positive saving removes both relay bodies. The full raw margin remains **−98.4557477630876** at .005 and **−220.4460926084396** at .0227. Both calculations retain the actual native paid jobs and independent helper credits. The square linear controls are granted free in these necessary cost tests. [Selected #7001 source](https://github.com/CrocSwap/integer-mult-bounds/pull/7001) · [Selected application review](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/docs/research/pr-intake-evidence/pr7000-application/PROOF-REVIEW.md)

## Formal contract

The central header \(q\) has order two over \(\mathbf F_2\). Independent commuting Laurent variables \(D_j\) represent bodies. A native acts on two roles by \(D_j(I+qE_{xy})\) with \(x\ne y\), and fixes its other roles. A thin query uses the odd transvection alone. A body idle applies a word of bodies to one role and supplies no odd pulse. Every root starts arbitrary. Ordinary role maps are invertible square scalars independent of the addresses. Each completed root independently receives \(q\) times its own body monomial. Each #7001 native helper return retains its independent input and is credited once.

An *idle-free label* appears **only once in the entire caller**, as the body of one rank-two native acting on \(D_j\) or its inverse. No other native or body idle uses it. The structural proof permits signs, grouping and repetition on other labels. The priced incidence bounds use the separately declared positive unit-incidence subclass.

## No three idle-free native bodies

Specialize all bodies to one, write \(q=1+\varepsilon\) with \(\varepsilon^2=0\), and absorb the invertible nominal prefixes into the input role basis. Each odd pulse is \(I+\varepsilon N_i\) with \(N_i=u_i v_i\) and \(v_i u_i=0\). The target gives \(\sum_i u_i v_i=I_n\). There are \(m=n+1\) odd occurrences. If \(U,V\) collect their columns and rows, \(UV=I_n\) implies that \(I_m+VU\) has rank one. Every diagonal entry is one, so the matrix is all-one over \(\mathbf F_2\). Thus \(v_i u_j=1\) for \(i\ne j\). The only relation among the columns is their all-one sum. Every proper subset of columns is independent.

For one idle-free \(D_i\), restore that variable while setting all other bodies to one. Its normalized native has a rank-two projector \(P_i\) with \(P_iN_i=N_iP_i=N_i\). At \(q=1\), the body endpoint is exactly \(I+(D_i^{\pm1}-1)P_i\), so \(P_i\) is the final coordinate projector on the label's two roles. The full relative header prefix before the native is \(I+\varepsilon B_i\) with \(B_i=\sum_{j<i}N_j\). Pulling the body operator back through that prefix changes the projector to \((I+\varepsilon B_i)^{-1}P_i(I+\varepsilon B_i)\). The final endpoint has the same projector in both header coefficients. Equality of the full \(D_i\)-dependent term therefore requires \([P_i,B_i]=0\). The sign on the isolated Laurent variable does not change this conclusion.

Take three alleged idle-free calls. Their two-element coordinate masks pairwise intersect, since disjoint \(P_i,P_j\) would give \(v_i u_j=v_iP_iP_ju_j=0\). For distinct masks meeting at coordinate \(c\), both cross-pairings equal one. Each supported column and row is nonzero at \(c\), and nilpotence forces each also to be nonzero at its other coordinate. Each generator is therefore the two-by-two all-ones block on its own pair.

If two masks coincide and a third differs, the two coincident calls now have the same column, contrary to proper-subset independence. If all three coincide, their columns span at most dimension two. Thus the masks must be distinct, forming a triangle or a star. The three triangle columns sum to zero and are also forbidden.

For a star, let \(i\) be the chronological middle of the three calls and let \(j<i<k\) be the other two. On \(\operatorname{im}P_i\), the rows \(v_j,v_k\) both restrict to the hub coordinate. Commutation and \(P_i u_i=u_i\) give \(B_i u_i\in\operatorname{im}P_i\). If \(T\) is the set of earlier pulses, then \(B_i u_i=\sum_{a\in T}u_a\). For \(b\ne i\),

\[
v_bB_i u_i=|T|-\mathbf1_{b\in T}\pmod2.
\]

These two responses differ for \(b=j,k\), contradicting their identical restriction. This excludes three in every case.

For \(n=2\), three distinct body labels can all be used once on the same full two-role plane. The proof's proper-subset step needs \(n\ge4\). The verifier enumerates all commuting rank-two candidates at each clock for \(n=2,4,6,8\) in the canonical simplex basis. It checks every eligible clock triple for pairwise commutation at \(n\ge4\), a positive two-clock case, and the three-clock two-root exception. At an interior odd clock the candidate is unique because its image and row space are spanned by \(u_i,B_i u_i\) and \(v_i,v_iB_i\), respectively. At an interior even clock the four pairings of those two independent pairs vanish, giving no idempotent. At the first and last clocks the independent second column and second covector parametrize all compatible rank-two idempotents. The written proof covers every even \(n\).

## Complete positive-body price

Now each of the \(L\) natives has its own distinct positive body label, each carrying seven independent axes. Each body idle applies a nonempty set of such labels once each on one role. Each credited output uses a label at most once. Write \(H_r=r^{1-\kappa}\) and \(H_0=0\). The number of thin queries is \(Q=n+1-L\).

At \(q=1\), determinant degree for a body label equals two for its native plus one for each containing idle. Transport the projectors for that label into the input role basis using nominal scalar prefixes. Their sum is the final coordinate projector. Its rank equals the total number of source columns of these projections, so those columns are independent and span the exact target coordinate space. A nonzero determinant summand matches these columns bijectively to target incidences. Do this for every stage. An idle covering \(a\) labels has the same transported image column at all of them. Its nonzero coordinates belong to targets carrying all \(a\) labels.

On one target with \(k\) marks, apportion \(H_{7k}\) equally. Each mark earns \(H_7 k^{-\kappa}\). Each assigned idle mark lands on a target with \(k\ge a\), and the idle pays \(H_7 a^{-\kappa}\) per mark. This covers the assigned credit. An output with \(x\) native marks can then earn at most \(H_7 x k^{-\kappa}\le H_{7x}\) beyond its matched idles. Concavity gives \(xH_7-H_{7x}\ge(x-1)g\) for \(x\ge1\), with \(g=2H_7-H_{14}>0\). Since the native marks total \(2L\), the debit for any grouped positive idles is \(g\max(0,2L-n)\). A large idle group can occupy one otherwise empty role at its whole group tariff. This is why the count of mandatory further label uses does not simply add to the grouped debit.

For single-label idles, let \(M\) be their number. They pay \(MH_7\), and the total target marks are \(2L+M\). The same concavity loss can now be charged on all marks. For \(n\ge4\), at least \(L-2\) native labels need another use, so the debit is \(g\max(0,2L+M-n)\ge g\max(0,3L-2-n)\). At \(n=2\) use only \(g\max(0,2L-n)\).

With \(d\) the relevant overlap count and \(P_0,T_0\) the full paid and independently productive helper moments per #7001 occurrence, the net cap is

\[
L(T_0-P_0)+111[2LH_7-gd+n\delta-Q].
\]

Here \(\delta=1\) grants the isolated header value. If every root carries a body, \(\delta=H_8-H_7\) follows from decreasing increments of \(H\). This is a separate head/body estimate. Its minimum-header debit is already present as \(n-Q=L-1\) when \(\delta=1\). The independent joint-cut bound must not charge it a second time.

For \(Q\le1\), use \(n=L-1\) at odd \(L\ge3\) and \(n=L\) at even \(L\). The cases \(L=1,2,3\) also fail at .005 with arbitrarily many pure relay pulses and any positive body-only idles using the separate bound \(L(T_0-P_0)+111[2LH_7+L-1]\). Selected directed upper endpoints:

| \(L\) | Grouped idle cap at .005 | One-label idle cap at .005 | One-label, every root body-bearing at .005 |
| ---: | ---: | ---: | ---: |
| 4 | −68.8270011616285 | −79.4757510738625 | −86.1224959314575 |
| 7 | −42.5216269889670 | −69.1435017695518 | −79.1136190559443 |
| 11 | −0.3486281505956 | −48.2680027556482 | −64.8848648996357 |
| 12 | +15.5189965151143 | −37.7247530460554 | −57.6649876188403 |
| 17 | +62.9108701069616 | −16.9547542347929 | −43.5417336651728 |
| 18 | +78.7784947726714 | −6.4115045252001 | −36.3218563843775 |

Positive endpoints leave cases open. The structural theorem covers signed unrelated bodies, but the priced strengthening requires distinct native labels, positive unit incidences, and body-only idles. Mixed odd idles, rectangular role operations, and changed native tariffs require their own estimates. At .0227 the previous joint-cut proof independently rejects unchanged #7001 at all sizes.

## Mixed two-root caller with variable-width grouped moves

Use the exact \(U(q),L(q),U(q)\) word followed by the role swap. Give the middle pulse the full #7001 seven-axis body \(D\). The other two pulses are direct relays with independent body \(A,B\) of widths \(a,b\). At its original role contact a relay is exactly a thin query followed by a complete body job on each of the same two arbitrary roles. The body jobs commute with that relay's head. This realizes \(qABD\) on both roots. At a zero width the corresponding relay is a pure rank-one query, with no body job or dummy owner. For positive width the assumed physical moves are complete coordinate interchanges on predesignated disjoint contiguous intervals or the existing grouped same-owner adapter. No arbitrary rank-only fusion across independent inputs is used.

Credit \(222H_{8+a+b}\) and pay \(222(1+H_a+H_b)\) for auxiliary work, retaining \(T_0-P_0\) for the actual native. Concavity and subadditivity of \(H\) make \(a=b=0\) the strict best choice at \(0<\kappa<1\). The result remains negative at both test values. Four exact fixtures \((0,0),(0,7),(7,7),(2,15)\) replay their outputs and reject a missing exit swap. Bounds on further widths through 128 corroborate the universal inequality.

The general direct relay with body width \(b\) and head width \(h\) pays \(2H_b+H_h\). The joint cut for a common-body transvection gives it at most \(\tfrac32H_b+\tfrac12H_{b+h}+\tfrac12H_h\) in net capacity. Its difference from the bill is \(-\tfrac12(H_b+H_h-H_{b+h})<0\) when both widths are positive, and zero in the pure-head limit. Thus arbitrary such priced relays cannot repair the fixed native's negative joint bound at .0227, even if compound signed odd idles are granted separately at full tariff. Smaller-label geometry, a changed host tariff, or non-saturated transport with a genuinely new coupling remains needed.

## Reproduce

Run the two commands in PowerShell with the standard-library CPython 3.13.14:

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$repo = 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
& $py -I -O -B -S -W error .\work\round7\recurrence\verify_saturated_body.py $repo --expect .\work\round7\recurrence\saturated-body.json
~~~

The script imports the earlier work/recurrence/verify_bit_caller_bound.py for read-only canonical Git source pins, exact all-column replay, and outward integer-interval pricing. The finite clock searches have dimensions at most eight. Normal and optimized commands take about 1.20 and 1.18 seconds within their 22-second process limits. Their byte-identical SHA-256 is `4560c64747f32136ad7825c06746e8b92a96e6fc0e8443df697bd1892db63352`. AST parsing and tabnanny passed. No GPU computation or external write was used.
