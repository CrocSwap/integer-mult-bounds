# Saturated blocks with independent body labels

Let an atomic host on arbitrary scalar roles contain \(r\) disjoint odd shears and apply its own common Laurent body \(D_i\) to all \(2r\) participating roles. Thin odd operations carry one shear and no body. Ordinary maps are invertible on the same \(n\) roles, independent of bodies and even in the common header. Demand an independently returned odd header and a body monomial on every role. Write \(m\) for the total shear count, with a full host contributing \(r\). In the exact-defect case \(m-n=r\), **at most two full hosts can have body labels used only once** if the word has at least four full hosts. The statement holds for binary headers with \(q^2=1\) and signed complex headers in the sector comparison \(q=+i,-i\). Body-only idles may apply other signed or grouped Laurent labels. The pricing consequence below uses positive, unit body incidences.

## Normalize the rank defect

Move each odd pulse to the initial role basis using its nominal prefix after putting the bodies to one. Write a pulse as \(U_aV_a\), a rank-one nilpotent contribution at a thin event, and a rank-\(r\) block with \(V_aU_a=0\) at a full event. The latter identity follows because the constituent shears are on disjoint pairs, with no ordinary map between them inside the host. A full relative block is \(I+U_aV_a\) in the signed case, since the cross products of the disjoint relative factors vanish.

Let \(U,V\) be all columns and rows in order, and \(C=VU\). In BIT use the coefficient of \(\varepsilon=q+1\) with \(\varepsilon^2=0\). The all-odd endpoint forces \(UV=I_n\), and \(K=I_m+C\) has rank \(r\). For the signed sectors let \(L\) be the strict lower part of \(C\). Chronological multiplication gives \(U(I-L)^{-1}V=-2I_n\), and \(K=I_m-L+C/2\) has rank \(r\). Its kernel has dimension \(n\), seen by factoring the invertible \(I-L\) on the left and identifying the kernel of \(I+(I-L)^{-1}VU/2\) with the role space via \(U\).

In either case factor \(K=XY\) through dimension \(r\). A full event has principal diagonal block \(I_r\). Its row block \(X_a\) and column block \(Y_a\) are inverses. Replace \(U_a,V_a\) by \(U_aX_a,X_a^{-1}V_a\) within that event. This keeps its operator and zero internal pairings, preserves chronological multiplication, and makes both defect factors of every full event the identity. Then for distinct events \(a,b\),

\[
V_aU_b=X_aY_b\quad\text{in BIT},\qquad
V_aU_b=2\operatorname{sgn}(b-a)X_aY_b\quad\text{in the signed model}.
\]

Both cases force \(U,V\) to have role rank \(n\). A signed thin pulse has \(X_aY_a=1\), and a full event has \(Y_aX_a=I_r\).

## Three body labels would force incompatible returns

For a native label used only on its own full host, specialize all other body labels to one. In the nominal header sector the body coefficient forces the transported \(2r\)-role projector \(P_i\) to be the output's coordinate projector for that label. Comparing its whole Laurent coefficient in the other sector makes \(P_i\) commute with the relative prefix \(R_i\). For BIT this is the condition \([P_i,B_i]=0\) on the first-order prefix \(B_i=\sum_{a<i}U_aV_a\). The argument also allows a single inverse power, since the two coefficients of \(1,D_i^{-1}\) remain identifiable. The projectors satisfy \(P_iU_i=U_i\) and \(V_iP_i=V_i\). These facts use only the one-label specialization and the declared independent diagonal endpoint.

Suppose three such full events are \(j<i<k\) and their active coordinate sets are \(S_j,S_i,S_k\). Each pair intersects in at least \(r\) coordinates because its cross block \(V_aU_b\) has rank \(r\). The three-by-three principal block of \(C\) on these events has rank \(2r\). Its right kernel is \((x,x,x)\) in BIT and \((x,-x,x)\) in the signed case. For the left kernel the same forms work when transposed. One external full event detects all these null directions on each side. In the signed case its row response is \(\pm2x\) regardless of where it falls among the three events. Thus the corresponding three column groups of \(U\) and row groups of \(V\) have rank \(3r\) each. With \(W=S_j\cup S_i\cup S_k\), Sylvester's inequality applied on those coordinates gives

\[
|W|\ge 3r+3r-2r=4r.
\]

Since \(|S_j\cup S_k|\le 3r\), their union covers fewer than \(2r\) of the middle coordinates. The row maps \(V_jP_i\), \(V_kP_i\) each have rank \(r\), as is proved by pairing with \(U_i\). Their two row spans in a space of dimension less than \(2r\) therefore intersect in a nonzero row \(w\).

In BIT put \(S=\sum_{a<i}Y_aX_a\). Then \(V_j B_i U_i=S-I_r\) and \(V_k B_i U_i=S\), as the earlier event loses its own internal pairing. Pairing \(w\) against \(U_i\) first forces its two representations through \(V_jP_i,V_kP_i\) to have the same coefficient row. Pairing against \(B_iU_i\), which stays in \(P_i\), then forces that row to vanish.

For the signed case write \(R_iU_i=U_i+\sum_{a<i} U_a M_a\). The chronological coefficients satisfy

\[
M_a=2X_aT_a,\qquad T_a=I_r-\sum_{c<a}Y_cM_c,\qquad
T_{a+1}=(I_r-2Y_aX_a)T_a.
\]

Put \(S=\sum_{a<i}Y_a M_a\). The earlier row response divided by \(2\) is \(S-I_r\) because the internal term vanishes and the signs before event \(j\) reverse. The later response divided by \(-2\) is \(S+I_r\). Pairing \(w\) against \(U_i\) forces opposite coefficient rows, and pairing against \(R_iU_i\) gives \(4\lambda=0\) for either signed coefficient row \(\lambda\). This is impossible for nonzero \(w\) in characteristic different from two.

One can replace the external full host condition by a rank condition. If the external rows of \(X\) and external columns of \(Y\) have ranks \(\alpha,\beta\), they detect dimensions \(\alpha,\beta\) of the same triple kernels. The corresponding restricted column and row ranks become \(2r+\alpha,2r+\beta\). Their union has size at least \(2r+\alpha+\beta\), which gives the same intersection argument when \(\alpha+\beta>r\). Three full blocks on the same \(2r\) roles with no intervening thin events show the need for such a condition. They implement `upper(q)`, `lower(q)` and `upper(q)` on each disjoint pair, followed by a swap. Over BIT this is \(qI\) by \(q^2=1\) and characteristic two. Over the signed model it is \(qI\) by \(q^2=-1\). Their distinct single-use bodies all act on the entire role space.

## Implications for the original native tariffs

With \(L\ge4\) full events, at least \(L-2\) body labels require another use. For #7546 Type A, \(r=2\) at an individual port. Its two disjoint shears may use inverse header signs, which are included in the relative factor normalization. For the price test the two shears have the same native body and the q-even ordinary scalar maps and label schedule obey the formal contract. With distinct positive body labels and unit incidences, the exact per-port 17-stage minimum-defect estimate at \(\kappa=.005\) is at most **−99.54355684** in the complete A/B-separate invoice with only single-label Type A idles and no thin queries. It grants Type B its full optimistic joint-cut value. With zero thin queries and arbitrary grouped positive body idles, a second support argument and exact occupancy calculation sharpen the +11.72058491 relaxation to **−0.0119883509271**. A globally mixed Type A schedule pays a different bound and would need a common header and atomic common body across all participating ports. See `recurrence/HOST-BALANCE.md` and `recurrence/GROUPED-Q0.md` for the price and branch counts. Compound odd idles, non-saturated words, and direct A/B mixing are outside this theorem. [#7546 exact-head check](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050)

`host_defect.py` factors the exact sequential Gram for 45 bounded controls on widths 2–4 over \(\mathbf F_2,\mathbf F_5,\mathbf F_{13}\). It verifies 207 triple ranks and chronological responses, including thin pulses and nontrivial external defect support. It also checks the three-host counterexample and rejects a flipped signed relative factor. The written argument gives the all-width implication. These are sector and scalar recurrence results. They do not certify a changed physical native or integer multiplication supplier.
