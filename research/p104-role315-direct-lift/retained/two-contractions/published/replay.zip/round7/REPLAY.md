# Round 7 exact replay

Authenticate the included `SHA256.json` before use. Run the following from the extracted ZIP root with standard-library CPython 3.11 or newer and Git. The BIT clock verifier reads authenticated blobs at canonical commit `e54523517d0f03e58352e647c403a5af3e525a57`. All other inputs are in the bundle.

```powershell
$repo = 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
$word = 'inputs/7546-word.json.gz'
$caller = 'inputs/7113-caller.json'
$whole = 'inputs/7546-whole.json'
$out = (New-Item -ItemType Directory -Path 'run' -Force).FullName
python -I -B -S -W error round7/flag_gram.py
python -I -B -S -W error round7/host_defect.py
python -I -B -S -W error round7/central_characters.py $word $caller
python -I -B -S -W error round7/algebra/directed_flag_dual.py
python -I -B -S -W error round7/algebra/multi_head_flag.py
python -I -B -S -W error round7/algebra/path_contact_group.py
python -I -B -S -W error round7/recurrence/verify_saturated_body.py $repo --expect round7/recurrence/saturated-body.json
python -I -B -S -W error round7/recurrence/verify_signed_saturation.py --expect round7/recurrence/signed-saturation.json
python -I -B -S -W error round7/recurrence/host_balance.py inputs --expect round7/recurrence/host-balance.json
python -I -B -S -W error round7/recurrence/verify_grouped_q0.py inputs --expect round7/recurrence/grouped-q0.json
python -I -B -S -W error round7/independent/direct_complex_native.py $word $caller $whole "$out/direct-complex-native.json"
python -I -B -S -W error round7/independent/detach_type_b.py $word $caller $whole "$out/detach-type-b.json"
python -I -B -S -W error round7/independent/closed_middle.py $word "$out/closed-middle.json"
python -I -B -S -W error round6/singleton_relay.py
python -I -B -S -W error round6/independent/adjoint_prearrival.py $word "$out/adjoint-prearrival.json"
```

The three changed complex replays have an optional `--emit PATH`. Their checked normalized hashes are in the receipts. The pinned interval checker requires assertions enabled. Each complex native's old helpers and restoration are counted according to its actual changed interface. Python scripts emit JSON for proof-relevant equality checks. `check_replay_bundle.py` can extract and verify the release into a fresh path with a bounded process lifetime for each replay.

The proofs and numerical tables specify separate scopes for aligned and oblique groups, thin calls, independently credited returns, Type A, and Type B. Positive upper endpoints grant unbuilt relaxations. Finite native checks do not supply a rounded physical compiler, external tape or uniform multiplication assembly.
