# SPDX-License-Identifier: Apache-2.0
"""Check the signed-independent flag bound and its failure in a common shadow."""

from collections import Counter
from fractions import Fraction as Q
import json
from pathlib import Path
from runpy import run_path
import sys


BASE = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(BASE / "algebra"), str(BASE / "round3" / "algebra")]
from nine_cut_geometry import fitting_calibration, hamming_roots, primitive
from scan_bit_move_runs import load_word
from staged_two_way_routes import binary_rank, dirty_dependency_cut

PRICE = run_path(str(BASE / "helper_price.py"))


def need(ok, message):
    if not ok:
        raise ValueError(message)


def mm(left, right):
    return [[sum(x * y for x, y in zip(row, col, strict=True)) for col in zip(*right)] for row in left]


def hadamard_rows(heads):
    """Scale the actual P111 directions so that each squared length is four."""
    full = hamming_roots()
    by_line = {primitive(tuple(map(Q, vector))): vector for vector in full}
    rows = [by_line[primitive(vector)] for vector in heads]
    gram = mm(rows, list(zip(*rows)))
    need(all(not x % 2 for row in gram for x in row), "half Gram is not integral")
    gram = [[x // 2 for x in row] for row in gram]
    need(all(gram[i][i] == 2 and all(abs(x) <= 1 for j, x in enumerate(gram[i]) if i != j)
             for i in range(len(rows))), "bad scaled head support")
    return gram


def parity(mask):
    return mask.bit_count() % 2


def test_flag_kernel():
    """Check full two-direction ranks and their finite Bernoulli polynomials."""
    count = {}
    for mode, out_cap_bits in (("aligned", 254), ("mismatched", 253)):
        table = Counter()
        for j in range(256):
            x, y = j & 1, 0
            xx, yy = parity(j), parity(j & out_cap_bits)
            got = 0
            for side in range(2):
                columns = int(x == side) | (int(y == side) << 1)
                rows = [row & columns for row, color in ((1, xx), (3, yy)) if color != side]
                got += binary_rank(rows)
            base = int(x != xx) + yy
            extra = int(x == xx == 1 and yy == 0)
            need(got == base + extra, "independent two-input crossing rank")
            table[j.bit_count()] += got
        count[mode] = dict(sorted(table.items()))
    for numerator, denominator in ((0, 1), (1, 16), (2, 7), (1, 2)):
        p = Q(numerator, denominator)
        z = 1 - 2 * p
        expected = {"aligned": 2 * (1 - z**7) + p * (1 + z**7),
                    "mismatched": 2 * (1 - z**7) + p**2 * (1 - z**6)}
        for mode, values in count.items():
            total = 2 * sum(v * p**size * (1-p)**(8-size) for size, v in values.items())
            need(total == expected[mode], "exact Bernoulli parity kernel")
    return count


def bounds(net, denominator):
    out = {}
    for k in ("0", ".005", ".0227"):
        lo, hi = PRICE["power_sum"](net, Q(k))
        unit = PRICE["SCALE"] * denominator
        out[k] = {"lo": lo, "hi": hi, "unit": unit, "lower": lo / unit, "upper": hi / unit}
    return out


def gram_checks(word):
    heads, _, *_ = fitting_calibration(word)
    gram = hadamard_rows(heads)
    n = len(gram)
    ideal_low_rank_fit = [sum((1 ^ (v % 2)) << j for j, v in enumerate(row)) for row in gram]
    off_diagonal_only = [sum(int(v == 0) << j for j, v in enumerate(row)) for row in gram]
    monotone, descents = dirty_dependency_cut(word)
    need(monotone == off_diagonal_only and n == 111, "selected zero-descents X-to-Y response")
    need(ideal_low_rank_fit == [r ^ (1 << i) for i, r in enumerate(monotone)], "Gram shadow mismatch")
    need(binary_rank(ideal_low_rank_fit) == 9 and binary_rank(monotone) == 108, "rank of selected split")
    # The same cancellation can be expressed by the constant Boolean lift of B0
    # minus the low-rank integral lift. Off-diagonal oblique entries 0 or 2
    # distinguish the two lifts even though both have the same mod-two result.
    b_lift = [[1-v for v in row] for row in gram]
    discrepancy = Counter(((b_lift[i][j] - ((ideal_low_rank_fit[i] >> j) & 1)))
                          for i in range(n) for j in range(n))
    # This integer identity isolates only the diagonal, even though v mod two cannot.
    pairs = Counter(v for row in gram for v in row)
    for i, row in enumerate(gram):
        for j, v in enumerate(row):
            eye = int(i == j)
            need(v*v - v**4 == -12 * eye, "fourth-degree signed Gram control")
    # All the head span and projector-complement tests were done on the literal source.
    return {"ports": n, "pointwise_half_gram_multiplicities": dict(sorted(pairs.items())),
            "canonical_binary_fitting_rank": 9, "monotone_only_binary_rank": 108,
            "selected_descents": len(descents),
            "two_integral_lifts_of_same_binary_fitting_matrix_difference": dict(sorted(discrepancy.items()))}


def main():
    flag = test_flag_kernel()
    gram = gram_checks(load_word())
    # The symmetric cut has full tariff on every independent nested helper endpoint.
    # With all flags becoming generic only the two body terms survive its linear mass.
    aligned = bounds({1: 1, 7: 1, 8: -1}, 2)
    mismatch = bounds({1: 2, 2: -1, 6: 1, 7: -2, 8: 1}, 4)
    print(json.dumps({"status": "PASS_P111_FLAG_AND_EVEN_SHADOW_CONTROLS", "flag_selectors": flag,
                      "aligned_loss_per_head": aligned, "mismatched_extra_per_head": mismatch,
                      "frozen_word": gram}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
