# SPDX-License-Identifier: Apache-2.0
"""Emit two source-pinned P104 contractions, with independent whole-call checks."""

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
import gzip
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
from runpy import run_path
import sys
from tempfile import TemporaryDirectory
from time import monotonic


HERE=Path(__file__).resolve().parent
SOURCE=HERE/"source7546"
CAL=run_path(str(HERE/"calendar_fusion.py"))
AUDIT,CORE,NEED=(CAL[k] for k in ("AUDIT","CORE","NEED"))
ADJ=AUDIT["BASE"]["ADJ"]
PINS={
    "interval_gate.py":"60a743d13f668ef86db4b8215b4d5d04430a671ba6f1fe06d9c1c4c3dfe86da5",
    "check_recurrence.py":"d213bb365436b7dba9f51d8354ea58dd3f6e5256cbbbabc2784e4c3b0570a8d5",
    "envelopes.py":"783da6b5b450fc07434946cb9ec86070dfee01df6b5fa1c385cb024def2c9a9f",
    "independent_bounds.py":"198521def614fe78fa728f1dde2b7fb820c0c0e0ac3ad0c9224dccbf51eac0d5",
    "source_binding.py":"624c459311c58f3847b7713b818bfd340153abf42919f02ac9aa8892ed52a2bd",
    "SIGNED.json":"e2d722fc0486440e25af25b74f270f1292fcf8eceb116e27fcb48f055c96f6c7",
    "check_odd_caller_exact_grid.py":"abd5a5fd011b71e5b382cbc058855594d4f2fe7b049f375506675c0303180f54",
}
FUSIONS=(
    (166,41976,43482,327,783,907,()),
    (134,42076,43522,618,789,913,(42078,42079)),
)
DELTA={2:-3,3:-1,4:1,5:1}
GAP=Fraction(1,10**17)


def read_source(name):
    blob=(SOURCE/name).read_bytes()
    NEED(sha256(blob).hexdigest()==PINS[name],f"exact inherited source {name}")
    return blob


def source_module(name):
    read_source(name)
    spec=spec_from_file_location(name.removesuffix(".py"),SOURCE/name)
    module=module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    return module


def replace(text,old,new,count=1):
    NEED(text.count(old)==count,"unique inherited formula " + old)
    return text.replace(old,new)


def replay_caller_grid(caller_path,baseline):
    src=read_source("check_odd_caller_exact_grid.py").decode()
    src=replace(src,"root=Path(__file__).resolve().parent","root = result_folder")
    src=replace(src,'cpath=root/"ODD-TYPE-AB-CALLER.json"',"cpath = caller_pin")
    src=src[:src.rfind("\nprint(")]
    with TemporaryDirectory(dir=HERE,prefix="caller-grid-") as folder:
        output=Path(folder)
        exec(compile(src,str(SOURCE/"check_odd_caller_exact_grid.py"),"exec"),
             {"result_folder":output,"caller_pin":caller_path})
        fresh=json.loads((output/"ODD-CALLER-EXACT-GRID.json").read_bytes())
    NEED(fresh==baseline["checks"]["ODD-CALLER-EXACT-GRID.json"],"exact unchanged caller valuation and all Laurent outputs")
    return fresh


def exact_envelopes(word,old,caller,baseline,caller_grid,deadline):
    source_module("source_binding.py")
    src=read_source("envelopes.py").decode()
    src=replace(src,"(life, peak, owned_count) == (54, 43, 51)","(life, peak, owned_count) == (74, 50, 68)")
    src=replace(src,'elif op in ("LAMBDA", "IDLE_ONE"):','elif op in ("LAMBDA", "IDLE_ONE", "IDLE_ODD"):',2)
    src=replace(src,"all(0 <= r < 38 for r in ar) and all(38 <= r < 76 for r in br[:2])",
                """all(caller["types"]["A"]["offset"] <= r < caller["types"]["A"]["offset"] + caller["types"]["A"]["roles"] for r in ar) and all(caller["types"]["B"]["offset"] <= r < caller["types"]["B"]["offset"] + caller["types"]["B"]["roles"] for r in br[:2])""")
    src=replace(src,'all(1 <= k <= 18 for k in e[3])','all(1 <= k <= caller["stages"] for k in e[3])')
    src=replace(src,'j_order == list(range(1, 19))','j_order == list(range(1, caller["stages"] + 1))')
    src=replace(src,'word["public"] - len(mains) == 1061','word["public"] - len(mains) == 1101')
    src=replace(src,'physical_main_inputs=3952, fresh_arbitrary_helpers=18 * 1061,',
                'physical_main_inputs=sum(t["roles"]*len(t["ports"]) for t in caller["types"].values()), fresh_arbitrary_helpers=caller["stages"] * 1101,')
    module={}
    exec(compile(src,str(SOURCE/"envelopes.py"),"exec"),module)
    _,old_receipt=module["native_envelope"](old)
    expected=baseline["checks"]["ODD-PRECISION.json"]
    NEED(old_receipt["bounds"]==expected["rounded_native"]["bounds"],"independent source rounding control")
    native,native_receipt=module["native_envelope"](word)
    call_peak,call_receipt=module["caller_envelope"](caller,native,word)
    NEED(caller_grid==expected["caller_grid"],"rounded caller is rooted in the fresh signed exact grid")
    converter=source_module("independent_bounds.py")
    grid=converter.word_run(word,frac=25)
    NEED(grid["odd_scale_lcm"]==1125 and grid["dyadic_height"]==25,"fixed signed grid")
    NEED(monotonic()<deadline,"bounded common-grid and envelope work")
    height=caller_grid["grid_exponents"][0]+grid["dyadic_height"]
    mass=module["strict_power"](call_peak["M_context"][0])+caller_grid["caller_odd_scale_bits"]+(1125).bit_length()
    factor=2*max(height,mass)
    NEED(factor<=4096,"supported signed precision envelope")
    return {"original_rounding_power":{name:z["strict_power_of_two"] for name,z in old_receipt["bounds"].items()},
            "native_rounding":native_receipt,"caller_rounding":call_receipt["bounds"],
            "caller_adjoint":call_receipt["independent_adjoint"],"integer_grid":grid,
            "context_height":height,"context_mass_bits":mass,"context_multiplier":factor}


def fused_word(word,cases=FUSIONS):
    program=word["program"]
    patches={}
    for role,l,r,a,b,c,inside in cases:
        NEED(program[l]==["MOVE",role,a,b,False] and program[r]==["MOVE",role,b,c,False],"literal original contacts")
        patches[l]=[["MOVE",role,a,c,False]]
        patches[r]=[]
        for i in inside:
            patches[i]=[]
    return {**word,"program":[step for i,e in enumerate(program) for step in patches.get(i,[e])]}


def verify_full_coefficients(old,book,candidate,deadline):
    out=[AUDIT["trace"](w,deadline) for w in (old,book,candidate)]
    NEED(out[0][1:]==out[1][1:]==out[2][1:],"all public and owned rows and retirement contents")
    delta=out[2][0].copy()
    delta.subtract(out[1][0])
    NEED({r:c for r,c in delta.items() if c}==DELTA,"exact paid native rank difference")
    slots=out[2][1]
    return {"public_rows":out[2][2],"owned_lifetimes":sum(x[0]=="CLEAR" for x in slots),
            "unchanged_owned_moves":sum(x[0]=="MOVE" for x in slots),
            "public_coefficients":out[2][2]**2,"same_source_frames_and_owned_contents":True}


def phase_worker(task):
    pack,source,matrices=task
    role,a,b,c=source
    compiler,_=AUDIT["PHYS"]["load_pins"](Path(pack)/"7546-word.json.gz")
    A,B,C=(compiler.canonical_frame(9,v) for v in matrices)
    F=A.adjoint().then(C)
    reference=A.adjoint().then(B).then(B.adjoint()).then(C)
    rec,D=compiler.lower_child(F)
    AUDIT["PHYS"]["equal_signed_clifford"](F,D,True)
    AUDIT["PHYS"]["equal_signed_clifford"](reference,D,True)
    NEED(rec["rank"]==len(matrices[2])-len(matrices[0]),"physical signed child rank")
    for before,after in ((reference,D),(reference.adjoint(),D.adjoint())):
        for col in range(512):
            NEED(before.zero_state(col)==after.zero_state(col),"full Gaussian column, including absolute phase")
    bad=D.then(compiler.Op(9,compiler.identity(9),[("phase",1)]))
    NEED(bad.tab==D.tab and bad.zero_state()!=D.zero_state(),"absolute phase rejection")
    return {"role":role,"frames":[a,b,c],"rank":rec["rank"],"forward_and_adjoint_columns_each":512}


def phase_columns(pack,book,cases,workers):
    checks=[]
    edits=AUDIT["checked"](HERE.parent/"round9/upstream-7601/edits.json")
    sources=[]
    for _,ins in edits["insert_before"]:
        for e in ins:
            if e[0]=="MOVE":
                _,r,a,c,_=e
                deleted=[z for _,z in edits["delete"] if z[0]=="MOVE" and z[1]==r]
                sources.append((r,a,deleted[0][3],c))
    sources.extend((role,a,b,c) for role,_,_,a,b,c,_ in cases)
    tasks=[(str(pack),z,[book["frames"][j] for j in z[1:]]) for z in sources]
    if workers==1:
        return list(map(phase_worker,tasks))
    with ProcessPoolExecutor(max_workers=min(workers,len(tasks))) as pool:
        return list(pool.map(phase_worker,tasks,timeout=78))


def signed_binding(word,caller,invoice,baseline):
    gauge=run_path(str(HERE.parent/"round8/independent/port_gauge.py"))
    path=HERE.parent/"round3/independent/pinned/upstream_application.py"
    src=path.read_text(encoding="utf-8").split("def inverse(matrix):")[0]
    src=replace(src,"range(153)","range(145)",2)
    src=replace(src,"caller['ambient_rank'] == 153 and caller['stages'] == 18",
                   "caller['ambient_rank'] == 145 and caller['stages'] == 17")
    src=replace(src,"list(range(1,19))","list(range(1,18))",2)
    src=replace(src,"len(helpers) == 1080","len(helpers) == 1101")
    src=replace(src,"len(owners) == 3952","len(owners) == 3744")
    src=replace(src,"all(0 <= r < 38 for r in plane_a)","all(r in type_owners(caller,'A') for r in plane_a)")
    src=replace(src,"all(38 <= r < 76 for r in plane_b[:2])","all(r in type_owners(caller,'B') for r in plane_b[:2])")
    src=replace(src,"word['public']+51","word['public']+word['owned_fields']")
    src=replace(src,"op in ('QUERY','IDLE_ONE')","op in ('QUERY','IDLE_ONE','IDLE_ODD')")
    src=replace(src,"all(1 <= s <= 18 for s in selected)","all(1 <= s <= 17 for s in selected)")
    src=replace(src,"rank = 8*len(selected); idle_uses += len(kind['ports'])","""rank = 8*len(selected); idle_uses += len(kind['ports'])
                    if op=='IDLE_ODD':
                        need(len(selected)==1 and a[1:]==[-1], 'signed idle')
                        rank+=1
                        stage=selected[0]
                        for pi in kind['ports']:
                            q=word['ports'][pi]
                            axes=[q]+[1<<(9+8*(stage-1)+j) for j in range(8)]
                            need(all(dot(x,y)==(i==j) for i,x in enumerate(axes) for j,y in enumerate(axes)),
                                 'signed rank-nine axes')
                            pos=terms((x,1) for x in axes)
                            signed=sub(pos,terms([(q,2)]))
                            need(translation(sub(pos,signed))==q,'negative central phase correction')""")
    src=replace(src,"len(selection)==18","len(selection)==17")
    src=replace(src,"ambient=153, native_calls=18, native_public=1480, fresh_helpers=19440",
                   "ambient=145, native_calls=17, native_public=1501, fresh_helpers=18717")
    src=replace(src,"reserved_native_banks=18*51","reserved_native_banks=17*word['owned_fields']")
    def type_owners(c,t):
        owner=c["types"][t]
        return range(owner["offset"],owner["offset"]+owner["roles"])
    ns={"__file__":str(path),"type_owners":type_owners}
    exec(compile(src,str(path),"exec"),ns)
    by_q={}
    for i,q in enumerate(word["ports"]):
        body=list(gauge["orthonormal"](word,i)[1:])
        by_q[q]={"q":q,"idle_children":[{"orthogonal_axes":body}]}
    result=ns["complex_application"](word,caller,{"invoice":invoice},{"recipes":list(by_q.values())})
    # Excludes phase_record_digest because the orthonormal completions are independently chosen.
    old=baseline["checks"]["ODD-PHYSICAL-BINDING.json"]["occurrence_and_geometry"]
    for name in ("ambient","fresh_helpers","idle_uses","lambda_uses","native_calls","native_contact_boundaries",
                 "native_public","nonzero_boundary_translations","productive_fields","query_uses","rank_surplus","reserved_native_banks"):
        NEED(old[name]==result[name],f"fresh physical caller contract {name}")
    NEED(result["paid_positions"]==sum(invoice["P"].values()),"fresh complete occurrence order")
    return result


def counts(word,caller,invoice,gate,precision,binding,baseline):
    old=baseline["checks"]
    H=int(gate["H"])
    c=precision["context_multiplier"]
    kstar=1920*153**1920*(H+1)**2
    NEED((4096*kstar).bit_length()<H,"compiler bit-height condition")
    NEED(max(v["strict_power_of_two"] for v in precision["caller_rounding"].values())<H,
         "bounded caller defect envelope")
    native_macros=sum(e[0]!="MOVE" for e in word["program"])
    L=caller["stages"]
    macros=sum(len(caller["types"][e[0]]["ports"]) for e in caller["events"] if e[0]!="J")
    conversions=2*L*word["public"]+2*sum(q["roles"]*len(q["ports"]) for q in caller["types"].values())
    scalar=32*(L*native_macros+macros+conversions)
    k=binding
    signed_idle=sum(len(caller["types"][e[0]]["ports"]) for e in caller["events"] if e[:2]==["B","IDLE_ODD"])
    maps=2*(sum(invoice["P"].values())+sum(invoice["T"].values()))+k["native_contact_boundaries"]+2*k["idle_uses"]+3*k["query_uses"]+k["lambda_uses"]+signed_idle
    records_per_map=4*(caller["ambient_rank"]+1)**2
    scalars=[Fraction(e[2] if e[0]=="SCALE" else e[3]) for e in word["program"] if e[0] in ("ADD","COPY","SCALE")]
    scalars+= [Fraction(e[-1]) for e in caller["events"] if e[0]!="J" and e[1] in ("ADD","SCALE")]
    odd=int(old["ODD-CALLER-EXACT-GRID.json"]["caller_odd_scale"])
    scalars.extend((Fraction(odd),Fraction(1,odd),Fraction(1125),Fraction(1,1125)))
    bits=max(abs(z.numerator).bit_length() for z in scalars)
    NEED(bits<=24,"fixed scalar shift-add representation")
    scalar_units=0
    for e in word["program"]:
        if e[0] in ("ADD","COPY","SCALE"):
            q=Fraction(e[2] if e[0]=="SCALE" else e[3])
            a,d=abs(q.numerator),q.denominator
            scalar_units+=4*(a.bit_length()+d.bit_length()+1+(a.bit_count() if e[0]!="SCALE" else 0))
    prior=old["ODD-ADMISSION-PARTIAL.json"]["ordinary"]
    native_moves=sum(e[0]=="MOVE" for e in word["program"])
    ordinary=prior["conservative_total"]+L*(scalar_units-prior["scalar_upper"]+1000*(native_moves-prior["route_items"]["moves"]))
    NEED(ordinary<10**9,"complete signed ordinary movement allowance")
    return {"ordinary_bound":ordinary,"raw_map_slots":maps,"raw_map_records_upper":maps*records_per_map,
            "scalar_services_upper":scalar,"max_scalar_numerator_bits":bits,"context_bound_bits":(c*kstar).bit_length(),
            "native_scalar_macros":native_macros,"unchanged_signed_native_contact_boundaries":k["native_contact_boundaries"]}


def precise_gate(word,baseline_word,caller,pr_invoice):
    core=source_module("check_recurrence.py")
    before,_=core.profile(baseline_word,caller)
    after,_=core.profile(word,caller)
    NEED({str(r):c for r,c in before["P"].items()}==pr_invoice["paid"] and
         {str(r):c for r,c in before["T"].items()}==pr_invoice["targets"],"rebuild literal #7601 invoice")
    NEED(before["S"]==after["S"]==1424 and before["T"]==after["T"] and not after["empty_root_credits"],
         "fixed targets and strict raw rank surplus")
    tariff=source_module("interval_gate.py")
    old,new=(core.signed_hist(z) for z in (before,after))
    bound=(Fraction(".0036490213054"),Fraction(".00376669"))
    lo,hi=core.locate(vars(tariff),new,*bound,Fraction(1,10**30))
    claim=Fraction(((lo-7*GAP)*10**15).__floor__(),10**15)
    tested=claim+7*GAP
    g=tariff.gate(after,claim,tested,lo,hi)
    NEED(tariff.moment(old,claim)[1]<0,"strict improvement on the exact open baseline")
    sample={}
    for pt in ((5,1000),(227,10000)):
        sample[str(pt)]=CORE.format_bounds(CORE.moment(new,*pt))
    return after,g,{"claim_decimal":f".{int(claim*10**15):015d}","raw_bracket":g["raw_bracket"],
                    "raw_bracket_decimal":[f".{(lo*10**28).__floor__():028d}",f".{(hi*10**28).__ceil__():028d}"],
                    "old_margin_at_new_claim":tariff.show(tariff.moment(old,claim)),
                    "same_fixed_calls_margin_at_reference_points":sample,
                    "paid_calls":sum(after["P"].values()),"productive_calls":sum(after["T"].values())}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    parser.add_argument("candidate_dir",type=Path)
    parser.add_argument("--word-out",type=Path)
    parser.add_argument("--workers",type=int,default=4)
    args=parser.parse_args()
    deadline=monotonic()+100
    _,old=AUDIT["PHYS"]["load_pins"](args.complex_pack/"7546-word.json.gz")
    book=AUDIT["checked"](args.candidate_dir/"word.json.gz",AUDIT["NEW"])
    candidate=fused_word(book)
    caller_path=args.complex_pack/"7113-caller.json"
    if not caller_path.is_file():
        caller_path=args.complex_pack/"phase-7481-inputs/caller.json"
    caller=AUDIT["checked"](caller_path,"255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc")
    edits=AUDIT["checked"](args.candidate_dir/"invoice-new.json")
    baseline=json.loads(read_source("SIGNED.json"))
    exact=verify_full_coefficients(old,book,candidate,deadline)
    phase=phase_columns(args.complex_pack,book,FUSIONS,args.workers)
    invoice,gate,price=precise_gate(candidate,book,caller,edits)
    caller_grid=replay_caller_grid(caller_path,baseline)
    precision=exact_envelopes(candidate,old,caller,baseline,caller_grid,deadline)
    binding=signed_binding(candidate,caller,invoice,baseline)
    physical=counts(candidate,caller,invoice,gate,precision,binding,baseline)
    payload=json.dumps(candidate,sort_keys=True,separators=(",",":")).encode()
    if args.word_out:
        args.word_out.write_bytes(gzip.compress(payload,mtime=0))
    res={"status":"PASS_SIGNED_TWO_FUSION_SUBSTITUTION","word_canonical_sha256":sha256(payload).hexdigest(),
         "candidate_on_open_head":AUDIT["HEAD"],"exact_coefficients_and_ownership":exact,"phase_pairs":phase,
         "complete_invoice":invoice,"compiled_price_and_numerical_outer":gate,"price":price,
         "precision":precision,"fresh_caller_integer_grid":caller_grid,"fresh_signed_caller_binding":binding,
         "tape_and_ordinary":physical,
         "scope":"raw native and fixed resource and numerical outer checks under inherited conditional contracts"}
    print(json.dumps(res,indent=2,sort_keys=True))


if __name__=="__main__":
    main()
