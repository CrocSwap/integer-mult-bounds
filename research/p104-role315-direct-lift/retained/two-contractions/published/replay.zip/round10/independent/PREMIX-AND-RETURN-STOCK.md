# Exact entrance correction and terminal stock after a deleted contact

The open #7601 edit uses ordinary preparation at the initial empty coframe and four later corrections to remove two intermediate stops. Of 1,915 single-contact public frame ascents in pinned #7546, every deleted ADD would need mixing between different initial coframes if the rest of the tape is retained and correction is allowed only at its entrance. For 310 stops the unique public entrance correction also fails at least one recorded owned boundary. [Literal #7546 source](https://github.com/CrocSwap/integer-mult-bounds/tree/99438c43df7aac1e5dbcc43c1578fcd886c119ec) · [Open #7601 edit](https://github.com/CrocSwap/integer-mult-bounds/pull/7601)

## Operator and owned constraints

Write \(F\) for the invertible normalized public endpoint, and \(R\) for the stacked rows at every owned CLEAR and prior-to-COPY zero guard. At an ADD of the source row \(s^\mathsf T\) into role \(d\) with coefficient \(a\), let \(v\) and \(w\) be the public and owned output responses to a unit addition in \(d\) just after that contact. MOVE acts as the identity in the all-frame normalized coefficient system, because the two consecutive signed frame conjugations cancel their common middle chart. Merging the nested hops after deleting this ADD therefore gives endpoint \(F'=F-avs^\mathsf T\) and guard rows \(R'=R-aws^\mathsf T\).

Let \(u=F^{-1}v\) and \(p=1-as^\mathsf T u\). For nonzero deleted effect and \(p\ne0\), the unique entrance map satisfying \(F'P=F\) is

\[
P=(I-aus^\mathsf T)^{-1}=I+\frac{a}{p}us^\mathsf T .
\]

The same identities give \(R'P-R=(a/p)(Ru-w)s^\mathsf T\). Thus copying every guard and preserving each erased payload require \(Ru=w\) when \(a\) and \(s\) are nonzero. Entrance ADD and SCALE preserve each exact initial coframe. They can only realize a block-diagonal \(P\) in these coframes. A nonzero off-block multiplication coefficient in \(us^\mathsf T\) excludes every entrance-only circuit for this modified tape, even granting arbitrary scalar coefficients on legal blocks. Singularity \(p=0\) independently excludes a square input correction.

More generally, for a modified endpoint \(F-\Delta F\) and guard matrix \(R-\Delta R\), an invertible entrance repair must equal \((I-F^{-1}\Delta F)^{-1}\). It is block-diagonal in initial coframes exactly when \(F^{-1}\Delta F\) is. The guard condition is \(\Delta R=RF^{-1}\Delta F\). These statements use the actual combined changes, so if one deleted contact alters another's source the interaction terms belong in \(\Delta F,\Delta R\).

## Exhaustive single-contact result on #7546

Enumerate every public occurrence MOVE, single incident ADD, MOVE with the same intermediate chart, including when the skipped role is either the sender or recipient. The certificate computes all source rows forward and independent sparse output/guard sensitivities backward. It verifies every public endpoint as well as all 74 owned CLEARs and the COPY zero guard. It uses the exact sparse block inverse of the known native A/B and helper endpoint. Four fixture controls cover a legal shear correction, a crossing of two initial coframes, a failed owned boundary and singular deletion.

| Skipped role kind | Single-contact stops | Off-block entrance repair | Owned residual |
|---|---:|---:|---:|
| Type A | 637 | 637 | 79 |
| Type B | 12 | 12 | 2 |
| Helper | 1,266 | 1,266 | 229 |
| Total | 1,915 | 1,915 | 310 |

All public deleted-contact operators are nonsingular. The known #7601 changes illustrate the boundary. In the corresponding #7546 single-deletion instances, role 134 requires 104 off-block coefficients, and role 100's read into role 166 requires eight. Both agree with the original owned guard constraints after the unique unrestricted entrance map. Actual #7601 restores the cross-initial contributions through later coframe arithmetic. The exhaustive result leaves additional coframe repairs, nonliteral altered ownership and multiple deleted contacts open.

## Complementary remainder at two shared caps

For a separated recipient \(d\), suppose the deleted read changes only its own public output, has no guard effect, and the original input coordinate of \(d\) influences only final \(d\). After the last outgoing use of \(d\), an ADD into \(d\) cannot alter any other coordinate. In any of its subsequent frames, collect the current same-frame stored rows, accounting for later recipient SCALEs. Modulo input coordinates at its original coframe, a necessary condition for restoring the old row is that its missing payload lie in the span of the projected collected rows. This grants arbitrary rational coefficients and treats origin effects in the most favorable way. Any position after the receiver's last outgoing read is eligible, including before the deleted read. Two copies of a retained role before and after a late ADD contribute their exact change to this stock.

On exact #7601, 255 read-type single-ADD stops have the separated recipient and guard-preserving shape. A bounded test checks 16 in order of Type B priority, then the smaller fused leg's rank, the total fused rank and source index. None has full projected stock. In particular Type B role 38's old read into 140 at chart 153 has eight independent projected stock directions and retains a 43-coordinate residue when repairs can begin after 140's last outgoing read at index 43672. Its recipient's terminal chart has rank eight, so full-chart fields never enter its same-coframe stock.

The apparent overlap of \(e_{82}^\mathsf T\) at chart 240 changes when both old contacts are removed. Recalculate each bank on the simultaneously deleted word, with both senders absent from the old middle coframe during their fused paths. At chart 240 the two exact quotient rows are \(e_{82}^\mathsf T+\tfrac12e_{86}^\mathsf T\) and \(2e_{82}^\mathsf T\). At chart 232 they are \(e_{826}^\mathsf T-e_{870}^\mathsf T\) and \(2e_{100}^\mathsf T-4e_{103}^\mathsf T\). Each pair is linearly independent. A single added streamed scalar row cannot repair either pair with these other sources fixed. Adding even one paid rank-one call costs one unit, which already exceeds the sum of the two \(H_1+H_5-H_6\) fusions at the comparison prices through .0227. The test leaves dynamic reallocation of retained work or earlier simultaneous corrections open.

## Reproduction

Use the two exact local scripts and their adjacent JSON receipts. The source dependency chain includes work/round9/audit_upstream_7601.py, work/round7/independent/direct_complex_native.py and its earlier local pinned rational, Clifford and tariff helpers. Pin the original 7546-word.json.gz, 7546-whole.json, phase-7481-inputs/caller.json, and the exact #7601 word.json.gz. Inputs are explicitly verified by the replay.

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$pack = '..\integer-mult-local-recovery\work'
& $py -I -B -S -W error .\work\round10\independent\entrance_sherman.py "$pack\7546-word.json.gz" "$pack\7546-whole.json" "$pack\phase-7481-inputs\caller.json" .\work\round10\independent\entrance-search.json --expect
& $py -I -B -S -W error .\work\round10\independent\terminal_affine_stock.py .\work\round9\upstream-7601\word.json.gz .\work\round10\independent\terminal-affine-stock.json --count 16 --expect
~~~

The two replay bodies run under 35-second and 33-second deadlines. The bounded run tested terms on one CPU and released its process. A broadened experimental bank accumulation hit its time limit and was released. Its incomplete census is excluded from the 16-case result. These local screens supply an exact obstruction under the stated correction conditions. A changed physical child, operative precision allocation and full recurrence improvement remain open in this branch.
