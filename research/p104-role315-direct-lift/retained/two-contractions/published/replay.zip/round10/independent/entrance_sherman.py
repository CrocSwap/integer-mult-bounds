"""Search every single-contact public frame merge with exact entrance correction."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DIRECT = run_path(str(ROOT/"round7/independent/direct_complex_native.py"))
REPLAY = run_path(str(ROOT/"round9/audit_upstream_7601.py"))
ROWS, NEED, PHYS = DIRECT["ROWS"], DIRECT["NEED"], DIRECT["PHYSICAL"]
ZERO = ROWS["NONE"]
UNIT = ROWS["unit"]
INC = ROWS["increment"]
SCALE = ROWS["scale"]
RATIO = ROWS["ratio"]


def as_map(row):
    d,v = row
    return {i:Q(x,d) for i,x in v.items()}


def dot(a,b):
    if len(a[1]) > len(b[1]):
        a,b=b,a
    return Q(sum(v*b[1].get(i,0) for i,v in a[1].items()), a[0]*b[0])


def project(row, keep):
    values = {i:v for i,v in row[1].items() if keep(i)}
    return ROWS["reduced"](row[0],values)


def contacts(word):
    program = word["program"]
    visits = defaultdict(list)
    n = word["public"]
    b = ROWS["target"](word)[0]
    a = {r for x in word["live"] for r in (x,x+112)} | set(word["hosted"]["X2"]) | set(word["hosted"]["Y2"])
    for at,e in enumerate(program):
        visits[e[1]].append(at)
        if e[0] in ("ADD","COPY"):
            visits[e[2]].append(at)
    result = []
    for r,xs in visits.items():
        if r >= n:
            continue
        for before,k,after in zip(xs,xs[1:],xs[2:]):
            u,m,v = (program[j] for j in (before,k,after))
            if (u[0],m[0],v[0]) != ("MOVE","ADD","MOVE"):
                continue
            f0,f1 = u[2:4]
            f2 = v[3]
            NEED(v[2]==m[4]==f1 and u[1]==v[1]==r, "Single-contact chart path")
            ranks = [len(word["frames"][f]) for f in (f0,f1,f2)]
            NEED(ranks[0] < ranks[1] < ranks[2], "Strict public ascent")
            _,d,s,c,_ = m
            result.append({"role":r, "type":"B" if r in b else "A" if r in a else "helper",
                           "moves":(before,after), "contact":k, "frames":(f0,f1,f2),
                           "ranks":(ranks[1]-ranks[0],ranks[2]-ranks[1]),
                           "d":d,"s":s,"coefficient":Q(c),
                           "destination_is_skipped":d==r})
    return sorted(result, key=lambda c:(c["contact"],c["role"]))


def observations(word, records, deadline):
    n,o=word["public"],word["owned_fields"]
    source_at = {r["contact"] for r in records}
    f = word["initial"][:]+[None]*o
    x = [UNIT(i) for i in range(n)]+[ZERO]*o
    source, aux, ordinals = {}, {}, {}
    for at,(op,r,*args) in enumerate(word["program"]):
        if at%512==0:
            NEED(monotonic()<deadline,"Exact forward prefix replay deadline")
        if op=="INIT":
            NEED(r>=n and f[r] is None and x[r]==ZERO, "Owned INIT")
            f[r]=args[0]
        elif op=="CLEAR":
            NEED(r>=n and f[r]==args[0], "Owned CLEAR")
            ordinals[at] = n+len(aux)
            aux[ordinals[at]]=x[r]
            f[r],x[r]=None,ZERO
        elif op=="MOVE":
            a,b,owned=args
            NEED(f[r]==a and owned==(r>=n), "Live MOVE endpoint")
            f[r]=b
        elif op=="SCALE":
            c,chart=args
            NEED(f[r]==chart, "Live SCALE endpoint")
            x[r]=SCALE(x[r],RATIO(c))
        else:
            s,c,chart=args
            NEED(f[r]==f[s]==chart and r!=s, "Live binary scalar contact")
            if at in source_at:
                source[at]=x[s]
            if op=="COPY":
                NEED(r>=n and x[r]==ZERO, "Legally cleared COPY target")
                ordinals[at]=n+len(aux)
                aux[ordinals[at]]=ZERO
            else:
                NEED(op=="ADD","Known scalar instruction")
            x[r]=INC(x[r],x[s],RATIO(c))
    _,public,inverse=ROWS["target"](word)
    NEED(f==word["final"]+[None]*o and x==public+[ZERO]*o,"Every arbitrary source endpoint")
    x = [UNIT(i) for i in range(n)]+[ZERO]*o
    response={}
    for at in range(len(word["program"])-1,-1,-1):
        if at%512==0:
            NEED(monotonic()<deadline,"Exact reverse response deadline")
        op,r,*args=word["program"][at]
        if at in source_at:
            response[at]=x[r]
        if op=="CLEAR":
            NEED(x[r]==ZERO, "No retained response from cleared incarnation")
            x[r]=UNIT(ordinals[at])
        elif op=="INIT":
            x[r]=ZERO
        elif op=="SCALE":
            x[r]=SCALE(x[r],RATIO(args[0]))
        elif op in ("ADD","COPY"):
            s,c,_=args
            x[s]=INC(x[s],x[r],RATIO(c))
            if op=="COPY":
                x[r]=UNIT(ordinals[at])
    NEED([project(z, lambda j:j<n) for z in x] == ROWS["transpose"](public,n)+[ZERO]*o,
         "Independent inverse response on all public columns")
    NEED(len(source)==len(response)==len(source_at), "Every requested contact has exact response")
    return source,response,aux,ordinals,inverse


def factor_contact(word, proposed, source,response,aux,inverse):
    at=proposed["contact"]
    s,v=source[at],response[at]
    a=proposed["coefficient"]
    n=word["public"]
    if s==ZERO or v==ZERO:
        return {"public_singular":False, "cross_initial_charts":0,
                "erase_guard_residuals":0, "entrance_supported":True}, {}, (s,v,ZERO)
    vp=project(v,lambda j:j<n)
    vinv=ROWS["transpose"](inverse,n) if not isinstance(inverse,dict) else inverse
    u=ZERO
    for j,c in as_map(vp).items():
        u=INC(u,vinv[j],c.as_integer_ratio())
    pivot=1-a*dot(s,u)
    blocked={}
    proposal={}
    initial=word["initial"]
    vmap=as_map(v)
    changes={}
    for k,row in aux.items():
        z=dot(row,u)-vmap.get(k,0)
        if z:
            changes[k]=z
    if pivot:
        payload=as_map(s)
        for j,x in as_map(u).items():
            eta=a*x/pivot
            for k,c in payload.items():
                if initial[j]!=initial[k]:
                    blocked[j,k]=eta*c
                else:
                    proposal[j,k]=eta*c
    facts={"public_singular":not pivot,"premix_pivot":str(pivot),
           "source_forms":len(s[1]),"inverse_receiver_forms":len(u[1]),
           "cross_initial_charts":len(blocked),"allowed_initial_entries":len(proposal),
           "erase_guard_residuals":len(changes),
           "initial_chart_witness":[[j,k,str(value)] for (j,k),value in list(blocked.items())[:2]],
           "erase_guard_witness_counts":[[j,str(value)] for j,value in list(changes.items())[:2]],
           "entrance_supported":bool(pivot and not blocked and not changes)}
    return facts,proposal,(s,v,u)


def apply_premix(word, proposed, proposal, payload):
    if not proposal:
        prefix=[]
    else:
        # The rank-one correction reads a fixed payload. For this emitted
        # triangular subcase, every modified row is outside its support.
        NEED(set(j for j,_ in proposal).isdisjoint(payload[1]),"Independent unmodified carrier input coordinates")
        prefix=[["ADD",j,k,str(value),word["initial"][j]] for (j,k),value in sorted(proposal.items())]
    before,after=proposed["moves"]
    deletion={before,proposed["contact"]}
    r=proposed["role"]
    f0,_,f2=proposed["frames"]
    program=prefix+[["MOVE",r,f0,f2,False] if i==after else e
                    for i,e in enumerate(word["program"]) if i not in deletion]
    return {**word,"program":program},prefix


def controls():
    # M=I, v=e0, s=e1^T. An entrance on common chart repairs a deleted shear
    # and an augmentation that observes the destination conflicts.
    a=Q(1,2)
    rec={"contact":0,"coefficient":a}
    source={0:UNIT(1)}; response={0:UNIT(0)}
    w={"public":2,"initial":[0,0]}
    inv={0:UNIT(0),1:UNIT(1)}
    m,p,_=factor_contact(w,rec,source,response,{},inv)
    NEED(m["entrance_supported"] and p=={(0,1):a}, "Planted exact triangular correction")
    w["initial"]=[0,1]
    m,_,_=factor_contact(w,rec,source,response,{},inv)
    NEED(not m["entrance_supported"] and m["cross_initial_charts"]==1, "Chart incompatibility control")
    w["initial"]=[0,0]
    m,_,_=factor_contact(w,rec,source,response,{2:UNIT(0)},inv)
    NEED(not m["entrance_supported"] and m["erase_guard_residuals"]==1, "Independent owned erase control")
    m,_,_=factor_contact(w,{**rec,"coefficient":Q(1)}, {0:UNIT(0)}, response,{},inv)
    NEED(m["public_singular"],"Singular modified-word control")
    return 4


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    for key in ("word","whole","caller","output"):
        cli.add_argument(key,type=Path)
    cli.add_argument("--expect",action="store_true")
    cli.add_argument("--emit",type=Path)
    args=cli.parse_args()
    start=monotonic()
    deadline=start+35
    compiler,word=PHYS["load_pins"](args.word)
    n=word["public"]
    native=contacts(word)
    source,response,aux,ordinals,inverse=observations(word,native,deadline)
    inv=dict(enumerate(ROWS["transpose"](inverse,n)))
    counts=defaultdict(Counter)
    supported=[]
    explored=[]
    trial=None
    for rec in native:
        NEED(monotonic()<deadline,"Bounded exact entrance scan")
        facts,moves,sig=factor_contact(word,rec,source,response,aux,inv)
        side=counts[rec["type"]]
        side["candidate_stops"]+=1
        for k in ("public_singular","cross_initial_charts","erase_guard_residuals","entrance_supported"):
            side[k]+=bool(facts[k])
        if facts["entrance_supported"]:
            if not moves or set(j for j,_ in moves).isdisjoint(sig[0][1]):
                supported.append((rec,facts,moves,sig))
        if rec["type"]=="B" or rec["role"] in (100,134) or facts["entrance_supported"]:
            explored.append({**rec,**facts})
    if supported:
        engine=DIRECT["BASE"]["price_engine"]()
        k=Q(".005")
        def saving(item):
            a,b=item[0]["ranks"]
            return engine.moment({a:1,b:1,a+b:-1},k)[0] if a!=b else engine.moment({a:2,a+b:-1},k)[0]
        ordered=sorted(supported,key=saving,reverse=True)
        record,facts,proposal,sig=ordered[0]
        candidate,prefix=apply_premix(word,record,proposal,sig[0])
        before,life,*_=REPLAY["trace"](word,deadline)
        after,new_life,*_=REPLAY["trace"](candidate,deadline)
        NEED(life==new_life,"Every owned lifetime and erased contents exactly equal")
        a,m,b=record["frames"]
        ca,cm,cb=(compiler.canonical_frame(9,word["frames"][j]) for j in (a,m,b))
        desired=ca.adjoint().then(cb)
        through=ca.adjoint().then(cm).then(cm.adjoint()).then(cb)
        PHYS["equal_signed_clifford"](desired,through,True)
        recipe,compiled=compiler.lower_child(desired)
        NEED(recipe["rank"]==sum(record["ranks"]),"New fused physical rank")
        PHYS["equal_signed_clifford"](desired,compiled,True)
        PHYS["equal_signed_clifford"](desired.adjoint(),compiled.adjoint(),True)
        delta=after.copy()
        delta.subtract(before)
        delta={r:c for r,c in delta.items() if c}
        whole=json.loads(DIRECT["BASE"]["pin"](args.whole,DIRECT["BASE"]["WHOLE"]))
        caller=json.loads(DIRECT["BASE"]["pin"](args.caller,DIRECT["BASE"]["CALLER"]))
        keep={int(r):q*caller["stages"] for r,q in whole["signed_profile"]["native_productive"].items()}
        trial={"record":record,"native_paid_delta":delta,"premix_ops":prefix,
               "precision_original":DIRECT["ROUND6"]["native_grid"](word,deadline),
               "precision_candidate":DIRECT["ROUND6"]["native_grid"](candidate,deadline),
               "whole_caller_invoice":DIRECT["signed_price"](after,whole,caller["stages"],extra_productive=keep),
               "exact_source_erased_values":True}
        if args.emit:
            args.emit.write_text(json.dumps(candidate,separators=(",",":"))+"\n",encoding="utf-8")
    result={"status":"PASS_ONE_CONTACT_EXACT_ENTRANCE_SEARCH",
            "controls":controls(),"native_source_head":DIRECT["ADJ"]["NATIVE_HEAD"],
            "categories":dict(counts),"examined_owned_guards_and_clears":len(ordinals),
            "individually_verified_charts_or_known_controls":explored,
            "best_replayed_trial":trial}
    payload=json.dumps(result,indent=2,sort_keys=True,default=str)+"\n"
    if args.expect:
        NEED(args.output.read_text(encoding="utf-8")==payload,"Expected receipt changed")
    else:
        args.output.write_text(payload,encoding="utf-8")
    print(result["status"],json.dumps(dict(counts)),f"{monotonic()-start:.2f}s",flush=True)


if __name__=="__main__":
    main()
