"""Move a missing public read into exact origin and terminal-coframe stock."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
SEARCH = run_path(str(HERE/"entrance_sherman.py"))
ROWS, DIRECT, NEED = (SEARCH[k] for k in ("ROWS","DIRECT","NEED"))
INC, SCALE, UNIT, ZERO, RATIO = (SEARCH[k] for k in ("INC","SCALE","UNIT","ZERO","RATIO"))
as_map = SEARCH["as_map"]


def collect(word, probes, deadline):
    """Replay once, recording each changed peer for each terminal target."""
    n,o=word["public"],word["owned_fields"]
    pp = word["program"]
    baskets=defaultdict(set)
    begins=defaultdict(list)
    visits={}
    for probe in probes:
        ident=probe["contact"]
        begins[probe["start"]].append(ident)
        visits[ident]=probe
    live=word["initial"][:]+[None]*o
    states=[UNIT(i) for i in range(n)]+[ZERO]*o
    stock={j:{} for j in visits}
    deleted = {j for p in probes for j in p.get("deleted",())}
    cur={}
    moves={}

    def store(j, r, at):
        p=visits[j]
        if r==p["d"] or states[r]==ZERO:
            return
        paths=p.get("suppressed",((p["role"],p["moves"]),))
        if any(r==owner and hops[0] < at <= hops[1] for owner,hops in paths):
            return
        # The pure-source projection determines span membership. Two snapshots
        # with identical projection offer the same quotient column.
        d,v=states[r]
        origin=word["initial"][p["d"]]
        projected=ROWS["reduced"](d,{i:x for i,x in v.items() if word["initial"][i]!=origin})
        key=(projected[0],tuple(sorted(projected[1].items())))
        stock[j].setdefault(key, (at,r,live[r],states[r]))

    def activate(j,d,at):
        z=live[d]
        cur[j]=z
        baskets[z].add(j)
        for r in moves[z]:
            store(j,r,at)

    for r,z in enumerate(live):
        moves.setdefault(z,set()).add(r)
    active=defaultdict(list)
    for at in range(len(pp)+1):
        if at%512==0:
            NEED(monotonic()<deadline,"Bounded exact terminal stock trace")
        for j in begins.get(at,()):
            d=visits[j]["d"]
            active[d].append(j)
            activate(j,d,at)
        if at==len(pp):
            break
        if at in deleted:
            continue
        op,r,*args=pp[at]
        if op in ("MOVE","INIT","CLEAR"):
            prior=live[r]
            if op=="MOVE":
                live[r]=args[1]
            else:
                live[r]=args[0] if op=="INIT" else None
                states[r]=ZERO
            moves[prior].discard(r)
            moves.setdefault(live[r],set()).add(r)
            for j in active[r]:
                baskets[cur[j]].discard(j)
                activate(j,r,at+1)
        elif op=="SCALE":
            states[r]=SCALE(states[r],RATIO(args[0]))
        else:
            s,c,_=args
            states[r]=INC(states[r],states[s],RATIO(c))
        for j in baskets[live[r]]:
            store(j,r,at+1)
    expected=ROWS["target"](word)[1]
    changed={pp[i][1] for i in deleted}
    observed={r for r in range(n) if states[r]!=expected[r]}
    NEED(observed==changed,"Exactly the deleted contact destinations differ")
    return {j:list(d.values()) for j,d in stock.items()}


def solve(target, stock, initial, origin):
    def outside(row):
        return {i:c for i,c in as_map(row).items() if initial[i]!=origin}
    echelon=DIRECT["TAIL"]["solve_echelon"]
    basis={}
    for i,(_,_,_,row) in enumerate(stock):
        echelon(basis,outside(row),{i:Q(1)})
    rem, recipe=echelon(basis,outside(target),{},save=False)
    return len(basis), rem, {j:-c for j,c in recipe.items()}


def instructions(word, rec, target, stock, recipe, base_end):
    pp=word["program"]
    d=rec["d"]
    expected=base_end[d]
    new_end=INC(expected,target,(-1,1))
    gains = {}
    factor=Q(1)
    edited_cuts=set(stock[i][0] for i in recipe)
    for at in range(len(pp),min(edited_cuts,default=len(pp))-1,-1):
        if at in edited_cuts:
            gains[at]=factor
        if at and pp[at-1][0]=="SCALE" and pp[at-1][1]==d:
            factor*=Q(pp[at-1][2])
    repair=defaultdict(list)
    for i,c in recipe.items():
        cut,r,chart,v=stock[i]
        NEED(v!=ZERO and r!=d and gains[cut], "Real coframe stock with surviving receiver")
        new_end=INC(new_end,v,c.as_integer_ratio())
        repair[cut].append(["ADD",d,r,str(c/gains[cut]),chart])
    pivot=as_map(new_end).get(d,0)
    if not pivot:
        return None
    residual=INC(expected,new_end,(-1,1))
    coeff={i:c/pivot for i,c in as_map(residual).items()}
    initial=word["initial"][d]
    NEED(all(word["initial"][i]==initial for i in coeff),"Origin coframe compatibility")
    origin=[]
    if d in coeff:
        if 1+coeff[d]==0:
            return None
        origin.append(["SCALE",d,str(1+coeff.pop(d)),initial])
    origin.extend(["ADD",d,s,str(c),initial] for s,c in sorted(coeff.items()))
    before,after=rec["moves"]
    f0,_,f2=rec["frames"]
    new=[]
    replacement=["MOVE",rec["role"],f0,f2,False]
    deletion={before,rec["contact"]}
    for at,e in enumerate(pp):
        new.extend(repair.get(at,()))
        if at not in deletion:
            new.append(replacement if at==after else e)
    new=origin+new+repair.get(len(pp),[])
    return {**word,"program":new},origin,dict(repair)


def joint_control(word, probes, source, response, deadline):
    chart_pairs = ((45392,45397),(45432,45435))
    found={}
    by_key={r["contact"]:r for r in probes}
    for j,k in chart_pairs:
        if j not in by_key or k not in by_key:
            continue
        first,second=by_key[j],by_key[k]
        # Their only modified incoming edge at or after these cuts is the
        # deleted one, and no role reads either receiver afterwards.
        owners={first["d"],second["d"]}
        NEED(first["frames"][1]==second["frames"][1] and
             all(word["final"][d]==first["frames"][1] for d in owners),
             "Both old receivers own the same genuine final coframe")
        NEED(max(first["start"],second["start"])<=min(j,k) and len(owners)==2,
             "No relevant onward read after either missing contribution")
        # Suppress both contact values and prohibit each skipped sender from
        # the old middle coframe. Other original operations are untouched.
        clipped=[{**r,"deleted":(j,k),"suppressed":((first["role"],first["moves"]),(second["role"],second["moves"]))}
                 for r in (first,second)]
        stock=collect(word,clipped,deadline)
        entries=[]
        for r in clipped:
            at=r["contact"]
            target=SCALE(source[at],(r["coefficient"]*as_map(response[at])[r["d"]]).as_integer_ratio())
            rank,u,_=solve(target,stock[at],word["initial"],word["initial"][r["d"]])
            entries.append({"contact":at,"target":r["d"],"current_stock_rank":rank,
                            "residue":{i:str(c) for i,c in sorted(u.items())}})
        found[f"{j},{k}"] = entries
    return found


def run(word, deadline, count, only=None):
    recs=[rec for rec in SEARCH["contacts"](word)
          if not rec["destination_is_skipped"] and (only is None or rec["role"]==only)]
    src,rsp,aux,_,inverse=SEARCH["observations"](word,recs,deadline)
    final=ROWS["target"](word)[1]
    inv=dict(enumerate(ROWS["transpose"](inverse,word["public"])))
    outgoing={}
    for i,e in enumerate(word["program"]):
        if e[0] in ("COPY","ADD"):
            outgoing[e[2]]=i
    eligible=[]
    for r in recs:
        d=r["d"]
        v=rsp[r["contact"]]
        if set(v[1])!={d}:
            continue
        if set(inv[d][1])!={d} or any(d in row[1] for row in aux.values()):
            continue
        # Legal corrections may straddle the deleted contact. The destination
        # is already dead to every other register once its last read passes.
        # Changing it before the physical merge does not alter this payload.
        eligible.append({**r,"start":outgoing.get(d,-1)+1})
    eligible.sort(key=lambda r:(r["type"]!="B",-min(r["ranks"]),-sum(r["ranks"]),r["contact"]))
    chosen=eligible[:count]
    stock=collect(word,chosen,deadline)
    tried=[]
    passed=[]
    for r in chosen:
        NEED(monotonic()<deadline,"Bounded exact terminal stock elimination")
        j=r["contact"]
        alpha=(r["coefficient"]*as_map(rsp[j])[r["d"]]).as_integer_ratio()
        target=SCALE(src[j],alpha)
        rank,u,recipe=solve(target,stock[j],word["initial"],word["initial"][r["d"]])
        rec={**r,"local_distinct_stock":len(stock[j]),"outside_origin_basis_rank":rank,
             "linear_residue":len(u),"sparse_outside_witness":[[i,str(c)] for i,c in list(sorted(u.items()))[:4]]}
        tried.append(rec)
        if not u:
            result=instructions(word,r,target,stock[j],recipe,final)
            if result:
                passed.append((rec,*result))
    joint=joint_control(word,chosen,src,rsp,deadline)
    return len(eligible),tried,passed,joint


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for label in ("base","out"):
        p.add_argument(label,type=Path)
    p.add_argument("--count",type=int,default=24)
    p.add_argument("--only-role",type=int)
    p.add_argument("--emit",type=Path)
    p.add_argument("--expect",action="store_true")
    args=p.parse_args()
    t=monotonic()
    deadline=t+33
    word=SEARCH["REPLAY"]["checked"](args.base,SEARCH["REPLAY"]["NEW"])
    eligible,tried,passed,joint=run(word,deadline,args.count,args.only_role)
    successes=[]
    if passed:
        before,life,_,_=SEARCH["REPLAY"]["trace"](word,deadline)
        for rec, new, prefix, repair in passed:
            after,new_life,_,_=SEARCH["REPLAY"]["trace"](new,deadline)
            NEED(new_life==life, "The exact erasures and ownership agree")
            after.subtract(before)
            successes.append({"case":rec,"origin":prefix,"coframe_corrections":repair,
                              "rank_delta":{k:v for k,v in after.items() if v}})
        if args.emit:
            args.emit.write_text(json.dumps(passed[0][1],separators=(",",":"))+"\n",encoding="utf-8")
    output={"status":"PASS_TERMINAL_AFFINE_STOCK_SCREEN", "eligible_single_owner":eligible,
            "base_head":SEARCH["REPLAY"]["HEAD"], "base_compressed_sha256":SEARCH["REPLAY"]["NEW"],
            "tested":tried,"fully_replayed_successes":successes,"joint_deleted_contact_controls":joint}
    result=json.dumps(output,sort_keys=True,default=str,indent=2)+"\n"
    if args.expect:
        NEED(args.out.read_text(encoding="utf-8")==result,"Receipt changed")
    else:
        args.out.write_text(result,encoding="utf-8")
    print(output["status"],len(passed),len(tried),f"{monotonic()-t:.2f}s",flush=True)


if __name__=="__main__":
    main()
