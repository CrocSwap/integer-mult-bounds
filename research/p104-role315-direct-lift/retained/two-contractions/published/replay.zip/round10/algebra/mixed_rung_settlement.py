"""Find and audit retirement of signed P104 public mixed-contact rungs."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
import gzip
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
ROWS = run_path(str(WORK / "round4/independent/receiver_support.py"))
need, unit, zero = ROWS["need"], ROWS["unit"], ROWS["NONE"]
incr, scale, ratio = ROWS["increment"], ROWS["scale"], ROWS["ratio"]
PIN = "be97530506ab633c2a76a173a51d13f58b581ee7249338821e6e4994e3104675"
INVOICE_PIN = "9deafd3564ba3e6f918bb584fb3a8ed5026c3ed11a65cb9bd5cb2940c60cbbeb"


def load_word(path):
    raw = path.read_bytes()
    need(sha256(raw).hexdigest() == PIN, "exact #7601 native source")
    return json.loads(gzip.decompress(raw))


def main_roles(word):
    x = word["live"]
    return set(x) | {r + 112 for r in x} | set(word["hosted"]["X2"]) | set(word["hosted"]["Y2"])


def candidates(word):
    program, frames = word["program"], word["frames"]
    public = main_roles(word)
    histories = defaultdict(list)
    for at, (op, r, *args) in enumerate(program):
        if r in public:
            histories[r].append((at, op))
        if op in ("ADD", "COPY") and args[0] in public:
            histories[args[0]].append((at, "READ" if op == "ADD" else "READ_COPY"))
    found = []
    for r, events in histories.items():
        moves = [i for i, (_, op) in enumerate(events) if op == "MOVE"]
        for lo, hi in zip(moves, moves[1:]):
            interior = events[lo + 1:hi]
            kinds = {k for _, k in interior}
            if kinds != {"ADD", "READ"}:
                continue
            a, b = [events[j][0] for j in (lo, hi)]
            f, g = program[a][2:4]
            g2, h = program[b][2:4]
            r0, r1, r2 = [len(frames[i]) for i in (f, g, h)]
            need(g == g2, "consecutive moves of a public role")
            if r0 < r1 < r2:
                found.append((r, a, b, tuple(j for j, _ in interior)))
    return sorted(found, key=lambda entry: (entry[-1], entry[0]))


def audit(word, interest, deadline):
    n, q = word["public"], word["owned_fields"]
    program = word["program"]
    live = word["initial"] + [None] * q
    rows = [unit(i) for i in range(n)] + [zero] * q
    before, after, observations = {}, {}, {}
    preserved = []
    paid = Counter()
    for at, (op, r, *a) in enumerate(program):
        if not at % 1024:
            need(monotonic() < deadline, "bounded rational replay")
        if op == "INIT":
            need(r >= n and live[r] is None and rows[r] == zero, "owned birth")
            live[r] = a[0]
            preserved.append((op, r, tuple(a)))
        elif op == "CLEAR":
            need(r >= n and live[r] == a[0], "owned retirement chart")
            observations[at] = (n + len(observations), rows[r])
            preserved.append((op, r, tuple(a), rows[r]))
            rows[r], live[r] = zero, None
        elif op == "MOVE":
            f, g, owned = a
            need(live[r] == f and owned == (r >= n), "literal owner and chart")
            width = len(word["frames"][g]) - len(word["frames"][f])
            need(width > 0 or owned and width < 0, "legal paid direction")
            paid[abs(width)] += 1
            if owned:
                preserved.append((op, r, tuple(a)))
            live[r] = g
        elif op == "SCALE":
            need(live[r] == a[1], "coframed scale")
            rows[r] = scale(rows[r], ratio(a[0]))
        else:
            s, coeff, f = a
            need(r != s and live[r] == live[s] == f, "coframed arithmetic")
            if at in interest:
                before[at] = rows[s]
            if op == "COPY":
                need(r >= n and rows[r] == zero, "zero COPY receiver")
                observations[at] = (n + len(observations), rows[r])
            else:
                need(op == "ADD", "known arithmetic event")
            rows[r] = incr(rows[r], rows[s], ratio(coeff))
    need(live == word["final"] + [None] * q, "literal final charts")
    final = rows[:n] + [row for _, row in observations.values()]
    # A backward injection is also consumed by an erasure or a COPY precondition.
    rows = [unit(i) for i in range(n)] + [zero] * q
    for at in range(len(program) - 1, -1, -1):
        if not at % 1024:
            need(monotonic() < deadline, "bounded rational reverse replay")
        op, r, *a = program[at]
        if at in interest:
            after[at] = rows[r]
        if op == "INIT":
            rows[r] = zero
        elif op == "CLEAR":
            rows[r] = unit(observations[at][0])
        elif op == "SCALE":
            rows[r] = scale(rows[r], ratio(a[0]))
        elif op in ("ADD", "COPY"):
            s, coeff, _ = a
            rows[s] = incr(rows[s], rows[r], ratio(coeff))
            if op == "COPY":
                rows[r] = unit(observations[at][0])
    need(rows[:n] == ROWS["transpose"](final, n), "whole backward observation matrix")
    return final, before, after, paid, preserved


def transfer(program, first, last):
    """Exact response at last's source to a unit after first's destination."""
    values = {program[first][1]: Fraction(1)}
    for op, r, *a in program[first + 1:last]:
        if op in ("ADD", "COPY"):
            z = values.get(a[0], 0) * Fraction(a[1])
            if op == "ADD":
                z += values.get(r, 0)
            if z:
                values[r] = z
            else:
                values.pop(r, None)
        elif op in ("INIT", "CLEAR"):
            values.pop(r, None)
        elif op == "SCALE" and r in values:
            values[r] *= Fraction(a[0])
    return values.get(program[last][2], Fraction(0))


def defects(program, removed, before, after):
    """Rows of U−T, with chronological cross-terms between all removed ADDs."""
    injecting = {}
    for i in removed:
        v = before[i]
        for j, w in injecting.items():
            if w[1] and (alpha := transfer(program, j, i)):
                v = incr(v, w, alpha.as_integer_ratio())
        injecting[i] = scale(v, ratio(str(-Fraction(program[i][3]))))
    effect = {}
    for i, v in injecting.items():
        d, u = after[i]
        for r, c in u.items():
            effect[r] = incr(effect.get(r, zero), v, (c, d))
    return {r: val for r, val in effect.items() if val[1]}


def zero_block(word, allowed, effect):
    """A new nonzero initial/final block rules out both local basis changes."""
    n = word["public"]
    starts, ends = word["initial"], word["final"]
    for r, (den, entries) in sorted(effect.items()):
        outblock = ends[r] if r < n else r + len(word["frames"])
        for s, k in sorted(entries.items()):
            if starts[s] not in allowed[outblock]:
                return [r, s, str(Fraction(k, den)), outblock, starts[s]]
    return None


def terminal_residual(word, effect, target_inverse):
    """Return E T^-1 and whether it is confined to blocks of final charts."""
    n = word["public"]
    ends = word["final"]
    residual = {}
    pure = True
    for i, (d, row) in sorted(effect.items()):
        if i >= n:
            pure = False
            continue
        prev = zero
        for j, a in sorted(row.items()):
            prev = incr(prev, target_inverse[j], (a, d))
        residual[i] = prev
        if any(ends[i] != ends[j] for j in prev[1]):
            pure = False
    return residual, pure


def inverse_pair(a, b, c, d):
    determinant = a * d - b * c
    need(determinant != 0, "two-coordinate response is nonsingular")
    return ((d / determinant, -b / determinant), (-c / determinant, a / determinant))


def projector_row(rows, inverse_row, ends, chart):
    den, terms = inverse_row
    result = zero
    for j, value in terms.items():
        if ends[j] == chart:
            result = incr(result, rows[j], (value, den))
    return result


def paired_obstruction(word, pair, original, before, after, base_path, deadline):
    """Verify the protected projector block of the 841/860 example."""
    left, right = pair
    pair_roles = (left[0], right[0])
    need(pair_roles == (841, 860) and left[-1] == right[-1] == (36920, 38254),
         "literal two-role shared contacts")
    _, target, old_inverse = original
    defect = defects(word["program"], left[-1], before, after)
    need(set(defect) == set(pair_roles), "only the two public rows are affected")
    t_columns = ROWS["transpose"](old_inverse, word["public"])
    need(all(t_columns[i] == unit(i) for i in pair_roles), "isolated target inverse columns")
    transition = [incr(unit(i), defect[i], (1, 1)) for i in pair_roles]
    small = tuple(Fraction(r.get(i, 0), d) for d, r in transition for i in pair_roles)
    reduced_inverse = inverse_pair(*small)
    inv_defect, _ = terminal_residual(word, defect, old_inverse)
    uncorrected_inverse = old_inverse[:]
    for i, coef in zip(pair_roles, reduced_inverse, strict=True):
        for j, a in zip(pair_roles, coef, strict=True):
            uncorrected_inverse[i] = incr(uncorrected_inverse[i], inv_defect[j], (-a).as_integer_ratio())
    uncorrected = [incr(row, defect.get(i, zero), (1, 1)) for i, row in enumerate(target)]
    starts, ends = word["initial"], word["final"]
    full, = (i for i, f in enumerate(word["frames"]) if len(f) == 9)
    original_blocks = []
    for i in range(word["public"]):
        if starts[i] not in {starts[j] for j in pair_roles}:
            continue
        old_projector = projector_row(target, old_inverse[i], ends, full)
        need(not any(starts[j] == 48 for j in old_projector[1]), "zero target projector blocks")
        original_blocks.append(i)
    entries = {}
    for i in pair_roles:
        d, cols = projector_row(uncorrected, uncorrected_inverse[i], ends, full)
        got = Fraction(cols[52], d)
        need(got == Fraction(-1, 8) and starts[52] == 48, "nonzero candidate projector block")
        entries[i] = [starts[i], 52, starts[52], str(got)]
    altered = edit(word, pair)
    u, _, _, new_paid, new_owned = audit(altered, set(), deadline)
    t, _, _, old_paid, old_owned = audit(word, set(), deadline)
    need(u == [*uncorrected, *t[word["public"]:]], "whole defect formula proves the exact literal replay")
    need(old_owned == new_owned, "owned schedule and all erased content unchanged")
    change = new_paid.copy()
    change.subtract(old_paid)
    need({k: v for k, v in change.items() if v} == {1: -4, 2: 2}, "two rank-two fusions")
    physical = run_path(str(WORK / "round3/independent/fresh_axis_lift.py"))
    compiler, _ = physical["load_pins"](base_path)
    phase_checks = []
    for r, a, b, _ in pair:
        f, g = word["program"][a][2:4]
        h = word["program"][b][3]
        A, B, C = [compiler.canonical_frame(9, word["frames"][i]) for i in (f, g, h)]
        direct = A.adjoint().then(C)
        through = A.adjoint().then(B).then(B.adjoint()).then(C)
        recipe, compiled = compiler.lower_child(direct)
        need(recipe["rank"] == 2, "literal physical rank-two child")
        for op in (compiled, through):
            need(op.tab == direct.tab and op.zero_state() == direct.zero_state(), "exact signed physical operator")
        need(compiled.adjoint().tab == direct.adjoint().tab
             and compiled.adjoint().zero_state() == direct.adjoint().zero_state(), "exact adjoint signed move")
        phase_checks.append([r, f, g, h, recipe["rank"]])
    return {"source_charts": [66, 84, 48], "projection_end_chart": full,
            "checked_zero_rows": original_blocks, "uncorrected_witnesses": entries,
            "paired_literal_move_physics": phase_checks, "removed_adds": list(left[-1]),
            "owned_lifetimes_and_erased_content_preserved": True,
            "rejected_candidate_paid_delta": {k: v for k, v in change.items() if v},
            "role_rows_changed": len(defect), "coefficients_changed": sum(len(r[1]) for r in defect.values()),
            "inverse_2_by_2": [[str(c) for c in row] for row in reduced_inverse]}


def edit(word, selected):
    program = word["program"]
    omitted = set()
    fused = {}
    for r, a, b, interactions in selected:
        omitted.update((a, *interactions))
        fused[b] = ["MOVE", r, program[a][2], program[b][3], False]
    need(not fused.keys() & omitted, "independent coalescing move sites")
    p = [fused.get(i, ev) for i, ev in enumerate(program) if i not in omitted]
    return {**word, "program": p}


def rank_ceilings(word, invoice):
    """Price the minimum rank tariff with all selected owner endpoints fixed."""
    raw = invoice.read_bytes()
    need(sha256(raw).hexdigest() == INVOICE_PIN, "pinned complete signed #7601 invoice")
    complete = json.loads(raw)
    budget = Counter({int(r): c for r, c in complete["targets"].items()})
    budget.subtract({int(r): c for r, c in complete["paid"].items()})
    need(complete["contract"]["boundary"] == "complete signed #7113 caller application with 17 native calls",
         "signed application with seventeen repeat charges")
    main = main_roles(word)
    dim = [len(f) for f in word["frames"]]
    n = word["public"]
    original = {k: Counter() for k in ("main", "public", "owned")}
    one = {k: Counter() for k in original}
    for i, (f, g) in enumerate(zip(word["initial"], word["final"], strict=True)):
        gap = dim[g] - dim[f]
        need(gap > 0, "every original public trajectory has positive rank demand")
        one["public"][gap] += 1
        if i in main:
            one["main"][gap] += 1
    lifetime_start = {}
    for op, r, *a in word["program"]:
        if op == "MOVE":
            rank = abs(dim[a[1]] - dim[a[0]])
            original["owned" if r >= n else "public"][rank] += 1
            if r in main:
                original["main"][rank] += 1
        elif op == "INIT":
            lifetime_start[r] = dim[a[0]]
        elif op == "CLEAR":
            one["owned"][abs(dim[a[0]] - lifetime_start.pop(r))] += 1
    need(not lifetime_start and sum(one["owned"].values()) == 74, "sealed owned lifetimes")
    need(len(main) == 400 and set(one["main"]) == {8}, "all independent main roles gain exactly eight dimensions")
    need(sum(r * k for r, k in original["main"].items()) == 8 * len(main), "fixed aggregate main rank")
    price = run_path(str(WORK / "round3/independent/body_rank_deformation.py"))["price_engine"]()
    reports = {}
    # H(0)=0. Zero-displacement owned lifetimes require no MOVE in the relaxation.
    weights = {}
    for label, groups in (("main_only", ("main",)), ("all_public", ("public",)),
                          ("all_public_and_owned", ("public", "owned"))):
        allowance = Counter()
        for group in groups:
            allowance.update(original[group])
            allowance.subtract({r: c for r, c in one[group].items() if r})
        maximal = budget.copy()
        maximal.update({r: 17 * c for r, c in allowance.items()})
        weights[label] = allowance, maximal
    for k in (".005", ".0227"):
        kappa = Fraction(k)
        reports[k] = {"signed_margin": price.show(price.moment(budget, kappa))}
        for label, (allowance, maximal) in weights.items():
            reports[k][label] = {"max_saving_per_native": price.show(price.moment(allowance, kappa)),
                                 "optimistic_whole_margin": price.show(price.moment(maximal, kappa))}
    need(Fraction(reports[".0227"]["all_public_and_owned"]["optimistic_whole_margin"][1]) < 0,
         "strongest fixed-trajectory relaxation cannot reach the long-term target")
    return {"actual_widths": {k: dict(v) for k, v in original.items()},
            "optimistic_widths": {k: dict(v) for k, v in one.items()}, "cost": reports}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("base_7546", type=Path)
    parser.add_argument("invoice", type=Path)
    args = parser.parse_args()
    deadline = monotonic() + 90
    word = load_word(args.source)
    cuts = candidates(word)
    groups = defaultdict(list)
    for cand in cuts:
        groups[cand[-1]].append(cand)
    interest = {i for c in cuts for i in c[-1]}
    final, before, after, _, _ = audit(word, interest, deadline)
    original = ROWS["target"](word)
    need(final[:word["public"]] == original[1], "source has exact desired public operator")
    allowed = defaultdict(set)
    for r, (_, row) in enumerate(final):
        outblock = word["final"][r] if r < word["public"] else r + len(word["frames"])
        allowed[outblock].update(word["initial"][j] for j in row)
    independent = [(c,) for c in cuts]
    coupled = [tuple(cs) for cs in groups.values() if len(cs) >= 2]
    report = {}
    for field, batch in (("single", independent), ("coupled_same_contacts", coupled)):
        summary, survivors, kinds = Counter(), [], Counter()
        first_rejection = None
        for cs in batch:
            _, _, _, touches = cs[0]
            n = word["public"]
            effect = defects(word["program"], touches, before, after)
            obstruction = zero_block(word, allowed, effect)
            label = "new_block" if obstruction else "needs_span"
            if not obstruction:
                _, terminal = terminal_residual(word, effect, original[2])
                if not effect:
                    label = "no_error"
                elif terminal:
                    label = "terminal_only"
                survivors.append((cs, label, len(effect), sum(len(row[1]) for row in effect.values()), sum(i >= n for i in effect)))
            else:
                if first_rejection is None:
                    first_rejection = (cs, obstruction)
            summary[label] += 1
            kinds[len(touches)] += 1
            need(monotonic() < deadline, "bounded mixed-contact screen")
        report[field] = {"classification": dict(summary), "contact_counts": dict(kinds),
                         "not_rejected": survivors, "sample_new_block_rejection": first_rejection}
    pair = groups[(36920, 38254)]
    report["pair_841_860"] = paired_obstruction(word, pair, original, before, after, args.base_7546, deadline)
    report["fixed_owner_rank_ceilings"] = rank_ceilings(word, args.invoice)
    print(json.dumps(report, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
