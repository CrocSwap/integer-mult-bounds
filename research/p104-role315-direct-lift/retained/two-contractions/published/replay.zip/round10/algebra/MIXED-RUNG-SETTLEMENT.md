# Mixed contacts and the rank tariff of fixed trajectories

The input is the open #7601 word at `eccf3d1fe814ea86a373d37a783105ceb853c390`, with the original #7546 physical compiler and the signed 17-call #7113 invoice. Each role contains an arbitrary independent field at entry. The augmented exact scalar operator records the public outputs, each owned value at CLEAR and the one required zero before COPY. [Open #7601](https://github.com/CrocSwap/integer-mult-bounds/pull/7601) · [Open #7546](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

## Fixed owner price bound

Set \(H(r)=r^{1-\kappa}\) for \(r>0\) and \(H(0)=0\). Every legal recursive MOVE on a fixed trajectory from an \(a\)-dimensional chart to a \(b\)-dimensional chart costs at least \(H(|a-b|)\). The rank of the difference of the two chart directions is at least \(|a-b|\). It is exactly \(|a-b|\) for the native's nested pairs. For arbitrary sequences of arrivals \(A_0,\ldots,A_m\) on a single physical field,

\[
  H(|\dim A_m-\dim A_0|)
  \ \le\ H\!\left(\sum_{i=1}^m |\dim A_i-\dim A_{i-1}|\right)
  \ \le\ \sum_{i=1}^m H(|\dim A_i-\dim A_{i-1}|).
\]

The first inequality uses the triangle inequality on dimensions and monotonicity. The second follows from subadditivity of the positive power when \(0<\kappa<1\). This permits an optimistic one-MOVE debit for each public trajectory with fixed initial and final chart, and for each owned lifetime with fixed birth and retirement chart. The bound even permits one fictitious rank-difference MOVE for nonnested endpoints and no MOVE for every zero net displacement. Neither assumption demands a realizable arithmetic or storage schedule.

The exact normalized rank histograms come from the pinned program. Every main role gains eight dimensions. Granting all 400 main roles one rank-eight MOVE yields the first relaxation. The stronger relaxation also counts all 1,501 public trajectories and all 74 owned lifetimes, while keeping every surrounding caller debit and every productive target fixed. Within each relaxation every arithmetic contact is assumed to be free to reschedule and ordinary arithmetic is omitted from the raw tariff. The table rounds exact interval bounds for readability.

| Relaxation | Maximum saving per native at .005 | Whole raw margin at .005 | Maximum saving per native at .0227 | Whole raw margin at .0227 |
| --- | ---: | ---: | ---: | ---: |
| Main roles only | 19.84466 | −184.45210 | 88.06202 | −5,600.17927 |
| All public trajectories | 69.40967 | +658.15307 | 308.15616 | −1,858.57891 |
| All public and owned trajectories | 69.55470 | +660.61858 | 308.79949 | −1,847.64234 |

At κ=.0227, the signed #7113 caller needs at least 1,847.64233 additional raw units beyond this relaxation, equivalent to 108.68484 per repeated native. A gain of this order must change the carrier identities or lifetime boundaries, the caller, or the productive targets. The positive upper bound at .005 for all trajectories has no construction attached. The price statement applies to the fixed owner boundaries and paid-move alphabet with one separately charged field per transport.

## Exact mixed-contact screen

Take a monotone public chain A→B→C and suppress all its writes and reads at B. When a base ADD at event i is deleted, let \(u_i\) be the suffix response of its destination, \(v_i\) the original value of its source, and \(a_i\) the deleted scalar. At each event, the changed trajectory injects

\[
  \delta_i=-a_i\left(v_i+\sum_{j<i}\gamma_{ji}\delta_j\right),\qquad
  U-T=\sum_i u_i\delta_i.
\]

Here \(\gamma_{ji}\) is the unchanged scalar tape's transfer from j's destination just after j to i's source just before i. Subsequent injections supply the cross-terms when deletions exchange information. Both forward rows and backward responses are computed over the rationals, including the owned erasures and pre-COPY zero observation.

The scan covers 431 originally mixed ADD/read main stops and seven simultaneous pairs sharing their entire contact list. For initial-chart blocks and final-chart blocks of the augmented operator, a zero full block in T must stay zero in \(LUR\) if L and R are invertible and block diagonal, respectively by final and initial chart. Erasure observations retain their individual slots. A newly nonzero full block rules out boundary-only retiming of this kind on 236 of the 431 individual drops and four of the seven simultaneous pairs. A drop failing the zero-block screen may still admit retiming inside the word. An open screen entry has no claim of reconstruction.

## A two-sided projector obstruction with actual physical coalescence

Roles 841 and 860 meet in chart 271. Their two ADDs at events 36,920 and 38,254 are exactly the two roles' full middle contact list. Each direct replacement has one signed rank-two child in place of two rank-one children. The Clifford reduction checks the complete tableau, one exact materialized column fixing the phase, and the adjoints. Full forward and reverse scalar replay of the literal edited word changes only 107 coefficients across two public rows and preserves all owned geometry and contents at retirement. Its prospective paid delta is `1: -4, 2: +2`.

The ordinary zero-block test leaves this pair open. Let U be the actual uncorrected public operator and T the required public operator. Both are invertible. If \(T=LUR\) with arbitrary invertible initial/final chart-local changes R,L, then the coordinate projector P onto full final chart 127 commutes with L and forces

\[
  T^{-1} P T=R^{-1}(U^{-1} P U)R.
\]

Thus the entire block for source-chart pair \((f,g)\) must be zero simultaneously in both conjugated projectors. T gives zero blocks for \((66,48)\) and \((84,48)\). U gives \(-1/8\) at input-role pairs \((841,52)\) and \((860,52)\) in these blocks. The original inverse has unit columns at roles 841 and 860, so the inverse update is an exact two-by-two Woodbury correction. The determinant of the relevant two-coordinate block is one. These two projector entries preclude every boundary-only solution for the actual paired drop even with freely chosen rational arithmetic. Interior arithmetic repairs and other chart changes are outside this obstruction.

## Local replay

From the goal directory, run with CPython 3.11 or later with assertions enabled.

```powershell
python -I -B -S -W error work/round10/algebra/mixed_rung_settlement.py `
  work/round9/upstream-7601/word.json.gz `
  work/round9/upstream-7601/base-7546-word.json.gz `
  work/round9/upstream-7601/invoice-new.json
```

The result is `mixed-rung-screen.json`. The standard-library verifier uses earlier pinned helpers in `work/round3/independent` and `work/round4/independent` and stops after 90 seconds if the augmented rational screen cannot finish. It leaves the source files and canonical checkout untouched. This experiment concerns the fixed signed model and its native invoice, with no claim of a new multiplication exponent.
