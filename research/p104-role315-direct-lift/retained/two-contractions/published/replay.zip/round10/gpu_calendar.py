# SPDX-License-Identifier: Apache-2.0
"""Compare a coordinate noncontainment screen on CPU and NVIDIA D3D11."""

import argparse
from array import array
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import islice
import json
from pathlib import Path
from runpy import run_path
import sys
from time import monotonic,perf_counter


HERE=Path(__file__).resolve().parent
CAL=run_path(str(HERE/"calendar_fusion.py"))
AUDIT=CAL["AUDIT"]
NEED=CAL["NEED"]
MUTATIONS=256


SHADER=r"""
StructuredBuffer<uint> support : register(t0);
StructuredBuffer<uint> jobs : register(t1);
RWStructuredBuffer<uint> gaps : register(u0);
RWStructuredBuffer<uint> first : register(u1);

[numthreads(64,1,1)]
void main(uint z : SV_DispatchThreadID) {
    uint row=jobs[2*z], col=jobs[2*z+1];
    if(row==0){gaps[z]=0;first[z]=0;return;}
    uint N=support[0], at=row*N*2+1;
    uint total=0, least=0xffffffffu;
    for(uint a=0;a<N;a++){
        uint demand=support[at+a+N];
        if(a==col/32u){
            demand |= 1u << (col%32);
        }
        uint gap=demand & ~support[at+a];
        total+=countbits(gap);
        if(gap!=0u && least==0xffffffffu){
            least=32u*a+firstbitlow(gap);
        }
    }
    gaps[z]=total;
    first[z]=least;
}
"""


def screen(tape,jobs,N):
    counts,first=array("I"),array("I")
    for row,col in jobs:
        a=1+row*2*N
        wanted=tape[a+N:a+2*N]
        if col!=0xffffffff:
            wanted[col//32] |= 1<<(col%32)
        q=[d & ~s for d,s in zip(wanted,tape[a:a+N],strict=True)]
        counts.append(sum(k.bit_count() for k in q))
        first.append(next((32*j+(k&-k).bit_length()-1 for j,k in enumerate(q) if k),0xffffffff))
    return counts,first


def setup_tables(word,duration):
    cases,_=CAL["catalog"](word)
    stock,values=CAL["delta_rows"](word,cases,duration)
    n=word["public"]
    N=(n+31)//32
    packed=array("I",[N]+[0]*(2*N))
    results=[]

    def mask(indices):
        values=[0]*N
        for k in indices:
            values[k//32] |= 1<<(k%32)
        return values

    for case,stocks in zip(cases,stock,strict=True):
        _,target=CAL["net_delta"](word,case,values)
        allowed={k for rows in stocks for j,(_,coeff) in rows if j!=case[0] for k in coeff}
        required=set(target[1])
        results.append((allowed,required))
        packed.extend(mask(allowed))
        packed.extend(mask(required))
    return N,packed,results


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate_dir",type=Path)
    parser.add_argument("backend",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--cpu-only",action="store_true")
    args=parser.parse_args()
    deadline=monotonic()+35
    guard=None
    device=None
    if sys.platform=="win32":
        sys.path.insert(0,str(HERE.parent))
        from benchmark_helper_cohorts import BACKEND_SHA, Limit, gpu_batch
        guard=Limit()
        guard.poll("calendar resources")
    if not args.cpu_only:
        NEED(guard is not None,"D3D11 requires Windows")
        guard.sample("before D3D11 coordinate screen")
    word=AUDIT["checked"](args.candidate_dir/"word.json.gz",AUDIT["NEW"])
    N,packed,rows=setup_tables(word,deadline)
    n=word["public"]
    def inputs():
        for k in range(len(rows)):
            yield k+1,0xffffffff  # literal source demand
            for j in range(MUTATIONS):
                yield k+1,(615*j+23*k)%n
    digest=sha256()
    cpu_ms=gpu_ms=gpu_setup=0.
    small={}
    total=0
    real_counts=Counter()
    t=iter(inputs())
    try:
        if not args.cpu_only:
            NEED(sha256(args.backend.read_bytes()).hexdigest()==BACKEND_SHA,"retained driver adapter")
            spec=spec_from_file_location("d3d11_backend",args.backend)
            backend=module_from_spec(spec)
            spec.loader.exec_module(backend)
            backend.HLSL=SHADER
            device=backend.D3D11()
            start=perf_counter()
            device.open()
            device.compile()
            gpu_setup=(perf_counter()-start)*1000
            guard.sample("after D3D11 shader")
        batch=list(islice(t,256))
        while batch:
            NEED(monotonic()<deadline,"bounded coordinate screens")
            if guard is not None:
                guard.poll("coordinate batch")
            start=perf_counter()
            got=screen(packed,batch,N)
            tc=(perf_counter()-start)*1000
            tg=0.
            if device is not None:
                actual,tg=gpu_batch(backend,device,packed,batch,guard)
                NEED(got==actual,"GPU and CPU coordinate witnesses agree")
            if not small:
                small={"cases":len(batch),"cpu_ms":tc,"gpu_ms":tg}
            cpu_ms+=tc
            gpu_ms+=tg
            total+=len(batch)
            for x in got:
                digest.update(x.tobytes())
            for q,(row,col) in enumerate(batch):
                if col==0xffffffff:
                    a,b=rows[row-1]
                    NEED(got[0][q]==len(b-a) and got[1][q]==min(b-a,default=0xffffffff),
                         "exact rational coefficients confirm the genuine witness")
                    real_counts["excluded" if b-a else "remaining"]+=1
            batch=list(islice(t,32768))
    finally:
        if device is not None:
            device.close()
            guard.sample("after D3D11 release")
    NEED(total==len(rows)*(1+MUTATIONS),"every genuine pair and sensitivity read screened")
    out={"status":"PASS_GPU_CALENDAR_STOCK","total_comparisons":total,"roles_with_real_demand":len(rows),
         "extra_coordinates_per_role":MUTATIONS,"real_demand_counts":dict(real_counts),
         "sha256":digest.hexdigest(),"cpu_ms":cpu_ms,"gpu_ms":gpu_ms,"gpu_setup_ms":gpu_setup,
         "small":small,"resources":guard.samples if guard else []}
    args.output.write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(out["status"],total,out["real_demand_counts"],f"CPU {cpu_ms:.2f} ms, GPU {gpu_ms:.2f} ms, setup {gpu_setup:.2f} ms")


if __name__=="__main__":
    main()
