# SPDX-License-Identifier: Apache-2.0
"""Authenticate and replay the tenth-round candidate and controlled comparisons."""

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from hashlib import sha256
import gzip
import json
from pathlib import Path
from runpy import run_path
import subprocess
import sys
from time import perf_counter


JOBS=(
    ("candidate_fusion","two-fusion-word-audit","candidate",105),
    ("calendar_fusion","calendar-fusion","stock",39),
    ("gpu_calendar","gpu-calendar","gpu",39),
    ("algebra/mixed_rung_settlement","algebra/mixed-rung-screen","mixed",48),
    ("independent/entrance_sherman","independent/entrance-search","entrance",43),
    ("independent/terminal_affine_stock","independent/terminal-affine-stock","terminal",41),
    ("recurrence/verify_shared_body","recurrence/shared-body","pack",25),
    ("../round9/audit_upstream_7601","../round9/audit-upstream-7601","upstream",40),
)
GPU_KEYS=("status","extra_coordinates_per_role","real_demand_counts","roles_with_real_demand","sha256","total_comparisons")


def replay(dest,job,want_gpu):
    file,receipt,mode,timeout=job
    root=dest/"round10"
    script=(root/f"{file}.py").resolve()
    expected=(root/f"{receipt}.json").resolve()
    output=dest/"run"/f"{Path(receipt).name}.json"
    emitted=dest/"run"/"two-fusion-word.json.gz"
    candidate="round9/upstream-7601"
    word=f"{candidate}/word.json.gz"
    old="inputs/7546-word.json.gz"
    whole="inputs/7546-whole.json"
    caller="inputs/7113-caller.json"
    args={
        "candidate":["inputs",candidate,"--word-out",str(emitted)],
        "stock":[candidate],
        "gpu":[candidate,"inputs/benchmark-d3d11-backend.py",str(output)]+([] if want_gpu else ["--cpu-only"]),
        "mixed":[word,old,f"{candidate}/invoice-new.json"],
        "entrance":[old,whole,caller,str(expected),"--expect"],
        "terminal":[word,str(expected),"--count","16","--expect"],
        "pack":["inputs","--expect",str(expected)],
        "upstream":["inputs",candidate],
    }
    start=perf_counter()
    run=subprocess.run([sys.executable,"-I","-B","-S","-W","error",str(script),*args[mode]],
                       cwd=dest,capture_output=True,timeout=timeout)
    if run.returncode or run.stderr:
        raise RuntimeError((file,run.returncode,run.stderr.decode(errors="replace")))
    if mode in ("entrance","terminal"):
        if b"PASS_" not in run.stdout:
            raise ValueError(f"{file} did not authorize receipt equality")
    else:
        actual=json.loads(output.read_bytes() if output.is_file() else run.stdout)
        baseline=json.loads(expected.read_bytes())
        if mode=="gpu":
            actual,baseline=({key:z[key] for key in GPU_KEYS} for z in (actual,baseline))
        if baseline!=actual:
            raise ValueError(f"{file} differs from the archived receipt")
    if mode=="candidate":
        raw=gzip.decompress(emitted.read_bytes())
        if sha256(raw).hexdigest()!=baseline["word_canonical_sha256"] or raw!=gzip.decompress((root/emitted.name).read_bytes()):
            raise ValueError("different emitted candidate")
    return file,perf_counter()-start


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("archive",type=Path)
    cli.add_argument("dest",type=Path)
    cli.add_argument("--workers",type=int,default=5)
    cli.add_argument("--gpu",action="store_true")
    args=cli.parse_args()
    dest=args.dest.resolve()
    dest.mkdir()
    helper=Path(__file__).resolve().parents[1]/"round7"/"check_replay_bundle.py"
    hashes=run_path(str(helper))["extract"](args.archive,dest)
    (dest/"run").mkdir()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        jobs=[pool.submit(replay,dest,x,args.gpu) for x in JOBS]
        for job in as_completed(jobs):
            name,elapsed=job.result()
            print(f"PASS {name} {elapsed:.2f}s",flush=True)
    print(f"PASS_ROUND10_REPLAY {len(JOBS)} fresh receipts and {hashes} input hashes")


if __name__=="__main__":
    main()
