# Sharing physical body axes in the signed prefix caller

The exact four-phase prefix caller allows the native stages to reuse physical Gaussian body axes. Such reuse can lower the rank of a grouped idle, and a rank-zero body can still be an ordinary address translation. For the fixed prefix masks, a rank inequality charges the simultaneous change to the returned fields. Even with arbitrary axis reuse and the entire optimistic Type B allowance, the full margin at \(\kappa=.005\) is at most **−529.2915753341442** at 21 stages. The proof extends the rejection to every odd depth \(L\ge5\) for the same prefix stencil. [Open #7546 candidate](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

## Physical rank and eigenphase

For a nonzero binary direction \(v\), let \(X_v\) be translation by \(v\) and \(C_v=((1+i)I+(1-i)X_v)/2\). On Fourier character \(z\), \(C_v\) acts by \(i^{\langle z,v\rangle}\), with the binary pairing lifted to \(0,1\). The exact phase of a product \(B=\prod_v C_v^{s_v}\) is therefore computed modulo four from \(q(z)=\sum_v s_v\langle z,v\rangle\). Its polarization satisfies

\[
q(x+y)-q(x)-q(y)=2x^{\mathsf T}M(B)y\pmod4,\qquad
M(B)=\sum_{s_v\ {\rm odd}} vv^{\mathsf T}\quad\text{over }\mathbf F_2.
\]

The sum uses the parity of each exponent. The even Fourier-linear part still matters to the full operator. For instance, \(C_v^2=X_v\), while \(C_vC_v^{-1}=I\). Both have zero body rank and distinct actions on an arbitrary dirty field.

On a \(Z\)-type address Pauli indexed by \(z\), conjugation by \(C_v\) adds \(v\langle v,z\rangle\) to its \(X\) index and leaves its \(Z\) index unchanged. Hence the upper-right symplectic tableau block of \(B\) is exactly \(M(B)\). Left and right monomial Clifford maps give invertible row and column transforms on this block. An interchange of \(j\) independent Fourier axes has block rank \(j\), so every such lowering needs at least \(\operatorname{rank}M(B)\) recursive axes. The pinned lowerer supplies those axes and exact signed monomial wrappers. For example, \(C_{e_1}C_{e_2}C_{e_1+e_2}\) has nonzero alternating \(M\) of rank two. This product needs three direct quarter-turn factors, since the sum of two independent rank-one binary squares has nonzero diagonal. It requires only a rank-two recursive call with the allowed wrappers. The exact replay compares both signed tableaux and all Gaussian-dyadic address columns of its small compilation fixtures. [Selected exact-frame review](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/docs/research/pr-intake-evidence/pr7000-application/PROOF-REVIEW.md)

At each full host let \(D_i\) use eight independent binary directions, all in the body complement of one fixed head axis. The eight columns form a full-column-rank matrix, so their binary square sum has rank eight. They may overlap arbitrarily with the directions of other hosts. One can extend each prescribed native body basis, together with the head, to a full ambient binary basis for its entry and inverse exit permutation. Fix the selected directions across all fields using that body symbol. Native paid children then retain the old rank inventory under conjugation. All original helper inputs remain independent, and their whole original credit is granted. No assumption is needed that different body labels remain algebraically independent after substitution in the exact prefix identity.

## Charging a grouped idle to its assigned role

Let \(S\) be the target's set of native stage labels and \(P\subseteq S\) the mask of its single grouped physical body idle in the prefix stencil. Let \(j\) be the number of other singleton body idles assigned to that role. An empty \(P\) has zero cost. Write \(M(T)=\sum_{i\in T} M(D_i)\) for any mask \(T\). Then

\[
\operatorname{rank}M(S)\le \operatorname{rank}M(P)+8|S\setminus P|.
\]

The head adds one further independent rank. Set \(H_a=a^{1-\kappa}\). For \(0<\kappa<1\), the inequality \(H_{p+b}\le H_p+H_b\) gives

\[
H_{\operatorname{rank}M(S)+1}-H_{\operatorname{rank}M(P)}-jH_8
\le H_{8|S\setminus P|+1}-jH_8.
\]

The right side grants the best possible sharing independently on each role. It does not assume that these separate grants can happen in one ambient geometry. It includes exact inverse powers since signs are immaterial to \(M\). Signed coefficient equality and address phases remain conditions for any proposed realized word.

The same proof applies whenever disjoint paid mask groups can be assigned whole to the target masks that contain them. For each target remove its assigned groups from its full mask, apply the rank triangle inequality, and use power subadditivity. The restriction to an assignment of whole groups matters. A transported idle's constituent marks can match different coordinates for its different labels in more general schedules.

## Complete prefix price at arbitrary depth

Use the exact [prefix body word](../../round9/PREFIX-BODY-WORD.md) and write \(L=2h+1\ge5\). Index the role coordinates by \(a_1,\ldots,a_{L-1}\), and let \(i=0,\ldots,L-1\) be the host index. Stage \(i\) includes the available \(a_i,a_{i+1}\), all odd \(a_j\) with \(j\le i\), and all even \(a_j\) with \(j>i\). Its active pivots are \(a_1\) and the largest supported \(U_i\) coordinate apart from \(a_1\), with hub \(a_2\) at clock zero. Body idles on even role \(a_j\) can group over \(1\le i<j-1\), while on odd \(a_j\) they group over \(i\ge j+1\). The remaining idles keep their singleton bills. This gives the following prefix inventory.

| Residual labels \(|S\setminus P|\) | Singleton bills per role | Number of roles per shear chain |
| ---: | ---: | ---: |
| \(L\) | 0 | 1 |
| 3 | 1 | 2 |
| 2 | 1 | \(h-1\) |
| 3 | 2 | \(h-2\) |

Indeed \(a_1\) has all the target labels and no idles. Odd roles other than \(a_1\) have two ungrouped labels each, with one singleton bill. The first and last even roles have three ungrouped labels and one singleton bill. The remaining even roles have three ungrouped labels and two singleton bills. Selecting the alternative active pivot \(a_i\) at odd clocks where it is available redistributes singleton bills between those roles. Their total and the multiset of residual target sizes stay the same for these grouping intervals.

Let \(P_0,T_0\) be the unchanged #7546 native paid and independent helper moments. Grant separated Type B the full joint allowance \(8L(H_8+H_9+1)\). The upper bound for this allowance continues to hold for the two-stage Type B cycle under shared bodies, since its modified targets each use at most sixteen body axes plus one head. When making a standalone scope statement, the allowance is granted numerically, rather than presumed for arbitrary redesigned shared-axis Type B schemes. The full prefix upper is

\[
\Phi(L)=L[T_0-P_0+8(H_8+H_9+1)]
 +192\big[H_{8L+1}+hH_{25}+(h-1)H_{17}-3(h-1)H_8\big].
\]

By decreasing increments of \(H\), \(\Phi(L+2)-\Phi(L)\) is at most its value at \(L=5\). The checker certifies both the base and largest increment negative at each displayed price.

| Test \(\kappa\) | \(L=5\) upper | \(L=21\) upper | At most per two additional clocks |
| ---: | ---: | ---: | ---: |
| .005 | −194.2900859486133 | **−529.2915753341442** | −31.4629439551754 |
| .0227 | −1838.2749394427940 | **−8497.5725052036177** | −789.4120696825758 |

For one more literal comparison at \(L=21,\kappa=.005\), identify one axis in two different stages and keep all other axes independent. Every target or grouped idle with both stages loses exactly two polar ranks, and all other ranks are unchanged. All 210 placements on the old max-pivot prefix schedule lose price. The best pair is zero-based stages 1 and 2, losing 3.8652680089577 per shear chain and giving full upper endpoint −2072.1996447799536. The general no-go admits arbitrary sharing, so it also covers patterns in which several cancellations together improve on an unshared price. This conclusion is about the fixed exact prefix stencils and unchanged native invoice. It leaves body-dependent scalar decoders, mixed A/B bodies on the same roles and other mask allocations outside its scope.

## Reproduction

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round10\recurrence\verify_shared_body.py $complexPack --expect .\work\round10\recurrence\shared-body.json
~~~

The verifier reads the same three pinned complex source files as Round 9 and imports its source invoice and interval arithmetic. Its pinned physical lowerer is work/round3/independent/pinned/clifford_exact.py. Normal and optimized CPU replays completed in roughly half a second and matched SHA-256 f9718c516a0bc71a6dfc7be4a6ef0783817b17437ece2b81e3bb5312ef144add. Both process budgets were 30 seconds. AST parsing and tabnanny passed.
