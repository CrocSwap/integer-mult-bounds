"""Check physical Clifford body ranks and the all-overlap prefix price."""

import argparse
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
PIN = WORK / "round3" / "independent" / "pinned" / "clifford_exact.py"
PIN_SHA = "2982ead07721e83358dc67c6f49c2b4c16a236a6bebdfd72f58221be1f5d0962"


def load_module(name, source):
    spec = spec_from_file_location(name, source)
    module = module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


SEAM = load_module("seam", WORK / "round9" / "recurrence" / "verify_seam_price.py")
CORE = SEAM.CORE
need = CORE.need
WIDTH = 192


def polar_rows(directions, width):
    rows = [0] * width
    for direction, exponent in directions:
        if exponent & 1:
            for j in range(width):
                if (direction >> j) & 1:
                    rows[j] ^= direction
    return tuple(rows)


def exact_compiler(compiler, width, directions):
    word = compiler.ident(width)
    for direction, exponent in directions:
        for _ in range(exponent % 4):
            word = word.then(compiler.cgate(width, direction))
    polar = polar_rows(directions, width)
    recipe, lowered = compiler.lower_child(word)
    observed_rank = compiler.rank(polar)
    need(recipe["rank"] == observed_rank, "Polar rank differs from the actual lowered child")
    need(lowered.tab == word.tab, "Lowered exact Clifford tableau changed")
    for address in range(1 << width):
        need(lowered.zero_state(address) == word.zero_state(address), "A lowered signed column changed")
    for x in range(1 << width):
        qx = sum(e * ((v & x).bit_count() & 1) for v, e in directions)
        for y in range(1 << width):
            qy = sum(e * ((v & y).bit_count() & 1) for v, e in directions)
            qxy = sum(e * ((v & (x ^ y)).bit_count() & 1) for v, e in directions)
            bilinear = (x & compiler.mv(polar, y)).bit_count() & 1
            need((qxy - qx - qy) % 4 == 2 * bilinear, "Phase polarization controls disagree")
    return observed_rank, word


def compiler_fixtures():
    need(sha256(PIN.read_bytes()).hexdigest() == PIN_SHA, "Exact compiler pin changed")
    compiler = load_module("shared_body_exact_clifford", PIN)
    fixtures = {
        "same_axis_squared": (2, [(1, 1), (1, 1)], 0),
        "same_axis_inverse": (2, [(1, 1), (1, -1)], 0),
        "two_independent_axes": (2, [(1, 1), (2, 1)], 2),
        "alternating_rank_two_from_three_axes": (2, [(1, 1), (2, 1), (3, 1)], 2),
        "dependent_directions_full_polar_rank": (3, [(1, 1), (2, 1), (4, 1), (3, 1)], 3),
        "mixed_signs_same_rank": (3, [(1, -1), (2, 1), (4, -1), (3, 1)], 3),
        "partial_overlap_two_bodies": (3, [(1, 1), (2, 1), (2, -1), (4, 1)], 2),
    }
    results = {}
    for name, (width, directions, want) in fixtures.items():
        rank, word = exact_compiler(compiler, width, directions)
        need(rank == want, f"Wrong expected child rank for {name}")
        if name == "same_axis_squared":
            translation = compiler.xgate(width, 1)
            need(word.tab == translation.tab and word.zero_state() == translation.zero_state(),
                 "The omitted rank-zero translation was not preserved")
        results[name] = rank
    # Every two-dimensional symmetric matrix has a minimal direct C-factor word.
    least = {}
    for size in range(4):
        for subset in combinations((1, 2, 3), size):
            rows = polar_rows([(v, 1) for v in subset], 2)
            least.setdefault(rows, size)
    need(len(least) == 8 and least[(2, 1)] == 3 and compiler.rank((2, 1)) == 2,
         "The alternating direct-axis and recursive ranks must differ")
    return results


def masks(stages, alternative_pivot):
    n = stages - 1
    supports = [set() for _ in range(n)]
    groups = [set() for _ in range(n)]
    singletons = [set() for _ in range(n)]
    for i in range(stages):
        support_u = {j for j in (i, i + 1) if 1 <= j <= n}
        support_v = {j for j in range(1, n + 1) if (j % 2 == 1) == (j <= i)}
        need(support_u | support_v and (1 if i else 2) in support_v, "Invalid canonical hub")
        hub = 1 if i else 2
        candidates = support_u - {hub}
        pivot = i if alternative_pivot and i % 2 and i in candidates else max(candidates)
        for j in support_u | support_v:
            supports[j - 1].add(i)
            if j in (hub, pivot):
                continue
            is_group = 1 <= i < j - 1 if j % 2 == 0 else i >= j + 1
            (groups if is_group else singletons)[j - 1].add(i)
    return list(zip(supports, groups, singletons, strict=True))


def mask_profile(stages, alternative_pivot):
    roles = masks(stages, alternative_pivot)
    need(all(g.isdisjoint(s) and g | s <= t for t, g, s in roles), "A grouped mask leaves its root's labels")
    profile = Counter((len(t - g), len(s)) for t, g, s in roles)
    h = (stages - 1) // 2
    target = {(stages, 0): 1, (3, 1): 2, (2, 1): h - 1, (3, 2): h - 2}
    if alternative_pivot:
        target = {(stages, 0): 1, (3, 1): 1, (2, 0): h - 1, (3, 3): h - 2, (3, 2): 1}
    need(profile == +Counter(target), "Closed prefix mask count changed")
    return roles


def prefix_caps(paid, helpers):
    result = {}
    for saving, point in ((".005", (5, 1000)), (".0227", (227, 10000))):
        margins = {}
        for stages in (5, 7, 17, 19, 21, 23, 41, 55, 57, 121):
            h = (stages - 1) // 2
            chain = Counter({8 * stages + 1: 1, 25: h, 17: h - 1, 8: -3 * (h - 1)})
            for alternative_pivot in (False, True):
                roles = mask_profile(stages, alternative_pivot)
                ranks = Counter(8 * len(t-g) + 1 for t, g, _ in roles)
                ranks[8] -= sum(len(s) for _, _, s in roles)
                need(ranks == chain, "Per-role accounting and closed rank list differ")
            margin = CORE.add(SEAM.source_cost(stages, point, paid, helpers),
                              CORE.scaled(CORE.moment(chain, *point), WIDTH))
            need(margin[1] < 0, "A prefix overlap bound no longer rejects")
            margins[str(stages)] = CORE.format_bounds(margin)
        step = CORE.add(SEAM.source_cost(2, point, paid, helpers), CORE.scaled(CORE.moment(
            {57: 1, 41: -1, 25: 1, 17: 1, 8: -3}, *point
        ), WIDTH))
        need(step[1] < 0, "The concavity extension to every odd depth does not hold")
        result[saving] = {"selected_depth_caps": margins, "every_two_clocks_increment_upper": CORE.format_bounds(step)}
    return result


def local_reuse_comparison(paid, helpers):
    stages, point = 21, (5, 1000)
    roles = masks(stages, alternative_pivot=False)
    trials = {}
    for first, second in combinations(range(stages), 2):
        # Both bodies use the same first direction, retaining seven uniquely independent axes each.
        shared = {first, second}
        change = Counter()
        for target, group, _ in roles:
            if shared <= target:
                degree = 8 * len(target) + 1
                change[degree - 2] += 1
                change[degree] -= 1
            if shared <= group:
                degree = 8 * len(group)
                change[degree - 2] -= 1
                change[degree] += 1
        gain = CORE.moment(change, *point)
        need(gain[1] < 0, "A literal one-axis identification unexpectedly improved this stencil")
        trials[first, second] = gain
    best_pair, gain = max(trials.items(), key=lambda item: item[1][1])
    native = SEAM.source_cost(stages, point, paid, helpers)
    target = Counter(8 * len(t) + 1 for t, _, _ in roles)
    target.subtract(Counter(8 * len(g) for _, g, _ in roles if g))
    target[8] -= sum(len(s) for _, _, s in roles)
    whole = CORE.add(native, CORE.scaled(CORE.add(CORE.moment(target, *point), gain), WIDTH))
    return {
        "reused_pairs_checked": len(trials),
        "best_pair": best_pair,
        "best_delta_per_chain": CORE.format_bounds(gain),
        "whole_upper_with_best_single_identification": CORE.format_bounds(whole),
    }


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack", type=Path)
    cli.add_argument("--expect", type=Path)
    args = cli.parse_args()
    paid, helpers = SEAM.CLOCK.JOINT.read_complex(args.complex_pack)
    results = {
        "status": "PASS_SHARED_PHYSICAL_BODY_PREFIX_PRICE",
        "compiler_fixtures": compiler_fixtures(),
        "arbitrary_overlap": prefix_caps(paid, helpers),
        "single_axis_pair_screen": local_reuse_comparison(paid, helpers),
    }
    payload = json.dumps(results, indent=2, sort_keys=True)
    if args.expect:
        need(payload == args.expect.read_text(encoding="utf-8").rstrip("\n"), "Receipt differs")
    print(payload)


if __name__ == "__main__":
    main()
