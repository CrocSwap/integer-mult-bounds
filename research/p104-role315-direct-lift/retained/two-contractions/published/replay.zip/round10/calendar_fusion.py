# SPDX-License-Identifier: Apache-2.0
"""Find and certify exact P104 receive-only chart contractions."""

import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE=Path(__file__).resolve().parent
AUDIT=run_path(str(HERE.parent/"round9/audit_upstream_7601.py"))
ROWS,NEED,CORE=(AUDIT[k] for k in ("ROWS","NEED","CORE"))
TAIL=AUDIT["BASE"]["TAIL"]
PRIME=1009
COLUMNS=128


def catalog(word):
    moves, touch = defaultdict(list),defaultdict(list)
    n=word["public"]
    for index,(op,role,*args) in enumerate(word["program"]):
        if op=="MOVE":
            moves[role].append((index,*args))
        else:
            use="read" if op not in ("ADD","SCALE") or role>=n else "write"
            touch[role].append((index,use))
            if op in ("ADD","COPY"):
                touch[args[0]].append((index,"read"))
    classes=Counter()
    out=[]
    for role,plan in sorted(moves.items()):
        if role>=n:
            continue
        for (left,a,b,_),(right,bb,c,_) in zip(plan,plan[1:]):
            if bb!=b:
                continue
            li,ri=bisect_left(touch[role],(left,"")),bisect_left(touch[role],(right,""))
            inside=touch[role][li:ri]
            kinds=tuple(sorted({u for _,u in inside}))
            classes[",".join(kinds) or "empty"]+=1
            if "read" not in kinds:
                out.append((role,left,right,a,b,c,tuple(i for i,_ in inside)))
    return out,dict(classes)


def delta_rows(word, catalog, deadline):
    wanted={i for *_,cuts in catalog for i in cuts}
    events=word["program"]
    queries=defaultdict(list)
    for i,(role,left,right,a,b,c,_) in enumerate(catalog):
        queries[left].append((i,0,a))
        queries[right].append((i,1,c))
    n=word["public"]
    x=[ROWS["unit"](i) for i in range(n)]+[ROWS["NONE"]]*word["owned_fields"]
    f=word["initial"][:]+[None]*word["owned_fields"]
    members=defaultdict(set)
    for k,v in enumerate(f):
        if v is not None:
            members[v].add(k)
    stock=[(None,None) for _ in catalog]
    values={}

    def frame_change(role,new):
        if f[role] is not None:
            members[f[role]].remove(role)
        f[role]=new
        if new is not None:
            members[new].add(role)

    for at,(op,role,*args) in enumerate(events):
        if at%1024==0:
            NEED(monotonic()<deadline,"bounded ordinary calendar")
        if at in queries:
            for i,side,chart in queries[at]:
                data=tuple((j,x[j]) for j in sorted(members[chart] | {role}) if x[j][1])
                old=stock[i]
                stock[i]=(data,old[1]) if not side else (old[0],data)
        if op=="MOVE":
            a,b,is_owned=args
            NEED(f[role]==a and is_owned==(role>=n),"paid frame movement")
            frame_change(role,b)
        elif op=="INIT":
            NEED(role>=n and f[role] is None,"owned initialization")
            frame_change(role,args[0])
        elif op=="CLEAR":
            NEED(role>=n and f[role]==args[0],"owned erasure")
            frame_change(role,None)
            x[role]=ROWS["NONE"]
        elif op=="SCALE":
            NEED(f[role]==args[1],"scale frame")
            x[role]=ROWS["scale"](x[role],ROWS["ratio"](args[0]))
        else:
            j,c,h=args
            NEED(f[role]==f[j]==h and role!=j,"coframed ADD/COPY")
            if op=="COPY":
                NEED(x[role]==ROWS["NONE"] and role>=n,"COPY to actual empty owner")
            else:
                NEED(op=="ADD","literal operator")
            if at in wanted:
                values[at]=x[j]
            x[role]=ROWS["increment"](x[role],x[j],ROWS["ratio"](c))
    NEED(x[:n]==ROWS["target"](word)[1],"every original public output")
    return stock,values


def net_delta(word,candidate,values):
    role,left,right,a,b,c,inside=candidate
    x=ROWS["NONE"]
    m=Fraction(1)
    prog=word["program"]
    for i in inside:
        op,_,*args=prog[i]
        if op=="SCALE":
            factor=Fraction(args[0])
            m*=factor
            x=ROWS["scale"](x,factor.as_integer_ratio())
        else:
            NEED(op=="ADD","public receive-only candidate")
            x=ROWS["increment"](x,values[i],ROWS["ratio"](args[1]))
    return m,x


def independent_stock(stock,role,target):
    """Select a stock basis with an inexpensive projected rank witness."""
    first=dict(stock[0])
    ordered=[(0,j,z) for j,z in stock[0] if j!=role]
    ordered.extend((1,j,z) for j,z in stock[1] if j!=role and first.get(j)!=z)
    repeated=set()
    unique=[]
    for side,j,(d,row) in ordered:
        key=d,tuple(sorted(row.items()))
        if key not in repeated:
            repeated.add(key)
            unique.append((side,j,(d,row)))
    support=Counter(k for _,_,(_,r) in unique for k in r)
    if any(k not in support for k in target[1]):
        return "excluded_coordinate_witness",[],[]
    if len(unique)>=COLUMNS:
        return "unresolved_projection_size",[],[]
    leading=sorted(target[1],key=lambda k:(support[k],k))[:COLUMNS//2]
    tail=sorted(support.keys()-set(leading),key=lambda k:(support[k],k))
    columns=(*leading,*tail[:COLUMNS-len(leading)])
    basis={}

    def extend(original):
        d,row=original
        NEED(d%PRIME!=0,"finite-field price screen has a nonunit denominator")
        v={i:row[k]%PRIME for i,k in enumerate(columns) if k in row and row[k]%PRIME}
        while v:
            p=min(v)
            y=v[p]
            if p not in basis:
                inv=pow(y,-1,PRIME)
                basis[p]={k:z*inv%PRIME for k,z in v.items()}
                return True
            for k,z in basis[p].items():
                value=(v.get(k,0)-y*z)%PRIME
                if value:
                    v[k]=value
                else:
                    v.pop(k,None)
        return False
    selected=[]
    dependencies=[]
    for w in unique:
        (selected if extend(w[-1]) else dependencies).append(w)
    if not dependencies and extend(target):
        return "excluded_rank_witness",[],[]
    return "directed_exact_solve",selected,dependencies


def solve(task):
    case,stock,target,m,expire=task
    if not target[1]:
        return "zero_residual",(m,{})
    screen,chosen,rejected=independent_stock(stock,case[0],target)
    if screen!="directed_exact_solve":
        return screen,None
    # Size and time limits on exact rational fill-in. Unresolved rows remain
    # explicit rather than being recorded as rank or restoration failures.
    if len(chosen)+len(rejected)>30 or sum(len(row) for _,_,(_,row) in chosen+rejected)>4000:
        return "unresolved_exact_size",None
    basis={}
    refs=[]
    for side,reg,(den,row) in chosen+rejected:
        NEED(monotonic()<expire,"bounded exact coframe elimination")
        serial=len(refs)
        refs.append((side,reg))
        # Exact rational elimination is kept small here. This loop is
        # bounded separately even if an ill-shaped chart fills densely.
        TAIL["solve_echelon"](basis,{j:Fraction(y,den) for j,y in row.items()},{serial:Fraction(1)})
    den,row=target
    residue,coeff=TAIL["solve_echelon"](basis,{j:Fraction(y,den) for j,y in row.items()}, {},save=False)
    if residue:
        return "excluded_exact_stock",None
    return "matched_exact_stock",(m,{refs[k]:-v for k,v in coeff.items()})


def fusion_patch(word,candidate,solved):
    role,left,right,a,b,c,inside=candidate
    multiplier,combo=solved
    premix,late=[],[]
    for (side,src),coeff in sorted(combo.items()):
        op=["ADD",role,src,str(coeff if side else coeff/multiplier),c if side else a]
        (late if side else premix).append(op)
    prog=word["program"]
    result=[]
    for i,e in enumerate(prog):
        if i==left:
            result.extend(premix)
            result.append(["MOVE",role,a,c,False])
        elif i==right:
            if multiplier!=1:
                result.append(["SCALE",role,str(multiplier),c])
            result.extend(late)
        elif i not in inside:
            result.append(e)
    return {**word,"program":result}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate_dir",type=Path)
    args=parser.parse_args()
    word=AUDIT["checked"](args.candidate_dir/"word.json.gz",AUDIT["NEW"])
    deadline=monotonic()+36
    cases,classes=catalog(word)
    stock,values=delta_rows(word,cases,deadline)
    matches,census=[],Counter()
    batch=[]
    for case,data in zip(cases,stock,strict=True):
        m,target=net_delta(word,case,values)
        batch.append((case,data,target,m,deadline))
    def report(results):
        for case,(label,sol) in zip(cases,results,strict=True):
            NEED(monotonic()<deadline,"bounded exact catalog search")
            census[label]+=1
            if sol is not None:
                mult,combo=sol
                matches.append({"case":case,"scale":str(mult),"added_adds":len(combo),
                                "coefficients":[[a,b,str(c)] for (a,b),c in sorted(combo.items())]})
    report(map(solve,batch))
    print(json.dumps({"status":"PASS_EXACT_ENDPOINT_CALENDAR","classes":classes,
                      "receive_only_cases":len(cases),"exact_stock_rank_witnesses":census,
                      "all_legal_endpoint_solutions":matches},
                     indent=2,sort_keys=True))


if __name__=="__main__":
    main()
