# Tenth-round reproducibility

The archive includes the emitted word, immutable source inputs, exact receipts and source notices. It verifies every member's SHA-256 before running a standard-library replay. Use Python 3.12 or later with assertions enabled and a fresh destination.

~~~powershell
Expand-Archive -LiteralPath .\kappa-research-round10-replay.zip -DestinationPath .\round10-source
python -I -B -S -W error .\round10-source\round10\check_replay_bundle.py .\kappa-research-round10-replay.zip .\round10-fresh
~~~

Append `--gpu` to run the coordinate screen on Direct3D 11 and CPU. CPU-only is the default and verifies the identical exact witness census. The GPU compares both the literal coordinate demands and controlled mutations. Its numerical performance is excluded from the receipt equality. The calendar has finite projection and rational-elimination budgets. Unresolved candidates remain explicit. The main candidate verifies all Gaussian columns of the four new chart pairs over the #7546 base and reruns its signed caller, precision envelopes, total rank bill and numerical outer gates under the original framework premises.

The row/ownership scope and complete tariff checks are in `TWO-FUSION.md`. The general negative results are retained in `algebra`, `independent` and `recurrence`. The public claim audit remains independently archived in `round9`.
