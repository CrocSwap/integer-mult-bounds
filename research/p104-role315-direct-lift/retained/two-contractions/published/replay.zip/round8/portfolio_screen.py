# SPDX-License-Identifier: Apache-2.0
"""Compare CPU and D3D11 screens of complete common-center tariff envelopes."""

import argparse
from array import array
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from itertools import islice, product
import json
from pathlib import Path
import sys
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent

SPEC = spec_from_file_location("full_mask_idle", HERE / "recurrence" / "verify_full_mask_idle.py")
FULL = module_from_spec(SPEC)
SPEC.loader.exec_module(FULL)
CLOCK, CORE, NEED = FULL.CLOCK, FULL.CORE, FULL.need
MIN_STAGES, MAX_STAGES, WIDTH = 5, 41, 192
POINTS = ((5,1000),(227,10000))
SHIFT = 1 << 30
UNIT = 10_000
BIAS = 1 << 31


HLSL = r"""
StructuredBuffer<uint> tables : register(t0);
StructuredBuffer<uint> jobs : register(t1);
RWStructuredBuffer<uint> verdict : register(u0);
RWStructuredBuffer<uint> mandatory : register(u1);

[numthreads(64,1,1)]
void main(uint z : SV_DispatchThreadID) {
    uint x=jobs[2*z];
    uint y=jobs[2*z+1];
    if (x==0u) { verdict[z]=0u; mandatory[z]=0u; return; }
    uint l=x & 255u;
    int b=int((x>>8) & 65535u);
    int d=int(y & 65535u);
    int c=int((y>>16) & 65535u);
    int even=int((l-3u)/2u);
    int q=even/2;
    int sum_short=2*q*(q+1)+(even%2)*int(l-1u)/2;
    int penalty=d==0 ? 2*even*(c/2) : (4*even+2*sum_short)*d+2*(even*c/2);
    int need=max(0,192*int(l-3u)-penalty);
    int short_marks=max(0,need-int(l)*c);
    int score=asint(tables[5*b]) + asint(tables[5*b+1])*d
             + asint(tables[5*b+2])*need + asint(tables[5*b+3])*short_marks
             + asint(tables[5*b+4])*c;
    verdict[z]=score<0 ? 1u : 2u;
    mandatory[z]=asuint(need);
}
"""


def interval_delta(a, b):
    return CORE.add(a,CORE.scaled(b,-1))


def h(rank, point):
    return CORE.price(rank,*point)


def make_coefficients(L,point,paid,helpers):
    l0 = interval_delta(CORE.scaled(h(17,point),3),CORE.scaled(h(25,point),2))
    l1 = interval_delta(h(25,point),h(17,point))
    headers = interval_delta(h(8*L+1,point),h(8*L,point))
    charge,_,_ = CLOCK.supporting_line(L,point)
    # Every short provider has <=L-1 axes. Check every relevant mark using a
    # closed interval. Zero-short marks were covered by supporting_line.
    options = []
    for x in range(L+1):
        line = CORE.add(l0,CORE.scaled(l1,x))
        for y in range(1,L-x+1):
            k=x+y
            short = min(k,L-1)
            for t in range(y if k==L else 1):
                v = CORE.add(h(8*k+1,point), CORE.scaled(h(8*short,point),t-y,short))
                v = CORE.add(v,CORE.scaled(h(8*L,point),-t,L))
                gap = CORE.add(interval_delta(line,v),CORE.scaled(charge,-y))
                options.append(CORE.scaled(gap,1,y-t)[0])
    short_debit = min(options)
    NEED(short_debit >= 0, "short masks need a nonnegative directed surcharge")
    # Only a lower bound on the short debit is needed here.
    short_debit = (short_debit,short_debit)
    hist = Counter({r:L*c for r,c in helpers.items()})
    hist.subtract({r:L*c for r,c in paid.items()})
    hist.update({1:8*L,8:8*L,9:8*L})
    supplier = CORE.moment(hist,*point)
    base = CORE.add(supplier,CORE.add(CORE.scaled(l0,WIDTH*(L-1)),CORE.scaled(l1,2*WIDTH*L)))
    return base,CORE.scaled(l0,-1),CORE.scaled(charge,-1),CORE.scaled(short_debit,-1),interval_delta(l0,headers)


def marks(l,c,d):
    even = (l-3)//2
    q = even//2
    shorter = 2*q*(q+1)+(even%2)*((l-1)//2)
    penalty = 2*even*(c//2) if d==0 else (4*even+2*shorter)*d+2*(even*c//2)
    total = max(0,WIDTH*(l-3)-penalty)
    return total,max(0,total-l*c)


def encode(L, table_index, c, d):
    return L | (table_index<<8), d | (c<<16)


def cpu_lattice(rows, bounds):
    verdicts,counts = array("I"),array("I")
    for job,c_d in rows:
        l, table = job&255, job>>8
        d,c = c_d&65535, c_d>>16
        need,short = marks(l,c,d)
        a,b,g,j,o = bounds[table]
        prefix = a+b*d+g*need+j*short+o*c
        NEED(-SHIFT < prefix < SHIFT, "screen left signed integer range")
        verdicts.append(1 if prefix < 0 else 2)
        counts.append(need)
    return verdicts,counts


def cpu_oracle(rows, exact, lattice_verdicts):
    view = array("I")
    for (job,c_d),code in zip(rows,lattice_verdicts,strict=True):
        l, table = job&255, job>>8
        d,c = c_d&65535, c_d>>16
        need,short = marks(l,c,d)
        base,defect,m,s,odd = exact[table]
        real_cap = base[1]+defect[1]*d+m[1]*need+s[1]*short+odd[1]*c
        direction = 1 if real_cap < 0 else 2
        NEED(code!=1 or direction==1,"GPU lattice enclosure has a false negative")
        view.append(direction)
    return view


def check_reference(exact, paid, helpers):
    lengths = range(MIN_STAGES,MAX_STAGES+1,2)
    for l in lengths:
        even = tuple(range(2,l-1,2))
        short_sum = sum(min(i,l-1-i) for i in even)
        NEED(marks(l,0,2)[0]==max(0,WIDTH*(l-3)-2*(4*len(even)+2*short_sum)),
             "closed clock-index counting")
    for index,point in enumerate(POINTS):
        ref = FULL.prices(paid,helpers,point)["scopes"]
        t = index*len(lengths)+lengths.index(17)
        for c,d in product(range(65),(0,2,4)):
            z = ref[f"c{c}_d{d}"]
            n,s = marks(17,c,d)
            NEED((n,s)==(z["required_idle_marks"],z["required_short_mask_idle_marks"]),
                 "all 195 original clock marks agree at length 17")
            u = sum(coef[1]*v for coef,v in zip(exact[t],(1,d,n,s,c),strict=True))
            NEED((u < 0) == z["margin"][1].startswith("-"),
                 "length 17 directed pricing sign")


def all_jobs():
    Ls = tuple(range(MIN_STAGES,MAX_STAGES+1,2))
    for t,j in product(range(len(POINTS)), range(len(Ls))):
        l = Ls[j]
        for c,d in product(range(257),range(0,258,2)):
            yield encode(l,t*len(Ls)+j,c,d)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("complex_pack",type=Path)
    ap.add_argument("backend",type=Path)
    ap.add_argument("output",type=Path)
    ap.add_argument("--cpu-only", action="store_true")
    args = ap.parse_args()
    deadline = monotonic()+48
    guard = None
    if sys.platform == "win32":
        sys.path.insert(0,str(HERE.parent))
        from benchmark_helper_cohorts import BACKEND_SHA, Limit, gpu_batch
        guard = Limit()
        guard.poll("before portfolio pricing")
    if not args.cpu_only:
        NEED(guard is not None,"Use --cpu-only on a platform without D3D11")
        guard.sample("before portfolio pricing")
    paid,helpers=CLOCK.JOINT.read_complex(args.complex_pack)
    exact = [make_coefficients(l,p,paid,helpers) for p in POINTS for l in range(MIN_STAGES,MAX_STAGES+1,2)]
    check_reference(exact,paid,helpers)
    lattice = [tuple(CORE.ceil_div(r[1]*UNIT,CORE.SCALE) for r in z) for z in exact]
    packed = array("I",(r & (2*BIAS-1) for z in lattice for r in z))
    device = None
    gpu_setup=batch_cpu=batch_gpu=exact_cpu=0.0
    hist, first, extra = Counter(),{},0
    signature = sha256()
    small = {}
    try:
        if not args.cpu_only:
            NEED(sha256(args.backend.read_bytes()).hexdigest()==BACKEND_SHA,"GPU backend pin")
            spec=spec_from_file_location("d3d11_backend",args.backend)
            backend=module_from_spec(spec)
            spec.loader.exec_module(backend)
            backend.HLSL=HLSL
            device=backend.D3D11()
            start=perf_counter()
            device.open()
            device.compile()
            gpu_setup=(perf_counter()-start)*1000
            guard.sample("after portfolio shader initialization")
        jobs=all_jobs()
        batch=list(islice(jobs,256))
        while batch:
            NEED(monotonic()<deadline,"bounded complete portfolio screen")
            if guard is not None:
                guard.poll("before allocated portfolio batch")
            c0=perf_counter()
            verdict,terms=cpu_lattice(batch,lattice)
            cpu_ms=(perf_counter()-c0)*1000
            gpu_ms=0
            if device is not None:
                (g1,g2),gpu_ms=gpu_batch(backend,device,packed,batch,guard)
                NEED(g1==verdict and g2==terms,"GPU agrees with all exact-integer host results")
            c0=perf_counter()
            oracle=cpu_oracle(batch,exact,verdict)
            exact_cpu+=(perf_counter()-c0)*1000
            if not small:
                small={"cases":len(batch),"cpu_ms":cpu_ms,"gpu_ms":gpu_ms}
            batch_cpu+=cpu_ms
            batch_gpu+=gpu_ms
            signature.update(verdict.tobytes())
            signature.update(terms.tobytes())
            signature.update(oracle.tobytes())
            extra+=sum(x!=y for x,y in zip(verdict,oracle,strict=True))
            for (job,cd),v in zip(batch,oracle,strict=True):
                l,tab=job&255,job>>8
                key=(tab//((MAX_STAGES-MIN_STAGES)//2+1),l)
                hist[key+(v,)]+=1
                if v==2 and not(cd&65535) and key not in first:
                    first[key]=cd>>16
            batch=list(islice(jobs,262144))
    finally:
        if device is not None:
            device.close()
        if device is not None:
            guard.sample("after portfolio device release")
    NEED(sum(hist.values())==len(exact)*257*129,"all parameter designs screened")
    result={"status":"PASS_PORTFOLIO_SCREEN", "scope":"scope-specific necessary prices, no constructed caller at nonnegative rows",
            "total":sum(hist.values()),"gpu":device.adapter_name if device else None,
            "cpu_lattice_ms":batch_cpu,"cpu_directed_oracle_ms":exact_cpu,
            "gpu_compute_and_io_ms":batch_gpu,"gpu_setup_ms":gpu_setup,
            "small":small,"exact_grid_extra_rejections":extra,"census_sha256":signature.hexdigest(),
            "resources":guard.samples if guard else [],"rows":[{"k":POINTS[t][0]/POINTS[t][1],"stages":l,
                                         "negative":hist[t,l,1],"nonnegative_relaxation":hist[t,l,2],
                                         "first_d0_open_compound_odd_idle_count":first.get((t,l))}
                                         for t,l in sorted({p[:2] for p in hist})]}
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(result["status"],result["total"],result["census_sha256"],
          f"CPU {batch_cpu:.1f} ms, GPU {batch_gpu:.1f} ms, setup {gpu_setup:.1f} ms, exact {exact_cpu:.1f} ms")


if __name__ == "__main__":
    main()
