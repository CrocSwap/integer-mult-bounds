# SPDX-License-Identifier: Apache-2.0
"""Authenticate and independently replay eighth-round research receipts."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from runpy import run_path
import subprocess
import sys
from time import perf_counter


JOBS = (
    ("signed_idle_defect", "signed-idle-defect", "pack"),
    ("recurrence/verify_even_clock_balance", "recurrence/even-clock-balance", "expect"),
    ("recurrence/verify_idle_residue", "recurrence/idle-residue", "expect"),
    ("recurrence/verify_full_mask_idle", "recurrence/full-mask-idle", "expect"),
    ("algebra/reciprocal_relay", "algebra/reciprocal-relay-results", "stdout"),
    ("algebra/oblique_reciprocal", "algebra/oblique-reciprocal-results", "stdout"),
    ("independent/port_gauge", "independent/port-gauge", "signed"),
    ("independent/mixed_body_packet", "independent/mixed-body-packet", "signed"),
    ("portfolio_screen", "portfolio-screen", "portfolio"),
    ("clock_capacity", "clock-capacity", "pack"),
    ("../round9/recurrence/verify_seam_price", "../round9/recurrence/seam-price", "expect"),
    ("../round9/recurrence/verify_combined_price", "../round9/recurrence/combined-price", "expect"),
    ("../round7/host_defect", "../round7/host-defect", "stdout"),
    ("../round7/recurrence/verify_grouped_q0", "../round7/recurrence/grouped-q0", "expect"),
)
PORTFOLIO_KEYS = ("status", "total", "exact_grid_extra_rejections", "rows", "census_sha256")


def replay(dest, job, gpu):
    script, receipt, mode = job
    source = (dest / "round8" / f"{script}.py").resolve()
    expected = (dest / "round8" / f"{receipt}.json").resolve()
    output = dest / "run" / f"{Path(receipt).name}.json"
    args = {
        "expect": ["inputs", "--expect", str(expected)],
        "pack": ["inputs"],
        "signed": ["inputs/7546-word.json.gz", "inputs/7113-caller.json",
                   "inputs/7546-whole.json", str(output)],
        "portfolio": ["inputs", "inputs/benchmark-d3d11-backend.py", str(output)]
                     + ([] if gpu else ["--cpu-only"]),
        "stdout": [],
    }
    start = perf_counter()
    run = subprocess.run([sys.executable, "-I", "-B", "-S", "-W", "error",
                          str(source), *args[mode]], cwd=dest, capture_output=True, timeout=58)
    if run.returncode or run.stderr:
        raise RuntimeError((script, run.returncode, run.stderr.decode(errors="replace")))
    actual = json.loads(output.read_bytes() if output.exists() else run.stdout)
    reference = json.loads(expected.read_bytes())
    if mode == "portfolio":
        actual, reference = ({k: z[k] for k in PORTFOLIO_KEYS} for z in (actual, reference))
    if actual != reference:
        raise ValueError(f"{script} differs from the saved receipt")
    return script, perf_counter() - start


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument("--gpu", action="store_true")
    args = parser.parse_args()
    dest = args.destination.resolve()
    dest.mkdir()
    helper = Path(__file__).resolve().parents[1] / "round7" / "check_replay_bundle.py"
    hashes = run_path(str(helper))["extract"](args.archive, dest)
    (dest / "run").mkdir()
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        workers = [pool.submit(replay, dest, entry, args.gpu) for entry in JOBS]
        for job in workers:
            script, elapsed = job.result()
            print(f"PASS {script} {elapsed:.2f}s", flush=True)
    print(f"PASS_ROUND8_REPLAY {len(JOBS)} fresh receipts and {hashes} archived hashes")


if __name__=="__main__":
    main()
