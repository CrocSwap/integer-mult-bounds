# Cyclic missing runs and the cost of even-clock incidence

Compare the common-center signed relative sectors \(q=i,-i\) under the assumptions of [SIGNED-IDLE-DEFECT.md](SIGNED-IDLE-DEFECT.md). A full native has \(r\) odd transvections and one independent width-eight body shared by its \(2r\) active roles. The number of full stages \(L\) is odd. Positive unit body incidences and an independent diagonal monomial endpoint are essential. The missing-run law uses exact defect \(r\) and no additional compound odd idles. The price by even clock below separately allows larger defect and compound odd idles. Mixing Type B and A, thin odd shears, signed cancellations of body factors, and the rounded compiler are outside the proof. The native scalar sign form has a scalar precedent in the repository. [Header braid classification](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/research/p104-header-braid-classification/PROOF.md)

## The exact capacity of omitted runs

In the saturated canonical Gram, \(V_iU_j=2\operatorname{sgn}(j-i)I_r\), and the only block relation among columns is \(\sum_j(-1)^jU_j=0\). Since the Gram is skew-symmetric and has rank \(n=r(L-1)\), there is a nondegenerate skew form \(J\) on the \(n\) roles with \(V_i=U_i^{\mathsf T}J\). Indeed, the full column map is surjective and its kernel is the two-sided kernel of that Gram, so the Gram descends to the roles. The \(W_i=I+U_iV_i\) and all their prefixes \(R_b=W_{b-1}\cdots W_0\) preserve \(J\) because \(U_i^{\mathsf T}JU_i=0\).

An actual body idle at cut \(b\) carries a body mask \(T\ne\varnothing\). In the nominal input gauge it has a rank-one projector \(wf\) with \(f(w)=1\). For every \(i\in T\) the rank-saturated body projectors mutually annihilate in each sector. Thus both \(f\) and \(g=w^{\mathsf T}J\) annihilate \(U_i\) and \(R_bR_i^{-1}U_i\). The column assertion follows by applying the symplectic identity to the two row assertions for \(V_i\). Define vector-valued rows \(s_j=(-1)^j fU_j\) and \(t_j=(-1)^j gU_j\). Each has total zero and vanishes at every listed label \(i\). Expansion of the canonical prefix also forces the sum of \(s_j\) on the cyclic interval from \(b\) up to \(i\) to vanish, and the same holds for \(t_j\). For \(b\le i\) the expansion is \(U_i+2\sum_{b\le a<i}(-1)^{i-a}U_a\). For \(b>i\) it is \(U_i+2\sum_{i<a<b}(-1)^{a-i}U_a\). Subtracting the constraints at consecutive listed labels and using the total-zero relation shows that the linear maximal missing runs in the order starting at \(b\) each have sum zero. This also proves sufficiency for these two row annihilation constraints.

Write \(w=\sum_j U_j a_j\) and \(B_j=(-1)^j a_j\). The signed Gram implies \(B_{j+1}-B_j=(t_j+t_{j+1})^{\mathsf T}/2\). The common additive constant in the \(B_j\) drops from \(f(w)\), giving

\[
f(w)=\sum_j s_j\left(\tfrac12 t_j+\sum_{k<j}t_k\right)^{\mathsf T}.
\]

The form is alternating on zero-sum lists. Moving the first entry to the end changes the value by zero because the totals of both lists vanish. Keep the original signs \((-1)^j\) when rotating the order. Disjoint missing runs are mutually orthogonal in this form. On the zero-sum subspace of a run of \(h\) missing indices, the adjacent differences form a basis of size \(h-1\) per native coordinate. The pairing in that basis is skew tridiagonal, with adjacent entries of absolute value \(1/2\). Its rank is \(2r\lfloor(h-1)/2\rfloor\).

All idles containing any one body label in common have biorthogonal nominal projectors, so \(f_a(w_b)=\delta_{ab}\). For a fixed common mask \(T\), all such idles have zero-sum rows on its **cyclic** missing runs regardless of their physical cuts. Changing the cut can only refine the spaces by splitting one missing run. Their aggregate count is therefore at most

\[
  2r\sum_{B\text{ cyclic run missing from }T}\left\lfloor (|B|-1)/2\right\rfloor.
\]

For a single idle the linear run version already forces a run of at least three missing clocks. Thus an actual positive idle mask has width at most \(L-3\). If it has width \(L-3\), the omitted triple must be cyclically consecutive and the cut must not split that triple. At a fixed cut, a local sharpness fixture takes the two neighboring differences on an omitted triple, with a factor of two and a sign for \(f(w)=1\). Two omitted clocks alone can leave a nonzero annihilator, whose induced pairing is zero. It cannot support a restored rank-one idle. The sharpness fixture concerns the row and column constraints. The complete native-body projections and joint Laurent endpoint need further construction.

The grouping restriction also localizes the forced returns. Fix the original seam immediately before clock zero. At an even interior clock \(i\), \(A_i=R_i^{-1}U_i=U_i+2\sum_{a<i}(-1)^aU_a\) and \(B_i=V_iR_i=A_i^{\mathsf T}J\). An idle covering \(i\) whose missing runs do not cross the original seam annihilates \([U_i,A_i]\) and \([V_i;B_i]\) on their corresponding sides. The prefix sums vanish because the prefix consists of whole missing runs and zero entries. Removing those idle projectors from the nominal decomposition therefore leaves both stacks inside its remaining rank-\(2r+I_i^{\rm seam}\) support. Their ranks are \(2r\) individually and their pairing is zero. Sylvester's inequality forces **\(I_i^{\rm seam}\ge2r\)**. The following price uses the count of even incidences and does not require this localization.

## Charging a complete group for its even incidences

Use the affine line \(\ell(x)=H_{17}+(x-2)(H_{25}-H_{17})\), and assign all native and idle marks by the determinant matching in [EVEN-CLOCK-BALANCE.md](recurrence/EVEN-CLOCK-BALANCE.md). A root with \(x\) native and \(y>0\) idle marks has target width \(8(x+y)+1\). Distribute its excess over the affine line equally among its \(y\) idle marks. If an actual idle covers \(a\) labels, every coordinate receiving one of its matched marks carries all \(a\) labels. Its aggregate excess allocations are at most \(a G_a\), where

\[
G_a=\max_{a\le k\le L,\,0\le x<k}\frac{H_{8k+1}-\ell(x)}{k-x},\qquad
\nu=\min_{a\ge1}\frac{H_{8a}-a G_a}{\min(a,(L-3)/2)}.
\]

The minimum is over \(a\le L\), or \(a\le L-3\) for the saturated all-even-idle class. The price of each paid group after its credit is at least \(\nu\) times the number of even interior labels it actually covers. The body part of a compound odd idle obeys the same argument. Its odd increment is still separately paid, and a header-only idle has zero body marks. Summing over all groups counts each marked body incidence once. The forced total \(M\) from the two-sector rank bound for general \(c,d\) counts only even interior labels, so the entire price loses at least \(\nu M\). Where relevant also compute the independent full-width mask bound and use the smaller of the two upper margins.

| Odd stages | Compound odd idles and extra defect | Upper margin at κ=.005 |
|---:|---|---:|
| 17 | \(c=d=0\) | −28.8954181537894 |
| 17 | \(c=105\), all admissible \(d\) | −0.0634744836599 |
| 19 | \(c=d=0\) | **−3.3487212920233** |
| 21 | \(c=d=0\) | +22.2271300960780 |

At 17 stages all \(c\le105\) are excluded by this pair of bounds. The first remaining upper envelope at \(c=106,d=20\) is +0.1674686380. At 19 stages with \(d=0\), \(c\le15\) is excluded. At \(c=0\) the computed exclusion reaches \(d=8\), and \(d=10\) survives. These are boundaries of a necessary cost condition. In every case all original #7546 native and helper costs are retained, and Type B receives the optimistic complete joint cut. The 19- and 21-stage \(c=d=0\) margins also remain negative at .0227. The proof uses exact Gaussian-rational scalar sectors and directed arithmetic for the recurrence. A modified fixed tape, compiled precision, and outer product remain unverified.

`clock_capacity.py` generates rational clock-projector fixtures and prices all even extra defects compatible with a nonnegative number of roots through \(c=128\) in the reported rows. To replay it, use `python -I -B -S -W error round8/clock_capacity.py inputs`. An independently written directed-price checker is included alongside the main replay.
