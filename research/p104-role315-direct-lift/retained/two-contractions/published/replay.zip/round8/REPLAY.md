# Eighth-round reproducibility

Use Python 3.12 or newer, the standard library, PowerShell, and an empty destination directory. The checker authenticates every archive member and runs each eighth-round computation from the new extraction. The old source code and the fixed #7546, #7113, and BIT inputs needed by those computations are included.

```powershell
Expand-Archive -LiteralPath .\kappa-research-round8-replay.zip -DestinationPath .\round8-source
python -I -B -S -W error .\round8-source\round8\check_replay_bundle.py .\kappa-research-round8-replay.zip .\round8-fresh
```

Append `--gpu` to replay the same grid against the bundled D3D11 shader path on Windows with an NVIDIA driver and `nvidia-smi`. CPU-only is the default. CUDA and ComfyUI are unnecessary. The numerical census and input hashes are deterministic. The timings and memory polls depend on the local system. The CPU classifies the directed price interval independently of the coarse integer screen and verifies that every GPU rejection is sound. A nonnegative count records a surviving relaxation only.

Proofs and counterexamples are in `SIGNED-IDLE-DEFECT.md`, `CLOCK-CAPACITY.md`, `recurrence`, `algebra`, and `independent`. The separate derivation and directed-price scripts under `round9/recurrence` verify the even-clock and joint costs against the same source inputs. Each formula prices the child ranks under the indicated interface. The proof's input, restoration, precision and tape requirements apply as written. Files named `upstream-*.json` retain the public heads and hosted checks observed during the round. Older rounds are included as dependencies. The modular reducer from round seven is corrected and its archived round-seven result is rerun here.
