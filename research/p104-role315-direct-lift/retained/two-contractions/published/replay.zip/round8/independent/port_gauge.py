"""Exact all-port common-head rebinding and a mixed A/B shear commutator."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from time import monotonic

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DIRECT = run_path(str(ROOT / "round7" / "independent" / "direct_complex_native.py"))
BODY = run_path(str(ROOT / "round3" / "independent" / "shared_body.py"))
FLOOR = run_path(str(ROOT / "round3" / "independent" / "pinned" / "upstream_application.py"))
BASE, NEED, PHYSICAL = (DIRECT[k] for k in ("BASE", "NEED", "PHYSICAL"))
N = 9
U = 1
FULL = 127
CENTRAL = (1 << N) - 1
TAPE_LIMIT = 45


def orthonormal(word, port):
    q = word["ports"][port]
    role = word["live"][port]+112
    space = DIRECT["ADJ"]["span"](word["frames"][word["final"][role]])
    basis = BODY["orthogonal_reps"](space, 8)
    NEED(basis and BODY["orthonormal"]([q,*basis]), "actual q and q⊥ orthonormal basis")
    return tuple([q,*basis])


def transform_address(rows, vector):
    return (vector & ~CENTRAL) | sum(FLOOR["dot"](r,vector) << j for j,r in enumerate(rows))


def factor_linear(rows):
    """Return all central XOR and swaps, and check their exact composition."""
    b = list(rows)
    gates = []
    for col in range(N):
        pick = next(i for i in range(col,N) if b[i]>>col&1)
        if pick != col:
            b[pick],b[col] = b[col],b[pick]
            gates.append(("SWAP",pick,col))
        for row in range(N):
            if row != col and b[row]>>col&1:
                b[row] ^= b[col]
                gates.append(("XOR",row,col))
    NEED(b == [1<<i for i in range(N)], "complete reversible address reduction")
    replay = b[:]
    for op,a,c in reversed(gates):
        if op == "SWAP": replay[a],replay[c] = replay[c],replay[a]
        else: replay[a] ^= replay[c]
    NEED(replay == list(rows), "every emitted ordinary address gate preserves exact bijection")
    return gates


def canonical_boundary(compiler, word, pi, p, slopes):
    """Prove local Γ charts equal the stored canonical frames up to signed monomials."""
    q = word["ports"][pi]
    reg = word["live"][pi]
    recorded = [word["initial"][reg],word["initial"][reg+112],
                word["final"][reg],word["final"][reg+112]]
    physical = [compiler.canonical_frame(N,word["frames"][f]) for f in recorded]
    gamma = [compiler.cgate(N,q),compiler.ident(N),compiler.fourier(N),
             compiler.cgate(N,q,-1).then(compiler.fourier(N))]
    ops = []
    for orig, representative in zip(physical,gamma,strict=True):
        boundary = representative.adjoint().then(orig)
        recipe, _ = compiler.lower_child(boundary)
        NEED(recipe["rank"]==0,"canonical register interface differs from Γ only by an exact signed monomial")
        ops.append(recipe["left"])
    core=compiler.cgate(N,q)
    want=compiler.cgate(N,U)
    PHYSICAL["equal_signed_clifford"](p.adjoint().then(core).then(p),want,True)
    PHYSICAL["equal_signed_clifford"](p.adjoint().then(core.adjoint()).then(p),want.adjoint(),True)
    std = compiler.fourier(N)
    phase_match=std.then(compiler.xgate(N,slopes))
    PHYSICAL["equal_signed_clifford"](p.adjoint().then(std).then(p),phase_match,True)
    for x in range(1<<N):
        source=FLOOR["dot"](compiler.mv(compiler.transpose(p.circuit[0][1],N),x),q)
        NEED(source==FLOOR["dot"](x,U), "all Fourier characters, including eigenvalue one")
    return ops


def composed_stage_wrapper(basis, stage):
    """Produce signed affine rows via one physical permutation and one translation."""
    q,*b = basis
    p = tuple(basis)
    pt = tuple(sum(((p[j]>>i)&1)<<j for j in range(N)) for i in range(N))
    old_route = FLOOR["route"](q,b,stage)
    fresh = [1 << (N+8*(stage-1)+i) for i in range(8)]
    old_prefix = [1<<j for j in range(N+8*(stage-1))]
    old_after = old_prefix+fresh
    local_spectators=[1<<j for j in range(N,N+8*stage)]
    before_x = FLOOR["terms"]((v,1) for v in old_prefix)
    before_y = FLOOR["terms"]([*before_x.items(),(q,-1)])
    after_x = FLOOR["terms"]((v,1) for v in old_after)
    after_y = FLOOR["terms"]([*after_x.items(),(q,-1)])
    native_x0 = FLOOR["terms"]([*((v,1) for v in local_spectators),(q,1)])
    native_y0 = FLOOR["terms"]((v,1) for v in local_spectators)
    native_x1 = FLOOR["terms"]((v,1) for v in [*(1<<j for j in range(N)),*local_spectators])
    native_y1 = FLOOR["terms"]([*native_x1.items(),(q,-1)])
    old_shifts = [FLOOR["boundary"](a,z,old_route)
                  for a,z in zip((before_x,before_y,native_x1,native_y1),
                                 (native_x0,native_y0,after_x,after_y),strict=True)]
    forward = lambda v:old_route(transform_address(pt,v))
    backward = lambda v:transform_address(p,old_route(v))
    for j in range(N+8*stage):
        v=1<<j
        NEED(backward(forward(v))==v and forward(backward(v))==v,"composed boundary has literal inverse")
    phases = []
    # The old phase gauge is conjugated, not reinterpreted as a new phase-free chart.
    for a,z,s in zip((before_x,before_y),(native_x0,native_y0),old_shifts[:2],strict=True):
        aff = FLOOR["terms"]([*((forward(transform_address(p,v)),e) for v,e in a.items()),(s,2)])
        NEED(not FLOOR["polynomial"](FLOOR["sub"](z,aff)),"conjugated signed entry phase")
        phases.append(s)
    for a,z,s in zip((native_x1,native_y1),(after_x,after_y),old_shifts[2:],strict=True):
        translated = transform_address(p,s)
        aff = FLOOR["terms"]([*((backward(v),e) for v,e in a.items()),(translated,2)])
        common = FLOOR["terms"]((transform_address(p,v),e) for v,e in z.items())
        NEED(not FLOOR["polynomial"](FLOOR["sub"](common,aff)),"conjugated signed exit phase")
        phases.append(translated)
    # In common coordinates all noncentral body directions remain identical across ports.
    NEED(transform_address(p,q)==U and all(transform_address(p,v)==v for v in fresh),"fixed external body and common head")
    for before, after, sign in ((before_x, after_x, 0),(before_y, after_y, 0),
                                (before_x, after_y, -1),(before_y, after_x, 1)):
        powers=[(transform_address(p,v),e) for v,e in FLOOR["sub"](after,before).items()]
        want=FLOOR["terms"]([*((v,1) for v in fresh),(U,sign)])
        NEED(not FLOOR["polynomial"](FLOOR["sub"](FLOOR["terms"](powers),want)),
             "all identity and opposite shear routes use the same exact common phase")
    return phases


def binding(compiler, word, caller, deadline):
    NEED(caller["ambient_rank"]==145 and caller["stages"]==17,"exact signed caller ambient")
    rows, pass_hist, phase_checks, ports = {}, Counter(), [], []
    main_count = 0
    ap = set(caller["types"]["A"]["ports"])
    for pi,q in enumerate(word["ports"]):
        NEED(monotonic()<deadline,"all-port phase binding deadline")
        basis = orthonormal(word,pi)
        p = compiler.perm(N,basis)
        steps = factor_linear(basis)
        pass_hist[len(steps)] += 1
        slopes=FLOOR["translation"](FLOOR["terms"]([*((transform_address(basis,1<<i),1) for i in range(N)),
                                                     *((1<<i,-1) for i in range(N))]))
        local_monomials = canonical_boundary(compiler,word,pi,p,slopes)
        for stage in range(1,18):
            phase_checks.append([pi,stage,composed_stage_wrapper(basis,stage)])
        arity = 4 if pi in ap else 2
        main_count += arity
        rows[pi] = basis
        ports.append({"port":pi,"q":q,"source_rows":basis,"type":"A" if pi in ap else "B",
                      "elementary_linear_passes":len(steps),"linear_passes":list(reversed(steps)),
                      "full_central_translation":slopes,"native_boundary_monomials":local_monomials})
    NEED(main_count==400 and len(phase_checks)==1768,"all A/B main phase contacts for 17 stages")
    main_wrappers = 2*17*main_count
    root_count = sum(len(v["ports"])*v["roles"] for v in caller["types"].values())
    boundary_elementary = sum(34*(4 if p["type"]=="A" else 2)*p["elementary_linear_passes"] for p in ports)
    root_elementary = sum(2*caller["types"][p["type"]]["roles"]*p["elementary_linear_passes"] for p in ports)
    return rows,{"outer_stage_wrapper_records_sha256":sha256(json.dumps(phase_checks,separators=(",",":")).encode()).hexdigest(),
                 "tested_independent_porttypes":Counter(x["type"] for x in ports),
                 "canonical_boundary_monomials_checked":4*len(rows),"root_public_owners":root_count,
                 "checked_chronological_stage_contacts":34*main_count,
                 "all_port_route_ordinary_histogram":dict(sorted(pass_hist.items())),
                 "extra_unfused_permutation_wrappers_upper":main_wrappers+2*root_count,
                 "extra_unfused_address_elementary_stage_upper":boundary_elementary,
                 "extra_unfused_address_elementary_root_upper":root_elementary,
                 "extra_unfused_elementary_passes_upper":boundary_elementary+root_elementary,
                 "candidate_scope":"pure affine common-gauge rebind; no changes to the old owner clock or old productive fields",
                 "recursive_children_added_by_gauge":0,"route_inventory":ports}


def gadd(a,b):
    return a[0]+b[0],a[1]+b[1]


def gmul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]


def choose_pair(word,caller):
    a_ports=caller["types"]["A"]["ports"]
    b_ports=caller["types"]["B"]["ports"]
    return [(a,b) for overlap in (0,1) for a,b in [next((a,b) for a in a_ports for b in b_ports
                                                       if FLOOR["dot"](word["ports"][a],word["ports"][b])==overlap)]]


def mixed_pair_controls(word,caller,gauges):
    """Exact address conjugacy and a toy common-head shear identity."""
    checks=0
    wrong_sign=0
    recovered=[]
    units=((Q(1),Q(0)),(Q(0),Q(1)),(Q(-1),Q(0)),(Q(0),Q(-1)))
    for a,b in choose_pair(word,caller):
        qa,qb=word["ports"][a],word["ports"][b]
        reps={ (FLOOR["dot"](x,qa),FLOOR["dot"](x,qb)) for x in range(512)}
        NEED(len(reps)==4,"distinct physical header directions")
        for x in range(512):
            ta,tb=(gauges[p] for p in (a,b))
            for repeat in (1,2):
                # independently compare true one-digit Fourier values at two different addresses
                ys=[transform_address(ta,x),transform_address(tb,x)]
                for p,y in zip((a,b),ys,strict=True):
                    z=transform_address(tuple(sum(((gauges[p][j]>>i)&1)<<j for j in range(N)) for i in range(N)),y)
                    NEED((repeat*FLOOR["dot"](z,word["ports"][p]))%4 == (repeat*FLOOR["dot"](y,U))%4,
                         "real phase along restored independent lane and address inverses")
        for j,k in reps:
            aphase,bphase=units[j],units[k]
            transform=units[(2*(j^k))%4]
            wrong_sign+=gmul(aphase,transform)!=bphase
        # Full four-root cross-port owner algebra; tensor char choices attain
        # ±1 and ±i using at most three address columns.
        for exponent, q in enumerate(units):
            qi=units[-exponent%4]
            for column in range(5):
                e=[units[0] if i==column else (Q(0),Q(0)) for i in range(5)]
                x,y,z,t,f=e
                # Elementary toy semidirect shear action after actual head
                # conjugacy. A literal Type B host replay is separate.
                v=e[:]
                for leg in (0,1,2,3):
                    if leg in (0,2):
                        sign=1 if leg==0 else -1
                        v[1]=gadd(v[1],gmul((Q(sign),Q(0)),gmul(q,v[2])))
                    else:
                        sign=1 if leg==1 else -1
                        v[0]=gadd(v[0],gmul((Q(sign),Q(0)),gmul(qi,v[1])))
                expected=[gadd(x,z),y,z,t,f]
                NEED(v==expected,"all-input low-rank mixed commutator and independent spectators")
                checks+=5
        recovered.append({"port_ids":[a,b],"q":[qa,qb],"overlap":FLOOR["dot"](qa,qb),"physical_addresses":512})
    NEED(wrong_sign==4,"translation-only restoration fails for both genuinely mismatched phase sectors per pair")
    return {"literal_mixed_pairs":recovered,"dirty_qi_coefficients":checks,
            "fixed_address_translation_only_failures":wrong_sign,
            "all_four_root_phase_checks":4,"formal_commutator_is_separate_from_invoice":True}


def whole_invoice(word,caller,whole,route,deadline):
    native_paid=Counter(abs(len(word["frames"][e[3]])-len(word["frames"][e[2]])) for e in word["program"] if e[0]=="MOVE")
    n=caller["stages"]
    old_helpers={int(k):v*n for k,v in whole["signed_profile"]["native_productive"].items()}
    receipt=DIRECT["signed_price"](native_paid,whole,n,extra_productive=old_helpers)
    NEED(receipt["complete_paid_count"]==110_468 and receipt["complete_productive_count"]==22_461,"all funded roles preserved")
    NEED(all(abs(m["vs_source_delta"])<1e-50 for m in receipt["exact_moment"].values()),"unchanged full recursive tariff")
    NEED(monotonic()<deadline,"limited physical and fee replay")
    return receipt


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for a in ("word","caller","whole","output"):
        p.add_argument(a,type=Path)
    args=p.parse_args()
    start=monotonic(); deadline=start+TAPE_LIMIT
    compiler,word=PHYSICAL["load_pins"](args.word)
    caller=json.loads(BASE["pin"](args.caller,BASE["CALLER"]))
    whole=json.loads(BASE["pin"](args.whole,BASE["WHOLE"]))
    g,route=binding(compiler,word,caller,deadline)
    control=mixed_pair_controls(word,caller,g)
    price=whole_invoice(word,caller,whole,route,deadline)
    out={"status":"PASS_P104_COMMON_AFFINE_PHYSICAL_GAUGE", "source_head":DIRECT["ADJ"]["NATIVE_HEAD"],
         "common_address_axis":U,"physical_binding":route,"mixed_controls":control,
         "complete_original_caller_after_gauge":price}
    args.output.write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
    print(out["status"],f"{monotonic()-start:.2f}s",flush=True)


if __name__=="__main__":
    main()
