"""Full phase check and physically charged restoration of a mixed A/B loop."""

import argparse
from collections import Counter
from fractions import Fraction as Q
from itertools import product
import json
from pathlib import Path
from runpy import run_path
from time import monotonic

HERE = Path(__file__).resolve().parent
GAUGE = run_path(str(HERE / "port_gauge.py"))
BASE, NEED, PHYSICAL = (GAUGE[k] for k in ("BASE", "NEED", "PHYSICAL"))
DIRECT = GAUGE["DIRECT"]
UNIT = ((1,0),(0,1),(-1,0),(0,-1))
ZERO = (Q(0),Q(0))
ORDER = ("Bi","Ai","B","A")


def add(a,b,scale=1):
    return a[0]+scale*b[0],a[1]+scale*b[1]


def phase(a,power):
    u,v = UNIT[power % 4]
    return u*a[0]-v*a[1],v*a[0]+u*a[1]


def half(a):
    return tuple(x/2 for x in a)


def apply(event,q,d,e,row):
    p,s,t,u,v = row
    if event=="A":
        return (phase(p,d),phase(add(s,phase(p,-q)),d),t,
                phase(add(u,phase(v,q),-1),d),phase(v,d))
    if event=="Ai":
        return (phase(p,-d),phase(add(s,phase(p,-q),-1),-d),t,
                phase(add(u,phase(v,q)),-d),phase(v,-d))
    if event=="B":
        return (p,phase(add(s,phase(t,q),-1),e),half(phase(add(t,phase(s,-q)),e)),u,v)
    NEED(event=="Bi","known literal local host")
    return (p,phase(add(half(s),phase(t,q)),-e),phase(add(t,phase(s,-q),Q(-1,2)),-e),u,v)


def execute(order,q,d,e,x):
    out=x
    for op in order:
        out=apply(op,q,d,e,out)
    return out


def first_control():
    """Counterexample if independent body-active hosts are treated as scalars."""
    p=(Q(1),Q(0))
    initial=(ZERO,p,ZERO,ZERO,ZERO)
    got=execute(ORDER,0,1,0,initial)
    expected=(ZERO,(Q(1,2),Q(1,2)),(Q(-1,4),Q(-1,4)),ZERO,ZERO)
    NEED(got==expected and got!=initial,"dirty middle coordinate changes even with p=0")
    # Corrections which read only p cannot change this fixture.
    return {"Q_exp":0,"D_exp":1,"E_exp":0,"input":["0","1","0","0","0"],
            "output":["0","(1+i)/2","-(1+i)/4","0","0"],
            "p_only_repair_rejected":True}


def replay():
    all_inverse=tuple(op[:-1] if op.endswith("i") else op+"i" for op in reversed(ORDER))
    completed=central=lost_body=lost_translation=0
    for q,d,e in product(range(4),repeat=3):
        for j in range(5):
            x=tuple((Q(1),Q(0)) if i==j else ZERO for i in range(5))
            y=execute(ORDER,q,d,e,x)
            restored=execute(all_inverse,q,d,e,y)
            NEED(restored==x,"independent inputs on each side of the fully charged rollback")
            completed+=len(x)
            guessed=list(x)
            guessed[2]=add(x[2],phase(x[0],-2*q),Q(-1,2))
            if d==e==0:
                NEED(y==tuple(guessed),"character-independent companion fields and exact Laurent relay without bodies")
                central+=len(x)
                corrected=list(y)
                corrected[2]=add(y[2],phase(y[0],2*q),Q(1,2))
                NEED(corrected==list(x),"ordinary signed translation repairs the center-only relay")
                if q%2 and not j:
                    lost_translation+=add(y[2],y[0],Q(1,2))!=x[2]
            else:
                lost_body+=y!=tuple(guessed)
    NEED(lost_body>0 and lost_translation==2,"body and central translation negative fixtures")
    return {"full_body_inverse_word":all_inverse,"restored_dirty_coefficients":completed,
            "center_only_dirty_coefficients":central,"body_ignorance_rejected_columns":lost_body,
            "central_translation_omission_rejected_columns":lost_translation,
            "body_counterexample":first_control()}


def physical_controls(compiler,word,caller,deadline):
    """Bind actual port q generators, with genuine signed rather than normalized phases."""
    result=[]
    for a,b in GAUGE["choose_pair"](word,caller):
        equations=[]
        for port in (a,b):
            q=word["ports"][port]
            p=compiler.perm(9,GAUGE["orthonormal"](word,port))
            for s in (1,-1):
                common=p.adjoint().then(compiler.cgate(9,q,s)).then(p)
                wish=compiler.cgate(9,1,s)
                PHYSICAL["equal_signed_clifford"](common,wish,True)
                recipe,compiled=compiler.lower_child(common)
                NEED(recipe["rank"]==1,"signed header step on every dirty input")
                PHYSICAL["equal_signed_clifford"](compiled,wish,True)
                equations.append((port,q,s))
        result.append({"actual_ports":[a,b],"signed_header_checks":equations})
    op=compiler.cgate(9,1).then(compiler.cgate(9,1))
    translation=compiler.xgate(9,1)
    PHYSICAL["equal_signed_clifford"](op,translation,True)
    # Eight body axes commute and their negative orientations are translated.
    direct=compiler.fourier(9,range(1,9))
    PHYSICAL["equal_signed_clifford"](direct.then(compiler.xgate(9,510)),direct.adjoint(),True)
    NEED(compiler.rank([x for x,_,_ in direct.adjoint().tab[9:]])==8,"explicit signed whole rank-eight inverse")
    NEED(monotonic()<deadline,"bounded physical fixtures")
    return {"pair_cases":result,"center_restore_is_ordinary_translation":True,"forward_and_inverse_whole_body_rank":8}


def price_full(word,caller,whole):
    """Price the complete restored gadget on the old full 17-stage invoice."""
    n=caller["stages"]
    native=Counter(abs(len(word["frames"][e[3]])-len(word["frames"][e[2]])) for e in word["program"] if e[0]=="MOVE")
    keep={int(k):v*n for k,v in whole["signed_profile"]["native_productive"].items()}
    # 4 true local mixed hosts, then buy all four direct inverse hosts to
    # roll back. Each A has two rank-1 and four rank-8 steps, each B
    # has two rank-1 and two rank-8 steps. No retained whole word is inverted.
    add=Counter({1:16,8:24})
    old=DIRECT["signed_price"](native,whole,n,extra_paid=add,extra_productive=keep)
    # Without bodies the same direct factorizations need only eight
    # rank-one header steps and an ordinary translation repair.
    central=DIRECT["signed_price"](native,whole,n,extra_paid={1:8},extra_productive=keep)
    NEED(old["complete_paid_count"]==110_508 and central["complete_paid_count"]==110_476 and
         old["complete_productive_count"]==central["complete_productive_count"]==22_461,"complete public and helper price")
    return {"full_body_restoration_extra_paid":dict(add),"full_body_loop_with_inverse":old,
            "center_only_direct_extra_paid":{"1":8},"center_only_loop_with_translation_repair":central,
            "added_independent_productive_outputs":0}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for label in ("word","caller","whole","output"):
        ap.add_argument(label,type=Path)
    args=ap.parse_args()
    start=monotonic(); deadline=start+15
    compiler,word=PHYSICAL["load_pins"](args.word)
    caller=json.loads(BASE["pin"](args.caller,BASE["CALLER"]))
    whole=json.loads(BASE["pin"](args.whole,BASE["WHOLE"]))
    result={"status":"PASS_TRUE_MIXED_A_B_CENTRAL_BODY_CONTROL","schedule":ORDER,
            "exact_dirty_inputs":replay(),"physical":physical_controls(compiler,word,caller,deadline),
            "whole_caller_comparison":price_full(word,caller,whole)}
    args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(result["status"],f"in {monotonic()-start:.2f}s",flush=True)


if __name__=="__main__":
    main()
