# SPDX-License-Identifier: Apache-2.0
"""Certify an exact-defect price bound with genuine compound odd idles."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path


HERE = Path(__file__).resolve().parent
BASE = HERE.parent
JOINT = run_path(str(BASE / "round5" / "recurrence" / "verify_joint_body_header.py"))
CORE = JOINT["CORE"]
LINEAR = run_path(str(BASE / "round7" / "host_defect.py"))
mm, take, transpose, rank = (LINEAR[k] for k in ("mm", "take", "transpose", "rank"))
identity, add, factor_gram = (LINEAR[k] for k in ("identity", "add", "factor_gram"))
NEED = CORE.need
STAGES, WIDTH, PORTS, BODY = 17, 192, 96, 8


def zero(rows, cols):
    return [[0] * cols for _ in range(rows)]


def scaled(a, factor, p):
    return [[factor * v % p for v in row] for row in a]


def inv(a, p):
    n = len(a)
    rows = [r[:] + e for r,e in zip(a,identity(n),strict=True)]
    for j in range(n):
        k = next(i for i in range(j,n) if rows[i][j])
        rows[j], rows[k] = rows[k], rows[j]
        f = pow(rows[j][j], -1, p)
        rows[j] = [f*x % p for x in rows[j]]
        for i in range(n):
            if i != j:
                f = rows[i][j]
                rows[i] = [(x-f*y)%p for x,y in zip(rows[i],rows[j],strict=True)]
    return [r[n:] for r in rows]


def matrix_fixture(width, hosts, reflections, p, omitted_axes=()):
    """Realize prescribed low-rank defect, including nilpotent idle factors."""
    e = identity(width)
    indices, factors, kinds = [], [], []
    for j in range(hosts + 1):
        for clock, a, b, *multiplier in reflections:
            if j == clock:
                amount = (multiplier[0] if multiplier else 1) if a != b else 0
                indices.append((sum(len(x) for x, _ in factors),))
                factors.append(([e[a]], transpose(scaled([e[b]],amount,p))))
                kinds.append("odd_idle")
        if j < hosts:
            cols = [col for col in range(width) if not omitted_axes or col not in omitted_axes[j]]
            full = [e[col] for col in cols]
            if not full:
                continue
            first = sum(len(x) for x, _ in factors)
            indices.append(tuple(range(first, first+len(full))))
            factors.append((full, transpose(full)))
            kinds.append("host")
    x = [row for left, _ in factors for row in left]
    y = [row for _, right in factors for row in transpose(right)]
    k = mm(x, transpose(y), p)
    size = len(x)
    clock_at = {i: j for j, block in enumerate(indices) for i in block}
    gram = zero(size, size)
    for i in range(size):
        for j in range(size):
            ci, cj = clock_at[i], clock_at[j]
            c = cj-ci
            if c:
                gram[i][j] = ((2 if c > 0 else -2) * k[i][j]) % p
            elif i == j and kinds[ci] == "odd_idle":
                gram[i][j] = p-2
    dim = size-width
    shift = identity(width)
    for left, right in factors:
        shift = mm(add(identity(width),mm(right,left,p),p,-2),shift,p)
    actual = rank(gram,p)
    expected = size-width+rank(add(shift,identity(width),p),p)
    NEED(actual==expected, f"defect kernel mismatch: {actual}, {expected}, {reflections}")
    if actual != dim:
        return None, {"width":width,"hosts":hosts,"field":p,"idle_clocks":reflections,
                      "omitted_defect_axes":omitted_axes,
                      "expected_gram_rank":dim,"actual_gram_rank":actual}
    u, v = factor_gram(gram, p, dim)
    return (factors, kinds, indices, u, v), None


def ideal_profile(price, reflection_count):
    n = WIDTH*(STAGES-1) + reflection_count
    h17, h25 = price(17), price(25)
    intercept = CORE.add(CORE.scaled(h17,3),CORE.scaled(h25,-2))
    # Sum the same tangent even when there are too few roots to balance on 2,3.
    tangent = CORE.add(CORE.scaled(intercept,n),
                       CORE.scaled(CORE.add(h25,CORE.scaled(h17,-1)),2*WIDTH*STAGES))
    return n, tangent


def check_clocks(w, hosts, reflections, p, omitted_axes=()):
    source, failure = matrix_fixture(w, hosts, reflections, p, omitted_axes)
    if failure is not None:
        return {"rejected_off_clock_defect_fixture":failure}
    factors, kinds, indices, U, V = source
    n = len(U)
    R = identity(n)
    flow = identity(w)
    identity_defect = identity(w)
    role = tuple(range(n))
    projections = []
    early = 0
    for a, ((X,Y), block, kind) in enumerate(zip(factors,indices,kinds,strict=True)):
        u, v = take(U, role, block), take(V, block, role)
        if kind == "host":
            r = len(block)
            d = w-r
            r_inverse = inv(R,p)
            next_u, next_v = mm(r_inverse,u,p), mm(v,R,p)
            left = [x+y for x,y in zip(u,next_u,strict=True)]
            right = v+next_v
            if early and early % 2 == 0 and early < hosts-1:
                dimension = rank(mm(right,left,p),p)
                rl, rr = rank(left,p), rank(right,p)
                NEED(min(rl,rr)>=2*r-2*d, "sector prefix stacks lost independent rows")
                earlier = next(b for b in reversed(range(a)) if kinds[b]=="host")
                later = next(b for b in range(a+1,len(kinds)) if kinds[b]=="host")
                observed = mm(take(V,indices[earlier]+indices[later],role),left,p)
                NEED(rank(observed,p)>=2*r-2*d,"signed clock separation lost a direction")
                seen = kinds[:a].count("odd_idle")
                remainder = len(reflections)-seen
                allowed = min(d*early+seen,d*(hosts-1-early)+remainder)
                NEED(dimension <= 2*allowed,"compound deflection exceeds both clock rank budgets")
                if d == 0:
                    NEED(dimension == 2*rank(add(flow,identity_defect,p,-1),p), "computed clock displacement misses pairing defect")
                projections.append({"native_clock":early,"pairing_rank":dimension,
                                    "column_stack_rank":rl,"row_stack_rank":rr,
                                    "necessary_coordinate_dimension":rl+rr-dimension})
            early += 1
        else:
            NEED(mm(v,u,p)==[[p-2]],"odd idle did not produce a rank-one relative reflection")
        R = mm(add(identity(n),mm(u,v,p),p),R,p)
        flow = mm(add(identity_defect,mm(Y,X,p),p,-2),flow,p)
    NEED(R==scaled(identity(n),-1,p),"full all-odd relative endpoint")
    return {"width":w,"hosts":hosts,"field":p,"idle_clocks":reflections,"ordinary_role_dimension":n,
            "omitted_defect_axes":omitted_axes,
            "two_sided_controls":projections}


def full_price(paid, helpers, p, reflection_count, d=0):
    # At exact excess r, each rank-one reflection yields a possible new root.
    # Retain all native work and credit only its original independent helper outputs.
    def price(k):
        return CORE.price(k, *p)

    counts = Counter({r: STAGES * c for r, c in helpers.items()})
    counts.subtract({r: STAGES * c for r, c in paid.items()})
    # Eight B ports get the larger model's complete joint-cut capacity.
    counts.update({1:8*STAGES, 8:8*STAGES, 9:8*STAGES})
    side = CORE.moment(counts, *p)
    n, base = ideal_profile(price, reflection_count-d)
    # Pair earlier and later interior clocks. Their short sides include disjoint
    # reflection sets. The central clock only needs the smaller of its two sides.
    penalty = (14*(reflection_count//2)) if not d else (92*d+2*(7*reflection_count//2))
    mandatory = max(0, WIDTH*(STAGES-3)-penalty)
    gap = []
    for x in range(STAGES + 1):
        for y in range(1, STAGES - x + 1):
            k = x+y
            line = CORE.add(CORE.scaled(price(17),3-x), CORE.scaled(price(25),x-2))
            role = CORE.add(price(BODY*k+1), CORE.scaled(price(BODY*k),-y,k))
            z = CORE.add(line, CORE.scaled(role,-1))
            gap.append((CORE.scaled(z,1,y),x,y))
    minimum, x0, y0 = min(gap, key=lambda e: e[0][0])
    NEED((x0,y0)==(0,17) and minimum[0]>0, "tangent selector certificate")
    loss = CORE.scaled(minimum,-mandatory)
    # Every compound odd idle has a residual header charge H_(8a+1)-H_(8a),
    # after its full body amount has been used for matched marks. Drop the
    # choice of a for an upper bound and use the smallest possible increment.
    odd_charge = CORE.add(price(BODY*STAGES+1), CORE.scaled(price(BODY*STAGES),-1))
    total = CORE.add(CORE.add(side,base), CORE.add(loss,CORE.scaled(odd_charge,-reflection_count)))
    return {"roots": n, "compound_odd_idle_calls": reflection_count, "surplus_above_minimum":d,
            "min_body_idle_incidences": mandatory,
            "body_deficit_charge_per_incidence": CORE.format_bounds(minimum),
            "whole_margin_upper": CORE.format_bounds(total),
            "scope": "common q, positive unit distinct bodies, no odd shears outside the native hosts"}


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("complex_pack", type=Path)
    o = args.parse_args()
    paid, helpers = JOINT["read_complex"](o.complex_pack)
    envelope = {k:[full_price(paid, helpers, p, c) for c in range(39)]
                for k,p in ((".005", (5,1000)), (".0227", (227,10000)))}
    controls = [check_clocks(w,5,q,p) for w in (2,3) for p in (5,13,101)
                for q in ((), ((1,0,0),), ((1,0,1),), ((1,0,1),(4,0,1,-1)),
                          ((1,0,1),(2,0,1,2),(4,0,1,-3)))]
    configs = ((0,1),(0,1),(0,2),(0,3),(2,3))
    bad_configs = ((0,),(1,),(0,),(1,),(2,))
    controls.extend(check_clocks(4,5,q,p,configs) for p in (5,13,101)
                    for q in ((), ((1,0,1),(4,0,1,-1))))
    controls.extend(check_clocks(3,5,(),p,bad_configs) for p in (5,13,101))
    price_point = (5,1000)
    h17, h25 = (CORE.price(r,*price_point) for r in (17,25))
    intercept = CORE.add(CORE.scaled(h17,3), CORE.scaled(h25,-2))
    # lambda is the unique minimum at (0,17), so it has this exact formula.
    head137 = CORE.add(CORE.price(137,*price_point),CORE.scaled(CORE.price(136,*price_point),-1))
    lam = CORE.scaled(CORE.add(intercept,CORE.scaled(head137,-1)),1,17)
    monotone = CORE.add(intercept,CORE.scaled(lam,-92))
    NEED(monotone[0]>0,"surplus need not improve the relaxed margin")
    # d is even: determinant of the total relative operator is (-1)^c, and
    # the fixed WIDTH*(STAGES-1) contribution to dimension is even.
    d2 = [full_price(paid,helpers,price_point,c,2) for c in range(40)]
    relevant = envelope[".005"][:37]+d2[:37]
    NEED(all(Fraction(row["whole_margin_upper"][1])<0 for row in relevant), "36-idle exclusion changed")
    print(json.dumps({"status": "PASS_PRICED_SIGNED_ODD_IDLE_DEFECT", "envelope": envelope,
                      "minimum_positive_extra_defect_at_005":d2,
                      "decrease_per_extra_defect_lower_at_005":CORE.format_bounds(monotone),
                      "accepted_gram_controls":sum("two_sided_controls" in row for row in controls),
                      "rejected_gram_prototypes":sum("rejected_off_clock_defect_fixture" in row for row in controls),
                      "finite_operator_controls": controls}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
