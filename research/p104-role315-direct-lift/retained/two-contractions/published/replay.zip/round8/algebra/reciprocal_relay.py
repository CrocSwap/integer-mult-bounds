"""Contract complementary BIT swaps and verify the exact nonnested flag limit."""

from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
sys.path[:0] = [str(BASE / "round7" / "algebra"), str(BASE / "round6"),
                str(BASE / "round6" / "algebra"), str(BASE / "algebra")]
from directed_flag_dual import (ORBITS, TERMS, WEIGHTS, integer_polynomial, lower_value)
from permute_head_frames import head_geometry
from scan_bit_fixed_graph import projector_frame, supported_interval
from scan_bit_move_runs import basis, load_word
from singleton_relay import circuit
from syndrome_packets import compare, require

ALG = run_path(str(BASE / "algebra" / "verify_bit_orthogonal_quotient.py"))


def contraction(word):
    frames,_,start,final,_ = circuit(word,two_way=True)
    n = len(start)//2
    steps = []
    for i in range(n):
        steps.extend([("MOVE",i,start[i],final[n+i]),
                      ("MOVE",n+i,start[n+i],final[i]),("SWAP",i,n+i)])
    return frames,steps,start,final


def replay(literal):
    frames,steps,start,final = literal
    n = len(start)//2
    location = start.copy()
    value = [1<<i for i in range(len(start))]
    target = [1<<((i+n)%(2*n)) for i in range(2*n)]
    rank_paid = Counter()
    ar = ALG["Arithmetic"]()
    cached = {}
    for op,i,*tail in steps:
        if op == "SWAP":
            j, = tail
            location[i],location[j] = location[j],location[i]
            value[i],value[j] = value[j],value[i]
        elif op == "MOVE":
            a,b = tail
            require(location[i] == a, "wrong movement source")
            if (a,b) not in cached:
                p = projector_frame(frames[a][0])
                q = projector_frame(frames[b][0])
                diff = ar.combine(p,q,-1)
                delta = len(basis(diff))
                require(delta > 0, "zero movement")
                # Only commuting projectors are used, even when incomparable.
                require(ar.mul(p,q) == ar.mul(q,p), "unlicensed noninvolutory quotient")
                u = ar.mul(ar.combine(ar.eye(8),ar.scale(q,2),-1),
                           ar.combine(ar.eye(8),ar.scale(p,2),-1))
                require(u == ar.scale(ar.eye(8),-1),"endpoint quotient is not the full paired address swap")
                require(len(basis(ar.combine(u,ar.eye(8),-1))) == delta,
                        "literal quotient rank disagrees")
                cached[a,b] = delta
            rank_paid[cached[a,b]] += 1
            location[i] = b
        else:
            raise ValueError(op)
    require(location==final and value==target,"complete arbitrary-input exchange")
    for j,expected in enumerate(target):
        u = 1<<j
        for op,i,*tail in reversed(steps):
            if op=="SWAP":
                k=tail[0]
                if ((u>>i)^(u>>k))&1:
                    u ^= (1<<i)|(1<<k)
        require(u==expected,"reverse coefficient disagrees")
    return {"paid":dict(rank_paid),"all_templates_checked":len(cached),
            "each_direction_public_coefficients":(2*n)**2,
            "owned_peak":0,"tape_word_length":len(steps)}


def finite_ring_controls():
    total = 0
    for modulus in (101,1009**2):
        a = ALG["Arithmetic"](modulus)
        g = ALG["split_operator"](a,a.scale(a.eye(8),-1),[1]*8)
        left,child,right = ALG["compile_one"](a,g,8)
        require(a.mul(a.mul(left,g),right)==child,"exact literal full child")
        require(a.mul(child,child)==a.eye(16),"full child is not reciprocal")
        total +=16
    return total


def dual_extension():
    selectors = {x:[j for j in range(256) if j&1==x[0] and (j>>1).bit_count()==x[1]]
                 for x in ORBITS}
    forms = {}
    for a in range(256):
        for b in range(256):
            if a==b:
                continue
            delta=(a^b).bit_count()
            signature=(delta,*(sum((a&j).bit_count()%2==orbit[2] and
                                   (b&j).bit_count()%2!=orbit[2] for j in selectors[orbit])
                               for orbit in ORBITS))
            forms.setdefault(signature,[]).append((a,b))
    gaps = {}
    for s in (".005",".0227"):
        h=[(0,0)]+[supported_interval(i,Fraction(s)) for i in range(1,9)]
        bad=[]
        strict=[]
        for (r,*hits),moves in forms.items():
            p=integer_polynomial([(r,1)]+[(j,-Fraction(n,len(selectors[x]))*v)
                                 for n,x,w in zip(hits,ORBITS,WEIGHTS,strict=True)
                                 for j,v in zip(TERMS,w,strict=True)])
            if not any(p):
                continue
            val=lower_value(p,h)
            if val <= 0:
                bad.extend(moves)
                require(p==integer_polynomial(((8,1),(1,-1),(7,-1))),
                        "only overcharge is the 1+7 split")
            else:
                strict.append(val)
        require(bad==[(1,254)],"unexpected second dangerous incomparable pair")
        gaps[s]={"failing_masks":bad,"overcharge_upper":float(-lower_value(
            integer_polynomial(((8,1),(1,-1),(7,-1))),h)),
                 "minimum_strict_positive_slack":float(min(strict))}
    return {"ordered_mask_pairs":256*255,"compressed_signatures":len(forms),"rates":gaps}


def main():
    w=load_word()
    ar=ALG["Arithmetic"]()
    got=replay(contraction(w))
    require(got["paid"]=={8:222},"complete contracted paid bill")
    # A non-orthogonal pair of distinct cap/head choices cannot use the
    # commuting complement compiler. Check its actual non-involution.
    heads,_caps,p = head_geometry(w)
    i,j=0,14
    require(p[i]!=p[j] and ar.mul(p[i],p[j])!=ar.mul(p[j],p[i]),"expected actual oblique pair")
    q=ar.combine(ar.eye(8),p[j],-1)
    u=ar.mul(ar.combine(ar.eye(8),ar.scale(q,2),-1),ar.combine(ar.eye(8),ar.scale(p[i],2),-1))
    require(ar.mul(u,u)!=ar.eye(8),"false stationary full-exchange calibration")
    # This comparison shares the swap endpoint exactly. A two-way full-body
    # port contributes 2 H8 (not a second or even a first odd-header job).
    old={1:111,7:111,8:111}
    report={"status":"PASS_COMMUTING_COMPLEMENT_RELAY","exact_exchange":got,
            "cold_full_child_columns":finite_ring_controls(),
            "wrong_offdiagonal_head_mutation":[i,j],
            "rank_credit":{8:222},"raw_pricing":compare({8:222},old,{8:222}),
            "directional_dual_extension":dual_extension()}
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
