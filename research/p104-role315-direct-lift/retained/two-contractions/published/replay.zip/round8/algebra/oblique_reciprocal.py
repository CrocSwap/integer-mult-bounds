"""Exact one-child calibration and odd-sector counterexample for oblique relays."""

from collections import Counter
from fractions import Fraction
from itertools import product
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from reciprocal_relay import ALG, head_geometry, load_word, require
from scan_bit_move_runs import basis
from permute_head_frames import dot
from scan_bit_fixed_graph import supported_interval


def rational_classes(word):
    h,caps,coeff = head_geometry(word)
    gram = Counter()
    for i,j in product(range(len(h)),repeat=2):
        square=dot(h[i],h[j])**2/(dot(h[i],h[i])*dot(h[j],h[j]))
        require(square in (0,Fraction(1,4),1),"E8 squared angle changed")
        key="diagonal" if i==j else "orthogonal" if square==0 else "oblique"
        require((square==1)==(i==j),"duplicated line")
        gram[key]+=1
    return coeff,h,caps,gram


def relative(ar, p, q):
    R=lambda x:ar.combine(ar.eye(8),ar.scale(x,2),-1)
    return ar.mul(R(q),R(p))


def check_compiler(table):
    out=[]
    unit = ALG["Arithmetic"]()
    for (i,j),w in product(((0,14),(14,15),(22,40)),([1]*8,list(range(2,10)))):
        u = relative(unit,table[i],unit.combine(unit.eye(8),table[j],-1))
        ident=unit.eye(8)
        require(len(basis(unit.combine(u,ident,-1)))==8,"wrong oblique relative rank")
        require(unit.mul(u,u)!=ident and unit.mul(u,unit.mul(u,u))==unit.scale(ident,-1),
                "order-six Weyl quotient")
        size=0
        expect = None
        for mod in (None,101,1009**2):
            ar=ALG["Arithmetic"](mod)
            g=ALG["split_operator"](ar,ar.matrix(u),[ar.scalar(v) for v in w])
            _,_,head = ALG["north_east"](ar,ALG["corner"](g),8)
            _,_,back = ALG["north_east"](ar,ALG["corner"](ar.invert(g)),8)
            require(head==back,"oblique forward or inverse pivot changed")
            a,child,b=ALG["compile_one"](ar,g,8)
            require(ar.mul(ar.mul(a,g),b)==child,"ordinary two lower adapters")
            reciprocal=[child[15-k][k] for k in range(8)]
            require(reciprocal==[ar.inverse_unit(d) for d in head],"reverse child weights are not exact reciprocals")
            if mod is None:
                expect=(list(map(str,head)),list(map(str,reciprocal)))
            size+=16
        out.append({"ordered_ports":[i,j],"external_weights":list(map(str,w)),
                    "head_pivots":expect[0],"inverse_pivots":expect[0],
                    "physical_backward_reciprocals":expect[1],"verified_columns":size})
    return out


def odd_sector_control(table):
    """Gauge telescoping and determinant on an actual oblique A2 cycle."""
    ar=ALG["Arithmetic"]()
    I=ar.eye(8)
    H=[0,14,15]
    R=lambda p:ar.combine(I,ar.scale(p,2),-1)
    # Ordered L_i→H_j factors are all even on the difference space.
    cycle=I
    for i,j in zip(H,H[1:]+H[:1]):
        p=table[i]
        q=ar.combine(I,table[j],-1)
        each=relative(ar,p,q)
        require(len(basis(ar.combine(each,I,-1)))==8,"cycle needs full rank each")
        cycle=ar.mul(each,cycle)
    require(cycle==ar.scale(I,-1),"cycled oblique orientations did not telescope")
    polynomial = [I,ar.scale(I,-1)]
    values=[]
    for scheme in product((0,1),repeat=3):
        # Each literal inverse remains in the even determinant component.
        op=I
        for i,j,backward in zip(H,H[1:]+H[:1],scheme):
            g=ar.scale(ar.mul(R(table[j]),R(table[i])),-1)
            op=ar.mul(ar.invert(g) if backward else g,op)
        require(constructed_det(op)==1,"one false odd-sector claimant")
        values.append({"reverse":scheme,"body_point":next((i for i,a in enumerate(polynomial) if op==a),None),
                       "odd_head":False})
    require(constructed_det(R(table[0]))==-1,"counterexample: real odd head is missing")
    return {"actual_three_head_cycle":H,"forward_product":"-I",
            "alternate_orientations":values,"odd_rank_one_head_det":-1}


def constructed_det(a):
    M=[r[:] for r in a]
    d=Fraction(1)
    for j in range(len(M)):
        i=next(i for i in range(j,len(M)) if M[i][j])
        if i!=j:
            M[i],M[j]=M[j],M[i]
            d=-d
        v=M[j][j]
        d*=v
        for i in range(j+1,len(M)):
            z=M[i][j]/v
            M[i]=[a-z*b for a,b in zip(M[i],M[j],strict=True)]
    return d


def price():
    out=[]
    for s in (".005",".0227"):
        h8=supported_interval(8,Fraction(s))
        h7=supported_interval(7,Fraction(s))
        # Each claimed use has the same dimension-8 cost. Any remaining move
        # to return to the original head or preserve a dipole is extra.
        gain=[111*(2**80+h7[k]-h8[1-k]) for k in (0,1)]
        out.append({"s":s,"local_rotation_child_rank":8,
                    "same_rank_evasion_budget_2pow80":gain,
                    "same_rank_evasion_budget_upper":gain[1]/2**80})
    return out


if __name__=="__main__":
    w=load_word()
    table,heads,_caps,angles=rational_classes(w)
    print(json.dumps({"status":"PASS_OBLIQUE_RECIPROCAL_AND_ROTATION_PARITY",
                      "all_source_bound_pairs":sum(angles.values()),
                      "ordered_classes":dict(angles),"full_child_replays":check_compiler(table),
                      "odd_sector_control":odd_sector_control(table),"rates":price()},indent=2))
