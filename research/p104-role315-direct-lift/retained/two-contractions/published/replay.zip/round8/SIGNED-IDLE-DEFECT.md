# Ordinary header excess and paid odd idles in a common-center caller

This calculation uses the exact #7546 native histogram and its original independent helper outputs. There are 17 Type A host stages, now allowed to mix all 96 Type A ports in a common center and one independent eight-axis body per stage. Inverse center signs of the two native shears per port are allowed. Each stage contributes an atomic set of \(r=192\) disjoint rank-one shears on \(2r\) roles. A body-only idle may group any positive unit subset of those stage bodies on one role. Allow \(c\) additional one-role compound odd idles using the same common center and arbitrary positive unit subsets. These include pure rank-one odd diagonal shifts. The body-only idles and the compound odd idles can occur anywhere. All main returns are independent diagonal monomials with one odd center and each body occurring at most once. Ordinary maps preserve the role dimension, are invertible on the two compared sectors, and have identical coefficient matrices at \(q=i,-i\) after the declared common-center routing. Type B is separate and receives its full optimistic joint-cut price. This is a changed caller class. The literal #7113 includes sector-changing thin shears and needs a separate calculation. [#7546 native](https://github.com/CrocSwap/integer-mult-bounds/pull/7546) · [#7113 application](https://github.com/CrocSwap/integer-mult-bounds/blob/07a76c5e2738882c0cb322278e56f6cae3c9885d/research/signed-caller-8x9/APPLICATION.md)

## Sign-relative defect factors

Set the bodies to one and use normalized opposite-sector factors \(W_a=I+U_aV_a\) in the initial role basis. A full stage uses \(V_aU_a=0\). A paid one-role odd idle is a rank-one reflection, so \(V_aU_a=-2\) and \(W_a^{-1}=W_a\). This holds for either odd center sign. The complete relative endpoint is \(-I_n\). Stack the columns in \(U\), the rows in \(V\), put \(C=VU\), and let \(L\) be the strictly lower part of \(C\) in event blocks. The diagonal blocks of full stages vanish even if viewed pulse by pulse. Expansion in increasing time gives

\[
U(I-L)^{-1}V=-2I_n,\qquad K=I-L+C/2.
\]

The rank of \(K\) is \(r+d=m-n\), where \(m=17r+c\). Each full diagonal block of \(K\) is \(I_r\), so \(d\ge0\). The determinant of the relative product is \((-1)^c\). With 17 stages, \(n=16r+c-d\), so \(d\) is even. Factor \(K=XY\) through dimension \(r+d\), and let \(E_a=Y_aX_a\) on this defect space. A full stage has \(X_aY_a=I_r\), so \(E_a\) is a rank-\(r\) idempotent. An odd idle has \(X_aY_a=0\), so \(E_a\) is square-zero of rank at most one. For distinct events \(a,b\),

\[
V_aU_b=2\operatorname{sgn}(b-a)X_aY_b.
\]

The chronological product of \(I-2E_a\) must equal \(-I\) on the defect space. To see this, for \(Cz=0\) write \(h=\sum_aY_az_a\), \(T_a=h-2\sum_{b<a}Y_bz_b\). The row equations give \(z_a=X_aT_a\), then \(T_{a+1}=(I-2E_a)T_a\) and \(T_{\rm end}=-h\). This is a bijection between \(\ker C\) and the \(-1\) eigenspace of the defect product. As \(U,V\) each have rank \(n\), \(C\) has rank \(n\) and nullity \(r+d\). Conversely the defect product identity and exact normalization give this rank, and the rank of \(K\) forces the relative endpoint on the resulting \(n\)-dimensional role space to be \(-I_n\). This converse is a scalar factorization construction. It does not construct the positive independent body endpoint or its physical tape.

For \(d=0\) all the full factors are \(-I_r\) on the defect space. The ordered product of the extra reflection factors must therefore be the identity. One odd idle can have \(E=0\), meaning no displacement on the defect space. A single nonzero nilpotent factor is inconsistent with full endpoint. Opposite nilpotent contributions on two separate clocks realize a nontrivial admissible scalar defect excursion, including controls where the opposite sectors require different axis spans.

## Rank required on each label in both sectors

Use one even, interior full clock \(i\), counting full hosts from 0 to 16. Put \(R_i=\prod_{a<i}W_a\) in chronological operator order, and \(A_i=R_i^{-1}U_i\), \(B_i=V_iR_i\). For the inverse prefix expand \(A_i=U_i+\sum_{a<i}U_a m_a\). Set \(e_a=-1\) for full hosts, \(+1\) for the odd-idle reflections. Recursing backwards gives

\[
m_a=2e_a X_aT_{a+1}Y_i,\qquad T_a=(I+2e_aE_a)T_{a+1},\qquad T_i=I.
\]

All factors are invertible. For \(P=T_0\), the sum \(\sum_{a<i}Y_am_a=(P-I)Y_i\). At any earlier full stage \(j\), division of \(V_j A_i\) by \(+2\) gives \(-X_jPY_i\). At any later full stage \(k\), division of \(V_k A_i\) by \(-2\) gives \(X_kPY_i\). In the earlier case the omitted self term and partial sum combine using \(X_jT_j=-X_jT_{j+1}\) because \(X_jE_j=X_j\). Thus their responses to \(U_i u+A_i v\) give

\[
X_j(Y_i u-PY_i v),\qquad X_k(Y_i u+PY_i v).
\]

Before applying those two \(X\) maps, this pair is injective on the \(2r\) arguments. Each \(X\) map has a kernel of dimension \(d\). Therefore \([U_i,A_i]\) has rank at least \(2r-2d\). For the row stack use transpose and reverse all events of the complete relative product. In that description an original suffix is a prefix, and at the current event its transformed columns are \(-B_i^\mathsf{T}\) because the complete product is \(-I\) and \(V_iW_i^{-1}=V_i\). This gives the same row rank on \([V_i;B_i]\).

In the paired matrix of the two stacks, \(V_iU_i=B_iA_i=0\) and \(V_iA_i=-2X_i(P-I)Y_i\). A full defect factor differs from \(-I\) by rank \(d\), and an odd idle factor differs from \(I\) by rank at most one. For an even full-clock prefix, standard product telescoping gives a rank bound \(id+c_{<i}\) for \(P-I\). The reversed complete product and \(W_iU_i=U_i\) allow a suffix bound of \((16-i)d+c_{>i}\) on the same relative pairing, up to an invertible scalar. Apply both the same way to \(B_iU_i\). Set \(b_i=\min(id+c_{<i},(16-i)d+c_{>i})\). The stack pairing therefore has rank at most \(2b_i\). These are two-sided rank estimates, with no assumption about attainment of the extremal scalar schedules.

For one body variable at a time, after setting all other bodies to one in each sector, the first derivative is the sum of transported body projectors. The exact output is one diagonal coordinate projector for that label. Its rank equals the sum of projector ranks by the determinant's positive degree. It follows that all contributing rows and columns lie in that same endpoint support in each sector. This covers a compound odd idle as well, by separating its fixed sector reflection when applying the determinant and derivative to its body. The coordinate support at clock \(i\) must contain both stacks. It therefore has dimension at least \(4r-4d-2b_i\) by Sylvester's inequality. The native supplies \(2r\) incidences of that label, giving at least \(2r-4d-2b_i\) paid idle incidences. Negative estimates are replaced by zero.

There are seven even interior clocks. Pair clocks \(i,16-i\) on their shorter sides. Their odd-idle sets are disjoint, and the middle clock sees at most \(\lfloor c/2\rfloor\) on its shorter side. The summed bound for all paid idle incidences is therefore

\[
I\ge \max(0,2688-92d-2\lfloor7c/2\rfloor).
\]

At \(d=0\), using at most \(\lfloor c/2\rfloor\) at each clock instead gives \(I\ge\max(0,2688-14\lfloor c/2\rfloor)\). The inequality counts both even and odd grouped idle incidences. It does not tie a charged mark to more than one production credit.

## Complete fixed-native price

Match the native and paid idle columns to distinct target coordinate incidences separately for each label using a nonzero nominal determinant summand. A role with \(x\) native and \(y\) idle marks gets at most \(f(x,y)=H_{8(x+y)+1}-yH_{8(x+y)}/(x+y)\), with \(f(0,0)=1\). Each grouped idle of body size \(8a\) allocates a share from its fully paid \(H_{8a}\) to each matched body mark, and every matched target contains all \(a\) group labels. Every odd idle also pays its extra header increment. At \(a\le17\) that increment is at least \(H_{137}-H_{136}\), by concavity. There are no free odd idles. For \(\ell(x)=H_{17}+(x-2)(H_{25}-H_{17})\), verify the directed inequality \(f(x,y)\le\ell(x)-\lambda y\) for every integer \(x+y\le17\). At \(\kappa=.005\) the optimal \(\lambda\) lies between .0064742447160 and .0064742447161. All native and independent helper prices are counted. Type B receives its full optimistic contribution \(8(H_8+H_9+1)\) per native. Every additional \(d\) decreases this affine relaxed upper price by at least \(\ell(0)-92\lambda>.48527\) once \(d\ge2\), since the grouped debit rebate is at most \(92\lambda\) per unit. For \(d=0,2\) verify the concrete rows directly.

With 36 compound odd idles and \(d=0\), the complete affine upper endpoint is **−0.0884374543117** at \(.005\). With 37 the affine upper endpoint is +0.0216247058622. The exact residue certificate sharpens that row to **−0.0443757347870** by accounting for the indivisibility of the final body counts. The [full-mask rank restriction](recurrence/FULL-MASK-IDLE.md) further forces short, more expensive groups. The stronger constraint excludes all cases with **at most 41** compound odd idles for any admissible \(d\). The price cap at 41 and \(d=0\) is **−0.0178313066098**. At .0227 the previous arbitrary-length joint address cut applies to the same fixed native and broader signed alphabet. Thin odd shears, mixed Type A/B roles, independent recast label sets or a change in native tariff require separate proofs.

`signed_idle_defect.py` verifies this sequential algebra over three odd finite fields, including opposing odd-idle factors, excess defect and an off-clock rejected Gram construction. It also computes the complete directed invoice. `recurrence/verify_idle_residue.py` supplies the residue check. During this calculation we corrected the modular reducer in `round7/host_defect.py` to read the current eliminated row after each pivot. The corrected checker reproduced the entire original round-seven JSON byte for byte. The proofs and arithmetic here do not establish a new feasible supplier, rounded physical wrapper, or multiplication exponent.
