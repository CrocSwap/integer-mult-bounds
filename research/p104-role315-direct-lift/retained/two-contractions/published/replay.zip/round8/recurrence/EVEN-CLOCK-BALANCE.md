# Two-sector body-span penalty for global Type A mixing

A common center and a global scalar basis generally let the 96 Type A ports mix. In the exact-defect zero-thin-query subclass, this flexibility still leaves the 17-host #7546 price short at \(\kappa=.005\), even with arbitrary grouped positive body idles. The full margin upper endpoint is **−5.6821848890185**. The calculation pays all actual native moves, retains every independent helper return, and grants Type B its entire optimistic joint-cut contribution. [#7546 native](https://github.com/CrocSwap/integer-mult-bounds/pull/7546) · [Signed #7113 caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7113)

## Scope

Use \(L\) atomic full Type A blocks on one common normalized central \(q\). A full block contains \(r\) disjoint rank-one odd shears on \(2r\) active roles. All \(L\) bodies are distinct formal Laurent variables. Each host carries its own single positive body label. General grouped body idles may apply any nonempty mask of these labels, once each, on one role. The endpoint is an independent diagonal monomial on each root, with every root odd in \(q\) and with unit body incidences. Ordinary scalar maps are invertible on the same roots, independent of the bodies, and agree at \(q=i,-i\).

There are no extra odd pulses in the Type A subproblem. The root count is \(n=r(L-1)\), so the signed relative rank defect is exactly \(r\). Global Type A mixing requires that all original ports have actually been normalized to a common center and one common body per stage. This is granted as an operator model. Physical routing, ordinary phase work, precision, tape and compiler admission are additional costs or contracts.

Type B and all arbitrary helper input banks are separated from the Type A scalar root, even when the 96 A ports mix. The proof does not apply to mixed odd idles, extra-defect or extra-query Type A words, or bodies whose formal independence and positive unit incidences fail. The 17-stage #7113 tape has additional features and is not a claim of class membership.

## Even interior clocks require \(2r\) further body incidences

Number the full clocks \(0,\ldots,L-1\). In the nominal input basis at \(q=i\), let \(U_i,V_i\) factor the sign-relative shear contribution. A full relative gate is \(I+U_iV_i\), with \(V_iU_i=0\). The two signed sectors produce relative endpoint \(-I_n\). The sequential-complement rank proof cited in HOST-DEFECT gives a rank-\(r\) matrix \(K=XY\) whose diagonal block at each host is \(I_r\). In each atomic block, an invertible change of basis on its \(r\) pulse indices preserves \(U_iV_i\) and sends its factors \(X_i,Y_i\) to \(I_r\). This yields the normalized block Gram

\[
V_aU_b=2\operatorname{sgn}(b-a) I_r,\qquad V_aU_a=0.
\]

All ranks here are over the characteristic-zero coefficient field with the two signed phases represented. The determinant of the odd-size scalar sign matrix has a one-dimensional alternating kernel, as seen by subtracting consecutive row equations. The even-size sign matrix is invertible by the same recurrence. Since \(U,V\) have rank \(n\), the Gram rank forces \(L\) odd and the full kernel relation to be exactly the scalar alternating relation tensored by the \(r\)-dimensional block parameter. Thus the column stack and row stack of every proper subset of full clocks has all its own \(r\)-wide blocks independent.

Let \(R_i=(I+U_{i-1}V_{i-1})\cdots(I+U_0V_0)\) be the relative prefix before clock \(i\). In the opposite-sector prefix, the transported native preserving vectors and covectors are
\[
A_i=R_i^{-1}U_i,\qquad B_i=V_iR_i .
\]
Both \(A_i\) and \(B_i\) retain independence within their own \(r\) rows or columns. Expand the inverse prefix on \(U_i\) from \(i-1\) down to zero. Write \(A_i=U_i+\sum_{a<i}U_a t_a\). The coefficients are all multiples of \(I_r\) and
\[
t_a=-2I_r-2\sum_{b>a,\ b<i}t_b=-2(-1)^{i-1-a}I_r .
\]
For \(B_i=V_i+\sum_{a<i}s_aV_a\), multiplication on the right goes through the same reverse clock order. The recurrence is \(s_a=-2I_r-2\sum_{b>a,\ b<i}s_b\), giving the same coefficients. For a nonempty proper interior prefix, these expansions have a nonzero term on a clock earlier than \(i\). The proper-subset independence above proves
\[
\operatorname{rank}[U_i\ A_i]=\operatorname{rank}\begin{bmatrix}V_i\\B_i\end{bmatrix}=2r
\quad (0<i<L-1).
\]
If \(i\) is even, each sum of coefficients is zero. The four pairings vanish:
\(V_iU_i=0\), \(V_iA_i=-2\sum_{a<i}t_a=0\), \(B_iU_i=2\sum_{a<i}s_a=0\), and \(B_iA_i=V_iU_i=0\).

For one label \(D_i\), specialize all other bodies to one in each signed sector. Divide out that sector's complete nominal endpoint on the left. The determinant degree of the remaining polynomial equals \(2r+I_i\), where \(I_i\) counts grouped idle incidences involving that label. Its exact output is \(I+(D_i-1)F_i\) for the same coordinate projector \(F_i\) in both sectors. The coefficient at \(D_i-1\) is the sum of transported role projectors. Their aggregate ranks equal \(\operatorname{rank}F_i\) by determinant degree. Thus their combined column span and row span are *exactly* the corresponding coordinate spaces of \(F_i\). The projectors are transported through invertible body-one scalar prefixes. This argument does not require monotone chronological realization of the scalar projectors or equality of the two sectors' individual transported moves.

In particular the preserving columns \(U_i,A_i\) and rows \(V_i,B_i\) all lie on the coordinates of \(F_i\). At an even interior clock, a \(2r\)-dimensional row space annihilates a \(2r\)-dimensional column space there. It follows that \(\operatorname{rank}F_i\ge4r\), and hence **\(I_i\ge2r\)**. Odd interior clocks are different: the off-diagonal pairings are nonzero multiples of \(I_r\), so the same four-block zero argument fails there. For odd \(L\), summing over even interior clocks gives
\[
I=\sum_i I_i\ \ge r(L-3).
\]
For \(r=192,L=17\), seven interior clocks force **2,688** additional positive body incidences.

## Grouped-idle tariff

Set \(H_j=j^{1-\kappa}\). Use nominal-sector incidence matching from HOST-BALANCE. Its full-rank basis on each label allocates the \(2rL\) native marks and all \(I\) idle marks bijectively to final target coordinates. A grouped idle of width \(8a\) pays \(H_{8a}/a\) per mark. A role that receives one of those marks carries all \(a\) labels of that idle, because the idle's transported column is supported in all the corresponding final coordinate masks.

For a target with \(x\) allocated native marks and \(y\) allocated idle marks, \(k=x+y\le L\), grant the remaining complete credit
\[
f(x,y)=H_{8k+1}-\frac{y}{k}H_{8k},\qquad f(0,0)=1.
\]
This includes the header. Every allocated idle mark lands on a role with \(k\ge a\). Its charge then covers at least \(H_{8k}/k\), by decreasing \(H_j/j\). No physical schedule is assumed to attain this bound.

The affine line \(\ell(x)=H_{17}+(x-2)(H_{25}-H_{17})\) dominates the all-odd target tariff \(H_{8x+1}\) on nonnegative integers. This follows from concavity and equality at two adjacent integers \(x=2,3\). The exact finite dual takes
\[
\lambda=\min_{\substack{x\ge0,\ y\ge1\\x+y\le L}}
\frac{\ell(x)-f(x,y)}{y}.
\]
Every role costs a debit at least \(\lambda y\) below \(\ell(x)\). Sum the affine line on \(n\) roots, retaining all \(2rL\) allocated native marks, and subtract \(\lambda r(L-3)\). For \(L=17\), the directed replay proves \(\lambda\) is attained at \((0,17)\). It lies in \([.0064742447160,.0064742447161]\) at \(\kappa=.005\). The per-mark bound is independent of how many labels or roots each paid idle grouping covers.

For only single-label idles the exact body-count total is \(2rL+I\), each added mark costs \(H_8\), and an extra mark increases the balanced target envelope by at most \(H_8\). Here the strongest favorable estimate balances \(2rL+r(L-3)\) marks evenly and pays \(r(L-3)H_8\).

## Complete source-bound price

Retain all \(L\) native bills \(P_0\) and arbitrary independent helper credits \(T_0\). For the eight Type B ports grant \(8(H_8+H_9+1)\) per native, the optimistic joint-cut maximum after their own auxiliary work. For global Type A \(r=192\). The initial total at \(L=17\) uses 3,072 A roots and 6,528 native marks. Its relaxed root profile is 2,688 rank-17 and 384 rank-25 fields before the mandatory-mark penalty. Thus the displayed total is the complete native-and-helper invoice plus a favorable Type A and Type B remainder.

| \(L=17\), exact defect 192, zero thin queries | κ=.005 upper endpoint | κ=.0227 upper endpoint |
| --- | ---: | ---: |
| Grant grouped idles without the even-clock constraint | +11.7205849078470 | −4879.6062232959227 |
| Charge the mandatory grouped idle incidences | **−5.6821848890185** | **−4954.2822915103121** |
| Allow only individually charged single-label idles | −195.9724796824573 | −5776.8545822678720 |

At .005 the verified grouped upper bound is negative at every odd \(L=5,7,\ldots,17\), and allows possibilities again at \(L=19\). The verified single-label bound is negative at every tested odd \(L=5,\ldots,49\). At .0227 every displayed finite row is negative. Earlier broader signed joint-cut bounds provide the separate arbitrary-length high-saving rejection. None of these cost estimates is an achieved supplier. The material opening is a schedule that falls outside exact-defect, zero-extra-odd positive grouped transport.

## Replay

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round8\recurrence\verify_even_clock_balance.py $complexPack --expect .\work\round8\recurrence\even-clock-balance.json
~~~

The checker independently builds the exact rational sign Gram and opposite-sector transforms at seven small widths/counts, tests the odd-clock and reversed-final-pulse controls, rebuilds the complete pinned source invoice, and verifies the directed affine tariff inequalities at all bounded profiles. It imports round5/recurrence/verify_joint_body_header.py and its existing source and arithmetic closure. The complex pack is the same fixed three-file input required by that earlier replay. Test processes had 15-second limits and both exited in 0.24 seconds. Normal and optimized receipts were byte-identical with SHA-256 `74513074d134b1ed7bb436b59679581138e876ae3cff804cd57df2154ac64e32`. AST parsing and tabnanny passed.
