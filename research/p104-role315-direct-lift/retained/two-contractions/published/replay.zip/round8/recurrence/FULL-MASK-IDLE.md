# A full-mask idle must avoid every native source column

At \(\kappa=.005\), the globally mixed 17-host common-center Type A price remains negative with up to **41 compound odd idles**, even when arbitrary positive grouped body-only idles and any nonnegative extra defect compatible with that operator are allowed. At 41 reflected calls and zero extra defect the complete upper endpoint is **−0.0178313066098**. The former numerical opening at 38 reflected calls is therefore excluded under these contracts. The bound starts to permit possibilities at 42 calls. No corresponding caller is supplied.

The estimate includes the entire pinned #7546 paid and independent helper inventory and again grants Type B its full optimistic joint-cut capacity. All Type A ports mix only after normalizing to one common center and one common stage body. Type A and Type B remain independent. Use the positive unit-incidence, square sector-even, independent body and rank-one odd-idle assumptions of IDLE-RESIDUE. There are no additional thin odd shears. The actual #7113 caller has its own distinct structure and invoice. [Open #7546 native](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

## Orthogonality from full positive rank

Consider a single body label in the nominal sector. The earlier determinant and derivative argument gives
\[
F=\sum_{b=1}^{s}P_b,\qquad \operatorname{rank}F=\sum_{b=1}^{s}\operatorname{rank}P_b,
\]
where \(F\) is the final coordinate projector of that label and each \(P_b\) is an actual transported body projector. This remains true when a body idle has an odd phase, since it multiplies its own role by a unit in each sector and the permanent scalar controls are absorbed before taking the body derivative.

Choose \(P_b=U_bV_b\) with independent columns and rows and \(V_bU_b=I_{\operatorname{rank}P_b}\). If \(U=[U_1\ \cdots\ U_s]\) and \(V\) stacks the \(V_b\), then \(UV=F\). The rank identity makes \(U\) injective and \(V\) surjective. Since \(F^2=F\), \(U(VU-I)V=0\), hence \(VU=I\). All cross compositions vanish: \(V_bU_a=0\) for \(b\ne a\). This is the missing pairwise annihilation. It applies also to oblique projectors. No orthogonality of the underlying physical charts is assumed.

Let \(t\) count actual one-role idle calls whose body masks contain **all 17** independent labels. Their nominal transported covectors annihilate every native body image: at each stage the named idle and that stage's native are distinct terms in the above decomposition. A native's full active-body image contains its own \(r=192\) relative odd columns. The \(t\) idle covectors also are independent, as can be seen in the rank-saturated row stack for any one stage. The relative endpoint equation \(-I_n\) gives total column span rank \(n\) when all native odd events and \(c\) single-rail odd reflections are included. Removing the \(c\) rank-one columns leaves native-only rank at least \(n-c\), irrespective of the surplus in the complement rank. The common annihilator can therefore contain at most \(c\) independent covectors:
\[
t\le n-\operatorname{rank}U_{\rm native}\le c .
\]
This counts actual idle calls, including an odd idle with a full mask, and uses the full-rank body identity in just one signed sector. It gives no advantage from uncharged body storage.

## Complete price

Let \(M\) be the compulsory idle incidence bound of IDLE-RESIDUE. At most \(17c\) idle marks can be supplied by the all-17 masks. At least \(\max(0,M-17c)\) are supplied by masks of size at most 16.

On one output role, let \(x,y\) be its allocated native and idle marks, \(\tau\) among the latter supplied by full-mask idles, and \(k=x+y\le17\). The nominal matching follows from the same rank-saturated columns. With \(H_j=j^{1-\kappa}\), its grouped net credit is bounded above by
\[
f(x,y,\tau)=H_{8k+1}-\tau H_{136}/17
 -(y-\tau)\frac{H_{8\min(k,16)}}{\min(k,16)} .
\]
Here \(\tau>0\) requires \(k=17\). The charge uses the full body's tariff per mark. Monotonic decrease of \(H_{8a}/a\) with \(a\) justifies the group-size cutoff \(\min(k,16)\). Supply the zero-body credit separately when \(k=0\). Recover the residual odd part of every \(c\)th rank-one odd idle by charging at least \(H_{137}-H_{136}\). No idle body charge is used twice.

Use the already proved affine line \(\ell(x)=H_{17}+(x-2)(H_{25}-H_{17})\) with slope in the native mark count and the coefficient \(\lambda\) for *every* idle mark. The exact checker computes a new coefficient
\[
\mu=\min_{\substack{0\le x,y,\tau\le17\\x+y\le17,\ y>\tau\\
                   \tau=0\ \text{if }x+y<17}}
\frac{\ell(x)-f(x,y,\tau)-\lambda y}{y-\tau}.
\]
It verifies every finite profile and isolates the minimum at \((x,y,\tau)=(0,16,0)\) at the tested savings. Where \(y=\tau\) the preceding affine coefficient alone applies. This gives a lower debit \(\mu\max(0,M-17c)\) in addition to the earlier \(\lambda M\). At .005, \(\mu\in[.0003863141468,.0003863141469]\). The retained #7546 helper and paid inventory and full Type B envelope have the same prices as the earlier computation.

| Reflection calls \(c\), extra defect \(d\) | Compulsory marks \(M\) | Short-mask marks at least | Complete margin cap at .005 |
| --- | ---: | ---: | ---: |
| \(c=37,d=0\) | 2,436 | 1,807 | −0.6764449574502 |
| \(c=38,d=0\) | 2,422 | 1,776 | −0.4637676326997 |
| \(c=41,d=0\) | 2,408 | 1,711 | **−0.0178313066098** |
| \(c=42,d=0\) | 2,394 | 1,680 | +0.1948460181407 |
| \(c=41,d=2\) | 2,218 | 1,521 | −0.8761283735013 |

At positive extra defect \(d\), increasing \(d\) by one decreases the affine target allowance by \(\ell(0)\). The mandatory mark formula can drop by no more than 92, and the short-mark lower bound can drop by no more than the same amount. At .005 the certified difference \(\ell(0)-92(\lambda+\mu)\) is positive. The \(d=2\) cases therefore dominate all admissible \(d\ge2\), since the signed determinant requires \(d\) even. The finite recomputation checks all \(c\le41\) at \(d=0,2\) and separately records \(d=4\) along with larger \(c\). The stronger all-signed joint-cut estimate already excludes this native at .0227.

## Replay

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round8\recurrence\verify_full_mask_idle.py $complexPack --expect .\work\round8\recurrence\full-mask-idle.json
~~~

Keep adjacent verify_idle_residue.py and verify_even_clock_balance.py, their same older pinned native reader closure, and the same three source inputs. The finite arithmetic checks 289 full tariff profiles at each requested saving and an explicit oblique two-projector decomposition, with a repeated oblique projector as an unsaturated negative control. The universal rank argument is the proof above. Both test processes exited within 0.16 seconds under 14-second caps. Normal and optimized output were byte-identical, SHA-256 `6ce1089c2346389fa108da37e8f4e35dee96f6a48f8e3cb5735118bab7028568`. AST parsing and tabnanny passed.
