"""Exact two-sector body-span controls and the complete grouped Type A price."""

import argparse
from collections import Counter
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SOURCE = HERE.parents[1] / "round5" / "recurrence" / "verify_joint_body_header.py"
SPEC = spec_from_file_location("joint_body_header", SOURCE)
JOINT = module_from_spec(SPEC)
SPEC.loader.exec_module(JOINT)
CORE = JOINT.CORE
need = CORE.need


def identity(n):
    return [[int(i == j) for j in range(n)] for i in range(n)]


def transpose(a):
    return [list(row) for row in zip(*a)]


def mul(a, b):
    cols = transpose(b)
    return [[sum(x*y for x,y in zip(row,col,strict=True)) for col in cols] for row in a]


def plus(a,b,sign=1):
    return [[x+sign*y for x,y in zip(row,brow,strict=True)] for row,brow in zip(a,b,strict=True)]


def rank(a):
    pivots = {}
    for original in a:
        row = list(map(Fraction,original))
        while any(row):
            h = next(i for i,x in enumerate(row) if x)
            if h not in pivots:
                pivots[h] = [x/row[h] for x in row]
                break
            val = row[h]
            row = [x-val*y for x,y in zip(row,pivots[h],strict=True)]
    return len(pivots)


def clock_factors(stages,r):
    small = stages-1
    n = small*r
    cols = identity(n)
    rows = []
    for a in range(stages):
        for c in range(r):
            rows.append([2*(int(j//r>a)-int(j//r<a)) if j%r==c else 0 for j in range(n)])
    for c in range(r):
        cols.append([(-1)**(small-1-j//r) if j%r==c else 0 for j in range(n)])
    u = [transpose(cols[r*i:r*(i+1)]) for i in range(stages)]
    v = [rows[r*i:r*(i+1)] for i in range(stages)]
    return u,v


def clock_fixture(stages,r):
    u,v = clock_factors(stages,r)
    n = (stages-1)*r
    unit = identity(n)
    prefix, inverse = unit,unit
    zero = [[0]*r for _ in range(r)]
    gram_cells = 0
    interior_odd = interior_even = negative_controls = 0
    for i in range(stages):
        for j in range(stages):
            expect = 2*(int(j>i)-int(j<i))
            need(mul(v[i],u[j])==[[expect*x for x in row] for row in identity(r)],"Normalized Gram changed")
            gram_cells += r*r
        a = mul(inverse,u[i])
        b = mul(v[i],prefix)
        need(mul(b,a)==zero and mul(v[i],u[i])==zero,"Sector port nilpotent changed")
        if 0<i<stages-1:
            columns = [x+y for x,y in zip(u[i],a,strict=True)]
            rows = v[i]+b
            joint = mul(rows,columns)
            need(rank(columns)==rank(rows)==2*r,"Stacked sector spans do not have full rank")
            if i%2==0:
                need(rank(joint)==0,"Exterior even prefix must annihilate both sectors")
                need(rank(columns)+rank(rows)-rank(joint)==4*r,"Even clock span debit changed")
                # Restricting to a space of dimension 4r-1 cannot preserve
                # the independent preserving rows and columns simultaneously.
                need(4*r-1 < rank(columns)+rank(rows)-rank(joint),"Unsupported compact even target accepted")
                interior_even += 1
            else:
                need(rank(joint)==2*r,"Odd prefix should differ from even clock")
                interior_odd += 1
        delta = mul(u[i],v[i])
        prefix = mul(plus(unit,delta),prefix)
        inverse = mul(inverse,plus(unit,delta,-1))
        need(mul(inverse,prefix)==unit,"Prefix inverse mistimed")
        if i==stages-1:
            mutated = mul(plus(unit,delta,-1),mul(plus(unit,delta,-1),prefix))
            need(mutated!=prefix,"Last-pulse orientation mutation did not change endpoint")
            negative_controls += 1
    need(prefix==[[-x for x in row] for row in unit],"Saturated all-odd two-sector endpoint changed")
    return {"stages":stages,"block_width":r,"roles":n,"explicit_gram_cells":gram_cells,
            "even_middle_clocks":interior_even,"odd_middle_clocks":interior_odd,
            "orientation_mutations_rejected":negative_controls}


def price(rank_value, point):
    return CORE.price(rank_value,*point)


def minus(a, b):
    return CORE.add(a,CORE.scaled(b,-1))


def supporting_line(stages, point):
    h = lambda r: price(r,point)
    start = minus(CORE.scaled(h(17),3),CORE.scaled(h(25),2))
    step = minus(h(25),h(17))
    best = None
    witness = None
    tests = 0
    positives = []
    for x in range(stages+1):
        line_at_x = CORE.add(start,CORE.scaled(step,x))
        for y in range(stages-x+1):
            k = x+y
            if y:
                role = minus(h(8*k+1),CORE.scaled(h(8*k),y,k))
                local = CORE.scaled(minus(line_at_x,role),1,y)
                need(local[0]>0,"Potential negative group-idle price")
                positives.append((local,x,y))
                if best is None or local[0]<best[0]:
                    best,witness = local,(x,y)
            elif x not in (2,3):
                need(minus(line_at_x,h(8*x+1))[0]>=0,"Supporting tangent not outward")
            tests += 1
    need(all((x,y)==witness or local[0]>best[1] for local,x,y in positives),
         "Directed lower values do not separate the minimum penalty")
    return best,witness,tests


def price_case(stages,r,mult,point,paid,helpers):
    roots = r*(stages-1)
    mandatory = r*(stages-3)
    native_marks = 2*r*stages
    lo,hi = divmod(native_marks,roots)
    need(lo in (2,3),"Tested profiles must be supported by the chosen affine line")
    h = lambda rank_value: price(rank_value,point)
    full = Counter({j:v*stages for j,v in helpers.items()})
    full.subtract({j:v*stages for j,v in paid.items()})
    full.update({1:8*stages,8:8*stages,9:8*stages})
    full.update({8*lo+1:(roots-hi)*mult,8*(lo+1)+1:hi*mult})
    ungated = CORE.moment(full,*point)
    charge,witness,tests = supporting_line(stages,point)
    total = minus(ungated,CORE.scaled(charge,mandatory*mult))
    singles = full.copy()
    singles.subtract({8*lo+1:(roots-hi)*mult,8*(lo+1)+1:hi*mult})
    a,b = divmod(native_marks+mandatory,roots)
    singles.update({8*a+1:(roots-b)*mult,8*(a+1)+1:b*mult})
    singles[8] -= mandatory*mult
    one_label = CORE.moment(singles,*point)
    return {"block_width":r,"roots":roots,"clock_count":stages,"copies":mult,
            "even_interior_clock_count":(stages-3)//2,
            "minimum_grouped_idle_incidences":mandatory,"finite_inequalities":tests,
            "directed_penalty_per_idle_mark":CORE.format_bounds(charge),"minimum_at_role_profile":witness,
            "ungated_grouped_upper":CORE.format_bounds(ungated),
            "all_grouped_body_only_upper":CORE.format_bounds(total),
            "single_label_idles_upper":CORE.format_bounds(one_label)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    parser.add_argument("--expect",type=Path)
    args = parser.parse_args()
    paid,helpers=JOINT.read_complex(args.complex_pack)
    repeats={}
    for saving,point in ((".005",(5,1000)),(".0227",(227,10000))):
        repeats[saving]={}
        for stages in range(5,50,2):
            repeats[saving][str(stages)]=price_case(stages,192,1,point,paid,helpers)
    need(Fraction(repeats[".005"]["17"]["all_grouped_body_only_upper"][1]) < -5,
         "Material global 17-host price failed to reject")
    payload=json.dumps({"status":"PASS_EVEN_INTERIOR_CLOCK_GLOBAL_PRICE", "exact_clock_controls":[
        clock_fixture(stages,r) for stages,r in ((3,1),(5,1),(5,2),(7,1),(7,2),(9,1),(9,2))],
        "global_prices":repeats},indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Receipt changed")
    print(payload)


if __name__=="__main__":
    main()
