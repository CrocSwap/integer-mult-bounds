# Grouped body-idle tariff modulo 17

In the globally mixed, common-center 17-host Type A model with 37 compound odd idles, the relaxed margin at \(\kappa=.005\) is at most **−0.0443757347870** after including a discrete body-incidence penalty. Without this penalty its upper endpoint is +0.0216247058619. This includes all joint #7546 native charges and all actual independent helper credits, and grants Type B its full optimistic joint-cut contribution. [Open #7546 candidate](https://github.com/CrocSwap/integer-mult-bounds/pull/7546)

The model has one common center, 17 independent positive unit body labels of width eight, and 192 disjoint Type A shears in each atomic host. There are \(c\) additional rank-one odd reflections, each implemented by a paid one-role idle carrying a body mask and the common odd center on that same role. Ordinary maps are square and sector-even. Type A is separate from Type B, and every credited A root returns with an odd center. Allow arbitrary positive grouped body-only idles on one role at the actual tariff. This does not model a two-center identity, cross-type mixing, arbitrary signed ungrouped body powers, or a new native bill.

## Opposite-sector corank and compulsory marks

Let \(r=192\), \(n=(17-1)r+c-d\). Here \(d\) is the surplus of the signed relative rank defect above \(r\). The determinant of the relative return \(-I_n\) equals the determinant \((-1)^c\) of the \(c\) reflections, so \(d\) is even.

For an even interior full clock \(i\), counted from zero and ignoring reflection positions, the body mask contains the preserving rows and columns of the respective \(i\)th native in *both* sectors. This follows by specializing all other body labels to one in each sector. The normalized polynomial endpoint is \(I+(D_i-1)F_i\) for the same coordinate projector \(F_i\). Its determinant degree equals the sum of ranks of all transports carrying that label. The linear terms' column and row spans each equal the corresponding coordinate spaces of \(F_i\). This includes rank-one odd idles. In a single sector their odd scalar and body act on the same unchanged line, so the body part factors separately through the relative reflection. The rank count is over independent positive unit labels, even when the reflection's mask contains more than one.

For completeness, the extra-defect prefix bounds used by the pricing screen can be seen directly from the defect factorization. Index odd events \(a\), using width \(r\) for a full event and one for a reflection. If \(C=VU\) is the relative Gram and \(K=XY\) its sequential complement, then
\[
C_{ab}=2\operatorname{sgn}(b-a)X_aY_b\quad(a\ne b),\qquad
C_{aa}=2(X_aY_a-I).
\]
For a full block \(X_aY_a=I_r\), and for a reflection \(X_aY_a=0\). The ambient defect coordinate dimension is \(r+d\). Put \(E_a=Y_aX_a\). On inverse prefix application, the full event \(I+U_aV_a\) inverts by negating its nilpotent part, while a reflection inverts by repeating itself. Write \(e_a=-1\) or \(+1\) respectively. The expansion of \(R_i^{-1}U_i\) uses coefficients
\[
m_a=2e_aX_aT_{a+1}Y_i,\quad
T_a=(I+2e_aE_a)T_{a+1},\quad T_i=I.
\]
In a full block \(E_a^2=E_a\) has rank \(r\), so its defect factor differs from \(-I\) by rank \(d\). For a reflection \(E_a^2=0\) has rank at most one, so its defect factor differs from \(I\) by rank at most one. All these defect factors are invertible. At an even full clock \(i\), the prefix product \(P=T_0\) satisfies \(\operatorname{rank}(P-I)\le i d+c_{\rm left}\), by telescoping against the alternating full-block signs and the identity reflection factors. The paired self-block \(V_iR_i^{-1}U_i=-2X_i(P-I)Y_i\) obeys the same rank bound. The analogous row pairing bound follows by transposing and reversing the full relative word. Indeed in that word the prefix before the reflected clock equals the transpose of the original suffix, and the relative product identity and the preservation of \(U_i,V_i\) inside their own event identify its inverse-prefix columns with the transpose of the original opposite-sector rows. The counts of full clocks on both sides of an even clock are even.

For the prefix columns, take an earlier full \(j\) and a later full \(k\). Dividing the earlier response by \(+2\) and the later by \(-2\), their joint evaluation on \(U_i u+R_i^{-1}U_i v\) is exactly
\[
\bigl(X_j(Y_i u-PY_i v),\;X_k(Y_i u+PY_i v)\bigr).
\]
The recurrence gives this because \(\sum_{a<i}Y_am_a=(P-I)Y_i\); the earlier response reverses the terms before \(j\) and drops its own pairing. The cancelled terms telescope using \(X_jE_j=X_j\). Before the two \(X\) projections, this map is injective by \(X_iY_i=I_r\), invertible \(P\) and characteristic zero. Each projection drops at most \(d\) directions. Thus each opposite-sector row or column stack has rank at least \(2r-2d\). The crossed self-blocks give total pairing rank at most \(2(i d+c_{\rm left})\).

The suffix gives the same estimate with \((16-i)d+c_{\rm right}\). To see this explicitly, for relative suffix \(S_i\) use
\(S_i(I+U_iV_i)R_i=-I\)
and the fact that the full block fixes its own columns and rows. Then \(R_i^{-1}U_i=-S_iU_i\) and \(V_iR_i=-V_iS_i^{-1}\). Passing to the reversed inverse sequence keeps the signed off-diagonal Gram law, after negating the full inverse transvection's column and leaving the reflection column unchanged in the resulting expansion. For the rank estimates, the product of reciprocal defect factors has the same telescope about its alternating scalar sign. The left and right rank bounds therefore coexist.

Sylvester's inequality on \(F_i\) now gives a lower bound of \(2r-4d-2\min(i d+c_{\rm left},(16-i)d+c_{\rm right})\) further incidences on an even interior clock. For \(d=0\) one may use \(\min(c_{\rm left},c_{\rm right})\le\lfloor c/2\rfloor\) at each of seven clocks. For \(d>0\), pair the earlier side at \(i=2,4,6\) with the later side at \(16-i\); their reflection sets are disjoint. The middle clock uses the smaller of its two sides. This sums to the compulsory mark count
\[
M=\begin{cases}
\max(0,2688-14\lfloor c/2\rfloor),&d=0,\\
\max(0,2688-92d-2\lfloor7c/2\rfloor),&d>0.
\end{cases}
\]
The full even-clock count and these rank estimates are necessary conditions in the formal model. They do not guarantee a change of physical caller.

## Directed tariff on the residue graph

For each target role let \(x,y\) be its allocated native and idle body marks and write \(k=x+y\le17\). The complete target credit after paying the allocated group body fees is bounded by
\[
f(x,y)=H_{8k+1}-(y/k)H_{8k},\qquad f(0,0)=1 .
\]
The rank-one odd part of an odd idle is charged separately at least \(H_{137}-H_{136}\), the smallest possible such increment. The role formula uses only the body part of each idle's tariff. It makes no charge-free use of an address-dependent ordinary operator. The affine line \(\ell(x)=H_{17}+(x-2)(H_{25}-H_{17})\) dominates \(f(x,0)\) on nonnegative integer \(x\).

Verify
\[
g(x,y)=\ell(x)-f(x,y)-\lambda y\ge0,\qquad
\lambda=\frac{\ell(0)-(H_{137}-H_{136})}{17}.
\]
The equality cases are \((2,0),(3,0),(0,17)\). In particular a role carrying all 17 marks and no native mark has residue zero modulo 17. Every role with \(1\le y\le16\) pays a strictly positive residual \(g(x,y)\). For each \(y\bmod17\), use the smallest directed *lower endpoint* of \(g\) among its eligible profiles as an edge cost. Use zero for residue zero. A cyclic path of such edges adds idle marks modulo 17 and adds the corresponding lower bounds. Therefore a collection of roles with total idle marks \(I\) has residual debit at least the shortest directed path cost from zero to \(I\bmod17\). This shortest path uses at most 16 edges after removing nonnegative cycles. The replay certifies its endpoint feasibility and all edge inequalities.

The actual \(I\) can exceed its compulsory value \(M\). Write \(I=M+u+17v\) with \(0\le u\le16\) and \(v\ge0\). Discarding the nonnegative \(17v\lambda\) gives a valid favorable additional debit
\[
\min_{0\le u\le16}\{\lambda u+\operatorname{dist}(0,(M+u)\bmod17)\}.
\]
For \(c=37,d=0\), \(M=2436\equiv5\pmod {17}\). The exact additional debit exceeds 0.0660004406489. Its favorable choice is \(u=0\). Thus the source-bound final margin is at most −0.0443757347870. At \(c=38,d=0\) the improved envelope is still positive, +0.1677039508656, up to the reported rounding interval. This is a remaining numerical opening, with no matching operator supplied. At \(d=2\) the checked range through \(c=43\) is strictly negative after residue. At .005 the earlier affine bound decreases with \(d\) at least \(\ell(0)-92\lambda>0.485\) within positive root dimension, so \(d\ge2\) cannot recover the excluded \(c\le37\) cases. At .0227 the independent joint-cut bound covers the underlying unchanged native tariff without this finite residue calculation.

## Replay

~~~powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$complexPack = 'C:\Users\cuchu\Documents\Codex\2026-11-14\integer-mult-local-recovery\work'
& $py -I -O -B -S -W error .\work\round8\recurrence\verify_idle_residue.py $complexPack --expect .\work\round8\recurrence\idle-residue.json
~~~

The verifier imports adjacent verify_even_clock_balance.py and its previously pinned native reader, along with the source-bound outward integer-grid tariff engine. The complex pack is the same three-file input as for EVEN-CLOCK-BALANCE. The computation uses exactly 17 residues and checks \(c=0,\ldots,43\), \(d=0,2,4\), at both requested savings. Normal and optimized runs each used less than 0.17 seconds under 14-second caps and agreed byte-for-byte with SHA-256 `1daa9b935e5ccf6642d637dfb08e288ad311c88dbc1d31761cd91b51bb49f8a2`. AST parsing and tabnanny passed.
