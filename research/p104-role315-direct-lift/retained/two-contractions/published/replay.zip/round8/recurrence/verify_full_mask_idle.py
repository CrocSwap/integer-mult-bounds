"""Exact grouped-idle cost with a simultaneous bound on all-stage idle roles."""

import argparse
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("idle_residue", HERE / "verify_idle_residue.py")
RESIDUE = module_from_spec(SPEC)
SPEC.loader.exec_module(RESIDUE)
CLOCK, CORE = RESIDUE.CLOCK, RESIDUE.CORE
need = CORE.need
STAGES, WIDTH, MARKS = RESIDUE.STAGES, RESIDUE.WIDTH, RESIDUE.MARKS


def short_group_dual(point):
    def h(r):
        return CORE.price(r,*point)

    l0,l1,head,lam,_,_,_ = RESIDUE.exact_edges(point)
    bounds = []
    for x in range(STAGES+1):
        line = CORE.add(l0,CORE.scaled(l1,x))
        for y in range(1,STAGES-x+1):
            k=x+y
            largest_short = min(k,STAGES-1)
            for t in range(y if k==STAGES else 1):
                role = CLOCK.minus(h(8*k+1),CORE.scaled(h(8*largest_short),y-t,largest_short))
                role = CLOCK.minus(role,CORE.scaled(h(8*STAGES),t,STAGES))
                residual = CLOCK.minus(CLOCK.minus(line,role),CORE.scaled(lam,y))
                charge = CORE.scaled(residual,1,y-t)
                need(charge[0]>0,"A short grouped idle has an inconclusive penalty")
                bounds.append((charge,x,y,t))
    minimum,x,y,t = min(bounds)
    need(all((u,v,w)==(x,y,t) or value[0]>minimum[1] for value,u,v,w in bounds),
         "Directed arithmetic does not isolate the short-mask minimizer")
    return l0,l1,head,lam,minimum,(x,y,t),len(bounds)


def pure_partition_control():
    # Two target coordinates, both carrying the same label. This oblique
    # pair retains the whole coordinate plane and annihilates cross rows.
    p = [[1,2],[0,0]]
    idle = [[0,-2],[0,1]]
    zero = [[0,0],[0,0]]
    need(CLOCK.mul(p,p)==p and CLOCK.mul(idle,idle)==idle,"Oblique exact projector fixture")
    need(CLOCK.plus(p,idle)==CLOCK.identity(2),"Projectors failed to span exact target")
    need(CLOCK.mul(p,idle)==CLOCK.mul(idle,p)==zero,"Positive equality must force annihilation")
    native_basis = [[1],[0]]
    idle_covector = [[0,1]]
    need(CLOCK.mul(idle_covector,native_basis)==[[0]],"Idle covector leaked native image")
    # Without rank sum saturation two equal idempotents are not mutually
    # orthogonal even if their span lies inside a valid target space.
    need(CLOCK.mul(p,p)!=zero,"Unsaturated negative control degenerated")
    return {"oblique_coordinate_completion":True,"unsaturated_overlap_rejected":True}


def prices(paid,helper,point):
    l0,l1,head,lam,mu,witness,count = short_group_dual(point)
    common = RESIDUE.source_side(paid,helper,point)
    monotone = CLOCK.minus(l0,CORE.scaled(CORE.add(lam,mu),92))
    scopes={}
    for c in range(65):
        for d in (0,2,4):
            roots = WIDTH*(STAGES-1)+c-d
            usages = max(0,2688-(14*(c//2) if not d else 92*d+2*(7*c//2)))
            shorts = max(0,usages-STAGES*c)
            upper = CORE.add(common,CORE.add(CORE.scaled(l0,roots),CORE.scaled(l1,MARKS)))
            bill = CORE.add(CORE.scaled(head,c),CORE.add(CORE.scaled(lam,usages),CORE.scaled(mu,shorts)))
            scopes[f"c{c}_d{d}"]={"roots":roots,"required_idle_marks":usages,
                                "max_full_mask_idles":c,"required_short_mask_idle_marks":shorts,
                                "margin":CORE.format_bounds(CLOCK.minus(upper,bill))}
    return {"penalty_per_short_mask_mark":CORE.format_bounds(mu),"minimizing_profile":witness,
            "exact_short_group_inequalities":count,"scopes":scopes,
            "decrease_per_positive_extra_defect":CORE.format_bounds(monotone)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    parser.add_argument("--expect",type=Path)
    args=parser.parse_args()
    paid,helper=CLOCK.JOINT.read_complex(args.complex_pack)
    scopes={k:prices(paid,helper,pt) for k,pt in ((".005",(5,1000)),(".0227",(227,10000)))}
    main_price=scopes[".005"]
    first=next(c for c in range(65) if Fraction(main_price["scopes"][f"c{c}_d0"]["margin"][1])>=0)
    need(first==42 and Fraction(main_price["decrease_per_positive_extra_defect"][0])>0,
         "Material excluded range changed")
    need(all(Fraction(main_price["scopes"][f"c{c}_d2"]["margin"][1])<0 for c in range(first)),
         "Positive extra defect could recover the low reflection range")
    payload=json.dumps({"status":"PASS_FULL_MASK_IDLE_PROVIDER_CAP", "projection_control":pure_partition_control(),
                        "first_nonnegative_relaxation_for_d0_at_005":first,"prices":scopes},
                       indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Price receipt changed")
    print(payload)


if __name__=="__main__":
    main()
