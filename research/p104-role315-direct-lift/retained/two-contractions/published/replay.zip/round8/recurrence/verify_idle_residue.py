"""Directed residue strengthening of the source-bound global grouped-idle price."""

import argparse
from collections import Counter
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("even_clock", HERE / "verify_even_clock_balance.py")
CLOCK = module_from_spec(SPEC)
SPEC.loader.exec_module(CLOCK)
CORE = CLOCK.CORE
need = CORE.need
STAGES, WIDTH = 17, 192
MARKS = 2*STAGES*WIDTH


def exact_edges(point):
    def h(k):
        return CORE.price(k,*point)

    intercept = CLOCK.minus(CORE.scaled(h(17),3),CORE.scaled(h(25),2))
    slope = CLOCK.minus(h(25),h(17))
    head = CLOCK.minus(h(137),h(136))
    lam_expression = CORE.scaled(CLOCK.minus(intercept,head),1,17)
    lam, where, n_checks = CLOCK.supporting_line(STAGES,point)
    need(where==(0,17) and lam[0]<=lam_expression[1] and lam_expression[0]<=lam[1],
         "Minimum affine penalty needs the full-mask equality")
    edges = [None]*STAGES
    edges[0] = 0
    counter = 0
    for x in range(STAGES+1):
        line = CORE.add(intercept,CORE.scaled(slope,x))
        for y in range(1,STAGES-x+1):
            k = x+y
            f = CLOCK.minus(h(8*k+1),CORE.scaled(h(8*k),y,k))
            cost = CLOCK.minus(CLOCK.minus(line,f),CORE.scaled(lam_expression,y))
            if (x,y)==(0,17):
                # Exact symbolic equality, independent of grid rounding.
                need(cost[0]<=0<=cost[1],"Symbolic zero fell outside its enclosure")
                continue
            need(cost[0]>0,"A nonempty residue edge has unclear sign")
            j = y%STAGES
            if edges[j] is None or cost[0]<edges[j]:
                edges[j] = cost[0]
            counter += 1
    need(all(i is not None for i in edges),"Incomplete residue graph")
    return intercept,slope,head,lam_expression,edges,n_checks,counter


def shortest_residue_cost(edges):
    dist = [0]+[None]*(STAGES-1)
    for _ in range(STAGES-1):
        out = dist[:]
        for i, cost in enumerate(dist):
            if cost is None:
                continue
            for move,w in enumerate(edges):
                j = (i+move)%STAGES
                if out[j] is None or cost+w<out[j]:
                    out[j]=cost+w
        dist=out
    need(all(x is not None for x in dist),"Unreachable residue")
    need(all(dist[(a+b)%STAGES]<=x+w for a,x in enumerate(dist)
             for b,w in enumerate(edges)),"Unexpected shorter residue path")
    need(all(x>0 for x in dist[1:]),"Residue correction became inconclusive")
    return dist


def source_side(paid,helper,point):
    full=Counter({r:STAGES*v for r,v in helper.items()})
    full.subtract({r:STAGES*v for r,v in paid.items()})
    full.update({1:8*STAGES,8:8*STAGES,9:8*STAGES})
    return CORE.moment(full,*point)


def prices(paid,helper,point):
    intercept,slope,odd,lam,edges,n_checks,n_edges = exact_edges(point)
    correction = shortest_residue_cost(edges)
    common = source_side(paid,helper,point)
    coefficient = CLOCK.minus(intercept,CORE.scaled(lam,92))
    ans={}
    for c in range(44):
        for d in (0,2,4):
            n = WIDTH*(STAGES-1)+c-d
            matched = max(0,2688-(14*(c//2) if not d else 92*d+2*(7*c//2)))
            gross = CORE.add(common,CORE.add(CORE.scaled(intercept,n),CORE.scaled(slope,MARKS)))
            base = CLOCK.minus(CLOCK.minus(gross,CORE.scaled(odd,c)),CORE.scaled(lam,matched))
            cost,extra = min((lam[0]*u+correction[(matched+u)%STAGES],u) for u in range(STAGES))
            margin_upper = base[1]-cost
            r = f"c{c}_d{d}"
            ans[r] = {"roots":n,"minimum_idle_incidences":matched,"base_upper":CORE.format_bounds(base)[1],
                      "residue_at_minimum":matched%STAGES,"optimistic_extra_incidence_count":extra,
                      "residue_debit_lower":CORE.format_bounds((cost,cost))[0],
                      "whole_margin_upper":CORE.format_bounds((margin_upper,margin_upper))[1]}
    return {"bounds":ans,"tangent_decrease_per_extra_defect_lower":CORE.format_bounds(coefficient)[0],
            "lambda_interval":CORE.format_bounds(lam),"affine_checks":n_checks,
            "directed_nonzero_residue_edges":n_edges,
            "residue_path_debits_lower":[CORE.format_bounds((c,c))[0] for c in correction]}


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("complex_pack",type=Path)
    cli.add_argument("--expect",type=Path)
    args=cli.parse_args()
    paid,helper=CLOCK.JOINT.read_complex(args.complex_pack)
    profiles={k:prices(paid,helper,p) for k,p in ((".005",(5,1000)),(".0227",(227,10000)))}
    h=profiles[".005"]["bounds"]
    first = next(c for c in range(44) if Fraction(h[f"c{c}_d0"]["whole_margin_upper"])>=0)
    need(first==38 and all(Fraction(h[f"c{c}_d2"]["whole_margin_upper"])<0 for c in range(44)),
         "Grouped opening count or positive extra-defect exclusion changed")
    need(Fraction(profiles[".005"]["tangent_decrease_per_extra_defect_lower"])>0,
         "Asymptotic extra-defect monotonicity no longer follows")
    payload=json.dumps({"status":"PASS_DIRECTED_GROUPED_IDLE_RESIDUE",
                        "first_sampled_nonnegative_envelope_at_005_for_d0":first,
                        "prices":profiles},indent=2,sort_keys=True)
    if args.expect:
        need(payload==args.expect.read_text(encoding="utf-8").rstrip("\n"),"Receipt changed")
    print(payload)


if __name__=="__main__":
    main()
