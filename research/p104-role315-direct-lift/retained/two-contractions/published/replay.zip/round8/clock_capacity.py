# SPDX-License-Identifier: Apache-2.0
"""Check the cyclic missing-run law and price complete idle masks exactly."""

import argparse
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
from itertools import combinations, product
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = spec_from_file_location("portfolio_screen", HERE / "portfolio_screen.py")
SCREEN = module_from_spec(SPEC)
SPEC.loader.exec_module(SCREEN)
CLOCK, CORE, NEED = SCREEN.CLOCK, SCREEN.CORE, SCREEN.NEED
matmul, rank = CLOCK.mul, CLOCK.rank


def missing_runs(stages, mask, cut):
    runs = [[]]
    for i in ((cut+a)%stages for a in range(stages)):
        if mask>>i & 1:
            if runs[-1]:
                runs.append([])
        else:
            runs[-1].append(i)
    return [run for run in runs if run]


def pair(s,t,cut=0):
    order = [(cut+j)%len(s) for j in range(len(s))]
    prefix, value = 0, 0
    for i in order:
        value += s[i]*(t[i]+2*prefix)
        prefix += t[i]
    return value  # twice the alternating pairing


def difference(stages,i,j):
    return [int(k==i)-int(k==j) for k in range(stages)]


def selector(stages,i):
    return [int(k==i) for k in range(stages)]


def prefix_response(stages, u, v):
    I = CLOCK.identity(stages-1)
    relative, inverse = [I], [I]
    for x,y in zip(u,v,strict=True):
        cell = matmul(x,y)
        relative.append(matmul(CLOCK.plus(I,cell),relative[-1]))
        inverse.append(matmul(inverse[-1],CLOCK.plus(I,cell,-1)))
    NEED(matmul(relative[-1],inverse[-1])==I and relative[-1]==[[-v for v in row] for row in I],
         "fixture relative endpoint is -I")
    return relative,inverse


def geometry(stages):
    u,v = CLOCK.clock_factors(stages,1)
    R,B = prefix_response(stages,u,v)
    cuts = (0,1,stages//2,stages-1,stages)
    laws = local_pair_cells = viable = 0
    distribution = {}
    first_basis = [difference(stages,j,j+1) for j in range(stages-1)]
    native_pair = []
    for s in first_basis:
        f = [[(-1)**i*s[i] for i in range(stages-1)]]
        native_pair.append([])
        for t in first_basis:
            coeff = [Fraction(t[j],2)+sum(t[:j]) for j in range(stages)]
            w = [[(-1)**j*(coeff[j]-coeff[-1]) for j in range(stages-1)]]
            J = v[:stages-1]
            p = matmul(w,[r[0] for r in J])[0]
            NEED([(-1)**j*matmul([p],u[j])[0][0] for j in range(stages)]==t,
                 "recover symplectic-dual row from weighted coefficients")
            value = matmul(f,list(zip(*w)))[0][0]
            NEED(value*2==pair(s,t),"actual f(w) is weighted alternating pairing")
            NEED(all(2*value==pair(s,t,b) for b in cuts),"cyclic pairing is unchanged on zero sums")
            native_pair[-1].append(value)
    NEED(rank(native_pair)==stages-1,"canonical form nondegenerate")

    for cut in cuts:
        actual_rows = []
        for i in range(stages):
            z = matmul(R[cut],matmul(B[i],u[i]))
            actual_rows.append([(-1)**j*z[j][0] for j in range(stages-1)])
        for size in range(1,stages):
            for inside in combinations(range(stages),size):
                mask = sum(1<<j for j in inside)
                runs = missing_runs(stages,mask,cut)
                equations = [selector(stages,i) for i in inside]
                rows = [actual_rows[i] for i in inside]
                basis = [difference(stages,a,b) for run in runs for a,b in zip(run,run[1:])]
                NEED(all(sum(u*v for u,v in zip(row,s,strict=True))==0
                         for s in basis for row in equations),"omissions respect nominal support")
                NEED(all(sum(u*v for u,v in zip(s[:-1],row,strict=True))==0
                         for s in basis for row in rows),"omission basis meets the true opposite prefix")
                if stages < 10:
                    phys = [m[:-1] if not m[-1] else [-1]*(stages-1) for m in equations]+rows
                    NEED(rank(phys)+len(basis)==stages-1,"omission basis spans both exact sector constraints")
                laws += 1
                expected = sum(2*((len(run)-1)//2) for run in runs)
                if stages < 10:
                    matrix = [[pair(s,t,cut) for t in basis] for s in basis]
                    NEED(rank(matrix)==expected,"capacity is alternating tridiagonal rank on each run")
                    local_pair_cells += len(basis)**2
                if expected:
                    NEED(size<=stages-3,"productive idle must omit at least three labels")
                    viable += 1
                    distribution[str(size)]=distribution.get(str(size),0)+1
                if size==stages-3:
                    NEED(expected in (0,2),"width-maximal idle omits one consecutive triple")
    return {"stages":stages,"exact_cuts":cuts,"exact_mask_checks":laws,"local_pair_cells":local_pair_cells,
            "admissible_masks_with_nonzero_pairing":viable,"productive_mask_width_distribution":distribution}


def even_debit(stages,point,max_width):
    h = lambda rank: CORE.price(rank,*point)
    minus = SCREEN.interval_delta
    start = minus(CORE.scaled(h(17),3),CORE.scaled(h(25),2))
    slope = minus(h(25),h(17))
    def excess(k,x):
        line = CORE.add(start,CORE.scaled(slope,x))
        return CORE.scaled(minus(h(8*k+1),line),1,k-x)
    mark_count = (stages-3)//2
    debits = []
    for a in range(1,max_width+1):
        gain,k,x = max((excess(k,x)[1],k,x) for k in range(a,stages+1) for x in range(k))
        group = minus(h(8*a),(a*gain,a*gain))
        NEED(group[0]>0,"all paid groups have a positive debit even without forced marks")
        debits.append((CORE.scaled(group,1,min(a,mark_count))[0],a,k,x))
    charge,a,k,x = min(debits)
    return charge,(a,k,x)


def prices(stages,point,paid,helpers):
    exact = SCREEN.make_coefficients(stages,point,paid,helpers)
    base,defect,charge,short,odd = (q[1] for q in exact)
    debit,profile = even_debit(stages,point,stages)
    restricted,small = even_debit(stages,point,stages-3)
    format_upper = lambda q: CORE.format_bounds((q,q))[1]
    loose = base + charge*SCREEN.marks(stages,0,0)[0] + short*SCREEN.marks(stages,0,0)[1]
    strict = base - restricted*SCREEN.marks(stages,0,0)[0]
    cap_profile = {}
    for c in range(129):
        for d in range(0,2*(stages*192+c)+2,2):
            if (stages-1)*192+c-d < 0:
                break  # The price formula describes a nonnegative number of roots.
            need,m_short = SCREEN.marks(stages,c,d)
            first = base+defect*d+charge*need+short*m_short+odd*c
            second = base+defect*d-debit*need+odd*c
            value = min(first,second)
            if c not in cap_profile or value>cap_profile[c][0]:
                cap_profile[c] = (value,d)
    first_open = next(((c,d,format_upper(q)) for c,(q,d) in cap_profile.items() if q>=0),None)
    exact_defect_max_c = max((c for c in range(129)
                             if base-debit*SCREEN.marks(stages,c,0)[0]+odd*c < 0),default=None)
    return {"stages":stages,"saving":point,"whole_upper_at_c0_d0_without_parity":format_upper(loose),
            "whole_upper_at_c0_d0_with_parity":format_upper(strict),
            "even_charge_per_mark_lower":CORE.format_bounds((debit,debit))[0],
            "full_width_optimizing_a_k_x":profile,"omission_restricted_optimizing_a_k_x":small,
            "first_nonnegative_c_at_some_admissible_d_through_128":first_open,
            "last_negative_even_charge_bound_c_at_d0":exact_defect_max_c,
            "joint_c0_cap_and_d":(format_upper(cap_profile[0][0]),cap_profile[0][1]),
            "joint_c41_cap_and_d":(format_upper(cap_profile[41][0]),cap_profile[41][1]),
            "joint_c105_cap_and_d":(format_upper(cap_profile[105][0]),cap_profile[105][1])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("complex_pack",type=Path)
    args = parser.parse_args()
    paid,helpers = CLOCK.JOINT.read_complex(args.complex_pack)
    rows = [prices(stages,point,paid,helpers) for point,stages in product(SCREEN.POINTS,(15,17,19,21))]
    by_L = {row["stages"]:row for row in rows if row["saving"]==SCREEN.POINTS[0]}
    NEED(Fraction(by_L[19]["whole_upper_at_c0_d0_with_parity"])<-3,"first naive relaxation opening closed")
    NEED(by_L[17]["first_nonnegative_c_at_some_admissible_d_through_128"][:2]==(106,20),"joint 17-stage boundary")
    NEED(by_L[19]["joint_c0_cap_and_d"][1]==26,"19-stage excess-defect maximum")
    print(json.dumps({"status":"PASS_CYCLIC_CLOCK_CAPACITY_AND_EVEN_PRICE", "prices":rows,
                      "capacity_fixtures":[geometry(l) for l in (5,7,9,11)]},indent=2,sort_keys=True))


if __name__ == "__main__":
    main()
