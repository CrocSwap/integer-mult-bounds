# SPDX-License-Identifier: Apache-2.0
"""Exact rank bounds for rescheduling the helper layer of the #7546 native word."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import gzip
from hashlib import sha256
import json
from pathlib import Path
from time import monotonic, perf_counter


WORD_SHA = "6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32"
CALLER_SHA = "255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc"
GRID = 1125 << 25
MODULUS = 2**31 - 1


def need(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def pinned_json(path, digest, compressed=False):
    raw = path.read_bytes()
    need(sha256(raw).hexdigest() == digest, f"source pin {path.name}")
    return json.loads(gzip.decompress(raw) if compressed else raw)


def chart_space(generators):
    result = {0}
    for vector in generators:
        need(vector not in result and 0 < vector < 512, "dependent chart generators")
        result.update({x ^ vector for x in result})
    return frozenset(result)


def scaled(row, factor):
    items = {}
    for key, value in row.items():
        quotient, remainder = divmod(value * factor.numerator, factor.denominator)
        need(remainder == 0, "nonexact grid operation")
        if quotient:
            items[key] = quotient
    return items


def add(row, increment):
    result = row.copy()
    for key, value in increment.items():
        new = result.get(key, 0) + value
        if new:
            result[key] = new
        else:
            result.pop(key, None)
    return result


def required_rows(word):
    n = word["public"]
    hosted = word["hosted"]
    main = {*word["live"], *(p + 112 for p in word["live"]), *hosted["X2"], *hosted["Y2"]}
    rows = [{i: GRID} for i in range(n)]
    for port, x in enumerate(word["live"]):
        y = x + 112
        if port in hosted["Dports"]:
            rows[y][x] = GRID
        else:
            rows[x][y] = -GRID
            rows[y] = {x: GRID // 2, y: GRID // 2}
    for x, y in zip(hosted["X2"], hosted["Y2"], strict=True):
        rows[x][y] = -GRID
    need(len(main) == 400, "literal main roles")
    return main, rows


def capture(word, deadline):
    """Log known arrivals and observable rows after exact replay on the full grid."""
    n, n_owned = word["public"], word["owned_fields"]
    main, expected = required_rows(word)
    main_index = {role: i for i, role in enumerate(sorted(main))}
    spaces = [chart_space(g) for g in word["frames"]]
    canonical = {g: i for i, g in reversed(list(enumerate(spaces)))}
    aliases = [canonical[g] for g in spaces]
    dimensions = {i: len(g).bit_length() - 1 for g, i in canonical.items()}
    rows = [{i: GRID} for i in range(n)] + [{} for _ in range(n_owned)]
    place = word["initial"][:] + [None] * n_owned
    histories = [[dimensions[aliases[f]]] for f in word["initial"]]
    timeline = defaultdict(list)
    public_moves, owned_moves = Counter(), Counter()
    side_count = Counter()

    def record(chart, kind, row, event, role):
        projection = {main_index[k]: value for k, value in row.items() if k in main_index}
        timeline[aliases[chart]].append((kind, projection, event, role))

    def fixed(role):
        return role in main or role >= n

    for role in sorted(main):
        record(place[role], "arrival", rows[role], -1, role)
    for index, event in enumerate(word["program"]):
        if index % 1024 == 0:
            need(monotonic() < deadline, "capture deadline")
        op, role, *args = event
        if op == "INIT":
            need(role >= n and place[role] is None and not rows[role], "INIT ownership")
            place[role] = args[0]
            record(args[0], "arrival", rows[role], index, role)
        elif op == "CLEAR":
            need(role >= n and place[role] == args[0], "CLEAR ownership and frame")
            record(args[0], "departure", rows[role], index, role)
            rows[role] = {}
            place[role] = None
        elif op == "MOVE":
            old, new, owned = args
            need(place[role] == old and owned == (role >= n), "MOVE ownership and frame")
            rising = spaces[old] < spaces[new]
            need(rising or (owned and spaces[new] < spaces[old]), "MOVE nesting")
            a, b = dimensions[aliases[old]], dimensions[aliases[new]]
            if fixed(role):
                record(old, "departure", rows[role], index, role)
                record(new, "arrival", rows[role], index, role)
                (owned_moves if owned else public_moves)[abs(b - a)] += 1
            else:
                record(old, "helper_out", {}, index, role)
                record(new, "helper_in", {}, index, role)
                histories[role].append(b)
            if owned:
                side_count["owned_ascent" if b > a else "owned_descent"] += abs(b - a)
            place[role] = new
        else:
            factor, chart = args[-2:]
            need(place[role] == chart, "scalar gate frame")
            if op == "SCALE":
                rows[role] = scaled(rows[role], Fraction(factor))
            else:
                source = args[0]
                need(op in ("ADD", "COPY") and source != role and place[source] == chart,
                     "scalar operand frame")
                if op == "COPY":
                    need(role >= n and not rows[role], "COPY destination")
                if fixed(source):
                    record(chart, "observe", rows[source], index, source)
                rows[role] = add(rows[role], scaled(rows[source], Fraction(factor)))
            if fixed(role):
                record(chart, "observe", rows[role], index, role)
    need(rows[:n] == expected and rows[n:] == [{}] * n_owned, "complete scalar endpoint")
    need(place[:n] == word["final"] and place[n:] == [None] * n_owned, "complete final frames")
    for role in sorted(main):
        record(place[role], "departure", rows[role], len(word["program"]), role)
    return timeline, dimensions, histories, main, public_moves, owned_moves, side_count


def extend_basis(basis, row, modulus):
    if modulus is None:
        value = {k: Fraction(x) for k, x in row.items() if x}
    else:
        value = {k: x % modulus for k, x in row.items() if x % modulus}
    while value:
        pivot = min(value)
        if pivot not in basis:
            divisor = value[pivot]
            if modulus is None:
                basis[pivot] = {k: x / divisor for k, x in value.items()}
            else:
                inverse = pow(divisor, -1, modulus)
                basis[pivot] = {k: (x * inverse) % modulus for k, x in value.items()}
            return 1
        factor = value[pivot]
        for key, x in basis[pivot].items():
            y = value.get(key, 0) - factor * x
            if modulus is not None:
                y %= modulus
            if y:
                value[key] = y
            else:
                value.pop(key, None)
    return 0


def chart_bounds(events, modulus=None, keep_certificate=False):
    arrivals, combined = {}, {}
    prefix = 0
    prefix_event = None
    accumulated = 0
    count_known_in = 0
    helper_in = helper_out = 0
    records = []
    for kind, row, event, role in events:
        if kind == "helper_in":
            helper_in += 1
        elif kind == "helper_out":
            helper_out += 1
        else:
            if kind == "arrival":
                extend_basis(arrivals, row, modulus)
                count_known_in += 1
            new = extend_basis(combined, row, modulus)
            if kind != "arrival" and new:
                accumulated += 1
                if keep_certificate:
                    records.append([event, role, len(combined), len(arrivals), helper_in])
            current = len(combined) - len(arrivals)
            if current > prefix:
                prefix = current
                prefix_event = event
    static_in = len(combined) - len(arrivals)
    need(static_in <= prefix <= accumulated <= helper_in, "literal word violates ordered rank bounds")
    return {
        "prefix": prefix,
        "prefix_event": prefix_event,
        "accumulated": accumulated,
        "static": static_in,
        "static_count_only": max(0, len(combined) - count_known_in),
        "actual_arrivals": helper_in,
        "actual_departures": helper_out,
        "arrival_ranks": len(arrivals),
        "combined_rank": len(combined),
        "records": records,
    }


def reverse_events(events):
    reverse_kind = {"arrival": "departure", "departure": "arrival", "observe": "observe",
                    "helper_in": "helper_out", "helper_out": "helper_in"}
    return [(reverse_kind[kind], row, event, role) for kind, row, event, role in reversed(events)]


def combined_profiles(caller, native_paid, native_targets):
    calls = sum(event[0] == "J" for event in caller["events"])
    paid = Counter({r: n * calls for r, n in native_paid.items()})
    targets = Counter({r: n * calls for r, n in native_targets.items()})
    for event in caller["events"]:
        if event[0] == "J":
            continue
        ports = len(caller["types"][event[0]]["ports"])
        if event[1] == "QUERY":
            paid[1] += ports
        elif event[1] in ("IDLE_ONE", "IDLE_ODD"):
            mask = event[3]
            need(mask and len(set(mask)) == len(mask) and all(1 <= s <= calls for s in mask),
                 "valid distinct body axes")
            paid[8 * len(mask) + (event[1] == "IDLE_ODD")] += ports
        else:
            need(event[1] in ("ADD", "SCALE", "SWAP", "LAMBDA"), "known caller opcode")
    for bank in caller["types"].values():
        for q, _, *mask in bank["diagonal"]:
            need(len(mask) == calls and all(bit in (0, 1) for bit in mask), "binary target mask")
            rank = q % 2 + 8 * sum(mask)
            need(rank > 0 and any(mask), "positive root jobs with nonempty bodies")
            targets[rank] += len(bank["ports"])
    return calls, dict(sorted(paid.items())), dict(sorted(targets.items()))


def report(word, caller, deadline, evaluation_grids=None):
    start = perf_counter()
    timeline, dims, histories, main, public_moves, owned_moves, side_count = capture(word, deadline)
    capture_time = perf_counter() - start
    results = {}
    exact_start = perf_counter()
    for chart, events in sorted(timeline.items()):
        need(monotonic() < deadline, "exact rank deadline")
        if dims[chart] in (0, 9):
            continue
        back = reverse_events(events)
        bound = chart_bounds(events, keep_certificate=True)
        reverse = chart_bounds(back, keep_certificate=True)
        for exact, modular in ((bound, chart_bounds(events, MODULUS)),
                               (reverse, chart_bounds(back, MODULUS))):
            need(all(exact[key] == modular[key] for key in ("prefix", "static", "accumulated")),
                 "exact and modular rank differ")
        bound["reverse"] = reverse
        arrivals, departures = set(), set()
        for kind, _, _, role in events:
            if kind == "helper_in":
                arrivals.add(role)
            if kind == "helper_out":
                departures.add(role)
        bound["actual"] = len(arrivals & departures)
        # In each direction give full credit to a helper that ends in this chart.
        # A redesign may trade such a helper for an interior visit only by keeping
        # the fixed endpoint count or charging that new endpoint separately.
        bound["joint"] = max(0, bound["accumulated"] - len(arrivals - departures),
                             reverse["accumulated"] - len(departures - arrivals))
        bound["prefix_interior"] = max(0, bound["prefix"] - len(arrivals - departures),
                                      reverse["prefix"] - len(departures - arrivals))
        bound["static_interior"] = max(0, bound["static"] - len(arrivals - departures),
                                      reverse["static"] - len(departures - arrivals))
        bound["fixed_helper_starts"] = len(departures - arrivals)
        bound["fixed_helper_finishes"] = len(arrivals - departures)
        need(bound["joint"] <= bound["actual"], "literal word violates joint interior bound")
        results[chart] = bound
        if evaluation_grids is not None:
            evaluation_grids[chart] = events

    native_targets = Counter()
    helper_paid = Counter()
    helper_endpoints = Counter()
    for role, path in enumerate(histories):
        if role not in main:
            native_targets[path[-1] - path[0]] += 1
            helper_endpoints[f"{path[0]}:{path[-1]}"] += 1
            helper_paid.update(b - a for a, b in zip(path, path[1:]))
    combined = public_moves + owned_moves + helper_paid
    calls, paid, targets = combined_profiles(caller, combined, native_targets)
    need(calls == 17 and sum(paid.values()) == 110468 and sum(targets.values()) == 22461,
         "signed invoice positive control")

    summary = {
        "status": "PASS_EXACT_TEMPORAL_HELPER_SCREEN",
        "capture_seconds": capture_time,
        "exact_and_modular_rank_seconds": perf_counter() - exact_start,
        "source_sha256": {"word": WORD_SHA, "caller": CALLER_SHA},
        "chart_count": len(results),
        "fixed_public": {"moves": dict(public_moves), "fields": len(main)},
        "fixed_owned": {"moves": dict(owned_moves), "slots": word["owned_fields"], "rank_mass": dict(side_count)},
        "helper_moves": dict(helper_paid),
        "helper_targets": dict(native_targets),
        "helper_endpoints": dict(helper_endpoints),
        "native_calls": calls,
        "signed_paid": paid,
        "signed_targets": targets,
        "signed_mass_surplus": sum(r * (targets.get(r, 0) - paid.get(r, 0)) for r in paid.keys() | targets.keys()),
        "charts": results,
        "totals": {key: sum(r[key] for r in results.values())
                   for key in ("prefix", "static", "static_count_only", "accumulated", "joint",
                               "prefix_interior", "static_interior", "actual")},
        "totals_reverse": {key: sum(r["reverse"][key] for r in results.values())
                           for key in ("prefix", "static", "static_count_only", "accumulated")},
    }
    return summary


def self_test():
    # A direction is observed before the fixed row supplying it arrives.
    early = [("helper_in", {}, 0, 0), ("observe", {0: 1}, 1, 1),
             ("arrival", {0: 1}, 2, 2)]
    late = [early[2], early[1]]
    need((chart_bounds(early)["prefix"], chart_bounds(early)["static"]) == (1, 0),
         "temporal false negative control")
    need(chart_bounds(late)["prefix"] == 0, "retiming can change the lower bound")
    burn_two = early + [("helper_in", {}, 3, 0), ("observe", {1: 7}, 4, 1),
                        ("arrival", {1: 7}, 5, 2)]
    need(chart_bounds(burn_two)["accumulated"] == 2 and chart_bounds(burn_two)["prefix"] == 1,
         "later arrival cannot retroactively pay for both independent observations")
    # Reducing integer rows mod p may hide an exact independent direction.
    full, modular = {}, {}
    for row in ({0: 1}, {0: 1, 1: MODULUS}):
        extend_basis(full, row, None)
        extend_basis(modular, row, MODULUS)
    need((len(full), len(modular)) == (2, 1), "singular modular control")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--word", type=Path)
    parser.add_argument("--caller", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--seconds", type=int, default=75)
    args = parser.parse_args()
    self_test()
    if args.self_test:
        print("PASS_TEMPORAL_AND_MODULAR_CONTROLS")
        return
    if not all((args.word, args.caller, args.output)):
        parser.error("--word, --caller and --output are required for source replay")
    need(0 < args.seconds <= 300, "finite requested deadline")
    deadline = monotonic() + args.seconds
    word = pinned_json(args.word, WORD_SHA, True)
    caller = pinned_json(args.caller, CALLER_SHA)
    result = report(word, caller, deadline)
    args.output.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(result["status"], result["totals"], flush=True)


if __name__ == "__main__":
    main()
