"""Track exact live relation components, then screen recipient-side recovery."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import gzip
from hashlib import sha256
from itertools import chain, combinations
import json
from math import gcd
from pathlib import Path
from random import Random
import time

WORD_SHA = "bdecd5cc1cb9f164dc695ce07a07d5d44e9961996fcdfa4d77b4092fecbda745"


def require(condition, description):
    if not condition:
        raise ValueError(description)


def op_fields(event):
    return event[1:3] if event[0] in ("ADD", "COPY") else event[1:2]


def normalized(row):
    row = {field: value for field, value in row.items() if value}
    if not row:
        return {}
    common = gcd(*row.values())
    return {field: value // common for field, value in row.items()}


class Relations:
    """Integer bases for disjoint relation subspaces, indexed by live owner."""

    def __init__(self, size):
        self.groups = [None] * size
        self.serial = 0
        self.dirty = set()

    def install(self, rows):
        if not rows:
            return
        # Split the support graph of this basis into disjoint components.
        components = []
        for row in rows:
            support = set(row)
            disjoint = []
            grouped = [row]
            for others, labels in components:
                if support.intersection(labels):
                    support.update(labels)
                    grouped.extend(others)
                else:
                    disjoint.append((others, labels))
            disjoint.append((grouped, support))
            components = disjoint
        for basis, support in components:
            self.serial += 1
            group = (basis, support, self.serial)
            for label in support:
                self.groups[label] = group
            self.dirty.update(support)

    def remap(self, fields, change):
        groups = {}
        for field in fields:
            group = self.groups[field]
            if group is not None:
                groups[group[2]] = group
        if groups:
            rows = list(chain.from_iterable(group[0] for group in groups.values()))
            for _, support, _ in groups.values():
                for label in support:
                    self.groups[label] = None
                self.dirty.update(support)
            self.install(change(rows))

    def add(self, destination, source, coefficient):
        if self.groups[destination] is None:
            return
        q, d = coefficient.numerator, coefficient.denominator

        def change(rows):
            result = []
            for row in rows:
                if destination in row:
                    changed = {field: d * value for field, value in row.items()}
                    changed[source] = changed.get(source, 0) - q * row[destination]
                    row = normalized(changed)
                result.append(row)
            return result

        self.remap((destination, source), change)

    def scale(self, field, coefficient):
        q, d = coefficient.numerator, coefficient.denominator

        def change(rows):
            result = []
            for row in rows:
                if field in row:
                    changed = {k: q * value for k, value in row.items()}
                    changed[field] = d * row[field]
                    row = normalized(changed)
                result.append(row)
            return result

        self.remap((field,), change)

    def clear(self, field):
        def change(rows):
            pivot = next(row for row in rows if field in row)
            result = []
            for row in rows:
                if row is pivot:
                    continue
                if field in row:
                    a, b = pivot[field], -row[field]
                    changed = {k: a * value for k, value in row.items() if k != field}
                    for k, value in pivot.items():
                        if k != field:
                            changed[k] = changed.get(k, 0) + b * value
                    row = normalized(changed)
                result.append(row)
            return result

        self.remap((field,), change)


def projected_relations(basis, outside):
    """Yield a basis on allowed owners with all coefficients retained."""
    pivots = {}
    for original in basis:
        row = original
        while available := outside.intersection(row):
            pivot = min(available)
            if pivot not in pivots:
                pivots[pivot] = row
                break
            other = pivots[pivot]
            a, b = other[pivot], -row[pivot]
            changed = {k: a * value for k, value in row.items()}
            for k, value in other.items():
                changed[k] = changed.get(k, 0) + b * value
            row = normalized(changed)
        else:
            if row:
                yield row


def recover_at_cut(field, target, group, frame):
    basis, support, _ = group
    outside = {k for k in support if k != field and frame[k] != target}
    if len(basis) == 1:
        return basis[0] if not outside else None
    for row in projected_relations(basis, outside):
        if field in row:
            return row
    return None


def test_retimed_group(arrivals, target, candidate_groups, frame):
    for group in candidate_groups.values():
        basis, support, _ = group
        relation_pivots = support & arrivals
        allowed = relation_pivots.copy()
        allowed.update(field for field in support if frame[field] == target)
        outside = support - allowed
        for row in projected_relations(basis, outside):
            if relation_pivots.intersection(row):
                return row
    return None


def one_pivot_field(field, target, group, frame):
    """Relations that use one additional nonresident owner besides the arrival."""
    basis, support, _ = group
    outside = {k for k in support if k != field and frame[k] != target}
    for donor in sorted(outside):
        for row in projected_relations(basis, outside - {donor}):
            if field in row and donor in row:
                yield donor, row
                break


def eliminate(basis, basis_vectors):
    """Reduce generators modulo a fixed exact row basis."""
    for vector in basis_vectors:
        for pivot, donor in basis.items():
            if pivot not in vector:
                continue
            a, b = donor[pivot], -vector[pivot]
            changed = {k: a * value for k, value in vector.items()}
            for k, value in donor.items():
                changed[k] = changed.get(k, 0) + b * value
            vector = normalized(changed)
        yield vector


def two_pivot_fields(field, target, group, frame):
    """Find independent two-donor directions that recover the arrival."""
    basis, support, _ = group
    # Pass to Q^[nonresident] modulo the projected live relations.
    outside = {k for k in support if frame[k] != target}
    echelon = {}
    for source_row in basis:
        projection = {k: v for k, v in source_row.items() if k in outside}
        reduced = next(eliminate(echelon, (projection,)))
        if reduced:
            echelon[min(reduced)] = reduced
    labels = sorted(outside)
    coordinates = dict(zip(labels, eliminate(echelon, ({k: 1} for k in labels)), strict=True))
    desired = coordinates[field]
    if not desired:
        return
    pivot = min(desired)
    direction_scale = desired[pivot]
    rays = defaultdict(list)
    for label, vector in coordinates.items():
        if label == field:
            continue
        scale = vector.get(pivot, 0)
        residual = {k: direction_scale * value - scale * desired.get(k, 0) for k, value in vector.items()}
        for k, value in desired.items():
            if k not in vector:
                residual[k] = -scale * value
        residual = normalized(residual)
        if not residual:
            continue
        sign = 1 if residual[min(residual)] > 0 else -1
        ray = tuple(sorted((k, sign * v) for k, v in residual.items()))
        # Check the actual vector ratio because primitive_row normalization
        # suppresses the gcd of the scaled residual.
        key = ray[0][0]
        coefficient = Fraction(scale, direction_scale * vector.get(key, 0) - scale * desired.get(key, 0))
        rays[ray].append((label, coefficient))
    for entries in rays.values():
        for (a, first), (b, second) in combinations(entries, 2):
            if first != second:
                yield a, b


def scan(word, deadline, use_event_index=True, one_donor=False, two_donors=False, tariff_floor=False):
    public, owned = word["public"], word["owned_fields"]
    program = word["program"]
    frame = word["initial"] + [None] * owned
    relations = Relations(len(frame))
    counts = Counter()
    examples = []
    donor_histograms = Counter()
    donor_examples = defaultdict(list)
    pair_histograms = Counter()
    pair_examples = defaultdict(list)
    floor_histograms = Counter()
    floor_examples = []
    dims = tuple(map(len, word["frames"]))
    spans = []
    if one_donor or two_donors or tariff_floor:
        for basis in word["frames"]:
            vectors = {0}
            for direction in basis:
                vectors.update(tuple(direction ^ vector for vector in vectors))
            spans.append(vectors)

    rank_cache = {}

    def fourier_rank(a, b):
        key = a, b
        if key in rank_cache:
            return rank_cache[key]
        common = (len(spans[a] & spans[b])).bit_length() - 1
        rank = dims[a] + dims[b] - 2 * common
        rank_cache[key] = rank
        return rank
    next_use_indices = defaultdict(list)
    for time_index, event in enumerate(program):
        for field in op_fields(event):
            next_use_indices[field].append(time_index)
    seen = [0] * len(frame)
    open_at, close_at = defaultdict(list), defaultdict(list)
    for field, indices in next_use_indices.items():
        for position, index in enumerate(indices):
            if program[index][0] != "MOVE":
                continue
            previous = indices[position-1] if position else -1
            following = indices[position+1] if position + 1 < len(indices) else len(program)
            move = (index, field, program[index][3])
            open_at[previous + 1].append(move)
            close_at[following + 1].append(move)
    open_moves = defaultdict(dict)
    label_open = [set() for _ in frame]
    active_with_relation = defaultdict(dict)

    def open_move(move):
        open_moves[move[2]][move[0]] = move
        label_open[move[1]].add(move)

    def close_move(move):
        del open_moves[move[2]][move[0]]
        label_open[move[1]].remove(move)

    def invalidate(field, changed_targets):
        group = relations.groups[field]
        for move in label_open[field]:
            target = move[2]
            if group is not None:
                active_with_relation[target][move[0]] = move
            else:
                active_with_relation[target].pop(move[0], None)
        if group is not None:
            for peer in group[1]:
                changed_targets.update(move[2] for move in label_open[peer])

    retimed_witnesses = []
    component_states = {}
    for move in open_at[0]:
        open_move(move)
    for time_index, event in enumerate(program):
        if time_index % 512 == 0:
            require(time.monotonic() < deadline, "receiver scan deadline")
        relations.dirty.clear()
        code, field = event[:2]
        if code == "INIT":
            require(relations.groups[field] is None, "INIT only on free owned fields")
            relations.install([{field: 1}])
            frame[field] = event[2]
        elif code in ("ADD", "COPY"):
            if code == "COPY":
                group = relations.groups[field]
                require(group is not None and (
                    recover_at_cut(field, None, group, frame) == {field: 1}
                    or any(set(row) == {field} for row in group[0])), "COPY input is zero")
            if field == event[2]:
                relations.scale(field, 1 + Fraction(event[3]))
            else:
                relations.add(field, event[2], Fraction(event[3]))
        elif code == "SCALE":
            relations.scale(field, Fraction(event[2]))
        elif code == "CLEAR":
            relations.clear(field)
            frame[field] = None
        elif code == "MOVE":
            require(frame[field] == event[2], "retained source chart")
            target = event[3]
            counts["moves"] += 1
            if (group := relations.groups[field]) is not None:
                counts["moves_touching_live_relation"] += 1
                counts["largest_support_component"] = max(counts["largest_support_component"], len(group[1]))
                counts["largest_relation_component_dimension"] = max(counts["largest_relation_component_dimension"], len(group[0]))
                witness = recover_at_cut(field, target, group, frame)
                if witness is not None:
                    following = next_use_indices[field][seen[field]+1:seen[field]+4]
                    examples.append({"event": time_index, "move": event, "relation": witness,
                                     "next_contacts": [[i, program[i]] for i in following]})
                if one_donor:
                    old_rank = abs(dims[event[2]] - dims[target])
                    for donor, row in one_pivot_field(field, target, group, frame):
                        donor_chart = frame[donor]
                        donor_rank = fourier_rank(donor_chart, target)
                        label = (old_rank, donor_rank)
                        donor_histograms[label] += 1
                        if donor_rank < old_rank and len(donor_examples[label]) < 12:
                            donor_examples[label].append({"event": time_index, "move": event, "donor": donor,
                                                          "donor_chart": donor_chart, "relation": row})
                if two_donors:
                    old_rank = fourier_rank(event[2], target)
                    for first, second in two_pivot_fields(field, target, group, frame):
                        first_rank = fourier_rank(frame[first], target)
                        second_rank = fourier_rank(frame[second], target)
                        label = (old_rank, *sorted((first_rank, second_rank)))
                        pair_histograms[label] += 1
                        if first_rank + second_rank <= old_rank and len(pair_examples[label]) < 12:
                            pair_examples[label].append({"event": time_index, "move": event,
                                                         "donors": [first, second],
                                                         "donor_charts": [frame[first], frame[second]],
                                                         "donor_ranks": [first_rank, second_rank]})
                if tariff_floor:
                    old_rank = fourier_rank(event[2], target)
                    basis, support, _ = group
                    rank_by_owner = {k: fourier_rank(frame[k], target) for k in support if k != field}
                    excluded = {k for k, rank in rank_by_owner.items() if rank >= old_rank}
                    for row in projected_relations(basis, excluded):
                        if field not in row:
                            continue
                        ranks = [rank_by_owner[k] for k in row if k != field]
                        label = (old_rank, max(ranks, default=0))
                        floor_histograms[label] += 1
                        floor_examples.append({"event":time_index, "move":event, "relation":row,
                                               "donor_ranks":{k:rank_by_owner[k] for k in row if k != field}})
                        break
            frame[field] = target
        else:
            raise ValueError(f"unexpected opcode {code}")
        for label in op_fields(event):
            seen[label] += 1
        cut = time_index + 1
        changed_targets = set()
        dirty_labels = relations.dirty
        for move in close_at.get(cut, ()):
            close_move(move)
            active_with_relation[move[2]].pop(move[0], None)
            changed_targets.add(move[2])
            dirty_labels.add(move[1])
        for move in open_at.get(cut, ()):
            open_move(move)
            changed_targets.add(move[2])
            dirty_labels.add(move[1])
        if code == "MOVE":
            dirty_labels.add(field)
        for label in dirty_labels:
            invalidate(label, changed_targets)
        # Leave all non-batched MOVE owners on their recorded chronology.
        # An owner of this destination batch has exactly one arriving value,
        # even in two touching MOVE windows.
        targets = changed_targets if use_event_index else active_with_relation
        for target in targets:
            if not active_with_relation[target]:
                continue
            arrivals = open_moves[target]
            relevant = active_with_relation[target].values()
            candidate_groups = {relations.groups[a[1]][2]: relations.groups[a[1]] for a in relevant}
            supporters = {k for _, support, _ in candidate_groups.values() for k in support}
            arriving_labels = {k for k in supporters if any(move[2] == target for move in label_open[k])}
            state = (frozenset(arriving_labels),
                     frozenset((key, frozenset(k for k in support if frame[k] == target))
                               for key, (_, support, _) in candidate_groups.items()))
            if component_states.get(target) == state:
                continue
            component_states[target] = state
            counts["retimed_projection_tests"] += 1
            counts["largest_retimed_candidate_batch"] = max(counts["largest_retimed_candidate_batch"],
                                                              len(arrivals))
            witness = test_retimed_group(arriving_labels, target, candidate_groups, frame)
            if witness is not None:
                retimed_witnesses.append({"cut": cut, "target": target, "relation": witness,
                                          "arriving": [a for a in arrivals.values() if a[1] in witness]})
    require(frame[:public] == word["final"] and frame[public:] == [None] * owned,
            "returned chronological frame list")
    require(all(group is None for group in relations.groups[public:]), "no relation refers to dead owned field")
    result = {"counts": counts, "relation_witnesses": examples, "retimed_witnesses": retimed_witnesses}
    if one_donor:
        result["one_donor_histograms"] = {f"{old}:{new}": count for (old, new), count in donor_histograms.items()}
        result["one_donor_examples"] = {f"{old}:{new}": rows for (old, new), rows in donor_examples.items()}
    if two_donors:
        result["two_donor_histograms"] = {f"{old}:{a}+{b}": count
                                          for (old, a, b), count in pair_histograms.items()}
        result["two_donor_examples"] = {f"{old}:{a}+{b}": rows
                                        for (old, a, b), rows in pair_examples.items()}
    if tariff_floor:
        result["tariff_floor_failures"] = {f"{old}:{new}": count for (old, new), count in floor_histograms.items()}
        result["tariff_floor_witnesses"] = floor_examples
    return result


def controls():
    r = Relations(5)
    r.install([{2: 1}, {3: 1}])
    r.add(2, 0, Fraction(2, 3))
    r.add(3, 2, Fraction(4, 5))
    r.add(1, 3, Fraction(1))
    require(set(r.groups[2][1]) == {0, 2, 3}, "zero relation for 2,3 has correct support")
    witness = recover_at_cut(3, 0, r.groups[3], [0, 1, 2, 3, 4])
    require(witness in ({3: 15, 0: -8}, {3: -15, 0: 8}),
            "deferred dependence obtained by eliminating inaccessible label 2")
    require(recover_at_cut(3, 1, r.groups[3], [0, 1, 2, 3, 4]) is None,
            "dirty side data gives no recovery")
    r.clear(2)
    require(r.groups[2] is None and r.groups[3][0][0] in ({3: 15, 0: -8}, {3: -15, 0: 8}),
            "CLEAR kills only dependence on its literal owner")
    r.clear(3)
    require(all(group is None for group in r.groups), "restored all live relations")
    r.install([{1: 3, 2: -1, 3: 1}])
    group = r.groups[1]
    require(test_retimed_group({1, 2}, 5, {group[2]: group}, [0, 1, 2, 5, 4])
            == {1: 3, 2: -1, 3: 1}, "two arriving independent rows compress with one recipient row")
    require(test_retimed_group({1, 2}, 4, {group[2]: group}, [0, 1, 2, 5, 4]) is None,
            "the recipient row must have arrived")
    require(list(two_pivot_fields(1, 4, group, [0, 1, 2, 5, 4])) == [(2, 3)],
            "two distinct nonresident rows recover one arrival")
    require(not list(two_pivot_fields(1, 5, group, [0, 1, 2, 5, 4])),
            "one already-resident row reduces to the single-donor case")


def dense_rank(rows):
    pivots = {}
    for row in rows:
        work = row.copy()
        for column in range(len(work)):
            entry = work[column]
            if entry:
                if column not in pivots:
                    pivots[column] = work
                    break
                other = pivots[column]
                scale = entry / other[column]
                work = [left - scale * right for left, right in zip(work, other, strict=True)]
    return len(pivots)


def dense_controls():
    """Cross-check sparse dual state against primal dense rational row arithmetic."""
    random = Random(7546)
    relation = Relations(8)
    rows = [[Fraction(i == j) for j in range(4)] if i < 4 else None for i in range(8)]
    for _ in range(256):
        live = [i for i, row in enumerate(rows) if row is not None]
        dead = [i for i, row in enumerate(rows) if row is None]
        event = random.randrange(4)
        q = random.choice([Fraction(-2), Fraction(4, 3), Fraction(1, 7)])
        if event == 0 and dead:
            destination = random.choice(dead)
            relation.install([{destination: 1}])
            rows[destination] = [Fraction(0)] * 4
        elif event == 1 and (spares := [i for i in live if i >= 4]):
            destination = random.choice(spares)
            relation.clear(destination)
            rows[destination] = None
        elif event == 2:
            destination = random.choice(live)
            relation.scale(destination, q)
            rows[destination] = [q * x for x in rows[destination]]
        else:
            destination, source = random.sample(live, 2)
            relation.add(destination, source, q)
            rows[destination] = [x + q * y for x, y in zip(rows[destination], rows[source], strict=True)]
        live = [i for i, row in enumerate(rows) if row is not None]
        groups = {group[2]: group for group in relation.groups if group is not None}
        basis = [row for b, _, _ in groups.values() for row in b]
        require(len(basis) == len(live) - dense_rank([rows[i] for i in live]), "dense dual kernel dimension")
        for identity in basis:
            require(all(not sum(coef * rows[i][column] for i, coef in identity.items())
                        for column in range(4)), "dense vanishing dual identity")
        frame = [random.randrange(3) if i in live else None for i in range(8)]
        arrivals = set(random.sample(live, random.randrange(1, len(live) + 1)))
        resident = {i for i in live if frame[i] == 0} - arrivals
        rank_before = dense_rank([rows[i] for i in resident])
        rank_after = dense_rank([rows[i] for i in resident | arrivals])
        observed = test_retimed_group(arrivals, 0, groups, frame)
        require(bool(observed) == (rank_after - rank_before < len(arrivals)), "dense quotient dimension")
    return 256


def main():
    start = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("--all-cuts", action="store_true", help="disable the indexed target filter")
    parser.add_argument("--one-donor", action="store_true", help="screen one additional donor at literal MOVE cuts")
    parser.add_argument("--two-donors", action="store_true", help="screen two additional donors at literal MOVE cuts")
    parser.add_argument("--tariff-floor", action="store_true", help="test the span of all strictly cheaper literal donors")
    args = parser.parse_args()
    controls()
    dense_cases = dense_controls()
    data = gzip.decompress(args.word.read_bytes())
    require(sha256(data).hexdigest() == WORD_SHA, "literal #7546 word hash")
    word = json.loads(data)
    result = scan(word, start + 30, use_event_index=not args.all_cuts,
                  one_donor=args.one_donor, two_donors=args.two_donors, tariff_floor=args.tariff_floor)
    print(json.dumps({"word_sha256": WORD_SHA, "dense_control_cuts": dense_cases, **result,
                      "seconds": time.monotonic() - start},
                     sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
