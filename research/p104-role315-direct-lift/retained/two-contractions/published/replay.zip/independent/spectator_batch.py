"""Exact sector-Clifford controls and chronological redundancy screen for #7546."""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict, deque
import gzip
from hashlib import sha256
from itertools import product
import json
from math import gcd
from pathlib import Path
import time


WORD_SHA = "bdecd5cc1cb9f164dc695ce07a07d5d44e9961996fcdfa4d77b4092fecbda745"
CALLER_SHA = "255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc"
GRID = 1125 * 2**25
PRIME = 2**31 - 1


def require(condition, description):
    if not condition:
        raise ValueError(description)


def read_pinned(path, digest, compressed=False):
    data = path.read_bytes()
    if compressed:
        data = gzip.decompress(data)
    require(sha256(data).hexdigest() == digest, f"source hash for {path}")
    return json.loads(data)


def parity(bits):
    return bits.bit_count() & 1


def binary_rank(values):
    pivots = {}
    for value in values:
        while value:
            column = value.bit_length() - 1
            if column not in pivots:
                pivots[column] = value
                break
            value ^= pivots[column]
    return len(pivots)


def apply_binary(columns, selector):
    value = 0
    for bit, column in enumerate(columns):
        if (selector >> bit) & 1:
            value ^= column
    return value


def is_pauli(elements, width):
    """A monomial is Pauli iff offsets are constant and phase is affine even."""
    offset, absolute = elements[0]
    linear = [(elements[1 << bit][1] - absolute) % 4 for bit in range(width)]
    if any(entry % 2 for entry in linear):
        return False
    for address, (target, phase) in enumerate(elements):
        if (address ^ target) != offset:
            return False
        if (phase - absolute - sum(val for bit, val in enumerate(linear) if address >> bit & 1)) % 4:
            return False
    return True


def clifford_from_generators(elements, width):
    """Direct modular Pauli conjugation for a monomial, including its inverses."""
    for bit in range(width):
        x_image = [None] * len(elements)
        z_image = [None] * len(elements)
        for address, (target, phase) in enumerate(elements):
            flipped, new_phase = elements[address ^ (1 << bit)]
            x_image[target] = (flipped, (new_phase - phase) % 4)
            z_image[target] = (target, 2 * ((address >> bit) & 1))
        if not is_pauli(x_image, width) or not is_pauli(z_image, width):
            return False
    return True


def multiplexer(branches, payload):
    """Branches specify (X mask, Z mask, i phase) relative to the zero tag."""
    return [((tag << payload) | (address ^ x), (phase + 2 * parity(z & address)) % 4)
            for tag, (x, z, phase) in enumerate(branches)
            for address in range(1 << payload)]


def sector_law(branches, tags):
    require(branches[0] == (0, 0, 0), "normalized base branch")
    xcols, zcols, lins = zip(*(branches[1 << bit] for bit in range(tags)), strict=True)
    pair = {}
    for a in range(tags):
        for b in range(a + 1, tags):
            phase = branches[(1 << a) ^ (1 << b)][2]
            pair[a, b] = (phase - lins[a] - lins[b]) % 4
    if any(phase % 2 for phase in pair.values()):
        return False
    for tag, (x, z, phase) in enumerate(branches):
        wanted_phase = sum(val for bit, val in enumerate(lins) if tag >> bit & 1)
        wanted_phase += sum(val for (a, b), val in pair.items() if tag >> a & 1 and tag >> b & 1)
        if (apply_binary(xcols, tag), apply_binary(zcols, tag), wanted_phase % 4) != (x, z, phase):
            return False
    return True


def controls():
    paulis = tuple(product(range(2), range(2), range(4)))
    positive = 0
    for tail in product(paulis, repeat=3):
        branches = ((0, 0, 0), *tail)
        expected = sector_law(branches, 2)
        found = clifford_from_generators(multiplexer(branches, 1), 3)
        require(expected == found, f"Clifford normalizer comparison for {branches}")
        positive += found
    require(positive == 512, "complete two-tag census")
    affine_paulis = tuple((parity(tag & 3), parity(tag & 4),
                           (tag & 1) + 2 * int(tag & 6 == 6)) for tag in range(8))
    corrupted = list(affine_paulis)
    corrupted[7] = (corrupted[7][0], corrupted[7][1], (corrupted[7][2] + 2) % 4)
    require(sector_law(affine_paulis, 3) and not sector_law(corrupted, 3),
            "cubic phase normal form")
    require(clifford_from_generators(multiplexer(affine_paulis, 1), 4)
            and not clifford_from_generators(multiplexer(corrupted, 1), 4),
            "cubic phase normalizer rejection")
    return {"two_tag_relative_pauli_cases": len(paulis)**3, "admitted": positive,
            "nonquadratic_sign_control_rejected": True}


def op_fields(event):
    return event[1:3] if event[0] in ("ADD", "COPY") else event[1:2]


def mul(value, ratio):
    numerator, separator, denominator = ratio.partition("/")
    numerator = int(numerator)
    denominator = int(denominator) if separator else 1
    output = {}
    for column, entry in value.items():
        scaled, remainder = divmod(numerator * entry, denominator)
        require(remainder == 0, "literal intermediate lies on prior exact grid")
        if scaled:
            output[column] = scaled
    return output


def add(a, b):
    output = a.copy()
    for column, entry in b.items():
        value = output.get(column, 0) + entry
        if value:
            output[column] = value
        elif column in output:
            del output[column]
    return output


def primitive_row(value):
    if not value:
        return ()
    common = gcd(*value.values())
    first = min(value)
    divisor = common if value[first] > 0 else -common
    return tuple(sorted((column, entry // divisor) for column, entry in value.items()))


def peel_rows(rows):
    incidence = defaultdict(set)
    for index, row in enumerate(rows):
        for column in row:
            incidence[column].add(index)
    singletons = deque(column for column, hits in incidence.items() if len(hits) == 1)
    residual = set(range(len(rows)))
    while singletons:
        column = singletons.popleft()
        hits = incidence[column]
        if len(hits) != 1:
            continue
        index = next(iter(hits))
        residual.remove(index)
        for k in rows[index]:
            other = incidence[k]
            other.remove(index)
            if len(other) == 1:
                singletons.append(k)
    return [rows[index] for index in sorted(residual)]


def modular_rank(rows, deadline=None):
    pivots = {}
    order = {}
    steps = 0
    for row in sorted(rows, key=len):
        value = {k: n % PRIME for k, n in row.items() if n % PRIME}
        while value:
            steps += 1
            if deadline and steps % 1024 == 0:
                require(time.monotonic() < deadline, "modular rank deadline")
            available = value.keys() & pivots.keys()
            first = min(available, key=order.__getitem__) if available else min(value)
            val = value[first]
            if not available:
                scale = pow(val, -1, PRIME)
                order[first] = len(order)
                pivots[first] = {k: n * scale % PRIME for k, n in value.items()}
                break
            for k, n in pivots[first].items():
                remainder = (value.get(k, 0) - val * n) % PRIME
                if remainder:
                    value[k] = remainder
                elif k in value:
                    del value[k]
    return len(pivots)


def exact_rank(rows, deadline=None):
    """Cross-multiply integer sparse rows, reducing gcd to control bit growth."""
    pivots = {}
    order = {}
    steps = 0
    for row in sorted(rows, key=len):
        value = row.copy()
        while value:
            steps += 1
            if deadline and steps % 1024 == 0:
                require(time.monotonic() < deadline, "exact rank deadline")
            available = value.keys() & pivots.keys()
            first = min(available, key=order.__getitem__) if available else min(value)
            if not available:
                order[first] = len(order)
                pivots[first] = value
                break
            other = pivots[first]
            a, b = other[first], -value[first]
            value = add({k: a * n for k, n in value.items()}, {k: b * n for k, n in other.items()})
            common = gcd(*value.values())
            if common > 1:
                value = {k: n // common for k, n in value.items()}
    return len(pivots)


def touches_from_right(program, field_count):
    next_touch = [len(program)] * field_count
    next_move_touch = {}
    for index in range(len(program) - 1, -1, -1):
        event = program[index]
        if event[0] == "MOVE":
            next_move_touch[index] = next_touch[event[1]]
        for field in op_fields(event):
            next_touch[field] = index
    return next_move_touch


def read_moves(word, deadline):
    public, owned = word["public"], word["owned_fields"]
    program = word["program"]
    bodies = [len(f) for f in word["frames"]]
    row = [{i: GRID} for i in range(public)] + [None] * owned
    frame = word["initial"] + [None] * owned
    previous_touch = [-1] * len(row)
    future_touches = touches_from_right(program, len(row))
    moves = []
    opcode = Counter()
    for index, event in enumerate(program):
        if index % 1024 == 0:
            require(time.monotonic() < deadline, "40-second source scan deadline")
        code, field = event[:2]
        opcode[code] += 1
        if code == "INIT":
            require(field >= public and frame[field] is None, "inactive owned allocation")
            frame[field], row[field] = event[2], {}
        elif code == "CLEAR":
            require(field >= public and frame[field] == event[2], "owned clearing chart")
            frame[field], row[field] = None, None
        elif code == "MOVE":
            a, b, is_owned = event[2:]
            require(frame[field] == a and is_owned == (field >= public), "MOVE boundary and owner")
            rank = abs(bodies[a] - bodies[b])
            require(rank > 0, "expected strictly positive MOVE rank")
            moves.append((index, field, a, b, previous_touch[field], future_touches[index],
                          rank, row[field]))
            frame[field] = b
        elif code in ("ADD", "COPY"):
            other, coefficient, chart = event[2:]
            require(frame[field] == frame[other] == chart, "common frame for binary scalar contact")
            if code == "COPY":
                require(not row[field], "COPY destination zero")
                row[field] = mul(row[other], coefficient)
            else:
                row[field] = add(row[field], mul(row[other], coefficient))
        elif code == "SCALE":
            coefficient, chart = event[2:]
            require(frame[field] == chart, "SCALE chart")
            row[field] = mul(row[field], coefficient)
        else:
            raise ValueError(f"unexpected opcode {code}")
        for touched in op_fields(event):
            previous_touch[touched] = index
    require(frame[:public] == word["final"], "public final chart list")
    require(frame[public:] == [None] * owned, "all owned slots returned")
    require(len(moves) == 6276, "all retained native moves")
    return moves, opcode


def inspect_overlap(moves, public, deadline):
    by_destination = defaultdict(list)
    for move in moves:
        by_destination[move[3]].append(move)
    counts = Counter()
    dependencies = []
    source_pairs = Counter()
    no_span = None
    primitive = {move[0]: primitive_row(move[7]) for move in moves}
    for chart, items in sorted(by_destination.items()):
        require(time.monotonic() < deadline, "40-second source scan deadline")
        # Cut t is before operation t. A move can be put at the cut iff prev < t <= next.
        starts, endings = defaultdict(list), defaultdict(list)
        for entry in items:
            starts[entry[4] + 1].append(entry)
            endings[entry[5] + 1].append(entry)
        live = {}
        maximal = set()
        for cut in sorted(starts.keys() | endings.keys()):
            # Inspect maximal cliques just before they lose a member.
            if len(live) > 1 and cut in endings:
                maximal.add(tuple(sorted(live)))
            for entry in endings.get(cut, ()):
                del live[entry[0]]
            for entry in starts.get(cut, ()):
                # The previous or next touch prevents two movements of the same value
                # from being co-scheduled; check explicitly that fields differ in each pair.
                for other in live.values():
                    if entry[1] == other[1]:
                        continue
                    counts["concurrent_common_destination_pairs"] += 1
                    if entry[2] == other[2]:
                        counts["concurrent_identical_ordered_transition_pairs"] += 1
                        source_pairs[entry[6]] += 1
                    if not entry[7] or not other[7]:
                        counts["pair_containing_exact_zero"] += 1
                    elif primitive[entry[0]] == primitive[other[0]]:
                        counts["pair_proportional_nonzero"] += 1
                live[entry[0]] = entry
        by_index = {entry[0]: entry for entry in items}
        checked = []
        for indices in sorted(maximal, key=lambda idx: (-len(idx), idx)):
            index_set = set(indices)
            if any(index_set <= earlier for earlier in checked):
                continue
            checked.append(index_set)
            columns = [by_index[index] for index in indices]
            # At one cut a given field has exactly one independently movable version.
            if len({entry[1] for entry in columns}) != len(columns):
                continue
            counts["maximal_move_groups"] += 1
            counts["largest_group"] = max(counts["largest_group"], len(columns))
            rows = [entry[7] for entry in columns]
            residue = peel_rows(rows)
            peeled = len(rows) - len(residue)
            counts["largest_dense_residue"] = max(counts["largest_dense_residue"], len(residue))
            if not residue:
                counts["full_integer_rank_via_unique_columns"] += 1
                continue
            reduced_rank = peeled + modular_rank(residue, deadline)
            if reduced_rank == len(columns):
                counts["full_modular_rank_groups"] += 1
                if no_span is None:
                    no_span = [chart, list(indices)]
                continue
            reconstructed_rank = peeled + exact_rank(residue, deadline)
            require(reduced_rank <= reconstructed_rank, "modular rank lower-bounds exact rank")
            if reconstructed_rank == len(columns):
                counts["modular_false_dependence"] += 1
                continue
            counts["exactly_dependent_groups"] += 1
            dependencies.append({"destination": chart, "rank": reconstructed_rank,
                                 "moves": [{"event": entry[0], "field": entry[1],
                                            "source": entry[2], "rank": entry[6],
                                            "owned": entry[1] >= public,
                                            "lexical_row_size": len(entry[7])} for entry in columns]})
    return {"counts": counts, "identical_transition_pairs_by_rank": source_pairs,
            "first_independent_group": no_span, "dependent_groups": dependencies}


def caller_census(caller):
    """IDLE_ONE uses eight active axes per named stage; IDLE_ODD also uses the center."""
    by_type = Counter()
    for event in caller["events"]:
        if event[0] in ("A", "B") and event[1] in ("IDLE_ONE", "IDLE_ODD"):
            body = len(set(event[3]))
            require(body == len(event[3]), "distinct stage blocks")
            rank = 8 * body + (event[1] == "IDLE_ODD")
            by_type[(event[0], rank)] += 1
    require(sum(count * len(caller["types"][side]["ports"])
                for (side, _), count in by_type.items()) == 3392, "signed caller idle positions")
    return {f"{side}-rank{rank}": count for (side, rank), count in sorted(by_type.items())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("caller", type=Path)
    args = parser.parse_args()
    start = time.monotonic()
    control = controls()
    require(modular_rank([{0: PRIME}]) == 0 and exact_rank([{0: PRIME}]) == 1,
            "exact fallback rejects manufactured modular dependence")
    word = read_pinned(args.word, WORD_SHA, compressed=True)
    moves, opcodes = read_moves(word, start + 40)
    overlaps = inspect_overlap(moves, word["public"], start + 40)
    caller = read_pinned(args.caller, CALLER_SHA)
    result = {"word_sha256": WORD_SHA, "caller_sha256": CALLER_SHA,
              "controls": control, "opcodes": opcodes, "overlap": overlaps,
              "caller_template_idle_by_rank": caller_census(caller),
              "seconds": time.monotonic() - start}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
