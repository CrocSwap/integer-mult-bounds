# SPDX-License-Identifier: Apache-2.0
"""Compare exact chart-incidence screening on CPU and NVIDIA D3D11."""

from array import array
import argparse
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
from ctypes import POINTER, byref, c_int, c_long, c_size_t, sizeof
from ctypes import Structure, WinDLL
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import statistics
import subprocess
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
BACKEND_SHA = "7cbd7711df73af91f2514af91a6364f31b822955e4b3614e7eec4c5c81a289a2"
EARLY_SECONDS = 90
LANES = 32

HLSL = r"""
StructuredBuffer<uint> records : register(t0);
StructuredBuffer<uint> cases : register(t1);
RWStructuredBuffer<uint> saves : register(u0);
RWStructuredBuffer<uint> first : register(u1);

[numthreads(64,1,1)]
void main(uint i : SV_DispatchThreadID) {
    const uint u = cases[i*2];
    const uint v = cases[i*2+1];
    const uint masked = u ^ v;
    uint strikes = 0;
    uint least = 0xffffffffu;
    for (uint lane=0; lane<32; ++lane) {
        const uint covered = records[32*u+lane] | records[32*v+lane];
        const uint need = records[32*masked+lane];
        const uint lost = need & ~covered;
        strikes += countbits(lost);
        if (lost && least == 0xffffffffu) least = 32*lane + firstbitlow(lost);
    }
    saves[i] = strikes;
    first[i] = least;
}
"""


def need(condition, error):
    if not condition:
        raise ValueError(error)


class Memory(Structure):
    _fields_ = [("length", c_long), ("load", c_long), *[(f"quantity{i}", c_size_t) for i in range(7)]]


def ram_fraction():
    state = Memory()
    state.length = sizeof(state)
    memory_status = WinDLL("kernel32").GlobalMemoryStatusEx
    memory_status.argtypes = (POINTER(Memory),)
    memory_status.restype = c_int
    need(memory_status(byref(state)), "host memory status unavailable")
    return state.load / 100


def device_sample():
    fields = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=memory.used,memory.total,utilization.gpu", "--format=csv,noheader,nounits"],
        text=True, timeout=5, creationflags=0x08000000,
    ).strip().split(",")
    used, total, utilization = map(int, fields)
    return {"vram_mib": used, "vram_total_mib": total, "gpu_percent": utilization, "ram_fraction": ram_fraction()}


class Limit:
    def __init__(self):
        self.deadline = monotonic() + EARLY_SECONDS
        self.samples = []

    def poll(self, label):
        need(monotonic() < self.deadline, "deadline: " + label)
        need(ram_fraction() < .75, "host RAM threshold")

    def sample(self, label):
        self.poll(label)
        state = device_sample()
        need(state["vram_mib"] < .75 * state["vram_total_mib"], "GPU VRAM threshold")
        self.samples.append({"label": label, **state})


def rooted_word(path):
    spec = spec_from_file_location("temporal", HERE / "temporal_helper_floor.py")
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    word = module.pinned_json(path, module.WORD_SHA, True)
    return word, module


def pack_inputs(word, module, bound_data):
    actual = [chart for chart, data in bound_data["charts"].items() if data["joint"] > 0]
    need(len(actual) <= LANES * 32, "packed chart count")
    sets = [module.chart_space(word["frames"][int(c)]) for c in actual]
    containing = [0] * 512
    for index, space in enumerate(sets):
        for vector in space:
            containing[vector] |= 1 << index
    # A mixed binary direction may be present even when both original labels
    # are absent. This queries the chart incidence of that difference.
    return containing, actual, sets


def root_label_mask(index):
    return ((index * 0x25d41 + 0x162c9) & 0x3ffff)


def cpu_batch(table, rows):
    hits, first = array("I"), array("I")
    all_mask = (1 << (LANES * 32)) - 1
    for a, b in rows:
        gap = table[a ^ b] & (~(table[a] | table[b]) & all_mask)
        hits.append(gap.bit_count())
        first.append((gap & -gap).bit_length() - 1 if gap else 0xFFFFFFFF)
    return hits, first


def worker_piece(item):
    table, case = item
    return cpu_batch(table, case)


def gpu_batch(backend, device, packed, rows, guard):
    t0 = perf_counter()
    count = len(rows)
    padded = (count + 63) // 64 * 64
    cases = array("I", (v for pair in rows for v in pair))
    cases.extend([0] * (2 * (padded - count)))
    res = []
    com, checked, release = backend.com, backend.checked, backend.release
    P, U, PP = backend.P, backend.U, backend.PP
    ctx = device.context
    result = array("I", [0]) * padded
    first = array("I", [0]) * padded
    try:
        inputs = [device.buffer(len(a) * 4, 0, 8, 0, 64, 4, res) for a in (packed, cases)]
        outputs = [device.buffer(padded * 4, 0, 128, 0, 64, 4, res) for _ in range(2)]
        staging = [device.buffer(padded * 4, 3, 0, 0x20000, 0, 0, res) for _ in range(2)]
        input_views = (P * 2)(*(device.view(buffer, False, res) for buffer in inputs))
        output_views = (P * 2)(*(device.view(buffer, True, res) for buffer in outputs))
        event = device.query(0, res)
        for dst, data in zip(inputs, (packed, cases), strict=True):
            com(ctx, 48, None, (P, U, P, P, U, U), dst, 0, None, data.buffer_info()[0], 0, 0)
        com(ctx, 67, None, (U, U, PP), 0, 2, input_views)
        com(ctx, 68, None, (U, U, PP, P), 0, 2, output_views, None)
        com(ctx, 69, None, (P, PP, U), device.shader, None, 0)
        com(ctx, 41, None, (U, U, U), padded // 64, 1, 1)
        com(ctx, 68, None, (U, U, PP, P), 0, 2, (P * 2)(), None)
        for dst, src in zip(staging, outputs, strict=True):
            com(ctx, 47, None, (P, P), dst, src)
        com(ctx, 28, None, (P,), event)
        com(ctx, 111, None, ())
        device.wait_query(event, c_int(), guard)
        device.read(staging[0], result)
        device.read(staging[1], first)
        need(result[-1] == 0 or count == padded, "padding control")
        return (result[:count], first[:count]), (perf_counter() - t0) * 1000
    finally:
        com(ctx, 110, None, ())
        for ref in reversed(res):
            release(ref)


def launch(args):
    guard = Limit()
    guard.sample("before benchmark")
    spec = spec_from_file_location("d3d11", args.backend)
    need(sha256(args.backend.read_bytes()).hexdigest() == BACKEND_SHA, "backend pin")
    backend = module_from_spec(spec)
    spec.loader.exec_module(backend)
    backend.HLSL = HLSL
    word, module = rooted_word(args.word)
    bounds = json.loads(args.bounds.read_bytes())
    table, chart_ids, spaces = pack_inputs(word, module, bounds)
    packed = array("I", ((mask >> (32 * lane)) & 0xFFFFFFFF for mask in table for lane in range(LANES)))
    results = []
    device = backend.D3D11()
    try:
        initialize = perf_counter()
        device.open()
        device.compile()
        setup_ms = (perf_counter() - initialize) * 1000
        guard.sample("hardware initialized")
        for length in (256, 16384, 262144):
            guard.sample(f"before {length} pairs")
            masks = [root_label_mask(i) for i in range(length)]
            rows = [(mask >> 9, mask & 511) for mask in masks]
            serial_times, gpu_times = [], []
            for _ in range(3):
                t0 = perf_counter()
                expected = cpu_batch(table, rows)
                serial_times.append((perf_counter() - t0) * 1000)
                result, milliseconds = gpu_batch(backend, device, packed, rows, guard)
                gpu_times.append(milliseconds)
                need(result == expected, "GPU full exact integer comparison")
            record = {"cases": length, "CPUms": serial_times, "GPUms": gpu_times,
                      "medianCPUms": statistics.median(serial_times), "medianGPUms": statistics.median(gpu_times),
                      "passes_exactly": len(rows), "nonzero": sum(weight > 0 for weight in expected[0]),
                      "nonzero_distinct_nonzero_labels": sum(a and b and a != b and n > 0 for (a, b), n in zip(rows, expected[0], strict=True)),
                      "sha256": sha256(expected[0].tobytes() + expected[1].tobytes()).hexdigest()}
            if length == 262144:
                # Eight CPU processes can use independent work without sharing GPU resources.
                pieces = [rows[i:i + length // 8] for i in range(0, length, length // 8)]
                t0 = perf_counter()
                with ProcessPoolExecutor(max_workers=8) as pool:
                    outputs = list(pool.map(worker_piece, ((table, chunk) for chunk in pieces), timeout=30))
                loaded = (array("I"), array("I"))
                for first, second in outputs:
                    loaded[0].extend(first)
                    loaded[1].extend(second)
                need(loaded == expected, "eight-worker arithmetic crosscheck")
                record["eight_worker_cold_ms"] = (perf_counter() - t0) * 1000
                demand = [bounds["charts"][c]["joint"] for c in chart_ids]
                eligible = [i for i, (a, b) in enumerate(rows) if a and b and a != b]
                top = sorted(eligible, key=lambda i: expected[0][i], reverse=True)[:50]
                survivors = []
                for i in top:
                    a, b = rows[i]
                    matches = [j for j, space in enumerate(spaces) if a ^ b in space and a not in space and b not in space]
                    need(len(matches) == expected[0][i] and matches and matches[0] == expected[1][i],
                         "direct span witness")
                    survivors.append([a, b, len(matches), sum(demand[j] for j in matches)])
                record["direct_top_50_confirmations"] = survivors
            results.append(record)
            guard.sample(f"after {length} pairs")
    finally:
        device.close()
    guard.sample("context and CPU workers closed")
    result = {"status": "PASS_EXACT_D3D11_HELPER_COHORT_BENCHMARK", "adapter": device.adapter_name,
              "initialization_ms": setup_ms, "results": results, "samples": guard.samples}
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(result["status"], [(r["cases"], r["medianCPUms"], r["medianGPUms"]) for r in results])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("--word", "--backend", "--bounds", "--output"):
        parser.add_argument(flag, type=Path, required=True)
    launch(parser.parse_args())
