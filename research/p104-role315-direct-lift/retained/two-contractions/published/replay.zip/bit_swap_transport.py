# SPDX-License-Identifier: Apache-2.0
"""One-native dual-header swap budget with fixed charts and linear transport."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction as Q
import gzip
from hashlib import sha256
import json
from pathlib import Path
from time import monotonic


SOURCE_SHA = "51203e7fc75ba10bd3ac3f8e675759f47e13d262bea66b6600d1e515095cad78"
N_PORTS = 111


def need(ok, message):
    if not ok:
        raise ValueError(message)


def xor_rank(rows):
    pivots = {}
    for value in rows:
        while value:
            key = value.bit_length()
            if key not in pivots:
                pivots[key] = value
                break
            value ^= pivots[key]
    return len(pivots)


def rational_rank(rows):
    pivots = {}
    for row in rows:
        row = list(map(Q, row))
        for i in range(len(row)):
            value = row[i]
            if not value:
                continue
            if i not in pivots:
                pivots[i] = [x / value for x in row]
                break
            row = [x - value * y for x, y in zip(row, pivots[i], strict=True)]
    return len(pivots)


def prepare(word):
    frames = {int(key): value for key, value in word["frames"].items()}
    n = word["public"]
    initial = word["start"][:] + [None] * word["owned_fields"]
    active = initial[:]
    paid = Counter()
    moves = []
    for event, (op, role, *args) in enumerate(word["program"]):
        if op == "MOVE":
            old, new = args[:2]
            need(active[role] == old, "live source chart")
            # Every production MOVE in this word is nested; the rank is its gap.
            left, right = frames[old], frames[new]
            rank = abs(left["dim"] - right["dim"])
            need(rank > 0 and rational_rank(left["B"] + right["B"]) == max(left["dim"], right["dim"]),
                 f"nested paid frame pair at event {event}: {old} → {new}, rank {rank}")
            active[role] = new
            paid[rank] += 1
            moves.append((event, role, old, new, rank))
        elif op == "SWAP":
            other, = args
            active[role], active[other] = active[other], active[role]
        elif op in ("INIT", "CLEAR"):
            f, = args
            need(role >= n and active[role] == (None if op == "INIT" else f), "life boundary")
            active[role] = f if op == "INIT" else None
        elif op == "ADD":
            other, f = args
            need(active[role] == active[other] == f and role != other, "local scalar ADD")
        else:
            raise ValueError(f"Unexpected operation {op}")
    need(active[:n] == word["final"] and active[n:] == [None] * word["owned_fields"], "terminal charts")
    need(paid == {1: 1386, 2: 1253, 3: 62, 4: 47, 5: 9, 6: 104, 7: 10}, "source MOVE histogram")
    return frames, moves, paid


def endpoint(word, swapped):
    result = [1 << i for i in range(word["public"])]
    for i in range(N_PORTS):
        x, y = i, N_PORTS + i
        if swapped:
            result[x], result[y] = result[y], result[x]
        else:
            result[y] ^= result[x]
    return result


def replay_selected(word):
    n = word["public"]
    rows = [1 << r for r in range(n)] + [0] * word["owned_fields"]
    for op, role, *args in word["program"]:
        if op == "ADD":
            rows[role] ^= rows[args[0]]
        elif op == "SWAP":
            other = args[0]
            rows[role], rows[other] = rows[other], rows[role]
        elif op in ("INIT", "CLEAR"):
            rows[role] = 0
    need(rows == endpoint(word, False) + [0] * word["owned_fields"], "literal independent scalar replay")


def verify_boundary_shapes(word, frames):
    need(all(frame == 0 for frame in word["start"][N_PORTS:2 * N_PORTS]), "initial Y chart")
    need(all(frame == 1 for frame in word["final"][:N_PORTS]), "final X chart")
    need(frames[0]["dim"] == 0 and frames[1]["dim"] == 8, "zero and full charts")
    y_exits = word["final"][N_PORTS:2 * N_PORTS]
    need(len(set(y_exits)) == N_PORTS, "distinct Y exit charts")
    need(not any(a == 0 and b in set(y_exits)
                 for a, b in zip(word["start"][2 * N_PORTS:], word["final"][2 * N_PORTS:], strict=True)),
         "no helper in a 0-to-Y terminal block")
    for x, y in zip(word["start"][:N_PORTS], y_exits, strict=True):
        need(frames[x]["dim"] == 1 and frames[y]["dim"] == 7 and
             rational_rank(frames[x]["B"] + frames[y]["A"]) == 1, "complementary port axes")


def flux(word, end, frame_property, moves):
    inside_inputs = sum(1 << i for i, start in enumerate(word["start"]) if frame_property[start])
    outside_inputs = ((1 << word["public"]) - 1) ^ inside_inputs
    in_demand = xor_rank(row & outside_inputs for row, chart in zip(end, word["final"], strict=True)
                         if frame_property[chart])
    out_demand = xor_rank(row & inside_inputs for row, chart in zip(end, word["final"], strict=True)
                          if not frame_property[chart])
    inbound = outbound = 0
    for _, _, a, b, _ in moves:
        if frame_property[a] != frame_property[b]:
            if frame_property[b]:
                inbound += 1
            else:
                outbound += 1
    return [in_demand, in_demand - inbound, out_demand, out_demand - outbound]


def small_flux_control():
    word = {"public": 4, "start": [1, 0, 2, 0], "final": [3, 2, 3, 1]}
    # The same frames can demand a different number of external rows.
    # This example uses the real operator endpoints rather than a rank proxy.
    member = {0: False, 1: True, 2: False, 3: True}
    no_moves = []
    paid_arrivals = [(0, 0, 0, 3, 2), (1, 1, 0, 3, 2)]
    swap = [2, 1, 8, 4]
    unchanged = [1, 2, 4, 8]
    need(flux(word, swap, member, no_moves)[1] == 3, "cut deficit is observable")
    need(flux(word, unchanged, member, no_moves)[1] == 2, "rank depends on chart-labelled output")
    need(flux(word, swap, member, paid_arrivals)[1] == 1, "an added arrival contributes at most one")


def max_symbolic_reach(word):
    """A Boolean upper bound, allowing every same-frame ADD at every cut."""
    n = word["public"]
    place = word["start"][:] + [None] * word["owned_fields"]
    contents = [1 << i for i in range(n)] + [0] * word["owned_fields"]
    residents = defaultdict(set)
    union = defaultdict(int)
    for role, frame in enumerate(place):
        if frame is not None:
            residents[frame].add(role)
            union[frame] |= contents[role]

    def leave(role):
        frame = place[role]
        contents[role] = union[frame]
        residents[frame].remove(role)
        union[frame] = 0
        for other in residents[frame]:
            # Simultaneous complete mixing before a departure means all
            # remaining residents keep the union they held before it.
            contents[other] = contents[role]
            union[frame] |= contents[other]

    def enter(role, frame):
        place[role] = frame
        residents[frame].add(role)
        union[frame] |= contents[role]

    for op, role, *args in word["program"]:
        if op == "MOVE":
            leave(role)
            enter(role, args[1])
        elif op == "INIT":
            contents[role] = 0
            enter(role, args[0])
        elif op == "CLEAR":
            leave(role)
            place[role], contents[role] = None, 0
        elif op == "SWAP":
            other, = args
            f, g = place[role], place[other]
            leave(role)
            leave(other)
            contents[role], contents[other] = contents[other], contents[role]
            enter(role, g)
            enter(other, f)
    return [union[f] for f in place[:n]]


def small_paid_extensions(frames, membership_masks):
    """Find a common repair for all deficient cuts, charging at most one rank-one job."""
    full = (1 << N_PORTS) - 1
    covers = defaultdict(list)
    for frame, mask in membership_masks.items():
        covers[mask].append(frame)
    # With extra frames allowed at one end, a rank-one nested move can cover
    # every required cut only if its larger endpoint contains the entire span.
    # If that span is the ambient space, the larger endpoint is forced full.
    near_full = [f for f in frames if frames[f]["dim"] == 7 and membership_masks[f] == 0]
    candidates = []
    for outer in sorted(covers[full]):
        for dimension in (7, 6):
            for f, record in frames.items():
                if record["dim"] == dimension and not membership_masks[f]:
                    candidates.append([f, outer, 8 - dimension])
    return {
        "unknown_layout_one_job_necessary_form": "rank-seven head-free hyperplane to full",
        "canonical_full_frames": covers[full],
        "retained_rank_seven_head_free_frames": near_full,
        "retained_single_full_cut_repairs_through_rank_two": sorted(candidates),
        "a_new_hyperplane_needs_prior_nonzero_input": True,
    }


def generic_hyperplane(heads):
    """Find a low-height rational hyperplane avoiding every selected head."""
    rational_heads = [list(map(Q, head)) for head in heads]
    # Each nonzero head imposes a nonzero polynomial of degree at most 7.
    # The moment curve therefore has at most 7*111 forbidden base values.
    for base in range(1, 7 * N_PORTS + 2):
        normal = [base**k for k in range(8)]
        witnesses = [sum(a * b for a, b in zip(head, normal, strict=True)) for head in rational_heads]
        if all(witnesses):
            return {"base": base, "normal": normal, "norm_squared": sum(x * x for x in normal),
                    "nonzero_head_dot_products": list(map(str, witnesses))}
    raise ValueError("moment-curve root bound violated")


def min_cuts(word, frames, moves, deadline):
    changed, baseline = endpoint(word, True), endpoint(word, False)
    result = []
    # Threshold cuts are moments of the same invariant across a partial order.
    for d in range(1, 9):
        membership = {f: frame["dim"] >= d for f, frame in frames.items()}
        result.append([d, flux(word, baseline, membership, moves), flux(word, changed, membership, moves)])
    # Principal up-sets based on the source's rational head directions.
    principal = []
    masks = dict.fromkeys(frames, 0)
    heads = []
    owned_capacity = []
    public_moves = [move for move in moves if move[1] < word["public"]]
    owned_moves = [move for move in moves if move[1] >= word["public"]]
    public_upward = all(frames[a]["dim"] < frames[b]["dim"] for _, _, a, b, _ in public_moves)
    need(public_upward, "source public endpoint-cut budget requires upward MOVEs")
    chart_spans = {f: [tuple(map(Q, row)) for row in frame["A"]]
                   for f, frame in frames.items()}
    for i in range(N_PORTS):
        need(monotonic() < deadline, "principal-cut deadline")
        [head] = frames[word["start"][i]]["B"]
        heads.append(head)
        basis = tuple(map(Q, head))
        for f, complement in chart_spans.items():
            if all(sum(a * b for a, b in zip(basis, row, strict=True)) == 0 for row in complement):
                masks[f] |= 1 << i
        membership = {f: bool(mask & (1 << i)) for f, mask in masks.items()}
        prior, new = flux(word, baseline, membership, moves), flux(word, changed, membership, moves)
        need(prior[1] <= 0 and prior[3] <= 0, "selected endpoint breaks a cut")
        admitted_public = sum(membership[f] for f in word["final"]) - sum(membership[f] for f in word["start"])
        actual_public = sum(not membership[a] and membership[b] for _, _, a, b, _ in public_moves)
        actual_owned = sum(not membership[a] and membership[b] for _, _, a, b, _ in owned_moves)
        need(actual_public == admitted_public, "public principal cut conservation")
        need(actual_public + actual_owned == new[0] - new[1], "cut inputs partition by public ownership")
        principal.append([i, prior, new])
        owned_capacity.append([i, actual_public, actual_owned, new[0] - actual_public])
    return result, principal, masks, heads, owned_capacity


def price_control():
    spec_path = Path(__file__).with_name("helper_price.py")
    from runpy import run_path

    price = run_path(str(spec_path))
    saving = Q(".0227")
    paid = {1: 1386, 2: 1253, 3: 62, 4: 47, 5: 9, 6: 104, 7: 10}
    helpers_and_pair_outputs = {2: 1, 4: 25, 6: 1, 8: 410 + 222}
    cost = price["power_sum"]
    subtract = price["subtract"]
    margin = subtract(cost(helpers_and_pair_outputs, saving), cost(paid, saving))
    two_rank_ones = subtract(margin, cost({1: 2}, saving))
    rank_two = subtract(margin, cost({2: 1}, saving))
    need(margin[0] > price["SCALE"] and two_rank_ones[1] < 0 and rank_two[1] < 0,
         "one rank-one repair at most")
    return {"scale": price["SCALE"], "margin": margin, "with_two_rank_ones": two_rank_ones,
            "with_one_rank_two": rank_two}


def owned_rerouting_budget(frames, moves, masks, paid, public_fields):
    """Check whether a rank-one owned child can be redirected at the same tariff."""
    owned_roles = {move[1] for move in moves if move[1] >= public_fields}
    occupied = {f for _, r, a, b, _ in moves if r in owned_roles for f in (a, b)}
    owned = [edge for edge in moves if edge[1] in owned_roles]
    owned_histogram = Counter(rank for _, _, _, _, rank in owned)
    # Per port, every public ascent across its principal cut is already charged
    # by the boundary count. A true swap needs at least one new owned crossing.
    # Nesting limits a single crossing for all cuts to a full-chart arrival.
    possible_rank_one_origins = [f for f in occupied if frames[f]["dim"] == 7 and masks[f] == 0]
    highest_owned = max((frames[b]["dim"] for _, _, _, b, _ in owned), default=0)
    need(paid.total() == 2871, "complete selected MOVE count")
    return {
        "owned_movements": len(owned),
        "owned_rank_profile": dict(owned_histogram),
        "largest_owned_arrival_dimension": highest_owned,
        "retained_owned_rank_one_origins": possible_rank_one_origins,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    deadline = monotonic() + 75
    small_flux_control()
    raw = args.word.read_bytes()
    need(sha256(raw).hexdigest() == SOURCE_SHA, "native source bytes")
    word = json.loads(gzip.decompress(raw))
    frames, moves, paid = prepare(word)
    replay_selected(word)
    verify_boundary_shapes(word, frames)
    cuts, principal, masks, heads, owned_capacity = min_cuts(word, frames, moves, deadline)
    repair = small_paid_extensions(frames, masks)
    repair["head_span_rank"] = rational_rank(heads)
    repair["at_target_cost"] = price_control()
    repair["new_hyperplane_positive_control"] = generic_hyperplane(heads)
    repair["target_cost_rejection_with_all_original_moves"] = "at least two positive jobs or one with rank at least two"
    repair["owned_baseline"] = owned_rerouting_budget(frames, moves, masks, paid, word["public"])
    need(repair["head_span_rank"] == 8 and all(row[2][1] == 1 for row in principal), "one-entry deficits")
    reached = max_symbolic_reach(word)
    missing_x = [i for i in range(N_PORTS) if not reached[i] & (1 << (N_PORTS + i))]
    missing_y = [i for i in range(N_PORTS) if not reached[i + N_PORTS] & (1 << i)]
    need(not missing_y, "source shear is a positive reachability control")
    need(not repair["retained_rank_seven_head_free_frames"], "retained single-job repair has entered the candidate set")
    # Over-relaxation may return all Y data by pooling at the full chart.
    report = {
        "status": "PASS_BIT_SWAP_TRANSPORT_SCREEN",
        "word_sha256": SOURCE_SHA,
        "paid": paid,
        "threshold_cuts": cuts,
        "principal_cuts": principal,
        "owned_capacity": owned_capacity,
        "owned_capacity_row": ["port", "inbound_public_fixed_by_endpoints", "literal_inbound_owned", "required_inbound_owned"],
        "principal_cut_failures": [i for i, _, row in principal if row[1] > 0 or row[3] > 0],
        "single_extra_rank_one_move": repair,
        "free_same_frame_reachability_missing_swap_outputs": {"X": missing_x, "Y": missing_y},
        "cut_row": ["in_demand", "in_deficit", "out_demand", "out_deficit"],
    }
    args.output.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    print(report["status"], cuts, "principal failures", len(report["principal_cut_failures"]),
          "missing X under free mixing", len(missing_x), flush=True)


if __name__ == "__main__":
    main()
