"""Small Direct3D 11 integer compute backend used by the local benchmark."""

from array import array
from ctypes import (POINTER, Structure, WINFUNCTYPE, WinDLL, byref, cast,
                    c_char_p, c_int, c_long, c_size_t, c_uint, c_uint64, c_void_p,
                    c_wchar, memmove, sizeof, string_at)
from time import perf_counter_ns, sleep
from uuid import UUID


U, P, S = c_uint, c_void_p, c_size_t
PP = POINTER(P)
MIB = 1024*1024

HLSL = r'''
StructuredBuffer<uint> basis : register(t0);
StructuredBuffer<uint> candidates : register(t1);
StructuredBuffer<uint> pivots : register(t2);
RWStructuredBuffer<uint> reduced : register(u0);
RWStructuredBuffer<uint> heads : register(u1);
cbuffer Params : register(b0) { uint rank; uint width; uint2 padding; };
groupshared uint v[553];
groupshared uint first;
groupshared uint coeff;

uint mod_product(uint a, uint b) {
    // For p = 2^31-1, compute two 32-bit halves using 16-bit limbs.
    uint a0 = a & 65535u, a1 = a >> 16;
    uint b0 = b & 65535u, b1 = b >> 16;
    uint x = a0*b0, y = a0*b1 + a1*b0;
    uint lo = x + (y << 16);
    uint hi = a1*b1 + (y >> 16) + (lo < x ? 1u : 0u);
    uint fold = (lo & 2147483647u) + (hi << 1) + (lo >> 31);
    return fold >= 2147483647u ? fold - 2147483647u : fold;
}

[numthreads(128,1,1)]
void main(uint lane:SV_GroupIndex, uint3 group:SV_GroupID) {
    uint offset = group.x * width;
    if (lane == 0) first = width;
    for (uint j=lane; j<width; j+=128) v[j] = candidates[offset+j];
    GroupMemoryBarrierWithGroupSync();
    for (uint i=0; i<rank; ++i) {
        uint pivot = pivots[i];
        if (lane == 0) coeff = v[pivot];
        GroupMemoryBarrierWithGroupSync();
        if (coeff != 0) {
            for (uint j=pivot+lane; j<width; j+=128) {
                uint residue = mod_product(coeff, basis[i*width+j]);
                uint current = v[j];
                v[j] = current >= residue ? current-residue : current+2147483647u-residue;
            }
        }
        GroupMemoryBarrierWithGroupSync();
    }
    for (uint j=lane; j<width; j+=128) {
        uint value=v[j];
        reduced[offset+j]=value;
        if (value != 0) InterlockedMin(first,j);
    }
    GroupMemoryBarrierWithGroupSync();
    if (lane == 0) heads[group.x] = first == width ? 0xffffffffu : first;
}
'''


class AdapterDesc(Structure):
    _fields_ = [('description', c_wchar*128), ('vendor', U), ('device', U), ('subsystem', U), ('revision', U),
                ('dedicated', S), ('dedicated_system', S), ('shared_system', S), ('luid', c_uint64)]


class BufferDesc(Structure):
    _fields_ = [(name,U) for name in ('bytes','usage','bind','access','misc','stride')]


class MapData(Structure):
    _fields_ = [('data',P),('row_pitch',U),('depth_pitch',U)]


class DisjointData(Structure):
    _fields_ = [('frequency',c_uint64),('disjoint',c_int)]


def checked(result, label):
    if result < 0:
        raise RuntimeError(f'{label}: HRESULT 0x{result & 0xffffffff:08x}')
    return result


def com(ref, slot, returns, types, *args):
    vtable = cast(ref, POINTER(PP))[0]
    return WINFUNCTYPE(returns, P, *types)(vtable[slot])(ref,*args)


def release(ref):
    if ref.value:
        com(ref,2,U,())
        ref.value = None


def ms(start):
    return (perf_counter_ns()-start)/1e6


class D3D11:
    def __init__(self):
        self.device, self.context, self.shader = P(), P(), P()
        self.adapter_name = ''
        self.dedicated_mib = 0

    def open(self):
        # IID_IDXGIFactory; enumerate hardware and select NVIDIA explicitly.
        factory= P()
        adapter = P()
        desc = AdapterDesc()
        iid = UUID('7b7166ec-21c7-44ae-b21a-c9ae321ae369').bytes_le
        factory_fn = WinDLL('dxgi.dll').CreateDXGIFactory
        factory_fn.argtypes, factory_fn.restype = (c_char_p,PP), c_long
        checked(factory_fn(iid,byref(factory)), 'CreateDXGIFactory')
        try:
            for i in range(16):
                if com(factory,7,c_long,(U,PP),i,byref(adapter)) < 0:
                    raise RuntimeError('no NVIDIA RTX 5080 DXGI adapter')
                checked(com(adapter,8,c_long,(P,),byref(desc)), 'IDXGIAdapter.GetDesc')
                if desc.vendor == 0x10de and '5080' in desc.description:
                    break
                release(adapter)
            else:
                raise RuntimeError('no NVIDIA RTX 5080 DXGI adapter')
            fn = WinDLL('d3d11.dll').D3D11CreateDevice
            fn.argtypes, fn.restype = (P,U,P,U,POINTER(U),U,U,PP,POINTER(U),PP), c_long
            native_level = U(0xb000)
            actual_level = U()
            # An explicit hardware adapter and D3D_DRIVER_TYPE_UNKNOWN.
            checked(fn(adapter,0,None,1,byref(native_level),1,7,byref(self.device),byref(actual_level),byref(self.context)),
                    'D3D11CreateDevice')
            self.adapter_name = desc.description
            self.dedicated_mib = desc.dedicated // MIB
            self.feature_level = hex(actual_level.value)
        finally:
            release(adapter)
            release(factory)

    def compile(self):
        source = HLSL.encode('ascii')
        blob, error = P(), P()
        fn = WinDLL('d3dcompiler_47.dll').D3DCompile
        fn.argtypes, fn.restype = (c_char_p,S,c_char_p,P,P,c_char_p,c_char_p,U,U,PP,PP), c_long
        t = perf_counter_ns()
        try:
            hr = fn(source,len(source),b'return_screen.hlsl',None,None,b'main',b'cs_5_0',1<<15,0,byref(blob),byref(error))
            if hr < 0 and error.value:
                raise RuntimeError(string_at(com(error,3,P,()),com(error,4,S,())).decode(errors='replace'))
            checked(hr,'D3DCompile')
            compiled = ms(t)
            t = perf_counter_ns()
            checked(com(self.device,18,c_long,(P,S,P,PP),com(blob,3,P,()),com(blob,4,S,()),None,byref(self.shader)),
                    'CreateComputeShader')
            return compiled,ms(t)
        finally:
            release(error)
            release(blob)

    def buffer(self, size, usage, bind, access, misc, stride, resources):
        ref = P()
        desc = BufferDesc(size,usage,bind,access,misc,stride)
        checked(com(self.device,3,c_long,(P,P,PP),byref(desc),None,byref(ref)), 'CreateBuffer')
        resources.append(ref)
        return ref

    def view(self, buffer, output, resources):
        ref=P()
        checked(com(self.device,8 if output else 7,c_long,(P,P,PP),buffer,None,byref(ref)), 'Create compute buffer view')
        resources.append(ref)
        return ref

    def query(self, kind, resources):
        ref=P()
        desc=(U*2)(kind,0)
        checked(com(self.device,24,c_long,(P,PP),desc,byref(ref)), 'CreateQuery')
        resources.append(ref)
        return ref

    def wait_query(self, q, value, guard):
        start=perf_counter_ns()
        while checked(com(self.context,29,c_long,(P,P,U,U),q,byref(value),sizeof(value),0),'GetData') == 1:
            guard.poll('wait for bounded hardware compute dispatch')
            if ms(start) > 3000:
                raise RuntimeError('hardware query did not complete within three seconds')
            sleep(0.001)

    def read(self, buffer, dest):
        mapped = MapData()
        checked(com(self.context,14,c_long,(P,U,U,U,P),buffer,0,1,0,byref(mapped)), 'Map staging buffer')
        try:
            memmove(dest.buffer_info()[0],mapped.data,len(dest)*dest.itemsize)
        finally:
            com(self.context,15,None,(P,U),buffer,0)

    def dispatch(self, norm, mat, pivots, out, heads, width, guard):
        start = perf_counter_ns()
        res = []
        ctx = self.context
        constants = array('I',[len(pivots),width,0,0])
        inputs=(norm,mat,pivots,constants)
        sizes = [len(a)*a.itemsize for a in (*inputs,out,heads)]
        if len(heads)>65535 or width>553 or sum(sizes)+sum(sizes[4:])>48*MIB:
            raise ValueError('explicit buffer bound')
        try:
            buffers = [self.buffer(s,0,8,0,64,4,res) for s in sizes[:3]]
            buffers += [self.buffer(sizes[3],0,4,0,0,0,res)]
            outputs = [self.buffer(s,0,128,0,64,4,res) for s in sizes[4:]]
            staging = [self.buffer(s,3,0,0x20000,0,0,res) for s in sizes[4:]]
            srv=(P*3)(*(self.view(b,False,res) for b in buffers[:3]))
            uav=(P*2)(*(self.view(b,True,res) for b in outputs))
            cb=(P*1)(buffers[3])
            disjoint,before,after,event = (self.query(k,res) for k in (3,2,2,0))
            alloc=ms(start)
            t=perf_counter_ns()
            for buf, data in zip(buffers,inputs,strict=True):
                com(ctx,48,None,(P,U,P,P,U,U),buf,0,None,data.buffer_info()[0],0,0)
            upload_submit=ms(t)
            t=perf_counter_ns()
            com(ctx,28,None,(P,),event)
            self.wait_query(event,c_int(),guard)
            upload_completion=ms(t)
            t=perf_counter_ns()
            com(ctx,67,None,(U,U,PP),0,3,srv)
            com(ctx,68,None,(U,U,PP,P),0,2,uav,None)
            com(ctx,69,None,(P,PP,U),self.shader,None,0)
            com(ctx,71,None,(U,U,PP),0,1,cb)
            com(ctx,27,None,(P,),disjoint)
            com(ctx,28,None,(P,),before)
            com(ctx,41,None,(U,U,U),len(heads),1,1)
            com(ctx,28,None,(P,),after)
            com(ctx,28,None,(P,),disjoint)
            launch=ms(t)
            t=perf_counter_ns()
            com(ctx,68,None,(U,U,PP,P),0,2,(P*2)(),None)
            for dst, src in zip(staging,outputs,strict=True):
                com(ctx,47,None,(P,P),dst,src)
            com(ctx,28,None,(P,),event)
            read_submit=ms(t)
            t=perf_counter_ns()
            self.wait_query(event,c_int(),guard)
            sync=ms(t)
            t=perf_counter_ns()
            self.read(staging[0],out)
            self.read(staging[1],heads)
            readback=ms(t)
            span, a, b = DisjointData(), c_uint64(), c_uint64()
            for q, value in ((disjoint,span),(before,a),(after,b)):
                self.wait_query(q,value,guard)
            kernel = (b.value-a.value)*1000/span.frequency if span.frequency and not span.disjoint else None
            return {'allocationMs':alloc,'uploadSubmitMs':upload_submit,'uploadCompletionWaitMs':upload_completion,
                    'dispatchSubmitMs':launch,
                    'copyToStagingSubmitMs':read_submit,'synchronizeMs':sync,'readbackMs':readback,
                    'gpuTimestampKernelMs':kernel,'explicitDeviceAndStagingBytes':sum(sizes)+sum(sizes[4:])}
        finally:
            com(ctx,110,None,())
            for ref in reversed(res):
                release(ref)

    def close(self):
        if self.context.value:
            com(self.context,110,None,())
            com(self.context,111,None,())
        release(self.shader)
        release(self.context)
        release(self.device)
