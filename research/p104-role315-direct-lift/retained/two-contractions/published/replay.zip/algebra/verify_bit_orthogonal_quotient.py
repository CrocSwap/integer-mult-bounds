"""Exact finite controls for one weighted child on an orthogonal BIT quotient."""

from fractions import Fraction
import json
import random


def need(condition, message):
    if not condition:
        raise ValueError(message)


class Arithmetic:
    def __init__(self, modulus=None):
        self.modulus = modulus

    def scalar(self, value):
        value = Fraction(value)
        if self.modulus is None:
            return value
        return value.numerator * pow(value.denominator, -1, self.modulus) % self.modulus

    def inverse_unit(self, value):
        if self.modulus is None:
            return 1 / Fraction(value)
        return pow(value, -1, self.modulus)

    def matrix(self, rows):
        return [[self.scalar(x) for x in row] for row in rows]

    def eye(self, n):
        return self.matrix([[int(i == j) for j in range(n)] for i in range(n)])

    def mul(self, a, b):
        bt = list(zip(*b))
        return self.matrix([[sum(u * v for u, v in zip(x, y)) for y in bt] for x in a])

    def combine(self, a, b, sign=1):
        return self.matrix([[x + sign * y for x, y in zip(u, v)] for u, v in zip(a, b)])

    def scale(self, a, c):
        return self.matrix([[c * x for x in row] for row in a])

    def invert(self, matrix):
        n = len(matrix)
        padded = [list(row) + ir for row, ir in zip(matrix, self.eye(n))]
        for col in range(n):
            pivot = None
            for idx in range(col, n):
                try:
                    pivot = idx, self.inverse_unit(padded[idx][col])
                    break
                except (ZeroDivisionError, ValueError):
                    continue
            need(pivot is not None, "nonunit matrix")
            idx, inv = pivot
            padded[col], padded[idx] = padded[idx], padded[col]
            padded[col] = [self.scalar(inv * x) for x in padded[col]]
            for i in range(n):
                if i == col:
                    continue
                factor = padded[i][col]
                padded[i] = [self.scalar(x - factor * y) for x, y in zip(padded[i], padded[col])]
        return [row[n:] for row in padded]


def transpose(a):
    return [list(col) for col in zip(*a)]


def block(a, b, c, d):
    return [x + y for x, y in zip(a, b)] + [x + y for x, y in zip(c, d)]


def diagonals(a, b):
    za = [[0] * len(a) for _ in b]
    return block(a, transpose(za), za, b)


def corner(a):
    n = len(a) // 2
    return [row[n:] for row in a[:n]]


def reverse_matrix(n):
    return [[int(i + j == n - 1) for j in range(n)] for i in range(n)]


def diagonal(values):
    return [[c if i == j else 0 for j in range(len(values))]
            for i, c in enumerate(values)]


def lower_unit(a):
    return all(x == int(i == j) for i, row in enumerate(a)
               for j, x in enumerate(row) if j >= i)


def rational_ldlt(ar, gram):
    """Unnormalized row Gram-Schmidt; requires every leading minor a unit."""
    n = len(gram)
    lower = ar.eye(n)
    rows = [x[:] for x in gram]
    for k in range(n):
        pivot = ar.inverse_unit(rows[k][k])
        for i in range(k + 1, n):
            factor = ar.scalar(-rows[i][k] * pivot)
            rows[i] = [ar.scalar(x + factor * y) for x, y in zip(rows[i], rows[k])]
            lower[i] = [ar.scalar(x + factor * y) for x, y in zip(lower[i], lower[k])]
    diag = ar.mul(ar.mul(lower, gram), transpose(lower))
    need(diag == diagonal([diag[i][i] for i in range(n)]), "Gram normalization failed")
    return lower


def orthogonal_chart(ar, g):
    lower = rational_ldlt(ar, ar.mul(g, transpose(g)))
    return ar.mul(lower, g)


def north_east(ar, matrix, rank):
    """Unit lower row/column additions at pivots (i, n-1-i)."""
    n = len(matrix)
    left, right = ar.eye(n), ar.eye(n)
    m = [row[:] for row in matrix]
    pivots = []
    for i in range(rank):
        j = n - 1 - i
        pivot = m[i][j]
        pivots.append(pivot)
        inv = ar.inverse_unit(pivot)
        for k in range(i + 1, n):
            c = ar.scalar(-m[k][j] * inv)
            m[k] = [ar.scalar(a + c * b) for a, b in zip(m[k], m[i])]
            left[k] = [ar.scalar(a + c * b) for a, b in zip(left[k], left[i])]
        for k in range(j):
            c = ar.scalar(-m[i][k] * inv)
            for s in range(n):
                m[s][k] = ar.scalar(m[s][k] + c * m[s][j])
                right[s][k] = ar.scalar(right[s][k] + c * right[s][j])
    expected = ar.matrix([[pivots[i] if i < rank and i + j == n - 1 else 0
                           for j in range(n)] for i in range(n)])
    need(m == expected, "split rank or northeast pivots failed")
    need(ar.mul(ar.mul(left, matrix), right) == expected, "bad northeast factors")
    return left, right, pivots


def split_operator(ar, u, weights):
    n = len(u)
    half = ar.inverse_unit(2)
    a = ar.scale(ar.combine(ar.eye(n), u, -1), half)
    same = ar.combine(ar.eye(n), a, -1)
    full = block(same, a, a, same)
    t = diagonals(diagonal(weights), reverse_matrix(n))
    return ar.mul(ar.mul(t, full), ar.invert(t))


def cross_shear(ar, k):
    n = len(k)
    return block(ar.eye(n), [[0] * n for _ in range(n)], k, ar.eye(n))


def make_weighted_child(ar, n, pivots):
    rank = len(pivots)
    same_head = diagonal([0] * rank + [1] * (n - rank))
    same_tail = diagonal([1] * (n - rank) + [0] * rank)
    forward = [[pivots[i] if i < rank and i + j == n - 1 else 0
                for j in range(n)] for i in range(n)]
    inverse = [[ar.inverse_unit(pivots[j]) if j < rank and i + j == n - 1 else 0
                for j in range(n)] for i in range(n)]
    return block(same_head, forward, inverse, same_tail)


def compile_one(ar, g, rank):
    """Return ordered normalizers and the actual literal one-child matrix."""
    n = len(g) // 2
    l, r, pivots = north_east(ar, corner(g), rank)
    _, _, inverse_pivots = north_east(ar, corner(ar.invert(g)), rank)
    need(inverse_pivots == pivots, "forward and inverse cross minors differ")
    q = diagonals(l, ar.invert(r))
    qinv = diagonals(ar.invert(l), r)
    gp = ar.mul(ar.mul(q, g), qinv)
    h = ar.combine(gp, ar.eye(2 * n), -1)
    a = [row[:n] for row in h[:rank]]
    d = diagonal(pivots)
    dinv = diagonal([ar.inverse_unit(x) for x in pivots])
    e = [row[:rank] for row in ar.eye(n)]
    f = [row[:rank] for row in reverse_matrix(n)]
    et, ft = transpose(e), transpose(f)
    b = ar.mul(ar.mul([row[n:] for row in h[n:]], f), dinv)
    need(h == ar.mul(e + b, [u + v for u, v in zip(a, ar.mul(d, ft))]),
         "split rank factorization failed")
    t = ar.combine(ar.combine(ar.eye(rank), ar.mul(a, e)),
                   ar.mul(ar.mul(d, ft), b))
    j = ar.scale(ar.mul(dinv, t), -1)
    k_left = ar.combine(ar.scale(ar.mul(ar.combine(b, ar.mul(f, dinv)), et), -1),
                        ar.mul(ar.mul(ar.mul(f, dinv), a),
                               ar.combine(ar.eye(n), ar.mul(e, et), -1)))
    k_right = ar.combine(ar.mul(ar.mul(f, ar.combine(j, dinv, -1)), et), k_left, -1)
    mid = ar.mul(ar.mul(cross_shear(ar, k_left), gp), cross_shear(ar, k_right))
    d_corner = corner(mid)
    j_corner = ar.mul(ar.mul(ft, [row[:n] for row in mid[n:]]), e)
    need(j_corner == j, "wrong active backward block")
    lower, rev_upper, middle_pivots = north_east(
        ar, ar.mul(ar.invert(j), reverse_matrix(rank)), rank)
    need(middle_pivots == pivots, "active reverse pivots changed")
    upper = ar.mul(ar.mul(reverse_matrix(rank), rev_upper), reverse_matrix(rank))
    h_right = ar.combine(ar.combine(ar.eye(n), ar.mul(e, et), -1),
                         ar.mul(ar.mul(e, ar.invert(lower)), et))
    t_left = ar.combine(ar.combine(ar.eye(n), ar.mul(f, ft), -1),
                        ar.mul(ar.mul(f, ar.invert(upper)), ft))
    z_left = diagonals(ar.eye(n), t_left)
    z_right = diagonals(h_right, ar.eye(n))
    left = ar.mul(ar.mul(z_left, cross_shear(ar, k_left)), q)
    right = ar.mul(ar.mul(qinv, cross_shear(ar, k_right)), z_right)
    child = make_weighted_child(ar, n, pivots)
    need(lower_unit(left) and lower_unit(right), "normalizers require nonordinary move")
    need(ar.mul(ar.mul(left, g), right) == child, "full one-child operator mismatch")
    need(ar.mul(child, child) == ar.eye(2 * n), "child is not a weighted involution")
    return left, child, right


def reflection(ar, v):
    n = len(v)
    norm = ar.scalar(sum(x * x for x in v))
    h = ar.scale(ar.matrix([[x * y for y in v] for x in v]), ar.inverse_unit(norm))
    return ar.combine(ar.eye(n), ar.scale(h, 2), -1)


def embed(matrices, n, f):
    """Embed one complete per-column map, respecting reverse pairing in tail."""
    result = [[0] * (2 * n * f) for _ in range(2 * n * f)]
    for c, matrix in enumerate(matrices):
        ix = [i * f + c for i in range(n)] + [(n + i) * f + f - 1 - c for i in range(n)]
        for i in range(2 * n):
            for j in range(2 * n):
                result[ix[i]][ix[j]] = matrix[i][j]
    return result


def nonsymmetric_fixture():
    ar = Arithmetic()
    p = reflection(ar, [1, 0])
    q = reflection(ar, [1, 1])
    u = ar.mul(p, q)
    h = ar.matrix([[1, 1], [0, 1]])
    gu = ar.mul(ar.mul(h, u), ar.invert(h))
    g = split_operator(ar, gu, [1, 1])
    _, _, before = north_east(ar, corner(g), 2)
    inverse = corner(ar.invert(g))
    return g, before, inverse[0][-1]


def with_weights(ar, u, weights, rank):
    n = len(u)
    f = len(weights)
    originals = [split_operator(ar, u, w) for w in weights]
    triples = [compile_one(ar, original, rank) for original in originals]
    left, middle, right = [embed(m, n, f) for m in zip(*triples)]
    expected = make_weighted_child(
        ar, n * f, [triples[j][1][i][2 * n - 1 - i]
                    for i in range(rank) for j in range(f)])
    need(middle == expected, "noncontiguous middle or wrong tail column")
    original = embed(originals, n, f)
    need(ar.mul(ar.mul(left, original), right) == middle, "full tensor-width check failed")
    return 2 * n * f


def main():
    rng = random.Random(14337)
    g, before, inverse_pivot = nonsymmetric_fixture()
    need(before == [1, Fraction(1, 2)] and inverse_pivot == 0, "wrong mutation fixture")
    try:
        compile_one(Arithmetic(), g, 2)
    except ZeroDivisionError:
        pass
    else:
        raise ValueError("unrestricted GL chart was silently admitted")

    g = Arithmetic().matrix([[0, 2], [3, 0]])
    try:
        compile_one(Arithmetic(), g, 1)
    except ValueError as error:
        need("cross minors differ" in str(error), "wrong wrong-reciprocity exception")
    else:
        raise ValueError("nonreciprocal child was silently admitted")

    cases = []
    total_columns = 0
    for n, v, t, header in (
        (2, [1, 0], [1, 1], [[1, 1], [2, 3]]),
        (3, [1, 2, 0], [0, 1, 1], [[2, 0, 1], [0, 1, 1], [1, 1, 1]]),
        (4, [1, 1, 2, 3], [2, 1, 0, 1],
         [[1, 1, 0, 1], [0, 1, 1, 1], [1, 0, 1, 1], [2, 1, 1, 0]]),
    ):
        for modulus in [None, 101, 101**2, 1009**3]:
            ar = Arithmetic(modulus)
            header = ar.matrix(header)
            r = reflection(ar, v)
            u = ar.mul(r, reflection(ar, t))
            b = orthogonal_chart(ar, header)
            br = orthogonal_chart(ar, ar.mul(header, r))
            need(br == ar.mul(b, r), "normalization failed right-route covariance")
            u = ar.mul(ar.mul(b, u), ar.invert(b))
            need(ar.mul(u, u) != ar.eye(n), "fixture accidentally involutory")
            for f in range(1, 4):
                weights = [[rng.choice([1, 2, -1, 3, -4]) for _ in range(n)] for _ in range(f)]
                total_columns += with_weights(ar, u, weights, 2)
            cases.append({"n": n, "modulus": modulus, "multiplicities": [1, 2, 3]})
    print(json.dumps({"status": "PASS_BIT_ORTHOGONAL_QUOTIENT",
                      "cases": cases, "complete_columns": total_columns,
                      "unrestricted_gl_control": {"forward_pivots": [str(x) for x in before],
                                                  "inverse_first_pivot": str(inverse_pivot)},
                      "nonreciprocal_control": "rank-one forward 2 vs inverse 1/3"},
                     indent=2))


if __name__ == "__main__":
    main()
