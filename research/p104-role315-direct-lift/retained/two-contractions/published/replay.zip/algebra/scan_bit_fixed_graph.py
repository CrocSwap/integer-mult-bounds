"""Test nonnested BIT frame reassignment in the exact #7001 contact graph."""

from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
import json
import sys
from pathlib import Path
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from scan_bit_move_runs import basis, load_word


def need(condition, message):
    if not condition:
        raise ValueError(message)


def make_graph(word):
    visits = []
    parents = []
    pinned = []

    def new(f):
        parents.append(len(visits))
        visits.append(f)
        return len(visits) - 1

    def find(a):
        while parents[a] != a:
            parents[a] = parents[parents[a]]
            a = parents[a]
        return a

    def join(a, b):
        need(visits[a] == visits[b], "unequal original contact")
        parents[find(a)] = find(b)

    at = [new(f) for f in word["start"]] + [None] * word["owned_fields"]
    pinned.extend(v for v in at if v is not None)
    edges = []
    for i, event in enumerate(word["program"]):
        op, field, *tail = event
        if op == "MOVE":
            src, dst = tail
            need(visits[at[field]] == src, "wrong move entrance")
            other = new(dst)
            edges.append((at[field], other, i))
            at[field] = other
        elif op == "ADD":
            src, frame = tail
            need(visits[at[field]] == frame, "wrong scalar frame")
            join(at[field], at[src])
        elif op == "SWAP":
            src, = tail
            at[field], at[src] = at[src], at[field]
        elif op == "INIT":
            need(at[field] is None, "live owned field initialized")
            at[field] = new(tail[0])
            pinned.append(at[field])
        elif op == "CLEAR":
            need(visits[at[field]] == tail[0], "wrong clear")
            pinned.append(at[field])
            at[field] = None
        else:
            raise ValueError(f"unhandled opcode {op}")

    need([None if f is None else visits[f] for f in at]
         == word["final"] + [None] * word["owned_fields"], "wrong final frames")
    pinned.extend(v for v in at if v is not None)
    fixed = {find(v) for v in pinned}
    roots = {v: visits[v] for v in range(len(parents)) if parents[v] == v}
    edges = [(find(a), find(b), i) for a, b, i in edges]
    return visits, roots, fixed, edges


def price_key(rows):
    return {i: sum(count * min(r, i) for r, count in rows.items()) for i in range(1, 9)}


def supported_interval(rank, saving):
    """Enclose r**(1-saving) with rational log and reciprocal-exp series."""
    shift = rank.bit_length() - 1

    def logarithm(value):
        x = (value - 1) / (value + 1)
        n = 64
        lo = sum(2 * x**(2 * j + 1) / (2 * j + 1) for j in range(n))
        hi = lo + 2 * x**(2 * n + 1) / ((2 * n + 1) * (1 - x * x))
        return lo, hi

    pow_lo, pow_hi = logarithm(Fraction(2))
    rank_lo, rank_hi = logarithm(Fraction(rank, 1 << shift))
    log_lo = shift * pow_lo + rank_lo
    log_hi = shift * pow_hi + rank_hi

    def exp_interval(t):
        lo = term = Fraction(1)
        for j in range(1, 29):
            term = term * t / j
            lo += term
        need(t < 29, "exponential enclosure outside declared tail domain")
        return lo, lo + term * t / (29 - t)

    scale = 2**80
    lo = Fraction(rank, exp_interval(log_hi * saving)[1]) * scale
    hi = Fraction(rank, exp_interval(log_lo * saving)[0]) * scale
    return lo.numerator // lo.denominator, -(-hi.numerator // hi.denominator)


def inverse(matrix):
    n = len(matrix)
    q = [[Fraction(c) for c in row] + [Fraction(i == j) for j in range(n)]
         for i, row in enumerate(matrix)]
    for i in range(n):
        k = next((j for j in range(i, n) if q[j][i]), None)
        need(k is not None, "singular basis")
        q[k], q[i] = q[i], q[k]
        q[i] = [x / q[i][i] for x in q[i]]
        for j in range(n):
            if i != j and q[j][i]:
                f = q[j][i]
                q[j] = [a - f * b for a, b in zip(q[j], q[i])]
    return [row[n:] for row in q]


def projector_frame(rows):
    if not rows:
        return [[Fraction(0)] * 8 for _ in range(8)]
    transpose = list(zip(*rows))
    gram = [[sum(x * y for x, y in zip(a, b)) for b in rows] for a in rows]
    inv = inverse(gram)
    left = [[sum(x * y for x, y in zip(a, b)) for b in zip(*inv)] for a in transpose]
    return [[sum(x * y for x, y in zip(a, b)) for b in transpose] for a in left]


def analyze(word):
    started = time.monotonic()
    visits, charts, fixed, edges = make_graph(word)
    frames = {int(label): (entry["dim"], entry["B"], entry["A"])
              for label, entry in word["frames"].items()}
    labels = sorted(frames)
    adjacent = defaultdict(Counter)
    for a, b, _ in edges:
        need(a != b, "self constraint")
        adjacent[a][b] += 1
        adjacent[b][a] += 1

    @lru_cache(None)
    def distance(a, b):
        da, rows_a, _ = frames[a]
        db, rows_b, _ = frames[b]
        return 2 * len(basis(rows_a + rows_b)) - da - db

    @lru_cache(None)
    def projector(i):
        return projector_frame(frames[i][1])

    @lru_cache(None)
    def commute(a, b):
        p, q = projector(a), projector(b)
        for row in range(8):
            for col in range(row + 1, 8):
                # Since P,Q symmetric, PQ=QP iff PQ is symmetric.
                if sum(p[row][k] * q[k][col] - p[col][k] * q[k][row]
                       for k in range(8)):
                    return False
        return True

    candidates = []
    commuting_candidates = []
    census = Counter()
    sensitivity = {}
    price_cache = {}
    for decimal in ("0.00385248", "0.0040075385047236", "0.0227"):
        price_intervals = [None] + [supported_interval(r, Fraction(decimal)) for r in range(1, 9)]
        sensitivity[decimal] = price_intervals, Counter()
    interval_zero, _ = next(iter(sensitivity.values()))
    local_lower = {}
    for v, old in charts.items():
        if v in fixed:
            continue
        neighbor_frames = Counter()
        for node, multiplicity in adjacent[v].items():
            neighbor_frames[charts[node]] += multiplicity
        need(bool(neighbor_frames), "unused coframe component")
        old_bill = Counter()
        for q, multiplicity in neighbor_frames.items():
            r = distance(min(old, q), max(old, q))
            need(r == abs(frames[old][0] - frames[q][0]) and r > 0,
                 "original transition was not nested")
            old_bill[r] += multiplicity

        baseline = price_key(old_bill)
        census[len(neighbor_frames)] += 1
        penalties = {}
        for proposed in labels:
            if proposed == old:
                continue
            new_bill = Counter()
            for q, multiplicity in neighbor_frames.items():
                r = distance(min(proposed, q), max(proposed, q))
                if r:
                    new_bill[r] += multiplicity
            price = price_key(new_bill)
            delta = {r: baseline[r] - price[r] for r in baseline}
            differences = tuple((k, old_bill[k] - new_bill[k])
                                for k in sorted(old_bill.keys() | new_bill.keys())
                                if old_bill[k] != new_bill[k])
            if differences not in price_cache:
                rating = []
                for intervals, _ in sensitivity.values():
                    lo = sum(d * intervals[k][0 if d > 0 else 1] for k, d in differences)
                    hi = sum(d * intervals[k][1 if d > 0 else 0] for k, d in differences)
                    rating.append("positive" if lo > 0 else "negative" if hi < 0
                                  else "unresolved" if differences else "same_invoice")
                first_upper = sum(d * interval_zero[k][1 if d > 0 else 0] for k, d in differences)
                price_cache[differences] = rating, -first_upper
            decisions, penalty = price_cache[differences]
            penalties[proposed] = penalty
            for decision, (_, statistics) in zip(decisions, sensitivity.values()):
                statistics[decision] += 1
            if delta[8] < 0 or (delta[8] == 0 and max(delta.values()) <= 0):
                continue
            commutes = all(commute(proposed, q) for q in neighbor_frames)
            row = dict(node=v, old=old, new=proposed, neighbor_frames=dict(neighbor_frames),
                       old_bill=dict(old_bill), new_bill=dict(new_bill), deltas=delta,
                       commuting=commutes,
                       nonnested=sum(multiplicity for q, multiplicity in neighbor_frames.items()
                                     if distance(min(proposed, q), max(proposed, q))
                                     != abs(frames[proposed][0] - frames[q][0])))
            if commutes:
                commuting_candidates.append(row)
            candidates.append(row)
        local_lower[v] = penalties

    pair_lower = Counter()
    pair_nodes = 0
    for u, old_u in charts.items():
        if u in fixed:
            continue
        possible = local_lower[u]
        for v, multiplicity in adjacent[u].items():
            if v <= u or v in fixed:
                continue
            pair_nodes += 1
            old_v = charts[v]
            other = local_lower[v]
            old_distance = distance(min(old_u, old_v), max(old_u, old_v))
            old_lower = interval_zero[old_distance][0]
            min_other = min(other.values())
            for new_u, du in possible.items():
                a = distance(min(new_u, old_v), max(new_u, old_v))
                a_upper = interval_zero[a][1] if a else 0
                # Triangle inequality lowers the correction by -2*min of
                # the two old-to-new distances (in the concave rank metric).
                moved_u = distance(min(new_u, old_u), max(new_u, old_u))
                moved_upper = interval_zero[moved_u][1] if moved_u else 0
                if du + min_other - 2 * multiplicity * moved_upper > 0:
                    pair_lower["triangle_negative"] += len(other)
                    continue
                for new_v, dv in other.items():
                    b = distance(min(old_u, new_v), max(old_u, new_v))
                    b_upper = interval_zero[b][1] if b else 0
                    # Drop the nonnegative jointly reassigned edge cost.
                    if du + dv + multiplicity * (old_lower - a_upper - b_upper) > 0:
                        pair_lower["zero_edge_negative"] += 1
                        continue
                    c = distance(min(new_u, new_v), max(new_u, new_v))
                    c_lower = interval_zero[c][0] if c else 0
                    lower = du + dv + multiplicity * (old_lower + c_lower - a_upper - b_upper)
                    if lower > 0:
                        pair_lower["full_negative"] += 1
                        continue
                    pair_lower["unresolved_or_improved"] += 1
                    if pair_lower["unresolved_or_improved"] <= 5:
                        pair_lower[f"fixture {u} {v} {new_u} {new_v}"] = int(lower)

    anchor_dual = {}
    for v, local in local_lower.items():
        internal = sum(count for u, count in adjacent[v].items() if u not in fixed)
        subsidies = []
        for new, penalty in local.items():
            if internal == 0:
                subsidies.append(penalty)
                continue
            d = distance(min(charts[v], new), max(charts[v], new))
            subsidies.append(penalty - internal * interval_zero[d][1])
        anchor_dual[v] = min(subsidies)

    metric = [[0] * len(labels) for _ in labels]
    for ia, a in enumerate(labels):
        for ib, b in enumerate(labels[:ia]):
            r = distance(b, a)
            metric[ia][ib] = metric[ib][ia] = r
    chart_index = {f: i for i, f in enumerate(labels)}
    lower = [0] + [interval_zero[k][0] for k in range(1, 9)]
    upper = [0] + [interval_zero[k][1] for k in range(1, 9)]
    separable = {v: {a: loss for a, loss in rr.items()} for v, rr in local_lower.items()}
    checks = Counter()
    for u, old_u in charts.items():
        if u in fixed:
            continue
        for v, count in adjacent[u].items():
            if v <= u or v in fixed:
                continue
            old_v = charts[v]
            ru, rv = metric[chart_index[old_u]], metric[chart_index[old_v]]
            old_lb = lower[ru[chart_index[old_v]]]
            for a in local_lower[u]:
                # Give half of baseline-to-single endpoint displacement to
                # this endpoint. Drop the joint edge cost, which is >=0.
                ca = max(0, 2 * upper[rv[chart_index[a]]] - old_lb)
                separable[u][a] -= (count * ca + 1) // 2
            for b in local_lower[v]:
                cb = max(0, 2 * upper[ru[chart_index[b]]] - old_lb)
                separable[v][b] -= (count * cb + 1) // 2
    checks["components_negative"] = sum(min(x.values()) < 0 for x in separable.values())
    checks["minimum"] = min(min(x.values()) for x in separable.values()) / 2**80

    def strongest(rows):
        return sorted(rows, key=lambda row: (
            row["deltas"][8], min(row["deltas"].values()), row["deltas"][1]),
                      reverse=True)[:30]

    return {"visits": len(visits), "coframe_components": len(charts),
            "fixed_components": len(fixed), "free_components": len(charts) - len(fixed),
            "moves": len(edges), "catalogue": len(labels),
            "neighbors_per_free_component": dict(sorted(census.items())),
            "candidates": len(candidates), "commuting_candidates": len(commuting_candidates),
            "strongest": strongest(candidates), "strongest_commuting": strongest(commuting_candidates),
            "rational_price_intervals": {k: statistics for k, (_, statistics) in sensitivity.items()},
            "unique_rank_profile_differences": len(price_cache),
            "pair_edges": pair_nodes,
            "adjacent_pair_certification_at_00385248": pair_lower,
            "global_triangle_dual": {
                "isolated_or_covered": sum(v >= 0 for v in anchor_dual.values()),
                "minimum": min(anchor_dual.values()) / 2**80,
            },
            "global_separable_zero_edge_dual": checks,
            "exact_span_cache_entries": distance.cache_info().currsize,
            "seconds": time.monotonic() - started}


if __name__ == "__main__":
    print(json.dumps(analyze(load_word()), indent=2))
