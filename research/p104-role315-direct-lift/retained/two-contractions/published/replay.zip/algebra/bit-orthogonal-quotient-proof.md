# One reciprocal BIT child for an orthogonal frame quotient

The retained BIT compiler lowers a nested difference of two partial swaps to a single weighted reversed interchange. Its written normalizer assumes the difference is an involution. A quotient between two nonnested orthogonal frames can instead rotate the difference coordinates. The following criterion characterizes when the same one-child interface applies despite this.

## Exact normal-form criterion

Let the two banks have dimension \(m\) over \(\mathbb Q\) or an odd-ring atom field \(\mathbb Z/q^w\mathbb Z\). Let \(G\) be the desired invertible two-bank address map. Suppose \(G-I\) has split rank \(r>0\), witnessed by its top-right block of rank \(r\), whose successive northeast corner determinants up through order \(r\) are units. Over a local ring, split rank means an actual rank-\(r\) factorization with an invertible \(r\times r\) minor. Rank of the reduction alone does not suffice.

For each \(k\le r\), consider the determinant formed by the first \(k\) rows and the last \(k\) columns, listing those columns in reverse. Then \(G\) is a product of unit lower ordinary adapters on both sides of one rank-\(r\) reciprocal weighted reversal if and only if these determinants for \(G\) and for \(G^{-1}\) agree.

Necessity follows from invariance of those corner determinants under multiplication by full \(2m\)-dimensional unit lower triangular matrices. On the first \(k\) rows left multiplication uses only those rows and has determinant one. On the last \(k\) columns right multiplication uses only those columns and has determinant one. The middle child is an involution, so its two lists coincide.

For sufficiency, let \(E=(e_1,\ldots,e_r)\), \(F=(e_m,\ldots,e_{m-r+1})\), and \(D\) the diagonal of unit northeast pivots. Unit lower intrabank factors put the upper-right block into \(ED F^\intercal\). They act by a two-bank similarity, so the conjugated map \(G'\) still has
\[
G'-I=\binom{E}{B}\,(A,\ D F^\intercal).
\]
Take \(T=I+AE+D F^\intercal B\), which is invertible since the restriction of \(G'\) to the rank-\(r\) image of \(G'-I\) is invertible. Set \(J=-D^{-1}T\). The inverse-map top-right block is \(E(-T^{-1}D)F^\intercal=EJ^{-1}F^\intercal\), by the rank-factorization inverse formula. Thus \(J^{-1}\) has unit leading principal minors with the same values as \(D\).

Write \(S(K)=\left[\begin{smallmatrix}I&0\\K&I\end{smallmatrix}\right]\) and choose
\[
K_L=-(B+FD^{-1})E^\intercal+FD^{-1}A(I-EE^\intercal),
\qquad K_R=F(J-D^{-1})E^\intercal-K_L.
\]
Direct multiplication gives \(S(K_L)G'S(K_R)\) fixing both inactive sectors and exchanging the active banks by \(D\) and \(J\). The identities \(F^\intercal K_L=D^{-1}(A+E^\intercal)\) and \(K_LE=-B-FD^{-1}\) make the bottom-right block \(I-FF^\intercal\). Also \(A+D F^\intercal K_R=-E^\intercal\), which makes the top-left block \(I-EE^\intercal\) and, together with \(K_L+K_R=F(J-D^{-1})E^\intercal\), makes the bottom-left block \(FJE^\intercal\).

No-pivot Gaussian factorization gives \(J^{-1}=L D U\) with \(L\) unit lower and \(U\) unit upper in \(F\)'s reversed order. Left multiplication on the active tail by \(U\) and right multiplication on the active head by \(L\) replace \(J\) by \(D^{-1}\) and leave the upper-right block intact. On physical coordinates both additions are unit lower, because tail order is reversed. Composition proves the biconditional. The exact checker implements these formulas and orderings, and compares the entire map with a literal one-child matrix.

## Application to frame quotients and the cover boundary

In sum/difference address coordinates, the BIT partial swap \(D_P\) is \(\operatorname{diag}(I,I-2P)\), where \(P\) is the orthogonal projector onto its selected subspace. A quotient on one field fixes all its sum coordinates and acts by an orthogonal
\[
U=(I-2Q)(I-2P)
\]
on its difference coordinates. The same claim holds for any finite product of such factors on the one field. Set \(A_0=(I-U)/2\). Reverting to head/tail and neglecting reversal for this one formula, the four blocks are \(I-A_0,A_0;A_0,I-A_0\). The upper-right block after tail reversal and external diagonal head weights \(W\) is \(W A_0 C_m\). The inverse has \(W A_0^\intercal C_m\); their northeast determinants coincide. For two frames the child rank is
\[
r=\operatorname{rank}(I-U)=\operatorname{rank}(P-Q)
 = \dim \operatorname{im}P+\dim\operatorname{im}Q-
       2\dim(\operatorname{im}P\cap\operatorname{im}Q).
\]
The first equality between ranks follows by multiplying an invertible reflection. For the second, \(\ker(P-Q)\) splits as the intersection of the images and the intersection of the kernels. This also explains why only a pair with a strictly shorter direct rank distance can save rank mass.

More generally, keep the uniform cover coordinate \(g\in\operatorname{GL}_m(\mathbb Z/q^w\mathbb Z)\). For headers with all leading Gram minors units, take a unit lower eliminator \(L_g\) for \(gg^\intercal\) and use the channel interpretation \(B(g)=L_g g\), where \(B(g)B(g)^\intercal=\Delta_g\) is diagonal. For arbitrary \(U\) orthogonal before the cover,
\[
 B(g) A_0 B(g)^{-1}=B(g)A_0 B(g)^\intercal\Delta_g^{-1},
\qquad
 B(g) A_0^\intercal B(g)^{-1}=B(g)A_0^\intercal B(g)^\intercal\Delta_g^{-1}.
\]
The restricted determinants are equal by transpose and the common column scaling. Gram-bad labels can use \(B(g)=g\) and pay the ordinary fallback. A fixed rational orthogonal matcher \(R\) obeys \(B(gR)=B(g)R\), including those bad labels, since \(gg^\intercal\) is unchanged. Thus all stock dimensions, integer high-header lifts and right-multiplication routes remain in the original full GL cover when **every matcher used with this interpretation is orthogonal**. The header normalization is label preparation and not a performed nonlocal linear map. Child pivots depend on full exposed parent headers, never on fresh child fields.

For a given finite leaf, each leading Gram polynomial in the first \(k\) rows \(X_k\) has degree \(2k\). The normalized pivot witnesses have the corresponding degree-\(2k\) determinants of \(X_k A_0 X_k^\intercal\) as numerators. For \(k\le r\) they are nonzero polynomials since a \(k\)-plane transverse to \(\ker A_0\) has no quadratic radical for \(A_0\), by \(v^\intercal A_0 v=\|A_0v\|^2\). Denominator witness and rank-minor exclusions remove finitely many primes. The sum of all degrees in the Gram and leaf tests is at most \(2m(m+1)\). Choosing the fixed odd prime after the program therefore bounds the bad fraction by \(4m(m+1)/q\) after conditioning on invertibility. The weighted-ring fallback for a generic full invertible matrix uses unit pivots and a paired diagonal normalization. It applies here because \(\det G=\det U\) is the fixed sign \(\pm1\) and the external weights are conjugation. A fresh surcharge at least the retained \(32m^2\) elementary-child bound times this fraction is required in the moment.

The matched lower matrices use at most \(2m(2m-1)\) elementary ordered additions per head/tail column, counting both sides and including zero-filled slots if a fixed schedule is desired. The original addressing lemma charges these as prefix-controlled ordered passes on arbitrary complete source/target fibers. Concatenating the first \(r\) head coarse atoms and last \(r\) tail coarse atoms gives one contiguous \(rf\)-atom weighted child in \(f\) reversed columns. Its descriptor is the current column's leading pivot times the external head weight at that column. Full matrix equality preserves arbitrary dirty inputs and complete spectators. Each address transformation reduces exactly modulo \(q^w\) for allowed \(q\) and all \(w\). Its coefficients act on address atoms and require no change to public BIT payload precision. The existing volume, row-stock, descriptor preparation, physical shifting and fallback charges still apply.

## Source-specific checks and counterexamples

The selected BIT input is the #7001 file at canonical main SHA \(e54523517d0f03e58352e647c403a5af3e525a57\), SHA-256 of compressed word \(51203e7fc75ba10bd3ac3f8e675759f47e13d262bea66b6600d1e515095cad78\). Checking all 34,137 events gives 2,871 MOVE calls and zero contact-free same-field runs of length at least two. Every ADD checks both fields as read/write barriers, every SWAP checks both and INIT/CLEAR delimit lifetimes. A change to that word needs changed chart/contact assignments or a different architecture. The independent exact quotient fixtures span dimensions 2 to 4, multiplicities 1 to 3, \(\mathbb Q\), \(\mathbb F_{101}\), \(\mathbb Z/101^2\mathbb Z\) and \(\mathbb Z/1009^3\mathbb Z\). They compare 432 full matrix columns.

An independent frame assignment scan compresses 3,767 visits to 636 same-frame components, of which 239 are fixed by public boundaries or owned INIT/CLEAR. The scan grants a single child of rank \(d(U,V)=\operatorname{rank}(P_U-P_V)\) for **every** nonnested move as a favorable relaxation. It tests all 252,095 ways to choose one free component and change it to a different retained chart. Every change increases the complete affected paid moment at saving 0.00385248, 0.0040075385047236 and 0.0227, using rational intervals of grid \(2^{-80}\). The productive jobs, forward/backward contacts, endpoint frames and the common chart of each ADD are fixed. Inactive spectator frames and zero INIT/CLEAR boundaries are held fixed as well.

The two-component exclusion at saving 0.00385248 uses a general interaction bound. Write \(d_s=d^{1-s}\), also a metric, and let \(\ell_u,\ell_v\) be individual increases of the paid moment after reassigning \(u,v\). On a shared MOVE, the joint correction equals
\[
d_s(u',v')+d_s(u,v)-d_s(u',v)-d_s(u,v').
\]
Regrouping as two differences and applying the triangle inequality gives the lower bound \(-2\min(d_s(u,u'),d_s(v,v'))\). For multiplicity \(e\) of shared MOVEs, the total joint increase is therefore at least \(\ell_u+\ell_v-2e\min(d_s(u,u'),d_s(v,v'))\). Directed integer intervals make this strictly positive for all \(817\cdot635^2=329{,}434{,}825\) adjacent-pair assignments, using each node's own single-penalty minimum to avoid enumerating the product of candidate lists. Disjoint pairs have exactly additive losses. This proof does not price assignments changing three or more components.

There is a larger class with an exact polynomial test. Fix one alternate chart \(a\) and let every free component keep its own old chart or change to \(a\). For an edge \(u,v\), the four absolute costs are \(d_s(u,v),d_s(u,a),d_s(a,v),0\). The triangle inequality makes the binary cost submodular. A directed cut computes the exact minimum for all subsets of changes simultaneously. To account for directed arithmetic, take upper bounds on baseline edges and lower bounds on new edges, leave an untouched edge's difference exactly zero, and relax a single-state cost downward if rounding alone violates submodularity. Thus the integer-capacity result remains a valid lower bound on the true difference. At saving 0.00385248, all 636 cut problems returned zero, attained by the unchanged assignment. This excludes even large changes to one common incoming chart. Simultaneous groups going to different new charts are outside this min-cut result. The test suite includes an artificial coordinated gain invisible to either single change, a losing control, high-capacity checks and 300 small integral flow networks checked by literal cut enumeration.

For the exact #7001 stage embeddings, all 111 head vectors have a rational unit normalization according to the census. A rational Householder reflection can map each normalized head to the first standard axis, extending it to a rational orthonormal basis. Thus the fixed outer stage exchange can use an orthogonal right matcher. This says nothing about a generic rational helper frame at an internal recursive substitution.

The unrestricted GL contract really matters. Take projectors onto \((1,0)\) and \((1,1)\), whose two reflections multiply to \(U=\left[\begin{smallmatrix}0&1\\-1&0\end{smallmatrix}\right]\). Conjugating by \(H=\left[\begin{smallmatrix}1&1\\0&1\end{smallmatrix}\right]\) gives forward northeast pivots \((1,1/2)\) but inverse first pivot zero. Therefore a cover or recursive matcher that permits arbitrary \(H\) cannot simply apply this one-child theorem in that chart. As a separate minimal control, \(G=\left[\begin{smallmatrix}0&2\\3&0\end{smallmatrix}\right]\) has forward corner \(2\) and inverse corner \(1/3\). A rank-one weighted involution cannot represent even this two-bank map up to unit lower adapters.

The current delayed mixed-target compiler uses arbitrary rational GL matchers and internally substitutes certified projector jobs until only rank-one leaves remain. A rank-2 orthogonal quotient can be a rotation without eigenvalue \(-1\), and cannot be matched to a rank-2 partial swap by any change of basis. This is an independent blocker even if all matchers were orthogonal. Treating one quotient as a raw low-rank child does not establish that the mixed-moment compiler can substitute it recursively. The source-specific census and proof establish no new kappa. A route around this is to constrain paid nonnested transitions to commuting projectors, whose quotient remains an exact projector, or to develop a separate recurrence handling rotational address jobs.

The arbitrary-GL boundary persists after any fixed leaf-basis conjugation, generically. Let \(A_0=(I-U)/2\) have \(A_0\ne A_0^\intercal\). The difference of the first forward and inverse corner after conjugation is the first diagonal entry of \(g(A_0-A_0^\intercal)g^{-1}\). For any nondiagonal entry \(M_{ij}\ne0\) of \(M=A_0-A_0^\intercal\), conjugate by \(I+E_{ji}\) to make the \(j\)-th diagonal nonzero, then permute it to coordinate one. So the difference numerator is a nonzero degree-\(m\) polynomial in \(g\), and the first necessary equality in the one-child criterion holds on at most \(2m/q\) of the full GL low cover, excluding finitely many primes. A fixed invertible conjugation of the leaf preserves this counting statement, because it permutes the GL cover labels. Hence the unrestricted standard cover cannot treat a genuine rotation as a one-child leaf plus a rare fallback.

## Limit on splitting at fixed total helper rank

On the matched #7001 signed moment, freeze the paid word and every root target. Relax the 15,732 productive native helpers to arbitrary independent positive split jobs conserving their original total rank, with free routing, basis synthesis, storage, restoration, precision and tape. Since \(r^{1-s}\le r\) on positive integer ranks, splitting each helper all the way to ones maximizes its allowed contribution. It therefore gives a rigorous upper bound on the credit from this whole mechanism. At \(s=0.0227\) even that most favorable moment has paid-minus-target \(>1474.98159976735\) raw units. This directly uses the complete authenticated 107,352-paid, 19,950-target receipt and recounts all native helper endpoints. Changing the paid schedule or root targets exits this exclusion.

Reproduce with CPython 3.11 or newer from this directory with:

    python -I -B -O verify_bit_orthogonal_quotient.py
    python -I -B -O scan_bit_move_runs.py
    python -I -B -O scan_bit_fixed_graph.py
    python -I -B -O scan_bit_coalitions.py
    python -I -B -O screen_bit_helpers.py

For the source census commands extract research/paired-query-only-bit/retained/inputs/BIT-NATIVE-WORD.json.gz from the canonical pin and use native.json.gz as the scratch filename. For the helper split screen also extract research/paired-query-only-bit/EFREE-RESULT.json to result.json. Preserve both files' exact Git bytes. The local verifier and frame scans were bounded to at most 60 seconds per subprocess on DESKTOP-CHKL6QL. The adjacent-node scan took 17.89 seconds on one worker. The coalition checker uses four CPU workers to build the exact rational distance catalogue. The complete uncached coalition screen took 5.45 seconds including that catalogue and a 1.72-second flow phase. Median timings are unmeasured.

Predecessor algebra and interfaces are in [the weighted-child construction](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/notes/three-stage-cover-bit.tex), [the delayed whole-cover bridge](https://github.com/CrocSwap/integer-mult-bounds/blob/e54523517d0f03e58352e647c403a5af3e525a57/research/kappa-rebuild/bit/DELAYED-COVER-BRIDGE.md), and [#7001](https://github.com/CrocSwap/integer-mult-bounds/pull/7001). The independent-field packing and paired caller allocation results [#7163](https://github.com/CrocSwap/integer-mult-bounds/pull/7163) and [#7162](https://github.com/CrocSwap/integer-mult-bounds/pull/7162) have different hypotheses.
