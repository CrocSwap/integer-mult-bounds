"""Exact census of consecutive per-field MOVE runs in the selected BIT word."""

from collections import Counter
from fractions import Fraction
from functools import lru_cache
import gzip
import hashlib
import json
import math
from pathlib import Path


SOURCE_SHA256 = "51203e7fc75ba10bd3ac3f8e675759f47e13d262bea66b6600d1e515095cad78"
WORK = Path(__file__).resolve().parent


def load_word():
    blob = (WORK / "native.json.gz").read_bytes()
    if hashlib.sha256(blob).hexdigest() != SOURCE_SHA256:
        raise ValueError("unexpected selected BIT source bytes")
    return json.loads(gzip.decompress(blob))


def basis(rows):
    echelon = {}
    for row in rows:
        reduced = [Fraction(value) for value in row]
        for index in range(len(reduced)):
            value = reduced[index]
            if not value:
                continue
            if index in echelon:
                reduced = [a - value * b for a, b in zip(reduced, echelon[index])]
                continue
            echelon[index] = [entry / value for entry in reduced]
            break
    return tuple(echelon.values())


def runs(program):
    pending = {}
    for index, event in enumerate(program):
        opcode, field, *rest = event
        if opcode == "MOVE":
            pending.setdefault(field, []).append((index, *rest))
            continue
        blocked = [field]
        if opcode in {"ADD", "SWAP"}:
            blocked.append(rest[0])
        if opcode not in {"ADD", "SWAP", "INIT", "CLEAR"}:
            raise ValueError(f"unsupported opcode {opcode}")
        for touched in blocked:
            run = pending.pop(touched, [])
            if run:
                yield touched, run
    yield from pending.items()


def analyze(word):
    frames = {int(label): (entry["dim"], entry["B"], entry["A"])
              for label, entry in word["frames"].items()}

    @lru_cache(None)
    def distance(start, stop):
        # For real orthogonal projectors, rank(P-Q) equals
        # dim(U)+dim(V)-2*dim(U intersect V).
        start_rank, start_rows, _ = frames[start]
        stop_rank, stop_rows, _ = frames[stop]
        return 2 * len(basis(start_rows + stop_rows)) - start_rank - stop_rank

    for rank, rows, complement in frames.values():
        if len(basis(rows + complement)) != 8 or len(rows) != rank:
            raise ValueError("invalid recorded frame dimension")
        if any(sum(Fraction(x) * Fraction(y) for x, y in zip(b, a))
               for b in rows for a in complement):
            raise ValueError("frame complement is not dot orthogonal")

    initial_coframes = 0
    for label in word["start"][:111]:
        _, rows, _ = frames[label]
        norm_square = sum(Fraction(x) * Fraction(x) for x in rows[0])
        p, q = math.isqrt(norm_square.numerator), math.isqrt(norm_square.denominator)
        if Fraction(p * p, q * q) != norm_square:
            raise ValueError("irrational norm in a main head")
        initial_coframes += 1

    original = Counter()
    merged = Counter()
    shapes = Counter()
    samples = []
    for field, run in runs(word["program"]):
        ranks = []
        _, start, stop = run[0]
        previous = start
        for _, entrance, exit in run:
            rank = distance(entrance, exit)
            if entrance != previous or rank != abs(frames[entrance][0] - frames[exit][0]):
                raise ValueError("MOVE run or original nesting failed")
            previous = exit
            ranks.append(rank)
        original.update(ranks)
        stop = run[-1][2]
        rank = distance(start, stop)
        if rank:
            merged[rank] += 1
        if len(run) > 1:
            shape = (tuple(ranks), rank, abs(frames[start][0] - frames[stop][0]) != rank)
            shapes[shape] += 1
            samples.append({"field": field, "start_frame": start, "stop_frame": stop,
                            "events": run, "original_ranks": ranks, "fused_rank": rank,
                            "nonnested": shape[2], "rank_mass_saving": sum(ranks) - rank})
    if original != {1: 1386, 2: 1253, 3: 62, 4: 47, 5: 9, 6: 104, 7: 10}:
        raise ValueError("source native invoice mismatch")
    samples.sort(key=lambda row: (-row["rank_mass_saving"], -len(row["events"]), row["field"]))

    return {"source_sha256": SOURCE_SHA256, "rational_unit_main_heads": initial_coframes,
            "events": len(word["program"]), "original": dict(sorted(original.items())),
            "merged": dict(sorted(merged.items())), "groups": len(samples),
            "rank_mass_saving": sum(rank * (original[rank] - merged[rank])
                                    for rank in original.keys() | merged.keys()),
            "run_shapes": [{"before": ranks, "after": rank, "nonnested": nonnested,
                            "count": count}
                           for (ranks, rank, nonnested), count in shapes.most_common()],
            "samples": samples}


if __name__ == "__main__":
    print(json.dumps(analyze(load_word()), indent=2))
