"""Signed-moment obstruction for splitting selected BIT helpers at fixed rank mass."""

from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from scan_bit_move_runs import load_word
from scan_bit_fixed_graph import supported_interval


def bounds(coefficients, powers):
    lower = sum(d * powers[k][0 if d > 0 else 1] for k, d in coefficients.items())
    upper = sum(d * powers[k][1 if d > 0 else 0] for k, d in coefficients.items())
    return lower, upper


def word_invoice():
    word = load_word()
    frames = {int(label): f["dim"] for label, f in word["frames"].items()}
    public = word["public"]
    paid = Counter()
    targets = Counter()
    field_moves = Counter()
    for opcode, field, *rest in word["program"]:
        if opcode == "MOVE":
            r = abs(frames[rest[0]] - frames[rest[1]])
            paid[r] += 1
            field_moves[field] += r
    for j in range(222, public):
        start, final = word["start"][j], word["final"][j]
        targets[abs(frames[start] - frames[final])] += 1
    return paid, targets, field_moves


def exact_integer_sensitivity(paid, helpers):
    # This is a raw signed amount, not normalized by ambient capacity.
    content = Path(__file__).resolve().with_name("result.json").read_bytes()
    want = "a46b6c6040f75184cab5467656811ad988c216e3bc8e44d595a5015b6e49620b"
    if hashlib.sha256(content).hexdigest() != want:
        raise ValueError("selected BIT receipt bytes differ")
    base = json.loads(content)
    p = Counter({int(k): v for k, v in base["paid"].items()})
    t = Counter({int(k): v for k, v in base["targets"].items()})
    calls = base["native_calls"]
    if calls != 36 or any(p[r] < calls * paid[r] for r in paid):
        raise ValueError("native debit mismatch")
    if any(t[r] < calls * helpers[r] for r in helpers):
        raise ValueError("native target mismatch")
    t_optimistic = t.copy()
    for r, n in helpers.items():
        t_optimistic[r] -= calls * n
        t_optimistic[1] += calls * r * n
    paid_minus_target = {r: p[r] - t[r] for r in p.keys() | t.keys()}
    relaxed_remainder = {r: p[r] - t_optimistic[r]
                         for r in p.keys() | t_optimistic.keys()}
    scale = 2**80
    rows = []
    for target in ["0.00385248", "0.0040075385047236", "0.0227"]:
        h = {r: supported_interval(r, Fraction(target)) for r in set(t_optimistic) | set(p)}
        lo, hi = bounds(paid_minus_target, h)
        ol, oh = bounds(relaxed_remainder, h)
        rows.append({"saving": target, "declared_paid_minus_target": [lo, hi],
                     "relaxed_paid_minus_target": [ol, oh],
                     "declared_display": [lo / scale, hi / scale],
                     "relaxed_display": [ol / scale, oh / scale]})
    if not rows[-1]["relaxed_paid_minus_target"][0] > 0:
        raise ValueError("optimistic-split obstruction no longer passes")
    return rows


if __name__ == "__main__":
    paid, targets, field_moves = word_invoice()
    print(json.dumps({"paid": dict(sorted(paid.items())), "targets": dict(sorted(targets.items())),
                      "move_rank_by_field": Counter(field_moves.values()),
                      "grid_denominator": 2**80,
                      "exact_relaxed_sensitivity": exact_integer_sensitivity(paid, targets)}, indent=2))
