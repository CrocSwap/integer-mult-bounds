"""Certify every common-chart coalition in the frozen #7001 scalar graph."""

from collections import Counter, deque
from concurrent.futures import ProcessPoolExecutor
from fractions import Fraction
import json
import os
from pathlib import Path
import random
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from scan_bit_fixed_graph import make_graph, supported_interval
from scan_bit_move_runs import basis, load_word


def directed_cut(n, edges, source, sink):
    adj = [[] for _ in range(n)]

    def edge(a, b, weight):
        adj[a].append([b, weight, len(adj[b])])
        adj[b].append([a, 0, len(adj[a]) - 1])

    for a, b, weight in edges:
        if weight:
            edge(a, b, weight)
    total = 0
    big = sum(capacity for _, capacity, _ in adj[source]) + 1
    while True:
        dist = [-1] * n
        dist[source] = 0
        todo = deque([source])
        while todo:
            u = todo.popleft()
            for v, capacity, _ in adj[u]:
                if capacity and dist[v] < 0:
                    dist[v] = dist[u] + 1
                    todo.append(v)
        if dist[sink] < 0:
            return total, {i for i, d in enumerate(dist) if d >= 0}
        at = [0] * n

        def push(u, amount):
            if u == sink:
                return amount
            while at[u] < len(adj[u]):
                i = at[u]
                v, capacity, back = adj[u][i]
                if capacity and dist[v] == dist[u] + 1:
                    sent = push(v, min(capacity, amount))
                    if sent:
                        adj[u][i][1] -= sent
                        adj[v][back][1] += sent
                        return sent
                at[u] += 1
            return 0

        while sent := push(source, big):
            total += sent


def interval(delta, prices):
    return (sum(v * prices[r][int(v < 0)] for r, v in delta.items()),
            sum(v * prices[r][int(v > 0)] for r, v in delta.items()))


def graph_search(base, fixed, edges, labels, distances):
    started = time.monotonic()
    savings = Fraction("0.00385248")
    prices = [(0, 0)] + [supported_interval(r, savings) for r in range(1, 9)]
    receipt = Counter()
    best = None
    for proposed in labels:
        active = [v for v, p in base.items() if v not in fixed and p != proposed]
        nodes = {v: i for i, v in enumerate(active)}
        source, sink = len(active), len(active) + 1
        unary = [0] * len(active)
        network = []
        for u, v, count in edges:
            u0, v0 = base[u], base[v]
            d = distances[u0][v0]
            old_up = count * prices[d][1]
            if u in nodes and v in nodes:
                a, b = nodes[u], nodes[v]
                fa, fb = distances[proposed][v0], distances[u0][proposed]
                alo, blo = count * prices[fa][0] - old_up, count * prices[fb][0] - old_up
                w = max(0, alo + blo + old_up)
                if w == 0:
                    # Only a weaker relaxation is needed if grid rounding breaks
                    # triangle equality by a few ulps.
                    unary[a] += min(alo, -old_up - blo)
                    unary[b] += blo
                else:
                    network.append((a, b, w))
                    unary[a] += alo - w
                    unary[b] += blo
            elif u in nodes:
                unary[nodes[u]] += count * prices[distances[proposed][v0]][0] - old_up
            elif v in nodes:
                unary[nodes[v]] += count * prices[distances[u0][proposed]][0] - old_up
        constant = 0
        for i, gain in enumerate(unary):
            if gain >= 0:
                network.append((i, sink, gain))
            else:
                network.append((source, i, -gain))
                constant += gain
        flow, reachable = directed_cut(sink + 1, network, source, sink)
        true_cut = sum(w for a, b, w in network if a in reachable and b not in reachable)
        if true_cut != flow:
            raise ValueError("cut and flow disagree")
        if flow + constant > 0:
            raise ValueError("zero-change control is unavailable")
        if flow + constant == 0:
            receipt["proved no negative coalition"] += 1
            continue
        selected = [v for v, i in nodes.items() if i in reachable]
        selected_set = set(selected)
        result = {v: proposed if v in selected_set else f for v, f in base.items()}
        change = Counter()
        for u, v, count in edges:
            change[distances[result[u]][result[v]]] += count
            change[distances[base[u]][base[v]]] -= count
        lo, hi = interval(change, prices)
        if hi < 0:
            receipt["verified negative coalition"] += 1
            if best is None or hi < best["loss_exact_upper"]:
                best = {"proposed": proposed, "old_frames": [base[v] for v in selected],
                        "components": selected, "size": len(selected), "loss_exact_lower": lo,
                        "loss_exact_upper": hi, "loss_approximate_upper": hi / 2**80,
                        "rank_diff": dict(sorted((r, v) for r, v in change.items() if v))}
        else:
            receipt["unresolved lower relaxation"] += 1
    return {"census": receipt, "best": best, "seconds": time.monotonic() - started}


def small_control():
    # Relabelling either vertex individually costs one. Relabelling both
    # reduces the price by three. A myopic coordinate descent cannot move.
    growth = directed_cut(4, [(2, 0, 4), (1, 3, 1), (0, 1, 5)], 2, 3)
    if growth != (1, {0, 1, 2}):
        raise ValueError("pair control lost")
    # Reverse fixture has no strict coalition.
    none = directed_cut(3, [(1, 0, 10), (0, 2, 11)], 1, 2)
    if none != (10, {1}):
        raise ValueError("negative control lost")
    large = 2**80
    if directed_cut(3, [(1, 0, large), (0, 2, large + 1)], 1, 2) != (large, {1}):
        raise ValueError("large exact capacities lost")

    rng = random.Random(889)
    for size in range(2, 8):
        for _ in range(50):
            network = [(a, b, rng.randrange(7)) for a in range(size) for b in range(size)
                       if a != b and rng.random() < 0.4]
            flow, selected = directed_cut(size, network, 0, 1)
            cut = sum(w for a, b, w in network if a in selected and b not in selected)
            optimum = min(sum(w for a, b, w in network if mask >> a & 1 and not mask >> b & 1)
                          for mask in range(1, 1 << size, 4))
            if flow != cut or flow != optimum:
                raise ValueError("random network disagrees with literal exhaustive cuts")


def distance_slice(args):
    groups, worker, count = args
    labels = sorted(groups)
    result = []
    for i in range(worker, len(labels), count):
        a = labels[i]
        da, ra = groups[a]
        for b in labels[:i]:
            db, rb = groups[b]
            distance = 2 * len(basis(ra + rb)) - da - db
            result.append((a, b, distance))
    return result


def main():
    small_control()
    started = time.monotonic()
    word = load_word()
    _, original, fixed, move_edges = make_graph(word)
    edges = [(u, v, n) for (u, v), n in
             Counter(tuple(sorted((a, b))) for a, b, _ in move_edges).items()]
    labels = sorted(int(x) for x in word["frames"])
    groups = {int(label): (frame["dim"], frame["B"]) for label, frame in word["frames"].items()}
    distance_path = Path(__file__).resolve().with_name("chart-distances.json")
    cache = []
    if "--reuse-distances" in sys.argv:
        cache = json.loads(distance_path.read_text())
    else:
        count = min(4, os.cpu_count() or 1)
        with ProcessPoolExecutor(max_workers=count) as pool:
            for portion in pool.map(distance_slice, [(groups, j, count) for j in range(count)]):
                cache.extend(portion)
        if "--write-distances" in sys.argv:
            distance_path.write_text(json.dumps(cache, separators=(",", ":")))
    distances = {a: {a: 0} for a in labels}
    for a, b, distance in cache:
        if a in distances[b] or b in distances[a] or distance < 0 or distance > 8:
            raise ValueError("invalid duplicate or rank in cached chart distances")
        distances[a][b] = distances[b][a] = distance
    if any(len(r) != len(labels) for r in distances.values()):
        raise ValueError("incomplete cached chart distances")
    output = graph_search(original, fixed, edges, labels, distances)
    output["status"] = "PASS_BIT_COALITION_SCREEN"
    output["total_seconds"] = time.monotonic() - started
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
