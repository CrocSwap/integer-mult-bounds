"""Reproduce signed body rank cuts and the combined #7001 tariff."""

import argparse
from itertools import product
from fractions import Fraction
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import random


support = Path(__file__).resolve().parents[2] / "recurrence" / "verify_bit_caller_bound.py"
spec = spec_from_file_location("bit_source_replay", support)
stock = module_from_spec(spec)
spec.loader.exec_module(stock)
need = stock.need


def cross_rank(columns, source_roles, target_roles, half):
    rows_left = (1 << (target_roles * half)) - 1
    return stock.rank(c & rows_left for c in columns[source_roles * half:])


def cyclic_distance(shift, half):
    residue = shift % (2 * half)
    return min(residue, 2 * half - residue)


def xor_all(items):
    result = 0
    for item in items:
        result ^= item
    return result


def compose(after, before):
    return tuple(xor_all(after[k] for k in stock.selected(col)) for col in before)


def cyclic_shift_roles(projector, shift, half):
    count = len(projector)
    size = 2 * half
    result = []
    for address, role in product(range(size), range(count)):
        target = projector[role]
        unchanged = (1 << role) ^ target
        end = (address + shift) % size
        result.append((unchanged << (address * count)) ^ (target << (end * count)))
    return tuple(result)


def rank_one_projector(dim, column, row):
    need(len(tuple(stock.selected(row))) <= dim and stock.parity(row, column) == 1,
         "Not a rank-one idempotent")
    return tuple(column if row & (1 << i) else 0 for i in range(dim))


def ordinary_roles(columns, new_width, half):
    """Repeat a possibly rectangular role-local matrix at all addresses."""
    return tuple(c << (p * new_width) for p in range(2 * half) for c in columns)


def signed_idle_cases():
    """Check a mixed-sign cancellation on an arbitrary dirty three-role input."""
    # Idempotent's image mixes roles 0/1; role 2 is a spectator.
    p = rank_one_projector(3, 0b011, 0b001)
    shifts = ((1, -1), (0, 1), (0, -1), (0, 1))
    # Composition on this channel is D1. Three different signed specializations
    # expose positive, negative, and zero total shift of the mixed atom.
    samples = 0
    first_operand = []
    for weights in ((1, 1), (2, -3), (-4, 1)):
        degrees = [sum(x * y for x, y in zip(vector, weights)) for vector in shifts]
        for half in range(1, 25):
            maps = [cyclic_shift_roles(p, degree, half) for degree in degrees]
            state = maps[0]
            for element in maps[1:]:
                state = compose(element, state)
            expected = cyclic_shift_roles(p, weights[0], half)
            need(state == expected, "Mixed-sign shift operator failed")
            need(
                all(cross_rank(m, 3, 3, half) == cyclic_distance(h, half)
                    for m, h in zip(maps, degrees)),
                "Mixed-sign crossing rank failed",
            )
            need(
                cross_rank(state, 3, 3, half)
                <= sum(cross_rank(m, 3, 3, half) for m in maps),
                "Signed rank subadditivity failed",
            )
            samples += 1
        first_operand.append(degrees[0])
    need(first_operand == [0, 5, -5], "Stale weighted fixture")
    return dict(factor_vectors=shifts, product_vector=(1, 0), projected_degrees=first_operand,
                strict_paid_l1=2, strict_absolute_collapsed=0,
                complete_cyclic_operator_trials=samples)


def determinant_false_credit():
    # Formal target diag(D1,D2) has the same determinant as diag(D1D2,1)
    # and a smaller optimistic signed invoice if the grouped idle is granted.
    # Every role-only rank-one projector has at most one shifted crossing
    # channel, so period 4 rejects all possible such coupled emitters.
    half = 2
    desired = cyclic_shift_roles((1, 2), 1, half)
    grouped = []
    n = 0
    for u, v in product(range(1, 4), repeat=2):
        if stock.parity(u, v) == 0:
            continue
        p = rank_one_projector(2, u, v)
        # D1 and D2 collapse to T under weight (1,1).
        shifted = cyclic_shift_roles(p, 2, half)
        grouped.append(cross_rank(shifted, 2, 2, half))
        # At a smaller period the difference is decisive: the grouped shift
        # is identity while each independent target crosses once.
        alias = cyclic_shift_roles(p, 2, 1)
        need(cross_rank(alias, 2, 2, 1) == 0, "Grouped cut should vanish")
        n += 1
    narrow = cyclic_shift_roles((1, 2), 1, 1)
    need(cross_rank(narrow, 2, 2, 1) == 2, "Wanted two independent transfers")
    need(cross_rank(desired, 2, 2, half) == 2 and grouped == [2] * n,
         "Large cut should not reject determinant control")
    price_gain = stock.add(
        stock.scaled(stock.price(7, 1, 200), 2),
        stock.scaled(stock.price(14, 1, 200), -1),
    )
    need(price_gain[0] > 0, "Determinant relaxation has no false positive")
    return dict(
        determinant_equal=True,
        period_two_target_crossing=2,
        period_two_grouped_crossing=0,
        period_four_both_crossings=2,
        rejected_grouped_projectors=n,
        false_reward_at_005=stock.format_bounds(price_gain),
    )


def rectangular_controls():
    rng = random.Random(7546)
    seen = 0
    positive = 0
    for a, b, c, half in product(range(1, 4), range(1, 4), range(1, 4), (1, 2, 3, 4)):
        unique_a = 2 * a * half
        unique_b = 2 * b * half
        unique_c = 2 * c * half
        first = tuple(rng.randrange(1 << unique_b) for _ in range(unique_a))
        second = tuple(rng.randrange(1 << unique_c) for _ in range(unique_b))
        chain = compose(second, first)
        lhs = cross_rank(chain, a, c, half)
        rhs = cross_rank(first, a, b, half) + cross_rank(second, b, c, half)
        need(lhs <= rhs, "Rectangular crossing rank composition")
        insert = ordinary_roles((1, 2), 3, half)
        erase = ordinary_roles((1, 2, 0), 2, half)
        need(cross_rank(insert, 2, 3, half) == cross_rank(erase, 3, 2, half) == 0,
             "Constant zero allocation or erasure paid a crossing")
        need(compose(erase, insert) == tuple(1 << i for i in range(4 * half)),
             "Allocation/erasure lost arbitrary inputs")
        seen += 1
        positive += bool(lhs)
    return dict(crossing_trials=seen, nonzero_composed_crossings=positive,
                constant_init_clear_crossing=0)


def signed_inventory(demand, unit_tariff):
    order = sorted(range(len(demand)), key=lambda j: (-abs(demand[j]), j))
    levels = [abs(demand[j]) for j in order] + [0]
    prices = [Fraction(0)] * len(demand)
    replay = [0] * len(demand)
    primal = 0
    atoms = []
    for j, coordinate in enumerate(order, 1):
        previous = unit_tariff[j - 1]
        prices[coordinate] = (1 if demand[coordinate] >= 0 else -1) * (
            unit_tariff[j] - previous
        )
        copies = levels[j - 1] - levels[j]
        if not copies:
            continue
        vector = [0] * len(demand)
        for active in order[:j]:
            vector[active] = 1 if demand[active] >= 0 else -1
            replay[active] += copies * vector[active]
        primal += unit_tariff[j] * copies
        atoms.append((vector, copies))
    dual = sum(q * n for q, n in zip(prices, demand))
    need(replay == list(demand) and primal == dual, "Primal/dual mismatch")
    tested = 0
    for vector in product((-1, 0, 1), repeat=len(demand)):
        tariff = unit_tariff[sum(c != 0 for c in vector)]
        need(sum(c * q for c, q in zip(vector, prices)) <= tariff,
             "Signed idle violated dual")
        tested += 1
    return dict(demand=demand, tariff=[str(x) for x in unit_tariff],
                optimal_tariff=str(primal), atoms=atoms, dual_vectors_tested=tested)


def cert_finite_threshold(numerator, denominator):
    n = numerator[0] // denominator[1] + 1
    need((n - 1) * denominator[1] < numerator[0], "Need sharper threshold below")
    need(n * denominator[0] > numerator[1], "Need sharper threshold above")
    return n


def ledger(paid, targets, claim, nu, de):
    signed = targets.copy()
    signed.subtract(paid)
    # At most two rank-seven body incidences per native, in either direction.
    signed[7] += 222
    body = stock.moment(signed, nu, de)
    delta = stock.add(stock.price(8, nu, de), stock.scaled(stock.price(7, nu, de), -1))
    record = {"saving": claim}
    for label, fee in (("general", stock.price(1, nu, de)), ("body_bearing", delta)):
        debit = stock.scaled(fee, 111)
        cap = stock.add(body, debit)
        row = dict(per_native_before_label_charge=stock.format_bounds(cap),
                   per_used_label_charge=stock.format_bounds(debit))
        if claim == "0.005":
            row["minimum_natives_by_used_labels_1_2_3"] = [
                cert_finite_threshold(stock.scaled(debit, labels), cap) for labels in (1, 2, 3)
            ]
        else:
            need(cap[1] < 0, "Target signed caller passed")
        record[label] = row
    return record


def main():
    cli = argparse.ArgumentParser()
    cli.add_argument("repo", type=Path)
    args = cli.parse_args()
    _, paid, targets, _, _ = stock.verify_sources(args.repo)
    tariff = tuple(Fraction(v) for v in (0, 5, 9, 12, 14))
    receipts = dict(
        canonical_source=stock.HEAD,
        ledger=[ledger(paid, targets, "0.005", 1, 200),
                ledger(paid, targets, "0.0227", 227, 10000)],
        opposite_sign_control=signed_idle_cases(),
        grouped_determinant_counterexample=determinant_false_credit(),
        rectangular_controls=rectangular_controls(),
        signed_inventory=signed_inventory((3, -2, 2, 0), tariff),
    )
    print(json.dumps(receipts, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
