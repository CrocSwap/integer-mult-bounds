# A power-tariff bound for signed BIT body schedules

Grouped body moves with mixed signs cannot escape the fixed #7001
threshold at 0.0227 within the formal Laurent-monomial caller model.
The key is to measure the rank that crosses half of a cyclic address
space, and then integrate these ranks over all cycle scales. The
result bounds the target power tariff by the paid body tariff and
holds for an arbitrary finite order of the forward and inverse moves.
At 0.005 it excludes smaller callers and leaves larger ones open.

The finite source replay binds [#7001](https://github.com/CrocSwap/integer-mult-bounds/pull/7001)
at canonical main `e54523517d0f03e58352e647c403a5af3e525a57`.
Compare the repository's earlier [finite dihedral crossing-rank proof](https://github.com/CrocSwap/integer-mult-bounds/tree/e54523517d0f03e58352e647c403a5af3e525a57/research/finite-dihedral-cut-bound)
and [signed idle determinant inventory](https://github.com/CrocSwap/integer-mult-bounds/tree/e54523517d0f03e58352e647c403a5af3e525a57/research/signed-overlap-idle-completion).
The first uses crossing rank for fixed finite address groups; the second
certifies an inventory for a fixed determinant demand. The scale
integration below uses the operator identity, so it distinguishes words
with the same determinant.

## Signed operator theorem

Work over a field F. Let the body variables be independent commuting
Laurent monomials `D_1,...,D_m`. Specialize every header to one before
reading the body identity. A body operation with `b∈Z^m` on a role
projector P is

```text
(I-P) + D^b P,              P^2=P, rank(P)=d.
```

An occurrence may have positive and negative powers in different
coordinates. Rank-d identity means the entire d-dimensional image is
shifted, and the complementary role subspace is unchanged. A normalized
forward or inverse #7001 LOCAL has one such body operation of role
rank two with `b=±e_j`, and an ordinary invertible nominal shear; after
header specialization the two commute. A whole IDLE on one field has
role rank one. Constant scalar role maps may be interleaved anywhere.
Suppose the exact formal endpoint equals a diagonal monomial
`diag(D^a_1,...,D^a_n)` on independent inputs, with zero vectors for
restored dirty spectators. For every `0<t<1` and every integer weight
vector w,

```text
Σ_i |w·a_i|^t <= Σ_occurrences d |w·b|^t.                 (1)
```

Square constant role mixers suffice for the combined #7001 tariff below.
Equation (1) separately permits constant rectangular maps such as
appending an identically zero role or discarding a fully restored auxiliary
role. Such operations must be address-local. No conclusion about which
erasure or copying opcode belongs to the original native alphabet follows
from allowing this relaxation.

### Half-cycle rank

For integers K,M≥1 specialize `D_j→S^(M w_j)` with S the translation by
one on `Z/(2K)`. This is a ring representation of every Laurent power.
Split addresses into the consecutive halves L={0,...,K−1} and R its
complement, placing all roles at each address in the same half. For a
linear operator A, define `r(A)=rank A[L,R]`. For compatible even
rectangular maps A and B, ordinary block multiplication gives

```text
(AB)[L,R] = A[L,L]B[L,R] + A[L,R]B[R,R],
r(AB) <= r(A)+r(B).
```

Here each site's L and R dimensions can change with the role count.
Products and sums are valid even with unequal intermediate sizes. Any
role-only constant map has crossing rank zero. A role basis makes an
idempotent P diagonal with d ones, because its image and kernel are
complementary. Both basis routes preserve the two address halves and
therefore preserve crossing rank. A cyclic translation by h carries
exactly `d_(2K)(h)=dist(h,2K Z)` right-half coordinates into the left
half. The count follows from translating two equal contiguous intervals
on the cycle. Their distinct destinations make this the exact crossing
rank. Each gate thus contributes `d d_(2K)(M w·b)`; the independent
diagonal targets contribute `Σ_i d_(2K)(M w·a_i)`.

This is an inequality at every finite cycle length. It remains valid
even if the specialization causes some opposite-sign shifts to cancel
or a nontrivial monomial to become the identity.

### Passing from integer cycles to the full tariff

Divide the inequality by M. For any real `s>0), take integer K(M) with
`K(M)/M→s`, for example `max(1,floor(Ms))`. Then
`d_(2K(M))(M h)/M = dist(h,2 K(M)/M Z)→dist(h,2s Z)`.
The distance is continuous in s at every positive s. Locally this is
the minimum of finitely many absolute linear functions, since slopes
from lattice points sufficiently far away cannot attain the minimum.
There are finitely many gates and targets, so this gives a pointwise
inequality for the real cycle function `d_(2s)(h)) at every s>0.

Multiply by `s^(t−2)>0` and integrate from zero to infinity.
The integrals converge: `d_(2s)(h)≤s` permits integration at zero
because t>0, and `d_(2s)(h)≤|h|` permits integration at infinity
because t<1. For h≠0 the change of variable `s=|h|u` gives exactly

```text
∫₀∞ d_(2s)(h) s^(t−2) ds = |h|^t C_t,
C_t = ∫₀∞ d_(2u)(1) u^(t−2) du > 0.
```

The same identity gives zero at h=0. The constant is strictly positive
because the distance equals one for u≥1. Dividing proves (1).
The written proof covers all cycles and all finite schedules. The
verifier's sampled cycles are corroboration, not the limit argument.

## Complete #7001 body and header invoice

To price the fixed BIT alphabet, each body label denotes seven distinct
independent stage axes. A target's retained body degrees are nonnegative
and its credited physical rank is at most seven times their sum. Usually
each stage occurs at most once. If a repeated formal power is present,
it cannot be priced as an independent axis without a separate physical
interpretation. Each paid whole idle has a single role projector with
signed exponents b, and is charged at least the tariff of
`7||b||_1`. A mixed-sign atom's physical implementation at that
tariff is granted for a favorable lower bound. The proof does not
assert such an implementation. If additional moves are needed,
they enter the paid side.

Putting all weights w_j=1 in (1) and multiplying it by `7^t` now
bounds total target body credit minus all paid idle charges by
`2L·7^t` per port, where L counts the full native occurrences
in either orientation. This uses
`|Σ_j b_j|^t≤||b||_1^t`; it is strict for an atom b=(1,−1).
Each full invocation pays its entire native profile. To make the bound
optimistic it may credit all native helper fields independently even
for inverses. Any alias, retirement, or reuse of a helper as input to
another native must debit the unavailable independent target.

Keep the prior square invertible role model for headers. The independent
involutive header variables remain formal and each native or thin
QUERY contributes one rank-one nilpotent after specializing the selected
header to `1+ε`. For a used label with o_j productive outputs, the
derivative gives `UV=E`, the rank-o_j diagonal projector. The diagonal
of VU is zero. This forces at least o_j+1 tagged occurrences because at
equality U and V have full column and row ranks and then VU=I.
Summing over u used labels and Q thin calls gives
`Σ o_j−Q≤L−u`. The rectangular role relaxation in (1) does not here
extend that header argument.

Let `H(r)=r^t`, `t=1−κ`, and write P₀ and T₀ for the full native paid
and helper moments. The marginal value of one header is at most δ=1,
or `δ=H(8)−H(7)` if every header-bearing productive main field has a
nonempty credited body. These claims follow from the decreasing
increments of H. Since a QUERY costs 1, the full signed margin obeys

```text
margin <= L·[T₀−P₀+111·(2H(7)+δ)] − 111δu.
```

The receipt reconstructs P₀ and T₀ from the source, prices all ranks by
directed integers, and gives these upper endpoints:

| κ | Arbitrary roots, per native | Body-bearing header roots, per native |
|---:|---:|---:|
| 0.005 | 15.8676246657099 | 14.2059384513111 |
| 0.0227 | −94.7103720928230 | −102.0782323506313 |

At 0.005 the debit per used independent header is respectively 111
and at least 109.3383137856012. For one, two, or three used headers, the
first column requires at least 7, 14, 21 full native invocations, and
the body-bearing column at least 8, 16, 24. For arbitrary u the exact
strict condition is `L > (111δu)/[T₀−P₀+111(2H(7)+δ)]` when the
bracket is positive. The #7001 source fails at 0.0227 for every positive
L in the stated signed body model. These conclusions leave the costs for
additional ordinary work, routing, integer recovery, precision,
restoration, and compiler admission intact as nonnegative obligations.

A specialized physical stage with extra finite-order relations can make
an operator identity hold without the requisite Laurent identity.
This argument cannot infer formal equality from a modulus test or
from a finite-order physical endpoint. The scope also excludes a
free address-dependent basis gate, coupled paid gates outside the
projector form, and a signed target whose credited rank is its ℓ₁
norm but whose positive weight specialization loses cancellations.
Equation (1) is still valid separately for any one signed vector of
weights; choosing a different weight per target does not follow.

## Tight signed determinant inventory and a strict separation

For comparison, ignore chronological and operator conditions. Suppose
the signed determinant demand is `d∈Z^m` and each allowed idle vector
`v∈{−1,0,+1}^m` is priced by a nondecreasing concave cardinality
tariff F with F(0)=0. Sort magnitudes `a_1>=...>=a_m` and set `a_(m+1)=0`.
The unbounded-inventory optimum is

```text
Σ_k (a_k−a_(k+1)) F(k).
```

Place `a_k−a_(k+1)` atoms on the first k coordinates with the demand's
signs. Their sum is d. For the lower bound set dual coordinate k to
`sign(d_k)·(F(k)−F(k−1))`. The largest h absolute dual entries sum to
F(h) by concavity, so any signed h-coordinate atom's pairing is at
most F(h). The demand pairs to exactly the displayed optimum. This
generalizes the cited fixed signed-inventory result. For demand
`(3,−2,2,0)` and F=(0,5,9,12,14), the cost is 29; the receipt checks
all 81 dual inequalities.

That inventory theorem grants a false optimistic reward
`2H(7)−H(14)>0` for separate targets `diag(D_1,D_2)) paid by one
grouped shift `D_1D_2` on a single role. Both determinants are
`D_1D_2`. On the two-cycle after the all-one specialization, the
grouped shift becomes identity and has zero crossing rank, while
the two separate targets have rank two. No ordinary pre/post role
basis can bridge that gap. The four-cycle gives equal crossing ranks
of two, so the two-cycle check is genuinely stronger on this example.
The replay rejects all six binary rank-one projector choices. The
false determinant reward at 0.005 is about 0.047967341947 per port.

The opposite-sign control keeps a dirty three-role input, shifts the
idempotent image with vectors `(1,−1),(0,1),(0,−1),(0,1)`, and
checks the resulting `(1,0)` endpoint. The first atom has charged
body width 14 but collapsed shift zero at weight (1,1). Weights
(2,−3) and (−4,1) give respectively shifts +5 and −5 for that atom.
All 72 complete cyclic action comparisons pass. There are also 108
exact rectangular crossing-rank composition checks and explicit
constant INIT/CLEAR controls.

## Reproduction

```powershell
$py = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
& $py -I -B -S .\work\round4\recurrence\verify_signed_body_tariff.py C:\Users\cuchu\Documents\Codex\integer-mult-bounds
```

The script imports the previous isolated `work/recurrence` verifier
for pinned tapes and exact arithmetic, and writes the JSON receipt
to stdout. CPython 3.13.14 replays in normal and optimized mode
were both bounded at 45 seconds and exited in under a second.
The byte-identical results have SHA-256
`e3f2210de07d0852b66a2436ef9dbcb0cc638a8675929125114aa6a9f72a2ccf`.
Syntax parsing and tabnanny passed. Ruff and uv were unavailable.
No GPU compute or external write ran.
