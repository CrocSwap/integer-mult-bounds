# SPDX-License-Identifier: Apache-2.0
"""Exact rank-one seam factorization for tensor-swapped complex helpers."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
ADJ = run_path(str(HERE / "independent/complex_adjoint.py"))
PRICE = run_path(str(HERE.parent / "helper_price.py"))
NEED = ADJ["need"]


def coframe_witnesses(word, deadline):
    """Find literal full seams with a pure independent vector before its final MOVE."""
    n = word["public"]
    mains = ADJ["main_roles"](word)
    rows = ADJ["ROWS"]
    _, _, before, after, _, _, _ = rows["capture"](word, deadline)
    terminal = []
    for event, (op, reg, *d) in enumerate(word["program"]):
        if event % 1024 == 0:
            NEED(monotonic() < deadline, "literal seam support census deadline")
        if op != "MOVE" or reg >= n or reg in mains or d[1] != word["final"][reg]:
            continue
        a, b = d[:2]
        start = word["initial"][reg]
        step = len(word["frames"][b]) - len(word["frames"][a])
        total = len(word["frames"][b]) - len(word["frames"][start])
        v, u = before[event], after[event]
        scalar = Fraction(v[1].get(reg, 0), v[0])
        normalized_v = rows["projective_key"](v, set())
        pure_u = set(j for j in u[1] if j < n) == {reg}
        if set(v[1]) == {reg}:
            terminal.append({"role":reg, "event":event, "old_frames":[start,a,b], "step":step,
                             "target_rank":total, "source_scalar":str(scalar), "pure_response":pure_u,
                             "outside_return_support":len([j for j in u[1] if j < n and j != reg]),
                             "same_public_source": normalized_v == ((reg,1),)})
    out = sorted(terminal, key=lambda r: (r["step"], r["target_rank"], r["role"]))
    usable = [r for r in out if r["target_rank"] > r["step"] and r["same_public_source"]]
    NEED(len(usable) == 27, "exact pure forward terminal rows on split independent helpers")
    return usable, before, after


def two_site_completion(word, before, after, deadline):
    """Find a second site that could repair the leaked output at a scalar fiber."""
    rows = ADJ["ROWS"]
    n = word["public"]
    event = 57999
    target = 993
    den, entries = after[event]
    main_effect = (den, {r: a for r,a in entries.items() if r<n and r!=target})
    influence = rows["projective_key"](main_effect, set())
    NEED(influence == ((851,1),), "observed first candidate has one outside owner")
    other_prefix_matching, nonempty = [], []
    for i, v in before.items():
        if i == event:
            continue
        NEED(monotonic() < deadline, "paired correction screen")
        if rows["projective_key"](v, set()) == ((target,1),):
            other_prefix_matching.append(i)
            u = after[i]
            extra = {r: x for r, x in u[1].items() if r<n and r!=target}
            if extra and rows["projective_key"]((u[0], extra), set()) == influence:
                nonempty.append(i)
    NEED(not nonempty, "no second literal contact with the same independent source and leaked target ray")
    return {"best_event":event,"other_MOVEs_with_exact_same_input_ray":other_prefix_matching,
            "second_nonzero_collinear_public_repair":nonempty,"leaked_public_return":851,
            "scope":"scalar responses, a matching second literal site with proportional original input and projected output"}


def polynomial_phases(vectors):
    """Exact quadratic Gaussian phase, keyed by coefficient coordinates."""
    data = Counter()
    for axis, exponent in vectors:
        bits = [i for i in range(axis.bit_length()) if (axis >> i) & 1]
        for i in bits:
            data[i,] += exponent
        for k, i in enumerate(bits):
            for j in bits[k+1:]:
                data[i,j] -= 2*exponent
    return {k: v%4 for k,v in data.items() if v%4}


def commuting_seam_control():
    """Check a genuine all-input seam, with two field owners kept independent."""
    # First paid transport of rank two applies Q to address axes 1 and 2 on
    # each helper; the round-trip uses Q^2 on the overlap, which is a
    # translation. All private field transforms are separate and diagonal.
    a, b, c = 1, 2, 4
    phase = polynomial_phases([(a,1),(b,1),(b,1),(c,1)])
    merged = polynomial_phases([(a,1),(b,2),(c,1)])
    NEED(phase == merged and len(phase) == 3, "rank of symmetric difference plus ordinary translation")
    table = [tuple((character & k).bit_count() % 2 for k in (a,b,c)) for character in range(8)]
    checked = 0
    for row in range(16):
        for column in range(16):
            x, y, z = table[column % 8]
            if row == column:
                NEED((x+y+y+z)%4 == (x+2*y+z)%4, "nonzero phase on every independent owner/address")
                if y:
                    NEED((x+y+y+z-(x+z))%4 == 2, "omitting seam translation changes sign")
            checked += 1
    receipt = {"full_two_owner_coefficients": checked, "rank_before_per_owner": [2,2],
               "rank_after_per_owner": 2, "independent_fields_before_and_after": 2}
    return receipt


def pricing(helpers):
    """Compare matched positive-body chains against destructive owner identification."""
    hp = PRICE["power_sum"]
    subtraction = PRICE["subtract"]
    rows = {}
    for decimal in ("0.003648411294790", "0.005", "0.0227"):
        s = Fraction(decimal)
        all_dilated = []
        for r in helpers:
            whole, piece = r["target_rank"], r["step"]
            # Two original independent outputs of size R. A positive
            # chain can keep one output of size 2R, not two. The optimistic
            # rank charge allows the two endpoint passes of size d to merge
            # into one of size 2d, with all other word charges unchanged.
            loss = subtraction(hp({whole: 2}, s), hp({2*whole:1}, s))
            save = subtraction(hp({piece: 2}, s), hp({2*piece:1}, s))
            diff = subtraction(save, loss)
            NEED(diff[1] < 0, "partial seam merging is dominated by the loss of target concavity credit")
            # If the seam uses coincident opposite phases, the target has two
            # copies of only the remaining axes. This is an optimistic helper-
            # only rank invoice. It leaves the changed support in other rails,
            # legal address embeddings and ordinary restoration to be checked.
            canceled = subtraction(hp({2*(whole-piece):1, piece:2}, s), hp({whole:2}, s))
            all_dilated.append({"role":r["role"],"positive_delta":diff,"opposite_local_delta":canceled})
        best = max(all_dilated,key=lambda r:r["positive_delta"][1])
        upper_cancel = max(all_dilated,key=lambda r:r["opposite_local_delta"][1])
        rows[decimal] = {"best_positive_chain":best, "best_opposite_completion":upper_cancel,
                         "positive_opposite_local_candidates":sum(r["opposite_local_delta"][0]>0 for r in all_dilated),
                         "full_signed_tariff_assumption":"part is literal, all other paid jobs / targets stay fixed"}
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    start, deadline = perf_counter(), monotonic()+35
    _, word = ADJ["PHYSICAL"]["load_pins"](args.word)
    usable, before, after = coframe_witnesses(word, deadline)
    NEED(not any(r["pure_response"] for r in usable), "no pure terminal candidate has an exclusive public response")
    top = next(r for r in usable if r["role"] == 993)
    NEED(top["event"]==57999 and top["step"]==5 and top["target_rank"]==9 and top["outside_return_support"]==1,
         "most favorable helper-only seam leaks into a second arbitrary return")
    report = {"status":"PASS_COMPLEX_ADJOINT_SEAM_SCREEN", "word_sha256":ADJ["ROWS"]["WORD_SHA"],
              "eligible_pure_terminal_helpers":usable, "pure_total_rank_profile":dict(Counter(r["target_rank"] for r in usable)),
              "phase_control":commuting_seam_control(), "tariff":pricing(usable), "scale":PRICE["SCALE"],
              "qualified_as_single_contact_seam": 0,
              "pair_screen_for_highest_local_margin":two_site_completion(word,before,after,deadline),
              "scope": "partial-target invoice candidates only; all moved helper rows have nonzero public output response off their owner"}
    NEED(monotonic() < deadline,"bounded exact seam checks")
    args.output.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(report["status"],len(usable),f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
