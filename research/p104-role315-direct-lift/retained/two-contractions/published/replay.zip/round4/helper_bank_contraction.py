# SPDX-License-Identifier: Apache-2.0
"""Contract a coframed pure-helper bank to test cross-owner adjoint stitching."""

import argparse
from collections import defaultdict
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
SEAM = run_path(str(HERE / "seam_rank_one.py"))
ADJ, NEED = (SEAM[k] for k in ("ADJ", "NEED"))
ROWS = ADJ["ROWS"]


def cancellation_bank(word, whole, deadline):
    """Detect cancellation of every other public output in a single common window."""
    n = word["public"]
    _, _, before, after, _, _, _ = ROWS["capture"](word, deadline)
    mains = ADJ["main_roles"](word)
    bank = defaultdict(list)
    for i, v in before.items():
        _, r, a, b, _ = word["program"][i]
        if r >= n or r in mains or a == word["initial"][r] or b != word["final"][r]:
            continue
        if ROWS["projective_key"](v, set()) == ((r,1),):
            bank[(a,b)].append((i,r))
    report = []
    best = []
    for (low, up), items in sorted(bank.items()):
        NEED(monotonic() < deadline, "bounded bank cancellation")
        if len(items) < 2:
            continue
        roles = {r for _, r in items}
        outs = [ROWS["projective_key"]((after[i][0],{r: a for r,a in after[i][1].items() if r<n and r not in roles}),set())
                for i,_ in items]
        proj_rank = ROWS["matrix_rank"](outs)
        row_rank = ROWS["matrix_rank"]([ROWS["projective_key"](after[i],set()) for i,_ in items])
        report.append({"frames":[low,up],"events":items,"outside_projection_rank":proj_rank,
                       "span_rank_with_erasures":row_rank,"putative_row_combinations":len(items)-proj_rank})
        if proj_rank < len(items):
            best.append([low,up])
    return {"status":"PASS_COMPLEX_HELPER_BANK_CONTRACTION", "cohorts":report,
            "nonzero_relaxed_nullspaces":best,"native_paid_count":sum(whole["signed_profile"]["signed_paid"].values()),
            "scope":"exact outside projection; nullity alone does not supply a physical seam or a pair of independent input directions"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("whole", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    start, deadline = perf_counter(), monotonic()+25
    _, word = ADJ["PHYSICAL"]["load_pins"](args.word)
    raw = args.whole.read_bytes()
    NEED(sha256(raw).hexdigest() == ADJ["WHOLE_SHA"], "exact signed bill")
    result = cancellation_bank(word,json.loads(raw),deadline)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(result["status"],len(result["nonzero_relaxed_nullspaces"]),f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
