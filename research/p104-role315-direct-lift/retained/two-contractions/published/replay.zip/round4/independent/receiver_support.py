"""Exact dirty-input response of each literal #7546 MOVE."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
import gzip
from hashlib import sha256
from itertools import combinations
import json
from math import gcd
from pathlib import Path
from time import monotonic


WORD_SHA = "6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32"
NONE = (1, {})


def need(condition, label):
    if not condition:
        raise ValueError(label)


@lru_cache(maxsize=None)
def ratio(text):
    return Fraction(text).as_integer_ratio()


def unit(index):
    return 1, {index: 1}


def reduced(denominator, values):
    if not values:
        return NONE
    common = denominator
    for value in values.values():
        common = gcd(common, value)
        if common == 1:
            return denominator, values
    return denominator // common, {key: value // common for key, value in values.items()}


def scale(row, factor):
    n, d = factor
    if not n or not row[1]:
        return NONE
    if n == d:
        return row
    s, entries = row
    return reduced(s * d, {key: n * value for key, value in entries.items()})


def increment(a, b, factor):
    n, d = factor
    if not n or not b[1]:
        return a
    if not a[1]:
        return scale(b, factor)
    sa, va = a
    sb, vb = b
    shared = gcd(sa, sb * d)
    la, lb = sb * d // shared, sa // shared
    values = {key: x * la for key, x in va.items()} if la != 1 else va.copy()
    for key, x in vb.items():
        value = values.get(key, 0) + n * lb * x
        if value:
            values[key] = value
        else:
            values.pop(key, None)
    return reduced(sa * la, values)


def target(word):
    n = word["public"]
    b = set()
    forward = [unit(i) for i in range(n)]
    inverse = [unit(i) for i in range(n)]
    a_ports = set(word["hosted"]["Dports"])
    for pi, x in enumerate(word["live"]):
        y = x + 112
        if pi in a_ports:
            forward[y] = 1, {x: 1, y: 1}
            inverse[y] = 1, {x: -1, y: 1}
        else:
            b.update((x, y))
            forward[x], forward[y] = (1, {x: 1, y: -1}), (2, {x: 1, y: 1})
            inverse[x], inverse[y] = (2, {x: 1, y: 2}), (2, {x: -1, y: 2})
    for x, y in zip(word["hosted"]["X2"], word["hosted"]["Y2"], strict=True):
        forward[x] = 1, {x: 1, y: -1}
        inverse[x] = 1, {x: 1, y: 1}
    need(len(b) == 16, "exact Type B rail count")
    return b, forward, inverse


def transpose(rows, input_count):
    columns = [NONE] * input_count
    for index, (den, row) in enumerate(rows):
        for col, coeff in row.items():
            columns[col] = increment(columns[col], unit(index), (coeff, den))
    return columns


def capture(word, deadline):
    """Return information before each MOVE and sensitivity of public and owned rows."""
    b, target_rows, inv = target(word)
    n, o = word["public"], word["owned_fields"]
    snapshots = {}
    program = word["program"]
    rows = [unit(i) for i in range(n)] + [NONE] * o
    live = word["initial"][:] + [None] * o
    erasures, guards = {}, {}
    nonzero_clear = 0
    for at, (op, reg, *args) in enumerate(program):
        if at % 512 == 0:
            need(monotonic() < deadline, "forward replay deadline")
        if op == "INIT":
            need(reg >= n and not rows[reg][1] and live[reg] is None, "owned INIT")
            live[reg] = args[0]
        elif op == "CLEAR":
            need(reg >= n and live[reg] == args[0], "exact owned CLEAR frame")
            nonzero_clear += bool(rows[reg][1])
            rows[reg] = NONE
            live[reg] = None
            erasures[at] = n + len(erasures) + len(guards)
        elif op == "MOVE":
            start, stop, owned = args
            need(live[reg] == start and owned == (reg >= n), "retained MOVE frame")
            live[reg] = stop
            snapshots[at] = rows[reg]
        elif op == "SCALE":
            factor, chart = args
            need(live[reg] == chart, "SCALE chart")
            rows[reg] = scale(rows[reg], ratio(factor))
        else:
            src, factor, chart = args
            need(reg != src and live[reg] == live[src] == chart, "scalar contact chart")
            if op == "COPY":
                need(reg >= n and not rows[reg][1], "literal COPY receiving zero")
                guards[at] = n + len(erasures) + len(guards)
                rows[reg] = scale(rows[src], ratio(factor))
            else:
                need(op == "ADD", "known native op")
                rows[reg] = increment(rows[reg], rows[src], ratio(factor))
    need(rows == target_rows + [NONE] * o, "all public inputs and owned exits")
    need(live == word["final"] + [None] * o, "all final charts")

    rows = [unit(i) for i in range(n)] + [NONE] * o
    sensitivity = {}
    for at in range(len(program) - 1, -1, -1):
        if at % 512 == 0:
            need(monotonic() < deadline, "reverse replay deadline")
        op, reg, *args = program[at]
        if op == "MOVE":
            sensitivity[at] = rows[reg]
        elif op == "CLEAR":
            need(reg >= n and not rows[reg][1], "owned reverse CLEAR")
            rows[reg] = unit(erasures[at])
        elif op == "INIT":
            need(reg >= n, "owned reverse INIT")
            rows[reg] = NONE
        elif op == "SCALE":
            rows[reg] = scale(rows[reg], ratio(args[0]))
        else:
            src, factor, _ = args
            rows[src] = increment(rows[src], rows[reg], ratio(factor))
            if op == "COPY":
                rows[reg] = unit(guards[at])
            else:
                need(op == "ADD", "known reverse native op")
    public_responses = [(den, {dst: x for dst, x in coeffs.items() if dst < n})
                        for den, coeffs in rows]
    public_responses = [reduced(den, values) for den, values in public_responses]
    need(public_responses == transpose(target_rows, n) + [NONE] * o, "all public response columns")
    return b, inv, snapshots, sensitivity, erasures, guards, nonzero_clear


def pairing(v, u, inverse):
    uv = Fraction(0)
    for src, weight in v[1].items():
        denominator, values = inverse[src]
        x = sum(coeff * u[1].get(dst, 0) for dst, coeff in values.items())
        uv += Fraction(x * weight, denominator * v[0] * u[0])
    return uv


def show(row):
    return {str(key): str(Fraction(value, row[0])) for key, value in sorted(row[1].items())}


def projective_key(row, excluded):
    """Integer primitive direction and sign, independent of row denominator."""
    items = sorted((key, val) for key, val in row[1].items() if key not in excluded)
    if not items:
        return ()
    common = gcd(*(val for _, val in items))
    if items[0][1] < 0:
        common = -common
    return tuple((key, val // common) for key, val in items)


def matrix_rank(vectors):
    """Exact sparse rational row rank for small lists of integer rows."""
    basis = {}
    for vector in vectors:
        row = dict(vector)
        while row:
            pivot = min(row)
            factor = row[pivot]
            if pivot not in basis:
                basis[pivot] = row
                break
            old = basis[pivot]
            left_scale, right_scale = old[pivot], factor
            common = gcd(left_scale, right_scale)
            row = {
                i: x for i in row.keys() | old.keys()
                if (x := row.get(i, 0) * (left_scale // common)
                    - old.get(i, 0) * (right_scale // common))
            }
    return len(basis)


def four_site_screen(signatures, full, deadline):
    """Enumerate the only four-site buckets that can beat the target residual."""
    counts = Counter()
    misses, survivors = [], []
    for side in (0, 1):
        buckets = defaultdict(list)
        for at, pair in signatures.items():
            buckets[pair[side]].append(at)
        counts[f"buckets_{side}"] = len(buckets)
        counts[f"largest_bucket_{side}"] = max(map(len, buckets.values()))
        counts[f"events_in_buckets_ge_4_{side}"] = sum(len(v) for v in buckets.values() if len(v) >= 4)
        for bucket in buckets.values():
            need(monotonic() < deadline, "four-site projection screen deadline")
            for selected in combinations(bucket, 4):
                counts[f"four_site_cases_{side}"] += 1
                other_rank = matrix_rank(signatures[i][1-side] for i in selected)
                if other_rank > 2:
                    continue
                need(other_rank == 2, "joint projective class contains no triple")
                counts[f"projection_survivors_{side}"] += 1
                inside_ranks = [matrix_rank(full[i][s] for i in selected) - k
                                for s, k in ((side, 1), (1-side, other_rank))]
                record = {"events": selected, "shared_projection_side": side,
                          "inside_intersection_ranks_shared_then_other": inside_ranks}
                if min(inside_ranks) == 0:
                    misses.append(record)
                else:
                    survivors.append(record)
    return {"census": dict(sorted(counts.items())), "misses_after_inner_support": misses,
            "survivors": survivors}


def analyze(word, deadline):
    b, inv, reads, effects, erasures, guards, nonzero_clear = capture(word, deadline)
    public = word["public"]
    levels = [len(frame) for frame in word["frames"]]
    counts = Counter()
    by_rank = Counter()
    passes = []
    outside_groups = defaultdict(list)
    signatures = {}
    full = {}
    erase_outputs = set(erasures.values())
    copy_outputs = set(guards.values())
    for event, read in reads.items():
        all_effect = effects[event]
        effect = reduced(all_effect[0], {dst: x for dst, x in all_effect[1].items() if dst < public})
        _, role, start, stop, owned = word["program"][event]
        step = levels[stop] - levels[start]
        kind = "owned-ascent" if owned and step > 0 else "owned-descent" if owned else "public"
        counts[f"{kind}:all"] += 1
        if not read[1]:
            counts[f"{kind}:zero-read"] += 1
        if not effect[1]:
            counts[f"{kind}:zero-effect"] += 1
        if all_effect[1].keys() & erase_outputs:
            counts[f"{kind}:affects-owned-clear-payload"] += 1
        if all_effect[1].keys() & copy_outputs:
            counts[f"{kind}:affects-exact-zero-copy-guard"] += 1
        if not read[1] or not effect[1]:
            continue
        row_clean = read[1].keys() <= b
        effect_clean = effect[1].keys() <= b
        if not row_clean and not effect_clean:
            key = projective_key(read, b), projective_key(effect, b)
            outside_groups[key].append(event)
            signatures[event] = key
            full[event] = projective_key(read, ()), projective_key(effect, ())
        counts[f"{kind}:pure-input"] += row_clean
        counts[f"{kind}:pure-output"] += effect_clean
        if not (row_clean and effect_clean):
            continue
        counts[f"{kind}:pure-both"] += 1
        strength = pairing(read, effect, inv)
        if strength != 1:
            continue
        counts[f"{kind}:rank-reducing"] += 1
        protected = all_effect[1].keys() - effect[1].keys()
        preserves_erased_payload = not protected & erase_outputs
        preserves_copy_guard = not protected & copy_outputs
        counts[f"{kind}:rank-reducing-with-same-erasure"] += preserves_erased_payload
        counts[f"{kind}:rank-reducing-with-same-copy-guard"] += preserves_copy_guard
        by_rank[abs(step)] += 1
        passes.append({"event": event, "role": role, "kind": kind, "old_step": step,
                       "old_frames": [start, stop], "information": show(read), "response": show(effect),
                       "preserves_erased_payload": preserves_erased_payload,
                       "preserves_copy_guard": preserves_copy_guard})
    need(len(reads) == len(effects) == 6_276 and len(erasures) == 74 and len(guards) == 1,
         "all source MOVE, CLEAR, and COPY occurrences")
    escape_groups = [events for events in outside_groups.values() if len(events) >= 3]
    diverse_groups = [ev for ev in escape_groups
                      if len({projective_key(reads[i], ()) for i in ev}) >= 2
                      and len({projective_key(effects[i], erase_outputs | copy_outputs) for i in ev}) >= 2]
    four_site = four_site_screen(signatures, full, deadline) if not escape_groups else None
    return {"source_word_sha256": WORD_SHA, "owned_clear_count": len(erasures),
            "owned_clear_nonzero_count": nonzero_clear, "protected_copy_count": len(guards),
            "type_b_rails": sorted(b), "counts": dict(sorted(counts.items())),
            "rank_reducing_old_rank_histogram": dict(sorted(by_rank.items())), "rank_reducing_sites": passes,
            "joint_outside_signature_group_sizes": dict(sorted(Counter(map(len, outside_groups.values())).items())),
            "three_or_more_proportional_outside_groups": escape_groups,
            "three_or_more_groups_variable_in_both_inside_projections": diverse_groups,
            "four_site_screen": four_site}


def self_test():
    a, b = (1, {0: 1, 1: 2}), (5, {0: -2, 1: -5})
    need(increment(a, a, (-1, 1)) == NONE, "signed cancellation")
    need(increment(a, b, (1, 2)) == (10, {0: 8, 1: 15}), "exact mixed denominator")
    inv = [(2, {0: 1, 1: 2}), (2, {0: -1, 1: 2})]
    need(pairing(unit(0), (1, {0: 1, 1: 1}), inv) == Fraction(3, 2), "non-unit pairing mutant")
    need(pairing(unit(0), (1, {1: 1}), inv) == 1, "unit pairing")
    need(projective_key((5, {0: 3, 1: -6, 2: 8}), {2}) == ((0, 1), (1, -2)), "outside normalization")
    need(projective_key((1, {0: -2, 1: 4}), ()) == ((0, 1), (1, -2)), "proportional sign normalization")
    need(matrix_rank([[(0, 1), (1, 2)], [(0, 2), (1, 4)], [(0, 1), (2, 5)]]) == 2,
         "sparse exact rank retains independent coordinate")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    self_test()
    raw = args.word.read_bytes()
    need(sha256(raw).hexdigest() == WORD_SHA, "pinned compressed #7546")
    start = monotonic()
    result = analyze(json.loads(gzip.decompress(raw)), start + 20)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"PASS 6276 directed response sites in {monotonic()-start:.3f}s; "
          f"rank-reducing={len(result['rank_reducing_sites'])}", flush=True)


if __name__ == "__main__":
    main()
