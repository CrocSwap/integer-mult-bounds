# Complex complemented adjoint of #7546

The #7546 native admits a reversed scalar topology with the same successful public field maps and the same full recursive rank profile. This supplies a second producer/receiver order for testing structural improvements. It needs sixteen additional dyadic scalar operations per native invocation, and the new ordinary precision and tape contracts have yet to be bound.

## Scalar identity and caller endpoints

Write the word in its normalized scalar charts. The literal single COPY starts at zero on every arbitrary input, as the rational replay checks; replace it by the corresponding ADD. Reverse the word and transpose each elementary operator. A coframe ADD exchanges source and destination, SCALE stays the same, and a zero INIT and owned CLEAR exchange roles. CLEAR discards an owned field that can be nonzero. The transpose of this rectangular discard is the injection of a zero owned field. The order retains every owned lifetime and every data dependency the transposed program needs.

Replace each F by its binary orthogonal complement F⊥ and swap the X and Y role within every pair, including all 96 second Type A pairs. It follows from reversal of both time and inclusion that all public MOVEs remain proper ascents. An owned MOVE retains its original orientation by the same argument. Complemented chart labels agree exactly with the original main boundary labels at all 800 contacts. Helpers keep their register IDs and independent identity rows with the same rank differences, since `dim(F⊥) = 9 − dim(F)`.

Let R exchange the two roles of a pair. For each Type A block S, a signed upper or lower shear, `R Sᵀ R = S`. For Type B the normalized block is

\[
M_B=\begin{pmatrix}1&-1\\1/2&1/2\end{pmatrix},\qquad
R M_B^{T} R=\begin{pmatrix}1/2&-1\\1/2&1\end{pmatrix}.
\]

The original block is recovered by scaling X at input by `2` and Y at output by `1/2`. Thus the emitted program keeps the Type B port interface and all arbitrary helper inputs exactly. There are 16 new SCALEs per native call, with no added paid recursive job.

## Signed physical charts and accounting

Over F₂ the canonical chart sends computational `Z` generator exponents to the Lagrangian

\[
L_F=\{(x,z): x\in F,\ x+z\in F^\perp\}.
\]

Use the canonical basis change `G` and its quadratic matrix `I+(GGᵀ)⁻¹` to check the two conditions. The common full quarter-turn maps `(x,z)` to `(x+z,z)`, hence maps `L_F` to `L_(F⊥)`. Its relative map with the canonical complement lies in the monomial subgroup; it can contain quadratic and signed factors. The exact program uses the canonical representative for each complement and ranks its relative MOVE from the complete signed tableau. An omitted nontrivial monomial gauge fails an exact Gaussian-dyadic phase control. The sample signed recipes use the existing exact Clifford lowerer. Their signed tableau and one full Gaussian-dyadic column establish the matrix, including its phase. The complete candidate's newly compiled elementary tape is outside the receipt.

All 6,276 paid native MOVEs match the old rank profile and all 1,101 productive helper rank differences match. All 2,955 distinct literal ordered MOVE pairs have the required physical rank, even counting equivalent labels separately. Five monomial chart gauges and thirteen representative MOVE recipes and their adjoints are lowered and compared exactly. The public scalar replay checks the 1,501 by 1,501 matrix, 74 INITs and CLEARs, and absence of uncovered COPY preconditions. The full inherited #7113 signed invoice using 17 equal-rank invocations retains the same 110,468 paid and 22,461 productive calls. Because both complete rank profiles agree, their recursive moment is exactly equal for every κ.

The literal dual has 66,340 ADD, 3,742 SCALE and no COPY. CALL, route, owned-slot and recovery rules still require concrete installation. The existing ordinary tariff assigns 16 units to each of the sixteen simple powers-of-two SCALEs. The added scalar allowance independently totals 256 units per native and 4,352 across 17 native calls. A new route and fixed-tape bill must also be charged before treating this as a complete application.

## Precision

The exact common normalized coefficient grid covers the stored rows and their pre-ADD products. Odd scale remains 1125. Its dyadic height drops from 25 to 20. This is an exact-grid improvement in the normalized scalar circuit. Peak row mass grows from approximately 91,295 to `60605389097/2560`, approximately 23.67 million. The reverse direction can amplify relative errors even with a better exact grid. The physical MOVE interior, scaled envelopes, recursive rounding/restoration, all-size recovery and full addressed tape are separate obligations. The original fixed-tape counts and precision constant cannot be taken as receipts for this reversed word. No κ improvement or new all-size bound follows directly.

## Reproduction

The standard-library verifier authenticates the exact #7546 tape and full signed tariff, and pins the source Gaussian-dyadic engine through `round3/independent/fresh_axis_lift.py`. The bounded one-CPU run completed in 7.69 seconds. No GPU or shared repository mutations were used.

```powershell
$python = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$inputs = '../integer-mult-local-recovery/work'
$out = 'work/round4/independent'
& $python -I -B -S -W error "$out/complex_adjoint.py" "$inputs/7546-word.json.gz" "$inputs/7546-whole.json" "$out/complex-adjoint.json" --emit "$out/complex-adjoint-word.json"
```

The canonical dual digest is `74722f7f052f8b61cb623ccc5640ba6eb8149208e5c3e702e5140a0402bd1a3f`. [#7546 exact-head tape](https://github.com/ToikY/integer-mult-bounds/blob/99438c43df7aac1e5dbcc43c1578fcd886c119ec/research/p104-role902-direct-lift/expected/role902-WORD.json.gz) · [#7546 hosted replay](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050) · [#7113 signed caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7113)
