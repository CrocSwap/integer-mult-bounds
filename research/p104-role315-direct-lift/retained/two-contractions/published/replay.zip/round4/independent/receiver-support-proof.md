# Type B cross-cut rank on #7546

The first Type B stage has 16 native return rails, two for each of eight ports. Keep the exact #7546 native scalar history and compare its public input/output operator at a common Fourier fiber. The fresh-axis target changes it by a rank-16 matrix supported on just those Type B input and output rails. The old inputs include all 1,501 independent public fields, which include dirty helpers. The caller can be specialized to old characters with phase 1. At tensor width two, a positive quarter-turn on both fresh copies has eigenvalue −1 on the two negative fresh characters. Restore the old invertible public host matrix `M` to the common gauge and the desired difference at this fiber is a nonzero scalar multiple of `P_B M`, where `P_B` keeps the 16 Type B output rows. The other native stages and the retained caller act as in the J1 correction test in round 3.

## A rank test that includes interactions

Change `m` literal paid MOVE sites. A changed occurrence at register `j` multiplies that field by scalar `1 + d` at the selected fiber in the normalized charts, with `d ≠ 0`. The model permits arbitrary scalars and a free reassignment of the old physical rank on the changed site. It preserves the literal scalar prefix and suffix. For occurrence `i` let `v_i` be the row of independent input coefficients before that event, and `u_i` the column giving its unit response in all public returns. Both are measured in the unmodified native word. Put the columns in `U` and the rows in `V`.

Every interaction between sites is included in `D = U K V`, the difference between the modified and original native endpoint. For example, a term using changed sites `i<j` has a scalar propagation coefficient from the output of `i` to the input of `j`, with exterior column `u_j` and row `v_i`. More generally the inputs to the changed sites satisfy `z = V x + L diag(d_i) z`, where `L` is strictly lower triangular. Thus `K = diag(d_i)(I − L diag(d_i))⁻¹` is lower triangular and invertible.

Let `α` be the rank of `U` projected onto the complement of the 16 Type B outputs, and `β` the rank of `V` restricted to the complement of the 16 Type B inputs. Factor the desired rank-16 difference `A=A_L A_R` in its independent target and source spaces. Then

\[
\begin{aligned}
A-D &= [A_L\mid U]\,\operatorname{diag}(I,-K)\,\begin{bmatrix}A_R\\V\end{bmatrix}, \\
\operatorname{rank}(A-D)&\geq16+\alpha+\beta-m.
\end{aligned}
\]

The first outer factor has rank `16+α`, the second `16+β`. The middle factor is invertible. Sylvester's rank inequality gives the stated bound. After the changed sites, each corrective one-field occurrence contributes a rank-at-most-one difference. Arbitrary ordinary scalar recombination before or after these corrections does not change that rank estimate when the common uncorrected endpoint is fixed in the positive fresh sector. In particular, 15 or fewer such corrections need `α+β < m`. All this computation is at a necessary single fiber. It grants the changed MOVE arbitrary scalar gains there, but does not cover gates that mix the selected fiber with another fiber or changes to the retained contacts.

## Exact #7546 census

The attached verifier replays coefficients over the rationals in two directions. A forward pass checks every complete public row, all frames, own-slot lifecycle and the zero destination before COPY. In reverse, a basis vector is propagated from each public output, with separate coordinates for the COPY guard and each erased payload. The expected public map is the disjoint Type A and Type B main map plus the identity on every helper. CLEAR is a valid owned discard. In the pinned tape 73 of 74 pre-CLEAR payloads are nonzero formal linear forms.

Every one of the 6,276 literal paid MOVE occurrences has nonzero outside input and outside output response. This includes 23 owned ascents and 24 owned descents. The only COPY zero guard is unaffected by every MOVE response. The projection ranks therefore satisfy `α≥1`, `β≥1` for any nonempty set of changed sites, which settles `m≤2`.

For `m=3` only `α=β=1` can improve. Group sites by their pair of projective outside input/output rays. Primitive integer forms represent these rays exactly. There are 6,260 singleton groups and eight groups of two. No group contains three sites.

For `m=4` one side must have outside rank 1 and the other rank 1 or 2. The largest one-sided ray buckets have four occurrences, so the full screen has 14 four-tuples on the incoming side and 15 on the outgoing side. Rational row elimination gives opposite rank at least three for every tuple. Thus **changing up to four literal paid MOVE sites cannot replace even one of the 16 standalone field corrections** under this scalar-fiber and fixed-contact model. The conclusion allows interactions among the changed sites and does not depend on their current ranks or on a particular tariff.

The conditional tariff at the open #7546 quote leaves about 15.54038 raw units for J1's 16 standalone rank-one corrections. Their charge is 16 even when all tested changes in this model are granted for free. More changed sites, interleaved corrective calls, changed scalar producer/receiver contacts, or a physical provider that mixes the old Fourier fibers require a new test. No new recursive profile or κ follows from this exclusion.

## Comparison with upstream

Open PR #7574 at `88665d52c614eb1b33c8b78aa7e35f90d68e4ff5` fixes #7481 contacts and external boundaries, and reports a concave paid-cost obstruction for its frame assignments. Open PR #7577 at `509baf4514966e4202cfdde379d7adf3085b1cc7` fixes #7481's whole jobs and owned histories in a different helper/cache joint ceiling. Its approximately 0.00373479 is a scope-limited ceiling. The recorded hosted plans failed and their scientific replay jobs were skipped. This independent #7546 check uses a different source and a fixed-history response-rank condition for the changed B boundary. [#7574 and plan](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43545160407/job/132294657051) · [#7577 and plan](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43545208871/job/132294819113)

## Reproduction

Use the exact published #7546 compressed tape with SHA-256 `6e03624b173b90356e96f845d05fc93153846b863734dc8163ab6c44c602cd32`. The verifier uses only Python's standard library. One CPU process, a 20-second deadline and no GPU. The last run completed in 3.49 seconds. Warning-strict CPython, AST parsing, tabnanny and exact proportional/nonunit-pairing controls passed.

```powershell
$python = 'C:\Users\cuchu\Documents\ComfyUI-DaSiWa\ComfyUI_windows_portable\python_embeded\python.exe'
$word = '../integer-mult-local-recovery/work/7546-word.json.gz'
& $python -I -B -S -W error work/round4/independent/receiver_support.py $word work/round4/independent/receiver-support.json
```

The full round 3 J1 companion is `work/round3/independent/j1-fresh-axis-floor.md`. [#7546 pinned word](https://github.com/ToikY/integer-mult-bounds/blob/99438c43df7aac1e5dbcc43c1578fcd886c119ec/research/p104-role902-direct-lift/expected/role902-WORD.json.gz) · [#7546 hosted replay](https://github.com/CrocSwap/integer-mult-bounds/actions/runs/43521106941/job/132217523050) · [#7113 signed caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7113)
