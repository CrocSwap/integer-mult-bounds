"""Construct and verify the exact complemented adjoint of the #7546 native."""

import argparse
from collections import Counter
from fractions import Fraction
import gzip
from hashlib import sha256
import json
from math import lcm
from pathlib import Path
from runpy import run_path
from time import monotonic


HERE = Path(__file__).resolve().parent
ROWS = run_path(str(HERE / "receiver_support.py"))
PHYSICAL = run_path(str(HERE.parents[1] / "round3" / "independent" / "fresh_axis_lift.py"))
need = ROWS["need"]
NATIVE_HEAD = "99438c43df7aac1e5dbcc43c1578fcd886c119ec"
WHOLE_SHA = "a0beec65810ba6be75053761eeab6a763506ac224e53c6187d8c8e977e1eefb9"
ALL = frozenset(range(512))


def digest(word):
    return sha256(json.dumps(word, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def span(lines):
    subspace = {0}
    for line in lines:
        need(line not in subspace, "independent chart directions")
        subspace.update(x ^ line for x in tuple(subspace))
    return frozenset(subspace)


def orthogonal(lines):
    return frozenset(x for x in ALL if all(not ((x & v).bit_count() & 1) for v in lines))


def basis(subspace):
    used, result = {0}, []
    for line in sorted(subspace):
        if line not in used:
            result.append(line)
            used.update(x ^ line for x in tuple(used))
    need(used == subspace, "canonical complement spans every direction")
    return result


def role_gauge(word):
    n = word["public"] + word["owned_fields"]
    role_map = list(range(n))
    type_b_x = set()
    h = word["hosted"]
    ap = set(h["Dports"])
    for pi, x in enumerate(word["live"]):
        y = x + 112
        role_map[x], role_map[y] = y, x
        if pi not in ap:
            type_b_x.add(x)
    for x, y in zip(h["X2"], h["Y2"], strict=True):
        role_map[x], role_map[y] = y, x
    need(len(set(role_map)) == n, "public permutation and original owned slots")
    return role_map, type_b_x


def build(word):
    frames = [*word["frames"]]
    primal_spaces = [span(f) for f in frames]
    labels = {space: i for i, space in reversed(list(enumerate(primal_spaces)))}
    chart_map = []
    for f, space in zip(word["frames"], primal_spaces, strict=True):
        perp = orthogonal(f)
        need(len(perp) * len(space) == len(ALL), "proper dimension complement")
        if perp not in labels:
            labels[perp] = len(frames)
            frames.append(basis(perp))
        chart_map.append(labels[perp])
    role_map, type_b_x = role_gauge(word)
    initial, final = [None] * word["public"], [None] * word["public"]
    main = main_roles(word)
    old_labels_by_new = {}
    for r, (u, v) in enumerate(zip(word["initial"], word["final"], strict=True)):
        nr = role_map[r]
        if nr in main:
            for f, required in ((v, word["initial"][nr]), (u, word["final"][nr])):
                need(primal_spaces[required] == orthogonal(word["frames"][f]), "complemented main contact shape")
                need(f not in old_labels_by_new or old_labels_by_new[f] == required, "canonical main aliases agree")
                old_labels_by_new[f] = required
                chart_map[f] = required
    for r, (u, v) in enumerate(zip(word["initial"], word["final"], strict=True)):
        nr = role_map[r]
        initial[nr], final[nr] = chart_map[v], chart_map[u]
    program = []
    for x in sorted(type_b_x):
        program.append(["SCALE", x, "2", initial[x]])
    for op, reg, *args in reversed(word["program"]):
        r = role_map[reg]
        if op == "MOVE":
            u, v, owned = args
            program.append([op, r, chart_map[v], chart_map[u], owned])
        elif op in ("INIT", "CLEAR"):
            program.append(["INIT" if op == "CLEAR" else "CLEAR", r, chart_map[args[0]]])
        elif op == "SCALE":
            factor, f = args
            program.append([op, r, factor, chart_map[f]])
        else:
            source, factor, f = args
            need(op in ("ADD", "COPY"), "old scalar opcode")
            s = role_map[source]
            # The sole COPY had an exactly zero destination on all allowed inputs.
            # Translate it into ADD before adjoint so the real linear transpose exists.
            program.append(["ADD", s, r, factor, chart_map[f]])
    for y in sorted(x + 112 for x in type_b_x):
        program.append(["SCALE", y, "1/2", final[y]])
    return {**word, "schema": "p104-complemented-adjoint-candidate/v1", "frames": frames,
            "initial": initial, "final": final, "program": program}, chart_map, role_map


def main_roles(word):
    h = word["hosted"]
    return {*word["live"], *(x + 112 for x in word["live"]), *h["X2"], *h["Y2"]}


def literal_replay(word, expected, deadline):
    n, o = word["public"], word["owned_fields"]
    dim = [len(f) for f in word["frames"]]
    spaces = [span(f) for f in word["frames"]]
    place = word["initial"][:] + [None] * o
    rows = [ROWS["unit"](i) for i in range(n)] + [ROWS["NONE"]] * o
    odd_lcm, height = 1, 0
    max_mass, mass_witness = Fraction(1), [-1, 0, "entrance"]
    paid, operations, produced = Counter(), Counter(), Counter()
    odd_surcharge = Counter()
    clear_nonzero = 0

    def inspect(row, event, reg, kind):
        nonlocal odd_lcm, height, max_mass, mass_witness
        d, values = row
        low = (d & -d).bit_length() - 1
        height = max(height, low)
        odd_lcm = lcm(odd_lcm, d >> low)
        mass = sum(abs(x) for x in values.values())
        if mass * max_mass.denominator > d * max_mass.numerator:
            max_mass, mass_witness = Fraction(mass, d), [event, reg, kind]

    for i, (op, r, *args) in enumerate(word["program"]):
        if i % 512 == 0:
            need(monotonic() < deadline, "bounded literal adjoint replay")
        operations[op] += 1
        if op == "INIT":
            need(r >= n and place[r] is None and not rows[r][1], "adjoint owned INIT")
            place[r] = args[0]
        elif op == "CLEAR":
            need(r >= n and place[r] == args[0], "adjoint owned CLEAR")
            clear_nonzero += bool(rows[r][1])
            place[r], rows[r] = None, ROWS["NONE"]
        elif op == "MOVE":
            u, v, owned = args
            need(place[r] == u and owned == (r >= n), "adjoint MOVE placement")
            need(spaces[u] < spaces[v] or (owned and spaces[v] < spaces[u]), "adjoint MOVE nesting")
            paid[abs(dim[v] - dim[u])] += 1
            place[r] = v
        else:
            factor, f = args[-2:]
            coeff = ROWS["ratio"](factor)
            odd_surcharge[op] += bool(coeff[1] & (coeff[1] - 1))
            need(place[r] == f, "adjoint scalar receiver coframe")
            if op == "SCALE":
                rows[r] = ROWS["scale"](rows[r], coeff)
            else:
                source = args[0]
                need(op == "ADD" and r != source and place[source] == f, "adjoint scalar sender coframe")
                addend = ROWS["scale"](rows[source], coeff)
                inspect(addend, i, r, "product")
                rows[r] = ROWS["increment"](rows[r], rows[source], coeff)
            inspect(rows[r], i, r, "stored")
    need(rows[:n] == expected and not any(x[1] for x in rows[n:]), "all adjoint dirty outputs")
    need(place == word["final"] + [None] * o, "all adjoint output frames")
    mains = main_roles(word)
    for r in range(n):
        if r not in mains:
            u, v = word["initial"][r], word["final"][r]
            need(spaces[u] < spaces[v], "positive independent adjoint helper")
            produced[dim[v] - dim[u]] += 1
    return {"operations": dict(sorted(operations.items())), "paid": dict(sorted(paid.items())),
            "native_helper_targets": dict(sorted(produced.items())), "checked_public_coefficients": n*n,
            "erased_nonzero_owned_payloads": clear_nonzero, "coefficient_grid": [odd_lcm, height],
            "odd_denominator_op_counts": dict(sorted(odd_surcharge.items())),
            "normalized_maximum_L1_mass": str(max_mass), "mass_witness": mass_witness}


def physical_covariance(compiler, word, dual, charts, deadline):
    """Check the complemented Lagrangian and lower actual representative moves."""
    gauges = {}
    ops = []
    for i, frame in enumerate(dual["frames"]):
        if i % 32 == 0:
            need(monotonic() < deadline, "physical chart spectral replay deadline")
        ops.append(compiler.canonical_frame(9, frame))
    full = compiler.fourier(9)
    for i, j in enumerate(charts):
        if i % 32 == 0:
            need(monotonic() < deadline, "signed monomial gauge deadline")
        # Both charts encode the same Lagrangian after one common full turn.
        # Consequently this relative operation is exactly monomial.
        gauge = ops[i].then(full).then(ops[j].adjoint())
        need(all(x == 0 and p % 2 == 0 for x, _, p in gauge.tab[9:]),
             "canonical complement is monomial-equivalent to common full turn")
        gauges[i] = gauge

    pairs = {(u, v) for (op, _, *args) in word["program"] if op == "MOVE" for u, v in [args[:2]]}
    inverse_tableaus = [compiler.inverse(op.tab) for op in ops]
    pair_hist = Counter()
    examples = {}
    for u, v in sorted(pairs):
        a, b = charts[v], charts[u]
        t = compiler.compose(ops[b].tab, inverse_tableaus[a])
        old_rank = abs(len(word["frames"][v]) - len(word["frames"][u]))
        need(compiler.rank([x for x, _, _ in t[9:]]) == old_rank,
             "exact rank of complemented canonical MOVE")
        owned_descent = len(word["frames"][u]) > len(word["frames"][v])
        pair_hist[old_rank] += 1
        examples.setdefault((owned_descent, old_rank), (u, v))

    main = main_roles(word)
    # Using the old label for every repeated space makes all old caller main
    # wrappers exactly identical, including their phases and global factors.
    for role in main:
        for a, b in ((word["initial"][role], dual["initial"][role]),
                     (word["final"][role], dual["final"][role])):
            need(a == b, "exact same caller main boundary label")

    # One exact Gaussian-dyadic column fixes the phase left unspecified by a tableau.
    verify_equal = PHYSICAL["equal_signed_clifford"]
    gauge_examples = [0, 3, 127, 470, 1090]
    nontrivial_gauge = False
    for i in gauge_examples:
        fixed, _ = compiler.monomial(gauges[i])
        expected = ops[i].then(full)
        verify_equal(fixed.then(ops[charts[i]]), expected, True)
        nontrivial_gauge |= ops[charts[i]].zero_state() != expected.zero_state()
    need(nontrivial_gauge, "omitted monomial gauge control")
    sample_recipes = []
    for (_, r), (u, v) in sorted(examples.items()):
        candidate = ops[charts[v]].adjoint().then(ops[charts[u]])
        recipe, compiled = compiler.lower_child(candidate)
        need(recipe["rank"] == r, "exact representative child rank")
        verify_equal(candidate.adjoint(), compiled.adjoint(), True)
        sample_recipes.append({"primal_pair": [u, v], "dual_pair": [charts[v], charts[u]], "rank": r})
    return {"old_frames_with_signed_monomial_covariance": len(gauges),
            "old_frame_count": len(charts), "literal_distinct_move_pairs": len(pairs),
            "distinct_move_ranks": dict(sorted(pair_hist.items())),
            "main_boundary_shape_checks": 2 * len(main),
            "main_adapters_exactly_inherited": True,
            "gaussian_dyadic_gauge_examples": gauge_examples,
            "sample_exact_lowered_recipes_and_adjoint": sample_recipes,
            "omitting_monomial_gauge_rejected": nontrivial_gauge}


def check_tariff(word, baseline, result):
    dims = list(map(len, word["frames"]))
    before = Counter(abs(dims[b] - dims[a]) for op, _, *args in word["program"]
                     if op == "MOVE" for a, b in [args[:2]])
    need(before == result["paid"], "entire native paid rank profile preserved")
    prod = baseline["signed_profile"]["native_productive"]
    need(result["native_helper_targets"] == {int(k): v for k, v in prod.items()},
         "exact independent native helper target profile preserved")
    return {key: sum(baseline["signed_profile"][key].values()) for key in ("signed_paid", "signed_productive")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("whole", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--emit", type=Path)
    args = parser.parse_args()
    start = monotonic()
    deadline = start + 35
    compiler, word = PHYSICAL["load_pins"](args.word)
    raw = args.whole.read_bytes()
    need(sha256(raw).hexdigest() == WHOLE_SHA, "pinned complete signed receipt")
    whole = json.loads(raw)
    # The source verifier proves the COPY destination zero on arbitrary inputs.
    ROWS["capture"](word, deadline)
    dual, charts, _ = build(word)
    _, expected, _ = ROWS["target"](word)
    exact = literal_replay(dual, expected, deadline)
    signed = check_tariff(word, whole, exact)
    physical = physical_covariance(compiler, word, dual, charts, deadline)
    need(monotonic() < deadline, "complete complemented replay before timebox")
    result = {"status": "PASS_COMPLEX_COMPLEMENTED_ADJOINT", "old_head": NATIVE_HEAD,
              "old_compressed_sha256": ROWS["WORD_SHA"], "dual_canonical_sha256": digest(dual),
              "dual_frames": len({f for f in charts}), "entire_signed_tariff_count": signed,
              "literal": exact, "physical": physical}
    if args.emit:
        args.emit.write_text(json.dumps(dual, separators=(",", ":")) + "\n", encoding="utf-8")
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(result["status"], f"in {monotonic()-start:.2f}s; {sum(exact['paid'].values())} old-rank calls", flush=True)


if __name__ == "__main__":
    main()
