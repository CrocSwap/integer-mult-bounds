# Round 4 exact replay

Extract the ZIP and run these commands at its root with standard-library
CPython 3.11 or later. The #7001 and #7546 inputs and the full #7546 signed
receipt are pinned. Use the canonical repository path for the final replay,
which authenticates and reads its source objects with Git.

```powershell
$q = 'inputs/7546-word.json.gz'
$caller = 'inputs/7113-caller.json'
$bill = 'inputs/7546-whole.json'
$out = (New-Item -ItemType Directory -Path 'run' -Force).FullName
python -I -B -S -W error round4/complex_terminal_transport.py $q $caller $bill "$out/terminal.json"
python -I -B -S -W error round4/terminal_frontier.py $q "$out/frontier.json"
python -I -B -S -W error round4/caller_phase_hiding.py $caller $bill "$out/phase.json"
python -I -B -S -W error round4/seam_rank_one.py $q "$out/seam.json"
python -I -B -S -W error round4/helper_bank_contraction.py $q $bill "$out/contract.json"
python -I -B -S -W error round4/complex_projection_stages.py $q $caller $bill "$out/project.json"
python -I -B -S -W error round4/complex_axis_rebuild.py $q $caller $bill "$out/rebuild.json" --emit "$out/rebuilt-word.json"
python -I -B -S -W error round4/complex_partial_projection.py $q $caller $bill "$out/partial.json"
python -I -B -S -W error round4/complex_prune_central.py $q $caller $bill "$out/prune.json"
python -I -B -S -W error round4/weighted_l1_tariff.py "$out/l1.json"
python -I -B -S -W error round4/complex_caller_envelope.py $q $caller $bill "$out/complex-envelope.json"
python -I -B -S -W error round4/independent/receiver_support.py $q "$out/support.json"
python -I -B -S -W error round4/independent/complex_adjoint.py $q $bill "$out/dual.json" --emit "$out/dual-word.json"
python -I -B -S -W error round4/algebra/singleton_descent.py
python -I -B -S -W error round4/recurrence/verify_signed_body_tariff.py 'C:\Users\cuchu\Documents\Codex\integer-mult-bounds'
```

The last two commands print their receipts as JSON. Do not use Python `-O`
for runs that load the upstream interval or Clifford engines. The two small
standalone BIT checks also pass under `-O`. The replay code reads the original
operand and owner chronology. Exact matrix and moment comparison must use the
full inventory, not just the displayed ranks at the modified ports.

The projection experiment emits a candidate with all dirty scalar returns
and explicit A boundary adapters. Its signed recursive cost loses even when
new ordinary/tape costs are waived. The emitted complemented adjoint preserves
old recursive rank counts. It needs a new physical precision and tape receipt
if proposed for use. The best helper-only seam projection is a screened lead
whose outside return effect rejects it as a one-contact change. The BIT power
tariff is a theorem for the formal target/operator interface stated in its
proof; the finite cycle replay only serves as an independent control.
The product-cut extension is in `WEIGHTED-L1-TARIFF.md` and also applies to
signed target exponents with a weighted total length.

Round 3 support code and the source attribution are included for replay. The
read-only API receipt `upstream-checks.json` records the exact heads checked
on November 14, 2026 KST. No script here writes into the canonical checkout
or performs a public action.
