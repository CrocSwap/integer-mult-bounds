# SPDX-License-Identifier: Apache-2.0
"""Rebuild #7546 on an eight-dimensional quotient and repair every public contact."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
PROJ = run_path(str(HERE / "complex_projection_stages.py"))
SOURCE, AXIS, NEED, EXACT = (PROJ[k] for k in ("SOURCE", "AXIS", "NEED", "EXACT"))
ADJ = run_path(str(HERE / "independent/complex_adjoint.py"))
ROWS = ADJ["ROWS"]


def orthogonal_projection(v, axis):
    return v ^ axis if (v & axis).bit_count() % 2 else v


def revised_native(word, axis, deadline, shorten_commuting_a=False):
    """Change all visits together, restore original A rails, and check exact stock."""
    helpers, b = AXIS["helper_roles"](word)
    mains = ADJ["main_roles"](word)
    a = set(mains) - b
    ports = {}
    for pi, r in enumerate(word["live"]):
        ports[r]=word["ports"][pi];ports[112+r]=word["ports"][pi]
    hosted=word["hosted"]
    for pi,r,s in zip(hosted["Dports"],hosted["X2"],hosted["Y2"],strict=True):
        ports[r]=word["ports"][pi];ports[s]=word["ports"][pi]
    if shorten_commuting_a:
        # Where q is perpendicular to the removed axis, retain q and use
        # a seven-axis body. Explicit repairs still serve other A ports.
        a = {r for r in a if (ports[r]&axis).bit_count()%2}
    packed = []
    versions, ids = [], {}
    old_spaces = [EXACT["chart_space"](bank) for bank in word["frames"]]

    def intern(space):
        if space not in ids:
            ids[space] = len(versions)
            versions.append(ADJ["basis"](space))
        return ids[space]

    for space in old_spaces:
        projected = frozenset(orthogonal_projection(v,axis) for v in space)
        packed.append(intern(projected))
    old_ref = [intern(space) for space in old_spaces]
    n = word["public"]
    starts, ends, paid = [], [], Counter()
    initial_repairs = Counter()
    final_repairs = Counter()
    tape = []
    for r, old in enumerate(word["initial"]):
        p = packed[old]
        if r in a and old_ref[old] != p:
            starts.append(old_ref[old]); tape.append(["BOUNDARY",r,old_ref[old],p,False]); initial_repairs[r] = 1
        else:
            starts.append(p)
    for i, (op, r, *parts) in enumerate(word["program"]):
        if i%1024==0:
            NEED(monotonic()<deadline,"exact quotient word deadline")
        if op=="MOVE":
            u,v,o = parts
            f,g = packed[u],packed[v]
            if f != g:
                tape.append([op,r,f,g,o]); paid[abs(len(versions[f])-len(versions[g]))] += 1
        else:
            tape.append([op,r,*parts[:-1],packed[parts[-1]]])
    for r, old in enumerate(word["final"]):
        p = packed[old]
        if r in a and old_ref[old] != p:
            ends.append(old_ref[old]); tape.append(["BOUNDARY",r,p,old_ref[old],False]); final_repairs[r] = 1
        else:
            ends.append(p)
    qword = {**word,"schema":"complex-quotient-boundary-rebuild/v1","frames":versions,
             "initial":starts,"final":ends,"program":tape}
    quotient_helpers = Counter(len(versions[ends[r]])-len(versions[starts[r]]) for r in helpers)
    NEED(sum(quotient_helpers.values())==len(helpers),"every independent helper is counted even with a zero difference")
    positive = +quotient_helpers
    positive.pop(0,None)
    return qword, dict(initial=sorted(initial_repairs),final=sorted(final_repairs)), paid, positive, quotient_helpers[0]


def verify_rebuilt_scalar(word, candidate, deadline):
    """Replay arbitrary inputs and actual frame visits, with exact rational scalar stock."""
    n, o = word["public"], word["owned_fields"]
    modes = [frozenset(ADJ["span"](f)) for f in candidate["frames"]]
    _, target, _ = ROWS["target"](word)
    logical = [ROWS["unit"](r) for r in range(n)] + [ROWS["NONE"]]*o
    place = candidate["initial"][:] + [None]*o
    boundaries, moves = [], Counter()
    for i, (op,r,*a) in enumerate(candidate["program"]):
        if i%512==0:
            NEED(monotonic()<deadline,"full independent scalar and frame replay deadline")
        if op in ("MOVE","BOUNDARY"):
            f,g,owned = a
            NEED(place[r]==f and owned==(r>=n),"source of every paid move is present")
            if op=="MOVE":
                NEED(modes[f]<modes[g] or owned and modes[g]<modes[f], "quotients preserve logical nested projection")
                moves[abs(len(candidate["frames"][f])-len(candidate["frames"][g]))]+=1
            else:
                boundaries.append((r,f,g))
            place[r]=g
        elif op=="INIT":
            NEED(place[r] is None and not logical[r][1],"exact owned zero")
            place[r]=a[0]
        elif op=="CLEAR":
            NEED(place[r]==a[0],"exact owned return")
            place[r]=None
            logical[r]=ROWS["NONE"]
        elif op=="SCALE":
            NEED(place[r]==a[-1],"SCALE coframe")
            logical[r]=ROWS["scale"](logical[r],ROWS["ratio"](a[0]))
        else:
            j,c,f=a
            NEED(op in ("ADD","COPY") and place[r]==place[j]==f,"ADD coframe")
            if op=="COPY":
                NEED(logical[r]==ROWS["NONE"],"COPY exact zero after collapse")
            logical[r]=ROWS["increment"](logical[r],logical[j],ROWS["ratio"](c))
    NEED(logical[:n]==target and place==candidate["final"]+[None]*o,"all public outputs and original dirty owners")
    NEED(all(logical[r]==ROWS["NONE"] for r in range(n,n+o)),"release every owned role")
    return modes,boundaries,moves


def exact_ranks(compiler, candidate, boundary, deadline):
    """Check exact canonical tableau rank for each distinct child and each repair."""
    tabs=[]
    for i, frame in enumerate(candidate["frames"]):
        if i%32==0:
            NEED(monotonic()<deadline,"canonical frame rank budget")
        tabs.append(compiler.canonical_frame(9,frame))
    inverses=[compiler.inverse(a.tab) for a in tabs]
    pairs={tuple(p[2:4]) for p in candidate["program"] if p[0] in ("MOVE","BOUNDARY")}
    cache={}
    for f,g in pairs:
        if len(cache)%128==0:
            NEED(monotonic()<deadline,"distinct exact MOVE tableau rank limit")
        t=compiler.compose(tabs[g].tab,inverses[f])
        cache[f,g]=compiler.rank([x for x,_,_ in t[9:]])
    hist=Counter()
    for op,r,*d in candidate["program"]:
        if op in ("MOVE","BOUNDARY"):
            f,g=d[:2]
            if op=="MOVE":
                NEED(cache[f,g]==abs(len(candidate["frames"][f])-len(candidate["frames"][g])),"all interior ranks literally valid")
            elif cache[f,g]:
                hist[cache[f,g]]+=1
    checked=[]
    for f,g in sorted({(u,v) for _,u,v in boundary})[:6]:
        goal=tabs[f].adjoint().then(tabs[g]); recipe,lowered=compiler.lower_child(goal)
        NEED(recipe["rank"]==cache[f,g] and lowered.tab==goal.tab and lowered.zero_state()==goal.zero_state(),"exact signed adapter and phase")
        checked.append([f,g,cache[f,g]])
    return hist,len(pairs),checked


def full_bill(caller, original_word, whole, modified_p, modified_t, boundary_p):
    orig_p=Counter(abs(len(original_word["frames"][d[0]])-len(original_word["frames"][d[1]]))
                   for op,_,*d in original_word["program"] if op=="MOVE")
    orig_t=Counter({int(k):v for k,v in whole["signed_profile"]["native_productive"].items()})
    dp=modified_p.copy();dp.update(boundary_p);dp.subtract(orig_p)
    dt=modified_t.copy();dt.subtract(orig_t)
    B=len(caller["types"]["B"]["ports"])
    extra_p,extra_t=PROJ["type_delta"](caller,"B",7,B)
    p,t=(Counter({int(k):v for k,v in whole["signed_profile"][name].items()}) for name in ("signed_paid","signed_productive"))
    for r,k in dp.items(): p[r]+=caller["stages"]*k
    for r,k in dt.items(): t[r]+=caller["stages"]*k
    p.update(extra_p);t.update(extra_t)
    NEED(min(p.values())>=0 and min(t.values())>=0,"every child and target counted exactly")
    engine=SOURCE["price_engine"]()
    data={}
    for s in (AXIS["INCUMBENT"],Fraction("0.005"),Fraction("0.0227")):
        z=engine.sub(engine.moment(t,s),engine.moment(p,s))
        data[str(s)]={"full_rebuilt_balance":engine.value(z),"directed_interval":engine.show(z)}
    return {"paid":+p,"productive":+t,"signed_balance":data,"paid_count":p.total(),"productive_count":t.total()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word",type=Path);parser.add_argument("caller",type=Path);parser.add_argument("original_bill",type=Path)
    parser.add_argument("output",type=Path);parser.add_argument("--emit",type=Path)
    ns=parser.parse_args()
    start,deadline=perf_counter(),monotonic()+40
    compiler,w=ADJ["PHYSICAL"]["load_pins"](ns.word)
    c=EXACT["pinned_json"](ns.caller,EXACT["CALLER_SHA"])
    h=json.loads(SOURCE["pin"](ns.original_bill,SOURCE["WHOLE"]))
    guide=372
    q,where,paid,target,zero=revised_native(w,guide,deadline)
    _,contacts,checked=verify_rebuilt_scalar(w,q,deadline)
    NEED(paid==checked,"independent MOVE histogram replay")
    sb,distinct,physical=exact_ranks(compiler,q,contacts,deadline)
    bill=full_bill(c,w,h,paid,target,sb)
    # On the commuting A ports we can keep q exactly and treat one tensor
    # direction as a seven-axis body, as for B. On the other ports this
    # variant keeps the same explicit old boundary repairs. Thus there are
    # no free replacements of lost central actions in this best orientation.
    alt,alt_where,alt_paid,alt_target,_=revised_native(w,guide,deadline,True)
    _,alt_contacts,alt_count=verify_rebuilt_scalar(w,alt,deadline)
    NEED(alt_paid==alt_count==paid,"revised boundary choice leaves the exact same interior rank invoice")
    alt_sb,alt_distinct,alt_physical=exact_ranks(compiler,alt,alt_contacts,deadline)
    kept = len({j for j in w["hosted"]["Dports"] if (w["ports"][j]&guide).bit_count()%2==0})
    outer_p,outer_t=PROJ["type_delta"](c,"A",7,kept)
    alt_bill=full_bill(c,w,h,alt_paid,alt_target,alt_sb)
    p,t=[Counter(a) for a in (alt_bill["paid"],alt_bill["productive"])]
    p.update(outer_p);t.update(outer_t)
    price=SOURCE["price_engine"]()
    variant_margins={}
    for saving in (AXIS["INCUMBENT"],Fraction(".005"),Fraction(".0227")):
        z=price.sub(price.moment(t,saving),price.moment(p,saving))
        variant_margins[str(saving)]={"value":price.value(z),"directed_interval":price.show(z)}
    result={"status":"PASS_COMPLEX_QUOTIENT_REBUILD_FINITE","removed_axis":guide,
            "boundary_repairs_before_address_matching":{k:len(v) for k,v in where.items()},
            "all_public_scalar_coefficients":w["public"]**2,"zero_public_helper_returns_uncredited":zero,
            "interior_paid_by_rank":paid,"positive_helper_ranks":target,"actual_boundary_debits":sb,
            "distinct_address_moves":distinct,"sample_phases":physical,"complete_recursion":bill,
            "type_A_keep_only_noncommuting_original_interfaces":{"seven_axis_ports":kept,"boundary_counts":{k:len(v) for k,v in alt_where.items()},
                "actual_boundary_debits":alt_sb,"distinct_address_moves":alt_distinct,"sample_phases":alt_physical,
                "changed_inventory":{"paid":+p,"productive":+t},"full_moments":variant_margins},
            "canonical_rebuilt_word_sha256":ADJ["digest"](q),"scope":"exact coframe and signed tableau, prices include terminal conversions; uniform physical routing, precision, tape and outer compilation still separate"}
    if ns.emit is not None: ns.emit.write_text(json.dumps(q,separators=(",",":"))+"\n",encoding="utf-8")
    ns.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(result["status"],f"{perf_counter()-start:.2f}s")


if __name__=="__main__":
    main()
