# SPDX-License-Identifier: Apache-2.0
"""Optimize a coupled choice of original and projected frames on #7546."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
CORE = run_path(str(HERE / "complex_axis_rebuild.py"))
AXIS, SOURCE, ADJ, EXACT, NEED = (CORE[k] for k in ("AXIS", "SOURCE", "ADJ", "EXACT", "NEED"))
FLOW, PROFILE = AXIS["FLOW"], CORE["PROJ"]


def frame_distance(u, v):
    """Rank of the off-diagonal Gaussian block, via the common Lagrangian."""
    return len(u).bit_length() + len(v).bit_length() - 2*len(u&v).bit_length()


def project(data, e):
    return frozenset(CORE["orthogonal_projection"](v,e) for v in data)


def cost_table(a, b, intervals):
    return tuple(intervals[frame_distance(u,v)] for u in a for v in b)


def lower_cut(graph, charts, word, bsmall, decline, intervals):
    """Each state change is a directed cut. Conservative endpoint weights bound the optimum."""
    n, s, t = graph["n"]+2, graph["n"], graph["n"]+1
    edges = []
    constant = 0
    _, type_b = AXIS["helper_roles"](word)
    helpers = set(range(word["public"])) - ADJ["main_roles"](word)
    tables = {}
    for frm, to, _, real, _ in graph["edges"]:
        _, _, f,g,_ = word["program"][real]
        geometry = (f,g)
        if geometry not in tables:
            tables[geometry] = cost_table(charts[f],charts[g],intervals)
        # 00/01/10/11 tariff entries are lower bounds used only in the cut.
        a,b,c,d = (v[0] for v in tables[geometry])
        deficit = max(0, a+d-b-c)
        NEED(deficit <= 8,"true tariff submodularity fails on a distinct frame pair")
        d -= deficit
        constant += a
        first, second = d-b, b-a
        for at, reward in ((frm,first),(to,second)):
            if reward>=0: edges.append((at,t,reward))
            else: edges.append((s,at,-reward));constant+=reward
        edges.append((frm,to,b+c-a-d))
    for r, at in enumerate(graph["starts"]):
        old = charts[word["initial"][r]]
        ex = old[int(bsmall and r in type_b)]
        atoms = [intervals[frame_distance(f,ex)][0] for f in old]
        constant += atoms[0]
        w = atoms[1]-atoms[0]
        if w>=0: edges.append((at,t,w))
        else: edges.append((s,at,-w));constant+=w
    for r, at in enumerate(graph["ends"]):
        old, new = charts[word["final"][r]]
        start = charts[word["initial"][r]][0]
        ex = new if bsmall and r in type_b else old
        open_end = decline and r in helpers and start <= new
        h0, h1 = frame_distance(start,old), frame_distance(start,new)
        costs = [intervals[frame_distance(old,ex)][0], intervals[frame_distance(new,ex)][0]]
        if open_end:
            costs[1] = intervals[h0][1]-intervals[h1][0]
        constant += costs[0]
        w=costs[1]-costs[0]
        if w>=0: edges.append((at,t,w))
        else: edges.append((s,at,-w));constant+=w
    val, take = FLOW(n,edges,s,t)
    NEED(val==sum(c for x,y,c in edges if x in take and y not in take),"exact min-cut capacity")
    take.remove(s)
    return take, val+constant


def invoice(graph, charts, word, bsmall, decline, selected):
    _, type_b = AXIS["helper_roles"](word)
    helpers = set(range(word["public"])) - ADJ["main_roles"](word)
    paid, produced, nonnested = Counter(), Counter(), 0
    adapters = Counter()
    for f,g,_,i,_ in graph["edges"]:
        _,_,a,b,_ = word["program"][i]
        u,v = charts[a][f in selected], charts[b][g in selected]
        rank = frame_distance(u,v)
        if rank:
            paid[rank]+=1
            nonnested+=not (u<=v or v<=u)
    for r, at in enumerate(graph["starts"]):
        old=charts[word["initial"][r]]
        ex = old[int(bsmall and r in type_b)]
        rank=frame_distance(ex,old[at in selected])
        if rank: adapters[rank]+=1
    for r, at in enumerate(graph["ends"]):
        old,new=charts[word["final"][r]]
        start=charts[word["initial"][r]][0]
        open_end=decline and r in helpers and start<=new and at in selected
        ex = new if open_end or bsmall and r in type_b else old
        paid_rank=frame_distance((old,new)[at in selected],ex)
        if paid_rank: adapters[paid_rank]+=1
        if r in helpers:
            rank=frame_distance(start,ex)
            if rank: produced[rank]+=1
    return paid,produced,adapters,nonnested


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word",type=Path);parser.add_argument("caller",type=Path);parser.add_argument("receipt",type=Path)
    parser.add_argument("out",type=Path)
    args=parser.parse_args()
    start,deadline=perf_counter(),monotonic()+40
    w=EXACT["pinned_json"](args.word,EXACT["WORD_SHA"],compressed=True)
    c=EXACT["pinned_json"](args.caller,EXACT["CALLER_SHA"])
    h=json.loads(SOURCE["pin"](args.receipt,SOURCE["WHOLE"]))
    convert=SOURCE["price_engine"]()
    g=AXIS["graph"](w)
    old=[EXACT["chart_space"](f) for f in w["frames"]]
    orig_t=Counter({int(k):v for k,v in h["signed_profile"]["native_productive"].items()})
    result=[]
    for e in (331,372):
        charts=[(o,project(o,e)) for o in old]
        for small in (False,True):
            for s in (AXIS["INCUMBENT"],Fraction(".005"),Fraction(".0227")):
                NEED(monotonic()<deadline,"partial projection cut ran beyond deadline")
                intervals={0:(0,0),**{i:convert.power(i,s) for i in range(1,10)}}
                flags,bound=lower_cut(g,charts,w,small,True,intervals)
                p,t,adapters,k=invoice(g,charts,w,small,True,flags)
                bill=CORE["full_bill"](c,w,h,p,t,adapters) if small else CORE["full_bill"](
                    {**c, "events":[e for e in c["events"] if e[0]!="B"],
                     "types":{**c["types"],"B":{"ports":[],"diagonal":[]}}}, w,h,p,t,adapters)
                pp=p.copy();pp.update(adapters);tt=orig_t.copy();tt.subtract(t)
                objective=convert.moment(pp,s); objective=convert.add(objective,convert.moment(tt,s))
                NEED(bound<=objective[1],"cut lower certificate against independently priced selected configuration")
                result.append({"normal":e,"saving":str(s),"smaller_B":small,"projected_components":len(flags),
                               "non_nested_interior_moves":k,"boundary_adapters":adapters,
                               "native_objective_lower_bound":convert.show((bound,bound))[0],
                               "native_objective_at_candidate":convert.value(objective),"complete":bill})
    data={"status":"PASS_COMPLEX_PARTIAL_PROJECTION_CUT","cases":result,
          "scope":"optimizes two symbolic subspace choices with fixed scalar contacts, all A and original helper inputs kept, permits independent final helper shortening and fully charges boundary adapters"}
    args.out.write_text(json.dumps(data,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(data["status"],f"{perf_counter()-start:.2f}s")


if __name__=="__main__":
    main()
