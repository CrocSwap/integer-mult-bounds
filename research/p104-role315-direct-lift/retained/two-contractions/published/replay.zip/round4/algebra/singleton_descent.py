"""Exact low-rank control for a ten-cut BIT circuit with one extra source coset."""

from collections import Counter
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
import json
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here.parents[1] / "round3" / "algebra"))
from nine_cut_geometry import codewords, fitting_calibration, hamming_roots, load_word
from permute_head_frames import dot, require
from staged_two_way_routes import binary_rank, xor_selection
sys.path.insert(0, str(here.parents[1] / "algebra"))
from scan_bit_move_runs import basis
from scan_bit_fixed_graph import supported_interval


def inverse(rows):
    n = len(rows)
    a = [row | 1 << (n+i) for i, row in enumerate(rows)]
    for i in range(n):
        j = next(j for j in range(i, n) if a[j] >> i & 1)
        a[i], a[j] = a[j], a[i]
        for j in range(n):
            if i != j and a[j] >> i & 1:
                a[j] ^= a[i]
    return [row >> n for row in a]


def fixture(word):
    heads, puncture, *_ = fitting_calibration(word)
    roots = hamming_roots()
    missing = [roots[i] for i in puncture]
    masks = [sum(1 << t for t, p in enumerate(heads) if not dot(q, p)) for q in missing]
    c = [sum(1 << j for j, q in enumerate(missing) if i == j or not dot(p, q))
         for i, p in enumerate(missing)]
    require(binary_rank(masks) == binary_rank(c) == 9, "wrong code basis")
    return heads, missing, masks, c


def small_span_control(heads, masks):
    # Any 8 independent integer directions modulo a prime are independent over Q.
    p = 257
    signs = [tuple(int(v * 2) % p for v in row) for row in heads]
    require(all((v * 2).denominator == 1 for row in heads for v in row),
            "integer root scale changed")
    reciprocal = [0] + [pow(i, -1, p) for i in range(1, p)]

    def rank(mask):
        seen = {}
        while mask:
            low = mask & -mask
            mask ^= low
            row = signs[low.bit_length() - 1]
            for i, v in enumerate(row):
                if not v:
                    continue
                old = seen.get(i)
                if old is None:
                    inv = reciprocal[v]
                    seen[i] = tuple(x * inv % p for x in row)
                    if len(seen) == 8:
                        return 8
                    break
                row = tuple((x - v * y) % p for x, y in zip(row, old))
        return len(seen)

    all_words = codewords(heads)
    root_masks = set(masks)
    counts = Counter()
    exceptional_full_to_reduced = []
    counts_modular = Counter()
    for w in all_words:
        if not w:
            continue
        for i in range(len(heads)):
            expected = 7 if w in root_masks and (w >> i & 1) else 8
            toggled = w ^ 1 << i
            v = rank(toggled)
            counts_modular[v] += 1
            if v != expected:
                v = len(basis([a for j, a in enumerate(heads) if toggled >> j & 1]))
            require(v >= 7 and not (v == 8 and expected == 7),
                    f"singleton rank impossible mask={w} i={i} expected={expected} got={v}")
            if v == 7 and expected == 8:
                require(w == sum(1 << j for j, a in enumerate(heads)
                                 if i == j or not dot(a, heads[i])),
                        "new cap is not a live-root orthogonality codeword")
                exceptional_full_to_reduced.append((w, i))
            counts[v] += 1
    return {"method": "integer minors mod 257 and rational cap containment", "modular": dict(counts_modular),
            "all_pairs": sum(counts.values()), "rank_counts": dict(sorted(counts.items())),
            "full_to_reduced_exceptions": exceptional_full_to_reduced,
            "minimum_nonzero_code_distance": min(w.bit_count() for w in all_words if w)}


def one_augmented_example(heads, missing, masks, c):
    # Pivot singleton owns a rank-one cut. Its only child carries the
    # orthogonality codeword of the live root with the self entry suppressed.
    # The five reduced pairs are ordered so their cross-gauge is lower triangular.
    n = len(heads)
    port = 1
    unit = 1 << port
    self_label = sum(1 << j for j, a in enumerate(heads) if j == port or not dot(a, heads[port]))
    coord = next(i for i in range(512) if xor_selection(masks, i) == self_label)
    pair_types = [(9, 1), (7, 5), (4, 2), (0, 8), (3, 6)]
    sm = [coord if a == 9 else 1 << a for a, _ in pair_types]
    rm = [1 << b for _, b in pair_types]
    require(binary_rank(sm) == 5 and binary_rank(rm) == 5, "reduced sources or readers dependent")
    for e in range(1, 512):
        row = xor_selection(c, e)
        if all(not(row & r) for r in rm) and binary_rank(sm + [e]) > len(sm):
            sm.append(e)
        if len(sm) == 9:
            break
    q = [xor_selection(c, a) for a in sm]
    dual = inverse(q)
    rm.extend(sum(((a >> j) & 1) << i for i, a in enumerate(dual))
              for j in range(5, 9))
    t = [0]+[sum(((a & b).bit_count() % 2) << (j+1) for j,b in enumerate(rm)) ^
             (1 << (i+1)) ^ int(i == 0) for i,a in enumerate(q)]
    require(all(r >> i == 0 for i,r in enumerate(t)), "not a chronological factor")
    first = [unit] + [xor_selection(masks, a) ^ (unit if i == 0 else 0) for i,a in enumerate(sm)]
    read = [0] + [xor_selection(masks, a) for a in rm]
    carried = []
    for i, m in enumerate(t):
        carried.append(first[i] ^ xor_selection(carried, m))
    require(binary_rank(first) == 10 and binary_rank(read) == 9, "not a rank-ten escape control")
    pairs = 0
    for i, a in enumerate(heads):
        got = xor_selection(carried, sum(((v >> i) & 1) << j for j, v in enumerate(read)))
        expected = sum(1 << j for j, b in enumerate(heads) if i == j or not dot(a, b))
        require(got == expected, "outside sample does not recover B0")
        pairs += len(heads)
    norm = missing + [heads[port]]
    upper = [None]
    lower = [None]
    for i,a in enumerate(sm):
        if i == 0 or a.bit_count() == 1:
            upper.append(norm[-1] if i == 0 else norm[a.bit_length()-1])
        else:
            upper.append(None)
    for a in rm:
        lower.append(norm[a.bit_length()-1] if a.bit_count() == 1 else None)
    # U_i is a hyperplane with the given normal unless None (full).
    # V_i is a line with the given normal unless None (zero).
    # The pivot U_0 is its live singleton line.
    for i in range(1, 10):
        for j in range(i+1):
            if i != j and not(t[i] >> j & 1):
                continue
            require(lower[j] is None or upper[i] is None or not dot(upper[i], lower[j]),
                    "illegal direct temporal contact")
    for i in range(1, 10):
        require(upper[i] is None or all(not(first[i] >> j & 1) or not dot(upper[i], a)
                                      for j,a in enumerate(heads)), "source misses its high frame")
        require(lower[i] is None or all(not(read[i] >> j & 1) or not dot(lower[i], a)
                                      for j,a in enumerate(heads)), "reader misses its low frame")
    ranks = [1]+[8 - int(u is not None) - int(v is not None)
                 for u,v in zip(upper[1:], lower[1:])]
    require(ranks == [1]+[6]*5+[8]*4, "five newly concentrated cuts missing")
    return {"source_rank": 10, "reader_rank": 9, "checked_pairs": pairs, "extra_source_port": port,
            "exceptional_ranks": ranks, "direct_T": t,
            "source_basis_coordinates": sm, "reader_basis_coordinates": rm,
            "reduced_sources": 5}, (upper, lower, t, first, read)


def literal_word(word, heads, geometry, factor):
    high, low, temporal, first, readers = factor
    n = len(heads)
    zero, full = word["start"][n], word["final"][0]
    source, terminal = word["start"][:n], word["final"][n:2*n]
    frames = {int(k): (f["B"], f["A"]) for k, f in word["frames"].items()}
    for k, (s, a) in frames.items():
        frames[k] = (tuple(tuple(map(Fraction, x)) for x in s),
                     tuple(tuple(map(Fraction, x)) for x in a))

    def paired_rows(normal, hyperplane):
        p = next(j for j, v in enumerate(normal) if v)
        cap = tuple(tuple(Fraction(i == k) - (Fraction(normal[k], normal[p])
                                               if i == p else 0)
                          for i in range(8)) for k in range(8) if k != p)
        return (cap, (normal,)) if hyperplane else ((normal,), cap)

    def append_frame(normal, hyperplane):
        k = max(frames)+1
        frames[k] = paired_rows(normal, hyperplane)
        return k

    upper = [source[geometry["extra_source_port"]]] + [
        full if v is None else append_frame(v, True) for v in high[1:]]
    lower = [zero if v is None else append_frame(v, False) for v in low]
    receivers = list(range(2*n, 3*n))
    carriers = list(range(3*n, 3*n+10))
    scratch = carriers[-1]+1
    steps = []

    def copy(dst, stop, src, start):
        steps.extend([("INIT", scratch, start), ("ADD", scratch, src, start)])
        if start != stop:
            steps.append(("MOVE", scratch, start, stop))
        steps.extend([("ADD", dst, scratch, stop), ("CLEAR", scratch, stop)])

    for i in range(n):
        steps.append(("INIT", receivers[i], terminal[i]))
    for i, j in product(range(n), repeat=2):
        if not dot(heads[i], heads[j]):
            copy(receivers[i], terminal[i], j, source[j])
    for j, cut in enumerate(carriers):
        start, stop = upper[j], lower[j]
        steps.append(("INIT", cut, start))
        for i in range(n):
            if first[j] >> i & 1:
                copy(cut, start, i, source[i])
        for i in range(j):
            if temporal[j] >> i & 1:
                copy(cut, start, carriers[i], lower[i])
        steps.append(("MOVE", cut, start, stop))
    for j, cut in enumerate(carriers):
        for i in range(n):
            if readers[j] >> i & 1:
                copy(receivers[i], terminal[i], cut, lower[j])
        steps.append(("CLEAR", cut, lower[j]))
    for i in range(n):
        steps.extend([("MOVE", n+i, zero, full), ("SWAP", i, n+i),
                      ("SWAP", n+i, receivers[i]), ("CLEAR", receivers[i], source[i])])
    return frames, steps, source+[zero]*n, [full]*n+terminal, scratch+1


def clique_control(missing):
    n = len(missing)
    return {k: sum(all(not dot(missing[i], missing[j]) for i, j in combinations(g, 2))
                   for g in combinations(range(n), k)) for k in range(1, n+1)}


def literal_replay(frames, steps, start, final, slots):
    n = len(start)
    at = start + [None]*(slots-n)
    rows = [1 << i for i in range(n)] + [None]*(slots-n)
    moves, descents, operations = Counter(), Counter(), Counter()
    live, peak, nonzero = 0, 0, 0
    subsets = {}

    def nested(b, a):
        if (b,a) not in subsets:
            subsets[b,a] = all(not dot(x,y) for x,y in product(frames[b][0], frames[a][1]))
        return subsets[b,a]

    for op,i,*rest in steps:
        operations[op] += 1
        if op == "INIT":
            require(i >= n and at[i] is None, "invalid owned activation")
            at[i], rows[i] = rest[0], 0
            live += 1
            peak = max(peak,live)
        elif op == "CLEAR":
            require(i >= n and at[i] == rest[0], "invalid owned clear")
            nonzero += bool(rows[i])
            at[i], rows[i] = None, None
            live -= 1
        elif op == "MOVE":
            a,b = rest
            require(at[i] == a, "wrong movement entrance")
            d = len(frames[b][0])-len(frames[a][0])
            require(d and (nested(a,b) if d > 0 else nested(b,a)), "nonnested movement")
            if d < 0:
                descents[-d] += 1
            moves[abs(d)] += 1
            at[i] = b
        elif op == "ADD":
            j,f = rest
            require(i != j and at[i] == at[j] == f, "mismatched same-frame addition")
            rows[i] ^= rows[j]
        elif op == "SWAP":
            j, = rest
            require(i != j and None not in (at[i],at[j]), "swapping an absent role")
            at[i],at[j] = at[j],at[i]
            rows[i],rows[j] = rows[j],rows[i]
        else:
            raise ValueError(op)
    require(at == final+[None]*(slots-n) and live == 0, "invalid terminal frames or owned state")
    want = [1 << ((i+n//2)%n) for i in range(n)]
    require(rows == want+[None]*(slots-n), "wrong arbitrary-input exchange")
    for i, expected in enumerate(want):
        mask = 1 << i
        for op,j,*rest in reversed(steps):
            if op == "ADD" and mask >> j & 1:
                mask ^= 1 << rest[0]
            elif op == "SWAP" and ((mask >> j) ^ (mask >> rest[0])) & 1:
                mask ^= (1 << j) | (1 << rest[0])
            elif op == "INIT":
                mask &= ~(1 << j)
            elif op == "CLEAR":
                require(not (mask >> j & 1), "backward functional uses retired stock")
        require(mask == expected, "backward arbitrary-input exchange disagrees")
    require(descents == {1:1,6:5,8:4}, "lit descents diverge from declared shape")
    tariffs = []
    for s in (".005",".0227"):
        h = {r:supported_interval(r,Fraction(s)) for r in range(1,9)}
        net = [sum(c*h[r][k] for r,c in moves.items())-n*h[8][1-k] for k in (0,1)]
        extra_cut = tuple(h[1][k]+h[6][k]-h[7][1-k] for k in (0,1))
        require(net[0] > 0 and extra_cut[0] > 0, "incorrect net charge or exceptional loss")
        tariffs.append({"s":s, "paid_minus_generous_targets_2pow80":net,
                        "paid_minus_generous_targets_lower":net[0]/2**80,
                        "more_than_concentrated_nine_cut_charge_2pow80":extra_cut,
                        "more_than_concentrated_nine_cut_charge_lower":extra_cut[0]/2**80})
    return {"paid_moves":dict(sorted(moves.items())), "exceptional_moves":dict(sorted(descents.items())),
            "operations":dict(operations), "nonzero_erasures":nonzero,
            "owned_peak":peak, "forward_and_reverse_coefficients_each":n*n,
            "generous_productive_profile":{8:n}, "tariffs":tariffs}


if __name__ == "__main__":
    word = load_word()
    heads, missing, masks, c = fixture(word)
    cliques = clique_control(missing)
    require(list(cliques.values()) == [9, 22, 16, 2, 0, 0, 0, 0, 0], "omitted graph changed")
    outside, factor = one_augmented_example(heads, missing, masks, c)
    print(json.dumps({"status": "PASS_SINGLETON_DESCENT_GEOMETRY",
                      "canonical_pairings": c, "orthogonal_cliques": cliques,
                      "rank_census": small_span_control(heads, masks),
                      "outside_coset_control": outside,
                      "literal_word":literal_replay(*literal_word(word, heads, outside, factor))}, indent=2))
