# SPDX-License-Identifier: Apache-2.0
"""Price uniform character restrictions before rebuilding mixed A/B callers."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
M = run_path(str(HERE / "complex_terminal_transport.py"))
EXACT, SOURCE, AXIS, NEED = (M[k] for k in ("EXACT", "SOURCE", "AXIS", "NEED"))


def norm(vector):
    return vector.bit_count() % 2


def occupancy(space, vector):
    """Dropping a coordinate along vector lowers dim only if its line is present."""
    return int(vector in space)


def profile_for_axis(word, spaces, normal, calls, funded_helpers):
    """Project onto one fresh hyperplane, granting all algebraic lowerings."""
    paid_delta, target_delta, budget_hist = Counter(), Counter(), Counter()
    for op, role, *rest in word["program"]:
        if op != "MOVE":
            continue
        a,b, _ = rest
        old = abs(len(word["frames"][a]) - len(word["frames"][b]))
        da, db = occupancy(spaces[a], normal), occupancy(spaces[b], normal)
        new = abs(len(word["frames"][a])-da-len(word["frames"][b])+db)
        NEED(new == old or new == old-1, "projected rank loss is 0 or 1 by nestedness")
        if new != old:
            paid_delta[old] -= calls
            if new:
                paid_delta[new] += calls
    for r in funded_helpers:
        a,b = word["initial"][r], word["final"][r]
        old = len(word["frames"][b])-len(word["frames"][a])
        new = old + occupancy(spaces[a],normal) - occupancy(spaces[b],normal)
        NEED(0 <= new <= old, "helper projection must remain a nested affine quotient")
        if new != old:
            budget_hist[old] += 1
            target_delta[old] -= calls
            if new:
                target_delta[new] += calls
    return paid_delta, target_delta, budget_hist


def type_delta(caller, selected_type, rank_width, lost_q):
    """Changed root widths, with independent roots already granted."""
    p,t = Counter(), Counter()
    n = lost_q
    for op in caller["events"]:
        if op[0] == selected_type and op[1] in ("IDLE_ONE","IDLE_ODD"):
            k = len(op[3]); h = op[1] == "IDLE_ODD"
            p[k*8+h] -= n
            new = k*rank_width+h
            if new:
                p[new] += n
    for _, _, *mask in caller["types"][selected_type]["diagonal"]:
        k=sum(mask)
        t[1+8*k] -= n
        t[1+rank_width*k] += n
    return p,t


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word",type=Path)
    parser.add_argument("caller",type=Path)
    parser.add_argument("whole",type=Path)
    parser.add_argument("output",type=Path)
    args = parser.parse_args()
    start, deadline = perf_counter(), monotonic()+35
    w = EXACT["pinned_json"](args.word,EXACT["WORD_SHA"],compressed=True)
    c = EXACT["pinned_json"](args.caller,EXACT["CALLER_SHA"])
    h = json.loads(SOURCE["pin"](args.whole,SOURCE["WHOLE"]))
    p,t = (Counter({int(k):v for k,v in h["signed_profile"][key].items()}) for key in ("signed_paid","signed_productive"))
    spaces = [EXACT["chart_space"](f) for f in w["frames"]]
    host = w["hosted"]; A = set(host["Dports"])
    b = [q for j,q in enumerate(w["ports"]) if j not in A]
    funded_helpers,_ = AXIS["helper_roles"](w)
    price=SOURCE["price_engine"]()
    records=[]
    for axis in (a for a in range(1,512) if norm(a) and all(not norm(a&q) for q in b)):
        pp,tp,lost = profile_for_axis(w,spaces,axis,c["stages"],funded_helpers)
        counts = Counter("preserved" if not norm(axis&q) else "lost_center" for j,q in enumerate(w["ports"]) if j in A)
        # Keep whole complex source and physical bindings waived as a useful
        # upper screen. Only B roots are resized, and all 96 A roots are
        # deliberately granted unchanged credit despite missing centers.
        pc,tc = type_delta(c,"B",7,len(b))
        pc.update(pp); tc.update(tp)
        new_paid,new_t = p.copy(),t.copy()
        new_paid.update(pc)
        new_t.update(tc)
        NEED(min(new_paid.values())>=0 and min(new_t.values())>=0,"complete amended inventory")
        data={}
        for s in (AXIS["INCUMBENT"],Fraction("0.005"),Fraction("0.0227")):
            native = price.sub(price.moment(tp,s),price.moment(pp,s))
            price_value=price.sub(price.moment(new_t,s),price.moment(new_paid,s))
            data[str(s)]={"exact_native_delta":price.value(native),"optimistic_signed_balance":price.value(price_value),
                          "optimistic_signed_interval":price.show(price_value)}
        records.append({"normal":axis,"unrecovered_A_center_ports":counts["lost_center"],"helper_rank_debits":lost,
                        "native_only_paid_delta":dict(pp),"native_only_target_delta":dict(tp),"balance":data})
        NEED(monotonic() < deadline,"bounded character check")
    NEED({r["normal"] for r in records}=={331,372},"all norm-one normals fixing Type B")
    # Reserve a subset of old A credit for what a different signed cutter
    # might restore. No value here certifies an enlarged productive set.
    result={"status":"PASS_COMPLEX_ONE_COORDINATE_PROJECTION_SCREEN","conditions":
            "all original 17 native copies projected; all independent helper rank losses charged, B body rank 7, A main returns optimistically reused",
            "cases":records}
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(result["status"],f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
