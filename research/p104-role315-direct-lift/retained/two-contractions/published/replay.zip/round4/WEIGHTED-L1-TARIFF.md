# Product address cuts for signed Laurent schedules

The power tariff of a diagonal Laurent endpoint is subadditive under a sequence of paid role shifts. The result holds for signed target exponents as well as signed paid exponents. It uses the full weighted \(\ell_1\) length of each vector. The priceable operator assumptions are stated below.

Let \(D_1,\ldots,D_m\) be commuting formal Laurent generators over a field. A paid operation has form

\[
I-P+D^bP,\qquad P^2=P,\quad \operatorname{rank}(P)=d,\quad b\in\mathbb Z^m .
\]

There can also be address-local role maps, including constants of rectangular size. Suppose the exact endpoint on independent roles is diagonal with monomials \(D^{a_i}\). For any \(w_j\ge0\) and \(0<t<1\),

\[
\boxed{\sum_i\left(\sum_j w_j|a_{ij}|\right)^t\leq \sum_{\mathrm{paid}\ g} d_g\left(\sum_j w_j|b_{gj}|\right)^t .}
\]

## Approximate weighted Manhattan distance by finite cut metrics

At any finite product address group, choose a partition into two colors and use the rank of the block carrying the second color to the first. For compatible rectangular maps \(A,B\) splitting the same intermediate addresses by color,

\[
(AB)_{01}=A_{00}B_{01}+A_{01}B_{11},\qquad r(AB)\le r(A)+r(B).
\]

Role-only matrices have zero crossing rank. In particular, constant basis changes preserve it. Specializing the Laurent variables to address shifts makes an occurrence with role rank \(d\) contribute \(d\) times the crossing count of its address displacement. This follows by a role-only diagonalization of \(P\). The diagonal target adds the exact crossing counts for its independent fields.

Use one cyclic coordinate of length \(2K_j\) for each positive weight, with its two consecutive half cycles. Write \(S_j\) for translation by one. Choose an independent fair bit per coordinate, determining whether to use that coordinate's half-indicator. Partition addresses by the parity of the selected indicators. For a uniform address, a displacement \(u_j\) changes one half-indicator with probability

\[
\frac{\operatorname{dist}(u_j,2 K_j\mathbb Z)}{K_j}.
\]

The address coordinates are independent. Whenever at least one indicator changes, the fair random selection makes the resulting parity change with probability \(1/2\). For a fixed selection and any displacement, crossing traffic in the two directions is equal because translation is a permutation. Therefore four times the expected normalized one-way crossing count is

\[
F_K(u)=1-\prod_j\left(1-\frac{\operatorname{dist}(u_j,2 K_j\mathbb Z)}{K_j}\right).
\]

This is an average over finitely many literal cuts. Constant role mixers and rank subadditivity give the claimed occurrence inequality with \(F_K\) in place of the power cost for any assignment of Laurent labels to commuting translations. The formula already distinguishes, for example, the displacement \((1,-1)\) from zero while a simultaneous one-axis specialization can collapse both.

Now give each positive-weight generator \(L\) independent copies of its cyclic coordinate, and assign \(D_j\) to simultaneous translation by an integer \(M\) in all those copies. For any \(s>0\) choose integer \(K_j(M)\) with \(K_j(M)/M\to Ls/w_j\). Take \(M\to\infty\) first. The distance to a lattice of positive spacing is continuous in that spacing. With fixed \(s>0\), sufficiently large \(L\) places every relevant finite displacement short of a half-period. The finite-cut inequality then passes, on each of its finitely many terms, to the kernel

\[
F_s(u)=1-\exp\left(-\frac{\sum_j w_j |u_j|}{s}\right),
\]

because \((1-w_j|u_j|/(Ls))^L\to\exp(-w_j|u_j|/s)\). Zero-weight generators may map to identity. All the constructions act on finite address groups at the point where a matrix rank is taken. There is no use of a limit of matrix ranks. Only the explicitly evaluated scalar inequality is taken to the limit.

## Recovering the full tariff

Put \(r=1/s\) and let \(h=\sum_jw_j|u_j|\). Integrating the inequality for \(1-e^{-rh}\) against \(r^{-t-1}\,dr\) gives a positive multiple of \(h^t\). At zero use \(1-e^{-rh}\le rh\) and at infinity use \(1-e^{-rh}\le1\), which are integrable for \(0<t<1\). A change of variable by \(h\) gives homogeneity and the constant is strictly positive. Thus each role's complete signed vector is priced once, even if different roles have opposite signs coordinate by coordinate.

The same proof applies to any nonnegative mixture of the kernels \(h\mapsto1-e^{-rh}\). It gives a separate \(t=1\) result by dividing by \(r>0\) and letting \(r\downarrow0\). The support-count limit \(r\to\infty\) bounds the number of nonzero output vectors by the sum of the paid role ranks with nonzero vector. A physical phase family over a finite group may have relations between its labels. The theorem uses an identity over the formal Laurent variables and does not permit reading this formal inequality back from a single specialized identity. A physical invoice also needs its actual rank to dominate the weighted length for paid operations and not exceed it on credited targets.

## Scope for #7001

A fixed #7001 forward or inverse LOCAL, after setting all header variables to one, has one role-rank-two pulse on a seven-axis body. A single grouped idle has role rank one. Charges are computed at \(7\lVert b\rVert_1\) or larger. For arbitrary signed target vectors of supported physical rank the theorem therefore gives at most the paid idle tariff plus \(2L H_7\) in body credit for \(L\) complete natives. It extends the signed single-projection theorem in `recurrence/SIGNED-BODY-TARIFF.md`. That prior result already treats arbitrary mixed signed paid groups for nonnegative target exponents. The independent header proof still assumes a square invertible nominal root and independent header involutions. Together these give the same directed per-native caps from the exact invoice, including **−94.710372092823** at κ=0.0227. Cross-axis identifications, changed native rates, a joint new header gate and a changed outer supplier architecture require their own evidence.

`weighted_l1_tariff.py` enumerates 32 finite product-torus/shift cases, including opposite-signed axes, and tests 96 rectangular matrix products over GF(2). The exact enumeration is a corroborating control. The scaling limit and integral supply the result for general weights and finite schedules. The underlying finite cut idea has a predecessor in the repository. [Finite dihedral crossing rank](https://github.com/CrocSwap/integer-mult-bounds/tree/e54523517d0f03e58352e647c403a5af3e525a57/research/finite-dihedral-cut-bound)
