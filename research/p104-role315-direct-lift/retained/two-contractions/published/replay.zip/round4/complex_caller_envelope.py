# SPDX-License-Identifier: Apache-2.0
"""Upper-bound a formal paid #7546 caller with square sector-even contact maps."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
CORE = run_path(str(HERE / "complex_axis_rebuild.py"))
SOURCE, EXACT, NEED = (CORE[k] for k in ("SOURCE", "EXACT", "NEED"))


def margins(paid, helper, price, saving):
    q = Fraction(saving)
    body = Counter({8: 400})
    central = Counter({1:208})
    award = helper+body+central
    return price.sub(price.moment(award,q),price.moment(paid,q))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word",type=Path);parser.add_argument("caller",type=Path);parser.add_argument("receipt",type=Path)
    parser.add_argument("out",type=Path)
    args=parser.parse_args()
    start, stop=perf_counter(),monotonic()+25
    word=EXACT["pinned_json"](args.word,EXACT["WORD_SHA"],compressed=True)
    c=EXACT["pinned_json"](args.caller,EXACT["CALLER_SHA"])
    h=json.loads(SOURCE["pin"](args.receipt,SOURCE["WHOLE"]))
    types={k:len(row["ports"]) for k,row in c["types"].items()}
    NEED(types=={"A":96,"B":8},"exact hosted main port counts")
    a,b=types["A"],types["B"]
    NEED((4*a+2*b,2*a+2*b)==(400,208),"body and odd central capacities from two opposite shears or one B block")
    # A forward B host local at q is [[1,-q],[q^-1/2,1/2]].
    # At q=i versus -i both off-diagonal entries change and neither is zero.
    # Each signed A shear changes one off-diagonal entry. The two distinct
    # shears act on separate rail pairs, so their sector ranks add.
    A_difference=[[0,0],[2,0]]; B_difference=[[0,-2],[-1,0]]
    NEED(A_difference[1][0] and B_difference[0][1]*B_difference[1][0],"nonzero rank-one and rank-two central controls")
    p=Counter(abs(len(word["frames"][rest[1]])-len(word["frames"][rest[0]]))
              for op,_,*rest in word["program"] if op=="MOVE")
    t=Counter({int(r):v for r,v in h["signed_profile"]["native_productive"].items()})
    price=SOURCE["price_engine"]()
    rows={}
    for s in (".003648411294790",".005",".006",".0075",".01",".0227"):
        z=margins(p,t,price,s)
        sm=Fraction(s)
        even_debit=price.sub(price.power(9,sm),price.power(8,sm))
        mixed=price.smul(price.sub(price.exact(1),even_debit),32)
        relaxed=price.add(price.smul(z,c["stages"]),mixed)
        rows[s]={"per_native_optimistic_margin":price.value(z),"exact_interval":price.show(z),
                 "excess_on_original_32_mixed_odd_idles":price.value(mixed),
                 "optimistic_margin_for_17_hosts_with_that_excess":price.value(relaxed)}
    lo,hi=Fraction(".006"),Fraction(".0075")
    threshold=Fraction(1,10**13)
    while hi-lo>threshold:
        mid=(lo+hi)/2
        z=margins(p,t,price,mid)
        if z[0]>0:lo=mid
        elif z[1]<0:hi=mid
        else:raise ValueError("could not separate the power-moment sign")
    # Certify monotonicity on the display interval. For each positive
    # coefficient in target-paid use the smallest power in that interval
    # to upper-bound its negative derivative; do the reverse for paid.
    bill=t+Counter({8:400,1:208});bill.subtract(p)
    derivative=price.exact(0)
    smax=Fraction(1,32)
    for r,v in bill.items():
        term=price.mul(price.power(r,smax if v>=0 else 0),price.log(r))
        derivative=price.add(derivative,price.smul(term,-v))
    NEED(derivative[1]<0 and monotonic()<stop,"strict margin derivative and exact price deadline")
    out={"status":"PASS_COMPLEX_FORMAL_CALLER_ENVELOPE", "body_role_rank_per_native":400,
         "central_sector_rank_per_native":208,"paid":p,"productive_helpers":t,
         "tested":rows,"display_bracket":[float(lo),float(hi)],"exact_bracket":[str(lo),str(hi)],
         "derivative_upper_0_to_1_over_32":price.value(derivative)[1],
         "scope":"fixed signed #7546 tariff; formal independent body monomials; sector-even ordinary operations; body-only idles and separate rank-one central calls, or separately charged mixed idles"}
    args.out.write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(out["status"],f"{perf_counter()-start:.2f}s")


if __name__=="__main__":
    main()
