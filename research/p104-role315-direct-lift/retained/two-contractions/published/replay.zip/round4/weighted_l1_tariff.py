# SPDX-License-Identifier: Apache-2.0
"""Check product-address cut ranks for mixed-sign Laurent jobs."""

import argparse
from collections import Counter
from fractions import Fraction
from itertools import product
import json
from math import prod
from pathlib import Path
from random import Random
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
STOCK = run_path(str(HERE.parent / "bit_swap_transport.py"))
NEED, RANK = STOCK["need"], STOCK["xor_rank"]


def prod_addresses(half_periods):
    return list(product(*(range(2*k) for k in half_periods)))


def vector_translation(box, half, displacement):
    address = {a:j for j,a in enumerate(box)}
    return [address[tuple((x+y)%(2*k) for x,y,k in zip(a,displacement,half,strict=True))] for a in box]


def parity_cut(box, half, enabled):
    """Take one explicit randomized phase of the product partition."""
    flags = [sum(a >= k for a,k,mask in zip(x,half,enabled,strict=True) if mask)%2 for x in box]
    return sum(int(mark == 0)<<j for j,mark in enumerate(flags))


def crossing_fraction(half, displacement):
    """Enumerate every independent fair coordinate inclusion, then every address."""
    box = prod_addresses(half)
    translation = vector_translation(box,half,displacement)
    whole = (1<<len(box))-1
    samples = 0
    for enabled in product((0,1),repeat=len(half)):
        left = parity_cut(box,half,enabled)
        right = whole ^ left
        post = sum((bool((right>>j)&1)<<d) for j,d in enumerate(translation))
        samples += (post&left).bit_count()
    expected = Fraction(1,4)*(1-prod(1-Fraction(min(d%(2*k),(-d)%(2*k)),k) for d,k in zip(displacement,half,strict=True)))
    NEED(Fraction(samples,len(box)*(2**len(half)))==expected,"independent cuts have exactly the predicted crossing rank average")
    return expected


def cut_family_cases(deadline):
    """Show that vector cancellations and simultaneous crossings are distinct."""
    pairs = ((1,-1),(-1,1),(1,2),(2,-2),(0,0),(4,-3),(0,5),(4,5))
    records = []
    for half in ((1,1),(2,3),(3,4),(8,9)):
        for v in pairs:
            NEED(monotonic()<deadline,"fixed cut family deadline")
            records.append({"half":half,"shift":v,"expected_crossing_density":str(crossing_fraction(half,v))})
    large = []
    for s in (1,2,4,8,16,32):
        # In characteristic tests all displacements can be lifted by an
        # independent factor while the scale is selected rationally.
        h = (s,s,s)
        density = Fraction(1,4)*(1-prod(1-Fraction(min(v%(2*s),(-v)%(2*s)),s) for v in (1,-2,3)))
        large.append([s,str(density)])
    NEED(crossing_fraction((4,4),(2,-2)) == Fraction(3,16),"absolute shift detected even when coordinate sum is zero")
    return records,large


def triangular_rank_control():
    """Independently replay a rectangular composition and a hidden pivot."""
    rng = Random(750046)
    done = 0
    for left_a,right_a,mid, target in ((1,2,3,2),(2,2,1,4),(3,1,3,1)):
        for _ in range(32):
            m=2*mid; t=2*target; n=left_a+right_a
            aa=[rng.randrange(1<<t) for k in range(m)]
            bb=[rng.randrange(1<<m) for k in range(n)]
            def act(v):
                r=0
                for i,col in enumerate(aa):
                    if (v>>i)&1:r ^= col
                return r
            a=RANK(v&((1<<target)-1) for v in aa[mid:]);b=RANK(v&((1<<mid)-1) for v in bb[left_a:]);
            c=RANK(act(v)&((1<<target)-1) for v in bb[left_a:]);
            NEED(c<=a+b,"rectangular crossing rank subadditivity")
            done+=1
    return done


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("output",type=Path)
    args=ap.parse_args()
    start,deadline=perf_counter(),monotonic()+25
    tables,limit=cut_family_cases(deadline)
    out={"status":"PASS_L1_BOUND_PRODUCT_ADDRESS_CUTS","explicit_cut_census":tables,"coarser_three_axis_examples":limit,
         "rectangular_matrices":triangular_rank_control(),
         "scope":"finite product-torus signed translations and rectangular cut rank. The scaling limit and integral are in WEIGHTED-L1-TARIFF.md"}
    NEED(monotonic()<deadline,"bounded exact product-cut replay")
    args.output.write_text(json.dumps(out,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(out["status"],f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
