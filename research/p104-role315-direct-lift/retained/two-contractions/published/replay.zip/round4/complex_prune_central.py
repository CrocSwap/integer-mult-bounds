# SPDX-License-Identifier: Apache-2.0
"""Route only the lost Type-A sectors through per-rail boundary changes."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE=Path(__file__).resolve().parent
CORE=run_path(str(HERE/"complex_axis_rebuild.py"))
PROJ,SOURCE,EXACT,NEED,AXIS=(CORE[k] for k in ("PROJ","SOURCE","EXACT","NEED","AXIS"))


def controller_bill(caller, original_p, original_t, word, axis, native_delta_p, native_delta_t):
    """Fare comparison after dropping or retaining each central direction exactly once."""
    a_ports = [q for j,q in enumerate(word["ports"]) if j in word["hosted"]["Dports"]]
    ports_bad = sum((q&axis).bit_count()%2 for q in a_ports)
    ports_good = len(a_ports)-ports_bad
    extra_p,extra_t=PROJ["type_delta"](caller,"B",7,8)
    ap,at=PROJ["type_delta"](caller,"A",7,ports_good)
    p,t=original_p.copy(),original_t.copy()
    for c in (extra_p,ap,native_delta_p):p.update(c)
    for c in (extra_t,at,native_delta_t):t.update(c)
    for e in caller["events"]:
        if e[0]=="A" and e[1]=="QUERY":
            p[1] -= ports_bad
        if e[0]=="A" and e[1]=="IDLE_ONE":
            p[8*len(e[3])] -= ports_bad
    for row in caller["types"]["A"]["diagonal"]:
        t[8*sum(row[2:])+1]-=ports_bad
    stages=caller["stages"]
    # A deliberately relaxed isolated-root tariff. Give two rank-seven
    # and two rank-eight outputs per stage of each affected A port.
    t[7]+=2*stages*ports_bad
    t[8]+=2*stages*ports_bad
    NEED(min(p.values())>=0 and min(t.values())>=0,"net full inventory")
    return p,t,ports_good,ports_bad


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word",type=Path);parser.add_argument("caller",type=Path);parser.add_argument("signed",type=Path)
    parser.add_argument("output",type=Path)
    ns=parser.parse_args()
    now,stop=perf_counter(),monotonic()+25
    w=EXACT["pinned_json"](ns.word,EXACT["WORD_SHA"],compressed=True)
    c=EXACT["pinned_json"](ns.caller,EXACT["CALLER_SHA"])
    h=json.loads(SOURCE["pin"](ns.signed,SOURCE["WHOLE"]))
    spaces=[EXACT["chart_space"](frame) for frame in w["frames"]]
    helpers,_=AXIS["helper_roles"](w)
    price=SOURCE["price_engine"]()
    p0,t0=(Counter({int(r):v for r,v in h["signed_profile"][name].items()}) for name in ("signed_paid","signed_productive"))
    records=[]
    for e in (331,372):
        dp,dt,_=PROJ["profile_for_axis"](w,spaces,e,c["stages"],helpers)
        p,t,good,bad=controller_bill(c,p0,t0,w,e,dp,dt)
        moments={}
        for s in (AXIS["INCUMBENT"],Fraction(".0038"),Fraction(".005"),Fraction(".0227")):
            z=price.sub(price.moment(t,s),price.moment(p,s))
            NEED(z[1]<0,"even relaxed isolated A outputs do not pay the invoice")
            moments[str(s)]={"value":price.value(z),"exact_interval":price.show(z)}
        records.append({"axis":e,"old_central_retained_A_ports":good,"no_central_A_ports":bad,
                        "paid":+p,"productive":+t,"complete_moment":moments})
    NEED(monotonic()<stop,"bounded exact mixed-type tariff")
    result={"status":"PASS_COMPLEX_TYPE_A_ISOLATION_SCREEN","records":records,
            "scope":"allow isolated A stage credit 2H7+2H8 at affected ports, existing A/B caller elsewhere; separate compensation architectures are open"}
    ns.output.write_text(json.dumps(result,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(result["status"],f"{perf_counter()-now:.2f}s")


if __name__=="__main__":
    main()
