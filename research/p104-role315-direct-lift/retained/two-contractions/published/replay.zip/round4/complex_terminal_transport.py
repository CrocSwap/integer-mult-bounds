# SPDX-License-Identifier: Apache-2.0
"""Refactor the exact #7546 full-chart sink by one-dimensional projections."""

import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
AXIS = run_path(str(WORK / "round3/type_b_axis_cut.py"))
SOURCE = AXIS["SOURCE"]
EXACT = run_path(str(WORK / "temporal_helper_floor.py"))
GRID, NEED = EXACT["GRID"], EXACT["need"]
FRESH, FULL = 512, 127


def sparse_add(dst, src, coefficient):
    """In-place exact rational-grid row addition, including the separate suffix grid."""
    p, q = coefficient.numerator, coefficient.denominator
    for j, x in src.items():
        dx, rem = divmod(x*p, q)
        NEED(not rem, "source coefficients must stay on the replay grid")
        y = dst.get(j, 0) + dx
        if y:
            dst[j] = y
        else:
            dst.pop(j, None)


def full_program(word):
    """Extract the scalar matrix from original ingress labels to returned owners."""
    program = word["program"]
    dims = list(map(len, word["frames"]))
    n = word["public"]
    top = [r for r, f in enumerate(word["final"]) if f == FULL]
    ingress = {}
    slots = {}
    operations = []
    for i, (op, r, *args) in enumerate(program):
        if op == "MOVE":
            f, g, owned = args
            NEED(f != FULL, "the original full chart has no outgoing MOVE")
            if g == FULL:
                NEED(r in top and r not in ingress, "every full ingress is one independent public slot")
                ingress[r] = (i, f, dims[g]-dims[f])
                slots[r] = {r: GRID}
        elif args[-1] == FULL:
            operations.append(i)
            if op == "INIT":
                NEED(r >= n and r not in slots, "owned full birth")
                slots[r] = {}
            elif op == "CLEAR":
                NEED(r >= n, "only scratch can be discarded")
                del slots[r]
            elif op == "SCALE":
                slots[r] = EXACT["scaled"](slots[r], Fraction(args[0]))
            else:
                NEED(op == "ADD" and r != args[0], "full coframe contacts are scalar ADDs")
                sparse_add(slots[r], slots[args[0]], Fraction(args[1]))
    NEED(not any(f == FULL for f in word["initial"]) and sorted(ingress) == top == sorted(slots),
         "the complete full sink is represented by its independent incoming slots")
    NEED(len(top) == 1052 and len(operations) == 29799, "pinned full sink census")
    return ingress, slots, operations


def common_caps(word, ingress, rows, outputs):
    """Find the independent ingress rows required across compatible and incompatible caps."""
    spaces = [EXACT["chart_space"](basis) for basis in word["frames"]]
    cut_space = set(term for r in outputs for term in rows[r])
    histogram = Counter(ingress[r][2] for r in cut_space)
    helpers, b_roles = AXIS["helper_roles"](word)
    trials = []
    for d in range(1, FRESH):
        if not (d.bit_count() % 2):
            continue
        if any((d & q).bit_count()%2 for q in outputs.values()):
            continue
        normal = {v for v in range(FRESH) if not (v & d).bit_count()%2}
        compatible = {r for r in cut_space if spaces[ingress[r][1]] <= normal}
        compatible_histogram = Counter(ingress[r][2] for r in compatible)
        projected = {r: {i: Fraction(a) for i, a in rows[r].items() if i not in compatible} for r in outputs}
        basis = {}
        for row in projected.values():
            EXACT["extend_basis"](basis, row, None)
        NEED(len(basis) == len(outputs), "forcing incompatible arrivals to stay full leaves all B readouts independent")
        # Any originally compatible helper terminal receives a rank-one-bigger
        # target only if given an additional phase. For each direct literal
        # one-hop helper the source→full rank is already its entire target rank.
        one = Counter()
        for r in cut_space:
            initial = word["initial"][r]
            original = ingress[r][1]
            if initial == original and r in helpers:
                one["compatible" if r in compatible else "incompatible"] += 1
        trials.append({"normal": d, "old_rank_histogram": histogram, "compatible_ingress": len(compatible),
                       "compatible_ranks": compatible_histogram, "direct_helper_ingress_by_compatibility": one,
                       "incompatible_access_rank": len(basis),
                       "pivot_incompatible_ingress_roles": sorted(basis),
                       "remainder_of_single_port_normals": len(b_roles)-len(outputs)})
    return trials


def split_low_returns(word, ingress, rows, targets, normal, rank_power, saving):
    """Price a fixed-stock split and give its coframed information obligation."""
    top = sorted(rows)
    dim = len(top)
    low = [r for r in top if not any((normal & j).bit_count() % 2 for j in word["frames"][ingress[r][1]])]
    low_set = set(low)
    high_set = set(top) - low_set
    below = {r: {j: Fraction(a, GRID) for j, a in rows[r].items() if j in low_set} for r in targets}
    above = {r: {j: Fraction(a, GRID) for j, a in rows[r].items() if j in high_set} for r in targets}
    high_basis = {}
    for row in above.values():
        EXACT["extend_basis"](high_basis, row, None)
    NEED(len(high_basis) == len(targets), "every target still requires a distinct incompatible full-chart direction")
    original = Counter(ingress[r][2] for r in low)
    # The fixed split retains each independent top coordinate. Every softened
    # ingress is separately completed to its original chart at the old sink.
    NEED(len(low)+len(high_set) == dim, "strict chart partition")
    direct = sum(1 for j in low if word["initial"][j] == ingress[j][1])
    by_completion = Counter()
    for old_rank, count in original.items():
        by_completion[old_rank] -= count
        if old_rank - 1:
            by_completion[old_rank-1] += count
        by_completion[1] += count
    # Per-entry splitting leaves the same total rank; its moment surcharge
    # is exact under the fixed independent-stock completion.
    delta = rank_power.moment(by_completion, saving)
    return {"low_compatible_total_ingresses": len(low), "direct_low_compatible": direct,
            "strict_high_quotient_rank_for_B": len(high_basis), "paid_delta_for_separately_completed_low_atoms":
            {r: q for r, q in by_completion.items() if q}, "completion_delta_moment": rank_power.value(delta),
            "B_rows_have_nonzero_low_signal": sum(bool(r) for r in below.values()),
            "example_high_pivots": sorted(high_basis)}


def exact_suffix_controls(readouts):
    """A compressed cross-chart basis still needs an independent row per mode."""
    a, b, c, d = ({0: 1}, {1: 1}, {2: 1}, {3: 1})
    r = [{0: 1, 2: 1}, {1: 1, 3: 1}]
    for fixed, wanted in (([a,b], 2), ([a,b,c], 1), ([a,b,c,d], 0)):
        bx = {}
        for v in fixed:
            EXACT["extend_basis"](bx, v, None)
        initial = len(bx)
        for v in r:
            EXACT["extend_basis"](bx, v, None)
        NEED(len(bx)-initial == wanted, "rank quotient response to planted early information")
    NEED(len(readouts) == 8, "one common lower chart must serve precisely eight Type B X fields")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("caller", type=Path)
    parser.add_argument("whole", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    now, deadline = perf_counter(), monotonic() + 35
    word = EXACT["pinned_json"](args.word, EXACT["WORD_SHA"], compressed=True)
    caller = EXACT["pinned_json"](args.caller, EXACT["CALLER_SHA"])
    whole = json.loads(SOURCE["pin"](args.whole, SOURCE["WHOLE"]))
    p, b = AXIS["helper_roles"](word)
    ingress, m, indices = full_program(word)
    rank_profiles = Counter()
    b_x = {r: q for r, q in zip(word["live"], word["ports"], strict=True) if r in b}
    for r, (_, old, rnk) in ingress.items():
        NEED(r in m and rnk + len(word["frames"][old]) == 9, "exact ordinary sink inventory")
        rank_profiles[rnk] += 1
    co = Counter(len(m[r]) for r in b_x)
    all_support = sorted(set().union(*(m[r] for r in b_x)))
    x_flags = {r for r in b_x}
    exact_suffix_controls(x_flags)
    tests = common_caps(word, ingress, m, b_x)
    NEED(len(tests) == 2 and len(x_flags) == 8, "two Type B global unit normals and eight X outputs")
    oldest = min(ingress[r][0] for r in all_support)
    price = SOURCE["price_engine"]()
    for test in tests:
        test["fixed_stock_split"] = split_low_returns(word, ingress, m, sorted(x_flags), test["normal"],
                                                     price, AXIS["INCUMBENT"])
    result = {"status": "PASS_COMPLEX_FULL_SINK_MATRIX", "word_sha256": EXACT["WORD_SHA"],
              "full_chart": FULL, "full_ingress_fields": len(ingress), "full_chart_scalar_operations": len(indices),
              "all_ingress_rank_profile": rank_profiles, "exact_B_X_output_rows":
              {r: {"support": sorted(m[r]), "coefficient_grid_sha256": sha256(json.dumps(m[r],sort_keys=True).encode()).hexdigest(),
                   "reused_independently_by_other_returns": any(r in v for u, v in m.items() if u != r)} for r in sorted(x_flags)},
              "all_b_X_input_atoms": len(all_support), "B_row_support_histogram": co,
              "b_X_input_atoms_also_used_elsewhere": sum(any(i in row for r,row in m.items() if r not in x_flags) for i in all_support),
              "first_needed_ingress": oldest, "cut_area": tests, "full_signed_paid_count": whole["signed_profile"]["signed_paid"],
              "full_stage_ids": [e[1] for e in caller["events"] if e[0] == "J"],
              "helper_returns_in_full": sum(r in p for r in ingress),
              "scope": "fixed independent ingress labels, common orthogonal Type B cap and exact scalar suffix; any changed prefix may change the cap quotient"}
    NEED(monotonic() < deadline, "full sink replay stayed within its 35-second bound")
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(result["status"], len(ingress), len(all_support), f"{perf_counter()-now:.2f}s")


if __name__ == "__main__":
    main()
