# SPDX-License-Identifier: Apache-2.0
"""Move a Type-B stage axis onto the inactive Type-A central address in #7113."""

import argparse
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
AXIS = run_path(str(WORK / "round3/type_b_axis_cut.py"))
SOURCE = AXIS["SOURCE"]
NEED = SOURCE["require"]


def evaluate(events, kind, stage_body, body_symbols, q):
    """Fourier specialization over Q(i), with exact dyadics and q in {±1,±i}."""
    # Gaussian integer pairs are encoded as Fraction pairs, keeping all
    # scalar cancellations and signs independent of floating-point support.
    one = (Fraction(1), Fraction(0))
    zero = (Fraction(0), Fraction(0))
    qi = (q[0], -q[1])
    q2 = multiply(q, q)

    def plus(a, b):
        return a[0]+b[0], a[1]+b[1]

    def scale(x, c):
        return {j: y for j, v in x.items() if (y := multiply(v, c)) != zero}

    def combine(x, y, c):
        result = x.copy()
        for j, v in y.items():
            a = plus(result.get(j, zero), multiply(v, c))
            if a == zero:
                result.pop(j, None)
            else:
                result[j] = a
        return result

    nm = len(kind["diagonal"])
    off = kind["offset"]
    rows = [{j: one} for j in range(nm)]
    for e in events:
        if e[0] == "J":
            if off == 0:
                a, b, c, d = e[2]
                rows[b] = combine(rows[b], rows[a], qi)
                rows[c] = combine(rows[c], rows[d], (-q[0], -q[1]))
                for r in e[2]:
                    rows[r] = scale(rows[r], phase_pair(stage_body[e[1]-1]))
            else:
                a0, b0, alpha, beta = e[3]
                a, b = a0-off, b0-off
                av, bv = Fraction(alpha), Fraction(beta)
                left = combine(rows[a], rows[b], (av*q[0], av*q[1]))
                right = combine(scale(rows[b], (1+av*bv, 0)), rows[a], (bv*qi[0], bv*qi[1]))
                rows[a], rows[b] = (scale(v, phase_pair(stage_body[e[1]-1])) for v in (left, right))
            continue
        if e[0] != ("A" if off == 0 else "B"):
            continue
        op, r0, *args = e[1:]
        r = r0-off
        if op == "ADD":
            rows[r] = combine(rows[r], rows[args[0]-off], (Fraction(args[1]), 0))
        elif op == "SCALE":
            rows[r] = scale(rows[r], (Fraction(args[0]), 0))
        elif op == "SWAP":
            j = args[0]-off
            rows[j], rows[r] = rows[r], rows[j]
        elif op == "QUERY":
            rows[r] = combine(rows[r], rows[args[0]-off], (q if args[1] == 1 else qi))
        elif op == "LAMBDA":
            z = Fraction(args[0], 2)
            coeff = plus((Fraction(1, 2), z), multiply((Fraction(1, 2), -z), q2))
            rows[r] = scale(rows[r], coeff)
        elif op in ("IDLE_ONE", "IDLE_ODD"):
            scale_value = one
            for j in args[0]:
                scale_value = multiply(scale_value, phase_pair(body_symbols[j-1]))
            rows[r] = scale(rows[r], multiply(scale_value, qi if op == "IDLE_ODD" else one))
        else:
            raise ValueError(f"unknown exact caller gate {op}")
    return rows


def multiply(a, b):
    x, y = a
    u, v = b
    return x*u-y*v, x*v+y*u


def phase_pair(value):
    return value if isinstance(value, tuple) else (value, 0)


def scenario(caller, tag, stage, price, saving, base_p, base_t):
    kind = caller["types"][tag]
    ports = len(kind["ports"])
    p, t = Counter(), Counter()
    idle_count, targets = 0, 0
    for e in caller["events"]:
        if e[0] == tag and e[1] in ("IDLE_ONE", "IDLE_ODD") and stage in e[3]:
            r = 8*len(e[3]) + (e[1] == "IDLE_ODD")
            p[r] -= ports
            p[r+1] += ports
            idle_count += ports
    for phase, z, *mask in kind["diagonal"]:
        NEED(phase == -1 and z == 0, "retained target orientation")
        if mask[stage-1]:
            rank = 1 + 8*sum(mask)
            if tag == "A":
                # A stage axis identified with the central Q contributes
                # Q at this output, where the old factor was Q^-1.
                rank_new = rank - 1
            else:
                rank_new = rank + 1
            t[rank] -= ports
            t[rank_new] += ports
            targets += ports
    p[1] += 2 * ports if tag == "B" else 0
    new_p, new_t = base_p.copy(), base_t.copy()
    new_p.update(p)
    new_t.update(t)
    change = price.sub(price.moment(t, saving), price.moment(p, saving))
    value = price.sub(price.moment(new_t, saving), price.moment(new_p, saving))
    return {"type": tag, "stage": stage, "old_idles_repriced": idle_count, "targets_repriced": targets,
            "paid_delta": dict(p), "productive_delta": dict(t), "delta_raw": price.value(change),
            "moment_raw": price.value(value), "directed_delta": price.show(change)}


def endpoint_controls(caller):
    """Exercise the Laurent identity in all four central sectors with two body lifts."""
    checks = []
    for tag, kind in caller["types"].items():
        for q in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            for flipped in ({1}, {1, 7, 9, 13, 17}):
                body = tuple(-1 if i in flipped else 1 for i in range(1,18))
                current = evaluate(caller["events"], kind, body, body, q)
                wanted = []
                for r, (_phase, _z, *mask) in enumerate(kind["diagonal"]):
                    k = sum(i in flipped and b for i,b in enumerate(mask,1))
                    wanted.append({r: multiply(((-1)**k,0), (q[0],-q[1]))})
                NEED(current == wanted, "all arbitrary input roles in the scalar sign specialization")
                checks.append([tag, q, sorted(flipped)])
            base = tuple(-1 if j in (6, 12) else 1 for j in range(17))
            projected = (q,) + base[1:]
            # Stage values can be complex only in the central-identification
            # trial. Promote scalars to Gaussian pairs inside `evaluate`.
            current = evaluate(caller["events"], kind, projected, projected, q)
            wanted = []
            for r, (_, _, *mask) in enumerate(kind["diagonal"]):
                z = (q[0], -q[1])
                for j, on in enumerate(mask):
                    if on:
                        z = multiply(z, phase_pair(projected[j]))
                wanted.append({r: z})
            NEED(current == wanted, "exact central identification on every scalar entry")
            checks.append([tag, q, "D1=central"])
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("caller", type=Path)
    parser.add_argument("whole", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    start = perf_counter()
    deadline = monotonic() + 30
    c = json.loads(SOURCE["pin"](args.caller, SOURCE["CALLER"]))
    whole = json.loads(SOURCE["pin"](args.whole, SOURCE["WHOLE"]))
    controls = endpoint_controls(c)
    price = SOURCE["price_engine"]()
    p = Counter({int(r): x for r,x in whole["signed_profile"]["signed_paid"].items()})
    t = Counter({int(r): x for r,x in whole["signed_profile"]["signed_productive"].items()})
    sc = {k: [scenario(c,k,i,price,AXIS["INCUMBENT"],p,t) for i in range(1,18)] for k in c["types"]}
    best_a = max(row["delta_raw"][1] for row in sc["A"])
    NEED(best_a < -376 and sc["B"][0]["delta_raw"][1] < 0, "even free central identification does not close the invoice")
    NEED(monotonic() < deadline, "caller specialization deadline")
    result = {"status": "PASS_CALLER_CENTRAL_COINCIDENCE_SCREEN", "checks": controls,
              "cases": sc, "scope": "charge all changed Type B body extensions and optimistic self-central cancellation in Type A, with A host adapters granted free"}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(result["status"], f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
