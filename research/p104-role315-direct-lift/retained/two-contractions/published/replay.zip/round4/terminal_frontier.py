# SPDX-License-Identifier: Apache-2.0
"""Compare where the primal and adjoint complex words acquire Type B outputs."""

import argparse
from collections import Counter
import json
from pathlib import Path
from runpy import run_path
from time import monotonic, perf_counter


HERE = Path(__file__).resolve().parent
MODEL = run_path(str(HERE / "complex_terminal_transport.py"))
ADJOINT = run_path(str(HERE / "independent/complex_adjoint.py"))
ROWS = ADJOINT["ROWS"]
EXACT, NEED = (MODEL[k] for k in ("EXACT", "NEED"))


def output_rows_here(word, all_targets, expected, deadline):
    """Check which ready B rows can be taken independently before the final jump."""
    n = word["public"]
    data = [ROWS["unit"](r) for r in range(n)] + [ROWS["NONE"]] * word["owned_fields"]
    frames = word["initial"][:] + [None] * word["owned_fields"]
    n_end = dict.fromkeys(all_targets, 0)
    incidence = Counter()
    exact = {}
    coframe = {}
    windows = {}
    target_set = set(all_targets)
    for i, (op, r, *d) in enumerate(word["program"]):
        if i % 1024 == 0:
            NEED(monotonic() < deadline, "full-frontier timed replay")
        if op == "MOVE":
            s, t = d[:2]
            NEED(s == frames[r], "live frame during frontier test")
            if r in target_set and t == 127:
                n_end[r] += 1
                exact[r] = data[r] == expected[r]
                peers = [data[j] for j in range(len(data)) if frames[j] == s and data[j][1]]
                group = [ROWS["projective_key"](a, set()) for a in peers]
                q = ROWS["projective_key"](expected[r], set())
                coframe[r] = ROWS["matrix_rank"](group + [q]) == ROWS["matrix_rank"](group)
                windows[r] = (i, s, len(peers), len(data[r][1]))
            frames[r] = t
        elif op == "INIT":
            frames[r] = d[0]
        elif op == "CLEAR":
            frames[r], data[r] = None, ROWS["NONE"]
        elif op == "SCALE":
            data[r] = ROWS["scale"](data[r], ROWS["ratio"](d[0]))
        elif op in ("ADD", "COPY"):
            s, factor, f = d
            NEED(frames[r] == f == frames[s], "coframed normalized ADD/COPY")
            if r in target_set and f == 127:
                incidence["writes_to_B_full"] += 1
            if s in target_set and f == 127:
                incidence["reads_from_B_full"] += 1
            if op == "COPY":
                NEED(data[r] == ROWS["NONE"], "true zero destination before COPY")
            data[r] = ROWS["increment"](data[r], data[s], ROWS["ratio"](factor))
    NEED(set(n_end.values()) == {1}, "each B-X boundary receives one full jump")
    NEED(data[:n] == expected, "complete arbitrary-input endpoint during census")
    return {"endpoint_rows_already_pure_at_full_move": [r for r in all_targets if exact[r]],
            "coframed_pure_pivot_available": [r for r in all_targets if coframe[r]],
            "full_move_windows": windows, "full_B_scalar_incidence": incidence}


def gauge_candidates(word, data, deadline):
    """Enumerate orthogonal missing directions of each last literal MOVE."""
    probes = []
    for r, (at, chart, _, _) in data["full_move_windows"].items():
        NEED(monotonic() < deadline, "finite frontier projection")
        q = word["ports"][word["live"].index(r)]
        old = word["frames"][chart]
        normals = [a for a in range(1,512) if a.bit_count() % 2 and not (a & q).bit_count()%2 and
                   all(not (a & v).bit_count()%2 for v in old)]
        probes.append({"role":r,"source_chart":chart,"move_event":at,"nested_body_normals":normals})
    return probes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("word", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    start, deadline = perf_counter(), monotonic()+25
    source = EXACT["pinned_json"](args.word, EXACT["WORD_SHA"], compressed=True)
    dual, _, _ = ADJOINT["build"](source)
    b, expected, _ = ROWS["target"](source)
    x = sorted(r for r in source["live"] if r in b)
    result = {"status": "PASS_COMPLEX_PRIMAL_DUAL_TERMINAL_FRONTIERS", "source_sha256": EXACT["WORD_SHA"],
              "dual_canonical_sha256": ADJOINT["digest"](dual)}
    for label, word in (("primal", source),("adjoint", dual)):
        data = output_rows_here(word, x, expected, deadline)
        data["body_normals_missing_from_literal_source_frame"] = gauge_candidates(word,data,deadline)
        result[label] = data
    NEED(monotonic() < deadline, "25-second combined terminal test")
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    print(result["status"], f"{perf_counter()-start:.2f}s")


if __name__ == "__main__":
    main()
