"""Emit and independently check the literal exact free rank-nine split."""
from fractions import Fraction as Q
import gzip,json
from hashlib import sha256
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cut import row, column, operands


def main(word,witness,out,receipt):
    raw=gzip.decompress(word.read_bytes())
    W=json.loads(raw); h=json.loads(witness.read_bytes())
    assert sha256(raw).hexdigest()==h['source_word_sha256']=='db9b86eba69ca556be5abc1eb85292566fc065ddebad9a26b2da0475f22aec6b'
    n=W['public']; ev=W['program']; p=h['pivot']; t=h['cut_before']; f=h['frame'];u,v=h['boundary']
    assert (n,p,t,f,u,v)==(1482,1285,35903,117,3,127)
    a,b,c,d=({int(k):Q(x) for k,x in h[s].items()} for s in ('a','b','c','d'))
    assert row(a,ev[:t])==c and column(b,ev[t:])==d
    assert sum(x*b.get(k,0) for k,x in a.items())==sum(x*d.get(k,0) for k,x in c.items())==1
    alpha=c.copy();alpha[p]-=1
    assert row(alpha,ev)==alpha and row({p:Q(1)},ev)==column({p:Q(1)},ev)=={p:Q(1)}
    G=h['output_G_before_rebind']; J=h['cut_J']
    assert row({p:Q(1)},G)==c and column(d,G)=={p:Q(1)}
    assert row({p:Q(1)},J)==a and column(b,J)=={p:Q(1)}
    assert h['suffix_pivot_contacts']==[i for i,e in enumerate(ev) if i>=t and any(e[k]==p for k in operands(e))]
    def shifted(e,new=False):
        z=e.copy()
        for k in operands(z):
            if z[k]>=n:z[k]+=1
            elif new and z[k]==p:z[k]=n
        return z
    prog=h['input_G_inverse']+[shifted(e) for e in ev[:t]]+J
    prog += [shifted(e,True) for e in h['suffix_J_inverse_before_rebind']+ev[t:]+G]
    final=W['final']+[v];final[p]=f
    outword=dict(W,public=n+1,initial=W['initial']+[f],final=final,program=prog)
    cur=outword['initial']+[None]*W['owned_fields']
    for e in prog:
        op,r=e[:2]
        if op=='MOVE':assert cur[r]==e[2];cur[r]=e[3]
        elif op=='INIT':assert cur[r] is None;cur[r]=e[2]
        elif op=='CLEAR':assert cur[r]==e[2];cur[r]=None
        else:
            assert cur[r]==e[-1]
            if op in ('ADD','COPY'):assert cur[e[2]]==e[-1]
    assert cur==final+[None]*W['owned_fields']
    assert row({p:Q(1)},prog)=={p:Q(1)} and row({n:Q(1)},prog)=={n:Q(1)}
    assert column({p:Q(1)},prog)=={p:Q(1)} and column({n:Q(1)},prog)=={n:Q(1)}
    payload=json.dumps(outword,sort_keys=True,separators=(',',':')).encode()
    out.write_bytes(gzip.compress(payload,mtime=0))
    r={'status':'PASS_LITERAL_FREE_RANK9_SPLIT','word_sha256':sha256(payload).hexdigest(),
       'events':len(prog),'public':n+1,'owned':W['owned_fields'],'paid_delta':{},
       'productive_delta':{4:1,5:1,9:-1},'retained_pivot':p,'successor':n,
       'all_chart_contacts_checked':True,'explicit_pivot_endpoints_checked':True}
    receipt.write_text(json.dumps(r,indent=2)+'\n');print(r)

if __name__=='__main__':main(*(Path(x) for x in sys.argv[1:]))
