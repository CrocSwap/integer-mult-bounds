"""Complete independent gate for the cocharted rank-nine helper split."""
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
from types import ModuleType
import gzip
import json
import sys

OLD = "db9b86eba69ca556be5abc1eb85292566fc065ddebad9a26b2da0475f22aec6b"
CALLER = "9557f713ab4ffb91ede05e8a6d5668c694b9940fc16f2f2d657e2f2b2cac2d3f"
BASE = "02745de35e6d9cd1deca76506d217d06675636b6e4aa602eac1d1e1b5e0a99d7"


def module(name, path, edits=()):
    raw = path.read_text()
    for before, after in edits:
        assert raw.count(before) == 1, (path, before)
        raw = raw.replace(before, after)
    out = ModuleType(name)
    out.__file__ = str(path)
    sys.modules[name] = out
    exec(compile(raw, str(path), "exec"), out.__dict__)
    return out


def delta(old, new):
    counts = Counter(new)
    counts.subtract(old)
    return {k: v for k, v in sorted(counts.items()) if v}


def signed(invoice):
    counts = Counter(invoice["T"])
    counts.subtract(invoice["P"])
    return {r: n for r, n in counts.items() if n}


def exact_price(vendor, archive, before, after, source):
    g = module("transferred_interval", vendor / "interval_gate.py")
    other = module("transferred_independent_price", archive / "audit_price.py")
    old, new = map(signed, (before, after))
    old_lo, old_hi = map(Q, source["gate"]["raw_bracket"])
    assert g.moment(old, old_lo)[0] > 0 and g.moment(old, old_hi)[1] < 0
    assert g.moment(new, old_hi)[0] > 0
    _, (check_lo, check_hi), _ = other.crossing(new)
    scale = 10**34
    a = (scale * check_lo).__floor__()
    lo, hi = Q(a, scale), Q(a + 1, scale)
    assert old_hi < lo <= check_lo < check_hi <= hi
    assert g.moment(new, lo)[0] > 0 > g.moment(new, hi)[1]
    k = Q((lo * 10**15).__floor__(), 10**15)
    tested = k + Q(7, 10**17)
    while tested >= lo:
        tested = k + (tested - k) / 10
    assert old_hi < k < tested < lo
    assert g.moment(old, k)[1] < 0 and other.raw_margin(old, k)[1] < 0
    gate = g.gate(after, k, tested, lo, hi, source["gate"]["BIT_pin"])
    with localcontext() as ctx:
        ctx.prec = 75
        show = lambda v: str(Decimal(v.numerator) / Decimal(v.denominator))
        price = dict(claim_decimal=show(k), previous_claim=source["gate"]["claim"],
                     gain=show(k-Q(source["gate"]["claim"])),
                     gain_exact=str(k-Q(source["gate"]["claim"])),
                     raw_bracket=[show(lo), show(hi)],
                     independent_raw_bracket=[show(check_lo), show(check_hi)],
                     candidate_margin_at_old_upper=g.show(g.moment(new, old_hi)),
                     baseline_rejects_new_claim=True)
    return gate, price


def main(replay, rank9, old_path, new_path, caller_path, source_path, new_pin):
    raw, new_raw = [gzip.decompress(p.read_bytes()) for p in (old_path, new_path)]
    assert tuple(sha256(x).hexdigest() for x in (raw, new_raw, caller_path.read_bytes(), source_path.read_bytes())) == (OLD, new_pin, CALLER, BASE)
    old, new, caller, source = map(json.loads, (raw, new_raw, caller_path.read_bytes(), source_path.read_bytes()))
    assert all(old[k] == new[k] for k in old.keys() - {"initial", "final", "public", "program"})
    vendor = replay / "research/shared-wire-split-composition"
    archive = replay / "research/shared-wire-stop-fusion"
    sys.path.insert(0, str(rank9))
    base = module("retimed_rank9_gate", rank9 / "candidate_gate.py", (
        ('== 1080', '== 1083'),
        ('fresh_arbitrary_helpers=18 * 1080', 'fresh_arbitrary_helpers=18 * 1083'),
    ))
    ind = base.independent(vendor)
    old_native, native = map(ind.native, (old, new))
    assert not old_native["bad_inputs"] and not native["bad_inputs"]
    assert all(old_native[k] == native[k] for k in ("owned_peak", "lifetimes", "rises"))
    assert delta(old_native["paid"], native["paid"]) == {}
    assert delta(old_native["helpers"], native["helpers"]) == {4: 1, 5: 1, 9: -1}
    mutation = ind.native(new, mutant=0)["bad_inputs"]
    assert mutation
    symbolic = ind.caller(caller)
    assert not symbolic["bad_outputs"] and symbolic == source["caller"]
    before, after = (ind.invoices(w, caller, n) for w, n in ((old, old_native), (new, native)))
    for key in ("T", "P"):
        assert {str(r): v for r, v in before[key].items()} == source["invoice"][key]
    assert delta(before["P"], after["P"]) == {}
    assert delta(before["T"], after["T"]) == {4: 18, 5: 18, 9: -18}
    assert before["S"] == after["S"] == 1520
    assert before["empty_root_credits"] == after["empty_root_credits"] == 0

    unadjusted, ordinary = (ind.ordinary(w, caller, n) for w, n in ((old, old_native), (new, native)))
    route = source["ordinary"]["caller_items"]["B"]["fused_routes"]
    route_delta = route - unadjusted["caller_items"]["B"]["fused_routes"]
    surcharge = source["ordinary"]["extra_B_scalar_surcharge"]
    assert unadjusted["conservative_total"] + route_delta + surcharge == source["ordinary"]["conservative_total"]
    ordinary["caller_items"]["B"]["fused_routes"] = route
    for name in ("caller_total", "raw_upper", "conservative_total"):
        ordinary[name] += route_delta
    ordinary["extra_B_scalar_surcharge"] = surcharge
    ordinary["conservative_total"] += surcharge
    ordinary["margin_to_billion"] = 10**9 - ordinary["conservative_total"]
    assert ordinary["margin_to_billion"] > 0
    gate, price = exact_price(vendor, archive, before, after, source)
    manifest = json.loads((vendor / "INDEPENDENT-SOURCES.json").read_bytes())
    limits = base.precision(vendor, new, caller, gate, manifest)
    out = dict(status="PASS_COCHART_RANK9_SPLIT_GATES", word_sha256=new_pin, caller_sha256=CALLER,
               native=native, caller=symbolic, mutation_bad_inputs=mutation,
               invoice=after, ordinary=ordinary, gate=gate, price=price, precision=limits)
    print(json.dumps(out, sort_keys=True))


if __name__ == "__main__":
    assert __debug__
    main(*(Path(p) for p in sys.argv[1:-1]), sys.argv[-1])
