#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bundle=$PWD
shasum -a 256 -c SHA256SUMS >/dev/null
if [[ $# != 1 ]]; then echo 'usage: verify.sh /absolute/results' >&2; exit 2; fi
mkdir -p "$1"
out=$(cd "$1" && pwd)
[[ -z "$(ls -A "$out")" ]]
python_bin=$(command -v "${RANK9_PYTHON:-python3.12}")
"$python_bin" -c 'import sys; assert sys.version_info[:2] == (3,12)'
work=$(mktemp -d "${TMPDIR:-/tmp}/croc-cochart-clean.XXXXXX")
trap 'rm -rf "$work"' EXIT
mkdir "$work/old" "$work/parent" "$work/base"
tar -xzf "$bundle/predecessor.tar.gz" -C "$work/old"
(cd "$work/old"; shasum -a 256 -c SHA256SUMS >/dev/null)
tar -xzf "$work/old/parent-replay.tar.gz" -C "$work/parent"
(cd "$work/parent"; shasum -a 256 -c SHA256SUMS >/dev/null)
tar -xzf "$work/parent/rank9-replay.tar.gz" -C "$work/base"
(cd "$work/base"; shasum -a 256 -c SHA256SUMS >/dev/null)
b="$work/base/sources/kappa-coupled-boundaries-20261110T0908Z"
r="$work/base/sources/kappa-rank9-lower-20261110T1247Z/evidence"
tar -xzf "$work/base/payload/incumbent.tar.gz" -C "$b"
v="$b/replay/research/shared-wire-split-composition"
a="$b/replay/research/shared-wire-stop-fusion/audit_native.py"
prior="$out/BASE-RANK9.json.gz"
old="$out/BASE-WORD.json.gz"
new="$out/WORD.json.gz"
caller="$r/dyadic/CALLER.json"
pin=3d500210240a340b865e2df8ce93cd53ad797537c1f6297508d2bd6a9b863d78
"$python_bin" -B "$work/parent/build.py" "$b/evidence/candidate.json.gz" "$a" "$prior" > "$out/BASE-RANK9-GRID.json"
cmp "$out/BASE-RANK9-GRID.json" "$work/parent/GRID.json"
"$python_bin" -B "$work/old/build.py" "$prior" "$a" "$old" > "$out/BASE-GRID.json"
cmp "$out/BASE-GRID.json" "$work/old/GRID.json"
"$python_bin" -I -B "$bundle/emit.py" "$old" "$bundle/WITNESS.json" "$new" "$out/EMIT.json" > "$out/emitter.stdout"
cmp "$out/EMIT.json" "$bundle/EMIT.json"
"$python_bin" -B "$bundle/gate.py" "$b/replay" "$r" "$old" "$new" "$caller" "$work/old/RESULT.json" "$pin" > "$out/gate.stdout" 2> "$out/gate.stderr" &
gate=$!
"$python_bin" -I -B "$v/frozen/verify_host3_odd.py" "$new" 1125 > "$out/host3.stdout" 2> "$out/host3.stderr" &
host=$!
"$python_bin" -I -B "$v/frozen/physical.py" "$new" "$v/frozen/clifford_exact.py" 1000000009 11 > "$out/physical.stdout" 2> "$out/physical.stderr" &
phys=$!
"$python_bin" -B "$bundle/routes.py" "$b/replay" "$r" "$old" "$new" "$caller" "$pin" 1285 117 > "$out/ROUTES.json" 2> "$out/routes.stderr" &
routes=$!
wait "$gate"
tail -1 "$out/gate.stdout" > "$out/RESULT.json"
wait "$host"
wait "$phys"
wait "$routes"
grep -q 'endpoint bad rows 0 odd certificate S 1125' "$out/host3.stdout"
grep -q 'helper rows bad 0 (of 1083), X rows bad 0, Y rows bad 0, X2 rows bad 0, Y2 rows bad 0' "$out/physical.stdout"
for log in "$out"/*.stderr; do test ! -s "$log"; done
cmp "$out/RESULT.json" "$bundle/RESULT.json"
cmp "$out/ROUTES.json" "$bundle/ROUTES.json"
"$python_bin" - "$out/RESULT.json" <<'PY'
from decimal import Decimal
import json
import sys
p=json.load(open(sys.argv[1]))['price']
print('PASS_COCHART_RANK9_SPLIT_REPLAY',p['claim_decimal'],format(Decimal(p['gain']),'f'))
PY
