#!/usr/bin/env python3
"""Pinned #7113/#7829 caller projection, structural bridge, and controls.

No Lean proof is claimed. Only the Python standard library is required.
"""
import argparse
import contextlib
import copy
from fractions import Fraction
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True

HEADS = {
    '7113': '07a76c5e2738882c0cb322278e56f6cae3c9885d',
    '7829': '1fdc9ecd1b1311d8ea6e02b6f81ae0d8d24999e2',
    '7852': '41beda1d6435760dc99e38bd7e65f36798aad212',
}
P7113 = 'research/signed-caller-8x9/'
P7829 = 'research/p104-certkit-pricekit-to-lean/'
P7852 = 'research/p104-lowerbound-toolkit/'
SHORT = P7113 + 'replay/supplier7112/short-caller/'
NATIVE = P7113 + 'replay/supplier7112/'
PINS = {
    '7113': {
        SHORT + 'independent.py': '21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874',
        SHORT + 'signed_model.py': 'f88c798b9a22c656ea0b755b4f32be411c1f80687dff1a1ac9e9c2a0b5f4203e',
        SHORT + 'check_odd_physical_binding.py': '5c80c3b0415a7f91d216395248dd6f13297eed637732098e1ca8fb0548951b98',
        SHORT + 'upstream_application.py': 'd98987db98553dc55bfc80e3ca47abfcd51c57af6f8cda61101391d8eae94184',
        SHORT + 'DATA-PHASES.json': 'c5916ff312678f12aba403847643fbbc29f643acec60bdf836fa56cd3e8251fa',
        NATIVE + 'WORD.json.gz': 'fe0b1dc3049a6b72760a705af2e698e0e9998e969e19862a696eba63434eb233',
        NATIVE + 'RESULT.json': '7b808ff32d9803084aaaf820cd172ddc9001c7aebbd17e0324e779abeff91b30',
        P7113 + 'expected/ODD-TYPE-AB-REPLAY.json': '71fd0a7ad8b743266c6a75100f3543b48ea7d6fcbe45f008d3b61270e3b660a0',
        P7113 + 'expected/ODD-PHYSICAL-BINDING.json': 'ade5f8cbb2e30677b1d48d23a1aa270b3d0b72e2504472ab9fdb71d124b075b5',
    },
    '7829': {
        P7829 + 'data/7113_CALLER.json': '255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc',
        P7829 + 'tools/callerfacts.py': '1bee1e86ecf1f4c3a8d18cad81b067acb9bce3d829573d407e5a0d76a64671a9',
        P7829 + 'lean/Nov15/CertCaller7113Data.lean': '948769347f3db9ed141f6ce812816a296f151b52831843f1666c6f45a1b8ceb5',
        P7829 + 'lean/Nov15/CertCaller7113Facts.lean': '35f221068aeb0f34ff6f4237fa9779674da8c794841317f2c5e5017c5675b7fe',
        P7829 + 'verify.py': '6289a99656a068ee7bced48041019963e85e0ea8c5989824d9f094e7d4762785',
        P7829 + 'MANIFEST.sha256': '49419b339736c857ad17893704307baa277aded75eff43c9a665c9ab57ec6359',
    },
    '7852': {
        P7852 + 'lean/Nov15/CallerWord.lean': '02b34949c241701ed732a2e1b6ef3957f2b23518e07ba289fe7c7b84b8afdbc7',
        P7852 + 'lean/Nov15/CertCallerCore.lean': '0484b57ea3b7296a1e7cd944a3233342e71559e55450eef2fa53908ef189ac57',
        P7852 + 'lean/Nov15/SchemaCostC.lean': '60a0c9e21f87af58dcf1850dfd2a10cce14ecfe61431d9007d7932b2ae14badd',
    },
}


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()


def import_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def check_inputs(roots, allow_exports):
    verified = {}
    for number, root in roots.items():
        require(root.is_dir(), 'missing source directory: ' + str(root))
        if (root / '.git').exists():
            head = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
            require(head == HEADS[number], 'wrong checkout head for #' + number + ': ' + head)
            verified[number] = 'git-head-and-file-sha256'
        else:
            require(allow_exports, 'checkout lacks .git; pass --allow-exports to use pinned file hashes')
            verified[number] = 'pinned-file-sha256-only'
        for path, digest in PINS[number].items():
            require(sha((root / path).read_bytes()) == digest, 'source hash mismatch: ' + number + '/' + path)
    return verified


def normalize(C):
    """Lossless source-event normalization and #7852 jA/jB primitive expansion.

    Role IDs become type-local and source stages 1..17 become 0..16. The
    returned syntax is a Python witness, not a Lean elaboration.
    """
    k = C['stages']
    require(k == 17 and C['roles'] == 72, 'unexpected caller dimensions')
    require(list(C['types']) == ['A', 'B'], 'unexpected type order')
    for t, off in [('A', 0), ('B', 36)]:
        v = C['types'][t]
        require(v['offset'] == off and v['roles'] == 36 and len(v['diagonal']) == 36,
                'unexpected role layout ' + t)
    alpha = C['types']['A']['alpha2']
    Fraction(alpha)
    records, primitive, targets, hosts = [], {'A': [], 'B': []}, {}, []

    def local(t, r):
        require(isinstance(r, int) and not isinstance(r, bool), 'role is not an integer')
        n = r - C['types'][t]['offset']
        require(0 <= n < C['types'][t]['roles'], 'role out of type range')
        return n

    def fin_stages(stages):
        require(isinstance(stages, list), 'stage set is not a list')
        require(all(isinstance(s, int) and not isinstance(s, bool) and 1 <= s <= k for s in stages),
                'stage out of range')
        require(len(stages) == len(set(stages)), 'repeated stage')
        return [s - 1 for s in stages]

    for t in ('A', 'B'):
        targets[t] = []
        for row in C['types'][t]['diagonal']:
            require(len(row) == k + 2 and row[1] == 0, 'bad target row')
            require(isinstance(row[0], int) and all(bit in (0, 1) for bit in row[2:]), 'bad target mask')
            targets[t].append([row[0], row[1], [i for i, bit in enumerate(row[2:]) if bit]])

    for i, e in enumerate(C['events']):
        if e[0] == 'J':
            require(len(e) == 4 and isinstance(e[1], int) and 1 <= e[1] <= k,
                    'bad J stage')
            require(len(e[2]) == 4 and len(e[3]) == 4, 'bad J shape')
            a = [local('A', r) for r in e[2]]
            b = [local('B', e[3][0]), local('B', e[3][1]), e[3][2], e[3][3]]
            Fraction(b[2]); Fraction(b[3])
            stage = e[1] - 1
            records.append(['J', stage, a, b])
            pa = [['host', a[0], a[1], '0', '1'], ['host', a[2], a[3], alpha, '0']]
            pb = [['host', b[0], b[1], b[2], b[3]]]
            for h in pa:
                hosts.append([i, 'A', h[1], h[2]])
            for h in pb:
                hosts.append([i, 'B', h[1], h[2]])
            primitive['A'].extend(pa + [['idle', r, [stage], 0] for r in a])
            primitive['B'].extend(pb + [['idle', r, [stage], 0] for r in b[:2]])
            continue
        require(len(e) >= 4 and e[0] in ('A', 'B'), 'bad plain event')
        t, op = e[:2]
        r = local(t, e[2])
        if op == 'ADD':
            require(len(e) == 5, 'bad ADD')
            s = local(t, e[3]); Fraction(e[4])
            rec = [t, op, r, s, e[4]]
            prim = ['add', r, s, e[4]]
        elif op == 'SCALE':
            require(len(e) == 4, 'bad SCALE'); Fraction(e[3])
            rec = [t, op, r, e[3]]
            prim = ['scale', r, e[3]]
        elif op == 'SWAP':
            require(len(e) == 4, 'bad SWAP')
            s = local(t, e[3]); rec = [t, op, r, s]
            prim = ['swap', r, s]
        elif op == 'QUERY':
            require(len(e) == 5 and isinstance(e[4], int) and e[4] % 2 == 1, 'bad QUERY')
            s = local(t, e[3]); rec = [t, op, r, s, e[4]]
            prim = ['query', r, s, e[4]]
        elif op == 'LAMBDA':
            require(len(e) == 4 and e[3] in (-1, 1), 'bad LAMBDA')
            rec = [t, op, r, e[3]]; prim = ['lam', r, e[3]]
        elif op in ('IDLE_ONE', 'IDLE_ODD'):
            require(len(e) == (4 if op == 'IDLE_ONE' else 5), 'bad IDLE')
            stages = fin_stages(e[3])
            q = 0 if op == 'IDLE_ONE' else e[4]
            require(isinstance(q, int) and (op != 'IDLE_ODD' or q % 2 == 1), 'bad idle phase')
            rec = [t, op, r, stages] + ([] if op == 'IDLE_ONE' else [q])
            prim = ['idle', r, stages, q]
        else:
            raise AssertionError('unsupported plain opcode: ' + op)
        records.append(rec)
        primitive[t].append(prim)

    def restore(rec):
        if rec[0] == 'J':
            _, stage, a, b = rec
            return ['J', stage + 1, [x + C['types']['A']['offset'] for x in a],
                    [b[0] + C['types']['B']['offset'], b[1] + C['types']['B']['offset'], b[2], b[3]]]
        t, op, r, *args = rec
        if op in ('ADD', 'SWAP', 'QUERY'):
            args[0] += C['types'][t]['offset']
        elif op in ('IDLE_ONE', 'IDLE_ODD'):
            args[0] = [s + 1 for s in args[0]]
        return [t, op, r + C['types'][t]['offset'], *args]

    require([restore(r) for r in records] == C['events'], 'normalized event round trip')
    violations = [h for h in hosts if h[2] == h[3]]
    witness = {'stages': k, 'ports': {t: C['types'][t]['ports'] for t in ('A', 'B')},
               'targets': targets, 'records': records, 'primitive': primitive}
    return witness, violations


def check_packed(C, witness, cf):
    types, nev, packed = cf.encode(C)
    require(cf.decode_invoice(types, nev, packed) == cf.invoice(C), 'pricing round trip')
    idle_checks = wrong_index_rejections = row_checks = 0
    js = []
    distinct_a = distinct_b = 0
    for i, (e, n) in enumerate(zip(C['events'], witness['records'])):
        x = (packed >> (32 * i)) & ((1 << 32) - 1)
        if e[0] == 'J':
            require(x == 0 and n[1] == e[1] - 1, 'J normalization')
            distinct_a += len(set(n[2])) == 4
            distinct_b += n[3][0] != n[3][1]
            js.append(n[1]); continue
        require(x % 16 == cf.OPS[e[1]], 'opcode mismatch')
        require((x // 16) % 4 == list(C['types']).index(e[0]), 'type mismatch')
        if e[1] in ('IDLE_ONE', 'IDLE_ODD'):
            stages = n[3]
            normal = sum(1 << s for s in stages)
            raw = x // 64
            require(raw & 1 == 0 and raw >> 1 == normal, 'exact stage-mask mismatch')
            idle_checks += 1
            wrong_index_rejections += (raw != normal)
        else:
            require(x // 64 == 0, 'unexpected plain stage bits')
    require(js == list(range(17)), 'J stage order')
    for ti, t in enumerate(('A', 'B')):
        for i, row in enumerate(C['types'][t]['diagonal']):
            slot = (types[ti][2] >> (64 * i)) & ((1 << 64) - 1)
            require(slot % (1 << 16) == row[0] + (1 << 15), 'target exponent mismatch')
            norm_mask = sum(1 << s for s in witness['targets'][t][i][2])
            require(slot >> 16 == norm_mask, 'exact target stage-mask mismatch')
            row_checks += 1
    return {'event_slots': nev, 'idle_masks_exact_after_shift': idle_checks,
            'unshifted_interpretations_rejected': wrong_index_rejections,
            'target_masks_exact': row_checks, 'j_stages': len(js),
            'j_a_all_four_distinct': distinct_a, 'j_b_pair_distinct': distinct_b}


def ceil_log2(q):
    a, b = q.numerator, q.denominator
    k = a.bit_length() - b.bit_length()
    require(k >= 0, 'negative log ceiling input')
    return k + (a > b << k)


def signed_caller(root):
    path = root / SHORT / 'independent.py'
    m = import_file('caller_independent', path)
    text = path.read_text()
    body = text[text.index('def caller('):text.index('def invoices(')]
    changes = [
        ("elif event[1]=='IDLE_ONE':degree.update(event[3])",
         "elif event[1] in ('IDLE_ONE','IDLE_ODD'):degree.update(event[3])"),
        ("elif op=='IDLE_ONE':rows[r]=pscale(rows[r],m=sum(1<<(8*(s-1)) for s in e[3]))",
         "elif op in ('IDLE_ONE','IDLE_ODD'):rows[r]=pscale(rows[r],q=e[4] if op=='IDLE_ODD' else 0,m=sum(1<<(8*(s-1)) for s in e[3]))"),
        ('math.ceil(math.log2(maxmass))', 'ceil_log2(maxmass)'),
    ]
    for old, new in changes:
        require(body.count(old) == 1, 'signed-model patch anchor')
        body = body.replace(old, new)
    m.ceil_log2 = ceil_log2
    exec(compile(body, str(path), 'exec'), m.__dict__)
    return m.caller


def endpoint(caller, C):
    with contextlib.redirect_stdout(io.StringIO()):
        report = caller(C)
    return {'bad_outputs': report['bad_outputs'], 'max_terms': report['max_terms']}


def generate_caller_facts(cf, raw, pkg, tmp):
    caller = tmp / '7113_CALLER.json'; caller.write_bytes(raw)
    lean = tmp / 'generated'; (lean / 'Nov15').mkdir(parents=True)
    cf.LEAN = str(lean)
    argv = sys.argv
    sys.argv = ['callerfacts.py', str(caller), '--name', '7113', '--bind7113']
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            cf.main()
    finally:
        sys.argv = argv
    for module in ('CertCaller7113Data', 'CertCaller7113Facts'):
        generated = (lean / 'Nov15' / (module + '.lean')).read_text().splitlines()
        pinned = (pkg / 'lean' / 'Nov15' / (module + '.lean')).read_text().splitlines()
        if module.endswith('Data'):
            generated, pinned = generated[1:], pinned[1:]
        require(generated == pinned, 'caller module mismatch: ' + module)


def physical_control(root, raw, tmp):
    native = tmp / 'physical'; short = native / 'short-caller'; short.mkdir(parents=True)
    for name in ('check_odd_physical_binding.py', 'upstream_application.py', 'DATA-PHASES.json'):
        shutil.copyfile(root / SHORT / name, short / name)
    for name in ('WORD.json.gz', 'RESULT.json'):
        shutil.copyfile(root / NATIVE / name, native / name)
    shutil.copyfile(root / P7113 / 'expected/ODD-TYPE-AB-REPLAY.json', short / 'ODD-TYPE-AB-REPLAY.json')
    (short / 'ODD-TYPE-AB-CALLER.json').write_bytes(raw)
    p = subprocess.run([sys.executable, '-I', '-B', str(short / 'check_odd_physical_binding.py')],
                       text=True, capture_output=True, timeout=180)
    require(p.returncode == 0, 'physical check failed: ' + p.stdout + p.stderr)
    receipt = (short / 'ODD-PHYSICAL-BINDING.json').read_bytes()
    require(receipt == (root / P7113 / 'expected/ODD-PHYSICAL-BINDING.json').read_bytes(),
            'physical receipt differs')
    obj = json.loads(receipt)
    require(obj['aliased_main_rejected'], 'physical alias not rejected')
    return {'receipt_byte_identical': True, 'aliased_main_rejected': True,
            'native_canonical_sha256': obj['native_sha256'],
            'native_contact_boundaries': obj['occurrence_and_geometry']['native_contact_boundaries'],
            'paid_positions': obj['occurrence_and_geometry']['paid_positions']}


def full_verify(pkg, coefficient, alias, tmp):
    # Run in an isolated package copy; the source checkout is never mutated.
    dst = tmp / 'certkit'; shutil.copytree(pkg, dst)
    caller = dst / 'data' / '7113_CALLER.json'
    original = caller.read_bytes()
    results = []
    for label, raw in [('original', original), ('coefficient', coefficient), ('alias', alias)]:
        caller.write_bytes(raw)
        p = subprocess.run([sys.executable, '-I', '-B', str(dst / 'verify.py')],
                           text=True, capture_output=True, timeout=180)
        if label == 'original':
            require(p.returncode == 0 and 'PASS_CERTKIT_PACKAGE' in p.stdout, 'original package check failed')
        else:
            require(p.returncode != 0 and 'FAIL: sha256 mismatch: data/7113_CALLER.json' in p.stdout,
                    label + ' manifest rejection missing')
        results.append({'case': label, 'returncode': p.returncode,
                        'pass': 'PASS_CERTKIT_PACKAGE' in p.stdout,
                        'manifest_mismatch': 'FAIL: sha256 mismatch: data/7113_CALLER.json' in p.stdout})
    return results


def main():
    require(__debug__, 'run Python without -O or PYTHONOPTIMIZE')
    ap = argparse.ArgumentParser()
    for n in ('7113', '7829', '7852'):
        ap.add_argument('--pr' + n, default=os.environ.get('P104_PR' + n),
                        help='root of exact #' + n + ' checkout (or P104_PR' + n + ')')
    ap.add_argument('--allow-exports', action='store_true', help='allow source exports without .git; still check file hashes')
    ap.add_argument('--full-verify', action='store_true', help='also run unmodified #7829 verify.py on original and both mutations')
    ap.add_argument('--report', type=Path, help='write the same JSON receipt to this path')
    ap.add_argument('--witness', type=Path, help='write canonical normalized witness bytes to this path')
    args = ap.parse_args()
    require(all(getattr(args, 'pr' + n) for n in HEADS), 'provide all three --pr checkout roots')
    roots = {n: Path(getattr(args, 'pr' + n)).resolve() for n in HEADS}
    verification = check_inputs(roots, args.allow_exports)
    pkg = roots['7829'] / P7829
    raw = (pkg / 'data/7113_CALLER.json').read_bytes()
    C = json.loads(raw)
    cf = import_file('callerfacts_pinned', pkg / 'tools/callerfacts.py')
    source, failures = normalize(C)
    require(not failures, 'original has an aliased HOST')
    require(len(C['events']) == 4783, 'wrong event count')
    packed = check_packed(C, source, cf)
    require(packed == {'event_slots': 4783, 'idle_masks_exact_after_shift': 94,
                       'unshifted_interpretations_rejected': 94, 'target_masks_exact': 72, 'j_stages': 17,
                       'j_a_all_four_distinct': 17, 'j_b_pair_distinct': 17},
            'unexpected structural totals')
    old = b'"events":[["B","ADD",37,36,"7"]'
    new = b'"events":[["B","ADD",37,36,"14"]'
    require(raw.count(old) == 1, 'coefficient mutation anchor')
    coefficient = raw.replace(old, new, 1)
    old = b'["J",1,[1,0,18,19],[36,37,"-1","1/2"]]'
    new = b'["J",1,[0,0,18,19],[36,37,"-1","1/2"]]'
    require(raw.count(old) == 1, 'contact mutation anchor')
    alias = raw.replace(old, new, 1)
    coeff_C, alias_C = json.loads(coefficient), json.loads(alias)
    coeff_w, coeff_bad = normalize(coeff_C)
    alias_w, alias_bad = normalize(alias_C)
    require(not coeff_bad and alias_bad == [[43, 'A', 0, 0]], 'wrong mutation structural control')
    require(cf.encode(C) == cf.encode(coeff_C) == cf.encode(alias_C), 'packed invariance failed')
    require(cf.invoice(C) == cf.invoice(coeff_C) == cf.invoice(alias_C), 'invoice invariance failed')
    require(len({sha(canonical(w)) for w in (source, coeff_w, alias_w)}) == 3, 'witness digest control')
    caller = signed_caller(roots['7113'])
    orig_ep, coeff_ep = endpoint(caller, C), endpoint(caller, coeff_C)
    require(orig_ep['bad_outputs'] == [] and coeff_ep['bad_outputs'] == [37], 'endpoint control')
    with tempfile.TemporaryDirectory(prefix='p104-binding-') as td:
        tmp = Path(td)
        generate_caller_facts(cf, raw, pkg, tmp)
        physical = physical_control(roots['7113'], raw, tmp)
        verify = full_verify(pkg, coefficient, alias, tmp) if args.full_verify else None
    result = {
        'schema': 'p104-caller-projection-and-structural-control/1',
        'expected_source_heads': HEADS, 'source_verification': verification, 'caller_sha256': sha(raw),
        'original': {'events': len(C['events']), 'ports': {t: len(C['types'][t]['ports']) for t in ('A', 'B')},
                     'endpoint': orig_ep, 'caller_fact_modules_match': True,
                     'well_formed_host_pairs': True, 'normalized_witness_sha256': sha(canonical(source)),
                     'expanded_events': {t: len(source['primitive'][t]) for t in ('A', 'B')},
                     'structural': packed},
        'coefficient_mutation': {'sha256': sha(coefficient), 'source_event': 0, 'from': '7', 'to': '14',
                                 'packed_and_invoice_unchanged': True, 'endpoint': coeff_ep,
                                 'normalized_witness_sha256': sha(canonical(coeff_w))},
        'contact_mutation': {'sha256': sha(alias), 'source_event': 43, 'from': 1, 'to': 0,
                             'packed_and_invoice_unchanged': True, 'host_pair_violations': alias_bad,
                             'normalized_witness_sha256': sha(canonical(alias_w))},
        'original_physical_and_alias_control': physical,
        'full_python_package_verify': verify,
    }
    text = json.dumps(result, sort_keys=True, indent=2) + '\n'
    if args.witness:
        args.witness.write_bytes(canonical(source))
    if args.report:
        args.report.write_text(text)
    print(text, end='')


if __name__ == '__main__':
    main()
