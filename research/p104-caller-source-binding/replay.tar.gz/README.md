# The #7113 caller: packed-price and structural controls

The #7829 packed caller record is an effective **pricing projection**: for the
pinned #7113 caller it reproduces the shipped target and paid histograms and
the number of calls. It is not a full encoding of the caller program. This
archive demonstrates two concrete source changes that leave that packed data
and its invoice unchanged, while separate endpoint or physical checks reject
the changed caller. It also constructs a reproducible, lossless Python-level
normalization of the original caller's events, target masks, ports, and J
expansions, and checks exact stage positions against the pricing projection.

This is a source-level structural check. It does **not** give a Lean theorem
about a `CallerWord.CWord`, prove the concrete caller's `CallerWord.Legal`,
reprove the t7669 crossing, or establish a new κ result. The raw SHA-256 check
and JSON-to-object conversion are outside Lean. Endpoint replay, physical
binding and pricing are separate checks with different scopes.

## Reproduce

Use Python 3.12 and three complete Git checkouts at these exact commits:

| Checkout | Commit | Primary source |
| --- | --- | --- |
| `PR7113` | `07a76c5e2738882c0cb322278e56f6cae3c9885d` | [#7113 signed caller](https://github.com/rohanarun/integer-mult-bounds/tree/07a76c5e2738882c0cb322278e56f6cae3c9885d/research/signed-caller-8x9) |
| `PR7829` | `1fdc9ecd1b1311d8ea6e02b6f81ae0d8d24999e2` | [#7829 CERTKIT](https://github.com/DreamingOfClouds/integer-mult-bounds/tree/1fdc9ecd1b1311d8ea6e02b6f81ae0d8d24999e2/research/p104-certkit-pricekit-to-lean) |
| `PR7852` | `41beda1d6435760dc99e38bd7e65f36798aad212` | [#7852 lower-bound toolkit](https://github.com/DreamingOfClouds/integer-mult-bounds/tree/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit) |

Set the variables to the **repository roots**, then run from this directory:

```sh
python3.12 -B check.py --pr7113 "$PR7113" --pr7829 "$PR7829" --pr7852 "$PR7852" \
  --full-verify --report actual.json --witness actual-normalized.json
cmp actual.json RECEIPT.json
cmp actual-normalized.json NORMALIZED.json
```

The `--prNNNN` arguments can instead be supplied as environment variables
`P104_PR7113`, `P104_PR7829`, and `P104_PR7852`. Each Git checkout is checked
for the specified HEAD, and each file consumed by this check is independently
SHA-256 checked against `SOURCE-PINS.json`. For extracted source trees without
`.git`, add `--allow-exports`; the file-hash checks still apply, but the command
cannot independently verify the checkout commit. The receipt records which
kind of source verification was performed; an export-based receipt therefore
differs from the checkout-based receipt even if its result fields agree.
A complete #7829 package is needed for `--full-verify`. Run without `-O` or
`PYTHONOPTIMIZE`, since upstream checks use assertions. The check writes only
to temporary copies and the explicit output paths; it does not edit the
checkouts. Without `--full-verify`,
the shorter run still executes the structural, endpoint, invoice-projection,
caller-generation and physical controls, but its `full_python_package_verify`
receipt field is `null` and it will not match the supplied full receipt.

`RECEIPT.json` is the observed deterministic full result. `NORMALIZED.json`
is the canonical JSON encoding of the derived Python witness; its digest is
in the receipt. It is provided for inspection, and can be regenerated using
`--witness`. `SOURCE-PINS.json` is human-readable; `check.py` independently
contains the expected pins. No individual timing or machine-specific paths
appear in the receipt. A local full run completed in about a minute under a
one-process, 4 GiB virtual-memory bound. Upstream verification can take longer
on another machine. A separate relocation test used hash-pinned exported
source files and environment-variable paths: its normalized witness and all
result fields matched the checkout run after accounting for the intentionally
different source-verification and optional-verifier fields. Changing the
exported `CallerWord.lean` then caused an immediate source-hash rejection.

## Exact stage and syntax result

The caller bytes have SHA-256
`255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc`.
They contain 4,783 ordered records, 72 global roles split into two sets of 36,
17 J records, 96 A ports and 8 B ports. The checker subtracts each type's role
offset, maps stage `s` in 1–17 to `s-1` in 0–16, records every source field,
and reverses that mapping. All 4,783 source event records round-trip exactly.
It expands J records into the ordered `jA` and `jB` primitives described by
[#7852 `CallerWord.lean`](https://github.com/DreamingOfClouds/integer-mult-bounds/blob/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit/lean/Nov15/CallerWord.lean).
This yields 1,008 A and 3,911 B primitive records, with no aliased HOST pair;
all four A role IDs and the two B role IDs are distinct for every J.

For each plain IDLE source set `S ⊂ {1,…,17}`, #7829's encoder places its
source stage `s` in bit `s`, while the normalized `Fin 17` index is `s-1`.
For all **94** actual IDLE records, the check compares the complete bit masks:

```text
packed evSt = Σ(s in S) 2^s = 2 * Σ(s in S) 2^(s-1)
```

Thus `evSt >> 1` equals the normalized set, not just its cardinality. Treating
`evSt` itself as zero-based fails on all 94 nonempty masks. All **72** target
row masks agree with their zero-based normalized indices directly, and the
17 J stage values normalize to exactly 0 through 16. This per-record and
per-bit structural test is stronger than a stage-aggregate count; it remains
an exact Python data check, not a checked parser or proof inside Lean. The
mask equality also follows algebraically for any distinct source stages in
1–17: the encoder's idle mask is `m = Σ 2^s`, each `2^s = 2*2^(s-1)`, and
`evSt(op + 16*type + 64*m) = m` because the opcode/type remainder is below 64.
The corresponding target-row mask is already stored at bit `s-1` above its
16-bit exponent field. The file hash selects the observed caller bytes; it
does not turn this algebra or the Python decoder into a Lean proof. A
verified Lean representation would still have to connect source bytes,
JSON parsing, role offsets, event records and these expansions to the Lean
`CWord`, and establish the separately required endpoint identity.

## Two one-field mutations

The encoded projection keeps opcode, type, idle-stage mask, per-type port
count, and diagonal exponent/mask. It does not carry event role IDs, ordinary
operation coefficients, J stage or contact fields, or the port lists. The
hash of the source file appears in generated comments and is independently
covered by the package manifest; neither comment nor hash supplies the
missing caller semantics to the packed `CData`.

| One-field change | Same packed data and invoice? | Separate rejection |
| --- | --- | --- |
| Event 0, B `ADD` coefficient `7 → 14` | Yes | The exact signed Laurent endpoint replay reports bad output `[37]`; the original has `[]`. |
| Event 43, first A J contact `1 → 0`, making the A list `[0,0,18,19]` | Yes | The normalized Python witness has aliased HOST pair `(0,0)`; #7113's physical checker rejects the same alias with `A owners`. |

Both changes also fail the **unmodified #7829 Python verifier** against the
unchanged source manifest (`sha256 mismatch: data/7113_CALLER.json`); the
original package passes that verifier. The verifier's source-hash failure and
the mathematical/physical rejection are different controls. In particular,
the unchanged packed invoice would not by itself reject either altered caller.

The signed Laurent replay imports #7113 `independent.py` and applies the exact
three source-to-source changes in `signed_model.py` for IDLE_ODD and the
integer ceiling-log bound. It compares all 72 output rows in exact Gaussian
rational arithmetic. It is not an independent implementation of that model.
The physical control runs the pinned #7113 checker in a temporary copy and
compares its receipt byte-for-byte with the pinned expected receipt. It covers
13,600 native contact boundaries and 110,638 paid positions for the **#7112**
native (canonical SHA-256 `3454c4900245ed1814ceeff79a741a45160eb3a93cf8d15f891fe2a67ba036fc`).
It is not a physical replay of the t7669 native. The physical receipt retains
its stated nested-chart and local-operator premises and calls for separate
full native and fixed-tape checks.

## Relationship to the existing crossing

For the original caller, #7829 `callerfacts.py` regenerates the pinned
`CertCaller7113Data` and `CertCaller7113Facts` modules (apart from the
path-bearing first comment). Its `CertCaller7113Link` substitutes the raw
packed caller invoice into the t7669 validity inequality. The upstream
`CertT7669.certified` source states native trace legality, rows, the word's
bracket and `Crossing .w7113 lo`. The historical bracket is
`[0.00372142604386, 0.00372142604387]` for that specific word and caller.
These statements concern the shipped model and pricing rules; this archive
does not run Lean or close the source-to-`CallerWord` bridge.

The optional full Python check also verifies #7829's file manifest, import
closure, two Python repricings and regeneration of its small numerical/link
modules. It does **not** regenerate the 340 large Lean modules or run a Lean
kernel build. Consult #7829's `verify.sh` for those additional steps.

## Attribution

The #7113 caller and checker are by Rohan Arun with substantial OpenAI Codex
assistance, building on the contributors named in that package's notices.
#7829 and #7852 are by DreamingOfClouds with Claude Opus 5.5 (Anthropic), via
Claude Code. The t7669 word is by SYLforge and builds on upstream work named
in #7829. The local normalization and two-mutation harness use those pinned
sources and preserve their separate scopes. See [NOTICE.md](NOTICE.md) and
the upstream package notices for credit. Apache-2.0; see [LICENSE](LICENSE).
