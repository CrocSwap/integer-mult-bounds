The check and normalized witness are local source-level work concerning the
following upstream constructions; they do not replace or endorse them.

* The #7113 17-stage signed caller is by Rohan Arun with substantial OpenAI
  Codex assistance and builds on the contributors credited in the #7113
  `research/signed-caller-8x9/README.md`, `NOTICE`, and upstream sources.
  `NORMALIZED.json` is a derived representation of that caller.
* The #7829 CERTKIT/PRICEKIT and #7852 lower-bound toolkit are by
  DreamingOfClouds with Claude Opus 5.5 (Anthropic), via Claude Code. Their
  notices credit the earlier P104 Lean library and other researchers.
* #7829's t7669 data is a replay of SYLforge's #7669 word, building on the
  K372-2 word and #7660 by Clear1nsight. This archive does not copy that word.

The check loads the named upstream files from user-supplied pinned checkouts;
it does not redistribute their Python or Lean source. Full source paths,
commit pins, and file hashes are in `SOURCE-PINS.json`. The Apache-2.0 license
is reproduced in `LICENSE`.
