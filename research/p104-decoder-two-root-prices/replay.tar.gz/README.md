# Two tight-root exchanges for the f = 22 loose decoder

Exactly two of the eight tight roots in the fixed E8 complement are replaced
by two of the eight inactive roots. Of the **784** exchanged complements,
**580 admit no decoder** in the specified family. Among the remaining 204,
the exact minimum price is **63 for 36 cases, 64 for 120, and 65 for 48**.
Every surviving case has an explicit full-Gram-modulo-four decoder; the 192
with determinant ±1 also have an exact full integer Gram witness. The other
12 have determinant ±3 and minimum 65; their witnesses are modulo four, so
this packet does not claim an integer Gram identity for those 12.

This extends the one-exchange analysis of [#7917](https://github.com/CrocSwap/integer-mult-bounds/pull/7917)
at `fa126cdae49f9e827f21d254cb68fd748fdcc864`. It uses the f=22 setup in
[#7902](https://github.com/CrocSwap/integer-mult-bounds/pull/7902) at
`354bd1471b8e6e31fc222ca622a178207b79133d`, and the source data from
[#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) at
`41beda1d6435760dc99e38bd7e65f36798aad212`. Source bytes and their upstream
license are pinned in `source/`; publication head pins are taken from the
campaign's publication ledger, not from an implied maintainer selection.
Round 4 stream 18 independently studied fractional row bases for the i3/i5
tight cubes and left the inherited 665-of-1,001 exclusion count unchanged;
it is contextual parent work, not an input to this two-exchange proof.

## Precise family and stopping roster

The original active tight indices are `[4,5,7,8,9,11,12,15]` and the
inactive indices are `[0,1,2,3,6,10,13,14]`. Replace any two original roots
by any two inactive roots. The 104 ports, 16 roots, Gram matrix `G` and
selected-cell matrix `Q` are as in the pinned data. Tight inputs are the
eight chosen roots; arbitrary tight output coefficients modulo four are
allowed. Add exactly one B-linear order-four input `x` whose parity is
`f = 22`, with actual loose output support `D` of homogeneous span dimension
three and efficiency `|D| >= 4`. There are no additional rows or exemptions.
Each row is charged `rank_F2 Q[D,S]` for its actual mod-four output and input
supports. All 256 lifts of `f`, all nonzero loose output values 1, 2 or 3,
and all selected-equation target signs are included. The loose input remains
order four when its chosen outputs are all 2.

| Classification | Count | Exact conclusion |
| --- | ---: | --- |
| Mod-2 rank 6 | 88 | At least 52 unrepresented ports; impossible |
| Mod-2 rank 7 | 492 | At least 52 unrepresented ports; impossible |
| Mod-2 rank 8, determinant ±1 | 192 | 36 cost 63, 120 cost 64, 36 cost 65 |
| Mod-2 rank 8, determinant ±3 | 12 | All cost 65, with full-Gram mod-four witnesses |

The 784 complements are explicit in `SCREEN.json` and `FIBERS.json`; all
204 prices, per-plane censuses and witness recipes are explicit in
`PRICE.json`. `SCREEN.json` records mod-2 uncovered ports. `FIBERS.json`
independently computes the exact target fibers modulo four. For the 580
excluded cases, their mod-four missing-port counts are 52 (336 cases), 60
(60), 71 (48), 76 (60), 80 (4), and 82 (72).

## Coverage argument

For each port `t`, the verifier derives the selected-Gram kernel modulo four
directly from the pinned data: it is `{0, 2 c_t}`. Thus a represented port
must be `+c_t` or `-c_t` modulo four; both signs have the same mod-2 image.
For every one of the 784 matrices `A`, `screen.py` generates the entire
mod-2 column image and counts ports outside it. Every noninvertible mod-2
case has at least 52 such ports. Their loose output coefficients must be
nonzero, but a homogeneous three-dimensional support contains at most four
ports and efficiency forces exactly four. The decoder cannot cover them.

As a separate check, `fibers.py` expresses all roots and ports in the original
unimodular E8 basis. It tries all 16 pairs of coefficients in the exchanged
coordinates; the other six coefficients are then uniquely determined. This
recomputes all 784 determinants, every `+c_t` and `-c_t` mod-four fiber,
kernel and image sizes, and the complete uncovered-port roster. Thus the
obstruction does not infer mod-four image sizes solely from mod-2 rank.

## Exact price argument for all 204 survivors

For a surviving `A`, invert it over `Z/4`. For each port set
`a_t = A^(-1)c_t`; for the loose input set `z = A^(-1)x`. The verifier
reconstructs all 17,958 four-port affine planes. Every f=22 lift has an
input support spanning the entire nine-dimensional homogeneous space, so
the loose row costs exactly three for each plane and lift.

For each of the eight tight rows, let `D0` be the nonzero support of its
coefficient in `a_t`. Its actual baseline rank is 7 or 8. The verifier
enumerates the binary column code of `Q[D0,S]`: across every survivor and
row its minimum nonzero weight is at least **11**. Consequently removal of
any four ports cannot reduce its rank. Outside the loose plane the actual
tight support equals `D0` even when the selected sign varies by port, so
those baseline ranks are unavoidable.

For a given port and tight row call it *bad* when its `Q[t,S]` lies outside
that baseline row space. A bad port has `a_t` equal to zero in that row.
If the same coordinate of `z` is odd, **any** nonzero loose output forces
the tight output to be nonzero there, for either selected sign and all three
allowed output coefficients. A bad port in the plane then adds one rank
unit in that row. The verifier counts the union of such forced bad rows for
every plane. The baseline plus this surcharge plus the loose cost is a lower
bound for every decoder in the family.

This bound is attained plane by plane: set the loose output to 2 on the four
ports and zero elsewhere, take the positive port targets, and correct the
tight output by `-2z`. In a row where `z` is even the correction vanishes
modulo four; in an odd row it adds exactly the bad-port surcharge. Each
entire tight input's `Q[:,S]` has rank 8, so no extra unit is possible.
Since `2 A^(-1)x = 2 A^(-1)f (mod 4)` for every lift, this construction
attains the same price for all 256 lifts. The checked exact minima partition
as follows:

| Tight baseline | Least tight surcharge | Loose | Exact price | Cases |
| ---: | ---: | ---: | ---: | ---: |
| 60 | 0 | 3 | 63 | 36 |
| 60 | 1 | 3 | 64 | 24 |
| 61 | 0 | 3 | 64 | 96 |
| 62 | 0 | 3 | 65 | 48 |

## Best witness and separate controls

Remove `[4,5]`, add `[0,1]`, and sort the active roots as
`[0,1,7,8,9,11,12,15]`. Its determinant is -1. Take loose support
`(0,22,32,89)`, loose root `f = (0,1,1,0,1,0,0,0)`, and loose output 2 at
each support port. With `A` the active root matrix, let `a_t=A^(-1)c_t` and
`z=A^(-1)f=(-1,-1,-2,0,1,2,2,1)`. Put the tight outputs at `a_t - 2z`
on the four ports and `a_t` elsewhere; input columns are
`V[s,i]=<c_s,z_i>` for the tight roots and `V[s,8]=<c_s,f>` for the loose
root. The replay verifies all **10,816 integer equalities** `W V^T = Gamma`.
The actual row prices are `[7,7,8,8,7,8,8,7,3]`, totaling **63**.
This example's tight baseline is already 60; the loose row costs three and
the best plane incurs zero additional tight surcharge.

For each surviving basis the main replay separately omits the tight
compensation and checks that selected equations fail; it also deletes an
active loose output from the corrected witness and checks failure. For the
example those controls fail 96 and 24 selected cells, respectively.
`controls.py` additionally verifies that the independent check rejects an
altered price and malformed plane, that a source-byte change is rejected,
and that an altered coverage roster fails the independent fiber check.

## Reproduction and boundaries

The packet uses only Python 3's standard library. Run from this directory:

```sh
sha256sum -c SHA256SUMS
python3 -B screen.py > /tmp/p104-screen-replayed.json
cmp SCREEN.json /tmp/p104-screen-replayed.json
python3 -B fibers.py > /tmp/p104-fibers-replayed.json
cmp FIBERS.json /tmp/p104-fibers-replayed.json
python3 -B price.py > /tmp/p104-price-replayed.json
cmp PRICE.json /tmp/p104-price-replayed.json
python3 -B crosscheck.py
python3 -B controls.py
```

`crosscheck.py` uses original-basis two-coordinate fibers and independently
enumerates planes from pair differences. It recomputes every per-plane price
census, 204 full-Gram mod-four witnesses, and all 192 integer-Gram witnesses.
The proof and its outcomes are finite and limited to the stated two-exchange,
one-loose-row family. Other complements, loose orbits or dimensions, extra
rows, order-two rows, exemptions, nonlinear decoders and the general decoder
wall remain outside this check. No new κ result is claimed.

The input data and original decoder research are by DreamingOfClouds with
Claude Opus 5.5; this finite screen and replay were developed with OpenAI
Codex assistance. See `source/LICENSE`.
