#!/usr/bin/env python3
"""Independent two-coordinate exact Z/4 fiber crosscheck for all 784 cases."""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from hashlib import sha256
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
assert sha256((ROOT/'source/e8base.json').read_bytes()).hexdigest()=='b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41'
E=json.loads((ROOT/'source/e8base.json').read_text());C,Z=E['C'][:104],E['C'][104:]
S=json.loads((ROOT/'SCREEN.json').read_text())
ORIGINAL=[4,5,7,8,9,11,12,15];INACTIVE=[0,1,2,3,6,10,13,14]
def inverse(a):
    n=len(a);r=[[Fraction(x) for x in a[i]]+[Fraction(i==j) for j in range(n)] for i in range(n)];det=1
    for j in range(n):
        k=next(i for i in range(j,n) if r[i][j])
        if k!=j:r[j],r[k]=r[k],r[j];det=-det
        z=r[j][j];det*=z;r[j]=[x/z for x in r[j]]
        for i in range(n):
            if i!=j:
                z=r[i][j];r[i]=[x-z*y for x,y in zip(r[i],r[j])]
    assert abs(det)==1 and all(x.denominator==1 for row in r for x in row)
    return int(det),[[int(x) for x in row[n:]] for row in r]
def mv(a,v):return [sum(x*y for x,y in zip(row,v)) for row in a]
B=[[Z[j][i] for j in ORIGINAL] for i in range(8)]
d0,bi=inverse(B)
assert all(mv(B,mv(bi,c))==c for c in C+Z)
T=[mv(bi,c) for c in C];U={j:mv(bi,Z[j]) for j in INACTIVE}
cases=[]
for ix,(removed,added) in enumerate((r,a) for r in combinations(ORIGINAL,2) for a in combinations(INACTIVE,2)):
    c=S['cases'][ix]
    assert c['removed']==list(removed) and c['added']==list(added)
    ii=[ORIGINAL.index(x) for x in removed]
    mat=[[U[added[j]][ii[i]] for j in range(2)] for i in range(2)]
    minor=mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0]
    replacement=[added[ii.index(j)] if j in ii else z for j,z in enumerate(ORIGINAL)]
    inversions=sum(replacement[i]>replacement[j] for i in range(8) for j in range(i+1,8))
    assert sorted(replacement)==c['active']
    assert d0*minor*((-1)**inversions)==c['determinant']
    pairs=[(a,b) for a in range(4) for b in range(4)]
    def projection(a,b,mod):
        return tuple((mat[i][0]*a+mat[i][1]*b)%mod for i in range(2))
    im2={projection(a,b,2) for a,b in pairs}
    missing2=[t for t,v in enumerate(T) if tuple(v[i]%2 for i in ii) not in im2]
    assert missing2==c['uncovered_mod_2']
    im4=Counter(projection(a,b,4) for a,b in pairs)
    k=im4[(0,0)]
    assert all(n==k for n in im4.values())
    plus=[im4.get(tuple(v[i]%4 for i in ii),0) for v in T]
    minus=[im4.get(tuple(-v[i]%4 for i in ii),0) for v in T]
    assert plus==minus
    missing=[t for t,n in enumerate(plus) if n==0]
    assert set(missing2)<=set(missing)
    assert (len(im2)*64).bit_length()-1==c['rank_mod_2']
    # Six retained coordinates can be selected freely, so each 2D kernel
    # element corresponds bijectively to an 8D kernel element.
    assert len(im4)*k==16
    assert len(im4)*(4**6)*k==4**8
    assert not missing or len(missing)>4
    assert bool(missing)==(c['status']=='EXCLUDED_MOD2_COVERAGE')
    cases.append({'removed':removed,'added':added,'active':c['active'],
        'determinant':c['determinant'],'projected_two_by_two':mat,
        'full_kernel_size_mod4':k,'full_image_size_mod4':len(im4)*4**6,
        'target_fiber_size_histogram':dict(sorted(Counter(plus).items())),
        'unrepresented_ports':missing,'unrepresented_count':len(missing)})

assert len(cases)==784
out={'status':'PASS','method':'Original unimodular E8 basis; independently enumerate 16 choices in the two exchanged coordinates.',
     'original_determinant':d0,'cases_checked':len(cases),
     'kernel_size_histogram':dict(sorted(Counter(c['full_kernel_size_mod4'] for c in cases).items())),
     'missing_count_histogram':dict(sorted(Counter(c['unrepresented_count'] for c in cases).items())),
     'cases':cases}
print(json.dumps(out,indent=2,sort_keys=True))
