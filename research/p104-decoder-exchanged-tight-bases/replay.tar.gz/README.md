# Exchanging one tight root in the f = 22 decoder

Among the 64 one-root exchanges specified below, 40 admit **no decoder** in
this family.  Each of the remaining 24 has exact minimum price **63**.  This
extends the calculation of [#7902](https://github.com/CrocSwap/integer-mult-bounds/pull/7902)
at head `354bd1471b8e6e31fc222ca622a178207b79133d` to 64 different tight
complements; the prices and obstructions are recomputed here from the pinned
source data.  In particular, 63 is not presumed for a changed basis.

## Exact family and result

Use the 104 port roots `C`, sixteen tight roots `Z`, Gram matrix `G`, and
binary matrix `Q` of [#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852),
at commit `41beda1d6435760dc99e38bd7e65f36798aad212`.  Start with the eight
active tight roots

```
[4, 5, 7, 8, 9, 11, 12, 15]
```

and replace exactly one by exactly one of
`[0, 1, 2, 3, 6, 10, 13, 14]`.  For each resulting ordered active set, allow
arbitrary tight output coefficients modulo four.  Include exactly one
B-linear order-4 loose input with `f = B^{-1} ybar = 22`, and require its
actual mod-4 output support `D` to have homogeneous port-span dimension three
and to be efficient (`|D| >= 4`).  There are no additional rows or free
exemptions.  Charge each row `rank_F2 Q[D,S]`, with `S` and `D` the actual
input and output supports modulo four.  Coefficients 1, 2, and 3 are all
allowed for a nonzero loose output.  The loose input has order four even when
all its chosen outputs are 2.

All 256 mod-4 lifts of `f` and all allowable output coefficients and
per-port selected signs are covered.  Each efficient 3-dimensional support
is one of 17,958 four-port affine planes.

| Type of exchange | Count | Actual result |
| --- | ---: | --- |
| `det A = 0` | 32 | No decoder: 52 port targets lack a tight-only mod-4 fiber |
| `det A = ±2` | 8 | No decoder: 52 port targets lack a tight-only mod-4 fiber |
| `det A = ±1` | 24 | Exact minimum 63, attained by an integer decoder |

Here `A` is the 8-by-8 integer matrix with the changed tight roots as columns,
in increasing tight-root index.  This is a finite family result.  It does not
resolve other complements, other loose-orbit choices, multiple loose rows,
order-2 rows, exemptions, nonlinear decoders, the complete decoder wall, or a
kappa bound.

The following table gives the exact integer determinant for each exchange.
Rows identify the removed original root and columns the added inactive root.

| Removed \\ added | 0 | 1 | 2 | 3 | 6 | 10 | 13 | 14 |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 4  | 1 | 0 | -1 | 0 | 2 | 0 | 0 | 1 |
| 5  | 0 | 1 | 0 | -1 | -1 | 0 | 0 | -2 |
| 7  | -2 | -1 | 0 | 0 | 1 | 1 | 0 | 0 |
| 8  | 1 | 0 | 1 | 0 | 0 | -2 | 1 | 0 |
| 9  | 0 | 0 | 1 | 2 | 0 | 0 | -1 | 1 |
| 11 | -1 | -2 | 0 | 0 | 0 | 0 | 1 | 1 |
| 12 | 0 | 1 | 0 | 1 | 0 | -1 | -2 | 0 |
| 15 | 0 | 0 | -2 | -1 | -1 | -1 | 0 | 0 |

## Why the nonunit cases are impossible

For each port `t`, the replay directly checks the actual selected Gram
equations.  Their kernel on `(Z/4)^8` is `{0, 2 c_t}`, so every represented
port vector must equal `+c_t` or `-c_t` modulo four.  This is established
from the selected equations themselves, without assuming the mod-4 covering
characterization.

For each changed `A`, the replay independently enumerates **all 65,536**
coefficient vectors in `(Z/4)^8`, records its actual kernel and image, and
counts the fibers of every `+c_t` and `-c_t`.  Every nonunit `A` has mod-2
rank seven, but the replay does not infer its mod-4 fibers from that rank:

* For each determinant-zero case, the exact image has 16,384 elements, the
  kernel has four elements, and the target-fiber sizes are zero for 52 ports
  and four for the other 52.
* For each determinant-`±2` case, the exact image has 32,768 elements, the
  kernel has two elements, and the target-fiber sizes are zero for 52 ports
  and two for the other 52.

Both target signs give the same fiber counts.  Every one of the 52 ports with
an empty fiber must use the loose row.  Its support contains exactly four
ports, so at least 48 of those targets remain impossible.  This argument
holds even if all four loose outputs could independently repair missing
targets; it does not assume they in fact can.

`RESULT.json` records the exact kernel vectors, all unrepresented port indices,
and the target-fiber histogram for every exchange.  As concrete checks, for
removing 4 and adding 1, the kernel in the sorted active coordinates
`[1,5,7,8,9,11,12,15]` is

```
00000000, 11100230, 22200020, 33300210
```

with digits read modulo four.  For removing 4 and adding 6, the kernel in
coordinates `[5,6,7,8,9,11,12,15]` is

```
00000000, 22200002.
```

## Exact price in every unit case

For a unit exchange, `A` has an integral inverse, and the bare tight decoder
uses `a_t = A^{-1}c_t`.  The replay computes its actual `Q[D,S]` ranks:
five rows cost seven, three rows cost eight, for **59**.  It enumerates the
nonzero column-code words for each tight row.  Their minimum distances are
five copies of 22, two copies of 11, and one of 24.  Removing any four ports
therefore cannot lower any tight-row price.  Outside the loose plane, each
port's tight coefficient is fixed up to sign by the selected equations, so
all nine-row decoders retain the 59-unit tight baseline.

Each of the 256 lifts of `f = 22` has input support with full homogeneous
span `F2^9`.  Consequently the loose row costs the dimension of the output
span, exactly **3**.  For a tight row whose baseline is seven, mark a port
**bad** if its `Q[t,S]` row lies outside that seven-space.  A bad port has
zero original tight coefficient.  In every one of the 24 exchanged bases,
all five seven-price rows have an odd coordinate in `A^{-1}f`.  Therefore
any nonzero loose coefficient at a bad port forces a nonzero tight
coefficient there, irrespective of the selected sign, actual lift of `f`,
or whether the loose coefficient is 1, 2, or 3.  That tight row then costs
eight.  All three baseline-eight rows retain price eight.

The replay computes the union of bad rows over every four-port plane for
each basis.  Each has the following independently checked census.  The last
column is the exact minimum for that plane, not merely a lower bound:

| Additional tight-row price | Planes per exchange | Total price |
| ---: | ---: | ---: |
| 1 | 3 | 63 |
| 2 | 130 | 64 |
| 3 | 1,861 | 65 |
| 4 | 6,541 | 66 |
| 5 | 9,423 | 67 |

To see attainment, take the loose coefficient **2** at the four plane ports
and zero elsewhere.  In a baseline-seven row an added outside-space vector
costs exactly one unit, and in a baseline-eight row no further unit is
possible.  For even coordinates of `A^{-1}f`, multiplication by 2 leaves the
original tight coefficients unchanged modulo four.  For odd coordinates it
forces exactly the bad-row surcharges.  Every lift `x = f + 2b` has the same
`2 A^{-1}x mod 4`, and each loose input support has full span nine, so the
same price is attainable for all 256 lifts.  The least plane surcharge is one,
giving `59 + 3 + 1 = 63` for every unit exchange.

## Explicit integer decoder and controls

For example, remove tight root 4 and add root 0, giving active indices
`[0,5,7,8,9,11,12,15]`.  Use plane `(0,22,32,89)` and the root-coordinate
loose lift

```
x = (0,1,1,0,1,0,0,0),
A^{-1}x = (-1,1,-1,0,1,0,1,1).
```

For each port, let `a_t = A^{-1}c_t` and let `u_t` be 2 on the four plane
ports and 0 otherwise.  Set

```
W[t,i] = a_t[i] - u_t * (A^{-1}x)[i]   for tight rows i = 0,...,7
W[t,8] = u_t
V[s,i] = <c_s, z_i>                     for tight rows
V[s,8] = <c_s, x>.
```

The replay checks all **10,816 integer equalities** `W V^T = Gamma` and the
selected equations separately.  The exact row prices are
`[7,7,8,8,7,8,8,7,3]`, and the output/input support sizes are
`[[52,52],[52,52],[74,52],[71,52],[52,52],[71,52],[54,52],[52,52],[4,62]]`.
The formula above and each case's indices and plane in `RESULT.json` specify
an exact 63-price integer witness for **every** unit exchange; the replay
checks all 24 full integer products.

As a negative control for every unit exchange, the bare tight basis costs 59,
but it has no active loose row.  Naively appending the four loose coefficients
without compensating the tight coefficients has a nominal price of 62 and
violates selected equations.  Separately, deleting one nonzero loose output
from the 63-price corrected witness while leaving the tight outputs intact
also violates the selected equations.  The failure counts are in
`RESULT.json`.

## Replay and provenance

Run:

```
python3 -B verify.py > result-replayed.json
cmp RESULT.json result-replayed.json
python3 -B crosscheck.py
```

The replay uses only the Python standard library and the three pinned files
under `source/`.  It verifies their SHA-256 hashes, exact selected-equation
kernels, mod-4 fibers, binary ranks and distances, all four-port planes by
two enumerations, all 256 loose lifts, 24 exact integer witnesses, and the
negative controls.  `RESULT.json` is the complete deterministic output;
`SHA256SUMS` pins the whole packet.  The separate `crosscheck.py` uses the
original E8-basis coordinates and tries the four replacement coefficients to
solve each target fiber, rather than repeating the packed `(Z/4)^8`
enumeration.  It also uses pair-difference plane enumeration, recomputes the
price census, and independently checks all 24 integer Gram witnesses.

The data and original decoder research are by DreamingOfClouds with Claude
Opus 5.5.  The fixed-complement f=22 calculation is #7902 at the head noted
above; this bounded exchange calculation, finite witnesses, and replay were
developed with OpenAI Codex assistance.  The upstream license is
`source/LICENSE`.
