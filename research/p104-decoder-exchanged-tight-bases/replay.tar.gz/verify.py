#!/usr/bin/env python3
"""Offline exact replay of all one-tight-root E8-complement exchanges.

Requires only the pinned e8base.json and labels.txt.  See README.md for the
scope, argument, the coefficient convention, and the meaning of the prices.
"""

import collections
from fractions import Fraction
import hashlib
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PINS = {
    "e8base.json": "b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41",
    "labels.txt": "8e6220f83b17ef0686dea27fc285ceb0f8f992a780287b12456792a5fb4aa4d5",
    "LICENSE": "c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4",
}
for name, digest in PINS.items():
    assert hashlib.sha256((ROOT / "source" / name).read_bytes()).hexdigest() == digest

E = json.loads((ROOT / "source/e8base.json").read_text())
C, Z, G = E["C"][:104], E["C"][104:], E["Gb"]
LAB = list(map(int, (ROOT / "source/labels.txt").read_text().split()))
assert len(C) == len(LAB) == 104 and len(Z) == 16
assert all(len(c) == 8 for c in C + Z)
assert all(G[i][j] == G[j][i] for i in range(8) for j in range(8))


def rank(vectors):
    """Rank of integer-encoded binary vectors."""
    pivots = {}
    for x in vectors:
        while x:
            i = x.bit_length() - 1
            if i in pivots:
                x ^= pivots[i]
            else:
                pivots[i] = x
                break
    return len(pivots)


def bits(v):
    return sum((int(x) & 1) << i for i, x in enumerate(v))


def ip(a, b):
    return sum(a[i] * G[i][j] * b[j] for i in range(8) for j in range(8))


def matvec(matrix, vector):
    return [sum(a * b for a, b in zip(row, vector)) for row in matrix]


def det_and_inverse(matrix):
    n = len(matrix)
    rows = [[Fraction(x) for x in matrix[i]] + [Fraction(i == j) for j in range(n)]
            for i in range(n)]
    determinant = 1
    for j in range(n):
        k = next((k for k in range(j, n) if rows[k][j]), None)
        if k is None:
            return 0, None
        if k != j:
            rows[j], rows[k] = rows[k], rows[j]
            determinant = -determinant
        scale = rows[j][j]
        determinant *= scale
        rows[j] = [x / scale for x in rows[j]]
        for k in range(n):
            if k != j:
                scale = rows[k][j]
                rows[k] = [a - scale * b for a, b in zip(rows[k], rows[j])]
    assert determinant.denominator == 1
    return int(determinant), [r[n:] for r in rows]


def pack(v):
    return sum((x % 4) << (2 * i) for i, x in enumerate(v))


def unpack(v):
    return [(v >> (2 * i)) & 3 for i in range(8)]


def add4(x, y):
    """Packed coordinate-wise addition in (Z/4)^8."""
    return (x ^ y) ^ ((x & y & 0x5555) << 1)


for a in range(4):
    for b in range(4):
        assert add4(pack([a] * 8), pack([b] * 8)) == pack([a + b] * 8)


# Reconstruct Q and its nondegenerate homogeneous bilinear form.
H = [1 | (bits(c) << 1) for c in C]
assert len(set(H)) == 104
assert rank([1] + [bits(G[i]) << 1 for i in range(8)]) == 9
Q = [sum(((a & b).bit_count() & 1) << s for s, b in enumerate(LAB)) for a in LAB]
assert all(((Q[t] >> s) & 1) == ((1 + ip(C[t], C[s])) & 1)
           for t in range(104) for s in range(104))
assert all(ip(C[t], C[s]) == (2 if t == s else 0)
           for t in range(104) for s in range(104) if (Q[t] >> s) & 1)

# Derive the mod-4 consequence from the selected equations, independent of
# the exchanged matrix.  The selected Gram-form kernel is {0, 2 C[t]}, so
# any represented vector must be +C[t] or -C[t] modulo 4.
FORMS = [[sum(G[i][j] * c[j] for j in range(8)) % 4 for i in range(8)] for c in C]
FORMS2 = [bits(v) for v in FORMS]
for t in range(104):
    selected = [s for s in range(104) if (Q[t] >> s) & 1]
    assert rank(FORMS2[s] for s in selected) == 7
    ct = [x & 1 for x in C[t]]
    assert bits(ct) and all((FORMS2[s] & bits(ct)).bit_count() % 2 == 0 for s in selected)
    kernel = set()
    for b in ([0] * 8, ct):
        values = [sum(FORMS[s][i] * b[i] for i in range(8)) % 4 for s in selected]
        assert all(v % 2 == 0 for v in values)
        for u in range(256):
            if all(((FORMS2[s] & u).bit_count() & 1) == values[j] // 2
                   for j, s in enumerate(selected)):
                kernel.add(tuple((b[i] + 2 * ((u >> i) & 1)) % 4 for i in range(8)))
    assert kernel == {(0,) * 8, tuple(2 * v for v in ct)}

# An efficient homogeneous dimension-3 port support is an affine four-point
# plane.  Enumerate it independently by triples and by pair differences.
HIX = {h: i for i, h in enumerate(H)}
planes = []
for a, b, c in itertools.combinations(range(104), 3):
    d = HIX.get(H[a] ^ H[b] ^ H[c])
    if d is not None and d > c:
        planes.append((a, b, c, d))
assert len(planes) == 17958 and all(rank(H[t] for t in p) == 3 for p in planes)
pairs = collections.defaultdict(list)
for a, b in itertools.combinations(range(104), 2):
    pairs[H[a] ^ H[b]].append((a, b))
pair_planes = set()
for bucket in pairs.values():
    for ab, cd in itertools.combinations(bucket, 2):
        plane = tuple(sorted(ab + cd))
        assert len(set(plane)) == 4
        pair_planes.add(plane)
assert pair_planes == set(planes)

# Every actual lift of f=22 has input homogeneous span 9.  Thus all the
# four-port planes cost rank(Q[D,S])=rank(H[D])=3 for every such lift.
F = 22
f = [(F >> i) & 1 for i in range(8)]
assert F not in {bits(z) for z in Z}
input_sizes = collections.Counter()
for b in range(256):
    x = tuple(f[i] + 2 * ((b >> i) & 1) for i in range(8))
    support = [s for s in range(104) if ip(C[s], x) % 4]
    assert rank(H[s] for s in support) == 9
    input_sizes[len(support)] += 1
assert dict(sorted(input_sizes.items())) == {62: 16, 76: 128, 78: 112}


def coefficient_code_distance(smask, ports):
    """Column-code minimum distance, including all nonzero codewords."""
    cols = []
    for s in range(104):
        if (smask >> s) & 1:
            col = sum(((Q[t] >> s) & 1) << j for j, t in enumerate(ports))
            if rank(cols + [col]) > len(cols):
                cols.append(col)
    weights = []
    for m in range(1, 1 << len(cols)):
        v = 0
        for j, col in enumerate(cols):
            if (m >> j) & 1:
                v ^= col
        weights.append(v.bit_count())
    return len(cols), min(weights)


original = [4, 5, 7, 8, 9, 11, 12, 15]
inactive = [j for j in range(16) if j not in original]
assert inactive == [0, 1, 2, 3, 6, 10, 13, 14]
cases = []
expected_histogram = {1: 3, 2: 130, 3: 1861, 4: 6541, 5: 9423}

for removed in original:
    for added in inactive:
        active = sorted((set(original) - {removed}) | {added})
        A = [[Z[j][i] for j in active] for i in range(8)]
        det, inverse = det_and_inverse(A)
        rank2 = rank(bits(row) for row in A)

        # Enumerate ALL 4^8 coefficient vectors, not merely the mod-2 rank.
        # Retain multiplicities and the exact kernel, then examine each real
        # +C[t] and -C[t] fiber of the exchanged tight matrix.
        states = [(0, 0)]
        for i, j in enumerate(active):
            v = pack(Z[j])
            twice = add4(v, v)
            shifts = (0, v, twice, add4(v, twice))
            states = [(add4(y, shift), code | (digit << (2 * i)))
                      for y, code in states for digit, shift in enumerate(shifts)]
        assert len(states) == 65536
        counts = collections.Counter(y for y, _ in states)
        kernel = sorted(unpack(code) for y, code in states if y == 0)
        kernel_size = len(kernel)
        assert len(counts) * kernel_size == 65536
        assert all(n == kernel_size for n in counts.values())
        assert all(pack(matvec(A, v)) == 0 for v in kernel)
        target_counts = [counts[pack(c)] for c in C]
        neg_counts = [counts[pack([-x for x in c])] for c in C]
        assert target_counts == neg_counts
        missing = [t for t, n in enumerate(target_counts) if n == 0]
        assert all(n in (0, kernel_size) for n in target_counts)

        case = {
            "removed": removed,
            "added": added,
            "active": active,
            "determinant": det,
            "rank_mod_2": rank2,
            "image_size_mod_4": len(counts),
            "kernel_coefficients_mod_4": kernel,
            "target_fiber_size_histogram": dict(sorted(collections.Counter(target_counts).items())),
            "unrepresented_port_count": len(missing),
            "unrepresented_ports": missing,
        }
        if abs(det) != 1:
            assert rank2 == 7 and det in (-2, 0, 2)
            assert kernel_size == (2 if abs(det) == 2 else 4)
            assert len(missing) == 52
            # At most four loose outputs can be nonzero; all 52 missing
            # targets require one, even after allowing either selected sign.
            case["status"] = "OBSTRUCTED"
            cases.append(case)
            continue

        assert rank2 == 8 and kernel_size == 1 and not missing
        assert all(x.denominator == 1 for row in inverse for x in row)
        inverse = [[int(x) for x in row] for row in inverse]
        assert all(sum(A[i][k] * inverse[k][j] for k in range(8)) == int(i == j)
                   for i in range(8) for j in range(8))
        coeff = [matvec(inverse, c) for c in C]
        assert all(matvec(A, a) == c for a, c in zip(coeff, C))
        fcoords = matvec(inverse, f)
        smasks = [sum(1 << s for s in range(104) if ip(C[s], Z[j]) % 4) for j in active]
        d0 = [[t for t in range(104) if coeff[t][i] % 4] for i in range(8)]
        base_prices, distances = [], []
        bad = [0] * 104
        for i in range(8):
            vectors = [Q[t] & smasks[i] for t in d0[i]]
            r = rank(vectors)
            dim, distance = coefficient_code_distance(smasks[i], d0[i])
            assert dim == r and distance > 4
            assert r in (7, 8) and rank(Q[t] & smasks[i] for t in range(104)) == 8
            base_prices.append(r)
            distances.append(distance)
            for t in range(104):
                if rank(vectors + [Q[t] & smasks[i]]) > r:
                    assert coeff[t][i] % 4 == 0
                    bad[t] |= 1 << i
        assert sorted(base_prices) == [7, 7, 7, 7, 7, 8, 8, 8]
        assert sorted(distances) == [11, 11, 22, 22, 22, 22, 22, 24]
        assert sum(base_prices) == 59
        assert all((fcoords[i] & 1) for i in range(8) if base_prices[i] == 7)
        fmask = bits(fcoords)
        # Multiplication by 2 makes the tight output correction identical
        # modulo 4 for every actual lift x = f + 2b.
        for b in range(256):
            x = [f[i] + 2 * ((b >> i) & 1) for i in range(8)]
            lc = matvec(inverse, x)
            assert all((2 * lc[i] - 2 * fcoords[i]) % 4 == 0 for i in range(8))
        histogram = collections.Counter()
        optimal = []
        for plane in planes:
            union = 0
            for t in plane:
                union |= bad[t]
            surcharge = (union & fmask).bit_count()
            histogram[surcharge] += 1
            if surcharge == 1:
                optimal.append(plane)
        assert dict(sorted(histogram.items())) == expected_histogram
        assert len(optimal) == 3

        # Exact integer witness: x=f, loose coefficient 2 on a minimum plane.
        # C[t] = A*coeff[t] and x = A*fcoords as integer equalities, so the
        # following W reconstructs the entire Gram matrix, not just Q-cells.
        plane = optimal[0]
        assert matvec(A, fcoords) == f
        X = [Z[j] for j in active] + [f]
        V = [[ip(c, x) for x in X] for c in C]
        W = [[coeff[t][i] - (2 if t in plane else 0) * fcoords[i] for i in range(8)]
             + [2 if t in plane else 0] for t in range(104)]
        assert all(sum(W[t][k] * V[s][k] for k in range(9)) == ip(C[t], C[s])
                   for t in range(104) for s in range(104))
        assert all(sum(W[t][k] * V[s][k] for k in range(9)) == (2 if t == s else 0)
                   for t in range(104) for s in range(104) if (Q[t] >> s) & 1)
        row_prices, support_sizes = [], []
        for k in range(9):
            d = [t for t in range(104) if W[t][k] % 4]
            smask = sum(1 << s for s in range(104) if V[s][k] % 4)
            row_prices.append(rank(Q[t] & smask for t in d))
            support_sizes.append([len(d), smask.bit_count()])
        union = 0
        for t in plane:
            union |= bad[t]
        assert row_prices[:8] == [base_prices[i] + ((union & fmask) >> i & 1) for i in range(8)]
        assert row_prices[8] == 3 and sum(row_prices) == 63

        # The bare eight-root integer decoder costs 59, but adding the loose
        # coefficient 2 without correcting its tight outputs only appears to
        # cost 62: it violates the actual selected decoder equations.
        V0 = [row[:8] for row in V]
        assert all(sum(coeff[t][k] * V0[s][k] for k in range(8)) == ip(C[t], C[s])
                   for t in range(104) for s in range(104))
        WN = [coeff[t] + [2 if t in plane else 0] for t in range(104)]
        naive_prices = []
        for k in range(9):
            d = [t for t in range(104) if WN[t][k] % 4]
            smask = sum(1 << s for s in range(104) if V[s][k] % 4)
            naive_prices.append(rank(Q[t] & smask for t in d))
        assert naive_prices == base_prices + [3] and sum(naive_prices) == 62
        naive_errors = sum(1 for t in range(104) for s in range(104) if (Q[t] >> s) & 1
                           and sum(WN[t][k] * V[s][k] for k in range(9)) % 4 != (2 if t == s else 0))
        assert naive_errors > 0

        # Leave the tight correction in place but remove a loose output.
        # The selected equations must fail, ensuring it is an active row.
        WM = [row[:] for row in W]
        WM[plane[0]][8] = 0
        mutations = sum(1 for t in range(104) for s in range(104) if (Q[t] >> s) & 1
                        and sum(WM[t][k] * V[s][k] for k in range(9)) % 4 != (2 if t == s else 0))
        assert mutations > 0
        case.update({
            "status": "EXACT_MINIMUM_63",
            "basis_f_coordinates": fcoords,
            "basis_output_support_sizes": [len(d) for d in d0],
            "basis_tight_prices": base_prices,
            "basis_column_code_distances": distances,
            "plane_surcharge_histogram": dict(sorted(histogram.items())),
            "optimal_planes": optimal,
            "explicit_witness_plane": plane,
            "explicit_witness_loose_root_coordinates": f,
            "explicit_witness_loose_output_coefficient": 2,
            "explicit_witness_row_prices": row_prices,
            "explicit_witness_D_S_sizes": support_sizes,
            "integer_gram_identity_cells_checked": 104 * 104,
            "basis_only_price": sum(base_prices),
            "naive_uncorrected_price": sum(naive_prices),
            "naive_uncorrected_bad_selected_cells": naive_errors,
            "mutated_witness_bad_selected_cells": mutations,
        })
        cases.append(case)

assert len(cases) == 64
assert collections.Counter(c["status"] for c in cases) == {"EXACT_MINIMUM_63": 24, "OBSTRUCTED": 40}
assert collections.Counter(abs(c["determinant"]) for c in cases) == {0: 32, 1: 24, 2: 8}
assert collections.Counter(c["image_size_mod_4"] for c in cases) == {16384: 32, 32768: 8, 65536: 24}

result = {
    "status": "PASS",
    "scope": "replace exactly one root in [4,5,7,8,9,11,12,15] by one inactive tight root; one efficient f=22 loose row, port-span dimension 3, no other rows or exemptions",
    "original_active_roots": original,
    "original_inactive_roots": inactive,
    "exchanges": len(cases),
    "selected_equation_kernels_verified": 104,
    "loose_input_support_size_histogram": dict(sorted(input_sizes.items())),
    "efficient_planes_checked_per_unit_exchange": len(planes),
    "determinant_absolute_histogram": {"0": 32, "1": 24, "2": 8},
    "nonunit_cases_obstructed": 40,
    "nonunit_unrepresented_ports_each": 52,
    "unit_cases_exact_minimum_63": 24,
    "unit_tight_basis_price_each": 59,
    "unit_loose_row_price_each": 3,
    "unit_minimum_tight_surcharge_each": 1,
    "unit_plane_surcharge_histogram_each": expected_histogram,
    "cases": cases,
}
print(json.dumps(result, indent=2, sort_keys=True))
