#!/usr/bin/env python3
"""Independent exchange/fiber, plane-census and witness cross-check.

Solves each replacement in coordinates of the original unimodular basis,
using four possible replacement coefficients.  This does not import the
packed-vector enumeration in verify.py or rely on its calculated fibers.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path

P = Path(__file__).resolve().parent
E = json.loads((P / "source/e8base.json").read_text())
C, Z, G = E["C"][:104], E["C"][104:], E["Gb"]
L = [int(x) for x in (P / "source/labels.txt").read_text().split()]
RESULT = json.loads((P / "RESULT.json").read_text())
ORIGINAL = RESULT["original_active_roots"]
F = [0, 1, 1, 0, 1, 0, 0, 0]


def inverse(a):
    rows = [[Fraction(x) for x in row] + [Fraction(i == j) for j in range(8)]
            for i, row in enumerate(a)]
    for j in range(8):
        p = next(i for i in range(j, 8) if rows[i][j])
        rows[j], rows[p] = rows[p], rows[j]
        x = rows[j][j]
        rows[j] = [y / x for y in rows[j]]
        for i in range(8):
            if i != j:
                x = rows[i][j]
                rows[i] = [u - x * v for u, v in zip(rows[i], rows[j])]
    inv = [row[8:] for row in rows]
    assert all(x.denominator == 1 for row in inv for x in row)
    return [[int(x) for x in row] for row in inv]


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def mv(a, v):
    return [dot(row, v) for row in a]


def ip(a, b):
    return dot(a, mv(G, b))


def binary_basis(words):
    basis = {}
    for word in words:
        while word:
            p = word.bit_length() - 1
            if p not in basis:
                basis[p] = word
                break
            word ^= basis[p]
    return basis


def in_basis(word, basis):
    while word:
        p = word.bit_length() - 1
        if p not in basis:
            return False
        word ^= basis[p]
    return True


def homogeneous(c):
    return 1 | sum((x & 1) << (i + 1) for i, x in enumerate(c))


A0 = [[Z[j][i] for j in ORIGINAL] for i in range(8)]
AI = inverse(A0)
assert all(mv(A0, mv(AI, c)) == c for c in C)
Q = [sum(((a & b).bit_count() & 1) << i for i, b in enumerate(L)) for a in L]
H = [homogeneous(c) for c in C]
pair_buckets = defaultdict(list)
for a, b in combinations(range(104), 2):
    pair_buckets[H[a] ^ H[b]].append((a, b))
paired_planes = []
for bucket in pair_buckets.values():
    for ab, cd in combinations(bucket, 2):
        q = tuple(sorted(ab + cd))
        assert len(set(q)) == 4
        paired_planes.append(q)
assert len(paired_planes) == 3 * 17958
plane_counts = Counter(paired_planes)
assert len(plane_counts) == 17958 and all(n == 3 for n in plane_counts.values())

cases = RESULT["cases"]
assert len(cases) == 64
for case in cases:
    active, removed, added = case["active"], case["removed"], case["added"]
    old_coordinate = ORIGINAL.index(removed)
    new_coordinate = active.index(added)
    change_column = mv(AI, Z[added])

    def fibers(target):
        target_in_old_basis = mv(AI, target)
        found = []
        for alpha_new in range(4):
            if (change_column[old_coordinate] * alpha_new - target_in_old_basis[old_coordinate]) % 4:
                continue
            alpha = []
            for j in active:
                if j == added:
                    alpha.append(alpha_new)
                else:
                    k = ORIGINAL.index(j)
                    alpha.append((target_in_old_basis[k] - change_column[k] * alpha_new) % 4)
            assert all((sum(Z[j][i] * alpha[k] for k, j in enumerate(active)) - target[i]) % 4 == 0
                       for i in range(8))
            found.append(alpha)
        return sorted(found)

    assert fibers([0] * 8) == case["kernel_coefficients_mod_4"]
    plus = [len(fibers(c)) for c in C]
    minus = [len(fibers([-x for x in c])) for c in C]
    assert plus == minus
    assert [t for t, n in enumerate(plus) if n == 0] == case["unrepresented_ports"]
    assert {str(k): v for k, v in sorted(Counter(plus).items())} == case["target_fiber_size_histogram"]
    if case["status"] == "OBSTRUCTED":
        assert len([n for n in plus if n == 0]) == 52
        continue

    assert case["status"] == "EXACT_MINIMUM_63"
    A = [[Z[j][i] for j in active] for i in range(8)]
    AINV = inverse(A)
    coeff = [mv(AINV, c) for c in C]
    fc = mv(AINV, F)
    assert fc == case["basis_f_coordinates"]
    smasks = [sum((ip(c, Z[j]) % 4 != 0) << i for i, c in enumerate(C)) for j in active]
    bad = [0] * 104
    for i in range(8):
        d0 = [t for t in range(104) if coeff[t][i] % 4]
        basis = binary_basis(Q[t] & smasks[i] for t in d0)
        assert len(basis) == case["basis_tight_prices"][i]
        for t in range(104):
            if not in_basis(Q[t] & smasks[i], basis):
                assert coeff[t][i] % 4 == 0 and (fc[i] & 1)
                bad[t] |= 1 << i
        columns = [sum(((Q[t] >> s) & 1) << k for k, t in enumerate(d0))
                   for s in range(104) if (smasks[i] >> s) & 1]
        spanning = list(binary_basis(columns).values())
        code = [0]
        for col in spanning:
            code += [word ^ col for word in code]
        assert min(word.bit_count() for word in code if word) == case["basis_column_code_distances"][i]

    counts = Counter()
    for plane in paired_planes:
        union = 0
        for t in plane:
            union |= bad[t]
        counts[union.bit_count()] += 1
    assert all(v % 3 == 0 for v in counts.values())
    counts = {str(k): v // 3 for k, v in sorted(counts.items())}
    assert counts == case["plane_surcharge_histogram"]

    plane = set(case["explicit_witness_plane"])
    assert len(plane) == 4 and tuple(sorted(plane)) in plane_counts
    W = [[coeff[t][i] - 2 * (t in plane) * fc[i] for i in range(8)] + [2 * (t in plane)]
         for t in range(104)]
    V = [[ip(c, Z[j]) for j in active] + [ip(c, F)] for c in C]
    assert all(dot(W[t], V[s]) == ip(C[t], C[s]) for t in range(104) for s in range(104))
    row_prices, support_sizes = [], []
    for i in range(9):
        ports = [t for t in range(104) if W[t][i] % 4]
        support = sum((V[s][i] % 4 != 0) << s for s in range(104))
        row_prices.append(len(binary_basis(Q[t] & support for t in ports)))
        support_sizes.append([len(ports), support.bit_count()])
    assert row_prices == case["explicit_witness_row_prices"] and sum(row_prices) == 63
    assert support_sizes == case["explicit_witness_D_S_sizes"]

print("PASS: 64 independent four-choice fibers; 24 pair-censuses and integer witnesses")
