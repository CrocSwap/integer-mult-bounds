# One native helper hosted at the next BIT local

This screen tests stage 1 of the pinned #7830 binary caller. Helper 664 in the first native visit can be used to carry one body-coordinate exchange of the second destination while its original, independent dirty owner is parked. That partial operation is **not** the second `LOCAL`: it leaves the second source unexchanged and omits the shear. Two complete two-native controls restore the proper interfaces and execute the complete second native word. Their signed change is exactly **−2** at every trial exponent. Neither control improves κ.

The checked family is one port, one native 0→1 helper, and explicit boundary adapters. The one-port rank obstruction below covers address-independent binary boundary mixes on these five fields, even allowing additional clean temporary fields. It does not cover using other native ports or helper targets, changing the interior of the native word, or adding address-transforming paid adapters.

## Pinned ports and four endpoint blocks

The caller has simultaneous stage-1 events `LOCAL 1,1,0` at clock 4 and `LOCAL 1,20,19` at clock 5, with 111 ports apiece. The newer #7830 native is the 680-public, 3,554-private word in `inputs/WORD.json.gz`; helper 664 is one of its eight grade-one helper endpoints. It is a *public helper of the native word*, with an independent caller-level owner; it is not one of the native private storage labels. It starts at chart 0 and ends at chart 8, the line `e6`.

At port 0 the main source begins at chart 2 (head line `e0`) and ends at chart 1 (full space); the main destination begins at chart 0 and ends at chart 525 (the complement of `e0`). Chart 8 lies in chart 525. Write `Q` for the head interchange, `D` for the full seven-axis stage-body interchange, and `L` for the `e6` interchange. With input pairs `(a,b)` and `(c,d)`, the required pair of contacts is

```
(a,b) -> (D a, D b + D Q a)
(c,d) -> (D c, D d + D Q c).
```

The four 2-by-2 blocks from the two input pairs to the two output pairs must consequently be

```
first <- first   [[D, 0], [D Q, D]]     first <- second  0
second <- first  0                      second <- second [[D, 0], [D Q, D]].
```

At the first entrance, swap the second destination `d` with helper input `h`; both are in chart 0. Run the complete first native word. Its original all-column endpoint means that `d` leaves via helper 664 at chart 8 as `L d`, while `h` is still independently parked at chart 0. The first native main pair is unchanged. The four blocks of this partial operation are

```
first <- first   [[D, 0], [D Q, D]]     first <- second  0
second <- first  0                      second <- second [[I, 0], [0, L]].
```

Thus this is a body-coordinate action on one second-pair field, not a completed shear. In particular the actual second endpoint charts are `(2,8)`, whereas a completed `LOCAL` requires `(1,525)`. The original grade-one target of owner `h` has been surrendered when `h` is returned at chart 0. Restoring `h` to chart 8 with a fresh owned register, one 0→8 MOVE, and dirty retirement preserves the target at a cost of one real `H1` paid job. The executable checks the partial tape in both orientations on all 682² scalar coefficients, including the independent input and return of `h`.

## Complete two-native controls and price

To run the original second native intact, reset the hosted second destination from chart 8 to 0 by one owned 8→0 MOVE, restore the two bank labels, and then run the entire second word. Two literal variants are emitted:

| First helper's return | Extra paid jobs | Surrendered productive target | Signed change |
| --- | ---: | ---: | ---: |
| Park and return owner at chart 0 | `H1` | `H1` | `−2` |
| Restore owner to original chart 8 | `2 H1` | none | `−2` |

Here `H1 = 1` in the tariff `H_r = r^(1−κ)`. In both variants all **916 distinct helper owners** of the two native words are returned independently. The first variant retains 915 of their original productive targets; the second retains all 916. Both execute two complete native words. The second word's bill remains 2,874 paid jobs, with grades `{1:1376, 2:1281, 3:54, 4:44, 5:17, 6:102}`, and 458 independent targets, with grades `{1:8, 2:9, 4:43, 5:8, 6:1, 8:389}`. No fraction of a call is credited.

Each archived paired tape is reloaded, compared to the word regenerated from the pinned source, and checked on all 1,849,600 scalar matrix coefficients in both orientations, all tag contacts and MOVE nesting, and all dirty private retirements. Its main endpoint is the original pair of `LOCAL`s, including the Q-dependent cross terms, so the unchanged exact caller polynomial proof applies. This physical lift uses the inherited source frame/interface theorem; it is not a separate proof of the full compiler or outer multiplier. The pinned caller independently passes all 38² coefficients in each orientation. Replacing clock 5 by the partial hosted action fails the full caller at output roles 19 and 20, both forwards and in the adjoint. That algebraic mutation is a negative control, not a physical complete caller.

The full 36-call source invoice has 107,460 paid positions and 20,706 productive positions. With ranks as keys, its exact histograms are

```
paid = {1:49980, 2:46116, 3:1944, 4:1584, 5:612, 6:3672,
        7:444, 14:444, 21:444, 28:444, 35:444, 42:444,
        49:444, 56:444}
targets = {1:288, 2:324, 4:1548, 5:288, 6:36, 8:14448,
           15:444, 22:444, 29:444, 36:444, 43:444, 50:444,
           57:444, 64:444, 127:222}.
```

The parked control changes `(paid[1], targets[1])` to `(49981,287)`; the restored control changes it to `(49982,288)`. Every other rank is unchanged. Each complete signed-histogram difference is therefore `{1:−2}`. Both complete histograms are retained in `RESULT.json` and reconstructed from all 36 actual caller occurrences.

At κ = `0.003879929046155`, the full original signed moment is enclosed by

```
[-0.000385127316613866441054139473,
 -0.000385127316613866441054139472].
```

Either complete paired control gives exactly that interval minus 2. At the reference `0.003879928046155`, the original is enclosed by `[-0.000000000381874566916336446611, -0.000000000381874566916336446610]`; the changed controls again subtract 2. These prices use the complete 36-call caller inventory and the source's directed arithmetic. No finite-product or outer-multiplier improvement follows.

The added operators use only XOR, whole-field swaps, the existing integral chart 8, and the original nested 0/8 MOVE, so they introduce no new rational frame or coefficient. The source's conservative raw accounting, treating the paired construction as one merged 1,360-public-field scan and granting no route savings, gives `935,131,494,288 < 10^12` records and `6,999,905 < 10^7` owned backing. This is a check in the retained source accounting model, not an independent new all-width compiler, precision-transfer, or multiplier theorem.

## Scoped capacity obstruction

The exact rational projectors give an explicit two-address orbit with difference vectors `±e6`. All arguments here use the physical view matrices of the pinned chart frames, and the data values at the two addresses are independently variable. The head `Q` fixes both points; the stage body `D` and helper `L` swap them. Call that swap `t`. On this orbit the field matrix of one unchanged first contact, two bypass fields, and the one helper has coefficient of `t` of rank 3: two channels from the first contact and one from the helper. The desired first four output rows of two complete contacts have coefficient of `t` of rank 4, specifically `diag(J,J)` with `J=[[1,0],[1,1]]`.

Write the untouched first-call field operator as `S0 + t S1`. Its `S1` has rank 3. Arbitrary address-independent binary entry and exit matrices `B` and `A` give `A S0 B + t A S1 B`, whose `t` coefficient has rank at most 3. This remains true with extra clean storage and discarded intermediates. The condition already fails on the four main outputs, regardless of the final owner row. It rules out synthesizing both complete contacts from this single first port and helper by that specified boundary-mixing class. It does not rule out a different full native implementation or combining the other independently required native channels.

## Reproduce

All files needed for the bounded standard-library replay are local. The source and verifier inputs are hash checked. Run on one CPU, for example:

```sh
sha256sum -c SHA256SUMS
python3 -I -B replay.py > /tmp/hosted-local-result.json
cmp RESULT.json /tmp/hosted-local-result.json
```

The two `PAIRED-*.json.gz` files are literal words. The replay checks their decompressed canonical bytes against the word regenerated from source before validating them. Their canonical SHA-256 digests are recorded in `RESULT.json`; `--emit-paired` regenerates the two archives if desired; their compressed container bytes may differ across Python or zlib versions even when their canonical digests agree. The [clean-copy receipt](CLEAN-COPY.md) records a one-CPU run using about five user CPU seconds and less than 100 MB RSS. Controls check that omitting the initial swap changes public output coefficients, omitting owner restoration gives the wrong endpoint, omitting the hosted-destination reset violates an ADD chart, and omitting the added dirty retirement attempts to activate a live field.

## Source and credit

The comparator is [PR #7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The caller gzip is `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`; the native word's canonical digest is `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. `SOURCES.json` records the immutable upstream input and verifier provenance; `NOTICE` preserves the original lineage. This local screen and adapters were prepared with OpenAI Codex assistance. No independent human review is claimed.
