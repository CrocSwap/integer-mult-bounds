# Clean-copy replay receipt

A fresh copy of this package was checked without any files from its parent
stream, using Python 3.12.3 and an empty environment apart from
`PATH=/usr/bin:/bin`. The process was restricted to one CPU. It checked
`SHA256SUMS`, ran the default offline replay against both supplied literal
archives, compared its stdout byte for byte with `RESULT.json`, and checked
`SHA256SUMS` again.

The two equal JSON streams have SHA-256
`0026af920e9d94ce621fdc55e5aec7e330b3af40d83dad9ac6a90bd7cf41e233`.
The measured run used 4.17 s wall, 4.07 s user CPU and 99,652 KiB peak RSS.
The receipt is evidence of this one run, not a performance guarantee or an
independent mathematical proof.
