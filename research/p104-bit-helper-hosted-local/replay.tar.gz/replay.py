#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""One-port, one-rank-one-helper reuse screen for the #7830 paired BIT caller.

The script checks a partial adapter and two complete paired-stage controls.
It does not claim a gain or a changed complete multiplier. Source pins and scope
are recorded in README.md.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip, json, sys

H = Path(__file__).resolve().parent
sys.path.insert(0, str(H / 'vendor'))
import binary_operator as op
import price

PINS = {
    'inputs/WORD.json.gz': 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
    'inputs/EFREE-CALLER.json.gz': '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
    'inputs/BIT.json': '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
    'vendor/binary_operator.py': '36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349',
    'vendor/literal.py': '4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
    'vendor/price.py': 'd720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b',
}
def need(ok, msg):
    if not ok: raise ValueError(msg)
def load(name):
    b=(H/name).read_bytes()
    need(sha256(b).hexdigest()==PINS[name], 'pin '+name)
    return json.loads(gzip.decompress(b) if name.endswith('.gz') else b)
for name, digest in PINS.items():
    need(sha256((H/name).read_bytes()).hexdigest()==digest, 'pin '+name)
w=load('inputs/WORD.json.gz'); caller=load('inputs/EFREE-CALLER.json.gz'); receipt=load('inputs/BIT.json')
need(op.canonical_hash(w)==op.WORD, 'canonical newer word')
need(caller['events'][:6]==[['ADD',0,1],['SWAP',0,1],['ADD',19,20],['SWAP',19,20],['LOCAL',1,1,0],['LOCAL',1,20,19]], 'two exact stage-1 clocks')
need((w['public'],w['owned_fields'])==(680,3554),'native dimensions')
need((w['start'][0],w['start'][111],w['final'][0],w['final'][111],w['start'][664],w['final'][664])==(2,0,1,525,0,8),'first native port and helper exact frames')

# Exact rational projector P = G diag(I_d,0) G^-1, G=[B^T A^T].
def inverse(m):
    n=len(m); a=[[F(x) for x in row]+[F(i==j) for j in range(n)] for i,row in enumerate(m)]
    for j in range(n):
        pivot=next((i for i in range(j,n) if a[i][j]),None)
        need(pivot is not None,'invertible chart')
        a[j],a[pivot]=a[pivot],a[j]
        z=a[j][j];a[j]=[x/z for x in a[j]]
        for i in range(n):
            if i!=j:
                z=a[i][j]
                a[i]=[x-z*y for x,y in zip(a[i],a[j])]
    return [row[n:] for row in a]
def mm(a,b):
    return [[sum((a[i][k]*b[k][j] for k in range(len(b))), F(0)) for j in range(len(b[0]))] for i in range(len(a))]
def projector(frame):
    f=w['frames'][str(frame)]; rows=f['B']+f['A'];g=[list(col) for col in zip(*rows)]
    inv=inverse(g); d=f['dim']; diag=[[F(i==j and i<d) for j in range(8)] for i in range(8)]
    return mm(mm(g,diag),inv)
def mv(a,v):return [sum((x*y for x,y in zip(row,v)),F(0)) for row in a]
def reflect(p,v):
    pv=mv(p,v);return [a-2*b for a,b in zip(v,pv)]
e6=[F(int(i==6)) for i in range(8)]; neg=[-x for x in e6]
reflections={str(f):[str(x) for x in reflect(projector(f),e6)] for f in (0,2,8,525,1)}
need(reflect(projector(0),e6)==e6 and reflect(projector(2),e6)==e6,'zero and head fix orbit')
need(reflect(projector(8),e6)==neg and reflect(projector(525),e6)==neg and reflect(projector(1),e6)==neg,'helper and body exchange orbit')
need(reflect(projector(8),neg)==e6 and reflect(projector(525),neg)==e6,'two-address orbit closes')
Phead, Pbody, Pline = (projector(f) for f in (2,525,8))
Id=[[F(i==j) for j in range(8)] for i in range(8)]
need([[Phead[i][j]+Pbody[i][j] for j in range(8)] for i in range(8)]==Id,'full port head/body complement')
need(mm(Pbody,Pline)==Pline==mm(Pline,Pbody),'helper line is contained in port body')
need(all(x.denominator==1 for row in Pline for x in row),'added line projector integral')

atlas=op.Atlas(w['frames']);need(atlas.main_contacts(w['start'],w['final'])==111,'111 source port contacts')
forward,backward,deleted=op.native_checks(w,atlas)
np,nt,paid,targets=op.binary_invoice(w,caller,atlas,forward)
for actual,name in ((np,'native_paid'),(nt,'native_targets'),(paid,'paid'),(targets,'targets')):
    need(actual==Counter({int(k):v for k,v in receipt['native'][name].items()}),'receipt '+name)
helpers=[j for j in range(222,680) if atlas.grade(w['start'][j],w['final'][j])==1]
need(helpers==list(range(664,672)),'all original rank-one helper endpoints')

# Extend the true word by the second pair's one port. Role 680 is its source,
# 681 its destination. At entrance donor 664 and destination 681 are frame 0.
# SWAP parks the independent donor at 681 and sends the destination through 664.
# Original private IDs are shifted because public banks now number 682.
def remap(e):
    opn,r,*args=e; r=r+2 if r>=680 else r
    if opn in ('ADD','SWAP'):
        args[0]=args[0]+2 if args[0]>=680 else args[0]
    return [opn,r,*args]
def build(restore):
    x=deepcopy(w);x['public']=682;x['owned_fields']=3554+int(restore)
    x['start']=w['start']+[2,0];x['final']=w['final']+[2,8 if restore else 0]
    x['program']=[['SWAP',664,681]]+[remap(e) for e in w['program']]
    if restore:
        z=682+3554
        # One separate paid rank-one MOVE restores the parked independent owner.
        # The final dirty clear follows the incumbent native owned-erasure rule.
        x['program'] += [['INIT',z,0],['ADD',z,681,0],['MOVE',z,0,8],['SWAP',z,681],['CLEAR',z,0]]
    return x
def bit_ids(n):
    return [j for j in range(682) if (n>>j)&1]
def expected_partial():
    out=[1<<j for j in range(682)]
    for j in range(111): out[111+j] ^= 1<<j
    out[664]=1<<681;out[681]=1<<664
    return out
def transpose(rows):
    out=[0]*len(rows)
    for i,row in enumerate(rows):
        while row:
            bit=row & -row; j=bit.bit_length()-1; out[j]|=1<<i; row^=bit
    return out
changed={}
for restore in (False,True):
    variant=build(restore)
    ft=op.run_tape(variant,atlas,False);bt=op.run_tape(variant,atlas,True)
    want=expected_partial()
    need(ft.output==want and bt.output==transpose(want),'all-column changed partial tape, both ways')
    pp=Counter(p.grade for p in ft.packets.values())
    expected=np.copy()
    if restore:expected[1]+=1
    need(pp==expected,'literal paid MOVE inventory of partial adapter')
    need(ft.dirty==3554+int(restore) and bt.dirty==3554+int(restore),'all dirty private lifetimes retire')
    changed['restored_owner' if restore else 'parked_owner']={
        'forward_coefficients':682**2,'adjoint_coefficients':682**2,
        'independent_input_rows':{'first_source':bit_ids(ft.output[0]),'first_destination':bit_ids(ft.output[111]),'second_source':bit_ids(ft.output[680]),'second_destination':bit_ids(ft.output[664]),'returned_owner':bit_ids(ft.output[681])},
        'actual_final_frames':{'first_source':variant['final'][0],'first_destination':variant['final'][111],
                               'second_source':variant['final'][680],'second_destination':variant['final'][664],
                               'owner':variant['final'][681]},
        'extra_paid':{'1':1} if restore else {},'dirty_retirements_each_way':ft.dirty,
        'original_rank_one_owner_target_credited':restore,
    }

# Complete stage-one repair: after the first native, reset the hosted second
# destination from chart 8 back to 0 through an actual paid rank-one MOVE,
# optionally restore the parked helper owner to chart 8 through another, swap
# the parked fields back, and run a complete independent second native word.
# This is an exact legal negative control, not a saving.
def pair_event(e, offset):
    kind,r,*args=e
    def addr(v):return v+offset if v<680 else 1360+(v-680)
    r=addr(r)
    if kind in ('ADD','SWAP'):args[0]=addr(args[0])
    return [kind,r,*args]
def paired_word(restore):
    pair={'schema':'literal-paired-host-reuse-control/1','public':1360,'owned_fields':3555,
          'frames':w['frames'],'start':w['start']+w['start'],'final':w['final']+w['final']}
    if not restore:pair['final'][664]=0
    z=1360+3554
    entries=[['SWAP',664,791]]+[pair_event(e,0) for e in w['program']]
    if restore:
        entries += [['INIT',z,0],['ADD',z,791,0],['MOVE',z,0,8],['SWAP',z,791],['CLEAR',z,0]]
    entries += [['INIT',z,8],['ADD',z,664,8],['MOVE',z,8,0],['SWAP',z,664],['CLEAR',z,8],['SWAP',664,791]]
    entries += [pair_event(e,680) for e in w['program']]
    pair['program']=entries
    return pair
def pair_expected():
    out=[1<<j for j in range(1360)]
    for base in (0,680):
        for j in range(111):out[base+111+j] ^= 1<<(base+j)
    return out
paired={}; paired_objects={}
for restore in (False,True):
    name='restored_owner' if restore else 'parked_owner'; v=paired_word(restore)
    canonical=json.dumps(v,sort_keys=True,separators=(',',':')).encode()
    packed_path=H/('PAIRED-'+name.upper().replace('_','-')+'.json.gz')
    if '--emit-paired' in sys.argv:packed_path.write_bytes(gzip.compress(canonical,mtime=0))
    else:need(gzip.decompress(packed_path.read_bytes())==canonical,'literal archived pair matches regenerated word')
    f=op.run_tape(v,atlas,False);b=op.run_tape(v,atlas,True); want=pair_expected()
    need(f.output==want and b.output==transpose(want),'paired two-call complete operator in both directions')
    pp=Counter(p.grade for p in f.packets.values()); expected=Counter({r:2*k for r,k in np.items()})
    expected[1]+=2 if restore else 1
    need(pp==expected,'full paired second native and explicit repair calls')
    need(f.dirty==7108+(2 if restore else 1) and b.dirty==7108+(2 if restore else 1),'paired complete dirty retirement')
    orig_t=Counter({r:2*k for r,k in nt.items()}); actual_t=orig_t.copy()
    if not restore:actual_t[1]-=1
    # Every returned helper is an independent scalar endpoint. Parked 664 is
    # deliberately 0->0, all 915 other original helper targets are preserved.
    for base in (0,680):
        for j in range(222,680):
            k=base+j
            need(f.output[k]==1<<k,'all paired dirty helper owners returned independently')
            if k!=664 or restore:need(atlas.grade(v['start'][k],v['final'][k])==atlas.grade(w['start'][j],w['final'][j]),'each other original helper target retained')
    paired[name]={'public_fields':1360,'native_calls':2,'operator_coefficients_each_way':1360**2,
        'returned_independent_helper_owners':916,'preserved_original_helper_targets':916 if restore else 915,
        'surrendered_target_grades':{} if restore else {'1':1},
        'additional_paid_grades':{'1':2 if restore else 1},
        'complete_second_native_paid':dict(np),'complete_second_native_targets':dict(nt),
        'dirty_retirements_each_way':f.dirty,'extra_instructions':len(v['program'])-2*len(w['program']),
        'owner_final_frame':v['final'][664],'second_destination_final_frame':v['final'][791]}
    paired_objects[name]=v
    paired[name]['canonical_sha256']=sha256(canonical).hexdigest()

# Controls: loss of the initial exchange changes actual public coefficients;
# missing either explicit 0/8 transfer breaks a literal chart obligation.
negative={}
cleaned=paired_objects['restored_owner']; want=pair_expected()
wrong=op.run_tape(cleaned,atlas,False,omit=0).output
negative['omitted_initial_SWAP_changed_output_rows']=sum(x!=y for x,y in zip(wrong,want))
need(negative['omitted_initial_SWAP_changed_output_rows']>0,'initial exchange omission rejected')
z=1360+3554
for name,event in [('omitted_owner_restore',['MOVE',z,0,8]),('omitted_second_reset',['MOVE',z,8,0])]:
    positions=[i for i,e in enumerate(cleaned['program']) if e==event]
    need(len(positions)==1,'unique added restoration MOVE')
    try:op.run_tape(cleaned,atlas,False,omit=positions[0])
    except ValueError as error:negative[name]=str(error)
    else:raise ValueError('omission accepted '+name)
owner_clear=[i for i,e in enumerate(cleaned['program']) if e==['CLEAR',z,0]]
need(len(owner_clear)==1,'unique extra owner dirty retirement')
try:op.run_tape(cleaned,atlas,False,omit=owner_clear[0])
except ValueError as error:negative['omitted_added_dirty_clear']=str(error)
else:raise ValueError('omitted added dirty retirement accepted')

# Source + one helper, with two other root fields passed around the visit.
# On the +/-e6 orbit q=1, D=L=t and t^2=1. Matrix entries are a+b*t,
# represented by bits 1 and 2. The desired top-left four-field block is
# diag(t J, t J), J=[[1,0],[1,1]].  Coefficient-of-t rank is a necessary
# condition under arbitrary address-independent binary entry/exit matrices.
S=[[2,0,0,0,0],[2,2,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,2]]
T=[[2,0,0,0,0],[2,2,0,0,0],[0,0,2,0,0],[0,0,2,2,0],[0,0,0,0,1]]
def gf2rank(a):
    m=[sum((int(bool(x))<<j) for j,x in enumerate(row)) for row in a];r=0
    for j in range(len(a[0])):
        p=next((k for k in range(r,len(m)) if m[k]>>j&1),None)
        if p is None:continue
        m[r],m[p]=m[p],m[r]
        for k in range(len(m)):
            if k!=r and m[k]>>j&1:m[k]^=m[r]
        r+=1
    return r
St=[[x>>1&1 for x in row] for row in S]
Tt=[[x>>1&1 for x in row] for row in T]
need(gf2rank(St)==3 and gf2rank(Tt[:4])==4,'source vs required target exact orbit rank')

# Symbolic whole-caller mutation in an optimistic common-view polynomial
# model, independent of the actual frame mismatch of the partial adapter.
# Factor stage1 D_1=L*R, with independent L,R variables (no accidental
# cancellation). q^2=1; other stage powers stay formal, just as source audit.
n=38;zero=(0,)*20
q=[0]*20;q[0]=1;q=tuple(q)
def mul(poly, factors):
    result={}
    for term,row in poly.items():
        t=list(term)
        for pos in factors:
            if pos==0:t[0]^=1
            else:t[pos]+=1
        t=tuple(t);result[t]=result.get(t,0)^row
        if not result[t]:del result[t]
    return result
def pxor(a,b):
    r=a.copy()
    for k,v in b.items():
        r[k]=r.get(k,0)^v
        if not r[k]:del r[k]
    return r
def stage_factor(s):return (1,19) if s==1 else (s,)
def poly_caller(reverse=False, partial=False):
    rows=[{zero:1<<i} for i in range(n)]
    indexes=range(len(caller['events'])-1,-1,-1) if reverse else range(len(caller['events']))
    for clock in indexes:
        kind,*args=caller['events'][clock]
        if kind in ('ADD','QUERY'):
            a,b=args[::-1] if reverse else args
            rows[a]=pxor(rows[a],mul(rows[b],(0,)) if kind=='QUERY' else rows[b])
        elif kind=='SWAP':
            a,b=args;rows[a],rows[b]=rows[b],rows[a]
        elif kind=='LOCAL':
            s,a,b=args
            if partial and clock==5:
                # No shear and no stage on source; destination gets L only.
                rows[b]=mul(rows[b],(19,));continue
            if reverse:a,b=b,a
            rows[b]=mul(pxor(rows[b],mul(rows[a],(0,))),stage_factor(s))
            rows[a]=mul(rows[a],stage_factor(s))
        elif kind=='IDLE_ONE':
            a,stages=args; factors=[]
            for s in stages:factors+=stage_factor(s)
            rows[a]=mul(rows[a],factors)
        else:raise ValueError(kind)
    return rows
roots=[]
for i,d in enumerate(caller['diagonal']):
    fact=[]
    if d['q']:fact.append(0)
    for s in d['stages']:fact+=stage_factor(s)
    roots.append(mul({zero:1<<i},fact))
mutations={}
for rev in (False,True):
    good=poly_caller(rev,False);bad=poly_caller(rev,True)
    need(good==roots,'split-body baseline caller all coefficients')
    diffs=[pxor(a,b) for a,b in zip(bad,roots)]
    failures=[i for i,v in enumerate(diffs) if v]
    need(failures,'partial LOCAL must fail full root identity')
    mutations['adjoint' if rev else 'forward']={'bad_output_rows':len(failures),'first_bad_output':failures[0],
        'bad_row_ids':failures,'changed_monomial_row_terms':sum(map(len,diffs)),
        'changed_scalar_coefficients':sum(v.bit_count() for row in diffs for v in row.values())}

def signed_cost(t,p,k):return price.sub(price.moment(t,k),price.moment(p,k))
# Full source caller and both explicitly changed 36-call occurrences.
p_pair_parked=paid.copy();p_pair_parked[1]+=1
t_pair_parked=targets.copy();t_pair_parked[1]-=1
p_pair_restored=paid.copy();p_pair_restored[1]+=2
t_pair_restored=targets.copy()
def exact_signed(t,p):
    x=Counter(t);x.subtract(p);return x
base_signed=exact_signed(targets,paid)
profiles={}
for name,p,t in [('parked_owner',p_pair_parked,t_pair_parked),('restored_owner',p_pair_restored,t_pair_restored)]:
    delta=exact_signed(t,p);delta.subtract(base_signed)
    delta={rank:v for rank,v in sorted(delta.items()) if v}
    need(delta=={1:-2},'full 36-call signed histogram delta')
    profiles[name]={'paid':dict(sorted(p.items())),'productive':dict(sorted(t.items())),
                    'signed_delta_from_baseline':delta,
                    'paid_job_count':sum(p.values()),'productive_job_count':sum(t.values())}
pricing={}
for label,k in [('round3',F('0.003879929046155')),('reference',F('0.003879928046155'))]:
    base=signed_cost(targets,paid,k)
    p_restored=paid.copy();p_restored[1]+=1
    t_parked=targets.copy();t_parked[1]-=1
    pricing[label]={'k':str(k),'full_baseline_signed':price.decimal_interval(base,30),
      'complete_second_native_paid':price.decimal_interval(price.moment(np,k),18),
      'complete_second_native_targets':price.decimal_interval(price.moment(nt,k),18),
      'extra_partial_parked_formal_invoice':price.decimal_interval(signed_cost(t_parked,paid,k),30),
      'extra_partial_restored_formal_invoice':price.decimal_interval(signed_cost(targets,p_restored,k),30),
      'complete_paired_parked_signed':price.decimal_interval(signed_cost(t_parked,p_pair_parked,k),30),
      'complete_paired_restored_signed':price.decimal_interval(signed_cost(targets,p_pair_restored,k),30),
      'paired_signed_change':'-2',
      'note':'Both partial invoices are diagnostics only. The completed paired-stage controls run the full second native and have exact gain -2.'}

# Conservative raw tape-work bound: scan all 1360 paired public fields and
# all 3555 owned fields at every instruction of the merged paired word. The
# other 34 native visits retain the source bound. Do not claim route savings.
orig_records=receipt['native']['ordinary']['ordinary_records']
base_pair=2*16*(680+3554+4)*len(w['program'])
max_word=paired_objects['restored_owner']
merged_pair=16*(1360+3555+4)*len(max_word['program'])
added_routes=8*80*134*135 # two additional paid positions, four route groups each
conservative_records=orig_records-base_pair+merged_pair+added_routes
need(conservative_records<10**12,'conservative paired partial-control raw record ceiling')
conservative_owned=receipt['native']['ordinary']['owned_backing']+1360+1
need(conservative_owned<10**7,'generous extra paired bank owned ceiling')

result={
 'status':'PASS_SCOPED_HELPER_HOSTING_AND_COMPLETE_PAIRED_NEGATIVE_CONTROLS',
 'source_pins':PINS,'native_canonical_sha256':op.WORD,
 'caller_clocks':{'first':[4,caller['events'][4]],'second':[5,caller['events'][5]],'port':0},
 'selected_helper':{'public':664,'start_chart':0,'end_chart':8,'end_line':w['frames']['8']['B'][0],
                    'all_original_grade_one_helpers':helpers},
 'physical_orbit':{'difference':list(map(str,e6)),'opposite':list(map(str,neg)),
                   'reflection_on_positive_difference_by_chart':reflections,
                   'interpretation':'head Q=I, body D=t, helper L=t, t swaps the two independent address points'},
 'baseline':{'native_scalar_coefficients_each_way':680**2,'caller_polynomial_coefficients_each_way':38**2,
             'native_paid':dict(np),'native_targets':dict(nt),'caller_paid':dict(paid),'caller_targets':dict(targets),
             'unchanged_native_dirty_retirements_each_way':forward.dirty},
 'physical_partial':{'input_frames':[2,0,2,0,0],
                     'required_four_blocks':{'first_from_first':[['D','0'],['D Q','D']],
                          'first_from_second':[['0','0'],['0','0']],
                          'second_from_first':[['0','0'],['0','0']],
                          'second_from_second':[['D','0'],['D Q','D']]},
                     'actual_four_blocks':{'first_from_first':[['D','0'],['D Q','D']],
                          'first_from_second':[['0','0'],['0','0']],
                          'second_from_first':[['0','0'],['0','0']],
                          'second_from_second':[['I','0'],['0','L']]},
                     'required_second_final_charts':[1,525], 'variants':changed},
 'optimistic_boundary_rank':{'source_t_coefficient':St,'source_t_rank':gf2rank(St),
     'required_four_output_t_coefficient':Tt[:4],'required_rank':gf2rank(Tt[:4]),
     'scope':'Five data fields, one actual native port plus helper 664; input/output adapters are address-independent binary matrices, arbitrary extra clean storage permitted. No other native ports/helpers, internal retiming, or paid address transforms in the adapters.'},
 'optimistic_caller_mutation':mutations,'paired_complete_controls':paired,'negative_controls':negative,
 'complete_36_call_profiles':profiles,'pricing':pricing,
 'ordinary_and_precision':{'baseline_raw_records':orig_records,'conservative_merged_pair_raw_records':conservative_records,
   'raw_ceiling':10**12,'baseline_owned_backing':receipt['native']['ordinary']['owned_backing'],
   'conservative_backing':conservative_owned,'owned_ceiling':10**7,
   'scope':'Conservative source raw-record counting model, not an independent new finite compiler or multiplier proof.',
   'precision':'New instructions use only XOR, existing integral chart 8, and the original 0/8 rank-one MOVE; no new rational chart or coefficient is introduced.'},
 'limitations':['A complete two-native paired stage was emitted and checked; both variants have strictly negative gain and do not reduce the second native bill.',
                'The changed paired-caller mutation is an algebraic negative control, not a chart-legal executable caller.',
                'The one-port rank obstruction is scoped to address-independent boundary mixes; it does not exclude multi-port/native retiming or paid address transforms.',
                'No fraction of a native call is credited, and no new kappa theorem is claimed.']}
print(json.dumps(result,sort_keys=True,indent=2))
