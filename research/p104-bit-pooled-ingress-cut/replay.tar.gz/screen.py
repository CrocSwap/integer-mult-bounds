#!/usr/bin/env python3
"""Optimistic joint stock cut for two punctures and multiple ingress recodes."""
if not __debug__:raise RuntimeError("Assertions must be enabled for this replay")
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from network import *
from itertools import combinations
from hashlib import sha256

EXPECTED_WORD='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
EXPECTED_GZIP='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
assert op.WORD==EXPECTED_WORD and op.WORD_GZIP==EXPECTED_GZIP
for item in json.loads((HERE/'SOURCES.json').read_text())['files']:
    assert sha256((HERE/item['local']).read_bytes()).hexdigest()==item['sha256'],item['local']

M=defaultdict(int)
for i,c in enumerate(W['final']):M[c]|=1<<i
BANK=defaultdict(list)
for i,c in enumerate(W['start']):BANK[c].append(i)
for p in O:BANK[R[p][1]].append(p)

def target(i):return (1<<i)^((1<<(i-111)) if 111<=i<222 else 0)
def val(z):return (1<<z) if z<680 else X[z]
def history(p):return [z for z in BANK[R[p][0]] if z<680 or CLOCK[z]<CLOCK[p]]
def hx(x):return sha256(x.to_bytes(85,'little')).hexdigest()
def span_of(ids):
    b=Span()
    for z in sorted(ids):b.add(val(z),1<<z)
    return b
def rem(b,x):
    for power,(v,_) in sorted(b.rows.items(),reverse=True):
        if (x>>(power-1))&1:x^=v
    return x

def touched(p):return {c for c,m in M.items() if m&Y[p]}

# This is an exhaustive roster defined only by these source-visible predicates.
roster=[]
for k in O:
    if k==3553 or G[k] not in (1,6):continue
    d=R[k][1];stock=BANK[d]
    if M[d].bit_count()!=1 or len(stock) not in (3,4):continue
    other=[p for p in stock if p!=k]
    if len(other)!=len(stock)-1 or any(p<680 or CLOCK[p]>=CLOCK[k] for p in other):continue
    if any(q!=k and ((PATH[q]>>k)&1) for q in O):continue
    owner=next(labels(M[d]));t=target(owner)
    prior=span_of(other)
    if prior.express(t) is not None:continue
    assert all(val(p)!=0 for p in other)
    full=span_of(stock); old=full.express(t)
    assert old is not None and old>>k&1
    assert Y[k]==1<<owner
    histories={p:history(p) for p in other}
    sources=sorted(set().union(*map(set,histories.values())))
    basis=span_of(sources)
    assert all(basis.express(X[p]) is not None for p in other)
    roster.append(dict(hole=k,grade=G[k],bank=d,owner=owner,ingress=other,
                       histories=histories,sources=sources,old_decoder=list(labels(old))))
assert len(roster)==111 and len({r['bank'] for r in roster})==111
assert Counter(r['grade'] for r in roster)=={1:9,6:102}
assert max(CLOCK[p] for r in roster for p in r['ingress']) < min(CLOCK[r['hole']] for r in roster)

stats=Counter();pair_digest=sha256();witness=None
for a,b in combinations(roster,2):
    k,j=a['hole'],b['hole'];assert CLOCK[k]<CLOCK[j]
    x=X[k];y=X[j]^(x if PATH[j]>>k&1 else 0)
    assert x and y and x!=y and Y[k] and Y[j] and Y[k]!=Y[j]
    sources=sorted(set(a['sources'])|set(b['sources']))
    assert k not in sources and j not in sources
    shared=span_of(sources);t1=target(a['owner']);t2=target(b['owner'])
    one,two=shared.express(t1),shared.express(t2)
    assert one is None and two is None
    # Adding back the forbidden deleted receipt is an exact positive control.
    for r,t in ((a,t1),(b,t2)):
        phantom=span_of(sources);phantom.add(X[r['hole']],1<<r['hole'])
        recovery=phantom.express(t)
        assert recovery is not None and recovery>>r['hole']&1
        stats['forbidden_deleted_receipt_positive_controls']+=1
    # Leave-one-out bank rows are already in the freely pooled history span.
    for r,t in ((a,t1),(b,t2)):
        for p in r['ingress']:
            basis=span_of(sources)
            for q in r['ingress']:
                if q!=p:basis.add(X[q],1<<q)
            assert basis.express(t) is None
            stats['leave_one_out_failures']+=1
    exterior_a=set().union(*(touched(p) for p in a['ingress']))-{a['bank'],b['bank']}
    exterior_b=set().union(*(touched(p) for p in b['ingress']))-{a['bank'],b['bank']}
    shared_ext=exterior_a&exterior_b
    stats['pairs_sharing_an_exterior_final_chart']+=bool(shared_ext)
    stats['pairs_sharing_chart_1']+=1 in shared_ext
    stats['pairs']+=1;stats['grade_'+str(min(G[k],G[j]))+'_'+str(max(G[k],G[j]))]+=1
    pair_digest.update(f'{k},{j},rank2,no,no\n'.encode())
    if (k,j)==(3302,3306):
        witness=dict(holes=[k,j],grades=[G[k],G[j]],banks=[a['bank'],b['bank']],
            target_owners=[a['owner'],b['owner']],ingresses=[a['ingress'],b['ingress']],
            clocks={str(z):CLOCK[z] for z in [k,j,*a['ingress'],*b['ingress']]},
            source_histories={str(p):history(p) for p in a['ingress']+b['ingress']},
            pooled_source_count=len(sources),pooled_rank=len(shared.rows),
            pooled_target_remainder_sha256_little_endian_680bit=[hx(rem(shared,t1)),hx(rem(shared,t2))],
            shared_exterior_final_charts=sorted(shared_ext),
            deleted_receipt_forbidden_recovery=True)
assert stats['pairs']==6105 and witness is not None
out=dict(schema='p104-paired-terminal-puncture-pooled-source-cut/1',
  source_word_sha256=EXPECTED_WORD,source_gzip_sha256=EXPECTED_GZIP,
  source_head='87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
  target_trial_kappa='0.00388',stats=dict(sorted(stats.items())),
  roster=roster,pair_decision_sha256=pair_digest.hexdigest(),example=witness,
  scope='Two distinct selected terminal-only omissions; only the remaining original paid ingresses into their two final banks may be recoded. All such senders can use arbitrary XORs of their actual strict-preclock same-chart histories. For the necessary cut all their original histories are freely pooled across both banks and clock restrictions for mixing are dropped. All final bank output decoders may use arbitrary combinations. No added paid call. All other sender equations remain original.',
  limitation='The pooled history cut fails before exterior-reader and literal scheduling requirements. It does not rule out changing earlier senders, retargeting routes, adding paid receipts, another roster or a different native/caller.')
text=json.dumps(out,sort_keys=True,indent=2)+'\n'
if '--verify' in sys.argv:assert (HERE/'RESULT.json').read_text()==text
else:(HERE/'RESULT.json').write_text(text)
print(json.dumps(dict(stats=out['stats'],sample=witness,pair_decision_sha256=out['pair_decision_sha256']),sort_keys=True,indent=2))
