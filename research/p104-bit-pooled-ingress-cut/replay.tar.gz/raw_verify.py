#!/usr/bin/env python3
"""Independent literal-instruction replay and low-pivot audit of the pooled cut."""
if not __debug__:raise RuntimeError("Assertions must be enabled for this replay")
from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
from itertools import combinations
import gzip,json,sys
HERE=Path(__file__).resolve().parent
WORD_GZ='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
WORD_CAN='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
raw=(HERE/'source/inputs/WORD.json.gz').read_bytes();assert sha256(raw).hexdigest()==WORD_GZ
w=json.loads(gzip.decompress(raw));assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()==WORD_CAN
n=w['public'];assert n==680

def bits(v):
    while v:
        z=v&-v;yield z.bit_length()-1;v-=z
class LowBasis:
    def __init__(self):self.p={}
    def add(self,v):
        while v:
            p=(v&-v).bit_length()-1
            if p not in self.p:self.p[p]=v;return
            v^=self.p[p]
    def contains(self,v):
        while v:
            p=(v&-v).bit_length()-1
            if p not in self.p:return False
            v^=self.p[p]
        return True

def expected(i):return (1<<i)^((1<<(i-111)) if 111<=i<222 else 0)
# Interpret the actual owner tape, with a second symbolic formal-packet tape.
a=[1<<i for i in range(n)]+[0]*w['owned_fields']
f=a.copy();chart=w['start'][:]+[None]*w['owned_fields']
arr=defaultdict(list)
for i,c in enumerate(w['start']):arr[c].append(i)
routes={};rows={};clocks={};value={i:1<<i for i in range(n)};paths={}
for clock,(op,owner,*args) in enumerate(w['program']):
    if op=='INIT':
        c,=args;a[owner]=f[owner]=0;chart[owner]=c
    elif op=='CLEAR':
        c,=args;assert chart[owner]==c;a[owner]=f[owner]=0
    elif op=='ADD':
        donor,c=args;assert chart[owner]==c and chart[donor]==c
        a[owner]^=a[donor];f[owner]^=f[donor]
    elif op=='SWAP':
        donor,=args;a[owner],a[donor]=a[donor],a[owner];f[owner],f[donor]=f[donor],f[owner];chart[owner],chart[donor]=chart[donor],chart[owner]
    elif op=='MOVE':
        c,d=args;assert chart[owner]==c;p=n+len(routes)
        routes[p]=(c,d);rows[p]=f[owner];value[p]=a[owner];clocks[p]=clock
        v=1<<p
        for z in bits(rows[p]):
            if z>=n:v^=paths[z]
        paths[p]=v;f[owner]=1<<p;chart[owner]=d;arr[d].append(p)
    else:raise AssertionError(op)
assert len(routes)==2874
assert chart[:n]==w['final']
assert all(a[i]==expected(i) for i in range(n))
# Read literal output rows then independently propagate their derivatives.
y={p:0 for p in routes}
for i in range(n):
    for z in bits(f[i]):
        if z>=n:y[z]^=1<<i
for p in reversed(list(routes)):
    for z in bits(rows[p]):
        if z>=n:y[z]^=y[p]
# Complete transpose from the 680 literal forward rows.
for i in range(n):
    trans=sum(((a[j]>>i)&1)<<j for j in range(n))
    assert trans==((1<<i)^((1<<(i+111)) if i<111 else 0))
owners=defaultdict(list)
for i,c in enumerate(w['final']):owners[c].append(i)

def historic(p):return [z for z in arr[routes[p][0]] if z<n or clocks[z]<clocks[p]]
def basis(src):
    b=LowBasis()
    for z in src:b.add(value[z])
    return b

grade={p:abs(w['frames'][str(c)]['dim']-w['frames'][str(d)]['dim']) for p,(c,d) in routes.items()}
roster=[]
for k in routes:
    if k==3553 or grade[k] not in (1,6):continue
    d=routes[k][1];stock=arr[d]
    if len(owners[d])!=1 or len(stock) not in (3,4):continue
    other=[p for p in stock if p!=k]
    if len(other)!=len(stock)-1 or any(p<n or clocks[p]>=clocks[k] for p in other):continue
    if any(q!=k and (paths[q]>>k)&1 for q in routes):continue
    t=expected(owners[d][0])
    if basis(other).contains(t):continue
    assert basis(stock).contains(t) and y[k]==1<<owners[d][0]
    hist=set(z for p in other for z in historic(p))
    assert all(basis(hist).contains(value[p]) for p in other)
    roster.append(dict(k=k,d=d,owner=owners[d][0],others=other,hist=hist,t=t))
assert len(roster)==111 and len({r['d'] for r in roster})==111
assert Counter(grade[r['k']] for r in roster)=={1:9,6:102}
assert max(clocks[p] for r in roster for p in r['others'])<min(clocks[r['k']] for r in roster)
producer=json.loads((HERE/'RESULT.json').read_text())
assert [r['k'] for r in roster]==[r['hole'] for r in producer['roster']]
counts=Counter();digest=sha256()
for u,v in combinations(roster,2):
    k,j=u['k'],v['k'];assert clocks[k]<clocks[j]
    x=value[k];z=value[j]^(x if paths[j]>>k&1 else 0)
    assert x and z and x!=z and y[k] and y[j] and y[k]!=y[j]
    src=u['hist']|v['hist'];assert k not in src and j not in src
    b=basis(src)
    assert not b.contains(u['t']) and not b.contains(v['t'])
    for rec in (u,v):
        bad=basis(src);bad.add(value[rec['k']]);assert bad.contains(rec['t'])
        counts['forbidden_deleted_receipt_positive_controls']+=1
        for p in rec['others']:
            loo=basis(src)
            for q in rec['others']:
                if q!=p:loo.add(value[q])
            assert not loo.contains(rec['t']);counts['leave_one_out_failures']+=1
    ex_u={w['final'][i] for p in u['others'] for i in bits(y[p])}-{u['d'],v['d']}
    ex_v={w['final'][i] for p in v['others'] for i in bits(y[p])}-{u['d'],v['d']}
    counts['pairs_sharing_an_exterior_final_chart']+=bool(ex_u & ex_v)
    counts['pairs_sharing_chart_1']+=1 in (ex_u & ex_v)
    counts['pairs']+=1
    counts[f"grade_{min(grade[k],grade[j])}_{max(grade[k],grade[j])}"]+=1
    digest.update(f'{k},{j},rank2,no,no\n'.encode())
for name,count in counts.items():assert count==producer['stats'][name]
assert digest.hexdigest()==producer['pair_decision_sha256']
report={'status':'PASS_INDEPENDENT_LITERAL_AND_LOW_PIVOT','word':WORD_CAN,
 'program_instructions':len(w['program']),'moves':len(routes),'forward_rows':n,'transpose_rows':n,
 'roster_holes':len(roster),'counts':dict(sorted(counts.items())),
 'pair_decision_sha256':digest.hexdigest(),
 'method':'Direct primitive tape for actual and formal values; separate low-pivot GF(2) elimination; no producer packet graph, span class, or decoder imported.'}
text=json.dumps(report,indent=2,sort_keys=True)+'\n'
if '--verify' in sys.argv:assert (HERE/'RAW-VERIFY.json').read_text()==text
else:(HERE/'RAW-VERIFY.json').write_text(text)
print(text,end='')
