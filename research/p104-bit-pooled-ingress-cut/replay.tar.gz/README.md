# Two punctures with jointly recoded surviving ingress senders

The pinned 680-owner binary word has a reproducible **necessary cut** for a bounded rank-two puncture family. Across 6,105 pairs of two originally paid terminal packets, neither affected terminal target belongs to an optimistic pool of all earlier source values for all retained ingress senders of both affected banks. The pool grants cross-chart mixing, unlimited retention, and arbitrary independent sender payloads; nevertheless both targets fail. The test therefore rules out every repair in this specified family, including changing two or more sender equations and freely re-decoding all final-bank outputs. It does not prove a new κ result.

The original binary word is the #7830 source at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`: canonical SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`, compressed SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`. `SOURCES.json` pins the word and the original packet interpreter and retains upstream source locations and notices.

## Family and test

The roster is defined from the pinned word, not chosen by a successful screen. Select a nonbridge paid packet `k` of grade 1 or 6 when all the following hold:

1. Its receiving chart has exactly one required final owner and three or four total historical arrivals, counting public inputs as arrivals.
2. The other arrivals are paid packets occurring before `k`; no later paid packet has nonzero linear influence from `k`.
3. Removing `k` makes the chart's one required final row unrecoverable from its other arrivals.

There are exactly 111 selected packets: 102 of grade 6 and nine of grade 1, each on a distinct final chart. Every retained ingress among these charts occurs before every selected omission; the last retained-ingress clock is 11456 and the first selected-omission clock is 11616. Choose any two distinct roster entries and remove their packets. The two original missing input directions and the two output-influence directions are independently rank two. There are 5,151 grade-6/6 pairs, 918 grade-1/6 pairs and 36 grade-1/1 pairs.

The only paid sender equations permitted to change are the surviving original ingresses into these two selected final banks. Each may be replaced by **any** XOR of its actual earlier same-chart stock, subject to its own original clock. All remaining paid sender equations and paid routes are fixed, and no extra paid call is added. Final output equations at all charts may be re-decoded arbitrarily. Source and output storage is optimistically granted free; the test does not claim physical stock availability.

For a pair, collect all original values from the strict-preclock source histories of all surviving ingresses at both banks, and call their span `U`. Grant the senders the entire pooled `U` even though it crosses charts and ignores the order in which values could really be mixed. If a changed earlier ingress affects a later sender's historical stock, its difference is also in `U`: induct on ingress clock, since the changed value and the original sender value both lie in `U`. Thus **every** retained ingress value at either selected bank lies in `U`, even with simultaneous dependent recodes. Each selected bank has no original input and no other retained arrival, so any final decoder at that bank can only produce a value in `U`.

For all 6,105 pairs, both required target rows are outside `U`. The checker also tests 35,640 leave-one-out carrier cases, optimistically including the other original rows and the whole pooled source span. All fail. All pairs have exterior readers in common at final chart 1; they are *not* assumed isolated. The pooled cut already rules out the family before any exterior constraint must be imposed.

The full result and exhaustive roster are in `RESULT.json`. For the concrete pair `(3302, 3306)`, the bank/owner pairs are `(612, 198)` and `(619, 205)`; their six surviving ingresses are `(2686, 2692, 2695)` and `(2614, 2620, 2625)`. All 18 source values are independent and neither required target lies in their span. The report records every source label, clock and quotient remainder hash. When the deleted original receipt for the affected bank is incorrectly inserted into the pool, that bank's target becomes expressible. All 12,210 such forbidden-restoration controls succeed, demonstrating why the original omitted or later value must not be admitted as a preclock source.

## Independent replay and scope

`raw_verify.py` independently interprets all 42,958 actual primitive instructions while tracking values, charts and packet labels. It checks all 680 forward rows, derives and checks the full transposed matrix from those rows, reconstructs the roster and reader influence, and repeats the cuts and positive controls with a separate low-pivot GF(2) reducer. This matrix check is not a reverse primitive-tape execution of a changed word. `RAW-VERIFY.json` gives its counts and the matching digest of all 6,105 pair decisions. It does not import the producer's packet graph, span implementation or decoder.

A positive result would require a real changed schedule, both full operator replays, a complete paired-caller paid and productive invoice, and the further finite and outer obligations. There is no positive result here, so there is no changed-word invoice or κ qualification. The result does **not** exclude changing earlier sender equations outside the two bank-ingress sets, other omitted packets, new or retargeted paid routes, a different timing schedule that creates new source values, a changed caller, or another native construction. Exterior readers and physical erasure were not certified; the optimistic algebraic cut precedes them.

## Reproduce offline

Python 3.11 or later and the standard library suffice. From this directory run:

```sh
sha256sum -c SHA256SUMS
python3 -IB screen.py --verify
python3 -IB raw_verify.py --verify
```

Both programs require assertions to remain enabled and reject a mismatch with their frozen JSON outputs. No external service is required.
