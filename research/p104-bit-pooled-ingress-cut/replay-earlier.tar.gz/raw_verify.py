#!/usr/bin/env python3
"""Independent literal-instruction replay and low-pivot audit of the pooled cut."""
if not __debug__:raise RuntimeError("Assertions must be enabled for this replay")
from pathlib import Path
from collections import Counter,defaultdict
from hashlib import sha256
from itertools import combinations
import gzip,json,sys
HERE=Path(__file__).resolve().parent
WORD_GZ='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
WORD_CAN='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
raw=(HERE/'source/inputs/WORD.json.gz').read_bytes();assert sha256(raw).hexdigest()==WORD_GZ
w=json.loads(gzip.decompress(raw));assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()==WORD_CAN
n=w['public'];assert n==680

def bits(v):
    while v:
        z=v&-v;yield z.bit_length()-1;v-=z
class LowBasis:
    def __init__(self):self.p={}
    def add(self,v):
        while v:
            p=(v&-v).bit_length()-1
            if p not in self.p:self.p[p]=v;return
            v^=self.p[p]
    def contains(self,v):
        while v:
            p=(v&-v).bit_length()-1
            if p not in self.p:return False
            v^=self.p[p]
        return True

def expected(i):return (1<<i)^((1<<(i-111)) if 111<=i<222 else 0)
# Interpret the actual owner tape, with a second symbolic formal-packet tape.
a=[1<<i for i in range(n)]+[0]*w['owned_fields']
f=a.copy();chart=w['start'][:]+[None]*w['owned_fields']
arr=defaultdict(list)
for i,c in enumerate(w['start']):arr[c].append(i)
routes={};rows={};clocks={};value={i:1<<i for i in range(n)};paths={}
for clock,(op,owner,*args) in enumerate(w['program']):
    if op=='INIT':
        c,=args;a[owner]=f[owner]=0;chart[owner]=c
    elif op=='CLEAR':
        c,=args;assert chart[owner]==c;a[owner]=f[owner]=0
    elif op=='ADD':
        donor,c=args;assert chart[owner]==c and chart[donor]==c
        a[owner]^=a[donor];f[owner]^=f[donor]
    elif op=='SWAP':
        donor,=args;a[owner],a[donor]=a[donor],a[owner];f[owner],f[donor]=f[donor],f[owner];chart[owner],chart[donor]=chart[donor],chart[owner]
    elif op=='MOVE':
        c,d=args;assert chart[owner]==c;p=n+len(routes)
        routes[p]=(c,d);rows[p]=f[owner];value[p]=a[owner];clocks[p]=clock
        v=1<<p
        for z in bits(rows[p]):
            if z>=n:v^=paths[z]
        paths[p]=v;f[owner]=1<<p;chart[owner]=d;arr[d].append(p)
    else:raise AssertionError(op)
assert len(routes)==2874
assert chart[:n]==w['final']
assert all(a[i]==expected(i) for i in range(n))
# Read literal output rows then independently propagate their derivatives.
y={p:0 for p in routes}
for i in range(n):
    for z in bits(f[i]):
        if z>=n:y[z]^=1<<i
for p in reversed(list(routes)):
    for z in bits(rows[p]):
        if z>=n:y[z]^=y[p]
# Complete transpose from the 680 literal forward rows.
for i in range(n):
    trans=sum(((a[j]>>i)&1)<<j for j in range(n))
    assert trans==((1<<i)^((1<<(i+111)) if i<111 else 0))
owners=defaultdict(list)
for i,c in enumerate(w['final']):owners[c].append(i)

def historic(p):return [z for z in arr[routes[p][0]] if z<n or clocks[z]<clocks[p]]
def basis(src):
    b=LowBasis()
    for z in src:b.add(value[z])
    return b

grade={p:abs(w['frames'][str(c)]['dim']-w['frames'][str(d)]['dim']) for p,(c,d) in routes.items()}
roster=[]
for k in routes:
    if k==3553 or grade[k] not in (1,6):continue
    d=routes[k][1];stock=arr[d]
    if len(owners[d])!=1 or len(stock) not in (3,4):continue
    other=[p for p in stock if p!=k]
    if len(other)!=len(stock)-1 or any(p<n or clocks[p]>=clocks[k] for p in other):continue
    if any(q!=k and (paths[q]>>k)&1 for q in routes):continue
    t=expected(owners[d][0])
    if basis(other).contains(t):continue
    assert basis(stock).contains(t) and y[k]==1<<owners[d][0]
    hist=set(z for p in other for z in historic(p))
    assert all(basis(hist).contains(value[p]) for p in other)
    roster.append(dict(k=k,d=d,owner=owners[d][0],others=other,hist=hist,t=t))
assert len(roster)==111 and len({r['d'] for r in roster})==111
assert Counter(grade[r['k']] for r in roster)=={1:9,6:102}
assert max(clocks[p] for r in roster for p in r['others'])<min(clocks[r['k']] for r in roster)
parent=json.loads((HERE/'PARENT-RESULT.json').read_text())
assert [r['k'] for r in roster]==[r['hole'] for r in parent['roster']]
producer=json.loads((HERE/'RESULT.json').read_text())
def demands(r):
    return {s:r['t']^sum_value(r['others'],s) for s in range(1,1<<len(r['others']))}
def sum_value(ing,s):
    out=0
    for i,p in enumerate(ing):
        if s>>i&1:out^=value[p]
    return out
stats=Counter();candidate_cases=[]
for r in roster:
    k=r['k'];ing=r['others'];first=min(clocks[p] for p in ing);needs=demands(r)
    assert len(set(needs.values()))==(1<<len(ing))-1 and all(needs.values())
    stats['grade_'+str(grade[k])+'_families']+=1
    cand=[]
    for q in routes:
        if q==3553 or q in ing or clocks[q]>=first:continue
        pattern=sum(((paths[p]>>q)&1)<<i for i,p in enumerate(ing))
        if pattern.bit_count()<2:continue
        cand.append((q,pattern))
    stats['grade_'+str(grade[k])+'_families_with_sender']+=bool(cand)
    for q,pattern in cand:
        assert clocks[q]<first and q!=k
        h=historic(q);assert all(p<n or clocks[p]<clocks[q] for p in h)
        B=basis(h)
        required=[(s,v) for s,v in needs.items() if (s&pattern).bit_count()%2]
        assert len(required)==2**(len(ing)-1)
        for s,v in required:
            assert not B.contains(v)
            stats['requirements_outside_actual_preclock_source']+=1
        stats['sender_family_cases']+=1;candidate_cases.append((k,q,pattern))
sets={r['k']:set(demands(r).values()) for r in roster};digest=sha256()
for u,v in combinations(roster,2):
    a,b=sets[u['k']],sets[v['k']]
    stats['correction_vector_equalities_tested']+=len(a)*len(b)
    assert not (a&b)
    stats['pairs']+=1
    stats[f"pairs_{min(grade[u['k']],grade[v['k']])}_{max(grade[u['k']],grade[v['k']])}"]+=1
    digest.update(f"{u['k']},{v['k']},disjoint\n".encode())
for key,count in stats.items():assert producer['stats'][key]==count
assert digest.hexdigest()==producer['pair_decisions_sha256']
# Positive control synthesizes a second-bank target whose correction is the first.
u=next(r for r in roster if r['k']==3302);v=next(r for r in roster if r['k']==3306)
pulse=next(iter(sets[u['k']]));fake=pulse^value[v['others'][0]]
fake_set={fake^sum_value(v['others'],s) for s in range(1,1<<len(v['others']))}
assert pulse in sets[u['k']] and pulse in fake_set and fake!=v['t']
# Replay the literal primitive tape with the named hole and a sender set to
# zero; compare every row to the independently computed outer-product column.
k=3306;q=1233;delta=value[q]
assert (k,q,5) in candidate_cases and basis(historic(q)).contains(delta)
def replay(change):
    reg=[1<<i for i in range(n)]+[0]*w['owned_fields'];ix=0
    for op,owner,*args in w['program']:
        if op in ('INIT','CLEAR'):reg[owner]=0
        elif op=='ADD':reg[owner]^=reg[args[0]]
        elif op=='SWAP':reg[owner],reg[args[0]]=reg[args[0]],reg[owner]
        elif op=='MOVE':
            p=n+ix;ix+=1
            if p==k:reg[owner]=0
            if p==q and change:reg[owner]^=delta
        else:raise AssertionError(op)
    return reg[:n]
base=replay(False);test=replay(True);influence=y[q]^(y[k] if paths[k]>>q&1 else 0)
assert all(test[i]==base[i]^(delta if influence>>i&1 else 0) for i in range(n))
assert sum(base[i]!=test[i] for i in range(n))==influence.bit_count()==56
assert all(w['final'][i]!=619 for i in bits(influence))
report={'status':'PASS_INDEPENDENT_PRIMITIVE_AND_LOW_PIVOT','word':WORD_CAN,
 'program_instructions':len(w['program']),'forward_rows':n,'transpose_rows_derived':n,
 'counts':dict(sorted(stats.items())),'pair_decisions_sha256':digest.hexdigest(),
 'direct_primitive_outer_product_control':True,'control_sender':q,'control_hole':k,
 'control_output_rows_affected':56,'synthetic_positive_control':True,
 'method':'Literal instruction interpreter and separate low-pivot GF(2) elimination; recoded sender is zeroed during the literal MOVE, not imported from producer graph.'}
text=json.dumps(report,sort_keys=True,indent=2)+'\n'
if '--verify' in sys.argv:assert (HERE/'RAW-VERIFY.json').read_text()==text
else:(HERE/'RAW-VERIFY.json').write_text(text)
print(text,end='')
