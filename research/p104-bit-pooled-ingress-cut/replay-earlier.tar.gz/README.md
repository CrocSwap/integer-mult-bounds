# Earlier paid-sender pulse at two terminal punctures

A single earlier paid-sender recode cannot repair any of the 6,105 two-hole pairs in the pinned 111-packet terminal roster. This is an optimistic rank-one cut: it allows the sender pulse to be any 680-input GF(2) vector and grants it an arbitrary independent presence or absence at each surviving ingress. The two affected banks nevertheless require disjoint correction-vector sets. There is no changed feasible word, invoice or κ improvement.

The original binary word is the #7830 source at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, canonical SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. `SOURCES.json` pins the word and source dependencies. The roster and its original verification are recorded in `PARENT-RESULT.json`: it has 102 grade-6 and nine grade-1 paid terminal packets at distinct output banks. A selected terminal packet has no later paid packet with nonzero linear influence from it, and its omission leaves one original required target unrecoverable from the other arrivals at its bank.

## Earlier-sender gate

First choose a single roster omission and one **different, already paid** earlier sender. Change only that sender's equation; it may use an arbitrary XOR of its own strictly earlier same-chart historical stock. Original paid routes, all other paid sender equations and clocks remain fixed. The sender must precede and affect at least two of the retained ingress packets into the affected bank. Final equations may be arbitrarily decoded at every bank, and retention and local XOR are granted free.

In the nine grade-1 families, the two surviving ingresses have no common paid-packet ancestor with nonzero GF(2) transfer, so no sender meets this condition. In the 102 grade-6 families, 53 have at least one such sender, giving 130 sender/family cases. For each possible final-bank decoder, the sender's influence parity and the required correction are computed exactly. All 520 parity-eligible correction requirements are outside the sender's actual earlier same-chart source span. These failures already hold before requiring exterior readers to remain correct.

For example, with hole `3306` at bank `619`, earlier paid sender `1233` (route `0 → 98`, clock `1958`) affects surviving ingresses `2614` and `2625`, but not `2620`, at clocks `9078`, `9102` and `9122`. All four required correction vectors fail containment in the sender's 524-dimensional preclock source span. A separate direct primitive-tape control sets this sender to zero while puncturing `3306`: its pulse changes 56 **original-decoder exterior output rows**. Those exterior rows might themselves have alternate decoders; this control only demonstrates why they cannot be silently ignored. `RESULT.json` lists the other 129 eligible cases, source ranks and original path signatures.

## Two-hole rank-one cut

For a bank with retained original ingress payloads `s_i`, target `t`, and a single sender pulse `δ`, the changed ingress payloads are `s_i + a_i δ` for fixed GF(2) path coefficients `a_i`. If a final decoder chooses coefficients `b_i`, then its output is

```
Σ b_i s_i + (Σ b_i a_i) δ.
```

Because the target is outside the original retained-bank span, the second coefficient must be one. Thus `δ` must lie in the bank's finite set `{t + Σ b_i s_i : b ≠ 0}`. For two holes, the same `δ` must lie in both banks' sets. The sets are disjoint for all 6,105 pairs, including 36 grade-1/1, 918 grade-1/6 and 5,151 grade-6/6 pairs. The checker compares 272,001 candidate vector equalities. This result permits an arbitrary pulse vector and arbitrary path coefficients, so it is stronger than any particular sender, route or affordability choice in the one-sender model.

A synthetic positive control changes one test target so the two correction sets share a vector; the checker detects the intersection. This is a canary for the decision method, not a construction for the original targets. A second control performs the `1233` recode and `3306` deletion on all 680 outputs and agrees with the exact outer-product prediction.

## Independent verification and boundaries

`raw_verify.py` interprets all 42,958 primitive instructions independently, tracks charts and values, derives the original transposed matrix from the 680 forward rows, and repeats the chronology, path, source-span and pair gates with low-pivot elimination. For the contamination control it executes the two interventions directly in the primitive tape and checks every one of the 680 output rows. It does not import the producer packet graph or span code. `RAW-VERIFY.json` records the counts and matching pair digest.

The result excludes only a **single changed sender payload**, with all other paid sender equations fixed. It does not exclude two or more coordinated earlier sender recodes, recoding descendants, changing routes, a different omission roster, or changing the caller. It does not establish exterior redecoding, a valid revised schedule, physical stock or erasure, a finite supplier or any outer theorem. The independent checker is a separate implementation in the same research activity, not an independent human audit.

## Reproduce offline

Python 3.11 or later and the standard library suffice:

```sh
sha256sum -c SHA256SUMS
python3 -IB screen.py --verify
python3 -IB raw_verify.py --verify
```

Both replays reject disabled assertions and mismatched frozen results. No external service is needed.
