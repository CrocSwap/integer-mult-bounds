"""The pinned binary network and its front/back port totals."""
import gzip
import hashlib
import json
import sys
from pathlib import Path
from collections import defaultdict, Counter
from functools import reduce
from operator import xor

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'source'
PHYSICAL=SOURCE/'vendor'
sys.path.insert(0,str(PHYSICAL))
import physical
sys.path.insert(0,str(SOURCE/'vendor'))
import binary_operator as op
sys.path.insert(0,str(SOURCE))
import common as prices

def labels(a):
    while a:
        bit=a&-a
        yield bit.bit_length()-1
        a^=bit

def xsum(terms):
    return reduce(xor,terms,0)

W=op.load_json(SOURCE/'inputs/WORD.json.gz',op.WORD_GZIP,True)
assert op.canonical_hash(W)==op.WORD
R,ROWS,CLOCK=physical.packet_word(W)
DR,DROWS=physical.dual(W['public'],R,ROWS)
O,X=physical.evaluate(W['start'],W['final'],R,ROWS,False)
_,Y=physical.evaluate(W['final'],W['start'],DR,DROWS,True)
O=sorted(R,key=CLOCK.get)
G={k:abs(W['frames'][str(a)]['dim']-W['frames'][str(b)]['dim']) for k,(a,b) in R.items()}
DIMS={int(c):v['dim'] for c,v in W['frames'].items()}
PATH={}
for k in O:
    PATH[k]=(1<<k)^xsum(PATH[j] for j in labels(ROWS[k]) if j in PATH)
DPA={}
for k in O[::-1]:
    DPA[k]=(1<<k)^xsum(DPA[j] for j in labels(DROWS[k]) if j in DPA)
assert all((PATH[k]>>j)&1==(DPA[j]>>k)&1 for k in O[::61] for j in O[::71])

class Span:
    def __init__(self):
        self.rows={}
        self.union=0
    def add(self,x,label=0):
        self.union|=x
        while x:
            p=x.bit_length()
            if p not in self.rows:
                self.rows[p]=(x,label)
                return True
            a,m=self.rows[p];x^=a;label^=m
        return False
    def express(self,x):
        if x&~self.union:return None
        lab=0
        while x:
            v=self.rows.get(x.bit_length())
            if v is None:return None
            a,m=v;x^=a;lab^=m
        return lab

def emit(name,value):
    (HERE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def public_source():
    return dict(head='87fbf4f7b35b0f18ab12b5767775a9a424cf0b15', word_canonical=op.WORD, word_gzip=op.WORD_GZIP)
