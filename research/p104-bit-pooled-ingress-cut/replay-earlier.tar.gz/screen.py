#!/usr/bin/env python3
"""One earlier paid-sender pulse: exact transfer, source and two-hole cuts."""
if not __debug__:raise RuntimeError('Assertions must be enabled')
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from network import *
from itertools import combinations
from hashlib import sha256

for f in json.loads((HERE/'SOURCES.json').read_text())['files']:
 assert sha256((HERE/f['local']).read_bytes()).hexdigest()==f['sha256']
parent=json.loads((HERE/'PARENT-RESULT.json').read_text());assert parent['source_word_sha256']==op.WORD
roster=parent['roster'];assert len(roster)==111 and Counter(r['grade'] for r in roster)=={1:9,6:102}
BANK=defaultdict(list)
for i,c in enumerate(W['start']):BANK[c].append(i)
for p in O:BANK[R[p][1]].append(p)
def val(z):return 1<<z if z<680 else X[z]
def history(q):return [z for z in BANK[R[q][0]] if z<680 or CLOCK[z]<CLOCK[q]]
def target(r):
 i=r['owner'];return (1<<i)^((1<<(i-111)) if 111<=i<222 else 0)
def drows(r):
 ing=r['ingress'];t=target(r)
 return {s:t^xsum(X[p] for i,p in enumerate(ing) if s>>i&1) for s in range(1,1<<len(ing))}
def digest(v):return sha256(v.to_bytes(85,'little')).hexdigest()
def basis(q):
 b=Span();hist=history(q)
 for z in hist:b.add(val(z),1<<z)
 return b,hist

stats=Counter();families=[];sample=None
for r in roster:
 k=r['hole'];ing=r['ingress'];earliest=min(CLOCK[p] for p in ing);ds=drows(r)
 assert len(set(ds.values()))==(1<<len(ing))-1 and all(ds.values())
 assert all(CLOCK[p]<CLOCK[k] for p in ing)
 # Exact impulse coefficient for a paid packet through each retained ingress.
 paths=0
 for p1,p2 in combinations(ing,2):paths|=PATH[p1]&PATH[p2]
 candidates=[q for q in labels(paths) if q in R and q!=3553 and q not in ing and CLOCK[q]<earliest]
 stats['grade_'+str(G[k])+'_families']+=1
 stats['grade_'+str(G[k])+'_families_with_sender']+=bool(candidates)
 details=[]
 for q in candidates:
  assert CLOCK[q]<earliest and q!=k
  pat=sum(((PATH[p]>>q)&1)<<i for i,p in enumerate(ing));assert pat.bit_count()>=2
  B,h=basis(q);assert all(z<680 or CLOCK[z]<CLOCK[q] for z in h)
  required=[(s,v) for s,v in ds.items() if (s&pat).bit_count()%2]
  assert len(required)==2**(len(ing)-1)
  for s,v in required:
   assert B.express(v) is None
   stats['requirements_outside_actual_preclock_source']+=1
  stats['sender_family_cases']+=1
  details.append(dict(sender=q,clock=CLOCK[q],route=list(R[q]),pattern=pat,
          required_masks=[s for s,v in required],source_history_count=len(h),source_history_rank=len(B.rows)))
  if k==3306 and q==1233:
   pulse=Y[q]^(Y[k] if (PATH[k]>>q)&1 else 0)
   sample=dict(hole=k,bank=r['bank'],sender=q,route=list(R[q]),clock=CLOCK[q],
      ingresses=ing,ingress_clocks=[CLOCK[p] for p in ing],
      influence_pattern=[(PATH[p]>>q)&1 for p in ing],source_history_count=len(h),
      source_history_rank=len(B.rows),selector_correction_sha256={str(s):digest(v) for s,v in required},
      all_four_source_containments_fail=True,original_impulse_rows=Y[q].bit_count(),
      deleted_hole_impulse=(PATH[k]>>q)&1,
      after_puncture_original_decoder_impulse_rows=pulse.bit_count(),
      exterior_original_decoder_impulse_rows=(pulse&~(1<<r['owner'])).bit_count(),
      exterior_charts=sorted({W['final'][i] for i in labels(pulse) if W['final'][i]!=r['bank']}))
 families.append(dict(hole=k,grade=G[k],bank=r['bank'],eligible_sender_details=details))
assert sample and stats['sender_family_cases']==130 and stats['requirements_outside_actual_preclock_source']==520
assert stats['grade_1_families']==9 and stats['grade_1_families_with_sender']==0
assert stats['grade_6_families']==102 and stats['grade_6_families_with_sender']==53

# Two holes: their desired corrections are disjoint even for an omnipotent
# single pulse with an arbitrary coefficient on every retained arrival.
needs={r['hole']:set(drows(r).values()) for r in roster};decisions=sha256()
for a,b in combinations(roster,2):
 A,B=needs[a['hole']],needs[b['hole']];stats['correction_vector_equalities_tested']+=len(A)*len(B)
 assert not A&B
 stats['pairs']+=1;stats['pairs_'+str(min(a['grade'],b['grade']))+'_'+str(max(a['grade'],b['grade']))]+=1
 decisions.update(f"{a['hole']},{b['hole']},disjoint\n".encode())
assert stats['pairs']==6105 and stats['correction_vector_equalities_tested']==272001
# Synthetic target control: exact desired-set intersection changes to positive.
a=next(r for r in roster if r['hole']==3302);b=next(r for r in roster if r['hole']==3306)
delta=next(iter(drows(a).values()));fake_target=delta^X[b['ingress'][0]]
fake_needs={fake_target^xsum(X[p] for i,p in enumerate(b['ingress']) if s>>i&1) for s in range(1,1<<len(b['ingress']))}
assert delta in needs[a['hole']] and delta in fake_needs and fake_target!=target(b)

# Direct graph replay of an allowed pulse, not a successful repair: zero q
# by XORing its own actual payload, puncture k, and check the full outer product.
k=3306;q=1233;delta=X[q]
B,h=basis(q);assert B.express(delta) is not None and delta

def evaluate(pulsed):
 vals={i:1<<i for i in range(680)}
 for p in O:
  vals[p]=0 if p==k else xsum(vals[z] for z in labels(ROWS[p]))
  if p==q and pulsed:vals[p]^=delta
 return [xsum(vals[z] for z in labels(ROWS[~i])) for i in range(680)]
base=evaluate(False);test=evaluate(True);impulse=Y[q]^(Y[k] if PATH[k]>>q&1 else 0)
assert all(test[i]==base[i]^(delta if impulse>>i&1 else 0) for i in range(680))
assert sum(test[i]!=base[i] for i in range(680))==impulse.bit_count()==sample['after_puncture_original_decoder_impulse_rows']
result=dict(schema='p104-earlier-single-sender-pulse-screen/1',source_word_sha256=op.WORD,
 source_head='87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 parent_result_sha256=sha256((HERE/'PARENT-RESULT.json').read_bytes()).hexdigest(),
 stats=dict(sorted(stats.items())),families=families,pair_decisions_sha256=decisions.hexdigest(),
 sample=sample,controls={'synthetic_second_target_has_common_correction':True,
  'direct_680_row_forward_outer_product':True,'control_sender':q,'control_hole':k,
  'control_delta':'sender original payload; recoding sender to zero',
  'changed_original_output_rows':impulse.bit_count()},
 scope='One deleted terminal packet and one earlier paid sender whose impulse reaches two or more surviving ingresses of its bank; sender may be arbitrarily recoded from actual strict-preclock same-chart stock, other paid equations fixed, arbitrary final bank decoder. Two-hole gate is stronger: any single earlier sender impulse may have arbitrary coefficients on all retained ingresses and arbitrary input value; the two correction sets are disjoint.',
 limitations='No results for simultaneous recoding of multiple earlier senders, coupled descendant recoding, another hole roster or changed routes; source-retention granted free. Exterior reader obligations are not solved; all candidates already fail a necessary local or rank-one gate. No changed valid word, invoice or kappa.')
out=json.dumps(result,sort_keys=True,indent=2)+'\n'
if '--verify' in sys.argv:assert (HERE/'RESULT.json').read_text()==out
else:(HERE/'RESULT.json').write_text(out)
print(json.dumps(dict(stats=result['stats'],sample=sample,controls=result['controls'],pair_decisions_sha256=result['pair_decisions_sha256']),indent=2,sort_keys=True))
