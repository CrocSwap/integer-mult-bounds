#!/usr/bin/env python3
"""Exact P104 examples for four 6D depots; not a proof of the cut.

Uses only stdlib and the included, manifest-verified #7916 controls.
The witness is derived by retiming an inherited exact P104 fixture.
"""
from fractions import Fraction as Q
from pathlib import Path
import runpy
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
old = runpy.run_path(str(HERE / 'prior' / 'check_two_six.py'))
r, p, s = old['r'], old['p'], old['s']


def check(name, net, expected, pairs_expected, rcount=4):
    M, gather, dep, D, dims = s['verify'](name, net)
    assert M == s['M0'] and len(gather) == 9 and len(dep) == 8
    gdims = sorted(dims[g][0] for g in gather)
    assert gdims in ([7,7,8,8,8,8,8,8,8], [7,7,8,8,8,8,8,8,9])
    lg = [g for g in gather if dims[g][0] == 7]
    assert len(lg) == 2 and len(s['echelon'](net['a'][lg[0]] + net['a'][lg[1]])) == 8
    lows = [d for d in dep if dims[d][0] == 6]
    assert len(lows) == rcount and all(dims[d][0] >= 8 for d in dep if d not in lows)
    assert all(dims[d][1] <= 1 for d in dep)
    E = sum(max(dims[d][0]-8,0) for d in dep)
    B = sum(dims[d][1] == 0 for d in dep)
    X = [i for i in range(len(dims)) if i not in dep and dims[i][0] > dims[i][1]]
    T = sum(dims[x][0]-dims[x][1] for x in X)
    assert (E,B,T,D) == expected and D == 56-2*rcount+E+B+T == 56+E+B
    reach = p['c']['reachability'](net['H'])
    pairs = [(d,e) for d in dep for e in dep if d != e and e in reach[d]]
    assert len(pairs) == pairs_expected, pairs
    H0, N, N0, A, C, C0 = r['sink_factor'](net['H'],dep,gather)
    assert r['rank'](C) == r['rank'](C0) == 8
    circuit = r['kernel_one'](C0)
    assert circuit == r['kernel_one'](C)
    assert all(circuit[gather.index(g)] for g in lg)
    P,U,R,J,V = p['factors'](H0,gather,lows,X)
    assert P == [C0[dep.index(d)] for d in lows]
    assert r['rank'](P) == r['rank'](U) == rcount
    high = [j for j,g in enumerate(gather) if dims[g][0] >= 8]
    high_rank = r['rank']([[row[j] for j in high] for row in P])
    assert high_rank >= rcount-1 and not any(v for row in V for v in row)
    assert not p['odd_transfer_errors'](net,net['H'])
    terminals = [X[i] for i in range(len(X)) if any(row[i] for row in U)]
    highs = [x for x in X if dims[x][0] >= 8]
    assert len(terminals) >= rcount and len(highs) >= rcount-1 and T >= len(terminals)+len(highs)
    print(f'{name}: lows={lows}, X={X}, terminal={terminals}, high={highs}')
    print(f'{name}: E={E}, B={B}, T={T}, D={D}, comparable depot pairs={pairs}')
    print(f'{name}: full 104x104 Gram, odd and diagonal cells pass; sink rank=8; rank(P)=rank(U)={rcount}; rank(P_H)={high_rank}')
    print(f'{name}: preserved unique circuit, both 7D coefficients nonzero; distinct input charts; all X-avoiding paths sum to zero')
    return H0, lows


# Start from inherited three 7D depots. Retime each to 6D, then create and
# retime one further 7D depot. Both steps preserve its complete transfer.
net = p['net']
for _ in range(3):
    net = p['retime_depot_7_to_6'](net)
check('three six-depot equality',net,(0,0,6,56),0,rcount=3)
net = p['third_low_depot'](net)
net = p['retime_depot_7_to_6'](net)
_, lows = check('four-six equality', net, (0,0,8,56), 0)

# Destroy a required relay and independently recompute odd cells, then restore.
d = lows[-1]
x = next(x for x in range(d) if net['H'][d][x])
damaged = [list(row) for row in net['H']]
damaged[d][x] = Q(0)
errors = p['odd_transfer_errors'](net,damaged)
assert errors and any(i==j for i,j,_ in errors)
assert not p['odd_transfer_errors'](net,net['H'])
print(f'negative control: deleting ({x},{d}) breaks {len(errors)} odd cells including diagonals; original passes')

relay,u,z,v,coefficient = r['add_relay_preserving_full_transfer'](net)
H0,_ = check('four-six with relay',relay,(1,0,8,57),1)
assert coefficient and relay['H'][z][u] and relay['H'][v][z]
errors = p['odd_transfer_errors'](relay,H0)
assert errors and any(i==j for i,j,_ in errors)
print(f'relay control: sinking without G adjustment breaks {len(errors)} odd/diagonal cells')
# The same explicit retiming gives equality controls for r=5,6,7,8 as well.
for nlow in range(5,9):
    net = p['third_low_depot'](net)
    net = p['retime_depot_7_to_6'](net)
    check(f'{nlow} six-depot equality',net,(0,0,2*nlow,56),0,rcount=nlow)
print('ALL FOUR-SIX AND FIVE-TO-EIGHT P104 EXAMPLE CONTROLS PASSED')
