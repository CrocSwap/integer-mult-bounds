#!/usr/bin/env python3
"""Export the exact four-low P104 witness and reference data as JSON."""
import contextlib
import io
import json
from pathlib import Path
import runpy
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):
    old = runpy.run_path(str(HERE/'prior'/'check_two_six.py'))
    p,s = old['p'],old['s']
    net = p['net']
    for _ in range(3):
        net = p['retime_depot_7_to_6'](net)
    net = p['third_low_depot'](net)
    net = p['retime_depot_7_to_6'](net)
convert = lambda matrix: [[str(x) for x in row] for row in matrix]
output = {
    'schema': 'p104-four-six-exact-witness-v1',
    'meaning': 'F,G,H and target_gram are exact rational strings; a,b are GF(2) basis-vector bitmasks; labels are GF(2) bitmasks',
    'a': net['a'], 'b': net['b'],
    'F': convert(net['F']), 'G': convert(net['G']), 'H': convert(net['H']),
    'labels': s['labels'], 'target_gram': convert(s['M0']),
    'source': 'deterministic retiming of #7942 carried #7916 exact fixture',
}
print(json.dumps(output,sort_keys=True,indent=2))
