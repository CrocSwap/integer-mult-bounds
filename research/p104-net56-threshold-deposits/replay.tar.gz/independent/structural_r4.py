#!/usr/bin/env python3
"""Independent finite support screen of the r=4 equality-case chart blocks.

The reduction from P104 to these finite patterns is a paper hypothesis here.
All gateway coefficients are arbitrary: a transversal is only an upper bound
on the rank of a matrix with the corresponding allowed zero pattern.  For a
rank-three high space, every low basis vector that can extend the high space
must lie in one chart block. This script screens all equality-case blocks and
allowed gateway supports; it does not enumerate P104 networks.
"""
from itertools import product, combinations
from collections import Counter
from fractions import Fraction
import json


def partitions(n):
    """Restricted-growth encodings enumerate all labelled set partitions."""
    if not n:
        yield ()
        return
    def rec(prefix):
        if len(prefix) == n:
            yield tuple(prefix)
            return
        for block in range(max(prefix) + 2):
            yield from rec(prefix + [block])
    yield from rec([0])


def transversal(rows):
    """Is there an injection from rows to allowed column positions?"""
    rows = sorted(rows, key=len)
    def find(i, used):
        if i == len(rows):
            return True
        return any(find(i+1, used | {v}) for v in rows[i] if v not in used)
    return find(0, set())


def rational_rank(rows):
    a = [[Fraction(x) for x in row] for row in rows]
    i = 0
    for j in range(len(a[0])):
        p = next((v for v in range(i, len(a)) if a[v][j]), None)
        if p is None:
            continue
        a[i],a[p] = a[p],a[i]
        t = a[i][j]
        a[i] = [x/t for x in a[i]]
        for z in range(i+1, len(a)):
            t = a[z][j]
            a[z] = [x-t*y for x,y in zip(a[z],a[i])]
        i += 1
        if i == len(a):
            break
    return i

out = {}
for high_terminal_count in range(4):
    # r=4, equality T=7: a high terminals, 3-a high gateways,
    # 4-a low terminals. Pass to the quotient by high terminals.
    a = high_terminal_count
    gateways = 3-a
    size = 4-a
    totals = Counter()
    for chart in partitions(size):
        block_sets = [{i for i in range(size) if chart[i] == j}
                      for j in range(max(chart)+1)]
        # A gateway's projected terminal vector may be zero, or its support
        # may be any subset of one chart block. We over-approximate it by the
        # entire block and independently over-approximate every rank query.
        for choice in product(range(-1, len(block_sets)), repeat=gateways):
            rows = [set() if j == -1 else block_sets[j] for j in choice]
            totals['patterns'] += 1
            if not transversal(rows):
                totals['high_rank_structurally_impossible'] += 1
                continue
            totals['high_rank_structurally_possible'] += 1
            extends = [transversal(rows + [{i}]) for i in range(size)]
            distinct_pairs = [(i,j) for i,j in combinations(range(size), 2)
                              if chart[i] != chart[j]]
            totals['distinct_block_pairs'] += len(distinct_pairs)
            for i,j in distinct_pairs:
                totals['independent_extension_checks'] += 1
                if extends[i] and extends[j]:
                    totals['violations'] += 1
    out[str(a)] = dict(sorted(totals.items()))
    assert totals['violations'] == 0, (a, totals)

# Mutation: omit the forced same-chart condition on a single gateway row.
# Two distinct singleton blocks, one gateway u=e0+e1. Both low directions
# are outside W=span(u), and e0+e1-u=0 has nonzero low coefficients.
u = [1,1]; low0 = [1,0]; low1 = [0,1]
assert rational_rank([u]) == 1
assert rational_rank([u,low0]) == rational_rank([u,low1]) == 2
assert [x+y-z for x,y,z in zip(low0,low1,u)] == [0,0]

result = {
    'status': 'PASS_R4_REDUCED_CHART_BLOCK_STRUCTURAL_SCREEN',
    'case_counts_by_high_terminal_count': out,
    'mutation': 'Dropping the single-chart gateway condition allows W=span((1,1)) and two distinct low blocks with nonzero relation.',
    'scope': 'All equality-case set partitions and over-approximated gateway zero patterns after the asserted original P104/sink/rank reduction; not a P104 network enumeration, proof of rigidity, bridge, Lean theorem, or kappa improvement.',
}
print(json.dumps(result, indent=2, sort_keys=True))
