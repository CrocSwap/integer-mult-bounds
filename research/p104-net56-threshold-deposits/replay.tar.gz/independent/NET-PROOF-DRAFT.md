# Four six-dimensional P104 depositors: threshold cuts and chart blocks

**Status:** paper proof with exact finite controls, not a Lean theorem or a
word-level result. It extends the first-depositor sink and original-network
rigidity used in [#7942 at `fab4bbc1a2a4a94ff8bac3458de8ad52787801f9`](https://github.com/CrocSwap/integer-mult-bounds/pull/7942),
under the P104 `NetW` model and results of [#7852 at
`41beda1d6435760dc99e38bd7e65f36798aad212`](https://github.com/CrocSwap/integer-mult-bounds/pull/7852).
The proof and controls permit signed rational path cancellation and arbitrary
chronological depositor relays. Two independent paper readers found no internal
gap subject to the source rigidity and bridge premises; see the separate
review report and finite structural screen below.

## Claim

Consider a P104 `NetW` with `b_j ⊆ a_j` at all nodes, exactly nine active
gatherers of input dimensions `7,7,≥8,≥8,≥8,≥8,≥8,≥8,≥8`, and exactly
eight active depositors, precisely four with 6D input and four with input
dimension at least 8. Write

* `T = Σ_non-depositors (dim a_j − dim b_j)`;
* `E = Σ_depositors max(dim a_j − 8, 0)`; and
* `B = #{depositors j : dim b_j = 0}`.

The argument below gives **T ≥ 8 and D = 48 + E + B + T ≥ 56 + E + B**.
There is no depositor antichain condition. An exact finite P104 witness with
`E=B=0`, `T=8`, `D=56` makes the bound sharp in this network profile;
a second witness has a genuine depositor relay with `E=1`, `T=8`, `D=57`.
Both controls use the inherited #7916 fixture and checker, and are not
claimed to arise from legal words. The same exact retiming construction
checks equality for r=5,6,7,8; inherited controls also check r=1,2,3.

The same chart-block argument works for each `1≤r≤8` 6D depositors and
`8-r` depositors of input dimension at least 8: `T≥2r`, so
`D=56−2r+E+B+T≥56+E+B`. Its hypotheses still include the same original
nine-gatherer P104 geometry, the original eight-depositor rigidity and
nested charts. It is not a proof for arbitrary P104 profiles.

## Original P104 facts and first-depositor sink

Let S be the nine gatherers, Q the eight depositors, H the chronological
edge matrix, and `N=(I−H)^−1`. Before changing the network, the P104 odd-cell
condition, eight-depositor factorization, and eight-row rigidity give
`C=N[Q,S]` row rank 8, each depositor output dimension at most 1, and a
one-dimensional kernel of C whose coefficients at both 7D gatherers are
nonzero. The two 7D gatherer input charts are distinct.

Set every edge leaving a depositor to zero, and call the resulting inverse
`N0=(I−H0)^−1`, with `C0=N0[Q,S]`. A path classified at its first depositor,
including length-zero paths, gives `C=A C0` with `A=N[Q,Q]` unit lower
triangular. Thus C0 has rank 8 and the same one-dimensional column kernel.
The sink graph is auxiliary and need not satisfy the odd-cell condition;
original P104 rigidity is applied only before sinking. Gatherers which are
depositors have no outgoing edges after sinking.

Let L denote the r six-dimensional depots (`r=4` for the main claim) and
`P=C0[L,S]`. Its r rows are independent. If `P_H` denotes its seven columns
from the ≥8D gathers, the preserved circuit makes the images of the two 7D
columns in the quotient by `im(P_H)` linearly dependent. Thus

```
rank P = r,     rank P_H ≥ r−1.                          (1)
```

Let X be all positive-drop nondepositors and `δ_x=dim a_x−dim b_x≥1`. Every
S-to-L path meets X: otherwise zero-drop support propagation puts a gather
input chart of dimension ≥7 inside a 6D depot input chart. Length-zero
prefixes are included when a gatherer belongs to X. Define signed rational
path-sum matrices U, K, J by successively cutting at X: `U[d,x]` sums x→d
paths with no other X vertex; `K[y,x]` sums x→y paths with no other X
vertex; `J[x,g]` sums g→x paths with no other X vertex. Chronology makes K
strictly lower triangular, and

```
P = U (I−K)^−1 J,     rank U = r.                         (2)
```

Call x **terminal** if its U column is nonzero. A nonzero terminal column
witnesses a support path through zero-drop nodes to a 6D depot, so
`dim a_x≤6+δ_x`. Call x **high** if `dim a_x≥8`. Nonzero J from a high
gatherer requires a high first X vertex. Full signed downstream path vectors
`t_x=N0[L,x]` therefore give

```
im(P_H) ⊆ span{t_x : x is high}.                          (3)
```

If K[y,x] is nonzero, at least one corresponding support path exists, so
`b_x⊆a_y`. No nonzero sum is inferred just from reachability. We use the
exact rational identity

```
t_x = U[:,x] + Σ_y K[y,x] t_y.                            (4)
```

## Threshold count and all cases through seven

Write m for the number of terminals and h for the number of high X vertices.
Equations (1)–(3) imply `m≥r` and `h≥r−1`. Every terminal costs at least one
drop. Every high vertex costs at least one further drop: if high and
terminal, `dim a_x≥8` and `dim a_x≤6+δ_x` imply `δ_x≥2`; otherwise its own
positive drop pays that unit. Hence

```
T ≥ m+h ≥ 2r−1.                                          (5)
```

For r=4 this immediately excludes T≤6. If T=7 then every inequality in (5)
is equality. There are exactly four terminals and three high vertices, no
other positive-drop vertices, each high terminal has δ=2, and every other
X vertex has δ=1. If a of the high vertices are terminals, then `a=0,1,2,3`.
The **complete** four positive-drop partitions, with terminal status further
constrained as above, are

```
a=3:  2+2+2+1
a=2:  2+2+1+1+1
a=1:  2+1+1+1+1+1
a=0:  1+1+1+1+1+1+1.
```

The following argument rules out every one of them simultaneously, for all
chronological orders and rational coefficients. More generally suppose
`T=2r−1` for any `1≤r≤8`. Equality gives r terminal vertices Y, r−1 high
vertices H, and no X vertices outside `Y∪H`; high terminals have drop 2,
and all others drop 1. Rank U makes the r terminal columns `U[:,Y]` a
basis. Because `(I−K)^−1[Y,Y]` is unit lower triangular, the r **full**
path vectors `t_y`, y∈Y, also form a basis, even when paths between them
visit high nonterminals.

Set `W=span{t_h:h∈H}` and `W0=span{t_h:h∈H∩Y}`. By (1), (3), and
`|H|=r−1`, W has dimension r−1 and contains `im(P_H)`; the high t vectors
are independent. Work in `V/W0`, with `V=Q^r`. Images of the remaining
terminal vectors form a basis. Each remaining terminal has drop one and
input dimension at most 7. Partition that basis into blocks by equal actual
input chart `a_y` (including a block for every distinct chart of dimension
below 7 if present).

A nonterminal high vertex z has drop one, so `dim b_z≥7`. Whenever
`K[y,z]≠0` for a non-high terminal y, support propagation gives
`b_z⊆a_y`; since `dim a_y≤7`, both charts are the same 7D chart. Define

```
u_z = Σ_(y∈Y\H) K[y,z] (t_y mod W0).
```

Thus each u_z lies within a **single** chart block, or is zero. From (4),
`t_z mod W0` equals u_z plus a combination of later nonterminal high
vectors. Chronological triangular elimination in both directions yields

```
W/W0 = span{u_z : z∈H\Y}.                                (6)
```

The right side is a direct sum of its intersections with the chart blocks,
because every generator lies in one block. Since W has codimension one in
V and contains W0, `(V/W0)/(W/W0)` is one-dimensional. Consequently at most
one chart block has a nonzero image modulo W.

For either 7D gatherer g, partition its paths at first X. First contacts in H
contribute in W. A first contact y in `Y\H` is possible only when `a_y`
equals g's 7D input chart; all such contributions lie in that one chart
block. The two gather charts are distinct, so at most one of their P
columns can have nonzero image modulo W. Their preserved relation has both
low coefficients nonzero and all high terms already in W; it therefore
forces both low columns into W. Every column of P lies in W, contradicting
`rank P=r`. Thus equality in (5) is impossible and `T≥2r`, including
`T≥8` for r=4.

## Accounting and word boundary

Original-network rigidity gives each depositor `dim b_d≤1`. For r 6D and
8−r at-least-8D depositor inputs, the depositor part of D is
`56−2r+E+B`; adding T gives the displayed bound. This paper argument uses
the conditional P104 network hypotheses and does not establish a universal
NET-D56 bound, a rise bound, or a κ improvement. A word-level conclusion
also requires the existing P104 word-to-network bridge, its hypotheses,
and proof that the induced network actually has this exact gather/depositor
profile and nested charts. No such bridge application is shown here.

## Controls

`check_four_six.py` runs inherited #7916 checks and then constructs and
checks the three-through-eight-low exact witnesses and the genuine-relay
four-low witness. It verifies
original full Gram and all odd/diagonal cells, nested charts and causal
support via the inherited verifier, the sink identity, unique circuit,
distinct 7D charts, `rank(P)=rank(U)=4`, `rank(P_H)≥3`, threshold counts,
and D/E/B/T. A mutation must break the original transfer, and simply sinking
the relay without adjusting G must fail. `check_chart_control.py` is a
separate tiny exact F₂-chart DAG with T=7, `rank(P)=4`, `rank(P_H)=3`, two
distinct 7D source charts and cancellation. Its unique relation has a zero
coefficient on one low source, so it is **not** a P104 counterexample; it
checks the role of the nonzero-low condition. `check_partition.py` enumerates
all positive partitions through seven using only the counting inequalities.
These finite checks do not prove the paper argument or exhaust networks.

Run from this directory:

```
(cd prior && sha256sum -c SHA256SUMS)
python3 -B check_four_six.py
python3 -B check_chart_control.py
python3 -B check_partition.py
```

The included `PARENT-SOURCES.json` is byte-identical to the file fetched
from #7942 at the pinned head (git blob
`044197580d66f63cb0182444c90c376b2bc7673a`). Its expected #7942
`replay.tar.gz` digest is
`54feafc8d6f721f53a93e5e019864ce568d92d553181598545408ea325d3756c`,
which the included `parent-7942-replay.tar.gz` matches. The parent archive's
manifest checks and its `prior/` matches our `prior/` byte for byte.
Original P104 authorship and Apache-2.0 notices are preserved in
`prior/source/NOTICE-P104.md` and `prior/source/LICENSE-7852`.
