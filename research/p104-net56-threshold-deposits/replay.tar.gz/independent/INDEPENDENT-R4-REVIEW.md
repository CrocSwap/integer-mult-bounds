# Independent review of the four-depositor cut

The paper proof snapshot reviewed is `NET-PROOF-DRAFT.md` with SHA-256
`5a33e2ab35b8281ecee0b0004b3abbff6a510a14d06a2531fead6baa9ce9b92d`.
Within the stated P104 NetW model, nested charts, and the original
nine-gatherer/eight-depositor profile, I found no internal gap in the
claimed `T >= 2r` deduction for `1 <= r <= 8`, conditional on the cited
original rigidity and label data. This is a paper review, not a Lean proof,
an enumeration of networks, a word-bridge application, or a kappa result.
I did not rebuild the inherited Lean dependencies or independently validate
the newly reported r=4..8 fixtures.

The eight-depositor odd-clique factorization forces `rank C=8`; the
first-depositor path partition gives `C=A C0` with unit-triangular A, hence
preserves the rank and the unique column kernel. The submatrix of the r
six-dimensional depositor rows therefore has rank r. The two low gatherer
coefficients in the preserved kernel imply that the seven high gatherer
columns have rank at least r-1.

For completeness, the two cited low-gatherer circuit consequences follow
from the original eight-row decoder rigidity: if either low-gatherer kernel
coefficient were zero, eliminate a different nonzero-coefficient column and
obtain an eight-row decoder retaining its original F row, whose support lies
in a 7D chart; if the two low charts were equal, eliminate one low column
and combine the two low F rows, which still has support in that 7D chart.
Either contradicts the 8D lower bound on a decoder gathering row. This
uses rigidity on the original transfer, not the sinked auxiliary graph.
`Net8.lean` at #7852 also states `dep_dim` for eight depositors; the source
was inspected but Lean was not rerun.

For the threshold, if m positive-drop vertices have nonzero terminal path
columns and h have input dimension at least 8, then `m >= r`, `h >= r-1`,
and each high terminal costs a second drop, so `T >= m+h >= 2r-1`. At
hypothetical equality there are exactly r terminals and r-1 high vertices,
and the full terminal path vectors form a basis. Modulo the high terminals,
chronological elimination turns each remaining high vector into a vector
supported in one forced 7D chart block. Their span therefore splits by chart
blocks. Its codimension one leaves at most one block with nonzero quotient;
the two distinct low gatherer charts and the preserved nonzero two-low
relation then contradict the rank-r requirement. This reasoning uses signed
path sums and needs no assumption that a nonzero support path sum follows
from mere reachability.

`structural_r4.py` independently checks the reduced r=4 equality case. It
exhausts 759 labelled chart-partition/gateway-support patterns for the four
possible high-terminal counts. Of these, 151 can structurally have full high
rank; in 662 distinct-chart extension-pair tests no two different chart
blocks can both extend it. A transversal is only a necessary rank condition,
so the checker grants each gateway its entire chart block and over-approximates
each extension separately. The conclusion thus covers arbitrary rational
coefficients, including cancellation, within the reduced zero-pattern model.
A mutation dropping the single-chart support restriction gives the explicit
countermodel `W=span((1,1))` with two distinct low blocks. The result and
script are `structural-r4-result.json` and `structural_r4.py`; neither checks
the P104-to-reduced-model proof, the full-network space, or a word bridge.
