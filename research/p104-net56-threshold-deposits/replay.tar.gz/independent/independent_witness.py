#!/usr/bin/env python3
"""Independent check of exported 4x6D P104 network, not its constructor."""
from pathlib import Path
from fractions import Fraction as Q
from hashlib import sha256
import json
P=Path(__file__).resolve().parent/'inputs'
raw=(P/'FOUR-SIX-WITNESS.json').read_bytes()
rootsraw=(P/'P104-ROOTS.json').read_bytes()
assert sha256(raw).hexdigest()=='f6cc7b62deff46a441cb0ce4bfa701f3aed08e5b3a3f176ca514e949d16639b4'
assert sha256(rootsraw).hexdigest()=='2693077172c0e3036fdc293f1d8d71d5f20830a3eb2a88c0cc4fc0623e6310b7'
w=json.loads(raw); root=json.loads(rootsraw)
labels=root['labs'];assert labels==w['labels'] and len(set(labels))==104
vecs=[[((c>>(3*i))&7)-2 for i in range(8)] for c in root['rootCode']]
assert len(vecs)==104 and all(sum(x*x for x in v)==8 for v in vecs)
F=[[Q(x) for x in row] for row in w['F']]; G=[[Q(x) for x in row] for row in w['G']]
H=[[Q(x) for x in row] for row in w['H']]; A=w['a']; B=w['b'];n=len(A)
assert n==len(B)==len(F)==len(H)==18 and len(G)==104
assert all(len(row)==104 for row in F) and all(len(row)==n for row in H+G)

def binary_basis(rows):
 p={}
 for x in rows:
  while x:
   k=x.bit_length()-1
   if k not in p:p[k]=x;break
   x^=p[k]
 return p

def contains(rows,v):
 p=binary_basis(rows)
 while v:
  k=v.bit_length()-1
  if k not in p:return False
  v^=p[k]
 return True

def rr(matrix):
 z=[list(map(Q,row)) for row in matrix];m=len(z); cols=len(z[0]) if m else 0; pivot=[];i=0
 for j in range(cols):
  r=next((k for k in range(i,m) if z[k][j]),None)
  if r is None:continue
  z[i],z[r]=z[r],z[i];s=z[i][j];z[i]=[x/s for x in z[i]]
  for k in range(m):
   if k!=i and z[k][j]:
    s=z[k][j];z[k]=[x-s*y for x,y in zip(z[k],z[i])]
  pivot.append(j);i+=1
  if i==m:break
 return z,pivot

def paths(H):
 n=len(H);N=[[Q(int(i==j)) for j in range(n)] for i in range(n)]
 for i in range(n):
  for j in range(i):N[i][j]=sum((H[i][k]*N[k][j] for k in range(i)),Q(0))
 return N

def multiply(X,Y):
 return [[sum((a*b for a,b in zip(row,col)),Q(0)) for col in zip(*Y)] for row in X]

ad=[len(binary_basis(v)) for v in A];bd=[len(binary_basis(v)) for v in B]
assert all(all(contains(A[i],x) for x in B[i]) for i in range(n))
assert all(not F[i][p] or contains(A[i],labels[p]) for i in range(n) for p in range(104))
assert all(not G[p][i] or all((labels[p]&v).bit_count()%2==0 for v in B[i]) for p in range(104) for i in range(n))
assert all(not H[i][j] or (j<i and all(contains(A[i],v) for v in B[j])) for i in range(n) for j in range(n))
gather=[i for i in range(n) if any(F[i])];dep=[i for i in range(n) if any(G[p][i] for p in range(104))]
assert len(gather)==9 and len(dep)==8
assert sorted(ad[i] for i in gather)==[7,7,8,8,8,8,8,8,8]
lowg=[i for i in gather if ad[i]==7];assert len(lowg)==2 and len(binary_basis(A[lowg[0]]+A[lowg[1]]))>=8
lowdep=[i for i in dep if ad[i]==6];assert len(lowdep)==4 and all(ad[i]>=8 for i in dep if i not in lowdep)
D=sum(a-b for a,b in zip(ad,bd));E=sum(max(ad[i]-8,0) for i in dep);BB=sum(bd[i]==0 for i in dep)
X=[i for i in range(n) if i not in dep and ad[i]>bd[i]];T=sum(ad[i]-bd[i] for i in X)
assert (E,BB,T,D)==(0,0,8,56) and all(bd[i]<=1 for i in dep)
N=paths(H);C=[[N[i][j] for j in gather] for i in dep]
M=multiply(multiply(G,N),F)
# Independently decode pinned rootCode values and reconstruct the exact Gram.
gram=[[Q(sum(a*b for a,b in zip(x,y)),8) for y in vecs] for x in vecs]
assert M==gram==[[Q(x) for x in row] for row in w['target_gram']]
odd_checks=0
for i in range(104):
 for j in range(104):
  if (labels[i]&labels[j]).bit_count()%2:
   odd_checks+=1;assert M[i][j]==int(i==j)
H0=[[Q(0) if j in dep else x for j,x in enumerate(row)] for row in H];N0=paths(H0)
C0=[[N0[i][j] for j in gather] for i in dep]
tri=[[N[i][j] for j in dep] for i in dep]
assert multiply(tri,C0)==C
rc,piv=rr(C0);assert len(piv)==8
assert len(rr(C)[1])==8
free=next(x for x in range(9) if x not in piv);kernel=[Q(0)]*9;kernel[free]=1
for i,pivcol in enumerate(piv):kernel[pivcol]=-rc[i][free]
assert all(sum((C0[i][j]*kernel[j] for j in range(9)),Q(0))==0 for i in range(8))
assert all(kernel[gather.index(x)] for x in lowg)
Psub=[[N0[d][g] for g in gather] for d in lowdep]
PH=[[row[gather.index(g)] for g in gather if ad[g]>=8] for row in Psub]
assert len(rr(Psub)[1])==4 and len(rr(PH)[1])>=3
# Independent terminal last-X path sums: suppress all other X vertices.
U=[[Q(0) for _ in X] for _ in lowdep]
for col,x in enumerate(X):
 path=[Q(0)]*n;path[x]=1
 for i in range(x+1,n):
  if i not in X:path[i]=sum((H0[i][j]*path[j] for j in range(i)),Q(0))
 for k,d in enumerate(lowdep):U[k][col]=path[d]
assert len(rr(U)[1])==4
# Negative control: remove real relay (12,13), count original odd equations broken.
assert H[13][12]
Hbad=[row[:] for row in H];Hbad[13][12]=0
MB=multiply(multiply(G,paths(Hbad)),F)
violations=[(i,j) for i in range(104) for j in range(104) if (labels[i]&labels[j]).bit_count()%2 and MB[i][j]!=int(i==j)]
assert len(violations)==1462 and any(i==j for i,j in violations)
print(json.dumps({'status':'PASS_INDEPENDENT_FOUR_SIX_P104_WITNESS',
 'witness_sha256':sha256(raw).hexdigest(),'root_fixture_sha256':sha256(rootsraw).hexdigest(),
 'node_count':n,'gatherers':gather,'depositors':dep,'six_dim_depositors':lowdep,
 'E':E,'B':BB,'T':T,'D':D,'full_gram_entries_checked':104*104,'odd_entries_checked':odd_checks,
 'sink_rank':len(piv),'low_rank':len(rr(Psub)[1]),'low_high_gather_rank':len(rr(PH)[1]),'terminal_rank':len(rr(U)[1]),
 'circuit_low_coefficients':[str(kernel[gather.index(x)]) for x in lowg],
 'broken_relay_negative_control_odd_cells':len(violations),
 'scope':'Direct independent arithmetic/support verification of exported 18-node network. The construction/fixture is inherited; this is not an exhaustive P104 search, a proof for all networks, legal-word realization or kappa improvement.'},indent=2,sort_keys=True))
