#!/usr/bin/env python3
"""Enumerate the r=4 T<=7 positive-drop accounting cases exactly."""
from itertools import combinations


def partitions(n, limit=None):
    if not n:
        yield ()
    else:
        for i in range(min(n,limit or n),0,-1):
            for tail in partitions(n-i,i):
                yield (i,)+tail

survivors=[]
for T in range(1,8):
    for part in partitions(T):
        k=len(part)
        for terminals in combinations(range(k),4):
            for high in combinations(range(k),3):
                # A high terminal needs two units. All other nodes need one.
                if all(part[i]>=2 for i in set(terminals)&set(high)):
                    survivors.append((T,part,len(set(terminals)&set(high))))
                    assert T==7
                    assert set(terminals)|set(high)==set(range(k))
                    assert all(part[i] == (2 if i in set(terminals)&set(high) else 1) for i in range(k))
observed=sorted(set((p,a) for _,p,a in survivors),reverse=True)
expected=sorted([((2,2,2,1),3),((2,2,1,1,1),2),((2,1,1,1,1,1),1),((1,1,1,1,1,1,1),0)],reverse=True)
assert observed==expected,(observed,expected)
print('all accounting survivors T<=7:',observed)
print('these are necessary equality patterns; chart-block proof excludes them')
print('ALL PARTITION ACCOUNTING CONTROLS PASSED')
