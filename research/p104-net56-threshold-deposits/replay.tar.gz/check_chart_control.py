#!/usr/bin/env python3
"""Independent exact synthetic chart/path controls, NOT P104 networks."""
from fractions import Fraction as Q


def echelon(vs):
    piv = {}
    for v in vs:
        while v:
            p = v.bit_length()-1
            if p in piv:
                v ^= piv[p]
            else:
                piv[p] = v
                break
    return list(piv.values())


def contains(a,v):
    return len(echelon(a+[v])) == len(echelon(a))


def rank(m):
    a = [[Q(x) for x in row] for row in m]
    if not a:
        return 0
    h,w,r = len(a),len(a[0]),0
    for j in range(w):
        q = next((i for i in range(r,h) if a[i][j]),None)
        if q is None:
            continue
        a[r],a[q] = a[q],a[r]
        z = a[r][j]
        a[r] = [v/z for v in a[r]]
        for i in range(h):
            if i != r:
                z = a[i][j]
                a[i] = [x-z*y for x,y in zip(a[i],a[r])]
        r += 1
        if r == h:
            break
    return r


C = [1<<i for i in range(6)]
A = C+[1<<6]
B = C+[1<<7]
AB = C+[1<<6,1<<7]
# low-A, low-B; three high gateways; two zero-drop A bridges;
# terminals B,A1,A2,A3; four low sinks.
a = [A,B,AB,AB,AB,A,A,B,A,A,A,C,C,C,C]
b = [A,B,A,B,A,A,A,C,C,C,C,[],[],[],[]]
H = [[Q(0) for _ in a] for _ in a]
for v,u,w in [(2,0,1),(3,1,1),(5,2,1),(6,2,1),
              (8,2,2),(8,5,1),(8,6,-1),(9,2,-3),
              (7,3,Q(5,2)),(10,4,Q(7,3)),
              (11,7,1),(12,8,1),(13,9,1),(14,10,1)]:
    H[v][u] = Q(w)
assert len(echelon(A)) == len(echelon(B)) == 7 and len(echelon(A+B)) == 8
assert all(contains(a[i],x) for i in range(len(a)) for x in b[i])
assert all(u<v and all(contains(a[v],x) for x in b[u])
           for v in range(len(a)) for u in range(len(a)) if H[v][u])
assert sum(len(echelon(a[i]))-len(echelon(b[i])) for i in range(11)) == 7
N = [[Q(0) for _ in a] for _ in a]
for i in range(len(a)):
    for j in range(i+1):
        N[i][j] = Q(i==j)+sum((H[i][k]*N[k][j] for k in range(i)),Q(0))
assert H[8][5]*H[5][2]+H[8][6]*H[6][2] == 0
sinks = [11,12,13,14]

def P(sources):
    return [[N[d][g] for g in sources] for d in sinks]

def annihilates(mat,v):
    return all(sum((x*y for x,y in zip(row,v)),Q(0)) == 0 for row in mat)

# Two actual 7D source charts are distinct. In this selection the unique
# relation has low-A coefficient zero, which the original P104 circuit forbids.
neg = P([2,3,4,8,7])
assert neg == [[0,Q(5,2),0,0,1],[2,0,0,1,0],[-3,0,0,0,0],[0,0,Q(7,3),0,0]]
assert rank(neg)==4 and rank([row[:3] for row in neg])==3
relation = [Q(0),Q(-2,5),Q(0),Q(0),Q(1)]
assert annihilates(neg,relation) and relation[-2] == 0 and relation[-1] != 0
print('T=7 synthetic, two distinct 7D charts: rank(P)=4, rank(P_H)=3')
print('unique relation:', [str(x) for x in relation], '(one low coefficient zero)')

# Same graph: distinct 7D input sources 0 and 1 feed high gateways. Both
# low coefficients can be nonzero in a relation, but then the P rank is 3.
pos = P([2,3,4,0,1])
relation2 = [Q(1),Q(1),Q(0),Q(-1),Q(-1)]
assert rank(pos)==rank([row[:3] for row in pos])==3
assert relation2[-2] and relation2[-1] and annihilates(pos,relation2)
print('nonzero-low relation control:', [str(x) for x in relation2], 'rank(P)=3')
print('both variants include two exactly cancelling bridge paths; neither is a P104 counterexample')
print('ALL SYNTHETIC CHART CONTROLS PASSED')
