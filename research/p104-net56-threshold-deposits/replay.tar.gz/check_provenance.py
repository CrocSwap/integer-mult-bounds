#!/usr/bin/env python3
"""Check pinned #7942 archive and its carried #7916 prior without extraction."""
import hashlib
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

src = (HERE/'PARENT-SOURCES.json').read_bytes()
readme = (HERE/'PARENT-README.md').read_bytes()
assert git_blob(src) == '044197580d66f63cb0182444c90c376b2bc7673a'
assert git_blob(readme) == '3d22743651e37f7ecfe565ca3130f8a964c9c471'
source = json.loads(src)
assert sha256(readme) == source['archive_file_sha256']['README.md']
archive = HERE/'parent-7942-replay.tar.gz'
assert sha256(archive.read_bytes()) == source['archive_file_sha256']['replay.tar.gz']
with tarfile.open(archive,'r:gz') as tar:
    files = {m.name.removeprefix('./'):m for m in tar if m.isfile()}
    def contents(name):
        f=tar.extractfile(files[name])
        assert f is not None
        return f.read()
    for line in contents('SHA256SUMS').decode().splitlines():
        digest, path = line.split(maxsplit=1)
        assert sha256(contents(path.lstrip('*'))) == digest, path
    parent_prior = {p for p in files if p.startswith('prior/')}
    local_prior = {str(p.relative_to(HERE)) for p in (HERE/'prior').rglob('*') if p.is_file()}
    assert parent_prior == local_prior, (parent_prior-local_prior,local_prior-parent_prior)
    for path in parent_prior:
        assert (HERE/path).read_bytes() == contents(path),path
print('pinned #7942 source/readme git blobs match; parent archive SHA-256 and internal manifest match')
print('all',len(parent_prior),'inherited prior files match the parent archive byte-for-byte')
print('ALL PARENT PROVENANCE CHECKS PASSED')
