#!/usr/bin/env python3
"""Build a complete checksummed portable archive of the scientific packet."""
import gzip
import hashlib
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
archive = root/'p104-net-four-six-depots.tar.gz'
exclude_dirs = {'cold', 'archive-cold', '__pycache__'}

def scientific_files():
    return sorted(p for p in root.rglob('*') if p.is_file()
        and not any(part in exclude_dirs for part in p.relative_to(root).parts)
        and p not in {root/'SHA256SUMS', archive})

files = scientific_files()
lines = [f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}\n" for p in files]
(root/'SHA256SUMS').write_text(''.join(lines))
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(mode='w', fileobj=compressed, format=tarfile.PAX_FORMAT) as tar:
            for p in files+[root/'SHA256SUMS']:
                info = tar.gettarinfo(str(p), arcname=p.relative_to(root).as_posix())
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                with p.open('rb') as data:
                    tar.addfile(info, data)
print('archive members:',len(files)+1)
print('archive sha256:',hashlib.sha256(archive.read_bytes()).hexdigest())
