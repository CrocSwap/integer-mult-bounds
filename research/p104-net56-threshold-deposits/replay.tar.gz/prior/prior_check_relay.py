#!/usr/bin/env python3
"""Exact P104 and synthetic controls for depositor-sink path elimination.

Imports the pinned, source-attributed previous P104 fixture and its verifier.
Only stdlib is used. The checks are finite examples, not a proof or D=55 search.
"""
from fractions import Fraction as Q
from pathlib import Path
import runpy
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
prev = runpy.run_path(str(HERE / 'source' / 'check_three_low.py'))
verify = prev['s']['verify']
echelon, contains = prev['echelon'], prev['contains']
rank, mul = prev['rank'], prev['mul']
odd_errors = prev['odd_transfer_errors']


def inverse_unit_lower(H):
    n = len(H)
    N = [[Q(0) for _ in range(n)] for _ in range(n)]
    for i in range(n):
        assert all(H[i][j] == 0 for j in range(i, n))
        for j in range(i + 1):
            N[i][j] = Q(i == j) + sum((H[i][k] * N[k][j] for k in range(i)), Q(0))
    return N


def sink_factor(H, dep, gat):
    n = len(H)
    D = set(dep)
    H0 = [[Q(0) if j in D else H[i][j] for j in range(n)] for i in range(n)]
    N, N0 = inverse_unit_lower(H), inverse_unit_lower(H0)
    A = [[N[d][z] for z in dep] for d in dep]
    C = [[N[d][g] for g in gat] for d in dep]
    C0 = [[N0[d][g] for g in gat] for d in dep]
    assert all(A[i][i] == 1 and all(A[i][j] == 0 for j in range(i + 1, len(dep)))
               for i in range(len(dep)))
    assert mul(A, C0) == C
    assert rank(C) == rank(C0)
    assert all(N0[d][z] == Q(d == z) for d in dep for z in dep)
    return H0, N, N0, A, C, C0


def kernel_one(M):
    z = [list(map(Q, row)) for row in M]
    m, n = len(z), len(z[0])
    pivots = []
    for j in range(n):
        r = len(pivots)
        pivot = next((i for i in range(r, m) if z[i][j]), None)
        if pivot is None:
            continue
        z[r], z[pivot] = z[pivot], z[r]
        a = z[r][j]
        z[r] = [x / a for x in z[r]]
        for i in range(m):
            if i != r and z[i][j]:
                a = z[i][j]
                z[i] = [x - a*y for x,y in zip(z[i],z[r])]
        pivots.append(j)
        if len(pivots) == m:
            break
    free = [j for j in range(n) if j not in pivots]
    assert len(free) == 1
    x = [Q(0)] * n
    x[free[0]] = Q(1)
    for r,j in reversed(list(enumerate(pivots))):
        x[j] = -sum((z[r][k] * x[k] for k in range(j+1,n)), Q(0))
    assert all(sum((v*w for v,w in zip(row,x)),Q(0)) == 0 for row in M)
    return x


def add_relay_preserving_full_transfer(net):
    # Source u is the 6D depositor, target v a later 8D depositor/gatherer.
    # Add u->z->v of weight 2/3; duplicate u's defining row at v with
    # coefficient -2/3, so v's complete effective input is unchanged.
    # Expand a_v from 8D to 9D to permit every new relay. This costs 1.
    n = len(net['a'])
    dep = [k for k in range(n) if any(row[k] for row in net['G'])]
    u = next(k for k in dep if len(echelon(net['a'][k])) == 6)
    v = next(k for k in dep if k > u and len(echelon(net['a'][k])) == 8
             and any(net['F'][k]) and not any(net['H'][k]))
    assert not any(net['H'][k][j] for j in dep for k in dep if j != k)
    assert not any(net['F'][u]) and any(net['H'][u])
    t = Q(2, 3)
    # Insert z immediately after u; retain every original ordered node.
    shift = lambda k: k if k <= u else k + 1
    z, us, vs = u + 1, shift(u), shift(v)
    aa = [list(x) for x in net['a'][:u+1]] + [list(net['b'][u])] + [list(x) for x in net['a'][u+1:]]
    bb = [list(x) for x in net['b'][:u+1]] + [list(net['b'][u])] + [list(x) for x in net['b'][u+1:]]
    aa[vs] = [1 << k for k in range(9)]
    F = [list(x) for x in net['F'][:u+1]] + [[Q(0)]*104] + [list(x) for x in net['F'][u+1:]]
    F[vs] = [F[vs][p] - t*net['F'][u][p] for p in range(104)]
    G = [list(row[:u+1]) + [Q(0)] + list(row[u+1:]) for row in net['G']]
    H = [[Q(0) for _ in range(n+1)] for _ in range(n+1)]
    for i in range(n):
        for j in range(n):
            H[shift(i)][shift(j)] = net['H'][i][j]
    for j in range(u):
        H[vs][shift(j)] -= t*net['H'][u][j]
    H[z][us] = Q(1)
    H[vs][z] = t
    return dict(a=aa,b=bb,F=F,G=G,H=H), us, z, vs, t


net, u, z, v, t = add_relay_preserving_full_transfer(prev['net67'])
M, gat, dep, drop, dims = verify('nonzero depositor-relay P104', net)
assert M == prev['s']['M0'] and drop == 57
assert sorted(dims[g][0] for g in gat) == [7,7,8,8,8,8,8,8,9]
assert sorted(dims[d][0] for d in dep if dims[d][0] < 8) == [6,7]
assert len(gat) == 9 and len(dep) == 8
E = sum(max(dims[d][0]-8, 0) for d in dep)
B = sum(dims[d][1] == 0 for d in dep)
T = sum(dims[k][0]-dims[k][1] for k in range(len(dims)) if k not in dep)
assert (E, B, T) == (1, 0, 3) and drop == 56 + E + B
R = prev['c']['reachability'](net['H'])
pairs = [(d,e) for d in dep for e in dep if d != e and e in R[d]]
assert pairs == [(u,v)] and net['H'][z][u] == 1 and net['H'][v][z] == t
H0, N, N0, A, C, C0 = sink_factor(net['H'], dep, gat)
assert N[v][u] == t and rank(C) == rank(C0) == 8
lam = kernel_one(C)
assert kernel_one(C0) == lam
lowg = [j for j,g in enumerate(gat) if dims[g][0] == 7]
assert len(lowg) == 2 and all(lam[j] for j in lowg)
assert all(N0[e][d] == Q(d == e) for d in dep for e in dep)
assert not odd_errors(net, net['H'])
errs = odd_errors(net, H0)
assert errs and any(s == p for s,p,_ in errs)
# Reconstruct the complete output transfer via G_D A C0 F_gat.
GD = [[net['G'][s][d] for d in dep] for s in range(104)]
Fgat = [net['F'][g] for g in gat]
assert mul(mul(mul(GD,A),C0),Fgat) == M
# G_D A need not have the required depositor support: test, not assumption.
GA = mul(GD,A)
labels, dot2 = prev['s']['labels'], prev['dot2']
violations = [(s,d) for s in range(104) for j,d in enumerate(dep)
              if GA[s][j] and any(dot2(labels[s], b) for b in net['b'][d])]
assert violations
print('REAL P104: D=57; 9 gathers, 8 depositors; depot dimensions 6/7; one comparable pair', pairs)
print('REAL P104: exact sharp accounting E=1, B=0, T=3, D=56+E+B')
print('REAL P104: pair passes through nondepositor', z, '; exact N[v,u] =', N[v][u])
print('REAL P104: all 104x104 original transfer cells equal pinned Gram transfer')
print('REAL P104: sinked C0 has rank 8, same one-dimensional kernel; both 7D coefficients nonzero')
print('REAL P104: retaining old G after sink deletion breaks', len(errs), 'odd/diagonal cells')
print('REAL P104: adjusted G_D A restores full transfer but violates', len(violations), 'depositor support cells')

# A separate synthetic rational DAG has several ordered depositor pairs,
# a cancelled nonempty 1->3 path sum, and a nonzero 1->6 path sum.
n = 10
H = [[Q(0) for _ in range(n)] for _ in range(n)]
for i,j,w in [(1,0,2),(2,1,1),(3,2,1),(3,1,-1),
              (4,1,Q(3,2)),(6,4,Q(2,3)),(5,3,1),(6,5,2),
              (7,3,4),(8,6,1),(9,8,Q(1,3))]:
    H[i][j] = Q(w)
dep = [1,3,6]
gat = [0,1,2,3,4,5,6,7,9]
H0, N, N0, A, C, C0 = sink_factor(H, dep, gat)
assert N[3][1] == 0 and N[6][1] == 1 and N[6][3] == 2
assert H[3][1] and H[3][2] and H[2][1]
assert rank(C) == rank(C0) == 3
assert all(C0[i][gat.index(d)] == Q(i == j)
           for i in range(len(dep)) for j,d in enumerate(dep))
print('SYNTHETIC: A C0=C under multiple ordered depositor pairs, signed cancellation,')
print('           rational paths, and each depositor also used as a gathering source')
print('ALL DEPOSITOR-SINK CONTROLS PASSED')
