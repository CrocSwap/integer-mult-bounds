#!/usr/bin/env python3
"""Synthetic chart-compatible rational DAG; not a P104 NetW example.

Three gathering sources equal the three positive-drop nodes. Two low source
charts are distinct 7D spaces. Two signed z->x paths have nonzero net sum;
x also reaches y, so the full transfer t_x differs from the last-cut U_x.
"""
from fractions import Fraction as Q

# z=0 is the high gather, w=1 a free relay, x=2 and y=3 the 7D gathers,
# d=4 and e=5 the two 6D depositor endpoints. All charts are F_2 subspaces.
z,w,x,y,d,e = range(6)
L=[1<<i for i in range(6)]
S=L+[1<<6]
R=L+[1<<7]
a=[S+[1<<7], S, S, R, L, L]
b=[S, S, L, L, [1], [2]]
H=[[Q(0) for _ in range(6)] for _ in range(6)]
for i,j,value in [(w,z,2),(x,z,-1),(x,w,1),(y,x,1),(d,x,1),(e,y,1)]:
    H[i][j]=Q(value)


def reduce_basis(vectors):
    piv={}
    for x in vectors:
        while x:
            k=x.bit_length()-1
            if k in piv: x^=piv[k]
            else:
                piv[k]=x
                break
    return list(piv.values())


def contains(V, v):
    return len(reduce_basis(V+[v]))==len(reduce_basis(V))


def paths(start,end,forbidden=()):
    f=set(forbidden)
    if start in f or end in f or start>end:
        return Q(0)
    q=[Q(0)]*6
    q[start]=1
    for i in range(start+1,end+1):
        if i not in f:
            q[i]=sum((H[i][j]*q[j] for j in range(i)),Q(0))
    return q[end]


def rank(M):
    M=[list(map(Q,row)) for row in M]
    r=0
    for j in range(len(M[0])):
        pivot=next((i for i in range(r,len(M)) if M[i][j]),None)
        if pivot is None: continue
        M[r],M[pivot]=M[pivot],M[r]
        v=M[r][j]
        M[r]=[x/v for x in M[r]]
        for i in range(len(M)):
            if i!=r and M[i][j]:
                v=M[i][j]
                M[i]=[p-v*q for p,q in zip(M[i],M[r])]
        r+=1
        if r==len(M): break
    return r

assert all(all(contains(a[i],v) for v in b[i]) for i in range(6))
assert all(all(contains(a[i],v) for v in b[j]) for i in range(6) for j in range(i) if H[i][j])
dims=[(len(reduce_basis(a[i])),len(reduce_basis(b[i]))) for i in range(6)]
assert dims==[(8,7),(7,7),(7,6),(7,6),(6,1),(6,1)]
assert set(S)!=set(R) and len(reduce_basis(S+R))==8
marked=[z,x,y]; low=[d,e]; gat=[z,x,y]
U=[[paths(q, target, set(marked)-{q}) for q in marked] for target in low]
C=[[paths(source,target) for source in gat] for target in low]
tz=[paths(z,target) for target in low]
tx=[paths(x,target) for target in low]
assert U==[[0,1,0],[0,0,1]] and rank(U)==2
assert paths(z,x)==Q(1) and H[x][z]==-1 and H[x][w]*H[w][z]==2
assert tz==tx==[1,1] and tx!=[U[0][1],U[1][1]]
assert C==[[1,1,0],[1,1,1]] and rank(C)==2
# Its only gather-column dependence has a zero coefficient at y, the second
# low gather; thus this toy deliberately does not satisfy P104's circuit fact.
assert [-C[0][0]+C[0][1],-C[1][0]+C[1][1]]==[0,0]
assert all(C[1][j]==C[0][j]+Q(j==2) for j in range(3))
print('chart legality, three drop-one nodes, distinct 7D gathers: PASS')
print('gathers are marked nodes z, x, y; length-zero source paths: PASS')
print('signed z->x paths -1 and +2; their net coefficient is 1: PASS')
print('U=',U,'rank=',rank(U),'; t_z=',tz,'; t_x=',tx,'; U_x=',[U[0][1],U[1][1]])
print('low transfer C=',C,'rank=',rank(C),'; unique relation=(-1,1,0)')
print('SCOPE: abstract DAG only; intentionally fails the nonzero low circuit-coefficient requirement')
