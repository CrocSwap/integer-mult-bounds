#!/usr/bin/env python3
"""Pinned P104 equality controls and exact path-sum checks; Python stdlib only.

This checks examples, not the paper argument or all possible networks.
"""
from fractions import Fraction as Q
from pathlib import Path
import runpy
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
r = runpy.run_path(str(HERE / 'prior_check_relay.py'))
p = r['prev']
s = p['s']
retime = p['retime_depot_7_to_6']


def check(name, net, expected_low, expected_depositor_pairs, expected_EBT):
    M, gat, dep, D, dims = s['verify'](name, net)
    assert M == s['M0'] and len(gat) == 9 and len(dep) == 8
    assert sorted(dims[g][0] for g in gat) in (
        [7,7,8,8,8,8,8,8,8], [7,7,8,8,8,8,8,8,9])
    low = [d for d in dep if dims[d][0] < 8]
    assert sorted(dims[d][0] for d in low) == expected_low
    E = sum(max(dims[d][0]-8, 0) for d in dep)
    B = sum(dims[d][1] == 0 for d in dep)
    X = [i for i in range(len(dims)) if i not in dep and dims[i][0] > dims[i][1]]
    T = sum(dims[x][0]-dims[x][1] for x in X)
    assert (E,B,T) == expected_EBT and D == 56 + E + B
    R = p['c']['reachability'](net['H'])
    pairs = [(d,e) for d in dep for e in dep if d != e and e in R[d]]
    assert len(pairs) == expected_depositor_pairs, pairs
    H0, N, N0, A, C, C0 = r['sink_factor'](net['H'], dep, gat)
    assert r['rank'](C) == r['rank'](C0) == 8
    lam = r['kernel_one'](C0)
    assert lam == r['kernel_one'](C)
    lowg = [i for i,g in enumerate(gat) if dims[g][0] == 7]
    assert len(lowg) == 2 and all(lam[i] for i in lowg)
    assert r['rank']([C0[dep.index(d)] for d in low]) == len(low)
    P,U,Qx,EX,V = p['factors'](H0, gat, low, X)
    assert P == [C0[dep.index(d)] for d in low]
    assert r['rank'](U) == len(low) and all(not v for row in V for v in row)
    print(f'{name}: exact original Gram and all odd P104 cells pass')
    print(f'{name}: low dimensions {expected_low}, E={E}, B={B}, T={T}, D={D}, comparable depot pairs={pairs}')
    print(f'{name}: sink C rank 8, preserved circuit nonzero at both 7D gathers; low rows and U rank {len(low)}')
    return net, gat, dep, dims, X, pairs


# Start from the single-7D and 6/7 equality networks already replayed by the
# prior package. A (7,6) relay is inserted before the selected 7D depot, whose
# input chart becomes 6D. All F, G and effective transfer coefficients remain.
sole = retime(p['c']['variant'])
check('sole 6D equality', sole, [6], 0, (0,0,2))
two = retime(p['net67'])
check('two 6D equality', two, [6,6], 0, (0,0,4))
comparable = retime(r['net'])
net,gat,dep,dims,X,pairs = check('two 6D with depositor relay', comparable, [6,6], 1, (1,0,4))
assert not p['odd_transfer_errors'](net, net['H'])
H0,_,_,_,_,_ = r['sink_factor'](net['H'],dep,gat)
errors = p['odd_transfer_errors'](net, H0)
assert errors and any(i==j for i,j,_ in errors)
print('two 6D with depositor relay: deleting depot exits breaks',len(errors),'odd cells; original has none')

# A synthetic chart-compatible path example illustrates why t_z must be
# factored by the *first* subsequent positive node, not by the last-drop U
# column. a_z=F2^8, b_z=a_x=F2^7, b_x=a_y=F2^6, b_y=F2^5,
# a_d1=a_d2=F2^6. Nodes 1,2 are zero-drop F2^7 bridges.
# z=0, x=3, y=4, low depots=5,6. The two bridge path sums cancel.
n=7
H=[[Q(0) for _ in range(n)] for _ in range(n)]
for i,j,w in [(1,0,1),(2,0,1),(3,0,1),(3,1,2),(3,2,-2),
              (4,3,1),(5,3,1),(6,4,1)]:
    H[i][j]=Q(w)
P,U,Qx,EX,V=p['factors'](H,[0,3],[5,6],[0,3,4])
assert U == [[Q(0),Q(1),Q(0)],[Q(0),Q(0),Q(1)]]
assert [P[i][0] for i in range(2)] == [Q(1),Q(1)]
assert [P[i][1] for i in range(2)] == [Q(1),Q(1)]
assert [P[i][0] for i in range(2)] != [U[i][1] for i in range(2)]
assert H[3][1]*H[1][0] + H[3][2]*H[2][0] == 0
print('synthetic cancellation: two bridge paths cancel; t_z=t_x=(1,1) while U_x=(1,0)')
print('ALL TWO-SIX EXAMPLE AND PATH CONTROLS PASSED')
