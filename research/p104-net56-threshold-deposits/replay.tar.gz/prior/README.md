# Two 6-dimensional depositor charts

This is a paper proof with exact example controls, **not a Lean theorem** and
not a proof of NET-D56 for arbitrary networks. It extends the first-depositor
sink argument in [PR #7897](https://github.com/CrocSwap/integer-mult-bounds/pull/7897),
pinned at `f9a2498da121a80d5d1d13f0cdeaac4677c1c6a7`. The underlying P104
`NetW` and 8-row rigidity are from DreamingOfClouds with Claude Opus 5.5's
[PR #7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852), pinned
at `41beda1d6435760dc99e38bd7e65f36798aad212`. P104 source notice and
Apache-2.0 license are in `source/`. The inherited P104 controls and fixture
are from [PR #7871](https://github.com/CrocSwap/integer-mult-bounds/pull/7871)
at `f4c554afebe370133ed1d04fec8947fe51d85fac`, building on
[PR #7860](https://github.com/CrocSwap/integer-mult-bounds/pull/7860)
at `2d5bb6b08a22f7cb448c1836170eaaced001ecf4`.

## Result

Let a P104 `NetW` satisfy `b_j ⊆ a_j` at every node, have exactly nine
active gatherers of dimensions `7, 7, ≥8, ≥8, ≥8, ≥8, ≥8, ≥8, ≥8`,
and exactly eight active depositors. Suppose exactly two depositor input
charts have dimension 6 and the other six have dimension at least 8. Put

* `T` = sum of drops `dim a_j − dim b_j` over nondepositors;
* `E` = sum of `max(dim a_d − 8, 0)` over depositors; and
* `B` = number of depositors with `dim b_d = 0`.

Then **T ≥ 4** and **D = 52 + E + B + T ≥ 56 + E + B**. There is no
antichain or comparability hypothesis on depositors, and no restriction
on rational path cancellation, E, or B. A P104 example attains T=4, D=56.
Another example with a genuine depositor-to-depositor path attains the
strengthened bound with E=1, B=0, T=4 and D=57.

The same proof also gives **T ≥ 2 and D ≥ 56 + E + B** if precisely one
depositor has dimension 6 and the other seven have dimension at least 8;
there is a T=2, D=56 P104 example. This is a separate profile, not a
consequence obtained by deleting one of the two low depositors.

## Original-network facts and the sink

Write `N=(I−H)⁻¹`, S for the nine gatherers, and Dset for the eight
depositors, both in chronological order. The original P104 odd-cell
conditions and eight-depositor factorization give `rank M=8` and row
rank 8 for `C=N[Dset,S]`. By the P104 8-row rigidity applied to the
**original** network, each depositor has `dim b_d≤1`. The P104 rigidity
also implies that the unique relation among the nine columns of C has
nonzero coefficients at both 7D gatherers and that their two 7D charts
are distinct; these are the original-network deductions used in #7897.

Set to zero every edge leaving a depositor, producing `H0`, and put
`N0=(I−H0)⁻¹` and `C0=N0[Dset,S]`. Classifying original paths by their
first depositor, with length-zero paths included, gives the exact identity

```
C = A C0,                A = N[Dset,Dset].
```

A is unit lower triangular, so C0 has row rank 8 and exactly the same
column kernel as C. In particular its two low-gather coefficients are
nonzero. Its two rows selected by the two 6D depositors are independent.
In the sink graph, a path ending at a depositor cannot previously visit a
depositor, and a gatherer which is also a depositor has no outgoing edge.
The sink graph is auxiliary: it need not itself satisfy the P104 transfer
condition. We use the original P104 rigidity only before sinking, and use
only the preserved rank/kernel and the original node charts afterward.

## Path-cut setup

Let L be the two 6D depositors and let `P=C0[L,S]`, a 2-by-9 matrix of
rank 2. Let X be the positive-drop nondepositors. Every gather-to-L path
in the sink graph visits X: otherwise zero-drop propagation would put its
at-least-7-dimensional gather chart inside a 6D endpoint. This includes a
gatherer in X (length-zero prefix) and a gatherer that is a depositor.

For `x∈X` and `d∈L`, let `U[d,x]` be the signed sum of paths x→d with
no other X vertex. For `x,y∈X`, let `K[y,x]` be the signed sum of x→y
paths with no other X vertex, and let `J[x,g]` be the signed sum of g→x
paths with no other X vertex; include the length-zero path for g=x. The
chronological order makes K strictly lower triangular, and partitioning
paths by successive X vertices gives the exact rational identity

```
P = U (I−K)⁻¹ J;          rank U = 2.                 (1)
```

The equality for rank U follows from rank P=2 and U having two rows. A
nonzero U column implies an actual support path from its X node to one of
the 6D endpoints without another X node. Along it, zero-drop propagation
gives `b_x ⊆ a_d`, hence

```
dim a_x ≤ 6 + drop(x).                                  (2)
```

Let `P_H` be the seven columns for gatherers of dimension at least 8.
The original column relation persists on these rows, and its coefficients
on both 7D columns are nonzero. If `P_H` were zero, those two columns
would be proportional, contradicting rank P=2. Thus `rank P_H≥1`.
For any node x write `t_x=N0[L,x]`, its complete vector of signed path
sums to the two endpoints. It includes paths through later X nodes.

Suppose for contradiction that T≤3. By (1), X has at least two nodes,
so the only cases are two drop-1 nodes, one drop-2 and one drop-1 node,
or three drop-1 nodes. A single drop-3 node already fails rank U=2.

## Two positive-drop nodes

With two nodes, rank U=2 makes both U columns nonzero. If both have drop
1, (2) gives input dimension at most 7 for each. No high-gather path can
have either as its first X node: before that node all vertices have zero
drop, so propagation would force its input dimension to be at least 8.
This contradicts `rank P_H≥1`.

Otherwise x has drop 2 and y has drop 1. By (2), `dim a_y≤7`. Every
high-gather path first visits x, so each high column is a scalar multiple
of t_x, even with cancellation. A 7D-gather path avoiding x must first
visit y; zero-drop propagation requires its 7D chart to equal `a_y`.
The two 7D charts are distinct, so at most one low-gather column can have
any x-avoiding contribution. All of the other one's paths visit x and
therefore its column lies in `span(t_x)`. The preserved column relation,
with both low coefficients nonzero, forces the exceptional low column
into that span as well. This would put all columns of P in one line,
contradicting rank P=2.

## Three positive-drop nodes

Suppose X consists of three drop-1 nodes. Since `rank P_H≥1`, some
high-gather-to-L path has nonzero total contribution and in particular
there is a support path. Let z be the first X node on one such path.
Its zero-drop prefix gives `dim a_z≥8` and hence `dim b_z≥7`. No z→L
path can avoid the other X nodes, because that would require its b chart
to fit in a 6D endpoint. Thus `U[:,z]=0`.

The other two nodes x,y have independent, nonzero U columns by (1); (2)
gives `dim a_x, dim a_y≤7`. Consequently every high-gather-to-L path
first visits z. The high columns all lie in `span(t_z)`, and `t_z≠0`
because their rank is at least one.

Every z→L path next visits x or y: a direct continuation avoiding the
other X nodes is impossible. If the next node is v, zero-drop propagation
on the z→v segment gives `b_z ⊆ a_v`. Since `dim b_z≥7` and
`dim a_v≤7`, both are 7D and `a_v=b_z`. There are two cases.

* **`a_x=a_y`.** At most one of the distinct 7D gather charts equals
  this chart. Any 7D-gather path avoiding z must first visit x or y; its
  chart must equal that first node's chart. Thus at most one low-gather
  column has a z-avoiding contribution. The other is in `span(t_z)` and
  the column relation puts the exceptional column in that span too.

* **`a_x≠a_y`.** Since t_z is nonzero, at least one next-X support path
  contributes. Exactly one of x,y can be next after z, say x, because its
  chart must equal `b_z`. Partitioning at that first next-X node gives
  `t_z=s t_x` for the signed rational sum s of z→x paths with no other X
  node. As t_z is nonzero, `s≠0`; hence t_x lies in `span(t_z)`. This is
  the **full downstream** t_x, not its terminal U column. Further, the
  support path z→x makes z earlier than x, so a path already at x cannot
  later visit z. A 7D-gather path avoiding z and first meeting x therefore
  contributes in `span(t_x)`. A path avoiding z and first meeting y can
  start only from a 7D gather whose chart is `a_y`; at most one of the two
  distinct low gathers can do so. All high columns and at least one low
  column lie in `span(t_z)`; the nonzero two-low relation puts the last
  low column there as well.

In either case all columns of P lie in one line, contradicting rank P=2.
Thus T≥4. Each original depositor has `dim b_d=0` or 1, so summing its
drop over the two 6D and six at-least-8D charts gives
`D=52+E+B+T≥56+E+B`. No nonzero path sum was inferred merely from
reachability; every rank argument and factorization uses rational sums.

## Sole 6D depositor

For one 6D depositor and seven with dimension at least 8, its single row
of C0 is nonzero and every gather-to-it path meets X. If T=0 this is
impossible. If T=1, X consists of one drop-1 node x whose terminal path
sum must be nonzero, so (2) gives `dim a_x≤7`. No high gather can reach x
without a preceding drop. A 7D gather can reach x only when its input
chart equals `a_x`, so at most one of the distinct 7D gather columns can
be nonzero. The preserved relation has a nonzero coefficient on that
column, contradicting its nonzero value. Hence T≥2. The original-network
accounting is `D=54+E+B+T≥56+E+B`.

## Exact controls and provenance

Run `python3 -B check_two_six.py` and `python3 -B check_distinct_charts.py`
from this directory. The first checker imports
the prior sink controls and pinned fixture, checks both supplied Lean source
blob IDs, and exactly verifies the original 104×104 Gram transfer, every
odd/diagonal P104 cell, nestedness, supports, causality, gather/depositor
counts, sink identity and common kernel. Its examples are:

| Profile | Comparability | E | B | T | D |
|---|---|---:|---:|---:|---:|
| one 6D, seven ≥8 | antichain | 0 | 0 | 2 | 56 |
| two 6D, six ≥8 | antichain | 0 | 0 | 4 | 56 |
| two 6D, six ≥8 | one comparable pair | 1 | 0 | 4 | 57 |

The comparable-pair example has a nonzero depositor relay through a
nondepositor and preserves the complete transfer. Deleting all depositor
exits without adjusting G makes 1,450 odd/diagonal cells fail. The last
small synthetic path control has signed cancellation, `t_z=t_x=(1,1)`,
and the different terminal vector `U_x=(1,0)`: it demonstrates why the
proof must use t_x. An independently constructed distinct-chart toy also
checks gatherers at the marked nodes and demonstrates that dropping the
nonzero low-circuit condition permits rank 2 with T=3; see
`INDEPENDENT-REVIEW.md`. These are example controls, not an enumeration
of all networks or a machine check of the proof. The upstream complete Lean
closure was not rebuilt here. `REPLAY.log` is the example replay;
`CLEAN-REPLAY.log` records the clean-copy relative-path run. The previous
#7897 archive was fetched at its immutable head, its published SHA-256 and
member manifest verified, and all retained source files byte-compared with
that archive. The exact source hashes and notices are in `SOURCES.json`.

The result says nothing about other depositor/gather profiles, general
NET-D56, the rise side, or a κ improvement. The P104 word bridge applies
only if the induced network has the stated profiles and its own bridge
hypotheses hold. Neither P104 example is claimed realizable by a legal word.
