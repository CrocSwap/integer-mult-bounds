#!/usr/bin/env python3
"""One-core exact controls for the seven-dimensional low-depot rank cut.

The imported P104 checkers and pinned source fixtures remain read-only. This is
an example and path-identity control, not a finite enumeration of all networks.
"""
from fractions import Fraction as Q
from pathlib import Path
import runpy
import sys

sys.dont_write_bytecode = True
src = Path(__file__).resolve().parent
c = runpy.run_path(str(src / 'next/check_cut.py'))
s = c['small']
echelon, contains, dot2 = s['echelon'], s['contains'], s['dot2']


def third_low_depot(net):
    n = len(net['a'])
    # Pick a distinct untouched original depositor that still gathers.
    d = next(k for k in range(n)
             if any(net['F'][k]) and any(row[k] for row in net['G'])
             and len(echelon(net['a'][k])) == 8
             and not any(net['H'][k]))
    a8, b1 = net['a'][d], net['b'][d]
    # Select a proper codimension-one cut of a8 which preserves b1.
    w = next(v for v in range(1, 512)
             if all(not dot2(v, y) for y in b1)
             and any(dot2(v, y) for y in a8))
    A7 = echelon([v for v in range(512) if contains(a8, v) and not dot2(v, w)])
    assert len(A7) == 7 and all(contains(A7, v) for v in b1)
    shift = lambda k: k if k < d else k + 1
    a = [list(x) for x in net['a'][:d]] + [list(a8)] + [list(x) for x in net['a'][d:]]
    b = [list(x) for x in net['b'][:d]] + [A7] + [list(x) for x in net['b'][d:]]
    a[d+1] = A7
    F = [list(x) for x in net['F'][:d]] + [list(net['F'][d])] + [list(x) for x in net['F'][d:]]
    F[d+1] = [Q(0)] * 104
    G = [list(row[:d]) + [Q(0)] + list(row[d:]) for row in net['G']]
    H = [[Q(0) for _ in range(n+1)] for _ in range(n+1)]
    for i in range(n):
        for j in range(n):
            H[shift(i)][shift(j)] = net['H'][i][j]
    H[d+1][d] = Q(1)
    return dict(a=a,b=b,F=F,G=G,H=H)


def rank(mat):
    if not mat:
        return 0
    a = [list(map(Q, row)) for row in mat]
    h, w, r = len(a), len(a[0]), 0
    for j in range(w):
        i = next((i for i in range(r, h) if a[i][j]), None)
        if i is None:
            continue
        a[r], a[i] = a[i], a[r]
        z = a[r][j]
        a[r] = [v/z for v in a[r]]
        for i in range(h):
            if i != r and a[i][j]:
                z = a[i][j]
                a[i] = [x-z*y for x,y in zip(a[i],a[r])]
        r += 1
        if r == h:
            break
    return r


def mul(a,b):
    if not a:
        return []
    assert len(a[0]) == len(b)
    return [[sum((a[i][k]*b[k][j] for k in range(len(b))), Q(0))
             for j in range(len(b[0]))] for i in range(len(a))]


def paths(H, start, end, forbidden):
    """All path weights from start to end avoiding a vertex set."""
    if start in forbidden or end in forbidden or start > end:
        return Q(0)
    z = [Q(0)] * len(H)
    z[start] = Q(1)
    for k in range(start+1, end+1):
        if k not in forbidden:
            z[k] = sum((H[k][j]*z[j] for j in range(start, k)), Q(0))
    return z[end]


def factors(H, gather, depot, X):
    X = list(sorted(X))
    xx = set(X)
    U = [[paths(H, x, d, xx-{x}) for x in X] for d in depot]
    E = [[paths(H, g, x, xx-{x}) for g in gather] for x in X]
    K = [[paths(H, x, y, xx-{x,y}) if x != y else Q(0) for x in X] for y in X]
    assert all(not K[i][j] for i in range(len(X)) for j in range(i,len(X)))
    Qx = [[Q(i == j) for j in range(len(X))] for i in range(len(X))]
    for i in range(len(X)):
        for j in range(len(X)):
            Qx[i][j] = Q(i==j)+sum((K[i][k]*Qx[k][j] for k in range(i)), Q(0))
    V = [[paths(H, g, d, xx) for g in gather] for d in depot]
    through = mul(mul(U,Qx),E)
    P = [[paths(H, g, d, set()) for g in gather] for d in depot]
    assert [[through[i][j] + V[i][j] for j in range(len(gather))]
            for i in range(len(depot))] == P
    return P, U, Qx, E, V


net = third_low_depot(c['twolowdep'])
M, gat, dep, D, dims = s['verify']('three low depositor control', net)
assert M == s['M0'] and D == 56 and len(gat) == 9 and len(dep) == 8
assert sorted(dims[g][0] for g in gat) == [7,7,8,8,8,8,8,8,8]
lowd = [d for d in dep if dims[d][0] == 7]
X = [k for k in range(len(dims)) if k not in dep and dims[k][0] > dims[k][1]]
assert len(lowd) == 3 and len(X) == 3
R = c['reachability'](net['H'])
assert all(not (R[d] & set(dep)) for d in dep)
assert all(dims[d][1] == 1 for d in dep)
assert [net['b'][d][0] for d in dep] == s['dnorm']
assert len(set(s['dnorm'])) == 8
for d in dep:
    v=net['b'][d][0]
    assert sum(bool(net['G'][p][d]) for p in range(104)) == 52
    assert all(bool(net['G'][p][d]) == (dot2(s['labels'][p],v)==0) for p in range(104))
P,U,Qx,E,V=factors(net['H'],gat,lowd,X)
assert rank(P) == 3
high_indices = [i for i,g in enumerate(gat) if dims[g][0] >= 8]
assert all(V[i][j] == 0 for i in range(3) for j in high_indices)
assert rank([[P[i][j] for j in high_indices] for i in range(3)]) == 2
print('three-low exact control: all odd/diagonal transfers pass; chosen 8-normal basis:', s['dnorm'])
print('low depot masks:', [net['b'][d][0] for d in lowd])
print('three-low low-row ranks: all=3, high=2; X has 3 nodes; D=56')

# An unrelated small exact DAG tests paths with multiple X visits, signed
# cancellation and a gatherer which is itself in X. No P104 claim is inferred.
H=[[Q(0) for _ in range(12)] for _ in range(12)]
for i,j,v in [(1,0,1),(2,0,1),(2,1,-1),(3,0,2),(4,2,3),(4,3,1),
              (5,1,2),(6,2,-2),(6,4,1),(6,5,3),(7,4,2),(8,6,1),
              (9,2,1),(9,4,-1),(9,6,2),(9,7,1),(10,4,1),(10,8,-2),
              (11,3,1),(11,6,1),(11,9,-1)]:
    H[i][j]=Q(v)
assert paths(H,0,2,set()) == 0  # the two paths cancel
P,U,Qx,E,V = factors(H,list(range(9)),[9,10,11],[2,4,6])
assert Qx[2][0] != 0 and E[0][2] == 1 and V[0][2] == 0
print('synthetic DAG factorization passed: signed cancellation, multi-X paths, gatherer=x')
print('ALL THREE-LOW EXACT CONTROLS PASSED')

# Independent forward-state evaluator for a restore/mutation control. It
# does not use verify() or a precomputed N matrix. Break one selected relay,
# test every odd cell, then restore and check the original matrix again.
def odd_transfer_errors(net, H):
    states = []
    for k in range(len(H)):
        states.append([net['F'][k][p] + sum(
            (H[k][j] * states[j][p] for j in range(k) if H[k][j]), Q(0))
                       for p in range(104)])
    active = [[(k,net['G'][q][k]) for k in range(len(H)) if net['G'][q][k]]
              for q in range(104)]
    errors=[]
    for q in range(104):
        for p in range(104):
            if dot2(s['labels'][q],s['labels'][p]):
                val=sum((co * states[k][p] for k,co in active[q]), Q(0))
                if val != Q(q==p):
                    errors.append((q,p,val))
    return errors

h = [list(row) for row in net['H']]
d = lowd[-1]
x = next(k for k in X if h[d][k])
original = h[d][x]
assert not odd_transfer_errors(net,h)
h[d][x] = Q(0)
errors = odd_transfer_errors(net,h)
assert errors and any(q==p for q,p,_ in errors)
h[d][x] = original
assert not odd_transfer_errors(net,h)
print('independent forward evaluator: deleting relay', (x,d),
      'breaks', len(errors), 'odd cells;',
      sum(q==p for q,p,_ in errors), 'diagonals; restoration passes')
print('ALL RESTORE/MUTATION CONTROLS PASSED')

# Further sharpness control: retime the first 7D depositor of the two-low
# example through an additional (7,6) intermediate, retaining transfer.
def retime_depot_7_to_6(net):
    n=len(net['a'])
    dims=[(len(echelon(net['a'][k])),len(echelon(net['b'][k]))) for k in range(n)]
    dep=[k for k in range(n) if any(row[k] for row in net['G'])]
    d=next(k for k in dep if dims[k] == (7,1))
    incoming=[k for k in range(d) if net['H'][d][k]]
    assert len(incoming)==1 and not any(net['F'][d])
    x=incoming[0]
    A7, b1 = net['a'][d], net['b'][d]
    w=next(v for v in range(1,512) if all(not dot2(v,z) for z in b1)
           and any(dot2(v,z) for z in A7))
    A6=echelon([v for v in range(512) if contains(A7,v) and not dot2(v,w)])
    assert len(A6)==6 and all(contains(A6,z) for z in b1)
    shift=lambda k: k if k<d else k+1
    a=[list(z) for z in net['a'][:d]]+[list(A7)]+[list(z) for z in net['a'][d:]]
    b=[list(z) for z in net['b'][:d]]+[A6]+[list(z) for z in net['b'][d:]]
    a[d+1]=A6
    F=[list(z) for z in net['F'][:d]]+[[Q(0)]*104]+[list(z) for z in net['F'][d:]]
    G=[list(row[:d])+[Q(0)]+list(row[d:]) for row in net['G']]
    H=[[Q(0) for _ in range(n+1)] for _ in range(n+1)]
    for i in range(n):
        for j in range(n):
            if (i,j)!=(d,x):
                H[shift(i)][shift(j)]=net['H'][i][j]
    H[d][shift(x)]=net['H'][d][x]
    H[d+1][d]=Q(1)
    return dict(a=a,b=b,F=F,G=G,H=H)

net67=retime_depot_7_to_6(c['twolowdep'])
M,gat,dep,D,dims=s['verify']('one-six one-seven depot control',net67)
assert M==s['M0'] and len(gat)==9 and len(dep)==8 and D==56
assert sorted(dims[g][0] for g in gat)==[7,7,8,8,8,8,8,8,8]
lowd=[d for d in dep if dims[d][0]<8]
assert sorted(dims[d][0] for d in lowd)==[6,7]
X=[k for k in range(len(dims)) if k not in dep and dims[k][0]>dims[k][1]]
assert sum(dims[k][0]-dims[k][1] for k in X)==3
R=c['reachability'](net67['H'])
assert all(not (R[d] & set(dep)) for d in dep)
P,U,Qx,E,V=factors(net67['H'],gat,lowd,X)
assert rank(P)==2 and not odd_transfer_errors(net67,net67['H'])
print('6/7-depot D=56 control passes: exact transfer, antichain and 3 units upstream')
print('ALL 6/7 EQUALITY CONTROLS PASSED')
