#!/usr/bin/env python3
"""Controls for the 9/8 antichain ancestor cut (stdlib only).

Reads, but does not modify, the sibling 01-net-small data and checkers.
"""
from fractions import Fraction as Q
from pathlib import Path
import runpy
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SMALL = HERE if (HERE / "check_separator.py").exists() else HERE.parent
small = runpy.run_path(str(SMALL / "check_separator.py"))
runpy.run_path(str(SMALL / "check_hyperplanes.py"))
labels = small["labels"]
echelon, contains, dot2 = small["echelon"], small["contains"], small["dot2"]
verify = small["verify"]


def chart_equal(a, b):
    return len(echelon(a)) == len(echelon(b)) == len(echelon(a + b))


def saturated(N):
    n = len(N["a"])
    for j in range(n):
        generators = [labels[p] for p in range(104) if N["F"][j][p]]
        for y in range(n):
            if N["H"][j][y]:
                generators.extend(N["b"][y])
        L = echelon(generators)
        B = echelon([v for v in range(512)
                     if contains(L, v)
                     and all(not N["G"][s][j] or not dot2(v, labels[s])
                             for s in range(104))
                     and all(not N["H"][x][j] or contains(N["a"][x], v)
                             for x in range(n))])
        assert chart_equal(L, N["a"][j]), (j, "input saturation")
        assert chart_equal(B, N["b"][j]), (j, "output saturation")


def reachability(H):
    n = len(H)
    r = [{k for k in range(n) if H[k][j]} for j in range(n)]
    for k in range(n):
        for j in range(n):
            if k in r[j]:
                r[j] |= r[k]
    return r


def structural_summary(name, N):
    n = len(N["a"])
    gat = [j for j in range(n) if any(N["F"][j])]
    dep = [j for j in range(n) if any(row[j] for row in N["G"])]
    dimensions = [(len(echelon(N["a"][j])), len(echelon(N["b"][j]))) for j in range(n)]
    drops = [a-b for a,b in dimensions]
    R = reachability(N["H"])
    assert len(gat) == 9 and len(dep) == 8
    assert sorted(dimensions[j][0] for j in gat) == [7,7,8,8,8,8,8,8,8]
    low_gathers = [j for j in gat if dimensions[j][0] == 7]
    assert len(echelon(N["a"][low_gathers[0]] + N["a"][low_gathers[1]])) == 8
    assert all(not (R[j] & set(dep)) for j in dep)  # depot antichain
    lows = [d for d in dep if dimensions[d][0] < 8]
    ancestor_costs = {d: sum(drops[j] for j in range(n)
                             if j not in dep and d in R[j]) for d in lows}
    assert all(ancestor_costs[d] >= 8-dimensions[d][0] for d in lows)
    assert sum(drops) == 56
    print(f"{name}: depositor antichain, D=56, low depositor dimensions "
          f"{[dimensions[d][0] for d in lows]}, ancestor invoices {list(ancestor_costs.values())}")
    return gat, dep, dimensions, drops, lows, ancestor_costs


def move_one_drop_upstream(N):
    # Existing two-low equality control: low nodes 0,1 feed depot 2.
    # Insert node 2 and shift all old indices >=2.  New b and old depot a
    # are the old low node 1's 7-dimensional chart (it contains depot b).
    n = len(N["a"])
    assert n == 10 and N["H"][2][0] == N["H"][2][1] == 1
    A7 = list(N["a"][1])
    assert len(echelon(A7)) == 7
    assert all(contains(A7, x) for x in N["b"][2])
    shift = lambda j: j if j < 2 else j + 1
    a = [list(x) for x in N["a"][:2]] + [list(N["a"][2])] + [list(x) for x in N["a"][2:]]
    b = [list(x) for x in N["b"][:2]] + [A7] + [list(x) for x in N["b"][2:]]
    a[3] = A7
    F = [list(x) for x in N["F"][:2]] + [[Q(0) for _ in range(104)]] + [list(x) for x in N["F"][2:]]
    G = [list(row[:2]) + [Q(0)] + list(row[2:]) for row in N["G"]]
    H = [[Q(0) for _ in range(n+1)] for _ in range(n+1)]
    for k in range(n):
        for j in range(n):
            if N["H"][k][j]:
                assert k == 2 and j in (0, 1)
                H[2][shift(j)] = N["H"][k][j]
    H[3][2] = Q(1)
    return dict(a=a, b=b, F=F, G=G, H=H)


def move_second_drop_upstream(N):
    # N is the one-intermediate control.  Insert a second independent
    # (8,7) gatherer before old depot 4; move its complete F row upstream.
    n = len(N["a"])
    assert n == 11 and any(N["F"][4])
    A7 = small["orth"]([25, 2])
    assert len(echelon(A7)) == 7
    assert all(contains(N["a"][4], x) for x in A7)
    assert all(contains(A7, x) for x in N["b"][4])
    shift = lambda j: j if j < 4 else j + 1
    a = [list(x) for x in N["a"][:4]] + [list(N["a"][4])] + [list(x) for x in N["a"][4:]]
    b = [list(x) for x in N["b"][:4]] + [A7] + [list(x) for x in N["b"][4:]]
    a[5] = A7
    F = [list(x) for x in N["F"][:4]] + [list(N["F"][4])] + [list(x) for x in N["F"][4:]]
    F[5] = [Q(0) for _ in range(104)]
    G = [list(row[:4]) + [Q(0)] + list(row[4:]) for row in N["G"]]
    H = [[Q(0) for _ in range(n+1)] for _ in range(n+1)]
    for k in range(n):
        for j in range(n):
            if N["H"][k][j]:
                H[shift(k)][shift(j)] = N["H"][k][j]
    H[5][4] = Q(1)
    return dict(a=a, b=b, F=F, G=G, H=H)


base = small["two_low"]
saturated(base)
_, dep, _, drops, lows, _ = structural_summary("baseline", base)
assert not lows and all(not drops[j] for j in range(len(drops)) if j not in dep)

variant = move_one_drop_upstream(base)
M, gat, dep, D, dims = verify("one charged intermediate", variant)
assert M == small["M0"] and D == 56
saturated(variant)
_, dep, dims, drops, lows, costs = structural_summary("retimed", variant)
assert len(lows) == 1 and dims[lows[0]][0] == 7 and list(costs.values()) == [1]
assert [j for j in range(len(drops)) if j not in dep and drops[j]] == [2]
assert drops[2] == 1 and len(echelon(variant["a"][2])) == 8
assert len(echelon(variant["b"][2])) == 7
print("both P104 networks are already support-saturated; full transfers coincide")

twolowdep = move_second_drop_upstream(variant)
M, _, _, D, _ = verify("two charged intermediates", twolowdep)
assert M == small["M0"] and D == 56
saturated(twolowdep)
_, dep, dims, drops, lows, costs = structural_summary("two-depot equality", twolowdep)
assert len(lows) == 2 and [dims[d][0] for d in lows] == [7,7]
assert sorted(costs.values()) == [1,1]
assert [j for j in range(len(drops)) if j not in dep and drops[j]] == [2,4]
R = reachability(twolowdep["H"])
cones = [{j for j in range(len(drops)) if j not in dep and drops[j] and d in R[j]} for d in lows]
assert cones[0] and cones[1] and not (cones[0] & cones[1])
print("two-depot D=56 equality: two disjoint one-unit ancestor cones; saturated")

# Two one-unit deletions that would superficially make D=55 are illegal.
# 1. Expand the intermediate's b to its full 8-dimensional a: its outgoing
# relay would then fail b_intermediate <= a_depot (which has dimension 7).
assert any(not contains(variant["a"][3], x) for x in variant["a"][2])
# 2. Expand the depot's one-dimensional b inside its a: its existing G
# support spans the perpendicular hyperplane, so some deposited label pairs
# oddly with any independent additional basis vector.
extra = next(x for x in variant["a"][3] if not contains(variant["b"][3], x))
assert any(variant["G"][s][3] and dot2(extra, labels[s]) for s in range(104))
print("two tempting D=55 edits rejected: outgoing relay, respectively G support")
print("ALL ANCESTOR-CUT CONTROLS PASSED")
