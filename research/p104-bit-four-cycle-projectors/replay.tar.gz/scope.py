"""Explicit seeded three-node scope, using fixed exterior and one old line."""
from collections import defaultdict
from itertools import combinations

def groups(seed_roster):
    out={}
    for sid,seed in enumerate(seed_roster):
        key=seed['pattern_hex']
        g=out.setdefault(key,{'pattern_index':seed['pattern_index'],'axis':seed['axis'],
                              'seed_ids':[],'anchors':set()})
        assert g['axis']==seed['axis'] and g['pattern_index']==seed['pattern_index']
        g['seed_ids'].append(sid);g['anchors'].update(seed['pair'])
    return sorted(out.items(),key=lambda kv:kv[1]['pattern_index'])

def paths_from_anchors(nb,free,anchors):
    """Every free length-two path meeting an anchor, then deduplicate triples."""
    paths=defaultdict(set)
    for a in sorted(anchors & free):
        for p,q in combinations(sorted(nb[a] & free),2):
            paths[tuple(sorted((p,a,q)))].add((a,p,q))
        for middle in sorted(nb[a] & free):
            for other in sorted((nb[middle] & free)-{a}):
                p,q=sorted((a,other))
                paths[tuple(sorted((a,middle,other)))].add((middle,p,q))
    return {k:sorted(v) for k,v in sorted(paths.items())}

def available(pat,charts,fixed,nb):
    x=[pat[c] for c in charts]
    free={i for i,z in enumerate(x) if z<2 and i not in fixed and all(x[j]<2 for j in nb[i])}
    return x,free
