#!/usr/bin/env python3
"""Exact 9D projector exchange on a two-component patch of #7910/#7830.

Four states per selected component. An exhaustive, deliberately favorable
projector test: all original MOVE/helper contacts remain nested; projectors
may coincide, in which case that edge is priced at grade zero. No claim is
made that changed rational frames compile over the finite alphabet.
"""
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from math import isqrt
from pathlib import Path
import json, sys
sys.path.insert(0, str(Path(__file__).resolve().parent/'source'))
from common import D,RATES,ZERO,baseline,check,display,minus,moment,plus,power,scale
from mincut import network,patterns
from timeline import timeline

OUT=Path(__file__).resolve().parent
N=9
ZERO_F=F(0)
I=tuple(tuple(F(int(i==j)) for j in range(N)) for i in range(N))
STATES=tuple(product((0,1),repeat=2))

def dot(a,b):return sum((x*y for x,y in zip(a,b)),ZERO_F)
def matmul(a,b):return tuple(tuple(sum((a[i][k]*b[k][j] for k in range(N)),ZERO_F) for j in range(N)) for i in range(N))
def matplus(a,b,scale_b=1):return tuple(tuple(a[i][j]+scale_b*b[i][j] for j in range(N)) for i in range(N))
def vector_mult(a,v):return tuple(sum((a[i][j]*v[j] for j in range(N)),ZERO_F) for i in range(N))
def outer(v,w):return tuple(tuple(x*y for y in w) for x in v)
def mtrace(a):return sum((a[i][i] for i in range(N)),ZERO_F)
def transpose(a):return tuple(zip(*a))
def packed_counter(c):return {str(k):v for k,v in sorted(c.items()) if v}

def projector(frame):
    orth=[]
    for raw in frame['B']:
        q=tuple(map(F,raw))+(ZERO_F,)
        for prev in orth:
            q=tuple(x-dot(q,prev)/dot(prev,prev)*y for x,y in zip(q,prev))
        check(dot(q,q)>0,'independent rational basis')
        orth.append(q)
    p=tuple(tuple(sum((v[i]*v[j]/dot(v,v) for v in orth),ZERO_F) for j in range(N)) for i in range(N))
    check(p==transpose(p) and matmul(p,p)==p and mtrace(p)==frame['dim'],'exact rational old projector')
    return p

def axes(axis):
    r=tuple(map(F,axis))+(ZERO_F,)
    k=dot(r,r);check(k>0,'nonzero line')
    l=tuple(tuple(z/k for z in row) for row in outer(r,r))
    e=(ZERO_F,)*8+(F(1),)
    ep=outer(e,e)
    return r,l,e,ep

def nested(a,b):
    ab=matmul(a,b)
    return ab==a or ab==b

def eval_pair(word,base,net,t,axis,pattern,pair):
    _,_,_,native_paid,native_helpers,paid,targets,rat=base
    nodes,charts,fixed,neighbors,groups=net
    x=[pattern[c] for c in charts]
    check(len(pair)==2 and pair[0] in neighbors[pair[1]],'pair adjacency')
    check(all(i not in fixed and x[i]!=2 and all(x[j]!=2 for j in neighbors[i]) for i in pair),'eligible exact reduction')
    r,l,e,ep=axes(axis)
    incident=[h for h in t['contacts'] if h['i'] in pair or h['j'] in pair]
    contact_groups=Counter()
    for h in incident:contact_groups[(tuple(sorted((h['i'],h['j']))),h['old_grade'])]+=1 if h['kind']=='paid' else -1
    for (ij,g),m in contact_groups.items():check(groups[ij]==(m,g),'matched signed grouped contact')
    relevant=set(pair)
    for h in incident:relevant.update((h['i'],h['j']))
    @lru_cache(None)
    def old_p(node):
        p=projector(word['frames'][str(charts[node])])
        check(x[node] in (0,1),'line reducing')
        check(vector_mult(p,r)==tuple(x[node]*v for v in r),'exact occupancy')
        return p
    @lru_cache(None)
    def new_p(node,u,v):
        p=matplus(matplus(old_p(node),l,u-x[node]),ep,v)
        check(p==transpose(p) and matmul(p,p)==p,'exact state is an orthogonal projector')
        check(mtrace(p).denominator==1 and 0<=mtrace(p)<=9,'new rank')
        return p
    unique_contacts=sorted({tuple(sorted((h['i'],h['j']))) for h in incident})
    @lru_cache(None)
    def edge(i,j,si,sj):
        p,q=new_p(i,*si),new_p(j,*sj)
        ok=nested(p,q)
        grade=int(abs(mtrace(p)-mtrace(q))) if ok else None
        return ok,grade
    for i,j in unique_contacts:
        ok,g=edge(i,j,(x[i],0),(x[j],0))
        check(ok and g==groups[i,j][1],'original exact nested contact')
    state_rows=[]
    for state in product(STATES,repeat=2):
        proposed=dict(zip(pair,state));get=lambda i:proposed.get(i,(x[i],0))
        bad=[list(ij) for ij in unique_contacts if not edge(*ij,get(ij[0]),get(ij[1]))[0]]
        row={'states':state,'nested':not bool(bad)}
        if bad:
            row['nonnested_contacts']=bad;state_rows.append(row);continue
        per_edge={ij:edge(*ij,get(ij[0]),get(ij[1]))[1] for ij in unique_contacts}
        adjustments=Counter();dp=Counter();dh=Counter(); details=[]
        for h in incident:
            ij=tuple(sorted((h['i'],h['j'])));g=h['old_grade'];new=per_edge[ij]
            if g==new:continue
            adjustments[h['kind'],g,new]+=1
            counter=dp if h['kind']=='paid' else dh
            counter[g]-=1;counter[new]+=1
        for kind,g,new in sorted(adjustments):details.append({'kind':kind,'old_grade':g,'new_grade':new,'count_per_native':adjustments[kind,g,new]})
        pn=Counter({int(k):v for k,v in paid.items()});tn=Counter({int(k):v for k,v in targets.items()})
        for g,v in dp.items():pn[g]+=36*v
        for g,v in dh.items():tn[g]+=36*v
        check(all(v>=0 for v in pn.values()) and all(v>=0 for v in tn.values()),'nonnegative complete counts')
        signed=Counter(dh)
        for g,v in dp.items():signed[g]-=v
        rates={}
        for k in RATES:
            delta=ZERO
            for g,count in signed.items():delta=plus(delta,scale(power(g,k),count*36))
            new_margin=moment(pn,tn,k)
            independent_delta=minus(new_margin,moment(paid,targets,k))
            check(independent_delta[0]<=delta[1] and delta[0]<=independent_delta[1],
                  'complete invoice recomputation overlaps local signed change')
            rates[str(k)]={'complete_signed_change':display(delta),'complete_bit_margin':display(new_margin),
                           'unchanged_rational_margin':display(moment(rat['signed']['paid'],rat['signed']['productive'],k))}
        row.update({'changed_contacts':details,'native_paid_delta':packed_counter(dp),'native_helper_target_delta':packed_counter(dh),
                    'native_signed_gain_coefficients':packed_counter(signed),'complete_paid_histogram':packed_counter(pn),
                    'complete_target_histogram':packed_counter(tn),'rates':rates,
                    'positive_grade_only':all(per_edge[ij]>0 for ij in unique_contacts),
                    'timeline_cochart_groups_are_singletons':all(t['components'][i]==[i] for i in pair)})
        state_rows.append(row)
    labels=[{'component':i,'canonical_root':list(nodes[i]),'chart':charts[i],
             'old_rank':int(mtrace(old_p(i))),'old_bit':x[i],'frozen':i in fixed,
             'neighbors':sorted(neighbors[i])} for i in pair]
    legs=[]
    for ij in unique_contacts:
        hs=[h for h in incident if tuple(sorted((h['i'],h['j'])))==ij]
        legs.append({'components':ij,'charts':[charts[i] for i in ij],'old_bits':[x[i] for i in ij],
                     'old_grade':groups[ij][1],'paid':sum(h['kind']=='paid' for h in hs),
                     'helper':sum(h['kind']=='helper' for h in hs),
                     'incidences':[{'kind':h['kind'],'id':h['id'],**({'clock':h['clock']} if 'clock' in h else {})} for h in hs]})
    return {'axis':axis,'pair':labels,'contact_census':legs,'state_rows':state_rows}

def global_isometry(word,base,net,axis):
    r,l,e,ep=axes(axis);norm=dot(r,r);root=isqrt(norm.numerator)
    check(norm.denominator==1 and root*root==norm.numerator,'rational unit representative')
    u=tuple(v/F(root) for v in r);v=tuple(x-y for x,y in zip(u,e));q=matplus(I,outer(v,v),-1)
    check(q==transpose(q) and matmul(q,q)==I,'global rational orthogonal involution')
    check(vector_mult(q,u)==e and vector_mult(q,e)==u,'global axis exchange')
    wordcharts=word['frames'];frozen=net[2];main=[(j,word['final'][j]) for j in range(111) if wordcharts[str(word['final'][j])]['dim']==8]
    check(main,'full-rank main endpoint')
    j,c=main[0];p=projector(wordcharts[str(c)]);changed=matmul(matmul(q,p),q)!=p
    check(changed,'global exchange moves a frozen main endpoint')
    return {'axis':axis,'unit_axis':[str(z) for z in u],
            'involution':'U = I - (unit_old-e9)(unit_old-e9)^T',
            'orthogonal_involution_exact':True,'all_contacts_preserved_by_isometry':True,
            'native_paid_histogram':packed_counter(base[3]),'native_helper_histogram':packed_counter(base[4]),
            'complete_bit_margin_by_rate':{str(k):display(moment(base[5],base[6],k)) for k in RATES},
            'frozen_main_endpoint_moved':{'owner':j,'chart':c,'rank':8,'projector_changed':changed},
            'feasible_under_frozen_main_scope':False}

def main():
    base=baseline();word=base[0];net=network(word);t=timeline(word)
    check(t['summary']['classes_with_many_semantic_components']==0,'all literal ADD cochart groups respected')
    check(len(net[2])==229,'fixed components')
    needed={(0,0,0,0,0,0,0,1),(0,0,0,0,1,1,1,1)}; found={}
    for v,p in patterns(word['frames']):
        if v in needed:found[v]=p
        if len(found)==len(needed):break
    check(len(found)==len(needed),'both selected axes in finite roster')
    cases=[((0,0,0,0,0,0,0,1),(27,259)),
           ((0,0,0,0,0,0,0,1),(270,493)),
           ((0,0,0,0,1,1,1,1),(3,655))]
    results=[eval_pair(word,base,net,t,a,found[a],p) for a,p in cases]
    check([sum(s['nested'] for s in c['state_rows']) for c in results]==[9,1,5],
          'complete finite state counts')
    for row in results[0]['state_rows']:
        if row['nested']:
            check(not row['native_signed_gain_coefficients'],'isolated paid/helper cancellation')
    for row in results[2]['state_rows']:
        if row['nested'] and row['states']!=((0,0),(0,0)):
            check(all(D(v['complete_signed_change'][1])<0 for v in row['rates'].values()),
                  'all nonbaseline feasible primary states lose at both trials')
    out={'source':'#7910 head 7880a7a0af4cf405991c60f26811fee926398406; #7830 pinned inputs in #7910 receipt',
         'scope':'two explicit node pairs, arbitrary 4-state old/fresh projectors, all other components fixed',
         'accounting':'new target-minus-paid; original full 36-call caller and rational side unchanged; grade zero is an optimistic cochart limit',
         'timeline':t['summary'],'cases':results,
         'global_isometry_tie_control':global_isometry(word,base,net,cases[-1][0])}
    text=json.dumps(out,indent=2,sort_keys=True)+'\n';(OUT/'OUTPUT.json').write_text(text)
    for case in out['cases']:
        print('axis',case['axis'],'pair',[p['component'] for p in case['pair']])
        for s in case['state_rows']:
            if s['nested']:
                print('  states',s['states'],'native delta',s['native_signed_gain_coefficients'],'full Δ lower and upper',[(k,v['complete_signed_change']) for k,v in s['rates'].items()])
        print('  admissible',sum(s['nested'] for s in case['state_rows']),'of 16')
    print('Wrote',OUT/'OUTPUT.json')
if __name__=='__main__':main()
