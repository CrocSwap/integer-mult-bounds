# Three-node old-line / fresh-axis exchange

**Result.** Within the fixed-boundary family defined below, all **982 connected length-two paths** and their **20,394 three-node assignments** are covered. Exactly **48** assignments preserve every required paid and helper contact. All 48 have a strictly negative full 36-call signed change at both rates. The greatest certified changes are at most `−34.4874780816952064669265561696` at `0.003879928046156` and `−34.487477693160276371254605522` at `0.003879929046155`. These are global outward upper bounds for this finite family, not sampled estimates. The unchanged caller and rational side remain in the complete invoice. No new κ bound or physical construction is claimed.

## Scope

The input word and caller are the [#7830 construction](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, inherited from the [#7910 source](https://github.com/CrocSwap/integer-mult-bounds/pull/7910) at `7880a7a0af4cf405991c60f26811fee926398406`. R4 stream 11 tested 3,394 old directions after pattern deduplication, yielding 96 nonzero two-site assignments. Its receipt saved their total and a digest, but not the individual rows. We recovered them with a single bounded legacy-control census. The 35,168 tested assignments reproduce the R4 complete nested-state digest `1d59eeb7baaa567990a969ef17ed8bdb814a16c59d26bea672267e900802cd3f`; `SEEDS.json` records all 96. They use eight distinct representative containment patterns. Forty-eight of the 96 seeds change both original sites.

For each seed pattern, form every length-two path of **three distinct unfrozen components** meeting **either** endpoint of any associated seed. Every selected component must materially change from its original old/fresh state. For a chart containing or orthogonal to the old line, each of its three changed occupancy states is allowed. A selected chart that neither contains nor is orthogonal to the old line may retain its old projector and add the fresh axis; adding or subtracting the tilted old-line projector would not be an orthogonal projector. This includes changing the seed endpoints to any compatible state; all 48 survivors happen to extend an original nontie seed assignment exactly. A single old line and one mutually orthogonal fresh ninth axis are used. All other components, including original main-port endpoints, owner 411, and protected bridge/tree endpoints, remain fixed. Every original incident paid MOVE and helper target must remain nested. The user-facing term “touching” is interpreted broadly: the path need only share one component with a seed, not necessarily contain its seed edge.

The 982 paths have 982 distinct component triples (there are no duplicate triangle paths in this roster). `ALL-PATHS.json` and `TILTED-SELECTED.json` list all paths and associate each excluded triple with a specific exact certificate. The first file includes every line-reducing selected chart **even when a fixed exterior neighbor does not reduce the old line**; the second covers the additional paths with a selected tilted chart in the fresh-only state. No other old directions, fourth changed component, routing change, changed caller, or physical exchange word is covered. A literal candidate is not established by these projector calculations.

## Exact geometry and independent accounting

For selected projector `P_i`, old-line projector `L`, fresh-line projector `E`, and original old occupancy `x_i ∈ {0,1}`, the four algebraic states are `P_i − x_i L + u_i L + v_i E`, `u_i,v_i ∈ {0,1}`. The original state `(x_i,0)` is excluded for each of the three components. All projectors and matrix products are rational. A contact remains nested exactly when `PQ = P` or `PQ = Q`.

The exhaustive proof splits without loss:

* **618 triples / 16,686 assignments** each have a selected old-orthogonal component with an unchanged non-reducing exterior neighbor. For each triple, `ALL-PATHS.json` points to one of 190 distinct rational certificates. Each certificate checks the original exact nesting and verifies that all three material states violate **both** inclusion directions on that boundary. It records nonzero entries of `PQ−P` and `PQ−Q`; no assumptions about the other two changed nodes can repair this fixed exterior contact.
* **340 triples / 3,060 assignments** have at least one non-reducing selected chart in the fresh-only state. `TILTED-SELECTED.json` records 110 additional fixed-boundary certificates, each excluding all allowed states of a selected node on that triple.
* **24 triples / 648 assignments** remain. `verify_projectors.py` checks all incident 9×9 rational projector products, including every rejected state: **48** are compatible. `COMPATIBLE.jsonl` contains each compatible placement and complete signed grade coefficients. Their roster SHA-256 is `371e3ceaff00eb463c3f0eb77377b51ecb43365c47742eb45dbe8dfa284f72e2`.

An independent replay constructs paths from the raw contact graph, uses all **2,874 paid** and **458 helper** native incidences, and reproduces both the 48-row roster and every price. The helper contacts in these 48 cases remain forward oriented and positive. A separate saved-certificate audit independently reconstructs all 982 paths from raw contacts and checks the rational residuals and correct fixed-boundary references for all 300 certificates (`VERIFY-COVERAGE.json`). Pricing uses `H(g)=g^(1−κ)`, with outward `10^28` integer enclosures, target minus paid, multiplied by all 36 native calls. If paid projectors coincide, grade zero is optimistically free. The full invoice includes all unchanged paid and productive terms and the fixed rational margin.

## Strongest placement and relation to R4

At both rates the largest upper bound is attained by old line `(0,0,0,0,1,1,1,1)` and components `(3,508,655)`, with each state `(1,0)`. Their original charts are `(431,428,514)`, with ranks `(6,6,7)` and old occupancies `(0,0,0)`. The native signed grade coefficients are `{0:−4, 1:3, 2:6, 3:−5, 5:1, 6:−1}`. `WITNESS.json` lists all changed primitive MOVE/helper IDs, the paid and target histograms for the whole caller, and independently recomputed complete invoices. Four paid incidences become grade zero, so the full result already assumes their favorable free treatment.

| κ | Complete 36-call change, directed interval | Changed complete BIT margin |
| --- | --- | --- |
| `0.003879928046156` | `[−34.487478081695206466927, −34.487478081695206466926]` | approximately `−34.487478082462208` |
| `0.003879929046155` | `[−34.487477693160276371255, −34.487477693160276371254]` | approximately `−34.487862820476890` |

This row extends the R4 `(3,655)` state `(10,10)`: adding component 508 repairs approximately `+0.4112533` of that two-site loss at each rate, yet the resulting complete change remains negative. This comparison does not claim the added component alone earns a positive overall invoice.

R4 stream 03 instead physically changed a packet-2669 word, rebuilt its graph, and found a negative two-endpoint rechart. That result illustrates why a changed physical route requires a new atlas and complete invoice. The present scan applies to the original #7830 word, not that modified graph, and carries no atlas replay or finite compiler qualification for an exchanged word. Ordinary work, stock/precision, lease, supplier, and analytic hypotheses remain inherited or unverified. A constructive claim would require a fresh literal atlas replay and its full changed-caller economics.

## Reproduce

From this directory, Python 3.10+ and the standard library suffice. `PARENT-SHA256SUMS.original` is the unchanged R4 manifest; `PARENT-SHA256SUMS` adjusts only the filenames of the copied R4 report and receipts so this directory's `REPORT.md` can describe the present result. The retained `source/` has its own manifest and notices.

```sh
sha256sum -c PARENT-SHA256SUMS
(cd source && sha256sum -c SHA256SUMS)
python3 -B extract_seeds.py        # authorized legacy input-recovery control
python3 -B scan_three.py           # 24 reducing-boundary triples and 48 prices
python3 -B verify_three_raw.py      # independent raw incidence and path enumeration
python3 -B verify_projectors.py     # direct exact projectors, all 648 assignments
python3 -B verify_all_paths.py      # 642 paths, including tilted boundaries
python3 -B verify_tilted_selected.py # 340 additional fresh-only tilted paths
python3 -B verify_coverage.py       # independent all-path and certificate audit
python3 -B witness.py               # complete original caller invoice for maximum
```

The source pins and complete parent records, separate output JSON, run logs, resource totals, full explicit roster and boundary certificates are retained beside this report. `COLD-REPLAY.json` records a deterministic repeat of all checks in 25.07 seconds on one CPU with unchanged artifact hashes. `ALL-PATHS.json` and `TILTED-SELECTED.json` together cover the 982-path scope; `THREE-SCAN.json` alone describes only the 24-triple subfamily without non-reducing exterior boundaries.
