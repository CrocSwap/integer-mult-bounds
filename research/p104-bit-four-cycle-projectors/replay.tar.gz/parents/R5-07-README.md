# Chart-388: one exterior arrival cannot restore six fixed exits

This is a bounded negative result. Starting from the two recodes and relay in #7924, no replacement of just one other chart-283 arrival can preserve **all six original chart-283 outgoing packet values** if the recoded arrival `1496=x43` is retained and there is no additional independent input. The argument grants an arbitrary replacement scalar, all local XORs, and free shadows of the other received scalars. It does not establish an improved κ bound and does not exclude a joint rewrite of multiple arrivals or downstream receivers.

The inputs are the [#7924 source at `c83039ac63874fa9f9a2fd0bb650469886076dc6`](https://github.com/CrocSwap/integer-mult-bounds/tree/c83039ac63874fa9f9a2fd0bb650469886076dc6/research/p104-bit388-paid-relay), [#7923 at `bddc42acae01355aa0e429432f84fac02c271059`](https://github.com/CrocSwap/integer-mult-bounds/tree/bddc42acae01355aa0e429432f84fac02c271059/research/p104-bit2947-edge-exchange), and the [#7830 comparator `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15). The local archive hashes match the package manifests obtained at the two exact heads; see `receipts/provenance.json`. All unqualified clocks below are zero-based in the original #7830 word. “Changed clock” refers to the corresponding #7924 word.

## First readers of the paid controls

The separate first-use interpreter replayed both published #7924 words forward and adjoint over all 680 public coordinates. First use means the first ADD, MOVE, retirement, or public exit involving the arrived packet in that direction. Rows show changed-word clocks and operations.

| #7924 word | Added MOVE, grade | Forward first use | Adjoint first use |
| --- | --- | --- | --- |
| direct | `927:45→560`, 6, clock 2 | MOVE `927:560→388`, clock 8950 | `ADD 927,43` on chart 45, clock 1 |
| direct | `927:560→388`, 1, clock 8950 | `ADD 2583,927` on 388, clock 8955 (original 8954) | MOVE `927:45→560`, clock 2 |
| two-recodes | `927:0→160`, 2, clock 2918 | `ADD 927,1122` on 160, clock 2919 | `ADD 927,527` on 0, clock 2917 |
| two-recodes | `927:160→283`, 2, clock 2924 | `ADD 1496,927` on 283, clock 2925 | `ADD 927,1122` on 160, clock 2919 |
| two-recodes | `927:283→560`, 3, clock 2927 | MOVE `927:560→388`, clock 8955 | `ADD 927,1496` on 283, clock 2926 |
| two-recodes | `927:560→388`, 1, clock 8955 | `ADD 2583,927` on 388, clock 8960 (original 8954) | MOVE `927:283→560`, clock 2927 |

The grade-two correction into 283 has value `D=x74+x321+x405+x527`. It restores original `1496=x43+D`. The **first use of the restored field** is the new `ADD 927,1496` at changed clock 2926, which prepares `x43` for the relay. Its subsequent original readers are `ADD 2021,1496`, `ADD 2022,1496`, `ADD 2025,1496` and `ADD 2026,1496` at original clocks 5191, 5197, 5218 and 5225, respectively; retirement is at original clock 40900. The direct control has no correction packet. Full first-use rows, including supports, are in `receipts/survey.json`.

## Price before stock

We named the five original exterior inputs other than 1496, all arriving on chart 283 before its first reader:

| Packet | Original MOVE clock | Source | Original grade | Replacement grades that pass the optimistic complete-price gate |
| --- | ---: | ---: | ---: | --- |
| 988 | 1095 | 56 | 3 | 0, 1, 2, 3 |
| 1111 | 1534 | 74 | 3 | 0, 1, 2, 3 |
| 1604 | 3327 | 187 | 2 | 0, 1, 2 |
| 1756 | 3897 | 225 | 2 | 0, 1, 2 |
| 1816 | 4122 | 240 | 2 | 0, 1, 2 |

For each packet we screened one replacement contact at each integer grade 0–8. The other original caller charges and targets are frozen. The two-recodes relay replaces the original 45→388 grade-five packet with 283→560 grade three and 560→388 grade one. With `H(r)=r^(1−κ)` and `H(0)=0` as an optimistic free-contact convention, the complete 36-call gain is

`36 × [H(5) − H(3) − H(1) + H(old grade) − H(new grade)]`.

Both `κ=0.003879928046156` and `κ=0.003879929046155` were priced with two outward-directed engines. Seventeen of 45 assignments have positive **complete** signed margins at both trials; all others are negative. For packet 1604 at its original grade two, the optimistic gain is about `+35.338865768176` and `+35.338865598426`, with complete margins about `+35.338865767409` and `+35.338480471109` respectively. Raising that packet to grade three instead gives complete margins about `−0.395133884479` and `−0.395519112405`.

The gate grants payload recoding, geometry changes, any local operations, and all precision/restoration costs for free; it is not a physical implementation. Grade zero is only a formal free-contact price. If coalescing charts makes additional independent sender stock locally accessible, the resulting larger interface is **outside** the six-input cut below. Other changes in exterior incidence or paid/productive terms are also outside the stated price bound. Full histograms and intervals are in `receipts/price-screen.json`.

## Exact information and stock checks

The six incoming rows have rank six: for roles `(988,1111,1496,1604,1756,1816)`, original input coordinates `(54,72,43,33,25,20)` form an identity minor. In the two-recode, unrestored state, the row for 1496 is `x43`; the other five inputs retain their original forms. The six original packets emitted from chart 283 are 2021–2026 at clocks 5195, 5201, 5207, 5214, 5221 and 5228. Their mixing matrix over the six old inputs has determinant one over F₂, so their old public-coordinate values have rank six. Their span, together with `x43`, has rank **seven**: the linear functional `coefficient(x43) XOR coefficient(x74)` is zero on each old output and one on `x43`.

Fixing any four of the other five inputs, retaining `x43`, and replacing the remaining input by one arbitrary scalar gives at most six received dimensions. The admitted span contains `x43`; if it also contained all six old outgoing rows it would contain seven independent rows, a contradiction. This checks the 17 price survivors as one-scalar-interface proposals, including the named packet 1604, without assuming what scalar a sender can produce. It permits rewriting the local ADDs and observing only the six original MOVE payloads. It does not freeze intermediate ADD results. If a rechart provides extra independent source stock, another arrival is edited, or an outgoing packet and its receiver are changed, this proof no longer applies.

The stock screen also tests a weaker same-endpoint task for each of the five packets: replace its old scalar by one current sender-chart XOR, then use any of the 32 combinations of the other five received scalar shadows to form an original compensated output involving both that packet and 1496. There are zero witnesses. For the named packet 1604 at clock 3327, chart 187 has four nonzero live fields but rank three: `871=x33`, `1187=x87+x431`, `1603=x554`, and `1604=x33+x87+x431+x554`. None, nor any of the five granted receiver shadows, contains coordinate `x74`; the compensated target `old(1604)+D` does. Coordinate 74 is an exact separating witness. The script records the analogous witness for all five named packets.

As a positive control, grant `D` as one extra independent scalar: all six original outgoing rows then lie in the rank-seven span. This does not grant it free in a literal invoice: #7924's actual restoration pays two grade-two moves. No new literal candidate survives this screen, so there is no new changed-word precision tape, restoration cost, or claimed full candidate replay. The source controls' complete directed invoices are independently replayed instead; all 680² coefficients forward and adjoint, the 38² caller, protected bridge omission, targets, ownership and dirty retirements are checked by #7924's verifier. `receipts/stock-screen.json` contains all exact rows, output coefficient masks, ranks and separators.

## #7923 packaging observation

The exact #7923 archive digest is `c123faccfb2b75de4575844e892c4132446b8ba334e849e20849b0422081ef04`. Its README instructs users to run `exchange.py` offline with retained `source/`, but the published archive contains no `source/` directory. A fresh extraction passes its incomplete `SHA256SUMS` yet `python3 -I -B exchange.py` fails with `ModuleNotFoundError: No module named 'binary_operator'`; see `receipts/pr7923-unaugmented.log`. This is a reproducibility packaging defect, not a numerical counterexample.

For a separate control only, `sources/pr7923-augmented` adds the `source/` tree from the independently pinned #7924 archive; that tree agrees with the #7923 round-4 working source apart from Python cache files. The augmented replay reproduces #7923 `RESULT.json` byte for byte. It does not make the published #7923 archive standalone. Packet 2669 in #7923 is at original clock 9296, after the chart-283 first reader, and was not silently treated as an earlier input here.

## Replay

Run from this directory with Python 3.12 and the standard library:

```sh
(cd sources/pr7924 && sha256sum -c SHA256SUMS && python3 -I -B verify_relay.py)
(cd sources/pr7923 && sha256sum -c SHA256SUMS)
python3 -I -B source/provenance.py
python3 -I -B source/survey.py
python3 -I -B source/price_screen.py
python3 -I -B source/stock_screen.py
(cd sources/pr7923-augmented && python3 -I -B exchange.py > ../../receipts/pr7923-augmented-result.json && cmp RESULT.json ../../receipts/pr7923-augmented-result.json)
```

The scripts write their deterministic receipts under `receipts/`; `provenance.py` deliberately checks and records the expected unaugmented #7923 failure. The correction, finite precision and other implementation costs are not assumed away in any physical claim. Inherited supplier and application premises still require their own qualification.
