#!/usr/bin/env python3
"""Independent walk census and direct 9x9 projector check of every rejection."""
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
from pathlib import Path
import gzip,json,sys,time
P=Path(__file__).resolve().parent
sys.path[:0]=[str(P),str(P/'source')]
from common import RATES, ZERO, baseline,check,display,moment,plus,power,scale
from mincut import network
from scope import groups
from timeline import timeline
from exchange import axes,projector,matplus,matmul,mtrace

start=time.process_time()
base=baseline();w=base[0];nodes,charts,frozen,_,_=network(w)
raw=timeline(w)['contacts'];adj=[set() for _ in nodes];edge=set()
for c in raw:
 a,b=c['i'],c['j'];adj[a].add(b);adj[b].add(a);edge.add(tuple(sorted((a,b))))
free=set(range(len(nodes)))-frozen
cycles=set()
for a in sorted(free):
 for b in adj[a]&free:
  for c in (adj[b]&free)-{a}:
   if c in adj[a]:continue
   for d in (adj[c]&adj[a]&free)-{b}:
    if d not in adj[b] and len({a,b,c,d})==4:cycles.add(tuple(sorted((a,b,c,d))))
saved_cycles={tuple(t) for t in json.loads((P/'CYCLES.json').read_text())}
check(cycles==saved_cycles and len(cycles)==338,'independent induced-cycle walks')
seed=json.loads((P/'SEEDS.json').read_text())['seed_roster']
gg={v['pattern_index']:(bytes.fromhex(h),v) for h,v in groups(seed)}
expected=set()
for idx,(pat,_) in gg.items():
 x=[pat[c] for c in charts]
 for cycle in cycles:
  opts=[((2,1),) if x[n]==2 else tuple(t for t in product((0,1),repeat=2) if t!=(x[n],0)) for n in cycle]
  for states in product(*opts):expected.add((idx,cycle,states))
check(len(expected)==21938,'all independently generated assignments')

@lru_cache(None)
def old(c):return projector(w['frames'][str(c)])
@lru_cache(None)
def axis(idx):return axes(gg[idx][1]['axis'])
@lru_cache(None)
def placed(idx,n,s):
 pat=gg[idx][0];x=pat[charts[n]];_,L,_,E=axis(idx)
 a=0 if x==2 else s[0]-x
 if x==2:check(s[0]==2,'tilted state retains old projector')
 p=matplus(matplus(old(charts[n]),L,a),E,s[1])
 check(matmul(p,p)==p,'exact state idempotence')
 return p
@lru_cache(None)
def check_contact(idx,i,j,si,sj):
 p,q=placed(idx,i,si),placed(idx,j,sj);pq=matmul(p,q)
 check(pq!=p and pq!=q,'two direct inclusion failures')
 return mtrace(pq),mtrace(p),mtrace(q)

seen=set();digest=sha256();blocked=Counter();by_pattern=Counter()
with gzip.open(P/'ASSIGNMENTS.jsonl.gz','rb') as stream:
 for rawline in stream:
  digest.update(rawline);row=json.loads(rawline);idx=row['pattern'];cycle=tuple(row['cycle'])
  states=tuple(map(tuple,row['states']));key=(idx,cycle,states)
  check(key in expected and key not in seen,'one correctly scoped row per assignment')
  seen.add(key);pos=dict(zip(cycle,states));i,j,overlap,ri,rj=row['block']
  check((i,j) in edge and (i in pos or j in pos),'real incident blocking edge')
  pat=gg[idx][0];si=pos.get(i,(pat[charts[i]],0));sj=pos.get(j,(pat[charts[j]],0))
  ov,rank_i,rank_j=check_contact(idx,i,j,si,sj)
  check((ov,rank_i,rank_j)==(F(overlap),F(ri),F(rj)),'saved overlap and ranks')
  blocked['internal' if i in pos and j in pos else 'fixed_exterior']+=1
  by_pattern[idx]+=1
result=json.loads((P/'RESULT.json').read_text())
check(seen==expected,'no omitted assignments')
check(digest.hexdigest()==result['assignments_uncompressed_sha256'],'receipt digest')
check(sum(blocked.values())==21938,'all checked by direct projectors')

# A separately reconstructed full invoice for the known R5 zero-grade control.
idx=46;pat=gg[idx][0];pos={3:(1,0),508:(1,0),655:(1,0)}
dp=Counter();dt=Counter();zeros=[]
for c in raw:
 i,j=c['i'],c['j']
 if i not in pos and j not in pos:continue
 p=placed(idx,i,pos.get(i,(pat[charts[i]],0)));q=placed(idx,j,pos.get(j,(pat[charts[j]],0)))
 pq=matmul(p,q);check(pq==p or pq==q,'known control nested')
 g=int(abs(mtrace(p)-mtrace(q)));oldg=c['old_grade'];d=dp if c['kind']=='paid' else dt
 if g!=oldg:d[oldg]-=1;d[g]+=1
 if c['kind']=='paid' and g==0:zeros.append(c['id'])
check(sorted(zeros)==[2698,2706,2934,2935],'known free-zero paid controls')
paid=Counter({int(k):v for k,v in base[5].items()});target=Counter({int(k):v for k,v in base[6].items()})
newpaid=paid.copy();newtarget=target.copy()
for g,v in dp.items():newpaid[g]+=36*v
for g,v in dt.items():newtarget[g]+=36*v
signed=dt.copy();signed.subtract(dp)
assert {str(k):v for k,v in sorted(signed.items()) if v}=={'0':-4,'1':3,'2':6,'3':-5,'5':1,'6':-1}
invoice={}
for k in RATES:
 m0=moment(paid,target,k);m1=moment(newpaid,newtarget,k);d=ZERO
 for g,v in signed.items():d=plus(d,scale(power(g,k),36*v))
 check(power(0,k)==ZERO,'zero-grade moment is exactly free in this control')
 comb=plus(m0,d);check(comb[0]<=m1[1] and comb[1]>=m1[0],'complete delta and bins overlap')
 invoice[str(k)]={'baseline_bit_margin':display(m0),'control_bit_margin':display(m1),
  'control_delta':display(d),'unchanged_rational_margin':display(moment(base[7]['signed']['paid'],base[7]['signed']['productive'],k))}
packed=lambda c:{str(k):v for k,v in sorted(c.items()) if v}
out={'status':'PASS_ALL_DIRECT_REJECTION_CERTIFICATES','cycles':len(cycles),'assignments':len(seen),
 'saved_receipt_digest':digest.hexdigest(),'blocking_contact_distribution':dict(blocked),
 'unique_direct_matrix_contacts':check_contact.cache_info().currsize,'per_pattern':dict(by_pattern),
 'projector_placement_count':placed.cache_info().currsize,'cpu_seconds':round(time.process_time()-start,3),
 'full_invoice':{'native_calls':36,'baseline_paid_bins':packed(paid),'baseline_target_bins':packed(target),
    'r5_three_node_control_paid_bins':packed(newpaid),'r5_three_node_control_target_bins':packed(newtarget),
    'r5_native_paid_delta':packed(dp),'r5_native_helper_delta':packed(dt),'r5_signed_delta':packed(signed),
    'free_zero_paid_ids':sorted(zeros),'rates':invoice},
 'limitations':'No induced four-cycle assignment survived nesting, so none has a valid changed full invoice; zero price applies only to the explicitly described optimistic control.'}
(P/'VERIFY.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='full_invoice'},sort_keys=True),flush=True)
