# Directed native cuts and the complete ninth-axis account

## Model

The source is the d3aa BIT word and the 798-event paired caller at #7830. There are 680 arbitrary public native inputs. On each of 111 pairs the normalized endpoint is (X,Y) ↦ (X,Y+X) over GF(2). Each of the other 458 fields is an independently returned identity. The exact retained paid grade counts are 1,376 of grade one, 1,281 of grade two, 54 of grade three, 44 of grade four, 17 of grade five and 102 of grade six. The productive helper grades are 8 of grade one, 9 of grade two, 43 of grade four, 8 of grade five, 1 of grade six and 389 of grade eight.

Add one orthogonal coordinate to the old eight-dimensional frame. A chart has tag 0 or 1 according to its occupancy on that coordinate. A paid or helper job whose endpoints have opposite tags adds exactly one to its original grade. With equal tags its grade stays fixed. Local operations mix fields only on their common chart. Whole-field swaps carry the tag and the value together. Private initialization adds a zero. For the cut argument a paid crossing delivers at most one new independent scalar direction in the normalized native transfer. This follows for the original single-field MOVE by restricting to independent scalar columns. Any changed local realization using this bound must retain this scalar-channel property, the same complete arbitrary-input map and the displayed old grade bins.

At every main port the input Y has tag 0 and the final X has tag 1. A port assigned to the head has input X tag 1 and final Y tag 0. Its head/body ranks become 2 and 7. A port assigned to the body has input X tag 0 and final Y tag 1. Its ranks become 1 and 8. These are precisely the two assignments being tested. We retain the same two LOCALs per stage, 36 sealed native calls, 4 QUERYs and 32 IDLE_ONEs per port program, the 18 independent stage variables, and the 38 original productive root masks. All physical egress, input independence and iterator assumptions would still have to hold on a positive alternative. An upper bound may grant its other work for free.

## Native lower cut

Let s of the 111 ports use the new head axis. Consider the matrix from input fields tagged 0 to output fields tagged 1. Each of the 111−s body ports contributes an independent invertible two-by-two block. Every helper whose input tag is 0 and output tag is 1 contributes one further independent unit. Let their number be H₀₁. Therefore the rank is 2(111−s)+H₀₁. The matrix in the other direction has one off-diagonal entry from X to Y for every head port and one unit for every 1→0 helper. Its rank is s+H₁₀. The direct sum in the normalized endpoint proves independence, including when many fields share one chart.

Grant unrestricted history on either side. At the beginning side 1 has no side-0 scalar input direction. A local linear update, an owned zero, a field swap carrying its own tag or an erasure creates no new such direction. Only a paid 0→1 crossing can increase the dimension of the total history of side-0 dependence accumulated in side 1, and the increase is at most one. The same proof applies with the roles reversed. Those paid crossings are disjoint. Adding both rank inequalities gives

Σ paid crossings − Σ productive helper crossings ≥ 222 − s.

The tag assignments can differ per port and the crossing sets can differ per native invocation. The same lower bound applies to each sealed native call under the same port assignments and scope.

## Marginal rank prices

Put H(g)=g^(1−κ) and δg=H(g+1)−H(g). Strict concavity makes δg positive and decreasing. The cheapest marginal on an old paid position is μ=δ6. If T is the collection of helper crossings and P the collection of paid crossings, the added native debit is

Σ(P) δg − Σ(T) δg ≥ (222−s) μ + Σ(T)(μ−δg).

For any selection of helper crossings the final sum is at least Σg n_g min(0,μ−δg), where n_g is the old count of helpers of grade g. This deliberately favorable lower bound permits every negative correction and discards every positive one. Multiply by 36 to debit the full caller.

For body or head mode, let b∈{8,7} be the new body rank and a∈{1,2} the new head rank. Its signed caller-root increment per port is the sum of H(a+bL)−H(1+7L) over the 38 original target masks of length L, less the sum of H(bM)−H(7M) over the 32 original IDLE_ONE masks of length M, less 4[H(a)−H(1)]. The four rank-one QUERY positions are independent of the IDLE_ONE list. Call the two resulting credits B and A. The complete signed change obeys

Δ ≤ (111−s)B+sA − 36[(222−s)μ+Σg n_g min(0,μ−δg)].

The coefficient of s is A−B+36μ. The upper endpoint for this coefficient is negative at each trial, approximately −1.48089354 and −1.48089341, respectively. The all-body case maximizes the formula. The directed outward upper endpoints at all-body are −78.85148768562446757495 and −78.85150766434442741463. Both are negative. Each original binary margin is already negative at its tested rate.

The two rates are discrete checks. A uniform rate interval or a different axis model would require another argument. The fresh dimension must change one existing grade by exactly one per opposite-tag job. A channel transmitting two independent scalar directions, a changed paid catalogue, or an independent change to productive targets must be repriced on its own construction.
