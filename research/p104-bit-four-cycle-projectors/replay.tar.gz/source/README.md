# A ninth native axis on the 111-port BIT caller

A fresh orthogonal axis assigned to the head or the body of each original main port makes the complete BIT invoice worse at both tested exponents. This covers every one of the 2¹¹¹ head/body assignments in the stated additive-axis model. At the first 15-decimal point strictly above the #7830 directed upper comparator, the full 36-call signed change is at most −78.85148768562446. At the near trial the upper bound is −78.85150766434442. A rank calculation on the returned native map accounts for the required paid crossings in both directions. The result holds across all placements of the new bit on the intervening charts that satisfy the stated grade and ownership accounting.

| Trial κ | Original full BIT margin | Optimistic Δ upper, all bodies | Optimistic Δ upper, all heads |
| --- | ---: | ---: | ---: |
| 0.003879928046156 | −7.670015024311303 × 10⁻¹⁰ | −78.85148768562446 | −243.23067112249008 |
| 0.003879929046155 | −0.00038512731661386644 | −78.85150766434442 | −243.23067650372539 |

The bound on Δ is affine and strictly decreasing in the number of ports using the new head axis. The third column is therefore an upper bound for every assignment at its trial. The fourth column gives the opposite endpoint of the upper-bound formula. These are ceilings on hypothetical changes. No minimizing native word or finite supplier is claimed. The rational side is fixed to #7830.

A separate appendix keeps the original main ports and the owner-411 tree fixed. It uses integer minimum cuts to optimize simultaneous changes to the eligible chart components along one of 3,394 specified rational directions, plus one fresh spectator direction. At each trial the complete potential improvement in the swept family is at most 1.116 × 10⁻²⁵. Only the separate fresh-spectator direction has certified upper bound exactly zero. The largest bound for the full family includes directed arithmetic slack. See APPENDIX.md.

The main rank argument allows changes to local routing coefficients if the original eight-dimensional paid and productive bins, the independent native return, the caller and all listed tag-crossing assumptions are retained. Heavier jobs, a different returned main operator, differently priced restoration services, joint movement of old axes, additional paid eliminations and multi-axis changes lie outside it. The finite compiler, physical stock/precision, owned erasure, analytic recovery and review remain separate.

The packet runs with Python 3.10 or newer and the standard library.

```sh
sha256sum -c SHA256SUMS
python3 -B verify.py
python3 -B mincut.py
```

EXPECTED.json contains outward intervals for both original invoices, both caller credits, each native debit lower formula and the complete changes. It includes direct GF(2) rank controls at all 112 possible head counts and a one-shear fault. EXPECTED-MINCUT.json records the fresh-axis control, maximum certificate, finite-direction census and the digest of all optimized systems. PROOF.md lists the model and derivation. SOURCES.json pins the caller, word, replay library and prior invoices.

The source construction is [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830). Its [451-factor continuation](https://github.com/CrocSwap/integer-mult-bounds/pull/7863) supplies a separate conditional result on the original invoice. Clear1nsight prepared this bounded analysis with substantial OpenAI Codex assistance. Attribution for the retained native word, caller and framework is in NOTICE and inputs/7830-NOTICE.
