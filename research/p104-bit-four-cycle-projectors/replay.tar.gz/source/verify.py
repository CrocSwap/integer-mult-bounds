#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Uniform directed price ceiling for a ninth axis assigned at all 111 main ports."""
from common import D, ROOT, RATES, ZERO, baseline, check, display, minus, moment, plus, power, scale
import argparse
import json


def gf2_rank(rows):
    echelon={}
    for vector in rows:
        while vector:
            pivot=vector.bit_length()-1
            if pivot not in echelon:
                echelon[pivot]=vector
                break
            vector^=echelon[pivot]
    return len(echelon)


def cut_ranks(rows,inputs,outputs):
    mask=sum(1<<i for i,v in enumerate(inputs) if v)
    return (gf2_rank(row&~mask for row,v in zip(rows,outputs) if v),
            gf2_rank(row&mask for row,v in zip(rows,outputs) if not v))


def rank_controls(matrix):
    n=len(matrix)
    cases=[]
    for s in range(112):
        starts=[0]*n
        ends=[0]*n
        for j in range(111):
            head=(17*j+13)%111<s
            starts[j]=int(head)
            ends[j]=1
            ends[111+j]=int(not head)
        check(sum(starts[:111])==s,'port permutation')
        for h in range(222,n):
            starts[h]=int(h%5<2)
            ends[h]=int(h%7<3)
        h01=sum(not x and y for x,y in zip(starts[222:],ends[222:]))
        h10=sum(x and not y for x,y in zip(starts[222:],ends[222:]))
        true=cut_ranks(matrix,starts,ends)
        check(true==(2*(111-s)+h01,s+h10),'native directional rank')
        if s in (0,1,50,111):
            cases.append(dict(s=s,helper_01=h01,helper_10=h10,directed_ranks=list(true)))
    starts=[int(j<111) for j in range(n)]
    ends=starts[:]
    good=cut_ranks(matrix,starts,ends)
    changed=matrix[:]
    changed[111]^=1
    bad=cut_ranks(changed,starts,ends)
    check(good==(0,111) and bad==(0,110),'single head-shear corruption')
    return {'cardinalities_checked':112,'examples':cases,'lost_head_shear':[list(good),list(bad)]}


def root_credit(head,caller,rate):
    q=1+int(head)
    b=7+int(not head)
    score=ZERO
    for owner in caller['diagonal']:
        stages=len(owner['stages'])
        score=plus(score,minus(power(q+b*stages,rate),power(1+7*stages,rate)))
    for event in caller['events']:
        if head and event[0]=='QUERY':
            score=minus(score,minus(power(q,rate),power(1,rate)))
        if not head and event[0]=='IDLE_ONE':
            stages=len(event[2])
            score=minus(score,minus(power(b*stages,rate),power(7*stages,rate)))
    return score


def at_rate(caller,helpers,original_paid,original_targets,rational,rate):
    marginal=[minus(power(g+1,rate),power(g,rate)) for g in range(9)]
    check(all(marginal[i][1]<marginal[i-1][0] for i in range(1,9)),'strictly decreasing marginals')
    mu=marginal[6]
    correction=ZERO
    for g,count in helpers.items():
        a,b=minus(mu,marginal[g])
        correction=plus(correction,scale((min(D(0),a),min(D(0),b)),count))
    body=root_credit(False,caller,rate)
    head=root_credit(True,caller,rate)
    slope=plus(minus(head,body),scale(mu,36))
    check(slope[1]<0,'affine upper bound decreases')
    points={}
    for s in (0,1,50,111):
        caller_gain=plus(scale(body,111-s),scale(head,s))
        native_floor=scale(plus(scale(mu,222-s),correction),36)
        upper=minus(caller_gain,native_floor)
        check(caller_gain[0]>0 and upper[1]<0,'required full native debit')
        points[s]={'caller_gain':display(caller_gain),'native_debit_floor_formula':display(native_floor),
                   'delta_upper_formula':display(upper),'minimum_paid_minus_helper_crossings':222-s}
    return {'complete_original_bit_margin':display(moment(original_paid,original_targets,rate)),
            'complete_original_rational_margin':display(moment(rational['signed']['paid'],rational['signed']['productive'],rate)),
            'body_root_gain_per_port':display(body),'head_root_gain_per_port':display(head),'paid_marginal_floor':display(mu),
            'helper_marginal_correction':display(correction),'slope':display(slope),'points':points}


def run():
    word,caller,matrix,native,helpers,paid,targets,rat=baseline()
    check(max(native)==6 and max(helpers)==8,'old source tariff scope')
    return json.loads(json.dumps({'native_paid':dict(native),'native_helpers':dict(helpers),
           'rank_controls':rank_controls(matrix),'rates':{str(k):at_rate(caller,helpers,paid,targets,rat,k) for k in RATES}}))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--emit',action='store_true')
    args=parser.parse_args()
    out=run()
    if args.emit:
        print(json.dumps(out,indent=2,sort_keys=True))
    else:
        check(out==json.loads((ROOT/'EXPECTED.json').read_bytes()),'rank-bound receipt')
        print('PASS_ALL_NINTH_HEAD_BODY assignments=2^111 rates=2 cardinalities=112')
