#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Optimize every simultaneous compatible one-axis chart placement at both trials."""
from collections import Counter, defaultdict, deque
from decimal import ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
from functools import reduce
from hashlib import sha256
from itertools import product
from math import gcd, lcm
from operator import and_, mul
from common import HI, LO, RATES, ROOT, baseline, check, inputs, minus, power
import argparse
import json

SCALE=10**28


def indices(mask):
    while mask:
        bit=mask & -mask
        yield bit.bit_length()-1
        mask^=bit


class Components:
    def __init__(self):
        self.parent={}

    def root(self,a):
        b=self.parent.setdefault(a,a)
        if a!=b:
            self.parent[a]=self.root(b)
        return self.parent[a]

    def join(self,a,b):
        ra,rb=self.root(a),self.root(b)
        self.parent[max(ra,rb)]=min(ra,rb)


def network(word):
    n=word['public']
    data=[1<<j for j in range(n)]+[0]*word['owned_fields']
    routes={}
    forms={}
    for op,r,*a in word['program']:
        if op in ('INIT','CLEAR'):
            data[r]=0
        elif op=='ADD':
            data[r]^=data[a[0]]
        elif op=='SWAP':
            j=a[0]
            data[r],data[j]=data[j],data[r]
        elif op=='MOVE':
            k=n+len(routes)
            forms[k]=data[r]
            routes[k]=tuple(a)
            data[r]=1<<k
        else:
            raise ValueError(op)
    forms.update({~j:data[j] for j in range(n)})
    d=Components()
    for j in range(n):
        d.root((j,'in'))
        d.root((~j,'out'))
    for k in routes:
        d.root((k,'out'))
        d.root((k,'in'))
    for k,form in forms.items():
        for j in indices(form):
            d.join((j,'in'),(k,'out'))
    nodes=sorted({d.root(v) for v in d.parent})
    ids={v:i for i,v in enumerate(nodes)}
    def component(v):
        return ids[d.root(v)]
    chart={}
    def bind(v,c):
        i=component(v)
        check(chart.setdefault(i,c)==c,'cocharted packet operands')
        return i
    owner_in=[bind((j,'in'),c) for j,c in enumerate(word['start'])]
    owner_out=[bind((~j,'out'),c) for j,c in enumerate(word['final'])]
    frozen={v for j in list(range(222))+[411] for v in (owner_in[j],owner_out[j])}
    edges=[]
    dims={int(c):f['dim'] for c,f in word['frames'].items()}
    tree={(509,0),(390,509),(517,390)}
    for k,(a,b) in routes.items():
        x,y=bind((k,'out'),a),bind((k,'in'),b)
        if k==3553 or (a,b) in tree:
            frozen.update((x,y))
        edges.append((x,y,abs(dims[a]-dims[b]),1))
    for h in range(222,n):
        x,y=owner_in[h],owner_out[h]
        edges.append((x,y,dims[chart[y]]-dims[chart[x]],-1))
    grouped={}
    neighbors=[set() for v in nodes]
    for i,j,g,sign in edges:
        check(i!=j and g>0,'old oriented incidence')
        key=tuple(sorted((i,j)))
        if key in grouped:
            count,old=grouped[key]
            check(old==g,'equal grade at equal endpoints')
        else:
            count=0
        grouped[key]=(count+sign,g)
        neighbors[i].add(j)
        neighbors[j].add(i)
    check(len(nodes)==656 and len(frozen)==229 and len(routes)==2874 and len(edges)==3332,'authenticated graph totals')
    check(all(c>=0 or i in frozen or j in frozen for (i,j),(c,_) in grouped.items()),'signed edge touches fixed boundary')
    return nodes, [chart[i] for i in range(len(nodes))],frozen,neighbors,grouped


class Flow:
    def __init__(self,n):
        self.adj=[[] for _ in range(n)]

    def directed(self,i,j,c):
        check(c>=0,'nonnegative integer flow capacity')
        if not c:
            return
        forward=[j,c,None]
        backward=[i,0,forward]
        forward[2]=backward
        self.adj[i].append(forward)
        self.adj[j].append(backward)

    def edge(self,i,j,c):
        self.directed(i,j,c)
        self.directed(j,i,c)

    def solve(self,source,sink):
        value=0
        while True:
            index=[0]*len(self.adj)
            level=[-1]*len(index)
            level[source]=0
            pending=deque([source])
            while pending:
                i=pending.popleft()
                for j,c,_ in self.adj[i]:
                    if c and level[j]<0:
                        level[j]=level[i]+1
                        pending.append(j)
            if level[sink]<0:
                return value,{i for i,z in enumerate(level) if z>=0}
            def send(i,limit):
                if i==sink:
                    return limit
                while index[i]<len(self.adj[i]):
                    arc=self.adj[i][index[i]]
                    j,cap,back=arc
                    if cap and level[j]==level[i]+1:
                        actual=send(j,min(limit,cap))
                        if actual:
                            arc[1]-=actual
                            back[1]+=actual
                            return actual
                    index[i]+=1
                return 0
            while True:
                pushed=send(source,10**60)
                if not pushed:
                    break
                value+=pushed


def direction(xs):
    rationals=tuple(map(Fraction,xs))
    den=lcm(*(x.denominator for x in rationals))
    ints=tuple(int(x*den) for x in rationals)
    divisor=reduce(gcd,ints,0)
    if not divisor:
        return (0,)*8
    if next(v for v in ints if v)<0:
        divisor=-divisor
    return tuple(v//divisor for v in ints)


def patterns(frames):
    bases={}
    rows=set()
    for c,f in frames.items():
        b=tuple(direction(v) for v in f['B'])
        a=tuple(direction(v) for v in f['A'])
        rows.update(b+a)
        bases[int(c)]=(b,a)
    axes={direction(v) for v in product((-1,0,1),repeat=8)}|rows
    axes.discard((0,)*8)
    axes=sorted(axes)
    orth={}
    for r in rows:
        # Each bit is one exact dot product test on a primitive integer line.
        orth[r]=sum(1<<i for i,v in enumerate(axes) if sum(map(mul,r,v))==0)
    all_axes=(1<<len(axes))-1
    masks=[(reduce(and_,(orth[r] for r in a),all_axes),
            reduce(and_,(orth[r] for r in b),all_axes)) for b,a in map(bases.__getitem__,range(len(bases)))]
    yield (0,)*8,bytes(len(bases))
    for i,v in enumerate(axes):
        bit=1<<i
        yield v,bytes(1 if inside&bit else (0 if outside&bit else 2) for inside,outside in masks)


def directed_weights(rate):
    bounds=[power(i,rate) for i in range(10)]
    lo=[int(LO.multiply(x,SCALE).to_integral_value(rounding=ROUND_FLOOR)) for x,_ in bounds]
    hi=[int(HI.multiply(x,SCALE).to_integral_value(rounding=ROUND_CEILING)) for _,x in bounds]
    return lo,hi


def placement(binary,free,edges,weights):
    n=len(binary)
    s,t=n,n+1
    flow=Flow(n+2)
    const=baseline_upper=0
    lo,hi=weights
    for (i,j),(m,g) in edges.items():
        if not m or (i not in free and j not in free):
            continue
        original=int(binary[i]!=binary[j])
        d=g-original
        low=lo[d+1]-hi[d]
        high=hi[d+1]-lo[d]
        lower=m*(low if m>0 else high)
        upper=m*(high if m>0 else low)
        baseline_upper+=original*upper
        p=i if i in free else (t if binary[i] else s)
        q=j if j in free else (t if binary[j] else s)
        if lower<0:
            check(p in (s,t) or q in (s,t),'negative cost must touch fixed boundary')
            if q not in (s,t):
                p,q=q,p
            q=s if q==t else t
            const+=lower
            lower=-lower
        flow.edge(p,q,lower)
    minimum,reached=flow.solve(s,t)
    changed={i for i in free if int(i not in reached)!=binary[i]}
    histogram=Counter()
    for (i,j),(m,g) in edges.items():
        if (i in changed)!=(j in changed):
            new=g+1 if binary[i]==binary[j] else g-1
            histogram[g]+=m
            histogram[new]-=m
    histogram.pop(0,None)
    h={g:c for g,c in histogram.items() if c}
    achieved_low=sum(c*(lo[g] if c>0 else hi[g]) for g,c in h.items())
    certificate=baseline_upper-minimum-const
    check(achieved_low<=certificate,'outward cut bound')
    return certificate,achieved_low,h


def controls():
    tested=0
    for ca,cb,cc in product(range(5),repeat=3):
        f=Flow(4)
        f.edge(2,0,ca)
        f.edge(0,1,cb)
        f.edge(1,3,cc)
        val,_=f.solve(2,3)
        check(val==min(ca,cb,cc),'integer maxflow on series network')
        tested+=1
    # An unlike-sign terminal term is translated to a nonnegative capacity
    # at the opposite terminal with a constant debit, both label choices.
    for old,weight in product((0,1),(-9,-2,0,3,8)):
        for label in (0,1):
            raw=weight*(label!=old)
            encoded=(-weight)*(label==old)+weight if weight<0 else raw
            check(encoded==raw,'signed unary conversion')
    return tested


def run():
    word,*_=baseline()
    nodes,charts,fixed,neighbors,edges=network(word)
    seen=set()
    by_rate={r:{'systems':0,'max_native_upper_units':0,'positive_placements':0} for r in RATES}
    weights={r:directed_weights(r) for r in RATES}
    digests={r:sha256() for r in RATES}
    enumerated=0
    for v,p in patterns(word['frames']):
        enumerated+=1
        if p in seen:
            continue
        seen.add(p)
        x=[p[c] for c in charts]
        free={i for i,z in enumerate(x) if z!=2 and i not in fixed and all(x[j]!=2 for j in neighbors[i])}
        if not free:
            continue
        for rate in RATES:
            upper,achieved,h=placement(x,free,edges,weights[rate])
            row=by_rate[rate]
            row['systems']+=1
            row['positive_placements']+=int(achieved>0)
            if upper>row['max_native_upper_units']:
                row['max_native_upper_units']=upper
                row['max_bound_witness']={'axis':v,'movable_components':len(free),'returned_native_signed_histogram':h}
            if v==(0,)*8:
                row['fresh_ninth_spectator_upper_units']=upper
                row['fresh_ninth_movable']=len(free)
            digests[rate].update(json.dumps([v,len(free),upper,achieved,h],sort_keys=True,separators=(',',':')).encode()+b'\n')
    for rate,d in by_rate.items():
        d['digest_of_all_optimized_cases']=digests[rate].hexdigest()
        d['complete_36_call_upper_units']=36*d['max_native_upper_units']
    return json.loads(json.dumps({'scale':SCALE,'basis_and_ternary_directions':enumerated-1,'unique_states_including_extra':len(seen),
            'graph':{'components':len(nodes),'protected':len(fixed),'grouped_contacts':len(edges),'negative_groups_with_two_movable_ends':0},
            'maxflow_controls':controls(),'rates':{str(r):v for r,v in by_rate.items()}}))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--emit',action='store_true')
    args=p.parse_args()
    out=run()
    if args.emit:
        print(json.dumps(out,indent=2,sort_keys=True))
    else:
        check(out==json.loads((ROOT/'EXPECTED-MINCUT.json').read_bytes()),'mincut receipt')
        print('PASS_SIMULTANEOUS_CHART_AXIS',out['basis_and_ternary_directions'],'directions, two rates')
