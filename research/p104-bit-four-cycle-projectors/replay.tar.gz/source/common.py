# SPDX-License-Identifier: Apache-2.0
"""Pinned native data and directed interval operations for the ninth-axis checks."""
from collections import Counter
from decimal import Context, Decimal as D, ROUND_CEILING, ROUND_FLOOR
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
import literal

LO=Context(prec=90,rounding=ROUND_FLOOR)
HI=Context(prec=90,rounding=ROUND_CEILING)
NEAREST=Context(prec=90)
RATES=(D('0.003879928046156'),D('0.003879929046155'))
ZERO=(D(0),D(0))


def check(ok,message):
    if not ok:
        raise ValueError(message)


def plus(a,b):
    return LO.add(a[0],b[0]),HI.add(a[1],b[1])


def minus(a,b):
    return LO.subtract(a[0],b[1]),HI.subtract(a[1],b[0])


def scale(a,c):
    if c<0:
        return scale((LO.minus(a[1]),HI.minus(a[0])),-c)
    return LO.multiply(a[0],c),HI.multiply(a[1],c)


def display(a):
    return [str(x) for x in a]


@lru_cache(None)
def power(rank,rate):
    if rank<=1:
        return (D(rank),D(rank))
    t=LO.subtract(D(1),rate)
    check(t==HI.subtract(D(1),rate) and t>0,'represented power')
    v=NEAREST.ln(D(rank))
    lo=NEAREST.exp(LO.multiply(t,NEAREST.next_minus(v)))
    hi=NEAREST.exp(HI.multiply(t,NEAREST.next_plus(v)))
    return NEAREST.next_minus(lo),NEAREST.next_plus(hi)


@lru_cache(None)
def inputs():
    sources=json.loads((ROOT/'SOURCES.json').read_bytes())
    for item in sources['inputs']:
        check(sha256((ROOT/item['local']).read_bytes()).hexdigest()==item['sha256'],item['local'])
    def read(name):
        p=ROOT/'inputs'/name
        raw=p.read_bytes()
        return json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw)
    word=read('WORD.json.gz')
    check(literal.canonical(word)==sources['construction']['binary_word_canonical_sha256'],'native canonical digest')
    return word,read('EFREE-CALLER.json.gz'),read('BIT.json'),read('AUDIT.json')


def baseline():
    word,caller,bit,rat=inputs()
    charts=literal.Charts(word['frames'])
    check(charts.main_contacts(word['start'],word['final'])==111,'main contacts')
    forward,data,_=literal.tape(word,charts)
    adj,other,_=literal.tape(word,charts,adjoint=True)
    check(forward==literal.expected_rows(680,False) and adj==literal.expected_rows(680,True),'all native columns')
    check(data['erase_dirty']==other['erase_dirty']==3554,'original owned erasure audit')
    helpers=Counter(charts.leg(a,b) for a,b in zip(word['start'][222:],word['final'][222:]))
    events=Counter(e[0] for e in caller['events'])
    paid,targets=literal.paired_invoice(caller,data['paid'],helpers,events)
    for checked,name in ((paid,'paid'),(targets,'targets')):
        check(checked=={int(k):c for k,c in bit['native'][name].items()},'full '+name)
    check(events['LOCAL']==36 and events['QUERY']==4 and events['IDLE_ONE']==32,'complete caller events')
    return word,caller,forward,data['paid'],helpers,paid,targets,rat


def moment(P,T,rate):
    pos=ZERO
    neg=ZERO
    for rank,n in T.items():
        pos=plus(pos,scale(power(int(rank),rate),n))
    for rank,n in P.items():
        neg=plus(neg,scale(power(int(rank),rate),n))
    return minus(pos,neg)
