# Four-node induced cycles for the inherited old/fresh axes

**Result.** For the original [#7830 word at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), the exact fixed-boundary screen covers all **338 distinct induced four-node cycles** of unfrozen components and all **eight old-line patterns** inherited from the Round 5 three-node study. Across those 2,704 cycle/pattern pairs there are **21,938 assignments** in which all four components change. **Every assignment fails nesting on at least one actual paid or helper incidence.** An independent direct rational-projector verifier checks the saved failing contact for every assignment. Thus this family has no compatible placement to submit to the changed-caller invoice; no literal gain or new κ is claimed.

## Family and inputs

`source/SOURCES.json` pins the binary word, its canonical digest, the E-free caller, and the supplier and audit files. The geometry and 96 recovered seeds are inherited from [Round 5 stream 09](parents/R5-09-REPORT.md); each of its eight distinct representative old lines is used here across the **whole graph**, not just at seed anchors. The separately inherited [Round 5 stream 07 boundary analysis](parents/R5-07-README.md) explains why joint exterior changes are a real possible escape and cannot be silently assumed to preserve a literal word. Neither prior result is counted as new evidence.

The original raw timeline has 656 semantic components, 2,874 paid incidences, and 458 helper incidences; collapsing only duplicate endpoints gives 2,392 undirected edges. A paid/helper cancellation does **not** remove an edge. The 229 frozen components include all original main-port endpoints, owner 411, protected bridge 3553, and the protected tree; the remaining 427 are eligible. An induced cycle is a set of four different eligible nodes with exactly the four cycle edges and no diagonal. Distinct cyclic rotations, reversals, and opposite-pair enumerations are counted once. `CYCLES.json` gives the exact roster. Two independently written graph enumerators recover the same 338 cycles from the literal graph.

For a selected original projector `P`, line projector `L`, and fresh orthogonal line `E`, a chart containing or orthogonal to the old line has occupancy `x∈{0,1}` and possible states `P−xL+uL+vE` for `u,v∈{0,1}`. The original `(u,v)=(x,0)` is excluded. A tilted chart, for which the old line is neither contained nor orthogonal, may only retain its old projector and add `E`. These are respectively three and one materially changed states. The other 652 components stay at their original projectors; the original contact graph and 36-call caller stay fixed. This grammar does not cover a rotated line, other old directions, non-induced cycles or other patches, changes to the frozen boundary or routing, or joint exterior rewrites.

Every selected-to-selected and selected-to-fixed original edge is evaluated. The producer uses the exact identity `tr(AB)=rank(A)` iff the range of orthogonal projector `A` is contained in that of `B`. Original source contacts are checked nested by the pinned literal replay. Exact rational arithmetic evaluates both inclusions and any nested grade for each contact. `ASSIGNMENTS.jsonl.gz` saves every placement and a specific rejecting contact, including the trace of its product and the two ranks. For example, line 46 on cycle `(0,282,307,476)` with all four tilted charts adding the fresh axis fails the exterior edge `(0,24)` with trace 6 and ranks 7 and 8.

The verifier independently walks the raw graph, generates the complete assignment roster, builds the 9×9 rational projectors, checks idempotence, and tests `PQ != P` and `PQ != Q` on every recorded blocker. Its cache contains 2,069 distinct direct matrix contact/state checks covering all 21,938 records. The **first saved** blocker is a fixed-exterior edge in 21,103 records and an internal cycle edge in 835; this partition does not claim those are the only failures. The uncompressed assignment-roster SHA-256 is `39ab01eeccdf8350a65d7e05c8bdd3d427bff016d6a816c2db936b72d7eab706`.

## Controls and prices

All 2,704 old-state cycle/pattern controls preserve every incident original contact and its grade. The independent verifier reconstructs the entire signed caller bins and reports the following directed trial margins for the unmodified binary supplier:

| Trial κ | Complete original binary margin | Unchanged rational margin |
| --- | ---: | ---: |
| `0.003879928046156` | approximately `−0.0000000007670015024311` | approximately `+0.21226247016335` |
| `0.003879929046155` | approximately `−0.0003851273166139` | approximately `+0.21124392992651` |

As a separate priced control, the verifier reconstructs the R5 three-node placement `(3,508,655)` on line 46 from raw contacts. Its per-native target-minus-paid coefficients are `{0:−4,1:3,2:6,3:−5,5:1,6:−1}`. Four paid incidences, 2698, 2706, 2934 and 2935, become grade zero, and the control optimistically charges `H(0)=0`. Its complete 36-call change is approximately `−34.4874780816952` at the first trial and `−34.4874776931603` at the second. `VERIFY.json` contains both complete paid and target histograms and outward intervals. The known three-node control is not a member of the four-node cycle family and is not a new gain.

No four-node survivor exists, so there are no valid changed four-node caller bins to quote. The zero-grade convention, nine-dimensional projector construction, and numerical moment do not establish a new finite frame or native word. A genuine candidate in an extended family would need both primitive orientations, a newly compiled frame/word, all first and last reads, dirty-field erasure, stock, precision and outer-transfer obligations, plus a rebuilt full caller invoice.

## Replay and resources

Python 3.10+ and the standard library suffice. From this directory:

```sh
sha256sum -c SHA256SUMS
(cd source && sha256sum -c SHA256SUMS)
python3 -B scan.py
python3 -B verify.py
```

The first execution started `2026-11-21T16:53:38+11:00`; the scan used 13.63 CPU seconds and 43,388 KiB maximum RSS, and the independent verification used 11.45 CPU seconds and 70,088 KiB maximum RSS. Exact run logs and resource measurements are saved. `cpu_seconds` in the JSON is a runtime observation and may vary on replay; the assignment digest and combinatorial results must remain fixed. The source code and input notices preserve contributor attribution and licensing.
