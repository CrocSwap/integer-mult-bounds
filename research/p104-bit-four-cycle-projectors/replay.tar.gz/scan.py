#!/usr/bin/env python3
"""All induced four-cycles, eight inherited old lines, one fresh axis.

For each selected component exactly one non-original orthogonal projector is
chosen. Nonreducing charts may only keep their old projector and add the fresh
axis. Every other component, raw incidence, and caller event remains fixed.

For orthogonal projectors A,B, range(A) is a subspace of range(B) exactly when
tr(AB)=tr(A). The trace formula here uses exact rational arithmetic. Original
incidences are independently checked for nestedness by literal.Charts in the
baseline replay. Physical compilation is not claimed.
"""
from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import gzip, json, sys, time

ROOT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), str(ROOT/'source')]
from common import RATES, ZERO, baseline, check, display, moment, plus, power, scale
from mincut import network, directed_weights, SCALE
from scope import groups
from timeline import timeline
from exchange import axes, dot, matmul, matplus, mtrace, projector, vector_mult

def packed(c):
    return {str(k):v for k,v in sorted(c.items()) if v}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))

def powermoment(hist, rate):
    out = ZERO
    for grade, count in hist.items():
        out = plus(out, scale(power(grade, rate), count))
    return out

def cycles_by_opposites(nb, free):
    out = set()
    for i,j in combinations(sorted(free), 2):
        if j in nb[i]:
            continue
        for a,b in combinations(sorted(nb[i] & nb[j] & free), 2):
            if b not in nb[a]:
                out.add(tuple(sorted((i,j,a,b))))
    return sorted(out)

def cycles_by_walks(nb, free):
    out = set()
    for a in sorted(free):
        for b in sorted(nb[a] & free):
            if b <= a:
                continue
            for c in sorted((nb[b] & free) - {a}):
                if c <= a or c in nb[a]:
                    continue
                for d in sorted(nb[c] & nb[a] & free):
                    if d <= a or d == b or d in nb[b]:
                        continue
                    out.add(tuple(sorted((a,b,c,d))))
    return sorted(out)

def direct_edge(old, axis, patterns, i, j, si, sj):
    """Independent matrix check of a particular state-pair."""
    _, L, _, E = axes(axis)
    def state(n, s):
        x=patterns[n]; a=0 if x==2 else s[0]-x
        p=matplus(matplus(old(n),L,a),E,s[1])
        check(matmul(p,p)==p, 'direct state projector')
        return p
    p,q=state(i,si),state(j,sj); pq=matmul(p,q)
    return pq==p, pq==q, int(abs(mtrace(p)-mtrace(q)))

def main():
    began = time.process_time()
    base=baseline(); word=base[0]
    nodes, charts, frozen, nb, graph=network(word)
    trace=timeline(word); raw=trace['contacts']
    check(trace['summary']['classes_with_many_semantic_components']==0, 'cochart singleton classes')
    check(Counter(c['kind'] for c in raw)=={'paid':2874,'helper':458}, 'raw incidence totals')
    edges=defaultdict(list)
    for c in raw:
        key=tuple(sorted((c['i'],c['j'])))
        edges[key].append(c)
    check(set(edges)==set(graph), 'raw and semantic contact graph agree')
    check(all(len({c['old_grade'] for c in cs})==1 and cs[0]['old_grade']==graph[key][1]
              for key,cs in edges.items()), 'old grades agree')
    free=set(range(len(nodes)))-frozen
    cycles=cycles_by_opposites(nb,free)
    check(cycles==cycles_by_walks(nb,free), 'independent cycle enumeration')
    for t in cycles:
        check(sum(j in nb[i] for i,j in combinations(t,2))==4, 'induced simple four-cycle')
    seedfile=json.loads((ROOT/'SEEDS.json').read_text())
    seeds=seedfile['seed_roster']; check(len(seeds)==96, '96 recorded seeds')
    axis_groups=groups(seeds); check(len(axis_groups)==8, 'eight inherited seed line patterns')
    rank=[word['frames'][str(c)]['dim'] for c in charts]
    weights=[directed_weights(k) for k in RATES]
    ratmargin=[display(moment(base[7]['signed']['paid'],base[7]['signed']['productive'],k)) for k in RATES]
    basemargin=[display(moment(base[5],base[6],k)) for k in RATES]
    basepaid=Counter({int(k):v for k,v in base[5].items()})
    basetarget=Counter({int(k):v for k,v in base[6].items()})
    cycle_info={t:sorted(key for key in edges if key[0] in t or key[1] in t) for t in cycles}
    cycle_nodes=set().union(*(set(t) for t in cycles))
    check(all(n not in frozen for n in cycle_nodes), 'unfrozen cycle nodes')
    relevant=cycle_nodes | set().union(*(nb[n] for n in cycle_nodes))
    @lru_cache(None)
    def old_chart(c):
        return projector(word['frames'][str(c)])
    def old(n):
        return old_chart(charts[n])
    counts=Counter(); per=[]; survivors=[]; best=[None,None]; direct_controls=[]
    globalhash=sha256(); first_reject=None; old_control_count=0
    with (ROOT/'ASSIGNMENTS.jsonl.gz').open('wb') as handle:
      with gzip.GzipFile(filename='', mode='wb', fileobj=handle, mtime=0) as archive:
       for hx,info in axis_groups:
        pat=bytes.fromhex(hx); x=[pat[c] for c in charts]
        r,L,_,E=axes(info['axis']); rr=dot(r,r)
        occupancy={n:dot(r,vector_mult(old(n),r))/rr for n in relevant}
        for n,z in occupancy.items():
            check((x[n]==0 and z==0) or (x[n]==1 and z==1) or
                  (x[n]==2 and 0<z<1),'exact old line pattern')
        def initial(n):
            return (x[n],0)
        def states(n):
            if x[n]==2:
                return ((2,1),)
            return tuple(s for s in product((0,1), repeat=2) if s!=initial(n))
        def alpha(n,s):
            check((x[n]==2 and s[0]==2) or (x[n]!=2 and s[0] in (0,1)), 'state label')
            return 0 if x[n]==2 else s[0]-x[n]
        @lru_cache(None)
        def edge(i,j,si,sj):
            ai,aj=alpha(i,si),alpha(j,sj)
            ri,rj=rank[i]+ai+si[1],rank[j]+aj+sj[1]
            # Original projectors are nested on every old physical contact.
            ov=F(min(rank[i],rank[j]))+aj*occupancy[i]+ai*occupancy[j]+ai*aj+si[1]*sj[1]
            check(0<=ov<=min(ri,rj),'projector intersection trace bound')
            le,ge=(ov==ri),(ov==rj)
            return le,ge,abs(ri-rj),ov,ri,rj
        local=Counter(); case_start=len(survivors)
        for t in cycles:
            selected=set(t); ce=cycle_info[t]
            # Baseline control on every edge incident to this cycle, every pattern.
            for i,j in ce:
                le,ge,g,_,_,_=edge(i,j,initial(i),initial(j))
                check((le or ge) and g==graph[i,j][1], 'old state contact')
            old_control_count+=1
            anchored=bool(selected & info['anchors'])
            for st in product(*(states(n) for n in t)):
                counts['assignments']+=1;local['assignments']+=1
                if anchored:local['anchor_touch_assignments']+=1
                changes=dict(zip(t,st)); evaluations={}; invalid=[]
                for i,j in ce:
                    ei=edge(i,j,changes.get(i,initial(i)),changes.get(j,initial(j)))
                    evaluations[i,j]=ei
                    if not (ei[0] or ei[1]):
                        invalid.append((i,j,ei))
                row={'pattern':info['pattern_index'],'cycle':t,'states':st}
                if invalid:
                    counts['rejected_nonnested']+=1;local['rejected_nonnested']+=1
                    i,j,(le,ge,g,ov,ri,rj)=invalid[0]
                    row['block']=[i,j,str(ov),ri,rj]
                    row['nonnested_contact_count']=len(invalid)
                    if first_reject is None:
                        first_reject=(info['pattern_index'],info['axis'],x,t,st,i,j,
                                      changes.get(i,initial(i)),changes.get(j,initial(j)))
                else:
                    counts['nested']+=1;local['nested']+=1
                    dp=Counter();dh=Counter();bad_helpers=[];zero_paid=[];zero_helpers=[]
                    for i,j in ce:
                        le,ge,g,_,_,_=evaluations[i,j]
                        for c in edges[i,j]:
                            oldgrade=c['old_grade']
                            change=dp if c['kind']=='paid' else dh
                            if g!=oldgrade:
                                change[oldgrade]-=1;change[g]+=1
                            if c['kind']=='helper':
                                forward=le if c['i']==i else ge
                                if not forward or g==0:
                                    bad_helpers.append({'id':c['id'],'forward':forward,'grade':g})
                                if g==0:zero_helpers.append(c['id'])
                            elif g==0:
                                zero_paid.append(c['id'])
                    signed=Counter(dh);signed.subtract(dp)
                    pn=basepaid.copy(); tn=basetarget.copy()
                    for g,v in dp.items():pn[g]+=36*v
                    for g,v in dh.items():tn[g]+=36*v
                    check(all(v>=0 for v in pn.values()) and all(v>=0 for v in tn.values()),'full nonnegative caller bins')
                    bounds=[]
                    for k,(lo,hi) in zip(RATES,weights):
                        lower=sum(v*(lo[g] if v>0 else hi[g]) for g,v in signed.items())
                        upper=sum(v*(hi[g] if v>0 else lo[g]) for g,v in signed.items())
                        if lower>0:local['strict_positive_'+str(k)]+=1
                        d=powermoment({g:36*v for g,v in signed.items()},k)
                        m=moment(pn,tn,k)
                        b=moment(basepaid,basetarget,k)
                        enclosure=plus(b,d)
                        check(enclosure[0] <= m[1] and enclosure[1] >= m[0], 'full invoice overlaps delta')
                        bounds.append({'rate':str(k),'native_lower_units':lower,'native_upper_units':upper,
                                       'full_caller_delta':display(d),'full_bit_margin':display(m)})
                    row.update({'native_paid_delta':packed(dp),'native_helper_delta':packed(dh),
                                'native_signed_coefficients':packed(signed),
                                'complete_paid_histogram':packed(pn),'complete_target_histogram':packed(tn),
                                'bad_or_zero_helpers':bad_helpers,'zero_grade_paid_ids':zero_paid,
                                'zero_grade_helper_ids':zero_helpers,'rates':bounds,
                                'touches_seed_anchor':anchored})
                    if bad_helpers:local['bad_or_zero_helper']+=1
                    else:local['positive_forward_helpers']+=1
                    if zero_paid:local['has_zero_grade_paid']+=1
                    survivors.append(row)
                    for z in range(2):
                        if best[z] is None or bounds[z]['native_upper_units']>best[z]['rates'][z]['native_upper_units']:
                            best[z]=row
                payload=(canonical(row)+'\n').encode();globalhash.update(payload);archive.write(payload)
        local['cycles']=len(cycles)
        local['anchor_touch_cycles']=sum(bool(set(t)&info['anchors']) for t in cycles)
        local['tilted_count_distribution']={str(k):v for k,v in sorted(Counter(sum(x[n]==2 for n in t) for t in cycles).items())}
        per.append({'pattern_index':info['pattern_index'],'axis':info['axis'],'seed_ids':info['seed_ids'],
                    'anchors':sorted(info['anchors']),'counts':dict(local)})
        print('pattern',info['pattern_index'],'assignments',local['assignments'],'nested',len(survivors)-case_start,flush=True)
    check(counts['assignments']==counts['rejected_nonnested']+counts['nested'], 'complete census')
    check(old_control_count==len(cycles)*len(axis_groups), 'all old control checks')
    # A direct 9x9 matrix audit for every state-pair on every incident edge of
    # each accepted assignment. Also include one known rejected contact.
    groupmap={g['pattern_index']:(hx,g) for hx,g in axis_groups}
    for row in survivors:
        hx,info=groupmap[row['pattern']]; pat=bytes.fromhex(hx); x=[pat[c] for c in charts]
        changes=dict(zip(row['cycle'],map(tuple,row['states'])))
        for i,j in cycle_info[tuple(row['cycle'])]:
            a=changes.get(i,(x[i],0));b=changes.get(j,(x[j],0))
            le,ge,g=direct_edge(old,info['axis'],x,i,j,a,b)
            check(le or ge,'direct accepted projector contact')
        direct_controls.append({'pattern':row['pattern'],'cycle':row['cycle'],'states':row['states']})
    check(first_reject is not None,'rejected contact available')
    idx,axis,x,t,st,i,j,a,b=first_reject
    le,ge,g=direct_edge(old,axis,x,i,j,a,b)
    check(not le and not ge,'directly damaged contact is nonnested')
    negative_control={'pattern':idx,'cycle':t,'states':st,'edge':[i,j],
                      'endpoint_states':[a,b],'both_inclusions_false':True}
    # Reproduce the independently reported R5 strongest three-node placement.
    hx,info=groupmap[46];pat=bytes.fromhex(hx);x=[pat[c] for c in charts]
    selected={3:(1,0),508:(1,0),655:(1,0)}; incident=[c for c in raw if c['i'] in selected or c['j'] in selected]
    dpaid=Counter(); dhelper=Counter(); zeros=[]
    for c in incident:
        i,j=c['i'],c['j'];si=selected.get(i,(x[i],0));sj=selected.get(j,(x[j],0))
        le,ge,g=direct_edge(old,info['axis'],x,i,j,si,sj)
        check(le or ge,'R5 witness exact contact')
        target=dpaid if c['kind']=='paid' else dhelper
        if g!=c['old_grade']:
            target[c['old_grade']]-=1;target[g]+=1
        if c['kind']=='paid' and g==0:zeros.append(c['id'])
    signed=Counter(dhelper);signed.subtract(dpaid)
    check(packed(signed)=={'0':-4,'1':3,'2':6,'3':-5,'5':1,'6':-1},'independent R5 signed witness')
    check(sorted(zeros)==[2698,2706,2934,2935],'known free-zero paid incidence IDs')
    # Grade-zero paid events make exactly zero contribution even if removed.
    for k in RATES:
        check(power(0,k)==ZERO and powermoment({0:-4*36},k)==ZERO,'free zero control')
    cycle_hash=sha256((''.join(canonical(t)+'\n' for t in cycles)).encode()).hexdigest()
    result={'status':'PASS_EXACT_ALL_INDUCED_CYCLES',
            'source_pins':{'7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','7910':'7880a7a0af4cf405991c60f26811fee926398406'},
            'scope':'all induced four-node cycles of unfrozen components in original raw 2874 paid plus 458 helper graph; eight seed-derived old lines; one orthogonal fresh axis; four materially changed states; every exterior component fixed',
            'graph':{'nodes':len(nodes),'distinct_edges':len(edges),'paid_incidences':2874,'helper_incidences':458,
                     'frozen_nodes':len(frozen),'free_nodes':len(free),'induced_cycles':len(cycles),
                     'cycle_nodes':len(cycle_nodes),'relevant_nodes':len(relevant),'cycle_roster_sha256':cycle_hash,
                     'independent_cycle_enumerators_match':True,'timeline':trace['summary']},
            'statistics':dict(counts),'per_pattern':per,'scale':SCALE,'baseline_bit_margins':dict(zip(map(str,RATES),basemargin)),
            'unchanged_rational_margins':dict(zip(map(str,RATES),ratmargin)),
            'old_state_control_cycles':old_control_count,
            'direct_matrix_controls':{'all_surviving_incident_contacts':len(direct_controls),
                'negative_example':negative_control},
            'r5_three_node_control':{'pattern':46,'components':[3,508,655],'states':[[1,0]]*3,
                                      'signed_histogram':packed(signed),'zero_grade_paid':sorted(zeros),
                                      'grade_zero_price_exactly_zero':True},
            'assignments_uncompressed_sha256':globalhash.hexdigest(),
            'survivor_count':len(survivors),'survivors':survivors,
            'best_at_each_rate':best,'cpu_seconds':round(time.process_time()-began,3),
            'limitations':['algebraic projector/price screen only','no changed literal word or physical compiler',
              'zero-grade contacts optimistically free','new frame, both primitive orientations, actual first/last reads, stock, dirty erasure and full physical transfer are not established',
              'not an exclusion for other old directions, non-cycle patches, more or fewer changed components, changed contact topology, or joint exterior rewrites']}
    (ROOT/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    (ROOT/'CYCLES.json').write_text(json.dumps(cycles,indent=2)+'\n')
    print('RESULT',json.dumps({'statistics':dict(counts),'cycles':len(cycles),'survivors':len(survivors),
                                'old_controls':old_control_count,'cpu_seconds':result['cpu_seconds']},sort_keys=True),flush=True)

if __name__=='__main__':main()
