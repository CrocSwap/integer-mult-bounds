#!/usr/bin/env python3
"""Rebuild literal chart-lifetime cochart components independently of value support."""
from collections import defaultdict
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent/'source'))
from mincut import Components, indices, network
from common import baseline,check

def timeline(word):
    n=word['public']
    data=[1<<j for j in range(n)]+[0]*word['owned_fields']
    init=list(range(n)); tags=init+[None]*word['owned_fields']; count=n
    charts={i:c for i,c in enumerate(word['start'])}
    alltags=Components(); routes={}; forms={}; add_count=0; swaps=0; lifetimes=0
    def new(c):
        nonlocal count
        i=count;count+=1;charts[i]=c;return i
    for clock,(op,r,*a) in enumerate(word['program']):
        if op=='INIT':
            check(tags[r] is None,'private lifetime')
            tags[r]=new(a[0]);data[r]=0;lifetimes+=1
        elif op=='CLEAR':
            check(tags[r] is not None and charts[tags[r]]==a[0],'clear chart')
            tags[r]=None;data[r]=0
        elif op=='ADD':
            j,c=a
            check(charts[tags[r]]==charts[tags[j]]==c,'add chart')
            alltags.join(tags[r],tags[j]);data[r]^=data[j];add_count+=1
        elif op=='SWAP':
            j=a[0];tags[r],tags[j]=tags[j],tags[r];data[r],data[j]=data[j],data[r];swaps+=1
        elif op=='MOVE':
            c1,c2=a;check(charts[tags[r]]==c1,'move source chart')
            k=n+len(routes);forms[k]=data[r];data[r]=1<<k
            before=tags[r];tags[r]=new(c2);routes[k]=(before,tags[r],clock,c1,c2)
        else:raise ValueError(op)
    check(all(t is None for t in tags[n:]),'retirement')
    forms.update({~j:data[j] for j in range(n)})
    graph=Components()
    for j in range(n):graph.root((j,'in'));graph.root((~j,'out'))
    for k in routes:graph.root((k,'out'));graph.root((k,'in'))
    for k,form in forms.items():
        for j in indices(form):graph.join((j,'in'),(k,'out'))
    nodes,oldcharts,_,_,_=network(word)
    check(sorted({graph.root(t) for t in graph.parent})==nodes,'reconstructed graph node names')
    ids={v:i for i,v in enumerate(nodes)}
    def c(p):return ids[graph.root(p)]
    classes=defaultdict(set)
    def record(port,tag):
        component=c(port);check(oldcharts[component]==charts[tag],'source chart vs timeline')
        classes[alltags.root(tag)].add(component)
    for j in range(n):record((j,'in'),init[j]);record((~j,'out'),tags[j])
    for k,(before,after,*_) in routes.items():record((k,'out'),before);record((k,'in'),after)
    members={i: sorted(group) for group in classes.values() for i in group}
    dims={int(k):v['dim'] for k,v in word['frames'].items()}
    contacts=[]
    for k,(before,after,clock,src,dst) in routes.items():
        contacts.append(dict(kind='paid',id=k,clock=clock,i=c((k,'out')),j=c((k,'in')),old_grade=abs(dims[src]-dims[dst])))
    for j in range(222,n):
        src,dst=word['start'][j],word['final'][j]
        contacts.append(dict(kind='helper',id=j,i=c((j,'in')),j=c((~j,'out')),old_grade=abs(dims[src]-dims[dst])))
    check(len(contacts)==2874+458,'all physical contact incidences')
    return dict(components=members,routes=routes,contacts=contacts,summary=dict(chart_timeline_tags=count,add_operations=add_count,swaps=swaps,owned_lifetimes=lifetimes,classes_with_many_semantic_components=sum(len(group)>1 for group in classes.values()),largest_semantic_class=max(map(len,classes.values()))))

if __name__=='__main__':
    w,*_=baseline(); t=timeline(w);print(t['summary'])
    for node in (3,655,27,259,270,493):print('node',node,'primitive cochart group',t['components'][node])
