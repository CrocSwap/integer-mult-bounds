#!/usr/bin/env python3
"""Check the changed actual source-bound relative chart recipes.

This checks exact nine-axis Gaussian/Clifford maps, not recursive physical
execution, spectators, supply or the five inherited outer premises.
"""
from copy import deepcopy
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent
ALI=(HERE/'source-round3/01-astra-design/external-ali')
OLD=(HERE/'source-round3/joint-consumer-cold/inputs/7830/research/p104-chart306-chain/DOUBLE-CANDIDATE.json.gz')
ENGINES=(HERE/'source-round3/joint-consumer-cold/inputs/cache/source/research/shared-wire-split-composition/frozen')
PINS={'clifford_exact.py':'2982ead07721e83358dc67c6f49c2b4c16a236a6bebdfd72f58221be1f5d0962',
      'native_verify.py':'3049471905b47b385c88378a1a3be7a18b8858aadd035b8a6da2f4a03b470f38'}
for name,pin in PINS.items():
    assert sha256((ENGINES/name).read_bytes()).hexdigest()==pin
sys.path.insert(0,str(ENGINES))
import clifford_exact as producer
import native_verify as verifier


def read(path):
    return json.loads(gzip.decompress(path.read_bytes()))


def main():
    old=read(OLD); word=read(ALI/'WORD.json.gz')
    layout=read(ALI/'LAYOUT.json.gz')
    assert old['frames']==word['frames']==layout['frames']
    frames=word['frames']
    bm={n:(a,b) for n,a,b in old['moves']}; cm={n:(a,b) for n,a,b in word['moves']}
    changed_moves={n:v for n,v in cm.items() if bm.get(n)!=v}
    changed_helpers={i:((old['initial'][i],old['final'][i]),(word['initial'][i],word['final'][i]))
                     for i in range(len(word['initial']))
                     if (old['initial'][i],old['final'][i])!=(word['initial'][i],word['final'][i])}
    assert set(changed_helpers)=={324,449,1254,1255}
    readers={n:cm[n] for n in (99166,99181,100851,100856,101256)}
    targets={pair for item in changed_helpers.values() for pair in item}
    pairs=targets|set(changed_moves.values())|set(readers.values())
    @lru_cache(None)
    def frame(i): return producer.canonical_frame(9,tuple(frames[i]))
    @lru_cache(None)
    def expected_frame(i): return verifier.frame(tuple(frames[i]),9)
    records=[]
    for a,b in sorted(pairs):
        recipe,_=producer.lower_child(frame(a).adjoint().then(frame(b)))
        assert recipe['rank']==abs(len(frames[a])-len(frames[b]))>0
        actual=verifier.recipe(recipe)
        expected=verifier.adjoint(expected_frame(a))+expected_frame(b)
        verifier.equal(actual,expected,f'chart pair {(a,b)}')
        dense=0
        if (a,b)==(1048,127):
            for observed,reference in ((actual,expected),(verifier.adjoint(actual),verifier.adjoint(expected))):
                for col in range(512):
                    assert verifier.state(observed,col)==verifier.state(reference,col)
                    dense+=1
            bad=deepcopy(recipe); bad['left']['phase']=(bad['left']['phase']+1)%4
            try: verifier.equal(verifier.recipe(bad),expected,'phase fault')
            except ValueError as e: assert str(e)=='phase fault: exact global phase'
            else: raise AssertionError('phase mutation not detected')
        records.append({'source':a,'return':b,'rank':recipe['rank'],'dense_columns_both_directions':dense,
                        'recipe_sha256':sha256(json.dumps(recipe,sort_keys=True,separators=(',',':')).encode()).hexdigest()})
        print('checked',a,b,'rank',recipe['rank'],'dense',dense,flush=True)
    result={'status':'PASS_EXACT_CHANGED_CHART_RECIPES','engine_pins':PINS,
            'changed_paid_moves':[[n,*v] for n,v in sorted(changed_moves.items())],
            'changed_helpers':{str(i):[list(p) for p in v] for i,v in changed_helpers.items()},
            'fresh_owner_324_direct_reader_pairs':readers,'records':records,
            'fresh_helper_324_phase_mutation_rejected':True,
            'scope':'Nine-axis relative Clifford recipes and rank/phase. Tensor-lifted execution and complete physical bank ownership remain separate.'}
    (HERE/'CHARTS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('PASS_EXACT_CHANGED_CHART_RECIPES',len(records),'pairs')


if __name__=='__main__':main()
