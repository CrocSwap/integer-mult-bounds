# Changed rational word: physical precision and owner 324

This self-contained research packet does not claim a new multiplication exponent. It examines Ali Romman's
[ten-edit rational source](https://github.com/aliromman/integer-mult-bounds/tree/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain)
at commit `d018f6ce89ba76b5ac0f56e1e23d73658d7f4681`
and the helper-binding result of [#7906](https://github.com/CrocSwap/integer-mult-bounds/pull/7906) at
`fd0637e6e95189e31d6d4a323d0a80f9030c57c7`. The word and layout canonical
SHA-256 values are `7e74ad15ba7564ad2207acac6c6cafcc57ae3b19386f6d332dd1c0fca968a17e`
and `90929fe1885c0b22004933c22fa57d1bea09f6c1d5955f540e3afb4a8fd0cf42`.
The parent is #7830 word `7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48`.

## Actual owner and return

In one native call, address 324 used to denote owner **338**, entering chart
3 with frame `[]`, returning at chart 234 with frame `[51,85,145,273]`.
Its first direct reader is MOVE 92917 at zero-based clock 40, coefficient
`1/4`, taking 3→337. Nine rows directly read that old input. Its output
row 155092 runs at clock 6031 and has six donors.

The changed address is fresh independent owner **1542**, entering chart 1048
with frame `[3,4,48,72,409]`, returning at chart 127 with frame
`[1,2,4,8,16,32,64,128,256]`. Its first direct reader is MOVE 99166 at
clock 1636, coefficient `−3/4`, taking 1048→874; the first reader of
that move is 100873 at clock 4053. Four other moves read the same input
directly. Output row 155092 runs at clock 6461 and has 18 donors. For the
independent input-324 column, exactly one return contribution is nonzero:
donor 103790 contains `−3/4` and is multiplied by `−4/3`, giving 1.
Other input columns generally contribute to those 18 terms and cancel;
do not remove them on the strength of this one-column observation.

For this one isolated normalized input column, the least common grid for
*each separate product* is **16**: at clock 5479, MOVE 102639 reads donor
102633 with coefficient `1/2`; that donor's total column value is `1/8`,
making an actual product `1/16`. This one-column result does not cover the
other 1,288 inputs or physical Gaussian chart fields. The old 324 column's
corresponding grid is 15,360. [Complete old/new reader and return traces](expected/RETURN-TRACE.json).

The code independently regenerated the entire product grid, not just this
column. The new word has 13,109,869 source-column products, including
7,556,199 with a non-unit literal denominator. Their minimum common grid is

```
35237207388978003467690311680000
  = 2^22 * 8401204917187214724466875.
```

It occupies 105 bits. The odd factor is a product of the four checked short
conversion constants `15658669`, `13190315`, `11159225`, `3645`. The
largest literal uses 37 bits: at clock 156 MOVE 88885 reads input −1289
with coefficient `−69893383680`. The largest literal denominator is
`5559882240`, at clock 41 MOVE 49 reading input −253 with coefficient
`734871943/5559882240`. The largest actual reduced denominator of an
individual basis product is **5682836275200**: at clock 4539 terminal
403 (node 155171, chart 127) reads paid donor 37 with coefficient
`1/986603520`; the input-289 contribution is `−1019/5682836275200`.
[Independent scalar-grid receipt](expected/SCALAR-PRECISION.json).

The grid calculation propagates exact sparse rows independently of the
producer's path-grid algorithm. If a donor row is `v_i/d` and the next
literal is `a/b`, the least common denominator of its separate products over
all source columns is

```
(b*d) / gcd(b*d, |a| * gcd_i(v_i)).
```

Taking the least common multiple of these values over the word is sufficient
for every integer input combination. It is necessary as a common grid:
each individual denominator is witnessed by choosing its source basis
column. This argument is for normalized scalar coefficients; it does not
bound intermediate Gaussian chart transformations.

These are rational exterior-scalar grids. The prior common-root proof also
needs the complete Clifford frame factors, dyadic guards, bounded work width,
and source-specific native execution. The scalar grid alone is not a
physical precision or recovery theorem.

## Bounded tape and call ownership

Using the retained #7786 bounded-scalar compiler on the changed word and
layout, and the #7830 capped wrapper against the independently checked #7786
BIT cap `0.0038799074072`, the full **capped producer replay** passes.
The separate retained expanded audit also passes: it independently checks all
13,109,869 basis products, 575 distinct wide literal plans (941 actual wide
term incidences per call), 5,750 signed boundary cases, and a four-component
actual-grid fixture returning all 1,289 outputs. It independently recounts
the unchanged 48-call caller, ordinary bill, common root and fixed-grid outer
arithmetic. [Producer receipt](expected/QUALIFIED-CAPPED.json) ·
[Independent expanded audit](expected/EXPANDED-CAPPED-AUDIT.json).

The wider lowering is necessary for the retained `W+26` service. At the
actual clock-41 literal above take the claimed grid as the integer input and
`W=106`. Both input and final result fit, but the direct product needs
135 bits while the temporary has only 132, so the unsplit transducer rejects
with `padded product overflow`. The checked sequence of two short divisions,
three short multiplications and one addition returns the exact result. Its
additional clear is charged. [Witness and independent plan audit](expected/INDEPENDENT-AUDIT.json).
In that plan `5559882240 = 10859145 * 512` and
`734871943 = 87 * 2^23 + 5063047`. Since the literal is reduced, an exact
integer product requires the input to be divisible by its denominator; each
of the two short divisions is then exact. The same-sign radix accumulation
stays within the larger of the input and output magnitudes. The independent
audit checks the actual emitted plan and scratch replacements for every wide
literal incidence, not only this example.

Per native call the retained guarded-home plan uses 1,289 immutable entry
homes, 5,700 immutable paid-return homes, 1,289 deferred terminal homes, one
sender and four scalar scratch homes: **8,283 numerical homes**, plus four
separate guarded streams. The conservative 48-call account reserves 397,584
numerical homes, 48 dummy homes, 48 guarded guide tracks and 192 separate
guarded streams. The checked cost has 9,662 extra component services
per native call for wide lowering; the full 48-call ordinary account is
1,319,273,472 scalar services at the retained `2^32` step rate, with
151,849,184,256 ordinary elementary records. The common context constant is
864; the checked root representation is `F=p+D`, `W=p+h+2D+3`, with
`W+26` short-service temporaries. A missing extra clear, inexact division,
insufficient width, early live-sender reuse, partial home clear and altered
phase all have rejection controls. These are the retained model and its
stated predicates, not a materialized machine.

The new source is not allowed to inherit label 338 at address 324. There are
48 distinct call-local helper identities `(call,1542)`; helper addresses are
independent per call. The 400 *main* addresses per call are instead mapped
to the actual long-lived caller roots, which can recur across calls. The
per-call trace checks the named receiver, reader chronology, paid-return
homes and same-owner terminal and records the actual call index. The common
word has 5,700 paid arrivals and 221,651 literal reads per call. Never infer
an owner-to-address binding from the sorted helper-label digest alone: #7906's
swap control shows why that is insufficient.

A separate normalized-scalar interpreter ran a distinct deterministic signed
grid fixture in **every one of the 48 calls**. It checked each actual chart
and call-local reader tag, executed all 941 wide term incidences per call
through the independently checked bounded-width bit programs, and compared
every completed terminal with the declared operator: 45,168 wide incidences
and 61,872 terminal comparisons in all. The 48 values assigned to owner 1542
are distinct and each is recovered at its own return; the signed width for
these fixtures is 170 bits. It also reconstructs the 19,200 main bindings
to caller roots instead of treating those main fields as independent across
calls. This is a concrete scalar execution on a bounded test family, plus
arbitrary-input basis and program checks; it is not physical multidimensional
field execution. [Per-call receipt](expected/INDEPENDENT-AUDIT.json).

The 28 relative chart pairs touched by changed paid routes, changed helper
endpoints and the five new-owner direct readers passed the retained exact
9-axis Clifford compiler and separate Gaussian verifier. The new 1048→127
helper is rank four and was checked on all 512 basis columns in both
orientations; a global-phase mutation is rejected. These checks do not
materialize tensor powers, full spectators or physical bank allocation.
[Exact chart receipts](expected/CHARTS.json).

The capped compiler output's `0.00387990740712` is below the current
incumbent. It uses the older independently checked BIT cap, and remains
conditional on `native_all_columns`, `owned_erasure`, `compiler`,
`precision_tape` and `analytic_recovery`. The source's ordinary home model
normalizes each paid return and clears addressed storage in its finite
fixture. It does not by itself provide a separately materialized full-field
call 0–47 implementation of the fresh owner's real nine-axis transitions,
dirty backing and arbitrary-input erasure. The inherited analytic recovery
premise is also not proved by exact scalar unscaling. A full new application
must bind those specific physical operations to `(call,1542)` and the other
changed endpoints, check the compiler and stock under the desired binary
source, and replay the appropriate outer consumer. Passing raw rational
tariffs or this older capped audit is not a new κ gain.

## Reproduce

The packet uses CPython 3.12 and only the standard library. From this
directory run:

```sh
python3 -I -B verify.py
```

The verifier authenticates every packaged file, rejects an altered journal in
a disposable copy, then replays the full source-bound scalar grid, single
owner return trace, chart recipes, bounded-scalar producer with the independent
BIT cap, independent expanded/caller/outer audit, and all 48 distinct
normalized scalar fixtures. All six receipts must match byte for byte. It
uses one Python process at a time and deletes its temporary working directory.
The bundled inputs are exact source exports and byte pins, not evidence that
those commits are now selected upstream.

The uncapped producer control used a looser BIT cap, so it is not included as
an independently admitted result. Ali Romman supplied the ten-edit graph
and its source credits. Clear1nsight supplied #7906 and the cited predecessor
bounded-scalar audit. The bundled source packages retain the earlier authors’
notices and licenses. This follow-up used OpenAI Codex assistance.
