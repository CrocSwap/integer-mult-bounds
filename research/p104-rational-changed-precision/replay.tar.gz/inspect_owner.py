#!/usr/bin/env python3
"""Inspect the actual old/new role 324 and exact rational scalar grids.

The sparse integer-row engine here is independent of the producer's grid
induction and the prior Fraction/adjoint replay. One process, standard library.
This is a scalar-graph test, not a physical full-field implementation.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from math import gcd, lcm
from pathlib import Path
import gzip
import json

HERE = Path(__file__).resolve().parent
ALI = (HERE/'source-round3/01-astra-design/external-ali')
OLD = (HERE/'source-round3/joint-consumer-cold/inputs/7830/research/p104-chart306-chain/DOUBLE-CANDIDATE.json.gz')
OLDLAYOUT = (HERE/'source-round3/joint-consumer-cold/inputs/7786/research/p104-iterated-returns/continuation/LAYOUT.json.gz')
PINS = {
    'newword': '731246c085638706bdb97e7e88618f8923e27ee4ce8eb4869f0847f8f4699f7c',
    'newlayout': '84cd1d11ff454eecf3504e4b3f26adc371539b17553bfce1bcfda7a331811998',
    'journal': '544840ed2aa50dc16788708c6828fedb667e0c129edd3e3aac09652a056e7b6e',
    'oldword': '1b1b3294e86979f1f41076fb056f3c0a08ace6df7bf80f2886bc579a22962f4b',
    'oldlayout': 'b0f3ebc5710e469f3e8fc5ce159cbba048b563944182b50993431ef94f4fedbf',
}


def load(path, key):
    raw = path.read_bytes()
    if sha256(raw).hexdigest() != PINS[key]:
        raise ValueError(f'{key} pin mismatch')
    return json.loads(gzip.decompress(raw) if raw[:2] == b'\x1f\x8b' else raw)


def entry(g, label):
    first = g['first_output']
    moves = {n: (s, t) for n, s, t in g['moves']}
    forms = {n: [(d, Fraction(q)) for d, q in terms] for n, terms in g['forms']}
    clock = {n: i for i, n in enumerate(g['schedule'])}
    consumers = []
    for n in g['schedule']:
        for d, q in forms[n]:
            if d == ~324:
                a, b = moves[n] if n in moves else (g['final'][n-first], g['final'][n-first])
                consumers.append({'clock': clock[n], 'node': n, 'kind': 'move' if n in moves else 'output',
                                  'target_owner': None if n in moves else n-first,
                                  'source_chart': a, 'return_chart': b, 'coefficient': str(q)})
    ret = first + 324
    return {'label': label, 'input_chart': g['initial'][324], 'input_frame': g['frames'][g['initial'][324]],
            'return_chart': g['final'][324], 'return_frame': g['frames'][g['final'][324]],
            'return_node': ret, 'return_clock': clock[ret],
            'direct_consumers': consumers,
            'return_donors': [[d, str(q), None if d < 0 else clock[d]] for d,q in forms[ret]]}


def analyse(g):
    first = g['first_output']
    moves = {n:(s,t) for n,s,t in g['moves']}
    forms = {n:[(d,Fraction(q)) for d,q in terms] for n,terms in g['forms']}
    state = {~i:(1,{i:1}) for i in range(len(g['initial']))}
    grid = 1
    divcounts = Counter()
    max_literal = (0, None)
    max_literal_den = (0, None)
    max_actual_term_den = (0, None)
    max_row_den = (0, None)
    max_product_group_den = (0, None)
    max_row_mass = (0, None)
    return_rows = {}
    for clock, node in enumerate(g['schedule']):
        terms = []
        for donor, q in forms[node]:
            den, vals = state[donor]
            bit = max(abs(q.numerator).bit_length(), q.denominator.bit_length())
            sample = {'clock':clock,'node':node,'donor':donor,'coefficient':str(q)}
            if bit > max_literal[0]:
                max_literal = bit, sample
            if q.denominator > max_literal_den[0]:
                max_literal_den = q.denominator, sample
            # For one coefficient the reduced denominators' lcm across all
            # source columns is (d*b)/gcd(d*b,a*gcd(row numerators)).
            d = den*q.denominator
            gnum = gcd(*vals.values())
            group_d = d//gcd(d, abs(q.numerator)*gnum)
            grid = lcm(grid, group_d)
            if group_d > max_product_group_den[0]:
                max_product_group_den = group_d, sample
            divcounts[q.denominator] += len(vals)
            # This max is an actual (single source column, donor, coefficient),
            # not only the lcm of several different columns.
            if d > max_actual_term_den[0]:
                for owner, v in vals.items():
                    actual_d = d//gcd(d, abs(q.numerator*v))
                    if actual_d > max_actual_term_den[0]:
                        max_actual_term_den = actual_d, dict(sample, input_owner=owner,
                                                               input_coefficient=str(Fraction(q.numerator*v,d)))
                    if actual_d == d:
                        break
            terms.append((d, vals, q.numerator))
        denom = lcm(*(d for d, _, _ in terms))
        nums = defaultdict(int)
        for d, vals, num in terms:
            scale = num*(denom//d)
            for owner,v in vals.items():
                nums[owner] += scale*v
        nums = {k:v for k,v in nums.items() if v}
        common = gcd(denom,*nums.values())
        denom //= common
        nums = {k:v//common for k,v in nums.items()}
        if denom > max_row_den[0]:
            max_row_den = denom, {'clock':clock,'node':node, 'support':len(nums)}
        mass = sum(abs(v) for v in nums.values())
        if mass > max_row_mass[0]:
            max_row_mass = mass, {'clock':clock,'node':node,'denominator':denom,'support':len(nums)}
        if node in moves:
            state[node] = (denom, nums)
        elif node-first in (324,449,1254,1255):
            return_rows[str(node-first)] = {'denominator':denom, 'coefficients':[[k,v] for k,v in sorted(nums.items())]}
    return {'product_grid':grid,'product_grid_bits':grid.bit_length(),
            'products':sum(divcounts.values()),'nontrivial_divisions':sum(divcounts.values())-divcounts[1],
            'divisor_counts':{str(k):v for k,v in sorted(divcounts.items())},
            'max_literal_bits':{'value':max_literal[0], **max_literal[1]},
            'max_literal_denominator':{'value':max_literal_den[0], **max_literal_den[1]},
            'max_actual_term_denominator':{'value':max_actual_term_den[0], **max_actual_term_den[1]},
            'max_product_group_denominator':{'value':max_product_group_den[0], **max_product_group_den[1]},
            'max_row_denominator':{'value':max_row_den[0], **max_row_den[1]},
            'max_row_numerator_l1':{'value':max_row_mass[0], **max_row_mass[1]},
            'specified_return_rows':return_rows}


def main():
    old, oldlayout = load(OLD,'oldword'), load(OLDLAYOUT,'oldlayout')
    new, newlayout = load(ALI/'WORD.json.gz','newword'), load(ALI/'LAYOUT.json.gz','newlayout')
    events = load(ALI/'EVENTS.json','journal')
    assert oldlayout['source_labels'][324] == 338 and newlayout['source_labels'][324] == 1542
    assert events['birth_source_label'] == 1542 and events['quotient']['pivot'] == 324
    records = [dict(call=i, address=324, old_label=338, old_input=old['initial'][324],
                    old_return=old['final'][324], new_label=1542,
                    new_input=new['initial'][324],new_return=new['final'][324]) for i in range(48)]
    assert len({(r['call'],r['new_label']) for r in records}) == 48
    report = {'source_pins':PINS, 'old_owner':entry(old,338), 'new_owner':entry(new,1542),
              'per_call_formal_owner_map':records, 'changed_precision':analyse(new)}
    audit = json.loads((ALI/'AUDIT.json').read_bytes())
    p=report['changed_precision']
    assert p['product_grid']==audit['minimum_product_grid']
    assert p['max_literal_bits']['value']==audit['literal_peak_bits']
    assert p['products']==audit['products'] and p['nontrivial_divisions']==audit['nontrivial_divisions']
    assert p['divisor_counts']==audit['by_denominator']
    assert p['specified_return_rows']['324']=={'denominator':1, 'coefficients':[[324,1]]}
    (HERE/'SCALAR-PRECISION.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print('PASS_INDEPENDENT_SCALAR_GRID_AND_324_TRACE')
    print('products',p['products'],'grid',p['product_grid'],'peak literal',p['max_literal_bits'])
    print('old/new direct readers',len(report['old_owner']['direct_consumers']),len(report['new_owner']['direct_consumers']))
    print('largest actual term denominator',p['max_actual_term_denominator'])


if __name__ == '__main__':
    main()
