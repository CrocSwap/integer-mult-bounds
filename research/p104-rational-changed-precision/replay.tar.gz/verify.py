#!/usr/bin/env python3
"""Cold-replay the pinned changed-rational precision and owner evidence."""
from hashlib import sha256
from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent
WORD='7e74ad15ba7564ad2207acac6c6cafcc57ae3b19386f6d332dd1c0fca968a17e'
LAYOUT='90929fe1885c0b22004933c22fa57d1bea09f6c1d5955f540e3afb4a8fd0cf42'


def check_manifest(root):
    seen=set()
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest,path=line.split('  ',1)
        assert len(digest)==64 and path not in seen and not path.startswith('/') and '..' not in Path(path).parts
        seen.add(path)
        assert sha256((root/path).read_bytes()).hexdigest()==digest,'SHA-256 mismatch: '+path
    assert seen and not {'SHA256SUMS'}&seen
    actual={p.relative_to(root).as_posix() for p in root.rglob('*')
            if p.is_file() and p!=root/'SHA256SUMS'}
    assert actual==seen, 'missing or unlisted package file'


def main():
    if not __debug__:
        raise RuntimeError('assertions must be enabled')
    check_manifest(HERE)
    optimized=subprocess.run([sys.executable,'-O','-I','-B',str(HERE/'verify.py')],
                             capture_output=True,text=True,timeout=10)
    assert optimized.returncode!=0 and 'assertions must be enabled' in optimized.stderr
    with tempfile.TemporaryDirectory(prefix='p104-physical-cold-',dir=HERE.parent) as temp:
        work=Path(temp)/'case';shutil.copytree(HERE,work)
        # The corruption check deliberately changes a source in the temporary
        # copy only. The original package remains read-only.
        victim=work/'source-round3/01-astra-design/external-ali/EVENTS.json'
        original=victim.read_bytes();victim.write_bytes(original+b' ')
        try:
            check_manifest(work)
        except AssertionError:
            pass
        else:
            raise AssertionError('modified journal unexpectedly accepted')
        victim.write_bytes(original)
        check_manifest(work)
        env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', TMPDIR=temp)
        def run(*args):
            result=subprocess.run([sys.executable,'-I','-B',*map(str,args)],cwd=work,env=env,
                                  capture_output=True,text=True,timeout=180)
            if result.returncode:
                raise RuntimeError('failed '+str(args[0])+'\n'+result.stdout+result.stderr)
            print(result.stdout.strip(),flush=True)
        source=work/'source-round3'
        joint=source/'joint-consumer-cold'
        cache=joint/'inputs/cache'
        parent=joint/'inputs/7786/research/p104-iterated-returns/continuation'
        ali=source/'01-astra-design/external-ali'
        word=ali/'WORD.json.gz';layout=ali/'LAYOUT.json.gz';package=work/'package'
        for script in ('inspect_owner.py','trace_return.py','chart_witness.py'):
            run(work/script)
        run(work/'qualify_capped.py','--package',package,'--cache',cache,
            '--word',word,'--word-sha',WORD,'--layout',layout,'--layout-sha',LAYOUT,
            '--out',work/'QUALIFIED-CAPPED.json')
        run(parent/'audit_expanded.py','--cache',cache,'--word',word,'--layout',layout,
            '--word-sha',WORD,'--layout-sha',LAYOUT,'--receipt',work/'QUALIFIED-CAPPED.json',
            '--binary-receipt',package/'binary/INDEPENDENT.json',
            '--reference-application',package/'evidence/application.json',
            '--out',work/'EXPANDED-CAPPED-AUDIT.json')
        run(work/'audit_candidate.py')
        receipts=['SCALAR-PRECISION.json','RETURN-TRACE.json','CHARTS.json','QUALIFIED-CAPPED.json',
                  'EXPANDED-CAPPED-AUDIT.json','INDEPENDENT-AUDIT.json']
        for name in receipts:
            assert (work/name).read_bytes()==(work/'expected'/name).read_bytes(), 'changed replay: '+name
        print('PASS_CHANGED_SOURCE_SCALAR_OWNER_CHART_AND_CAPPED_OUTER',len(receipts),
              'byte-identical receipts; altered journal and optimized mode rejected',flush=True)
        print('Scope: retained five premises; no physical full-field/erasure proof or new kappa.',flush=True)


if __name__=='__main__':main()
