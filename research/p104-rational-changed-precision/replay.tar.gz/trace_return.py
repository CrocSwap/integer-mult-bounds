#!/usr/bin/env python3
"""Trace old and fresh 324 through one literal scalar call and return."""
from fractions import Fraction
from math import lcm
from pathlib import Path
import gzip
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE/'source-round3'


def read(p):
    return json.loads(gzip.decompress(p.read_bytes()))


def trace(word,label):
    moves={n:(a,b) for n,a,b in word['moves']}
    rows={n:[(d,Fraction(q)) for d,q in ts] for n,ts in word['forms']}
    order=word['schedule']; clock={n:i for i,n in enumerate(order)}
    values={~i:Fraction(int(i==324)) for i in range(len(word['initial']))}
    first_reader={}; last_reader={}; target=word['first_output']+324
    input_column_grid=1
    max_single_column_denominator=(0,None)
    for i,node in enumerate(order):
        for d,_ in rows[node]:
            if d>=0:
                first_reader.setdefault(d,(i,node))
                last_reader[d]=(i,node)
        for d,q in rows[node]:
            product=values[d]*q
            input_column_grid=lcm(input_column_grid,product.denominator)
            if product.denominator>max_single_column_denominator[0]:
                max_single_column_denominator=(product.denominator,
                   {'clock':i,'node':node,'donor':d,'literal':str(q),'product':str(product)})
        value=sum((values[d]*q for d,q in rows[node]),Fraction())
        values[node]=value
    entries=[]
    for donor,q in rows[target]:
        entries.append({'donor':donor,'donor_clock':clock.get(donor),'q':str(q),
                        'source_324_coefficient':str(values[donor]),
                        'contribution_to_324':str(q*values[donor])})
    directs=[]
    for n in order:
        for donor,q in rows[n]:
            if donor==~324:
                directs.append({'node':n,'clock':clock[n],'q':str(q),'charts':moves.get(n),
                                'first_reader':first_reader.get(n),'last_reader':last_reader.get(n)})
    chain=[]
    node=target
    while node>=0:
        donor,q=next((d,q) for d,q in rows[node] if values[d] and q)
        chain.append({'node':node, 'clock':clock[node], 'donor':donor,
                      'coefficient':str(q), 'donor_value_from_324':str(values[donor]),
                      'node_value_from_324':str(values[node]), 'charts':moves.get(node)})
        node=donor
    assert node==~324
    chain.reverse()
    result={'label':label,'input_chart':word['initial'][324],'return_chart':word['final'][324],
            'return_node':target,'return_clock':clock[target], 'return_terms':entries,
            'actual_return_of_input_324':str(values[target]),'first_level_receivers':directs,
            'one_nonzero_path_to_return':chain,'minimum_single_column_product_grid':input_column_grid,
            'worst_single_column_product_denominator':{'value':max_single_column_denominator[0],
                                                        **max_single_column_denominator[1]}}
    assert values[target]==1
    return result


def main():
    old=read(ROOT/'joint-consumer-cold/inputs/7830/research/p104-chart306-chain/DOUBLE-CANDIDATE.json.gz')
    new=read(ROOT/'01-astra-design/external-ali/WORD.json.gz')
    result={'old_owner':trace(old,338),'fresh_owner':trace(new,1542),
            'scope':'One independent normalized scalar column, exact literals and complete ordered donor list. Full field realization is separate.'}
    (HERE/'RETURN-TRACE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    for k in ('old_owner','fresh_owner'):
        z=result[k];print(k,'direct readers',len(z['first_level_receivers']),'return terms',len(z['return_terms']),
                           'nonzero contributions',sum(t['contribution_to_324']!='0' for t in z['return_terms']),
                           'return',z['actual_return_of_input_324'])


if __name__=='__main__':main()
