#!/usr/bin/env python3
"""Independent bounded-scalar audit and 48 call-tagged chronology controls.

The arithmetic audit is the prior independently authored checker, applied to
the freshly qualified changed source. The small tagged-state model below does
not materialize the complete multidimensional fields or prove owned erasure.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
BASE = (HERE/'source-round3/joint-consumer-cold')
ALI = (HERE/'source-round3/01-astra-design/external-ali')


def load(name,path):
    spec=spec_from_file_location(name,path)
    module=module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module


def read(path):
    raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if raw[:2]==b'\x1f\x8b' else raw)


def tagged(word,layout,expected,plans,grid,audit,width):
    moves={n:(a,b) for n,a,b in word['moves']}
    forms={n:[(d,Fraction(q)) for d,q in terms] for n,terms in word['forms']}
    labels=layout['source_labels']; n=len(labels); first=word['first_output']
    assert n==1289 and len(moves)==5700 and len(set(labels))==n and labels[324]==1542
    # The 400 main contacts map to caller roots which can recur in later
    # calls. Only the helper owners have call-local independent identity.
    complex_dir=BASE/'inputs/cache/source/research/p104-dual-supplier-lift/complex'
    sys.path[:0]=[str(complex_dir),str(complex_dir/'retained')]
    from closed_caller import templates,placement
    from mixed_caller import layout_bindings
    caller=read(complex_dir/'retained/data/CALLER.json.gz')
    bound,_,receipt=layout_bindings(templates(caller),placement(caller),layout,48)
    host=layout['hosted']
    secondary=dict(zip(host['Dports'],zip(host['X2'],host['Y2'],strict=True),strict=True))
    slots={p:(x,x+112)+secondary.get(p,()) for p,x in enumerate(layout['live'])}
    mains={i for group in slots.values() for i in group}
    assert len(mains)==400 and 324 not in mains
    helper_owners=set(); main_roots=set(); occurrence_tags=set(); summaries=[]
    for call in range(48):
        # Immutable entry and returned homes, one sender and deferred terminals.
        entry={(call,'entry',label) for label in labels}
        assert len(entry)==n
        occurrences={(call,label) for label in labels}
        assert len(occurrences)==n and not occurrence_tags.intersection(occurrences)
        occurrence_tags.update(occurrences)
        owners={(call,labels[i]) for i in range(n) if i not in mains}
        assert len(owners)==889 and not helper_owners.intersection(owners)
        helper_owners.update(owners)
        mapped={i:root for port,ids in bound[call].items()
                for i,root in zip(slots[port],ids,strict=True)}
        assert set(mapped)==mains and len(set(mapped.values()))==400
        main_roots.update(mapped.values())
        owner_ids={i:('root',mapped[i]) if i in mains else ('helper',call,labels[i]) for i in range(n)}
        assert len(set(owner_ids.values()))==n and owner_ids[324]==('helper',call,1542)
        values=[]
        for i in range(n):
            sample=(i*(37+2*(call%17))+15+3*call)%127-63
            if i==324 and sample==0:
                sample=1
            values.append(grid*sample)
        known={~i:(word['initial'][i],(call,'entry',labels[i],owner_ids[i]),values[i]) for i in range(n)}
        terminal={}; live_sender=None; first_reads={}; calls=Counter(); digest=sha256()
        for clock,node in enumerate(word['schedule']):
            if node in moves:
                source,destination=moves[node]
            else:
                source=word['final'][node-first]; destination=None
            accumulator=0
            for donor,coefficient in forms[node]:
                chart,tag,value=known[donor]
                assert tag[0]==call and chart==source
                calls['read']+=1
                if coefficient in plans:
                    contribution=audit.execute_program(*plans[coefficient],value,width)
                    calls['wide_execution']+=1
                else:
                    contribution,remainder=divmod(value*coefficient.numerator,coefficient.denominator)
                    assert remainder==0
                accumulator+=contribution
                assert -(1<<(width-1))<accumulator<(1<<(width-1))
                if donor in moves and donor not in first_reads:
                    first_reads[donor]=clock
                if donor==~324:
                    assert tag==(call,'entry',1542,('helper',call,1542))
                    digest.update(f'{clock}:{node}:{coefficient};'.encode())
            if node in moves:
                assert live_sender is None and node not in known
                live_sender=(call,'sender',node,source)
                # Only after the ordered return may a reader observe the result.
                known[node]=(destination,(call,'returned',node),accumulator)
                live_sender=None
                calls['move_return']+=1
            else:
                owner=node-first
                assert owner not in terminal
                wanted=sum((q*values[i] for i,q in expected[owner].items()),Fraction())
                assert wanted.denominator==1 and accumulator==wanted
                terminal[owner]=(call,labels[owner],source,accumulator,owner_ids[owner])
                calls['terminal']+=1
        assert live_sender is None and len(first_reads)==len(moves)
        assert len(terminal)==n and terminal[324]==(call,1542,127,values[324],('helper',call,1542))
        assert all(terminal[i][4]==('root',mapped[i]) for i in mains)
        assert calls=={'read':221651,'move_return':5700,'terminal':1289,'wide_execution':941}
        # Deleting all temporary entries here represents their planned full
        # retirement; the operation is not an independent erasure theorem.
        recovered=terminal[324][3]
        del known,terminal
        summaries.append({'call':call,'owner':[call,1542], 'address':324,
                          'input_chart':1048,'return_chart':127,'read_count':calls['read'],
                          'returned_senders':calls['move_return'],'terminal_installs':calls['terminal'],
                          'distinct_main_root_bindings':len(set(mapped.values())),
                          'wide_incidences_executed':calls['wide_execution'],
                          '324_input':values[324],'324_normalized_recovered':recovered,
                          '324_direct_reader_digest':digest.hexdigest()})
    assert len(occurrence_tags)==48*1289 and len(helper_owners)==48*889
    assert receipt['stage_helper_owners']==len(helper_owners) and receipt['native_main_bindings']==48*400
    assert len({x['324_direct_reader_digest'] for x in summaries})==1
    return {'calls':summaries,'all_call_public_occurrence_tags':len(occurrence_tags),
            'call_local_distinct_helper_owners':len(helper_owners),
            'main_root_bindings':48*400,'distinct_caller_roots_used_by_main':len(main_roots),
            'each_reader_chart_and_call_matches':True,
            'all_paid_arrivals_observed_after_return':True,'all_terminals_bound_to_owner':True,
            'each_call_scalar_fixture_recovers_every_terminal':True,'fixture_signed_width':width,
            'wide_incidences_all_calls':48*941,
            'scope':'Distinct tagged normalized-scalar fixture per call with complete-home plan; no multidimensional physical field execution or erasure theorem.'}


def main():
    word=read(ALI/'WORD.json.gz'); layout=read(ALI/'LAYOUT.json.gz')
    receipt=read(HERE/'QUALIFIED-CAPPED.json'); old=read(BASE/'expected/JOINT-RATIONAL-REPLAY.json')
    qual=BASE/'inputs/7786/research/p104-iterated-returns/continuation'
    audit=load('independent_candidate_scalar_audit',qual/'audit_expanded.py')
    reader=load('independent_candidate_graph',BASE/'inputs/cache/parent/complex/independent.py')
    graph=reader.Graph.parse(word); spans=[reader.span(f) for f in graph.frames]
    expected,mains=reader.public_operator(graph,layout,spans)
    grid=audit.basis_grid(graph,expected,receipt['native'],receipt['conversion'])
    plans,programs=audit.audit_plans(word,receipt['conversion']['scalar_cases'])
    fixture=audit.replay_grid(graph,expected,receipt['native'],programs)
    ordinary=audit.audit_ordinary(word,receipt,plans,old['invoice'])

    # A genuine wide, fractional literal on a real input, using an exact grid
    # value for which the legacy unsplit W+26 transducer actually overflows.
    physical=load('source_physical',BASE/'inputs/cache/source/research/p104-dual-supplier-lift/complex/retained/vendor/physical.py')
    compiler=load('source_compiler',qual/'compiler.py')
    q=Fraction(734871943,5559882240); x=grid['product_grid']; w=x.bit_length()+1
    assert (49,-253,str(q)) in [(node,donor,text) for node,terms in word['forms'] for donor,text in terms]
    assert x%q.denominator==0 and (abs(x*q.numerator//q.denominator)).bit_length()<w
    try:
        physical.scalar_service(x,q,w)
    except ValueError as e:
        assert str(e)=='padded product overflow'
        unsplit='padded product overflow'
    else:
        raise AssertionError('wide unsplit scalar unexpectedly accepted')
    y,peak=compiler.execute(compiler.compile_scalar(q),x,w,physical.scalar_service,(17,-91))
    assert y==x*q.numerator//q.denominator and peak==x
    witness={'clock':41,'receiver':49,'donor':-253,'coefficient':str(q),
             'input':x,'width':w,'unsplit_product_bits':(x*q.numerator).bit_length(),
             'unsplit_padding_bits':w+26,'unsplit_rejection':unsplit,
             'split_result':y,'split_peak':peak,'split_result_matches_exact':True}
    result={'status':'PASS_BOUNDED_SCALAR_AND_CALL_TAG_MODEL_ONLY',
            'basis_grid':grid,'all_literal_plans':plans,'four_component_replay':fixture,
            'independent_ordinary_recount':ordinary,'wide_witness':witness,
            'tagged_48_calls':tagged(word,layout,expected,programs,grid['product_grid'],audit,
                                     fixture['fixture_signed_width']+1),
            'scope':'Native normalized-value and tagged-home model with inherited signed caller and owned-erasure assumptions; not an instantiated full-field machine or a new kappa.'}
    (HERE/'INDEPENDENT-AUDIT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['status'],'plans',plans['expanded_coefficients'],'terms',plans['expanded_terms'],
          'basis products',grid['all_basis_products'],'tagged calls',len(result['tagged_48_calls']['calls']))
    print('unsplit rejection:',unsplit,'then exact lowered value:',y)


if __name__=='__main__': main()
