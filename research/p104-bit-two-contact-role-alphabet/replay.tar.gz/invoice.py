"""Recount the unpruned two-contact invoice and a rational negative bound."""

import gzip
import json
import sys
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
from hashlib import sha256
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_binary_operator import Atlas, native_checks

HERE = Path(__file__).resolve().parent
PIN = "d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9"


def main():
    raw = (HERE / "BIT-WORD.json.gz").read_bytes()
    assert sha256(raw).hexdigest() == PIN
    word = json.loads(gzip.decompress(raw))
    atlas = Atlas(word["frames"])
    assert atlas.main_contacts(word["start"], word["final"]) == 111
    forward, adjoint, _ = native_checks(word, atlas)
    assert (forward.dirty, adjoint.dirty) == (3554, 3554)
    assert len(forward.packets) == len(adjoint.packets) == 2874
    native_paid = Counter(p.grade for p in forward.packets.values())
    helper_targets = Counter(atlas.grade(a, b) for a, b in
                             zip(word["start"][222:], word["final"][222:], strict=True))
    assert native_paid == {1: 1376, 2: 1281, 3: 54, 4: 44, 5: 17, 6: 102}
    assert helper_targets == {1: 8, 2: 9, 4: 43, 5: 8, 6: 1, 8: 389}
    assert sum(helper_targets.values()) == 458

    # Two distinct native calls, with separate helper owners at the two visits.
    P = {k: 2 * v for k, v in native_paid.items()}
    T = {k: 2 * v for k, v in helper_targets.items()}
    T[15] = 222  # optimistic: desired mains despite the single-level defect
    p, b = sum(P.values()), sum(T.values())
    pmass, tmass = sum(k*v for k, v in P.items()), sum(k*v for k, v in T.items())
    assert (p, b, pmass, tmass) == (5748, 1138, 9946, 10042)
    main_total = 222**2
    keep_main = 111**2
    lost_main = main_total - keep_main
    main_helper = 2 * 222 * 916
    helper_helper = 916**2
    assert (main_total, keep_main, lost_main) == (49284, 12321, 36963)
    assert main_total + main_helper + helper_helper == b*b
    assert (main_helper, helper_helper) == (406704, 839056)

    # e > 5/2 proves ln(6) < 2 and ln(225) < 6.  For 0 <= C < 1/6,
    #   P_(1-C) >= P_1(1-2C),
    #   225^(1-C) >= 225(1-6C), and T_(1-C) <= T_1.
    # Thus T^2 - lost*225^(1-C) - P^2 is bounded above by
    #   T_1^2 - lost*225*(1-6C) - P_1^2*(1-4C).
    # This is generous even before cleanup: all helper pairs get full credit.
    trials = ["0.003879928046156", "0.003879929046155"]
    results = []
    with localcontext() as ctx:
        ctx.prec = 60
        for s in trials:
            c = Fraction(s)
            assert 0 <= c < Fraction(1, 6)
            upper = (tmass**2 - lost_main*225*(1-6*c)
                     - pmass**2*(1-4*c))
            assert upper < -4_660_000
            # Each original paid tuple has rank at most 6*6=36 and t<1.
            # This lower bound assumes no target loss or cleanup cost and no
            # other new productive credit while deleting original paid tuples.
            min_deletions = (-upper // 36) + 1
            assert min_deletions == 129694
            d, t = Decimal(s), Decimal(1)-Decimal(s)
            paid = sum(Decimal(n)*Decimal(k)**t for k, n in P.items())
            target = sum(Decimal(n)*Decimal(k)**t for k, n in T.items())
            lost = Decimal(lost_main)*Decimal(225)**t
            results.append({
                "trial": s,
                "fixed_word_margin_approx": str(target*target-lost-paid*paid),
                "lost_main_credit_approx": str(lost),
                "rational_margin_upper": str(upper),
                "rational_margin_upper_approx": str(Decimal(upper.numerator)/Decimal(upper.denominator)),
                "minimum_paid_tuple_deletions_if_each_saves_at_most_36": min_deletions,
            })
    U = b + p
    program_counts = Counter(e[0] for e in word["program"])
    assert program_counts == {"MOVE": 2874, "ADD": 32296, "SWAP": 680,
                              "INIT": 3554, "CLEAR": 3554}
    live = peak = 0
    for op, *_ in word["program"]:
        live += (op == "INIT") - (op == "CLEAR")
        assert live >= 0
        peak = max(peak, live)
    assert live == 0 and peak == 3554
    receipt = {
        "word_sha256": PIN,
        "main_ports": 111,
        "all_680_native_rows_each_orientation_checked": True,
        "native_dirty_retirements_each_orientation": 3554,
        "native_peak_private_live_fields": peak,
        "native_paid_histogram": dict(sorted(native_paid.items())),
        "native_helper_histogram": dict(sorted(helper_targets.items())),
        "two_contact": {"calls": 2, "paid_histogram": dict(sorted(P.items())),
                        "assumed_target_histogram": dict(sorted(T.items())),
                        "paid_count": p, "target_count": b,
                        "paid_rank_mass": pmass, "target_rank_mass": tmass,
                        "separate_helper_owners": 916,
                        "native_retirement_operations_per_orientation": 7108},
        "two_level": {"full_paid_tuple_count": p*p, "full_paid_rank_mass": pmass**2,
                      "all_main_pairs": main_total, "selected_main_pairs": keep_main,
                      "surrendered_main_pairs": lost_main,
                      "optimistically_credited_main_helper_pairs": main_helper,
                      "optimistically_credited_helper_helper_pairs": helper_helper,
                      "fixed_template_occurrences": U,
                      "native_templates": 2*U,
                      "native_retirement_template_operations": 7108*U},
        "trials": results,
        "scope": "Unpruned two-contact fixed word; helper pairs and uncoupled mains optimistically credited; no cleanup or extra caller charges. No claim for a changed paid schedule.",
    }
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
