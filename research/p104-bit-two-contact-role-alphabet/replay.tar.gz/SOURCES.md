# Source pins

The following five files are exact, unmodified bytes from Ali Romman's public
[`d018f6ce89ba76b5ac0f56e1e23d73658d7f4681` package](https://github.com/aliromman/integer-mult-bounds/tree/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain).
SHA-256 is over the actual file bytes, including gzip framing.

| Included file | Public pinned source | SHA-256 |
| --- | --- | --- |
| `BIT-WORD.json.gz` | [binary word](https://github.com/aliromman/integer-mult-bounds/blob/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain/BIT-WORD.json.gz) | `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9` |
| `BINARY-PRODUCT.md` | [peer test and provenance](https://github.com/aliromman/integer-mult-bounds/blob/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain/BINARY-PRODUCT.md) | `573343898230dad6adb7d59b7b066c3a85dacbf60474597a6c4847c52598ccf1` |
| `verify_binary_product.py` | [peer verifier](https://github.com/aliromman/integer-mult-bounds/blob/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain/verify_binary_product.py) | `942b66f954a2114648d7ec07db5ddd7156a6fe7d77cd12fa5763893d521a8960` |
| `PARENT-NOTICE` | [predecessor notice](https://github.com/aliromman/integer-mult-bounds/blob/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain/PARENT-NOTICE) | `b213998c8dae6d88e4a1f0fd17c81dd78c31ef35bc9460fa16ca692326f1a02b` |
| `LICENSE` | [Apache-2.0 license](https://github.com/aliromman/integer-mult-bounds/blob/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain/LICENSE) | `c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4` |

The binary word is also the identical file in Clear1nsight's
[pinned iterated-returns predecessor](https://github.com/CrocSwap/integer-mult-bounds/blob/89a67c404226d51028e135de2b9169e9020d57af/research/p104-iterated-returns/binary/WORD.json.gz).

`native_binary_operator.py` is the included, unmodified local comparator-review
checker, SHA-256 `36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349`.
It is not represented as a previously published source. `check_role_blocks.py`
extends the peer test, `invoice.py` uses that local native checker, and
`verify.py` runs both and their controls. Their hashes and the hashes of all
other package files are listed in `SHA256SUMS`.
