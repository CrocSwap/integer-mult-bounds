"""Replay the complete role-code screen and its controls, serially and offline."""

import gzip
import json
import shutil
import subprocess
import sys
import tempfile
from fractions import Fraction
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
PINS = {
    "BIT-WORD.json.gz": "d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9",
    "BINARY-PRODUCT.md": "573343898230dad6adb7d59b7b066c3a85dacbf60474597a6c4847c52598ccf1",
    "verify_binary_product.py": "942b66f954a2114648d7ec07db5ddd7156a6fe7d77cd12fa5763893d521a8960",
    "PARENT-NOTICE": "b213998c8dae6d88e4a1f0fd17c81dd78c31ef35bc9460fa16ca692326f1a02b",
    "LICENSE": "c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4",
    "native_binary_operator.py": "36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def run_script(name):
    return subprocess.run([sys.executable, "-I", "-B", str(HERE / name)],
                          cwd=HERE, capture_output=True, check=True,
                          timeout=30).stdout


def main():
    manifest = {}
    for line in (HERE / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split("  ", 1)
        require(Path(name).name == name and name not in manifest, "manifest name")
        manifest[name] = digest
        require(sha256((HERE / name).read_bytes()).hexdigest() == digest,
                f"package digest: {name}")
    present = {p.name for p in HERE.iterdir() if p.is_file()} - {"SHA256SUMS"}
    require(set(manifest) == present, "manifest covers every file")
    for name, digest in PINS.items():
        require(manifest[name] == digest, f"immutable source pin: {name}")

    peer = run_script("verify_binary_product.py")
    require(b"diagonal control gives zero mixed addresses" in peer and b"gives 50" in peer,
            "peer counterexample")
    role_raw = run_script("check_role_blocks.py")
    invoice_raw = run_script("invoice.py")
    require(role_raw == (HERE / "ROLE-BLOCKS.json").read_bytes(), "role receipt")
    require(invoice_raw == (HERE / "INVOICE.json").read_bytes(), "invoice receipt")
    roles = json.loads(role_raw)
    invoice = json.loads(invoice_raw)

    # Both nonzero directions matter: equal-weight roles 01 and 10 collide.
    require(roles["actual_source_rows_target_columns"][1][2] == 50 and
            roles["diagonal_source_rows_target_columns"][1][2] == 0,
            "diagonal control and equal-weight failure")
    require(len(roles["witness_edges"]) == 6 and
            roles["maximum_sample_independent_cardinality"] == 1,
            "all pair witnesses")
    require(roles["adjoint_source_rows_target_columns"][0] == [1, 36, 2, 40],
            "discarded adjoint outputs are nonzero")
    require(all(Fraction(row["rational_margin_upper"]) < -4_660_000 and
                row["minimum_paid_tuple_deletions_if_each_saves_at_most_36"] == 129694
                for row in invoice["trials"]), "rational invoice bounds")

    # A wrong destination must fail as a forward witness and as its transpose.
    sys.path.insert(0, str(HERE))
    from check_role_blocks import run, run_adjoint
    from verify_binary_product import DESTINATION, SOURCE
    word = json.loads(gzip.decompress((HERE / "BIT-WORD.json.gz").read_bytes()))
    wrong = (DESTINATION[0] + 1, *DESTINATION[1:])
    require(wrong not in run(word, 0, 1, True)[1, 0], "wrong forward destination")
    require(SOURCE not in run_adjoint(word, 1, 0, wrong)[0, 1],
            "wrong transposed destination")

    # Exercise the peer's digest gate against a changed compressed source byte.
    with tempfile.TemporaryDirectory(prefix="p104-role-code-") as temp:
        directory = Path(temp)
        shutil.copyfile(HERE / "verify_binary_product.py", directory / "verify_binary_product.py")
        tampered = bytearray((HERE / "BIT-WORD.json.gz").read_bytes())
        tampered[-1] ^= 1
        (directory / "BIT-WORD.json.gz").write_bytes(tampered)
        result = subprocess.run([sys.executable, "-I", "-B", "verify_binary_product.py"],
                                cwd=directory, capture_output=True, timeout=30)
        require(result.returncode != 0 and b"binary word digest" in result.stderr,
                "tampered-source control")
    print("PASS: two-level role-code screen and controls")


if __name__ == "__main__":
    main()
