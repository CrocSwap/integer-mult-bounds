"""Directed impulse screen for the two-level P104 two-contact role code.

This reuses only the pinned peer's reflection routine and source constants.
The result is a *witness* screen: zero for one impulse is not an operator proof.
"""

import gzip
import itertools
import json
import sys
from functools import cache
from hashlib import sha256
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_binary_product import (AXES, DESTINATION, PORT, SOURCE, WORD_SHA256,
                                   caller as original_caller, reflect, require)


def run(word, outer_source, inner_source, defects):
    @cache
    def matrix(chart):
        return reflect(word["frames"][str(chart)])

    @cache
    def change(address, chart, stage):
        positions = AXES[stage]
        data = [address[i] for i in positions]
        target = list(address)
        for i, row in zip(positions, matrix(chart), strict=True):
            target[i] = sum(a * b for a, b in zip(row, data, strict=True))
        return tuple(target)

    def contact(values, stage):
        size = word["public"] + word["owned_fields"]
        direct = [set() for _ in range(size)]  # inner role 1
        mixed = [set() for _ in range(size)]   # inner role 0
        tags = word["start"].copy() + [None] * word["owned_fields"]
        for port, (a, b) in zip(PORT, values, strict=True):
            direct[port] = {change(v, tags[port], stage) for v in a}
            mixed[port] = {change(v, tags[port], stage) for v in b}
        for op, i, *args in word["program"]:
            if op == "MOVE":
                before, after = args
                require(tags[i] == before, "move source")
                if defects and direct[i]:
                    moved = {change(change(v, before, stage), after, stage)
                             for v in direct[i]}
                    mixed[i] ^= direct[i] ^ moved
                tags[i] = after
            elif op == "ADD":
                j, chart = args
                require(tags[i] == tags[j] == chart, "ADD charts")
                direct[i] ^= direct[j]
                mixed[i] ^= mixed[j]
            elif op == "SWAP":
                j, = args
                for state in (direct, mixed, tags):
                    state[i], state[j] = state[j], state[i]
            elif op == "INIT":
                chart, = args
                require(tags[i] is None, "INIT owner")
                tags[i] = chart
            elif op == "CLEAR":
                chart, = args
                require(tags[i] == chart, "CLEAR owner")
                tags[i] = None
                direct[i].clear()
                mixed[i].clear()
            else:
                raise ValueError(op)
        require(tags[:word["public"]] == word["final"], "public final charts")
        require(all(tag is None for tag in tags[word["public"]:]), "owned return")
        # For the chosen input/output port, the other port and helper endpoint
        # channels vanish through the next diagonal native endpoint. The inner
        # defect is nilpotent, so mixed-to-mixed transfer is diagonal.
        return [({change(v, tags[i], stage) for v in direct[i]},
                 {change(v, tags[i], stage) for v in mixed[i]}) for i in PORT]

    def add(x, y):
        return x[0] ^ y[0], x[1] ^ y[1]

    empty = (set(), set())
    bit = (set(), {SOURCE}) if inner_source == 0 else ({SOURCE}, set())
    x, y = (bit, empty) if outer_source == 0 else (empty, bit)
    x, y = y, x
    x = add(x, y)
    x, y = contact((x, y), 0)
    y = add(y, x)
    y, x = contact((y, x), 1)
    # Each pair is (inner 1, inner 0).
    return {(0, 1): y[0], (0, 0): y[1],
            (1, 1): x[0], (1, 0): x[1]}


def run_adjoint(word, outer_source, inner_source, point=SOURCE):
    """Transpose the literal address-level straight-line program, including resets."""
    @cache
    def matrix(chart):
        return reflect(word["frames"][str(chart)])

    @cache
    def change(address, chart, stage):
        positions = AXES[stage]
        data = [address[i] for i in positions]
        target = list(address)
        for i, row in zip(positions, matrix(chart), strict=True):
            target[i] = sum(a * b for a, b in zip(row, data, strict=True))
        return tuple(target)

    def contact(values, stage):
        size = word["public"] + word["owned_fields"]
        direct = [set() for _ in range(size)]
        mixed = [set() for _ in range(size)]
        tags = word["final"].copy() + [None] * word["owned_fields"]
        for port, (a, b) in zip(PORT, values, strict=True):
            direct[port] = {change(v, tags[port], stage) for v in a}
            mixed[port] = {change(v, tags[port], stage) for v in b}
        for op, i, *args in reversed(word["program"]):
            if op == "MOVE":
                before, after = args
                require(tags[i] == after, "adjoint move destination")
                if mixed[i]:
                    back = {change(change(v, after, stage), before, stage)
                            for v in mixed[i]}
                    direct[i] ^= mixed[i] ^ back
                tags[i] = before
            elif op == "ADD":
                j, chart = args
                require(tags[i] == tags[j] == chart, "adjoint ADD charts")
                direct[j] ^= direct[i]
                mixed[j] ^= mixed[i]
            elif op == "SWAP":
                j, = args
                for state in (direct, mixed, tags):
                    state[i], state[j] = state[j], state[i]
            elif op == "CLEAR":
                chart, = args
                require(tags[i] is None, "adjoint CLEAR")
                tags[i] = chart
            elif op == "INIT":
                chart, = args
                require(tags[i] == chart, "adjoint INIT")
                tags[i] = None
                direct[i].clear()
                mixed[i].clear()
            else:
                raise ValueError(op)
        require(tags[:word["public"]] == word["start"], "adjoint start charts")
        require(all(tag is None for tag in tags[word["public"]:]), "adjoint owned return")
        return [({change(v, tags[i], stage) for v in direct[i]},
                 {change(v, tags[i], stage) for v in mixed[i]}) for i in PORT]

    def add(x, y):
        return x[0] ^ y[0], x[1] ^ y[1]

    empty = (set(), set())
    bit = (set(), {point}) if inner_source == 0 else ({point}, set())
    x, y = (bit, empty) if outer_source == 0 else (empty, bit)
    x, y = y, x
    y, x = contact((y, x), 1)
    x = add(x, y)
    x, y = contact((x, y), 0)
    y = add(y, x)
    x, y = y, x
    return {(0, 1): x[0], (0, 0): x[1],
            (1, 1): y[0], (1, 0): y[1]}


def main():
    packed = Path(__file__).with_name("BIT-WORD.json.gz").read_bytes()
    require(sha256(packed).hexdigest() == WORD_SHA256, "word digest")
    word = json.loads(gzip.decompress(packed))
    require(original_caller(word, True)[1][1] == run(word, 0, 1, True)[1, 0],
            "pinned counterexample exact set")
    require(DESTINATION in run(word, 0, 1, True)[1, 0], "known address")
    require(SOURCE in run_adjoint(word, 1, 0, DESTINATION)[0, 1],
            "transpose of known 50-address witness")
    roles = list(itertools.product(range(2), repeat=2))
    outputs = {}
    diagonal = {}
    adjoint = {}
    actual_sets = {}
    for role in roles:
        out = run(word, *role, True)
        ctrl = run(word, *role, False)
        actual_sets[role] = out
        outputs[role] = {target: len(out[target]) for target in roles}
        diagonal[role] = {target: len(ctrl[target]) for target in roles}
        out_adj = run_adjoint(word, *role)
        adjoint[role] = {target: len(out_adj[target]) for target in roles}
    expected = [[1, 0, 0, 0], [36, 1, 50, 0], [2, 0, 1, 0], [40, 2, 66, 1]]
    require([[outputs[a][b] for b in roles] for a in roles] == expected,
            "all sixteen expected impulse counts")
    require([[adjoint[a][b] for b in roles] for a in roles] ==
            [list(c) for c in zip(*expected, strict=True)],
            "all sixteen adjoint impulse counts")
    edges = [(a, b) for a, b in itertools.combinations(roles, 2)
             if outputs[a][b] or outputs[b][a]]
    good = [s for k in range(1, 5) for s in itertools.combinations(roles, k)
            if not any(a in s and b in s for a, b in edges)]
    maximum = max(map(len, good))
    require(len(edges) == 6 and maximum == 1, "complete pairwise witness graph")
    witnesses = []
    for a, b in edges:
        source, target = (a, b) if outputs[a][b] else (b, a)
        address = DESTINATION if (source, target) == ((0, 1), (1, 0)) else min(actual_sets[source][target])
        require(address in actual_sets[source][target], "recorded witness")
        witnesses.append({"source_role": source, "target_role": target,
                          "target_address": [str(v) for v in address]})
    receipt = {
        "source_word_sha256": WORD_SHA256,
        "port": 0,
        "source_coordinates": SOURCE,
        "role_order": roles,
        "actual_source_rows_target_columns": [[outputs[a][b] for b in roles] for a in roles],
        "diagonal_source_rows_target_columns": [[diagonal[a][b] for b in roles] for a in roles],
        "adjoint_source_rows_target_columns": [[adjoint[a][b] for b in roles] for a in roles],
        "adjoint_reverses_known_address_witness": True,
        "witness_edges": edges,
        "explicit_edge_witnesses": witnesses,
        "maximum_sample_independent_cardinality": maximum,
        "maximum_sample_independent_sets": [s for s in good if len(s) == maximum],
        "note": "Positive counts prove nonzero directed blocks. Zero counts are not operator proofs.",
    }
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
