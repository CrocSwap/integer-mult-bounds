# Two-level binary role-code screen

This self-contained package tests the two-contact binary caller and its natural two-level chronological matchers. The published `01 -> 10` impulse has 50 mixed addresses. Six positive port-0 witnesses exclude every two-role uniform alphabet. The chosen singleton `{00}` has nonzero adjoint outputs in all three discarded roles, so its returned-zero restriction is not established. A separate deliberately favorable invoice for the **unpruned** fixed word is negative at both requested trials. See [RESULT.md](RESULT.md) for the exact scope, counts and proof of the upper bound.

## Run offline

From this directory, with CPython 3.12 and its standard library:

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```

The second command runs a bounded sequential replay and compares its generated outputs byte-for-byte with [ROLE-BLOCKS.json](ROLE-BLOCKS.json) and [INVOICE.json](INVOICE.json), without rewriting the receipts. It also tests that a corrupted word is rejected, the equal-weight pair fails, the diagonal control removes the 50-address block, an incorrect destination is rejected in both orientations, and the adjoint of the selected `00` impulse contaminates discarded roles. The native check separately verifies every public row in each orientation and rejects an omitted bridge read and omitted dirty retirement. The expected final line is `PASS: two-level role-code screen and controls`.

The peer replay and the two new checks may also be run individually:

```sh
python3 -I -B verify_binary_product.py
python3 -I -B check_role_blocks.py
python3 -I -B invoice.py
```

No network access, package installation, or workspace files are required. [SOURCES.md](SOURCES.md) identifies the unchanged public bytes and the included local comparator checker; [NOTICE](NOTICE), [PARENT-NOTICE](PARENT-NOTICE), and [LICENSE](LICENSE) preserve attribution and license terms. The negative result applies to the stated matcher, uniform role alphabet and fixed paid schedule. It does not exclude another caller or prove a κ gain.
