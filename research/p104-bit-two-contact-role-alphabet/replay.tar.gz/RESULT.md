# Two-level role-code screen for the two-contact BIT caller

The uniformly chosen code `{00}` does not produce a qualified two-sided supplier. At port 0 every pair of the four two-level main roles has a witnessed directed cross term, so any uniform role alphabet that demands independent main roots has at most one member. The adjoint sends an input in the chosen `00` role into all three discarded roles. Moreover, retaining one quarter of the main/main targets makes even an optimistic **unpruned** native invoice negative by millions at both requested trials. This is a bounded negative screen for the stated fixed caller and matcher, not a no-go for a new caller, a different code at different port pairs, or a reoptimized paid schedule.

## Source and exact role calculation

The source is Ali Romman's [pinned two-contact test at d018f6c](https://github.com/aliromman/integer-mult-bounds/tree/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain). The unchanged `BIT-WORD.json.gz` has SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`. The unchanged peer test and its description are copied here as `verify_binary_product.py` and `BINARY-PRODUCT.md`. The peer's test first passes as published and yields 50 wrong addresses in the directed block `01 -> 10`.

`check_role_blocks.py` uses the same rational chart reflections, 15-coordinate source impulse, actual 42,958-instruction native word, natural inverse matchers and two-contact chronology. It repeats the construction for all four input roles, and separately transposes the literal straight-line program (including XOR orientation, reflection order, initialization and retirement) for the adjoint. The same port-boundary reduction as the peer test applies: after the first contact, a mixed value at another port/helper cannot return to port 0 through the second diagonal native endpoint, and the inner defect is nilpotent. It independently checks that the named destination in the peer's `01 -> 10` result maps back to the source in the adjoint. The full address witness for each of the six unordered role pairs is in `ROLE-BLOCKS.json`.

Rows are input role and columns output role, in order `00,01,10,11`. An entry is the **number of nonzero output addresses for this one input impulse**, not a rank or a complete operator description:

```text
forward             adjoint
 1   0   0   0       1  36   2  40
36   1  50   0       0   1   0   2
 2   0   1   0       0  50   1  66
40   2  66   1       0   0   0   1
```

The diagonal-only forward control has rows `1,0,0,0`; `0,1,0,0`; `2,0,1,0`; `0,2,0,1`. The 50 cross addresses therefore are absent in the control. Every one of the six unordered pairs has at least one nonzero directed witness. Thus the complete-graph upper bound of one retained role uses only **positive** witnesses; it does not infer that any block is zero from a sample. In particular this does not establish compatibility among different port pairs or with independent helper inputs. The 111-by-111 port-pair count in the invoice is for a uniform alphabet applied everywhere, with real, distinct owners, not additional free tag axes.

For the chosen `{00}`, this impulse has no off-code forward main output, but its adjoint has 36, 2 and 40 nonzero addresses in roles `01`, `10` and `11`, respectively. A returned-zero specialization cannot simply discard those outputs. One must exhibit and price actual erasure/uncomputation or charge a legal arrangement that restores the borrowed fields. No such corrected two-sided product is claimed here.

## Paid, targets, helper owners and stock

`invoice.py` imports the included, pinned `native_binary_operator.py` checker from a separate local comparator review. It checks all 680 native public rows in each orientation, all 111 port decompositions and the nested grades. The native instruction counts are 2,874 MOVE, 32,296 ADD, 680 SWAP, 3,554 INIT and 3,554 CLEAR. The checker sees 3,554 dirty private retirements in **each** orientation on arbitrary public inputs; native retirement must be implemented and billed. It does not establish the new product's cleanup.

Per native call the paid grade histogram is `{1:1376, 2:1281, 3:54, 4:44, 5:17, 6:102}` and the 458 helper target histogram is `{1:8, 2:9, 4:43, 5:8, 6:1, 8:389}`. Two unpruned contacts therefore have 5,748 native paid events, with rank mass 9,946. They require 916 independent helper owners if the 458 helper jobs of each contact are to be credited separately. Assuming the 222 defective main fields could each be made a rank-15 target for free gives the following deliberately generous one-factor target histogram:

```text
{1:16, 2:18, 4:86, 5:16, 6:2, 8:778, 15:222}
```

That is 1,138 hypothetical independent target fields with rank mass 10,042. The 916 helper owners are separate physical field roles, not freely supplied labels. Reusing or colliding stage-one and stage-two helpers changes the target map; it cannot keep both credits without an independent construction and new bill. The unchanged native calls alone also have 7,108 INIT and 7,108 CLEAR operations and 64,592 ADD and 1,360 SWAP instructions; the proposed caller adds two XORs and two swaps. The count `3,554` is the native word's peak private live-field count; the two sequential calls can reuse private backing only after the first is actually retired.

In the hypothetical two-level product, before restriction, there are `222^2 = 49,284` main/main targets. Exactly `111^2 = 12,321` have the uniform code `00`; the remaining 36,963 rank-225 targets are surrendered. For the optimistic bound, all 406,704 main/helper and 839,056 helper/helper pairs are credited at their full tensor ranks even though helper interactions and owner feasibility were not checked. Thus the bound cannot hide a loss due to a helper collision; it assumes those losses are zero. It also assumes zero extra cost for correction, endpoint restriction, helper routing, stock return, local ordinary operations and compiler lifts.

The **unpruned** fixed chronological construction retains all `5748^2 = 33,039,504` paid tuples, rank mass `9946^2 = 98,922,916`. Under the standard two-level occurrence count `b+p = 1138+5748 = 6,886`, this is 13,772 native call templates and 48,945,688 native retirement template operations in each orientation if the original templates are carried intact. This is a count of scheduled template events, not simultaneous backing or a claim that every specialized retirement remains dirty. Allocation, full lifetime, actual lifted field sizes, and every specialization and return still need an implementation-specific invoice. A changed schedule may prove certain work removable; no such omission is assumed here.

## Rigorous favorable bound at both trials

Let `C` be the trial, `t=1-C`, `P_t` and `T_t` the moments of the generous one-factor histograms above. Ignoring all costs except original paid tuples and surrendering only the three unchosen main/main codes gives margin

```text
M = T_t^2 - 36,963 * 225^t - P_t^2.
```

For the two trials, the decimal evaluations of this optimistic expression are approximately `-7,443,688.9464664` and `-7,443,689.2130025`. The sign does not rely on decimal rounding: for `0 <= C < 1/6`, `ln(6)<2`, `ln(225)<6`, and `exp(-u)>=1-u` give

```text
M <= 10042^2 - 36,963*225*(1-6C) - 9946^2*(1-4C)
   = -6,397,827 + 445,591,714*C.
```

At `C=0.003879928046156`, the exact rational upper bound is `-583620401464584606077/125000000000000`, about `-4,668,963.212`. At `C=0.003879929046155` it is `-466896276612540844033/100000000000000`, about `-4,668,962.766`. Both are strictly negative before any omitted overhead or cleanup cost. Each original paid tuple has rank at most `6*6=36`, so, holding these target credits fixed, deleting original tuples would require at least 129,694 such deletions even if each saved the full amount 36 and cleanup were free. These bounds do not rule out schedules that remove paid jobs or change the helper/main target ranks.

## Reproduction and limits

Run the complete, offline replay from this directory, using one CPU:

```sh
python3 -I -B verify.py
```

The source word and peer witness are due to Ali Romman and the credited native-word authors; the separate checker is from a retained local comparator review (SHA-256 `36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349`). The output is a local research screen, without independent human or formal-kernel review. It does not prove a full arbitrary-input two-sided caller, helper independence, a physical ownership map, priced restriction and cleanup, finite compiler, precision/ordinary BIT work, rational consumer, outer application, or a new conditional κ bound.
