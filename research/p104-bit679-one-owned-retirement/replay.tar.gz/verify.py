#!/usr/bin/env python3
"""Cold replay plus a separate, direct interpreter for both audited cuts."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip
import json
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def must(ok, what):
    if not ok:
        raise AssertionError(what)


def read(path):
    data = path.read_bytes()
    return json.loads(gzip.decompress(data) if path.suffix == '.gz' else data)


def inventory():
    names = []
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        must(not path.is_absolute() and '..' not in path.parts, 'unsafe inventory path')
        must(sha256((ROOT / path).read_bytes()).hexdigest() == digest, 'inventory ' + name)
        names.append(name)
    must({'check.py', 'verify.py', 'README.md', 'RESULT.json', 'inputs/CONTROL-WORD.json.gz',
          'inputs/EFREE-CALLER.json.gz', 'inputs/INVOICE.json'} <= set(names), 'inventory incomplete')
    return names


def direct_replay(w, result, adjoint):
    n = w['public']
    bank = [1 << i for i in range(n)] + [0] * w['owned_fields']
    chart = (w['final'] if adjoint else w['start'])[:] + [None] * w['owned_fields']
    case = result['base_and_amended'][1 if adjoint else 0]
    data = result['base_and_amended'][1]['cut']['adjoint_retirement']
    donors = data['donors']
    seen = set()
    seq = range(len(w['program']) - 1, -1, -1) if adjoint else range(len(w['program']))
    for t in seq:
        op, target, *args = w['program'][t]
        if not adjoint and t == 31282:
            must(chart[3551] == 1 and bank[3551] == 0, 'forward insertion after open')
            must(all(chart[d] == 1 for d in donors), 'all inserted contacts chart 1')
            seen.add('forward_open')
        if not adjoint and t == 38712:
            must((chart[3551], bank[3551], chart[0], bank[0]) == (2, 1, 1, 1),
                 'forward first clear and extracted receipt')
            seen.add('forward_cut')
        if adjoint and t == 31281:
            must((chart[3551], bank[3551]) == (1, 1), 'adjoint target')
            must(len(donors) == len(set(donors)) == 86, 'donor count and uniqueness')
            total = 0
            for d in donors:
                must(chart[d] == 1 and bank[d], 'adjoint donor contact')
                total ^= bank[d]
            must(total == bank[3551] and (total ^ bank[donors[0]]) != bank[3551],
                 'adjoint combination and negative control')
            must([[d, hex(bank[d])] for d in donors] == data['donor_rows'], 'donor masks')
            seen.add('adjoint_cut')
        if op in ('INIT', 'CLEAR'):
            opens = op == ('CLEAR' if adjoint else 'INIT')
            if opens:
                must(chart[target] is None, 'open')
                chart[target] = args[0]
            else:
                must(chart[target] == args[0], 'close')
                chart[target] = None
            bank[target] = 0
        elif op == 'ADD':
            other, c = args
            must(chart[target] == chart[other] == c, 'ADD chart')
            if adjoint:
                bank[other] ^= bank[target]
            else:
                bank[target] ^= bank[other]
        elif op == 'MOVE':
            before, after = args[::-1] if adjoint else args
            must(chart[target] == before, 'MOVE chart')
            chart[target] = after
        elif op == 'SWAP':
            other = args[0]
            bank[target], bank[other] = bank[other], bank[target]
            chart[target], chart[other] = chart[other], chart[target]
        else:
            raise AssertionError('unrecognized instruction')
    expected = []
    for i in range(n):
        row = 1 << i
        if adjoint and i < 111:
            row ^= 1 << (i + 111)
        if not adjoint and 111 <= i < 222:
            row ^= 1 << (i - 111)
        expected.append(row)
    must(bank[:n] == expected and not any(bank[n:]), 'independent source endpoint')
    expected_hash = sha256(json.dumps([hex(x) for x in expected], sort_keys=True,
                                      separators=(',', ':')).encode()).hexdigest()
    must(case['public_rows_sha256'] == expected_hash, 'published source row digest')
    must(seen == ({'adjoint_cut'} if adjoint else {'forward_open', 'forward_cut'}), 'cut coverage')


def verify_reader_table(w, result):
    rows = result['affected_native_readers']
    for key, item in rows.items():
        bank = int(key)
        every, read = [], []
        for t, ins in enumerate(w['program']):
            op, target, *args = ins
            if target == bank or (op in ('ADD', 'SWAP') and args[0] == bank):
                every.append([t, ins])
            if op == 'ADD' and args[0] == bank:
                read.append([t, ins])
        must(item['native_operand_touches'] == len(every) and
             item['first_native_touch'] == (every[0] if every else None) and
             item['last_native_touch'] == (every[-1] if every else None) and
             item['native_add_source_reads'] == len(read) and
             item['first_native_add_source_read'] == (read[0] if read else None) and
             item['last_native_add_source_read'] == (read[-1] if read else None),
             'reader table ' + key)
    donor_set = set(result['base_and_amended'][1]['cut']['adjoint_retirement']['donors'])
    must(set(map(int, rows)) == donor_set | {0, 3551}, 'all affected reader banks covered')


def main():
    names = inventory()
    w = read(ROOT / 'inputs/CONTROL-WORD.json.gz')
    result = read(ROOT / 'RESULT.json')
    direct_replay(w, result, False)
    direct_replay(w, result, True)
    verify_reader_table(w, result)
    with TemporaryDirectory(prefix='cold-', dir=ROOT) as path:
        dest = Path(path)
        for name in names:
            q = dest / name
            q.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, q)
        p = subprocess.run([sys.executable, '-I', '-B', 'check.py'], cwd=dest,
                           capture_output=True, text=True)
        must(p.returncode == 0, 'cold replay: ' + p.stderr)
        must(read(dest / 'RESULT.json') == result, 'cold result mismatch')
        word = dest / 'inputs/CONTROL-WORD.json.gz'
        b = bytearray(word.read_bytes())
        b[len(b) // 2] ^= 1
        word.write_bytes(b)
        bad = subprocess.run([sys.executable, '-I', '-B', 'check.py'], cwd=dest,
                             capture_output=True, text=True)
        must(bad.returncode != 0 and 'input pin' in bad.stderr, 'changed word accepted')
    print('PASS_COLD_REPLAY_INDEPENDENT_CUTS_AND_ALL_AFFECTED_READERS')


if __name__ == '__main__':
    main()
