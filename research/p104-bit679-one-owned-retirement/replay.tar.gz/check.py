#!/usr/bin/env python3
"""Two-orientation scalar erasure test of the pinned R5/10 word.

This deliberately interprets a MOVE as a paid chart-tag change, exactly as
the parent literal interpreter does.  It is not a physical realization of a
graded MOVE or a proof for the 3550 remaining dirty native retirements.
"""
from collections import Counter
from decimal import Decimal, localcontext
from hashlib import sha256
from pathlib import Path
import gzip
import json

HERE = Path(__file__).resolve().parent
PINS = {
    'CONTROL-WORD.json.gz': '1eba53d44095b27353d40e5b45c65a3ea1a34ec7fdf8c82edfd255d2371a6145',
    'EFREE-CALLER.json.gz': '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
    'INVOICE.json': '85be0a6a8d451cb211d7896accdc94e5acb5580d13f44967bbec932fbfe0c01b',
}
CANON = '088f35a1178ae49653c2629c2da7cb8983aa0d6f4002ab911df27edc0450afd4'
OPEN, CLOSE, TARGET, DONOR = 31281, 38712, 3551, 0


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def canonical(obj):
    return sha256(json.dumps(obj, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def load(name):
    data = (HERE / 'inputs' / name).read_bytes()
    require(sha256(data).hexdigest() == PINS[name], 'input pin ' + name)
    return json.loads(gzip.decompress(data) if name.endswith('.gz') else data)


def expected(n, adjoint):
    return [(1 << r) ^ ((1 << (r + 111)) if adjoint and r < 111 else 0)
            ^ ((1 << (r - 111)) if not adjoint and 111 <= r < 222 else 0)
            for r in range(n)]


def touches(word, selected):
    out = {}
    for bank in sorted(selected):
        relevant, source_reads = [], []
        for t, ins in enumerate(word['program']):
            op, dst, *args = ins
            if dst == bank or (op in ('ADD', 'SWAP') and args[0] == bank):
                relevant.append([t, ins])
            if op == 'ADD' and args[0] == bank:
                source_reads.append([t, ins])
        out[str(bank)] = {
            'native_operand_touches': len(relevant),
            'first_native_touch': relevant[0] if relevant else None,
            'last_native_touch': relevant[-1] if relevant else None,
            'native_add_source_reads': len(source_reads),
            'first_native_add_source_read': source_reads[0] if source_reads else None,
            'last_native_add_source_read': source_reads[-1] if source_reads else None,
        }
    return out


def coefficients_basis(stock, target):
    """High-pivot elimination records an actual XOR representation."""
    pivots = {}
    for i, row in stock:
        v, support = row, 1 << i
        while v:
            bit = v.bit_length() - 1
            if bit not in pivots:
                pivots[bit] = (v, support)
                break
            b, s = pivots[bit]
            v ^= b
            support ^= s
    v, support = target, 0
    while v:
        bit = v.bit_length() - 1
        if bit not in pivots:
            return None, len(pivots), v
        b, s = pivots[bit]
        v ^= b
        support ^= s
    return [i for i, _ in stock if (support >> i) & 1], len(pivots), 0


class Tape:
    def __init__(self, w, adjoint=False, amended=False, donors=(), fault=None):
        self.w, self.adjoint, self.amended = w, adjoint, amended
        self.donors, self.fault = list(donors), fault
        self.n, self.m = w['public'], w['owned_fields']
        self.S, self.E, self.K = self.n + self.m, self.n + self.m + 1, self.n + self.m + 2
        self.sentinel_a, self.sentinel_s = 1 << self.n, 1 << (self.n + 1)
        self.a = [1 << i for i in range(self.n)] + [0] * self.m
        self.tags = list(w['final'] if adjoint else w['start']) + [None] * self.m
        self.dirty = []
        self.moves = Counter()
        self.cut = {}
        self.events = []
        if amended:
            # Native TARGET is dormant while its dirty initial contents persist.
            self.a[TARGET] = self.sentinel_a
            # Receipt S starts dirty. Its clean escrow E and TARGET's K are
            # distinct chart-1 fields which must return to zero and chart 1.
            self.a.extend([self.sentinel_s, 0, 0])
            self.tags.extend([1, 1, 1])

    def primitive(self, ins, *, transpose=False, added=False):
        op, r, *arg = ins
        a, c = self.a, self.tags
        if op == 'ADD':
            q, chart = arg
            require(r != q and c[r] == c[q] == chart, 'ADD contact ' + str(ins))
            if transpose:
                a[q] ^= a[r]
            else:
                a[r] ^= a[q]
        elif op == 'SWAP':
            q = arg[0]
            require(r != q and c[r] is not None and c[q] is not None, 'SWAP contact')
            a[r], a[q] = a[q], a[r]
            c[r], c[q] = c[q], c[r]
        elif op == 'MOVE':
            before, after = arg[::-1] if transpose else arg
            require(c[r] == before, 'MOVE chart ' + str(ins))
            rank = abs(self.w['frames'][str(before)]['dim'] - self.w['frames'][str(after)]['dim'])
            require(rank > 0, 'zero grade MOVE')
            c[r] = after
            self.moves[rank] += 1
            if added:
                self.events.append(['paid', r, before, after, rank])
        else:
            raise AssertionError('unknown primitive ' + op)

    def receipt(self):
        return [
            ['SWAP', self.S, self.E],
            ['ADD', self.S, DONOR, 1],
            ['MOVE', self.S, 1, 2],
            ['ADD', TARGET, self.S, 2],
            ['MOVE', self.S, 2, 1],
            ['ADD', self.S, DONOR, 1],
            ['SWAP', self.S, self.E],
        ]

    def receipt_apply(self, transpose=False):
        ops = self.receipt()
        if self.fault == 'omit_uncopy':
            del ops[5]
        if self.fault == 'omit_target_clean':
            del ops[3]
        for ins in reversed(ops) if transpose else ops:
            self.primitive(ins, transpose=transpose, added=True)

    def donor_apply(self, transpose=False):
        ops = [['ADD', d, TARGET, 1] for d in self.donors]
        for ins in reversed(ops) if transpose else ops:
            self.primitive(ins, transpose=transpose, added=True)

    def target_open(self, clock):
        a, c = self.a, self.tags
        require(c[TARGET] is None and a[TARGET] == self.sentinel_a and
                a[self.K] == 0 and c[self.K] == 1, 'dirty target opening preflight')
        c[TARGET] = 1  # its dormant dirty owner's original chart
        if self.adjoint:
            # Inverse of forward's final zero-stock rechart.
            self.primitive(['MOVE', self.K, 1, 2], added=True)
        self.primitive(['SWAP', TARGET, self.K])
        wanted = 2 if self.adjoint else 1
        require(a[TARGET] == 0 and c[TARGET] == wanted and
                a[self.K] == self.sentinel_a and c[self.K] == 1, 'target escrow opening')
        self.events.append(['target_open', clock, wanted])

    def target_close(self, clock):
        a, c = self.a, self.tags
        require(a[TARGET] == 0 and a[self.K] == self.sentinel_a,
                'cannot retire a dirty target or missing escrow sentinel')
        self.primitive(['SWAP', TARGET, self.K])
        if not self.adjoint:
            # SWAP returns the dirty owner to chart 1 and leaves zero escrow
            # in chart 2. Charge its restoration explicitly.
            self.primitive(['MOVE', self.K, 2, 1], added=True)
        require(a[TARGET] == self.sentinel_a and c[TARGET] == 1 and
                a[self.K] == 0 and c[self.K] == 1, 'target escrow restoration')
        c[TARGET] = None
        self.events.append(['target_close', clock, 1])

    def run(self):
        w, a, c, n = self.w, self.a, self.tags, self.n
        seq = range(len(w['program']) - 1, -1, -1) if self.adjoint else range(len(w['program']))
        for t in seq:
            ins = w['program'][t]
            op, r, *args = ins
            if t == OPEN and self.adjoint:
                stock = [(i, row) for i, row in enumerate(a[:n + self.m])
                         if i != TARGET and c[i] == 1 and row]
                donors, rank, residual = coefficients_basis(stock, a[TARGET])
                self.cut['adjoint_retirement'] = {
                    'clock': t, 'bank': TARGET, 'chart': c[TARGET],
                    'target_hex': hex(a[TARGET]), 'stock_count': len(stock),
                    'rank': rank, 'donors': donors, 'residual_hex': hex(residual),
                    'donor_rows': [[i, hex(a[i])] for i in (donors or [])],
                }
                if self.amended:
                    require(donors == self.donors and c[TARGET] == 1,
                            'adjoint donor identity at actual close')
                    before = [a[d] for d in self.donors]
                    self.donor_apply(transpose=True)
                    require(a[TARGET] == 0 and [a[d] for d in self.donors] == before,
                            'adjoint cleanup and donor restoration')
            if t == CLOSE and not self.adjoint:
                self.cut['forward_retirement'] = {
                    'clock': t, 'target': [TARGET, c[TARGET], hex(a[TARGET])],
                    'public_donor': [DONOR, c[DONOR], hex(a[DONOR])],
                }
                if self.amended:
                    require((a[TARGET], c[TARGET], a[DONOR], c[DONOR]) == (1, 2, 1, 1),
                            'forward exact input-wide receipt at cut')
                    require((a[self.S], c[self.S], a[self.E], c[self.E]) ==
                            (self.sentinel_s, 1, 0, 1), 'receipt stock preflight')
                    self.receipt_apply()
                    require((a[TARGET], a[DONOR], a[self.S], a[self.E]) ==
                            (0, 1, self.sentinel_s, 0) and c[self.S] == c[self.E] == 1,
                            'receipt clean, sentinel and source restoration')
            if op in ('INIT', 'CLEAR'):
                opens = (op == 'CLEAR') if self.adjoint else (op == 'INIT')
                if self.amended and r == TARGET:
                    if opens:
                        self.target_open(t)
                    else:
                        self.dirty.append([t, r, bool(a[r])])
                        self.target_close(t)
                elif opens:
                    require(c[r] is None, 'native double opening')
                    a[r] = 0
                    c[r] = args[0]
                else:
                    require(c[r] == args[0], 'native closing chart')
                    self.dirty.append([t, r, bool(a[r])])
                    c[r] = None
                    a[r] = 0
            else:
                self.primitive(ins, transpose=self.adjoint)
            if t == OPEN and not self.adjoint and self.amended:
                before = [a[d] for d in self.donors]
                require(a[TARGET] == 0 and all(c[d] == 1 for d in self.donors),
                        'forward donor insertion chart and zero')
                self.donor_apply()
                require(a[TARGET] == 0 and [a[d] for d in self.donors] == before,
                        'forward donor insertion had an effect')
            if t == CLOSE and self.adjoint and self.amended:
                require(a[TARGET] == 0 and a[DONOR] == 1, 'adjoint receipt inputs')
                self.receipt_apply(transpose=True)
                require((a[TARGET], a[DONOR], a[self.S], a[self.E]) ==
                        (0, 1, self.sentinel_s, 0), 'adjoint receipt stock restoration')
        require(a[:n] == expected(n, self.adjoint), 'public endpoint map')
        require(c[:n] == (w['start'] if self.adjoint else w['final']), 'public endpoint charts')
        for i in range(n, n + self.m):
            require(c[i] is None, 'native private lifetime closed')
            require(a[i] == (self.sentinel_a if self.amended and i == TARGET else 0),
                    'native private data at end')
        if self.amended:
            require(a[self.S:] == [self.sentinel_s, 0, 0] and c[self.S:] == [1, 1, 1],
                    'added fields and sentinels returned')
        return {
            'orientation': 'adjoint' if self.adjoint else 'forward',
            'amended': self.amended, 'rows_checked': n,
            'public_rows_sha256': canonical([hex(x) for x in a[:n]]),
            'private_retirements': len(self.dirty),
            'dirty_native_retirements': sum(row[2] for row in self.dirty),
            'target_retirement': next(row for row in self.dirty if row[1] == TARGET),
            'paid_grades': {str(k): self.moves[k] for k in sorted(self.moves)},
            'extra_events': self.events, 'cut': self.cut,
        }


def rollback_checks(w, donors):
    # Standalone local reversible test, including the two independent dirty
    # sentinels. Reverse the literal gates themselves, not their transpose.
    t = Tape(w, amended=True, donors=donors)
    t.a[TARGET], t.tags[TARGET] = 1, 2
    t.a[DONOR], t.tags[DONOR] = 1, 1
    before_a, before_c = t.a[:], t.tags[:]
    for op in t.receipt():
        t.primitive(op, added=True)
    require(t.a[TARGET] == 0 and t.a[t.S] == t.sentinel_s and t.a[t.E] == 0,
            'local complete forward')
    for ins in reversed(t.receipt()):
        if ins[0] == 'MOVE':
            ins = [ins[0], ins[1], ins[3], ins[2]]
        t.primitive(ins)
    require(t.a == before_a and t.tags == before_c, 'local literal inverse rollback')
    # Skipping only uncopy retains an input-dependent payload in clean stock;
    # fail closed rather than silently discarding it.
    bad = Tape(w, amended=True, donors=donors, fault='omit_uncopy')
    bad.a[TARGET], bad.tags[TARGET] = 1, 2
    bad.a[DONOR], bad.tags[DONOR] = 1, 1
    bad.receipt_apply()
    require(bad.a[bad.S] == bad.sentinel_s and bad.a[bad.E] == 1 and bad.a[TARGET] == 0,
            'omitted-uncopy negative control')
    bad3 = Tape(w, amended=True, donors=donors, fault='omit_target_clean')
    bad3.a[TARGET], bad3.tags[TARGET] = 1, 2
    bad3.a[DONOR], bad3.tags[DONOR] = 1, 1
    bad3.receipt_apply()
    require(bad3.a[TARGET] == 1 and bad3.a[bad3.S] == bad3.sentinel_s and bad3.a[bad3.E] == 0,
            'omitted-target-clean negative control')
    # Dirty escrow is rejected before any change to either sentinel.
    bad2 = Tape(w, amended=True, donors=donors)
    bad2.a[bad2.K] = 1 << (bad2.n + 2)
    original = (bad2.a[:], bad2.tags[:])
    try:
        bad2.target_open(OPEN)
    except AssertionError as exc:
        require(str(exc) == 'dirty target opening preflight' and
                (bad2.a, bad2.tags) == original, 'dirty escrow rollback')
    else:
        raise AssertionError('dirty escrow accepted')
    # One donor omitted must not silently retire the actual x0 target.
    adj = Tape(w, adjoint=True).run()['cut']['adjoint_retirement']
    rows = [int(row, 16) for _, row in adj['donor_rows']]
    total = 0
    for row in rows[1:]:
        total ^= row
    require(total != int(adj['target_hex'], 16), 'omitted adjoint donor accepted')
    return {'literal_forward_inverse_restores_every_field_and_tag': True,
            'omitted_uncopy_leaves_payload_in_escrow': True,
            'omitted_clean_step_leaves_native_target_dirty': True,
            'dirty_native_escrow_rejected_without_state_change': True,
            'omitted_adjoint_donor_leaves_dirty_target': True}


def price(w, caller, invoice):
    local_calls = [(i, e) for i, e in enumerate(caller['events']) if e[0] == 'LOCAL']
    require(len(local_calls) == 36, '36 actual calls')
    native = Counter(abs(w['frames'][str(a)]['dim'] - w['frames'][str(b)]['dim'])
                     for op, *rest in w['program'] if op == 'MOVE'
                     for _, a, b in [rest])
    require(sum(native.values()) == 2872 and native[7] == 0, 'native grade inventory')
    bins = []
    for row in invoice['bins']:
        new = dict(row)
        add = 108 if row['grade'] == 7 else 0
        new['amended_paid'] = row['control_paid'] + add
        new['amended_targets'] = row['control_targets']
        new['amended_signed'] = new['amended_targets'] - new['amended_paid']
        new['amended_vs_baseline_signed'] = new['amended_signed'] - row['baseline_signed']
        bins.append(new)
    by_grade = {r['grade']: r for r in bins}
    require(by_grade[7]['control_paid'] == 444 and by_grade[7]['amended_paid'] == 552,
            'paired grade-seven recount')
    delta = {r['grade']: r['amended_vs_baseline_signed'] for r in bins
             if r['amended_vs_baseline_signed']}
    require(delta == {1: 36, 4: 36, 6: -36, 7: -108}, 'full signed grade delta')
    with localcontext() as ctx:
        ctx.prec = 65
        rate = Decimal('0.003879928046156')
        h = lambda k: ((Decimal(1) - rate) * Decimal(k).ln()).exp()
        delta_36 = Decimal(36) * (h(1) + h(4) - h(6) - 3 * h(7))
        extra = Decimal(-108) * h(7)
    return {
        'calls': local_calls, 'native_paid_before': dict(sorted(native.items())),
        'new_native_paid_grade7': 3, 'paired_added_grade7_paid': 108,
        'bins': bins, 'signed_delta_by_grade': delta,
        'formula_36_call_delta': '36*(H(1)+H(4)-H(6)-3*H(7))',
        'evaluation_rate': str(rate), 'delta_approx': str(delta_36),
        'incremental_cleanup_charge_approx': str(extra),
        'limits': 'formal grade recount only; all remaining erasure, physical transport, stock and precision costs are open',
    }


def main():
    w, caller, invoice = load('CONTROL-WORD.json.gz'), load('EFREE-CALLER.json.gz'), load('INVOICE.json')
    require(canonical(w) == CANON and w['public'] == 679 and w['owned_fields'] == 3551 and
            len(w['program']) == 42941, 'control word identity')
    require(w['program'][OPEN] == ['INIT', TARGET, 1] and
            w['program'][CLOSE - 1] == ['SWAP', DONOR, TARGET] and
            w['program'][CLOSE] == ['CLEAR', TARGET, 2], 'cut clocks')
    eye = [[int(i == j) for j in range(8)] for i in range(8)]
    require(w['frames']['1']['dim'] == 8 and w['frames']['1']['B'] == eye and
            w['frames']['1']['A'] == [] and w['frames']['2']['dim'] == 1 and
            w['frames']['2']['B'] == [eye[0]] and w['frames']['2']['A'] == eye[1:],
            'nested full-space and rank-one standard chart')
    forward_old = Tape(w).run()
    adjoint_old = Tape(w, adjoint=True).run()
    cut = adjoint_old['cut']['adjoint_retirement']
    donors = cut['donors']
    require(cut['target_hex'] == '0x1' and cut['stock_count'] == cut['rank'] == 537 and
            donors is not None and len(donors) == 86, 'actual adjoint donor span')
    forward_new = Tape(w, amended=True, donors=donors).run()
    adjoint_new = Tape(w, adjoint=True, amended=True, donors=donors).run()
    require([x['dirty_native_retirements'] for x in (forward_old, adjoint_old)] == [3551, 3551] and
            [x['dirty_native_retirements'] for x in (forward_new, adjoint_new)] == [3550, 3550],
            'one retirement per orientation')
    require(all(x['paid_grades']['7'] == 3 for x in (forward_new, adjoint_new)),
            'three added grade-seven transfers in each orientation')
    report = {
        'status': 'PASS_SCALAR_TWO_ORIENTATION_SINGLE_OWNER_REPAIR',
        'word_canonical': CANON, 'base_and_amended': [forward_old, adjoint_old, forward_new, adjoint_new],
        'affected_native_readers': touches(w, set(donors) | {DONOR, TARGET}),
        'adjoint_added_adds': len(donors),
        'stock': {'native_owner': TARGET, 'receipt_dirty_owner': w['public'] + w['owned_fields'],
                  'receipt_clean_escrow': w['public'] + w['owned_fields'] + 1,
                  'native_clean_escrow': w['public'] + w['owned_fields'] + 2,
                  'initial_clean_fields': 2, 'new_fields_total': 3,
                  'stock_input_output_chart': 1,
                  'scope': 'one scalar lane with independent symbolic sentinel bases'},
        'rollback': rollback_checks(w, donors), 'price': price(w, caller, invoice),
        'scope': ['scalar literal chart semantics only; MOVE is a tag change and charged rank difference',
                  'all remaining 3550 dirty native retirements in each orientation are unresolved',
                  'clean initial stock procurement and physical chart-aware 8-axis MOVE are unresolved',
                  'ordinary fixed-head, tensor, precision, full supplier and kappa obligations are unresolved'],
    }
    (HERE / 'RESULT.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(report['status'])
    print('donors', len(donors), 'dirty_before', 3551, 'dirty_after', 3550,
          'added_grade7_per_local', 3, 'delta_36_approx', report['price']['delta_approx'])


if __name__ == '__main__':
    main()
