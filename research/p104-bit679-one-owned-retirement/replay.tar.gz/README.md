# One 679-word retirement in both scalar orientations

This is a finite **scalar literal and chart-interface control**, not a clean
physical supplier, an `owned_erasure` proof, or a new κ bound. Starting from
the pinned Round 5 stream 10 word, it cleans the first forward dirty
retirement and the corresponding reverse retirement of the **same original
scratch owner**, using an explicitly charged receipt and independently dirty
sentinels. All **3,550 other dirty native retirements in each orientation**
remain unresolved. The simulated `MOVE` checks and changes a chart label while
leaving the scalar row unchanged; a real graded, chart-aware physical MOVE is
not implemented or proven here.

The source is the R5/10 separately compiled `x341=x340` two-hole word,
canonical SHA-256
`088f35a1178ae49653c2629c2da7cb8983aa0d6f4002ab911df27edc0450afd4`.
It removes original owner 341 and packets 968 and 1564, while retaining 971 and
3553. It descends from the separately pinned owner-411-tree word referenced
with [#7830 at `87fbf4f7`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830);
it is **not asserted to be #7830's raw word**. The R5/11 comparison
[#7912 at `83ece5a6`](https://github.com/CrocSwap/integer-mult-bounds/pull/7912)
is a different 679-owner word. The parent READMEs are copied under `inputs/`
for provenance; `verify.py` binds the candidate bytes, not the remote PRs.

## Forward and adjoint repair

At original clock 31281, native output scratch **3551** opens at chart 1.
At clocks 31282–31284, it accumulates from banks 2414, 2693 and 2917; the
actual forward row becomes `x0`. At clock 38711 the word swaps this scratch
with public bank 0. Immediately before the first forward CLEAR at 38712,
scratch 3551 is `x0` at chart 2, while the **post-swap** public bank 0 is
`x0` at chart 1. Chart 1 is the standard rank-8 frame and chart 2 the standard
rank-1 frame, so their formal leg grade is 7. The input-wide equality is
checked by exact symbolic replay, not by a sample.

Write `a` for bank 3551, `p` for post-swap bank 0, `s` for an added dirty
receipt field, and `e` for its separate zero escrow. All `s`, `e`, and `p`
initially have chart 1. Between the original swap and CLEAR execute:

1. Exchange `s` and `e`, holding `s`'s arbitrary original sentinel in `e`.
2. `s ^= p`; **paid** `MOVE(s, 1→2)`; `a ^= s`.
3. **Paid** `MOVE(s, 2→1)`; `s ^= p`; exchange `s` and `e` back.

In this scalar model `a` is now zero, `p` is unchanged, the arbitrary sentinel
is restored, and `e` is zero with its original chart. Omitting the target XOR
leaves `a` dirty; omitting the final uncopy leaves `x0` in `e`. The script also
reverses the actual local gates and verifies restoration of **all** symbolic
fields and chart labels. This gate inverse is a different check from the
adjoint below.

The native owner 3551 itself also starts with an independent arbitrary dirty
sentinel. Present it as zero at 31281 by exchanging it with a second, distinct
clean chart-1 field `k`. At 38712, after the above cleanup, exchange back: the
dirty sentinel and chart 1 return to the native owner, while zero `k` has
chart 2. An explicitly counted third **paid grade-7 MOVE** returns `k` to chart
1. The two added clean fields `e` and `k`, and the separate dirty receipt
field `s`, are caller-supplied resources and are restored; their physical
procurement and machine cost are not supplied by the scalar proof.

The transpose of that forward addition does not by itself clean 3551's reverse
retirement at original INIT clock **31281**. A direct reverse replay at that
clock finds `x0` in 3551 at chart 1; the 537 nonzero other same-chart banks
have rank 537, and a concrete 86-bank XOR equals `x0`. These exact bank
numbers and input-wide symbolic rows are in `RESULT.json`. Insert the 86
forward operations `bank[d] ^= 3551` immediately after INIT 31281. In the
forward run 3551 is zero there, so the operations leave every donor unchanged.
In the transposed reverse run they instead XOR those 86 donors into 3551 just
before its retirement, clearing it while leaving the donors unchanged. The
separately transposed receipt runs after the reverse opening at clock 38712;
its zero target means it leaves the live public row and both receipt fields
unchanged. The reverse native escrow starts with a grade-7 `1→2` move and
finishes with its original sentinel and chart restored.

Both full amended scalar executions pass all **679 arbitrary-input output
rows**, complete native chart and lifetime checks, and two independently
symbolic dirty sentinel identities. Of 3,551 native retirements, the forward
clock 38712 and the reverse clock 31281 are clean; 3,550 still discard nonzero
symbolic values in each orientation. Forward public bank 0's original first
and last ADD-source readers are clocks 10 and 21348; its last original touch
is the swap at 38711. The new receipt reads it twice after that swap. The
result records the original first and last operand touch and ADD-source reader
for **every** bank in the 86-donor set, plus bank 0 and 3551; the independent
verifier reconstructs this inventory from the source instructions. The
forward no-op and reverse donor-preservation checks ensure those inserted
contacts do not alter the original readers' values in the modeled runs.

## Full caller grade recount

This specific control adds three grade-7 paid moves to each of the actual
36 `LOCAL` calls: **108 grade-7 occurrences**. The productive targets are
unchanged. Against the 680-owner R5 baseline, the full signed target-minus-
paid changes are `+36` at grade 1, `+36` at grade 4, `−36` at grade 6,
and `−108` at grade 7. The complete bins and caller clocks are in
`RESULT.json`. With `H(g)=g^(1−κ)`, the resulting 36-call difference is

```
36 * (H(1) + H(4) - H(6) - 3*H(7)).
```

At `κ = 0.003879928046156` this is approximately **−785.589753562337**;
the new three-move cleanup alone contributes approximately
**−750.313699301465**. These are grade-accounting calculations for this
particular formal repair. They exclude the rest of the dirty retirements,
physical implementation, simultaneous stock, tensor cover, fixed-head time,
precision, and any consumer changes. They do not rule out a cheaper different
repair, retiming, or different word.

## Reproduce

With Python 3.10+ and the standard library, one process:

```
python3 -I -B verify.py
```

The verifier checks the SHA-256 inventory, independently interprets both
source cuts and all affected reader bounds, reruns the modified scalar test in
a fresh copy, compares its full receipt, and checks that corrupting the pinned
word is rejected. `check.py` regenerates `RESULT.json`. The recorded controls
also cover an omitted adjoint donor and rejection of dirty initial native
escrow without state change. No network access is required.
