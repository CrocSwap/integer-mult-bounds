# A finite 679-owner zero-escrow control

This is a **finite chart-coordinate construction and a separate scalar control**, not the changed 451-factor supplier, an `owned_erasure` proof, or a κ improvement. The control word of [#7912 at `83ece5a62d3addbee45bad9594ef4809851b833b`](https://github.com/CrocSwap/integer-mult-bounds/pull/7912) has exactly zero complete signed-histogram change against its baseline. The rate and stock discussion is pinned to [#7911 at `4afc1ffbcde45da360e631a8634b1c86261ddc09`](https://github.com/CrocSwap/integer-mult-bounds/pull/7911). Round 4 parents 12 and 05 are copied under `inputs/`; the latter found no new fixed-graph same-bank pulse relation. The source archives, their copied members, original notices, 36 tables, word hashes and parent-readme hashes are checked before the experiment runs.

## The actual tags and the selected path

All 36 `LOCAL` events are bound in order to the actual candidate, call clock and caller event. Each call's 457 helper records and 2,873 paid records are checked against the word, chart ranks, bank chronology, and original-owner and packet numbering. Swapping in the old namespace, falsifying the stale grade and owner under the new namespace, or using another call clock is rejected. New helper address 649 is original owner 650, charts `374 → 1`, grade 2. The old same-spelled address was original owner 649, charts `506 → 1`, grade 4. The actual root tag `('root', 0, 0)` has grade 127. Thus the two-factor grade changes from `127 × 4 = 508` to `127 × 2 = 254`, across `16² = 256`. They are different original owners even though their legacy address has the same spelling.

Independently recounting the complete caller gives `−36` productive grade-four and `−36` paid grade-four occurrences. Target minus paid therefore changes by exactly zero. The finite experiment supplies no additional raw signed gain.

The separately checked 451-factor *logical* path consists of the changed helper, 223 other actual grade-four helpers, two grade-eight roots and 225 grade-64 roots. The ordered tag enumeration has radix 20,706 in the old word and 20,670 in the candidate; both exact mixed-radix ordinals round-trip to the same index sequence, but their ordinal hashes differ. The old grade is `16^451`, the candidate grade is `16^451/2`, and the productive floor is `16^451`. This is a source-order enumeration address. It does not allocate or route the 451-factor product on physical tapes.

## Reversible local zero and retirement

For the candidate's actual nested chart pair, compute the rational idempotent difference `P = P₁ − P₃₇₄`. Exact arithmetic proves `P² = P` and constructs a 3-unit image/kernel frame `F` with `P = F diag(I₂, 0₆) F⁻¹`. For each of 127 **abstract** independent root coordinates, the tested physical local field has eight coordinates over `Z/3^w`. Apply elementary invertible row operations for `F⁻¹`, exchange its two image coordinates with separate zero stock, then apply `F`. The projector image is zero; the six complement coordinates are preserved. This presents 254 owned zero coordinates while retaining every initial image value independently in the escrow. For `w = 1, 2, 3`, the code verifies the chart frame and its inverse on every basis vector, and tests 127 independently populated full fields, with nonzero dirty image sentinels.

The test mutates a retained complement coordinate by an invertible shear. Retirement preserves that change while restoring all original dirty image coordinates and returning the 254 stock coordinates to zero. It also mutates the prepared target itself. Attempted retirement then rejects without losing state. The test takes two separate recovery routes:

* Undo the target mutation, then retire; the original dirty target and changed retained fields return and the initial stock is zero again.
* Exchange the mutated target into another 254 clean coordinates, restore the original target, and preserve the mutation in that second bank as **dirty garbage**. The first stock returns to zero, but the extra bank remains occupied until separately uncomputed. In the worst case arbitrary 254-coordinate mutation data cannot be discarded reversibly without an equally expressive destination or an inverse.

Preflight rejects aliased host fields, a 253-coordinate initial bank, a dirty initial bank, a dirty target without a recovery bank, and a 253-coordinate recovery bank; the data and held sentinels survive each rejection. These are counts for this particular eager allocation and recovery procedure, not an optimality proof for every physical supplier.

The ambient field is `1016w` ternary digits; the original escrow reserves `254w` **additional clean ternary digits**. An unreversed arbitrary target requires a further `254w` clean ternary digits to preserve it as dirty garbage. For each of preparation and successful retirement the implementation performs `254` coordinate swaps, plus `6,350` elementary coordinate operations at `w=1` or `7,620` at `w=2,3`. The retained-coordinate shear and target-mutation inverse each cost `6,477` or `7,747` further coordinate operations in these tests. A failed dirty-retirement inspection also pays the frame change and its inverse. These are finite ring-element operation counts, not fixed-head tape-time or machine-word costs. Program storage, counters, scanning, coefficients, actual 127-root realization, paid leaves, and all concurrent stock remain to be costed. The full q=3 cover's `W^D` reserves, high fibres, seed, conversions and restoration are separate from this clean escrow.

## The changed literal word, independently and separately

The above `Z/3^w` chart control does **not** execute #7912's complete raw product. As a separate check, lift its exact 42,947 literal instructions to an equal-width GF(2) scalar model with 254 independent lanes. It tracks symbolic independent public inputs (with the chosen helper zero), all 3,552 arbitrary private dirty sentinels, and each private bank's zero escrow. Replacing each `INIT` and `CLEAR` by the corresponding reversible exchange returns the original private sentinels, but preserves the would-be discarded payload in a history bank. Each complete forward and adjoint source orientation produces its exact 679-row scalar endpoint on all retained inputs. Reversing the constructed physical scalar sequence restores every symbolic public field, private sentinel and zero escrow. Removing the real `ADD` at clock 389 changes 64 scalar coefficients in either orientation.

This simple implementation reserves 3,552 history blocks of 254 bits, or `902,208` bits. Together with 679 public blocks, 3,552 private blocks and one 254-bit target escrow, the preallocated scalar-test storage is `1,977,136` bits. The symbolic post-local history has 3,551 nonzero forward or 3,550 nonzero adjoint blocks; allocated blocks must be counted even when a payload happens to be zero. The method is a deliberately eager construction and not a lower bound on required memory. The 254-bit blocks are a uniform-width scalar lift; real product target ranks differ. In this model `MOVE` only validates and changes a chart tag, not the genuine chart-aware paid physical operation. The scalar and ternary storage figures are independent diagnostics and cannot simply be combined into an end-to-end stock invoice.

Unresolved work includes physical MOVE and private-erasure refinement, linking this zero to an actual paid path, all other below-floor paths and their simultaneous stock, the real 451-factor cover/route and address tapes, fixed-head costs, precision and the changed consumer. No conclusion about an improved κ follows.

## Replay

Use Python 3.10+ with standard library, one process and assertions enabled:

```sh
python3 -I -B verify.py
```

The verifier authenticates the inventory, replays a clean temporary copy and compares the complete receipt. It also tests that source corruption and optimized execution fail. `replay.py` may be run directly to regenerate `RESULT.json` from the pinned inputs. No network access is required.
