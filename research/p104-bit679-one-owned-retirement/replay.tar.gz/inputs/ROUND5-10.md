# Literal two-hole 971 control

This is a finite control and an erasure obstruction for one literal schedule. It is **not** a completed clean physical supplier and does **not** establish a κ gain. The underlying owner-411-tree word is the separately pinned canonical input used with [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830); it is not asserted to be #7830's raw word bytes. The independent comparison word is [#7912 at `83ece5a62d3addbee45bad9594ef4809851b833b`](https://github.com/CrocSwap/integer-mult-bounds/pull/7912), authenticated against the Round 4 published archive. Both input canonical hashes and all copied files are pinned below.

## Control and literal check

Starting from the 680-owner source, identify cocharted inputs `x341=x340`, remove original public owner 341 and its target, and remove precisely original paid packets 968 and 1564. Keep packet 971 and bridge 3553. All other original packet identities, routes and their chronological order are retained. Substitute the input relation into the actual sender and terminal rows, then compile those rows to primitive `INIT`, `ADD`, `MOVE`, `SWAP` and `CLEAR` instructions. `CONTROL-WORD.json.gz` has canonical SHA-256 `088f35a1178ae49653c2629c2da7cb8983aa0d6f4002ab911df27edc0450afd4`, 679 public fields, 2,872 paid transfers, and 3,551 private fields. It is a symbolic destructive-erasure interpreter. Both primitive orientations pass exact 679-by-679 arbitrary-input row comparisons and every actual chart/contact, beginning and terminal check. Original owner 411 becomes local address 410; original packet 3553 still transports exactly `x411`.

The control is distinct from #7912: #7912 removes original owner 649 and original packet 3266, giving a zero signed histogram change; this construction removes owner 341 and the two named packets. `OWNER-CALL-TABLES.json.gz` binds every one of the 36 actual caller clocks to the candidate word, all 457 helper identities, all 2,872 original packet identities/new clocks/banks/routes/grades, and both complete private-lifetime digests. Local negative controls reject wrong word/caller/lifetime binding, a forged #7912 owner mapping, and equal-grade owner and packet identity swaps. This validates the included table binder, not an uninspected downstream consumer.

## Concrete cleanup blocker

`PRIVATE-LIFETIMES.json.gz` records every opening, last touch, closing chart and symbolic value discarded in each orientation. All **3,551** forward CLEARs and all **3,551** reverse INIT retirements discard nonzero symbolic private data. Omitting the first forward CLEAR or the identified adjoint INIT fails the independent literal endpoint check. These operations are accepted by the literal interpreter and cannot be treated as physical clean erasure. No corresponding erasure cost is claimed or priced.

At the first forward CLEAR, candidate clock **38712**, output scratch bank **3551** is at chart **2** and holds original `x0`. The other four nonzero live fields at chart 2 have rank 4. The functional `x0* + x627*` annihilates all four, but has value 1 on the retiring `x0`. Thus the available same-chart fields do not span its value, and a local XOR cleanup preserving the other fields cannot succeed at that point. `RESULT.json` contains their exact bank addresses, rows and separating witness. `verify.py` independently interprets the candidate through this first CLEAR and checks the witness without importing the compiler. The result rules out this immediate cleanup in this compiled schedule; it does not rule out retiming, a changed word, extra transport, or another paid/owned erasure construction. The first adjoint same-chart span failure is also recorded, with its scope explicitly conditional on the unchanged destructive-interpreter prefix.

## Complete caller price

`INVOICE.json` contains **every signed grade bin** of the full paired caller, before and after, across the exact 36 `LOCAL` calls. With `H(g)=g^(1−κ)`, the 36-call change is

```
36 * ( H(1) + H(4) - H(6) )
```

The two paid removals contribute grades 1 and 4, but owner 341's lost target costs grade 6. The delta is approximately **−35.276054260872** at `0.003879928046156`, yielding a BIT margin of approximately **−35.276054261639**; at `0.003879929046155`, the delta is approximately **−35.276054075089** and the margin **−35.276439202405**. These are before any physical cleanup, timing, precision or other new charges. The positive `+0.723945739128...` Round 4 hypothetical additionally removes grade-1 packet 971; that is not this control.

## Reproduce and limits

Python 3.10+, standard library, one CPU process:

```
python3 -I -B verify.py
```

The verifier checks the SHA inventory and the pinned #7912 archive members, reconstructs both exact primitive orientations, caller bins and owner/lifetime bindings in a temporary copy, compares all generated JSON content, tests the input hash rejection, and independently checks the first erasure witness. It should end with `PASS_INVENTORY_ARCHIVE_679_ROWS_TWO_ORIENTATIONS_CHARTS_BINDING_INVOICE_AND_FIRST_CLEAR_WITNESS`. This is a finite one-word test; it does not independently re-run the broader 678-direction exclusion, establish a clean reversible word, prove the inherited supplier interfaces, or rule out alternative recodings.
