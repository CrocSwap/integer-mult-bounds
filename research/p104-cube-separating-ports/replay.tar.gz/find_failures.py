#!/usr/bin/env python3
"""Find omitted ports not covered by the immutable R5 00 row-span witnesses."""
import json, sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(P/'upstream-r5'))
import verify as old

report={}
for I in (3,5):
    proof=json.loads((P/'upstream-r5'/'cases'/f'i{I}-00.json').read_text())
    _,_,_,spans=old.proof_check(I,0,0,proof)
    ports=set(proof['ports'])
    failures=[]
    for t in sorted(set(range(104))-ports):
        m=sum(1<<z for z in spans if old.old.h[t] in spans[z])
        uncovered=[c for c in old.old.C[t] if not(c&m)]
        if uncovered:
            failures.append({'port':t,'mask':m,'uncovered_clauses':len(uncovered),'first_uncovered_clause':uncovered[0]})
    report[f'i{I}']={'selected_ports':proof['ports'],'tested_omitted':104-len(ports),'failures':failures}
    print('i%d: %d of 80 omitted ports fail witness' % (I,len(failures)))
    print('  '+', '.join('%d(%d)'%(f['port'],f['uncovered_clauses']) for f in failures))
(P/'failures.json').write_text(json.dumps(report,indent=2)+'\n')
