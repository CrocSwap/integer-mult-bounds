#!/usr/bin/env python3
"""Deterministic greedy extension; result is a model, not a minimum."""
import json, sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(P/'upstream-r5'))
import verify as old

BATCH={3:[23,36,41,46],5:[30,53,16,52]}
def span(b):
    s={0}
    for v in b:
        if v not in s:s|={x^v for x in s}
    return s

def run(I):
    proof=json.loads((P/'upstream-r5'/'cases'/f'i{I}-00.json').read_text());orig=proof['ports'];ports=orig+BATCH[I]
    active=[r['z'] for r in proof['rows']];bs={r['z']:r['vectors'][:] for r in proof['rows']}
    z0,t1,t2,_=old.BRANCH[I]
    def score(bs):
        spans={z:span(bs[z]) for z in active}
        masks={t:sum(1<<z for z in active if old.old.h[t] in spans[z] and not(z==z0 and t in (t1,t2))) for t in ports}
        bad=[(t,c) for t in ports for c in old.old.C[t] if not(c&masks[t])]
        return bad,masks,spans
    history=[]
    while True:
        bad,_,spans=score(bs)
        if not bad:break
        candidates=[]
        # any unserved (z,t) pair in a failing clause gives a possible one-axis enlargement
        for t,z in sorted({(t,z) for t,c in bad for z in active if c>>z&1 and not(z==z0 and t in (t1,t2))}):
            if old.old.h[t] in spans[z]:continue
            nb={w:bs[w][:] for w in active};nb[z].append(old.old.h[t])
            left=len(score(nb)[0]);candidates.append((left,t,z))
        if not candidates:raise RuntimeError('no progress')
        left,t,z=min(candidates)
        assert left < len(bad)
        bs[z].append(old.old.h[t]); history.append({'row':z,'port':t,'before':len(bad),'after':left})
    _, masks, _ = score(bs)
    out={'schema':'p104-augmented-port-branch-subspace-v1','id':f'i{I}','inactive_mask':I,'ports':ports,'new_ports':BATCH[I], 'branch':{'z':z0,'t1':t1,'t2':t2,'values':[0,0]},'rows':[{'z':z,'vectors':bs[z]} for z in active], 'port_masks':[{'t':t,'mask':masks[t]} for t in ports], 'total_price':sum(len(bs[z])-1 for z in active),'greedy_extensions':history}
    (P/f'witness-i{I}-00.json').write_text(json.dumps(out,indent=2)+'\n')
    print(f'i{I}: {len(orig)}+{len(BATCH[I])} ports, extensions={len(history)}, upper={out["total_price"]}; {history}')
for I in (3,5):run(I)
