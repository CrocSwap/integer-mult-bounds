#!/usr/bin/env python3
"""Bounded search for augmented-port row mixtures; output requires exact replay."""
import argparse,json,random,sys,time,warnings
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix
P=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(P/'upstream-r5'/'inherited'))
import search
BATCH={3:[23,36,41,46],5:[30,53,16,52]}
BRANCH={3:(2,39,27),5:(4,66,72)}
def run(I,rounds,seconds,output=None):
 start=time.monotonic();old=json.loads((P/'upstream-r5'/'inherited'/f'i{I}-24.json').read_text());ports=old['ports']+BATCH[I];active,masks,counts,incid,good=search.setup(I);Z=len(active);N=len(ports);z0,t1,t2=BRANCH[I];rng=random.Random(104+I)
 allowed=[]
 for t in ports:
  ids=good[t]
  if t in (t1,t2): ids=ids[((masks[ids]>>z0)&1)==0]
  assert len(ids);allowed.append(ids)
 bases=[]
 for row in old['row_mixtures']:
  z=row['z'];assert z==active[len(bases)]
  B={tuple(sorted(x['ports'])) for x in row['mixture']}
  for _ in range(12):B.add(search.independent_greedy(z,ports,[rng.random() for t in ports]))
  bases.append(sorted(B))
 cuts=[];seen=set()
 def add(ti,mask):
  k=ti,int(mask)
  if k in seen:return False
  seen.add(k);cuts.append(k);return True
 # Starting cuts include the old certified score-minimizing supports when valid.
 for ti,t in enumerate(ports):
  ids=allowed[ti];add(ti,masks[ids[np.argmin(counts[ids])]])
  add(ti,masks[ids[-1]])
  if ti<len(old['port_minima']):
   s=old['port_minima'][ti]['support']
   if s in masks[ids]:add(ti,s)
 def certificate(res,offsets):
  den=10**6;rows=[];weights=np.zeros((Z,N),dtype=np.int64)
  for zi,z in enumerate(active):
   B=bases[zi];lam=res.x[offsets[zi]:offsets[zi]+len(B)];rs=search.rationalize(lam,den);mix=[]
   for basis,wt in zip(B,rs):
    if wt:
     mix.append({'ports':list(basis),'weight':wt})
     for t in basis:weights[zi,ports.index(t)]+=wt
   rows.append({'z':z,'mixture':mix})
  minima=[];score=0
  for ti,t in enumerate(ports):
   vals=incid[allowed[ti]].astype(np.int64)@weights[:,ti];k=int(np.argmin(vals));v=int(vals[k]);score+=v
   minima.append({'t':t,'minimum':v,'support':int(masks[allowed[ti][k]])})
  return {'schema':'p104-augmented-port-mixture-v1','id':f'i{I}','inactive_mask':I,'ports':ports,'new_ports':BATCH[I],'branch':{'z':z0,'t1':t1,'t2':t2,'values':[0,0]},'denominator':den,'row_mixtures':rows,'port_minima':minima,'lower_numerator':score}
 best=-1
 print('START',I,'N',N,'rounds',rounds,'setup_seconds',round(time.monotonic()-start,2),flush=True)
 for itr in range(rounds):
  nx=Z*N;offsets=[];cur=nx+N
  for B in bases:offsets.append(cur);cur+=len(B)
  er=[];ec=[];ev=[]
  for zi,z in enumerate(active):
   for ti in range(N):er.append(zi*N+ti);ec.append(zi*N+ti);ev.append(1.)
   for j,B in enumerate(bases[zi]):
    col=offsets[zi]+j
    for t in B:er.append(zi*N+ports.index(t));ec.append(col);ev.append(-1.)
    er.append(nx+zi);ec.append(col);ev.append(1.)
  Aeq=coo_matrix((ev,(er,ec)),shape=(nx+Z,cur)).tocsr();beq=np.r_[np.zeros(nx),np.ones(Z)]
  ur=[];uc=[];uv=[]
  for k,(ti,mask) in enumerate(cuts):
   ur.append(k);uc.append(nx+ti);uv.append(1.)
   for zi,z in enumerate(active):
    if (mask>>z)&1:ur.append(k);uc.append(zi*N+ti);uv.append(-1.)
  Aub=coo_matrix((uv,(ur,uc)),shape=(len(cuts),cur)).tocsr();obj=np.zeros(cur);obj[nx:nx+N]=-1.
  with warnings.catch_warnings():
   warnings.simplefilter('ignore');res=linprog(obj,A_ub=Aub,b_ub=np.zeros(len(cuts)),A_eq=Aeq,b_eq=beq,bounds=(0,None),method='highs',options={'time_limit':seconds,'threads':1})
  if not res.success:print('STOP',itr,res.message,flush=True);break
  proof=certificate(res,offsets);score=proof['lower_numerator']
  if score>best:
   best=score;(Path(output) if output else P/f'lower-i{I}-00.json').write_text(json.dumps(proof,indent=2)+'\n')
  a=res.x[:nx].reshape((Z,N));newcuts=0
  for ti,t in enumerate(ports):
   vals=incid[allowed[ti]]@a[:,ti];order=np.argsort(vals,kind='stable')
   for k in order[:8]:
    if vals[k]>=res.x[nx+ti]-1e-8:break
    newcuts+=add(ti,masks[allowed[ti][k]])
  y=res.eqlin.marginals[:nx].reshape((Z,N));mu=res.eqlin.marginals[nx:];newbasis=0
  for zi,z in enumerate(active):
   basis=search.independent_greedy(z,ports,list(-y[zi]))
   if -sum(y[zi,ports.index(t)] for t in basis)>-mu[zi]+1e-8 and basis not in bases[zi]:bases[zi].append(basis);newbasis+=1
  print('ITER',itr,'LP',round(-res.fun,6),'cert',score/1e6,'best',best/1e6,'cuts+',newcuts,'basis+',newbasis,'time',round(time.monotonic()-start,2),flush=True)
  if not newcuts and not newbasis:break
 print('END',I,'best',best/1e6,'elapsed',round(time.monotonic()-start,2),flush=True)
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('I',type=int,choices=(3,5));ap.add_argument('--rounds',type=int,default=15);ap.add_argument('--lp-seconds',type=float,default=3);ap.add_argument('--output');args=ap.parse_args();run(args.I,args.rounds,args.lp_seconds,args.output)
