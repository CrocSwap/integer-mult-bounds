#!/usr/bin/env python3
"""Reject damaged row-cover and fractional certificates, with one-way controls."""
import copy,json
from pathlib import Path
import verify
P=Path(__file__).resolve().parent
w=json.loads((P/'witness-i3-00.json').read_text())
l=json.loads((P/'lower-i3-00.json').read_text())
verify.verify_witness(3,w);verify.verify_lower(3,l)
def reject(name,base,change,checker):
    x=copy.deepcopy(base);change(x)
    try:checker(3,x)
    except AssertionError:print('PASS rejected',name);return
    raise AssertionError('mutation accepted: '+name)
reject('dropped active row',w,lambda x:x['rows'].pop(),verify.verify_witness)
reject('dependent vector',w,lambda x:x['rows'][0]['vectors'].append(x['rows'][0]['vectors'][0]),verify.verify_witness)
reject('incorrect price',w,lambda x:x.update(total_price=x['total_price']-1),verify.verify_witness)
reject('incomplete new-port family',w,lambda x:x['ports'].pop(),verify.verify_witness)
reject('wrong branch',w,lambda x:x['branch'].update(values=[1,0]),verify.verify_witness)
# Flip a real positive flag whose removal uncovers an original positive clause.
choice=next((j,z) for j,item in enumerate(w['port_masks']) for z in range(16) if item['mask']>>z&1 and any(not((item['mask']&~(1<<z))&c) for c in verify.old.C[item['t']]))
def remove_required(x):
    j,z=choice;x['port_masks'][j]['mask']&=~(1<<z)
reject('removed required true membership',w,remove_required,verify.verify_witness)
# Turn on any active flag whose label is not actually in its claimed row span.
spans={r['z']:verify.r5.span(r['vectors']) for r in w['rows']}
choice2=next((j,z) for j,item in enumerate(w['port_masks']) for z in spans if not(item['mask']>>z&1) and verify.old.h[item['t']] not in spans[z])
def forge_membership(x):
    j,z=choice2;x['port_masks'][j]['mask']|=1<<z
reject('true flag with no containment',w,forge_membership,verify.verify_witness)
reject('inexact lower numerator',l,lambda x:x.update(lower_numerator=x['lower_numerator']+1),verify.verify_lower)
reject('invalid support mask',l,lambda x:x['port_minima'][0].update(support=0),verify.verify_lower)
def duplicate_basis_label(x):
    item=next(y for row in x['row_mixtures'] for y in row['mixture'] if y['ports'])
    item['ports'].append(item['ports'][0])
reject('dependent mixture basis',l,duplicate_basis_label,verify.verify_lower)
reject('broken mixture normalization',l,lambda x:x['row_mixtures'][0]['mixture'][0].update(weight=x['row_mixtures'][0]['mixture'][0]['weight']+1),verify.verify_lower)
_,contained=verify.verify_witness(3,w)
assert contained=={27,39}
print('PASS contained-but-false branch labels 27 and 39 are accepted')
print('PASS 11 mutations rejected')
