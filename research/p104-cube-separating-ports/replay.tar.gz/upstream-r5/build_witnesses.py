#!/usr/bin/env python3
"""Construct four active-row witnesses from each saved price-54 relaxed seed."""
import itertools,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
D=json.loads((HERE/'inherited/inherited/audit/source/drat/data/e8base.json').read_text())['C']
def vec(xs):return 1|sum((int(v)&1)<<(i+1) for i,v in enumerate(xs))
h=list(map(vec,D[:104]));n=list(map(vec,D[104:]));specs={3:(2,39,27),5:(4,66,72)}
for I,(z,t1,t2) in specs.items():
    original=json.loads((HERE/f'base-i{I}-54.json').read_text())
    for a,b in itertools.product((0,1),repeat=2):
        d=json.loads(json.dumps(original));d['branch']={'z':z,'t1':t1,'t2':t2,'values':[a,b]}
        # Each cube's noninactive rows must remain nonzero. Each old zero row
        # is filled with <n_z,h_t>, of dimension two and normal flag true.
        for row in d['rows']:
            if not row['vectors']:
                row['vectors']=[n[row['z']],h[d['ports'][0]]];d['total_price']+=1
        if a or b:
            next(r for r in d['rows'] if r['z']==z)['vectors'].append(h[t1]);d['total_price']+=1
        d.pop('status',None)
        (HERE/'cases'/f'i{I}-{a}{b}.json').write_text(json.dumps(d,indent=2)+'\n')
