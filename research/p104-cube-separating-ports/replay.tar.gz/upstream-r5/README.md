# Coupled cross-port branches for P104 cubes i3 and i5

**No additional cube is eliminated.** We split each of the residual cube IDs i3 and i5 on two same-row Boolean membership flags, check all four children including the mixed cases, and impose actual binary row-subspace closure on the respective 24 selected ports. A replayable row-subspace witness costs 60 in child `00` and 61 in each of `01`, `10`, and `11` for each cube. These witnesses exceed the target budget 55. They show that every child is nonempty in the stated *unbudgeted 24-port relaxation*; they do **not** show that any child or full cube has a satisfying assignment at budget 55. The derived lower bounds are near 43, so every budget-55 child is unresolved.

The exact source pins are [#7915 at `af21be16714507f7bc674ed2ecc9e71f0f2af639`](https://github.com/CrocSwap/integer-mult-bounds/pull/7915), [#7893 at `86366417aa712746545fa3ab9c3f7659cbffe878`](https://github.com/CrocSwap/integer-mult-bounds/pull/7893), and [#7852 at `41beda1d6435760dc99e38bd7e65f36798aad212`](https://github.com/CrocSwap/integer-mult-bounds/pull/7852). The inherited solver-free 665-of-1,001 cube-exclusion count is unchanged. Inherited branch-free fractional row-basis **ceilings** of 43 for i3 and 339/8 for i5 concern a different quantity: they limit that particular *branch-free certificate method* on each named 24-port set. They are not upper bounds on the actual minimum row price and must not be combined with 665/1,001.

## Exact domain

The source builds `h_t=(1,c_t mod 2)` and row normals `n_z=(1,z mod 2)` in `F2^9`. For cube i3 rows `{0,1}` are inactive; for i5 rows `{0,2}` are inactive. All 14 other rows must be nonzero, as their cube units require. Each row has a subspace `U_z`, one-way flags `m[z,t] -> h_t in U_z` and `nin[z] -> n_z in U_z`, and the original normalization forbidding dimension 1 with `nin=1`. Inactive rows have `U=0` and false flags. For the selected 24 ports, all their original generated positive cover clauses must hold. No lex clauses and no cover clauses for the other 80 ports are required here. The objective is the source's charged price `sum_z(dim(U_z)-nin[z])`; it is an integer. The budget condition is considered only when comparing to 55. These constraints form a relaxation of each full source branch; they are not an assertion about the original decoder or κ.

The port sets are exactly #7915's 24-port families:

* i3: `93,18,33,39,51,59,92,6,17,27,38,74,85,9,25,56,70,82,96,11,14,19,40,48`.
* i5: `6,22,43,85,28,33,57,59,51,80,42,66,72,86,5,74,89,93,11,25,96,97,34,68`.

## Branches and coupled closure

* i3 branches on `(m[2,39],m[2,27])`; the exact vector identity is `h_93 + h_18 + h_39 + h_27 = 0`.
* i5 branches on `(m[4,66],m[4,72])`; the exact vector identity is `h_6 + h_22 + h_66 + h_72 = 0`.

The two bits are distinct, so `00`, `01`, `10`, `11` are a disjoint and exhaustive Boolean partition. Every row-subspace witness contains the first two labels of its identity in the shared row. In a child in which either branch flag is true, closure forces both branch *labels* into that row. The mixed children are still valid: a false `m` flag does not assert noncontainment. Treating it as such would improperly discard them. The checker explicitly verifies all four children and all selected cover clauses; no child is silently omitted or declared invalid.

For each child `Q` is the minimum charged price in the above unbudgeted 24-port relaxation. The lower bound is an exactly re-evaluated inherited rational independent-row mixture, with the applicable branch flag imposed while minimizing over each selected port's complete admissible support masks. The upper bound is an explicit simultaneous collection of actual row subspaces, not a fractional mixture. `verify.py` prints exact rational gaps, each generated full-CNF branch hash, the row-span checks and the inherited branch-free ceilings.

| Cube | Child | Exact lower bound on Q | Witness upper bound on Q |
|---|---|---:|---:|
| i3 | 00 | 8,599,993 / 200,000 | 60 |
| i3 | 01 | 10,749,991 / 250,000 | 61 |
| i3 | 10 | 8,599,993 / 200,000 | 61 |
| i3 | 11 | 10,749,991 / 250,000 | 61 |
| i5 | 00 | 21,187,491 / 500,000 | 60 |
| i5 | 01 | 42,374,983 / 1,000,000 | 61 |
| i5 | 10 | 42,374,981 / 1,000,000 | 61 |
| i5 | 11 | 21,187,491 / 500,000 | 61 |

Since Q is integral, each lower bound rounds up to 43. The displayed witnesses have every noninactive row of dimension at least 2 and contain its normal, so `nin=1` is valid and normalization is respected. The i3 and i5 `00` seeds initially had six empty rows; the builder fills each with `<n_z,h_t>` at cost one before saving the checked witnesses. The other children add one genuine shared-row axis. Earlier price-54 numbers for those seeds are **not** valid under the active-row cube units.

## Replay

A standard Python 3 installation and shell suffice. The checked package includes the inherited pinned source and requires no solver, network, or third-party package:

```sh
sha256sum -c SHA256SUMS
(cd inherited && sha256sum -c SHA256SUMS)
python3 -B inherited/inherited/verify_all.py
python3 -B verify.py
python3 -B verify_controls.py
```

The inherited replay checks the 665 exclusions and original source fidelity. The new replay checks source pins and full cube hashes, all original positive cover clauses at each selected port, the complete branch units and their eight full-CNF hashes, all row spans over F2, active/inactive rows, true normal flags and normalization, exhaustive independent-mask minima, and the rational bounds. Nine mutation controls test omitted rows, dependent vectors, wrong prices or branches, and missing mandatory positive flags. The inherited 43 and 339/8 ceilings and the 665/1,001 exclusion count are verified independently; no κ change or full-cube SAT/UNSAT claim is made.
