#!/usr/bin/env python3
"""Mutation controls for the exact branch and subspace checker."""
import copy,json
from pathlib import Path
import verify
HERE=Path(__file__).resolve().parent
base=json.loads((HERE/'cases/i3-11.json').read_text())
base00=json.loads((HERE/'cases/i3-00.json').read_text())
verify.proof_check(3,1,1,base)
def reject(name,change):
    p=copy.deepcopy(base);change(p)
    try: verify.proof_check(3,1,1,p)
    except (AssertionError,KeyError,StopIteration):print('PASS rejected',name);return
    raise AssertionError('mutation accepted: '+name)
reject('price',lambda p:p.update(total_price=p['total_price']-1))
reject('branch value',lambda p:p['branch'].update(values=[0,1]))
reject('missing active row',lambda p:p['rows'].pop())
reject('selected port list',lambda p:p['ports'].pop())
reject('dependent basis',lambda p:p['rows'][0]['vectors'].append(p['rows'][0]['vectors'][0]))
reject('zero-dimensional active row',lambda p:p['rows'][0].update(vectors=[]))
reject('one-dimensional row with normal',lambda p:p['rows'][0].update(vectors=[verify.old.n[p['rows'][0]['z']]]))
reject('missing forced positive',lambda p:p['rows'][0].update(vectors=base00['rows'][0]['vectors']))
reject('schema',lambda p:p.update(schema='different'))
print('PASS 9 mutations rejected')
