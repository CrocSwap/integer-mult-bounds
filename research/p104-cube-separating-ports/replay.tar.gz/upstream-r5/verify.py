#!/usr/bin/env python3
"""Exact finite replay of the two four-child P104 24-port screens (Python 3 only)."""
import hashlib,itertools,json,sys
from fractions import Fraction
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(HERE/'inherited'))
import verify_exact as old
BRANCH={3:(2,39,27,(93,18,39,27)),5:(4,66,72,(6,22,66,72))}
BRANCH_HASHES=json.loads((HERE/'branch_hashes.json').read_text())

def span(vectors):
    s={0}
    for v in vectors:
        assert type(v) is int and 0<v<512
        assert v not in s,('dependent basis',v)
        s |= {x^v for x in s}
    return s

def proof_check(I,a,b,proof):
    z0,t1,t2,circuit=BRANCH[I]; d=json.loads((HERE/'inherited'/f'i{I}-24.json').read_text());P=d['ports'];active=[z for z in range(16) if not I>>z&1]
    assert proof['schema']=='p104-24-port-branch-subspace-v1'
    assert proof['id']==f'i{I}' and proof['inactive_mask']==I and proof['ports']==P
    assert proof['branch']=={'z':z0,'t1':t1,'t2':t2,'values':[a,b]}
    rows=proof['rows'];assert [r['z'] for r in rows]==active
    S={r['z']:span(r['vectors']) for r in rows}
    # Cube active units, plus the true normal flags and normalization.
    assert all(4<=len(S[z])<=512 and old.n[z] in S[z] for z in active)
    assert len(set(circuit))==4 and set((t1,t2))<=set(circuit)
    fixed=set(circuit)-{t1,t2}
    assert all(old.h[t] in S[z0] for t in fixed)
    if a or b: assert old.h[t1] in S[z0] and old.h[t2] in S[z0]
    else: assert old.h[t1] not in S[z0] and old.h[t2] not in S[z0]
    prices={z:(len(S[z]).bit_length()-1)-(old.n[z] in S[z]) for z in active};total=sum(prices.values());assert total==proof['total_price']
    # The CNF flags are one-way. Make all contained labels true, except the
    # two explicitly false branch literals; true flags imply containment.
    masks={}
    for t in P:
        m=sum(1<<z for z in active if old.h[t] in S[z])
        if t==t1 and a==0:m &= ~(1<<z0)
        if t==t2 and b==0:m &= ~(1<<z0)
        assert not m&I and all(m&c for c in old.C[t]),('cover failure',I,a,b,t)
        masks[t]=m
    assert ((masks[t1]>>z0)&1)==a and ((masks[t2]>>z0)&1)==b
    # Explicit four-term shared-row XOR circuit, independent of flags.
    assert set((t1,t2))<=set(circuit) and set(circuit)<=set(P)
    assert old.h[circuit[0]]^old.h[circuit[1]]^old.h[circuit[2]]^old.h[circuit[3]]==0
    # If three are contained in a row, closure necessarily contains the fourth.
    for z in active:
        for fourth in circuit:
            rest=[t for t in circuit if t!=fourth]
            assert not(all(old.h[t] in S[z] for t in rest) and old.h[fourth] not in S[z])
    return total,prices,masks,S

def branch_lower(I,a,b):
    z0,t1,t2,_=BRANCH[I];D=json.loads((HERE/'inherited'/f'i{I}-24.json').read_text());P=D['ports'];den=D['denominator'];active=[z for z in range(16) if not I>>z&1]
    w={z:{t:0 for t in P} for z in active}
    for row in D['row_mixtures']:
        for mixture in row['mixture']:
            for t in mixture['ports']:w[row['z']][t]+=mixture['weight']
    score=0
    for t in P:
        good=old.admissible(I,t)
        if t==t1:good=[m for m in good if (m>>z0)&1==a]
        if t==t2:good=[m for m in good if (m>>z0)&1==b]
        assert good,('empty restricted positive cover domain',I,t)
        score += min(sum(w[z][t] for z in active if m>>z&1) for m in good)
    return Fraction(score,den)

def verify_all():
    expected={(3,0,0),(3,0,1),(3,1,0),(3,1,1),(5,0,0),(5,0,1),(5,1,0),(5,1,1)}
    present={(int(p.stem[1]),int(p.stem[-2]),int(p.stem[-1])) for p in (HERE/'cases').glob('i?-??.json')};assert present==expected
    for I in (3,5):
        inherited=json.loads((HERE/'inherited'/f'i{I}-24.json').read_text());lo,ceiling=old.verify_case(inherited,verbose=False)
        assert ceiling==({3:Fraction(43),5:Fraction(339,8)})[I]
        print(f'PASS i{I} inherited 24-port mixture {lo} and ceiling {ceiling}')
        z0,t1,t2,circuit=BRANCH[I];print(f'PASS four-child Boolean partition i{I}: m[{z0},{t1}], m[{z0},{t2}]; shared circuit {circuit}')
        for a,b in itertools.product((0,1),repeat=2):
            p=json.loads((HERE/'cases'/f'i{I}-{a}{b}.json').read_text());total,prices,masks,S=proof_check(I,a,b,p);low=branch_lower(I,a,b)
            assert low<=total
            # Generator adds exactly the two branch units to the complete cube.
            lits=[[old.b.m[z0,t1] if a else -old.b.m[z0,t1]],[old.b.m[z0,t2] if b else -old.b.m[z0,t2]]]
            branch_hash=hashlib.sha256(old.b.text(old.gen.cube_extra(old.b,f'i{I}')+lits).encode()).hexdigest()
            assert branch_hash==BRANCH_HASHES[f'i{I}-{a}{b}']
            print(f'PASS i{I} {a}{b}: exact lower {low}, row-span upper {total}, gap {total-low}; budget55={"yes" if total<=55 else "unresolved"}; CNF sha256={branch_hash}')
    print('PASS all 8 branches enumerated; selected-port row spans, closure and positive clauses checked')
    print('NOTE: these are partial 24-port covering models, ignoring other ports and lex clauses; they exceed budget 55 and are not full-cube SAT certificates')
if __name__=='__main__':verify_all()
