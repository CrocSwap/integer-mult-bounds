#!/usr/bin/env python3
"""Exact solver-free replay of the R6 selected-port screens (Python 3 only)."""
import importlib.util, json, sys
from fractions import Fraction
from pathlib import Path
P=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(P/'upstream-r5'))
spec=importlib.util.spec_from_file_location('p104_r5_verify',P/'upstream-r5'/'verify.py')
r5=importlib.util.module_from_spec(spec);spec.loader.exec_module(r5)
old=r5.old
BATCH={3:[23,36,41,46],5:[30,53,16,52]}

def source(I):
    return json.loads((P/'upstream-r5'/'cases'/f'i{I}-00.json').read_text())

def original_failures(I,proof):
    _,_,_,S=r5.proof_check(I,0,0,proof)
    out=[]
    for t in sorted(set(range(104))-set(proof['ports'])):
        mask=sum(1<<z for z in S if old.h[t] in S[z])
        failures=[c for c in old.C[t] if not(mask&c)]
        if failures:out.append({'port':t,'mask':mask,'uncovered_clauses':len(failures),'first_uncovered_clause':failures[0]})
    return out

def expected_header(I,rec,schema):
    base=source(I); z,t1,t2,_=r5.BRANCH[I]
    assert rec['schema']==schema and rec['id']==f'i{I}' and rec['inactive_mask']==I
    assert rec['ports']==base['ports']+BATCH[I] and rec['new_ports']==BATCH[I]
    assert rec['branch']=={'z':z,'t1':t1,'t2':t2,'values':[0,0]}
    assert len(set(rec['ports']))==28

def verify_witness(I,rec):
    expected_header(I,rec,'p104-augmented-port-branch-subspace-v1')
    active=[z for z in range(16) if not(I>>z&1)]; rows=rec['rows']
    assert len(active)==14 and [r['z'] for r in rows]==active
    history=rec['greedy_extensions'];assert len(history)==3
    originals={r['z']:r['vectors'] for r in source(I)['rows']}
    for row in rows:
        z=row['z']
        additions=[old.h[step['port']] for step in history if step['row']==z]
        assert row['vectors']==originals[z]+additions
    S={r['z']:r5.span(r['vectors']) for r in rows}
    assert all(len(S[z])>=4 and old.n[z] in S[z] for z in active)
    z0,t1,t2,_=r5.BRANCH[I]
    assert [item['t'] for item in rec['port_masks']]==rec['ports']
    masks={}
    for item in rec['port_masks']:
        t,mask=item['t'],item['mask']
        # In the source, flags imply membership, not the reverse. Explicit
        # masks may clear a flag even when its vector lies in the subspace.
        assert type(mask) is int and 0<=mask<65536
        contained=sum(1<<z for z in active if old.h[t] in S[z])
        assert not(mask&~contained),('true flag without containment',I,t)
        assert not(mask&I) and all(mask&c for c in old.C[t]),('uncovered',I,t)
        masks[t]=mask
    assert not(masks[t1]>>z0&1) and not(masks[t2]>>z0&1)
    total=sum(len(S[z]).bit_length()-2 for z in active)
    assert total==rec['total_price']
    return total, {t for t in (t1,t2) if old.h[t] in S[z0]}

def verify_lower(I,rec):
    expected_header(I,rec,'p104-augmented-port-mixture-v1')
    old.check_cube(f'i{I}',I); active=[z for z in range(16) if not(I>>z&1)]; ports=rec['ports']
    den=rec['denominator'];assert type(den) is int and den>0
    assert [r['z'] for r in rec['row_mixtures']]==active
    prices={t:{z:0 for z in active} for t in ports}
    for row in rec['row_mixtures']:
        z=row['z'];mix=row['mixture'];assert mix and sum(x['weight'] for x in mix)==den
        for item in mix:
            wt=item['weight'];B=item['ports']
            assert type(wt) is int and wt>0 and len(B)==len(set(B)) and set(B)<=set(ports)
            old.independent(z,B)
            for t in B:prices[t][z]+=wt
    assert [m['t'] for m in rec['port_minima']]==ports
    z0,t1,t2,_=r5.BRANCH[I];score=0
    for m in rec['port_minima']:
        t=m['t'];good=old.admissible(I,t)
        if t in (t1,t2):good=tuple(s for s in good if not(s>>z0&1))
        assert good
        def cost(s):return sum(prices[t][z] for z in active if s>>z&1)
        best=min(map(cost,good))
        assert m['support'] in good and cost(m['support'])==best and m['minimum']==best
        score+=best
    assert type(rec['lower_numerator']) is int and score==rec['lower_numerator']
    return Fraction(score,den)

def run():
    source_ports={I:set(source(I)['ports']) for I in (3,5)}
    results={};reserved=set().union(*source_ports.values())
    for I in (3,5):
        proof=source(I);fails=original_failures(I,proof)
        saved=json.loads((P/'failures.json').read_text())[f'i{I}']
        assert saved['selected_ports']==proof['ports'] and saved['tested_omitted']==80 and saved['failures']==fails
        first=fails[0];assert first['port']==0 and first['mask']=={3:41996,5:32944}[I]
        assert first['first_uncovered_clause']==old.C[0][8]==17153
        assert [z for z in range(16) if 17153>>z&1]==[0,8,9,14]
        assert [old.b.m[z,0] for z in (0,8,9,14)]==[2737,32657,36397,55097]
        available=[r for r in fails if r['port'] not in reserved]
        selected=sorted(available,key=lambda r:(-r['uncovered_clauses'],r['port']))[:4]
        assert [r['port'] for r in selected]==BATCH[I]
        reserved.update(BATCH[I])
        lower=verify_lower(I,json.loads((P/f'lower-i{I}-00.json').read_text()))
        upper,contained=verify_witness(I,json.loads((P/f'witness-i{I}-00.json').read_text()))
        previous=r5.branch_lower(I,0,0)
        rounded=(lower.numerator+lower.denominator-1)//lower.denominator
        assert previous<lower<=upper and rounded>=44
        print(f'PASS i{I}/00: {len(fails)}/80 omitted ports fail the R5 witness; first t=0, original cover clause 8 has rows 0,8,9,14; selected {BATCH[I]} fail it')
        print(f'PASS i{I}/00: previous lower {previous}; new lower {lower}; integer cut >= {rounded}; 28-port row-span upper {upper}')
        print(f'PASS one-way membership: false-flag branch ports still contained in row {r5.BRANCH[I][0]}: {sorted(contained)}')
        results[f'i{I}-00']={'omitted_tested':80,'original_witness_failing_omitted':len(fails),'first_failure':{'port':0,'witness_mask':first['mask'],'cover_clause_index_zero_based':8,'clause_row_mask':17153,'rows':[0,8,9,14],'dimacs_literals':[2737,32657,36397,55097]},'new_ports':BATCH[I], 'previous_exact_lower':str(previous),'new_exact_lower':str(lower),'new_integer_lower':rounded,'new_witness_upper':upper, 'false_branch_ports_contained':sorted(contained)}
    print('PASS deterministic batches disjoint from both R5 port sets and from one another')
    print('PASS 14 active rows, branch flags, all 28-port cover clauses, subspace bases, and exact support-mask minima')
    print('NOTE selected-port witnesses omit the other 76 ports and lex clauses; Q<=55 and full-cube SAT/UNSAT remain unresolved')
    (P/'RESULT.json').write_text(json.dumps({'scope':'28-port 00 projections, not full cubes','cases':results,'excluded_cube_count':'665/1001 unchanged','kappa_change':None},indent=2)+'\n')

if __name__=='__main__':run()
