#!/usr/bin/env python3
"""Independent forward replay of FutureAttr bookkeeping on generated words.

Selected symbols are the 96 hosted D (X2,Y2) pairs.  This checks actual
register values, class-F cold/GTD intake, epoch A/B/cost and output weights,
and the CF relay factorization; it is Python evidence, not a Lean proof.
"""
from collections import defaultdict
from fractions import Fraction as Q
from pathlib import Path
import importlib.util, json

HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('pinned_native',HERE/'independent.py')
mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
sel=None  # The verifier's full ordered hosted D sector is used below.
zero=Q(0)

def add(a,b,c):return [x+c*y for x,y in zip(a,b)]
def dim(s):
    assert len(s)>0 and len(s)&(len(s)-1)==0
    return len(s).bit_length()-1
def join(a,b):return frozenset(x^y for x in a for y in b)
def rank(M):
    a=[list(map(Q,r)) for r in M];r=0
    for c in range(len(a[0])):
        pos=next((i for i in range(r,len(a)) if a[i][c]),None)
        if pos is None:continue
        a[r],a[pos]=a[pos],a[r];v=a[r][c];a[r]=[x/v for x in a[r]]
        for j in range(len(a)):
            if j!=r and a[j][c]:
                v=a[j][c];a[j]=[a[j][i]-v*a[r][i] for i in range(len(a[0]))]
        r+=1
    return r

def check(name):
    W=json.loads((HERE/(name+'.json')).read_bytes());n=W['public'];N=n+W['owned_fields']
    sel=W['hosted']['Dports'];d=len(sel);assert d==96
    fs=[mod.span(b) for b in W['frames']]; labels=[W['ports'][i] for i in sel]
    hosts={p:(x,y) for p,x,y in zip(W['hosted']['Dports'],W['hosted']['X2'],W['hosted']['Y2'])}
    xs=[hosts[i][0] for i in sel];ys=[hosts[i][1] for i in sel]
    assert len(set(xs+ys))==2*d
    vec=[[zero]*(2*d) for _ in range(N)]
    for i,x in enumerate(xs):vec[x][i]=Q(1)
    for i,y in enumerate(ys):vec[y][d+i]=Q(1)
    weights=[[zero]*d for _ in range(N)]
    cur=list(W['initial'])+[None]*(N-n);active=set(range(n));epochs=[];live={}
    # carrier[r][j] is the coefficient of the jth closed epoch value in public r.
    carrier=[defaultdict(Q) for _ in range(n)]; relay={};total_rise=0
    for tick,e in enumerate(W['program']):
        op,r=e[:2]
        if op=='INIT':
            assert r>=n and r not in active and r not in live
            active.add(r);cur[r]=e[2];idx=len(epochs);epochs.append(None)
            live[r]={'idx':idx,'A':frozenset(range(512)),'B':frozenset({0}),
                     'dep':False,'cost':0,'last_intake':None,'start':tick}
        elif op=='CLEAR':
            rec=live.pop(r);assert r in active and cur[r]==e[2]
            u=[vec[r][d+j]+vec[r][j] for j in range(d)] # Fy=-I96
            rec.update(w=weights[r][:],u=u,end=tick,reg=r)
            epochs[rec['idx']]=rec;active.remove(r);cur[r]=None
            vec[r]=[zero]*(2*d);weights[r]=[zero]*d
        elif op=='MOVE':
            _,r,a,b,owned=e;assert r in active and cur[r]==a and owned==(r>=n)
            assert (fs[a]<fs[b]) if not owned else (fs[a]<fs[b] or fs[b]<fs[a])
            if owned and fs[a]<fs[b]:
                delta=dim(fs[b])-dim(fs[a]);live[r]['cost']+=delta;total_rise+=delta
            cur[r]=b
        elif op in ('ADD','COPY'):
            src=e[2];c=Q(e[3]);chart=e[4]
            assert r in active and src in active and r!=src and cur[r]==cur[src]==chart
            if op=='COPY':
                # Valid compilation COPY -> ADD because every INIT is zero.
                assert r>=n and not any(vec[r]) and not any(weights[r])
            if r>=n:
                rec=live[r];assert not rec['dep']
                eff=[vec[src][d+j]+vec[src][j] for j in range(d)]
                for j,v in enumerate(eff):
                    if c*v:assert all((a&labels[j]).bit_count()%2==0 for a in fs[chart])
                rec['A']=rec['A'] & fs[chart];rec['last_intake']=tick
                if src<n:
                    for prev,v in carrier[src].items():
                        if v:relay[(rec['idx'],prev)]=relay.get((rec['idx'],prev),zero)+c*v
            if r<n and src>=n:
                rec=live[src];rec['B']=join(rec['B'],fs[chart]);rec['dep']=True
                carrier[r][rec['idx']]+=c
            tv=[Q(int(r==x)) for x in xs]
            weights[src]=add(weights[src],add(tv,weights[r],-1),c)
            vec[r]=add(vec[r],vec[src],c)
        else:raise AssertionError(op)
    assert not live and active==set(range(n)) and cur[:n]==W['final']
    assert len(epochs)==W['owned_fields']==208 and all(e is not None for e in epochs)
    assert all(e['last_intake'] is not None for e in epochs)
    # FutureAttr attribution_decoder's endpoint hypotheses on selected X2/Y2.
    for r in range(n):
        for j in range(d):
            assert vec[r][j]==Q(int(r==xs[j]))  # hfx, hence hbal
            if r not in xs and vec[r][d+j]:
                assert all((a&labels[j]).bit_count()%2==0 for a in fs[cur[r]]) # hfy
    for i,x in enumerate(xs):
        assert labels[i] in fs[W['initial'][x]]
        for j in range(d):assert vec[x][d+j]==-Q(int(i==j)) # hfyX
    # Construct F as cold increments: total epoch u minus the hot relay inputs.
    # The predecessor's effective content is fixed before its output in this word.
    for e in epochs:
        assert dim(join(e['A'],e['B']))-dim(e['A']) <= e['cost']
        k=e['idx'];cold=e['u'][:]
        for (dst,src),v in relay.items():
            if dst==k and v:cold=add(cold,epochs[src]['u'],-v)
        e['cold']=cold
        for j,v in enumerate(cold):
            if v:assert all((a&labels[j]).bit_count()%2==0 for a in e['A'])
        for j,v in enumerate(e['w']):
            if v:assert labels[j] in e['B']
    # Each relay is legal and progresses strictly in last-intake time.
    relay={k:v for k,v in relay.items() if v}
    for (k,j),v in relay.items():
        assert epochs[k]['A']<=epochs[j]['B']
        assert epochs[j]['last_intake']<epochs[k]['last_intake']
    # In this concrete program relays are disjoint edges, H^2=0, so N=I+H.
    assert not any(j==a for (k,j) in relay for (a,b) in relay)
    M=[[sum(e['w'][s]*e['cold'][t] for e in epochs) +
         sum(epochs[k]['w'][s]*v*epochs[j]['cold'][t] for (k,j),v in relay.items())
         for t in range(d)] for s in range(d)]
    assert M==[[-Q(int(i==j)) for j in range(d)] for i in range(d)]
    hF=all(dim(e['A'])<=1 for e in epochs if any(e['cold']))
    hG=all(dim(e['B'])>=8 for e in epochs if any(e['w']))
    assert rank(M)==d
    native=mod.native(W);assert native['bad_inputs']==[]
    assert total_rise==sum(k*v for k,v in native['rises'].items())
    relevant=[{'epoch':e['idx'],'reg':e['reg'],'A_dim':dim(e['A']),'B_dim':dim(e['B']),
               'cold_nonzero':[j for j,v in enumerate(e['cold']) if v],
               'w_nonzero':[j for j,v in enumerate(e['w']) if v],
               'cost':e['cost'],'last_intake':e['last_intake']} for e in epochs if any(e['cold']) or any(e['w'])]
    return {'hF':hF,'hG':hG,'hM':True,'rank':rank(M),'M':[[str(x) for x in row] for row in M],
            'R':total_rise,'relay_count':len(relay),
            'relays':[{'taker_epoch':i,'source_epoch':j,'coefficient':str(v),
                       'A_taker_dim':dim(epochs[i]['A']),'B_source_dim':dim(epochs[j]['B'])}
                      for (i,j),v in sorted(relay.items())], 'relevant_epochs':relevant}

out={n:check(n) for n in ('control_boundary','hF_dim2','hG_dim7','both_small')}
assert [(v['hF'],v['hG'],v['hM']) for v in out.values()]==[(True,True,True),(False,True,True),(True,False,True),(False,False,True)]
(HERE/'attribution-results.json').write_text(json.dumps(out,indent=2)+'\n')
for name,v in out.items():
    print(name,'hF',v['hF'],'hG',v['hG'],'hM',v['hM'],'rank',v['rank'],
          'R',v['R'],'relays',v['relay_count'])
print('PASS native, exact endpoints, cold/GTD, CF relay time and inclusion, factor-rank, controls')
