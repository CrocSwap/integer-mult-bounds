#!/usr/bin/env python3
"""Check 7113 labels and find a D-only all-odd overlap clique.

Independent finite arithmetic; source text is read-only, not a Lean proof.
"""
import ast
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent / 'source'
src = (root/'UniFold7113.lean').read_text()
sigsrc = (root/'BridgeNetInst.lean').read_text()

def readlist(s, marker):
    start = s.index('[', s.index(marker))
    end = s.index(']', start) + 1
    return ast.literal_eval(s[start:end])

ports = readlist(src, 'def ports7113 : List ℕ :=')
sig = readlist(sigsrc, 'def sigL : List ℕ :=')
nonD = set(sig[96:])
assert len(ports)==104 and len(set(ports))==104
assert len(sig)==104 and set(sig)==set(range(104)) and len(nonD)==8
assert nonD=={15,17,27,34,35,42,47,55}
assert all(0 < x < 512 and x.bit_count()%2 for x in ports)
def odd(a,b): return (a&b).bit_count()%2==1
D = [i for i in range(104) if i not in nonD]
# Recursively find the lexicographically first index-ordered D-only 8-clique.
def find(prefix, pool):
    if len(prefix)==8: return prefix
    if len(prefix)+len(pool)<8:return None
    for j,x in enumerate(pool):
        candidates=[y for y in pool[j+1:] if odd(ports[x],ports[y])]
        if len(prefix)+1+len(candidates)<8: continue
        r=find(prefix+[x],candidates)
        if r is not None:return r
    return None
clique=find([],D)
assert clique is not None
labels=[ports[i] for i in clique]
assert all(odd(a,b) for a in labels for b in labels)
assert all(i not in nonD for i in clique)
print('D-only clique indices:',clique)
print('D-only clique labels:',labels)
print('odd-overlap matrix:')
for x in labels: print(' '.join(str(int(odd(x,y))) for y in labels))
print('nonD indices:',sorted(nonD))
for p in ['UniFold7113.lean','BridgeNetInst.lean']:
    print(p, 'sha256',hashlib.sha256((root/p).read_bytes()).hexdigest())
