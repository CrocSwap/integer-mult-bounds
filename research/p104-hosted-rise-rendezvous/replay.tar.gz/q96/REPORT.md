# Rendezvous Lemma A: Q96 native-word separators

Source under examination: CrocSwap/integer-mult-bounds PR #7852 at commit
`41beda1d6435760dc99e38bd7e65f36798aad212` (DreamingOfClouds with Claude Opus
5.5; see the PR). The exact `independent.py` native verifier is copied locally,
with Git blob `1ae1d7c680ad86c0fa999f2e8f0c09e966fc07a0`, SHA256
`21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874`.
Exact-byte Lean source pins are checked by `native_separator.py`. These are
new finite examples and an independently written Python bookkeeping replay;
no Lean checking is asserted.

## Exact hypotheses and mapping

`CFRelay.lean:207` takes, in addition to the run lives, enumeration and relays:

* `hF`: for **every** node and port, `u[k,p] != 0` implies
  `dim A[k] <= 1`.
* `hG`: for **every** port and node, `w[k,s] != 0` implies
  `dim B[k] >= 8`.
* `hM`: `rank_Q(G * N8.Nmat(H) * F) >= 8`, where `G[s,k]=w[k,s]`,
  `F[k,p]=u[k,p]`, and `N8.Nmat(H)` is the finite geometric relay sum.

Here A is the meet of the owned epoch's intake charts (including the starting
A0=top), B the join of its owned-to-public output charts; `u` is its cold
increment, and `w` its output/attribution weight. In the verifier, `INIT`/`CLEAR`
make an owned life, `COPY` from public to owned is the intake (each fresh owned
field is zero, so COPY compiles to ADD), and `ADD` from owned to public is the
output. `MOVE` supplies the charts and owned ascent charge. The extraction uses
all 96 D-hosted pairs X2/Y2 in #7113, not just eight ports. `FutureAttr.lean`
records its attribution weight W, intake meet A, output join B, deposit flag,
owned rise cost, and effective value `eff`; `CFChain.lean` separately requires
support of `w` in B and orthogonality of `u` to A. The Python replay checks
these implications, endpoint conditions, rise/drop accounting, and both
`hHlam` and `hleg` on every actual relay. It gives each lifetime a distinct
owned field and enumerates each exactly once. The verifier performs its own
native endpoint check. **There is no implemented formal word-to-CF bridge in
this package, and this finite Python replay is not a universal bridge.**

## Exact P104 words and controls

All four are complete native-verifier inputs with the concrete 104 #7113 labels,
96 D ports, 416 public fields, 208 distinct owned lifetimes and 1,648 events;
`independent.native` reports no bad inputs and correctly terminated public
locations. All 96 selected target receipts are `X2 <- X2 - Y2`; the replay
obtains `G N(H) F = -I_96`, rank 96. The eight nonzero relay coefficients
belong to the other B-port blocks; each has strict last-intake chronology and
`A_taker = B_source` of rank 1. Thus the legal equal-rank relay boundary is
exercised, even though equal-rank *moves* are forbidden.

| Complete word | Rank pair (A, B) at selected port 0 | hF | hG | hM | owned rise R |
|---|---:|---|---|---|---:|
| `control_boundary.json` | (1, 8) | true | true | true | 680 |
| `hF_dim2.json` | (2, 8) | false | true | true | 679 |
| `hG_dim7.json` | (1, 7) | true | false | true | 679 |
| `both_small.json` | (2, 1) | false | false | true | 674 |

All other selected hosted epochs have ranks (1,8), with one nonzero `u` and
one nonzero `w`; the 112 other lifetimes have zero `u` and `w` on this Q96
sector. The final row matrix is exactly correct, and `hM` remains true in
each example. Thus hF and hG cannot be derived just from native legality,
Q96 endpoint, cold/GTD and CF relay conditions, even if the other of the two
premises and hM are retained. This is a separation of the **premises**, not a
counterexample to `R >= 56`: all four R values are much larger than 56.

The simplest simultaneous local violation uses label 11, with
`A=<3,4> ⊂ 11^⊥`, `B=<11>`, cold coefficient `u[0]=1`, output weight
`w[0]=-1`. Y2 moves from 0 to A; the fresh owned field copies it at A, moves
A -> 0 -> B, is added with coefficient -1 to X2 at B, and is cleared. A move
of X2 from B to the full chart and of Y2 from A to `11^⊥` complete the hosted
endpoints. An A dimension of 2 is the smallest way to violate hF; because
`q[0]=11` must belong to B when `w[0] != 0`, B dimension 1 is the smallest
possible for hG in this nonzero-label instance. No claim is made that 1,648
is the globally least possible event count. The separate 1/2 and 7/8 examples
exercise both actual thresholds.

`negative_controls.py` adds a validly located opposite ADD that cancels the
first hosted receipt: the native checker reports bad input `[320]`. Mutating
a MOVE to a distinct equal-rank singleton chart is rejected by the strict
nesting guards, for both owned and public fields.

## A conditional route to hM

The concrete source data contain a D-only clique at 0-based #7113 indices
`[0,6,18,24,32,41,52,103]`, labels
`[11,21,161,38,146,140,56,191]`. Every one of the 64 pairwise F2 dot products
is 1, and each label belongs to a D port; `clique_check.py` recomputes this.
Consequently, if a CF extraction has been shown to satisfy the odd-cell
receipt identity for the 96 hosted X2/Y2 pairs, its `GNF` matrix has `-I_8`
on that clique and hence rank at least 8. The native endpoint gives those
hosted receipts, while `FutureAttr.attribution_decoder` derives an odd-cell
decoder identity for its own attributed rows under its stated hypotheses.
The missing step is identifying the `CFRelay` epoch factors and actual H
with those attributed receipts. `Life` by itself only asks support and cost
conditions, so its u and w cannot be silently identified with verifier rows.
This is a conditional linear-algebra observation, not a formal proof that
hM follows for every native word.

## Reproduce

Python 3, standard library only, no network or solver:

```sh
python3 -I -B q96/clique_check.py
python3 -I -B q96/native_separator.py
python3 -I -B q96/replay_attribution.py
python3 -I -B q96/negative_controls.py
```

The first verifies data and clique; the second verifies exact source pins,
regenerates the four words and invokes the unchanged native verifier on each;
the third independently replays physical values, attribution and relay legality;
the fourth exercises endpoint and tied-rank negative controls. Detailed results
are `native-results.json` and `attribution-results.json`. The P104 words are
synthetic and demonstrate the named native/CF class; no replay or claim is made
for the actual #7113 submitted word, its outer caller, ordinary cost, selected
frontier, or kappa.
