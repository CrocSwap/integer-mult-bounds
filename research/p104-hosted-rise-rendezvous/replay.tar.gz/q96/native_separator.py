#!/usr/bin/env python3
"""Construct and native-replay P104/#7113-contract CF epoch separators.

Reuses the unchanged independent.py at #7852 head.  This script computes the
selected Q96 physical factorization separately; no formal Lean replay is claimed.
"""
import ast, hashlib, importlib.util, json
from fractions import Fraction
from pathlib import Path

HERE=Path(__file__).resolve().parent
OTHER=HERE/'source'
PINS={
    HERE/'independent.py':'21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874',
    OTHER/'UniFold7113.lean':'d3dbc8613472562469769e0b12049a7abffd912e1d04a40d81df73c4877a611c',
    OTHER/'BridgeNetInst.lean':'2890dd0faeee606abf424069a615fd9396420b3c5e6e1d982da8678d6319e130',
    OTHER/'CFRelay.lean':'ca1f04f426fbe47fa60b2fb3a4ddb067f095fde5f4d4a9dfe565cb7d2da62323',
    OTHER/'CFChain.lean':'3b8ba0f997377c09c53c39b325edd06e039a5e813569014fc2b6b4b0e8a45991',
    OTHER/'FutureAttr.lean':'96a5bbeae59cf3720f94d6786a5a28e79e5050694f0c9cf3c256534291f30f8b',
    OTHER/'WordModelDefs.lean':'22d8779e82d053f81c6752c8b3e8e7cde5fe33e353c116ebbbfc9f7baa66656d',
}
for path,digest in PINS.items(): assert hashlib.sha256(path.read_bytes()).hexdigest()==digest, path

def read_list(text, marker):
    i=text.index('[',text.index(marker)); j=text.index(']',i)+1
    return ast.literal_eval(text[i:j])

ports=read_list((OTHER/'UniFold7113.lean').read_text(), 'def ports7113 : List ℕ :=')
sig=read_list((OTHER/'BridgeNetInst.lean').read_text(), 'def sigL : List ℕ :=')
nonD=set(sig[96:]); Ds=[i for i in range(104) if i not in nonD]
assert len(Ds)==96 and nonD=={15,17,27,34,35,42,47,55}
clique=[0,6,18,24,32,41,52,103]
selected=Ds  # every hosted D port (Q96), in port-index order
assert all(i in Ds for i in clique)
assert all((ports[i]&ports[j]).bit_count()%2==1 for i in clique for j in clique)

sp=importlib.util.spec_from_file_location('pinned_native',HERE/'independent.py')
mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)

def qperp_basis(q):
    pivot=next(i for i in range(9) if q>>i&1)
    bs=[(1<<j)^((1<<pivot) if q>>j&1 else 0) for j in range(9) if j!=pivot]
    assert len(bs)==8 and all((q&v).bit_count()%2==0 for v in bs)
    assert len(mod.span(bs))==256
    return bs

def generate(first_intake_dim=1,first_output_dim=8):
    assert first_intake_dim in (1,2)
    assert first_output_dim in (1,7,8)
    frames=[]; byspan={}
    def frame(b):
        span=mod.span(b)
        if span not in byspan:
            byspan[span]=len(frames); frames.append(list(b))
        return byspan[span]
    z=frame([]); top=frame([1<<i for i in range(9)])
    public=416; next_owned=public
    initial=[None]*public; final=[None]*public
    live=list(range(104)); hosts={p:(224+j,320+j) for j,p in enumerate(Ds)}
    for p,q in enumerate(ports):
        x=live[p];y=x+112; line=frame([q]); hp=frame(qperp_basis(q))
        initial[x]=line;final[x]=top;initial[y]=z;final[y]=hp
        if p in hosts:
            x2,y2=hosts[p];initial[x2]=line;final[x2]=top;initial[y2]=z;final[y2]=hp
    helpers=[i for i,v in enumerate(initial) if v is None]
    assert helpers==list(range(104,112))+list(range(216,224))
    for h in helpers: initial[h]=z;final[h]=frame([ports[0]])
    program=[]; cur=initial.copy()
    def pmove(r,t):
        if cur[r]!=t:
            program.append(['MOVE',r,cur[r],t,False]);cur[r]=t
    def transfer(src,dst,start,end,coeff):
        nonlocal next_owned
        owned=next_owned;next_owned+=1
        assert cur[src]==start and cur[dst]==end
        program.extend([['INIT',owned,start],['COPY',owned,src,'1',start]])
        a=mod.span(frames[start]);b=mod.span(frames[end])
        if a < b or b < a:
            program.append(['MOVE',owned,start,end,True])
        elif a!=b:
            # Meet-free detour.  Strictly nested on both legs.
            assert start!=z and end!=z
            program.extend([['MOVE',owned,start,z,True],['MOVE',owned,z,end,True]])
        program.extend([['ADD',dst,owned,str(coeff),end],['CLEAR',owned,end]])
    epochs=[]
    for p,q in enumerate(ports):
        x=live[p];y=x+112; line=initial[x];hp=final[y]
        if p in nonD:
            # (x,y) -> (x-y,(x+y)/2), elementary shear factorization.
            transfer(y,x,z,line,-1);transfer(x,y,line,z,Fraction(1,2))
        else:
            # D primary block (x,y) -> (x,y+x).
            transfer(x,y,line,z,1)
        pmove(x,top);pmove(y,hp)
        if p in hosts:
            x2,y2=hosts[p]
            if p in selected:
                per=qperp_basis(q)
                ar=first_intake_dim if p==selected[0] else 1
                br=first_output_dim if p==selected[0] else 8
                ai=frame(per[:ar]);bo=frame([q]+per[:br-1])
                pmove(y2,ai);pmove(x2,bo)
                # X2 <- X2-Y2, with one cold intake and one output, no relay.
                transfer(y2,x2,ai,bo,-1)
                epochs.append({'port_index':p,'label':q,'A_basis':frames[ai],
                               'B_basis':frames[bo],'A_dim':ar,'B_dim':br,
                               'u':1,'w':-1})
            else:
                transfer(y2,x2,z,line,-1)
            pmove(x2,top);pmove(y2,hp)
    for h in helpers:pmove(h,final[h])
    assert cur==final
    W={'public':public,'owned_fields':next_owned-public,'frames':frames,'initial':initial,
       'final':final,'program':program,'ports':ports,'live':live,
       'hosted':{'Dports':Ds,'X2':[hosts[p][0] for p in Ds],
                 'Y2':[hosts[p][1] for p in Ds]}}
    return W,epochs

def canonical(obj):return (json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
def verify_case(name,ad,bd):
    W,epochs=generate(ad,bd)
    outcome=mod.native(W)
    assert outcome['bad_inputs']==[]
    assert len(epochs)==96
    # All 96 selected ports are isolated from each other: each selected Y2 is
    # copied once, deposited once with coefficient -1 into its own X2, and
    # no public or owned gate transfers a selected symbol to another port.
    # Thus u=e_i, w=-e_i; unrelated B-port relays are handled in the forward replay.
    hF=all(e['A_dim']<=1 for e in epochs)
    hG=all(e['B_dim']>=8 for e in epochs)
    assert hF==(ad<=1) and hG==(bd>=8)
    assert len(W['program'])==outcome['events']
    content=canonical(W);(HERE/(name+'.json')).write_bytes(content)
    return {'word':name+'.json','sha256':hashlib.sha256(content).hexdigest(),
            'native':outcome,'epochs':epochs,'hF':hF,'hG':hG,'hM':True,
            'GNF':'-I_96','rank':96,
            'first_source_A_subset_q_perp':all((e&ports[0]).bit_count()%2==0 for e in epochs[0]['A_basis'])}

results={n:verify_case(n,a,b) for n,a,b in [
    ('control_boundary',1,8),('hF_dim2',2,8),('hG_dim7',1,7),('both_small',2,1)]}
report={'pins':{'head':'41beda1d6435760dc99e38bd7e65f36798aad212',
                'independent.py_sha256':hashlib.sha256((HERE/'independent.py').read_bytes()).hexdigest(),
                'independent.py_git_blob_sha':'1ae1d7c680ad86c0fa999f2e8f0c09e966fc07a0',
                'ports_source_sha256':hashlib.sha256((OTHER/'UniFold7113.lean').read_bytes()).hexdigest(),
                'D_types_source_sha256':hashlib.sha256((OTHER/'BridgeNetInst.lean').read_bytes()).hexdigest()},
        'clique_indices':clique,'clique_labels':[ports[i] for i in clique], 'selected_D_indices':selected,'cases':results}
(HERE/'native-results.json').write_text(json.dumps(report,indent=2)+'\n')
for name,r in results.items():
    print(name,'events',r['native']['events'],'lifetimes',r['native']['lifetimes'],
          'bad_inputs',len(r['native']['bad_inputs']),'hF',r['hF'],'hG',r['hG'],
          'hM',r['hM'],'sha256',r['sha256'])
