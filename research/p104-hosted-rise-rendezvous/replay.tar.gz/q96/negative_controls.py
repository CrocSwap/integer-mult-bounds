#!/usr/bin/env python3
"""Exercise verifier rejection of an endpoint cancellation and tied-rank moves."""
from copy import deepcopy
from pathlib import Path
import importlib.util, json
HERE=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('pinned_native',HERE/'independent.py')
mod=importlib.util.module_from_spec(sp);sp.loader.exec_module(mod)
W=json.loads((HERE/'control_boundary.json').read_bytes())
assert mod.native(W)['bad_inputs']==[]
# Cancel the chosen hosted X2 output before the owned field is cleared.  All
# moves, activity rules and gates remain legal; its receipt becomes 0 instead
# of -1 and exactly the endpoint check should record a bad input.
endpoint=deepcopy(W);x=endpoint['hosted']['X2'][0]
i=next(i for i,e in enumerate(endpoint['program']) if e[0]=='ADD' and e[1]==x)
e=endpoint['program'][i]
assert e[3]=='-1' and endpoint['program'][i+1][0]=='CLEAR'
endpoint['program'].insert(i+1,['ADD',e[1],e[2],'1',e[4]])
r=mod.native(endpoint)
assert r['bad_inputs'] and endpoint['hosted']['Y2'][0] in r['bad_inputs']
# An equal-rank change between distinct singleton lines is not nested.  Test
# both public and owned paths; compare the strict subset guard itself.
def tied(own):
    B=deepcopy(W)
    j=next(j for j,e in enumerate(B['program']) if e[0]=='MOVE' and e[4]==own and
           len(mod.span(B['frames'][e[2]]))==2)
    e=B['program'][j];a=mod.span(B['frames'][e[2]])
    v=next(v for v in range(1,512) if frozenset((0,v))!=a)
    B['frames'].append([v]);b=len(B['frames'])-1;e[3]=b
    assert len(a)==len(mod.span(B['frames'][b])) and a!=mod.span(B['frames'][b])
    try:mod.native(B)
    except AssertionError:return
    raise AssertionError('verifier accepted equal-rank nonnested move')
tied(True);tied(False)
print('endpoint cancellation rejected by target: bad_inputs',r['bad_inputs'])
print('owned and public tied-rank nonnested MOVEs rejected')
