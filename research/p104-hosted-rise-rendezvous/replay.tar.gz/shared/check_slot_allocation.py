#!/usr/bin/env python3
"""Check unit-level matching and ascent telescoping for the pinned #7113 word.

Admissible slots in these toy examples are supplied explicitly.  The matcher
does not prove any decoder, causality, or price premise for a proposed claim.
"""
import gzip
import hashlib
import json
from pathlib import Path

SOURCE = Path(__file__).resolve().parent.parent / Path('source/7113/research/signed-caller-8x9/replay/supplier7112/WORD.json.gz')
PIN = 'fe0b1dc3049a6b72760a705af2e698e0e9998e969e19862a696eba63434eb233'


def match(admissible):
    """Maximum bipartite matching by augmenting paths; indices name claims."""
    owner = {}
    def augment(claim, seen):
        for slot in sorted(admissible[claim]):
            if slot in seen:
                continue
            seen.add(slot)
            if slot not in owner or augment(owner[slot], seen):
                owner[slot] = claim
                return True
        return False
    for i in range(len(admissible)):
        augment(i, set())
    return {claim: slot for slot, claim in owner.items()}


def native_ascents(word):
    """Independent count after the source native checker has validated W.

    Public MOVEs are strict ascents, so their signed increments telescope
    register by register.  Owned rises count only positive increments.
    """
    n = word['public']; d = list(map(len, word['frames']))
    cur = list(word['initial']) + [None] * word['owned_fields']
    public_rise = owned_rise = owned_drop = 0
    slots = []
    for i, e in enumerate(word['program']):
        op, r = e[:2]
        if op == 'INIT':
            assert r >= n and cur[r] is None
            cur[r] = e[2]
        elif op == 'CLEAR':
            assert r >= n and cur[r] == e[2]
            cur[r] = None
        elif op == 'MOVE':
            _, r, a, b, owned = e
            assert cur[r] == a and owned == (r >= n)
            delta = d[b] - d[a]
            assert delta != 0
            if owned:
                owned_rise += max(delta, 0)
                owned_drop += max(-delta, 0)
                slots.extend((i, h) for h in range(d[a] + 1, d[b] + 1))
            else:
                assert delta > 0
                public_rise += delta
            cur[r] = b
    assert cur[:n] == word['final'] and all(v is None for v in cur[n:])
    climb = sum(d[b] - d[a] for a, b in zip(word['initial'], word['final']))
    assert public_rise == climb
    assert len(slots) == len(set(slots)) == owned_rise
    return {'public_rise': public_rise, 'public_field_climb': climb,
            'all_ascents': public_rise + owned_rise,
            'owned_rise': owned_rise, 'owned_descent': owned_drop,
            'hosted_rise': public_rise + owned_rise - climb,
            'owned_rise_move_events': len({slot[0] for slot in slots})}


def main():
    assert __debug__
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == PIN
    w = json.loads(gzip.decompress(SOURCE.read_bytes()))
    base = native_ascents(w)
    prefix = json.loads(Path(__file__).with_name('evidence.json').read_bytes())['prefix']
    candidate = dict(w, owned_fields=w['owned_fields'] + 2, program=prefix + w['program'])
    trial = native_ascents(candidate)
    assert base['owned_rise'] == 56 and trial['owned_rise'] == 57
    assert trial['public_rise'] == base['public_rise']

    # The only prefix rise occupies the event/height slot (2,1).  Both
    # transient claims depend on that same slot; they cannot both be billed.
    shared_slot = (2, 1)
    single = match([{shared_slot}])
    collision = match([{shared_slot}, {shared_slot}])
    assert len(single) == 1 and len(collision) == 1 < 2

    # A rank-two MOVE has two distinct height units, and may support two
    # already-certified unit claims without assigning the bank twice.
    two_units = match([{(7, 1), (7, 2)}, {(7, 1), (7, 2)}])
    assert len(two_units) == 2 and len(set(two_units.values())) == 2
    assert len({slot[0] for slot in two_units.values()}) == 1
    over_capacity = match([{(7, 1), (7, 2)}] * 3)
    assert len(over_capacity) == 2 < 3

    print(json.dumps({
        'status': 'PASS_TELESCOPE_AND_SLOT_CONTROLS',
        'source_word_sha256': PIN,
        'baseline': base, 'candidate': trial,
        'controls': {
            'one_claim_one_slot_matching': len(single),
            'shared_path_two_claims_matching': len(collision),
            'rank_two_two_claims_matching': len(two_units),
            'rank_two_three_claims_matching': len(over_capacity),
        },
        'scope': 'Counts source trace ascent units and checks given allocation graphs only; semantic admissibility of claims is an external premise.',
    }, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
