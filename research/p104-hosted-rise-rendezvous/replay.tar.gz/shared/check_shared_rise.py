#!/usr/bin/env python3
"""Replay a hot, shared-rise identity prefix against the pinned native checker.

This is a finite separator for one-charge-per-consumer path accounting.  It is
not a counterexample to a decoder-rank or P104 Wall56 claim.
"""
import copy
import gzip
import hashlib
import importlib.util
import json
from collections import Counter
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / 'source'
P7113 = ROOT / '7113/research/signed-caller-8x9'
WORD = P7113 / 'replay/supplier7112/WORD.json.gz'
CHECKER = P7113 / 'replay/supplier7112/short-caller/independent.py'
CALLER = P7113 / 'expected/ODD-TYPE-AB-CALLER.json'
PRICEKIT = ROOT / '7829/research/p104-certkit-pricekit-to-lean/tools/pricekit.py'
PINS = {
    WORD: 'fe0b1dc3049a6b72760a705af2e698e0e9998e969e19862a696eba63434eb233',
    CHECKER: '21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874',
    CALLER: '255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc',
    PRICEKIT: '7e08e9129dfc46d7dd351d0ec972d1223b2488503fe49e556df0c6dcad1f3743',
}


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add(dst, src, q):
    for k, v in src.items():
        dst[k] = dst.get(k, Fraction(0)) + q * v
        if not dst[k]:
            del dst[k]


def local_prefix_replay(program, n, p, x, z, a, b):
    """Symbolic forward replay of touched public rows; source native checks all.

    `hot` means p has already been added to public x when x is read by b.
    This term is an operational provenance description, not a claim that
    FutureAttr's abstract hcold premise fails for any particular decoder.
    """
    rows = {r: {r: Fraction(1)} for r in (p, x, z)}
    cur = {p: a, x: b, z: b}
    active = {p, x, z}
    marks = {}
    for j, e in enumerate(program):
        op, r = e[:2]
        if op == 'INIT':
            assert r >= n and r not in active
            rows[r] = {}; cur[r] = e[2]; active.add(r)
        elif op == 'CLEAR':
            assert r >= n and r in active and cur[r] == e[2]
            active.remove(r); del rows[r], cur[r]
        elif op == 'MOVE':
            assert r in active and r >= n and e[4] and cur[r] == a and e[2:4] == [a, b]
            cur[r] = b
        elif op == 'ADD':
            s, q, frame = e[2], Fraction(e[3]), e[4]
            assert q and r in active and s in active and r != s and cur[r] == cur[s] == frame
            add(rows[r], rows[s], q)
            if j == 3:
                marks['first_public_after_read'] = dict(rows[x])
            if j == 5:
                marks['hot_owned_after_intake'] = dict(rows[r])
            if j == 6:
                marks['second_public_after_read'] = dict(rows[z])
        else:
            raise AssertionError(op)
    assert active == {p, x, z}
    assert rows == {r: {r: Fraction(1)} for r in (p, x, z)}
    assert all(marks[k][p] == 1 for k in marks)
    assert marks['hot_owned_after_intake'][x] == 1
    return marks


def main():
    assert __debug__, 'Run without -O'
    for path, digest in PINS.items():
        assert sha(path) == digest, f'source hash mismatch: {path}'
    checker = load_module(CHECKER, 'pinned_native_checker')
    pricekit = load_module(PRICEKIT, 'pinned_pricekit')
    word = json.loads(gzip.decompress(WORD.read_bytes()))
    caller = json.loads(CALLER.read_bytes())

    # First hosted D-port: x and its hosted counterpart z start at <q>;
    # y = p starts at 0. New registers start outside the source range.
    n = word['public']; d = word['hosted']['Dports'][0]
    x = word['live'][d]; p = x + 112; z = word['hosted']['X2'][0]
    a, b = word['initial'][p], word['initial'][x]
    assert word['initial'][z] == b
    assert checker.span(word['frames'][a]) == frozenset({0})
    assert checker.span(word['frames'][a]) < checker.span(word['frames'][b])
    assert len(word['frames'][b]) - len(word['frames'][a]) == 1
    o0 = n + word['owned_fields']; o1 = o0 + 1
    prefix = [
        ['INIT', o0, a],
        ['ADD', o0, p, '1', a],
        ['MOVE', o0, a, b, True],
        ['ADD', x, o0, '1', b],
        ['INIT', o1, b],
        ['ADD', o1, x, '1', b],  # picks up x after it received o0
        ['ADD', z, o1, '1', b],
        ['ADD', z, o1, '-1', b],
        ['CLEAR', o1, b],
        ['ADD', x, o0, '-1', b],
        ['CLEAR', o0, b],
    ]
    marks = local_prefix_replay(prefix, n, p, x, z, a, b)
    candidate = dict(word, owned_fields=word['owned_fields'] + 2,
                     program=prefix + word['program'])

    baseline = checker.native(word)
    tested = checker.native(candidate)
    assert not baseline['bad_inputs'] and not tested['bad_inputs']
    assert Counter(tested['paid']) - Counter(baseline['paid']) == Counter({1: 1})
    assert Counter(tested['rises']) - Counter(baseline['rises']) == Counter({1: 1})
    assert tested['helpers'] == baseline['helpers']
    assert tested['events'] == baseline['events'] + len(prefix)
    assert tested['lifetimes'] == baseline['lifetimes'] + 2

    # Both invalid-locality and nonidentity controls must be detected by the
    # original source checker, not merely by the toy replay above.
    broken_chart = copy.deepcopy(prefix)
    broken_chart[3][-1] = a
    try:
        checker.native(dict(candidate, program=broken_chart + word['program']))
    except AssertionError:
        pass
    else:
        raise AssertionError('invalid frame accepted')
    missing_undo = prefix[:7] + prefix[8:]
    wrong = checker.native(dict(candidate, program=missing_undo + word['program']))
    assert wrong['bad_inputs'], 'endpoint corruption escaped checker'

    # The caller has 17 J events; they are not 17*104 copies.  This checks
    # the precise invoice effect without replaying caller algebra or geometry.
    n0 = pricekit.native_from_word(word)
    n1 = pricekit.native_from_word(candidate)
    ci = pricekit.caller_invoice(caller)
    i0 = pricekit.invoice(ci, n0); i1 = pricekit.invoice(ci, n1)
    assert ci['nJ'] == caller['stages'] == 17
    assert i1['P'] - i0['P'] == Counter({1: 17}) and i1['T'] == i0['T']

    def repr_rows(m):
        return {name: {str(k): str(v) for k, v in sorted(row.items())} for name, row in m.items()}
    result = {
        'status': 'PASS_SHARED_RISE_FULL_NATIVE_REPLAY',
        'source_sha256': {str(p): sha(p) for p in [WORD, CHECKER, CALLER, PRICEKIT]},
        'word_public': n, 'word_events': baseline['events'], 'candidate_events': tested['events'],
        'p_x_z': [p, x, z], 'fresh_owned': [o0, o1], 'frames_a_b': [a, b],
        'prefix': prefix, 'symbolic_rows': repr_rows(marks),
        'baseline_paid': baseline['paid'], 'candidate_paid': tested['paid'],
        'baseline_owned_rises': baseline['rises'], 'candidate_owned_rises': tested['rises'],
        'bad_inputs_baseline_candidate': [len(baseline['bad_inputs']), len(tested['bad_inputs'])],
        'missing_undo_bad_inputs': wrong['bad_inputs'], 'bad_frame_rejected': True,
        'caller_J': ci['nJ'], 'whole_caller_delta_paid': {'1': 17},
        'naive_consumer_path_charges': 2, 'distinct_owned_rise_units': 1,
        'scope': 'Finite replay of an identity prefix embedded in the pinned P104 word. Two transient consumers share one rank-one owned rise via a hot public intermediate. This is not a decoder-rank counterexample or an unconditional bound.',
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
