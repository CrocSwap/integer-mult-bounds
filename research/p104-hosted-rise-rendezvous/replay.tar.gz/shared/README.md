# P104 hosted-rise accounting: a shared hot path

This is a local, source-bound screen. It does **not** prove or refute
`R >= 56`, the aggregate `D + R >= 112` premise, or a multiplication
theorem. It identifies a failure of charging one rise per consumer path and
states an accounting rule that avoids that particular failure. The hard
semantic step—extracting enough independently chargeable obligations from an
arbitrary legal word—remains open.

## Result

An 11-event identity prefix, embedded in the real #7113 native word, makes two
transient public values depend on one owned rank-one ascent. The second public
dependency is relayed through a fresh owned register that picks up the first
public register **after** it has received the first owned value. The copied
input has coefficient 1 in both values. Counting a distinct rise for each
consumer would charge 2 although the prefix adds only one paid H1 MOVE and one
unit of owned ascent. One shared rise and two uses are minimal as a *capacity
separator*: this makes no claim of a globally shortest event sequence.

The prefix is deliberately undone before the source word begins. Thus these
are transient paths; the example does not disprove a rank-based decoder
inequality or show that two required final outputs cost only one rise. The
source word's linear endpoint and its native verifier checks survive. It is
an example of why an execution-to-decoder proof must handle cancellation,
reuse, and hot intake rather than count paths.

## Pinned sources and prior work

* #7852 head `41beda1d6435760dc99e38bd7e65f36798aad212`:
  `research/p104-lowerbound-toolkit/lean/Nov15/UniOwnedBank.lean`,
  `UniTrans.lean`, `FutureAttr.lean`, `CFChain.lean`, `CFRelay.lean`,
  `UniTrace.lean`, and `RungWord7113.lean`. This toolkit is by
  DreamingOfClouds with Claude Opus 5.5; preserve its notices and its
  attribution of the earlier P104 library and constructions.
* #7113 head `07a76c5e2738882c0cb322278e56f6cae3c9885d`,
  `research/signed-caller-8x9/replay/supplier7112/WORD.json.gz`, SHA256
  `fe0b1dc3049a6b72760a705af2e698e0e9998e969e19862a696eba63434eb233`;
  its `short-caller/independent.py`, SHA256
  `21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874`;
  and `expected/ODD-TYPE-AB-CALLER.json`, SHA256
  `255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc`.
  #7113 is by Rohan Arun with substantial OpenAI Codex assistance, with
  the full native/caller lineage credited in its README.
* #7829 head `1fdc9ecd1b1311d8ea6e02b6f81ae0d8d24999e2`,
  `tools/pricekit.py`, SHA256
  `7e08e9129dfc46d7dd351d0ec972d1223b2488503fe49e556df0c6dcad1f3743`.
  Its stated pricing contract is a source-bound model, not an independent
  derivation from SPEC.

The original #7852 toolkit already establishes the bank-level accounting
`UniTrans.ownedRise_ge_of_emb`: a supplied *injective bank map*, suitable
height inequalities, and the public telescope bound a supplied transpose
witness's descent by hosted rise. It also establishes `CFChain` bounds for
disjoint GTD epochs and `CFRelay` hot relays under the stated carrier-forest
conditions. `TransWitness` still requires a banked transpose witness and a
unified layout. None of these statements constructs such data from every
legal P104 execution. The #7852 README explicitly records its own prior
climb-sharing obstruction (R=2, mass=3); the present toy is a simpler
consumer-path accounting witness and is not a replacement for that result.

## The exact price boundaries

The source `independent.py:native` checks legal frame spans, owned INIT/CLEAR,
gate co-location, strict public ascents, nested owned MOVEs, positive MOVE
rank, final positions, and the reverse-mode native endpoint. Each MOVE of
rank `abs(dim(dst)-dim(src))` contributes **one** paid job at that rank;
an owned ascent also increments the `rises` histogram at that rank. `ADD`,
`COPY`, `SCALE`, `INIT`, and `CLEAR` do not add a native recursive paid job.
They do have ordinary-work and other physical obligations, which this screen
does not waive. An `ADD` into owned storage may read a public whose value has
previously been changed; the native checker has no general cold-intake rule.

The #7113 caller's own `emit_odd_type_ab.py` and PRICEKIT charge one complete
native word per J event, not per port: there are 17 J events here. `QUERY`
charges H1 per port of the caller type; `IDLE_ONE(S)` charges H(8|S|) per
type-port; `IDLE_ODD(S)` charges H(8|S|+1) per type-port. Those are separate
caller occurrences, not extra owned MOVE rises inside one J. PRICEKIT's
counterfactual paid-LAMBDA option is not used. Native main climbs are part of
the paid MOVE ledger, while their field climb must be subtracted in the
hosted-rise statistic. A recursive H_r job is not r independent H1 jobs:
the unit slots below are rank-*mass* bookkeeping, not a decomposition of the
concave recursive tariff.

## Explicit checked prefix

Write `p=112`, `x=0`, `z=772`; `x,z` begin at frame 0, the line `<11>`,
and `p` begins at frame 3, `{0}`. Use fresh owned registers `a=1535`,
`b=1536`. The full eleven raw operations are preserved in `evidence.json`.
The non-undo part is:

1. `INIT a` at `{0}`; `ADD a,p`; `MOVE a: {0} -> <11>`.
2. `ADD x,a`; then `INIT b` at `<11>` and `ADD b,x`.
3. `ADD z,b`. The first public value is `x+p`; the second is `z+x+p`.

The final four operations undo the two public ADDs and clear both owned
registers. Every gate's
operands are co-located; coefficient signs are allowed. On the original and
modified full words, the source's `native` check returned zero bad inputs.
Deleting the undo of `z` yielded bad inputs `[0,112]`; changing a gate's
frame to the wrong one triggered the verifier assertion. The modified word
has two more owned fields and a different ordinary-work bill; no candidate
physical caller rebinding, compiler, outer-gate, or multiplier replay was
performed.

For the source word the independent count is: all ascent mass `10920`,
public field climb `10864`, owned ascent/hosted rise `56` across 23 MOVE
events, and owned descent `56`. The prefix changes these to `10921`,
`10864`, `57` across 24 MOVE events, and `56`, respectively. The caller
pricer yields exactly 17 extra H1 jobs under its 17-J arithmetic; no full
physical caller replay is implied by that calculation.

## A sufficient injective accounting class

For a verifier-valid native word, let each owned ascent event `e` from
dimension `a_e` to `b_e > a_e` provide the finite slot set
`{(e,h): a_e < h <= b_e}`. The slots are a count of rank mass, not canonical
basis directions. Define `S` as their disjoint union. Suppose a separate
argument supplies a finite set of unit obligations `U`, proves every chosen
slot is causally and geometrically admissible for its obligation, and gives
an injective map `f: U -> S`. Then

```
|U| <= |S| = sum_owned_ascents (b_e - a_e) = hostedRise.
```

The last equality follows by telescoping every public field's strictly
ascending MOVE path: public ascent mass equals final dimension minus initial
dimension. The remaining ascent mass is exactly the owned ascent mass.
Each equality requires the fold to identify its public banks and field climbs
with these actual paths; #7852's `UniTrans.hostedRise_eq_owned` states the
bank-level conclusion under that telescope hypothesis. This paragraph is a
paper proof of the unit-capacity accounting, not a new Lean theorem.

For a constructive special class, suppose independently certified integer
demands `d_j` each come with a set `E_j` of owned ascent events, the sets
`E_j` are pairwise disjoint, and `d_j <= sum_{e in E_j}(b_e-a_e)` is already
proved. Enumerate the slots of each `E_j` and assign its first `d_j` slots
to that demand. The assignments are injective because the event sets are
disjoint; hence `sum_j d_j <= hostedRise`. This accounting remains valid
when the execution contains hot intakes, provided the stated local demand
certificates are valid for those intakes. It does not derive those
certificates from hot execution. CFChain already supplies such disjoint
cost accounting under its own epoch hypotheses; no new general CF cover is
claimed here.

The slot condition allows two separately certified unit obligations to share
one rank-two MOVE at **different** slots. It rejects two claims whose only
admissible slot is the same rank-one event; the checked prefix is such a
collision if one tries to charge its two paths. It does not prove that
obligations may occupy different slots: for vector-valued claims one must
establish the relevant rank/independence or another sound capacity theorem.
A graph matching cannot manufacture those semantic premises. Constructing a
decoder, preserving its exact identity through hot relay and cancellation,
and proving enough admissible, independent slots for all legal words remain
open. A source-level verifier bridge must also identify one slot only once
across epochs, registers and consumers. Across separate J calls, the call
identifier must be included in the slot identity.

## Replay

Exports remain read-only. The scripts import the pinned independent native
checker and PRICEKIT from `source` and check the hashes
above. From this directory run:

```
python3 -I -B check_shared_rise.py > evidence.json
python3 -I -B check_slot_allocation.py > allocation-evidence.json
```

The first is three native endpoint replays plus an invalid-frame control; it
does not run the caller endpoint or a Lean build. The second independently
recounts the physical MOVE dimensions and checks four finite matching
controls. Expected markers: `PASS_SHARED_RISE_FULL_NATIVE_REPLAY` and
`PASS_TELESCOPE_AND_SLOT_CONTROLS`. No GitHub changes or publication were
made. Local new scripts and proof sketch: OpenAI Codex, building on the
sources credited above.
