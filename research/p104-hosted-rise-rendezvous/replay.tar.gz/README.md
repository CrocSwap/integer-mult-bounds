# Exact hosted-rise and rendezvous controls

The Q96 cases independently separate hF and hG in the verifier and
attribution setting while hM holds. Retimed cases reach owned rise 104
in the stated class. The separate identity-prefix experiment shows two
transient public reads that share one rank-one ascent. These claims have
different hypotheses. The hosted-rise 56 question remains open.

Run from this directory on CPython 3.12.

```sh
python3 -I -B q96/clique_check.py
python3 -I -B q96/native_separator.py
python3 -I -B q96/replay_attribution.py
python3 -I -B q96/negative_controls.py
python3 -I -B retimed/review.py
python3 -I -B retimed/controls.py
python3 -I -B shared/check_shared_rise.py > shared/evidence.json
python3 -I -B shared/check_slot_allocation.py
```

The subdirectory reports give exact pins and finite controls. The same
native checker bytes are supplied with the #7113 and #7852 inputs. Credit
DreamingOfClouds and the #7112/#7113 authors for those sources and models.
