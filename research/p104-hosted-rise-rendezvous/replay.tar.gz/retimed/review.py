#!/usr/bin/env python3
"""Independent restricted review and room-retiming of Q96 witness words.

The conclusions are finite Python checks. The generated words are not Lean
instances and these are not multiplier or complete-caller replays.
"""
from collections import Counter, defaultdict
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import importlib.util
import json

PEER = Path(__file__).resolve().parent.parent / 'q96'
OUT = Path(__file__).resolve().parent
LEAN = Path(__file__).resolve().parent.parent / 'q96/source'
PINS = {
    'independent.py': '21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874',
    'hG_dim7.json': '7f4ad411b65fca5751c8c17ecc39c1e72745e4c8b5a51663aea5f22582b273cb',
    'both_small.json': 'd3844f52957c1059dde86c3584d39f6118d024682939926fd1b895eb2853b560',
    'hF_dim2.json': 'c9c5d30115e28149986a80cdf30c3ad8b7974902dffc658f9701b32184305306',
}
LEAN_PINS = {
    'FutureAttr.lean': '96a5bbeae59cf3720f94d6786a5a28e79e5050694f0c9cf3c256534291f30f8b',
    'CFChain.lean': '3b8ba0f997377c09c53c39b325edd06e039a5e813569014fc2b6b4b0e8a45991',
    'CFRelay.lean': 'ca1f04f426fbe47fa60b2fb3a4ddb067f095fde5f4d4a9dfe565cb7d2da62323',
    'UniFold7113.lean': 'd3dbc8613472562469769e0b12049a7abffd912e1d04a40d81df73c4877a611c',
    'BridgeNetInst.lean': '2890dd0faeee606abf424069a615fd9396420b3c5e6e1d982da8678d6319e130',
}


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def module(path):
    spec = importlib.util.spec_from_file_location('pinned_native', path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def add(a, b, scale=Q(1)):
    out = dict(a)
    for k, v in b.items():
        out[k] = out.get(k, Q(0)) + scale * v
        if out[k] == 0:
            del out[k]
    return out


def orth(chart, label):
    return all((a & label).bit_count() % 2 == 0 for a in chart)


def dim(chart):
    assert len(chart) > 0 and len(chart) & (len(chart) - 1) == 0
    return len(chart).bit_length() - 1


def join(a, b):
    return frozenset(x ^ y for x in a for y in b)


def effective(v, count):
    # Fy = -I, so eff(v)_j = v(y_j) + v(x_j).
    return {j: value for j in range(count)
            if (value := v.get(j, Q(0)) + v.get(count + j, Q(0)))}


def review(word, native):
    n = word['public']; N = n + word['owned_fields']; D = word['hosted']['Dports']
    xs = word['hosted']['X2']; ys = word['hosted']['Y2']
    m = len(D); assert m == len(xs) == len(ys) == 96
    labels = [word['ports'][p] for p in D]
    fs = [native.span(b) for b in word['frames']]
    assert len(set(xs + ys)) == 2 * m
    assert all(labels[j] in fs[word['initial'][xs[j]]] for j in range(m))
    cur = list(word['initial']) + [None] * (N - n)
    values = [{} for _ in range(N)]
    weights = [{} for _ in range(N)]
    for j, r in enumerate(xs): values[r] = {j: Q(1)}
    for j, r in enumerate(ys): values[r] = {m+j: Q(1)}
    xpos = {r: j for j, r in enumerate(xs)}
    live, epochs = {}, []
    carrier = [defaultdict(Q) for _ in range(n)]
    H = defaultdict(Q)
    for tick, e in enumerate(word['program']):
        op, r = e[:2]
        if op == 'INIT':
            assert r >= n and cur[r] is None and not values[r] and not weights[r]
            cur[r] = e[2]
            live[r] = {'id': len(epochs), 'A': fs[1], 'B': frozenset({0}),
                       'cost': 0, 'intakes': [], 'outputs': [], 'reg': r}
            assert dim(fs[1]) == 9
            epochs.append(None)
        elif op == 'CLEAR':
            assert r in live and cur[r] == e[2]
            a = live.pop(r); a['v'] = dict(values[r]); a['w'] = dict(weights[r])
            a['u'] = effective(a['v'], m); epochs[a['id']] = a
            values[r] = {}; weights[r] = {}; cur[r] = None
        elif op == 'MOVE':
            _, r, a, b, owned = e
            assert cur[r] == a and owned == (r >= n)
            if owned:
                assert fs[a] < fs[b] or fs[b] < fs[a]
                live[r]['cost'] += max(dim(fs[b]) - dim(fs[a]), 0)
            else:
                assert fs[a] < fs[b]
            cur[r] = b
        elif op in ('COPY', 'ADD'):
            s, coeff, c = e[2], Q(e[3]), e[4]
            assert coeff and cur[r] == cur[s] == c and r != s
            assert (r >= n) != (s >= n), 'this review expects public/owned transfers only'
            if op == 'COPY':
                assert r >= n and not values[r] and not weights[r]
            if r >= n:
                a = live[r]
                assert not a['outputs'], 'GTD failed'
                for j in effective(values[s], m): assert orth(fs[c], labels[j]), ('cold', tick, j)
                a['A'] = a['A'] & fs[c]; a['intakes'].append(tick)
                for prev, v in carrier[s].items(): H[(a['id'], prev)] += coeff*v
            else:
                a = live[s]; a['B'] = join(a['B'], fs[c]); a['outputs'].append(tick)
                carrier[r][a['id']] += coeff
            tv = {xpos[r]: Q(1)} if r in xpos else {}
            weights[s] = add(weights[s], add(tv, weights[r], Q(-1)), coeff)
            if op == 'COPY': values[r] = {}
            values[r] = add(values[r], values[s], coeff)
        else:
            raise AssertionError(('unexpected op', e))
    assert not live and cur[:n] == word['final'] and all(v is None for v in cur[n:])
    assert all(e is not None and len(e['intakes']) == len(e['outputs']) == 1 for e in epochs)
    assert len({e['intakes'][-1] for e in epochs}) == len(epochs)  # injective lam
    # Endpoint hypotheses for X symbols, non-target cold Ys, and Fy=-I.
    for r in range(n):
        xpart = {j: v for j, v in values[r].items() if j < m}
        assert xpart == ({xpos[r]: Q(1)} if r in xpos else {})
        for idx, value in values[r].items():
            if idx >= m and r not in xpos:
                assert orth(fs[cur[r]], labels[idx-m])
        if r in xpos:
            assert effective(values[r], m) == {}  # v_y + v_x = 0 for Fy=-I
    # Compute cold factors F_k = eff(v_k) - sum_j H_kj eff(v_j).
    H = {k: v for k, v in H.items() if v}
    assert not any(j == k2 for (_, j) in H for (k2, _) in H), 'not H^2=0'
    for e in epochs:
        f = dict(e['u'])
        for (k, j), v in H.items():
            if k == e['id']: f = add(f, epochs[j]['u'], -v)
        e['F'] = f
        for j in f: assert orth(e['A'], labels[j])
        for j in e['w']: assert labels[j] in e['B']
        assert dim(join(e['A'], e['B'])) - dim(e['A']) <= e['cost']
    for (k, j), v in H.items():
        assert epochs[k]['A'] <= epochs[j]['B']
        assert epochs[j]['intakes'][-1] < epochs[k]['intakes'][-1]
    # H^2=0 implies Nmat(H)=I+H, since there are >1 nodes.
    M = defaultdict(Q)
    for e in epochs:
        for s, g in e['w'].items():
            for t, f in e['F'].items(): M[s, t] += g*f
    for (k, j), h in H.items():
        for s, g in epochs[k]['w'].items():
            for t, f in epochs[j]['F'].items(): M[s, t] += g*h*f
    M = {k: v for k, v in M.items() if v}
    assert M == {(j, j): Q(-1) for j in range(m)}
    hf_bad = [e['id'] for e in epochs if e['F'] and dim(e['A']) > 1]
    hg_bad = [e['id'] for e in epochs if e['w'] and dim(e['B']) < 8]
    relay_relevant = [(k, j) for (k, j) in H if epochs[k]['F'] or epochs[k]['w']
                      or epochs[j]['F'] or epochs[j]['w']]
    first = next(e for e in epochs if 0 in e['F'] or 0 in e['w'])
    return {'epochs': len(epochs), 'hF': not hf_bad, 'hG': not hg_bad, 'hM': True,
            'hF_bad': hf_bad, 'hG_bad': hg_bad, 'rank_GNF': m,
            'R': sum(e['cost'] for e in epochs), 'relays': len(H),
            'selected_relevant_relay_edges': relay_relevant,
            'first': {'epoch': first['id'], 'A_dim': dim(first['A']),
                      'B_dim': dim(first['B']), 'F0': str(first['F'].get(0, 0)),
                      'G0': str(first['w'].get(0, 0)), 'cost': first['cost']}}


def retime(word, skip_first=True):
    """Remove artificial public rooms and retime each selected transfer.

    For each changed D port, take Y2 at its initial zero chart, lift once to
    the line where X2 was born, then finish each public's original ascent.
    The selected first port can be preserved verbatim as the hF/hG witness.
    """
    program = [e[:] for e in word['program']]
    remove = set(); changed = []
    for ordinal, (x, y) in enumerate(zip(word['hosted']['X2'], word['hosted']['Y2'])):
        if skip_first and ordinal == 0: continue
        copies = [i for i, e in enumerate(program) if e[0] == 'COPY' and e[2] == y]
        assert len(copies) == 1
        i = copies[0]; owned = program[i][1]
        assert program[i-1][0:2] == ['INIT', owned]
        assert program[i-2][0:2] == ['MOVE', x]
        assert program[i-3][0:2] == ['MOVE', y]
        assert program[i+1][0:2] == ['MOVE', owned] and program[i+1][4] is True
        assert program[i+2][0:3] == ['ADD', x, owned]
        assert program[i+3][0:2] == ['CLEAR', owned]
        assert program[i+4][0:2] == ['MOVE', x]
        assert program[i+5][0:2] == ['MOVE', y]
        low, line = word['initial'][y], word['initial'][x]
        assert len(word['frames'][low]) == 0 and len(word['frames'][line]) == 1
        remove.update((i-3, i-2))
        program[i-1][2] = low
        program[i][4] = low
        program[i+1][2:4] = [low, line]
        program[i+2][4] = line
        program[i+3][2] = line
        program[i+4][2] = line
        program[i+5][2] = low
        changed.append(ordinal)
    result = dict(word, program=[e for i, e in enumerate(program) if i not in remove])
    assert len(result['program']) == len(program)-2*len(changed)
    return result, changed


def retime_hf(word, native, skip_first=True):
    """Keep each output B=8 but start intake at its final 8-dim q-perp.

    The two dimension-eight charts are different.  Move owned content down
    to their seven-dimensional intersection and then up once to the output.
    """
    program = [e[:] for e in word['program']]
    frames = [b[:] for b in word['frames']]
    spans = [native.span(b) for b in frames]
    remove, insert_before, changed = set(), {}, []
    for ordinal, (x, y) in enumerate(zip(word['hosted']['X2'], word['hosted']['Y2'])):
        if skip_first and ordinal == 0: continue
        copies = [i for i, e in enumerate(program) if e[0] == 'COPY' and e[2] == y]
        assert len(copies) == 1
        i = copies[0]; owned = program[i][1]
        assert program[i-3][0:2] == ['MOVE', y]
        assert program[i-2][0:2] == ['MOVE', x]
        assert program[i-1][0:2] == ['INIT', owned]
        assert program[i+1][0:2] == ['MOVE', owned] and program[i+1][4] is True
        assert program[i+2][0:3] == ['ADD', x, owned]
        assert program[i+3][0:2] == ['CLEAR', owned]
        assert program[i+4][0:2] == ['MOVE', x]
        assert program[i+5][0:2] == ['MOVE', y]
        hp = word['final'][y]; out = program[i+1][3]
        assert dim(spans[hp]) == dim(spans[out]) == 8 and spans[hp] != spans[out]
        common = spans[hp] & spans[out]
        assert dim(common) == 7
        basis, got = [], {0}
        for v in sorted(common):
            if v not in got:
                basis.append(v); got |= {u ^ v for u in got}
        assert frozenset(got) == common and len(basis) == 7
        if common in spans:
            mid = spans.index(common)
        else:
            mid = len(frames); frames.append(basis); spans.append(common)
        program[i-3][3] = hp
        program[i-1][2] = hp
        program[i][4] = hp
        insert_before[i+1] = ['MOVE', owned, hp, mid, True]
        program[i+1][2] = mid
        remove.add(i+5)
        changed.append(ordinal)
    combined = []
    for i, e in enumerate(program):
        if i in insert_before: combined.append(insert_before[i])
        if i not in remove: combined.append(e)
    assert len(combined) == len(program)
    return dict(word, program=combined, frames=frames), changed


def main():
    assert __debug__
    for name, pin in PINS.items(): assert sha(PEER/name) == pin, name
    for name, pin in LEAN_PINS.items(): assert sha(LEAN/name) == pin, name
    checker = module(PEER/'independent.py')
    summary = {'source_pins': PINS, 'lean_pins': LEAN_PINS,
               'p104_head': '41beda1d6435760dc99e38bd7e65f36798aad212', 'cases': {}}
    for source_name, dest_name, method, skip in [
        ('hG_dim7', 'hG_preserved_first', 'hG', True),
        ('hG_dim7', 'hG_all_retimed', 'hG', False),
        ('both_small', 'both_preserved_first', 'hG', True),
        ('hF_dim2', 'hF_preserved_first', 'hF', True),
        ('hF_dim2', 'hF_all_retimed', 'hF', False),
        ('hF_dim2', None, None, True),
    ]:
        word = json.loads((PEER/(source_name+'.json')).read_bytes())
        if method == 'hG':
            word, changed = retime(word, skip)
        elif method == 'hF':
            word, changed = retime_hf(word, checker, skip)
        else:
            dest_name = 'hF_reference'; changed = []
        result = checker.native(word); assert not result['bad_inputs']
        computed = review(word, checker)
        assert computed['R'] == sum(int(k)*v for k, v in result['rises'].items())
        expected = {'hG_preserved_first': (True, False, 109),
                    'hG_all_retimed': (True, False, 104),
                    'both_preserved_first': (False, False, 104),
                    'hF_preserved_first': (False, True, 109),
                    'hF_all_retimed': (False, True, 104),
                    'hF_reference': (False, True, 679)}[dest_name]
        assert (computed['hF'], computed['hG'], computed['R']) == expected
        raw = (json.dumps(word, sort_keys=True, separators=(',', ':'))+'\n').encode()
        if changed: (OUT/(dest_name+'.json')).write_bytes(raw)
        summary['cases'][dest_name] = {'source': source_name, 'changed_D_port_ordinals': changed,
                                        'sha256': hashlib.sha256(raw).hexdigest(),
                                        'events': len(word['program']), 'native': result, 'review': computed}
        print(dest_name, 'hF/hG/hM', computed['hF'], computed['hG'], computed['hM'],
              'R', computed['R'], 'events', len(word['program']), flush=True)
    (OUT/'review-results.json').write_text(json.dumps(summary, indent=2, sort_keys=True)+'\n')
    print('PASS_FINITE_ATTRIBUTION_AND_ROOM_RETIME', flush=True)


if __name__ == '__main__': main()
