# Independent review: Q96 rendezvous witnesses

The 04-rendezvous examples are **native-verifier-valid finite words** with
explicitly constructed attribution factors. Their hF and hG failures are
real for those factors. Their selected 96-port factors do not, however,
exercise a nonzero hot relay: the eight relay edges belong to epochs with
zero selected cold increments and zero selected output weights. They are
therefore not evidence that the Q96 factor survives a genuinely hot relay.
No universal conclusion about all possible attributions follows.

The large rise totals are also not intrinsic to these examples. A local
retiming lowers them while preserving each reported Boolean failure and,
where indicated, the original first failing epoch exactly. All totals here
remain above 56 and make no counterexample to `R >= 56`.

## Results

| Source → locally retimed case | First relevant `(dim A, dim B, F_0, G_0)` | hF | hG | rank GNF | R |
|---|---|---:|---:|---:|---:|
| `hF_dim2` reference | `(2,8,1,-1)` | false | true | 96 | 679 |
| `hF_preserved_first` | `(2,8,1,-1)` | false | true | 96 | 109 |
| `hF_all_retimed` | `(8,8,1,-1)` | false | true | 96 | 104 |
| `hG_dim7` peer reference | `(1,7,1,-1)` | true | false | 96 | 679 |
| `hG_preserved_first` | `(1,7,1,-1)` | true | false | 96 | 109 |
| `hG_all_retimed` | `(0,1,1,-1)` | true | false | 96 | 104 |
| `both_small` peer reference | `(2,1,1,-1)` | false | false | 96 | 674 |
| `both_preserved_first` | `(2,1,1,-1)` | false | false | 96 | 104 |

The first-row data of the two preserved-first variants are untouched, but
retiming the other 95 selected ports increases the number of hF- or hG-bad
epochs from 1 to 96. Thus the truth values and original witness are
preserved, not the whole failure set or the original chart sequence.

For hG, at each of the other 95 ports, take Y2 at its initial zero chart,
climb the owned scratch once to the line `<q>` already occupied by X2, and
then send the public fields to their original final charts. This removes
two room moves per changed port and retimes the dependent MOVEs/gates; it is
not a deletion-only patch. It reduces that owned ascent from 7 to 1. The
first hG witness stays at A=1, B=7 and cost 6.

For hF, take Y2 directly to its final `q-perp` chart A of dimension 8; keep
the original output chart B of dimension 8 containing q. Since q is odd,
`A != B`, `dim(A ∩ B)=7`, and `dim(A+B)=9`. Move owned scratch down to
the intersection and then up to B. This costs one unit of owned rise, while
`q ∈ A-perp`, `q ∈ B`, and B still has dimension 8. The first hF witness
stays at A=2, B=8 and cost 6. Retiming every selected port rather than 95
gives R=104 in both hF-only and hG-only cases. The all-retimed hF case has
96 relevant price-one epochs and eight units in the non-D sector.

These are literal native-rank bills, not 570 free recursive jobs. For each
of the 95 hG retimings the paid histogram changes by `-H1 - 3 H7 + 2 H8`;
for each of the 95 hF retimings it changes by `+H1 - 2 H7 + H8`. Helpers
are unchanged. The complete caller, helper credit, ordinary work, compiler
and κ calculations were not replayed.

## Definition-by-definition review

Pinned toolkit: #7852 head `41beda1d6435760dc99e38bd7e65f36798aad212`.
The relevant source theorems and their SHA256 hashes are:

* `FutureAttr.lean` `96a5bbeae59cf3720f94d6786a5a28e79e5050694f0c9cf3c256534291f30f8b`:
  `eff(c)_s = c(y_s) - sum_u c(x_u) Fy[u,s]`; an owned ADD intake requires
  `dep=false` and, for every nonzero effective coefficient, the intake
  chart must be orthogonal to that coefficient's label. `W` is updated on
  the source by `coeff * (tv(destination) - W(destination))`. A read of
  owned storage into a public field updates B and `dep`.
* `CFChain.lean` `3b8ba0f997377c09c53c39b325edd06e039a5e813569014fc2b6b4b0e8a45991`:
  a `Life` consists of disjoint GTD epochs; the cold row `u` is supported
  on labels perpendicular to A, the weight row `w` on labels inside B, and
  epoch drop `dim(A+B)-dim A` is bounded by its owned ascent cost.
* `CFRelay.lean` `ca1f04f426fbe47fa60b2fb3a4ddb067f095fde5f4d4a9dfe565cb7d2da62323`:
  for H[k,j] nonzero, A[k] must be contained in B[j] and the last-intake
  time of j must be strictly smaller than that of k. Last-intake times must
  be injective over nodes. hF is conditional on a **nonzero cold factor**
  F[k,p], hG on a **nonzero output weight** G[s,k], and hM is a rank bound
  on `G Nmat(H) F`; it is not a rank requirement on the label Gram matrix.

`review.py` is a separate sparse rational replay on the 96 selected hosted
X2/Y2 symbols, with `Fy=-I`. It checks every represented owned intake for
the exact FutureAttr effective-content cold condition and GTD; computes the
attribution weights with the update above; builds each epoch's A, B, cost,
and final effective content; subtracts the recorded relay contributions to
obtain F; and checks the cold/output support laws. Every epoch has exactly
one intake and one output, and the 208 intake times are distinct. It checks
all eight relay inclusions and their strict time order, `H^2=0`, and computes
`G(I+H)F=-I_96`. Since `Nmat` is the finite sum of H powers and H²=0,
this establishes rank 96 for this factorization. `COPY` occurs only into
fresh zero owned storage, so its represented vector update agrees with an
ADD in FutureAttr; native COPY is still checked by the original verifier.

In every reviewed case the 96 nonzero selected F/G epochs are distinct
from the endpoints of all eight H edges. Consequently the H contribution to
this selected matrix is zero; it is not evidence of a hot selected relay.
The representation projects onto selected X2/Y2 symbols; no claim is made
about a different choice of references or every 104-port attribution.

The reference `independent.py:native` validates the 104-port D/B endpoint,
co-located gates, nested owned moves, strict public ascents, final charts,
and a reverse-mode exact endpoint matrix. Its `bad_inputs` must be checked
by the caller; this replay asserts it is empty. The native words use 416
public fields and 208 declared owned fields (peak concurrent use 1), not the
specific 51-owned-field supplier shape. The local results are Python checks
and a constructive trace interpretation, not a Lean instance, a complete
caller rebinding, or a verified multiplier. No new source-level theorem
constructs a CF factorization for every legal word.

The price-one cases illustrate why the rank hypotheses are substantive:
without hF, an F-supported node may have A=8, B=8, drop=1; without hG, a
G-supported node may have A=0, B=1, drop=1. The particular words still
spend R=104 and do not establish that either rank hypothesis is necessary
for the desired conclusion on all valid words or that the wall is false.

## Reproduction and controls

Input witnesses and independent checker are read-only in
`/tmp/p104-campaign/04-rendezvous`. Their exact hashes are pinned in
`review.py`, and the output source hashes are recorded in
`review-results.json`. Run sequentially, one core:

```
python3 -I -B review.py > replay.log
python3 -I -B controls.py > controls-results.json
```

Expected markers are `PASS_FINITE_ATTRIBUTION_AND_ROOM_RETIME` and
`PASS_MUTATION_CONTROLS`. Changing the selected target ADD coefficient is
detected as bad input `[320]`; deleting the owned MOVE is rejected by the
native checker. The resulting native words, factor summaries, paid
histograms and per-case SHA256 hashes are in `review-results.json`.

The initial source-bound constructions and witness exports are by the
04-rendezvous lane. The underlying #7852 toolkit is by DreamingOfClouds
with Claude Opus 5.5 and carries earlier P104-lineage credits; the separate
review and retiming above were prepared by OpenAI Codex. No GitHub mutation
or publication was made.
