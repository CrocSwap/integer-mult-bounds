#!/usr/bin/env python3
"""Small mutation controls for the retimed Q96 native example."""
from copy import deepcopy
from pathlib import Path
import importlib.util
import json

HERE = Path(__file__).resolve().parent
PEER = Path(__file__).resolve().parent.parent / 'q96'
spec = importlib.util.spec_from_file_location('review', HERE/'review.py')
review = importlib.util.module_from_spec(spec); spec.loader.exec_module(review)
checker = review.module(PEER/'independent.py')
w = json.loads((HERE/'hG_preserved_first.json').read_bytes())
assert not checker.native(w)['bad_inputs']
x, y = w['hosted']['X2'][0], w['hosted']['Y2'][0]
i = next(i for i, e in enumerate(w['program']) if e[0] == 'ADD' and e[1] == x)
assert w['program'][i][3] == '-1'

# Same legal event and charts, wrong endpoint coefficient.
bad_endpoint = deepcopy(w); bad_endpoint['program'][i][3] = '1'
bad = checker.native(bad_endpoint)['bad_inputs']
assert y in bad
try:
    review.review(bad_endpoint, checker)
except AssertionError:
    pass
else:
    raise AssertionError('attribution replay accepted wrong target')

# Same endpoint arithmetic if MOVE were ignored, but the output gate would
# read the scratch field at the wrong current chart and must be rejected.
bad_chart = deepcopy(w)
j = next(j for j, e in enumerate(bad_chart['program'])
         if e[0] == 'MOVE' and e[1] == w['program'][i][2])
del bad_chart['program'][j]
try:
    checker.native(bad_chart)
except AssertionError:
    pass
else:
    raise AssertionError('checker accepted missing owned move')

print(json.dumps({'status': 'PASS_MUTATION_CONTROLS',
                  'changed_target_coefficient_bad_inputs': bad,
                  'missing_owned_move_rejected': True}, indent=2, sort_keys=True))
