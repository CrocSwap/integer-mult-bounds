# SPDX-License-Identifier: Apache-2.0
"""Exact bidirectional flow of owner 679 for seven paid incidences."""
import argparse
from collections import Counter,defaultdict
from functools import reduce
from hashlib import sha256
from itertools import product
from operator import xor
from pathlib import Path
import gzip,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
import common
import binary_operator as op
import bit_native

H=679
def need(q,label):
    if not q:
        raise ValueError(label)
def mix(values):
    return reduce(xor,values,0)
def rank(rows):
    piv={}
    for v in rows:
        while v:
            p=v.bit_length()-1
            if p not in piv:
                piv[p]=v
                break
            v^=piv[p]
    return len(piv)
def cut_rows(receipts,charts,starts,ends,targets,edges):
    scope=charts.copy();out=[]
    for item in receipts:
        s=set(item['charts']) if 'charts' in item else charts-set(item['complement'])
        need(starts[H] in s and ends[H] in s,'both helper endpoints on the selected side')
        inside=sum(1<<i for i,c in enumerate(starts) if c in s)
        wanted=[targets[j]&inside for j,c in enumerate(ends) if c not in s]
        k=rank(wanted)
        edge_count=sum(a in s and b not in s for a,b in edges.values())
        need(k==edge_count,'tight full-map GF(2) chart cut')
        need(all(not(v>>H&1) for v in wanted),'the outside restricted target space annihilates input 679')
        scope&=s
        out.append(dict(side_size=len(s),rank=k,capacity=edge_count))
    return scope,out

def paths(start,dest,scope,edges):
    inside=defaultdict(list)
    for k,(a,b) in edges.items():
        if a in scope and b in scope:inside[a].append((k,b))
    rows=[];first=set()
    def visit(c,seen,path):
        first.add(c)
        if c==dest:
            rows.append(path)
            return
        for k,b in inside[c]:
            if b not in seen:visit(b,seen|{b},path+[k])
    visit(start,{start},[])
    return sorted(rows),sorted(first)

def live_masks(eligible,routes):
    masks=[]
    for m in range(1<<len(eligible)):
        delta=Counter()
        for i,p in enumerate(eligible):
            if m>>i&1:
                a,b=routes[p]
                delta[a]^=1;delta[b]^=1
        if {c for c,parity in delta.items() if parity}=={19,421}:
            masks.append(tuple(p for i,p in enumerate(eligible) if m>>i&1))
    return sorted(masks)

def gates(eligible):
    profiles={}
    for a0,a1,d in product((0,1),repeat=3):
        for mat in product((0,1),repeat=4):
            b0=(a0&mat[0])^(a1&mat[1]);b1=(a0&mat[2])^(a1&mat[3])
            for f0,f1,u in product((0,1),repeat=3):
                if ((b0&f0)^(b1&f1)^(d&u))!=1:continue
                adj0=(mat[0]&f0)^(mat[2]&f1);adj1=(mat[1]&f0)^(mat[3]&f1)
                zs={785:a0&adj0,1583:a1&adj1,789:d&u,1584:b0&f0,1934:b0&f0,
                    1585:b1&f1,2234:b1&f1}
                mask=tuple(p for p in eligible if zs[p])
                old=profiles.get(mask)
                encoding=(a0,a1,d,*mat,f0,f1,u)
                if old is None or sum(encoding)<sum(old):profiles[mask]=encoding
    return profiles

def compile_one(native,atlas,initial,final,edges,reference,control,eligible,expected_mask,materialize=None):
    a0,a1,d,m00,m01,m10,m11,f0,f1,u=control
    rows=dict(reference)
    # Fixed zero and source binding. Scalar 3554 is the new 0→19 contact.
    changed=sum(1<<p for p in eligible)
    rows={p:v&~changed for p,v in rows.items()}
    rows[3554]=1<<549
    rows[785]=a0<<H;rows[1583]=a1<<H;rows[789]=d<<H
    rows[1584]=(m00<<785)^(m01<<1583);rows[1585]=(m10<<785)^(m11<<1583)
    rows[1934]=1<<1584;rows[2234]=1<<1585
    rows[~H]=(u<<789)^(f0<<1934)^(f1<<2234)
    order=bit_native.schedule(initial,final,edges,rows)
    w=bit_native.emit_word(native,initial,final,edges,rows,order)
    packets={old:680+i for i,old in enumerate(order)}
    tr=[op.run_tape(w,atlas,r) for r in (False,True)]
    tests=[op.expected_operator(r) for r in (False,True)]
    fail=[[i for i,(a,b) in enumerate(zip(t.output,want)) if a!=b] for t,want in zip(tr,tests)]
    now=Counter(p.grade for p in tr[0].packets.values())
    need(all(Counter(p.grade for p in t.packets.values())==now for t in tr),'both complete raw grade censuses')
    need(all(H not in r and 411 not in r for r in fail) and all(r for r in fail),'both helper and bridge correct on each damaged global control')
    forward=[p for p,j in packets.items() if tr[0].packets[j].arrival.row>>H&1]
    adjoint=[p for p,j in packets.items() if tr[1].packets[j].arrival.row>>H&1]
    both=tuple(sorted(set(forward)&set(adjoint)))
    need(both==expected_mask,'literal forward/adjoint products at every paid packet')
    # Independent conservation at every actual chart, accounting for each literal paid crossing.
    boundary=Counter()
    for old in both:
        a,b=edges[old];boundary[a]^=1;boundary[b]^=1
    need({c for c,v in boundary.items() if v}=={initial[H],final[H]},'all-chart bilinear boundary')
    compressed=gzip.compress(json.dumps(w,sort_keys=True,separators=(',',':')).encode(),mtime=0)
    if materialize is not None:
        materialize.mkdir(exist_ok=True,parents=True)
        (materialize/('control-'+'-'.join(map(str,both))+'.json.gz')).write_bytes(compressed)
    return dict(encoder=list(control),jointly_active=list(both),forward_h=sorted(forward),adjoint_h=sorted(adjoint),
                error_counts=list(map(len,fail)),owner_221=[221 not in row for row in fail],
                actual_histogram=dict(sorted(now.items())),dirty_erasures=[t.dirty for t in tr],
                complete_word_canonical=op.canonical_hash(w),protected_411=[True,True],owner_679=[True,True])

def verify(materialize=None):
    native,caller,_,_,helpers,baseline,productive,rat=common.baseline()
    atlas=op.Atlas(native['frames']);charts=set(atlas.body)
    init,final,edges,rows,_=bit_native.extract(native)
    need((edges[3409],edges[3410],edges[1583])==((421,19),(19,0),(0,182)),'native retained source')
    del edges[3409],rows[3409]
    edges[3410]=(421,0);rows[3410]=(1<<1934)^(1<<2234)^(1<<2947)
    edges[1583]=(19,182);edges[3554]=(0,19);rows[3554]=1<<549;rows[1583]=1<<3554
    # Stored adjoint cuts use the forward graph set S, so its complement is the source side for reverse traffic.
    cuts=json.loads((ROOT/'CUTS.json').read_text());setsA=[]
    for item in cuts['adjoint']:
        s=set(item['charts']) if 'charts' in item else charts-set(item['complement'])
        setsA.append(dict(complement=sorted(s)))
    rev_edges={p:(b,a) for p,(a,b) in edges.items()}
    fspace,fc=cut_rows(cuts['forward'],charts,native['start'],native['final'],op.expected_operator(False),edges)
    aspace,ac=cut_rows(setsA,charts,native['final'],native['start'],op.expected_operator(True),rev_edges)
    F,ff=paths(19,421,fspace,edges);A,af=paths(421,19,aspace,rev_edges)
    request=sorted([[789],[785,1584,1934],[785,1585,2234],[1583,1584,1934],[1583,1585,2234]])
    core=fspace&aspace
    both=sorted(p for p,(a,b) in edges.items() if a in core and b in core)
    need(F==request and sorted([list(reversed(row)) for row in A])==request,'five free-clock first histories in each orientation')
    need(ff==af==sorted(core)==[19,182,268,318,421],'bidirectional intersection and first-reachable charts')
    need(both==[785,789,1583,1584,1585,1934,2234],'seven eligible receipts')
    masks=live_masks(both,edges);controls=gates(both)
    need(len(masks)==8 and masks==sorted(controls),'all eight parity masks have encoders')
    evidence=[compile_one(native,atlas,init,final,edges,rows,controls[m],both,m,materialize) for m in masks]
    by_grade=Counter(atlas.grade(a,b) for a,b in edges.values())
    need(all(e['actual_histogram']==by_grade for e in evidence),'every explicit word pays the exact qualifying profile')
    counted,targets=common.literal.paired_invoice(caller,by_grade,helpers,Counter(e[0] for e in caller['events']))
    need(targets==productive,'complete caller productive bins')
    signed=rat['signed'];rp={int(g):v for g,v in signed['paid'].items()};rt={int(g):v for g,v in signed['productive'].items()}
    prices={s:dict(binary=common.display(common.moment(counted,targets,common.D(s))),
                   original_binary=common.display(common.moment(baseline,targets,common.D(s))),
                   rational=common.display(common.moment(rp,rt,common.D(s))))
                   for s in ['0.00388','0.0038800000000000083']}
    return dict(source_gzip=op.WORD_GZIP,native_word=op.WORD,forward_cuts=fc,adjoint_cuts=ac,
                forward_simple_first_paths=F,adjoint_simple_first_paths=A,joint_charts=sorted(core),eligible=both,
                admissible_jointly_active_masks=[list(m) for m in masks],controls=evidence,
                paid_36=dict(sorted(counted.items())),productive_36=dict(sorted(targets.items())),signed=prices,
                scope='Necessary for every full operator with this paid topology. Local helper controls realize each mask and fail other rows.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--write',action='store_true');ap.add_argument('--materialize',type=Path);args=ap.parse_args()
    output=json.dumps(verify(args.materialize),sort_keys=True,indent=2)+'\n'
    if args.write:(ROOT/'RESULT.json').write_text(output)
    else:need((ROOT/'RESULT.json').read_text()==output,'deterministic receipt')
    print('PASS: seven tight-cut witnesses, five first paths both ways, seven possible joint packets, eight physical parity controls; no valid full operator among controls.')
