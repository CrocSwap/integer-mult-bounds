# Where owner 679 can travel in a funded chart-268 repair

On the paid graph that adds 0→19 to the restored-side chart-268 word, the independent helper can first reach chart 421 through only five simple paid paths. The literal adjoint has the same five paths in reverse. Only seven of the 2,874 paid moves can carry both the forward input coefficient and the reverse output coefficient of owner 679. All seven restrictions allow every sender to change its XOR and permit any acyclic retiming. [Round 9 candidate](https://github.com/CrocSwap/integer-mult-bounds/pull/8006)

| First path, native receipt IDs | Intermediate charts |
| --- | --- |
| 789 | Direct 19→421 |
| 785, 1584, 1934 | 19→182→268→421 |
| 1583, 1584, 1934 | 19→182→268→421 |
| 785, 1585, 2234 | 19→182→318→421 |
| 1583, 1585, 2234 | 19→182→318→421 |

The two 19→182 contacts are independently paid. The native 421→19→0 return has become one 421→0 contact. All other retained physical incidences use the pinned native tape. The new 0→19 receipt can deliver an old component before 785. It cannot deliver the *first* 679 component to chart 421. Any occurrence of that coefficient at chart 0 already depends on a visit to 421. [Native 680-owner word](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier)

## Full-operator restrictions on each paid transmission

Let S be a set of charts and restrict the full linear transfer to input owners starting inside S and required outputs ending outside. If exactly r scalar sends leave S and the restricted target rank is r, the r forward values on those sends span exactly the required restricted output row space. Indeed every exterior target depends on the interior data through those sends, and their number equals the independent output demand. Thus any interior input coordinate annihilated by that target space has coefficient zero on **every** outgoing send. This statement allows feedback, replacement donor equations and arbitrary causal timing.

An exact 35-chart set containing both the initial and final chart of helper 679 has required rank and outgoing capacity 545. Its exterior target space annihilates 679. The forward helper therefore stays in this set. A graph traversal starting at 19 and stopping on the first visit to 421 reaches only charts 19, 182, 268, 318 and 421. The verifier enumerates all simple paid paths. The first-reachable subgraph has no directed cycle before 421, so the list covers chronological first receipts as well.

Apply the same argument to the physical adjoint, reversing the incidences and using the transposed public map. Six full-operator cuts have exact ranks 6, 586, 582, 579, 585 and 586. Their source sides all contain the two helper endpoints. Their intersection allows the five reverse first paths. The forward set and this reverse intersection meet in exactly the five charts listed above. A packet whose forward arrival contains the input 679 and whose adjoint arrival contains the output 679 must have both endpoints in the intersection. Only receipts 785, 789, 1583, 1584, 1585, 1934 and 2234 qualify. These conclusions follow from seven explicit sets in CUTS.json. A search for the sets is unnecessary to replay the proof.

## Joint use in the forward and adjoint words

Let z for a given packet be the GF(2) product of its forward helper coefficient and its adjoint helper coefficient. For a chart-local linear map B, the pairing of the forward outputs with the reverse inputs equals the pairing of the forward inputs with the reverse outputs. This follows from the identity (Bx)·y = x·(Bᵀy). Private INIT and CLEAR instructions pair a fresh zero with the opposite orientation's retirement. Adding the local identities cancels internal chart operations and leaves the packet incidences. The parity of the jointly active incoming and outgoing receipts is one at charts 19 and 421 and zero elsewhere.

The seven allowed z values consequently satisfy the following equations over GF(2).

- z785 + z1583 + z789 = 1
- z1584 + z1585 = z785 + z1583
- z1934 = z1584 and z2234 = z1585

There are eight admissible joint-support masks. If 789 has zero joint product, precisely one of 785 and 1583 is jointly active and precisely one of the two branches through 268 and 318 is jointly active. A forward-only test of a candidate cannot establish this condition.

The verifier compiles a full literal 680-owner control for each of the eight masks. A binary two-by-two sender at chart 182 selects the two chart-268 and chart-318 channels. The controls return 679 and the protected owner 411 correctly in both orientations. Their complete maps still fail 111 forward and 43 adjoint rows. Thus all eight masks can occur in physical controls with the requested helper behavior. None supplies a full operator. Every control has the same signed 36-call binary margin +0.15481217569851 and unchanged 48-call rational margin +0.13897452233425 at 0.00388. RESULT.json includes the full grade histograms, both guard-rate profiles, actual public failure counts and canonical hashes. The finite outer application remains open.

## Reproduce

Use Python 3.11 or later with its standard library.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```

To write all eight complete diagnostic tapes into a new directory, run `python3 -I -B verify.py --materialize controls`. The original native word, caller invoices, upstream source pins and licenses are retained under source/.
