# Paid upstream repairs at the terminal chart-1 BIT bank

The unchanged 537-row terminal contract is priced inside the complete 36-call BIT supplier. This packet joins the two-pulse screen, the causal/funded repair and their exact shared Round 5 single-upstream predecessor. The paired and causal families make different edits and retain their respective scope, controls and source notices.

* **Exact predecessor.** The original Round 5 scripts find 1,029 cheaper visible packet/ingress pairs among 512 of 2,337 nonsink paid packets. After granting free terminal decoding under one changed upstream receipt, every one fails to restore the required nonsink outputs. Both original result JSONs, scripts, baseline word, vendor sources and notices are preserved under `predecessor/`.
* **Two independent upstream pulses.** Among 736 directed equal-footprint pairs, 365 are independent, 105 of these have a nonzero common live source row and 21 pairs expose 32 cheaper old-target combinations. All 32 fail the actual immediate receiver/single-replacement cut even with arbitrary common pulse and free choice of live receiver XOR. The failed sampled literal operator and a separate 32-case check are included. Later replacement clocks, unequal pulses and extra receipts are open.
* **A causal and a separately paid correction.** No joint sink and output-138 solution survives the 336 tested two-recode cases. A different, explicitly paid transfer from chart 157 to 552 funds a literal correction and a grade-one 552→1 route. All binary scalar rows in both directions, both complete 38-role caller operators, and owner 411/bridge 3553 replay. At K = 0.003879928046156 its complete BIT margin is approximately −71.651948302139315 and the separately priced rational margin is +0.212262470163347. At near = 0.003879929046155 the margins are about −71.652333339349117 and +0.211243929926514. The change retains 3,555 dirty private retirements in each orientation under the formal interpreter. The physical compiler, erasure, stock, precision and outer consumer remain open. No complete κ gain follows.

The two original worker archives in `components/` are byte-identical to the recorded deliveries. `COMPONENTS.json` names and hashes their evidence members. From this packet directory:

```sh
sha256sum -c SHA256SUMS
python3 -I -B predecessor/replay.py
mkdir paired causal
tar -xzf components/paired.tar.gz -C paired
tar -xzf components/causal.tar.gz -C causal
(cd paired/p104-round6-paired-pulses && python3 -B verify.py)
(cd causal/p104-r6-bit-sink-causal-correction && sha256sum -c SHA256SUMS && python3 -B cold_replay.py && python3 -B independent_literal.py)
```

For R5, the two scripts execute in a temporary copy with just two historical library pathnames relocated to the bundled source. It compares both regenerated JSONs with the preserved originals. Each component README explains its separate proof, original replay environment, boundaries and damaged controls. A future experiment could change both the upstream carrier and the time or source of a subsequent replacement, checking every restored charge.

Credit the #7852/#7869 P104 toolkit authors, #7830 supplier and its predecessor contributors, #7910 and #7927 source and the two original component notices. Clear1nsight’s campaign used OpenAI Codex assistance. This is a scoped local research export for upstream assessment.
