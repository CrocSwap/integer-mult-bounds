"""Test arbitrary free recoding of every damaged nonsink terminal after one upstream pulse."""
from collections import defaultdict,Counter
import json
from sink_recode import H,REF,op,make_basis,solve,C,bits

def basis(vals):
 p={}
 for x in vals:
  while x and x.bit_length() in p:x^=p[x.bit_length()]
  if x:p[x.bit_length()]=x
 return p

def intersect(rows,b):
 q={};result=[]
 for x in rows:
  y=x
  for i,z in sorted(b.items(),reverse=True):
   if y>>(i-1)&1:y^=z
  while y and y.bit_length() in q:v,u=q[y.bit_length()];y^=v;x^=u
  if y:q[y.bit_length()]=y,x
  elif x:result.append(x)
 return list(basis(result).values())

def main():
 w=op.load_json(REF/'inputs/WORD.json.gz',op.WORD_GZIP,True);a=op.Atlas(w['frames']);f=op.run_tape(w,a,False);inc=f.stock[1];B=make_basis(inc);D=[0]*len(inc)
 for o in f.demand[1]:
  for i in bits(solve(B,o.row)):D[i]|=1<<~o.label
 X={o.label:(d^((d&((1<<111)-1))<<111)) for o,d in zip(inc,D)};fields=[0]*(w['owned_fields']+w['public']);reach={};next_id=w['public']
 for e in w['program']:
  code,field,*args=e
  if code in ('INIT','CLEAR'):fields[field]=0
  elif code=='ADD':fields[field]^=fields[args[0]]
  elif code=='SWAP':other=args[0];fields[field],fields[other]=fields[other],fields[field]
  else:assert code=='MOVE';fields[field]|=1<<next_id;reach[next_id]=fields[field];next_id+=1
 current=json.load(open(H/'UPSTREAM-FIRST.json'));groups=defaultdict(list)
 for row in current['all']:groups[row['upstream_packet']].append(row)
 cases=Counter();hits=[];proof=[]
 for k,items in groups.items():
  pk=f.packets[k];src=list(basis(o.row for o in f.stock[pk.source] if o.time<pk.clock).values());cc=sorted({w['final'][j] for j in items[0]['nonsink_outputs_changed']});assert cc
  dims=[]
  for c in cc:
   zero=[];one=None
   for ob in f.stock[c]:
    if reach.get(ob.label,0)>>k&1:
     if one is None:one=ob.row
     else:zero.append(one^ob.row)
    else:zero.append(ob.row)
   assert one is not None
   zz=basis(zero);q=one
   while q and q.bit_length() in zz:q^=zz[q.bit_length()]
   if q:src=intersect(src,zz)
   dims.append((c,bool(q),len(zz),len(src)))
  for d in items:
   pulse=X[d['removed_sink_packet']];good=next((v for v in src if (v&pulse).bit_count()&1),None)
   if good:hits.append(dict(d,allowed_beta=list(bits(good)),bank_checks=dims));cases['stock_visible_after_all_nonsink_readout_repairs']+=1
   else:cases['excluded_after_all_free_nonsink_decoding']+=1
  proof.append({'upstream':k,'strict_cochart_upstream_span_after_terminal_repairs':len(src),'damaged_charts':[c for c,*_ in dims],'free_bank_stock_tests':dims})
 out={'source':'#7830 fixed native','upstream_candidates':len(groups),'counts':cases,'survivors':hits,'clocked_stock_ranks':proof};(H/'UPSTREAM-READOUT-CUT.json').write_text(json.dumps(out,indent=2)+'\n');print(len(groups),cases,str(hits[:1])[:390])
if __name__=='__main__':main()
