"""Binary-only seam on two forests, with complete paired native charges."""
from collections import Counter
from itertools import product
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent
BASE=Path('/tmp/p104-round3/00-astra-gain/public-ninth-axis')
sys.path.insert(0,str(BASE));import common as C

def rank(rows):
    piv={}
    for x in rows:
        while x and x.bit_length() in piv:x^=piv[x.bit_length()]
        if x:piv[x.bit_length()]=x
    return len(piv)

def bits(x):
    while x:
        t=x&-x;yield t.bit_length()-1;x^=t

def half(active,order,n):
    """Stage must contain the earlier connected components of the two contacts."""
    comp=[1<<i for i in range(n)];masks={}
    for t in order:
        a,b=active[t];union=comp[a]|comp[b];masks[t]=union
        for i in bits(union):comp[i]=union
    return masks

def counts(active,split,n):
    L=len(active);left=list(range(split));right=list(range(split,L))
    masks=half(active,left,n)|half(active,right[::-1],n)
    idle={};targets=Counter()
    for u in range(n):
        targets[1+7*sum((m>>u)&1 for m in masks.values())]+=1
        since=[]
        for t,(a,b) in enumerate(active):
            if u in (a,b):
                if since:idle[u,since[-1]]=tuple(since);since=[]
            elif masks[t]>>u&1:since.append(t)
        if since:idle[u,since[-1]]=tuple(since)
    return Counter(7*len(s) for s in idle.values()),targets,idle,masks

def nils(edge,mode):
    x,y=(1<<i for i in edge)
    return [(x+y,x+y),(x,y),(y,x)][mode]

def residual(active,modes,n):
    r=[1<<j for j in range(n)]
    for edge,mode in zip(active,modes):
        a,b=nils(edge,mode)
        for j in bits(a):r[j]^=b
    return tuple(r)

def main():
    w,caller,_,np,nt,bp,bt,rat=C.baseline()
    n=19;inc=[(0,j) for j in range(1,n)];Hf=lambda r:r**(1-float(C.RATES[0]));M=sum(Hf(g)*c for g,c in nt.items())-sum(Hf(g)*c for g,c in np.items()); shapes=[]
    for a in range(1,41):
        for b in range(1,41):
            d=a+b; pay=Counter({1:444}); tar=Counter({1+7*d:222});
            for length in [a,b]:
                for j in range(1,length):pay[7*j]+=222
                for j in range(1,length+1):tar[1+7*j]+=222
            pp=pay+Counter({r:2*d*c for r,c in np.items()});tt=tar+Counter({r:2*d*c for r,c in nt.items()})
            m=C.moment(pp,tt,C.RATES[0]);shapes.append((m[1],a,b,m,pp,tt))
    shapes.sort(reverse=True);out={'baseline_p':bp,'baseline_t':bt,'baseline_moments':{str(k):C.display(C.moment(bp,bt,k)) for k in C.RATES},'profile_shapes':len(shapes),'shapes_best':[{'a':a,'b':b,'margin':C.display(m)} for _,a,b,m,pp,tt in shapes[:10]],'all_shape_monthly_control':{str(k):C.display(C.moment(shapes[0][4],shapes[0][5],k)) for k in C.RATES}}
    assert shapes[0][1:3]==(9,9) and (shapes[0][4],shapes[0][5])==(bp,bt)
    cases=[];best=[];baseline=[]
    for j in range(18):
        for v in range(19):
            if v==j+1 or (v==0 and j!=0):continue
            a=inc.copy();a[j]=(v,j+1)
            pd,tg,_,_=counts(a,9,n)
            for mode1 in range(3):
                for mode2 in range(3 if v else 1):
                    modes=[0]*18;modes[j]=mode1
                    if v:modes[v-1]=mode2
                    res=residual(a,modes,n);rk=rank(res)
                    gain=2*(18*M+111*(sum(Hf(g)*c for g,c in tg.items())-sum(Hf(g)*c for g,c in pd.items())-rk));cases.append(gain);best.append((gain,j,v,mode1,mode2,rk,pd,tg))
    best.sort(key=lambda x:-x[0]);out['one_rewire_with_two_variable_gates']={'count':len(cases),'paid_query_lower_bound':'rank(I+sum of transported nilpotents), per chain; a two-chain joint correction costs at least twice this rank','top':[{'margin_estimate':m,'stage':j+1,'new_partner':v,'modes':[a,b],'rank':rk,'idles':pd,'roots':tg} for m,j,v,a,b,rk,pd,tg in best[:10]],'nonstandard_top':[{'margin_estimate':m,'stage':j+1,'new_partner':v,'modes':[a,b],'rank':rk,'idles':pd,'roots':tg} for m,j,v,a,b,rk,pd,tg in [next(x for x in best if x[2])]]}
    (H/'TREE-CHECKPOINT.json').write_text(json.dumps(out,indent=2)+'\n');print(out['shapes_best'][:4]);print(out['one_rewire_with_two_variable_gates']['nonstandard_top']);print(len(cases))
if __name__=='__main__':main()
