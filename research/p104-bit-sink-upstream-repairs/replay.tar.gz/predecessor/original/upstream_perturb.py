"""Find single upstream native packet perturbations observable by a cheaper sink sender."""
from collections import Counter,defaultdict
from pathlib import Path
import json
from sink_recode import REF,H,op,make_basis,solve,C,bits

def main():
    w=op.load_json(REF/'inputs/WORD.json.gz',op.WORD_GZIP,True);a=op.Atlas(w['frames']);f=op.run_tape(w,a,False);r=op.run_tape(w,a,True);inc=f.stock[1];B=make_basis(inc);D=[0]*len(inc)
    for o in f.demand[1]:
        for i in bits(solve(B,o.row)):D[i]|=1<<~o.label
    X=[d^((d&((1<<111)-1))<<111) for d in D];P=[f.packets[o.label].grade for o in inc];sinkmask=sum(1<<~o.label for o in f.demand[1]);co=Counter();hits=[];all_h=[]
    for k,pkt in f.packets.items():
        if pkt.receiver==1:continue
        c=pkt.receiver;ng=a.grade(c,1);sens=r.packets[k].arrival.row;outside=sens&~sinkmask
        relevant=[(i,x) for i,x in enumerate(X) if P[i]>ng and inc[i].label!=3553];co['non_sink_packets']+=1;co['maximum_grade_can_improve']+=bool(relevant)
        stock=[o for o in f.stock[pkt.source] if o.time<pkt.clock];co['stock_pair_checks']+=len(stock)*len(relevant)
        for i,x in relevant:
            st=[o for o in stock if (o.row&x).bit_count()&1];
            if not st:continue
            assert not (pkt.arrival.row&x).bit_count()%2
            co['visible_pairs']+=1;co['visible_with_fixed_nonsink']+=int(not outside)
            item={'upstream_packet':k,'route':[pkt.source,c],'raw_clock':pkt.clock,'upstream_grade':pkt.grade,'new_to_sink_grade':ng,'removed_sink_packet':inc[i].label,'old_sink_grade':P[i],'visible_source_rows':[o.label for o in st],'nonsink_outputs_changed':list(bits(outside)),'sink_output_sensitivity_on_537':(sens&sinkmask).bit_count()}
            all_h.append(item)
            if not outside:hits.append(item)
    aa=sorted(all_h,key=lambda f:(len(f['nonsink_outputs_changed']),f['new_to_sink_grade']-f['old_sink_grade']));(H/'UPSTREAM-FIRST.json').write_text(json.dumps({'counts':co,'all_pure_sink_pairs':hits,'ten_smallest_nonsink_repair_sets':aa[:10],'all':aa},indent=2)+'\n');print(co,'first',str(aa[:1])[:330])
if __name__=='__main__':main()
