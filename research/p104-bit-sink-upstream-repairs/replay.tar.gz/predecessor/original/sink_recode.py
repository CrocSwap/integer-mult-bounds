"""Find native sink deletions whose missing terminal owners can be reconstructed at other charts."""
from collections import Counter,defaultdict
from pathlib import Path
from itertools import combinations,product
import json,sys
from tree_screen import bits,C
H=Path(__file__).resolve().parent
REF=Path('/tmp/p104-round4/streams/04-bit-sink-retarget/public');sys.path.insert(0,str(REF/'vendor'));import binary_operator as op

def make_basis(stock):
    pivot={}
    for i,o in enumerate(stock):
        x,m=o.row,1<<i
        while x and x.bit_length() in pivot:
            t,s=pivot[x.bit_length()];x^=t;m^=s
        if x:pivot[x.bit_length()]=x,m
    return pivot

def solve(b,x):
    v=0
    while x and x.bit_length() in b:
        a,m=b[x.bit_length()];x^=a;v^=m
    return None if x else v

def main():
    w=op.load_json(REF/'inputs/WORD.json.gz',op.WORD_GZIP,True);assert op.canonical_hash(w)==op.WORD
    atlas=op.Atlas(w['frames']);f=op.run_tape(w,atlas,False);fac=[(i,o) for i,o in enumerate(f.stock[1])];incoming=[o for _,o in fac];b=make_basis(incoming);assert len(b)==537
    dep=[0]*len(incoming)
    for o in f.demand[1]:
        for i in bits(solve(b,o.row)):dep[i]|=1<<~o.label
    exclude=(1<<222)-1 | (1<<411)
    roster={i for i,d in enumerate(dep) if not(d&exclude) and d.bit_count()<=3};owners=sorted({j for i in roster for j in bits(dep[i])});bases={c:make_basis(s) for c,s in f.stock.items() if c!=1}
    forms={};old={h:atlas.grade(w['start'][h],1) for h in owners}
    for h in owners:
        opts=[]
        for c,basis in bases.items():
            m=solve(basis,1<<h)
            if m is None:continue
            g=atlas.grade(w['start'][h],c)
            if not g and w['start'][h]!=c:continue
            src=[f.stock[c][i].label for i in bits(m)]
            opts.append((g,c,src))
        forms[h]=sorted(opts,reverse=True)
    from collections import defaultdict
    sigs={};best={};classes=Counter();near=[]
    for k in (1,2,3):
        for sub in combinations(sorted(roster),k):
            dm=0
            for j in sub:dm|=dep[j]
            if dm.bit_count()>k:continue
            hs=tuple(bits(dm));assert len(hs)==k
            grades=[f.packets[incoming[i].label].grade for i in sub];d=Counter(grades)
            for h in hs:d[old[h]]-=1;d[forms[h][0][0]]+=1
            sg=tuple(sorted((i,c) for i,c in d.items() if c and i));
            if sg not in sigs:
                pd={i:-36*c for i,c in sg if c<0};tg={i:36*c for i,c in sg if c>0};sigs[sg]=tuple(C.moment(pd,tg,r) for r in C.RATES)
            m=sigs[sg];state='gain' if m[0][0]>0 else ('tie' if not sg else 'loss');classes[k,state]+=1
            witnesses=tuple((h,forms[h][0]) for h in hs);item=(m[0][0],tuple(incoming[i].label for i in sub),grades,witnesses,sg)
            if k not in best or item[0]>best[k][0]:best[k]=item
            if state=='gain':near.append(item)
    out={'word':op.WORD,'qualifying_inputs':len(roster),'all_candidate_owner_ids':owners,'full_native_stock_charts':len(bases),'single_two_three_omissions':{str(k):c for k,c in classes.items()},'distinct_histogram_shapes':len(sigs),'per_size_best':{str(k):str(a) for k,a in best.items()},'positive':list(map(str,near)),'owners_and_all_synthesized_charts':forms,'scoped':'One to three original chart-1 sink ingresses removed; retained chart-1 outputs fixed, at most k original helper roots retargeted, pure owner recoverable from all before-sink arbitrary XOR stock at one existing chart. Source granted free chronological holdings and local combinations. Actual older 411 and all 222 main columns retained.'};(H/'SYNTHESIZED-SINK.json').write_text(json.dumps(out,indent=2)+'\n');print(out['qualifying_inputs'],out['single_two_three_omissions'],out['per_size_best'],str(near[:1]))
if __name__=='__main__':main()
