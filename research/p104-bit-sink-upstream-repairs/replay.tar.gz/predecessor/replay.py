"""Reproduce the original single-pulse receipts from relocated public stock."""
import argparse
from hashlib import sha256
from pathlib import Path
import subprocess
import sys
import tempfile

def main():
    args=argparse.ArgumentParser()
    args.add_argument('--check-only',action='store_true',help='verify inputs and relocation anchors without running the two mathematical screens')
    arg=args.parse_args()
    root=Path(__file__).resolve().parent
    for line in (root/'SHA256SUMS').read_text().splitlines():
        expected,name=line.split('  ',1)
        if sha256((root/name).read_bytes()).hexdigest()!=expected:raise ValueError(name)
    rewrites={
        'tree_screen.py':("Path('/tmp/p104-round3/00-astra-gain/public-ninth-axis')",'library'),
        'sink_recode.py':("Path('/tmp/p104-round4/streams/04-bit-sink-retarget/public')",'stock'),
    }
    with tempfile.TemporaryDirectory() as tmp:
        out=Path(tmp)
        for name in ('tree_screen.py','sink_recode.py','upstream_perturb.py','upstream_repair.py'):
            content=(root/'original'/name).read_text()
            if name in rewrites:
                old,local=rewrites[name]
                if content.count(old)!=1:raise ValueError('unexpected relocation anchor '+name)
                content=content.replace(old,'Path('+repr(str(root/local))+')')
            (out/name).write_text(content)
        if arg.check_only: print('PASS predecessor source, preserved inputs and two pathname substitutions');return
        for mod,receipt in [('upstream_perturb','UPSTREAM-FIRST.json'),('upstream_repair','UPSTREAM-READOUT-CUT.json')]:
            program='import sys; sys.path.insert(0,sys.argv[1]); import '+mod+'; '+mod+'.main()'
            subprocess.run([sys.executable,'-IB','-c',program,str(out)],check=True)
            if (out/receipt).read_bytes()!=(root/'expected'/receipt).read_bytes():raise ValueError(receipt)
            print('PASS byte-identical '+receipt)
if __name__=='__main__':main()
