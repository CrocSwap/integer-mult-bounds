# A common-scalar obstruction for the early chart-268 route

For the pinned early chart-268 family, owners 184 and 189 need incompatible values from the same paid scalar, packet **3300**. Ranks and four small dual probes certify the obstruction. The result allows arbitrary causal linear recoding of **344** named surviving paid senders and every terminal decoder. The original owner endpoints, the specified early rows and receipt incidences, and the specified clocks remain fixed. It does allow every actual 1584 source row and grants earlier 3409 feedback immediately after clock 10388. The checker records the exact mutable roster and the conditions on each eliminated case.

## Proof and scope

The funded 0→19 receipt carries x549. The early rows are `785=h+x549`, `789=x549`, `1583=A`, `1585=P`, and `1586=A`, with `h=e679`, `A=X785`, `P=A+X813`, and the regraded 1583 incidence `19→182`. The contact after original clock 370 and the early 3409 are the only added or retimed placements in the named contract. Fixed donor equations evaluate on the changed rows. This distinction permits their expanded coefficients to change.

The owner-679 gate and the exact source reductions close the possibilities for 1584. In the final four boundary cases keep packet 3300 a single variable row z in its 18-dimensional live source envelope U. Grant every other mutable sender its causal source envelope. The resulting terminal spaces without z have dimensions 566 and 572. Their targets each increase the corresponding rank by one, so both targets require z. The dual probes vanish on the two separate terminal spaces, and their sum vanishes on U. The targets have opposite probe evaluations, which makes the shared z impossible. Equivalently, the diagonal map into the two quotients has rank 13 and adjoining the target pair raises it to 14. Early equations outside the fixed roster, a different payload on the new contact, and other clocks lie outside this conclusion.

The distinct partial construction restores all 537 chart-1 target rows and owner 221, owner 411, and owner 679 in both literal orientations. The full word nevertheless has **64 forward and 127 adjoint errors**. The 36-call formal BIT margin is approximately **+0.15481217569851** at κ = 0.00388. The separate incumbent 48-call rational margin is approximately **+0.13897452233425**. The full map, physical erasure and outer admission remain unsatisfied. The package establishes no new κ lower bound.

## Source and replay

The inner archive SHA-256 is `6330ffe5b35b44d9766df295056f6783cb45a9d7a694f783a66b4b57f6c43c82`. Its native word and #8006 side-restored control are byte-pinned in `source/SOURCES.json`. The governing sources include #7786 `89a67c404226d51028e135de2b9169e9020d57af`, #7830 `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, and #8006 `4035f150285513852cab8d00b8bfc233c699ea0a`. [Native source](https://github.com/CrocSwap/integer-mult-bounds/tree/89a67c404226d51028e135de2b9169e9020d57af/research/p104-iterated-returns) · [Starting diagnostic](https://github.com/CrocSwap/integer-mult-bounds/pull/8006)

Run these commands in a clean extraction with Python 3.12 and its standard library. The saved output records the observed cold replay. The inner runner checks the input and certificate manifest, regenerates the case gates, recompiles the diagnostic, executes both literal orientations, and recomputes the directed tariffs.

```sh
sha256sum -c SHA256SUMS
python3 -m zipfile -e PRO-AUDIT.zip inner
cd inner/p104-round10-audit
PYTHONDONTWRITEBYTECODE=1 python3 -I -B verify_all.py
```

The separate `lowprobe-371.py` rebuilds the primitive and checks the common-scalar dual with low pivots. Copy it into `inner` beside the `p104-round10-audit` directory, run it with `python3 -I -B inner/lowprobe-371.py`, and compare its JSON output with `LOWPIVOT-371.json`. It places the new contact immediately after 784 at clock 370. The other envelope checker grants the receipt at clock 350. Between those placements chart 19 has four arrivals and no departures; sender 785 at 374 sees identical stock. The independent receipts also retain the separate chart-1 and invoice audit.

#8012 studies a forwarded x549 word with different early equations. #8018 and #8019 treat separate coefficient and feedback-stock contracts. #8020 instead moves a productive input and reaches a complete native map while failing paired port admission. The next test for the fixed-endpoint route is a causal route for an independent old direction that changes at least one of the two quotient demands without spending a second 3300 pulse.
