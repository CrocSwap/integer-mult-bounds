#!/usr/bin/env python3
import collections,gzip,json,hashlib
from pathlib import Path
P=Path(__file__).parent/'p104-round10-audit';raw=(P/'source/WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));starts=w['start'];ends=w['final'];N=680

def xsum(it):
 v=0
 for x in it:v^=x
 return v
def low_basis(rows):
 b={}
 for x in rows:
  while x:
   i=(x&-x).bit_length()-1
   if i not in b:b[i]=x;break
   x^=b[i]
 return b
def reduce(x,b):
 for i in sorted(b):
  if x>>i&1:x^=b[i]
 return x
def dot(x,y):return (x&y).bit_count()&1
cells={i:1<<i for i in range(N)};charts=dict(enumerate(starts));donors={};pack={}
for clock,event in enumerate(w['program']):
 op,i,*a=event
 if op=='INIT':cells[i]=0;charts[i]=a[0];donors[i]=[]
 elif op=='ADD':
  j,c=a;assert charts[i]==charts[j]==c;cells[i]^=cells[j];donors[i].append(j)
 elif op=='MOVE':
  s,d=a;assert charts[i]==s;pack[i]=dict(clock=clock,src=s,dst=d,ds=donors[i][:]);charts[i]=d
 elif op=='SWAP':
  j=a[0];cells[i],cells[j]=cells[j],cells[i];charts[i],charts[j]=charts[j],charts[i]
 elif op=='CLEAR':del cells[i];del charts[i]
 else:raise AssertionError(op)
target={i:(1<<i)^((1<<(i-111)) if 111<=i<222 else 0) for i in range(N)}
assert cells==target and len(pack)==2874
assert all(charts[i]==ends[i] for i in range(N))
native={i:1<<i for i in range(N)}
for p,r in pack.items():native[p]=xsum(native[j] for j in r['ds'])
G5=[1445,1485,1577,1661,1901];F5=[722,1360,1464,1728,1824];H2=[2669,2674];A=native[785];B=native[813];h=1<<679;w549=1<<549
ind=[264,549,679,785,813]+F5+G5+H2
assert len(low_basis(native[i] for i in ind))==17

def choices(rows):
 q=[0]
 for x in rows:q += [v^x for v in q]
 return q
branch=[]
for mask in range(4):
 q=h^w549^(A if mask&1 else 0)^(B if mask&2 else 0)
 rr=choices([native[i] for i in F5]+[q]);ss=choices([native[i] for i in G5]+[A^B]);uu=choices([native[i] for i in H2]);survivors=[]
 for ir,r in enumerate(rr):
  for js,s in enumerate(ss):
   for ku,u in enumerate(uu):
    if reduce(h,low_basis([1<<264,w549,r,s,u]))==0:survivors.append([ir,js,ku])
 expected=([[32,s,u] for s in range(64) for u in range(4)] if mask==0 else [[32,32,u] for u in range(4)] if mask==3 else [])
 assert survivors==expected
 branch.append(len(survivors))
assert branch==[256,0,0,4]
# Independently derive the fixed-clock closure from primitive MOVE donors.
free={i for i,r in pack.items() if r['src'] in {268,318,421,518,509} and i!=3553}
free|={i for i,r in pack.items() if r['src']==0 and r['clock']>10378}
free|={i for i,r in pack.items() if set(r['ds']) & set(range(1931,1937))}
free|={i for i,r in pack.items() if r['dst']==0 and i!=3410}
while True:
 more={i for i,r in pack.items() if i not in {3410,3553} and any(j in free for j in r['ds'])}
 if more<=free:break
 free|=more
assert len(free)==344
reported=json.loads((P/'synthesis/independent_3300_common_scalar_certificate.json').read_text())
assert sorted(free)==reported['mutable_labels']
H184=sum(1<<i for i in [86,95,101,102,105]);H189=sum(1<<i for i in [78,85,86,94,95,96,101,102,105,106,107,108,110])
G184=sum(1<<i for i in [29,58,73,95,100,102,105,107,110]);G189=sum(1<<i for i in [78,102,106,108,109])
NEW=4234;results=[]
for c in (0,1):
 for a in (0,1):
  vals={i:(1<<i,(),False) for i in range(N)};stock=collections.defaultdict(list)
  for i,ch in enumerate(starts):stock[ch].append(i)
  prefix={NEW:[549],785:[679,NEW],789:[NEW],1583:[17,781],1584:[785],1585:[1583,813],1586:[1583],1934:[1584],2234:[1445,1577,1661,1901]+([1585] if c else []),2947:[2669,2674],3409:[2234,2947]+([789] if a else [])}
  events=sorted([(r['clock'],i) for i,r in pack.items() if i not in (3409,3410)]+[(371,NEW),(10389,3409)])
  for t,i in events:
   src,dst=(0,19) if i==NEW else (19 if i==1583 else pack[i]['src'],0 if i==3409 else pack[i]['dst'])
   if i==3300:
    srcids=stock[src][:];assert srcids==[11,673,747,748,749,750,3299] and t==11488
    assert not any(vals[j][2] for j in srcids)
    source_rows=[r for j in srcids for r in (vals[j][0],*vals[j][1])];U=low_basis(source_rows);v=(0,(),True)
   elif i in free and i not in prefix:
    # Every sender gets the whole current affine stock independently.
    rs=[r for j in stock[src] for r in (vals[j][0],*vals[j][1])]
    v=(0,tuple(low_basis(rs).values()),any(vals[j][2] for j in stock[src]))
   else:
    ds=prefix[i] if i in prefix else [3409 if j==3410 else j for j in pack[i]['ds']]
    assert set(ds)<=set(stock[src]),('bad causality',i)
    v=(xsum(vals[j][0] for j in ds),tuple(low_basis(r for j in ds for r in vals[j][1]).values()),any(vals[j][2] for j in ds))
   vals[i]=v;stock[dst].append(i)
  data={}
  for owner,H,G in ((184,H184,G184),(189,H189,G189)):
   ids=stock[ends[owner]];rs=[r for j in ids for r in (vals[j][0],*vals[j][1])];K=low_basis(rs)
   assert all(dot(r,H)==dot(r,G)==0 for r in rs)
   assert any(vals[j][2] for j in ids) and dot(target[owner],G)==1
   assert dot(target[owner],H)==(owner==189)
   data[owner]=(K,ids)
  assert len(U)==18 and all(dot(r,H184^H189)==0 for r in source_rows)
  joint=low_basis(list(data[184][0].values())+[r<<680 for r in data[189][0].values()]+[r^(r<<680) for r in U.values()])
  tar=target[184]^(target[189]<<680)
  assert [len(data[184][0]),len(data[189][0])]==[566,572] and len(joint)==1151 and reduce(tar,joint)!=0
  results.append(dict(c=c,a=a,known=[566,572],source=18,joint=1151,augmented=1152,stocks=[data[184][1],data[189][1]]))
print(json.dumps(dict(native_hash=hashlib.sha256(raw).hexdigest(),native_rows=680,mutable=344,branch_counts=branch,source_ids=srcids,cases=results),sort_keys=True,indent=2))
