#!/usr/bin/env python3
"""Self-contained replay: source authentication, graph, tariffs, ranks and prices."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json,subprocess,tempfile
from common import enclose,margin
from derive import derive,TARGET
from search import lagrangian,relative,symplectic

HERE=Path(__file__).resolve().parent

def check_witness(C,axes,expect_paid,expected_gain):
 def tr(lag,v):return tuple(x^(v if symplectic(x,v) else 0) for x in lag)
 changes={a:tr(lagrangian(C.chart[a]),v) for a,v in axes.items()}
 assert all(relative(changes[a],lagrangian(C.chart[a]))==1 for a in changes)
 edges={tuple(sorted((a,b))) for a in changes for b in C.inc[a]}
 assert len(edges)==17 and sum(len(C.inc[a][b][0]) for a,b in edges)==20
 assert sum(len(C.inc[a][b][1]) for a,b in edges)==0
 paid=Counter();target=Counter()
 for a,b in edges:
  old=relative(lagrangian(C.chart[a]),lagrangian(C.chart[b]))
  new=relative(changes.get(a,lagrangian(C.chart[a])),changes.get(b,lagrangian(C.chart[b])))
  for count,items in ((paid,C.inc[a][b][0]),(target,C.inc[a][b][1])):
   count[old]-=48*len(items);count[new]+=48*len(items)
 assert {k:v for k,v in paid.items() if v}==expect_paid
 assert not any(target.values())
 assert enclose(margin(paid,target,TARGET))==expected_gain

def check_cancellation(C):
 lag=lagrangian(C.chart[8754]);axis=76
 changed=tuple(x^(axis if symplectic(x,axis) else 0) for x in lag)
 paid=Counter();target=Counter();changes={}
 for b,(ps,hs) in C.inc[8754].items():
  old=relative(lag,lagrangian(C.chart[b]));new=relative(changed,lagrangian(C.chart[b]))
  if old!=new:
   for cnt,group in ((paid,ps),(target,hs)):
    cnt[old]-=48*len(group);cnt[new]+=48*len(group)
   for item in ps:changes[item[0]]=(old,new)
 assert changes=={100087:(2,1),100088:(3,2),100090:(3,2),100092:(1,2),100730:(2,3),100981:(2,3)}
 assert not any(paid.values()) and not any(target.values())
 assert enclose(margin(Counter({2:96}),Counter({3:96}),TARGET))==['95.289754102975474735182684888369244582808828730','95.289754102975474735182684888369244582808828731']

def main():
 C,geo,tariff,baseline=derive()
 result=json.loads((HERE/'RESULT.json').read_bytes())
 assert result['source']['rational_word_sha256']=='7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
 assert result['positive_rank']['choices']==1058086804 and result['positive_rank']['gain_upper_48_calls']=='-381.253429239456'
 assert result['relaxed_rank_zero']['choices']==1067462648 and result['relaxed_rank_zero']['gain_upper_48_calls']=='-189.769756506528'
 check_cancellation(C)
 assert enclose(baseline)==['-4.880391089954707282632121322599412665463258252','-4.880391089954707282632121322599412665463258251']
 check_witness(C,{4922:385,8754:76,5626:385},{1:-192,2:96,3:96,5:-96,6:96},['-381.253429556239165412788725212396474196628287758','-381.253429556239165412788725212396474196628287757'])
 check_witness(C,{4922:7198,8754:76,5626:7198},{0:96,1:-192,3:96,5:-96,6:96},['-189.769756823251420716911608525553857374559982373','-189.769756823251420716911608525553857374559982372'])
 with tempfile.TemporaryDirectory(prefix='p104-triple-') as t:
  root=Path(t);(root/'geometry').write_bytes(geo);(root/'tariff').write_bytes(tariff)
  fast=root/'triple';ind=root/'independent'
  subprocess.run(['c++','-std=c++20','-O3','-I',str(HERE),str(HERE/'triple.cpp'),'-o',str(fast)],check=True)
  subprocess.run(['c++','-std=c++20','-O3',str(HERE/'independent.cpp'),'-o',str(ind)],check=True)
  def run(exe,*flags):return subprocess.run([str(exe),str(root/'geometry'),str(root/'tariff'),*flags],check=True,text=True,stdout=subprocess.PIPE).stdout
  strict=run(fast);assert strict==run(fast,'--direct')
  relaxed=run(fast,'--relax-zero');assert relaxed==run(fast,'--relax-zero','--direct')
  assert strict.splitlines()==['CENSUS 1021 2078756 1058086804 1067462648 6596 101674814374','BEST -7942779782418 385 76 385 3 3','NEAR_TOTAL 0 0']
  assert relaxed.splitlines()==['CENSUS 1022 2088968 1067462648 1067462648 6596 101674814374','BEST -3953536600482 7198 76 7198 3 3','NEAR_TOTAL 0 0']
  assert run(ind).splitlines()==['INDEPENDENT 1018 1021 1018 2078756 1058086804 -7942779782418 198']
  assert run(ind,'--relax-zero').splitlines()==['INDEPENDENT 1022 1022 1022 2088968 1067462648 -3953536600482 199']
  strict_upper=F((-7942779782418+6596)*48,10**12);relaxed_upper=F((-3953536600482+6596)*48,10**12)
  assert strict_upper==F('-381.253429239456') and relaxed_upper==F('-189.769756506528')
 print('PASS: authenticated inputs, source-derived graph, all path ranks, strict and relaxed prices')
 print('strict choices=1058086804; gain <= -381.253429239456 (48 calls)')
 print('relaxed choices=1067462648; gain <= -189.769756506528 (48 calls)')

if __name__=='__main__':main()
