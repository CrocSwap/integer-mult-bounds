// Independent graph-path screen: enumerate every 18-bit transvection, dedup
// resulting 9-dimensional subspaces by binary RREF, and use direct pair ranks.
#include <array>
#include <algorithm>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <vector>
using Basis=std::array<unsigned,9>;
using Score=long long;
constexpr unsigned MASK=(1u<<9)-1;
int omega(unsigned x,unsigned y){return std::popcount(((x&MASK)&(y>>9))^((y&MASK)&(x>>9)))&1;}
Basis rref(Basis x){
 int pos=0;for(int c=17;c>=0;c--){int k=pos;while(k<9&&!((x[k]>>c)&1))k++;if(k==9)continue;std::swap(x[k],x[pos]);for(int i=0;i<9;i++)if(i!=pos&&((x[i]>>c)&1))x[i]^=x[pos];pos++;}
 if(pos!=9)throw std::runtime_error("rank not 9");return x;
}
int grade(Basis const& a,Basis const& b){
 std::array<unsigned,9> piv{};int r=0;
 for(auto x:a){unsigned row=0;for(int i=0;i<9;i++)row|=omega(x,b[i])<<i;
  while(row){int k=std::bit_width(row)-1;if(piv[k])row^=piv[k];else{piv[k]=row;r++;break;}}}
 return r;
}
std::vector<Basis> all_neighbors(Basis const& old){
 std::map<Basis,unsigned> unique;
 auto identity=rref(old);
 for(unsigned axis=1;axis<(1u<<18);axis++){
  Basis x=old;for(auto& v:x)if(omega(v,axis))v^=axis;
  auto y=rref(x);if(y==identity)continue;
  unique.try_emplace(y,axis);
 }
 if(unique.size()!=1022)throw std::runtime_error("neighbor count");
 std::vector<Basis> all;for(auto const& [x,v]:unique){(void)v; if(grade(x,old)!=1)throw std::runtime_error("non-neighbor");all.push_back(x);}return all;
}
struct Contact{int a,b,p,h,r;int other(int x)const{return a^b^x;}};
struct Node{int label,frame,fixed;std::vector<int> edges;};
struct Partial{Basis b;Score exterior;};
int main(int argc,char**argv){
 if(argc!=3 && !(argc==4 && std::string(argv[3])=="--relax-zero"))return 2;bool relax=argc==4;std::ifstream graph(argv[1]),fees(argv[2]);int nf,nv,ne;graph>>nf>>nv>>ne;
 std::vector<Basis> frames(nf);for(auto& f:frames)for(auto& v:f)graph>>v;
 std::vector<Node> nodes(nv);std::array<int,3> idx{-1,-1,-1};for(int i=0;i<nv;i++){
 graph>>nodes[i].label>>nodes[i].frame>>nodes[i].fixed;for(int j=0;j<3;j++)if(nodes[i].label==std::array{4922,8754,5626}[j])idx[j]=i;}
 std::vector<Contact> edges(ne);for(int i=0;i<ne;i++){auto& e=edges[i];graph>>e.a>>e.b>>e.p>>e.h>>e.r;nodes[e.a].edges.push_back(i);nodes[e.b].edges.push_back(i);if(grade(frames[nodes[e.a].frame],frames[nodes[e.b].frame])!=e.r)throw std::runtime_error("edge");}
 std::array<Score,10> H;for(auto& x:H)fees>>x;Score threshold;fees>>threshold;if(!graph||!fees) return 3;
 std::array<int,2> shared{-1,-1};for(int e=0;e<ne;e++)for(int s=0;s<2;s++){int l=idx[s?2:0],m=idx[1];if((edges[e].a==l&&edges[e].b==m)||(edges[e].a==m&&edges[e].b==l))shared[s]=e;}
 if(idx[0]<0||idx[1]<0||idx[2]<0||shared[0]<0||shared[1]<0)return 4;
 for(int k:idx)if(nodes[k].fixed)return 5;
 for(int e:shared)if(edges[e].p!=1||edges[e].h!=0||edges[e].r!=3)return 6;
 std::array<std::vector<Partial>,3> part;
 for(int i=0;i<3;i++){
  int node=idx[i];for(auto const& b:all_neighbors(frames[nodes[node].frame])){
   Score score=0;bool ok=true;
   for(int ei:nodes[node].edges){if((i==0&&ei==shared[0])||(i==2&&ei==shared[1])||(i==1&&(ei==shared[0]||ei==shared[1])))continue;
    auto const& e=edges[ei];int r=grade(b,frames[nodes[e.other(node)].frame]);if(!relax&&r==0&&(e.p||e.h))ok=false;
    score+=Score(e.h-e.p)*(H[r]-H[e.r]);}
   if(ok)part[i].push_back({b,score});
  }
 }
 uint64_t valid=0,calc=0;Score best=INT64_MIN;uint64_t bestcenter=0;
 for(uint64_t c=0;c<part[1].size();c++){
  std::array<Score,2> mx{INT64_MIN,INT64_MIN};std::array<uint64_t,2> n{0,0};
  for(int s=0;s<2;s++){
   auto const& e=edges[shared[s]];for(auto const& leaf:part[s?2:0]){calc++;int rank=grade(leaf.b,part[1][c].b);if(!relax&&!rank)continue;
    n[s]++;auto val=leaf.exterior+Score(e.h-e.p)*(H[rank]-H[e.r]);mx[s]=std::max(mx[s],val);}
  }
  valid+=n[0]*n[1];if(n[0]&&n[1]){auto val=part[1][c].exterior+mx[0]+mx[1];if(val>best){best=val;bestcenter=c;}}
 }
 std::cout<<"INDEPENDENT "<<part[0].size()<<' '<<part[1].size()<<' '<<part[2].size()<<' '<<calc<<' '<<valid<<' '<<best<<' '<<bestcenter<<'\n';
}
