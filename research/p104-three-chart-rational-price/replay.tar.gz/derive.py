"""Authenticate public inputs, rebuild occurrence graph and directed tariffs."""
from collections import Counter
from fractions import Fraction
from hashlib import sha1,sha256
from io import StringIO
import json
from pathlib import Path
from common import enclose,histogram,margin
from extended import Components
from search import GRAPH,LAYOUT,APP,WORD,LAYOUT_SHA,MAIN,FRAMES,lagrangian,relative

HERE=Path(__file__).resolve().parent
TARGET='0.003884928046155'

def derive():
 locks=json.loads((HERE/'SOURCE-LOCK.json').read_bytes());assert len(locks)==4
 for item in locks:
  raw=(HERE/item['file']).read_bytes();assert sha256(raw).hexdigest()==item['sha256']
  assert sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==item['git_blob']
 assert WORD=='7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
 assert LAYOUT_SHA=='f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7'
 assert APP['caller']=='156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858'
 assert len(GRAPH['initial'])==len(GRAPH['final'])==1289 and len(MAIN)==400
 C=Components();nodes=sorted(C.group);index={x:i for i,x in enumerate(nodes)}
 edges=[]
 for a in nodes:
  for b,(paid,helper) in C.inc[a].items():
   if a<b:edges.append((index[a],index[b],len(paid),len(helper),relative(lagrangian(C.chart[a]),lagrangian(C.chart[b]))))
 assert len(FRAMES)==1103 and len(nodes)==1362 and len(C.fixed)==333 and len(edges)==4179
 assert len(C.paid)==sum(e[2] for e in edges)==5707 and len(C.helper)==sum(e[3] for e in edges)==889
 assert all(n not in C.fixed for n in (4922,8754,5626)) and 5626 not in C.inc[4922]
 assert C.inc[4922][8754][0][0][0]==100088 and C.inc[5626][8754][0][0][0]==100090
 out=StringIO();print(len(FRAMES),len(nodes),len(edges),file=out)
 for f in range(len(FRAMES)):print(*lagrangian(f),file=out)
 for a in nodes:print(a,C.chart[a],int(a in C.fixed),file=out)
 for e in edges:print(*e,file=out)
 geo=out.getvalue().encode();assert sha256(geo).hexdigest()=='54f0f83bc687da2ca782c8dc43570bea44ab8ffa3934adf7ba0503bc03ef9103'
 scale=10**12;weights=[0]
 for r in range(1,10):
  lo,hi=margin(Counter(),Counter({r:1}),TARGET);v=int(lo*scale)
  assert v<=lo*scale<=hi*scale<v+1;weights.append(v)
 paid=histogram(APP['application']['invoice']['paid']);targets=histogram(APP['application']['invoice']['targets'])
 lo,hi=margin(paid,targets,TARGET);assert lo<=hi<0
 threshold=(-hi*scale/48);cut=threshold.numerator//threshold.denominator
 tariff=(' '.join(map(str,weights+[cut]))+'\n').encode()
 assert sha256(tariff).hexdigest()=='362b430484b783750d1192b5fb700f020a3b24cb8f1e818e8c5586822ed26d08'
 return C,geo,tariff,(lo,hi)
