#include "neighbors.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

using Basis = std::vector<unsigned>;
using PackedBill = __int128_t;
using Score = int64_t;
constexpr int n = 9;
constexpr unsigned mask = (1u << n) - 1;
constexpr int bill_digit_bits = 14;
constexpr int digits_modulus = 1 << bill_digit_bits;

unsigned symplectic(unsigned a, unsigned b) {
    return std::popcount(((a & mask) & (b >> n)) ^ ((b & mask) & (a >> n))) & 1;
}

unsigned pairing(Basis const& lag, unsigned axis) {
    unsigned result = 0;
    for (int j = 0; j < n; ++j) result |= symplectic(lag[j], axis) << j;
    return result;
}

Basis transvect(Basis lag, unsigned axis) {
    for (auto& v : lag) if (symplectic(v, axis)) v ^= axis;
    return lag;
}

template <size_t width, class Rows>
int rank_binary(Rows const& rows) {
    std::array<unsigned, width> pivots{};
    int rank = 0;
    for (auto v : rows) {
        while (v) {
            const int j = std::bit_width(v) - 1;
            if (pivots[j]) v ^= pivots[j];
            else {
                pivots[j] = v;
                ++rank;
                break;
            }
        }
    }
    return rank;
}

int relative(Basis const& a, Basis const& b) {
    std::array<unsigned, n> rows;
    for (int j = 0; j < n; ++j) rows[j] = pairing(b, a[j]);
    return rank_binary<n>(rows);
}

int direct_relative(Basis const& a, unsigned v, Basis const& b, unsigned w) {
    std::array<unsigned, 2*n> combined;
    for (int j = 0; j < n; ++j) {
        combined[j] = a[j] ^ (symplectic(a[j], v) ? v : 0);
        combined[n+j] = b[j] ^ (symplectic(b[j], w) ? w : 0);
    }
    return rank_binary<2*n>(combined) - n;
}

struct Contact {
    int a, b, paid, helper, rank;
    int coefficient() const { return helper - paid; }
    int other(int endpoint) const { return a ^ b ^ endpoint; }
};

// One moving Lagrangian and one fixed Lagrangian. Eliminate into their sum,
// remembering the representative from the moving side.
struct SingleRank {
    std::array<unsigned, 2*n> pivots{}, left{};
    int rank;

    SingleRank(Basis const& moving, Basis const& fixed, int old_rank) : rank(old_rank) {
        for (auto const* side : {&moving, &fixed}) {
            for (auto v : *side) {
                unsigned a = side == &moving ? v : 0;
                while (v) {
                    const int j = std::bit_width(v) - 1;
                    if (pivots[j]) {
                        v ^= pivots[j];
                        a ^= left[j];
                    } else {
                        pivots[j] = v;
                        left[j] = a;
                        break;
                    }
                }
            }
        }
    }

    int after(unsigned axis) const {
        unsigned v = axis, a = 0;
        while (v) {
            const int j = std::bit_width(v) - 1;
            if (!pivots[j]) return rank + 1;
            v ^= pivots[j];
            a ^= left[j];
        }
        return rank - symplectic(a, axis);
    }
};

// For the simultaneously updated pair, put the base pairing into diag(I_r,0)
// and take the Schur complement of I_r in the rank-two update.
struct CoupledRank {
    Basis a, b;
    int rank = 0;

    CoupledRank(Basis left, Basis right) : a(std::move(left)), b(std::move(right)) {
        for (; rank < n; ++rank) {
            int i = rank, j = n;
            for (; i < n; ++i) {
                for (j = rank; j < n; ++j) if (symplectic(a[i], b[j])) break;
                if (j < n) break;
            }
            if (i == n) break;
            std::swap(a[rank], a[i]);
            std::swap(b[rank], b[j]);
            for (i = rank + 1; i < n; ++i) if (symplectic(a[i], b[rank])) a[i] ^= a[rank];
            for (j = rank + 1; j < n; ++j) if (symplectic(a[rank], b[j])) b[j] ^= b[rank];
        }
    }

    struct Axis {
        unsigned v, a, b;
    };

    Axis axis(unsigned v) const { return {v, pairing(a, v), pairing(b, v)}; }

    int after(Axis v, Axis w) const {
        const unsigned active = (1u << rank) - 1;
        const unsigned alpha = v.a;
        const unsigned q = w.a;
        const unsigned beta = w.b;
        const unsigned u = v.b ^ (symplectic(v.v, w.v) ? beta : 0);

        const unsigned h0 = (u & ~active) | ((1 ^ (std::popcount(u & alpha & active) & 1)) << n)
                             | ((std::popcount(u & q & active) & 1) << (n + 1));
        const unsigned h1 = (beta & ~active) | ((std::popcount(beta & alpha & active) & 1) << n)
                             | ((1 ^ (std::popcount(beta & q & active) & 1)) << (n + 1));
        const unsigned pattern_01 = (alpha & ~q & ~active) ? 1u << n : 0;
        const unsigned pattern_10 = (q & ~alpha & ~active) ? 1u << (n + 1) : 0;
        const unsigned pattern_11 = (alpha & q & ~active) ? 3u << n : 0;
        return rank - 2 + rank_binary<n+2>(std::array{pattern_01, pattern_10, pattern_11, h0, h1});
    }
};

struct Candidate {
    unsigned axis;
    Score full_score = 0;
    PackedBill full_bill = 0;
    int paid_zero = 0;
    int helper_zero = 0;
    std::vector<uint8_t> ranks;
};

struct Node {
    int label, frame, fixed;
    std::vector<int> contacts;
    std::vector<Candidate> edits;
};

std::array<Score, n+1> tariff;
std::array<PackedBill, n+1> unit;

Score price(Contact const& contact, int rank) {
    return contact.coefficient() * (tariff[rank] - tariff[contact.rank]);
}

PackedBill bill(Contact const& contact, int rank) {
    return contact.coefficient() * (unit[rank] - unit[contact.rank]);
}

struct Side {
    CoupledRank::Axis axis;
    Score exterior_score;
    PackedBill exterior_bill;
    int one_side_rank;
    bool exterior_paid_zero, exterior_helper_zero;
};

std::vector<Side> sides(Node const& node, size_t shared_index, Contact const& shared, CoupledRank const& coupled) {
    std::vector<Side> out;
    out.reserve(node.edits.size());
    for (auto const& edit : node.edits) {
        const int rank = edit.ranks[shared_index];
        const bool shared_zero = rank == 0;
        out.push_back({
            coupled.axis(edit.axis),
            edit.full_score - price(shared, rank),
            edit.full_bill - bill(shared, rank),
            edit.ranks[shared_index],
            edit.paid_zero > (shared_zero && shared.paid > 0),
            edit.helper_zero > (shared_zero && shared.helper > 0),
        });
    }
    return out;
}

struct Witness {
    int edge = -1;
    unsigned a = 0, b = 0;
    Score score = std::numeric_limits<Score>::min();
    int rank = -1;
};

struct Census {
    uint64_t visits = 0, grid_positive = 0, ambiguous = 0, zero = 0;
    Witness best;
};

void print_bill(PackedBill packed) {
    for (int grade = 1; grade <= n; ++grade) {
        int digit = int(packed & (digits_modulus - 1));
        if (digit >= digits_modulus / 2) digit -= digits_modulus;
        packed = (packed - digit) / digits_modulus;
        std::cout << ' ' << digit;
    }
    if (packed) throw std::runtime_error("bill exceeds grid");
}

struct Uncertain {
    std::array<uint64_t, 3> counts{};
    Witness first;
};

// Three-component path. Given a center edit, the leaves do not touch each
// other, so their exterior plus joint-edge costs can be optimized separately.
// This adds only changed native paid/helper tariffs. Unchanged caller cancels.
struct Option { Score score; PackedBill bill; unsigned axis; int rank; };
struct Key { Score score; PackedBill bill; bool operator<(Key const& o) const { return score<o.score || (score==o.score && bill<o.bill); } };
struct Aggregate { uint64_t count=0; unsigned l=0,c=0,r=0; Score score=0; int rankl=-1,rankr=-1; };
struct Group { uint64_t count=0; Option witness{}; };
int main(int argc,char** argv) {
    if(argc!=3 && argc!=4 && argc!=5) return 2;
    bool direct=false, relax=false;
    for(int i=3;i<argc;i++){std::string a=argv[i];if(a=="--direct")direct=true;else if(a=="--relax-zero")relax=true;else return 2;}
    std::ifstream graph(argv[1]),weights(argv[2]);
    int nf,nv,ne;graph>>nf>>nv>>ne;
    std::vector<Basis> frames(nf,Basis(n));
    for(auto& frame:frames)for(auto& v:frame)graph>>v;
    std::vector<Node> nodes(nv); std::array<int,3> idx{-1,-1,-1};
    for(int i=0;i<nv;i++){graph>>nodes[i].label>>nodes[i].frame>>nodes[i].fixed;for(int j=0;j<3;j++)if(nodes[i].label==std::array{4922,8754,5626}[j])idx[j]=i;}
    std::vector<Contact> contacts(ne); Score error=0;
    for(int i=0;i<ne;i++){
        auto& c=contacts[i];graph>>c.a>>c.b>>c.paid>>c.helper>>c.rank;
        nodes[c.a].contacts.push_back(i);nodes[c.b].contacts.push_back(i);
        if(c.rank!=relative(frames[nodes[c.a].frame],frames[nodes[c.b].frame]))throw std::runtime_error("original grade mismatch");
        error+=c.paid+c.helper;
    }
    for(auto& t:tariff)weights>>t;
    Score required;weights>>required;
    for(int r=1;r<=n;r++)unit[r]=PackedBill{1}<<((r-1)*bill_digit_bits);
    if(!graph||!weights||error!=6596||!std::is_sorted(tariff.begin(),tariff.end()))return 3;
    for(int x:idx)if(x<0||nodes[x].fixed)return 4;
    std::array<int,2> edge{-1,-1};
    for(int i=0;i<ne;i++){
      auto const& c=contacts[i];
      for(int side=0;side<2;side++){
        int leaf=idx[side?2:0];
        if((c.a==leaf&&c.b==idx[1])||(c.b==leaf&&c.a==idx[1]))edge[side]=i;
      }
      if((c.a==idx[0]&&c.b==idx[2])||(c.b==idx[0]&&c.a==idx[2]))throw std::runtime_error("leaves touch");
    }
    for(int e:edge){if(e<0||contacts[e].rank!=3||contacts[e].paid!=1||contacts[e].helper!=0)throw std::runtime_error("wrong shared incidence");}
    for(int x:idx){
      auto& node=nodes[x];auto const& lag=frames[node.frame];auto axes=canonical_transvection_axes(lag);
      if(axes.size()!=1022)throw std::runtime_error("axis count");
      for(size_t k=0;k<axes.size();k++){
        unsigned functional=unsigned(k/2+1),axis=axes[k];
        if(pairing(lag,axis)!=functional || (k%2&&(axes[k-1]^axis)!=lag[std::countr_zero(functional)]))throw std::runtime_error("axes");
        Candidate item{};item.axis=axis;node.edits.push_back(item);
      }
      for(int e:node.contacts){
        auto const& c=contacts[e];auto const& other=frames[nodes[c.other(x)].frame];SingleRank single(lag,other,c.rank);
        for(auto& item:node.edits){
          int rank=direct?direct_relative(lag,item.axis,other,0):single.after(item.axis);
          if(rank<0||rank>n)throw std::runtime_error("single rank");
          item.ranks.push_back(rank);item.full_score+=price(c,rank);item.full_bill+=bill(c,rank);
          item.paid_zero+=(rank==0&&c.paid>0);item.helper_zero+=(rank==0&&c.helper>0);
        }
      }
    }
    auto pos=[&](int node,int e){auto& list=nodes[node].contacts;auto it=std::find(list.begin(),list.end(),e);if(it==list.end())throw std::runtime_error("missing contact");return int(it-list.begin());};
    std::array<int,2> lp{pos(idx[0],edge[0]),pos(idx[2],edge[1])};
    std::array<int,2> cp{pos(idx[1],edge[0]),pos(idx[1],edge[1])};
    auto const& center=nodes[idx[1]];
    std::array<CoupledRank,2> joints{CoupledRank(frames[nodes[idx[0]].frame],frames[center.frame]),CoupledRank(frames[nodes[idx[2]].frame],frames[center.frame])};
    for(int s=0;s<2;s++)if(joints[s].rank!=contacts[edge[s]].rank)throw std::runtime_error("coupled baseline");
    uint64_t inspected=0,strict=0,centers=0;Score maxscore=std::numeric_limits<Score>::min();
    Aggregate best; std::map<PackedBill,Aggregate> near;
    for(auto const& ec:center.edits){
      auto const& e0=contacts[edge[0]];auto const& e1=contacts[edge[1]];
      int zpaid=(ec.ranks[cp[0]]==0&&e0.paid>0)+(ec.ranks[cp[1]]==0&&e1.paid>0);
      int zhelp=(ec.ranks[cp[0]]==0&&e0.helper>0)+(ec.ranks[cp[1]]==0&&e1.helper>0);
      if(!relax && (ec.paid_zero-zpaid || ec.helper_zero-zhelp))continue;
      centers++;
      Score center_score=ec.full_score-price(e0,ec.ranks[cp[0]])-price(e1,ec.ranks[cp[1]]);
      PackedBill center_bill=ec.full_bill-bill(e0,ec.ranks[cp[0]])-bill(e1,ec.ranks[cp[1]]);
      std::array<std::vector<Option>,2> sides_;std::array<Score,2> maxs{std::numeric_limits<Score>::min(),std::numeric_limits<Score>::min()};
      for(int s=0;s<2;s++){
        auto const& leaf=nodes[idx[s?2:0]];auto const& con=contacts[edge[s]];
        auto centeraxis=joints[s].axis(ec.axis);
        for(auto const& el:leaf.edits){
          int z=(el.ranks[lp[s]]==0);
          if(!relax && (el.paid_zero-(z&&con.paid>0)||el.helper_zero-(z&&con.helper>0)))continue;
          ++inspected;
          int rank=direct?direct_relative(frames[leaf.frame],el.axis,frames[center.frame],ec.axis):joints[s].after(joints[s].axis(el.axis),centeraxis);
          if(rank<0||rank>n)throw std::runtime_error("joint rank");
          int low=std::max({0,int(el.ranks[lp[s]])-1,int(ec.ranks[cp[s]])-1});
          int high=std::min({n,int(el.ranks[lp[s]])+1,int(ec.ranks[cp[s]])+1});
          if(rank<low||rank>high)throw std::runtime_error("triangle bound");
          if(!relax && rank==0&&(con.paid||con.helper))continue;
          Option op{el.full_score-price(con,el.ranks[lp[s]])+price(con,rank),el.full_bill-bill(con,el.ranks[lp[s]])+bill(con,rank),el.axis,rank};
          sides_[s].push_back(op);maxs[s]=std::max(maxs[s],op.score);
        }
      }
      strict+=uint64_t(sides_[0].size())*sides_[1].size();
      if(sides_[0].empty()||sides_[1].empty())continue;
      Score score=center_score+maxs[0]+maxs[1];
      if(score>maxscore){
        maxscore=score;auto a=*std::find_if(sides_[0].begin(),sides_[0].end(),[&](auto const&x){return x.score==maxs[0];});
        auto b=*std::find_if(sides_[1].begin(),sides_[1].end(),[&](auto const&x){return x.score==maxs[1];});
        best={1,a.axis,ec.axis,b.axis,score,a.rank,b.rank};
      }
      if(score < -error)continue;
      std::array<std::map<Key,Group>,2> groups;
      for(int s=0;s<2;s++)for(auto const& op:sides_[s]){
        if(center_score+op.score+maxs[1-s] < -error)continue;
        auto& g=groups[s][{op.score,op.bill}];if(!g.count)g.witness=op;g.count++;
      }
      for(auto const& [lk,lg]:groups[0]) for(auto const& [rk,rg]:groups[1]){
        Score sc=center_score+lk.score+rk.score;
        if(sc < -error)continue;
        PackedBill hist=center_bill+lk.bill+rk.bill;auto& a=near[hist];
        if(!a.count){a.l=lg.witness.axis;a.c=ec.axis;a.r=rg.witness.axis;a.score=sc;a.rankl=lg.witness.rank;a.rankr=rg.witness.rank;}
        else if(a.score!=sc)throw std::runtime_error("bill grid mismatch");
        a.count+=lg.count*rg.count;
      }
    }
    std::cout<<"CENSUS "<<centers<<' '<<inspected<<' '<<strict<<' '<<uint64_t(1022)*1022*1022<<' '<<error<<' '<<required<<'\n';
    std::cout<<"BEST "<<maxscore<<' '<<best.l<<' '<<best.c<<' '<<best.r<<' '<<best.rankl<<' '<<best.rankr<<'\n';
    uint64_t ncase=0;for(auto const& [hist,a]:near){ncase+=a.count;std::cout<<"NEAR "<<a.count<<' '<<a.score<<' '<<a.l<<' '<<a.c<<' '<<a.r<<' '<<a.rankl<<' '<<a.rankr;print_bill(hist);std::cout<<'\n';}
    std::cout<<"NEAR_TOTAL "<<near.size()<<' '<<ncase<<'\n';
}
