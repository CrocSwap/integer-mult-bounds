# A three-component rational price exclusion

At `κ = 0.003884928046155`, every one-step neighboring-chart choice on the fixed-incidence rational supplier path `4922—8754—5626` worsens the complete 48-call signed invoice. This is a bounded computational price result. It makes no new κ claim, supplies no new legal word, and does not prove a general supplier, decoder, or `Wall56` lower bound.

The path uses old paid slots 100088 and 100090, both grade 3. All scalar rows and paid/helper incidences remain fixed; only the three chosen occurrence components receive one-step Lagrangian-neighbor charts. The 400 main roles are anchored. The three components touch 17 contact pairs, consisting of 20 paid occurrences and no helper identities. All 889 productive helper identities remain present, and the complete affected paid and productive tariff change is charged. If a favorable price existed, a physical compilation, exact all-column operator replay, ordinary costs and complete finite qualification would still be needed. Here the price fails first.

| Price screen | Choices | Certified upper bound on gain over 48 calls |
| --- | ---: | ---: |
| All affected paid and helper ranks positive | 1,058,086,804 | −381.253429239456 |
| Optimistically allow rank zero at H(0)=0 | 1,067,462,648 | −189.769756506528 |

The second line is a larger relaxation: an alleged rank-zero paid or helper occurrence is priced as zero, and productive target losses are still debited. The existing complete rational signed margin at this target is approximately `−4.88039108995470728`; the relaxed bound leaves a shortfall of at least `194.65014759648270728`. The existing binary service also needs a separately funded improvement. These results do not cover different supports, multiple neighboring steps, altered scalar rows, changed producer incidence, nonlocal coupling or another service tariff.

For the strict best-grid witness, the exact directed gain is between `−381.253429556239165412788725212396474196628287758` and `−381.253429556239165412788725212396474196628287757`. Its complete paid histogram delta over 48 calls is `{1: −192, 2: +96, 3: +96, 5: −96, 6: +96}`; productive target delta is zero. The relaxed best-grid witness has exact directed gain between `−189.769756823251420716911608525553857374559982373` and `−189.769756823251420716911608525553857374559982372`, using grade-zero paid slots 94590 and 95539. The grid maximum need not be the exact real-valued maximum; the displayed global upper bounds account for all price rounding.

## Reproduce

Run from this directory with Python 3.11+ and a C++20 compiler named `c++`:

```sh
python3 -B verify.py
```

The verifier authenticates the public compressed word, layout and complete application using SHA-256 and Git blob hashes, derives every component and contact from the source word, rebuilds every original relative grade and the directed tariff grid, and verifies both exact-price witnesses. It compiles and runs both C++ implementations in a temporary directory. Fast coupled-rank and direct basis-union ranks agree byte for byte; the separately implemented exhaustive all-axis and binary-RREF enumeration reproduces the complete counts and maxima. No prebuilt binary, network access, private path, or prior workspace is required.

[RESULT.json](RESULT.json) records the machine-readable result and scope. The public source lock records exact predecessor paths and commits. The native word's canonical SHA-256 is `7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48`; its layout is `f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7`, and the original complete rational application is `1b2d87e93ae023f5ffd464546af53281b6cb4963dfd76ae4742e0a5540b752fa`. The application pins unchanged caller macro `156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858`. The source-derived graph has SHA-256 `54f0f83bc687da2ca782c8dc43570bea44ab8ffa3934adf7ba0503bc03ef9103`, 1,362 components, 333 anchored components, 4,179 contacts, 5,707 paid positions, and 889 helper identities. The predecessor archive head is `14c74c6a67108f675ac1196a5f2415ead0920e71`; the same rational word is retained by #7830 head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` with its 480-factor binary supplier.

## Bound method

Each original 9-dimensional Lagrangian has 511 nonzero functionals. Each common 8-dimensional hyperplane has two distinct extensions, giving 1,022 one-step neighbors. The first implementation enumerates canonical transvection axes; the second enumerates every 18-bit axis, forms the resulting subspaces and deduplicates them by binary reduced row echelon form. It confirms exactly 1,022 neighbors per selected component.

The two leaves share no contact. With a fixed center choice the total signed score is the center's exterior score plus each leaf's exterior score and its joint-edge score. Each leaf can therefore be optimized independently, exactly covering the Cartesian product of its 1,022 options. The two screens evaluate 2,078,756 and 2,088,968 coupled ranks respectively.

For `H(r) = r^(1−κ)` and `H(0) = 0`, a contact with `p` paid and `h` productive incidences contributes `(h−p)(H(new)−H(old))` to gain. Each weight is a certified floor of `10^12 H(r)` computed with directed dyadic arithmetic. The error in a changed incidence is less than one grid unit: the two flooring errors each lie in `[0,1)`. We charge a conservative 6,596 units per native call, the entire native paid-plus-helper census. Thus `(-3953536600482 + 6596) * 48 / 10^12 = -189.769756506528` bounds every relaxed choice; the strict bound follows analogously. No near-zero tariff ties remain.

## Credit and remaining assumptions

Credit the source #7786/#7781, Ali Romman's #7776 carrier, tariff and caller, #7774 restored chain, and the #7830 double-chain edits. The predecessor fixed-incidence pair analysis and one triple fixture were local work by Clear1nsight with OpenAI Codex assistance. The retained exact Clifford compiler is attributed in [SOURCE-LOCK.json](SOURCE-LOCK.json). This extension and the separate computational checks were performed with Codex assistance; they are not an independent human review. The existing conditional construction retains `native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery`.
