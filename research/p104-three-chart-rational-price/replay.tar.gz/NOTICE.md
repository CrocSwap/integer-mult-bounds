# Source and attribution

The selected #7830 rational word and complete 48-call application are by Clear1nsight with OpenAI Codex assistance. They build on #7786/#7781, Ali Romman's #7776 carrier, tariff and caller, and #7774's restored chain. The exact predecessors and their compressed-source SHA-256 and Git blob identifiers are recorded in SOURCE-LOCK.json. The source-data files are retained unmodified.

The retained `clifford_exact.py` is from Ali Romman's `integer-mult-bounds` at commit `4f7c67ae387cc91580f469aeda4d508b372b9ec1` and is also pinned in SOURCE-LOCK.json. Its upstream notice and the repository Apache-2.0 license continue to apply. The remaining geometry preparation is adapted from Clear1nsight's earlier local fixed-incidence one/two-component research with Codex assistance. The distinct all-axis RREF checker and the scoped three-component calculation are new work assisted by OpenAI Codex. No contributor is represented as having independently reviewed this extension.
