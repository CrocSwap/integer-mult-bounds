# Two and three paid-packet punctures with one replacement

This is a finite negative result for one fixed native binary word. It does not
establish a κ improvement, a new physical supplier, or a universal no-gain
theorem. The pinned word is #7830 at
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, gzip SHA-256
`d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`,
and canonical JSON SHA-256
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
Native source and predecessor attribution, original Apache license and notices
are under `producer/`; `producer/SOURCES.json` pins the source files.

## Exact scope

Choose exactly two or exactly three distinct original paid MOVE payloads and
set those payloads to zero while retaining the original primitive program and
all 680 public input/output roles. Protected bridge packet 3553 may not be
removed, but **may** be read as an unchanged donor. Permit at most one added
coded communicator between two nested original rational charts. The added
sender may use arbitrary free XORs of all prior original historical stock at
its chart; the receiver may use arbitrary free XORs of all later dual stock
at its chart. Arbitrary retention is granted for free. The added communication
must occur strictly after its last source leaf and before its first affected
receiver use. These grants over-approximate actual live-bank and local-work
permissions within this precisely named family.

The test does not cover changed other native operations, new charts, changed
productive roles, additional communicators, arbitrary changed call schedules,
cross-stage redesign, dirty-state cleanup, or a general legal word. A candidate
outside the stated family must be evaluated on its own full actual caller
invoice and physical interfaces.

## Findings

There are 2,874 paid packets, of which 2,873 may be removed. Every original
input row and every original dual row is nonzero.

* **Two holes.** All `C(2873,2) = 4,125,628` pairs are covered by the exact
  two-outer-product rank dichotomy. Of these, 1,389 have rank-one residual,
  4,124,239 have rank two, and none has rank zero. All 1,389 rank-one cases
  are screened against the free historical source and dual-bank spans. There
  are 19 temporally ordered, geometrically nested bank pairs. Their new grade
  exceeds the sum of the two old grades by 2 in nine cases, 3 in one, 5 in
  one and 6 in eight. Every directed signed local price is negative at both
  `K=0.003879928046156` and `near=0.003879929046155`.
* **Three holes.** For the residual `X'Y^T`, causal puncturing changes X by an
  invertible unit-triangular 3×3 factor, hence preserves its column rank.
  Sylvester's rank inequality gives `rank(X'Y^T) >= rank(X)+rank(Y)-3`.
  Therefore only triples with original rank sum at most four can have a
  rank-one residual. An independent span-product grouping finds all 2,436
  such triples: 288 have rank one, 2,148 rank two, and none rank zero. Every
  one of the 288 rank-one residuals is independently reconstructed by
  executing its punctured literal primitive tape against all 680 public
  output rows. A full historical-bank screen yields nine ordered nested
  routes. Each has new grade 8 and old grade sum 7, and each outward signed
  price is negative at K and near.

`independent/PRICE-36.json` gives outward intervals for all 28 listed local
prices multiplied by the original 36 binary caller invocations. This is an
optimistic hypothetical price for the same edit at every original LOCAL,
with all productive bins fixed and all additional costs free. It is not a
changed caller or physical word; altered calls need their true complete
36/48-or-other-call invoice.

The packet contains both the architect's grouped producer and an independently
written primitive-tape/call-bank implementation. The latter reconstructs
forward and transposed arbitrary-input rows, checks the entire original pulse
influence transpose, explicitly tests exact rational subspace identity for all
636 charts, exhausts the two-hole pairs, independently groups the triple
families, directly replays all 288 surviving triple words and prices every
reported route. Its stored source and result receipts are under `independent/`.
The former uses the pinned source packet/dual implementation under `producer/`.
The lead's original triple scripts are preserved in `producer/originals/`;
their working copies add only the local script directory to `sys.path`, so
`python3 -I` can import the adjacent portable source. The original script
SHA-256 values are `d03521e3a2592ae4da73297a17aa0fc3daabc559bf78586cba2ba4068faaabd9`
and `8285be7664280048acd5c01ccd4390cf1d827123349766dd287f57e9b82fb187`.

The two-parallel-communicator exploratory result is intentionally outside
this packet: it has a different scope and is not independently checked here.
Neither these cuts nor a local negative price establishes the five inherited
`native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and
`analytic_recovery` premises for a changed supplier.

## Reproduction

Use CPython 3.12 with the standard library; no network is required. From a
fresh extracted copy:

```
sha256sum -c SHA256SUMS
python3 -IB verify.py
```

The verifier authenticates the manifest and source pins, copies only the
inventoried files into a fresh temporary sibling, reruns the producer two- and
three-hole scans and the independent scans, and compares exact result bytes.
It also recomputes all 28 directed 36-call tariff intervals. Corruption controls
reject a changed source byte, an altered causal residual, and a false route
rank; a deliberately synthetic cheaper grade confirms the tariff detects a
positive sign. No synthetic alteration represents a physical candidate.
Each long scan is limited to 100 seconds. On the originating machine, the
independent two-hole and three-hole runs took 16.75 and 24.93 seconds,
respectively, and each used about 36 MiB maximum RSS. Hardware or contention
can change wall time.
