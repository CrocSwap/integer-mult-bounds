#!/usr/bin/env python3
"""Independent two-deletion pulse census and optional relaxed bank scan.

Reconstructs forward and transposed bitsets directly from primitive #7830
INIT/ADD/MOVE/SWAP/CLEAR events. No producer network, span or cost helper is
imported. CLEAR remains literal discard. Additional messenger is granted a
free span of all past arrivals, including protected packet 3553 as read-only;
both missing packets and no more are deleted. All 680 outputs are protected.
"""
from pathlib import Path
from collections import defaultdict,Counter
from hashlib import sha256
from fractions import Fraction as Q
from functools import lru_cache
from itertools import combinations
import gzip,json,sys
P=Path(__file__).resolve().parent
raw=(P/'inputs/WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));n=w['public'];program=w['program'];assert n==680
assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
R={};clock={};X={};Y={};path={};dpath={}

def sweep(reverse=False):
 state=[(c,1<<i,0) for i,c in enumerate(w['final'] if reverse else w['start'])]+[None]*w['owned_fields']
 sequence=range(len(program)-1,-1,-1) if reverse else range(len(program))
 for t in sequence:
  op,a,*arg=program[t]
  if op in ('INIT','CLEAR'):
   opening=(op=='CLEAR') if reverse else (op=='INIT')
   if opening:
    assert state[a] is None;state[a]=(arg[0],0,0)
   else:
    assert state[a] is not None and state[a][0]==arg[0];state[a]=None
  elif op=='ADD':
   j,c=arg;x,y=state[a],state[j];assert x is not None and y is not None and x[0]==y[0]==c
   if reverse:state[j]=(c,y[1]^x[1],y[2]^x[2])
   else:state[a]=(c,x[1]^y[1],x[2]^y[2])
  elif op=='SWAP':
   j=arg[0];state[a],state[j]=state[j],state[a]
  elif op=='MOVE':
   src,dst=arg[::-1] if reverse else arg;x=state[a];assert x is not None and x[0]==src
   if reverse:
    assert a in R and R[a]==(dst,src) and clock[a]==t
    Y[a]=x[1];dpath[a]=x[2]|(1<<a)
   else:
    assert a not in R;R[a]=(src,dst);clock[a]=t;X[a]=x[1];path[a]=x[2]|(1<<a)
   state[a]=(dst,x[1],x[2]|(1<<a))
  else:raise ValueError(op)
 assert all(s is None for s in state[n:])
 assert [s[0] for s in state[:n]]==(w['start'] if reverse else w['final'])
 expected=[(1<<i)^((1<<(i+111)) if reverse and i<111 else (1<<(i-111)) if not reverse and 111<=i<222 else 0) for i in range(n)]
 assert [s[1] for s in state[:n]]==expected
sweep();sweep(True)
O=sorted(R,key=clock.get);assert len(O)==2874 and all(X[p] and Y[p] for p in O)
assert all(((path[j]>>i)&1)==((dpath[i]>>j)&1) for i in O for j in O)
G={p:abs(w['frames'][str(a)]['dim']-w['frames'][str(b)]['dim']) for p,(a,b) in R.items()}
assert all(g>0 for g in G.values())
# The rank-one criterion is necessary and sufficient for two nonzero rank-one
# summands over GF(2): one pair of sides agrees or one adjusted side is zero.
# Exhaust the full pair list rather than generating equality groups.
eligible=[p for p in O if p!=3553]
pairs=[];counter=Counter()
for pos,k in enumerate(eligible):
 for j in eligible[pos+1:]:
  x0=X[k];x1=X[j]^(x0 if path[j]>>k&1 else 0);y0=Y[k];y1=Y[j]
  if x1==0 or x0==x1:
   x=x0;y=y0 if x1==0 else y0^y1
  elif y0==y1:x=x0^x1;y=y0
  else:
   counter['rank_two']+=1;continue
  if not x or not y:
   counter['rank_zero']+=1;continue
  pairs.append((k,j,x,y));counter['rank_one']+=1;counter[f'rank_one_sum_{G[k]+G[j]}']+=1
assert len(eligible)==2873 and len(eligible)*(len(eligible)-1)//2==4125628
assert counter['rank_one']+counter['rank_two']+counter['rank_zero']==4125628

def rref(rows):
 # Full exact rational row reduction; canonical result independent of basis.
 a=[[Q(v) for v in row] for row in rows];i=0
 for j in range(8):
  pivot=next((k for k in range(i,len(a)) if a[k][j]),None)
  if pivot is None:continue
  a[i],a[pivot]=a[pivot],a[i];scale=a[i][j];a[i]=[v/scale for v in a[i]]
  for k in range(len(a)):
   if k!=i and a[k][j]:
    scale=a[k][j];a[k]=[v-scale*x for v,x in zip(a[k],a[i])]
  i+=1
  if i==len(a):break
 assert i==len(a)
 return tuple(tuple(row) for row in a)
frames={int(k):v for k,v in w['frames'].items()}
canonical={k:rref(v['B']) for k,v in frames.items()}
assert len(set(canonical.values()))==len(frames)==636
# Exactly compare chart inclusions via original rational rows/annihilators;
# equal-dimensional chart labels are checked explicitly rather than discarded.
@lru_cache(maxsize=None)
def grade(a,b):
 if a==b:return 0
 da,db=frames[a]['dim'],frames[b]['dim']
 if da==db:return 0 if canonical[a]==canonical[b] else None
 lo,hi=(a,b) if da<db else (b,a)
 if any(sum(Q(x)*Q(y) for x,y in zip(u,v)) for u in frames[lo]['B'] for v in frames[hi]['A']):return None
 return abs(da-db)
assert all(grade(*R[p])==G[p] for p in O)

# Bank rosters in chronological orientation, as if all arrivals can be held
# freely. This overapproximates actual live stock and charges no local XORs.
def make_stock(reverse):
 bank=defaultdict(list)
 for i,c in enumerate(w['final'] if reverse else w['start']):bank[c].append(i)
 for p in (O[::-1] if reverse else O):bank[R[p][0] if reverse else R[p][1]].append(p)
 return bank
forward_bank=make_stock(False);backward_bank=make_stock(True)

def add(basis,row):
 while row:
  pivot=row.bit_length()
  old=basis.get(pivot)
  if old is None:basis[pivot]=row;return True
  row^=old
 return False

def contains(basis,row):
 while row:
  old=basis.get(row.bit_length())
  if old is None:return False
  row^=old
 return True

def possible(k,j,want,reverse):
 # Alter *every* later arrival by the exact two-hole causal signal, then grant
 # arbitrary retention and linear recombination inside each bank. The
 # protected packet 3553 is allowed as a read-only donor.
 old,paths,first,second,banks=(Y,dpath,j,k,backward_bank) if reverse else (X,path,k,j,forward_bank)
 firstrow=old[first];secondrow=old[second]^(firstrow if paths[second]>>first&1 else 0)
 maskfirst=1<<first;masksecond=1<<second
 changed={p:old[p]^(firstrow if paths[p]&maskfirst else 0)^(secondrow if paths[p]&masksecond else 0) for p in O if p!=k and p!=j}
 result=[]
 for chart,labels in banks.items():
  basis={}
  for p in labels:
   if p==k or p==j:continue
   value=changed[p] if p>=n else 1<<p
   if add(basis,value) and contains(basis,want):
    t=clock[p] if p>=n else (len(program) if reverse else -1)
    result.append((chart,t));break
 return result

result={'source_word_sha256':sha256(raw).hexdigest(),'public_rows_checked_each_orientation':n,
 'paid_packet_count':len(O),'protected_packet_allowed_as_read_only_donor':3553,
 'all_packet_input_and_dual_rows_nonzero':True,'exact_distinct_rational_chart_subspaces':len(canonical),
 'all_pairs_excluding_3553':4125628,'census':dict(counter),
 'scope':'Two missing named original paid packets, every original output retained, fixed other original operations, at most one extra nested-route communicator; grants free XORs and all historical sender/dual stock with causal insertion. Does not cover arbitrary word rewrites, new stocks, extra communicators, physical erasure or kappa.'}
if '--scan' in sys.argv:
 counts=Counter();offsets=Counter();details=[]
 for ix,(k,j,x,y) in enumerate(pairs):
  left=possible(k,j,x,False);right=possible(k,j,y,True)
  if left and right:counts['both_sides_algebraic']+=1
  for a,start in left:
   for b,end in right:
    if start>=end:continue
    counts['ordered_bank_pairs']+=1
    d=grade(a,b)
    if d is None:counts['nonnested_bank_pairs']+=1;continue
    excess=d-G[k]-G[j];offsets[excess]+=1
    details.append({'removed':[k,j],'old_grades':[G[k],G[j]],'route':[a,b],'new_grade':d,'grade_excess':excess,'earliest_source_clock':start,'latest_destination_clock':end})
  if ix%200==0:print('scanned',ix,'/',len(pairs),flush=True)
 # Compare signed prices directly at both trial rates, with outward intervals;
 # 0 is a zero-cost local operation, not a grade passed to H.
 import importlib.util
 sp=importlib.util.spec_from_file_location('admission',P/'tariff.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
 for case in details:
  case['signed_gain']={}
  for trial in (a.K,a.NEAR):
   with a.localcontext(a.N):
    exp=a.D(1)-trial
    left=a.moment(Counter({case['old_grades'][0]:1,case['old_grades'][1]:1}) if case['old_grades'][0]!=case['old_grades'][1] else Counter({case['old_grades'][0]:2}),exp)
    right=(Q(0),Q(0)) if case['new_grade']==0 else a.pow_iv(case['new_grade'],exp)
    gain=a.diff(left,right)
   case['signed_gain'][str(trial)]=a.iv(gain)
 result.update({'bank_scan':dict(counts),'grade_excess_histogram':dict(sorted(offsets.items())),
    'profitable_or_zero_local_candidates':[c for c in details if c['grade_excess']<=0],
    'outward_negative_signed_at_both_trials':all(a.D(c['signed_gain'][str(a.K)][1])<0 and a.D(c['signed_gain'][str(a.NEAR)][1])<0 for c in details),
    'all_nested_candidates':details})
 result['status']='PASS_SCOPED_INDEPENDENT_TWO_HOLE_CUT' if not result['profitable_or_zero_local_candidates'] and result['outward_negative_signed_at_both_trials'] else 'ATTENTION_TWO_HOLE_CANDIDATE'
else:result['status']='PASS_INDEPENDENT_PAIR_CENSUS_ONLY'
(P/'TWO-HOLE-INDEPENDENT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('all_nested_candidates',)},sort_keys=True,indent=2),flush=True)
