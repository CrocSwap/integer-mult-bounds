"""Outward Decimal/log enclosure and exact rational signed-grade tariff."""
from decimal import Context,Decimal,ROUND_FLOOR,ROUND_CEILING,ROUND_HALF_EVEN,localcontext
from fractions import Fraction
from collections import Counter
D=Decimal;F=Fraction
K=D('0.003879928046156');NEAR=D('0.003879929046155')
N=Context(prec=90,rounding=ROUND_HALF_EVEN);L=Context(prec=90,rounding=ROUND_FLOOR);U=Context(prec=90,rounding=ROUND_CEILING)
def pow_iv(rank,exponent):
 assert type(rank) is int and rank>=1 and exponent>=0
 if rank==1:return F(1),F(1)
 x=N.ln(D(rank));a=N.next_minus(x);b=N.next_plus(x)
 return F(N.next_minus(N.exp(L.multiply(a,exponent)))),F(N.next_plus(N.exp(U.multiply(b,exponent))))
def moment(histogram,exponent):
 lo=hi=F(0)
 for rank,count in histogram.items():
  a,b=pow_iv(rank,exponent)
  if count>=0:lo+=count*a;hi+=count*b
  else:lo+=count*b;hi+=count*a
 return lo,hi
def diff(a,b):return a[0]-b[1],a[1]-b[0]
def iv(q):return [str(L.divide(D(q[0].numerator),D(q[0].denominator))),str(U.divide(D(q[1].numerator),D(q[1].denominator)))]
