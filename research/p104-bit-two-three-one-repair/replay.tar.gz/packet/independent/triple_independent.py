#!/usr/bin/env python3
"""Independent triple rank-family census, direct literal holes, bank pricing.

Source rows are independently swept from the original word by the separate
`two_hole_independent.py` primitive interpreter. Group triples via pairs of
independent X,Y vectors, not the lead's grouping. All 288 rank-one survivors
are directly replayed against every original public row before bank screening.
"""
from pathlib import Path
from collections import defaultdict,Counter
from itertools import combinations,product
from fractions import Fraction as Q
from hashlib import sha256
from functools import lru_cache
import importlib.util,json
P=Path(__file__).resolve().parent
prefix=(P/'two_hole_independent.py').read_text().split('# The rank-one criterion')[0]
env={'__file__':str(P/'two_hole_independent.py')};exec(compile(prefix,str(P/'two_hole_independent.py'),'exec'),env)
w,n,program,O,X,Y,path,dpath,R,clock,G=[env[k] for k in ('w','n','program','O','X','Y','path','dpath','R','clock','G')]
packets=[p for p in O if p!=3553]
lead=json.loads((P/'inputs/LEAD-TRIPLE-RANK.json').read_bytes());routes=json.loads((P/'inputs/LEAD-TRIPLE-ROUTES.json').read_bytes())
assert len(packets)==2873 and all(X[p] and Y[p] for p in packets)
# Nonzero (x,y) pairs are unique for this pinned source. Distinct nonzero
# vectors are automatically independent over GF(2).
cells={(X[p],Y[p]):p for p in packets};assert len(cells)==len(packets)
byx=defaultdict(list);byy=defaultdict(list)
for p in packets:byx[X[p]].append(p);byy[Y[p]].append(p)
triples=set()
for groups in (byx,byy):
 for values in groups.values():
  for a,b,c in combinations(values,3):triples.add(tuple(sorted((a,b,c))))
# Remaining rank-2/rank-2 triples admit a pair independent in both
# projections. Its third nonzero vector must lie in the 3x3 product of
# their two spans; enumerate that lattice and deduplicate all pair choices.
for idx,p in enumerate(packets):
 xp,yp=X[p],Y[p]
 for q in packets[idx+1:]:
  xq,yq=X[q],Y[q]
  if xp==xq or yp==yq:continue
  xs=(xp,xq,xp^xq);ys=(yp,yq,yp^yq)
  for xc,yc in product(xs,ys):
   r=cells.get((xc,yc))
   if r is not None and r!=p and r!=q:triples.add(tuple(sorted((p,q,r))))
assert len(triples)==2436

def adjusted(holes,old,reach):
 effects={}
 for k in holes:
  v=old[k]
  for j,z in effects.items():
   if reach[k]>>j&1:v^=z
  effects[k]=v
 return effects

def residual(holes):
 eff=adjusted(holes,X,path)
 # Build every row of the 680x680 residual independently, then take rank.
 rows=[];basis={}
 for i in range(n):
  row=0
  for k,z in eff.items():
   if z>>i&1:row^=Y[k]
  rows.append(row);v=row
  while v:
   pivot=v.bit_length()
   if pivot not in basis:basis[pivot]=v;break
   v^=basis[pivot]
 rank=len(basis)
 if rank!=1:return rank,None
 y=next(iter(basis.values()));x=0
 for i,row in enumerate(rows):
  assert row in (0,y)
  if row:x|=1<<i
 return rank,(x,y)

claimed={tuple(q['ids']):q for q in lead['one']};assert len(claimed)==288
survivors=[];counts=Counter()
for ids in sorted(triples):
 ordered=tuple(sorted(ids,key=clock.get));rank,pair=residual(ordered);counts[str(rank)]+=1
 if rank==1:
  assert ordered in claimed and pair==(claimed[ordered]['input'],claimed[ordered]['output'])
  assert sum(G[k] for k in ordered)==claimed[ordered]['funding']
  survivors.append((ordered,*pair))
 else:assert ordered not in claimed
assert len(survivors)==len(claimed)==288 and dict(counts)==lead['rank_census'] and not lead['zero']
# Literal tape with three zeroed MOVE payloads; all 288 surviving residuals
# must agree with the proposed rank-one outer product at all 680 outputs.
expected=[(1<<i)^((1<<(i-111)) if 111<=i<222 else 0) for i in range(n)]
def literal_holes(holes):
 state=[1<<i for i in range(n)]+[0]*w['owned_fields'];holes=set(holes)
 for op,a,*rest in program:
  if op in ('INIT','CLEAR'):state[a]=0
  elif op=='ADD':state[a]^=state[rest[0]]
  elif op=='SWAP':b=rest[0];state[a],state[b]=state[b],state[a]
  elif op=='MOVE':
   if a in holes:state[a]=0
  else:raise ValueError(op)
 return state[:n]
for holes,x,y in survivors:
 rows=literal_holes(holes)
 assert all((rows[i]^expected[i])==(x if (y>>i)&1 else 0) for i in range(n))
print('direct literal residuals passed:',len(survivors),flush=True)

# Independent historical stock bases, in both causal directions. 3553 is
# available as an untouched read-only donor, but may not be deleted.
def banks(reverse):
 out=defaultdict(list)
 for i,c in enumerate(w['final'] if reverse else w['start']):out[c].append(i)
 for p in O[::-1] if reverse else O:out[R[p][0] if reverse else R[p][1]].append(p)
 return out
FB,DB=banks(False),banks(True)
def add(B,v):
 while v:
  k=v.bit_length()
  if k not in B:B[k]=v;return True
  v^=B[k]
 return False

def contains(B,v):
 while v:
  k=v.bit_length()
  if k not in B:return False
  v^=B[k]
 return True

def search(holes,want,rev):
 old,reach,stock=(Y,dpath,DB) if rev else (X,path,FB)
 hs=holes[::-1] if rev else holes;effects=adjusted(hs,old,reach)
 rows={}
 for p in O:
  if p in effects:continue
  v=old[p]
  for j,z in effects.items():
   if reach[p]>>j&1:v^=z
  rows[p]=v
 found=[]
 for chart,ls in stock.items():
  B={}
  for p in ls:
   if p in effects:continue
   row=rows[p] if p>=n else 1<<p
   if add(B,row) and contains(B,want):
    found.append((chart,clock[p] if p>=n else (len(program) if rev else -1)));break
 return found

frames={int(k):v for k,v in w['frames'].items()}
@lru_cache(maxsize=None)
def grade(a,b):
 if a==b:return 0
 da,db=frames[a]['dim'],frames[b]['dim']
 if da==db:
  # Previous independent rational RREF exhaustively verified that the source
  # has no equal-dimensional duplicate chart subspaces.
  return None
 low,high=(a,b) if da<db else (b,a)
 if any(sum(Q(x)*Q(y) for x,y in zip(u,v)) for u in frames[low]['B'] for v in frames[high]['A']):return None
 return abs(da-db)

hits=[];bankcounts=Counter()
for holes,x,y in survivors:
 src=search(holes,x,False);dst=search(holes,y,True)
 if src and dst:bankcounts['both sides in stock']+=1
 for c,start in src:
  for d,end in dst:
   if start>=end:continue
   bankcounts['ordered pair']+=1
   g=grade(c,d)
   if g is None:continue
   bankcounts['ordered geometrically legal pair']+=1
   hits.append({'ids':list(holes),'route':[c,d],'old_grades':[G[i] for i in holes],'new_grade':g,'window':[start,end]})
assert dict(bankcounts)==routes['counters']
reported={(tuple(x['ids']),tuple(x['route']),x['new_grade'],tuple(x['window'])) for x in routes['results']}
ours={(tuple(x['ids']),tuple(x['route']),x['new_grade'],tuple(x['window'])) for x in hits}
assert ours==reported and len(hits)==9
sp=importlib.util.spec_from_file_location('admission',P/'tariff.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
for hit in hits:
 hit['signed_gain']={}
 for trial in (a.K,a.NEAR):
  with a.localcontext(a.N):
   e=a.D(1)-trial;old=a.moment(Counter(hit['old_grades']),e);new=a.pow_iv(hit['new_grade'],e) if hit['new_grade'] else (Q(0),Q(0));margin=a.diff(old,new)
  assert margin[1]<0;hit['signed_gain'][str(trial)]=a.iv(margin)
assert all(h['new_grade']-sum(h['old_grades'])==1 for h in hits)
result={'status':'PASS_INDEPENDENT_TRIPLE_REPLAY','total_packets':len(packets),'rank_sum_at_most_4_triples':len(triples),
 'independent_rank_census':dict(counts),'all_288_direct_680_output_residuals_pass':True,'bank_scan':dict(bankcounts),
 'all_nine_signed_margins_negative_at_K_and_near':True,'candidates':hits,
 'source_word_sha256':sha256((P/'inputs/WORD.json.gz').read_bytes()).hexdigest(),
 'lead_rank_receipt_sha256':sha256((P/'inputs/LEAD-TRIPLE-RANK.json').read_bytes()).hexdigest(),
 'lead_route_receipt_sha256':sha256((P/'inputs/LEAD-TRIPLE-ROUTES.json').read_bytes()).hexdigest(),
 'scope':'Exactly three original MOVE payloads zeroed, all 680 original outputs required, all other native operations fixed, one added nested communicator, free historical bank XOR/retention, 3553 protected from deletion but available as donor. No general changed word, extra communicator, physical erasure or kappa bound.'}
(P/'TRIPLE-INDEPENDENT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='candidates'},indent=2,sort_keys=True),flush=True)
