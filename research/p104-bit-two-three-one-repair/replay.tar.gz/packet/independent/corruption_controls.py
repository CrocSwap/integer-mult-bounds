#!/usr/bin/env python3
"""Fail-closed controls for source, residual, chart rank and tariff checks."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from fractions import Fraction
from decimal import localcontext
import importlib.util,json
P=Path(__file__).resolve().parent
raw=(P/'inputs/WORD.json.gz').read_bytes();pin='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
assert sha256(raw).hexdigest()==pin
bad=bytearray(raw);bad[len(bad)//2]^=1
assert sha256(bad).hexdigest()!=pin
prefix=(P/'two_hole_independent.py').read_text().split('# The rank-one criterion')[0]
e={'__file__':str(P/'two_hole_independent.py')};exec(compile(prefix,str(P/'two_hole_independent.py'),'exec'),e)
w,n,R,G,X,Y,path=[e[k] for k in ('w','n','R','G','X','Y','path')]
t=json.loads((P/'EXPECTED-TRIPLE.json').read_text());z=t['candidates'][0];holes=z['ids'];assert len(holes)==3
# Reconstruct all residual output rows for the selected triple from the raw
# primitive word and check the declared and tampered input masks.
original=[(1<<i)^((1<<(i-111)) if 111<=i<222 else 0) for i in range(n)]
program=w['program'];state=[1<<i for i in range(n)]+[0]*w['owned_fields']
for op,a,*arg in program:
 if op in ('INIT','CLEAR'):state[a]=0
 elif op=='ADD':state[a]^=state[arg[0]]
 elif op=='SWAP':j=arg[0];state[a],state[j]=state[j],state[a]
 elif op=='MOVE':
  if a in holes:state[a]=0
rank=json.loads((P/'inputs/LEAD-TRIPLE-RANK.json').read_text())
source=next(q for q in rank['one'] if q['ids']==holes);x,y=source['input'],source['output']
def matches(v):return all((state[i]^original[i])==(v if y>>i&1 else 0) for i in range(n))
assert matches(x) and not matches(x^1)
# Route rank is bound to the actual frame pair; a reported cheaper rank fails.
a,b=z['route'];actual=abs(w['frames'][str(a)]['dim']-w['frames'][str(b)]['dim'])
assert actual==z['new_grade']==8 and actual!=7
sp=importlib.util.spec_from_file_location('tariff',P/'tariff.py');q=importlib.util.module_from_spec(sp);sp.loader.exec_module(q)
with localcontext(q.N):
 e0=q.D(1)-q.K;old=q.moment(Counter(z['old_grades']),e0)
 real=q.diff(old,q.pow_iv(actual,e0));fiction=q.diff(old,q.pow_iv(1,e0))
assert real[1]<0 and fiction[0]>0
out={'status':'PASS_SOURCE_RESIDUAL_RANK_AND_TARIFF_CORRUPTION_CONTROLS',
 'word_byte_mutation_rejected':True,'residual_input_mask_mutation_rejected':True,
 'fake_grade_7_rejected_by_actual_route':True,'synthetic_grade_1_profit_detected':True,
 'scope':'Small deterministic negative controls. The grade-1 price is a synthetic corruption, not a physical candidate.'}
print(json.dumps(out,sort_keys=True,indent=2))
