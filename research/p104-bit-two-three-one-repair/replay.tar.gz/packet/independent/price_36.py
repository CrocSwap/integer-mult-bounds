#!/usr/bin/env python3
"""Reprice each independently identified local edit for 36 unchanged calls."""
from pathlib import Path
from collections import Counter
from decimal import localcontext
from fractions import Fraction
import importlib.util,json
P=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('tariff',P/'tariff.py');a=importlib.util.module_from_spec(sp);sp.loader.exec_module(a)
res={}
for kind,file in [('two','EXPECTED-TWO-HOLE.json'),('three','EXPECTED-TRIPLE.json')]:
 raw=json.loads((P/file).read_bytes());rows=raw['all_nested_candidates'] if kind=='two' else raw['candidates'];cases=[]
 for z in rows:
  old=z['old_grades'];new=z['new_grade'];prices={}
  for rate in (a.K,a.NEAR):
   with localcontext(a.N):
    e=a.D(1)-rate;before=a.moment(Counter(old),e);after=a.pow_iv(new,e) if new else (Fraction(0),Fraction(0));d=a.diff(before,after)
   total=(36*d[0],36*d[1]);assert total[1]<0
   prices[str(rate)]=a.iv(total)
  cases.append({'removed':z.get('removed',z.get('ids')),'old_grades':old,'new_grade':new,'full_36_call_paid_only_gain':prices})
 res[kind]={'cases':cases,'case_count':len(cases)}
assert (res['two']['case_count'],res['three']['case_count'])==(19,9)
print(json.dumps({'status':'PASS_ALL_28_OUTWARD_36_CALL_PRICES_NEGATIVE',
 'scope':'Hypothetical uniform replay of each listed local change in all 36 pinned caller calls, unchanged productive bins and no additional charges. Not an actual changed word, physical erasure or kappa bound.',
 'groups':res},sort_keys=True,indent=2))
