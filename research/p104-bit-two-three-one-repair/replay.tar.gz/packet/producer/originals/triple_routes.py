"""Check a chronological, single new coded communicator for each rank-one triple."""
from collections import Counter, defaultdict
import json
from pathlib import Path

from network import CLOCK, DPA, DROWS, DR, G, O, PATH, R, ROWS, Span, W, X, Y, labels, xsum
from triple_cut import omitting
from two_hole import grade

HERE = Path(__file__).resolve().parent
n = W["public"]
eof = len(W["program"])


def stock_index(routes, endpoints, order):
    banks = defaultdict(list)
    for k, c in enumerate(endpoints):
        banks[c].append(k)
    for k in order:
        banks[routes[k][1]].append(k)
    return banks


F = stock_index(R, W["start"], O)
A = stock_index(DR, W["final"], O[::-1])


def changed_rows(holes, order, old, reach):
    perturbations = {}
    for k in holes:
        perturbations[k] = old[k] ^ xsum(
            value for j, value in perturbations.items() if reach[k] >> j & 1
        )
    return {k: old[k] ^ xsum(
        value for j, value in perturbations.items() if reach[k] >> j & 1
    ) for k in order if k not in holes}


def direct_rows(holes, order, forms):
    values = {j: 1 << j for j in range(n)}
    for k in order:
        values[k] = 0 if k in holes else xsum(values[j] for j in labels(forms[k]))
    return values


def first_banks(stock, holes, changed, wanted, initial_clock):
    for c, available in stock.items():
        span = Span()
        for k in available:
            if k in holes:
                continue
            row = changed[k] if k >= n else 1 << k
            if not span.add(row, 1 << k):
                continue
            combination = span.express(wanted)
            if combination is not None:
                yield c, CLOCK[k] if k >= n else initial_clock, list(labels(combination))
                break


def verify_residual(triple, rows_f, rows_a, x, y, check_direct):
    if check_direct:
        naive_f = direct_rows(triple, O, ROWS)
        naive_a = direct_rows(triple, O[::-1], DROWS)
        assert all(naive_f[k] == v for k, v in rows_f.items())
        assert all(naive_a[k] == v for k, v in rows_a.items())
    for end in range(n):
        want = 1 << end
        if 111 <= end < 222:
            want ^= 1 << (end - 111)
        cut = xsum((1 << j) if j < n else rows_f.get(j, 0) for j in labels(ROWS[~end]))
        assert cut ^ want == (x if y >> end & 1 else 0)


def main():
    census = json.loads((HERE / "TRIPLE-RANK.json").read_text())
    results, stats, gaps = [], Counter(), Counter()
    for i, row in enumerate(census["one"]):
        holes = tuple(row["ids"])
        x, y = row["input"], row["output"]
        assert omitting(holes) == (1, (x, y))
        fs = changed_rows(holes, O, X, PATH)
        ds = changed_rows(holes[::-1], O[::-1], Y, DPA)
        verify_residual(holes, fs, ds, x, y, i % 11 == 0)
        source = list(first_banks(F, holes, fs, x, -1))
        dest = list(first_banks(A, holes, ds, y, eof))
        if source and dest:
            stats["both sides in stock"] += 1
        for a, earliest, operands in source:
            for b, latest, readers in dest:
                if earliest >= latest:
                    continue
                stats["ordered pair"] += 1
                g = grade(a, b)
                if g is None:
                    continue
                stats["ordered geometrically legal pair"] += 1
                old = [G[k] for k in holes]
                gaps[g-sum(old)] += 1
                results.append(dict(ids=holes, old_grades=old, new_grade=g, route=[a, b],
                                    window=[earliest, latest], operands=operands, readers=readers))
    results.sort(key=lambda r: (r["new_grade"]-sum(r["old_grades"]), r["ids"]))
    (HERE / "TRIPLE-ROUTES.json").write_text(json.dumps(dict(
        source=census["source"], counters=stats, grade_surplus=gaps, results=results
    ), indent=2) + "\n")
    print(dict(cases=len(census["one"]), counters=stats, grade_surplus=gaps))
    if results:
        print("best", results[:3])


if __name__ == "__main__":
    main()
