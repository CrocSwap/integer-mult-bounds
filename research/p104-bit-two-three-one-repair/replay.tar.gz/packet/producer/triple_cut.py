"""Three ordinary packet omissions in the exact pinned binary graph."""
from collections import Counter, defaultdict
from itertools import combinations, product
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

from network import CLOCK, G, O, PATH, X, Y, public_source


def candidate_triples(packets):
    """Yield every set whose original input and output ranks sum to at most four."""
    byinput, byoutput = defaultdict(list), defaultdict(list)
    for k in packets:
        byinput[X[k]].append(k)
        byoutput[Y[k]].append(k)
    for group in byinput.values():
        yield from combinations(group, 3)
        for a, b in combinations(group, 2):
            ya, yb = Y[a], Y[b]
            for c in packets:
                if X[c] != X[a] and (ya == yb or Y[c] in (ya, yb, ya ^ yb)):
                    yield a, b, c
    for group in byoutput.values():
        for a, b, c in combinations(group, 3):
            if len({X[a], X[b], X[c]}) == 3:
                yield a, b, c
        for a, b in combinations(group, 2):
            xa, xb = X[a], X[b]
            if xa != xb:
                for c in byinput.get(xa ^ xb, ()):
                    if Y[c] != Y[a]:
                        yield a, b, c
    rows = sorted(byinput)
    for i, xa in enumerate(rows):
        for j in range(i+1, len(rows)):
            xb = rows[j]
            xc = xa ^ xb
            if xc <= xb or xc not in byinput:
                continue
            for a, b, c in product(byinput[xa], byinput[xb], byinput[xc]):
                ya, yb, yc = Y[a], Y[b], Y[c]
                if len({ya, yb, yc}) == 3 and ya ^ yb == yc:
                    yield a, b, c


def append_pivot(basis, v):
    while v and v.bit_length() in basis:
        v ^= basis[v.bit_length()]
    if v:
        basis[v.bit_length()] = v


def omitting(packets):
    """Factor the causal residual in X echelon coordinates, then rank it."""
    perturbations, pivots, columns = {}, {}, {}
    for k in packets:
        v = X[k]
        for j, perturbation in perturbations.items():
            if PATH[k] >> j & 1:
                v ^= perturbation
        perturbations[k] = v
        while v and v.bit_length() in pivots:
            p = v.bit_length()
            v ^= pivots[p]
            columns[p] ^= Y[k]
        if v:
            p = v.bit_length()
            pivots[p] = v
            columns[p] = Y[k]
    column_basis = {}
    for col in columns.values():
        append_pivot(column_basis, col)
    rank = len(column_basis)
    if rank != 1:
        return rank, None
    y = next(iter(column_basis.values()))
    x = 0
    for p, col in columns.items():
        assert col in (0, y)
        if col:
            x ^= pivots[p]
    return rank, (x, y)


def main():
    packets = [k for k in O if k != 3553]
    assert all(X[k] and Y[k] for k in packets)
    stats, rank_one, rank_zero, saw = Counter(), [], [], set()
    for triple in candidate_triples(packets):
        triple = tuple(sorted(triple, key=CLOCK.get))
        assert triple not in saw
        saw.add(triple)
        rank, residual = omitting(triple)
        stats[rank] += 1
        if rank == 0:
            rank_zero.append(triple)
        if residual:
            x, y = residual
            rank_one.append(dict(ids=triple, funding=sum(G[k] for k in triple),
                                 input=x, output=y))
    rank_one.sort(key=lambda v: (-v["funding"], v["ids"]))
    result = dict(source=public_source(), packet_count=len(packets), rank_census=stats,
                  zero=rank_zero, one=rank_one)
    path = Path(__file__).with_name("TRIPLE-RANK.json")
    path.write_text(json.dumps(result, indent=2) + "\n")
    print(dict(packet_count=len(packets), rank_census=stats,
               max_funding=max(x["funding"] for x in rank_one)))


if __name__ == "__main__":
    main()
