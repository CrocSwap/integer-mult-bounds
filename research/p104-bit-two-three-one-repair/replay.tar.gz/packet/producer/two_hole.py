"""Factor the exact residual of two missing paid packets, with one funded replacement."""
import itertools
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from network import *

protect={3553}

def rank1(k,j):
    assert CLOCK[k]<CLOCK[j]
    path=PATH[j]>>k&1
    x0=X[k];x1=X[j]^(X[k] if path else 0)
    y0=Y[k];y1=Y[j]
    if not x1:return x0,y0
    if x0==x1:return x0,y0^y1
    if y0==y1:return x0^x1,y0
    return None

def pairs():
    out=set()
    for terms in (X,Y):
        groups=defaultdict(list)
        for p in O:
            if p not in protect:groups[terms[p]].append(p)
        for group in groups.values():out.update(itertools.combinations(group,2))
    return [(k,j) for k,j in sorted(out) if rank1(k,j) is not None]

if __name__=='__main__':
    pp=pairs(); count=Counter(); z=[]
    for k,j in pp:
        x,y=rank1(k,j); count[('xy' if x and y else 'zero',G[k]+G[j])]+=1
        if not x or not y:z.append((k,j))
    print('cases',len(pp),sorted(count.items()),'zeros',z[:20])

from functools import lru_cache
from math import lcm
from fractions import Fraction

def integral(row):
    q=list(map(Fraction,row)); m=lcm(*(x.denominator for x in q));return tuple(int(x*m) for x in q)
FRAMES={int(c):(tuple(integral(r) for r in f['B']),tuple(integral(r) for r in f['A'])) for c,f in W['frames'].items()}
@lru_cache(maxsize=None)
def grade(a,b):
    if a==b:return 0
    l,h=sorted((a,b),key=DIMS.get)
    d=DIMS[h]-DIMS[l]
    if not d:return None
    if any(sum(u*v for u,v in zip(x,y)) for x in FRAMES[l][0] for y in FRAMES[h][1]):return None
    return d

stock=[]
for reverse,(start,routes,order) in enumerate(((W['start'],R,O),(W['final'],DR,O[::-1]))):
    banks=defaultdict(list)
    for h,s in enumerate(start):banks[s].append(h)
    for p in order:banks[routes[p][1]].append(p)
    stock.append(banks)

def avail(k,j,reverse,want):
    old,paths,first,later=(Y,DPA,j,k) if reverse else (X,PATH,k,j)
    x0=old[first];x1=old[later]^(x0 if paths[later]>>first&1 else 0)
    bitfirst=1<<first;bitlater=1<<later
    changed={p:old[p]^(x0 if paths[p]&bitfirst else 0)^(x1 if paths[p]&bitlater else 0) for p in O if p!=k and p!=j}
    found=[]
    for c,ls in stock[reverse].items():
        b=Span()
        for p in ls:
            if p==k or p==j:continue
            a=changed[p] if p>=680 else 1<<p
            if not b.add(a,1<<p):continue
            # A previously impossible vector may become present only after a growth.
            s=b.express(want)
            if s is None:continue
            clock=CLOCK[p] if p>=680 else (len(W['program']) if reverse else -1)
            found.append((c,clock,s));break
    return found

def scan():
    pp=pairs();cnt=Counter();hits=[];all_nested=[];basket=Counter(); examples=[]
    assert len(O)==2874 and all(X[k] and Y[k] for k in O)
    for index,(k,j) in enumerate(pp):
        x,y=rank1(k,j)
        assert x and y
        src=avail(k,j,False,x);dst=avail(k,j,True,y)
        if src and dst:cnt['both_sides_algebraic']+=1
        for a,first,inp in src:
            for b,last,out in dst:
                if first>=last:continue
                cnt['ordered_bank_pairs']+=1
                d=grade(a,b)
                if d is None:continue
                basket[d-G[k]-G[j]]+=1
                residual={}
                for rate in prices.RATES:
                    val=prices.minus(prices.plus(prices.power(G[k],rate),prices.power(G[j],rate)),prices.power(d,rate))
                    residual[str(rate)]=prices.display(prices.scale(val,36))
                all_nested.append(dict(removed=[k,j],legs=[G[k],G[j],d],banks=[a,b],clock_range=[first,last],full_36_call_gain=residual))
                if all(prices.D(x[1])<0 for x in residual.values()):continue
                rec=dict(removed=[k,j],old_grades=[G[k],G[j]],route=[a,b],cost=d,range=[first,last],inputs=list(labels(inp)),outputs=list(labels(out)))
                hits.append(rec)
                print('HIT',rec,flush=True)
        if index%100==0:print('progress',index,len(pp),cnt,len(hits),flush=True)
    emit('TWO-HOLE.json',dict(source=public_source(),all_nonbridge_pairs=2873*2872//2,rank_one_pairs=len(pp),nested=all_nested,census=cnt,repricing_candidates=hits,contact_budget_offset_by_grade=dict(basket),method='exact two missing named paid packets, original solver outside one extra communicator; all 680 returned owners, arbitrary temporally appropriate changed input/dual bank span. All protected 3553 donor reads are granted. The communicator begins after its last source leaf and before its first destination use.'))

if __name__=='__main__' and '--scan' in sys.argv:scan()
