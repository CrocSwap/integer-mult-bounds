#!/usr/bin/env python3
"""Cold-copy manifest, producer and independent finite replay."""
from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess,sys,tempfile
P=Path(__file__).resolve().parent
if not __debug__:raise SystemExit('Assertions must be enabled')
items=[]
for line in (P/'SHA256SUMS').read_text().splitlines():
 digest,rel=line.split('  ',1);path=P/rel
 assert path.is_file() and path.resolve().is_relative_to(P.resolve())
 assert sha256(path.read_bytes()).hexdigest()==digest,rel
 items.append(rel)
assert len(items)==len(set(items))
source=json.loads((P/'producer/SOURCES.json').read_text())
for row in source['files']:
 assert sha256((P/'producer'/row['local']).read_bytes()).hexdigest()==row['sha256'],row['local']
with tempfile.TemporaryDirectory(prefix='p104-two-three-check-',dir=P.parent) as tmp:
 root=Path(tmp)/'packet';root.mkdir()
 for rel in items:
  dst=root/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/rel,dst)
 def run(label,folder,script,args=(),expected=None,generated=None):
  work=root/folder
  r=subprocess.run([sys.executable,'-IB',script,*args],cwd=work,capture_output=True,timeout=100)
  if r.returncode:
   sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);raise SystemExit(label+' failed')
  if expected:
   actual=(work/generated).read_bytes() if generated else r.stdout
   assert actual==(work/expected).read_bytes(),label+' changed receipt'
  print('PASS',label,flush=True)
 run('producer two-hole','producer','two_hole.py',('--scan',),'EXPECTED-TWO-HOLE.json','TWO-HOLE.json')
 run('producer triple census','producer','triple_cut.py',(),'EXPECTED-TRIPLE-RANK.json','TRIPLE-RANK.json')
 run('producer triple routes','producer','triple_routes.py',(),'EXPECTED-TRIPLE-ROUTES.json','TRIPLE-ROUTES.json')
 run('independent two-hole','independent','two_hole_independent.py',('--scan',),'EXPECTED-TWO-HOLE.json','TWO-HOLE-INDEPENDENT.json')
 run('independent triple census and literal words','independent','triple_independent.py',(),'EXPECTED-TRIPLE.json','TRIPLE-INDEPENDENT.json')
 run('directed 36-call prices','independent','price_36.py',(),'PRICE-36.json')
 run('corruption controls','independent','corruption_controls.py',(),'CORRUPTION-CONTROLS.json')
 # Exercise the actual word loader on tampered bytes, not just an in-memory hash.
 word=root/'independent/inputs/WORD.json.gz';b=bytearray(word.read_bytes());b[len(b)//2]^=1;word.write_bytes(b)
 bad=subprocess.run([sys.executable,'-IB','two_hole_independent.py'],cwd=root/'independent',capture_output=True,timeout=15)
 assert bad.returncode!=0,'changed source word accepted'
 print('PASS changed-source execution rejected',flush=True)
print('PASS CLEAN TWO-AND-THREE HOLE PACKAGE',flush=True)
