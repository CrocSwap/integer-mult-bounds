# Second-owner screen after the 679-owner zero control

This finite screen finds **no positive signed gain** when one additional original helper is surrendered and up to three retained paid packets are directly omitted in the four arrival banks examined. The best case in an expanded five-bank screen has the complete 36-call signed change `36(H1 + H2 − H4)`, which is strictly negative at both trial values. Here `Hr = r^(1−κ)`.

The starting point is the literal 679-owner word from [#7912 at `83ece5a`](https://github.com/CrocSwap/integer-mult-bounds/blob/83ece5a62d3addbee45bad9594ef4809851b833b/research/p104-bit-adjoint-multidonor-cut/README.md). It specializes original owner 649 and removes original packet 3266, with exactly zero signed histogram change from [#7830 at `87fbf4f`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15). Packet and owner numbers below always refer to #7830's 680-owner graph, not renumbered compiled fields. The program reconstructs the supplied 679-owner literal word byte for byte before screening.

## Relations and eligible second owners

The five payloads affected by the first specialization arrive at charts 349, 506, 511, and 536. Their retained packet rosters are recorded in [RESULT.json](RESULT.json). Among all 129 pairs of retained adjoint packet payloads at these four charts, the only singleton XORs after projection of owner 649 are:

| Arrival chart | Packet pair | Exact XOR | Grades of the two packets |
| --- | --- | --- | --- |
| 506 | 2283, 2284 | original owner 633 | 2, 2 |
| 506 | 2287, 3387 | original owner 634 | 2, 2 |

Both original owners are eligible grade-4 helpers. The complete projected packet supports and original source clocks appear in the receipt, so these equations can be checked independently. A further survey found `payload(2937) XOR payload(2938) = owner 633` at chart 515; both packets are grade 1. Surrendering 634 also makes packet 3122, a grade-1 movement from adjoint chart 1 to 586, identically zero. No automatic packet becomes zero or dead when 633 is surrendered in addition to 649. A separate global rank scan of all 636 retained arrival-chart families finds no further same-bank input relations: only charts 506 and 515 have a nontrivial kernel after surrendering 633, and only chart 506 does after surrendering 634. This global rank statement does not extend the subsequent bounded omission search beyond the stated banks.

For each surrender the receipt lists all **678 surviving original owners**. Original owner 411 remains present, and packet/field 3553 retains its original 411-only sender row, pure pulse, and adjoint route `1 → 509`. All 678 adjoint public endpoint equations are checked for every schedulable candidate. This is a packet-graph replay; none of the negative changed graphs was compiled into a new physical word.

## Exhaustive bounded screen and timed stock

For each owner, the four requested banks contain 25 retained packets. The screen checks all `C(25,0)+C(25,1)+C(25,2)+C(25,3) = 2,626` omission sets. It grants free access to **all** retained same-chart initial and packet payloads at any time, but requires each surviving packet's original specialized payload and each surviving terminal output to be preserved. It allows aggregate cancellation of several omitted parents at a reader. The complete bank families and their GF(2) kernels make this a necessary all-time stock test, independent of an assumed schedule. For both owners exactly three sets pass that optimistic test: the empty set and either member of the relevant chart-506 pair. All three admit actual topological schedules and pass the endpoint equations.

Adding chart 515 yields 28 candidate packets and 3,683 sets of size zero through three for each owner. For 633 there are nine all-time-repairable sets: neither or one of 2283/2284, independently combined with neither or one of 2937/2938. For 634 there are three: neither or one of 2287/3387. Every one has a valid topological schedule; all other sets fail even the free all-time stock test. A subsequent zero/dead fixed point finds no further omitted packet in any scheduled case.

The receipt lists every repaired reader, donor and their zero-based positions in the **new adjoint packet schedule**. For example, after surrendering 633 and omitting 2284 and 2938, donor 2283 is available at position 2179 before reader 1310 at 2662, and donor 2937 is available at 206 before reader 2479 at 2182. After surrendering 634 and omitting 3387, donor 2287 is available at 48 before its earliest repaired reader, packet 3386 at 1664. These are deterministic topological positions, not instruction clocks of the original literal word. A deliberately omitted live donor repair fails a protected output for each second owner.

## Full 36-call price

The native grade histogram is inserted into the pinned actual 36-call caller, including all its other paid and productive terms. Surrendering either grade-4 owner removes 36 productive grade-4 positions. The best 633 case omits one grade-2 packet at chart 506 and one grade-1 packet at chart 515. The best 634 case omits one grade-2 packet at chart 506 and automatically removes grade-1 packet 3122. Thus both save 36 paid positions of each of grades 1 and 2, and both have the same full signed change. The ordinary cost of changing sender XORs is optimistically ignored in the screen.

| κ | Full signed margin of 679 control | Best screened full signed margin | Signed change from control |
| --- | --- | --- | --- |
| `0.003879928046156` | [`-0.000000000767001502431130261464`, `-0.000000000767001502431130261463`] | [`-35.420917119457732074302392982011`, `-35.420917119457732074302392982010`] | [`-35.420917118690730571871262720547`, `-35.420917118690730571871262720546`] |
| `0.003879929046155` | [`-0.000385127316613866441054139473`, `-0.000385127316613866441054139472`] | [`-35.421302097224518221462592461237`, `-35.421302097224518221462592461236`] | [`-35.420916969907904355021538321765`, `-35.420916969907904355021538321764`] |

The control's signed histogram is exactly the comparator's, including both the 36 paid and 36 productive grade-4 deletions. These numbers describe the finite signed tariff under the inherited caller model; they do not independently prove the inherited full-bound premises. The receipt retains every full paid, productive, and signed histogram and both directed-interval prices for each schedulable graph.

## Scope and reproduction

The result covers second owners obtained by singleton XORs of two retained packet payloads in the four specified banks; at most three additional packet omissions in those banks, plus the explicitly expanded chart 515; and direct same-bank repair preserving all surviving packet payloads and terminals. It does not rule out added routes, changed retained payloads, recharting, more omissions, different second owners, another compiler, or cascades after a different first edit. No new κ bound is claimed.

Run with Python 3.12 and the standard library:

```sh
python3 -I -B verify.py
```

The verifier checks the manifest, recomputes the full receipt in a relocated temporary copy, independently rechecks signed prices with high-precision decimal arithmetic, checks actual donor/reader ordering, and rejects a corrupted target-debit receipt. The main rational directed-interval arithmetic is provided by the pinned `inputs/price.py`.

For an additional offline provenance check, supply the #7912 replay archive whose hash is in [SOURCES.json](SOURCES.json):

```sh
python3 -I -B verify.py --upstream-archive /path/to/replay.tar.gz
```

The verifier checks the archive hash and compares all packaged copied source members byte for byte. Copied material retains its upstream [LICENSE](LICENSE) and [notices](NOTICE).
