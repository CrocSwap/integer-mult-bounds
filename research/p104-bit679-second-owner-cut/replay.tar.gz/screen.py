#!/usr/bin/env python3
"""Finite direct-repair screen after specializing original owners 649 and 633/634.

Exact packet IDs are those of #7830; do not confuse them with compiled fields.
The screen preserves each surviving packet payload and terminal row. It allows
all same-bank linear stock without timing first, then checks actual scheduling
and zero/dead fixed points for the statically repairable omission sets.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import gzip,json,sys
HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(HERE/'inputs')]
import project as p, bit_native as bit, literal, price

TRIALS=('0.003879928046156','0.003879929046155')
ORIGINAL_SHA='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
CONTROL_SHA='09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be'
BANKS=(349,506,511,536); EXPANDED=(*BANKS,515)

def clean(c):return {str(k):int(v) for k,v in sorted(c.items()) if v}
def digest(value):return sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def ids(mask):return list(bit.indices(mask))
def check(condition,message):
 if not condition:raise ValueError(message)

def kernel(group,vals):
 basis={}; out=[]
 for label in sorted(group):
  v=vals[label]; subset=1<<label
  while v:
   pivot=v.bit_length()-1
   if pivot not in basis:basis[pivot]=(v,subset);break
   v^=basis[pivot][0];subset^=basis[pivot][1]
  if not v:out.append(subset)
 return len(basis),out

def inverse_use(rows):
 uses=defaultdict(set)
 for q,row in rows.items():
  for j in ids(row):uses[j].add(q)
 return uses

def evaluate(initial,final,moves,rows):
 order=bit.schedule(initial,final,moves,rows)
 vals={j:1<<j for j in initial}
 for k in order:vals[k]=bit.combine(rows[k],vals)
 for j in final:
  target=(1<<j)^((1<<(j+111)) if j<111 else 0)
  check(bit.combine(rows[~j],vals)==target,f'protected output {j}')
 cols=dict.fromkeys(moves,0)
 for j in final:
  for k in ids(rows[~j]):
   if k in moves:cols[k]^=1<<j
 for k in reversed(order):
  for q in ids(rows[k]):
   if q in moves:cols[q]^=cols[k]
 return order,vals,cols

def prune(initial,final,moves,rows):
 moves=moves.copy();rows=rows.copy();steps=[]
 while True:
  order,vals,cols=evaluate(initial,final,moves,rows)
  z={k for k in moves if not vals[k] and k!=3553}
  dead={k for k in moves if not cols[k] and k!=3553} - z
  remove=z|dead
  if not remove:break
  mask=sum(1<<k for k in remove)
  steps.append({'zero':sorted(z),'dead':sorted(dead)})
  moves={k:v for k,v in moves.items() if k not in remove}
  rows={q:r&~mask for q,r in rows.items() if q not in remove}
  check(len(steps)<10,'pruning terminates')
 return moves,rows,order,vals,cols,steps

def stock_repair(omitted,rows,uses,relations,moves):
 removed=sum(1<<k for k in omitted)
 changes={}
 affected=set().union(*(uses[k] for k in omitted))
 for q in sorted(affected):
  if q in omitted:continue
  missing=rows[q]&removed
  if not missing:continue
  chart=moves[q][0] if q>=0 else p.final[~q]
  rel=relations[chart]
  if rel is None or (rel&removed)!=missing:
   return None,{'receiver':q,'arrival_chart':chart,'missing_parents':ids(missing)}
  changes[q]=(missing,rel^missing)
 return changes,None

def build(omitted,initial,final,moves,rows,changes):
 removed=sum(1<<k for k in omitted)
 newmoves={k:v for k,v in moves.items() if k not in omitted}
 newrows={q:r&~removed for q,r in rows.items() if q not in omitted}
 for q,(_,donors) in changes.items():newrows[q]^=donors
 return newmoves,newrows

def full_price(caller,events,base_paid,base_targets,deleted,owner):
 native_paid=base_paid.copy();native_targets=base_targets.copy()
 for k in deleted:native_paid[p.grades[k]]-=1
 native_targets[p.hg[owner]]-=1
 check(min(native_paid.values())>=0 and min(native_targets.values())>=0,'nonnegative inventory')
 paid,targets=literal.paired_invoice(caller,native_paid,native_targets,events)
 baseP,baseT=literal.paired_invoice(caller,base_paid,base_targets,events)
 net=Counter(targets);net.subtract(paid)
 base=Counter(baseT);base.subtract(baseP)
 delta=Counter(net);delta.subtract(base)
 return {'native_paid':clean(native_paid),'native_targets':clean(native_targets),
         'full_paid':clean(paid),'full_targets':clean(targets),'full_signed':clean(net),
         'signed_histogram_delta_control':clean(delta),
         'trials':{t:{'signed_margin':price.decimal_interval(price.moment(net,Fraction(t)),30),
                       'signed_delta':price.decimal_interval(price.moment(delta,Fraction(t)),30)} for t in TRIALS}}

def record_stock(omitted,changes,order,moves,rows,oldorder):
 pos={k:i for i,k in enumerate(order)};oldpos={k:i for i,k in enumerate(oldorder)}
 records=[]
 for q,(missing,donors) in sorted(changes.items()):
  for d in ids(donors):check(d not in moves or pos[d]<pos[q] if q>=0 else True,'donor stock precedes reader')
  records.append({'receiver_kind':'packet' if q>=0 else 'terminal','receiver':q if q>=0 else ~q,
                  'receiver_chart':moves[q][0] if q>=0 else p.final[~q],
                  'receiver_old_schedule_index':oldpos[q] if q>=0 else None,
                  'receiver_repaired_schedule_index':pos[q] if q>=0 else None,
                  'replaced_packets':ids(missing),'donor_sources':ids(donors),
                  'donor_repaired_schedule_indices':{str(d):pos[d] if d in moves else 'initial' for d in ids(donors)}})
 return records

check(literal.canonical(p.w)==ORIGINAL_SHA,'#7830 original canonical word')
control=json.loads(gzip.decompress((HERE/'ZERO-CONTROL-WORD.json.gz').read_bytes()))
check(literal.canonical(control)==CONTROL_SHA and control['public']==679,'#7912 literal 679 control pin')
# Start by independently regenerating the exact supplied 679-owner literal word.
cx=p.project({649},keep=frozenset({3266,2926,2982}))
ci={j:c for j,c in p.initial.items() if j!=649};cf={j:c for j,c in p.final.items() if j!=649}
cm={k:p.moves[k] for k in cx['alive'] if k!=3266}
cr={k:p.orig[k]&~(1<<649)&~(1<<3266) for k in cm}
cr.update({~j:p.orig[~j]&~(1<<649)&~(1<<3266) for j in cf})
check((p.orig[3266]&~(1<<649)&~(1<<3266))==0,'nominal donor transfer is zero')
forward,frows=p.physical.dual(p.n,cm,cr)
forder=bit.schedule(cf,ci,forward,frows)
bit.basis(cf,forward,frows,forder)
check(bit.emit_word(p.w,cf,ci,forward,frows,forder)==control,'reconstructed control literal bytes')
corder,cvals,ccols=evaluate(ci,cf,cm,cr)

caller=literal.pinned(HERE/'inputs/EFREE-CALLER.json.gz',literal.CALLER_SHA)
events=Counter(e[0] for e in caller['events']);check(events['LOCAL']==36,'36 actual calls')
base_paid=Counter(p.grades[k] for k in cm);base_targets=Counter(p.hg[h] for h in ci if h>=222)
baseP,baseT=literal.paired_invoice(caller,base_paid,base_targets,events)
ref=json.loads((HERE/'inputs/BIT.json').read_text())['native']
compP={int(k):v for k,v in ref['paid'].items()};compT={int(k):v for k,v in ref['targets'].items()}
baseOrigP,baseOrigT=literal.paired_invoice(caller,Counter(p.grades[k] for k in p.moves),Counter(p.hg.values()),events)
check(clean(baseOrigP)==clean(compP) and clean(baseOrigT)==clean(compT),'#7830 complete frozen comparator invoice')
check(clean(base_paid)=={'1':1376,'2':1281,'3':54,'4':43,'5':17,'6':102},'control native paid')
check(clean(base_targets)=={'1':8,'2':9,'4':42,'5':8,'6':1,'8':389},'control native targets')
bs=Counter(baseT);bs.subtract(baseP)
orig_signed=Counter(baseOrigT);orig_signed.subtract(baseOrigP)
paid_delta=Counter(baseP);paid_delta.subtract(baseOrigP)
target_delta=Counter(baseT);target_delta.subtract(baseOrigT)
signed_delta=Counter(bs);signed_delta.subtract(orig_signed)
check(clean(paid_delta)=={'4':-36} and clean(target_delta)=={'4':-36} and not clean(signed_delta),'literal 679 control has exactly zero signed change from #7830')
base_trials={t:price.decimal_interval(price.moment(bs,Fraction(t)),30) for t in TRIALS}

# Derive all singleton XORs of two retained packet arrivals in the requested banks.
control_families=defaultdict(list)
for k,(_,b) in cm.items():control_families[b].append(k)
original_pairs=[]
control_positions={k:i for i,k in enumerate(corder)}
for b in BANKS:
 for a,d in combinations(sorted(control_families[b]),2):
  v=cvals[a]^cvals[d]
  if v and v.bit_count()==1:
   h=v.bit_length()-1
   original_pairs.append({'chart':b,'packets':[a,d],'xor_owner':h,
                          'owner_eligible':222<=h<680 and h not in {411,649},
                          'payload_xor_hex':hex(v),'grades':[p.grades[a],p.grades[d]],
                          'adjoint_routes':[list(cm[a]),list(cm[d])],
                          'original_7830_forward_clocks':[p.clocks[a],p.clocks[d]],
                          '679_control_adjoint_schedule_indices':[control_positions[a],control_positions[d]],
                          '649_projected_payload_supports':[ids(cvals[a]),ids(cvals[d])]})
check([(x['chart'],x['packets'],x['xor_owner']) for x in original_pairs]==[(506,[2283,2284],633),(506,[2287,3387],634)],'complete exact singleton packet pair census')
check(cvals[2937]^cvals[2938]==1<<633,'additional chart-515 singleton relation')

results=[]
for owner in (633,634):
 S={649,owner};x=p.project(S)
 initial={j:c for j,c in p.initial.items() if j not in S};final={j:c for j,c in p.final.items() if j not in S}
 auto=set(ids(x['erased']));mask=sum(1<<j for j in S|auto)
 moves={k:p.moves[k] for k in x['alive']}; rows={k:p.orig[k]&~mask for k in moves}
 rows.update({~j:p.orig[~j]&~mask for j in final})
 oldorder,vals,cols=evaluate(initial,final,moves,rows)
 check(vals==x['values'],'specialized payloads match projection')
 check(len(initial)==678 and 411 in initial and 3553 in moves,'all 678 owners and 411 bridge packet')
 check(moves[3553]==(1,509) and rows[3553]==1<<411 and vals[3553]==1<<411,'original 411 bridge route, sender row and pulse')
 check(auto==({3266} if owner==633 else {3122,3266}),'automatic pruning')
 groups=defaultdict(list)
 for j,c in initial.items():groups[c].append(j)
 for k,(_,c) in moves.items():groups[c].append(k)
 global_deps=[]
 for chart,group in sorted(groups.items()):
  rank,kern=kernel(group,vals)
  if kern:global_deps.append({'chart':chart,'family_size':len(group),'rank':rank,'kernel_basis':[ids(k) for k in kern]})
 expected_global=([{'chart':506,'family_size':18,'rank':17,'kernel_basis':[[2283,2284]]},
                   {'chart':515,'family_size':3,'rank':2,'kernel_basis':[[2937,2938]]}] if owner==633 else
                  [{'chart':506,'family_size':18,'rank':17,'kernel_basis':[[2287,3387]]}])
 check(global_deps==expected_global,'all retained cocharted input families independently ranked')
 relations={};bank_entries=[]
 for b in EXPANDED:
  group=sorted(groups[b]);rank,kern=kernel(group,vals)
  check(len(kern)<=1,'at most one independent family relation')
  relations[b]=kern[0] if kern else None
  bank_entries.append({'chart':b,'public_sources':[j for j in group if j in initial],
                       'retained_packet_sources':[j for j in group if j in moves],
                       'family_size':len(group),'rank':rank,'kernel_basis':[ids(k) for k in kern]})
 uses=inverse_use(rows)
 pool=sorted(k for k,(_,b) in moves.items() if b in EXPANDED)
 primary=set(k for k in pool if moves[k][1] in BANKS)
 stats={x:Counter() for x in ('requested_four_banks','expanded_five_banks')}
 qualified=[]; static_counts=Counter();first_failure=Counter()
 for n in range(0,4):
  for candidate in combinations(pool,n):
   charts={moves[k][1] for k in candidate};C=set(candidate);is_primary=C<=primary
   assert charts<=set(EXPANDED)
   changes,why=stock_repair(C,rows,uses,relations,moves)
   scopes=['expanded_five_banks']+(['requested_four_banks'] if is_primary else [])
   for scope in scopes:stats[scope]['tested']+=1
   if changes is None:
    for scope in scopes:stats[scope]['unrepresentable_even_with_free_all_time_stock']+=1
    first_failure[str(why['arrival_chart'])]+=1
    continue
   for scope in scopes:stats[scope]['static_repairable']+=1
   m,r=build(C,initial,final,moves,rows,changes)
   try:order,v,c=evaluate(initial,final,m,r)
   except ValueError as ex:
    if 'causal binary packet schedule' not in str(ex):raise
    for scope in scopes:stats[scope]['schedule_cycle']+=1
    qualified.append({'omitted':list(candidate),'scope':'requested' if is_primary else 'expanded',
                      'disposition':'CYCLE','reason':str(ex)})
    continue
   check(all(v[k]==vals[k] for k in m),'all surviving original packet payloads retained')
   stock=record_stock(C,changes,order,m,rows,oldorder)
   m,r,po,pv,pc,pruning=prune(initial,final,m,r)
   additional=set(moves)-set(m)
   check(C<=additional and 3553 in m,'retained original bridge after optional pruning')
   check(m[3553]==(1,509) and r[3553]==1<<411 and pv[3553]==1<<411,'retained pure 411 bridge after repairs')
   for scope in scopes:stats[scope]['scheduled_and_endpoint_exact']+=1
   paid_deleted=additional|(auto-{3266})
   invoice=full_price(caller,events,base_paid,base_targets,paid_deleted,owner)
   check(all(price.moment({int(k):v for k,v in invoice['signed_histogram_delta_control'].items()},Fraction(t))[1]<0 for t in TRIALS),'expected strictly negative signed outcome')
   qualified.append({'omitted':list(candidate),'scope':'requested' if is_primary else 'expanded',
                     'disposition':'EXECUTABLE_PACKET_GRAPH_NEGATIVE',
                     'repair_sites':len(changes),'stock':stock,'post_repair_pruning':pruning,
                     'additional_pruned_paid_packets':sorted(additional-C),
                     'all_paid_deleted_from_679_control':sorted(paid_deleted),
                     'paid_grades_deleted_from_control':clean(Counter(p.grades[k] for k in paid_deleted)),
                     'surviving_packets':len(m),'surviving_owners':len(initial),
                     'all_678_protected_adjoint_rows_pass':True,
                     'all_surviving_payloads_preserved_before_dead_prune':True,
                     'owner_411_and_original_packet_3553_retained':True,
                     'invoice':invoice})
 # Graph-control: dropping one live alias without donor must break a protected endpoint.
 alias=2284 if owner==633 else 3387
 no_changes={};m,r=build({alias},initial,final,moves,rows,no_changes)
 try:evaluate(initial,final,m,r)
 except ValueError as ex:check('protected output' in str(ex),'missing-donor fails an endpoint');bad=str(ex)
 else:raise ValueError('missing-donor control falsely accepted')
 results.append({'second_surrendered_original_owner':owner,'surrendered_owner_grade':p.hg[owner],
                 'remaining_original_owner_roster':sorted(initial),
                 'original_owner_411_retained':411 in initial,'original_packet_3553_retained':3553 in moves,
                 'auto_pruned_after_second_surrender':[{'packet':k,'route':list(p.moves[k]),'grade':p.grades[k]} for k in sorted(auto-{3266})],
                 'bank_families':bank_entries,'all_arrival_family_count':len(groups),
                 'all_arrival_family_source_count':sum(map(len,groups.values())),
                 'all_arrival_families_with_nonzero_kernel':global_deps,
                 'screen_pool_requested':sorted(primary),
                 'screen_pool_expanded':pool,'enumeration':{s:dict(v) for s,v in stats.items()},
                 'unrepresentable_first_obstruction_bank_counts_expanded':dict(sorted(first_failure.items())),
                 'candidates':qualified,'missing_alias_repair_control':bad})

result={'schema':'p104-bit679-second-owner-payload-repair-screen/1',
        'status':'PASS_BOUNDED_DIRECT_REPAIR_SCREEN_NO_POSITIVE_SIGNED_GAIN',
        'scope':'The 679-owner literal control, a single second surrender among owners whose unit is the XOR of two retained adjoint packet values in arrival charts 349/506/511/536, then <=3 additional paid omissions in those banks; an extra screen also includes chart 515. Free arbitrary all-time same-bank stock is used for the necessary representation test. Successful rewrites preserve every surviving original packet value and output, are topologically scheduled, then have zero/dead packets pruned. No rechart, added routes, changed retained payload, different compiler, larger omission set or later edit cascade is excluded.',
        'source_pr_7912_head':'83ece5a62d3addbee45bad9594ef4809851b833b',
        'baseline_pr_7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
        'control_canonical_sha256':CONTROL_SHA,'control_reconstructed_byte_exact':True,
        'control_original_owners':sorted(ci),'control_original_packet_3266_omitted':True,
        'control_owner_411_and_packet_3553_retained':411 in ci and 3553 in cm,
        'control_native_paid':clean(base_paid),'control_native_targets':clean(base_targets),
        'control_full_paid':clean(baseP),'control_full_targets':clean(baseT),
        'control_paid_delta_from_7830':clean(paid_delta),'control_target_delta_from_7830':clean(target_delta),
        'control_signed_histogram_delta_from_7830':clean(signed_delta),
        'control_full_signed_margin':base_trials,'native_calls':events['LOCAL'],
        'requested_bank_packet_rosters':{str(b):sorted(control_families[b]) for b in BANKS},
        'requested_packet_pairs_examined':sum(len(control_families[b])*(len(control_families[b])-1)//2 for b in BANKS),
        'all_pair_singleton_relations_in_requested_banks':original_pairs,
        'additional_chart_515_pair':{'packets':[2937,2938],'xor_owner':633,'grades':[p.grades[2937],p.grades[2938]],
            'adjoint_routes':[list(cm[2937]),list(cm[2938])],
            'original_7830_forward_clocks':[p.clocks[2937],p.clocks[2938]],
            '679_control_adjoint_schedule_indices':[control_positions[2937],control_positions[2938]],
            '649_projected_payload_supports':[ids(cvals[2937]),ids(cvals[2938])]},
        'trials':list(TRIALS),'results':results}
text=json.dumps(result,indent=2,sort_keys=True)+'\n'
if '--emit' in sys.argv:(HERE/'RESULT.json').write_text(text)
else:check((HERE/'RESULT.json').read_text()==text,'receipt deterministic')
print('PASS exact 679 literal reconstruction; 678-owner packet graphs; exhaustive direct-repair screening; complete 36-call signed prices')
for r in results:
 print('owner',r['second_surrendered_original_owner'],'stats',json.dumps(r['enumeration'],sort_keys=True),'candidate_count',len(r['candidates']))
 for c in r['candidates']:
  print(c['omitted'],c['disposition'],c.get('all_paid_deleted_from_679_control'),c.get('invoice',{}).get('signed_histogram_delta_control'))
