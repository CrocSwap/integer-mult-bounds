#!/usr/bin/env python3
"""Check pins, relocate/recompute the receipt, and independently recount prices."""
from collections import Counter
from decimal import Decimal,localcontext
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse,json,shutil,subprocess,sys,tarfile

H=Path(__file__).resolve().parent
UPSTREAM_SHA='87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096'
def need(x,message):
 if not x:raise ValueError(message)
def manifest(root):
 seen=set()
 for line in (root/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1)
  need(not name.startswith('/') and '..' not in Path(name).parts and name not in seen,'safe unique manifest path')
  seen.add(name);need(sha256((root/name).read_bytes()).hexdigest()==expected,'manifest '+name)
 need({'README.md','screen.py','RESULT.json','verify.py','project.py','ZERO-CONTROL-WORD.json.gz','inputs/WORD.json.gz'}<=seen,'essential manifest entries')

def hist(x):return Counter({int(k):int(v) for k,v in x.items() if v})
def numeric_moment(h,k):
 with localcontext() as ctx:
  ctx.prec=90
  return sum((Decimal(v)*(Decimal(g).ln()*(Decimal(1)-Decimal(k))).exp() for g,v in h.items()),Decimal(0))
def inside(v,interval):return Decimal(interval[0])<=v<=Decimal(interval[1])

def crosscheck(doc):
 base_paid=hist(doc['control_full_paid']);base_targets=hist(doc['control_full_targets'])
 base_signed=base_targets.copy();base_signed.subtract(base_paid)
 need(doc['native_calls']==36 and doc['requested_packet_pairs_examined']==129,'control count')
 for pair in doc['all_pair_singleton_relations_in_requested_banks']:
  a,b=[sum(1<<int(j) for j in support) for support in pair['649_projected_payload_supports']]
  need(a^b==1<<pair['xor_owner'],'singleton relation independently reconstituted from stored supports')
 pair=doc['additional_chart_515_pair']
 a,b=[sum(1<<int(j) for j in support) for support in pair['649_projected_payload_supports']]
 need(a^b==1<<633,'additional chart-515 relation')
 for t,interval in doc['control_full_signed_margin'].items():
  need(inside(numeric_moment(base_signed,t),interval),'decimal cross-check of full control signed price')
 for result in doc['results']:
  owner=result['second_surrendered_original_owner']
  need(result['remaining_original_owner_roster']==[j for j in range(680) if j not in {649,owner}], 'exact original owner roster')
  need(411 in result['remaining_original_owner_roster'] and result['original_packet_3553_retained'],'retained bridge')
  for c in result['candidates']:
   if c['disposition']=='CYCLE':continue
   invoice=c['invoice'];pa=hist(invoice['full_paid']);ta=hist(invoice['full_targets'])
   paid_expected=base_paid.copy()
   for grade,count in hist(c['paid_grades_deleted_from_control']).items():paid_expected[grade]-=36*count
   target_expected=base_targets.copy();target_expected[4]-=36
   need(pa==paid_expected and ta==target_expected,'complete 36-call paid and target recount')
   net=ta.copy();net.subtract(pa);delta=net.copy();delta.subtract(base_signed)
   need(hist(invoice['full_signed'])==net and hist(invoice['signed_histogram_delta_control'])==delta,'signed inventory')
   for t,v in invoice['trials'].items():
    need(inside(numeric_moment(net,t),v['signed_margin']) and inside(numeric_moment(delta,t),v['signed_delta']),'independent decimal full and delta price')
    need(Decimal(v['signed_delta'][1])<0,'strictly negative price')
   for site in c['stock']:
    if site['receiver_kind']=='packet':
     for d,pos in site['donor_repaired_schedule_indices'].items():
      need(pos=='initial' or int(pos)<site['receiver_repaired_schedule_index'],'actual donor before reader')

parser=argparse.ArgumentParser();parser.add_argument('--upstream-archive',type=Path);args=parser.parse_args()
manifest(H);doc=json.loads((H/'RESULT.json').read_text());crosscheck(doc)
if args.upstream_archive:
 need(sha256(args.upstream_archive.read_bytes()).hexdigest()==UPSTREAM_SHA,'#7912 upstream archive sha256')
 with tarfile.open(args.upstream_archive,'r:gz') as f:
  members={m.name.removeprefix('./'):m for m in f.getmembers() if m.isfile()}
  for name in ['ZERO-CONTROL-WORD.json.gz','project.py',*[str(p.relative_to(H)) for p in (H/'inputs').iterdir() if p.is_file()]]:
   need(name in members and f.extractfile(members[name]).read()==(H/name).read_bytes(),'original #7912 member '+name)
 print('PASS exact upstream #7912 archive digest and copied member bytes')
with TemporaryDirectory(prefix='p104-second-relation-') as tmp:
 copy=Path(tmp)/'screen';shutil.copytree(H,copy,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 run=subprocess.run([sys.executable,'-I','-B',str(copy/'screen.py')],cwd=copy,capture_output=True,text=True)
 need(run.returncode==0,'relocated deterministic replay: '+run.stderr[-1000:])
 bad=json.loads((copy/'RESULT.json').read_text());bad['results'][0]['candidates'][0]['invoice']['full_targets']['4']+=36
 (copy/'RESULT.json').write_text(json.dumps(bad))
 try:crosscheck(bad)
 except ValueError:pass
 else:raise ValueError('independent price recount accepted the corrupted debit')
 run=subprocess.run([sys.executable,'-I','-B',str(copy/'screen.py')],cwd=copy,capture_output=True,text=True)
 need(run.returncode!=0 and 'receipt deterministic' in run.stderr,'corrupted productive debit rejected')
manifest(H)
print('PASS manifest, relocated recomputation, decimal prices, timed donor stock and corrupted-debit rejection')
