#!/usr/bin/env python3
"""Enumerate paid-atlas bank pairs and genuinely new rational join/meet bridges.

The literal source is a paid grade-7 chart for each frozen return.  Two
distinct existing banks have dimension 1, 2 or 4.  One new, empty bridge is
exactly the rational sum or intersection of the two bank subspaces.  A bridge
is kept only when it is absent from all 636 paid atlas charts and the two
bridge incidences have positive grade.  Each source must have a proper
nested first leg to at least one of (bank A, bank B, bridge).  A route may
travel either direction across a bridge incidence and may finish from any
of these three charts to zero.  This is a finite, explicit subfamily; other
new charts, bank dimensions, shifted sources and exterior rewrites are open.

Each basis is canonical rational RREF; dimension difference is the rank
tariff on each positive nested incidence.  Row inclusion in exact rational
RREF is equivalent to the R5/09 test PQ=P (orthogonal projectors).  No
stock, actual first reads, legal candidate, or complete invoice is asserted
by the geometry enumeration alone.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import gzip,hashlib,json,sys,time
HERE=Path(__file__).resolve().parent
blob=(HERE/'source/BIT-WORD.json.gz').read_bytes()
assert hashlib.sha256(blob).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(blob));F={int(k):v for k,v in w['frames'].items()};D=8

def rref(raw):
    a=[[Q(x) for x in row] for row in raw];i=0
    for j in range(D):
        p=next((k for k in range(i,len(a)) if a[k][j]),None)
        if p is None:continue
        a[i],a[p]=a[p],a[i];den=a[i][j]
        a[i]=[x/den for x in a[i]]
        for k in range(len(a)):
            if k!=i and a[k][j]:
                f=a[k][j];a[k]=[x-f*y for x,y in zip(a[k],a[i])]
        i+=1
        if i==len(a):break
    return tuple(tuple(x for x in row) for row in a[:i])

def nullspace(raw):
    a=rref(raw);pivots=[next(j for j,x in enumerate(row) if x) for row in a]
    free=[j for j in range(D) if j not in pivots];rows=[]
    for f in free:
        x=[Q(0)]*D;x[f]=1
        for i,p in enumerate(pivots):x[p]=-a[i][f]
        rows.append(x)
    return rref(rows)

atlas={rref(v['B']):k for k,v in F.items()}
assert len(atlas)==636
bases={c:rref(f['B']) for c,f in F.items()}
duals={c:rref(f['A']) for c,f in F.items()}
assert all(len(bases[c])==f['dim'] and len(duals[c])+len(bases[c])==8 for c,f in F.items())
paid={c for op,*a in w['program'] if op=='MOVE' for c in a[1:]}
assert paid==set(F)
roster=[c for c in sorted(F) if F[c]['dim'] in (1,2,4)]
assert len(roster)==334
src={2:511,6:515,7:516}
def contained(body,annihilator):
    return all(not sum(x*y for x,y in zip(u,z)) for u in body for z in annihilator)
def sub(c,parent):return contained(bases[c],duals[parent])
def reduced(x):return [[str(q) for q in row] for row in x]
elig={c:{g:7-F[c]['dim'] for g,p in src.items() if sub(c,p)} for c in roster}
assert all(v>0 for d in elig.values() for v in d.values())
counts=Counter();bridge_ids={};bridges=[];edges=[]
began=time.monotonic()
for ia,(a,b) in enumerate(combinations(roster,2)):
    counts['bank_pairs']+=1
    # If the banks are nested, their sum/meet already exists in the atlas.
    if len(bases[a])<=len(bases[b]) and sub(a,b) or len(bases[b])<=len(bases[a]) and sub(b,a):
        counts['nested_bank_pairs']+=1;continue
    for name,cbody in (('join',rref(bases[a]+bases[b])),('meet',nullspace(duals[a]+duals[b]))):
        counts[name+'_considered']+=1
        if cbody in atlas:
            counts[name+'_atlas']+=1;continue
        d=len(cbody);da=len(bases[a]);db=len(bases[b])
        if not d or d in (da,db):
            counts[name+'_zero_grade']+=1;continue
        assert name=='join' and d>max(da,db) or name=='meet' and d<min(da,db)
        csrc={g:7-d for g,p in src.items() if 0<d<7 and contained(cbody,duals[p])}
        feed={g:[('A',elig[a][g]) for _ in [0] if g in elig[a]]+
                [('B',elig[b][g]) for _ in [0] if g in elig[b]]+
                [('C',csrc[g]) for _ in [0] if g in csrc] for g in src}
        if any(not feed[g] for g in src):
            counts[name+'_not_source_covered']+=1;continue
        if cbody not in bridge_ids:
            bridge_ids[cbody]=len(bridges);bridges.append({'id':len(bridges),'dimension':d,'rref_basis':reduced(cbody),'source_grades':csrc})
        cid=bridge_ids[cbody]
        edge={'A':a,'B':b,'C':cid,'operation':name,'dimensions':[da,db,d],
              'first_ingress_grades':feed,'A_C_grade':abs(da-d),'C_B_grade':abs(db-d),
              'final_to_zero_grades':{'A':da,'B':db,'C':d}}
        edges.append(edge);counts[name+'_eligible']+=1
    if ia and ia%10000==0:print('processed',ia,'time',round(time.monotonic()-began,1),flush=True)

out={'description':__doc__,'word_sha256':hashlib.sha256(blob).hexdigest(),'counts':dict(counts),
     'bridge_count':len(bridges),'bridge_dimension_counts':dict(Counter(str(b['dimension']) for b in bridges)),
     'edge_records':len(edges),'eligible_operation_counts':dict(Counter(e['operation'] for e in edges)),
     'incidence_grade_counts':{'A_C':dict(Counter(str(e['A_C_grade']) for e in edges)),'C_B':dict(Counter(str(e['C_B_grade']) for e in edges))},
     'bridges':bridges,'edges':edges}
raw=(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n').encode()
with (HERE/'GEOMETRY.json.gz').open('wb') as f:
    with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(raw)
summary={k:out[k] for k in ('counts','bridge_count','bridge_dimension_counts','edge_records','eligible_operation_counts','incidence_grade_counts')}
(HERE/'GEOMETRY-SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2,sort_keys=True),'elapsed',round(time.monotonic()-began,1),flush=True)
