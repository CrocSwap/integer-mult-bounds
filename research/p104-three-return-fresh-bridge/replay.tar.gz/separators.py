#!/usr/bin/env python3
"""Generate and pool explicit 680-bit separating assignments for all pairs."""
from itertools import combinations
from pathlib import Path
import gzip,json,time,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import stock_probe as q
HERE=Path(__file__).resolve().parent
start=time.monotonic();pool={};vectors=[];rows=[];passes=[]
for index,(x,y) in enumerate(combinations(q.roster,2)):
    ids=[]
    for g in q.tri:
        b=q.v.binary_basis(q.cached[g][x]+q.cached[g][y]);rem=q.v.reduce_binary(q.tar[g],b)
        if not rem:
            ids.append(-1);passes.append([g,x,y]);continue
        # A dual annihilator for quotient rows.  Lift it to the original
        # 680-coordinate space by eliminating pairings with base pivots.
        z=1<<(rem.bit_length()-1)
        for pivot in sorted(b):
            if (b[pivot]&z).bit_count()&1:z^=1<<pivot
        for pivot in sorted(q.bases[g]):
            if (q.bases[g][pivot]&z).bit_count()&1:z^=1<<pivot
        assert all(not ((v&z).bit_count()&1) for v in q.bases[g].values())
        assert all(not ((v&z).bit_count()&1) for v in q.cached[g][x]+q.cached[g][y])
        assert (q.targets[g]&z).bit_count()&1
        if z not in pool:
            pool[z]=len(vectors);vectors.append(hex(z))
        ids.append(pool[z])
    rows.append([x,y,*ids])
    if index and index%10000==0:print('separators',index,'pooled',len(vectors),'seconds',round(time.monotonic()-start,1),flush=True)
out={'word_sha256':q.v.WORD_SHA,'triple':q.tri,'description':'Rows [bank A, bank B, witness for return 2, return 6, return 7]; -1 means span pass; each other entry indexes the pooled 680-owner assignment in hexadecimal.',
     'vectors':vectors,'pairs':rows,'passes':passes}
with (HERE/'SEPARATORS.json.gz').open('wb') as f:
    with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write((json.dumps(out,separators=(',',':'))+'\n').encode())
print('pair rows',len(rows),'pooled assignments',len(vectors),'passes',passes,'seconds',round(time.monotonic()-start,1),flush=True)
