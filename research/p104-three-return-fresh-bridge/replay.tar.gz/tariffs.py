#!/usr/bin/env python3
"""Complete optimistic binary-caller prices for the saved bridge geometry.

For each placement, take one independently cheapest valid source ingress per
return; grant free access to all three banks for each delivery; charge both
bridge edges once; take the cheapest delivery for each return; and grant every
reader restoration, local operation and other alteration for free. Exactly
the nine original return moves are removed, every other binary-caller baseline
histogram entry is held fixed, and all 36 calls are charged. The rational side
is unchanged. This is a price-only upper bound for that declared two-added-
bridge accounting, not a realizable invoice; the explicit stock-cut model
rules out all of these placements.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import gzip,hashlib,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'pricing_source'))
import target_exact as arith
assert hashlib.sha256((HERE/'pricing_source/target_exact.py').read_bytes()).hexdigest()=='8e06b109926b471cdb887fe3fbc631cc71a69a17aadf1a818fa238b8e1dd9bce'
doc=json.loads(gzip.decompress((HERE/'GEOMETRY.json.gz').read_bytes()))
base=json.loads((HERE/'source/expected/BASELINE-CHECK.json').read_text())
paid=Counter({int(k):v for k,v in base['caller_paid_ranks'].items()});prod=Counter({int(k):v for k,v in base['caller_productive_ranks'].items()})
old=Counter({1:6,5:3})
best={};tariff_tables={};rates=('0.003879928046156','0.003879929046155')
for rate in rates:
    ex=1-Fraction(rate);tariff_tables[rate]={str(g):arith.interval_output(arith.rank_power(g,ex)) for g in range(1,9)}
    optimum=None
    for edge in doc['edges']:
        outg=min(edge['final_to_zero_grades'].values())
        grades=[min(grade for _,grade in edge['first_ingress_grades'][str(g)]) for g in (2,6,7)]
        grades += [edge['A_C_grade'],edge['C_B_grade'],outg,outg,outg]
        changed=paid.copy();changed.subtract({r:36*n for r,n in old.items()});changed.update({r:36*n for r,n in Counter(grades).items()})
        assert all(v>=0 for v in changed.values())
        interval=arith.signed(changed,prod,rate)
        if optimum is None or interval[1]>optimum[0][1]:optimum=(interval,edge,grades,changed)
    interval,edge,grades,changed=optimum
    corrupted=changed.copy();corrupted[1]+=1
    bad=arith.signed(corrupted,prod,rate)
    assert bad[1]<interval[0]
    best[rate]={'baseline_full_margin':arith.interval_output(arith.signed(paid,prod,rate)),
       'optimistic_full_margin':arith.interval_output(interval),'placement':{k:edge[k] for k in ('A','B','C','operation','dimensions')},
       'charged_new_grades':grades,'complete_paid_histogram':dict(sorted(changed.items())),
       'complete_productive_histogram':dict(sorted(prod.items())),
       'unaccounted_grade_one_corruption_rejected':True}
    assert interval[0]>0
out={'description':__doc__,'engine':'exact rational atanh logarithms and directed fixed point exponential','native_calls':36,
     'tariff_intervals_by_grade':tariff_tables,'best_price_only_upper_bounds':best}
(HERE/'TARIFFS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({'source_fed_placements':len(doc['edges']),'best_price_only_upper_bounds':{k:{'full_margin':v['optimistic_full_margin'],'placement':v['placement'],'grades':v['charged_new_grades']} for k,v in best.items()}},indent=2,sort_keys=True))
