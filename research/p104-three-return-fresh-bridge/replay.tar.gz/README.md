# Three BIT returns with a fresh cross-bank bridge

This is an **exact finite stock-cut certificate**, not a new literal word, a
κ improvement, or a general impossibility theorem. It extends the fixed-atlas
two-relay screen in [#7938 at `63d2210f15fd288ad6ed535ddca6c28826d05a97`](https://github.com/CrocSwap/integer-mult-bounds/pull/7938)
and the rank-21 triple of [#7921 at `7962491529f871300f02bb5b7e3abfc0333bc8c8`](https://github.com/CrocSwap/integer-mult-bounds/pull/7921).
The native baseline is [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830).
The inherited source manifest matches the one in the #7938 replay package,
whose SHA-256 is `1222e5bbd3c9aa2ba88d6f0adafcf579661951fc16d6535f3b1b4077535d384d`.
The native word compressed SHA-256 is
`d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

## New finite geometry

Take two distinct original paid atlas charts `A` and `B`, each of dimension
1, 2, or 4, and one initially empty new chart `C`. Define `C` to be exactly
the rational sum `A+B` or intersection `A∩B`; both operands occur on actual
paid contacts. Exclude `C` if it matches any of the 636 atlas frames or if
either incident movement `A↔C` or `C↔B` has zero grade. For each of the
three original grade-7 senders, require a positive-grade proper nested first
leg to at least one of `A`, `B`, or `C`. Each of these three frames can deliver
to chart 0. This includes nonnested `A,B` pairs joined by the fresh frame and
allows the source to feed `C` directly. It is a distinct family from #7938's
nested atlas pairs.

Enumerating all 55,611 pairs yields **13,297 source-fed placements**: 13,087
sums and 210 intersections. They use **9,424 distinct non-atlas frames** of
dimensions 1, 2, 3, 4, 5, and 6. `GEOMETRY.json.gz` lists every placement,
the canonical rational basis of its new frame, every allowed source ingress
grade, both bridge grades, and all three delivery grades. `geometry.py`
generates the roster from the raw atlas. `verify_projectors.py` separately
constructs all 9,424 exact rational orthogonal projectors, checks symmetry,
idempotence, trace and non-membership in the atlas, checks **26,594** 8×8
projector products on the bridge incidences, and independently checks all
**60,923** admissible source incidences and **39,891** delivery grades. It
checks the sum/intersection dimensions by fraction-free integer rank. The
nesting criterion is the same `PQ=P` or `PQ=Q` test used in the Round 5
three-node projector work. A corrupted projector and a corrupted grade are
rejected.

## Exact first reads and stock cut

The original zero-based returns are `(2,6,7)`. The three selected receipt
moves of each path and their actual first reads in the pinned program are:

| Return | Source move → first reader | Middle move → first reader | Final move → first reader |
| --- | --- | --- | --- |
| 2 | `10302 → 11482` | `11483 → 11487` | `11488 → 11611` |
| 6 | `10342 → 13059` | `13060 → 13064` | `13065 → 13241` |
| 7 | `10352 → 15591` | `15592 → 15596` | `15597 → 15767` |

The cut asks for each original 680-owner final row to be recoverable in
chart 0 by its **first reader**, a later allowance than the old final MOVE.
It makes deliberately generous grants at each such time:

* all three complete sender banks at their original first clocks, regardless
  of how many source scalars could actually be sent;
* every historic row at `A`, `B`, and chart 0 available by that first read
  whose original dependence tags use only earlier completed selected paths;
* all earlier target rows, free retention, and unlimited free exchanges among
  the banks and the new frame.

Rows with dependence on the current or a later selected receipt are excluded
from these original-history grants. Earlier selected-path rows are free gifts,
not a proof that a changed word reproduces them. No repair of the earlier
source or middle readers is charged or required in this test. The fresh
bridge starts empty and brings no old stock. The resulting cut is intentionally
stronger than testing only the above geometry: it examines **all 55,611**
unordered pairs of the 334 dimension-1/2/4 banks, with no nesting,
source-coverage, price, or exchange-time restriction.

| Return | Actual first reader | Pairs spanning its final row under all grants |
| --- | ---: | ---: |
| 2 | 11611 | 0 / 55,611 |
| 6 | 13241 | 0 / 55,611 |
| 7 | 15767 | 1 / 55,611 |

Therefore no declared placement passes all three cuts. The lone return-7
positive span is banks `(506,507)`; it has no source-fed new sum/intersection
placement in the above roster. `PASS-7-CONTROL.json` contains and directly
replays an XOR expression for that span, with a corrupted expression rejected.
The source-plus-zero-plus-prior-target base has ranks 532, 536, and 537 at
the respective first reads. These are full 680-coordinate checks, not merely
the 111 live-input projection. Because the stock cut never tests the geometry
of `C`, it applies equally to any genuinely new initially empty frame whose
only incoming information is confined to the three sender banks and the two
admitted atlas/zero histories described above.

`SEPARATORS.json.gz` gives **166,832** explicit dual checks, pooling 327
binary owner assignments, for every failing pair and return. Independently,
`verify_stock.py` replays the word with set-valued receipt tags and checks
each saved separator by direct parity against the actual original rows; it
does not import the generating elimination. It also replays the positive XOR
and rejects a changed separator. The original forward and adjoint maps,
owner-411 bridge and omission control are checked by the pinned baseline
engine. The original caller and supplier are replayed separately. None of
these is a replay of a changed candidate.

The cut's limits matter. It does **not** rule out a construction that obtains
new bank or empty-chart stock through changed current/future receipt-dependent
exterior descendants, changes the source clocks, uses a third original bank,
uses bank dimensions other than 1/2/4, supplies the fresh frame from other
exterior banks, or changes which original output row is required at the named
reader. Such a construction needs its own causal stock,
restoration, protected-output, adjoint and complete price checks.

## Tariff diagnostics

`TARIFFS.json` encloses `H(r)=r^(1−κ)` for grades 1 through 8 at both
requested decimal rates using exact rational logarithm bounds and directed
fixed-point exponentiation. The full binary caller's baseline margins are
approximately `−0.00000000076700150243` at `0.003879928046156` and
`−0.00038512731661386644` at `0.003879929046155`.

For an optimistic **price-only** comparison, remove the nine old returns,
charge the independently cheapest eligible ingress for each return, charge
both `A↔C` and `C↔B` once, and charge three cheapest deliveries. Give access
to every bank and all reader restoration for free; keep all other binary
caller bins and all 36 native calls. The greatest directed upper bounds over
the geometry roster are `+249.991053003491` and `+249.990667361128`,
respectively. These positive upper bounds are **not attained prices**; the
stock cut rejects the corresponding declared candidates, and the rational
side is unchanged. They do show that this relaxed tariff screen alone cannot
reject the cross-bank family. An unaccounted extra grade-1 charge is detected.

## Replay

Python 3.10+ and the standard library are sufficient. Run:

```sh
python3 -I -B verify_all.py
```

The wrapper uses a temporary directory **inside this directory**, regenerates
the geometry and all separators, runs the independent projector, stock and
baseline checks, reprices the diagnostics, and byte-compares every saved
receipt. `source/` and `pricing_source/` retain the predecessor notices,
licenses and source pins. The work was prepared with OpenAI Codex assistance.
