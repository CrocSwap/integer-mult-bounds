#!/usr/bin/env python3
"""Independent exact rational 8x8 projector and incident-grade verification.

For each saved new frame, integer Gram-Schmidt creates P=N/D and checks
P²=P, symmetry and trace.  Every bridge/bank projector product is checked,
and every saved source eligibility and grade is independently reconstructed.
The span/meet condition is checked using fraction-free integer rank.
"""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from math import gcd,lcm
from pathlib import Path
import gzip,hashlib,json,time
HERE=Path(__file__).resolve().parent
began=time.monotonic();raw=(HERE/'source/BIT-WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));doc=json.loads(gzip.decompress((HERE/'GEOMETRY.json.gz').read_bytes()));F={int(k):x for k,x in w['frames'].items()}
assert doc['word_sha256']==hashlib.sha256(raw).hexdigest()
def integral(row):
    row=[Fraction(x) for x in row];den=lcm(*(x.denominator for x in row));u=[int(x*den) for x in row]
    g=gcd(*u)
    if g:u=[x//g for x in u]
    return tuple(u)
def dot(x,y):return sum(a*b for a,b in zip(x,y))
def make_projector(body):
    orth=[]
    for row in body:
        u=integral(row)
        for v in orth:
            d=dot(v,v);t=dot(u,v);u=tuple(d*a-t*b for a,b in zip(u,v));g=gcd(*u)
            if g:u=tuple(x//g for x in u)
        assert dot(u,u)>0 and all(dot(u,v)==0 for v in orth)
        orth.append(u)
    norms=[dot(u,u) for u in orth];den=lcm(*norms) if norms else 1
    m=tuple(tuple(sum((den//n)*u[i]*u[j] for n,u in zip(norms,orth)) for j in range(8)) for i in range(8))
    common=gcd(den,*(x for row in m for x in row))
    den//=common;m=tuple(tuple(x//common for x in row) for row in m)
    assert all(m[i][j]==m[j][i] for i in range(8) for j in range(8))
    assert sum(m[i][i] for i in range(8))==den*len(body)
    assert all(sum(m[i][k]*m[k][j] for k in range(8))==den*m[i][j] for i in range(8) for j in range(8))
    return m,den
def product_equals_small(small,large):
    (a,da),(b,db)=small,large
    return all(sum(a[i][k]*b[k][j] for k in range(8))==db*a[i][j] for i in range(8) for j in range(8))
def belongs(row,p):
    u=integral(row);m,den=p
    return all(sum(m[i][j]*u[j] for j in range(8))==den*u[i] for i in range(8))
def rank(rows):
    a=[list(integral(r)) for r in rows];i=0
    for j in range(8):
        p=next((k for k in range(i,len(a)) if a[k][j]),None)
        if p is None:continue
        a[i],a[p]=a[p],a[i]
        for k in range(i+1,len(a)):
            if a[k][j]:
                x,y=a[i][j],a[k][j];a[k]=[x*s-y*t for s,t in zip(a[k],a[i])];g=gcd(*a[k])
                if g:a[k]=[v//g for v in a[k]]
        i+=1
        if i==len(a):break
    return i

bp={c:make_projector(f['B']) for c,f in F.items() if f['dim'] in (1,2,4) or c in (511,515,516)}
src={2:511,6:515,7:516};roster=set(bp)-set(src.values());assert len(roster)==334
ap={c:tuple(all(belongs(r,bp[src[g]]) for r in F[c]['B']) for g in src) for c in roster}
bridges=doc['bridges'];assert len(bridges)==9424
new={};seen_new=set();celig={};atlas_projectors=set(bp.values())
# Other atlas dimensions are also excluded by their exact orthogonal matrices.
for c,f in F.items():
    if c not in bp:atlas_projectors.add(make_projector(f['B']))
assert len(atlas_projectors)==636
for i,item in enumerate(bridges):
    assert item['id']==i;body=item['rref_basis'];d=item['dimension'];assert len(body)==d
    p=make_projector(body);assert p not in atlas_projectors and p not in seen_new
    seen_new.add(p);new[i]=p
    allowed=tuple(0<d<7 and all(belongs(r,bp[src[g]]) for r in body) for g in src)
    celig[i]=allowed
    assert {int(g):v for g,v in item['source_grades'].items()}=={g:7-d for g,ok in zip(src,allowed) if ok}
    if i and i%2500==0:print('new projector checks',i,'time',round(time.monotonic()-began,1),flush=True)

seen=set();cross=0;feeds=0;join=meet=0;example=None
@lru_cache(None)
def pair_rank(a,b):return rank(F[a]['B']+F[b]['B'])
for edge in doc['edges']:
    a,b,c=edge['A'],edge['B'],edge['C'];kind=edge['operation']; key=(a,b,kind)
    assert a<b and a in roster and b in roster and c in new and key not in seen
    seen.add(key);da,db,dc=edge['dimensions'];assert [da,db,dc]==[F[a]['dim'],F[b]['dim'],bridges[c]['dimension']]
    if kind=='join':
        assert dc>max(da,db) and pair_rank(a,b)==dc
        assert product_equals_small(bp[a],new[c]) and product_equals_small(bp[b],new[c]);join+=1
    else:
        assert kind=='meet' and dc<min(da,db) and da+db-pair_rank(a,b)==dc
        assert product_equals_small(new[c],bp[a]) and product_equals_small(new[c],bp[b]);meet+=1
    assert edge['A_C_grade']==abs(da-dc) and edge['C_B_grade']==abs(db-dc)
    assert edge['final_to_zero_grades']=={'A':da,'B':db,'C':dc}
    for k,g in enumerate(src):
        expected=([['A',7-da]] if ap[a][k] else [])+([['B',7-db]] if ap[b][k] else [])+([['C',7-dc]] if celig[c][k] else [])
        assert edge['first_ingress_grades'][str(g)]==expected and expected
        feeds+=len(expected)
    cross+=2
    if example is None:example=(a,b,c,kind)

# Corrupt an actual adjacent projector and an actual grade.
a,b,c,kind=example
small,large=(bp[a],new[c]) if kind=='join' else (new[c],bp[a])
sm,sd=small;lm,ld=large;j=next(i for i in range(8) if sm[i][i])
broken=[list(row) for row in lm];broken[j][j]+=ld
assert not product_equals_small(small,(tuple(tuple(row) for row in broken),ld))
edge=doc['edges'][0];assert edge['A_C_grade']+1!=abs(edge['dimensions'][0]-edge['dimensions'][2])
out={'status':'PASS','word_sha256':doc['word_sha256'],'new_projectors_checked':len(new),
     'atlas_projectors_compared':len(atlas_projectors),'source_fed_placements_verified':len(seen),
     'sum_placements':join,'intersection_placements':meet,'bridge_projector_products_checked':cross,
     'source_incidence_grades_checked':feeds,'zero_delivery_grades_checked':3*len(seen),
     'every_projector_idempotent_symmetric_and_correct_trace':True,'fraction_free_sum_and_intersection_rank':True,
     'corrupted_projector_rejected':True,'corrupted_grade_rejected':True}
(HERE/'INDEPENDENT-PROJECTORS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True),'seconds',round(time.monotonic()-began,1),flush=True)
