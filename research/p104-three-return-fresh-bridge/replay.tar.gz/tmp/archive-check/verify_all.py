#!/usr/bin/env python3
"""Regenerate, independently verify, and compare every saved receipt."""
from hashlib import sha256
from pathlib import Path
import os,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent

def require(ok,msg):
    if not ok:raise ValueError(msg)
for line in (HERE/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1);p=HERE/name
    require(p.is_file() and sha256(p.read_bytes()).hexdigest()==digest,'manifest mismatch '+name)
scripts=('geometry.py','stock_probe.py','separators.py','verify_projectors.py','verify_stock.py','tariffs.py')
receipts=('GEOMETRY.json.gz','GEOMETRY-SUMMARY.json','STOCK-PROBE.json','SEPARATORS.json.gz',
          'INDEPENDENT-PROJECTORS.json','INDEPENDENT-STOCK.json','PASS-7-CONTROL.json','TARIFFS.json')
(HERE/'tmp').mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix='cold-replay-',dir=HERE/'tmp') as d:
    temp=Path(d);shutil.copytree(HERE/'source',temp/'source');shutil.copytree(HERE/'pricing_source',temp/'pricing_source')
    for f in scripts:shutil.copyfile(HERE/f,temp/f)
    (temp/'scratch').mkdir()
    env=os.environ.copy();env['TMPDIR']=str(temp/'scratch')
    for script in ('geometry.py','separators.py','verify_projectors.py','verify_stock.py','tariffs.py','source/verify.py'):
        p=subprocess.run([sys.executable,'-I','-B',script],cwd=temp,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        require(p.returncode==0,script+' failed:\n'+p.stdout[-4000:]+'\n'+p.stderr[-4000:])
        print('PASS',script,flush=True)
    for name in receipts:
        require((temp/name).read_bytes()==(HERE/name).read_bytes(),'saved receipt differs: '+name)
    print('PASS all eight regenerated receipts match byte for byte',flush=True)
print('PASS new-frame geometry, first-read stock, controls, tariffs and frozen source')
