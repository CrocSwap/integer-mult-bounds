#!/usr/bin/env python3
"""Independent set-tag replay and direct dual parity checks for every pair.

This does not import the stock generator or its binary-elimination functions.
Each saved owner assignment is checked directly against the original source,
empty-bank and per-relay rows available up to the actual first reader. The
single admitted third-return span has a separately checked XOR derivation.
"""
from collections import defaultdict,Counter
from itertools import combinations
from pathlib import Path
import gzip,hashlib,json,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import binary_operator as b

start=time.monotonic()
blob=(HERE/'source/BIT-WORD.json.gz').read_bytes();assert hashlib.sha256(blob).hexdigest()==b.WORD_GZIP
w=json.loads(gzip.decompress(blob));atlas=b.Atlas(w['frames'])
assert atlas.main_contacts(w['start'],w['final'])==111
fw,ad,deleted=b.native_checks(w,atlas)
forward={p.clock:p for p in fw.packets.values()};reverse={p.clock:p for p in ad.packets.values()}
returns=sorted(t for t,p in forward.items() if p.receiver==0);tri=(2,6,7)
groups={g:sorted(t for t in forward if reverse[t].arrival.row==reverse[returns[g]].arrival.row) for g in tri}
assert [groups[g] for g in tri]==[[10302,11483,11488],[10342,13060,13065],[10352,15592,15597]]
def first_read(t):
    addr=w['program'][t][1]
    for u,e in enumerate(w['program'][t+1:],t+1):
        op,dst,*args=e
        if dst==addr or op in ('ADD','SWAP') and args[0]==addr:return u,e
    raise AssertionError(t)
reads={g:first_read(groups[g][-1]) for g in tri}
assert {g:t for g,(t,_) in reads.items()}=={2:11611,6:13241,7:15767}
marks={t:(g,j) for g in tri for j,t in enumerate(groups[g])}
first_clock={groups[g][0]:g for g in tri};read_clock={reads[g][0]:g for g in tri}
values=[1<<i for i in range(680)]+[0]*w['owned_fields'];tags=[set() for _ in values]
charts=list(w['start'])+[None]*w['owned_fields'];past=defaultdict(set)
def save(i):
    if charts[i] is not None and values[i]:past[charts[i]].add((values[i],frozenset(tags[i])))
for i in range(680):save(i)
first={};history={};goal={};snapshot_counts={}
for clock,(op,addr,*args) in enumerate(w['program']):
    if clock in first_clock:
        g=first_clock[clock];src=forward[clock].source
        first[g]=[values[i] for i in range(len(values)) if charts[i]==src and values[i]]
    if clock in read_clock:
        g=read_clock[clock];earlier=set(tri[:tri.index(g)])
        history[g]={c:sorted(x for x,tag in bank if all(group in earlier for group,_ in tag)) for c,bank in past.items()}
        receipt_addr=w['program'][groups[g][-1]][1];goal[g]=values[receipt_addr]
        assert goal[g]==forward[groups[g][-1]].arrival.row
        snapshot_counts[str(g)]={'first_read':clock,'first_read_operation':w['program'][clock],
            'historical_zero_rows':len(history[g].get(0,[])),
            'source_bank_row_counts':{str(k):len(first[k]) for k in tri}}
    changed=[]
    if op=='INIT':assert charts[addr] is None;charts[addr]=args[0];values[addr]=0;tags[addr]=set()
    elif op=='CLEAR':assert charts[addr]==args[0];charts[addr]=None;values[addr]=0;tags[addr]=set()
    elif op=='ADD':
        j=args[0];assert charts[addr]==charts[j]==args[1]
        values[addr]^=values[j];tags[addr]^=tags[j];changed=[addr]
    elif op=='SWAP':
        j=args[0];values[addr],values[j]=values[j],values[addr];charts[addr],charts[j]=charts[j],charts[addr];tags[addr],tags[j]=tags[j],tags[addr];changed=[addr,j]
    elif op=='MOVE':
        assert charts[addr]==args[0];charts[addr]=args[1]
        if clock in marks:tags[addr]^={marks[clock]}
        changed=[addr]
    else:raise AssertionError(op)
    for i in changed:save(i)

doc=json.loads(gzip.decompress((HERE/'SEPARATORS.json.gz').read_bytes()))
assert doc['word_sha256']==b.WORD_GZIP and doc['triple']==list(tri)
vectors=[int(x,16) for x in doc['vectors']]; assert len(set(vectors))==len(vectors)
roster=[int(c) for c,f in sorted(w['frames'].items(),key=lambda kv:int(kv[0])) if f['dim'] in (1,2,4)]
assert len(roster)==334 and len(doc['pairs'])==len(roster)*(len(roster)-1)//2
base={g:sum((first[k] for k in tri),[])+history[g].get(0,[])+[goal[k] for k in tri[:tri.index(g)]] for g in tri}
used=defaultdict(set);bank_checks=defaultdict(set);passing=[]
for saved,(x,y) in zip(doc['pairs'],combinations(roster,2)):
    assert saved[:2]==[x,y]
    for j,g in enumerate(tri):
        i=saved[2+j]
        if i<0:passing.append([g,x,y]);continue
        assert 0<=i<len(vectors);used[g].add(i);bank_checks[g,i].update((x,y))
assert passing==doc['passes']==[[7,506,507]]
checks=0
for g,ids in used.items():
    for i in ids:
        z=vectors[i]
        assert z>0 and z.bit_length()<=680
        assert (goal[g]&z).bit_count()%2==1
        assert all(not ((r&z).bit_count()%2) for r in base[g])
        for bank in bank_checks[g,i]:
            assert all(not ((r&z).bit_count()%2) for r in history[g].get(bank,[]))
        checks+=1
assert all(row[2]>=0 and row[3]>=0 for row in doc['pairs'])

# Positive span control, with a complete XOR derivation and direct replay.
g,x,y=passing[0];pieces=[]
for k in tri:
    pieces.extend(({'kind':'source','return':k,'index':i},row) for i,row in enumerate(first[k]))
for c in (0,x,y):
    pieces.extend(({'kind':'history','chart':c,'row_hex':hex(row)},row) for row in history[g].get(c,[]))
for k in tri[:tri.index(g)]:pieces.append(({'kind':'earlier_target','return':k},goal[k]))
basis={};explain={}
for i,(_,row) in enumerate(pieces):
    combo=1<<i
    while row and row.bit_length()-1 in basis:
        p=row.bit_length()-1;row^=basis[p];combo^=explain[p]
    if row:
        p=row.bit_length()-1;basis[p]=row;explain[p]=combo
res=goal[g];combo=0
while res and res.bit_length()-1 in basis:
    p=res.bit_length()-1;res^=basis[p];combo^=explain[p]
assert not res
chosen=[i for i in range(len(pieces)) if combo>>i&1]
def xor_selected(indices):
    x=0
    for i in indices:x^=pieces[i][1]
    return x
assert xor_selected(chosen)==goal[g]
assert xor_selected(chosen+[chosen[0]])!=goal[g]
control={'return':g,'banks':[x,y],'target_hex':hex(goal[g]),'xor_pieces':[pieces[i][0] for i in chosen],
         'xor_replay_matches':True,'removed_piece_corruption_rejected':True}
(HERE/'PASS-7-CONTROL.json').write_text(json.dumps(control,indent=2,sort_keys=True)+'\n')
# Flipping one target bit necessarily spoils the target parity of this cut.
sample=doc['pairs'][0];z=vectors[sample[2]];pivot=goal[2]&-goal[2];bad=z^pivot
assert (goal[2]&z).bit_count()%2==1 and (goal[2]&bad).bit_count()%2==0
out={'status':'PASS','word_sha256':b.WORD_GZIP,'source_verifier':'binary_operator.Atlas and native_checks',
     'base_forward_adjoint_maps_checked':True,'protected_owner_411_and_omission_checked':True,
     'dirty_retirements_each_direction':[fw.dirty,ad.dirty],'deleted_owner_411_add_clock':deleted,
     'pair_rows_verified':len(doc['pairs']),'direct_separator_occurrences':sum(i>=0 for r in doc['pairs'] for i in r[2:]),
     'distinct_assignments':len(vectors),'assignment_return_checks':checks,'passed_spans':passing,
     'first_reads':snapshot_counts,'corrupted_separator_rejected':True,'corrupted_positive_xor_rejected':True,
     'generating_elimination_imported':False}
(HERE/'INDEPENDENT-STOCK.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True),'seconds',round(time.monotonic()-start,1),flush=True)
