#!/usr/bin/env python3
"""All 334 choose 2 banks: generous three-return history span screen."""
from collections import Counter,defaultdict
from itertools import combinations
from pathlib import Path
import gzip,hashlib,json,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import verify_decoder_triples as v

start=time.monotonic()
blob=(HERE/'source/BIT-WORD.json.gz').read_bytes()
assert hashlib.sha256(blob).hexdigest()==v.WORD_SHA
w=json.loads(gzip.decompress(blob));F={int(k):x for k,x in w['frames'].items()}
s=v.run_tape(w,False);a=v.run_tape(w,True)
returns=[t for t,(_,dst,_) in s.items() if dst==0]
groups=[[t for t in sorted(s) if a[t][2]==a[returns[g]][2]] for g in range(9)]
tri=(2,6,7)
assert [groups[g] for g in tri]==[[10302,11483,11488],[10342,13060,13065],[10352,15592,15597]]
marks={t:3*j+k for j,g in enumerate(tri) for k,t in enumerate(groups[g])}
firstwatch={groups[g][0]:g for g in tri}
def first_read(t):
    addr=w['program'][t][1]
    for u in range(t+1,len(w['program'])):
        op,dst,*args=w['program'][u]
        if dst==addr or op in ('ADD','SWAP') and args[0]==addr:
            return u,w['program'][u]
    raise AssertionError((t,addr))
first_reads={g:first_read(groups[g][-1]) for g in tri}
assert {g:t for g,(t,_) in first_reads.items()}=={2:11611,6:13241,7:15767}
lastwatch={first_reads[g][0]:g for g in tri}
chart=list(w['start'])+[None]*w['owned_fields'];row=[1<<i for i in range(w['public'])]+[0]*w['owned_fields']
mask=(1<<w['public'])-1; history=defaultdict(set)
def record(i):
    if chart[i] is not None and row[i]&mask: history[chart[i]].add((row[i]&mask,row[i]>>w['public']))
for i in range(w['public']):record(i)
first={};snap={}
for t,(op,addr,*args) in enumerate(w['program']):
    if t in firstwatch:
        g=firstwatch[t];src=s[t][0];first[g]=[x&mask for c,x in zip(chart,row) if c==src and x&mask]
    if t in lastwatch:
        g=lastwatch[t];prior=(1<<(3*tri.index(g)))-1
        snap[g]={c:[x for x,tag in sorted(bank) if not tag&~prior] for c,bank in history.items()}
    touched=[]
    if op=='INIT':chart[addr]=args[0];row[addr]=0
    elif op=='CLEAR':chart[addr]=None;row[addr]=0
    elif op=='ADD':row[addr]^=row[args[0]];touched=[addr]
    elif op=='SWAP':
        j=args[0];row[addr],row[j]=row[j],row[addr];chart[addr],chart[j]=chart[j],chart[addr];touched=[addr,j]
    elif op=='MOVE':
        chart[addr]=args[1]
        if t in marks:row[addr]^=1<<(w['public']+marks[t])
        touched=[addr]
    else:raise ValueError(op)
    for i in touched:record(i)

def full_reduce(x,b):
    for p in sorted(b,reverse=True):
        if (x>>p)&1:x^=b[p]
    return x

roster=[c for c in sorted(F) if F[c]['dim'] in (1,2,4)]
assert len(roster)==334
targets={g:s[groups[g][-1]][2] for g in tri}
srcrows=[x for g in tri for x in first[g]]
cached={};tar={};bases={};meta={}
for j,g in enumerate(tri):
    b=v.binary_basis(srcrows+snap[g].get(0,[])+[targets[k] for k in tri[:j]])
    bases[g]=b;tar[g]=full_reduce(targets[g],b)
    cached[g]={c:tuple(v.binary_basis(full_reduce(x,b) for x in snap[g].get(c,[])).values()) for c in roster}
    assert tar[g]
    meta[str(g)]={'base_rank':len(b),'target_quotient_nonzero':True,'bank_nonempty':sum(bool(cached[g][c]) for c in roster),'rank_histogram':dict(Counter(str(len(cached[g][c])) for c in roster))}
print('snapshots/caches',round(time.monotonic()-start,2),meta,flush=True)
stats=Counter();passing=[];first_failure=Counter();pass_target=Counter();target_pairs=defaultdict(list)
for x,y in combinations(roster,2):
    # Both banks' entire original history, with free retention and unlimited exchange.
    status=[]
    for g in tri:
        b=v.binary_basis(cached[g][x]+cached[g][y]);ok=v.reduce_binary(tar[g],b)==0
        status.append(ok);pass_target[str(g)]+=ok
        if ok:target_pairs[str(g)].append([x,y])
    if all(status):passing.append([x,y])
    else:first_failure[str(tri[status.index(False)])]+=1
    stats['pairs']+=1
print('pairs',stats['pairs'],'passes',dict(pass_target),'all',len(passing),'time',round(time.monotonic()-start,2),flush=True)
out={'word_sha256':v.WORD_SHA,'triple':tri,'all_nine_first_reads':{str(t):first_read(t) for g in tri for t in groups[g]},'roster':roster,'metadata':meta,'pair_count':stats['pairs'],'passes_by_target':dict(pass_target),'passing_pairs_by_target':dict(target_pairs),'first_failure_counts':dict(first_failure),'all_three_pass_pairs':passing,
     'method':'target restored by actual first read; all three full source banks, historical row spaces of both chosen banks and chart zero, all prior targets, free retention/exchange, current or later receipt dependent rows excluded; no geometry/causality constraint'}
(HERE/'STOCK-PROBE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
