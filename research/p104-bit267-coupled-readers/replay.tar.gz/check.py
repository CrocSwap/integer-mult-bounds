#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Bounded chart-267 paired-basis/first-consumer exclusion and baseline control.

Idealized sender changes and invisible omitted fields are deliberate relaxations,
not literal word edits. See README for the fixed history and restoration scope.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip, itertools, json, sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import verify as v
op=v.op

def require(ok,msg):
 if not ok:raise ValueError(msg)
def digest(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
for name,h in v.PINS.items():require(sha256((HERE/'source'/name).read_bytes()).hexdigest()==h,'pin '+name)
w=v.read('inputs/WORD.json.gz');caller=v.read('inputs/EFREE-CALLER.json.gz');receipt=v.read('inputs/BIT.json')
require(digest(w)==v.WORD,'canonical word')
P=w['program']; N=w['public']; require(N==680,'all owners retained')
require(P[4559]==['MOVE',1926,267,349] and P[4565]==['MOVE',1927,267,374],'send clocks')
require(P[8511]==['ADD',2471,1926,349] and P[8792]==['ADD',2542,1927,374],'first readers')
# Original paid outputs from the two opened first readers; first use and the
# completed first consumer are frozen in the original source clock system.
D={2471:(349,8510,8513,511,10301,2924,10302),
   2472:(349,8514,8518,536,10492,2982,10493),
   2473:(349,8519,8521,1,31344,3560,31355),
   2542:(374,8790,8794,574,10810,3088,10811),
   2543:(374,8795,8798,578,10843,3099,10844),
   2544:(374,8799,8801,1,31965,3613,31973)}
for a,(bank,pre,send,down,first,child,complete) in D.items():
 require(P[send]==['MOVE',a,bank,down],'paid exit '+str(a))
 require(P[first]==['ADD',child,a,down],'first consumer '+str(a))
 uses=[t for t,e in enumerate(P) if e[0]=='ADD' and e[2]==a and t>send]
 require(uses and uses[0]==first,'first read '+str(a))
 if a in (2471,2472,2542,2543):require(P[complete][0:2]==['MOVE',child],'immediate next paid consumer')
 else:require(P[complete][0]!='ADD' or P[complete][1]!=child,'terminal consumer completed')
# Histories after packet arrival and before either receiver's first read cannot
# carry a modified payload elsewhere, nor can chart 349's outputs feed chart 374
# before the second receiver opens.
for a,first in ((1926,8511),(1927,8792)):
 move=4559 if a==1926 else 4565
 require(not any(e[0]=='ADD' and e[2]==a for e in P[move+1:first]),'no prior use '+str(a))
require(min(D[a][4] for a in (2471,2472,2473))>8790,'no 349 output read before 374 opens')

cuts={4559,4565,8510,8511,8513,8514,8518,8519,8521,8790,8792,8794,8795,8798,8799,8801,38736,38842}
for bank,pre,send,down,first,child,complete in D.values():cuts.update((first,complete))
def replay(pair=None,omit=None):
 """Rerun field rows. pair injects ideal source rows at original send clocks;
 omit keeps a routed ghost only for clock alignment and skips its subsequent reads.
 Ghost is never available in the stock offered to the elimination test.
 """
 cells=[(chart,1<<i) for i,chart in enumerate(w['start'])]+[None]*w['owned_fields'];out={}
 # Retaining every old arrival for free is a deliberate relaxation over the
 # actual live stock. Local ADD, INIT and SWAP create no new chart information.
 history={bank:[] for bank in (1,349,374,511,536,574,578)};history_out={}
 for i,chart in enumerate(w['start']):
  if chart in history:history[chart].append((f'owner:{i}',1<<i))
 moved=False
 for t,(code,a,*z) in enumerate(P):
  if t in cuts:
   out[t]=cells.copy();history_out[t]={bank:rows.copy() for bank,rows in history.items()}
  if code=='INIT':require(cells[a] is None,'init');cells[a]=(z[0],0)
  elif code=='CLEAR':require(cells[a] is not None and cells[a][0]==z[0],'clear');cells[a]=None
  elif code=='MOVE':
   require(cells[a] is not None and cells[a][0]==z[0],'move')
   row=cells[a][1]
   if pair is not None and t in (4559,4565):row=pair[0 if t==4559 else 1]
   cells[a]=(z[1],row)
   if z[1] in history and a!=omit:history[z[1]].append((f'move:{a}@{t}',row))
   if a==omit:moved=True
  elif code=='SWAP':require(cells[a] is not None and cells[z[0]] is not None,'swap');cells[a],cells[z[0]]=cells[z[0]],cells[a]
  else:
   require(code=='ADD' and a!=z[0] and cells[a] is not None and cells[z[0]] is not None and cells[a][0]==cells[z[0]][0]==z[1],'add')
   if not (omit is not None and moved and z[0]==omit):cells[a]=(z[1],cells[a][1]^cells[z[0]][1])
 return out,history_out
base,base_history=replay()
S=(741,1356,1460,1508,1580,1628)
source=base[4559]
require(all(source[i] is not None and source[i][0]==267 for i in S),'sender stock')
require(all(base[4559][i]==base[4565][i] for i in S),'sender stock held')
def xor(xs):
 v=0
 for x in xs:v^=x
 return v
A=source[1926][1];B=base[4565][1927][1]
require(A==xor(source[i][1] for i in (741,1460,1508,1580,1628)),'A source')
require(B==xor(source[i][1] for i in (741,1356,1508,1628)),'B source')
require(A and B and A!=B,'source pair independent')

def basis_with_expressions(fields):
 b={}
 for i,(addr,row) in enumerate(fields):
  x=row;expr=1<<i
  while x:
   p=x.bit_length()-1
   if p in b:x^=b[p][0];expr^=b[p][1]
   else:b[p]=(x,expr);break
 return b

def evaluate(fields,target):
 """Exact membership, free co-chart linear operations and separating witness."""
 b=basis_with_expressions(fields); x=target;expr=0
 while x:
  p=x.bit_length()-1
  if p not in b:break
  x^=b[p][0];expr^=b[p][1]
 # Continue elimination even across non-pivot residual bits.
 for p in sorted(b,reverse=True):
  if x>>p&1:x^=b[p][0];expr^=b[p][1]
 out={'stock_count':len(fields),'stock_rank':len(b),'target_rank_increment':int(bool(x))}
 if not x:
  chosen=[fields[i][0] for i in range(len(fields)) if expr>>i&1]
  require(xor(fields[i][1] for i in range(len(fields)) if expr>>i&1)==target,'member certificate')
  out['reconstruct_from_labels']=chosen
 else:
  free=x.bit_length()-1;require(free not in b,'free separator coordinate')
  cert=1<<free
  for p in sorted(b):
   if (b[p][0]&cert).bit_count()%2:cert^=1<<p
  require(all((row&cert).bit_count()%2==0 for _,row in fields) and (target&cert).bit_count()%2==1,'orthogonal separator')
  out['separator_owner_support']=[i for i in range(N) if cert>>i&1]
 return out

def bank_fields(snapshot,bank,exclude=()):
 return [(a,c[1]) for a,c in enumerate(snapshot) if c is not None and c[0]==bank and a not in exclude]

# Exhaust all six ordered invertible row pairs in GL(2,2). At each receiver,
# use its actual current co-chart fields with arbitrary free XORs. The source
# row itself may be an ideal genie injection, so this is an information test.
cases={};R={1:A,2:B,3:A^B}
for m,n in itertools.permutations((1,2,3),2):
 q,q_history=replay((R[m],R[n]));checks={}
 for addr,(bank,pre,send,down,first,child,complete) in D.items():
  packet=1926 if bank==349 else 1927
  # Altering earlier local output payloads has not contaminated this stock:
  old=bank_fields(base[pre],bank,(1926,1927));new=bank_fields(q[pre],bank,(1926,1927))
  require(old==new,'actual non-packet stock unchanged at receiver')
  require(q[pre][packet][1]==R[m if bank==349 else n],'genie packet')
  fields=bank_fields(q[pre],bank)
  checks[str(addr)]=evaluate(fields,base[send][addr][1])
  checks[str(addr)]['side_field_addresses']=[i for i,_ in old]
  hist=q_history[pre][bank];packet_label=f'move:{packet}@{4559 if packet==1926 else 4565}'
  old_history=[e for e in base_history[pre][bank] if e[0]!=packet_label]
  require([e for e in hist if e[0]!=packet_label]==old_history,'other historical arrivals unchanged')
  checks[str(addr)]['all_prior_arrivals_freely_retained']=evaluate(hist,base[send][addr][1])
  require(checks[str(addr)]['all_prior_arrivals_freely_retained']['target_rank_increment']==checks[str(addr)]['target_rank_increment'],'history relaxation agrees')
 fail=[int(a) for a,z in checks.items() if z['target_rank_increment']]
 cases[f'{m},{n}']={'basis_rows':[m,n],'failed_restored_paid_exits':fail,'exits':checks}
for key,row in cases.items():
 fail=row['failed_restored_paid_exits']
 require((not fail)==(key=='1,2'),'identity uniquely restores both groups')
 # At least two other exits fail even if any single slot is allowed to disappear.
 if fail:require(all(any(x!=omitted for x in fail) for omitted in D),'single omission does not repair basis')

# Identity candidate: offer every cocharted live field except the missing ghost.
# Replaying all remaining original reads makes this more generous than an actual
# omission: source ghost routing costs and the repair instructions are free.
omissions={}
for missing,(bank,pre,send,down,first,child,complete) in D.items():
 q,q_history=replay(omit=missing);target=base[complete][child]
 require(target is not None and target[0]==down,'first completed consumer chart')
 fields=bank_fields(q[complete],down,(missing,))
 ev=evaluate(fields,target[1]);require(ev['target_rank_increment']==1,'first consumer cannot be restored '+str(missing))
 ev.update({'exit_clock':send,'route':[bank,down], 'first_reader_clock':first,
            'first_consumer_address':child,'consumer_completion_clock':complete,
            'stock_field_addresses': [a for a,_ in fields]})
 old=[e for e in base_history[complete][down] if e[0]!=f'move:{missing}@{send}']
 require(q_history[complete][down]==old,'other first-consumer arrivals unchanged')
 hist=evaluate(q_history[complete][down],target[1])
 require(hist['target_rank_increment']==1,'freely retained arrival history cannot restore first consumer')
 ev['all_prior_arrivals_freely_retained']=hist
 # Grade-two exits land at the common chart. Continue the idealized omission to
 # the first associated public SWAP, allowing all later original arrivals free.
 if missing in (2473,2544):
  late=38736 if missing==2473 else 38842
  require(P[late][0]=='SWAP' and P[late][2]==child,'first affected terminal swap')
  target=base[late][child];fields=bank_fields(q[late],1,(missing,));e=evaluate(fields,target[1])
  require(e['target_rank_increment']==1,'later terminal consumer deficit')
  old=[x for x in base_history[late][1] if x[0]!=f'move:{missing}@{send}']
  require(q_history[late][1]==old,'other terminal arrivals unchanged')
  hist=evaluate(q_history[late][1],target[1]);require(hist['target_rank_increment']==1,'terminal history deficit')
  e.update({'before_swap_clock':late,'owner':P[late][1],
            'stock_field_addresses_sha256':digest([a for a,_ in fields]),
            'all_prior_arrivals_freely_retained':hist})
  ev['at_first_affected_terminal_swap']=e
 omissions[str(missing)]=ev

# Untouched three-exit-per-receiver control: full two-direction native and
# caller operators, original bridge/owner isolation, complete signed invoice.
atlas=op.Atlas(w['frames']);require(atlas.main_contacts(w['start'],w['final'])==111,'main contacts')
for addr,(bank,pre,send,down,first,child,complete) in D.items():
 require(atlas.grade(bank,down)==(2 if addr in (2473,2544) else 1),'original exit grade')
f,b,bridge_omission=op.native_checks(w,atlas)
protected={}
routes={2942:(517,390,1),2943:(390,509,2),2944:(509,0,4),3553:(509,1,4)}
for name,tape in (('forward',f),('adjoint',b)):
 protected[name]={}
 for packet,(start,end,grade) in routes.items():
  p=tape.packets[packet];route=(start,end) if name=='forward' else (end,start)
  require((p.source,p.receiver,p.grade)==(*route,grade),'protected tree/bridge route')
  if packet==3553:require(p.arrival.row==1<<411,'owner411 bridge payload')
  protected[name][str(packet)]={'route':[p.source,p.receiver], 'grade':p.grade,
   'row_little_endian_sha256':sha256(p.arrival.row.to_bytes((N+7)//8,'little')).hexdigest()}
np,nt,paid,targets=op.binary_invoice(w,caller,atlas,f)
for name,got in (('native_paid',np),('native_targets',nt),('paid',paid),('targets',targets)):
 require(got==Counter({int(k):v for k,v in receipt['native'][name].items()}),'receipt '+name)
ordinary=op.ordinary_boundary(w,caller,paid,targets)
signed=Counter(targets);signed.subtract(paid)
def quote(rate,hist):
 lo=hi=F(0)
 for r,n in hist.items():
  if n:
   a,b=v.power_bounds(r,1-F(rate),204);lo+=n*(a if n>0 else b);hi+=n*(b if n>0 else a)
 return v.decimals((lo,hi),30)
rates=('0.003879928046156','0.003879929046155')
corrupt={}
for clock in (8511,8792):
 observations=[]
 for reverse,tape in ((False,f),(True,b)):
  bad=op.run_tape(w,atlas,reverse,omit=clock).output
  diff=[x^y for x,y in zip(bad,tape.output)]
  require(any(diff),'corruption must be detected')
  observations.append({'orientation':'adjoint' if reverse else 'forward',
   'changed_output_rows':sum(bool(x) for x in diff),'changed_scalar_coefficients':sum(x.bit_count() for x in diff)})
 corrupt[str(clock)]=observations
out={
 'status':'PASS_BOUNDED_PAIRED_BASIS_AND_PAID_CONSUMER_EXCLUSION',
 'source_heads':{'pr7913':'b252f7dad5c36ab6382d68a42ee90d95cf4d33eb','pr7926':'b2ef618d28ac387b424321bf71daa5ada3881440','pr7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'},
 'source_word_canonical_sha256':v.WORD,
 'scope':'All six paired bases; both send clocks and receiver charts fixed; original other five of six first outgoing paid payloads and first consumer outputs restored; all original prior co-chart arrivals freely retained, otherwise fixed histories. Any free local linear recoding allowed. No alternate paid edges or retiming are excluded.',
 'source_pair':{'A_address':1926,'B_address':1927,'A_coordinates':[741,1460,1508,1580,1628],
                'B_coordinates':[741,1356,1508,1628], 'rank':2,'basis_encoding':'1=A, 2=B, 3=A XOR B'},
 'basis_cases':cases,'single_paid_exit_omissions_in_original_basis':omissions,
 'control':{'description':'Original unmodified three outgoing paid slots at each receiver, all 680 owners retained.',
   'exact_native_coefficients_each_orientation':N*N,'exact_caller_coefficients_each_orientation':38*38,
   'native_calls':36,'paid':dict(sorted(paid.items())),'targets':dict(sorted(targets.items())),
   'full_signed_margin':{rate:quote(rate,signed) for rate in rates},'signed_gain_from_source':{rate:['0','0'] for rate in rates},
   'ordinary':ordinary,'dirty_retirements':[f.dirty,b.dirty],
   'owner411_bridge_packet3553_and_tree_preserved':True,'protected_tree_and_bridge':protected,'bridge_omission_clock':bridge_omission,
   'each_first_reader_omission_rejected_in_both_orientations':corrupt},
 'result':'No changed literal witness or positive kappa gain; every enumerated omission fails at the stated restored output with the fixed history. Later alternative transmissions or altered other exits require fresh legal construction, full retiming debit and full invoice.'}
print(json.dumps(out,indent=2,sort_keys=True))
