#!/usr/bin/env python3
"""Verify exact supplied parent archives against the local frozen inputs."""
from hashlib import sha256
from pathlib import Path
import json,tarfile
here=Path(__file__).resolve().parent
pins={
 '7913':{'head':'b252f7dad5c36ab6382d68a42ee90d95cf4d33eb','sha256':'acd35b771b132bf34a2ff15ccf1e054a8c4e73dbbdaaf53ffac7aa6392902139','path':'research/p104-bit267-receiver-exchange/replay.tar.gz','blob':'b960e4103ea2c298c9da810c471eb42ee6fcbc08'},
 '7926':{'head':'b2ef618d28ac387b424321bf71daa5ada3881440','sha256':'a614d676ac38a8c60274b4b0dd476a53da8853df33fa895ba3d529beafd6eefe','path':'research/p104-bit679-postspecialization-cut/replay.tar.gz','blob':'7e78b2ed2ac01151bf3d77d5b190fca966084d0d'}}

def check(ok,msg):
 if not ok:raise ValueError(msg)
out={}
for pr,info in pins.items():
 raw=(here/f'upstream-{pr}.tar.gz').read_bytes();check(sha256(raw).hexdigest()==info['sha256'],'archive digest '+pr)
 with tarfile.open(fileobj=__import__('io').BytesIO(raw),mode='r:gz') as z:
  def read(name):
   f=z.extractfile('./'+name);check(f is not None,'missing '+name);return f.read()
  if pr=='7913':
   members=[m for m in z.getmembers() if m.isfile() and m.name.startswith('./source/')]
   check(members,'source members')
   for m in members:
    check(read(m.name[2:])==(here/m.name[2:]).read_bytes(),'source member '+m.name)
   comparison={'all_packaged_source_members_byte_identical':len(members)}
  else:
   for name in ('WORD.json.gz','BIT.json','EFREE-CALLER.json.gz'):
    check(read('inputs/'+name)==(here/'source/inputs'/name).read_bytes(),'shared comparator '+name)
   result=json.loads(read('RESULT.json'))
   check(result['status']=='NO_NEW_SAME_BANK_PULSE_RELATION' and result['original_owners_removed']==[649],'context only')
   comparison={'shared_comparator_inputs_identical':3,'upstream_679_owner_projection_is_context_only':True}
  out[pr]={**info,**comparison}
print(json.dumps({'status':'PASS_PARENT_ARCHIVE_AND_COMPARATOR_PINS','parents':out,'local_source_owners':680},indent=2,sort_keys=True))
