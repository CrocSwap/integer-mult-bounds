#!/usr/bin/env python3
"""Replay every reported separator with one-bit arithmetic, no Gaussian code."""
import gzip,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
w=json.loads(gzip.decompress((HERE/'source/inputs/WORD.json.gz').read_bytes()));P=w['program']
r=json.loads((HERE/'RESULT.json').read_bytes());N=w['public']
D={2471:(349,8510,8513,511,10301,2924,10302),2472:(349,8514,8518,536,10492,2982,10493),2473:(349,8519,8521,1,31344,3560,31355),2542:(374,8790,8794,574,10810,3088,10811),2543:(374,8795,8798,578,10843,3099,10844),2544:(374,8799,8801,1,31965,3613,31973)}
def need(c,m):
 if not c:raise ValueError(m)
def parity_screen(support, bank, cut, target_clock, target_addr, basis=None, omitted=None):
 """Observe a dual functional; nonzero target and zero arrivals certify a gap."""
 s=set(support);a=[(chart,int(i in s)) for i,chart in enumerate(w['start'])]+[None]*w['owned_fields'];b=a.copy()
 history=[bit for chart,bit in a[:N] if chart==bank];target=None;past=False;AB=None
 for t,(code,x,*z) in enumerate(P):
  if t==cut:
   need(all(v==0 for v in history),'a history arrival violates separator')
  if t==target_clock:
   need(b[x] is not None or b[target_addr] is not None,'target address inactive')
   target=b[target_addr][1]
  if t>=max(cut,target_clock):break
  def step(c,variant):
   nonlocal past,AB
   if code=='INIT':c[x]=(z[0],0)
   elif code=='CLEAR':c[x]=None
   elif code=='MOVE':
    val=c[x][1]
    if variant and basis and t==4559:
     aa=val;bb=0
     for j in (741,1356,1508,1628):bb^=c[j][1]
     AB=(aa,bb)
    if variant and basis and t in (4559,4565):
     mask=basis[0 if t==4559 else 1]
     val=((AB[0] if mask&1 else 0)^(AB[1] if mask&2 else 0))
    c[x]=(z[1],val)
    if variant and t<cut and z[1]==bank and x!=omitted:history.append(val)
    if variant and x==omitted:past=True
   elif code=='SWAP':c[x],c[z[0]]=c[z[0]],c[x]
   elif not (variant and omitted is not None and past and z[0]==omitted):c[x]=(z[1],c[x][1]^c[z[0]][1])
  step(b,False);step(a,True)
 need(target==1,'separator does not distinguish target')
 return {'history_size':len(history),'all_historical_values_zero':True,'original_target_value':target}
proofs={};count=0
for basis,case in sorted(r['basis_cases'].items()):
 pair=tuple(map(int,basis.split(',')))
 for addr in case['failed_restored_paid_exits']:
  bank,pre,send,down,first,child,complete=D[addr]
  sup=case['exits'][str(addr)]['all_prior_arrivals_freely_retained']['separator_owner_support']
  proofs[f'basis:{basis}:exit:{addr}']=parity_screen(sup,bank,pre,send,addr,basis=pair);count+=1
for missing,row in sorted(r['single_paid_exit_omissions_in_original_basis'].items()):
 missing=int(missing);bank,pre,send,down,first,child,complete=D[missing]
 sup=row['all_prior_arrivals_freely_retained']['separator_owner_support']
 proofs[f'omission:{missing}:consumer']=parity_screen(sup,down,complete,complete,child,omitted=missing);count+=1
 if 'at_first_affected_terminal_swap' in row:
  later=row['at_first_affected_terminal_swap'];late=later['before_swap_clock']
  sup=later['all_prior_arrivals_freely_retained']['separator_owner_support']
  proofs[f'omission:{missing}:terminal']=parity_screen(sup,1,late,late,child,omitted=missing);count+=1
need(count==32,'expected separator count')
# Replacing a genuine separator by the zero functional must be rejected.
try:parity_screen([],511,10302,10302,2924,omitted=2471)
except ValueError as e:need(str(e)=='separator does not distinguish target','zero certificate rejection')
else:raise ValueError('zero separator accepted')
print(json.dumps({'status':'PASS_INDEPENDENT_ONE_BIT_SEPARATOR_REPLAY','verified_separator_count':count,'zero_separator_rejected':True,'proofs':proofs},indent=2,sort_keys=True))
