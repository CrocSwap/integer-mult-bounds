# Paired chart-267 payloads and first downstream consumers

No changed witness or κ gain was found in this bounded screen. With the 1926 and 1927 sends fixed at their original clocks and routes, all six invertible two-payload bases fail to omit any one of the six named first outgoing paid slots while preserving the other five original payloads, the named downstream outputs, and the original arrival histories. The test allows free GF(2) recoding and free retention of **every prior arrival** at each tested chart. Alternate paid edges, jointly changed other outgoing payloads, and retiming remain open and require a new construction and a full debit.

The source is the 680-owner word in [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15), following the distinct receiver histories in [#7913 at `b252f7dad5c36ab6382d68a42ee90d95cf4d33eb`](https://github.com/CrocSwap/integer-mult-bounds/tree/b252f7dad5c36ab6382d68a42ee90d95cf4d33eb). [#7926 at `b2ef618d28ac387b424321bf71daa5ada3881440`](https://github.com/CrocSwap/integer-mult-bounds/tree/b2ef618d28ac387b424321bf71daa5ada3881440) supplies related fixed-bank context; its 679-owner projection is **not** applied here. Both actual parent archives are included and checked byte for byte against their published SHA-256 digests. [PROVENANCE.json](PROVENANCE.json) records their archive paths and the identical comparator bytes.

## The paired source

Let `A` be packet field 1926 and `B` field 1927. Both are available from the six original chart-267 fields before the first send:

```
A = 741 + 1460 + 1508 + 1580 + 1628
B = 741 + 1356 + 1508 + 1628
```

Both send clocks are source-word indices: 1926 goes 267→349 at 4559; 1927 goes 267→374 at 4565. The original first readers are `ADD 2471,1926` at 8511 and `ADD 2542,1927` at 8792. Their receiver charts are distinct. Each reader region has three original outbound paid fields:

| Receiver | Outbound paid fields | Original grades |
| --- | --- | --- |
| 349 | 2471, 2472, 2473 | 1, 1, 2 |
| 374 | 2542, 2543, 2544 | 1, 1, 2 |

For this screen, the sent rows may be any ordered basis chosen from `A`, `B`, and `A+B`. This is an **ideal injection**, including combinations that would still need a literal realization. At a receiver, all historical incoming rows are available for free; the model does not assume the other receiver's packet or stock arrives there. The unchanged other five exits must reproduce their exact original outgoing payloads. Thus the model grants more local memory and computation than the original word, but fixes the other input arrivals and outputs. It cannot bound a construction that changes other routes or the named payloads.

| Payloads sent to 349, 374 | Original outgoing fields that cannot be restored |
| --- | --- |
| A, B | none |
| A, A+B | 2542, 2543, 2544 |
| B, A | all six |
| B, A+B | all six |
| A+B, A | all six |
| A+B, B | 2471, 2472, 2473 |

Every non-original basis therefore leaves at least two failed outputs even if any one of the six outgoing fields is omitted. [RESULT.json](RESULT.json) gives all 36 rank checks, exact arrival labels, reconstructing XORs or separating duals. The script checks that all other historical arrivals are unchanged at the tested cuts.

## Original basis: can one first outgoing payment disappear?

In each row the candidate omits the named outgoing field, while the remaining original word and all other arrival values are fixed. A ghost is routed only to retain the source clocks, is hidden from the tested bank, and all reads from it are omitted. This makes no legal-word claim. The test grants every other prior arrival at the bank for free. The requested original first-consumer row is outside that entire history span in every case.

| Omitted field | First consumer and completion clock | History rank | Rank with required row |
| --- | --- | ---: | ---: |
| 2471 | 2924 at paid send 10302 | 1 | 2 |
| 2472 | 2982 at paid send 10493 | 2 | 3 |
| 2473 | 3560 at completion 31355 | 536 | 537 |
| 2542 | 3088 at paid send 10811 | 2 | 3 |
| 2543 | 3099 at paid send 10844 | 2 | 3 |
| 2544 | 3613 at completion 31973 | 536 | 537 |

For 2473 and 2544, the first consumers are terminal computations, not paid sends. The same one-dimensional deficit remains when all other original arrivals up to the first affected public swap are retained: `SWAP 6,3560` at 38736 and `SWAP 59,3613` at 38842 respectively. The script independently confirms that the actual non-omitted arrival histories agree with the original at those cuts. It does not rule out changing those arrivals or repairing the output through an additional or retimed paid event.

## Unchanged control and price

The original three exits on each receiver pass both complete 680×680 binary operators, all 38×38 caller polynomial coefficients, all 111 main contacts, and the full 36-call invoice. Original owner 411 and bridge packet 3553 remain isolated, and the three named tree routes and payload hashes are recorded in both directions. Omitting either original first `ADD` changes the operator in **both** orientations: omitting clock 8511 changes 1,207 scalar coefficients; omitting 8792 changes 64. Ordinary records are 934,182,831,504 and owned backing 6,998,544.

The control's full target-minus-paid signed margins, using directed bounds, are:

| κ | Complete signed interval |
| --- | --- |
| `0.003879928046156` | [`−0.000000000767001502431130261464`, `−0.000000000767001502431130261463`] |
| `0.003879929046155` | [`−0.000385127316613866441054139473`, `−0.000385127316613866441054139472`] |

The control has exactly zero change from #7830. No legal changed word passed this screen, so no hypothetical deleted-transfer credit is booked. A future repair must account for the old and new paid transfers, retimes, productive targets, all owners, complete native and caller operators, and ordinary resources before it can imply a gain.

## Offline reproduction

Python 3.12, standard library only. All commands run from this directory:

```sh
sha256sum -c SHA256SUMS
python3 -IB provenance.py > /tmp/p104-267-provenance.json
cmp PROVENANCE.json /tmp/p104-267-provenance.json
python3 -IB check.py > /tmp/p104-267-result.json
cmp RESULT.json /tmp/p104-267-result.json
python3 -IB independent.py > /tmp/p104-267-independent.json
cmp INDEPENDENT.json /tmp/p104-267-independent.json
```

The independent checker uses only one-bit signal propagation, not the rank-elimination engine. It verifies all 32 reported separators directly against actual historical arrivals and the required original target, and rejects a zeroed separator. The binary operator and caller control are computational replay, not independent human review, a physical-erasure qualification, precision-tape qualification, or an outer-theorem proof. Original licenses and notices remain under [source/](source/), and the pinned upstream archives retain their own notices.
