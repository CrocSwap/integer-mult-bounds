# Physical releases of the nine chart-268 anchors and the cost of a replacement feedback row

The nine-coordinate obstruction for the funded 0→19 graph can be broken on its own tested input slice by releasing **any one** of its nine old coefficients. This package constructs a separate physical word for each release. Each preserves the other eight old components on every paid receipt and returns all ten tested source columns (the eight, 17 and 679) correctly at all 680 outputs. The full forward and literal-adjoint replays expose the remaining errors. These controls establish inclusion-minimality for this projected test and its particular nine-coordinate roster. Feasibility of the complete map still requires the other 670 input columns. [Round 9 source](https://github.com/CrocSwap/integer-mult-bounds/pull/8006)

| Released input | Full forward errors | Full adjoint errors | Owner 221 exact both ways |
| --- | ---: | ---: | --- |
| 22 | 63 | 18 | Yes |
| 51 | 63 | 207 | Yes |
| 77 | 108 | 476 | No |
| 91 | 111 | 499 | No |
| 92 | 63 | 210 | Yes |
| 96 | 93 | 414 | No |
| 97 | 90 | 431 | Yes |
| 98 | 93 | 445 | No |
| 100 | 63 | 180 | Yes |

Owners 411 and 679 are correct in both orientations for every word in the table. Every word uses the same 2,874 paid contacts and has a complete signed 36-call binary margin of +0.15481217569851 at 0.00388. The unchanged 48-call rational margin is +0.13897452233425. RESULT.json provides all actual paid/productive bins, the finite guard-rate invoices, both orientations of the monitored owners, complete failure rosters and canonical word hashes. The construction uses original MOVE identifiers to describe donor changes; its scheduled tapes use new chronological identifiers. [Native 680-owner word and caller](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier)

## Exact feedback minimum at the first reader

The target feedback is the original paid value of 3410. Grant chart 421 any XOR of its five bank rows 264, 789, 1934, 2234 and 2947. Independently grant chart 0 any XOR of all eight other incoming rows before the first old 3410 reader, plus its complete 524-dimensional initial stock. Those early paid values use their native historical components. The new 0→19 contact forwards x549. Under these assumptions, exactly 2,048 of the 8,192 binary assignments preserve both source coefficients 17 and 679 in the required feedback. Taking the quotient by all local chart-0 inputs, the unique minimum Hamming weight of the remaining original-owner-coordinate discrepancy is **nine**. It uses only 1934 and 2947 from chart 421 and none of the eight central receipts.

Before central cancellation, the feedback discrepancy is e17 + X2234 and has weight 18. Chart 0 cancels owners 266, 267, 276, 298, 336, 361, 398, 402 and 423 in every direct old reader. The residual is

```
e22 + e32 + e40 + e49 + e55 + e59 + e71 + e73 + e83.
```

The literal program attaining this minimum fails 63 forward and nine adjoint outputs. The nine failed adjoint owners are precisely those in the displayed residual. Owners 221, 411 and 679 remain correct in both orientations. The minimum concerns one static feedback row with the retained early source stocks. It does not optimize global public error counts over arbitrary other sender changes.

Next grant each of the 636 charts its complete actual stock before the first old feedback reader. Test whether one additional bank, combined with all chart-0 initial owners, all eight other central receipts and the alternative feedback, can supply the residual. Only chart 1 succeeds; it lies a paid grade eight from 0. An earlier chart 24 and chart 318 together pass the relaxed rank test. Their exact representative uses 22 at chart 24 and receipts 1445, 1577, 1661 and 1901 at chart 318, modulo original chart-0 owners. This rank test grants the two banks jointly and supplies no free transmission between them.

## A real replacement at chart 318

Changing 2234 to its original XOR plus its actual local input 1585 reduces the central feedback discrepancy to **e22** after cancelling its local original components. It simultaneously changes the paid feeder through 2677 and the downstream owner-203 read. After granting all eventual terminal readouts the physical word still fails 70 forward and five adjoint rows, and chart 1 has rank 536 for 537 required rows. The five wrong adjoint owners are 17, 22, 266, 267 and 276. Adding X813 at the chart-24 send 3400 and adding e266+e267 at 3399 reduces owner 203's own error to precisely e17; owner 221 remains correct both ways in these two controls. A further route through 1586 and 2944 has 91 forward and five adjoint failures, and loses the forward owner-221 row. All four controls retain 411 and 679 in both orientations. Their full invoices and exact failure lists are included.

## Reproduce

The verifier rebuilds all fourteen physical words, runs the complete operator and literal adjoint, checks the eight-coordinate constraints at every actual MOVE for each release and exhausts the finite bank assignments. Python 3.11 or later and its standard library suffice.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```

For individual tapes use `python3 -I -B verify.py --materialize controls`. None of the tested funded words gives a new conditional κ value. The separate finite outer application has not been reached. [451 comparator](https://github.com/CrocSwap/integer-mult-bounds/pull/7863) · [Independent comparator replay](https://github.com/CrocSwap/integer-mult-bounds/pull/7973)
