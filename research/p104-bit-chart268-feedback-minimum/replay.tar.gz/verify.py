# SPDX-License-Identifier: Apache-2.0
"""Rebuild nine released-column controls and price sender corrections at chart 421."""
from collections import Counter,defaultdict
from functools import reduce
from operator import xor
from pathlib import Path
import argparse,gzip,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
import common
import binary_operator as op
import bit_native
J=(22,51,77,91,92,96,97,98,100)
def req(ok,message):
    if not ok:raise ValueError(message)
def labels(x):return bit_native.indices(x)
def xx(lst):return reduce(xor,lst,0)
def bb(x):return 1<<x
class Basis:
    def __init__(self):self.s={}
    def reduce(self,x,tag=0):
        while x:
            cell=self.s.get(x.bit_length()-1)
            if cell is None:break
            x^=cell[0];tag^=cell[1]
        return x,tag
    def add(self,x,t=0):
        x,t=self.reduce(x,t)
        if x:self.s[x.bit_length()-1]=(x,t)
def run(outdir=None):
    w,caller,_,_,helpers,original,prod,rat=common.baseline()
    atlas=op.Atlas(w['frames']);native=op.run_tape(w,atlas,False)
    start,end,moves,reference,clock=bit_native.extract(w)
    oldorder=sorted(moves,key=clock.get)
    old={p:d.arrival.row for p,d in native.packets.items()};old.update({i:bb(i) for i in start});old[3554]=bb(549)
    del moves[3409],reference[3409]
    moves[3410]=(421,0);moves[1583]=(19,182);moves[3554]=(0,19)
    reference[3410]=bb(1934)^bb(2234)^bb(2947);reference[1583]=bb(3554);reference[3554]=bb(549)
    order=[3554]+[p for p in oldorder if p not in (3409,3410)];order.insert(order.index(2947)+1,3410)
    center=sum(bb(i) for i,c in start.items() if c==0)
    pre=defaultdict(list);cutclock=clock[3411]
    for i,c in start.items():pre[c].append(i)
    for p in order:
        if clock.get(p,-1)<cutclock:pre[moves[p][1]].append(p)
    before=[p for p in pre[0] if p in moves and p!=3410]
    source_421=pre[421]
    req(len(before)==8 and len(source_421)==5 and center.bit_count()==524,'exact pre-reader inventories')
    no_old_value=old[1934]^old[2947];rho=old[3410]^no_old_value;minimal_front=rho&~center
    req(list(labels(minimal_front))==[22,32,40,49,55,59,71,73,83],'nine front coordinates')
    req(list(labels(rho&center))==[266,267,276,298,336,361,398,402,423],'nine central coordinates')
    rows=[(0,0)]
    for p in source_421+before:
        rows.extend([(value^(old[p]&~center),donors^bb(p)) for value,donors in rows])
    req(len(rows)==8192,'complete 5 plus 8 binary choices')
    choices=[];whole=old[3410]&~center
    for value,m in rows:
        r=whole^value
        if not r&(bb(17)|bb(679)):choices.append((r,m))
    best=min(r.bit_count() for r,m in choices)
    minimal=[(r,m) for r,m in choices if r.bit_count()==best]
    req(minimal==[(minimal_front,bb(1934)^bb(2947))] and best==9,'unique full 8192-option optimum')
    single=[]
    def stockspan(ids):
        basis=Basis()
        for p in dict.fromkeys(ids):
            v=no_old_value if p==3410 else old[p]
            basis.add(v&~center,bb(p))
        return basis
    for c in atlas.body:
        B=stockspan(before+[3410]+pre[c]);r,m=B.reduce(minimal_front)
        if not r:single.append(dict(chart=c,grade_to0=atlas.grade(c,0),expression=list(labels(m))))
    req([s['chart'] for s in single]==[1] and single[0]['grade_to0']==8,'one of all 636 frozen sources grants the residue')
    banks={}
    for a,b in [(24,318),(182,318),(182,421),(19,318),(268,318),(268,421),(24,268),(24,0),(19,24),(24,518),(318,518)]:
        B=stockspan(before+[3410]+pre[a]+pre[b]);rem,rep=B.reduce(minimal_front)
        banks[f'{a},{b}']=None if rem else list(labels(rep))
    req(banks['24,318'] is not None and banks['268,318'] is None,'paired early-bank controls')
    allgr=Counter(atlas.grade(a,b) for a,b in moves.values());paid,targets=common.literal.paired_invoice(caller,allgr,helpers,Counter(e[0] for e in caller['events']))
    req(targets==prod,'fixed productive profile')
    def compile_control(name,rows,issued=None,frozen=None):
        order_actual=bit_native.schedule(start,end,moves,rows) if issued is None else issued
        v={i:bb(i) for i in start};delta=[];bychart=defaultdict(Basis)
        for i,c in start.items():bychart[c].add(v[i])
        for p in order_actual:
            v[p]=xx(v[k] for k in labels(rows[p]))
            if frozen is not None and ((v[p]^old[p])&frozen):delta.append(p)
            bychart[moves[p][1]].add(v[p])
        req(not delta,'reference on every retained frozen coordinate, receipt '+name)
        cw=bit_native.emit_word(w,start,end,moves,rows,order_actual)
        tape=[op.run_tape(cw,atlas,a) for a in (False,True)]
        expected=[op.expected_operator(a) for a in (False,True)]
        bad=[[i for i,(r,s) in enumerate(zip(t.output,y)) if r!=s] for t,y in zip(tape,expected)]
        req(all(Counter(p.grade for p in t.packets.values())==allgr for t in tape),'literal paid profiles')
        digest=op.canonical_hash(cw)
        if outdir is not None:
            outdir.mkdir(parents=True,exist_ok=True)
            (outdir/(name+'.json.gz')).write_bytes(gzip.compress(json.dumps(cw,sort_keys=True,separators=(',',':')).encode(),mtime=0))
        return dict(canonical=digest,failures=list(map(len,bad)),forward_bad_owners=bad[0],adjoint_bad_owners=bad[1],
                    owner221=[221 not in b for b in bad],owner411=[411 not in b for b in bad],owner679=[679 not in b for b in bad],
                    literal_erasures=[t.dirty for t in tape],chart1_stock_rank=len(bychart[1].s),owner203_residual=list(labels(tape[0].output[203]^expected[0][203])))
    codes=json.loads((ROOT/'RELEASE-CODES.json').read_text());released=[]
    # Three controls use a single central XOR, six use bounded native donor deltas and the explicit order.
    for drop in J:
        kept=sum(bb(i) for i in J if i!=drop);testmask=kept|bb(17)|bb(679);rr=dict(reference)
        if str(drop) in codes:
            item=codes[str(drop)]
            for p,ds in item['xor_original_donors'].items():rr[int(p)]^=sum(bb(d) for d in ds)
            result=compile_control('release-'+str(drop),rr,issued=order,frozen=kept)
            req(result['canonical']==item['word_canonical'],'literal discovery control')
        else:
            b=Basis()
            for p in pre[0]:
                projected=old[p]^(bb(17) if p==3410 else 0);b.add(projected&testmask,bb(p))
            residual,d=b.reduce(bb(17));req(residual==0,'single central correction')
            for p,row in reference.items():
                if row>>3410&1:rr[p]^=d
            result=compile_control('release-'+str(drop),rr,frozen=kept)
        req(all(not (testmask>>j&1) for j in result['adjoint_bad_owners']),'all required source columns at all outputs')
        req(all(result['failures']),'the limited success has full-map errors')
        result.update(released_input=drop,remaining_inputs=[i for i in J if i!=drop]);released.append(result)
    reduced=dict(reference);reduced[3410]^=bb(2234)
    for p,r in reference.items():
        if r>>3410&1:reduced[p]^=rho&center
    min_control=compile_control('nine-residual',reduced)
    req(min_control['failures']==[63,9] and min_control['adjoint_bad_owners']==list(labels(minimal_front)),'nine-column minimum visibly attained')
    branch=[]
    for ferm in (False,True):
        for side in (False,True):
            rr=dict(reference);rr[2234]^=bb(1585)
            if ferm:rr[1586]^=bb(813)
            for p,r in reference.items():
                if r>>3410&1:rr[p]^=(old[1585]^bb(17))&center
                if ferm and r>>2944&1:rr[p]^=old[813]&center
            if side:rr[3400]^=bb(22)^bb(810);rr[3399]^=bb(266)^bb(267)
            sched=bit_native.schedule(start,end,moves,rr)
            val={i:bb(i) for i in start};avail=defaultdict(Basis)
            for i,c in start.items():avail[c].add(val[i],bb(i))
            for p in sched:
                val[p]=xx(val[j] for j in labels(rr[p]));avail[moves[p][1]].add(val[p],bb(p))
            req(((val[3410]^old[3410])&~center)==bb(22),'one-coordinate feedback after central cancellation')
            for i,c in end.items():
                desired=op.expected_operator(False)[i]
                if xx(val[j] for j in labels(rr[~i]))==desired:continue
                rem,rep=avail[c].reduce(desired)
                if not rem:rr[~i]=rep
            obj=compile_control('e22-'+str(int(ferm))+str(int(side)),rr)
            obj.update(second_1586_ferry=ferm,side617_repaired=side)
            req(obj['failures']==([91,5] if ferm else [70,5]) and obj['chart1_stock_rank']==536,'full e22 branch controls')
            if side and not ferm:req(obj['owner203_residual']==[17],'local 203 debt reduced to input 17')
            branch.append(obj)
    rate_data={};q=rat['signed'];rp={int(k):v for k,v in q['paid'].items()};rt={int(k):v for k,v in q['productive'].items()}
    for r in ['0.00388','0.0038800000000000083']:
        rate=common.D(r);rate_data[r]=dict(binary=common.display(common.moment(paid,prod,rate)),rational=common.display(common.moment(rp,rt,rate)))
    return dict(native_canonical=op.WORD,native_gzip=op.WORD_GZIP,anchor_columns=J,all_releases=released,
             chart0_early_inputs=524,chart0_receipts=before,chart421_stock=source_421,raw_combinations=len(rows),h_and_17_correct_choices=len(choices),
             minimum_weight=best,unique_minimum_donors=list(labels(minimal[0][1])),nine_front=list(labels(minimal_front)),nine_center=list(labels(rho&center)),
             all_single_sources=636,single_hits=single,paired_frozen_bank_tests=banks,unique_min_word=min_control,pure_e22_feedback_words=branch,
             raw_grades=dict(sorted(allgr.items())),paid_36=dict(sorted(paid.items())),productive_36=dict(sorted(prod.items())),signed=rate_data)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--write',action='store_true');a.add_argument('--materialize',type=Path);args=a.parse_args()
    encoded=json.dumps(run(args.materialize),sort_keys=True,indent=2)+'\n'
    if args.write:(ROOT/'RESULT.json').write_text(encoded)
    else:req((ROOT/'RESULT.json').read_text()==encoded,'canonical machine receipt')
    print('PASS: nine paid release words, unique 8192-choice minimum, 636 bank tests, four e22 feedback words, both complete caller prices.')
