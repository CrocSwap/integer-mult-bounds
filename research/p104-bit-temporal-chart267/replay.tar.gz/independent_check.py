#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Run separately authored packet-first-use and rational-price checkers."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'independent'))
import changed_bit_replay as replay
import target_exact as price

def need(x,m):
 if not x:raise ValueError(m)
def readgz(path):return json.loads(gzip.decompress(path.read_bytes()))
def counts(d):return Counter({int(k):v for k,v in d.items()})
def intersects(a,b):
 return Fraction(a[0],price.GRID)<=Fraction(b[1]) and Fraction(b[0])<=Fraction(a[1],price.GRID)
source=HERE/'source'/'inputs'
w=readgz(source/'WORD.json.gz');caller=readgz(source/'EFREE-CALLER.json.gz')
need(sha256((source/'WORD.json.gz').read_bytes()).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9','source word')
need(sha256((source/'EFREE-CALLER.json.gz').read_bytes()).hexdigest()=='757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b','source caller')
receipt=json.loads((HERE/'RESULT.json').read_bytes());charts=replay.Charts(w['frames'])
call_f=replay.caller_transfer(caller,False);call_r=replay.caller_transfer(caller,True)
base_paid,base_prod,base_trace=replay.recount_from_candidate(w,caller,charts)
rates=list(receipt['price_proof']['baseline_margin_at_rates']);cases={}
for name,expected in sorted(receipt['literal_controls'].items()):
 path=HERE/'words'/(name+'.json.gz');raw=path.read_bytes();candidate=readgz(path)
 need(sha256(raw).hexdigest()==expected['gzip_sha256'],'candidate gzip')
 need(replay.canonical_digest(candidate)==expected['canonical_word_sha256'],'candidate canonical')
 need(set(candidate)==set(w) and all(candidate[k]==w[k] for k in w if k!='program'),'unchanged endpoints and layout')
 paid,prod,trace=replay.recount_from_candidate(candidate,caller,charts)
 need(paid==counts(expected['full_paid']) and prod==counts(expected['full_productive'])==base_prod,'complete invoice')
 need(trace['dirty_retirements']==[3554,3554],'retirement counts')
 need(trace['raw_records']==expected['ordinary']['records'] and trace['owned_fields']==expected['ordinary']['owned_fields'],'ordinary')
 prices={}
 for rate in rates:
  orig=price.signed(base_paid,base_prod,rate);new=price.signed(paid,prod,rate)
  delta=(new[0]-orig[1],new[1]-orig[0])
  need(intersects(orig,receipt['price_proof']['baseline_margin_at_rates'][rate]),'baseline price overlap')
  need(intersects(new,expected['complete_margin_at_rates'][rate]),'candidate price overlap')
  need(intersects(delta,expected['gain_at_rates'][rate]),'gain price overlap')
  prices[rate]={'complete_margin':price.interval_output(new),'gain':price.interval_output(delta),'overlaps_primary':True}
 cases[name]={'canonical_sha256':expected['canonical_word_sha256'],'physical':trace,'prices':prices}
 if name=='after-egress-coded-to-full':negative=deepcopy(candidate)
# Mutate a valid paid-packet source while retaining chart legality and check
# that both independently implemented operator directions reject it.
i,= [i for i,e in enumerate(negative['program']) if e==['ADD',1926,741,1]]
negative['program'][i]=['ADD',1926,1356,1]
rejections=[]
for reverse in (False,True):
 try:replay.run_word(negative,charts,reverse)
 except ValueError as e:
  need(str(e)=='all-public linear operator','wrong mutation failure');rejections.append(str(e))
 else:raise ValueError('mutated egress accepted')
print(json.dumps({'status':'PASS_SEPARATE_OPERATOR_INVOICE_AND_PRICE_CROSSCHECK',
 'scope':'Separately authored word interpreter, first-use tracking, complete caller recount and independent directed price engine. Not compiler, erasure, precision or outer application.',
 'caller_forward_sha256':call_f,'caller_adjoint_sha256':call_r,
 'mutated_egress_source_clock':i,'mutated_egress_rejections':rejections,
 'original_physical':base_trace,'cases':cases},indent=2,sort_keys=True))
