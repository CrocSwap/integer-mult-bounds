#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Exact bounded chart-267 temporal rechart test and four literal controls.

Source and the two physical cuts are pinned. The 5-field control performs an
invertible XOR basis change before recharting; it does not assume five named
fields were individually dead. No assertion covers changing exterior payloads.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip,json,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import verify as v
op=v.op
R=lambda c,m: v.require(c,m)
for path,digest in v.PINS.items():
 R(sha256((HERE/'source'/path).read_bytes()).hexdigest()==digest,'source pin '+path)
w=v.read('inputs/WORD.json.gz');caller=v.read('inputs/EFREE-CALLER.json.gz')
R(sha256(v.canon(w)).hexdigest()==v.WORD,'canonical native word')
R(sha256(v.canon({k:w[k] for k in ('frames','start','final')})).hexdigest()==v.LAYOUT,'canonical atlas')
P=w['program'];N=w['public'];owned=w['owned_fields']; frame=w['frames'];atlas=op.Atlas(frame)
addrs=[741,1356,1460,1508,1580,1628]
egress=[1925,1926,1927,1928,1929,1930]
clocks=[4552,4559,4565,4572,4579,4586]
dest=[326,349,374,392,410,428]
R(P[3417]==['MOVE',1628,193,267],'first cut')
for i,(addr,clk,target) in enumerate(zip(egress,clocks,dest)):
 R(P[clk]==['MOVE',addr,267,target],'egress '+str(i))

# Exact Q row reduction, independent of the modular screen.
def rref(vectors):
 basis={}
 for vector in vectors:
  row=list(map(F,vector))
  for p,b in sorted(basis.items()):
   if row[p]:row=[x-row[p]*y for x,y in zip(row,b)]
  j=next((j for j,x in enumerate(row) if x),None)
  if j is None:continue
  row=[x/row[j] for x in row]
  for p,b in list(basis.items()):
   if b[j]:basis[p]=[x-b[j]*y for x,y in zip(b,row)]
  basis[j]=row
 return tuple(tuple(basis[j]) for j in sorted(basis))

def rkbits(rows):
 basis={}
 for row in rows:
  while row:
   k=row.bit_length()-1
   if k in basis:row^=basis[k]
   else:basis[k]=row;break
 return len(basis)

def inds(x):return [i for i in range(x.bit_length()) if x>>i&1]

def capture(reverse,word=w,cuts=(3417,4552)):
 program=word['program']
 cells=[(c,1<<i) for i,c in enumerate(word['final' if reverse else 'start'])]+[None]*owned
 out={};cuts=set(cuts)
 for t in (range(len(program)-1,-1,-1) if reverse else range(len(program))):
  if reverse and t in cuts:out[t]=cells.copy()
  code,addr,*a=program[t]
  if code==('CLEAR' if reverse else 'INIT'):
   R(cells[addr] is None,'open');cells[addr]=(a[0],0)
  elif code==('INIT' if reverse else 'CLEAR'):
   R(cells[addr][0]==a[0],'close');cells[addr]=None
  elif code=='MOVE':
   source,target=a[::-1] if reverse else a
   R(cells[addr][0]==source,'cut tape MOVE');cells[addr]=(target,cells[addr][1])
  elif code=='SWAP':cells[addr],cells[a[0]]=cells[a[0]],cells[addr]
  else:
   R(code=='ADD' and cells[addr][0]==cells[a[0]][0]==a[1],'cut tape ADD')
   d,s=(a[0],addr) if reverse else (addr,a[0]);cells[d]=(a[1],cells[d][1]^cells[s][1])
  if not reverse and t in cuts:out[t]=cells.copy()
 return out

f,b=capture(False),capture(True);cuts={}
for t in (3417,4552):
 R([x[0] if x else None for x in f[t]]==[x[0] if x else None for x in b[t]],'both chart atlases')
 chart_fields=[i for i,x in enumerate(f[t]) if x and x[0]==267]
 R(chart_fields==addrs,'only six active chart-267 fields')
 Frows=[f[t][i][1] for i in addrs];Brows=[b[t][i][1] for i in addrs]
 R(rkbits(Frows)==6 and rkbits(Brows)==(6 if t==3417 else 5),'exact two-direction cut ranks')
 R(all(Frows) and all(Brows),'all named values independently affect suffix')
 cuts[str(t)]={'addresses':addrs,'forward_rank':rkbits(Frows),'adjoint_rank':rkbits(Brows),
  'individual_nonzero_forward':6,'individual_nonzero_adjoint':6,
  'forward_input_supports':[inds(x) for x in Frows],
  'adjoint_output_supports':[inds(x) for x in Brows]}

# Reconstruct all six egress XOR forms relative to the six cut fields.
form={a:1<<i for i,a in enumerate(addrs)};masks=[]
for t in range(3418,4587):
 code,addr,*a=P[t]
 if code=='INIT':form[addr]=0
 elif code=='CLEAR':form.pop(addr,None)
 elif code=='ADD' and a[1]==267:
  R(addr in form and a[0] in form,'egress local input');form[addr]^=form[a[0]]
 elif code=='MOVE' and a[0]==267:masks.append(form[addr])
R(masks==[0b111100,0b111101,0b101011,0b011111,0b101111,0b110111],'egress forms')
R(rkbits(masks)==6 and rkbits(masks[1:])==5,'egress residual rank')
null=[x for x in range(1,64) if all((x&row).bit_count()%2==0 for row in masks[1:])]
R(null==[0b111011],'unique five-form kernel')
R(all(any(row>>i&1 for row in masks[1:]) for i in range(6)),'all six source coordinates remain read')
R(not any(e[0]=='ADD' and e[3]==267 for e in P[4587:]),'no later chart-267 adds')

# The five rank-six destinations intersect in exactly the old rank-four chart,
# and their span has rank eight. Both calculations are over Q.
A=rref(row for z in dest[1:] for row in frame[str(z)]['A'])
B=rref(row for z in dest[1:] for row in frame[str(z)]['B'])
C=rref(frame['267']['A'])
R(len(A)==4 and A==C and len(B)==8,'suffix rational exterior intersection and span')
for z in dest:
 R(frame[str(z)]['dim']==6 and op.annihilates(atlas.body[267],atlas.dual[z]),'source exterior nesting')

# Source independently passes both public maps and caller invoice.
f0,b0,deleted=op.native_checks(w,atlas)
np0,nt0,paid0,target0=op.binary_invoice(w,caller,atlas,f0)
receipt=v.read('inputs/BIT.json')
for actual,name in ((np0,'native_paid'),(nt0,'native_targets'),(paid0,'paid'),(target0,'targets')):
 R(actual==Counter({int(k):n for k,n in receipt['native'][name].items()}),'source invoice '+name)

def exterior_rows(word,tape):
 """Bind the same six ingress and six egress payloads despite new MOVE IDs."""
 ingress=dict(zip(addrs,[11,125,151,163,181,193]));exit_charts=dict(zip(egress,dest))
 out={};ident=N
 for code,addr,*args in word['program']:
  if code!='MOVE':continue
  if addr in ingress and args==[ingress[addr],267]:out[('in',addr)]=tape.packets[ident].arrival.row
  if addr in exit_charts and args[1]==exit_charts[addr]:out[('out',addr)]=tape.packets[ident].arrival.row
  ident+=1
 R(len(out)==12,'identify each fixed exterior payload')
 return out

exterior_forward=exterior_rows(w,f0);exterior_adjoint=exterior_rows(w,b0)

# Find elementary invertible row operations taking I_6 to the five remaining
# egress rows and a sixth complementary row. These are legal cochart ADD/SWAP.
def encoder():
 target=masks[1:]+[1];work=target.copy();ops=[]
 R(rkbits(work)==6,'coded basis nonsingular')
 for col in range(6):
  j=next(j for j in range(col,6) if work[j]>>col&1)
  if j!=col:work[col],work[j]=work[j],work[col];ops.append(('SWAP',col,j))
  for j in range(6):
   if j!=col and work[j]>>col&1:
    work[j]^=work[col];ops.append(('ADD',j,col))
 R(work==[1<<i for i in range(6)],'basis reduction')
 out=[]
 for kind,i,j in reversed(ops):
  out.append([kind,addrs[i],addrs[j]]+([267] if kind=='ADD' else []))
 return out
enc=encoder()

def make_early(chart):
 # A common direct MOVE of each of six named live fields at the first cut.
 new=[]
 for t,event in enumerate(P):
  e=event.copy()
  if t>3417:
   if e[0] in ('INIT','CLEAR') and e[2]==267:e[2]=chart
   if e[0]=='ADD' and e[3]==267:e[3]=chart
   if e[0]=='MOVE':
    if e[2]==267:e[2]=chart
    if e[3]==267:e[3]=chart
  new.append(e)
  if t==3417:new.extend([['MOVE',i,267,chart] for i in addrs])
 q=deepcopy(w);q['program']=new;return q

def make_late(chart):
 # Code the five surviving egress rows in situ. The sixth stays at chart267,
 # unused thereafter; all six remain owned until their original retirements.
 new=[]
 for t,event in enumerate(P):
  if 4553<=t<=4586:continue
  e=event.copy()
  if t>4586 and e[0]=='CLEAR' and e[1] in addrs[:5]:
   R(e[2]==267,'coded retirement original chart');e[2]=chart
  new.append(e)
  if t==4552:
   new.extend(deepcopy(enc))
   new.extend([['MOVE',i,267,chart] for i in addrs[:5]])
   for addr,target,source in zip(egress[1:],dest[1:],addrs[:5]):
    new.extend([['INIT',addr,chart],['ADD',addr,source,chart],['MOVE',addr,chart,target]])
 q=deepcopy(w);q['program']=new;return q

# Full exact public forward and adjoint maps; caller polynomial replay;
# protected bridge and retirement test, accommodating renumbered packets.
def changed_replay(word):
 forward=op.run_tape(word,atlas,False);adjoint=op.run_tape(word,atlas,True)
 for rev,tape in ((False,forward),(True,adjoint)):
  R(tape.output==op.expected_operator(rev),'changed full 680x680 map')
  R(tape.dirty==3554,'changed dirty private count')
  bridge_clock,=[i for i,e in enumerate(word['program']) if e[0]=='MOVE' and e[1]==3553]
  packet_id=N+sum(e[0]=='MOVE' for e in word['program'][:bridge_clock]);p=tape.packets[packet_id]
  R((p.source,p.receiver,p.arrival.row,p.grade)==((*((1,509) if rev else (509,1)),1<<411,4)),'bridge route and row')
  R([k for k,p in tape.packets.items() if p.arrival.row>>411&1]==[packet_id],'bridge isolation')
  deleted,=[i for i,e in enumerate(word['program']) if e[0]=='ADD' and e[1]==3553 and e[2]==411]
  changed=op.run_tape(word,atlas,rev,omit=deleted).output
  R([x^y for x,y in zip(changed,tape.output)]==[(1<<411) if i==411 else 0 for i in range(N)],'bridge omission')
 np,nt,paid,targets=op.binary_invoice(word,caller,atlas,forward)
 R(nt==nt0 and targets==target0,'productive inventory unchanged')
 return forward,adjoint,np,nt,paid,targets

def ordinary(word,paid,targets):
 events=Counter(e[0] for e in caller['events']);calls=events['LOCAL'];ports=caller['ports'];roles=caller['roles']
 native=calls*16*(word['owned_fields']+N+4)*len(word['program'])
 cr=ports*(8*(events['ADD']+3*events['SWAP'])+256*(calls+events['QUERY']+roles))
 route=4*(sum(paid.values())+sum(targets.values()))+8*ports*(calls+events['IDLE_ONE'])
 records=native+cr+route*80*134*135
 fields=calls*(word['owned_fields']+4)+2*ports*roles*len(caller['events'])+16*ports*(calls+events['QUERY']+roles)
 R(records<10**12 and fields<10**7,'ordinary allowance')
 return {'records':records,'record_limit':10**12,'owned_fields':fields,'owned_limit':10**7,'native_events':len(word['program'])}

def normal(counter):return {str(k):counter[k] for k in sorted(counter) if counter[k]}
def signed(targets,paid):
 out=Counter(targets)
 for k,n in paid.items():out[k]-=n
 return out

rates=['0.003879928046155','0.003879928046156','0.003879929046155']
weights={k:{r:v.power_bounds(r,1-F(k),204) for r in set(paid0)|set(target0)|set(range(1,9))} for k in rates}
def quote(hist,k):
 lo=hi=F(0)
 for r,n in hist.items():
  if n:
   x,y=weights[k][r];lo+=n*(x if n>0 else y);hi+=n*(y if n>0 else x)
 return v.decimals((lo,hi))
base_hist=signed(target0,paid0);cases={}
for name,q in [('after-ingress-to-zero',make_early(0)),('after-ingress-to-full',make_early(1)),
               ('after-egress-coded-to-zero',make_late(0)),('after-egress-coded-to-full',make_late(1))]:
 ft,bt,np,nt,paid,targets=changed_replay(q)
 R(exterior_rows(q,ft)==exterior_forward and exterior_rows(q,bt)==exterior_adjoint,
   'all fixed exterior ingress and egress payloads in both orientations')
 h=signed(targets,paid);delta=h.copy();delta.subtract(base_hist)
 raw=v.canon(q);digest=sha256(raw).hexdigest()
 path=HERE/'words'/(name+'.json.gz')
 if '--write-words' in sys.argv:path.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))
 blob=path.read_bytes()
 R(gzip.decompress(blob)==raw,'emitted word differs from recipe '+name)
 coded_observation=None
 if name.startswith('after-egress-coded'):
  cut=4552+len(enc)+5
  cf=capture(False,q,(cut,))[cut];cb=capture(True,q,(cut,))[cut]
  R(all(cf[a][0]==(0 if name.endswith('zero') else 1) for a in addrs[:5]),'five recharted fields')
  R(cf[addrs[5]][0]==267,'sixth field remains')
  R([bool(cb[a][1]) for a in addrs]==[True]*5+[False],'coded individual adjoints')
  R(rkbits(cf[a][1] for a in addrs)==6 and rkbits(cb[a][1] for a in addrs)==5,'coded cut ranks')
  coded_observation={'clock_after_last_transition':cut,'addresses':addrs,
   'charts':[cf[a][0] for a in addrs],
   'forward_input_supports':[inds(cf[a][1]) for a in addrs],
   'adjoint_output_supports':[inds(cb[a][1]) for a in addrs],
   'forward_rank_six_including_old_chart':6,'adjoint_rank':5}
 cases[name]={'canonical_word_sha256':digest,'gzip_sha256':sha256(blob).hexdigest(),
  'native_paid_delta':normal(Counter({k:np[k]-np0[k] for k in set(np)|set(np0)})),
  'native_paid_before':normal(np0),'native_paid_after':normal(np),
  'coded_cut_observation':coded_observation,
  'complete_signed_delta_histogram':normal(delta),
  'full_paid':normal(paid),'full_productive':normal(targets),
  'gain_at_rates':{k:quote(delta,k) for k in rates},
  'complete_margin_at_rates':{k:quote(h,k) for k in rates},
  'native_forward_and_adjoint_coefficients_each':N*N,
  'fixed_exterior_payloads_each_direction':12,
  'caller_forward_and_adjoint_polynomial_coefficients_each':38*38,
  'dirty_retirements_each_way':ft.dirty,'ordinary':ordinary(q,paid,targets)}

one=weights[rates[0]][2][1];R(one<2,'strict grade-two unit bound')
R(6>one,'early minimum transition exceeds first contact')
out={'status':'PASS_FIXED_EXTERIOR_TEMPORAL_OBSTRUCTION_WITH_FOUR_FULL_OPERATOR_CONTROLS',
 'scope':'Two common-frame cuts: after packet 1628 and after packet 1925. Only chart267 internal linear recoding and its live-value chart transitions vary. The six ingress packets and exterior output endpoints, their payloads and all targets remain fixed; no borrowed exterior side-information or altered caller. Fixed source endpoints and no other paid or productive changes.',
 'source':{'head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','word_canonical_sha256':v.WORD,'word_gzip_sha256':v.PINS['inputs/WORD.json.gz']},
 'cuts':cuts,
 'egress':{'packets':egress,'clocks':clocks,'destinations':dest,'destination_ranks':[6]*6,
  'masks_x1_low_bit':[format(x,'06b') for x in masks],
  'all_six_rank':rkbits(masks),'last_five_rank':rkbits(masks[1:]),'last_five_kernel_coordinates':inds(null[0])},
 'rational_geometry':{'suffix_peer_charts':dest[1:],'dual_span_rref':[[str(x) for x in row] for row in A],
  'intersection_dim':8-len(A),'intersection_equals_chart267':True,'peer_span_dim':len(B),
  'possible_common_frame_ranks':[0,1,2,3,4,8],
  'suffix_original_grade':2,'suffix_changed_grade_by_rank':{'0':6,'1':5,'2':4,'3':3,'4':2,'8':2}},
 'price_proof':{'unit':'sum(target grade^(1-kappa)) minus sum(paid grade^(1-kappa))',
  'early_nontrivial_switch':'six independent values need >=6 paid MOVE grade units; first egress can save at most 2^(1-kappa)<2, and later five cannot save',
  'late_only_switch':'five independent suffix forms need >=5 paid MOVE grade units; later five cannot save',
  'optimistic_36_call_gain_upper_early_nontrivial':{k:quote(Counter({2:36,1:-216}),k) for k in rates},
  'optimistic_36_call_gain_upper_late_only':'-180 exactly',
  'baseline_margin_at_rates':{k:quote(base_hist,k) for k in rates},
  'new_scratch':'zero in the four literal controls; no extra owned fields or restore MOVE; reverse uses the same inserted paid MOVEs in reverse, and remaining old field retires on its original chart',
  'coded_basis_ops':enc,'coded_fields':addrs[:5],'uncoded_retired_field':addrs[5]},
 'literal_controls':cases}
print(json.dumps(out,indent=2,sort_keys=True))
