#!/usr/bin/env python3
"""Replay 679-owner control and test new same-bank pulse relations by GF(2) rank."""
from collections import Counter, defaultdict, deque
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip,json,sys

HERE=Path(__file__).resolve().parent
PINS={
 'project.py':'cf3ff945359cadab95132faee37dabac6fb456adfc1f7db31df3bae6666790c3',
 'ZERO-CONTROL-WORD.json.gz':'f0aa75a63cc9200f627721851bd68c27367ae80e7fca2f0fe6f515fe2bfc9f63',
 'inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'inputs/BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
 'inputs/physical.py':'34dbf131f9d305d8e98b7284476dab2d2a250a28a02d3cf4c55b4232cfd0d435',
 'inputs/finite.py':'c780cea060f4a9efef064b239636162a7e8e84e40369abc1a1c4679dfbeb3041',
 'inputs/bit_native.py':'4368c62a5d42f81189d6776b8dba8c85a311b6a199b816244b545c6bb7d3dc1e',
 'inputs/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'inputs/price.py':'d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b'}
for name,digest in PINS.items():
 if sha256((HERE/name).read_bytes()).hexdigest()!=digest:raise ValueError('input pin '+name)
sys.path[:0]=[str(HERE),str(HERE/'inputs')]
import project as p, bit_native as bit, literal, price


def rank(words):
 """Rank of bit-packed GF(2) columns, with elimination pivots."""
 basis={}
 for value in words:
  while value:
   pivot=value.bit_length()-1
   if pivot not in basis:
    basis[pivot]=value;break
   value^=basis[pivot]
 return len(basis)


def brute_nonempty_zero_subsets(words):
 """Independent Gray-code enumeration, for the four small changed banks."""
 previous=0
 value=0
 zeros=0
 for i in range(1,1<<len(words)):
  gray=i^(i>>1)
  changed=gray^previous
  value^=words[changed.bit_length()-1]
  zeros+=not bool(value)
  previous=gray
 return zeros

# The test must detect a relation created by the precise projection in use.
assert rank([1,1^(1<<649)])==2 and rank([1,(1^(1<<649))&~(1<<649)])==1

def evaluate(initial,final,moves,rows):
 order=bit.schedule(initial,final,moves,rows)
 values={j:1<<j for j in initial}
 for k in order:values[k]=bit.combine(rows[k],values)
 for j in final:
  expected=(1<<j)^((1<<(j+111)) if j<111 else 0)
  if bit.combine(rows[~j],values)!=expected:raise ValueError(f'adjoint owner {j}')
 columns={j:0 for j in initial.keys()|moves.keys()}
 for j in final:
  for k in bit.indices(rows[~j]):columns[k]^=1<<j
 for k in reversed(order):
  for parent in bit.indices(rows[k]):columns[parent]^=columns[k]
 return order,values,columns


def clean(c):return {int(k):int(v) for k,v in sorted(c.items()) if v}

def replay_literal(word,charts,caller,events):
 n=word['public'];charts.main_contacts(word['start'],word['final'])
 f,fl,_=literal.tape(word,charts);b,bl,_=literal.tape(word,charts,adjoint=True)
 assert f==literal.expected_rows(n,False) and b==literal.expected_rows(n,True)
 assert fl['paid']==bl['paid']
 targets=Counter(charts.leg(word['start'][j],word['final'][j]) for j in range(222,n))
 paid,all_targets=literal.paired_invoice(caller,fl['paid'],targets,events)
 ordinary=literal.ordinary(word,caller,events,paid,all_targets)
 return {'public':n,'native_coefficient_matrix_size_each_direction':[n,n],
         'native_paid':clean(fl['paid']),'native_targets':clean(targets),
         'paired_paid':clean(paid),'paired_targets':clean(all_targets),
         'ordinary':ordinary,'program_counts':dict(sorted(fl['counts'].items())),
         'native_calls':events['LOCAL'],'exact_forward_and_transpose':True}

original=json.loads(gzip.decompress((HERE/'inputs/WORD.json.gz').read_bytes()))
control=json.loads(gzip.decompress((HERE/'ZERO-CONTROL-WORD.json.gz').read_bytes()))
assert literal.canonical(original)==p.physical.TREE_WORD
assert literal.canonical(control)=='09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be'
assert original['public']==680 and control['public']==679
assert 411 in [j for j in range(680) if j!=649]
assert control['start']==[v for j,v in enumerate(original['start']) if j!=649]
assert control['final']==[v for j,v in enumerate(original['final']) if j!=649]
assert control['frames']==original['frames']
# Recover the original packet labels from the physical word before specialization.
x=p.project({649},keep=frozenset({3266,2926,2982}))
assert not x['erased'] and len(x['alive'])==2874
initial={j:c for j,c in p.initial.items() if j!=649}
final={j:c for j,c in p.final.items() if j!=649}
moves={k:p.moves[k] for k in x['alive'] if k!=3266}
rows={k:p.orig[k]&~(1<<649) for k in moves}
rows.update({~j:p.orig[~j]&~(1<<649) for j in final})
donor_row=p.orig[3266]&~(1<<649)&~(1<<3266)
assert donor_row==0, 'the nominal donor XORs are empty after projection'
for k in rows:rows[k]&=~(1<<3266)
old_order,oldvals,oldcols=evaluate(p.initial,p.final,p.moves,p.orig)
order,vals,cols=evaluate(initial,final,moves,rows)
assert len(moves)==2873
# Recompile back to forward literal form, proving the packet graph really is the
# supplied 679-owner control, not merely a graph with the same endpoints.
forward,frows=p.physical.dual(p.n,moves,rows)
forder=bit.schedule(final,initial,forward,frows)
bit.basis(final,forward,frows,forder)
reconstructed=bit.emit_word(original,final,initial,forward,frows,forder)
assert reconstructed==control
assert json.dumps(reconstructed,sort_keys=True,separators=(',',':')).encode()==gzip.decompress((HERE/'ZERO-CONTROL-WORD.json.gz').read_bytes())
print('PASS exact control reconstruction',flush=True)

mask=~(1<<649);survivors=set(initial)|set(moves)
assert all(vals[k]==oldvals[k]&mask and cols[k]==oldcols[k]&mask for k in survivors)
assert all(not(oldcols[k]&(1<<649)) for k in survivors)
assert p.orig[3266]==1<<649
changed=sorted(k for k in moves if (oldvals[k]>>649)&1)
assert changed==[2282,2471,2472,2926,2982]
# Input coefficients at the adjoint arrival chart are forward reverse pulses.
# A drop in their GF(2) rank would produce a same-bank relation available only
# after projection. It is necessary and sufficient for arbitrary linear donor
# sets; using all same-chart public origins and retained packets is a superset
# of any particular realizable causal sender edit.
banks=defaultdict(list)
for j,chart in initial.items():banks[chart].append(j)
for k,(_,arrival) in moves.items():banks[arrival].append(k)
affected=sorted({moves[k][1] for k in changed})
assert affected==[349,506,511,536]
rank_rows=[]
for bank in affected:
 sources=sorted(banks[bank]);pre=[oldvals[k] for k in sources];post=[vals[k] for k in sources]
 before,after=rank(pre),rank(post)
 assert before==after==len(sources)
 assert brute_nonempty_zero_subsets(pre)==brute_nonempty_zero_subsets(post)==0
 rank_rows.append({'arrival_chart':bank,'source_count':len(sources),
                   'owner_sources':[k for k in sources if k in initial],
                   'packet_sources':[k for k in sources if k in moves],
                   'changed_packets':[k for k in sources if k in changed],
                   'pre_rank':before,'post_rank':after,
                   'nonempty_subsets_enumerated_each_way':(1<<len(sources))-1,
                   'nonempty_zero_subsets_each_way':0})
# Every other same-bank family is bit-for-bit unchanged. In the other orientation
# every surviving reverse pulse is bit-for-bit unchanged, so no rank change can
# occur there either. Establish the checked source/packet counts explicitly.
assert all(vals[k]==oldvals[k] for chart,ks in banks.items() if chart not in affected for k in ks)
sender_banks=defaultdict(list)
for k,(sender,_) in moves.items():sender_banks[sender].append(('packet',k))
for j,chart in final.items():sender_banks[chart].append(('terminal',j))
assert sum(map(len,banks.values()))==3552 and sum(map(len,sender_banks.values()))==3552
for family in sender_banks.values():
 for kind,k in family:
  # A terminal's reverse pulse is its own unit column, and is unchanged for
  # surviving owners. Packet columns are recomputed on both complete graphs.
  pre,post=(oldcols[k],cols[k]) if kind=='packet' else (1<<k,1<<k)
  assert pre==post
# Independently test whether a changed packet could already have been removed
# by *any* direct linear same-sender donor combination, including terminal
# recipients. This is a fixed-graph test, not a later cascading-edit theorem.
essential=[]
for k in changed:
 family=sender_banks[moves[k][0]]
 def pulse(entry):
  kind,j=entry
  return cols[j] if kind=='packet' else 1<<j
 other=[pulse(entry) for entry in family if entry!=('packet',k)]
 r0=rank(other);r1=rank(other+[cols[k]])
 assert r1==r0+1
 essential.append({'packet':k,'sender_chart':moves[k][0],
                   'other_packets_and_terminal_receivers':len(other),
                   'donor_span_rank':r0,'rank_with_packet':r1})
# Measure the specified two-hop cone in the original packet graph. The donor
# packets are included as explicit seeds; this is a superset of the owner-only
# two-hop neighborhood. Owner nodes and packets share the old, unambiguous IDs.
adj=defaultdict(set)
for child,row in p.orig.items():
 if child<0:continue
 for parent in bit.indices(row):adj[child].add(parent);adj[parent].add(child)
seeds=(649,3266,2926,2982);distance={s:0 for s in seeds};queue=deque(seeds)
while queue:
 k=queue.popleft()
 if distance[k]==2:continue
 for v in adj[k]:
  if v not in distance:distance[v]=distance[k]+1;queue.append(v)
assert len(distance)==128 and all(k in distance for k in changed)
print('PASS no newly introduced same-bank relation in either orientation',flush=True)

charts=literal.Charts(original['frames'])
caller=literal.pinned(HERE/'inputs/EFREE-CALLER.json.gz',literal.CALLER_SHA)
events=Counter(e[0] for e in caller['events'])
base=replay_literal(original,charts,caller,events)
test=replay_literal(control,charts,caller,events)
paid_banks={event[1] for event in control['program'] if event[0]=='MOVE'}
literal_controls=literal.held_out(control,charts,paid_banks)
assert literal_controls['omitted_ADD_clock']==389 and literal_controls['changed_coefficients']==64
assert literal_controls['omitted_CLEAR_clock']==38717
ref=json.loads((HERE/'inputs/BIT.json').read_bytes())['native']
assert base['paired_paid']=={int(k):v for k,v in ref['paid'].items()}
assert base['paired_targets']=={int(k):v for k,v in ref['targets'].items()}
assert base['ordinary']==ref['ordinary']
assert events['LOCAL']==36
paid_delta=Counter(test['paired_paid']);paid_delta.subtract(base['paired_paid'])
target_delta=Counter(test['paired_targets']);target_delta.subtract(base['paired_targets'])
assert clean(paid_delta)=={4:-36} and clean(target_delta)=={4:-36}
net_delta=Counter(target_delta);net_delta.subtract(paid_delta)
assert not clean(net_delta)
signed=Counter(test['paired_targets']);signed.subtract(test['paired_paid'])
base_signed=Counter(base['paired_targets']);base_signed.subtract(base['paired_paid'])
assert clean(signed)==clean(base_signed)
trials={}
for trial in ('0.003879928046156','0.003879929046155'):
 k=Fraction(trial)
 b=price.moment(base_signed,k);c=price.moment(signed,k)
 assert b==c and price.moment(clean(net_delta),k)==(0,0)
 missing_debit=price.moment({4:36},k)
 assert missing_debit[0]>0
 trials[trial]={'full_signed_margin_interval':price.decimal_interval(c,30),
                'signed_delta_interval':price.decimal_interval((0,0),30),
                'fabricated_gain_if_target_debit_omitted':price.decimal_interval(missing_debit,30)}
result={'status':'NO_NEW_SAME_BANK_PULSE_RELATION',
 'scope':'Literal 679-owner control; original packet graph retained, 649 specialized, 3266 removed. Same-bank GF(2) relations of surviving original packet pulses plus public-origin pulses. No multi-step recoding, chart change, new packets, or alternate compiler is excluded.',
 'starting_control_canonical_sha256':literal.canonical(control),
 'original_comparator_canonical_sha256':literal.canonical(original),
 'reconstructed_control_equals_supplied_word':True,
 'original_owners_removed':[649],'original_owner_411_retained':True,
 'original_packet_removed':3266,'nominal_donor_packets':[2926,2982],
 'nominal_donor_transfer_row_after_projection_is_zero':True,
 'retained_original_packets':len(moves),'retained_public_owners':len(initial),
 'specialized_changed_adjoint_payload_packets':changed,
 'specialized_adjoint_payload_changed_banks':rank_rows,
 'changed_payloads_not_in_same_sender_donor_span':essential,
 'unchanged_adjoint_arrival_banks':len(banks)-len(affected),
 'adjoint_surviving_reverse_columns_bitwise_unchanged':True,
 'two_hop_seeds':list(seeds),'two_hop_total_nodes':len(distance),
 'two_hop_distance_counts':clean(Counter(distance.values())),
 'two_hop_retained_packet_nodes':sum(v in moves for v in distance),
 'same_bank_rank_test_synthetic_projection_control':'PASS: rank drops 2 to 1 when a projected owner creates a relation',
 'literal_corruption_controls':literal_controls,
 'genuine_retained_payload_edit_constructed':False,
 'post_rewrite_pruning':'not applicable: no required newly equal same-bank pulse relation',
 'literal_comparator':base,'literal_control':test,
 'paired_paid_delta_control_minus_comparator':clean(paid_delta),
 'paired_targets_delta_control_minus_comparator':clean(target_delta),
 'complete_signed_histogram_delta':clean(net_delta),'trials':trials,
 }
(HERE/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print('PASS full literal and 36-call repricing',json.dumps(trials,sort_keys=True),flush=True)
print('NO_NEW_SAME_BANK_PULSE_RELATION',flush=True)
