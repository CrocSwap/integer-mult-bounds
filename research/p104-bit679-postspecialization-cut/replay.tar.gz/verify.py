#!/usr/bin/env python3
"""Pin-check and reproduce the 679-control finite receipt offline."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse,os,shutil,subprocess,sys,tarfile
HERE=Path(__file__).resolve().parent
ARCHIVE_SHA='87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096'
UPSTREAM_FILES=('project.py','ZERO-CONTROL-WORD.json.gz','ZERO-CONTROL.json','NOTICE',
 'inputs/WORD.json.gz','inputs/EFREE-CALLER.json.gz','inputs/BIT.json','inputs/physical.py',
 'inputs/finite.py','inputs/bit_native.py','inputs/literal.py','inputs/price.py',
 'inputs/LICENSE','inputs/NOTICE-7786','inputs/NOTICE-7830','inputs/NOTICE-PAID-BIRTHS')

def check_manifest(root):
 seen=set()
 for line in (root/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1);path=Path(name)
  if path.is_absolute() or '..' in path.parts or name in seen:raise ValueError('invalid manifest path')
  seen.add(name)
  if sha256((root/path).read_bytes()).hexdigest()!=expected:raise ValueError('manifest mismatch: '+name)
 for name in (*UPSTREAM_FILES,'UPSTREAM-SOURCES.json','audit.py','verify.py','RESULT.json','README.md','SOURCES.json'):
  if name not in seen:raise ValueError('manifest missing '+name)

def check_archive(root,path):
 if sha256(path.read_bytes()).hexdigest()!=ARCHIVE_SHA:raise ValueError('upstream archive SHA')
 with tarfile.open(path,'r:gz') as tar:
  for name in UPSTREAM_FILES:
   member=tar.extractfile('./'+name)
   if member is None or member.read()!=(root/name).read_bytes():raise ValueError('upstream member mismatch: '+name)
  if tar.extractfile('./SOURCES.json').read()!=(root/'UPSTREAM-SOURCES.json').read_bytes():
   raise ValueError('upstream sources manifest mismatch')
 print('PASS upstream #7912 archive digest and all bundled inherited bytes',flush=True)

def run_audit(root,expect_success=True):
 env=os.environ.copy();env['OMP_NUM_THREADS']='1';env['OPENBLAS_NUM_THREADS']='1'
 r=subprocess.run([sys.executable,'-IB','audit.py'],cwd=root,env=env,capture_output=True,text=True,timeout=120)
 if expect_success and r.returncode:raise ValueError('audit failed\n'+r.stdout+'\n'+r.stderr)
 if not expect_success and r.returncode==0:raise ValueError('corrupted source accepted')
 return r.stdout

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--upstream-archive',type=Path)
 args=ap.parse_args();check_manifest(HERE)
 if args.upstream_archive:check_archive(HERE,args.upstream_archive)
 expected=(HERE/'RESULT.json').read_bytes()
 with TemporaryDirectory(prefix='bit679-fixed-graph-') as temp:
  root=Path(temp)/'source'
  shutil.copytree(HERE,root,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
  print(run_audit(root),end='')
  if (root/'RESULT.json').read_bytes()!=expected:raise ValueError('recomputed result differs')
  check_manifest(root)
  print('PASS offline recomputation matches exact receipt',flush=True)
  for name in ('ZERO-CONTROL-WORD.json.gz','inputs/BIT.json','project.py','RESULT.json'):
   path=root/name;raw=path.read_bytes();path.write_bytes(raw+b'\n')
   try:check_manifest(root)
   except ValueError:pass
   else:raise ValueError('corrupt manifest member accepted: '+name)
   if name!='RESULT.json':run_audit(root,expect_success=False)
   path.write_bytes(raw)
  print('PASS source and receipt corruption rejections',flush=True)
 print('PASS standalone 679-control audit',flush=True)
if __name__=='__main__':main()
