# Fixed-graph post-specialization pulse audit

The literal 679-owner control from [#7912 at `83ece5a`](https://github.com/CrocSwap/integer-mult-bounds/blob/83ece5a62d3addbee45bad9594ef4809851b833b/research/p104-bit-adjoint-multidonor-cut/README.md) introduces **no new same-bank GF(2) pulse relation in the fixed surviving packet graph**. The check includes all surviving public owners and keeps original owner 411. It constructs no further changed payload, no pruning cascade, and no improved κ result. This is a finite obstruction to the direct post-specialization pulse route; it does not exclude a later cascade following a different first edit.

The control already surrendered original owner 649 and removed original packet 3266. It has 679 public owners and 2,873 retained packets. This audit does not surrender any further owner. Packet identifiers below are those of the original 680-owner graph; they are not the packet ordinals in the recompiled control. The nominal edits to packets 2926 and 2982 do not count as a gain: the added sender row is literally zero after owner 649 is specialized.

## What was checked

Starting from #7912's original graph and exact control, the program recovers the adjoint packet graph, specializes only owner 649, and deletes only packet 3266. It schedules and emits the forward literal control again, requiring identical canonical JSON bytes to the supplied word. It checks every surviving endpoint of the derived adjoint graph and then checks the literal 679-by-679 scalar map in both orientations. The full 680-by-680 #7830 comparator is checked the same way.

As an initial bounded region, the undirected packet-parent graph is explored two hops from seeds 649, 3266, 2926 and 2982. The resulting superset has 128 nodes, including 105 retained packets. The proof below in fact covers every surviving packet, so it is stronger than this particular two-hop screen.

Only five retained adjoint payloads lose an original owner-649 coefficient: `2926`, `2982`, `2471`, `2472` and `2282`. For each arrival chart containing one of them, form the complete family of all retained packet payloads arriving at that chart **and all public-origin payloads at that chart**. Before/after means the original 680-coordinate vectors and their coordinate-649 projections, with the deleted packet and owner excluded from both families.

| Arrival chart | Family size | Before rank | After rank | Changed packet(s) |
| ---: | ---: | ---: | ---: | --- |
| 349 | 3 | 3 | 3 | 2471, 2472 |
| 506 | 18 | 18 | 18 | 2282 |
| 511 | 3 | 3 | 3 | 2926 |
| 536 | 4 | 4 | 4 | 2982 |

All remaining 632 arrival-chart families are bitwise unchanged. Projection can only enlarge a family's linear-relation kernel; equal ranks prove that the kernel did not enlarge. A separately implemented Gray-code enumeration checks every nonempty subset both before and after in the four changed families, including 262,143 subsets per orientation at chart 506. In the other direction, every surviving packet's adjoint reverse pulse is bitwise unchanged, and surviving terminal pulses remain their unit columns. Thus no new linear equality among cocharted surviving packet/public pulses appears in either orientation, even if one allows arbitrarily many donors. This is stronger than merely checking original packet pairs or triples.

For an additional fixed-graph check, each of the five changed packets has a reverse pulse outside the span of **all** other same-sender packet and terminal pulses. Their donor-span ranks increase by one on adding the chosen packet: `2→3` for 2282, `1→2` for 2471, `3→4` for 2472, and `535→536` for both 2926 and 2982. This rules out a direct alias removal of these five by a linear rewrite in the current graph, without imposing an artificial donor-count limit. It does not assert that every possible graph edit must take this form.

The evidence applies to this fixed graph and this specialization. Rewriting a retained sender by a separately available mechanism may change downstream payloads or sensitivities, create new equalities or zero/dead packets, and require a fresh fixed-point prune and full invoice. Altering charts, introducing new packets, surrendering another owner, alternate compilers, nonlinear constructions, and such post-edit cascades are outside this check.

## Complete caller economics

Both literal words pass rational chart/leg checks, both arbitrary-input maps and complete private retirement. The inherited caller's 36 native calls and full paid/target histograms are rebuilt and the #7830 full invoice is checked against its frozen `BIT.json`. The control removes 36 paid rank-4 occurrences and 36 productive target rank-4 occurrences, so the complete signed target-minus-paid histogram delta is exactly zero. Ordinary records decrease from `934182831504` to `933664973520`, and owned backing from `6998544` to `6998472`; both remain within their stated allowances. All grades and ordinary counts are in [RESULT.json](RESULT.json).

| Trial | Full signed target-minus-paid interval | Delta from #7830 |
| --- | --- | --- |
| `0.003879928046156` | [`-0.000000000767001502431130261464`, `-0.000000000767001502431130261463`] | exactly `0` |
| `0.003879929046155` | [`-0.000385127316613866441054139473`, `-0.000385127316613866441054139472`] | exactly `0` |

The directed intervals describe this finite signed tariff, not a standalone proof of the inherited full-bound premises.

## Replay and controls

With Python 3.12 and standard library only:

```sh
python3 -IB verify.py
```

The verifier checks the packaged manifest, reruns the audit on one Python process in a disposable directory, compares the entire receipt byte for byte, and rejects alterations to the control word, original comparator invoice, projection program, and receipt. The rank test detects a deliberately manufactured relation under coordinate projection. A separate live `ADD` omission changes 64 public coefficients in both orientations; omitting a private `CLEAR` fails retirement. A deliberately omitted productive debit falsely creates a positive signed gain and is reported as a bad-price control. The nominal 2926/2982 transfers correctly remain omittable negative controls; they are not the live `ADD` used for corruption testing.

The #7912 archive was fetched at the pinned commit, its full SHA-256 checked and each bundled upstream source and control byte compared with its archive member. To repeat that extra provenance check offline, supply that exact downloaded archive:

```sh
python3 -IB verify.py --upstream-archive /path/to/replay.tar.gz
```

[SOURCES.json](SOURCES.json) identifies the archive and [UPSTREAM-SOURCES.json](UPSTREAM-SOURCES.json) retains its original source provenance. Copied Apache-2.0 code and original notices remain under [inputs](inputs/).
