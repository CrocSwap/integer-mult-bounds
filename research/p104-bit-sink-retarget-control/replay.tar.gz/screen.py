#!/usr/bin/env python3
"""Optimistic one-ingress, one-helper pure-owner retarget screen."""
from collections import Counter,defaultdict
from fractions import Fraction as F
from pathlib import Path
import json,os,sys
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'vendor'))
import binary_operator as op, price
if not __debug__: raise RuntimeError('assertions required')
if hasattr(os,'sched_getaffinity'):
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
w=op.load_json(H/'inputs/WORD.json.gz',op.WORD_GZIP,True)
assert op.canonical_hash(w)==op.WORD
atlas=op.Atlas(w['frames']);f=op.run_tape(w,atlas,False)
incoming=f.stock[1];outgoing=f.demand[1]
assert len(incoming)==len(outgoing)==537
assert all(o.label>=680 for o in incoming) and all(o.label<0 for o in outgoing)
# Express every original output in the independent ingress basis. Deleting one
# ingress leaves all output rows except j reproducible exactly iff that ingress
# coefficient occurs only in j's expansion.
basis={}
for i,o in enumerate(incoming):
    row=o.row;mask=1<<i
    while row:
        p=row.bit_length()-1
        if p not in basis:
            basis[p]=(row,mask);break
        a,b=basis[p];row^=a;mask^=b
    assert row
assert len(basis)==537
required_by=[[] for _ in incoming]
for o in outgoing:
    row=o.row;mask=0
    while row:
        p=row.bit_length()-1
        assert p in basis
        a,b=basis[p];row^=a;mask^=b
    while mask:
        bit=mask&-mask;required_by[bit.bit_length()-1].append(~o.label);mask^=bit
assert all(required_by)
indices=[i for i,owners in enumerate(required_by)
         if len(owners)==1 and owners[0]>=222 and owners[0]!=411]
owners={required_by[i][0] for i in indices}
assert len(indices)==len(owners)==15
def rank(rows):
    pivots={}
    for row in rows:
        while row:
            bit=row.bit_length()-1
            if bit not in pivots:
                pivots[bit]=row;break
            row^=pivots[bit]
    return len(pivots)
for i in indices:
    j=required_by[i][0]
    kept=[o.row for q,o in enumerate(incoming) if q!=i]
    targets=[o.row for o in outgoing if ~o.label!=j]
    assert len(kept)==len(targets)==536
    assert rank(kept)==rank(targets)==rank(kept+targets)==536
# Enumerate every moment at which a pure owner row appears before all incoming
# packets are in: initial stocks and the result of each instruction. Saving a
# short-lived copy, repairing its readers and running the owner exit are all
# granted for free. Thus the price test is optimistic.
cells=[(c,1<<j) for j,c in enumerate(w['start'])]+[None]*w['owned_fields']
observed=defaultdict(dict)
def inspect(a,clock):
    item=cells[a]
    if item is None:return
    c,row=item
    if row and not row&(row-1):
        j=row.bit_length()-1
        if j in owners and c!=1:
            observed[j].setdefault(c,{'field':a,'chart':c,'first_observed_clock':clock})
for j in owners:inspect(j,-1)
for clock,(code,a,*arg) in enumerate(w['program']):
    if clock==31291:break
    assert code not in ('CLEAR','SWAP')
    if code=='INIT':cells[a]=(arg[0],0)
    elif code=='ADD':cells[a]=(cells[a][0],cells[a][1]^cells[arg[0]][1])
    else:
        assert code=='MOVE' and cells[a][0]==arg[0]
        cells[a]=(arg[1],cells[a][1])
    inspect(a,clock)
# We keep the original ordinal/field relation even if a hypothetical deletion
# would renumber every later packet.
moves=[(clock,row[1]) for clock,row in enumerate(w['program']) if row[0]=='MOVE']
all_reads=defaultdict(list)
for clock,row in enumerate(w['program']):
    if row[0]=='ADD':all_reads[row[2]].append((clock,row[1]))
results=[];signs=Counter()
for i in indices:
    j=required_by[i][0]; arrival=incoming[i]; packet=f.packets[arrival.label]
    src_clock,field=moves[arrival.label-680];assert src_clock==packet.clock
    old_grade=atlas.grade(w['start'][j],1);packet_grade=packet.grade
    readers=all_reads[field]
    assert len(readers)==1
    reader_clock,target=readers[0]
    target_readers=[(k,row) for k,row in enumerate(w['program']) if row[0] in ('ADD','SWAP') and row[2]==target]
    assert len(target_readers)==1 and target_readers[0][1]==['SWAP',j,target]
    exit_clock=target_readers[0][0]
    assert w['program'][exit_clock+1]==['CLEAR',target,w['start'][j]]
    options=[]
    for c,item in sorted(observed[j].items()):
        retained_grade=atlas.grade(w['start'][j],c)
        if not retained_grade and c!=w['start'][j]:continue
        delta=Counter({packet_grade:1});delta[old_grade]-=1
        if retained_grade:delta[retained_grade]+=1
        delta={g:n for g,n in delta.items() if n}
        moments={k:price.moment(delta,F(k)) for k in ('0.003879928046156','0.003879929046155')}
        if not delta: disposition='zero'
        else:
            assert all(moment[1]<0 for moment in moments.values())
            disposition='negative'
        signs[disposition]+=1
        options.append({**item,'retained_productive_grade':retained_grade,
                        'optimistic_one_call_signed_change':{k:price.decimal_interval(v,18) for k,v in moments.items()},
                        'disposition':disposition})
    assert options
    results.append({'owner':j,'ingress_packet':arrival.label,'field':field,
                    'route':[packet.source,packet.receiver], 'arrival_clock':src_clock,
                    'paid_grade':packet_grade,'old_productive_grade':old_grade,
                    'arrival_row_support':arrival.row.bit_count(),
                    'only_packet_read':{'clock':reader_clock,'target_field':target},
                    'only_target_field_reader':{'clock':exit_clock,'operation':['SWAP',j,target]},
                    'old_owner_retired_in_target_field_at_next_clock':True,
                    'pure_owner_copy_options':options})
assert signs==Counter({'zero':13,'negative':3})
assert {r['owner'] for r in results}=={237,250,264,274,351,355,383,387,391,432,634,639,648,649,650}
receipt={'status':'PASS_NO_POSITIVE_OPTIMISTIC_SINGLE_INGRESS_SINGLE_HELPER_RETARGET',
 'scope':'Keep all original chart-1 arrivals except exactly one, keep 411 and every other original chart-1 output, retarget exactly one helper to an already-live pure-owner field seen at any time through clock 31290. Require a nested original-start-to-new-output grade or same chart. The bound grants free copying, all reader repairs and all owner-exit work, and adds no paid routes. It does not cover XOR-synthesized copies, changes to routes or more arrivals.',
 'rank_original_arrivals_and_fixed_outputs':537,
 'direct_rank_check_of_each_536_arrival_and_536_output_union':True,
 'recoverable_single_ingress_helper_pairs':len(results),
 'pure_owner_chart_choices':sum(signs.values()),'nonpositive_choices':dict(signs),
 'comparison_kappa':['0.003879928046156','0.003879929046155'],
 'entries':results}
text=json.dumps(receipt,sort_keys=True,indent=2)+'\n'
if '--emit' in sys.argv:(H/'SCREEN.json').write_text(text)
assert (H/'SCREEN.json').read_text()==text
print('PASS 15 helper/ingress pairs; 16 optimistic pure-owner chart choices; 13 tie and 3 lose')
