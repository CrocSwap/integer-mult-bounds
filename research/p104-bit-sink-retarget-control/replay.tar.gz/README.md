# One-helper chart-1 retarget: owner 432 and an optimistic cut screen

The first requested helper retarget gives **zero signed gain**. Public helper 432 has a pure, independent live copy in chart 509 before its original packet 3544 enters chart 1. Returning this owner at chart 509 permits removal of that one grade-4 ingress, its sole output reader, and its old owner-exit path. The original productive endpoint was also grade 4; the changed endpoint has grade 0. Saving one `H4` paid charge and surrendering one `H4` productive target cancels exactly, for every exponent. No new κ bound follows.

The result changes only helper 432's declared final chart, the eight instructions in its isolated return path, and their consequently shifted instruction positions. The 411 bridge and 222 main fields remain fixed. Chart 1 then has 536 arrivals and 536 fixed output rows, both of rank 536: the #7901 rank-537 cut does not apply unchanged after removing an output endpoint. The one-owner result does not rule out other output retargets or changed routes.

## Owner 432, every reader and the exit

All clocks here are in the original word. Field references are separated from numeric chart labels.

| Clock | Operation and consequence |
| ---: | --- |
| 31261–31263 | Initialize private field 3544, copy public owner 432 into it at chart 509, and move it to chart 1 at grade 4. Immediately before the move, fields 432 and 3544 are the only live fields containing owner 432 and both hold the pure owner row at chart 509. |
| 36133–36134 | Initialize private field 3986 at chart 1 and add 3544 into it. This is the sole ADD reader of 3544. |
| 39588–39589 | Swap 3986 into public 432 and retire the former public field at chart 509. The scratch field has no other reader. |
| 42948 | Retire packet field 3544 at chart 1. |

The replay enumerates **all** field uses and propagates the owner-432 coefficient through every instruction. No other packet, owner, or main field uses this direction. The changed word removes the eight listed path instructions and leaves the original public field 432 in chart 509. It retains all other instructions verbatim, including the 411 bridge. Its 3,554 private field labels are preserved, with 3544 and 3986 unused; dirty retirements fall from 3,554 to 3,552 in each orientation.

The archived changed word has canonical SHA-256 `64617ccc259cc360fcf036edffd64046830bf3ff08d8705bc0f663ed437b4453`. The replay checks all 680 public output rows, or 462,400 field coefficients, forward and adjoint. It compares all 2,873 surviving packet payloads, routes and grades in both orientations by field identity rather than by the packet ordinal, which shifts after deletion. An omitted 411 injection still flips only output 411 in either orientation. Declaring the former chart-1 exit for owner 432 makes the changed word fail its endpoint check.

## Physical address binding

The changed endpoint must use the changed physical address action. In the retained rational chart view, write `S_c = I − 2P_c`. The original owner action is `S_1 S_509`; the retargeted action is `S_509 S_509 = I`. The replay verifies these matrices exactly over the rationals and verifies the corresponding reverse actions. They are different: for the chart-509 dual vector `v = (-1,1,1,1,0,0,0,0)`, the original forward and adjoint actions carry `v` to `−v`, while the retargeted actions fix it.

As an independent-address control the replay reduces the exact matrices modulo 5, where `v` and `−v` are distinct, and assigns independent input bits to those two addresses. Both directions have output rows `[2,1]` under the old action and `[1,2]` under the new action. This is a small finite fixture, not the large-prime physical compiler or an assertion that the old physical helper interface is preserved.

## Complete caller price

The changed native word has 2,873 paid movements and 457 positive-grade productive helpers; all 458 helper owners still have independent returns, with owner 432 now a grade-zero identity. In the actual 36-call caller, paid and productive rank-4 counts each fall by 36. The complete caller has 107,424 paid and 20,670 positive-grade productive positions, and all other bins are unchanged. Directed enclosures of productive minus paid are:

| κ | Signed margin |
| --- | --- |
| `0.003879928046156` | [`-0.000000000767001502431130261463999524371067664883`, `-0.000000000767001502431130261463999524371067664882`] |
| `0.003879929046155` | [`-0.000385127316613866441054139472099789196374646204`, `-0.000385127316613866441054139472099789196374646203`] |

These equal the original complete signed moments; the signed change is exactly zero, not merely within a numerical tolerance. The 38² caller polynomial coefficients are checked in both orientations. Using the inherited raw accounting formula, the changed word has `933,746,509,200` records and `6,998,544` owned backing units. The incumbent accounting has `934,182,831,504` records. These ordinary savings do not constitute a signed tariff gain.

The original `binary_invoice` validator requires all 458 helper targets to have positive grade. This exploratory recount intentionally omits the one grade-zero target from the positive-grade histogram; it does **not** assert that the unchanged source validator or full compiler accepts this retarget. Its changed address interface, compiler, precision and inherited outer application would need their own binding before use in a contribution.

## Optimistic one-ingress screen

The replay in `screen.py` separately inverts the full chart-1 ingress basis and asks which single original ingress may be removed while all other chart-1 output rows remain fixed. Replacing one helper output by a live pre-sink pure-owner copy changes exactly one target; the 411 bridge remains fixed. There are **15** such helper/ingress pairs. The screen tracks every pure owner row at every clock through the final original ingress, including short-lived intermediate rows, and considers all nested starting-chart/new-chart pairs plus an unchanged chart. For this source that yields **16** distinct owner/chart choices.

The tariff screen grants free copies, all reader repairs and owner-exit work, with no added paid routes. Even with that optimistic treatment, **13 choices tie exactly** and **3 are strictly negative at both trial values** above. Each of the 15 original ingress fields has one ADD reader, and that reader's output field has one reader, the affected owner's exit SWAP. [SCREEN.json](SCREEN.json) records each route, those original clocks, each observed owner/chart copy, retained target grade and directed price interval. Only owner 432 is actually rewritten and replayed here; the rest are upper-bound screens, not claimed executable changed words.

This scope leaves untouched any alteration of other original ingress payloads or routes, removal of multiple paid packets, additional crossings, retargeting multiple outputs, and pure-owner directions synthesized by XOR rather than observed as an existing field. It is not a global no-go theorem. The complete signed gain and replay apply only to the explicit owner-432 control.

## Reproduction and source

Run Python 3 with the standard library:

```sh
python3 -I -B verify.py
```

The scripts bind themselves to one available CPU where supported. The verifier checks the manifest, replays the archived candidate and deterministic receipts, and checks the manifest again. The source word is [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The prior fixed-endpoint cut is [#7901](https://github.com/CrocSwap/integer-mult-bounds/pull/7901) at `07425227fdb39318f7eebd66fcad9c8542f23ec7`. The included inputs and predecessor replay and price code are pinned by the manifest and retain their notices. No independent human review is asserted.
