#!/usr/bin/env python3
"""One-CPU source manifest and deterministic receipt verification."""
from hashlib import sha256
from pathlib import Path
import os,subprocess,sys
H=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('assertions required')
def manifest():
    for line in (H/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1);p=(H/name).resolve()
        assert p.is_relative_to(H) and p.is_file(),name
        assert sha256(p.read_bytes()).hexdigest()==digest,name
manifest()
if hasattr(os,'sched_getaffinity'):
    os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONNOUSERSITE='1')
env.pop('PYTHONPATH',None)
for script in ('replay.py','screen.py'):
    p=subprocess.run([sys.executable,'-I','-B',str(H/script)],cwd=H,env=env,text=True,
                     stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
    assert p.returncode==0 and 'PASS ' in p.stdout,f'{script}: {p.stdout}'
    print(p.stdout,end='')
manifest()
print('PASS source hashes, candidate bytes, exact operators, address and complete caller receipts')
