#!/usr/bin/env python3
"""One-owner chart retarget, exact binary replay and full caller pricing."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip, json, os, sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'vendor'))
import binary_operator as op
import literal
import price

if not __debug__:
    raise RuntimeError('assertions must be enabled')
if hasattr(os, 'sched_getaffinity'):
    allowed = os.sched_getaffinity(0)
    os.sched_setaffinity(0, {min(allowed)})

base = op.load_json(HERE/'inputs/WORD.json.gz', op.WORD_GZIP, True)
caller = op.load_json(HERE/'inputs/EFREE-CALLER.json.gz', op.CALLER, True)
assert op.canonical_hash(base) == op.WORD
assert (base['public'], base['owned_fields']) == (680, 3554)
assert (base['start'][432], base['final'][432]) == (509, 1)
assert (base['start'][411], base['final'][411]) == (509, 1)
assert len(base['program']) == 42958
atlas = op.Atlas(base['frames'])
assert atlas.main_contacts(base['start'], base['final']) == 111
oldf, oldr, bridge_omission = op.native_checks(base, atlas)

# The complete direct use lists for the three affected field identities. Chart
# numbers are never mistaken for fields: only ADD and SWAP have a peer field.
def mentions(row, field):
    return row[1] == field or (row[0] in ('ADD', 'SWAP') and row[2] == field)
uses = {field: [(k, row) for k, row in enumerate(base['program']) if mentions(row, field)]
        for field in (432, 3544, 3986)}
expected = {
    432: [(31262, ['ADD', 3544, 432, 509]), (39588, ['SWAP', 432, 3986])],
    3544: [(31261, ['INIT', 3544, 509]), (31262, ['ADD', 3544, 432, 509]),
           (31263, ['MOVE', 3544, 509, 1]), (36134, ['ADD', 3986, 3544, 1]),
           (42948, ['CLEAR', 3544, 1])],
    3986: [(36133, ['INIT', 3986, 1]), (36134, ['ADD', 3986, 3544, 1]),
           (39588, ['SWAP', 432, 3986]), (39589, ['CLEAR', 3986, 509])]
}
assert uses == expected
removed = sorted({k for rows in uses.values() for k, _ in rows})
assert removed == [31261, 31262, 31263, 36133, 36134, 39588, 39589, 42948]

# Trace the 432 bit through every original instruction, not merely through
# the direct use list. Capture its full public and private provenance and all
# operations reading or disposing of a live copy.
owner_bit = 1 << 432
cells = [(c, 1 << i) for i, c in enumerate(base['start'])] + [None]*base['owned_fields']
flow = []
snapshot = None
for k, row in enumerate(base['program']):
    code, a, *arg = row
    refs = [a] + ([arg[0]] if code in ('ADD','SWAP') else [])
    before = [(j, cells[j][0], bool(cells[j][1] & owner_bit))
              for j in refs if cells[j] is not None]
    if k == 31263:
        snapshot = [(j,c,v) for j, item in enumerate(cells) if item is not None
                    for c,v in [item] if v & owner_bit]
    if code == 'INIT': cells[a] = (arg[0], 0)
    elif code == 'CLEAR': cells[a] = None
    elif code == 'ADD': cells[a] = (cells[a][0], cells[a][1] ^ cells[arg[0]][1])
    elif code == 'SWAP': cells[a], cells[arg[0]] = cells[arg[0]], cells[a]
    else:
        assert code == 'MOVE' and cells[a][0] == arg[0]
        cells[a] = (arg[1], cells[a][1])
    after = [(j, cells[j][0], bool(cells[j][1] & owner_bit))
             for j in refs if cells[j] is not None]
    if any(t[2] for t in before + after):
        flow.append({'clock': k, 'event': row, 'before': before, 'after': after})
assert [(i,c,v) for i,c,v in snapshot] == [(432,509,owner_bit),(3544,509,owner_bit)]
assert [x['clock'] for x in flow] == [31262,31263,36134,39588,39589,42948]
assert all(cells[i][1] & owner_bit == (owner_bit if i == 432 else 0) for i in range(680))

candidate = deepcopy(base)
candidate['final'][432] = 509
candidate['program'] = [row for k, row in enumerate(base['program']) if k not in set(removed)]
assert candidate['start'] == base['start'] and candidate['final'][:432] == base['final'][:432]
assert candidate['final'][433:] == base['final'][433:]
assert candidate['start'][:222] == base['start'][:222] and candidate['final'][:222] == base['final'][:222]
assert atlas.main_contacts(candidate['start'], candidate['final']) == 111
for field in (432,3544,3986):
    assert not any(mentions(row, field) for row in candidate['program'])

blob = json.dumps(candidate, sort_keys=True, separators=(',', ':')).encode()
canonical_hash = sha256(blob).hexdigest()
archive = HERE/'OWNER-432-RETARGET.json.gz'
if '--emit' in sys.argv:
    archive.write_bytes(gzip.compress(blob, mtime=0))
assert gzip.decompress(archive.read_bytes()) == blob

newf = op.run_tape(candidate, atlas, False)
newr = op.run_tape(candidate, atlas, True)
for backwards, old, new in ((False, oldf, newf), (True, oldr, newr)):
    assert old.output == new.output == op.expected_operator(backwards)
    assert old.dirty == 3554 and new.dirty == 3552

def rank(rows):
    basis = {}
    for row in rows:
        while row:
            j = row.bit_length()-1
            if j not in basis:
                basis[j] = row
                break
            row ^= basis[j]
    return len(basis)
assert len(oldf.stock[1]) == len(oldf.demand[1]) == 537
assert len(newf.stock[1]) == len(newf.demand[1]) == 536
assert rank(o.row for o in oldf.demand[1]) == 537
assert rank(o.row for o in newf.demand[1]) == 536
assert rank([o.row for o in newf.stock[1]] + [o.row for o in newf.demand[1]]) == 536

# Packet ordinals change when one MOVE is deleted, so compare by the unique
# field address, not the shifted ordinal or shifted instruction clock.
def packet_rows(word, tape):
    moves = [row[1] for row in word['program'] if row[0] == 'MOVE']
    assert len(moves) == len(set(moves)) == len(tape.packets)
    return {field: tape.packets[680+i] for i, field in enumerate(moves)}
oldfp, oldrp = packet_rows(base, oldf), packet_rows(base, oldr)
newfp, newrp = packet_rows(candidate, newf), packet_rows(candidate, newr)
for old, new in ((oldfp,newfp), (oldrp,newrp)):
    assert set(old) - set(new) == {3544} and not (set(new) - set(old))
    assert all((old[k].source,old[k].receiver,old[k].grade,old[k].arrival.row) ==
               (new[k].source,new[k].receiver,new[k].grade,new[k].arrival.row) for k in new)
    assert (old[3553].source,old[3553].receiver,old[3553].grade,old[3553].arrival.row) == \
           (new[3553].source,new[3553].receiver,new[3553].grade,new[3553].arrival.row)
assert (oldfp[3544].source,oldfp[3544].receiver,oldfp[3544].grade,oldfp[3544].arrival.row)==(509,1,4,owner_bit)

# Negative control: an unchanged old chart-1 endpoint rejects this word.
wrong_exit = deepcopy(candidate)
wrong_exit['final'][432] = 1
try: op.run_tape(wrong_exit, atlas, False)
except ValueError as err: assert str(err) == 'wrong public endpoints'
else: raise AssertionError('wrong owner exit was accepted')
# Bridge 411 remains functional and necessary in each direction.
bridge_new, = [k for k, row in enumerate(candidate['program']) if row == ['ADD',3553,411,509]]
for backwards, tape in ((False,newf),(True,newr)):
    bad = op.run_tape(candidate, atlas, backwards, omit=bridge_new)
    assert [a^b for a,b in zip(tape.output,bad.output)] == [1<<411 if i==411 else 0 for i in range(680)]

# Bind the new exit to its actual physical address action, not the former
# rank-4 transport. In this source physical view a chart B has reflection
# S(B)=I-2P_B. Charts 509 and 1 produce R_old=S1*S509; R_new=S509*S509.
def inverse(m):
    n = len(m); a = [[F(x) for x in row]+[F(i==j) for j in range(n)] for i,row in enumerate(m)]
    for j in range(n):
        p = next(i for i in range(j,n) if a[i][j]); a[j],a[p] = a[p],a[j]
        z=a[j][j]; a[j]=[x/z for x in a[j]]
        for i in range(n):
            if i!=j:
                z=a[i][j]; a[i]=[x-z*y for x,y in zip(a[i],a[j])]
    return [row[n:] for row in a]
def mm(a,b):
    return [[sum((a[i][k]*b[k][j] for k in range(len(b))),F(0)) for j in range(len(b[0]))] for i in range(len(a))]
def projector(chart):
    fr=base['frames'][str(chart)]; rows=fr['B']+fr['A']; g=[list(col) for col in zip(*rows)]
    d=fr['dim']; diag=[[F(i==j and i<d) for j in range(8)] for i in range(8)]
    return mm(mm(g,diag), inverse(g))
def mv(m,v): return [sum((x*y for x,y in zip(row,v)),F(0)) for row in m]
I=[[F(i==j) for j in range(8)] for i in range(8)]
def refl(chart):
    p=projector(chart)
    return [[I[i][j]-2*p[i][j] for j in range(8)] for i in range(8)]
S509,S1=refl(509),refl(1)
old_map,old_adjoint = mm(S1,S509),mm(S509,S1)
new_map = mm(S509,S509)
assert new_map == I and old_map == old_adjoint and mm(old_map,old_adjoint) == I and old_map != I
v=list(map(F,base['frames']['509']['A'][0])); neg=[-x for x in v]
assert any(v) and mv(old_map,v)==neg and mv(old_adjoint,v)==neg and mv(new_map,v)==v
# Choose F_5, where +/-v are distinct and every projector denominator is a unit.
def f5(x): return x.numerator * pow(x.denominator,-1,5)%5
old_mod=[[f5(x) for x in row] for row in old_map]
new_mod=[[f5(x) for x in row] for row in new_map]
v5=[f5(x) for x in v]; m5=[(-x)%5 for x in v5]
def mod_mv(m,x): return [sum(a*b for a,b in zip(row,x))%5 for row in m]
assert v5 != m5 and mod_mv(old_mod,v5)==m5 and mod_mv(old_mod,m5)==v5
assert mod_mv(new_mod,v5)==v5 and mod_mv(new_mod,m5)==m5
# Label the two independently variable physical inputs with distinct basis
# bits. The adjoint is the transpose of the forward point permutation.
addresses = [v5,m5]
old_rows = [1 << addresses.index(mod_mv(old_mod,x)) for x in addresses]
new_rows = [1 << addresses.index(mod_mv(new_mod,x)) for x in addresses]
assert old_rows == [2,1] and new_rows == [1,2]
assert old_rows == [sum(((old_rows[i]>>j)&1)<<i for i in range(2)) for j in range(2)]
assert new_rows == [sum(((new_rows[i]>>j)&1)<<i for i in range(2)) for j in range(2)]

# Recount all actual caller events; the removed endpoint has grade zero and
# is omitted from productive positive-grade targets, not priced as H_4.
oldnp,oldnt,oldpaid,oldtargets = op.binary_invoice(base,caller,atlas,oldf)
newnp=Counter(p.grade for p in newf.packets.values())
helper_grades=[atlas.grade(a,b) for a,b in zip(candidate['start'][222:],candidate['final'][222:])]
assert helper_grades.count(0)==1 and helper_grades[432-222]==0
newnt=Counter(g for g in helper_grades if g)
assert newnp == oldnp-Counter({4:1}) and newnt==oldnt-Counter({4:1})
events=Counter(row[0] for row in caller['events'])
newpaid,newtargets=literal.paired_invoice(caller,newnp,newnt,events)
assert newpaid == oldpaid-Counter({4:36}) and newtargets == oldtargets-Counter({4:36})
assert sum(newpaid.values())==107424 and sum(newtargets.values())==20670
assert price.signed_profile(newtargets,newpaid)==price.signed_profile(oldtargets,oldpaid)
assert op.caller_operator(caller,False)==op.caller_operator(caller,True)
trials=['0.003879928046156','0.003879929046155']
intervals={k:price.decimal_interval(price.moment(price.signed_profile(newtargets,newpaid),F(k)),48) for k in trials}
oldboundary=op.ordinary_boundary(base,caller,oldpaid,oldtargets)
newboundary=literal.ordinary(candidate,caller,events,newpaid,newtargets)
assert newboundary['ordinary_records'] < 10**12 and newboundary['owned_backing'] < 10**7

result={
 'status':'PASS_ONE_OWNER_432_RETARGET_ZERO_NET_GAIN',
 'source_commit_7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'prior_cut_source_commit_7901':'07425227fdb39318f7eebd66fcad9c8542f23ec7',
 'source_word_sha256':op.WORD,'candidate_word_sha256':canonical_hash,
 'candidate_gzip_sha256':sha256(archive.read_bytes()).hexdigest(),
 'scope':'One independent helper 432; unchanged 411 bridge, its other packet dependencies, 222 main fields, and every other owner and original packet. Reselect only owner 432 final chart from 1 to 509 and remove its isolated original return branch.',
 'owner':432,'old_start_chart':509,'old_final_chart':1,'new_final_chart':509,
 'original_helper_productive_grade':4,'new_helper_productive_grade':0,
 'removed_source_clocks':removed,'direct_field_uses':uses,
 'forward_owner_bit_provenance':flow,
 'pre_sink_live_copies':[{'field':i,'chart':c,'pure_owner_432':v==owner_bit} for i,c,v in snapshot],
 'packet_3544_only_reader':{'clock':36134,'receiver':3986,'operation':'ADD'},
 'old_owner_exit':{'clock':39588,'event':['SWAP',432,3986],'retirement_clock':39589,'retired_at_chart':509},
 'new_owner_exit':'public field 432 stays live at 509; there is no additional reader, crossing or owner retirement',
 'remaining_packets_same_source_receiver_grade_and_full_payload_in_both_orientations':len(newfp),
 'original_bridge_field_address':3553,'original_bridge_new_clock':next(k for k,r in enumerate(candidate['program']) if r==['MOVE',3553,509,1]),
 'bridge_omission_flips_only_owner411_in_both_orientations':True,
 'wrong_original_sink_exit_rejected':True,
 'native_public_rows_checked_per_orientation':680,'scalar_coefficients_checked_per_orientation':680**2,
 'dirty_retirements_per_orientation':newf.dirty,'unchanged_main_contacts':111,
 'chart1_after_retarget':{'arrivals':536,'fixed_remaining_output_rows':536,'output_rank':536,
                          'combined_arrival_output_rank':536},
 'address_binding':{'physical_view':'S_B=I-2P_B; old end-to-start action S1*S509, new S509*S509=I',
   'matrix_identity_exact_over_rationals':True,'old_forward_and_adjoint_are_same_nonidentity_involution':True,
   'witness':list(map(str,v)),'prime':5,'witness_mod5':v5,'opposite_mod5':m5,
   'old_forward_and_adjoint_map_witness_to_opposite':True,'new_forward_and_adjoint_leave_witness_fixed':True,
   'old_two_independent_address_output_rows':old_rows,'new_two_independent_address_output_rows':new_rows,
   'meaning':'Different physical source addresses carry independent values; retaining the old 509-to-1 output action for the changed 509-to-509 target would be wrong.'},
 'native_paid':dict(newnp),'native_productive_positive_grade':dict(newnt),
 'full_36_call_paid':dict(newpaid),'full_36_call_productive':dict(newtargets),
 'full_36_call_paid_count':sum(newpaid.values()),'full_36_call_productive_count':sum(newtargets.values()),
 '36_call_paid_delta':{'4':-36},'36_call_productive_delta':{'4':-36},
 '36_call_signed_gain':'exactly zero for every kappa', 'directed_signed_margins':intervals,
 'caller_all_38_squared_polynomial_coefficients_each_orientation':True,
 'old_raw_records':oldboundary['raw_records'],'new_raw_records':newboundary['ordinary_records'],
 'owned_backing':newboundary['owned_backing'],
 'limitations':'This owner-only retarget is a zero-gain control, not an exhaustive search over other helpers, encoded paths or endpoint replacements, nor a new kappa bound or an independent proof of inherited compiler assumptions. The incumbent binary_invoice requires all 458 helper target grades positive; this recount treats the same-chart helper as a grade-zero identity and does not claim the unchanged validator accepts it.'
}
text=json.dumps(result,sort_keys=True,indent=2)+'\n'
receipt=HERE/'RESULT.json'
if '--emit' in sys.argv: receipt.write_text(text)
assert receipt.read_text()==text
print('PASS owner 432; saved H4 and surrendered H4; exact 36-call signed gain 0')
print('candidate',canonical_hash,'old/new raw records',oldboundary['raw_records'],newboundary['ordinary_records'])
for k,v in intervals.items(): print(k,v)
