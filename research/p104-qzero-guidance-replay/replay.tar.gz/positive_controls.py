#!/usr/bin/env python3
import copy, importlib.util, json
from pathlib import Path
P=Path(__file__).resolve().parent/'source/data/q0_callers'
spec=importlib.util.spec_from_file_location('author_q0_word',P/'check.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
results=[]
for path in sorted(P.glob('*.json')):
    c=json.loads(path.read_text());k=c['stages'];degrees=[sum(x[2:2+k]) for x in c['diagonal']]
    assert len(degrees)==2*k-2 and min(degrees)>=2
    slacks=[]
    for a in range(1,k.bit_length()+1):
        lhs=sum(min(d,2**(a+1))-1 for d in degrees)
        rhs=sum(2*(len(range(j,k,2**l))//2) for l in range(a+1) for j in range(2**l))
        assert lhs>=rhs
        slacks.append(lhs-rhs)
    assert module.legal(c)==(True,True)
    results.append({'file':path.name,'k':k,'dyadic_slacks':slacks,'symbolic_D_four_q':True})
c=json.loads((P/'ml_k4.json').read_text());bad=copy.deepcopy(c)
for event in bad['events']:
    if event[0]=='HOST':event[4]=str(module.Fr(event[4])+1);break
assert module.legal(bad)==(False,True)
assert len(results)==15
print(json.dumps({'words':results,'changed_host_rejected':True},indent=2))
