#!/usr/bin/env python3
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path
import independent_q0 as independent

HERE=Path(__file__).resolve().parent

def determinant(a):
    a=[[F(x) for x in row] for row in a]
    answer=F(1)
    for j in range(len(a)):
        pivot=next((i for i in range(j,len(a)) if a[i][j]),None)
        if pivot is None:return F(0)
        if pivot!=j:a[j],a[pivot]=a[pivot],a[j];answer=-answer
        p=a[j][j];answer*=p
        for i in range(j+1,len(a)):
            ratio=a[i][j]/p
            for l in range(j,len(a)):a[i][l]-=ratio*a[j][l]
    return answer

pins=json.loads((HERE/'SOURCES.json').read_text())
for name,expected in pins['sha256'].items():
    assert hashlib.sha256((HERE/'source'/name).read_bytes()).hexdigest()==expected,name
stored=json.loads((HERE/'INDEPENDENT-Q0.json').read_text())
computed=[independent.bound(k) for k in (71,72,73)]
assert computed==stored,'the recomputed exact certificate differs from the stored receipt'
for c in range(1,37):
    assert determinant([[1 if i<=j else -1 for j in range(c)] for i in range(c)])==2**(c-1)
for k,deficit,count in [(71,58,10),(72,62,11),(73,60,10)]:
    rhs=sum(2*(len(range(j,k,2**l))//2) for l in range(3) for j in range(2**l))
    assert rhs-(2*k+10)==deficit
    assert (deficit+5)//6==count
    assert 6*(count-1)<deficit<=6*count
# A changed endpoint must fail equality even if it preserves the claimed below-bar sign.
corrupt=json.loads(json.dumps(stored));corrupt[1]['upper']=str(F(corrupt[1]['upper'])-F(1,1000))
assert corrupt!=computed
# Integer root check rejects a floor moved up by one at an irrational test power.
a,_=independent.power(17);target=17**99*independent.SCALE**100
assert a**100<=target<(a+1)**100
assert not (a+1)**100<=target<(a+2)**100
print('PASS source hashes, independent Q0 dual enclosures, all witness rows, dyadic corollary, controls')
