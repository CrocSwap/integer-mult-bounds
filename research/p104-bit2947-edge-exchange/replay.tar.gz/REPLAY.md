# Freshly extracted standalone replay

A deterministic tar archive of this exact directory was extracted into a new,
otherwise empty directory under `/tmp/p104-round4/streams/03-bit2947-edge-exchange/`.
The following checks were run on the extracted bytes with Python 3.12.3,
`python3 -I -B`, and an empty environment apart from `PATH` and `LC_ALL`:

| Extracted-package check | Observed result |
| --- | --- |
| `sha256sum -c SHA256SUMS` and exact file-set comparison | PASS |
| `exchange.py` output byte comparison with `RESULT.json` | PASS |
| `exchange.py --emit` output compared with decompressed `EXCHANGE-WORD.json.gz` | PASS |
| `two_donor_search.py` output byte comparison with `TWO-SEARCH.txt` | PASS |
| `rechart.py` output byte comparison with `RECHART.json` | PASS |

`SHA256SUMS` lists every other regular file in this package; it does not hash
itself. No network, repository checkout, sibling `source/` directory, Python
site packages, or local working files are used by these commands. The exact
command sequence to repeat the checks is in [README.md](README.md).
