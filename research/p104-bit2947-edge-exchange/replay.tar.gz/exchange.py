#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Packet 2669 actual-reader stock span and physical rejection/control.

Standalone after retaining source/. No network or optimization assumptions.
Every operation is keyed by its original clock, so retiming keeps observer IDs.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from types import SimpleNamespace
import gzip, json, sys
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source'
sys.path[:0]=[str(SRC/'vendor'),str(SRC)]
import binary_operator as op
import literal
import price
import verify as v

for name,digest in v.PINS.items():
 assert sha256((SRC/name).read_bytes()).hexdigest()==digest, name
w=v.read('inputs/WORD.json.gz'); caller=v.read('inputs/EFREE-CALLER.json.gz')
assert sha256(v.canon(w)).hexdigest()==v.WORD
A=op.Atlas(w['frames']); n=w['public']; p=w['program']; N=n+w['owned_fields']
assert (n,len(p),w['owned_fields'])==(680,42958,3554)
assert p[9293:9297]==[['INIT',2669,418],['ADD',2669,2050,418],['ADD',2669,2244,418],['MOVE',2669,418,518]]
assert p[10386]==['ADD',2947,2669,518] and p[10390]==['ADD',2948,2669,518]
assert p[42073]==['CLEAR',2669,518]
assert all(e[1] == 680+j for j,e in enumerate(e for e in p if e[0]=='MOVE'))

# Three exact words: incumbent; an uncorrected physical deletion; a later
# reconstruction using the only real source span.  Event labels are source
# clocks, not new clock indices.
orig=list(enumerate(p))
skip={9293,9294,9295,9296,10386,10390,42073}
removed=[q for q in orig if q[0] not in skip]
late=[]
for key,event in orig:
 if key in {9293,9294,9295,9296}:continue
 if key==10386:late.extend(orig[9293:9297])
 late.append((key,event))
assert len(removed)==len(orig)-7 and len(late)==len(orig)
assert sum(e[0]=='MOVE' for _,e in removed)==2873
assert sum(e[0]=='MOVE' for _,e in late)==2874
# A real two-sender replacement found at the first reader: bank 2671 on chart
# 1 plus five cocharted banks on chart 320. Both temporary transfers are paid.
new=[]
def emit(e):
 new.append((-len(new)-1,e));return new[-1]
construct=[emit(['INIT',2669,1]),emit(['ADD',2669,2671,1]),emit(['MOVE',2669,1,518]),
           emit(['INIT',4233,320])]
construct += [emit(['ADD',4233,j,320]) for j in (1477,1649,1773,1801,1853)]
construct += [emit(['MOVE',4233,320,518])]
first=[emit(['ADD',2947,2669,518]),emit(['ADD',2947,4233,518])]
second=[emit(['ADD',2948,2669,518]),emit(['ADD',2948,4233,518])]
retire=[emit(['CLEAR',2669,518]),emit(['CLEAR',4233,518])]
replacement=[]
for key,event in orig:
 if key in {9293,9294,9295,9296,42073}:continue
 if key==10386:replacement.extend(construct+first);continue
 if key==10390:replacement.extend(second+retire);continue
 replacement.append((key,event))
assert len(replacement)==len(orig)+9
replacement_word=dict(w);replacement_word['program']=[e for _,e in replacement]
if '--emit' in sys.argv:
 print(json.dumps(replacement_word,sort_keys=True,separators=(',',':')))
 raise SystemExit

def indices(x):
 out=[]
 while x:
  bit=x & -x;out.append(bit.bit_length()-1);x^=bit
 return out

def tape(seq,reverse=False,snapshots=()):
 cells=[(c,1<<i) for i,c in enumerate(w['final' if reverse else 'start'])]+[None]*w['owned_fields']
 reads={}; packets={}; snaps={}; dirty=0; counts=Counter();g=Counter();life=0
 for key,event in (reversed(seq) if reverse else seq):
  opn,r,*args=event
  if key in snapshots:snaps[key]=list(cells)
  assert 0<=r<N
  counts[opn]+=1;cell=cells[r]
  if opn in ('INIT','CLEAR'):
   c,=args
   opens=(opn=='CLEAR') if reverse else (opn=='INIT')
   if opens:
    assert r>=n and cell is None;cells[r]=(c,0);life+=1
   else:
    assert cell is not None and cell[0]==c;dirty+=bool(cell[1]);life-=1
    reads[key]=('retire',r,cell[1]);cells[r]=None
  elif opn=='ADD':
   s,c=args;other=cells[s]
   assert r!=s and cell is not None and other is not None and cell[0]==other[0]==c
   dst,src=(s,r) if reverse else (r,s)
   reads[key]=('add',src,cells[src][1]);cells[dst]=(c,cells[dst][1]^cells[src][1])
  elif opn=='MOVE':
   source,dest=args[::-1] if reverse else args
   assert r>=n and cell is not None and cell[0]==source
   grade=A.grade(source,dest);assert grade>0
   packets[r]=(key,source,dest,grade,cell[1]);reads[key]=('move',r,cell[1]);g[grade]+=1
   cells[r]=(dest,cell[1])
  else:
   assert opn=='SWAP';s,=args;assert r!=s and cell is not None and cells[s] is not None
   reads[key]=('swap',r,cell[1],s,cells[s][1]);cells[r],cells[s]=cells[s],cells[r]
 assert life==0 and all(x is None for x in cells[n:])
 assert [x[0] for x in cells[:n]]==w['start' if reverse else 'final']
 return {'output':[x[1] for x in cells[:n]],'reads':reads,'packets':packets,'snaps':snaps,
         'dirty':dirty,'counts':counts,'grades':g}

f0=tape(orig,False,(9296,10386,10390));r0=tape(orig,True)
fd=tape(removed,False,(10391,));rd=tape(removed,True)
fl=tape(late,False,(10386,10390));rl=tape(late,True)
fx=tape(replacement,False);rx=tape(replacement,True)
assert f0['output']==op.expected_operator(False) and r0['output']==op.expected_operator(True)
assert fl['output']==f0['output'] and rl['output']==r0['output']
assert fx['output']==f0['output'] and rx['output']==r0['output']
assert fx['dirty']==rx['dirty']==3555
for t in (fx,rx):assert [i for i,pkt in t['packets'].items() if pkt[4] & (1<<411)]==[3553]
protected_routes={(509,0),(390,509),(517,390)}
protected_banks={e[1] for e in p if e[0]=='MOVE' and tuple(e[2:]) in protected_routes}|{3553}
for key,e in orig:
 if e[1] in protected_banks or (e[0] in ('ADD','SWAP') and e[2] in protected_banks):
  assert (key,e) in replacement
# Independent retained literal checker, not the local chronological replay.
literal_atlas=literal.Charts(w['frames'])
literal_f,lsf,_=literal.tape(replacement_word,literal_atlas)
literal_r,lsr,_=literal.tape(replacement_word,literal_atlas,adjoint=True)
assert literal_f==fx['output'] and literal_r==rx['output']
assert lsf['erase_dirty']==lsr['erase_dirty']==3555
# Separately replay all addresses, chart tags and outputs using #7830's tape.
ind_f=op.run_tape(replacement_word,A,False);ind_r=op.run_tape(replacement_word,A,True)
assert ind_f.output==fx['output'] and ind_r.output==rx['output']
assert ind_f.dirty==ind_r.dirty==3555
assert f0['dirty']==r0['dirty']==fl['dirty']==rl['dirty']==3554
assert fd['output']!=f0['output'] and rd['output']!=r0['output']
assert fd['grades']==f0['grades']-Counter({1:1}) and fl['grades']==f0['grades']
assert fx['grades']==f0['grades']+Counter({3:1})==rx['grades']

# Construct and replay the literal control against the pinned checker as well.
late_word=dict(w);late_word['program']=[e for _,e in late]
ff,rr,bridge=op.native_checks(late_word,A)
np,nt,fp,ft=op.binary_invoice(late_word,caller,A,ff)
receipt=v.read('inputs/BIT.json')['native']
for actual,key in [(np,'native_paid'),(nt,'native_targets'),(fp,'paid'),(ft,'targets')]:
 assert actual==Counter({int(k):num for k,num in receipt[key].items()})
assert bridge==31289 and A.main_contacts(w['start'],w['final'])==111
base=ft.copy();base.subtract(fp)
def signs(counter,k):
 lo=hi=Fraction(0)
 for r,num in counter.items():
  if not r or not num:continue
  a,b=v.power_bounds(r,1-Fraction(k),240)
  lo+=num*(a if num>0 else b);hi+=num*(b if num>0 else a)
 return v.decimals((lo,hi))
trials=['0.003879928046156','0.003879929046155']
prices={k:signs(base,k) for k in trials}
# Reprice the literal replacement using every changed paid packet and every
# original caller occurrence. No free grade-zero or unwritten relief is used.
tape_for_invoice=SimpleNamespace(packets={i:SimpleNamespace(grade=pkt[3]) for i,pkt in fx['packets'].items()})
xnp,xnt,xfp,xft=op.binary_invoice(replacement_word,caller,A,tape_for_invoice)
assert xnp==np+Counter({3:1}) and xnt==nt and xfp==fp+Counter({3:36}) and xft==ft
xbase=xft.copy();xbase.subtract(xfp)
xprices={k:signs(xbase,k) for k in trials}
for k in trials:
 alt=price.moment(xbase,Fraction(k));ref=xprices[k]
 assert Fraction(ref[0])<=Fraction(alt[1],price.GRID) and Fraction(alt[0],price.GRID)<=Fraction(ref[1])
change=xbase.copy();change.subtract(base)
assert {k:v for k,v in change.items() if v}=={3:-36}
xgains={k:signs(change,k) for k in trials}
for k in trials:
 alt=price.moment(change,Fraction(k));ref=xgains[k]
 assert Fraction(ref[0])<=Fraction(alt[1],price.GRID) and Fraction(alt[0],price.GRID)<=Fraction(ref[1])
# Apply the predecessor's full raw allowance formula to the changed literal.
events=Counter(e[0] for e in caller['events']);calls=events['LOCAL'];queries=events['QUERY'];idles=events['IDLE_ONE']
ports=caller['ports'];roles=caller['roles'];owned=w['owned_fields'];scratch=4
native_records=calls*16*(owned+n+scratch)*len(replacement_word['program'])
caller_records=ports*(8*(events['ADD']+3*events['SWAP'])+256*(calls+queries+roles))
route_groups=4*(sum(xfp.values())+sum(xft.values()))+8*ports*(calls+idles)
records=native_records+caller_records+route_groups*80*134*135
fields=calls*(owned+scratch)+2*ports*roles*len(caller['events'])+16*ports*(calls+queries+roles)
assert records<10**12 and fields<10**7
# Verify exact owner-411 protected bridge omission after this actual edit.
xomit=[ev for ev in replacement if ev[0]!=31289]
xof=tape(xomit,False)['output'];xor=tape(xomit,True)['output']
assert [x^y for x,y in zip(xof,fx['output'])]==[1<<411 if i==411 else 0 for i in range(n)]
assert [x^y for x,y in zip(xor,rx['output'])]==[1<<411 if i==411 else 0 for i in range(n)]
assert fx['packets'][3553][1:4]==(509,1,4) and fx['packets'][3553][4]==1<<411
assert rx['packets'][3553][1:4]==(1,509,4) and rx['packets'][3553][4]==1<<411

# Gaussian span of literal, physically live row values (not graph labels).
def basis(sources):
 piv={}
 for bank,x in sources:
  combination=1<<bank
  while x:
   pivot=x.bit_length()-1
   if pivot in piv:x^=piv[pivot][0];combination^=piv[pivot][1]
   else:piv[pivot]=(x,combination);break
 return piv
def express(piv,target):
 x=target;combination=0
 while x:
  pivot=x.bit_length()-1
  if pivot not in piv:return None,x
  x^=piv[pivot][0];combination^=piv[pivot][1]
 return indices(combination),0

target=f0['packets'][2669][4]
assert target==f0['snaps'][9296][2050][1]^f0['snaps'][9296][2244][1]
reader_snapshot=f0['snaps'][10386]
assert reader_snapshot[4233] is None
assert reader_snapshot[2671][0]==1
assert all(reader_snapshot[j][0]==320 for j in (1477,1649,1773,1801,1853))
value=reader_snapshot[2671][1]
for j in (1477,1649,1773,1801,1853):value^=reader_snapshot[j][1]
assert value==target
assert target & (1<<8) and not f0['snaps'][10386][2674][1] & (1<<8)

def stock_report(cells,dest,exclude):
 groups=defaultdict(list)
 for bank,cell in enumerate(cells):
  if cell is not None and cell[1] and bank not in exclude|{dest}:
   groups[cell[0]].append((bank,cell[1]))
 local=groups[518];lpiv=basis(local);donors,residual=express(lpiv,target)
 # At this bounded reader there is exactly one live nonzero local stock row.
 # Test the complete target + span(local stock) coset, not merely the target.
 assert len(local)==1 and len(lpiv)==1
 local_variants=[([],0),([local[0][0]],local[0][1])]
 hit=[]
 for chart,rows in sorted(groups.items()):
  piv=basis(rows)
  for local_donors,local_row in local_variants:
   senders,missing=express(piv,target^local_row)
   if senders is not None:
    hit.append({'chart':chart,'chart_dimension':len(A.body[chart]),'rank_to_receiver_518':A.grade(chart,518),
                'live_nonzero_banks':[bank for bank,_ in rows], 'row_span_rank':len(piv),
                'donors':senders,'local_receiver_donors':local_donors})
 return {'all_live_nonzero_chart_groups':len(groups),'all_chart_sender_span_hits':hit,
         'receiver_chart_518_live_nonzero_banks':[b for b,_ in local],
         'receiver_chart_518_span_rank':len(lpiv),'receiver_exact_reconstruction':donors,
         'receiver_remainder_input_owners':indices(residual),
         'local_receiver_coset_variants_tested':len(local_variants)}
s0=stock_report(f0['snaps'][10386],2947,{2669})
s1=stock_report(f0['snaps'][10390],2948,{2669})
s1_unrepaired=stock_report(fd['snaps'][10391],2948,{2669})
assert s0['receiver_chart_518_live_nonzero_banks']==[2674]
assert s1['receiver_chart_518_live_nonzero_banks']==[2674]
assert s1_unrepaired['receiver_chart_518_live_nonzero_banks']==[2674]
assert s0['receiver_exact_reconstruction'] is None and s1['receiver_exact_reconstruction'] is None
assert s1['receiver_exact_reconstruction'] is None
assert s0['all_chart_sender_span_hits']==[{'chart':418,'chart_dimension':6,'rank_to_receiver_518':1,
 'live_nonzero_banks':[2050,2244,2308],'row_span_rank':3,'donors':[2050,2244], 'local_receiver_donors':[]}]
assert s1_unrepaired['receiver_exact_reconstruction'] is None
# The uncorrected deletion changes no other stock before either affected read.
for clock,dest in [(10386,2947),(10390,2948)]:
 before=f0['snaps'][clock]
 after=fl['snaps'][clock] if clock==10386 else fd['snaps'][10391]
 for i in range(N):
  if i==2669 or (clock==10390 and i==2947):continue
  assert before[i]==after[i],(clock,i)

class DSU:
 def __init__(self):self.p={}
 def root(self,x):
  if x not in self.p:self.p[x]=x
  if self.p[x]!=x:self.p[x]=self.root(self.p[x])
  return self.p[x]
 def join(self,x,y):
  a,b=self.root(x),self.root(y)
  if a!=b:self.p[max(a,b)]=min(a,b)
def graph(seq):
 # Decompose actual physical XOR forms using persistent bank IDs; packet IDs
 # remain stable even if a paid packet is removed or retimed.
 state=[1<<i for i in range(n)]+[0]*w['owned_fields'];routes={};forms={}
 for _,event in seq:
  opn,r,*args=event
  if opn=='MOVE':
   assert r not in routes
   routes[r]=tuple(args);forms[r]=state[r];state[r]=1<<r
  elif opn=='ADD':state[r]^=state[args[0]]
  elif opn=='SWAP':state[r],state[args[0]]=state[args[0]],state[r]
  else:
   assert opn in ('INIT','CLEAR');state[r]=0
 forms.update({~i:state[i] for i in range(n)})
 d=DSU()
 for i in range(n):d.root((i,'in'));d.root((~i,'out'))
 for i in routes:d.root((i,'in'));d.root((i,'out'))
 for k,mask in forms.items():
  for j in indices(mask):d.join((j,'in'),(k,'out'))
 groups=defaultdict(list)
 for x in list(d.p):groups[d.root(x)].append(x)
 component={x:min(group) for group in groups.values() for x in group};charts={}
 def bind(x,c):
  root=component[x]
  assert charts.setdefault(root,c)==c,(root,c,charts[root])
 for i in range(n):bind((i,'in'),w['start'][i]);bind((~i,'out'),w['final'][i])
 for i,(a,b) in routes.items():bind((i,'out'),a);bind((i,'in'),b)
 edges=[('paid',i,component[(i,'out')],component[(i,'in')]) for i in sorted(routes)]
 edges += [('targets',i,component[(i,'in')],component[(~i,'out')]) for i in range(222,n)]
 return {'component':component,'charts':charts,'edges':edges,'forms':forms}
G0=graph(orig);Gd=graph(removed);Gl=graph(late);Gx=graph(replacement)
assert G0==Gl
assert len(G0['edges'])==3332 and len(Gd['edges'])==3331

def neighborhood(G,node):
 comp=G['component'][node]; members=sorted(x for x,c in G['component'].items() if c==comp)
 edges=[]
 for kind,key,a,b in G['edges']:
  if a==comp or b==comp:
   other=b if a==comp else a
   edges.append({'kind':kind,'key':key,'peer':list(other),'peer_chart':G['charts'][other],
                 'peer_rank':len(A.body[G['charts'][other]])})
 return {'component':list(comp),'chart':G['charts'][comp],'rank':len(A.body[G['charts'][comp]]),
         'members':[list(x) for x in members], 'incident_edges':edges}

# Rank-seven parent proposal after the physical deletion: 2947 forces the two
# seven-spaces equal.  The remaining chart-617 and chart-420 incidences force
# one such space to contain their union, which has rational dimension eight.
def rank(rows):return op.rational_rank([list(map(Fraction,row)) for row in rows])
assert rank(list(A.body[617])+list(A.body[420]))==8
witness=next(([str(x) for x in row],[str(x) for x in normal],str(sum(a*b for a,b in zip(row,normal))))
             for row in A.body[420] for normal in A.dual[617]
             if sum(a*b for a,b in zip(row,normal)))

def observer_delta(before,after):
 result=[]
 for key in sorted(set(before['reads'])&set(after['reads'])):
  x,y=before['reads'][key],after['reads'][key]
  if x!=y:
   assert x[:2]==y[:2] and x[0] in ('add','move','retire','swap')
   result.append({'source_clock':key,'operation':x[0],'bank':x[1],
                  'old_payload_hex':hex(x[2]),'new_payload_hex':hex(y[2]),
                  **({'second_bank':x[3],'old_second_payload_hex':hex(x[4]),'new_second_payload_hex':hex(y[4])} if x[0]=='swap' else {})})
 return result

def packet_delta(before,after):
 return [{'bank':i,'source_clock':before['packets'][i][0],
          'old_payload_hex':hex(before['packets'][i][4]),'new_payload_hex':hex(after['packets'][i][4]),
          'changed_input_owners':indices(before['packets'][i][4]^after['packets'][i][4])}
         for i in sorted(set(before['packets'])&set(after['packets']))
         if before['packets'][i][0]==after['packets'][i][0] and before['packets'][i][4]!=after['packets'][i][4]]
def output_delta(before,after):
 return [{'output_owner':i,'changed_input_owners':indices(x^y)}
         for i,(x,y) in enumerate(zip(before['output'],after['output'])) if x!=y]
def check_transpose(fwd,adj):
 assert all(bool((fwd[i]>>j)&1)==bool((adj[j]>>i)&1) for i in range(n) for j in range(n))
for x,y in [(f0,r0),(fd,rd),(fl,rl),(fx,rx)]:check_transpose(x['output'],y['output'])

fm,rm=packet_delta(f0,fd),packet_delta(r0,rd)
fo,ro=output_delta(f0,fd),output_delta(r0,rd)
fre, rre=observer_delta(f0,fd),observer_delta(r0,rd)
control_f=observer_delta(f0,fl);control_r=observer_delta(r0,rl)
exchange_f=observer_delta(f0,fx);exchange_r=observer_delta(r0,rx)
exchange_paid_f=packet_delta(f0,fx);exchange_paid_r=packet_delta(r0,rx)
assert not exchange_paid_f and [q['bank'] for q in exchange_paid_r]==[2244,2671]
assert not exchange_f and [q['source_clock'] for q in exchange_r]==[6680,6681,6682,6683,6684,6685,6686,9302,9303,9304]
def paid_payload_summary(forward,adjoint,banks):
 return [{'bank':i,'forward_source_chart':forward['packets'][i][1],
          'forward_receiver_chart':forward['packets'][i][2],
          'grade':forward['packets'][i][3],
          'forward_payload_hex':hex(forward['packets'][i][4]),
          'adjoint_payload_hex':hex(adjoint['packets'][i][4])} for i in banks]
assert not packet_delta(f0,fl) and not packet_delta(r0,rl)

out={'status':'TWO_SENDER_PHYSICAL_EXCHANGE_VALID_BUT_NEGATIVE',
 'scope':'One named source incidence: delete 2669 (418 -> 518). First reader is 2947 at 10386, second is 2948 at 10390. Exact live-stock same-chart XOR spans at original chronological reads; arbitrary one-transfer replacement from any one currently live sender chart combined with any receiver-local stock tested. Other program and protected owners fixed.',
 'source':{'pr_7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','third_frame_pr_7900_head':'0313ee081bd06e38586db1ee9595d9b36e4a243c',
  'canonical_word_sha256':v.WORD,'program_length':len(p)},
 'source_payload':{'input_owners':indices(target),'sender_chart':418,'sender_banks':[2050,2244],
                   'destination_chart':518,'original_move_clock':9296},
 'reader_spans':{'clock_10386':s0,'clock_10390_if_first_corrected':s1,'clock_10390_after_uncorrected_first':s1_unrepaired,
  'separating_bit':{'input_owner':8,'packet_2669':1,'packet_2674':0,'fresh_receiver':0},
  'bounds':'Any exact XOR of simultaneous existing sender stock on one chart, at most one new positive-grade paid transfer to chart 518, and any existing receiver-local stock. No stock changes before first read. Additional upstream edits or multiple transfers are not covered.'},
 'uncorrected_physical_removal':{'removed_source_clocks':sorted(skip),'still_paid_moves':sum(fd['grades'].values()),
  'dirty_forward_adjoint':[fd['dirty'],rd['dirty']],
  'all_680_rows_each_direction_checked':True,'forward_transpose_of_adjoint_checked':True,
  'forward_bad_public_outputs':len(fo),'forward_bad_main_outputs':sum(x['output_owner']<222 for x in fo),
  'forward_bad_helper_outputs':sum(x['output_owner']>=222 for x in fo),
  'forward_owner411_bad':any(x['output_owner']==411 for x in fo),
  'adjoint_bad_public_outputs':len(ro),'adjoint_bad_main_outputs':sum(x['output_owner']<222 for x in ro),
  'adjoint_bad_helper_outputs':sum(x['output_owner']>=222 for x in ro),
  'adjoint_owner411_bad':any(x['output_owner']==411 for x in ro),
  'forward_changed_paid_payloads':fm,'adjoint_changed_paid_payloads':rm,
  'forward_output_differences':fo,'adjoint_output_differences':ro,
  'forward_all_changed_read_and_retire_payloads':fre,'adjoint_all_changed_read_and_retire_payloads':rre,
  'billable_relief_claimed':False},
 'geometry_after_uncorrected_deletion':{
  'old_A':neighborhood(G0,(-680,'out')),'old_B':neighborhood(G0,(2947,'out')),
  'new_A':neighborhood(Gd,(-680,'out')),'new_B':neighborhood(Gd,(2947,'out')),
  'new_2948_out':neighborhood(Gd,(2948,'out')),
  'rank7_parent_proposal':{'packet_2947_forces_equal_7_spaces':True,
   'fixed_chart_617_rank':len(A.body[617]),'fixed_chart_420_rank':len(A.body[420]),
   'rational_union_rank':8,'row_420_and_normal_617_nonzero_dot_witness':witness,
   'conclusion':'The proposed common seven-space cannot exist even if deletion were restored for free.'}},
 'late_reconstruction_control':{'same_paid_edge_recreated':True,'sender_banks':[2050,2244],
  'canonical_word_sha256':op.canonical_hash(late_word),'length':len(late_word['program']),
  'component_graph_equal_to_incumbent':True,'all_680_squared_coefficients_each_orientation':'PASS',
  'all_38_squared_caller_coefficients_each_orientation':'PASS','protected_main_contacts':111,
  'protected_owner_411_omission_clock':bridge,'dirty_retirements_each_direction':[ff.dirty,rr.dirty],
  'changed_paid_packet_payloads_forward':len(packet_delta(f0,fl)),
  'changed_paid_packet_payloads_adjoint':len(packet_delta(r0,rl)),
  'changed_other_observer_payloads_forward':control_f,'changed_other_observer_payloads_adjoint':control_r,
  'native_paid':dict(sorted(np.items())),'native_targets':dict(sorted(nt.items())),
  'full_36_call_paid':dict(sorted(fp.items())),'full_36_call_targets':dict(sorted(ft.items())),
  'full_signed_margins':prices,'signed_gain_over_source':'0 (identical full histograms)',
  'disposition':'Valid literal retiming control; no exterior edge removed and no gain.'},
 'two_sender_actual_exchange':{
  'original_paid_edge':'2669 chart 418 -> 518 is removed',
  'new_paid_edges':[{'bank':2669,'source_chart':1,'destination_chart':518,'grade':1,'source_banks':[2671]},
                    {'bank':4233,'source_chart':320,'destination_chart':518,'grade':3,
                     'source_banks':[1477,1649,1773,1801,1853]}],
  'new_private_scratch_address_4233_reused_before_original_lifetime':True,
  'rewritten_original_readers':[10386,10390],
  'removed_packet_forward_and_adjoint_payloads':paid_payload_summary(f0,r0,[2669]),
  'new_packets_forward_and_adjoint_payloads':paid_payload_summary(fx,rx,[2669,4233]),
  'canonical_word_sha256':op.canonical_hash(replacement_word),'length':len(replacement_word['program']),
  'all_680_squared_coefficients_each_orientation':'PASS',
  'independent_literal_and_vendor_replays':'PASS',
  'all_38_squared_caller_coefficients_each_orientation':'PASS',
  'protected_main_contacts':A.main_contacts(w['start'],w['final']),
  'owner_411_bridge_and_omission_both_directions':'PASS',
  'protected_bridge_tree_bank_addresses':sorted(protected_banks),
  'protected_bridge_tree_source_events':'all retained',
  'ordinary_raw_recount':{'records':records,'records_limit':10**12,'owned_fields':fields,'owned_fields_limit':10**7,'scope':'same source raw allowance formula; not finite compiler qualification'},
  'dirty_retirements_each_direction':[fx['dirty'],rx['dirty']],
  'native_paid':dict(sorted(xnp.items())),'native_targets':dict(sorted(xnt.items())),
  'full_36_call_paid':dict(sorted(xfp.items())),'full_36_call_targets':dict(sorted(xft.items())),
  'full_signed_margins':xprices,'signed_gain_over_source':xgains,
  'native_signed_histogram_change':{'3':-1},
  'forward_changed_surviving_paid_packet_payloads':exchange_paid_f,
  'adjoint_changed_surviving_paid_packet_payloads':exchange_paid_r,
  'forward_all_changed_other_observer_payloads':exchange_f,
  'adjoint_all_changed_other_observer_payloads':exchange_r,
  'geometry_A':neighborhood(Gx,(-680,'out')),'geometry_B':neighborhood(Gx,(2947,'out')),
  'geometry_original_sender_418':neighborhood(Gx,(2050,'in')),
  'geometry_new_sender_1':neighborhood(Gx,(2669,'out')),
  'geometry_new_sender_320':neighborhood(Gx,(4233,'out')),
  'rank7_parent_proposal':{'fixed_chart_617_and_420_union_rank':8,
   'conclusion':'unchanged obstruction: paid 2947 would force equal 7-spaces, which cannot contain both fixed charts'},
  'disposition':'A valid changed literal word replaces the original incidence with two actually paid incidences; the complete price is strictly negative.'},
 'unknowns':['Upstream re-encodings that create a different available sender form.',
  'Multiple new paid transfers or changed receiver computations.',
  'Other exterior incidences and other rank assignments.',
  'Finite compiler and changed-candidate ordinary-cost qualification.']}
print(json.dumps(out,sort_keys=True,indent=2))
