# Source and packaging provenance

This standalone package contains the inputs required by all three replay scripts.
It retains the binary word, complete caller, BIT invoice, operator, literal and
price implementations from the predecessor package as exact bytes. Their
immutable upstream locations, Git blobs, and SHA-256 values are in
[source/SOURCES.json](source/SOURCES.json). The retained
[source/NOTICE](source/NOTICE) and [source/LICENSE](source/LICENSE) preserve the
predecessor attribution and Apache-2.0 terms.

The retained [source/arbitrary.py](source/arbitrary.py) is the #7881 rational
frame geometry implementation with SHA-256
`b53b46c492860707b95e801c92b6bbf0608e5aa5061bd4fd5114fb28f27eacd9`;
`rechart.py` authenticates it before executing its helper definitions. The
companion [source/verify.py](source/verify.py) carries the embedded source pins.
The exact packaged paths and hashes are in [SHA256SUMS](SHA256SUMS).

The scientific source heads are #7830
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` and #7900
`0313ee081bd06e38586db1ee9595d9b36e4a243c`. The later archive packaging repair
adds retained dependencies and this provenance record; it changes no scientific
claim, replay script, candidate word, or numerical receipt.
