#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Exact two-endpoint rechart screen on the physically exchanged graph.

Any equal paid contacts are given free as an optimistic geometry relaxation;
this creates no changed word for a rank assignment. The complete altered
36-call invoice is carried through in every comparison.
"""
from collections import Counter,defaultdict
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import product
from pathlib import Path
from types import SimpleNamespace
import gzip,json,sys
HERE=Path(__file__).resolve().parent;SRC=HERE/'source';arb=SRC/'arbitrary.py'
assert sha256(arb.read_bytes()).hexdigest()=='b53b46c492860707b95e801c92b6bbf0608e5aa5061bd4fd5114fb28f27eacd9'
code=arb.read_text().split('\nout=[]\nfor i,p in enumerate(pairs[:N],1):');assert len(code)==2
z={'__file__':str(arb)};exec(compile(code[0],str(arb),'exec'),z)
v=z['v'];price=z['price'];w=json.loads(gzip.decompress((HERE/'EXCHANGE-WORD.json.gz').read_bytes()))
assert sha256(v.canon(w)).hexdigest()=='fa7126dc550e2dbfbb69321785351bafb943091664f91d0cf22d66e871dd4570'
charts,raw_edges,_,_,routes=v.graph(w)
move_ids={e[1]:680+j for j,e in enumerate(e for e in w['program'] if e[0]=='MOVE')}
assert len(move_ids)==2875
edge_by_key={key:(a,b) for kind,key,a,b in raw_edges if kind=='paid'}
a,b=edge_by_key[move_ids[2947]];A=b;B=a
assert charts[A]==421 and charts[B]==518
rank={int(k):r['dim'] for k,r in w['frames'].items()};edges=[];incident=defaultdict(list)
for kind,key,left,right in raw_edges:
 edges.append(SimpleNamespace(kind=kind,key=key,source=left,target=right,grade=abs(rank[charts[left]]-rank[charts[right]])))
 incident[left].append(len(edges)-1);incident[right].append(len(edges)-1)
receipt=v.read('inputs/BIT.json')['native'];paid=Counter({int(k):n for k,n in receipt['paid'].items()});paid[3]+=36
targets=Counter({int(k):n for k,n in receipt['targets'].items()});base=targets.copy();base.subtract(paid)
K=['0.003879928046156','0.003879929046155']
def normalize(c):return {str(k):n for k,n in sorted(c.items()) if k and n}
@lru_cache(None)
def power(r,k):return v.power_bounds(r,1-Fraction(k),240)
def check_power(c,k,interval):
 lo=hi=Fraction(0)
 for r,num in c.items():
  if not r or not num:continue
  a,b=power(r,k)
  lo+=num*(a if num>0 else b);hi+=num*(b if num>0 else a)
 assert lo<=Fraction(interval[1],price.GRID) and Fraction(interval[0],price.GRID)<=hi
def opts(node,other):
 ids=[i for i in incident[node] if other not in (edges[i].source,edges[i].target)]
 peers=tuple(sorted({charts[edges[i].target if edges[i].source==node else edges[i].source] for i in ids}))
 out=[]
 for d in range(9):
  env=z['envelope'](peers,d)
  if env is None:continue
  h=Counter()
  for i in ids:
   ed=edges[i];u=d if ed.source==node else rank[charts[ed.source]];v_=d if ed.target==node else rank[charts[ed.target]]
   if ed.kind=='targets' and v_<=u:break
   z['delta'](h,ed.kind,ed.grade,abs(u-v_))
  else:out.append((d,env,h))
 return peers,out
pa,oa=opts(A,B);pb,ob=opts(B,A)
inner=[i for i in set(incident[A])|set(incident[B]) if edges[i].source in (A,B) and edges[i].target in (A,B)]
assert len(inner)==1 and edges[inner[0]].kind=='paid'
rows=[];summary=Counter()
for x,y in product(oa,ob):
 d,ea,ha=x;e,eb,hb=y;h=ha.copy();h.update(hb)
 for i in inner:
  ed=edges[i];first=d if ed.source==A else e;second=d if ed.target==A else e
  if ed.kind=='targets' and second<=first:break
  z['delta'](h,ed.kind,ed.grade,abs(first-second))
 else:
  ee1,ee2,dd,ee=(ea,eb,d,e) if d<=e else (eb,ea,e,d)
  possible,why=z['dimension_test'](ee1,ee2,dd,ee)
  assert possible==(z['coupled'](ee1,ee2,dd,ee) is not None)
  full=base.copy();gain=Counter({k:36*n for k,n in h.items()});full.update(gain)
  ivs={k:price.moment(full,Fraction(k)) for k in K}
  for k in K:check_power(full,k,ivs[k])
  signs={k:('positive' if iv[0]>0 else 'negative' if iv[1]<0 else 'undecided') for k,iv in ivs.items()}
  summary['exterior_and_orientation_legal']+=1
  summary['geometry_feasible' if possible else 'geometry_obstructed']+=1
  if possible:
   for k in K:summary['feasible_balance_'+k+'_'+signs[k]]+=1
  rows.append({'ranks':[d,e],'native_signed_change_to_exchange':normalize(h),
   'geometry_possible':possible,'dimension_certificate':why,
   'complete_36_call_balance':{k:price.decimal_interval(ivs[k],48) for k in K},'balance_signs':signs})
assert not summary['feasible_balance_'+K[0]+'_positive'] and not summary['feasible_balance_'+K[1]+'_positive']
assert not summary['feasible_balance_'+K[0]+'_undecided'] and not summary['feasible_balance_'+K[1]+'_undecided']
out={'status':'NO_POSITIVE_COMPLETE_BALANCE_FOR_TWO_CHANGED_PARENT_ENDPOINTS',
 'scope':'Physically exchanged word; only chart-421 packet-2947 output component and chart-518 input component may choose arbitrary rational subspaces of Q8; all other graph forms, endpoints and helper orientation frozen. Equal paid contacts optimistically free. Candidate histogram includes both physically added paid routes, without relief.',
 'input_word_canonical_sha256':'fa7126dc550e2dbfbb69321785351bafb943091664f91d0cf22d66e871dd4570',
 'old_charts':[421,518],'external_neighbor_charts':[pa,pb],
 'original_clock_2947_new_sequential_packet_id':move_ids[2947],
 'source_packet_id_after_recompile':{'2669':move_ids[2669],'2674':move_ids[2674],'4233':move_ids[4233]},
 'rank_choices':[[i[0] for i in oa],[i[0] for i in ob]],'counts':dict(summary),'price_crosscheck':'directed Taylor and integer-square-root intervals overlap on every full balance', 'rows':rows,
 'qualification':'Necessary and sufficient coupled-subspace condition for these two components and fixed exterior, but no physical recode is constructed for a rank proposal; the screen is optimistic for any equal-rank paid contact.'}
print(json.dumps(out,indent=2,sort_keys=True))
