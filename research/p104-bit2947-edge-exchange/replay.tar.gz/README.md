# Packet 2669: a physical edge exchange with a negative invoice

A literal alternate-stock replacement **does** remove the original packet-2669 incidence into the packet-2947 source, and it preserves the complete native operator. It does **not** improve the signed invoice: the replacement adds a net grade-three paid position per native call. Its full 36-call signed margins are

| κ | Complete signed margin, including the unchanged caller |
| --- | --- |
| `0.003879928046156` | `−107.540625789895758010659242804791616394796523069670` to `−107.540625789895758010659242804791616394796523069669` |
| `0.003879929046155` | `−107.541010798300035562024600106671356082777209913321` to `−107.541010798300035562024600106671356082777209913320` |

The exact native signed histogram change is `{3: −1}`: the old grade-one MOVE is removed and new grade-one and grade-three MOVEs are both charged. Every productive position and all 36 caller invocations remain included. The two marginal price changes are approximately −107.54062578912876 and −107.54062567098342 respectively. Two independently directed arithmetic methods agree on the full price and its change. This changed word supports no new κ claim or maintainer selection.

## The physical replacement

The source is the [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) binary word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The named pair and prior fixed-incidence context are from [#7900](https://github.com/CrocSwap/integer-mult-bounds/pull/7900), head `0313ee081bd06e38586db1ee9595d9b36e4a243c`. Original clock numbers below refer to the pinned source.

At clock 9296, packet 2669 sends `2050 XOR 2244` from chart 418 to chart 518 at grade one. It is read by packet 2947 at clock 10386 and by packet 2948 at clock 10390. Delete its original `INIT`, two source `ADD`s, `MOVE`, both reader `ADD`s, and its original `CLEAR`. At the first reader, instead:

1. Form a temporary from live bank 2671 on chart 1 and move it to chart 518, grade 1.
2. Form a second temporary from live banks 1477, 1649, 1773, 1801 and 1853 on chart 320 and move it to chart 518, grade 3.
3. XOR both temporary values into each of packets 2947 and 2948 at the original reads, then retire both temporaries. Bank 4233 is inactive at this time and is reused before its later original lifetime.

The two temporary values XOR exactly to the old packet-2669 value at both reads. The 418→518 incidence is gone; new 1→518 and 320→518 incidences are present. All other original paid packets remain, including packet 2671, which already has its own 418→1 charge. The physical word is [EXCHANGE-WORD.json.gz](EXCHANGE-WORD.json.gz), canonical JSON SHA-256 `fa7126dc550e2dbfbb69321785351bafb943091664f91d0cf22d66e871dd4570`.

A direct chronological tape, the retained predecessor's separate literal checker, and the #7830 vendor tape each reproduce all **680² scalar coefficients in both orientations**. The 38² caller polynomial coefficients pass in both orientations. All 222 main and 458 helper outputs are preserved. All 111 main contacts, owner 411, the protected bridge and tree source events, and the owner-411 bridge-ADD omission test survive in both directions. The candidate has 3,555 dirty private retirements in each direction. The original paid packets' forward payloads are unchanged; in the adjoint, surviving packets 2244 and 2671 have changed payloads. All ten changed surviving read or retirement observations, plus both changed paid payloads, are recorded in [RESULT.json](RESULT.json); they are not assumed unchanged.

Under the predecessor's raw ordinary allowance formula, the complete changed tape counts 934,413,198,096 records and 6,998,544 owned backing fields, below the respective 10¹² and 10⁷ raw limits. This arithmetic is not a finite compiler qualification or a new multiplication theorem.

## Reader span and recomputed geometry

Before the first read, the only other nonzero chart-518 stock is bank 2674, and the fresh receiver is zero. Original input owner 8 has coefficient 1 in the missing packet and 0 in bank 2674, proving that an XOR of that local stock alone cannot restore it. The check searches every one of the **636 live nonzero chart groups**, allowing any XOR from one sender chart, one paid transfer to chart 518, and either local chart-518 XOR. The only first-read hit is chart 418, banks 2050 XOR 2244, which simply recreates the original incidence. At the second read, provided the first has been repaired, the now-live packet 2947 on chart 421 gives an additional grade-one source when combined with local bank 2674; this does not solve the earlier read. The separately recorded bounded two-sender search fixes chart 1 as one sender and considers other eligible sender charts; it produces the chart-320 construction above. No claim is made about other two-sender families or later upstream edits.

The component graph is rebuilt from the emitted physical word, and its affected components and incidences appear in the receipt. The source parent component for the new chart-320 route contains the original packet 2244 source and its independent incidence; the chart-1 route uses the independently owed packet 2671. Both are kept and charged. In the changed graph, the rank-(7,7) parent proposal remains impossible even if equal paid contacts are optimistically inlined: remaining chart 617 has rank 7, remaining chart 420 has rank 6, and their rational union has rank 8. Packet 2947 would force both proposed seven-spaces to be equal, so they cannot contain that union. A row of chart 420 dotted with a chart-617 normal equals 1. This is a specific dimension certificate, not an exclusion of all other ranks or of other physical designs.

After rebuilding the changed component graph, [RECHART.json](RECHART.json) screens the **two parent endpoints** over arbitrary rational subspaces, with all exterior components and packet forms fixed and equal paid contacts optimistically free. It finds 24 rank pairs compatible with the exterior and helper orientation: 18 satisfy the exact joint-space criterion and six do not. All 18 feasible pairs have strictly negative complete 36-call balances at both trials. The greatest feasible balance occurs at ranks `(7, 8)`, approximately −106.319648519974 and −106.320033214779. This is an optimistic fixed-exterior geometry and price screen; no physical recode of those proposed spaces is claimed.

As a failure control, physically deleting 2669 without restoring its reads preserves the chart tape but corrupts 77 forward outputs (66 main, 11 helper) and 36 adjoint outputs (19 main, 17 helper). It changes 137 forward and 47 adjoint surviving paid payloads; the full observer deltas are in the receipt. No relief is credited to this invalid word. A separate valid retiming of the original 418→518 route has exactly unchanged packet geometry, all observer payloads, and invoice; it earns zero.

## Reproduce

From this directory using Python 3.12 and the standard library:

```sh
sha256sum -c SHA256SUMS
python3 -I -B exchange.py > /tmp/p104-2669-result.json
cmp RESULT.json /tmp/p104-2669-result.json
python3 -I -B exchange.py --emit > /tmp/p104-2669-word.json
gzip -dc EXCHANGE-WORD.json.gz | cmp - /tmp/p104-2669-word.json
python3 -I -B two_donor_search.py > /tmp/p104-2669-two-search.txt
cmp TWO-SEARCH.txt /tmp/p104-2669-two-search.txt
python3 -I -B rechart.py > /tmp/p104-2669-rechart.json
cmp RECHART.json /tmp/p104-2669-rechart.json
```

The script pins every retained input under [source](source/) and reconstructs the literal word, reader spans, affected component graph, unchanged caller, observer deltas, protected omission, both exact directions, ordinary recount and complete price. The copied predecessor notice and license remain in [source](source/).

## Open questions

Could a different incidence, an upstream re-encoding, more complex sender combination, or a jointly recharted physical exchange yield a positive complete invoice? This result tests one named original incidence and one charged two-sender construction. It does not exclude those other families, and neither the finite compiler nor supplier/application qualification is claimed for this negative-price candidate.
