from collections import defaultdict
import gzip,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent/'source';sys.path.insert(0,str(P/'vendor'));from binary_operator import Atlas
w=json.load(gzip.open(P/'inputs/WORD.json.gz','rt'));a=Atlas(w['frames']);n=w['public'];cells=[(c,1<<i) for i,c in enumerate(w['start'])]+[None]*w['owned_fields']
def add(basis,x,tags):
 while x:
  p=x.bit_length()-1
  if p in basis:x^=basis[p][0];tags^=basis[p][1]
  else:basis[p]=(x,tags);return
for clk,(op,r,*arg) in enumerate(w['program']):
 if clk==10386:
  target=cells[2669][1];groups=defaultdict(list)
  for bank,v in enumerate(cells):
   if v and v[1] and bank not in (2669,2947):groups[v[0]].append((bank,v[1]))
  print('chart1 stock',len(groups[1]))
  b1={}
  for bank,x in groups[1]:add(b1,x,1<<bank)
  print('chart1 span rank',len(b1));hits=[]
  for c,rows in sorted(groups.items()):
   if c in (1,418,518) or a.grade(c,518)==0:continue
   b=b1.copy()
   for bank,x in rows:add(b,x,1<<bank)
   for local in (0,1):
    x=target^(cells[2674][1] if local else 0);tags=0
    while x:
     p=x.bit_length()-1
     if p not in b:break
     x^=b[p][0];tags^=b[p][1]
    if not x:
     donors=[j for j in range(n+w['owned_fields']) if tags>>j&1]
     d1=[i for i in donors if cells[i][0]==1];d2=[i for i in donors if cells[i][0]==c]
     if not d1 or not d2:continue
     hits.append({'charts':[1,c],'grades':[a.grade(1,518),a.grade(c,518)],'donors1':d1,'donors2':d2,'local2674':local,'rank':len(b)})
  print('hits',len(hits));print(json.dumps(sorted(hits,key=lambda h:(sum(h['grades']),len(h['donors1'])+len(h['donors2']))),indent=2));break
 if op=='INIT':cells[r]=(arg[0],0)
 elif op=='CLEAR':cells[r]=None
 elif op=='ADD':cells[r]=(cells[r][0],cells[r][1]^cells[arg[0]][1])
 elif op=='MOVE':cells[r]=(arg[1],cells[r][1])
 elif op=='SWAP':cells[r],cells[arg[0]]=cells[arg[0]],cells[r]
