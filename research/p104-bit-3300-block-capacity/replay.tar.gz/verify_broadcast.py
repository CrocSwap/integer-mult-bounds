#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Rebuild the pinned 3300 envelopes and certify their arbitrary-block cost."""
import argparse
from collections import defaultdict
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'source'))
from audit_3300_common_scalar import mutable
from verify_fixed_prefix_dual import NEW, SHA, parse


def dot(lhs, rhs):
    return (lhs & rhs).bit_count() & 1


def xor(values):
    row = 0
    for value in values:
        row ^= value
    return row


def support(row):
    while row:
        bit = row & -row
        yield bit.bit_length() - 1
        row ^= bit


class Rows:
    """Binary row reduction with a tag for every independent equation."""

    def __init__(self, values=()):
        self.pivots = {}
        self.dependencies = []
        for index, value in enumerate(values):
            self.add(value, 1 << index)

    def add(self, value, tag=0):
        while value:
            pivot = value.bit_length() - 1
            if pivot not in self.pivots:
                self.pivots[pivot] = value, tag
                return
            other, reference = self.pivots[pivot]
            value ^= other
            tag ^= reference
        self.dependencies.append(tag)

    def reduce(self, value):
        tag = 0
        for pivot, (row, old_tag) in sorted(self.pivots.items(), reverse=True):
            if (value >> pivot) & 1:
                value ^= row
                tag ^= old_tag
        return value, tag

    def rows(self):
        return [row for row, _ in self.pivots.values()]


def right_kernel(equations, width):
    pivots = Rows(equations).pivots
    for index in range(width):
        if index in pivots:
            continue
        vector = 1 << index
        for pivot, (row, _) in sorted(pivots.items()):
            if dot(row, vector):
                vector ^= 1 << pivot
        yield vector


def solve(equations, values):
    space = Rows()
    for row, target in zip(equations, values, strict=True):
        space.add(row, target)
    assert not any(space.dependencies), 'inconsistent witness lift'
    solution = 0
    for pivot, (row, target) in sorted(space.pivots.items()):
        if dot(row, solution) != target:
            solution ^= 1 << pivot
    return solution


def envelope(word, packets, use_p, add_x549, candidate_charts=None):
    free = mutable(packets)
    assert len(free) == 344 and 3553 not in free
    banks = defaultdict(list)
    # Track fixed XOR parts, possible linear observations and real 3300 reach.
    states = {i: (1 << i, (), False) for i in range(680)}
    for index, chart in enumerate(word['start']):
        banks[chart].append(index)
    prefix = {
        NEW: [549], 785: [679, NEW], 789: [NEW], 1583: [17, 781],
        1584: [785], 1585: [1583, 813], 1586: [1583], 1934: [1584],
        2234: [1445, 1577, 1661, 1901] + ([1585] if use_p else []),
        2947: [2669, 2674], 3409: [2234, 2947] + ([789] if add_x549 else []),
    }
    events = [(2 * p['clock'], i) for i, p in packets.items() if i not in (3409, 3410)]
    # Half slots denote strictly-after insertions on the pinned MOVE clock.
    events.extend(((741, NEW), (20777, 3409)))
    source_rows = None
    source_ids = None
    pre_send = {}
    for when, packet in sorted(events):
        if packet == NEW:
            start, finish = 0, 19
        else:
            start = 19 if packet == 1583 else packets[packet]['source']
            finish = 0 if packet == 3409 else packets[packet]['destination']
        live = banks[start]
        if packet == 3300:
            assert (when, start, finish) == (22976, 13, 0)
            assert live == [11, 673, 747, 748, 749, 750, 3299]
            assert all(not states[i][2] for i in live)
            source_ids = live.copy()
            source_rows = Rows(r for j in live for r in (states[j][0], *states[j][1])).rows()
            value = 0, (), True
        elif packet in free and packet not in prefix:
            grant = Rows(r for j in live for r in (states[j][0], *states[j][1])).rows()
            value = 0, grant, any(states[j][2] for j in live)
        else:
            donors = prefix.get(packet)
            if donors is None:
                donors = [3409 if d == 3410 else d for d in packets[packet]['donors']]
            assert set(donors) <= set(live)
            constant = xor(states[i][0] for i in donors)
            directions = Rows(r for i in donors for r in states[i][1]).rows()
            value = constant, directions, any(states[i][2] for i in donors)
        if finish in (598, 603):
            chart_ids = [start] if candidate_charts is None else candidate_charts[packet]
            pre_send[packet] = {
                chart: (Rows(r for j in banks[chart] for r in (states[j][0], *states[j][1])).rows(),
                        any(states[j][2] for j in banks[chart]))
                for chart in chart_ids
            }
        states[packet] = value
        banks[finish].append(packet)
    known = []
    for owner in (184, 189):
        members = banks[word['final'][owner]]
        assert any(states[i][2] for i in members)
        known.append(Rows(r for i in members for r in (states[i][0], *states[i][1])).rows())
    assert len(source_rows) == 18 and [len(v) for v in known] == [566, 572]
    return source_ids, source_rows, known, pre_send, states


def analyse(source, known, targets):
    source_dimension = len(source)
    sides = []
    for side, target in zip(known, targets, strict=True):
        side_span = Rows(side)
        residues = [side_span.reduce(row)[0] for row in source]
        image = Rows(residues)
        missing, coefficient = image.reduce(side_span.reduce(target)[0])
        assert missing == 0 and coefficient, 'target must need a feasible message'
        representative = xor(source[i] for i in support(coefficient))
        assert side_span.reduce(target ^ representative)[0] == 0
        sides.append((side, representative, coefficient, image.dependencies))
    (side0, row0, coeff0, orth0), (side1, row1, coeff1, orth1) = sides
    joint_kernel = list(right_kernel(orth0 + orth1, source_dimension))
    restrictions = [dot(coeff0, v) | (dot(coeff1, v) << 1) for v in joint_kernel]
    joint_rank = len(Rows(restrictions).rows())
    individual_ranks = [int(any(v & (1 << i) for v in restrictions)) for i in range(2)]
    total = joint_rank + max(1 - rank for rank in individual_ranks)
    assert total == 2

    # Produce an explicit 2D clique of encoder stocks and native preimage
    # differences for its three nonzero vectors, for independent checking.
    clique = {}
    for i, (side, coeff, side_orth) in enumerate(((side0, coeff0, orth0), (side1, coeff1, orth1))):
        differences = list(right_kernel(side_orth, source_dimension))
        if individual_ranks[i] == 0:
            first = next(v for v in differences if dot(coeff, v))
            other = coeff1 if i == 0 else coeff0
            second = next(v for v in joint_kernel if dot(other, v))
            selectors = [i, 1-i, i]
            break
    else:
        both = Rows(restrictions)
        first = xor(joint_kernel[i] for i in support(both.reduce(1)[1]))
        second = xor(joint_kernel[i] for i in support(both.reduce(2)[1]))
        assert first and second
        selectors = [0, 1, 0]
    for delta, i in zip((first, second, first ^ second), selectors, strict=True):
        assert delta and delta not in clique
        side = known[i]
        y = [(delta >> j) & 1 for j in range(source_dimension)]
        lift = solve(side + source, [0]*len(side) + y)
        assert all(dot(row, lift) == 0 for row in side)
        assert [dot(row, lift) for row in source] == y
        assert dot(targets[i], lift) == 1
        clique[delta] = dict(receiver=(184, 189)[i], native_flip=list(support(lift)))

    return dict(source_rank=source_dimension, known_ranks=[len(v) for v in known],
                difference_ranks=[source_dimension-len(orth0), source_dimension-len(orth1)],
                intersection_rank=len(joint_kernel), target_restriction_ranks=individual_ranks,
                joint_target_restriction_rank=joint_rank, minimum_bits_per_copy=total,
                separate_source_rows=[list(support(row)) for row in (row0, row1)],
                clique_basis=[list(support(first)),list(support(second))],
                clique_witnesses=[{'difference':list(support(key)),**value} for key,value in clique.items()])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--emit', action='store_true', help='print regenerated result rather than comparing')
    args = parser.parse_args()
    encoded = (HERE / 'source' / 'WORD.json.gz').read_bytes()
    assert sha256(encoded).hexdigest() == SHA
    word = json.loads(gzip.decompress(encoded))
    packets, targets = parse(word)
    cases = []
    for use_p in (False, True):
        for add_x549 in (False, True):
            sources, U, B, _, _ = envelope(word, packets, use_p, add_x549)
            report = analyse(U, B, [targets[184], targets[189]])
            cases.append(dict(use_p=use_p, add_x549=add_x549, source_labels=sources, **report))
    result = dict(native_gzip=SHA, owners=[184,189], shared_packet=3300, cases=cases,
                  scope='Four reduced fixed-prefix cases. No full-word or improved kappa assertion.')
    rendered = json.dumps(result, indent=2, sort_keys=True) + '\n'
    if args.emit:
        print(rendered, end='')
    else:
        assert rendered == (HERE/'RESULT.json').read_text()
        print('PASS: 4 pinned cases. 2D conflicts and two separate source rows checked in each.')


if __name__ == '__main__':
    main()
