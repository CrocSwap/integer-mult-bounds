#!/usr/bin/env python3
"""Exact fixed-prefix one-feedback obstruction and positive/corrupt controls.

Supports both the D+h proposal and the noP variant. This does NOT exclude
arbitrary changes to their earlier local basis matrices. All late chart0
senders and every paid child on their unique paths are arbitrary; every
terminal decoder is arbitrary. The feedback is even granted an arbitrary
global input row at clock10389.
"""
import argparse,collections,gzip,hashlib,json
from pathlib import Path

SHA='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
NEW=4234
PREFIX={785:[679,NEW],789:[NEW],1583:[17,781],1585:[1583,813],1586:[1583],
        1934:[1584],2234:[1585],2677:[789],2678:[2234],3547:[264],
        1931:[722,1464,1728,1824],1932:[1360,1464,1728,1824],
        1935:[722,1360,1464],1936:[722,1360,1464,1728]}

def need(ok,message):
    if not ok:raise RuntimeError(message)

def basis(rows):
    b={}
    for v in rows:
        while v:
            q=v.bit_length()-1
            if q not in b:b[q]=v;break
            v^=b[q]
    return b

def rem(v,b):
    for q,r in sorted(b.items(),reverse=True):
        if v>>q&1:v^=r
    return v

def parse(word):
    val={i:1<<i for i in range(680)};loc=dict(enumerate(word['start']));donors={};p={}
    for clock,op in enumerate(word['program']):
        k,i,*a=op
        if k=='INIT':need(i not in val,'duplicate owner');val[i]=0;loc[i]=a[0];donors[i]=[]
        elif k=='ADD':
            j,c=a;need(loc[i]==loc[j]==c,'native ADD location');val[i]^=val[j];donors[i].append(j)
        elif k=='MOVE':
            s,d=a;need(loc[i]==s,'native MOVE source');p[i]=dict(label=i,clock=clock,source=s,destination=d,donors=donors[i].copy());loc[i]=d
        elif k=='SWAP':
            j=a[0];val[i],val[j]=val[j],val[i];loc[i],loc[j]=loc[j],loc[i]
        elif k=='CLEAR':del val[i];del loc[i]
        else:raise RuntimeError('unknown native operation')
    need(set(val)==set(range(680)) and len(p)==2874,'native dimensions')
    T={i:(1<<i)^((1<<(i-111)) if 111<=i<222 else 0) for i in range(680)}
    need(val==T,'native complete forward matrix')
    need(all(loc[i]==word['final'][i] for i in range(680)),'native endpoints')
    need(NEW>max(op[1] for op in word['program']),'new owner collides with native scratch')
    return p,T

def evaluate(word,p,choice):
    parents=[i for i,r in p.items() if r['source']==0 and r['clock']>10378]
    paths={}
    for i in parents:
        path=[i]
        while True:
            readers=[j for j,r in p.items() if path[-1] in r['donors']]
            if not readers:break
            need(len(readers)==1,'feedback reader branch');path.append(readers[0])
        paths[i]=path
    free={i for path in paths.values() for i in path}
    need(len(parents)==111 and len(free)==231,'late path inventory')
    events=sorted([(r['clock'],i) for i,r in p.items() if i not in {3409,3410}]+[(350,NEW),(10389,3409)])
    base={i:1<<i for i in range(680)};K={i:() for i in range(680)};Z={i:False for i in range(680)}
    stock=collections.defaultdict(list);at={}
    for i,c in enumerate(word['start']):stock[c].append(i)
    for clock,i in events:
        if i==NEW:s,d,ds=0,19,[549]
        else:s,d,ds=(19 if i==1583 else p[i]['source']),(0 if i==3409 else p[i]['destination']),choice.get(i,p[i]['donors'])
        at[i]=stock[s].copy()
        if i==3409:base[i]=0;K[i]=();Z[i]=True
        elif i in free:
            # An upper envelope for every possible known component of one
            # mutable scalar. Retaining all these directions only weakens
            # an impossibility conclusion.
            base[i]=0;K[i]=tuple(basis(v for j in stock[s] for v in (base[j],*K[j])).values());Z[i]=any(Z[j] for j in stock[s])
        else:
            need(all(j in stock[s] for j in ds),'illegal prefix source stock')
            base[i]=0
            for j in ds:base[i]^=base[j]
            K[i]=tuple(basis(v for j in ds for v in K[j]).values());Z[i]=any(Z[j] for j in ds)
        stock[d].append(i)
    return base,K,Z,stock,at,paths,free

def check_variant(word,p,T,variant):
    choice={i:ds.copy() for i,ds in PREFIX.items()}
    if variant=='noP':choice[1584]=[785];del choice[2234]
    base,K,Z,stock,at,paths,free=evaluate(word,p,choice)
    need(all(not K[i] and not Z[i] for i in stock[1]),'late ambiguity reaches chart1 control')
    one=basis(base[i] for i in stock[1]);need(len(one)==537,'positive chart1 rank')
    need(all(rem(T[i],one)==0 for i,c in enumerate(word['final']) if c==1),'positive chart1 demand span')
    h=base[1934]^base[789]
    if variant=='DplusH':h^=base[2234]
    need(h==1<<679,'positive owner679 return')

    hs={198:[58,92,96,102,108,109,110],205:[0,96,101,109,110],203:[0,58,92,101,102,108]}
    gs={198:[17,87,110],205:[17,94,101,107],203:[0,58,92,101,102,108]}
    proofs=[];combined=0;combined_rhs=0
    for owner in [198,205,203]:
        chart=word['final'][owner];parent=next(i for i,path in paths.items() if p[path[-1]]['destination']==chart)
        ids=stock[chart];B=basis(v for i in ids for v in (base[i],*K[i]))
        need(any(Z[i] for i in ids),'missing feedback opportunity')
        H=sum(1<<i for i in hs[owner]);G=sum(1<<i for i in gs[owner]);rhs=(T[owner]&H).bit_count()%2
        need(all((r&H).bit_count()%2==0 and (r&G).bit_count()%2==0 for r in B.values()),'annihilator fails')
        need((T[owner]&G).bit_count()%2==1,'target not separated from known stock')
        need(rhs==int(owner==203),'dual RHS')
        combined^=H;combined_rhs^=rhs
        proofs.append(dict(owner=owner,chart=chart,path=paths[parent],parent_clock=p[parent]['clock'],known_component_rank=len(B),
                           constraint_probe=hs[owner],constraint_rhs=rhs,deficiency_probe=gs[owner],deficiency_rhs=1))
    need(combined==0 and combined_rhs==1,'inconsistent affine feedback system not established')
    Wids=at[3409];W=[base[i] for i in Wids];H=sum(1<<i for i in hs[203])
    need(Wids==[264,789,1934,2234,2947] and all((r&H).bit_count()%2==0 for r in W),'actual421 source bound')

    corrupt={i:ds.copy() for i,ds in choice.items()};corrupt[2678]=[789]
    cb,cK,cZ,cstock,_,_,_=evaluate(word,p,corrupt)
    crank=len(basis(cb[i] for i in cstock[1]));need(crank==536,'corrupt duplicate-arrival control not caught')
    return dict(variant=variant,source_equations=choice,
                positive_controls=dict(chart1_arrivals=537,chart1_demand_rank=537,chart1_stock_rank=537,owner679_recovered=True),
                corrupt_control=dict(change='2678 sends789 instead of2234',chart1_stock_rank=crank,required_rank=537),
                arbitrary_global_feedback_dual=proofs,dual_sum=dict(probe=0,rhs=1),
                actual_feedback_source_ids=Wids,source_restricted_missed_owner=203,
                late_mutable_sender_labels=sorted(free),terminal_decoders='Arbitrary',
                scope='All earlier equations fixed to this prefix; all111late0senders and120paidchainchildren arbitrary; feedback even an arbitrary global row at10389. Not an arbitrary-earlier-recoding theorem.')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('word',type=Path);ap.add_argument('--out',type=Path);a=ap.parse_args()
    raw=a.word.read_bytes();need(hashlib.sha256(raw).hexdigest()==SHA,'wrong pinned source');word=json.loads(gzip.decompress(raw));p,T=parse(word)
    r=dict(schema='P104-round10-fixed-prefix-feedback-dual/1',gzip_sha256=SHA,
           fresh_contact=dict(label=NEW,source=0,destination=19,grade=1,clock=350,payload='e549'),
           fixed_topology_changes=dict(regraded1583='19to182grade1',feedback3409='421to0at10389',deleted=[3410]),
           variants=[check_variant(word,p,T,v) for v in ['DplusH','noP']],
           qualification='Exact packet-level impossibility for each fixed prefix, with positive local controls; no successful full word or kappa claim.')
    if a.out:a.out.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps(dict(status='VERIFIED',variants=['DplusH','noP'],positive_chart1_rank=537,corrupt_rank=536,
                         feedback_dual_owners=[198,205,203],fresh_noncolliding_owner=NEW),indent=2))

if __name__=='__main__':main()
