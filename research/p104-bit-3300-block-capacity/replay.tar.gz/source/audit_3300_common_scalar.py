#!/usr/bin/env python3
"""Independent standard-library replay of the two-owner common3300 cut.

All 344 mutable contacts receive a causal affine row-space overgrant, except
3300, which remains one common scalar z in its source envelope at clock11488.
No h-free or chart1 saturation restriction is imposed in this audit.
"""
import argparse,collections,gzip,hashlib,json
from pathlib import Path
from verify_fixed_prefix_dual import parse,basis,rem,NEW,SHA,need

H184=[86,95,101,102,105]
H189=[78,85,86,94,95,96,101,102,105,106,107,108,110]
G184=[29,58,73,95,100,102,105,107,110]
G189=[78,102,106,108,109]

def xor(rows):
    v=0
    for r in rows:v^=r
    return v

def mutable(p):
    f={i for i,r in p.items()if r['source']in{268,318,421,518,509}and i!=3553}
    f|={i for i,r in p.items()if r['source']==0 and r['clock']>10378}
    f|={i for i,r in p.items()if set(r['donors'])&set(range(1931,1937))}
    f|={i for i,r in p.items()if r['destination']==0 and i!=3410}
    while True:
        more={i for i,r in p.items()if i not in{3410,3553}and any(j in f for j in r['donors'])}
        if more<=f:return f
        f|=more

def audit(w,p,T,c,a):
    f=mutable(p);need(len(f)==344,'mutable family')
    native={i:1<<i for i in range(680)}
    for i,r in p.items():native[i]=xor(native[j]for j in r['donors'])
    # A triple (base, directions, z_available) contains every actual packet
    # row in base+span(directions)+span(z) when z_available is true.
    V={i:(1<<i,(),False)for i in range(680)};stocks=collections.defaultdict(list)
    for i,ch in enumerate(w['start']):stocks[ch].append(i)
    prefix={NEW:[549],785:[679,NEW],789:[NEW],1583:[17,781],1584:[785],1585:[1583,813],1586:[1583],1934:[1584],
            2234:[1445,1577,1661,1901]+([1585]if c else []),2947:[2669,2674],3409:[2234,2947]+([789]if a else [])}
    seq=sorted([(r['clock'],i)for i,r in p.items()if i not in{3409,3410}]+[(350,NEW),(10389,3409)])
    for clock,i in seq:
        src,dst=(0,19)if i==NEW else((19 if i==1583 else p[i]['source']),(0 if i==3409 else p[i]['destination']))
        if i==3300:
            source_ids=stocks[src].copy()
            need(clock==11488 and src==13 and dst==0,'3300 source or chronology')
            need(source_ids==[11,673,747,748,749,750,3299],'strict3300 stock')
            need(not any(V[j][2]for j in source_ids),'future common scalar used at its source')
            U=basis(r for j in source_ids for r in(V[j][0],*V[j][1]))
            value=(0,(),True)
        elif i in f and i not in prefix:
            value=(0,tuple(basis(r for j in stocks[src]for r in(V[j][0],*V[j][1])).values()),any(V[j][2]for j in stocks[src]))
        else:
            ds=prefix[i]if i in prefix else[3409 if j==3410 else j for j in p[i]['donors']]
            need(set(ds)<=set(stocks[src]),'fixed source stock')
            value=(xor(V[j][0]for j in ds),tuple(basis(r for j in ds for r in V[j][1]).values()),any(V[j][2]for j in ds))
        V[i]=value;stocks[dst].append(i)
    Bs={};records=[]
    for owner,hs,gs in[(184,H184,G184),(189,H189,G189)]:
        chart=w['final'][owner];ids=stocks[chart]
        B=basis(r for j in ids for r in(V[j][0],*V[j][1]));Bs[owner]=B
        H=sum(1<<j for j in hs);G=sum(1<<j for j in gs)
        need(any(V[j][2]for j in ids),'no common-scalar route')
        need(all((r&H).bit_count()%2==0 and(r&G).bit_count()%2==0 for r in B.values()),'terminal annihilator')
        need((T[owner]&G).bit_count()%2==1,'target must use common scalar')
        need((T[owner]&H).bit_count()%2==int(owner==189),'incompatible common-scalar RHS')
        records.append(dict(owner=owner,chart=chart,stock=ids,known_rank=len(B),
                            constraint_probe=hs,constraint_rhs=int(owner==189),deficiency_probe=gs,deficiency_rhs=1))
    Hsum=sum(1<<j for j in H184)^sum(1<<j for j in H189)
    need(len(U)==18 and all((r&Hsum).bit_count()%2==0 for r in U.values()),'3300 source dual')
    J=basis([*Bs[184].values(),*(r<<680 for r in Bs[189].values()),*(r^(r<<680)for r in U.values())])
    target=T[184]^(T[189]<<680)
    need([len(Bs[o])for o in[184,189]]==[566,572]and len(J)==1151 and rem(target,J)!=0,'joint rank certificate')
    return dict(C_adds_P=c,feedback_adds_w=a,source_stock=source_ids,source_clock=11488,source_envelope_rank=18,
                source_dual_probe=[j for j in range(680)if Hsum>>j&1],terminals=records,
                diagonal_quotient_rank=13,augmented_target_rank=14,
                result='IMPOSSIBLE: one common3300 scalar is forced to have source-compatible evaluations0and1.')

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('word',type=Path);ap.add_argument('--out',type=Path);args=ap.parse_args()
    raw=args.word.read_bytes();need(hashlib.sha256(raw).hexdigest()==SHA,'pinned gzip')
    decoded=gzip.decompress(raw);w=json.loads(decoded);p,T=parse(w)
    results=[audit(w,p,T,c,a)for c in[0,1]for a in[0,1]]
    report=dict(schema='P104-round10-independent-common3300-audit/2',gzip_sha256=SHA,
                decoded_sha256=hashlib.sha256(decoded).hexdigest(),native_rows_verified=680,
                mutable_labels=sorted(mutable(p)),new_contact_label=NEW,cases=results,
                scope='FixednoPprefix and native move clocks except3409 at10389; arbitrary344sender equations with free terminal decoders; no h-free saturation restrictions imposed. All other mutable contacts overgranted. No successful word or kappa claim.')
    if args.out:args.out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(status='INDEPENDENTLY_VERIFIED',cases=4,common_scalar=3300,source_clock=11488,
                         source_rank=18,known_ranks=[566,572],quotient_rank=13,augmented_rank=14,mutable_count=344),indent=2))

if __name__=='__main__':main()
