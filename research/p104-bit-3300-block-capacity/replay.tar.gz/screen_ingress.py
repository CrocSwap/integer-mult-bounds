#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Screen one terminal retarget with every original side observation granted."""
import argparse
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_broadcast import HERE, Rows, SHA, analyse, envelope, parse, support, xor
from binary_operator import Atlas

OWNERS = (184, 189)
CHARTS = (598, 603)
STOCK_IDS = ((2907, 2913, 2918, 3498), (2910, 2916, 2919, 3509))


def affine(encoder, known, target):
    residues = Rows(known)
    table = Rows(residues.reduce(row)[0] for row in encoder)
    rem, tags = table.reduce(residues.reduce(target)[0])
    assert not rem
    head = xor(encoder[j] for j in support(tags))
    kernel = [xor(encoder[j] for j in support(dependency)) for dependency in table.dependencies]
    return head, kernel


def relaxed_receiver_deficits(sides, targets, encoder):
    return analyse(encoder, sides, targets)['minimum_bits_per_copy']


def verify_case(word, packets, targets, atlas, eligible, use_p, add_x549):
    _, sender, known, stocks, states = envelope(word, packets, use_p, add_x549, eligible)
    assert sorted(stocks) == sorted(sum(STOCK_IDS, ()))
    old_source_grants = []
    for side, slots in zip(known, STOCK_IDS, strict=True):
        # Give each terminal every actual incoming sender's entire pre-MOVE
        # envelope, without deleting the native receipt and without a tariff.
        all_rows = [r for slot in slots for r in stocks[slot][packets[slot]['source']][0]]
        old_source_grants.append(Rows(side + all_rows).rows())
    old_rooms = relaxed_receiver_deficits(old_source_grants, targets, sender)
    counts = []
    optimistic = []
    surviving = []
    for receiver, slots in enumerate(STOCK_IDS):
        other = 1 - receiver
        other_value, other_kernel = affine(sender, known[other], targets[other])
        # The two useful extra observations modulo the unchanged terminal bank.
        support_goals = (targets[receiver], targets[receiver] ^ other_value)
        grant_basis = Rows(known[receiver] + other_kernel)
        for slot in slots:
            source = packets[slot]['source']
            dest = packets[slot]['destination']
            grade = atlas.grade(source, dest)
            remaining = [m for m in slots if m != slot]
            surviving_rows = Rows(r for p in remaining for r in (states[p][0], *states[p][1])).rows()
            any_z_at_receiver = any(states[p][2] for p in remaining)
            considered = 0
            for new_chart, (live, z_at_new_source) in stocks[slot].items():
                if source == new_chart:
                    continue
                considered += 1
                # Even a free full-span grant at the retargeted source must
                # carry one of the two exact quotient directions.
                enlarged = Rows(grant_basis.rows() + live)
                useful = [i for i,row in enumerate(support_goals) if enlarged.reduce(row)[0] == 0]
                if not useful:
                    continue
                record = dict(owner=OWNERS[receiver], slot=slot, old_chart=source, new_chart=new_chart,
                              old_grade=grade, new_grade=atlas.grade(new_chart,dest),
                              clock=packets[slot]['clock'], tests=useful)
                optimistic.append(record)
                new_basis = Rows(surviving_rows + live)
                feasible = new_basis.reduce(targets[receiver])[0] == 0
                if any_z_at_receiver or z_at_new_source:
                    with_common = Rows(surviving_rows + live + other_kernel)
                    feasible |= with_common.reduce(targets[receiver] ^ other_value)[0] == 0
                if feasible:
                    surviving.append(record)
            counts.append(dict(slot=slot, clock=packets[slot]['clock'], grade=grade, retargets=considered))
    return dict(use_p=use_p, add_x549=add_x549, old_sender_full_grant_ranks=[len(r) for r in old_source_grants],
                min_bits_with_all_eight_old_sender_grants=old_rooms, tested=counts,
                optimistic_one_retarget=optimistic, one_retarget_after_removing_old_payload=surviving)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--emit', action='store_true')
    args = ap.parse_args()
    encoded = (HERE/'source'/'WORD.json.gz').read_bytes()
    assert sha256(encoded).hexdigest() == SHA
    word = json.loads(gzip.decompress(encoded))
    atlas = Atlas(word['frames'])
    packets, demands = parse(word)
    eligible = {}
    assert not any(event['source'] == 1 for event in packets.values())
    assert not any(chart == 1 for chart in word['start'])
    one_arrivals = [i for i,p in packets.items() if p['destination'] == 1]
    assert len(one_arrivals) == 537
    assert len(Rows(demands[i] for i,chart in enumerate(word['final']) if chart == 1).rows()) == 537
    capacities = []
    for dest, slots in zip(CHARTS, STOCK_IDS, strict=True):
        assert all(event['destination'] == 1 for event in packets.values() if event['source'] == dest)
        assert not any(chart == dest for chart in word['start'])
        assert [r for r,c in enumerate(word['final']) if c == dest] == [OWNERS[CHARTS.index(dest)]]
        returned = [i for i in one_arrivals if packets[i]['source'] == dest]
        assert len(returned) == 3
        assert max(packets[i]['clock'] for i in slots[:3]) < min(packets[i]['clock'] for i in returned)
        assert max(packets[i]['clock'] for i in returned) < packets[slots[3]]['clock']
        capacities.append(dict(chart=dest, early_incoming=slots[:3], returns_to_chart1=returned,
                               outside_chart1_arrivals=534, new_external_bits_before_returns=2,
                               chart1_observation_bits_max=536, chart1_required_bits=537))
        for slot in slots:
            assert packets[slot]['destination'] == dest
            bound = atlas.grade(packets[slot]['source'],dest)
            eligible[slot] = [chart for chart in sorted(atlas.body) if 0 < atlas.grade(chart,dest) <= bound]
    targets = [demands[i] for i in OWNERS]
    cases = [verify_case(word, packets, targets, atlas, eligible, p, a) for p in (False, True) for a in (False, True)]
    for case in cases:
        survivors = case['one_retarget_after_removing_old_payload']
        assert {x['slot'] for x in survivors} == set(STOCK_IDS[0][:3] + STOCK_IDS[1][:3])
        assert len(survivors) == 6 and all(x['new_chart'] == 1 for x in survivors)
        assert sum(x['retargets'] for x in case['tested']) == 234
    result = dict(owners=OWNERS,cases=cases,global_chart1_cuts=capacities,
                  qualification='Causal rank relaxation at these eight paid clocks only. No full literal code or kappa gain.')
    rendered = json.dumps(result, indent=2, sort_keys=True)+'\n'
    if args.emit:
        print(rendered,end='')
    else:
        assert rendered == (HERE/'INGRESS.json').read_text()
        print('PASS: all eight existing timing windows and exact priced nested grade caps checked.')


if __name__ == '__main__':
    main()
