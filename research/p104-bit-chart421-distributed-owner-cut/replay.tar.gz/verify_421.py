#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Replay the conditional chart-421 and chart-617 separations."""
from pathlib import Path
from collections import Counter
import gzip, hashlib, json, sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'prior'))
from core import *
from bit_native import schedule
import construct

def require(ok,why):
    if not ok: raise AssertionError(why)
def rank(vectors):
    b=Span()
    for x in vectors: b.add(x)
    return len(b.rows)
def span(vectors):
    b=Span()
    for x in vectors:b.add(x)
    return b
def bits(m): return list(labels(m))
def subvalues(vectors):
    values=[0]
    for x in vectors:values += [v^x for v in values]
    return values
def dot(a,b):return (a&b).bit_count()%2

# The bundled constructor verifies its original receipt and literal compressed word.
# It also independently replays both complete binary orientations and both invoices.
side_path=HERE/'prior'/'EARLY-268-RESTORED-SIDE-WORD.json.gz'
side_sha=hashlib.sha256(side_path.read_bytes()).hexdigest()
require(side_sha=='84b53c2d8c69c77f9e36b45e238f8be7dae62e6a5ebffeac45c108fe7be0e98a','side SHA')
construct.run(True)
side=json.loads(gzip.decompress(side_path.read_bytes()))
# Recreate the packet-value model while retaining the native packet identifiers.
M=dict(R);rr=dict(ROWS)
M[3410]=(421,0);rr[3410]=rr[3409];del M[3409],rr[3409];rr[789]=1<<17
for k in (785,1584,1934):
    for p,r in list(rr.items()):
        if r>>k&1:rr[p]^=1<<k
rr.update({785:1<<679,1584:1<<785,1934:1<<1584,~679:1<<1934,
           1583:(1<<17)^(1<<781),1585:(1<<1583)^(1<<813),1586:1<<1583})
M[1583]=(19,182)
initial=dict(enumerate(W['start']));final=dict(enumerate(W['final']))
order=schedule(initial,final,M,rr)
vals={i:1<<i for i in initial}
for p in order:vals[p]=xsum(vals[j] for j in labels(rr[p]))
trace=op.run_tape(side,ATLAS,False)
reverse=op.run_tape(side,ATLAS,True)
for i,p in enumerate(order):require(trace.packets[680+i].arrival.row==vals[p],f'literal packet {p}')
require(trace.output[221]==op.expected_operator(False)[221] and reverse.output[221]==op.expected_operator(True)[221],'side owner 221')
require(trace.output[679]==1<<679 and reverse.output[679]==1<<679,'side owner 679')
require(trace.output[203]!=op.expected_operator(False)[203],'side owner 203 failure')

def pre(c,p):
    return [i for i,x in enumerate(W['start']) if x==c]+[q for q in O if q in M and M[q][1]==c and CLOCK.get(q,999999)<CLOCK[p]]
def P(ids):return [vals[q] for q in ids]

# Exact original demand at the local chart, including the retiming allowance.
old=[264,789,1934,2234,2947]
oldvals=[1<<264]+[X[p] for p in old[1:]]
newvals=[vals[p] for p in old]
require(rank(oldvals)==rank(newvals)==5,'local rank')
require(ROWS[2677]==(1<<1934)^(1<<2234) and ROWS[2678]==1<<1934,'early native demands')
require(ROWS[3409]==sum(1<<p for p in (789,1934,2234,2947)),'native 3409')
require(X[3410]==(1<<17)^X[1934]^X[2234]^X[2947],'native 3410')
require(CLOCK[2669]<CLOCK[2677] and CLOCK[2674]<CLOCK[2677]<CLOCK[2947] and
        list(labels(ROWS[2947]))==[2669,2674],'2947 donor timing')
require(span(newvals).express(X[1934]) is None,'old 1934 missing')

T=op.expected_operator(False)[203];H=1<<679
Q=[17,264,2669,2674,2667,2672,3400]
A=pre(268,1934)
B=pre(318,2234)
Bextra=pre(182,1585)
require(A==[722,1360,1464,1584,1728,1824] and B==[1445,1485,1577,1585,1661,1901] and Bextra==[785,813,1583],'sender inventories')

def quotient_record(q,a,b):
    qv=P(q);base=span(qv); qrank=len(base.rows)
    require(base.add(T) and base.add(H),'independent T,H modulo Q')
    qa=span(qv+P(a));qb=span(qv+P(b));qab=span(qv+P(a)+P(b))
    tests=(T,H,T^H)
    u=[qa.express(z) is not None for z in tests]
    v=[qb.express(z) is not None for z in tests]
    union=[qab.express(z) is not None for z in tests]
    # A and B each contain at most the H line in the target plane.
    require(u==[False,True,False] and v in ([False,True,False],[False,False,False]),'intersections at most H')
    require(union==[True,True,True],'the relaxed union still spans target plane')
    return dict(base_rank=qrank,target_quotient_rank=2,a_intersection=u,b_intersection=v,union=union)

cut=quotient_record(Q,A,B+Bextra)
# A single changed existing stock source.  Grant the entire original preclock donor
# bank and the displaced stock gratis, not just one sender scalar.
cases=[]
for p in B+[2669,2674]:
    extra=pre(M[p][0],p)
    q=Q+(extra if p in (2669,2674) else [])
    b=B+(extra if p in B else [])
    cases.append(dict(packet=p,source=M[p][0],donor_stock=extra,**quotient_record(q,A,b)))

# Exact selector enumeration for the one interesting changed stock, 1585.
# 2947 is allowed to arrive before both original readers and both chart-518
# source observations are granted as one selectable scalar.
count=Counter(); fixed=[vals[p] for p in B if p!=1585]
for p1585 in subvalues(P(Bextra)):
    for p2234 in subvalues(fixed+[p1585]):
        for p2947 in subvalues(P([2669,2674])):
            upper=[1<<17,1<<264,p2234,p2947]
            bu=span(upper);bv=span(upper+P([2667,2672,3400]))
            for p1934 in subvalues(P(A)):
                count['assignments']+=1
                if bu.express(H) is None and bu.express(H^p1934) is None:continue
                count['owner679']+=1
                if bv.express(T) is None and bv.express(T^p1934) is None:continue
                count['owner679_and_203']+=1
require((count['assignments'],count['owner679'],count['owner679_and_203'])==(131072,2300,0),'exact selector counts')

# Stronger nonlinear collision for the advertised y family.  All chart-zero
# history up to 3399, both chart-518 donors, both untouched 617 receipts,
# all source-318 rows and all other 19/24 arrivals are identical on these
# two inputs.  1934 is h+X785+X813+y and y is any deterministic function of
# the recorded source-zero history, so it is also identical.  Feedback 3410
# from chart421 cannot distinguish them, even if sent before 3399; nor can
# any locally recoded 3399/3400 or 2677.  No linearity is needed in this part.
source0=pre(0,3399)
extra19=[17,679,781,782,783,784]
extra24=[22,810,811,812]
ids=source0+B+[264,2669,2674,2667,2672]+extra19+extra24
shift=sum(1<<j for j in (29,58,92,101,106,109))
require(len(source0)==532 and all(dot(vals[q],shift)==0 for q in ids),'feedback collision stocks')
require(dot(X[785],shift)==dot(X[813],shift)==0 and dot(T,shift)==1,'feedback collision target')
require(dot(X[1934],shift)==1,'missing old 1934 distinguishes pair')
require(dot(T,shift^(1<<92))==0,'corrupted target witness is rejected')
feedback_rank=rank(P(ids))
require(feedback_rank==545,'feedback union rank')

# Owner 221: if the other three terminal stocks remain fixed, changing 3408
# by delta permits local linear decoding iff delta is in their span.
S=[2876,2882,2885];ss=span(P(S));target221=op.expected_operator(False)[221]
require(len(ss.rows)==3 and ss.express(target221) is None,'owner 221 other stocks')
# Use an explicitly tagged basis to establish the unique original decoder.
bs=Span()
for p in S+[3408]:bs.add(vals[p],1<<p)
require(bits(bs.express(target221))==S+[3408],'unique owner 221 decoder')
require(ss.express(vals[3410]) is None,'feedback perturbation outside other stock')
rr2=dict(rr);rr2[3407]^=1<<3410
order2=schedule(initial,final,M,rr2)
v2={i:1<<i for i in initial}
for p in order2:v2[p]=xsum(v2[j] for j in labels(rr2[p]))
require(order2.index(3410)<order2.index(3407)<order2.index(3408),'causal retiming')
require(all(v2[p]==vals[p] for p in S) and v2[3408]==vals[3408]^vals[3410],'feedback control')
require(span([v2[p] for p in S+[3408]]).express(target221) is None,'owner 221 control not locally decodable')

_,caller,_,_,helpers,paid,productive,rational=prices.baseline();rate=prices.D('0.00388')
side_margin=prices.plus(prices.moment(paid,productive,rate),price((5,1,2),(6,1)))
extra_margin=prices.plus(side_margin,price((),(1,)))
require(extra_margin[0]>0,'grade-1 nominal price')
result=dict(
 source_native_gzip_sha256=op.WORD_GZIP,source_side_gzip_sha256=side_sha,
 literal_packets_compared=len(order),native_forward_and_adjoint_controls=True,
 local_chart421=dict(original_rank=5,side_rank=5,original_arrivals=old,old_1934_absent_in_side=True,
  native_2677=[1934,2234],native_2678=[1934],native_3410='e17+X1934+X2234+X2947',
  native_clocks={str(p):CLOCK[p] for p in (2669,2674,2677,2678,2947)},
  donor_2947_retimable_before_2677_in_causal_stock_relaxation=True),
 simultaneous_owner203_679=dict(Q=Q,source1934=A,source2234=B,extra_source1585=Bextra,
  **cut,one_changed_existing_source=cases,selectors={k:count[k] for k in ('assignments','owner679','owner679_and_203')}),
 early_feedback_collision=dict(family_1934='h+X785+X813+y',source0_before_3399_count=len(source0),
  freely_granted_bank_rank=feedback_rank,input_shift=bits(shift),target=[92,203],old_X1934_changes=True,
  permits_early_3410_and_mutable_3399_3400_2677=True),
 owner221=dict(target=[110,221],fixed_other_stocks=S,other_rank=3,original_decoder=S+[3408],
  criterion='delta3408 in span(2876,2882,2885)',unretimed_side_correct_both_orientations=True,
  retimed_3410_into_3407_control_unrecoverable=True),
 nominal_binary_margin_00388=prices.display(side_margin),nominal_binary_margin_one_extra_grade1=prices.display(extra_margin),
 creates_valid_supplier=False,new_qualified_kappa=False)
raw=json.dumps(result,sort_keys=True,indent=2)+'\n'
p=HERE/'RESULT-421.json'
if '--freeze' in sys.argv:p.write_text(raw)
else:require(p.read_text()==raw,'frozen RESULT-421.json')
print('421/617 and owner221 replay passed; result matches' if '--freeze' not in sys.argv else '421/617 and owner221 result frozen')
