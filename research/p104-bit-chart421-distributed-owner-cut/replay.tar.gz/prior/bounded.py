from core import *
from itertools import product
def go():
 d=Direction(False);owners=set(d.owners);early785=ROWS[785]^(1<<679)
 graph={p:xy for p,xy in R.items() if p!=3409};graph[3410]=(421,0)
 base={p:v for p,v in ROWS.items() if p!=3409};base[3410]=ROWS[3409];base[785]=early785;base[789]=1<<17
 st=defaultdict(list)
 for i,c in enumerate(d.start):st[c].append(i)
 for p in d.order:
  if p in graph:st[graph[p][1]].append(p)
 clocks=d.rank
 pre=lambda c,k:[v for v in st[c] if v in owners or clocks[v]<clocks[k]]
 B182=pre(182,1584);B268=pre(268,1931);B348=pre(348,2470)
 assert len(B182)==3 and len(B268)==6 and len(B348)==3
 ct=Counter();details=[]
 for c182 in range(8):
  donors=[v for i,v in enumerate(B182) if c182>>i&1]
  if 785 not in donors:continue
  row=dict(base);row[1584]=sum(1<<p for p in donors)
  v={i:1<<i for i in owners};form={i:0 for i in owners}
  for p in d.order:
   if p==3409:continue
   if p in (1932,1934,2470):
    v[p]=0;form[p]=1<<(1932,1934,2470).index(p);continue
   v[p]=xsum(v[j] for j in labels(row[p]));form[p]=xsum(form[j] for j in labels(row[p]))
  vals=[xsum(v[p] for i,p in enumerate(B268) if z>>i&1) for z in range(64)]
  status={}
  for b2,b4 in product((0,1),repeat=2):
   for b7 in (0,1):
    m=b2|(b4<<1)|(b7<<2)
    leaks=[p for p in st[1] if (v[p]>>679&1)^((form[p]&m).bit_count()%2)]
    status[m]=leaks
  ownok=0;no_leak=0;both=0;first=Counter();always=sorted(set.intersection(*(set(z) for z in status.values())))
  for a,b in product(range(64),repeat=2):
   v2,v4=vals[a],vals[b];env=[0,v2,v4,v2^v4]
   target=Span()
   for p in st[421]:
    assert form[p]<4;target.add(v[p]^env[form[p]])
   own=target.express(1<<679) is not None;ownok+=8*own
   o348=[v[p]^env[form[p]] for p in B348]
   hmask=[(z>>679)&1 for z in o348]
   for jj in range(8):
    m=(v2>>679&1)|((v4>>679&1)<<1)|(sum(z for n,z in enumerate(hmask) if jj>>n&1)%2<<2)
    ok=not status[m];no_leak+=ok;both+=ok and own
    if own and not ok:first[status[m][0]]+=1
  details.append(dict(early_1584_donors=donors,total=32768,owner_679=ownok,saturated_1_h_free=no_leak,both=both,always_leaking_chart1_sources=always,first_chart1_leak_if_679_survives=first))
  ct['total']+=32768;ct['owner_679']+=ownok;ct['saturated_1_h_free']+=no_leak;ct['both']+=both
 print(ct,details,flush=True);write('EARLY-268-OLD-COMPONENT.json',dict(source_rows=dict(chart182=B182,chart268=B268,chart348=B348),counts=ct,detail=details))
if __name__=='__main__':go()
