from core import *
import bit_native
def run(side=False):
    M=dict(R);rows=dict(ROWS);M[3410]=(421,0);rows[3410]=ROWS[3409];del M[3409],rows[3409];rows[789]=1<<17
    local={785:1<<679,1584:1<<785,1934:1<<1584}
    orphan={}
    for p in (785,1584,1934):
        old=1<<p
        out=[k for k,r in rows.items() if r&old and k not in local]
        for k in out:rows[k]&=~old
        orphan[p]=out
    rows.update(local);rows[~679]=1<<1934
    if side:
        M[1583]=(19,182);rows[1583]=(1<<17)^(1<<781)
        rows[1585]=(1<<1583)^(1<<813);rows[1586]=1<<1583
    M0=dict(enumerate(W['start']));F=dict(enumerate(W['final']));seq=bit_native.schedule(M0,F,M,rows)
    vals={i:1<<i for i in M0};st=defaultdict(list)
    for i,c in M0.items():st[c].append(i)
    for p in seq:vals[p]=xsum(vals[j] for j in labels(rows[p]));st[M[p][1]].append(p)
    assert vals[785]==vals[1584]==vals[1934]==1<<679
    if side:
        assert vals[1583]==X[785] and vals[1585]==X[1585] and vals[1586]==X[1586]
        other_549=[p for p in seq if vals[p]>>549&1]
        assert other_549
    B={}
    for c,ps in st.items():
        ss=Span()
        for p in ps:ss.add(vals[p],1<<p)
        B[c]=ss
    miss=[];corrected=[];targets=op.expected_operator(False)
    for i,c in F.items():
        v=B[c].express(targets[i])
        if v is None:miss.append(i);continue
        if xsum(vals[j] for j in labels(rows[~i]))!=targets[i]:corrected.append(i)
        rows[~i]=v
    assert 679 not in miss and all(not(vals[p]>>679&1) for p in st[1])
    word=bit_native.emit_word(W,M0,F,M,rows,seq);at=op.Atlas(word['frames']);tr=[op.run_tape(word,at,r) for r in (False,True)]
    bad=[[i for i,(v,w) in enumerate(zip(t.output,op.expected_operator(r))) if v!=w] for r,t in enumerate(tr)]
    assert bad[0]==miss and tr[0].output[679]==tr[1].output[679]==1<<679
    name='EARLY-268-RESTORED-SIDE' if side else 'EARLY-268-ESCAPE';dest=HERE9/(name+'-WORD.json.gz');raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode()
    if '--write' in sys.argv:dest.write_bytes(gzip.compress(raw,mtime=0))
    else:assert gzip.decompress(dest.read_bytes())==raw
    _,caller,_,_,helpers,P,T,rat=prices.baseline();rate=prices.D('0.00388')
    d=price([5,1,2],[6,1]) if side else price([5,1],[6]);m=prices.plus(prices.moment(P,T,rate),d)
    res=dict(other_549_count=len(other_549) if side else None,first_other_549=other_549[:12] if side else [],side_restored=side,terminal_549=d0 if (d0:=F[549]) else 0,paid_rows_1585_1586_exact=side,word=op.canonical_hash(word),sha=hashlib.sha256(dest.read_bytes()).hexdigest(),paid_route=[785,1584,1934],changed_old_payloads={str(p):list(labels(X[p])) for p in (785,1584,1934)},cleared_old_references=orphan,arbitrary_forward_terminal_banks_missing=len(miss),bad=bad,fully_recovered_by_redecoding=corrected,owner679_both=True,chart1_fresh_coefficient_zero=True,dirty=[t.dirty for t in tr],hypothetical_margin=list(map(str,m)))
    res.update(public_owners=len(M0), operator_valid_by_orientation=[not failures for failures in bad], actual_move_grade_histogram=dict(Counter(v.grade for v in tr[0].packets.values())), positive_price_and_both_operators_valid=bool(m[0]>0 and not any(bad)), chart1_observations=len(st[1]), first_785_side_readers_correct=[vals[k]==X[k] for k in (1585,1586)], chart268_four_old_exits_correct=[vals[k]==X[k] for k in (1931,1932,1935,1936)])
    paid, productive = prices.literal.paired_invoice(caller, Counter(v.grade for v in tr[0].packets.values()), helpers, Counter(event[0] for event in caller['events']))
    assert productive == T and min(m[1], prices.moment(paid, productive, rate)[1]) >= max(m[0], prices.moment(paid, productive, rate)[0])
    q = rat['signed']
    rational = prices.moment({int(k):v for k,v in q['paid'].items()}, {int(k):v for k,v in q['productive'].items()}, rate)
    res.update(charged_binary_paid=dict(paid), charged_binary_productive=dict(productive), actual_binary_36_margin=prices.display(prices.moment(paid, productive, rate)), unchanged_rational_48_margin=prices.display(rational))
    write(name+'.json',res);print(res['sha'],len(bad[0]),len(bad[1]),miss[:15],corrected[:10],m[0],orphan)
if __name__=='__main__':run('--side' in sys.argv)
