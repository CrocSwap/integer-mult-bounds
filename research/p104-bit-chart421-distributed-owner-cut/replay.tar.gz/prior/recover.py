# SPDX-License-Identifier: Apache-2.0
from core import *
DIMS = {c: len(v) for c, v in ATLAS.body.items()}
leg = ATLAS.grade
def run():
 d=Direction(False);M=dict(R);rr=dict(ROWS);M[3410]=(421,0);rr[3410]=rr[3409];del rr[3409],M[3409]
 rr[789]=1<<17
 for k in [785,1584,1934]:
  for p,r in rr.items():
   if r>>k&1:rr[p]^=1<<k
 rr.update({785:1<<679,1584:1<<785,1934:1<<1584,~679:1<<1934,1583:(1<<17)^(1<<781),1585:(1<<1583)^(1<<813),1586:1<<1583});M[1583]=(19,182)
 vals={i:1<<i for i in d.owners}
 for p in O:
  if p in M:vals[p]=xsum(vals[i] for i in labels(rr[p]))
 out={}
 for b,cut,target in [(182,1584,1<<549),(268,1931,X[1584])]:
  bank=defaultdict(list)
  for i,c in enumerate(d.start):bank[c].append(i)
  for p in O:
   if p==cut:break
   if p in M:bank[M[p][1]].append(p)
  orig=bank[b]
  oldstocks=[vals[p] for p in orig]
  using=[c for c,ids in bank.items() if any((vals[p]>>549)&1 for p in ids)]
  scenarios=[];counts=Counter();bundle=[]
  if b==268:assert vals[1464]==X[1464] and 1464 in orig
  for old in [None]+[p for p in orig if p in M and p not in (785,1584,1934,1583)]:
   for S in DIMS:
    g=leg(S,b)
    if not g:continue
    for extra in (False,True):
     if extra and (old is None or leg(0,S)!=1):continue
     oldhist=[5,1,2]+([G[old]] if old is not None else [])
     news=[6,1,g]+([1] if extra else [])
     if price(tuple(oldhist),tuple(news))[0]<=prices.D('0.02771136020'):continue
     # Honest upper: even the possibly displaced receipt remains at B and
     # all source ancestors retain their original values for free. For an
     # additional 0-to-line receipt grant that line all chart-zero stock.
     base=Span()
     ids=list(orig)+bank[S]+(bank[0] if extra else [])
     for p in ids:base.add(vals[p],1<<p)
     rep=base.express(target);counts['tested']+=1
     if b==268 and old==1464:
      lost=[p for p in orig if p!=1464];strict=Span()
      joint=lost+bank[S]+(bank[0] if extra else [])
      for p in joint:strict.add(vals[p],1<<p)
      CplusD=X[1464]^X[1584]
      counts['explicit_1464_bundle_tests']+=1
      assert (base.express(CplusD) is None)==(rep is None)
      got=strict.express(CplusD)
      if got is not None:bundle.append((S,g,extra,list(labels(got))))
     if rep is not None:scenarios.append((old,S,g,extra,list(labels(rep))));counts['optimistic_span']+=1
  out[b]=dict(cutoff=cut,clock=CLOCK[cut],preclock_original_549_sources=using,grade1_neighbors=[S for S in DIMS if leg(S,b)==1],counts=counts,candidates=scenarios,bundle_1464=bundle)
  if b==182:
   ss=Span();[ss.add(vals[p]) for p in orig if p!=813];assert ss.add(X[813]) and ss.add(1<<549)
   out[b]['rank_deficit_after_sacrificing_813']=2
 write('EARLY-549-RETARGET.json',out);print([(b,v['counts'],v['candidates'][:5],v['preclock_original_549_sources']) for b,v in out.items()],flush=True)
if __name__=='__main__':run()
