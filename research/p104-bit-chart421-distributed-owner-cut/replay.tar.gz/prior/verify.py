#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import bounded
import construct
import recover
bounded.go();construct.run(False);construct.run(True);recover.run()
