# Chart 421 terminal-basis and early-feedback tests

This is a bounded negative result. It does not produce a valid primitive, supplier, or new κ value. The tested literal parent is the independently reconstructed side-restored word from the preceding chart-268 study, whose 36-call binary margin at κ = 0.00388 is approximately +36.1548121757 before repairing its incorrect operator. One additional grade-1 charge would leave approximately +0.1548121757 on that hypothetical invoice. The parent still has 89 incorrect forward outputs and 29 incorrect adjoint outputs; its functional emitter has dirty private retirements. Positive nominal margin is not an application.

The bundle pins the native #7830 gzip `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9` and the stronger side-restored word gzip `84b53c2d8c69c77f9e36b45e238f8be7dae62e6a5ebffeac45c108fe7be0e98a`. The included parent constructor rebuilds and byte-compares the latter and checks its complete operators and invoices. This supplement independently aligns every emitted packet with its original identifier and reconstructs all local stocks from those packets.

## Chart 421

Write `U=X1934`, `V=X2234`, `K=X2947`, and `h=e679` for values in the native word. Before the native `2677` and `2678`, the chart has `e264`, `789=h`, `1934=U`, and `2234=V`; the two sends carry `U+V` and `U`. Receipt 2947 later brings `K`; the two-hop native feedback eventually delivers `e17+U+V+K` to chart 0. The five final native stocks have rank five.

In the side-restored word, 789 instead carries `e17` and 1934 carries `h`, while 2234 and 2947 still carry `V` and `K`. The local rank is still five, but `U` is absent from that span. Native packet 2947 was recorded after 2677 and 2678, but its native sender rows 2669 and 2674 both exist earlier. The tests below grant both sender values free and early, so the conclusion does not rely on the recorded position of 2947.

## Two-sender quotient cut

The public output at chart 617 is `T=e92+e203`; chart 421 must return `h`. Grant both charts the common stock `Q = span(e17,e264,2669,2674,2667,2672,3400)` and allow arbitrary local linear decoding. Also grant sender 2234 all original chart-318 stock and all three preclock source rows of 1585, retaining the displaced row for free. The source of 1934 has all six of its original preclock chart-268 rows. These are optimistic grants: real packets 1934 and 2234 carry only one scalar each.

`T` and `h` have rank two modulo `Q`. Each of the two enlarged source spaces intersects their two-dimensional target plane only in the line spanned by `h`; their union can span both targets. Two scalar sends cannot span the target plane: were they to do so, each sent residue would itself lie in that plane, and neither can supply its missing `T` direction. This is a per-chart quotient obstruction, not a loss of total word rank. It allows free recoding of 1934, 2234, 2677, 2678 and 3410 and allows 2947 to be earlier, while fixing the other chart-617 inputs and the indicated sender-source histories.

The same test covers eight separate one-stock changes: the six existing arrivals of chart 318 and the two arrivals of chart 518. In each case it grants the changed packet's **entire** preclock donor bank and keeps its old receipt free. All eight still fail. All changes retain their existing paid incidence in this screen; no extra grade-2 charge is assumed. An independent enumeration of 131,072 actual source-selector combinations for the interesting 1585 change yields 2,300 that return `h` and zero that return both `h` and output 203. The quotient proof is stronger than this enumeration within its stated fixed-stock contract.

## Arbitrary 0→19 payload and earlier feedback

A separately proposed grade-1 0→19 contact sends an arbitrary source-zero value `y` to chart 19. Its named 1934 family carries

`h + X785 + X813 + y`,

where the old `X785=e17+e266+e267` and `X813=e22+e276`. The proposed concrete case uses `y=e549`; this case returns `h` at chart 421 but does not restore output 203.

A stronger explicit collision applies to **any** `y` computed from the available source-zero bank, not just `e549`. Compare zero input to the input with owners `29, 58, 92, 101, 106, 109` set to one. The verifier checks that all 532 fixed chart-0 observations available before old 3399, all six chart-318 sender rows, both chart-518 sender rows, 617's receipts 2667 and 2672, all relevant original chart-19 and chart-24 stocks, and `e264` are identical on the two inputs. Consequently `y` and the named 1934 value are identical too. The old `X1934` distinguishes the pair, and the required output `e92+e203` changes.

Thus, with the stated outside receipts fixed, the two inputs remain indistinguishable at chart 617 even if 789, 2234, 2947 and 2677 are recoded, 3410 is sent before 3399, and 3399/3400 are recomputed from their available stocks. The argument permits arbitrary deterministic processing of the granted stock; it is not restricted to XOR decoding. Changed outside producers or changed 1934 payload formulas escape this collision and require a new check.

## Owner 221

The side-restored parent is correct for owner 221 in both orientations. At its forward terminal chart 635, fixed receipts 2876, 2882, and 2885 have rank three, and receipt 3408 completes the unique decoder for `e110+e221`. If the other three stay fixed and the 3408 value changes by `δ`, a local linear decoder succeeds **if and only if** `δ` is in their span. A causal control retimes 3410 before 3407 and XORs the feedback into 3407; the resulting `δ` is outside that span, so owner 221 becomes unrecoverable. This is a diagnostic control with the other stocks fixed, not a complete changed candidate.

## Reproduce

Python 3.11+ and standard-library modules suffice:

```sh
sha256sum -c SHA256SUMS
(cd prior && sha256sum -c SHA256SUMS)
python3 -I -B verify_421.py
```

The verifier checks the pinned input and parent reconstruction, both literal orientations, every packet alignment, the quotient calculations, all eight one-source cases, the 131,072-selector enumeration, the early-feedback collision including a corrupted-witness control, the owner-221 retiming control, and the nominal binary price. Its deterministic output must match `RESULT-421.json` exactly; default verification never rewrites the receipt. `prior/` retains the source's own license and notices. The source provenance and limitations of the parent are in `prior/README.md` and `prior/source/SOURCES.json`.
