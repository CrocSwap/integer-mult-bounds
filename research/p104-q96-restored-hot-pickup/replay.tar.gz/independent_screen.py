#!/usr/bin/env python3
"""Recompute the census with 512-bit subspace masks, independently of eng.py."""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import product
import json
from pathlib import Path
import check

L,G,X,C4=check.load();C0=[[Fraction(v,4) for v in row] for row in C4]
W=[row[:] for row in X]+[[int(t==1) for t in range(96)],[int(t==5) for t in range(96)]]
for i,a,b in ((0,1,1),(1,1,-1)):W[i][1]+=a;W[i][5]+=b
C=C0+[[-a-b for a,b in zip(C0[0],C0[1])],[-a+b for a,b in zip(C0[0],C0[1])]]
chains=[[0,8],[1,9]]+[[i] for i in range(2,8)]; whole=(1<<512)-1

def dim(mask):
    size=mask.bit_count();assert size and size & (size-1)==0
    return size.bit_length()-1

def elements(mask):
    while mask:
        bit=mask & -mask
        yield bit.bit_length()-1
        mask^=bit

def span_join(mask,vec):
    if (mask>>vec)&1:return mask
    return mask | sum(1<<(a^vec) for a in elements(mask))

@lru_cache(maxsize=None)
def out(mask,support):
    for t in support:mask=span_join(mask,L[t])
    return mask

def support(v):return tuple(i for i,x in enumerate(v) if x)

@lru_cache(maxsize=None)
def orth(s):
    return sum(1<<v for v in range(512) if all(((v & L[t]).bit_count()&1)==0 for t in s))

qperp=[orth((t,)) for t in range(96)]
e={};control=0
for life,ch in enumerate(chains):
    prev=whole;u=[Fraction(0) for _ in L]
    for pos,i in enumerate(ch):
        w=[x-y for x,y in zip(W[i],W[ch[pos+1]])] if pos+1<len(ch) else W[i][:]
        a=prev & orth(support(C[i]));b=out(a,support(w));u=[x+y for x,y in zip(u,C[i])]
        cost=dim(b)-dim(a);control+=cost
        e[i]={'life':life,'pos':pos,'prev':prev,'a':a,'b':b,'w':w,'c':C[i],'u':u[:],'cost':cost}
        prev=b
assert control==58
assert orth(support(C[8]))==orth(support(C[9]))==1

hist=Counter();optim=Counter();pickup=Counter();bad=0;trials=0;legal=[];pairs=set();strata=0
for i,j in product(range(10),repeat=2):
    a,b=e[i],e[j]
    if a['life']==b['life']:continue
    pairs.add((i,j))
    exceptional={x/y for x,y in zip(b['c'],a['u']) if x and y}; generic=Fraction(1)
    while generic in exceptional:generic+=1
    for h in sorted(exceptional)+[generic]:
        strata+=1
        d=[x-h*y for x,y in zip(b['c'],a['u'])]
        old_source=[e[k] for k in chains[a['life']][:a['pos']+1]]
        old_target=[e[k] for k in chains[b['life']][:b['pos']]]
        for s in range(96):
            trials+=1
            aa=a['b'] & b['prev'] & orth(support(d)) & qperp[s]
            cost=58+dim(out(aa,support(b['w'])))-dim(aa)-b['cost']
            # A successor is necessarily row 8 or 9. Its cold chart is zero,
            # so the baseline successor's rise is unchanged.
            optim[cost]+=1
            if any(z['c'][s] and z['a'] & ~a['b'] for z in old_source+old_target):
                bad+=1;continue
            hist[cost]+=1;pickup[dim(aa)]+=1;legal.append([i,j,str(h),s,cost])

result=json.loads((Path(__file__).resolve().parent/'RESULT.json').read_text())
assert len(pairs)==86 and strata==294 and trials==28224 and bad==6258
assert dict(hist)=={int(k):v for k,v in result['R_histogram'].items()}
assert dict(optim)=={int(k):v for k,v in result['optimistic_ignore_prior_carrier_chart_R_histogram'].items()}
assert dict(pickup)=={int(k):v for k,v in result['pickup_dimension_histogram'].items()}
assert legal==result['legal_records']
print('Independent 512-bit subspace replay matches all 21,966 legal records, 6,258 conflicts and 28,224 optimistic prices.')
