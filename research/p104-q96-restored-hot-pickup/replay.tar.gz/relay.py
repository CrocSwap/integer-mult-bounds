#!/usr/bin/env python3
"""One restored Y_s carrier between epochs of the fixed #7922 R58 chain.

The source epoch's original output chart is frozen.  The taker's intake chart
is the largest subspace of it that is cold for c_j - h*U_i, belongs to q_s^perp,
and fits the taker's preceding chart.  All other charts use the source's
minimal chart rule.  Every h support stratum and every physical Y_s is tested.
"""
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from pathlib import Path
import hashlib,json,sys
import check
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source/7869'))
import eng

raw=(ROOT/'source/7869/eng.py').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='900b41f42c978e2bca2db001a5dc81dc93953adb5e842a4924d37c860124c2f6'
L,Gram,X,C4=check.load(); C0=[[Q(v,4) for v in row] for row in C4]
W=[r[:] for r in X]+[[int(t==1) for t in range(96)],[int(t==5) for t in range(96)]]
for i,a,b in [(0,1,1),(1,1,-1)]: W[i][1]+=a;W[i][5]+=b
C=C0+[[-a-b for a,b in zip(C0[0],C0[1])],[-a+b for a,b in zip(C0[0],C0[1])]]
chains=[[0,8],[1,9]]+[[i] for i in range(2,8)]
assert all(sum(W[k][t]*C[k][s] for k in range(10))==-Q(Gram[t][s],2) for t in range(96) for s in range(96))
assert (check.qrank(W),check.qrank(C))==(10,8)
perps=[eng.perp([v],9) for v in L]

@lru_cache(maxsize=None)
def _cold(support): return eng.perp([L[t] for t in support],9)
def cold(c): return _cold(tuple(t for t,x in enumerate(c) if x))
@lru_cache(maxsize=None)
def _outspace(a,support): return eng.span(list(a)+[L[t] for t in support])
def outspace(a,w): return _outspace(a,tuple(t for t,x in enumerate(w) if x))
def dim(a): return eng.fdim(a)
def vector_sub(a,h,b): return [x-h*y for x,y in zip(a,b)]
def vals(a,b): return [x+y for x,y in zip(a,b)]

# Freeze complete original control charts. Each entry carries exact phase
# intake/output, and the source value accumulated through that phase.
eps={}; original_cost=0
for li,ch in enumerate(chains):
    prior=None;cum=[Q(0) for _ in L]
    for pos,row in enumerate(ch):
        w=vector_sub(W[row],1,W[ch[pos+1]]) if pos+1<len(ch) else W[row][:]
        a=cold(C[row]); a=a if prior is None else a & prior
        b=outspace(a,w); cum=vals(cum,C[row]); cost=dim(b)-dim(a);original_cost+=cost
        eps[row]={'life':li,'pos':pos,'w':w,'c':C[row],'a':a,'b':b,'u':cum[:],'cost':cost,'prev_b':prior}
        prior=b
assert original_cost==58 and [eps[x]['cost'] for ch in chains for x in ch]==[7,1,7,1,7,7,7,7,7,7]
assert (check.qrank([eps[i]['w'] for i in range(10)]),check.qrank([eps[i]['u'] for i in range(10)]))==(10,8)
# Every continuation after an epoch in these two nontrivial lifetimes has
# fresh-intake chart zero, even when its previous chart is enlarged.
assert all(cold(C[i])==frozenset([0]) for i in (8,9))

def candidates(c,u):
    # Exceptional coefficients of c-h*u.  One generic nonzero rational
    # represents all remaining nonzero real h, for chart/support purposes.
    ex={x/y for x,y in zip(c,u) if x and y}
    gen=Q(1)
    while gen in ex:gen+=1
    return sorted(ex)+[gen]

def prefix_inputs(row, inclusive):
    e=eps[row]; ch=chains[e['life']]; n=e['pos']+int(inclusive)
    return [(eps[k]['a'],eps[k]['c']) for k in ch[:n]]

def solve(src,tak,h,s,allow_uncharted=False,source_chart=None):
    p=eps[src];q=eps[tak];assert p['life']!=q['life'] and h
    source_chart=p['b'] if source_chart is None else source_chart
    assert p['b']<=source_chart
    rise=dim(source_chart)-dim(p['b'])
    d=vector_sub(q['c'],h,p['u'])
    # Ys' existing chart comes from every source prefix intake and every
    # pre-relay taker prefix intake.  Source and taker precede all other lives.
    old=[a for a,c in prefix_inputs(src,True)+prefix_inputs(tak,False) if c[s]]
    compatible=all(a<=source_chart for a in old)
    if not compatible and not allow_uncharted:return None
    a=source_chart & cold(d) & perps[s]
    if q['prev_b'] is not None:a=a & q['prev_b']
    assert a<=source_chart and all(not eng.dot(v,L[s]) for v in a)
    b=outspace(a,q['w']); delta=rise+dim(b)-dim(a)-q['cost']
    continuation=[]
    for row in chains[q['life']][q['pos']+1:]:
        z=eps[row]; a2=b & cold(z['c']); b=outspace(a2,z['w'])
        cost=dim(b)-dim(a2);delta+=cost-z['cost'];continuation.append((row,dim(a2),dim(b),cost))
    return {'R':58+delta,'a':a,'d':d,'new_cost':dim(outspace(a,q['w']))-dim(a), 'continuation':continuation,'old_carrier_charts':old,'source_extra_rise':rise}

def serial_result():
    count=Counter(); optimistic=Counter(); pickup=Counter(); bypair={}; legal=0; tested=0; nochart=0; examples={}; minrow=None; rows=[]
    for src,tak in product(range(10),repeat=2):
        if eps[src]['life']==eps[tak]['life']:continue
        best=None; pairs=0; passcount=0
        for h in candidates(eps[tak]['c'],eps[src]['u']):
            for s in range(96):
                tested+=1;pairs+=1
                hopeful=solve(src,tak,h,s,allow_uncharted=True);optimistic[hopeful['R']]+=1
                z=solve(src,tak,h,s)
                if z is None:nochart+=1;continue
                legal+=1;passcount+=1;r=z['R'];count[r]+=1;pickup[dim(z['a'])]+=1
                if best is None or r<best:best=r
                example={'source':src,'taker':tak,'h':str(h),'carrier':s,'carrier_label':L[s],'R':r,
                         'input_dim':dim(z['a']),'cold_support':sum(bool(v) for v in z['d']),
                         'taker_epoch_cost':z['new_cost'],'continuation':z['continuation']}
                examples.setdefault(str(r),example)
                if minrow is None or r<minrow['R']:minrow=example
                rows.append([src,tak,str(h),s,r])
        bypair[f'{src}->{tak}']={'tested':pairs,'legal':passcount,'min_R':best}
    return {'sources':list(range(10)),'takers':list(range(10)),'distinct_lifetime_ordered_pairs':len(bypair),
            'coefficient_rule':'all nonzero exact coordinate cancellation ratios plus one generic nonzero representative',
            'physical_carrier_port_indices':list(range(96)),'tested':tested,'cochart_failures':nochart,
            'cocharted':legal,'R_histogram':dict(sorted(count.items())),
            'optimistic_ignore_prior_carrier_chart_R_histogram':dict(sorted(optimistic.items())),
            'pickup_dimension_histogram':dict(sorted(pickup.items())), 'by_pair':bypair,'examples_by_R':examples,
            'minimum_example':minrow,'legal_records':[list(v) for v in rows]}

def full_replay(src=None,tak=None,h=None,s=None,broken=False,source_chart=None):
    # Source prefix; taker previous epochs; taker intake; carrier event;
    # cleanup; taker tail; source tail; all other lives.  This sequence
    # keeps the source value frozen until Ys is cleaned.
    R=eng.Run(9,L,eng.Field(0)); states={}; traces=[]; phases=[]
    def start(li,at):
        oid=('O',li)
        if li not in states:R.INIT(oid,at);states[li]=True
        else:R.MOVE(oid,at)
        return oid
    def inputs(oid,a,c):
        for v,coef in enumerate(c):
            if coef:
                y=('Y',v);R.MOVE(y,eng.span(list(R.reg[y][0])+list(a)));R.ADD(oid,coef,y)
    def output(oid,w):
        a=R.reg[oid][0];b=outspace(a,w);R.MOVE(oid,b)
        for t,v in enumerate(w):
            if v:R.ADD(('X',t),v,oid)
    def normal(row):
        z=eps[row]; before=R.cost; oid=start(z['life'],z['a']);inputs(oid,z['a'],z['c']);output(oid,z['w']);
        phases.append([row,R.cost-before]);assert R.reg[oid][0]==z['b']
    if src is None:
        for li,ch in enumerate(chains):
            for row in ch:normal(row)
            R.CLEAR(('O',li))
    else:
        z=solve(src,tak,h,s,source_chart=source_chart);assert z is not None
        se,te=eps[src],eps[tak];ls,lt=se['life'],te['life']
        for row in chains[ls][:se['pos']+1]:normal(row)
        if source_chart is not None:R.MOVE(('O',ls),source_chart)
        for row in chains[lt][:te['pos']]:normal(row)
        before=R.cost;oid=start(lt,z['a']);inputs(oid,z['a'],z['d'])
        # Existing source Ys charts and pickup chart must fit the source.
        y=('Y',s);R.MOVE(y,eng.span(list(R.reg[y][0])+list(z['a'])))
        so=('O',ls);assert R.reg[y][0]<=R.reg[so][0]
        R.ADD(y,1,so);R.ADD(oid,h,y);R.ADD(y,-1,so)
        if not broken:R.ADD(oid,-h,y)
        output(oid,te['w']);phases.append([tak,R.cost-before])
        prior=R.reg[oid][0]
        for row in chains[lt][te['pos']+1:]:
            e=eps[row];a=prior & cold(e['c']);before=R.cost
            start(lt,a);inputs(oid,a,e['c']);output(oid,e['w']);prior=R.reg[oid][0];phases.append([row,R.cost-before])
        R.CLEAR(oid)
        for row in chains[ls][se['pos']+1:]:normal(row)
        R.CLEAR(so)
        for li,ch in enumerate(chains):
            if li in (ls,lt):continue
            for row in ch:normal(row)
            R.CLEAR(('O',li))
        assert R.cost==z['R']
        assert sum(cost for _,cost in phases)+z['source_extra_rise']==R.cost
    got=R.rec();badcells=[(t,u) for t in range(96) for u in range(96) if got[t][u]!=-Q(Gram[t][u],2)]
    oddbad=[(t,u) for t,u in badcells if check.dot(L[t],L[u])]
    result={'R':R.cost,'operations':len(R.ops),'bad':R.bad,'pinning_errors':R.pinned(),
            'full_bad_cells':len(badcells),'odd_bad_cells':len(oddbad),'phase_costs':phases}
    if src is None: assert not R.bad and not R.pinned() and not badcells and R.cost==58
    elif not broken:
        assert not R.bad and not R.pinned() and not badcells
        # One hot link and all same-register links. Its complete relay cross
        # is h * W_taker * U_source^T.  Compute the full G(I-H)^-1 F
        # expansion independently rather than calling the complement GF.
        tail=W[tak];u=eps[src]['u'];fresh=eps[src]['c']; w=eps[tak]['w']
        total=[[h*tail[t]*u[v] for v in range(96)] for t in range(96)]
        immediate=[[h*w[t]*fresh[v] for v in range(96)] for t in range(96)]
        higher=[[total[t][v]-immediate[t][v] for v in range(96)] for t in range(96)]
        F={i:eps[i]['c'][:] for i in range(10)};F[tak]=z['d'][:]
        edges={i:[] for i in range(10)}
        for ch in chains:
            for a,b in zip(ch,ch[1:]):edges[b].append((a,Q(1)))
        edges[tak].append((src,h))
        power=F; terms=[]; matrices=[]
        while any(any(row) for row in power.values()):
            mat=[[sum(eps[i]['w'][t]*power[i][v] for i in range(10)) for v in range(96)] for t in range(96)]
            matrices.append(mat)
            terms.append(mat)
            power={i:[sum(coef*power[parent][v] for parent,coef in edges[i]) for v in range(96)] for i in range(10)}
            assert len(terms)<=10, 'non-nilpotent relay graph'
        assert all(sum(mat[t][v] for mat in terms)==got[t][v] for t in range(96) for v in range(96))
        def stats(mat):return {'nonzero':sum(bool(x) for row in mat for x in row),
                               'odd_nonzero':sum(bool(mat[t][v]) for t in range(96) for v in range(96) if check.dot(L[t],L[v]))}
        result['hot_edge_GHF_immediate']=stats(immediate)
        result['hot_edge_higher_order_paths']=stats(higher)
        result['hot_all_same_register_paths']=stats(total)
        result['full_GF_GHF_higher_terms']=[stats(m) for m in matrices]
        result['full_G_I_minus_H_inverse_F_exact']=True
        result['cold_input_factor_rank_Q']=check.qrank(list(F.values()))
        result['hot_coefficient']=str(h);result['source']=src;result['taker']=tak;result['carrier']=s
        result['carrier_label']=L[s];result['pickup_dim']=dim(z['a'])
        result['source_extra_rise']=z['source_extra_rise']
        result['carrier_restored']=R.reg[y][1]=={('y',s):Q(1)}
        assert result['carrier_restored'] and result['hot_all_same_register_paths']['nonzero']
    else:
        assert all(got[t][v]+Q(Gram[t][v],2)==(h*W[tak][t] if v==s else 0)
                   for t in range(96) for v in range(96))
        assert badcells
    return result

def main():
    data=serial_result(); x=data['minimum_example'];h=Q(x['h']);src=x['source'];tak=x['taker'];s=x['carrier']
    data['baseline_replay']=full_replay();data['minimum_replay']=full_replay(src,tak,h,s)
    # A second minimum uses the entire source value for the taker's fresh
    # intake: U_8 = -V_1, c_1 = V_1, and the pickup has dimension one.
    data['one_dimensional_hot_witness']=full_replay(8,1,Q(-1),6)
    data['omit_carrier_token_cancel_control']=full_replay(8,1,Q(-1),6,True)
    # This port fails the frozen-chart cochart test; one extra source rise
    # admits it, and the engine verifies the resulting R=59 run.
    assert solve(0,9,Q(-2),0) is None
    data['extra_source_rise_control']=full_replay(0,9,Q(-2),0,source_chart=frozenset(range(512)))
    assert data['one_dimensional_hot_witness']['R']==data['minimum_example']['R']==58
    assert data['extra_source_rise_control']['R']==59
    assert min(map(int,data['optimistic_ignore_prior_carrier_chart_R_histogram']))==58
    print(json.dumps(data,indent=2,sort_keys=True))
if __name__=='__main__':main()
