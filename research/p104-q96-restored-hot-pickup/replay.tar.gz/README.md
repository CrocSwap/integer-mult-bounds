# One restored Y-port relay on the Q96 R=58 chain

The exact minimum in the insertion family below is **R = 58**. It includes one genuine hot update of a public Y port followed by an owned intake in a different lifetime. The fixed baseline is the actual rational rank-(10,8), ten-epoch, eight-lifetime run of [#7922](https://github.com/CrocSwap/integer-mult-bounds/pull/7922) at `93b34c8b786229777f1dd5becb0ec3d5f7627f32`. A full run through the unmodified [#7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869) engine at `06c207a9feb3994a4b987dc3010657b6e85b7956` attains R = 58 with a one-dimensional hot pickup, all 9,216 entries equal to `−G/2`, all odd cells correct, zero bad operations, and no pinning errors. It has no κ gain.

The result is a **local obstruction**, not a Q96 hosted-rise theorem or an exhaustive search of legal words. We keep the #7922 factors, signed output increments, lifetime partition and the pre-pickup source and target histories. We allow every nonzero real coefficient for one compensated hot transfer, every source and taker epoch in different lifetimes, every named Q96 Y port, every subchart at pickup, and arbitrary nested enlargement of the source's selected output chart. All other lifetimes retain the baseline construction. The source's selected output is made before the pickup, the source stays unchanged until the port is cleaned, and the port is read once hot plus once after cleaning to cancel its own original value. A different factorization, changing earlier histories or source output increments, multiple transfers, a helper carrier, or other public paths is outside this result. The rank-(8,8) hosted-rise result in the pinned `carrier8.md` does not apply to this rank-(10,8) factorization; here we replay and price the stated insertion directly.

## Exact insertion and enumeration

Use #7922's ports `p=1,q=5`, and ordered Abel-row lifetimes

```
(0,8), (1,9), (2), (3), (4), (5), (6), (7).
```

Write `w_i` for the actual signed output increment of epoch i, `c_i` for its fresh intake, `W_i` for the Abel tail (the sum of the remaining increments in its lifetime), and `U_i` for its accumulated source value through epoch i. The ten baseline prices in the displayed order are `7,1,7,1,7,7,7,7,7,7`. For a source epoch i and a taker j in a different lifetime, and nonzero scalar h, replace only the taker's direct fresh intake by

```
d_j = c_j − h U_i.
```

After the source has output at its chart `B`, gather `d_j` in the taker at chart `A`, write the still-live `U_i` into `Y_s`, read `h Y_s` into the taker, undo the Y update, and read `−h Y_s` into the taker. The last read cancels the Y port's original value. The taker therefore receives exactly `d_j + h U_i = c_j`; the source remains live for cleaning before its next intake. `Y_s` remains in `q_s⊥`, and both the source's and taker's required chart inclusions are checked. This is one public hot write and one hot pickup, with cleanup and token cancellation; it is not a free independent copy.

For source output chart `B`, define `T` as the intersection of the taker's previous output chart, the perpendicular of the labels in `supp(d_j)`, and `q_s⊥`; omit the first factor for a first epoch. The maximal possible pickup chart is `A = B ∩ T`. The pinned model's public Y charts are monotone. Consequently the prior charts of the selected `Y_s`, built by all source prefix and taker prefix cold reads before the hot write, must also be contained in `B` for this frozen-chart insertion. The program checks those inclusions per named port and constructs the exact ordered run for representative cases. It counts every owned rise once.

There are 86 ordered source/taker pairs in distinct lifetimes. For each pair the nonzero h at which a coordinate of `c_j − h U_i` vanishes are exact rational ratios; every other nonzero real h has the same support. These are **294 support strata across the 86 pairs**. Testing all 96 ports produces 28,224 cases:

| Test at the baseline source chart | Cases | Replayed cost or lower-bound price |
|---|---:|---:|
| Prior Y chart cochart check passes | 2,952 | 58 |
| Prior Y chart cochart check passes | 19,014 | 59 |
| Prior Y chart is not contained in the source chart | 6,258 | excluded from this frozen-chart construction |

The passing canonical constructions use pickup dimension zero in 21,945 cases and dimension one in 21 cases. `RESULT.json` contains all passing `(source,taker,h,port,R)` tuples and a per-pair census; each h value in a generic stratum is a representative of its entire nonzero-real support class. In the deliberately optimistic screen which **ignores all prior carrier-chart conflicts**, there are 6,284 cases of price 58 and 21,940 of price 59. This screen is a lower-bound calculation and does not assert those incompatible cases are legal at the original chart.

### Allowing an enlarged source chart

Let `B₀` be the baseline selected source output chart and let the source enlarge it to any `B₁ ⊇ B₀` before the pickup, paying at least `k = dim B₁ − dim B₀` ascents. The maximally usable taker charts satisfy `A₀ = B₀ ∩ T ⊆ A₁ = B₁ ∩ T` and `dim A₁ − dim A₀ ≤ k`. For any fixed output-label space L, its required ascent

```
drop(A,L) = dim(A+L) − dim A
```

can decrease by at most `dim A₁ − dim A₀`. The possible later epochs of these source and taker lifetimes are rows 8 and 9, whose fresh-intake cold charts are both exactly `{0}`. Thus their subsequent costs do not decrease when the earlier output chart is enlarged. The added source rise can therefore save no more than itself. Since even the optimistic frozen-chart screen has minimum 58, **all nested source enlargements in this insertion schedule have R ≥ 58**, including enlargements needed to make an initially incompatible Y chart cocharted. The engine control source 0 → taker 9 via Y_0 enlarges the source by one dimension, becomes legal and has R=59. This dimension argument does not allow changing the fixed pre-pickup histories or insertions outside the stated schedule.

## Concrete hot witness and cross-term check

Take source row 8, taker row 1, carrier Y_6 (label 21), and `h=−1`. The source first gathers V₀, performs row 0, gathers `−V₀−V₁`, and performs row 8. Its actual current value is `U₈=−V₁` and its output chart is `span(19)`. The taker's original fresh intake is `c₁=V₁`, so `d₁ = 0`. The Y_6 label 21 pairs evenly with label 19, making the one-dimensional pickup chart `span(19)` a legal Y_6 chart. After the hot pickup, carrier cleanup and token cancellation, the taker has exactly V₁. The ascent charges are again `7,1,7,1,7,7,7,7,7,7`: the fresh intake is shared, but the taker's seven-dimensional rise remains.

The engine executes 1,346 operations, has zero illegal operations and pinning errors, restores Y_6, and verifies the entire `−G/2` matrix and every odd cell. The output and total intake factor ranks remain `(10,8)`, and the modified cold intake factor rank is 8. Omitting the final token-cancellation read is an intentionally invalid **receipt** control: legality and pinning checks alone still pass, but 44 full-matrix cells, including 23 odd cells, are wrong.

The code separately constructs the causal epoch network, with same-lifetime edges `0→8` and `1→9` and hot edge `8→1` of coefficient −1, and expands `G(I−H)⁻¹F` as `GF + GHF + GH²F + GH³F`. Exact equality with the engine's 9,216-entry receipt is checked. The **immediate hot-edge portion** of GHF has 2,880 nonzero cells, 1,565 odd; all paths using that hot edge together contribute `h W₁ U₈ᵀ`, with 2,156 nonzero cells, 1,172 odd. Higher same-lifetime paths contribute the difference; their cell counts overlap, so the counts are not additive. The compensated cold term is included in the full expansion. These are causal epoch factors for this construction, not a claim that raw causal factors equal FutureAttr lifetime attribution.

## Provenance and replay

* `source/pr7922-replay.tar.gz` was read at #7922's pinned commit. Its SHA-256 is `511e8695c085cfeb5f9e3cac2edd6bfe7cd860475558b9ee42fe2c69953fd673`, the value in that commit's `SOURCES.json`. `verify.py` checks the copied `check.py`, `data.json`, engine, Lean data, and parent note byte-for-byte against the archive.
* `source/7869/eng.py` is the unmodified pinned engine, SHA-256 `900b41f42c978e2bca2db001a5dc81dc93953adb5e842a4924d37c860124c2f6`. `source/pr7869-carrier8.md` is the prior hosted-rise discussion, SHA-256 `96824d25bfe833e5d7777f9bac92a1718f167b698ea79add3796bfde4db24a7f`.
* The original Apache-2.0 license and source notices are preserved. The source archive and manifest are consistency checks, not signatures of a publisher.

Run with Python 3.10+ and the standard library, from any current directory:

```
python3 -B /path/to/verify.py
```

The verifier checks the packet manifest and source archive identities, reconstructs all 28,224 support/port cases, reproduces the full engine runs, checks the odd and full receipts and the causal cross-term expansion, and compares regenerated evidence against `RESULT.json`. A separate 512-bit subspace implementation recomputes every individual cochart and price record without importing the engine or the main relay search.
