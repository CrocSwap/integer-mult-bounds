#!/usr/bin/env python3
"""Reconstruct the finite support census and compare all pinned evidence."""
import hashlib,json,subprocess,sys,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()

def main():
    manifest={}
    for line in (P/'SHA256SUMS').read_text().splitlines():
        h,sep,name=line.partition('  ');p=Path(name)
        if not sep or len(h)!=64 or p.is_absolute() or '..' in p.parts or name in manifest:
            raise ValueError('invalid manifest entry')
        manifest[name]=h
    files={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file() and p!=P/'SHA256SUMS'}
    if files!=set(manifest):raise ValueError('packet file set differs')
    for n,h in manifest.items():
        p=P/n
        if p.is_symlink() or sha(p.read_bytes())!=h:raise ValueError('file hash mismatch: '+n)
    arc=P/'source/pr7922-replay.tar.gz'
    assert sha(arc.read_bytes())=='511e8695c085cfeb5f9e3cac2edd6bfe7cd860475558b9ee42fe2c69953fd673'
    copies={'check.py':'./check.py','data.json':'./data.json',
            'source/7852/DecoderWall4Data.lean':'./source/7852/DecoderWall4Data.lean',
            'source/7869/eng.py':'./source/7869/eng.py','source/round4-parent-19.md':'./README.md'}
    with tarfile.open(arc,'r:gz') as t:
        for here,there in copies.items():
            f=t.extractfile(there)
            if f is None or f.read()!=(P/here).read_bytes():raise ValueError('source archive mismatch: '+here)
    assert sha((P/'source/pr7869-carrier8.md').read_bytes())=='96824d25bfe833e5d7777f9bac92a1718f167b698ea79add3796bfde4db24a7f'
    p=subprocess.run([sys.executable,'-B',str(P/'relay.py')],cwd=P,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:raise RuntimeError('relay.py failed: '+p.stderr)
    r=json.loads(p.stdout);e=json.loads((P/'RESULT.json').read_text())
    if r!=e:raise ValueError('regenerated result differs')
    assert (r['tested'],r['cocharted'],r['cochart_failures'])==(28224,21966,6258)
    assert r['R_histogram']=={'58':2952,'59':19014}
    assert r['optimistic_ignore_prior_carrier_chart_R_histogram']=={'58':6284,'59':21940}
    assert r['one_dimensional_hot_witness']['R']==58
    assert r['extra_source_rise_control']['R']==59
    other=subprocess.run([sys.executable,'-B',str(P/'independent_screen.py')],cwd=P,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if other.returncode:raise RuntimeError('independent_screen.py failed: '+other.stderr)
    print('Verified %d manifest files and the authenticated #7922 source archive.'%len(manifest))
    print('Recomputed 28,224 source/taker/coefficient/port cases; cocharted R histogram: 58=2,952, 59=19,014.')
    print('Optimistic omitted-chart floor = 58; both continuations have zero-dimensional cold charts.')
    print('Replayed R=58 genuine hot witness, R=59 charged enlargement, and 23-odd-cell negative control.')
    print('Full −G/2 and G(I−H)^−1F verified on all 9,216 cells.')
    print(other.stdout.strip())
if __name__=='__main__':
    try:main()
    except (ValueError,AssertionError,RuntimeError,KeyError,OSError,json.JSONDecodeError) as e:
        print('Verification failed: '+str(e),file=sys.stderr);sys.exit(1)
