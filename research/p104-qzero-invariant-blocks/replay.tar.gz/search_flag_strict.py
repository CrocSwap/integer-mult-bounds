#!/usr/bin/env python3
"""Bounded exploratory search for a 1D-flag strict-support separator.

This is not a negative completeness claim.  Each candidate is a conjugated
1+1+2 upper-triangular family; stages choose a triangular frame on the last
two coordinates.  Its role supports come from exact integer cofactors.
"""
import itertools
import random

rng=random.Random(79160)

def det3(a):
    return a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])-a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])+a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0])

def adj(a):
    cof=[[(-1)**(i+j)*det3([[a[x][y] for y in range(4) if y!=j] for x in range(4) if x!=i]) for j in range(4)] for i in range(4)]
    determinant=sum(a[0][i]*cof[0][i] for i in range(4))
    return determinant, list(map(list,zip(*cof)))

def choices(A,inv,t):
    # Supports of T E00 T^-1, T E11 T^-1, then the complementary
    # triangular rank-one projectors E22+tE23 and E33-tE23.
    dom=[]
    dom.append([r for r in range(4) if A[r][0]*inv[0][r]])
    dom.append([r for r in range(4) if A[r][1]*inv[1][r]])
    dom.append([r for r in range(4) if A[r][2]*(inv[2][r]+t*inv[3][r])])
    dom.append([r for r in range(4) if (A[r][3]-t*A[r][2])*inv[3][r]])
    return {(a,b) for a in dom[0] for b in dom[1] if a!=b
            for c in dom[2] for d in dom[3] if len({a,b,c,d})==4}

def main():
    for trial in range(100000):
        A=[[rng.choice([0,0,-1,1,2]) for _ in range(4)] for _ in range(4)]
        d,inv=adj(A)
        if not d: continue
        opts=[(t,choices(A,inv,t)) for t in (-3,-2,-1,0,1,2,3)]
        for subset in itertools.combinations(opts,2):
            if all(z[1] for z in subset) and not set.intersection(*(z[1] for z in subset)):
                print('FOUND trial',trial,'T=',A,'det=',d,'parameters',[z[0] for z in subset],
                      'stage choices',[sorted(z[1]) for z in subset],flush=True)
                return
    print('No example found in 100000 seeded candidates (bounded search only).',flush=True)

if __name__=='__main__': main()
