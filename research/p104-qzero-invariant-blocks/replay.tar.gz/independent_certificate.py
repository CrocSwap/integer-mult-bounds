#!/usr/bin/env python3
"""Independently replay modular algebra certificates and strict separator.

This script does not import the #7903 capture/matching code or algebra_check.
It reconstructs each prefix from source events and inverts it from scratch.
"""
import itertools
import json
from fractions import Fraction
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parent
P=1000000007

def f(x):
    q=Fraction(x)
    return q.numerator*pow(q.denominator%P,-1,P)%P

def eye(n): return [[int(i==j) for j in range(n)] for i in range(n)]

def matmul(A,B):
    n=len(A)
    return [[sum(A[i][k]*B[k][j] for k in range(n))%P for j in range(n)] for i in range(n)]

def inverse(A):
    n=len(A); R=[a[:]+b[:] for a,b in zip(A,eye(n))]
    for j in range(n):
        pivot=next(i for i in range(j,n) if R[i][j]%P)
        R[j],R[pivot]=R[pivot],R[j]
        c=pow(R[j][j],-1,P);R[j]=[x*c%P for x in R[j]]
        for i in range(n):
            if i!=j:
                c=R[i][j];R[i]=[(x-c*y)%P for x,y in zip(R[i],R[j])]
    assert [r[:n] for r in R]==eye(n)
    return [r[n:] for r in R]

def projectors_mod(C):
    n=C['roles'];prefix=eye(n); out=[];keys=[]
    def inc(j,kind,reg):
        inv=inverse(prefix)
        out.append([[inv[i][reg]*prefix[reg][h]%P for h in range(n)] for i in range(n)])
        keys.append(f'{j}:{kind}')
    for j,e in enumerate(C['events']):
        if e[0]=='ADD':
            a,b,c=e[1],e[2],f(e[3]);prefix[a]=[(x+c*y)%P for x,y in zip(prefix[a],prefix[b])]
        elif e[0]=='SCALE': prefix[e[1]]=[f(e[2])*x%P for x in prefix[e[1]]]
        elif e[0]=='LAMBDA': pass
        elif e[0]=='IDLE_ONE': inc(j,'idle',e[1])
        elif e[0]=='HOST':
            _,t,a,b,x,y=e;x,y=f(x),f(y);aa,bb=prefix[a][:],prefix[b][:]
            prefix[a]=[(u+x*v)%P for u,v in zip(aa,bb)]
            prefix[b]=[(y*u+(1+x*y)*v)%P for u,v in zip(aa,bb)]
            inc(j,'host_first',a);inc(j,'host_second',b)
        else: raise ValueError(e)
    assert prefix==eye(n)
    return out,keys

def rank_mod(rows):
    A=[r[:] for r in rows];nr=len(A);nc=len(A[0]);r=0
    for c in range(nc):
        ids=[i for i in range(r,nr) if A[i][c]%P]
        if not ids:continue
        a=ids[0];A[a],A[r]=A[r],A[a]
        iv=pow(A[r][c],-1,P); A[r]=[z*iv%P for z in A[r]]
        for i in range(r+1,nr):
            d=A[i][c];A[i]=[(x-d*y)%P for x,y in zip(A[i],A[r])]
        r+=1
        if r==nr: break
    return r

def verify_algebra():
    for result in json.loads((ROOT/'algebra_results.json').read_text()):
        name=result['name'];C=json.loads((ROOT/'source/data/q0_callers'/f'{name}.json').read_text())
        n=C['roles'];ps,keys=projectors_mod(C); vectors=[]
        for word,wordkeys in zip(result['event_indices'],result['words']):
            assert [keys[i] for i in word]==wordkeys
            w=eye(n)
            for i in word: w=matmul(w,ps[i])
            vectors.append([x for row in w for x in row])
        rank=rank_mod(vectors)
        assert rank==len(vectors)==n*n
        print('PASS independent modular full-algebra certificate',name,rank,'/',n*n)

def verify_strict():
    C=json.loads((ROOT/'flag_strict_word.json').read_text()); n=C['roles']; P0=s.eye(n); ev=[]
    T=s.Matrix([[1,0,-1,-1],[1,0,-1,1],[0,0,-1,0],[1,-1,0,0]])
    for j,e in enumerate(C['events']):
        if e[0]=='ADD': P0[e[1],:]=P0[e[1],:]+s.Rational(e[3])*P0[e[2],:]
        elif e[0]=='SCALE': P0[e[1],:]=s.Rational(e[2])*P0[e[1],:]
        elif e[0]=='IDLE_ONE':
            i=e[1];inv=P0.inv(); p=inv[:,i]*P0[i,:]
            ev.append({'key':j,'mask':tuple(e[2]),'p':p,
                       'domain':{r for r in range(n) if inv[r,i]!=0 and P0[i,r]!=0}})
        else: raise ValueError(e)
    assert P0==s.eye(n) and len(ev)==10
    tri=[T.inv()*e['p']*T for e in ev]
    assert all(all(x==0 for x in p.lower_triangular(-1)) for p in tri)
    assert ev[0]['p']*ev[6]['p']!=ev[6]['p']*ev[0]['p']
    choices={}
    for t in (1,2,3):
        es=[e for e in ev if t in e['mask']]
        good=[p for p in itertools.permutations(range(n)) if all(p[i] in es[i]['domain'] for i in range(n))]
        assert good
        if t in (1,2): choices[t]={(p[0],p[1]) for p in good}
    assert choices=={1:{(1,3)},2:{(0,3)}}
    print('PASS independent exact flag, noncentral pair, local strict matchings and global strict obstruction')

if __name__=='__main__':
    verify_algebra(); verify_strict()
