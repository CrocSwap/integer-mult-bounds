#!/usr/bin/env python3
"""Verify bundle hashes and independently regenerate evidence in a temp dir."""
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def main():
    for line in (ROOT/'MANIFEST.sha256').read_text().splitlines():
        expected,name=line.split('  ',1)
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,name
    generated=['flag_word.json','one_2d_word.json','two_2d_host_word.json',
               'example_results.json','flag_strict_word.json','flag_strict_result.json',
               'algebra_results.json']
    with tempfile.TemporaryDirectory(prefix='q0-flag-verify-') as path:
        work=Path(path)/'bundle'
        shutil.copytree(ROOT,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
        env.pop('P104_ATTRIBUTION_SOURCE',None);env.pop('P104_GUIDANCE_SOURCE',None)
        for script in ['examples.py','flag_strict_separator.py','algebra_check.py',
                       'independent_certificate.py','search_flag_strict.py']:
            subprocess.run([sys.executable,script],cwd=work,env=env,check=True)
        for name in generated:
            assert (work/name).read_bytes()==(ROOT/name).read_bytes(),name
    print('PASS manifest and byte-identical regeneration of all seven outputs')

if __name__=='__main__':main()
