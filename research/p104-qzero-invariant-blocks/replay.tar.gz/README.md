# Q0 attribution via invariant flags and two-dimensional quotients

Research note, 2026-11-21. Inputs are #7903 at `f791c24514071c0c1e8454beffd51e9fb51854cd` and the #7869 caller examples at `06c207a9feb3994a4b987dc3010657b6e85b7956`. The results below concern global event-to-role attribution, not a new bound. Role and source-event indices are zero-based; stages are one-based.

## The mask-only theorem

For each nonempty incidence event `e`, let `S_e` be its set of stages and let `p_e` be its rank-one idempotent at `q=1,D=1`, as in #7903. In particular, each HOST contributes two singleton incidence events immediately after the host's base transformation. A mask-only global attribution assigns each event to one role such that the stage sets assigned to each role are disjoint and partition that role's squarefree target mask.

**Theorem.** Suppose there is a common invariant flag

`0 = W_0 ⊂ W_1 ⊂ ... ⊂ W_m = K^n`

for all incidence projectors `p_e`, over a characteristic-zero field extension `K`, and every quotient `W_j/W_{j-1}` has dimension one or two. Then a global mask-only attribution exists. The projectors need not commute. In particular the claim holds whenever there is a complete flag of one-dimensional quotients, and for any single two-dimensional caller block even when its projectors are absolutely irreducible.

**Proof.** At `q=1`, factor the base prefixes out of the ordered word. The endpoint is

`F(D) = ordered_product_e ((I - p_e) + D^{S_e} p_e) = diag(D^{M_r})`.

The product is in the word-induced order, which need not be commuting. The `p_e` induced on each quotient are idempotents. Their traces are nonnegative integers; the sum of those traces is `tr(p_e)=1`. Therefore each event acts by a rank-one projector on exactly one quotient, and by zero on every other quotient. Let `E_j` be the events belonging to quotient `j`.

The flag makes `F` block triangular. Its characteristic polynomial equals the product of the characteristic polynomials of its quotient actions. Since the endpoint is diagonal, uniqueness of the linear factors over `K(D)` assigns exactly `dim(W_j/W_{j-1})` endpoint monomials to each quotient, preserving multiplicity. These monomials correspond to actual role masks.

If quotient `j` is one-dimensional, its event projectors act as `1`, so the quotient endpoint is `D^{sum_{e in E_j} S_e}`. Its single assigned endpoint monomial therefore equals this product. Since the endpoint mask is squarefree, these event masks are disjoint and partition it. This is the complete one-dimensional flag argument: the unique `1` on each triangularized projector's diagonal assigns the event to a graded quotient, and the endpoint's diagonal eigenvalues match the quotients to roles.

If quotient `j` has dimension two, write its two endpoint monomials as `D^A` and `D^B`, allowing `A=B`. Expand its ordered product using `(I-p_e)+D^{S_e}p_e`. Its trace is a polynomial supported on monomials `D^{sum_{e in U} S_e}` for subsets `U ⊆ E_j`, with coefficients in `K`. The coefficient of `D^A` on the endpoint side is `1` if `A≠B` and `2` if `A=B`; in characteristic zero it is nonzero. Thus some subset `U` satisfies `sum_{e in U} S_e=A`. Meanwhile `det((I-p_e)+D^{S_e}p_e)=D^{S_e}` for each rank-one idempotent on this quotient, so determinants give `sum_{e in E_j} S_e=A+B`. The complementary subset has sum `B`. Squarefreeness makes each subset a disjoint partition of its mask. This trace-and-determinant argument applies even when the quotient is irreducible and has no invariant line.

For each quotient, choose the actual role or pair of roles matching the corresponding endpoint monomials. These choices are disjoint as a multiset, and the partitions above give the desired global mask-only attribution. □

The trace identifies a subset even when different subsets give the same monomial: cancellation cannot erase a target monomial whose coefficient is nonzero. The argument does **not** require the events selected in a two-dimensional quotient to be supported on the corresponding endpoint role. The general mask-only question remains open when some irreducible quotient has dimension at least three.

## Exact words demonstrating the scope

All four generated words have been replayed both by the bundled #7869 four-root symbolic-D checker and by a separate SymPy event implementation. The event words use only the declared source operations. Full witnesses and counts are in `example_results.json` and `flag_strict_result.json`.

* `flag_word.json` has `n=2,k=4`, the standard common one-dimensional flag, noncommuting multi-stage and singleton projectors, and unequal endpoint masks `{1,2,3,4}` and `{1,2,3}`. Both mask-only and strict witnesses exist. It has no HOST and even q-targets.
* `one_2d_word.json` has the same masks but a **sole absolutely irreducible two-dimensional block**. In its standard basis, one multi-event projector is `p=[[1,0],[0,0]]` and a stage-3 projector is `q=[[2,2],[-1,-1]]`. Their commutator is `[[0,2],[1,0]]`, and `I,p,q,pq` span `M_2(Q)`, so there is no common invariant line even over an extension. An exact partition assigns the first multi-event `{1,2}`, the first stage-3 singleton, and the stage-4 singleton to role 0; the complementary two events go to role 1. Strict and mask-only witnesses both exist. This example has no HOST and even q-targets.
* `two_2d_host_word.json` has two invariant irreducible two-dimensional blocks, four ordered type-B HOSTs, nonzero HOST K-block determinants `8,-4,8,-4`, odd q-targets, Q=0, and degree four for every role. Its multi-event projectors fail to commute with HOST incidence projectors. Both strict and mask-only witnesses exist. It is **not tight**: `n+2=6 < 2k=8`.
* `flag_strict_word.json` is the full-flag strict separator detailed below. It has `n+2=2k`, but even q-targets and no HOST, so it is not a full tight-RC2 caller.

These noncommuting multi-event examples are outside the hypothesis of #7903's central-multi-projector theorem. The present result supplies another sufficient condition; no inclusion in the opposite direction is claimed.

## A strict separator with a complete one-dimensional flag

`flag_strict_word.json` is a literal q-free legal word, not just a list of candidate supports. It has `n=4,k=3`, four target masks `{1,2,3}`, and a common rational flag whose ordered basis columns form

```
T = [[1,  0, -1, -1],
     [1,  0, -1,  1],
     [0,  0, -1,  0],
     [1, -1,  0,  0]],     det(T) = -2.
```

All `T^-1 p_e T` are upper triangular. Multi-event `13:idle` does not commute with singleton `24:idle`; their exact nonzero commutator is recorded in `flag_strict_result.json`. The strict role domain is the set of roles where both the inverse-prefix column and prefix row are nonzero:

| Event | Mask | Strict eligible roles |
|---|---|---|
| 13 | `{1,2}` | `{0,1}` |
| 14 | `{1,2}` | `{3}` |
| 16 | `{1}` | `{0,1,2}` |
| 17 | `{1}` | `{0}` |
| 20 | `{2}` | `{0,1,2}` |
| 21 | `{2}` | `{1}` |
| 24 | `{3}` | `{0,1,3}` |
| 25 | `{3}` | `{0,1,3}` |
| 26 | `{3}` | `{2}` |
| 27 | `{3}` | `{0,1}` |

In stage 1, event 17 forces role 0, forcing the ordered multi-event roles `(1,3)`. In stage 2, event 21 forces role 1, forcing `(0,3)`. Each stage has its own strict matching, but these pairs are disjoint, so no global strict attribution exists. For stage 3 one strict matching is `(0,3,2,1)` for events `(24,25,26,27)`. Global mask-only attribution does exist, and the complete witness is in the result file. The exact cofactor search leading to this fixed example is reproducible with `search_flag_strict.py`.

Although this word meets the numerical equality `n+2=2k` and all masks have degree at least two, its q-targets are even and it has no HOSTs. It does not refute strict attribution under the full odd-target, type-B HOST, tight RC2 hypotheses. Conversely, the theorem guarantees mask-only attribution under its flag condition without asserting strict support.

## The pinned real controls are not small-block cases

For `caller_C1`, `ml_k4`, and `ml_k5`, exact arithmetic over the prime field with modulus `1,000,000,007` gives ranks respectively `16/16`, `36/36`, and `64/64` for explicit products of the rational incidence projectors. No source denominator vanishes modulo this prime. These independent matrix words therefore span the full rational matrix algebra. Any common invariant subspace over any field extension would be invariant under this full algebra, which is impossible. Consequently all three control families are absolutely irreducible and have no common flag with quotient dimensions at most two.

`algebra_results.json` records each product as a list of event indices and names. `independent_certificate.py` reads those fixed products, reconstructs the prefixes directly from the input event words, inverts each prefix afresh modulo the prime, and independently checks their full rank. It also recomputes the strict separator's projectors and support matchings over exact rationals without importing the #7903 capture or solver code. This is a positive irreducibility certificate, not an inference from a failed search. These controls still have mask-only and strict witnesses by #7903; their irreducibility only shows the sufficient theorem above does not explain them.

## Reproduction and provenance

Run with Python 3 and SymPy (tested with 1.12), on one CPU:

```
python3 verify.py
```

This checks `MANIFEST.sha256`, replays all proofs and examples in a temporary copy, and requires byte-identical regeneration of each output. The individual commands are:

```
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 examples.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 flag_strict_separator.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 algebra_check.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 independent_certificate.py
python3 search_flag_strict.py
```

The pinned #7869 source files are copied unchanged under `source/`. The #7903 `attribution.py` is copied unchanged. `algebra_check.py`, `examples.py`, `flag_strict_separator.py`, `independent_certificate.py`, `search_flag_strict.py`, and the generated words and results are new. `LICENSE` and `UPSTREAM-NOTICE.md` are copied from the #7903 bundle. Four-q replay proves the polynomial endpoint identity modulo `q^4-1`; it does not independently establish additional caller restrictions not checked by the scripts.
