#!/usr/bin/env python3
"""Build a literal full-flag, stagewise/global strict separator.

Everything is exact rational arithmetic.  The T and shears were found by the
bounded cofactor search and are now fixed: this script does not search.
"""
import itertools
import json
from pathlib import Path
from fractions import Fraction as F
import sympy as s
import attribution as at
from examples import replay_independent

ROOT=Path(__file__).resolve().parent
T=s.Matrix([[1,0,-1,-1],[1,0,-1,1],[0,0,-1,0],[1,-1,0,0]])

def row_program(M):
    # Exact elementary row reduction from M to I; invert it to build M from I.
    X=M.copy(); n=X.rows; reduce=[]
    def add(i,j,c):
        X[i,:]=X[i,:]+c*X[j,:]; reduce.append(['ADD',i,j,str(c)])
    def scale(i,c):
        X[i,:]=c*X[i,:]; reduce.append(['SCALE',i,str(c)])
    for i in range(n):
        if X[i,i]==0:
            j=next(j for j in range(i+1,n) if X[j,i]!=0)
            add(i,j,s.Integer(1))
        scale(i,1/X[i,i])
        for j in range(n):
            if i!=j and X[j,i]!=0: add(j,i,-X[j,i])
    assert X==s.eye(n)
    out=[]
    for e in reduce[::-1]:
        if e[0]=='ADD': out.append(['ADD',e[1],e[2],str(-s.Rational(e[3]))])
        else: out.append(['SCALE',e[1],str(1/s.Rational(e[2]))])
    return out

def inverse_program(events):
    out=[]
    for e in events[::-1]:
        if e[0]=='ADD': out.append(['ADD',e[1],e[2],str(-s.Rational(e[3]))])
        else: out.append(['SCALE',e[1],str(1/s.Rational(e[2]))])
    return out

def word():
    base=row_program(T.inv())
    events=base+[['IDLE_ONE',0,[1,2]],['IDLE_ONE',1,[1,2]]]
    for stage,param in ((1,-1),(2,1)):
        events += [['ADD',2,3,str(param)],['IDLE_ONE',2,[stage]],
                   ['IDLE_ONE',3,[stage]],['ADD',2,3,str(-param)]]
    events += [['ADD',0,1,'1']]+[['IDLE_ONE',j,[3]] for j in range(4)]+[['ADD',0,1,'-1']]
    events += inverse_program(base)
    return {'schema':'exact Q0 full-flag strict attribution separator','roles':4,'stages':3,
            'events':events,'diagonal':[[0,0,1,1,1] for _ in range(4)]}

def main():
    C=word(); masks,ev=at.capture(C); ps=[s.Matrix(x['v'])*s.Matrix([x['w']]) for x in ev]
    assert at.q0check.legal(C)==(True,True)
    replay_independent(C)
    assert all(all(x==0 for x in (T.inv()*p*T).lower_triangular(-1)) for p in ps)
    assert ps[0]*ps[6]!=ps[6]*ps[0] # multi event 0, stage-3 singleton 0
    stage_pairs={}
    for t in (1,2):
        ids=[i for i,e in enumerate(ev) if t in e['S']]
        dom=[[r for r in range(4) if ev[i]['v'][r] and ev[i]['w'][r]] for i in ids]
        matches=[assignment for assignment in itertools.permutations(range(4))
                 if all(assignment[j] in dom[j] for j in range(4))]
        stage_pairs[str(t)]=sorted({(m[0],m[1]) for m in matches})
    assert stage_pairs=={'1':[(1,3)],'2':[(0,3)]}
    results={}
    for strict in (False,True):
        _,_,locals_,stats,witness=at.solve(ev,masks,3,strict)
        assert all(v is not None for v in locals_.values())
        assert (witness is None)==strict
        results['strict' if strict else 'mask_only']={'all_stages_match':True,
            'global':witness is not None,'stats':stats}
        if witness is not None:
            results['mask_only']['witness']=[{'event':e['key'],'stages':sorted(e['S']),'role':witness[i]}
                                              for i,e in enumerate(ev)]
    out={'basis_T':[[int(x) for x in row] for row in T.tolist()],'det_T':str(T.det()),'strict_ordered_multi_choices':stage_pairs,
         'multi_noncentral_pair':[ev[0]['key'],ev[6]['key']],
         'multi_and_stage3_commutator':[[str(x) for x in row] for row in (ps[0]*ps[6]-ps[6]*ps[0]).tolist()],
         'four_q_legal':True,'independent_sympy_replay':True,'results':results,
         'boundary':'n+2=2k but q targets even and no HOSTs; this is not the tight RC2 branch'}
    for name,data in (('flag_strict_word.json',C),('flag_strict_result.json',out)):
        (ROOT/name).write_text(json.dumps(data,indent=2)+'\n')
    print('PASS 4q replay; simultaneous rational 1D flag; noncentral multi;')
    print('strict stage 1 multi choices',stage_pairs['1'],'stage 2',stage_pairs['2'])
    print('PASS every stage strict-matches, global strict fails, mask-only succeeds')
    print('Boundary: n+2=2k, even q targets, no HOSTs')

if __name__=='__main__': main()
