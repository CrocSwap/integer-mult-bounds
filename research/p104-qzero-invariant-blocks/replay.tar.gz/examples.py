#!/usr/bin/env python3
"""Generate and validate flag and irreducible-block caller examples."""
import json
import os
import sys
from fractions import Fraction as F
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parent
SRC=Path(os.environ.get('P104_ATTRIBUTION_SOURCE',str(ROOT)))
os.environ.setdefault('P104_GUIDANCE_SOURCE',str(SRC/'source'))
sys.path.insert(0,str(SRC))
import attribution as at

def example_words():
    flag={
        'schema':'q0 invariant 1D flag example', 'roles':2,'stages':4,
        'events':[['IDLE_ONE',0,[1,2]],['IDLE_ONE',1,[1,2]],
                  ['ADD',0,1,'1'],['IDLE_ONE',0,[3]],['IDLE_ONE',1,[3]],
                  ['ADD',0,1,'-1'],['IDLE_ONE',0,[4]]],
        'diagonal':[[0,0,1,1,1,1],[0,0,1,1,1,0]]}
    block={
        'schema':'q0 sole absolutely irreducible 2D block example','roles':2,'stages':4,
        'events':[['IDLE_ONE',0,[1,2]],['IDLE_ONE',1,[1,2]],
                  ['ADD',0,1,'1'],['ADD',1,0,'1'],
                  ['IDLE_ONE',0,[3]],['IDLE_ONE',1,[3]],
                  ['ADD',1,0,'-1'],['ADD',0,1,'-1'],['IDLE_ONE',0,[4]]],
        'diagonal':[[0,0,1,1,1,1],[0,0,1,1,1,0]]}
    # Two independent noncentral, absolutely irreducible 2D blocks; each block
    # has two ordered HOSTs.  Their first two events provide the other pair of
    # stage masks.  The odd q targets hold at all four roots, with no thin events.
    host={
        'schema':'q0 two 2D blocks with four ordered type-B hosts','roles':4,'stages':4,
        'events':[['IDLE_ONE',0,[3,4]],['IDLE_ONE',1,[3,4]],
                  ['IDLE_ONE',2,[1,2]],['IDLE_ONE',3,[1,2]],
                  ['HOST',1,0,1,'1','1'],['HOST',2,0,1,'-1','2'],
                  ['ADD',0,1,'1'],['ADD',1,0,'-1'],['ADD',0,1,'1'],
                  ['LAMBDA',0,1],['LAMBDA',0,1],
                  ['HOST',3,2,3,'1','1'],['HOST',4,2,3,'-1','2'],
                  ['ADD',2,3,'1'],['ADD',3,2,'-1'],['ADD',2,3,'1'],
                  ['LAMBDA',2,1],['LAMBDA',2,1]],
        'diagonal':[[1,0,1,1,1,1] for _ in range(4)]}
    return {'flag_word':flag,'one_2d_word':block,'two_2d_host_word':host}

def projectors(events):
    return [s.Matrix(e['v'])*s.Matrix([e['w']]) for e in events]

def replay_independent(C):
    n=C['roles']; k=C['stages']; D=s.symbols('D1:'+str(k+1))
    for q in (s.Integer(1),s.Integer(-1),s.I,-s.I):
        R=s.eye(n)
        for e in C['events']:
            op=e[0]
            if op=='ADD': R[e[1],:]=R[e[1],:]+s.Rational(e[3])*R[e[2],:]
            elif op=='SCALE': R[e[1],:]=s.Rational(e[2])*R[e[1],:]
            elif op=='LAMBDA':
                lam=((1+s.I*e[2])+(1-s.I*e[2])*q*q)/2
                R[e[1],:]=lam*R[e[1],:]
            elif op=='IDLE_ONE': R[e[1],:]=s.prod(D[t-1] for t in e[2])*R[e[1],:]
            elif op=='HOST':
                t,r,z,a,b=e[1],e[2],e[3],s.Rational(e[4]),s.Rational(e[5]); oldr,oldz=R[r,:],R[z,:]
                R[r,:]=D[t-1]*(oldr+a*q*oldz)
                R[z,:]=D[t-1]*(b*q**3*oldr+(1+a*b)*oldz)
            else: raise ValueError(op)
        T=s.diag(*[q**d[0]*s.prod(D[i]**d[i+2] for i in range(k)) for d in C['diagonal']])
        assert all(s.expand(x)==0 for x in R-T),q

def report(name,C):
    assert at.q0check.legal(C)==(True,True)
    replay_independent(C)
    masks,events=at.capture(C); n=C['roles']; k=C['stages']; ps=projectors(events)
    noncentral=[(events[i]['key'],events[j]['key']) for i in range(len(events)) for j in range(len(events))
                if len(events[i]['S'])>1 and ps[i]*ps[j]!=ps[j]*ps[i]]
    assert noncentral
    if name=='flag_word':
        assert all(p[1,0]==0 for p in ps)
        assert ps[0]*ps[2]!=ps[2]*ps[0]
    elif name=='one_2d_word':
        p,q=ps[0],ps[2]
        # E11's only invariant lines are the coordinate lines; q preserves neither.
        assert p==s.diag(1,0) and q[0,1]!=0 and q[1,0]!=0
        assert s.Matrix.hstack(*[s.Matrix(x).reshape(4,1) for x in (s.eye(2),p,q,p*q)]).det()!=0
    else:
        for p in ps:
            assert p[:2,2:]==s.zeros(2,2) and p[2:,:2]==s.zeros(2,2)
        for indices in ((0,1),(2,3)):
            mats=[p.extract(indices,indices) for p in ps]
            # Check a concrete algebra-spanning certificate in each block.
            a=next(p for p in mats if p==s.diag(1,0)); b=next(p for p in mats if p[0,1] and p[1,0])
            assert s.Matrix.hstack(*[x.reshape(4,1) for x in (s.eye(2),a,b,a*b)]).det()!=0
        hs=[e for e in C['events'] if e[0]=='HOST']
        assert [e[1] for e in hs]==list(range(1,k+1))
        assert all(F(e[4]) and F(e[5]) and 1+F(e[4])*F(e[5]) for e in hs)
    sols={}
    for strict in (False,True):
        _,_,_,stats,witness=at.solve(events,masks,k,strict)
        assert witness is not None
        sols['strict' if strict else 'mask_only']={'stats':stats,
            'witness':[{ 'event':events[i]['key'],'stages':sorted(events[i]['S']),'role':witness[i]}
                       for i in range(len(events))]}
    out={'four_q_symbolic_D':True,'independent_sympy_replay':True,
         'multi_noncentral_pairs':noncentral,'solutions':sols}
    print(name,'4q=True; noncentral multi pairs=',len(noncentral),'attributions=',list(sols),flush=True)
    return out

if __name__=='__main__':
    results={}
    for name,C in example_words().items():
        (ROOT/(name+'.json')).write_text(json.dumps(C,indent=2)+'\n')
        results[name]=report(name,C)
    (ROOT/'example_results.json').write_text(json.dumps(results,indent=2)+'\n')
