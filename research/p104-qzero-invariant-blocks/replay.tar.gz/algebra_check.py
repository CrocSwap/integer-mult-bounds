#!/usr/bin/env python3
"""Exact finite-field certificates that incidence projectors generate M_n.

The input fractions come from the exact prefix capture of #7903. A full rank
mod p certifies that the corresponding rational matrix words span M_n(Q), and
therefore proves irreducibility over every field extension of Q. A smaller rank
mod p makes no such claim. All generated products have the original matrices
as factors; row reduction is used only for the independence test.
"""
import importlib.util
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = Path(os.environ.get('P104_ATTRIBUTION_SOURCE', str(ROOT)))
os.environ.setdefault('P104_GUIDANCE_SOURCE',str(SRC/'source'))
sys.path.insert(0,str(SRC))
import attribution as at

P = 1000000007

def mod(x):
    return (x.numerator % P) * pow(x.denominator % P, -1, P) % P

def outer(e):
    return [[mod(a*b) for b in e['w']] for a in e['v']]

def matmul(a,b):
    n=len(a)
    return [[sum(a[i][k]*b[k][j] for k in range(n))%P for j in range(n)] for i in range(n)]

def analyze(name):
    c=json.loads((SRC/'source/data/q0_callers'/f'{name}.json').read_text())
    masks,events=at.capture(c)
    n=len(masks)
    gens=[outer(e) for e in events]
    # The arrays basis, words, and reduced stay in the same insertion order.
    basis=[]; words=[]; reduced=[]; pivots=[]
    def add(m, word):
        v=[x for row in m for x in row]
        for pivot, rv in zip(pivots,reduced):
            a=v[pivot]
            if a:
                v=[(x-a*y)%P for x,y in zip(v,rv)]
        try: pivot=next(i for i,x in enumerate(v) if x)
        except StopIteration: return False
        inv=pow(v[pivot],-1,P)
        v=[x*inv%P for x in v]
        basis.append(m); words.append(word); reduced.append(v); pivots.append(pivot)
        return True
    add([[int(i==j) for j in range(n)] for i in range(n)],[])
    for i,g in enumerate(gens): add(g,[i])
    j=0
    while j<len(basis) and len(basis)<n*n:
        current=basis[j]; word=words[j]
        for i,g in enumerate(gens):
            if add(matmul(current,g),word+[i]) and len(basis)==n*n: break
        j+=1
    result={'name':name,'modulus':P,'n':n,'events':len(events),'algebra_rank_mod_p':len(basis),
        'absolute_irreducible_certified':len(basis)==n*n,
        'words':[[events[i]['key'] for i in word] for word in words],
        'pivots':pivots,'event_indices':[[i for i in word] for word in words]}
    print(name, 'events',len(events),'algebra rank modulo',P, len(basis),'/',n*n,
          'absolutely irreducible certified',result['absolute_irreducible_certified'], flush=True)
    return result

if __name__=='__main__':
    names=sys.argv[1:] or ['caller_C1','ml_k4','ml_k5']
    results=[analyze(name) for name in names]
    (ROOT/'algebra_results.json').write_text(json.dumps(results,indent=2)+'\n')
