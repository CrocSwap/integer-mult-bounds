#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Directly screen two native BIT packet omissions with any principal helper surrender."""
from collections import Counter
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import argparse
import gzip
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
import literal

D = Decimal
LOW = Context(prec=90, rounding=ROUND_FLOOR)
HIGH = Context(prec=90, rounding=ROUND_CEILING)
NEAR = Context(prec=90)
SCALE = 10**30
K = D('0.003879929046155')
WORD = 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
BRIDGE = 3553
PUBLIC = 680
PROTECTED = ((1 << 222) - 1) | (1 << 411)


def require(test, message):
    if not test:
        raise ValueError(message)


def indices(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit


def grade_bounds(rank, rate):
    if rank == 1:
        return D(1), D(1)
    ln = NEAR.ln(D(rank))
    t = LOW.subtract(D(1), rate)
    require(t == HIGH.subtract(D(1), rate), 'represented exponent')
    lo = LOW.multiply(t, NEAR.next_minus(ln))
    hi = HIGH.multiply(t, NEAR.next_plus(ln))
    return NEAR.next_minus(NEAR.exp(lo)), NEAR.next_plus(NEAR.exp(hi))


def signed_margin(targets, paid, rate):
    moment = []
    for census in (targets, paid):
        lo, hi = D(0), D(0)
        for rank, count in census.items():
            x, y = grade_bounds(int(rank), rate)
            lo = LOW.add(lo, LOW.multiply(x, count))
            hi = HIGH.add(hi, HIGH.multiply(y, count))
        moment.append((lo, hi))
    return [str(LOW.subtract(moment[0][0], moment[1][1])),
            str(HIGH.subtract(moment[0][1], moment[1][0]))]


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load_inputs():
    source = json.loads((ROOT / 'SOURCES.json').read_bytes())
    for item in source['inputs']:
        require(digest(ROOT/item['local']) == item['sha256'], item['local'])
    source_dir = ROOT/'inputs'
    def unpack(name):
        return json.loads(gzip.decompress((source_dir/name).read_bytes()))
    word = unpack('WORD.json.gz')
    require(literal.canonical(word) == WORD and word['public'] == PUBLIC, 'binary word')
    return word, unpack('EFREE-CALLER.json.gz'), json.loads((source_dir/'BIT.json').read_bytes()), json.loads((source_dir/'AUDIT.json').read_bytes())


def literal_probe(word, reverse=False, omissions=(), capture_paths=False):
    """Compute arbitrary public rows in literal order, with optional rank-one impulse labels."""
    n = word['public']
    data = [1 << j for j in range(n)] + [0]*word['owned_fields']
    ancestry = [0]*len(data)
    records = {}
    clocks = [clock for clock, event in enumerate(word['program']) if event[0] == 'MOVE']
    packet_at = {clock:n+j for j,clock in enumerate(clocks)}
    sequence = range(len(word['program']))
    for clock in (reversed(sequence) if reverse else sequence):
        op, bank, *args = word['program'][clock]
        if op in ('INIT', 'CLEAR'):
            data[bank] = ancestry[bank] = 0
        elif op == 'ADD':
            source = args[0]
            dest, src = (source, bank) if reverse else (bank, source)
            data[dest] ^= data[src]
            ancestry[dest] ^= ancestry[src]
        elif op == 'SWAP':
            peer = args[0]
            data[bank], data[peer] = data[peer], data[bank]
            ancestry[bank], ancestry[peer] = ancestry[peer], ancestry[bank]
        else:
            require(op == 'MOVE', 'literal primitive')
            packet = packet_at[clock]
            if capture_paths:
                ancestry[bank] ^= 1 << packet
            records[packet] = (data[bank], ancestry[bank], clock, *args)
            if packet in omissions:
                data[bank] = ancestry[bank] = 0
    return records, data[:n]


def overlap_check(word):
    """Independent direct word replay for a rank-one formula including one true dependency."""
    fwd, base = literal_probe(word, capture_paths=True)
    adj, _ = literal_probe(word, reverse=True)
    cases = [(719,724,[664,672]), (873,880,[]), (1934,2947,[]), (680,683,[])]
    result = []
    for i,j,surrender in cases:
        x, y = fwd[i][0], fwd[j][0]
        path = (fwd[j][1] >> i) & 1
        y ^= x if path else 0
        z = sum(1 << h for h in surrender)
        _, changed = literal_probe(word, omissions=(i,j))
        _, reverse = literal_probe(word, reverse=True, omissions=(i,j))
        wrong, predicted = [], [0]*PUBLIC
        for h in range(PUBLIC):
            discrepancy = (x if (adj[i][0] >> h)&1 else 0) ^ (y if (adj[j][0] >> h)&1 else 0)
            require(changed[h]^base[h] == discrepancy, 'independent literal forward control')
            for a in indices(changed[h]):
                predicted[a] |= 1 << h
            if h not in surrender and discrepancy & ~z:
                wrong.append(h)
        require(reverse == predicted, 'independent literal adjoint control')
        result.append(dict(packets=[i,j], clocks=[fwd[i][2],fwd[j][2]],
                           old_path_parity=path, surrender=surrender, wrong_retained_rows=len(wrong)))
    require(result[0]['wrong_retained_rows']==0 and result[-1]['old_path_parity']==1, 'control sensitivity')
    return result


def covers(rectangles, budget, losses, scale):
    """All potentially affordable minimal covers of at most three rectangles."""
    forced = 0
    choices = []
    for left, right in rectangles:
        if not left or not right:
            continue
        if left & PROTECTED:
            if right & PROTECTED:
                return False, ()
            forced |= right
        elif right & PROTECTED:
            forced |= left
        else:
            choices.append((left, right))
    def fits(mask):
        return mask.bit_count()*scale <= budget and losses(mask) <= budget
    if not fits(forced):
        return True, ()
    current = {forced}
    for left, right in choices:
        next_masks = set()
        for mask in current:
            if left & ~mask == 0 or right & ~mask == 0:
                next_masks.add(mask)
            else:
                for candidate in (mask | left, mask | right):
                    if fits(candidate):
                        next_masks.add(candidate)
        current = next_masks
    return True, current


def screen(word, charts):
    forward, _ = literal_probe(word, capture_paths=True)
    adjoint, _ = literal_probe(word, reverse=True)
    grade = {k:charts.leg(row[3],row[4]) for k,row in forward.items()}
    helpers = {h:charts.leg(word['start'][h],word['final'][h]) for h in range(222,PUBLIC)}
    bounds = {r:grade_bounds(r,K) for r in range(1,9)}
    lower = {r:int(LOW.multiply(x,SCALE).to_integral_value(rounding=ROUND_FLOOR)) for r,(x,_) in bounds.items()}
    upper = {r:int(HIGH.multiply(y,SCALE).to_integral_value(rounding=ROUND_CEILING)) for r,(_,y) in bounds.items()}
    @lru_cache(maxsize=30000)
    def losses(mask):
        return sum(lower[helpers[h]] for h in indices(mask))
    counts, ties, unequal = Counter(), [], []
    for i,j in combinations(sorted(k for k in forward if k != BRIDGE),2):
        counts['pairs'] += 1
        u, w = forward[i][0], forward[j][0]
        v, z = adjoint[i][0], adjoint[j][0]
        if forward[j][1] & (1 << i):
            w ^= u
        rects = ((v & ~z,u),(z & ~v,w),(z & v,u^w))
        ok, candidates = covers(rects, upper[grade[i]] + upper[grade[j]], losses, SCALE)
        if not ok:
            continue
        counts['pass_protected_rectangles'] += 1
        if candidates:
            counts['pairs_with_sign_candidates'] += 1
        for chosen in candidates:
            change = Counter([grade[i],grade[j]])
            change.subtract(helpers[h] for h in indices(chosen))
            if any(change.values()):
                unequal.append([i,j,list(indices(chosen)),dict(change)])
            else:
                counts['ties'] += 1
                if len(ties)<12:
                    ties.append([i,j,list(indices(chosen))])
    return dict(counts=dict(counts),ties=ties,distinct_histogram_candidates=unequal,
                grade_scale=SCALE,grade_bounds={r:[lower[r],upper[r]] for r in lower})


def run():
    word, caller, bit, rat = load_inputs()
    charts = literal.Charts(word['frames'])
    charts.main_contacts(word['start'],word['final'])
    fwd, data, _ = literal.tape(word,charts)
    adj, other, _ = literal.tape(word,charts,adjoint=True)
    require(fwd==literal.expected_rows(PUBLIC,False) and adj==literal.expected_rows(PUBLIC,True), 'baseline arbitrary public inputs')
    require(data['erase_dirty']==other['erase_dirty']==3554, 'baseline owned-state controls')
    native_targets = Counter(charts.leg(a,b) for a,b in zip(word['start'][222:],word['final'][222:]))
    paid, targets, *_ = literal.paired_invoice(caller,data['paid'],native_targets,Counter(e[0] for e in caller['events']))
    require(dict(paid)=={int(k):v for k,v in bit['native']['paid'].items()}, 'full caller paid')
    require(dict(targets)=={int(k):v for k,v in bit['native']['targets'].items()}, 'full caller targets')
    result = screen(word,charts)
    result['controls'] = overlap_check(word)
    result['word_sha256'] = WORD
    result['kappa'] = str(K)
    result['complete_36_bit_margin'] = signed_margin(targets,paid,K)
    result['complete_48_rational_margin'] = signed_margin(rat['signed']['productive'],rat['signed']['paid'],K)
    result['paid_36'],result['target_36'] = sum(paid.values()),sum(targets.values())
    result['baseline_catalogue'] = {'charts':len(charts.frames),'native_moves':sum(data['paid'].values()),'native_helpers':PUBLIC-222,
                                    'dirty_lifetimes_each_direction':data['erase_dirty'],'public_coefficients_each_direction':PUBLIC**2}
    return json.loads(json.dumps(result))


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--emit',action='store_true')
    args=parser.parse_args()
    output=run()
    if args.emit:
        print(json.dumps(output,indent=2,sort_keys=True))
    else:
        require(output==json.loads((ROOT/'EXPECTED.json').read_bytes()),'receipt mismatch')
        print('PASS_TWO_NATIVE_OMISSIONS',output['counts'],'no positive signed histogram')
