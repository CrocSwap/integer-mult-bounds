# Two paid BIT omissions with arbitrary principal helper surrender

At the near trial κ = 0.003879929046155, simultaneous removal of any two existing unprotected BIT MOVE packets has maximum signed improvement zero in the model below. The census covers all 4,125,628 unordered pairs of the 2,873 eligible packets. The helper surrender may have any size. All subsequent private packet values may change. The baseline native word and original 36-call caller come from [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830).

A principal surrender sets the selected helper inputs to zero and discards the same output indices. Retained helpers keep their original identities and charts. The 222 main coordinates, helper 411 and the paid bridge numbered 3553 are protected. Each selected paid packet is set to zero at its original chart transition. Every other local row and paid route retains its original formula and clock. A change of local coefficients, a new route, an independent input relation, a changed caller or three paid omissions lies outside the calculation.

| Native pairs | Count |
| --- | ---: |
| All unordered pairs | 4,125,628 |
| Pairs whose discrepancy has no protected-to-protected nonzero entry | 137,550 |
| Pairs with a principal surrender reaching a nonnegative signed upper price | 435 |
| Candidate surrenders with exactly identical old and new signed grade counts | 435 |
| Positive native changes | 0 |

Each zero in the last price class follows by cancellation of identical grade counts at every rate. The global upper bound is proved at the stated near trial. The full BIT and rational margins there remain approximately −0.000385127316613866441 and +0.211243929926514344, respectively. This result supplies a bounded obstruction to a paid-edit family. New native constructions, finite suppliers, physical erasure, compiler transfer, precision and stock, analytic recovery, independent human review and frontier selection remain separate.

Run the following commands with Python 3.10 or newer from the package directory. The verifier uses the Python standard library and bundled source inputs.

```sh
sha256sum -c SHA256SUMS
python3 -B verify.py
python3 -B controls.py
```

The baseline check reconstructs the exact rational nesting of all MOVE and helper grades, both 680-by-680 native matrices, all paired caller coefficients in both directions, and 3,554 dirty owned retirements each way. It independently reconstructs both public transfer orientations from the primitive clocks for four deletion controls. EXPECTED.json contains the complete machine result, source-authenticated full invoices, and 30-place outward integer price enclosures. SOURCES.json lists original input URLs and hashes. PROOF.md gives the exact family and the price test.

Clear1nsight prepared the bounded search and verification with substantial OpenAI Codex assistance. The source word, paired caller and previous verification work retain their authorship in NOTICE and inputs/7830-NOTICE. The retained #7830 mixed supplier draws on Ali Romman's #7776 paired caller and predecessor native and physical contributions. These artifacts report automated computational checks.
