#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Independent small controls for the coverage logic and old path dependency."""
from itertools import combinations
from verify import PUBLIC, covers, indices, literal_probe, load_inputs, overlap_check, require


def brute(rectangles, owners, budget):
    result=[]
    for size in range(budget+1):
        for subset in combinations(owners,size):
            mask=sum(1<<x for x in subset)
            if all(not(a & ~mask) or not(b & ~mask) for a,b in rectangles):
                result.append(mask)
    return result


word, *_=load_inputs()
cases=overlap_check(word)
record,base=literal_probe(word,capture_paths=True)
rev,_=literal_probe(word,reverse=True)
first,second=680,683
_,actual=literal_probe(word,omissions=(first,second))
naive=[((record[first][0] if rev[first][0]&(1<<j) else 0)
        ^ (record[second][0] if rev[second][0]&(1<<j) else 0)) for j in range(PUBLIC)]
require(any((got^old)!=wrong for got,old,wrong in zip(actual,base,naive)),'uncoupled formula must fail')
owners=(222,223,224)
masks=[0,1,1<<411]+[sum(1<<i for i in s) for n in (1,2,3) for s in combinations(owners,n)]
roster=0
for a in masks:
    for b in masks:
        for c in masks:
            for d in masks:
                rectangles=((a,b),(c,d))
                brute_masks=brute(rectangles,owners,2)
                ok,got=covers(rectangles,2,int.bit_count,1)
                require(all(any(x&~m==0 for x in got) for m in brute_masks),'all brute covers dominated')
                require(all(x in brute_masks for x in got),'every returned cover valid')
                roster+=1
print('PASS_TWO_OMISSION_CONTROLS',roster,'rectangle cases, true path and principal surrender controls')
