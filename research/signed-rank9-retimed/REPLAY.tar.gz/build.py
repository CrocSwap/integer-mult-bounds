"""Transfer the exact #7105 retimed helper to the rank-nine native word."""
from collections import Counter
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import gzip
import json
import sys

OLD = "cca66a7ec924bab47ccd1410968d16e071a01dc6110b5c08040bd207f753d066"
AUDIT = "c7d81ad6620de5e46abf97259f62da0138b58a02759c3189e57b8ab176db6bd5"
CUT, MOVE, OLD_HELPER, NEW_HELPER = 43039, 43999, 1123, 1480


def canonical(word):
    return json.dumps(word, sort_keys=True, separators=(",", ":")).encode()


def operands(event):
    return (1, 2) if event[0] in ("ADD", "COPY") else (1,)


def build(old):
    assert old["public"] == NEW_HELPER
    seq = old["program"]
    assert old["final"][OLD_HELPER] == 127
    assert seq[MOVE] == ["MOVE", OLD_HELPER, 242, 127, False]
    assert seq[37895] == ["MOVE", OLD_HELPER, 744, 242, False]
    assert seq[38712] == ["MOVE", 843, 1071, 245, False]
    assert seq[43505] == ["MOVE", 843, 245, 127, False]
    assert not any(e[k] == OLD_HELPER for e in seq[37902:MOVE] for k in operands(e))
    later = [i for i, e in enumerate(seq) if i > MOVE and any(e[k] == OLD_HELPER for k in operands(e))]
    assert later == [56174, 56177, 56189, 56271]
    inserted = [
        ["MOVE", OLD_HELPER, 242, 245, False],
        ["ADD", 843, OLD_HELPER, "-1", 245],
        ["ADD", 843, NEW_HELPER, "1", 245],
    ]
    tagged = []
    for i, e in enumerate(seq):
        if i == CUT:
            tagged.extend((-1 - k, op) for k, op in enumerate(inserted))
        if i == MOVE:
            tagged.append((i, ["MOVE", NEW_HELPER, 245, 127, False]))
            continue
        event = e.copy()
        for k in operands(event):
            if event[k] >= NEW_HELPER:
                event[k] += 1
            elif i > MOVE and event[k] == OLD_HELPER:
                event[k] = NEW_HELPER
        tagged.append((i, event))
    final = [*old["final"], 127]
    final[OLD_HELPER] = 245
    return dict(old, public=NEW_HELPER + 1, initial=[*old["initial"], 245],
                final=final, program=[e for _, e in tagged]), tagged, inserted, later


def main(old_path, audit_path, out):
    raw = gzip.decompress(old_path.read_bytes())
    assert sha256(raw).hexdigest() == OLD
    assert sha256(audit_path.read_bytes()).hexdigest() == AUDIT
    old = json.loads(raw)
    new, tagged, inserted, later = build(old)
    spec = spec_from_file_location("retimed_grid", audit_path)
    a = module_from_spec(spec)
    sys.modules[spec.name] = a
    spec.loader.exec_module(a)
    old_result, old_grid = a.replay(old, list(enumerate(old["program"])), set())
    new_result, grid = a.replay(new, tagged, {-2})
    expected = list(old_result[0][:NEW_HELPER]) + [{NEW_HELPER: 1125 * 2**24}]
    assert new_result[0][:new["public"]] == expected
    assert new_result[1][-2] == ((OLD_HELPER, 1125 * 2**24),)
    delta = Counter(grid["paid"]); delta.subtract(old_grid["paid"])
    assert {r: v for r, v in delta.items() if v} == {1: 1, 4: 1, 5: -1}
    assert all(old_grid[k] == grid[k] for k in ("owned_peak", "owned_lifetimes", "owned_rise_mass", "odd_grid_lcm"))
    for old_life, new_life in zip(old_result[4], new_result[4], strict=True):
        assert (*old_life[:2], old_life[2] + 1) == new_life
    payload = canonical(new)
    out.write_bytes(gzip.compress(payload, mtime=0))
    print(json.dumps(dict(status="PASS_RETIMER_NATIVE_GRID", original=OLD,
                          word_sha256=sha256(payload).hexdigest(), insertion=CUT, old_move=MOVE,
                          inserts=inserted, rebound=later, owned_alpha_shift=1,
                          old_grid=old_grid, grid=grid), sort_keys=True, indent=2))


if __name__ == "__main__":
    assert __debug__
    main(*(Path(p) for p in sys.argv[1:]))
