#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bundle=$PWD
shasum -a 256 -c SHA256SUMS >/dev/null
if [[ $# != 1 ]]; then echo 'usage: verify.sh /absolute/results' >&2; exit 2; fi
mkdir -p "$1"
out=$(cd "$1" && pwd)
[[ -z "$(ls -A "$out")" ]]
python_bin=$(command -v "${RANK9_PYTHON:-python3.12}")
"$python_bin" -c 'import sys; assert sys.version_info[:2] == (3,12)'
work=$(mktemp -d "${TMPDIR:-/tmp}/croc-retimed-clean.XXXXXX")
mkdir "$work/base"
tar -xzf "$bundle/rank9-replay.tar.gz" -C "$work/base"
(cd "$work/base"; shasum -a 256 -c SHA256SUMS >/dev/null)
b="$work/base/sources/kappa-coupled-boundaries-20261110T0908Z"
r="$work/base/sources/kappa-rank9-lower-20261110T1247Z/evidence"
tar -xzf "$work/base/payload/incumbent.tar.gz" -C "$b"
v="$b/replay/research/shared-wire-split-composition"
a="$b/replay/research/shared-wire-stop-fusion/audit_native.py"
old="$b/evidence/candidate.json.gz"
new="$out/WORD.json.gz"
caller="$r/dyadic/CALLER.json"
"$python_bin" -B "$bundle/build.py" "$old" "$a" "$new" > "$out/GRID.json"
cmp "$out/GRID.json" "$bundle/GRID.json"
"$python_bin" -B "$bundle/gate.py" "$b/replay" "$r" "$old" "$new" "$caller" "$bundle/BASE.json" > "$out/gate.stdout" 2> "$out/gate.stderr" &
gate=$!
"$python_bin" -I -B "$v/frozen/verify_host3_odd.py" "$new" 1125 > "$out/host3.stdout" 2> "$out/host3.stderr"
grep -q 'endpoint bad rows 0 odd certificate S 1125' "$out/host3.stdout"
"$python_bin" -I -B "$v/frozen/physical.py" "$new" "$v/frozen/clifford_exact.py" 1000000009 11 > "$out/physical.stdout" 2> "$out/physical.stderr"
grep -q 'helper rows bad 0 (of 1081), X rows bad 0, Y rows bad 0, X2 rows bad 0, Y2 rows bad 0' "$out/physical.stdout"
wait "$gate"
tail -1 "$out/gate.stdout" > "$out/RESULT.json"
cmp "$out/RESULT.json" "$bundle/RESULT.json"
"$python_bin" -B "$bundle/routes.py" "$b/replay" "$r" "$old" "$new" "$caller" > "$out/ROUTES.json"
cmp "$out/ROUTES.json" "$bundle/ROUTES.json"
test ! -s "$out/gate.stderr" && test ! -s "$out/host3.stderr" && test ! -s "$out/physical.stderr"
printf 'PASS_SIGNED_RANK9_RETIMED_REPLAY 0.003635302061475 0.000000099492204\n'
