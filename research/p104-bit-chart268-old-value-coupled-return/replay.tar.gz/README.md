# Restore the five chart-268 exit values with an earlier paid return

Rebind 2678 to 182→0 to deliver the exact old X1464+X1584 direction and restore five old chart-268 exits while keeping owners 221, 679 and 411 in both orientations.

Both sides still fail 66/23 full rows. Two cut deficits exclude funded additions or one more retarget with other incidences fixed. A separate native-clock theorem excludes exact old exits for pure 1584 and fixed earlier contacts despite arbitrary earlier recoding. The 206 displaced-packet tests use a named deterministic repair policy.

Change the surviving incidence set enough to restore both independent cut dimensions and rebind the full operator.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. Both inner cold archives passed. Checks include 634 sink collisions, the priced x519 restoration and x518 corruption, independent stock support, all 206 policy cases and both complete 680-row orientations.
