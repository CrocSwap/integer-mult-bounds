#!/usr/bin/env python3
"""Verify this frozen Q96 singleton-gauge packet with only Python stdlib.

Default: verify all file hashes and rerun the general support proof, exact
fixed-gauge checks, Q5 obstruction, and rational engine replay.  --census
also reruns the unit-gauge support census.  All paths are packet-relative.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent

def check_manifest():
    expected={}
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,sep,name=line.partition('  ')
        if not sep or len(digest)!=64 or name in expected:
            raise ValueError('malformed or duplicate SHA256SUMS entry')
        target=Path(name)
        if target.is_absolute() or '..' in target.parts:
            raise ValueError('non-relative SHA256SUMS entry: '+name)
        expected[name]=digest
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*')
            if p.is_file() and p!=ROOT/'SHA256SUMS'}
    if actual != set(expected):
        raise ValueError('packet files differ from manifest: missing=%s extra=%s' %
                         (sorted(set(expected)-actual),sorted(actual-set(expected))))
    for name,want in sorted(expected.items()):
        p=ROOT/name
        if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=want:
            raise ValueError('SHA-256 mismatch or symlink: '+name)
    return len(expected)

def stage(script,evidence):
    p=subprocess.run([sys.executable,'-B',str(ROOT/script)],cwd=ROOT,
                     text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:
        raise RuntimeError('%s failed (exit %d):\n%s' % (script,p.returncode,p.stderr))
    got=json.loads(p.stdout)
    want=json.loads((ROOT/'evidence'/evidence).read_text())
    if got != want:
        raise ValueError(script+' output does not match recorded evidence')
    return got

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--census',action='store_true',help='also rerun all 521,412 unit-gauge support cases')
    args=ap.parse_args()
    count=check_manifest()
    support=stage('general_bound.py','general_bound.json')
    fixed=stage('check.py','result.json')
    witness=stage('replay.py','replay.json')
    census=stage('sweep.py','sweep.json') if args.census else None
    print('Verified %d packet files against SHA256SUMS.' % count)
    print('General support proof: lower bound %d in the stated singleton-gauge family.' % support['proved_chain_price_floor_in_described_gauge'])
    print('Q96 engine replay: R=%d, %d epochs, factor ranks %s; 0 legality/pinning errors.' %
          (witness['q96']['ascents'],witness['q96']['epochs'],witness['q96']['epoch_factor_ranks_Q']))
    print('Q5 control: chain/R=%d, decoder mass=3; evidence matched.' % witness['q5']['ascents'])
    print('Signed-tail mutation: %d odd-cell violations.' % witness['q96']['abel_tail_as_increment_odd_violations'])
    if census:
        print('Unit-gauge census: %d support cases; minimum %d.' % (census['support_cases'],census['minimum_chain_price']))
    else:
        print('Unit-gauge census not rerun; pass --census to include it.')

if __name__=='__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, KeyError, json.JSONDecodeError) as exc:
        print('Verification failed: '+str(exc),file=sys.stderr)
        sys.exit(1)
