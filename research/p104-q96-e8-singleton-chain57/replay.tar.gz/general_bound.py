#!/usr/bin/env python3
"""Verify the finite support facts for the arbitrary-coefficient 57 bound.

All coefficients may be arbitrary real numbers.  The only support changes
of u-r*v are at the finitely many ratios u[t]/v[t].  Integers/Fractions give
an exact representative of each such support and one of the generic support.
"""
from collections import Counter
from itertools import combinations
import json
import check

L,G,W,C=check.load()
output_hist=Counter()
output_cases=0
for i in range(8):
    cases=[W[i]]
    for j in range(8):
        if i==j: continue
        for r in check.choices(W[i],W[j]):
            cases.append([r.denominator*x-r.numerator*y for x,y in zip(W[i],W[j])])
    for w in cases:
        assert any(w)
        output_cases+=1
        for p in range(96):
            d=check.f2rank(L[t] for t,x in enumerate(w) if x and t != p)
            output_hist[d]+=1
            assert d>=8

intake_hist=Counter()
intake_cases=0
singleton_checks=0
for a,b in combinations(range(8),2):
    cases=[C[a],C[b]]
    for r in check.choices(C[a],C[b]):
        cases.append([r.denominator*x-r.numerator*y for x,y in zip(C[a],C[b])])
    for c in cases:
        assert any(c)
        basis=check.independent(L[t] for t,x in enumerate(c) if x)
        intake_hist[len(basis)]+=1
        assert len(basis)>=8
        intake_cases+=1
        for p in range(96):
            # The 1-by-|support| label-pairing has rank exactly one.
            assert any(check.dot(L[p],x) for x in basis)
            singleton_checks+=1

assert output_cases==174 and dict(output_hist)=={8:982,9:15722}
assert intake_cases==140 and dict(intake_hist)=={8:56,9:84}
assert singleton_checks==13440
print(json.dumps({'output_combination_support_cases':output_cases,
                  'label_ranks_after_any_one_port_deletion':dict(sorted(output_hist.items())),
                  'intake_combination_support_cases':intake_cases,
                  'intake_label_ranks':dict(sorted(intake_hist.items())),
                  'singleton_pairing_checks':singleton_checks,
                  'all_singleton_pairings_have_rank_one':True,
                  'proved_chain_price_floor_in_described_gauge':57},indent=2,sort_keys=True))
