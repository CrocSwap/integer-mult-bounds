#!/usr/bin/env python3
"""Construct and replay actual pinned runs with the #7869 rational engine.

The Q96 run realizes one minimizer of the bounded screen.  Its R=57 is an
upper bound in the pinned engine model, not a word or recursive invoice.
"""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import check
ENGINE_DIR=Path(__file__).resolve().parent / 'source' / '7869'
raw=(ENGINE_DIR/'eng.py').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='900b41f42c978e2bca2db001a5dc81dc93953adb5e842a4924d37c860124c2f6'
assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()=='cad7f0d954221c6806533efbe757d659162c27e0'
sys.path.insert(0,str(ENGINE_DIR))
import eng

def run_rows(labels, chains):
    n=max(labels).bit_length()
    R=eng.Run(n,labels,eng.Field(0))
    for ix,chain in enumerate(chains):
        assert len(chain) in (1,2)
        w,c=chain[0]
        C=eng.perp([labels[i] for i,v in enumerate(c) if v],n)
        oid=('O',ix)
        R.INIT(oid,C)
        for phase,(w,c) in enumerate(chain):
            if phase:
                cold=eng.perp([labels[i] for i,v in enumerate(c) if v],n)
                C=frozenset(R.reg[oid][0] & cold)
                R.MOVE(oid,C)
            for s,v in enumerate(c):
                if v:
                    Y=('Y',s)
                    R.MOVE(Y,eng.span(list(R.reg[Y][0])+list(C)))
                    R.ADD(oid,v,Y)
            D=[labels[t] for t,v in enumerate(w) if v]
            H=eng.span(list(C)+D)
            R.MOVE(oid,H)
            for t,v in enumerate(w):
                if v: R.ADD(('X',t),v,oid)
        R.CLEAR(oid)
    assert not R.bad and not R.pinned()
    return R

def main():
    labs,gram,W0,C0=check.load()
    W,C4=check.gauge(W0,C0,0,0,1)
    # Ordered Abel pair (0,8), rescale r=1: W1=w1+w2, W2=w2.
    w1=[x-y for x,y in zip(W[0],W[8])]
    C=[[Fraction(v,4) for v in c] for c in C4]
    shared=[(w1,C[0]),(W[8],C[8])]
    singles=[[(W[k],C[k])] for k in range(1,8)]
    chains=[shared]+singles
    assert len(chains)==8 and sum(map(len,chains))==9
    assert all(any(w) and any(c) for chain in chains for w,c in chain)
    factor_ranks=(check.qrank([w for ch in chains for w,c in ch]),
                  check.qrank([c for ch in chains for w,c in ch]))
    assert factor_ranks==(9,8)
    R=run_rows(labs,chains)
    got=R.rec()
    assert R.cost==57
    assert all(got[t][s]==Fraction(-gram[t][s],2) for t in range(96) for s in range(96))
    assert all(got[t][s]==(-1 if t==s else 0) for t in range(96) for s in range(96) if check.dot(labs[t],labs[s]))
    chain=[check.qprice(labs,w,c) for ch in chains for w,c in ch]
    assert sum(chain)==R.cost
    # Negative control: incorrectly treating Abel tail W1 as its own epoch
    # increment adds W2*c1 and must break the constrained odd cells.
    bad_tail=[(t,s) for t in range(96) for s in range(96)
              if check.dot(labs[t],labs[s]) and W[8][t]*C[0][s] != 0]
    assert bad_tail

    L=[1,2,7,11,13]
    c1=[0,0,1,1,0];c2=[1,1,0,0,0]
    w1=[-1,0,0,0,0];w2=[0,0,-1,-1,0]
    Q=run_rows(L,[[(w1,c1),(w2,c2)]])
    q5=Q.rec(); target={(0,2),(0,3),(2,0),(2,1),(2,2),(3,0),(3,1),(3,3)}
    assert Q.cost==2
    assert {(t,s) for t in range(5) for s in range(5) if check.dot(L[t],L[s]) and q5[t][s]}==target
    assert all(q5[t][s]==(-1 if (t,s) in target else 0) for t in range(5) for s in range(5) if check.dot(L[t],L[s]))
    print(json.dumps({'q96':{'pinned_engine_bad':len(R.bad),'pinned_errors':len(R.pinned()),
                              'ascents':R.cost,'lifetimes':len(chains),'epochs':sum(map(len,chains)),
                              'epoch_factor_ranks_Q':factor_ranks,'chain_prices':chain,
                              'odd_and_full_completion_exact':True,
                              'abel_tail_as_increment_odd_violations':len(bad_tail),
                              'abel_tail_first_violation':bad_tail[0], 'operations':len(R.ops)},
                      'q5':{'pinned_engine_bad':len(Q.bad),'pinned_errors':len(Q.pinned()),
                            'ascents':Q.cost,'odd_target_exact':True}},indent=2))

if __name__=='__main__': main()
