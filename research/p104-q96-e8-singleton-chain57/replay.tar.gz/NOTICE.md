# Source and attribution notice

This packet includes the following unchanged source files from
`CrocSwap/integer-mult-bounds`:

* `source/7852/DecoderWall4Data.lean`, from PR #7852 at commit
  `41beda1d6435760dc99e38bd7e65f36798aad212`; its original accompanying
  notice is `source/7852/NOTICE.md`.
* `source/7869/eng.py`, from PR #7869 at commit
  `06c207a9feb3994a4b987dc3010657b6e85b7956`; its original accompanying
  notice is `source/7869/NOTICE.md`.

Both upstream packages identify their license as Apache License 2.0. The
license text is included as `LICENSE`. `data.json` extracts the labels and
packed Gram entries from the #7852 source, retaining its source identifiers.
The remaining Python programs and evidence are new checks and constructions
for this packet. They refer to the earlier work without implying endorsement
by its authors.
