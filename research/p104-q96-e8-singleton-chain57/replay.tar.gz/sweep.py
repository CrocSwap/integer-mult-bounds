#!/usr/bin/env python3
"""Exact cache-accelerated sweep of the fixed basis and singleton gauges.

All 96 positions, all 28 gauge column pairs, all 72 ordered epoch pairs,
and all possible support-changing real nonzero row rescalings are covered.
The only source of truth for prices is the GF(2) label pairing.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations, permutations
import json
import check

L, G, W0, C0 = check.load()

def groups(v):
    d={}
    for i,x in enumerate(v):
        if x: d[x]=d.get(x,0) | (1 << i)
    return d

def support(v):
    return sum(1 << i for i,x in enumerate(v) if x)

labels_for=[]
for mask in range(1<<9):
    labels_for.append([check.dot(x,mask) for x in L])

S_cache={}
P_cache={}
def price(D,S):
    key=(D,S)
    if key in P_cache: return P_cache[key]
    if S not in S_cache:
        S_cache[S]=check.independent(L[i] for i in range(96) if S>>i&1)
    sb=S_cache[S]
    vals=(sum(labels_for[x][t] << i for i,x in enumerate(sb)) for t in range(96) if D>>t&1)
    p=check.f2rank(vals)
    P_cache[key]=p
    return p

def outputs(g1,g2):
    D=0
    for v in g1.values(): D|=v
    for v in g2.values(): D|=v
    # Generic nonzero scaling always retains the union support.
    outcomes={D}
    cancel={}
    for a,m1 in g1.items():
        for b,m2 in g2.items():
            intersection=m1 & m2
            if intersection:
                r=Fraction(a,b)
                cancel[r]=cancel.get(r,0)|intersection
    outcomes.update(D & ~m for m in cancel.values())
    return outcomes

hist=Counter(); gauges=0; best=100; worst=0; first=None; min_gauges=Counter()
for p in range(96):
    for a,b in combinations(range(8),2):
        W,C=check.gauge(W0,C0,p,a,b)
        WG=[groups(w) for w in W]
        D=[support(w) for w in W];S=[support(c) for c in C]
        rates=[price(d,s) for d,s in zip(D,S)]
        if (p,a,b) in {(0,0,1),(31,2,4),(95,6,7)}:
            assert rates == [check.qprice(L,w,c) for w,c in zip(W,C)]
            for i,j in permutations(range(9),2):
                expected=set()
                for r in check.choices(W[i],W[j]):
                    v=[r.denominator*x-r.numerator*y for x,y in zip(W[i],W[j])]
                    expected.add(support(v))
                    assert price(support(v),S[i])==check.qprice(L,v,C[i])
                assert outputs(WG[i],WG[j])==expected
        total=sum(rates); gauges+=1; local=100
        for i,j in permutations(range(9),2):
            for supp in outputs(WG[i],WG[j]):
                assert supp
                cost=total-rates[i]+price(supp,S[i])
                hist[cost]+=1
                if cost<local:local=cost
                if cost<best:
                    best=cost;first=(p,a,b,i,j,supp)
        worst=max(worst,local);min_gauges[local]+=1

print(json.dumps({'gauge_count':gauges,'ordered_pairs_per_gauge':72,
                  'support_cases':sum(hist.values()),'support_price_histogram':dict(sorted(hist.items())),
                  'minimum_chain_price':best,'max_gauge_minimum':worst,
                  'per_gauge_minima':dict(sorted(min_gauges.items())),
                  'first_minimum':list(first[:5]),
                  'cached_support_pairs':len(P_cache)},indent=2,sort_keys=True))
