# Q96: one two-epoch lifetime in a nine-row singleton gauge

## Result and scope

For the explicit E8 decoder below, add one output supported at one Q96 port,
with arbitrary real gauge coefficients, and then share exactly one ordered
pair of its nine rows in a two-epoch lifetime.  Even allowing arbitrary
nonzero real rescaling of the two Abel rows, the exact support-pairing chain
price is **at least 57**.  The bound is sharp in this family: a rational
pinned-engine run has nine nonzero epochs in eight lifetimes, cost **R = 57**,
and full Q96 receipt matrix **−G/2**, hence **−I on the odd cells**.

The factor ranks over Q are output **9**, intake **8**, including after the
two tails are converted into actual epoch increments.  Thus this does not
apply the rank-(8,8) chain lemma to the example.  This is a fixed E8 basis
and a singleton-output gauge, not all rank-(9,8) chains, all nine-row
decoders, arbitrary multi-epoch chains, runs with hot relays, or legal word
realizations.  It establishes neither ChainWall56@Q96 nor a kappa gain.

## Pinned inputs and exact basis

* [#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) commit `41beda1d6435760dc99e38bd7e65f36798aad212`,
  `research/p104-lowerbound-toolkit/lean/Nov15/DecoderWall4Data.lean`, Git
  blob `90949f8d5dbcdee99974de505018768f4f9f640e`, SHA-256
  `081bf16ed5e19930082ffb58548c6e6cded5c100f15332e797695e0cd07ef8c4`.
  The complete source is `source/7852/DecoderWall4Data.lean`, and the
  extracted arrays are `data.json`.  Q96
  uses its indices 0 through 95, as in #7869's `code/uphase/asc56.py`.
  The R1 challenge's port 103 is outside Q96, so its original ninth factor
  would vanish under restriction; here the extra port ranges over 0..95.
* [#7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869) exact commit `06c207a9feb3994a4b987dc3010657b6e85b7956`,
  `notes/reuse96.md` and `code/reuse96/{chainfuzz.py,eng.py}`;
  `notes/ctcover.md` and `code/ctcover/ctsplit.py`.
  `source/7869/eng.py` is copied unchanged from that commit (Git blob
  `cad7f0d954221c6806533efbe757d659162c27e0`).
  Its free nonzero-chart INIT, free owned descent and CLEAR model is the
  model replayed here.  The chart-control construction is independent of
  the earlier #7869 stored runs.

Put `F = [0,6,16,22,29,36,45,95]`, `A[t,k] = G[t,F[k]]` on Q96.  The
checker recomputes `G[F,F]=2I`, `A A^T=2G`, and all the relevant odd-cell
identities.  The integer 8-vectors `Z_i,Y_i` in `check.py` satisfy
`Z_i·Y_j = d_i δ_ij`, with each `d_i = ±2`.  Define

```
X_i = -A Z_i / 2                    V_i = sign(d_i) A Y_i / 4.
```

Exact arithmetic verifies `sum_i X_i V_i^T = -G/2`, rational ranks (8,8),
and the eight **GF(2)** support-pairing prices `[7,7,7,7,7,7,7,7]`.
The Z,Y basis was obtained by scanning 9-bit normals and exact rational
kernels, then finding eight mutually biorthogonal row pairs.  Its displayed
identities, not the search, are needed to verify the result.

Choose any Q96 port `p`, distinct `a,b` among `0..7`, and real `α,β`, not
both zero.  Let `e_p` be the singleton at p.  The nine Abel rows are

```
W_a = X_a + α e_p          W_b = X_b + β e_p
W_k = X_k for k ≠ a,b     W_8 = e_p
C_k = V_k for k < 8        C_8 = −α V_a − β V_b.
```

Their sum `Σ W_k C_k^T` is exactly `−G/2`; the added contribution cancels
identically on every cell.  All nine input and output factors are nonzero.
The frame block proves `e_p` lies outside `col(A)`: for a non-frame p this
is immediate, and for a frame p the corresponding column of A has another
nonzero entry, which the verifier checks.  Thus `rank_Q W=9`,
`rank_Q C=8` for rational α,β.  `C_8` is nonzero by independence of `V_a,V_b`.

## Correct chain price and proof

An output factor in a decoder row is an **Abel tail**, not generally an
epoch increment.  If two ordered rows i,j share a lifetime and the second
Abel row is rescaled by nonzero `r`, the correct fresh intakes and outputs
are

```
epoch 1:  (w_1, c_1) = (W_i − r W_j, C_i)
epoch 2:  (w_2, c_2) = (r W_j, C_j/r).
```

The receipt identity is `w_1 c_1^T + w_2 (c_1+c_2)^T =
W_i C_i^T + W_j C_j^T`.  Thus the prices must use the signed
`W_i − r W_j`, not `W_i`, and supports must be calculated after cancellation.
All other rows are single-epoch lifetimes.  The charge is the binary rank
`rank_F2 Q[supp(w),supp(c)]`, where `Q[t,s]=parity(lab[t]&lab[s])`.
No rational Gram rank is substituted for this binary pairing rank.

`general_bound.py` checks the following exact, finite facts on the pinned
Q96 labels:

1. Every one-basis output `X_i` and every nonzero two-basis output
   `X_i−r X_j` retains label-span dimension at least 8 after removing any one
   of the 96 ports.  There are 174 output-support cases and 16,704 deletions:
   982 have dimension 8, and 15,722 dimension 9.
2. Every nonzero combination `α V_a+β V_b` has intake label-span dimension
   at least 8.  Across the 140 support cases for the 28 pairs, 56 have
   dimension 8 and 84 dimension 9.  Every such support pairs nontrivially
   with every singleton port label: all 13,440 binary rank-one checks pass.

The case lists are exhaustive over **real** coefficients: a coordinate of
`u−r v` can vanish only at one of the finitely many exact ratios `u[t]/v[t]`;
all other nonzero r have the same support.  The two endpoints with one
coefficient zero are checked separately.  Since the values are rational,
the exceptional ratios and a generic representative are exactly
computable using integers and `Fraction`.

For the proof, on the nondegenerate nine-dimensional binary label space,
if the output support and the intake support each span at least 8
dimensions, their pairing has rank at least `8 − (9−8) = 7`.  The
exceptional singleton output has pairing rank exactly 1 by fact 2.  Adding
or removing the gauge coordinate cannot reduce any other output below
dimension 8, by fact 1.  The actual first increment of a shared pair is,
away from p, a one- or two-basis output, so the same lower bound applies.

If the singleton Abel row is **not first**, the eight non-singleton output
increments each cost at least 7 and the singleton output costs 1; total at
least 57.  If it **is first**, its actual increment is a one-basis output
away from p, so all nine increments cost at least 7; total at least 63.
These conclusions are support statements over the reals, and therefore
include all rational instances of the pinned model.  For a legal cold-intake
chain, #7869's chain law makes the sum a lower bound on R.

## Witness, controls, and finite sweep

`replay.py` constructs the unit gauge `p=0,a=0,b=1` with ordered shared
pair `(0,8)` and `r=1`.  It feeds every INIT, nested MOVE, ADD, and CLEAR to
the copied rational engine.  The engine reports no illegal operations or
pinned errors across 1,306 operations, and exact full completion.  Its nine
epoch prices are `[7,1,7,7,7,7,7,7,7]`, with 57 ascents.  A negative
control that substitutes the Abel tail `W_0` for the increment `W_0−W_8`
breaks 22 odd cells, including `(0,0)`.

As a distinct positive distinction control, the same verifier constructs a
Q5 two-epoch R2 target on labels `[1,2,7,11,13]`.  It replays a valid
rational run with **R=2**, while the two Abel-row prices sum to **3** and
the epoch prices to **2**.  Independently enumerating possible supports
shows no one- or two-positive-price-row decoder can have total mass ≤2;
the two Abel rows give mass ≤3, so this nonidentity target has mass exactly
3 over Q.  This control is not an identity target and is not extrapolated
to Q96.

The separate direct `sweep.py` enumerates all 96 singleton ports, all 28
column pairs for the fixed `α=β=1` gauge, and all 72 ordered shared pairs.
For every pair it enumerates all distinct supports of `W_i−rW_j`; it checks
521,412 support cases with minimum 57.  The minimum for 2,043 of the 2,688
gauges is 57 and for 645 it is 58.  Three complete gauges cross-check its
bit-mask acceleration against direct vector arithmetic and binary Gaussian
elimination.  This sweep is a regression check; the wider arbitrary-α,β
bound is the proof above, not a claim that the 2,688 unit gauges exhaust it.

## Replay

From this directory, Python 3.10+ with no third-party packages:

```
python3 -B verify.py
python3 -B verify.py --census
```

The first command checks the packet manifest and reruns the general support
proof, fixed-gauge checks, Q5 control, and engine replay against the recorded
evidence.  The second additionally reruns the 521,412-case unit-gauge
census.  The commands also work when the packet directory is moved and the
script is invoked by path from another working directory.

The individual checks can also be run directly:

```
python3 -B general_bound.py
python3 -B check.py
python3 -B replay.py
python3 -B sweep.py
```

Recorded results are in `evidence/`. Assertions check the source identity,
vector equations, supports, fields, rank facts, Q5 obstruction, and the
replayed target and legality. `SHA256SUMS` lists every packet file except
itself; it is a file-consistency manifest, not an independent signature of
the upstream commits. `NOTICE.md` identifies the unchanged upstream source;
the original notices are preserved alongside it, and `LICENSE` contains the
Apache-2.0 license text.
