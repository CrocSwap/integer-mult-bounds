# Chart-339 helper-quotient separator

For the pinned #7830 rational native word, surrendering any combination of helper owners 21, 320 and 151 cannot repair the deletion of paid slot `92032` by changing only the three immediate chart-339 reader forms. Even if **all three** readers are allowed arbitrary rational-linear forms of the two surviving arrivals, a protected main terminal changes on an input with all three helpers zero. This is a fixed-tape, arbitrary-native-input separator. It is not a theorem about every changed caller or an exclusion of repairs using other routes or changed operations.

[PR #7877](https://github.com/CrocSwap/integer-mult-bounds/pull/7877) separately establishes the rank-144 image of the original three arrivals under the actual 48-call caller, using a fresh-helper subspace. The result here is different: it computes the full native input pullbacks and terminal adjoints, and exhibits a **main-only** pulse. The isolated pulse has not been shown to be an isolated attainable input in the closed caller. It is nevertheless required by the inherited arbitrary-column native contract. Neither statement turns scalar information rank into a geometric tariff.

## The fixed tape and the main-only pulse

In the arrival order `A=(92034,92035,92032)`, the slots and their immediate readers are:

| Slot | Route | Grade | Native clock |
| --- | --- | ---: | ---: |
| 92034 | 333 → 339 | 1 | 2024 |
| 92035 | 333 → 339 | 1 | 2157 |
| 92032 | 50 → 339 | 2 | 1482 |
| 98755 | 339 → 840 | 3 | 2755 |
| 89065 | 339 → 234 | 1 | 2895 |
| 92041 | 339 → 823 | 3 | 2896 |

There are no initial fields at chart 339 and the three arrivals are its only paid deposits. Its readers have respective values `A1+4A3`, `−4A2+4A3` and `−A1+A2−4A3`. On the native input with `x54=4` and all other 1,288 coordinates zero, independent exact forward propagation gives `A=(0,0,1)`. Input 54 and terminal 40 are both main coordinates in the retained physical-port layout. Thus zeroing or deleting the 92032 value changes the three reader values from `(4,4,−4)` to `(0,0,0)`. Replacing each reader by any linear combination of the two surviving arrivals also returns zero on this input.

The original terminal 40 is `x40−x152`, hence zero on the pulse. Exact forward propagation from an injected unit at each reader gives terminal-40 adjoints `(-4, 7/4, -4)` respectively. Therefore the adjoint of slot 92032 at terminal 40 is

```text
4*(-4) + 4*(7/4) - 4*(-4) = 7.
```

With the arrival removed, terminal 40 is `−7` on the pulse, with or without the allowed reader recodings. Its lost input-54 coefficient is `−7/4`. The verifier checks its **entire 1,289-entry input row** before and after deletion and for a nontrivial three-reader recoding control; it also checks the full 1,289-entry arrival forms, not just the displayed pulse. In general the changed terminal-40 row differs from the original by `−7 A3 + c1 A1 + c2 A2` for some rational `c1,c2`; the pulse kills the last two terms.

The full terminal adjoint of 92032 has 309 nonzero entries: 82 main and 227 helper coordinates. Its explicit coefficient list is in [RESULT.json](RESULT.json). The script independently checks all 1,289 terminal differences on the main pulse against the negative adjoint. A second forward control checks the prior helper pulse `(x21,x320,x151)=(4,0,16)`, whose arrival image is `(0,0,1)` and whose original terminals are exactly the same helper combination.

The result does not rely on retaining that helper pulse in the input domain. In fact, all of the following three **main** input columns lie outside the proposed helper space, and their exact arrival minor has nonzero determinant:

```text
               x40   x54   x772
  slot 92034   1/2     0      2
  slot 92035     0     0   -1/2
  slot 92032     0   1/4   -1/2

determinant = 1/16
```

## Endpoint and lifecycle check

The layout classifies 21, 320 and 151 as distinct fresh helper owners, with source labels 21, 334 and 151. They all start in chart 3 with empty frame and end in chart 127 with frame `[1,2,4,8,16,32,64,128,256]`. Their respective terminal clocks are 5728, 6027 and 5858. Exact backward expansion on all 1,289 native inputs gives `y21=x21`, `y320=x320` and `y151=x151`. Every paid move precedes every terminal row, and no terminal output slot is subsequently read by the tape. The source application receipt reports immutable entry banks, deferred terminal banks and 1,289 same-owner final installs.

For a concrete algebraic section of the proposed `(4,0,16)` surrender, write `x21=z21+4t`, `x151=16t` and set `t=0`. At the endpoint retain `y21−y151/4` and `y320`, and drop `y151`. The same endpoint chart and final frame make the scalar basis comparison meaningful, but **do not themselves certify** a legal physical basis conversion, owner lifecycle or changed compiler. The main-only pulse keeps `t` and all other helper coordinates zero, so it already disproves the restricted repair before such a conversion is needed.

For this explicit algebraic section, the script traces literal syntactic dependencies from the retained terminal forms after omitting 92032. The original has all 5,707 paid slots syntactically live; exactly slot 92032 becomes unreachable, while 92034, 92035 and all three readers remain reachable. This is a dead-stock census for that literal relaxed edit, not a global semantic-minimization theorem. The edit fails the protected main terminal and is **not** a valid changed word.

## Signed accounting

For `H(r)=r^(1−κ)`, dropping one grade-9 productive helper target per call while deleting the one grade-2 paid slot changes the signed productive-minus-paid moment by `48(H(2)−H(9))`. These are physical endpoint and slot grades, not inferred prices for scalar rank. At `κ=0.003884928046155`, directed arithmetic gives

```text
48(H(9)−H(2)) in
[332.586279983722531773436881545899754819543382655,
 332.586279983722531773436881545899754819543382656].
```

Using all bins of the original 48-call rational invoice, its margin is approximately `−4.88039108995`; the illustrative arithmetic after those two removals and assuming no other bill changes is approximately `−337.46667107368`. This is only the price of the explicitly stated, already-invalid change. It is not the invoice of a physically realized quotient and does not rule out an altered tape that eliminates additional paid slots or changes other bills. The result file also reports the directed calculation at `κ=0.003879929046155`.

## Reproduce and source

Run using Python 3.11 or later; the standard library is sufficient:

```sh
python3 -I -B verify.py
```

The offline replay authenticates the three retained source exports by fixed SHA-256 and Git blob IDs, verifies the canonical word, layout and caller pins, and checks all 220,217 original local reads for chart co-residence and chronology. It expands arrival and protected terminal forms on all 1,289 native inputs, independently propagates all terminal adjoints and two pulse controls, inventories the explicit literal quotient's syntactically reachable paid slots, and recomputes the two directed 48-call invoice comparisons. It compares the new machine-readable result to [RESULT.json](RESULT.json). It authenticates the retained #7877 pullback receipt for context; it does **not** rerun that PR's full caller replay. These computational controls are not an independent human review.

The word, layout and application are those of [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; exact export locations and blob hashes are in [SOURCE-LOCK.json](SOURCE-LOCK.json). The five inherited premises `native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery` remain. No reverse execution, dirty-spectator, changed-owner, physical precision or changed-caller proof is claimed.
