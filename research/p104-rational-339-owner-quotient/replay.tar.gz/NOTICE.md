# Attribution

The selected #7830 rational word and complete 48-call application are by Clear1nsight with OpenAI Codex assistance. They build on #7786/#7781, Ali Romman's #7776 carrier, tariff and caller, and #7774's restored chain. Exact predecessor paths, compressed SHA-256 and Git blob identifiers are in SOURCE-LOCK.json. The three input files are retained unmodified.

The context receipt PR7877-PULLBACK-RESULT.json is retained from the replay package of Clear1nsight's #7877 chart-339 pullback, prepared with OpenAI Codex assistance. This work uses its pinned source and helper pulse but adds a separate fixed-tape main-only quotient separator and accounting.

The directed arithmetic in common.py is retained from the #7877 predecessor package, with its Apache-2.0 header. This separator and its computational checks were prepared with OpenAI Codex assistance. See LICENSE.
