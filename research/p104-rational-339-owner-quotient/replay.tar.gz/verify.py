#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Exact fixed-tape chart-339 quotient separator; standard-library offline replay."""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha1, sha256
from pathlib import Path
import gzip
import json
import sys
import time

START=time.process_time()
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from common import enclose, margin
ARR=(92034,92035,92032)
READ=(98755,89065,92041)
AXES=(21,320,151)
FROZEN_WORD='7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
FROZEN_LAYOUT='f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7'
FROZEN_CALLER='156fdf3a4a129b39225fd6ca51011de27974d7f104e8b04907c17ed5344bc858'

def canon(v):
    return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
def digest(v):
    return sha256(v).hexdigest()
def load(path):
    raw=(HERE/path).read_bytes()
    return json.loads(gzip.decompress(raw) if path.endswith('.gz') else raw)
def add_scaled(dst,src,s):
    for i,c in src.items():
        z=dst.get(i,Q(0))+s*c
        if z: dst[i]=z
        else: dst.pop(i,None)
def str_sparse(row):
    return {str(i):str(row[i]) for i in sorted(row)}
def dense_hash(row,n):
    return digest(canon([str(row.get(i,Q(0))) for i in range(n)]))
def det(m):
    return (m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])
            -m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])
            +m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]))

# Authenticate the exact public exports and their retained Git blob IDs.
locks=load('SOURCE-LOCK.json')
pins={
 'inputs/DOUBLE-APPLICATION.json':('1b2d87e93ae023f5ffd464546af53281b6cb4963dfd76ae4742e0a5540b752fa','714f7b48a2a70bb2cc9f7cd4206b2a8701bbb062'),
 'inputs/DOUBLE-CANDIDATE.json.gz':('1b1b3294e86979f1f41076fb056f3c0a08ace6df7bf80f2886bc579a22962f4b','51ac72e499cdf6efac62cbd34a9f217d6d135b14'),
 'inputs/LAYOUT.json.gz':('b0f3ebc5710e469f3e8fc5ce159cbba048b563944182b50993431ef94f4fedbf','35af1c9e36953cd223eadfca734e122792703de8'),
}
assert len(locks)==3 and {entry['file'] for entry in locks}==set(pins)
for entry in locks:
    raw=(HERE/entry['file']).read_bytes()
    sha,blob=pins[entry['file']]
    assert digest(raw)==entry['sha256']==sha
    assert sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==entry['git_blob']==blob
reference_path=HERE/'PR7877-PULLBACK-RESULT.json'
assert digest(reference_path.read_bytes())=='062af5641792e5034905188190673d0ca0937be7142d16da47ea07becf667c38'
reference=load('PR7877-PULLBACK-RESULT.json')
assert reference['word_sha256']==FROZEN_WORD and reference['caller_stream_sha256']==FROZEN_CALLER
assert reference['all_calls_row_rank']==144 and reference['binding']['calls']==48
g=load('inputs/DOUBLE-CANDIDATE.json.gz')
layout=load('inputs/LAYOUT.json.gz')
app=load('inputs/DOUBLE-APPLICATION.json')
assert digest(canon(g))==FROZEN_WORD==app['word_sha256']
assert digest(canon(layout))==FROZEN_LAYOUT==app['layout_sha256']
assert app['caller']==FROZEN_CALLER and app['caller_census']['calls']==48
assert app['caller_proof']['readback']['op_counts']['NATIVE']==48
assert g['frames']==layout['frames']
n=len(g['initial']); first=g['first_output']; assert n==len(g['final'])==1289
forms={i:{k:Q(q) for k,q in row} for i,row in g['forms']}
moves={i:(a,b) for i,a,b in g['moves']}
order=g['schedule']; at={i:t for t,i in enumerate(order)}
assert len(moves)==5707 and len(forms)==len(order)==len(at)==6996

# Audit the unmodified tape's explicit co-residence and chronology of each read.
source={i:a for i,(a,b) in moves.items()}|{first+i:c for i,c in enumerate(g['final'])}
deposit={~i:c for i,c in enumerate(g['initial'])}|{i:b for i,(a,b) in moves.items()}
terms=0
for i in order:
    for k,q in forms[i].items():
        assert q and k in deposit and source[i]==deposit[k]
        assert k<0 or at[k]<at[i]
        terms+=1
assert terms==220217
# All terminal forms read their charts only after every paid move; terminal
# output slots are never themselves sources for another form.
assert max(at[i] for i in moves)<min(at[first+i] for i in range(n))
assert all(k<first for row in forms.values() for k in row)
assert [moves[i] for i in ARR]==[(333,339),(333,339),(50,339)]
assert [at[i] for i in ARR]==[2024,2157,1482]
assert [at[i] for i in READ]==[2755,2895,2896]
assert sorted(i for i in moves if moves[i][1]==339)==sorted(ARR)
assert all(c!=339 for c in g['initial'])
assert [i for i in order if any(k in forms[i] for k in ARR)]==list(READ)
assert all(set(forms[i])<=set(ARR) for i in READ)
reader_matrix=[[forms[i].get(k,Q(0)) for k in ARR] for i in READ]
assert reader_matrix==[[Q(1),Q(0),Q(4)],[Q(0),Q(-4),Q(4)],[Q(-1),Q(1),Q(-4)]]
assert det(reader_matrix)==-4

def back(target,omit=False,replace=None):
    """Expand one row onto every one of the n independent native inputs."""
    pending={target:Q(1)}
    for i in reversed(order):
        v=pending.pop(i,Q(0))
        if not v: continue
        if omit and i==92032: continue
        form=(replace or {}).get(i,forms[i])
        add_scaled(pending,form,v)
    assert all(k<0 for k in pending)
    return {~k:v for k,v in pending.items()}

def forward(seed,omit=False,replace=None):
    """Inject arbitrary input or one forced node and propagate the whole tape."""
    values=dict(seed)
    for i in order:
        if i in values: continue
        if omit and i==92032: continue
        form=(replace or {}).get(i,forms[i])
        z=sum((q*values.get(k,Q(0)) for k,q in form.items()),Q(0))
        if z: values[i]=z
    return values

def terminal(v):
    return {i:v[first+i] for i in range(n) if first+i in v}

# Classify physical caller main inputs from the retained native layout.
hosted=layout['hosted']
second=dict(zip(hosted['Dports'],zip(hosted['X2'],hosted['Y2'],strict=True),strict=True))
slots={p:(x,x+112)+second.get(p,()) for p,x in enumerate(layout['live'])}
mains={r for z in slots.values() for r in z}
helpers=set(range(n))-mains
assert len(mains)==400 and len(helpers)==889 and set(AXES)<=helpers
assert {40,54,772}<=mains
assert [layout['source_labels'][i] for i in AXES]==[21,334,151]
assert all(g['initial'][i]==3 and g['frames'][3]==[] for i in AXES)
assert all(g['final'][i]==127 for i in AXES)
assert g['frames'][127]==[1,2,4,8,16,32,64,128,256]
assert app['native']['all_public_inputs_preserved_until_final_installs']
assert app['native']['same_owner_complete_fixture_outputs']==n
assert app['native']['immutable_entry_banks']==app['native']['deferred_terminal_banks']==n

# All 1,289 arbitrary native-input coefficients of the three arrivals.
arrival_rows=[back(i) for i in ARR]
helper_terminal_rows=[back(first+i) for i in AXES]
assert helper_terminal_rows==[{i:Q(1)} for i in AXES]
assert [len(r) for r in arrival_rows]==[233,17,31]
helper_minor=[[r.get(i,Q(0)) for i in AXES] for r in arrival_rows]
assert helper_minor==[[Q(1),-Q(1,2),-Q(1,4)],
                      [Q(0),Q(1,2),Q(0)],[Q(0),Q(1,2),Q(1,16)]]
assert det(helper_minor)==Q(1,32)
# Three protected main columns outside the proposed helper surrender already
# make all three arrivals independent; a helper-only input quotient cannot
# remove this 3x3 minor.
main_axes=(40,54,772)
main_minor=[[r.get(i,Q(0)) for i in main_axes] for r in arrival_rows]
assert main_minor==[[Q(1,2),Q(0),Q(2)],[Q(0),Q(0),-Q(1,2)],
                    [Q(0),Q(1,4),-Q(1,2)]]
assert det(main_minor)==Q(1,16)

# The exact terminal adjoints are propagated independently in a forward pass.
adj_read=[terminal(forward({i:Q(1)})) for i in READ]
adj_cut=terminal(forward({92032:Q(1)}))
assert len(adj_cut)==309 and adj_cut[40]==7
combo={}
for row,c in zip(adj_read,(Q(4),Q(4),Q(-4)),strict=True): add_scaled(combo,row,c)
assert combo==adj_cut
assert [r.get(40,Q(0)) for r in adj_read]==[Q(-4),Q(7,4),Q(-4)]
assert len(set(adj_cut)&mains)>0

# All input coefficients of protected main output 40, both before and after
# the literal deletion. The reader recode control uses all three exit rows.
original=back(first+40)
cut=back(first+40,omit=True)
assert original=={40:Q(1),152:Q(-1)}
expected=original.copy(); add_scaled(expected,arrival_rows[2],Q(-7))
assert cut==expected
recoded={98755:{92034:Q(1),92035:Q(2)},
         89065:{92034:Q(3),92035:Q(-1)},
         92041:{92034:Q(-2),92035:Q(4)}}
rec=back(first+40,omit=True,replace=recoded)
# Reader adjoint j=(-4,7/4,-4). Changed output is input40-input152 plus
# (-4*a1+7*a2/4-4*a3)*A1 + (-4*b1+7*b2/4-4*b3+11)*A2 -7*A3.
expected_recode=original.copy()
add_scaled(expected_recode,arrival_rows[0],Q(-4)+Q(21,4)+Q(8))
add_scaled(expected_recode,arrival_rows[1],Q(-8)-Q(7,4)-Q(16)+Q(11))
add_scaled(expected_recode,arrival_rows[2],Q(-7))
assert rec==expected_recode
assert cut.get(54)==rec.get(54)==Q(-7,4) and original.get(54,Q(0))==0

# Main-only counterexample, independent of whether the surrendered helper
# direction remains an input. A pulse of 4 may be scaled to the inherited grid.
probe={~54:Q(4)}
v0=forward(probe); v1=forward(probe,omit=True); v2=forward(probe,omit=True,replace=recoded)
assert [v0.get(i,Q(0)) for i in ARR]==[0,0,1]
assert [v0.get(i,Q(0)) for i in READ]==[4,4,-4]
assert [v1.get(i,Q(0)) for i in READ]==[0,0,0]
assert [v2.get(i,Q(0)) for i in READ]==[0,0,0]
assert [v.get(first+40,Q(0)) for v in (v0,v1,v2)]==[0,-7,-7]
for i in range(n):
    assert v1.get(first+i,Q(0))-v0.get(first+i,Q(0))==-adj_cut.get(i,Q(0))

# The original #7877 helper e3 pulse is included as a second forward control;
# the main-only pulse above remains valid under an actual helper input quotient.
h=forward({~21:Q(4),~151:Q(16)})
assert [h.get(i,Q(0)) for i in ARR]==[0,0,1]
assert terminal(h)=={21:Q(4),151:Q(16)}

# Conservative syntactic dead-stock inventory for one explicit algebraic
# quotient/section: x21=z21+4t, x151=16t, set t=0, retain y21-y151/4,
# drop y151. This does not assert that the changed tape is valid or that a
# separate optimizer cannot find more eliminations.
combined=forms[first+21].copy(); add_scaled(combined,forms[first+151],-Q(1,4))
def reachable(changed):
    roots=list(range(first,first+n))
    if changed: roots.remove(first+151)
    seen=set(); todo=roots[:]
    while todo:
        i=todo.pop()
        if i<0 or i in seen or (changed and i==92032): continue
        seen.add(i)
        row=combined if changed and i==first+21 else forms[i]
        todo.extend(k for k in row if not(changed and k==~151))
    return seen
old,new=reachable(False),reachable(True)
lost=sorted((old-new)&set(moves))
assert len(old & set(moves))==5707 and lost==[92032]
assert all(i in new for i in (92034,92035,*READ))

# Reprice the entire retained 48-call source invoice, not scalar rank.
paid=Counter({int(k):v for k,v in app['application']['invoice']['paid'].items()})
targets=Counter({int(k):v for k,v in app['application']['invoice']['targets'].items()})
assert sum(paid.values())==283152 and sum(targets.values())==52512
assert app['native']['positive_helper_ranks']['9']==532
assert app['caller_census']['fixed_root_targets']['9']==480
assert targets[9]==48*532+480
assert abs(len(g['frames'][moves[92032][0]])-len(g['frames'][moves[92032][1]]))==2
assert all(len(g['frames'][g['final'][i]])-len(g['frames'][g['initial'][i]])==9 for i in AXES)
changed_paid=paid.copy(); changed_paid[2]-=48
changed_targets=targets.copy(); changed_targets[9]-=48
prices={}
for k in ('0.003884928046155','0.003879929046155'):
    debit=margin(Counter({2:48}),Counter({9:48}),k)
    assert debit[0]>0
    prices[k]={
      'H2':enclose(margin(Counter(),Counter({2:1}),k)),
      'H9':enclose(margin(Counter(),Counter({9:1}),k)),
      'debit_48_H9_minus_H2':enclose(debit),
      'original_full_invoice_margin':enclose(margin(paid,targets,k)),
      'illustrative_invalid_cut_and_target_removed_margin':enclose(margin(changed_paid,changed_targets,k)),
    }

report={
 'scope':'Fixed native tape outside chart-339 exit-form recoding; arbitrary rational native inputs. This is a separator, not a physical candidate or changed-caller theorem.',
 'source':{'pr_7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','word':FROZEN_WORD,
           'layout':FROZEN_LAYOUT,'caller':FROZEN_CALLER,
           'related_pr_7877':'https://github.com/CrocSwap/integer-mult-bounds/pull/7877',
           'caller_calls_from_source_receipt':48},
 'chronology':{'arrivals':list(ARR),'arrival_clocks':[at[i] for i in ARR],
               'readers':list(READ),'reader_clocks':[at[i] for i in READ],
               'reader_forms':[[str(q) for q in row] for row in reader_matrix],
               'all_local_reads_checked':terms},
 'owner_binding':{'helper_indices':list(AXES),'helper_source_labels':[layout['source_labels'][i] for i in AXES],
    'main_witness_input':54,'main_protected_output':40,
    'helper_initial_chart':3,'helper_initial_frame':g['frames'][3],
    'helper_final_chart':127,'helper_final_frame':g['frames'][127],
    'helper_terminal_clocks':[at[first+i] for i in AXES],
    'all_paid_moves_precede_every_terminal_form':True,
    'terminal_outputs_are_not_tape_sources':True,
    'same_owner_deferred_install_from_source_receipt':True,
    'helper_basis_legal_at_boundaries_only_if_separately_compiled':True},
 'all_input_pullback':{'dimension':n,'nonzero_coefficients':[len(r) for r in arrival_rows],
    'arrival_full_rows':[str_sparse(r) for r in arrival_rows],
    'helper_terminal_full_rows':[str_sparse(r) for r in helper_terminal_rows],
    'arrival_dense_sha256':[dense_hash(r,n) for r in arrival_rows],
    'helper_minor':[[str(q) for q in row] for row in helper_minor],
    'helper_minor_determinant':str(det(helper_minor)),
    'outside_helpers_main_minor_axes':list(main_axes),
    'outside_helpers_main_minor':[[str(q) for q in row] for row in main_minor],
    'outside_helpers_main_minor_determinant':str(det(main_minor)),
    'original_output40_all_inputs':str_sparse(original),
    'after_literal_cut_output40_all_inputs':str_sparse(cut),
    'after_recode_control_output40_all_inputs':str_sparse(rec)},
 'terminal_adjoint':{'cut_nonzero':len(adj_cut),'cut_main_nonzero':len(set(adj_cut)&mains),
    'cut_helper_nonzero':len(set(adj_cut)&helpers),'cut_full_row':str_sparse(adj_cut),
    'reader_at_output40':[str(r.get(40,Q(0))) for r in adj_read],
    'identity':'adj(92032) = 4 adj(98755) + 4 adj(89065) - 4 adj(92041)',
    'cut_at_output40':str(adj_cut[40]),'cut_dense_sha256':dense_hash(adj_cut,n)},
 'main_only_forward_probe':{'input':{'54':'4'},'arrivals':['0','0','1'],
    'readers_original':['4','4','-4'],'readers_deleted_or_recoded':['0','0','0'],
    'output40_original':'0','output40_deleted_or_recoded':'-7',
    'all_1289_terminal_differences_equal_negative_cut_adjoint':True,
    'isolated_main_pulse_reachability_in_closed_caller_claimed':False},
 'helper_control':{'input':{'21':'4','151':'16'},'arrivals':['0','0','1'],
    'original_terminal':{'21':'4','151':'16'}},
 'specified_literal_quotient_dead_stock':{'algebraic_section':'x21=z21+4t; x151=16t; t=0',
    'retained_terminal':'y21-y151/4','surrendered_terminal':'y151',
    'baseline_syntactically_live_paid':5707,'paid_slots_lost':lost,
    'remaining_chart_339_paid_slots':[92034,92035,98755,89065,92041],
    'not_a_global_dead_code_or_physical_legality_claim':True},
 'price':{'saved_paid_per_call':{'slot':92032,'grade':2},
    'surrendered_productive_per_call':{'count':1,'grade':9},
    'calls':48,'other_changed_bills_assumed_zero_in_illustration':True,
    'intervals':prices},
 'remaining_limits':['No changed valid physical word, reverse execution, dirty-spectator, precision or erasure replay is asserted.',
    'A physically legal owner basis transformation has not been compiled; endpoint co-residence alone does not prove one.',
    'The main-only native pulse has not been shown reachable as an isolated closed-caller input.',
    'A repair adding routes, changing upstream or downstream operators, or changing the caller is outside scope.',
    'The structural dead-stock tally is for the stated literal edit, not every possible optimized word.',
    'The arithmetic price illustration is not a candidate invoice or a kappa bound.']}
path=HERE/'RESULT.json'
if '--write' in sys.argv[1:]: path.write_text(json.dumps(report,indent=2)+'\n')
else: assert load('RESULT.json')==report, 'receipt mismatch'
print('PASS source blobs, canonical word, layout, caller receipt and 220217 original local reads')
print('PASS all 1289 input coefficients; 3 protected-main-column arrival minor determinant 1/16')
print('PASS full 1289 terminal adjoints; protected output 40 cut coefficient -7/4 on input 54')
print('PASS main-only pulse: retained arrivals 0, deleted arrival 1, protected output 0 -> -7')
print('PASS literal structural paid removal and directed full 48-call price illustration')
print('CPU seconds',round(time.process_time()-START,3))
