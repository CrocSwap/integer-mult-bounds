# First-reader stock limits for direct BIT receipts

Two exact finite screens concern the same pinned #7830 binary word at
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The original primitive source is
`89a67c404226d51028e135de2b9169e9020d57af`. Its canonical and compressed
hashes are in the source receipt and checked by both replays.

## Replacing an unread cohort with no extra receipts

For a receiver bank and an original first read deadline, collect all its old
paid receipts that have arrived strictly earlier but have not yet played a
role in any paid equation or final output. Omit protected packet 3553 and
the forward chart-1 / adjoint chart-0 central bank from this census.
Hold all other paid equations, observable uses and clock constraints fixed.
Grant free historical retention of every original other stock value.
Allow replacing any selected unread arrivals with no more new scalar
receipts than were removed. Each replacement may come from any original
nested chart using any earlier source combination. The receiver must
reconstruct the old demanded combinations at that same deadline.
This is an optimistic packet model, prior to resource and primitive checks.

Write S for the receiver's retained prefix, D for the span modulo S of
the restricted coefficients of every later original consumer on the
omitted coordinates, and U_a for each donor's strict-preclock prefix.
No omitted receipt influenced those donors by this deadline, by the
definition of unread. A donor's possible directions in D are the image
of U_a intersected with the preimage of D modulo S. The script computes
this intersection by eliminating the coordinates outside that preimage,
carrying tags that identify both the source XOR and its demand coordinates.
Every chosen row can therefore be traced to the actual source history.

In a full-rank cohort with n omitted arrivals, any reconstruction with at
most n new rows must use exactly n independent quotient rows, each in D.
Because every independent contribution from a given bank has the same
grade, scanning donor spaces in increasing grades gives a minimum-price
basis by the greedy linear matroid rule. At every grade threshold this
greedy construction realizes the full rank of all directions available
up to that threshold. Thus its sorted grade vector is minimal at every
position for any increasing grade price. A candidate for a subset would
extend to a solution for the maximal census cohort by keeping every unedited
arrival. The common clock and actual fixed source history ensure that this
extension collects all simultaneously unread candidates.

The scan checks 838 forward cohorts and 1,211 adjoint cohorts, with cohort
sizes up to 15. All 2,040 full-demand-rank cases have exactly the incumbent
optimal grade profile. The remaining nine adjoint cases have three old
grade-one rows and rank-two demand. No two rows in D can span it even
using all nested donors. Three rows cost at least three, so any solution
using three rows cannot improve. The replay records attainable controls
with original sender labels and the actual old consumer rows. Cofactors
outside the cohort, arbitrary new geometry, differing readouts, changed
timing of retained equations and taking more paid receipts than omitted
require separate models.

## One omitted packet, two direct receipts

A separate whole-word census allows paying for **more** direct receipts,
for one narrower family. At each old nonprotected grade-three through
grade-six packet P, omit P, keep all remaining packet payloads and routes
fixed, and allow two additional direct scalar receipts from distinct
nested original donor charts into the same receiver. Both senders may
use all original values strictly before the first paid or terminal reader
of P. Free retention and local XOR are granted even when a physical word
would be stricter. Require recovering the original scalar value P by this
first reader. An actual earlier affected read or lifecycle can only
reduce the legal options.

For H(g) = g^(1−κ) and 0 < κ < 1, two positive grades a and b satisfy
H(a)+H(b) > H(a+b). Thus any strictly improving pair has a+b < grade(P).
Every such distinct pair with nonzero donor quotient stock is tested.
The necessary and sufficient local stock condition in this granted model
is that the image of P modulo old receiver stock lie in the sum of the
two donor spaces. A separate low-pivot implementation carries the tags.
The screen tries 67,565 forward and 30,092 adjoint pairs and finds zero
span hits. A donor with zero image cannot add independent information.
This census excludes two nonzero different-chart contributors under its
declared hypothesis. It does not constrain arbitrary changed surviving
stock, new intermediate charts, terminal redecoding in place of preserving
P, or three or more added receipts.

These tests preserve the productive invoice in their models. They prove
no positive changed native word and no new κ bound. #7985 changes terminal
decoders for two omissions and includes particular early terminal carriers.
#7953 fixes exterior stock for the central chart-1 matching problem.
#7983 keeps the original incidences for rational regrading. The present
proof keeps the original chronologically unread receiver cohorts or the
specific old first-reader payloads.

Run in a clean extraction with Python 3.12:

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```
