"""Regenerate the four source-bound cohort and donor-pair receipts."""
import subprocess
from pathlib import Path
import sys
import tempfile
if not __debug__:
    raise SystemExit('Run with assertions enabled.')
root=Path(__file__).resolve().parent
targets=[
    ('cohort.py','FWD-COHORT.json',[]),
    ('cohort.py','REV-COHORT-WIDE.json',['--reverse','--rank-two-wider']),
    ('two_receipts.py','FWD-TWO-RECEIPTS.json',[]),
    ('two_receipts.py','ADJ-TWO-RECEIPTS.json',['--reverse']),
]
with tempfile.TemporaryDirectory() as tmp:
    for script,expected,flags in targets:
        candidate=Path(tmp)/expected
        subprocess.run([sys.executable,'-I','-B',str(root/script),'--source',str(root),
                        '--out',str(candidate),*flags],check=True)
        if candidate.read_bytes()!=(root/expected).read_bytes():
            raise RuntimeError(expected+' differs')
print('PASS pinned unread cohort and two-receipt screens')
