#!/usr/bin/env python3
"""Cost of replacing unread paid receipt cohorts by a nested basis at their first read."""
from __future__ import annotations

import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
from decimal import Decimal
from functools import cache
from itertools import combinations_with_replacement
import json
from pathlib import Path
import sys

import hashlib

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, required=True)
parser.add_argument('--reverse', action='store_true')
parser.add_argument('--include-central', action='store_true')
parser.add_argument('--rank-two-wider', action='store_true')
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.source))
import network as n
from two_hole import grade

K = Decimal('0.00388')
TERMINAL = max(n.CLOCK.values()) + 1
PUBLIC = n.W['public']
direction = 'adjoint' if args.reverse else 'forward'

if args.reverse:
    payload, routes, eq = n.Y, n.DR, n.DROWS
    chart = n.W['final']
    clocks = {k: TERMINAL - t for k, t in n.CLOCK.items()}
else:
    payload, routes, eq = n.X, n.R, n.ROWS
    chart = n.W['start']
    clocks = n.CLOCK

vectors = {**{i: 1 << i for i in range(PUBLIC)}, **payload}
groups = defaultdict(list)
history = defaultdict(list)
for i, c in enumerate(chart):
    history[c].append((-1, i))
for p in sorted(routes, key=clocks.__getitem__):
    _, b = routes[p]
    groups[b].append(p)
    history[b].append((clocks[p], p))

uses = defaultdict(list)
for slot, expression in eq.items():
    for p in n.labels(expression):
        if p in routes:
            uses[p].append(slot)

def read_clock(slot):
    return clocks[slot] if slot >= 0 else TERMINAL+1

first = {p:min(map(read_clock, uses[p]), default=TERMINAL+1) for p in routes}


class Basis:
    """High-pivot GF(2) elimination, with a linear tag carried with each row."""
    def __init__(self):
        self.rows = {}

    def reduce(self, bits, tag=0):
        remaining = 0
        while bits:
            p = bits.bit_length()-1
            if p not in self.rows:
                z = 1 << p
                bits ^= z
                remaining |= z
            else:
                row, mark = self.rows[p]
                bits ^= row
                tag ^= mark
        return remaining, tag

    def add(self, bits, tag=0):
        bits, tag = self.reduce(bits, tag)
        if not bits:
            return False
        self.rows[bits.bit_length()-1] = bits, tag
        return True

    def __len__(self):
        return len(self.rows)


@cache
def before(c, t):
    h = history[c]
    return [p for _, p in h[:bisect_left(h, (t, -1))]]


@cache
def neighbors(b):
    return sorted((g, a) for a in history if a != b
                  and (g := grade(a, b)) is not None and g > 0)


def bare_rows(basis):
    return [r for r, t in basis.rows.values()]


def cost(grades):
    v = n.prices.ZERO
    for g in grades:
        v = n.prices.plus(v, n.prices.power(g, K))
    return v


def local_demand(cohort):
    cols = {p:1 << i for i, p in enumerate(cohort)}
    by_slot = defaultdict(int)
    for p in cohort:
        for r in uses[p]:
            by_slot[r] |= cols[p]
    image = Basis()
    for vector in by_slot.values():
        image.add(vector)
    return bare_rows(image), by_slot


def attainable(space, leaves, full_width):
    outside = Basis()
    for p in leaves:
        rem, value_tag = space.reduce(vectors[p])
        value_tag |= 1 << (p + full_width)
        rem, value_tag = outside.reduce(rem, value_tag)
        if rem:
            outside.rows[rem.bit_length()-1] = rem, value_tag
        elif direction_tag := value_tag & ((1 << full_width)-1):
            support = value_tag >> full_width
            assert space.reduce(n.xsum(vectors[y] for y in n.labels(support))) == (0,direction_tag)
            yield direction_tag, support


def minimum_nested_basis(b, t, existing, cohort, demand):
    standard = Basis()
    for p in existing:
        standard.add(vectors[p])
    for p in cohort:
        if not standard.add(vectors[p]):
            raise AssertionError(('original stock not independent',p))
    # Demand rows are the original uncoded scalar combinations of the cohort.
    space = Basis()
    for p in existing:
        assert space.add(vectors[p])
    for i, comb in enumerate(demand):
        row = n.xsum(vectors[cohort[j]] for j in n.labels(comb))
        assert space.add(row, 1 << i)
    chosen = Basis()
    actions = []
    donors = 0
    width = len(demand)
    if not width:
        return [], 0
    for g, a in neighbors(b):
        leaves = before(a,t)
        if not leaves:
            continue
        donors += 1
        assert all(p not in cohort for p in leaves)
        for c, support in attainable(space,leaves,width):
            if chosen.add(c):
                actions.append({'src':a, 'dst':b, 'grade':g, 'coefficients':c,
                                'source_labels': list(n.labels(support))})
                if len(chosen) == width:
                    return actions, donors
    return None, donors


def wider_rank_two(b, t, existing, cohort, demand):
    """Enumerate affordable donor triples and all rank-two decoder matrices."""
    assert len(cohort) == 3 and len(demand) == 2
    receiver = Basis()
    for p in existing:
        assert receiver.add(vectors[p])
    def quotient(v):
        return receiver.reduce(v)[0]
    want = tuple(quotient(n.xsum(vectors[cohort[j]] for j in n.labels(d))) for d in demand)
    x_bits = (1 << PUBLIC)-1
    all_decoders = [(u, v) for u in range(1, 8) for v in range(1, 8) if u != v]
    donors = []
    for g, a in neighbors(b):
        r = Basis()
        for p in before(a,t):
            r.add(quotient(vectors[p]), 1 << p)
        if len(r):
            donors.append((g,a,r))
    ordered_grades = [c[0] for c in donors]
    stats = Counter()
    old = cost(n.G[p] for p in cohort)
    by_price = Counter()
    for idx in combinations_with_replacement(range(len(donors)),3):
        grades = tuple(ordered_grades[i] for i in idx)
        worth = n.prices.minus(old, cost(grades))
        if worth[0] <= 0:
            assert worth[1] <= 0 or sorted(n.G[p] for p in cohort) == list(grades)
            continue
        by_price[grades] += 1
        selected = [donors[i] for i in idx]
        for u, v in all_decoders:
            # Form one 1360-bit direct sum for the two frozen demands.
            coeff = [((u >> j)&1)|(((v >> j)&1)<<1) for j in range(3)]
            # A zero column means at most two receipts, already excluded.
            if not all(coeff):
                continue
            stats['linear_systems'] += 1
            two_row = Basis()
            for j,(_,_,bank) in enumerate(selected):
                for row, support in bank.rows.values():
                    z = (row if coeff[j]&1 else 0) | ((row if coeff[j]&2 else 0) << PUBLIC)
                    tagged = support << (j*4096)
                    two_row.add(z, tagged)
            desired=want[0] | (want[1]<<PUBLIC)
            leftover, expressed=two_row.reduce(desired)
            if not leftover:
                pin = (1 << 4096)-1
                support = [list(n.labels((expressed >> (j*4096)) & pin)) for j in range(3)]
                forms = [quotient(n.xsum(vectors[p] for p in support[j])) for j in range(3)]
                for row, mask in zip(want,(u,v)):
                    assert n.xsum(forms[j] for j in n.labels(mask)) == row
                return {'hits':[{'banks':[x[1] for x in selected], 'grades':grades,
                                 'decoder': [u,v], 'support':support,
                                 'gain':n.prices.display(n.prices.scale(worth,36))}],
                        'counts':dict(stats)}
    return {'hits':[], 'counts':dict(stats), 'cheaper_grade_triples':[[list(g),i] for g,i in sorted(by_price.items())],
            'eligible_donors':len(donors)}


def main():
    counts = Counter()
    cohorts = Counter()
    fit = Counter()
    grade_pairs = Counter()
    examples = []
    positive = []
    deficient = []
    for b, ps in sorted(groups.items()):
        if not args.include_central and b == (0 if args.reverse else 1):
            continue
        eligible = [p for p in ps if p != 3553]
        for t in sorted({first[p] for p in eligible}):
            co = tuple(p for p in eligible if clocks[p]<t<=first[p])
            if len(co)<2:
                continue
            old = tuple(sorted(n.G[p] for p in co))
            if len(co)>64:
                print('WIDE',b,t,len(co),flush=True)
            base = [p for p in before(b,t) if p not in co]
            demand, reads = local_demand(co)
            cohorts[(len(co),len(demand))] += 1
            acts,attempts= minimum_nested_basis(b,t,base,co,demand)
            counts['tested_donors'] += attempts
            if acts is None:
                if len(demand)==len(co):
                    raise AssertionError(('original grades must be feasible',co))
                counts['rank_deficient_without_basis']+=1
                if args.rank_two_wider:
                    deficient.append({'bank':b,'time':t,'original':co,'old_grades':old,
                                      'result':wider_rank_two(b,t,base,co,demand)})
                continue
            new = tuple(a['grade'] for a in acts)
            fit[(len(co),len(demand))]+=1
            gain = n.prices.ZERO if new==old else n.prices.minus(cost(old),cost(new))
            grade_pairs[(old,new)]+=1
            assert gain[0] > 0 or gain[1] <= 0 or new==old, 'exact grade separation'
            rec = {'bank':b,'clock_limit':t,'old': co,'before_stock':base,
                   'demand_combinations':[list(n.labels(q)) for q in demand],
                   'first_use_readers':{str(r): [co[i] for i in n.labels(v)] for r,v in sorted(reads.items())},
                   'replacement':acts,'old_grades':old,'new_grades':new,
                   'margin_36_calls':n.prices.display(n.prices.scale(gain,36))}
            if len(examples)<8:
                examples.append(rec)
            if gain[0]>0:
                positive.append(rec)
                print('PRICE HIT',json.dumps(rec),flush=True)
    out={'source':n.public_source(), 'direction':direction,'rate':str(K),
         'central_included':args.include_central,'cohort_size_demand_rank':[[*k,v] for k,v in sorted(cohorts.items())],
         'fit_size_demand_rank':[[*k,v] for k,v in sorted(fit.items())],'stats':dict(counts),
         'grades':[[*k,v] for k,v in sorted(grade_pairs.items())],
         'positive':positive,'controls':examples}
    if args.rank_two_wider:
        out['rank_two_wider']=deficient
    args.out.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(direction, 'cohorts',sum(cohorts.values()),dict(cohorts),'positive',len(positive),'stats',dict(counts),flush=True)


if __name__ == '__main__':
    main()
