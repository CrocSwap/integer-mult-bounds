#!/usr/bin/env python3
"""Could two cheaper direct receipts replace one old receipt at its first read?"""
import argparse
from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path
import sys
from bisect import bisect_left

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--reverse',action='store_true')
parser.add_argument('--pool',action='store_true')
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
sys.path.insert(0,str(args.source))
import network as n
from two_hole import grade

end=len(n.W['program'])
if args.reverse:
    values,routes,rows = n.Y,n.DR,n.DROWS
    owners=n.W['final']
    clock={r:end-1-u for r,u in n.CLOCK.items()}
else:
    values,routes,rows=n.X,n.R,n.ROWS
    owners,clock=n.W['start'],n.CLOCK
values={i:1<<i for i in range(n.W['public'])}|values
uses=defaultdict(list)
for reader,bits in rows.items():
    for label in n.labels(bits):
        if label in routes:
            uses[label].append(reader)
history=defaultdict(list)
for h,c in enumerate(owners):
    history[c].append((-1,h))
for r in sorted(routes,key=clock.__getitem__):
    history[routes[r][1]].append((clock[r],r))
nested={b:[(g,a) for a in history if a!=b and (g:=grade(a,b)) is not None and 0<g<=5] for b in history}
assert max(n.G.values())<=6

class Quotient:
    def __init__(self):
        self.rows={}

    def reduce(self,row,marks=0):
        rem=0
        while row:
            bit=row&-row
            known=self.rows.get(bit)
            if known:
                value,coeff=known
                row^=value
                marks^=coeff
            else:
                row^=bit
                rem|=bit
        return rem,marks

    def add(self,row,marks=0):
        row,marks=self.reduce(row,marks)
        if row:
            self.rows[row&-row]=(row,marks)

def before(bank,time,drop):
    h=history[bank]
    return [p for _,p in h[:bisect_left(h,(time,-1))] if p!=drop]

def run():
    grade_cases=Counter()
    slots=Counter()
    hits=[]
    pools=[]
    for slot in sorted(routes,key=clock.__getitem__):
        g0=n.G[slot]
        if slot==3553 or g0<3:
            continue
        dst=routes[slot][1]
        deadline=min((clock[u] if u>=0 else end for u in uses[slot]),default=end)
        assert deadline>clock[slot]
        receiver=Quotient()
        for v in before(dst,deadline,slot):
            receiver.add(values[v],1<<v)
        residual,_=receiver.reduce(values[slot])
        assert residual,(slot,dst)
        donors=[]
        for g,a in nested[dst]:
            if g>=g0-(0 if args.pool else 1): continue
            ds=Quotient()
            for v in before(a,deadline,slot):
                row,_=receiver.reduce(values[v])
                ds.add(row,1<<v)
            if ds.rows:
                donors.append((g,a,ds))

        if slot!=2944:
            continue
        assert not args.reverse and g0==4 and deadline==11612
        singles=[]
        for g,a,ds in donors:
            rem,used=ds.reduce(residual)
            if not rem:
                singles.append([g,a,list(n.labels(used))])
        assert not singles,singles
        single_count=len(donors)
        donors=[(a,ds) for g,a,ds in donors if g==1]
        print('grade-one donors',len(donors),flush=True)
        tested=0
        witnesses=[]
        for i,(a,d1) in enumerate(donors):
            for j,(b,d2) in enumerate(donors[i+1:],i+1):
                pair=Quotient()
                for ds in (d1,d2):
                    for row,tags in ds.rows.values():
                        pair.add(row,tags)
                need,tag=pair.reduce(residual)
                assert need
                for c,d3 in donors[j+1:]:
                    tested+=1
                    last=Quotient()
                    for row,marks in d3.rows.values():
                        r,ex=pair.reduce(row,marks)
                        last.add(r,ex)
                    rem,used=last.reduce(need,tag)
                    if not rem:
                        witnesses.append({'donors':[a,b,c],'support':list(n.labels(used))})
        out={'slot':slot,'first_reader_clock':deadline,'single_donors':single_count,'single_witnesses':singles,'grade_ones':len(donors),
             'triple_membership_tests':tested,'source':n.public_source(),'witnesses':witnesses}
        args.out.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
        print(tested,len(witnesses),flush=True)
        return


if __name__=='__main__':
    run()
