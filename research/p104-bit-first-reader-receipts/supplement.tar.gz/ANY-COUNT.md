# More than two direct receipts at an unchanged first reader

For a single omitted nonbridge packet of original grade three through six,
keep its original receiver and demanded scalar at the first paid or public
reader. Freeze all other packet equations and clocks. Grant all retained
strictly earlier stock and cochart XOR. Any positively priced solution may
only use donor grades strictly below the original grade. Repeated uses of
one donor combine into a single transmitted form, since that receiver
requires one scalar only.

Pool the **entire** strict-preclock stocks of all such nested cheaper
donors modulo the receiver's old retained stock, with no price or count
charge. Of 216 forward and 216 adjoint omissions, there is only one
membership success, forward packet 2944 into chart 0, grade four. The
displayed pooled witness uses 56 donor charts and is a relaxation control.

For this remaining case, strict improvement with two or more sends entails
strictly smaller integer total grade by subadditivity of the increasing
concave tariff. The preceding direct-pair census rules out all pairs.
The only remaining price-feasible cardinalities are one receipt of grade
at most three or three grade-one receipts. The supplementary replay tests
all 264 single nested donors and all 221,815 triples of 111 grade-one
donors. No solution exists. Four or more scalar calls cost at least four,
strictly above the original grade-four tariff for any 0 < κ < 1.

This extends the single-payload direct-receipt part, without covering a
changed receiving chart or required form, changed upstream histories, or
new geometry. The original and 36-call complete BIT invoices are unchanged.

To replay, unpack this supplement in a separate directory alongside the
extraction of the original `replay.tar.gz`. Point `--source` at the
extracted original. Verify the supplement and exact original hashes, and run:

```sh
python3 -I -B pooled_prefix.py --source /path/to/original --pool --out fresh-forward.json
python3 -I -B pooled_prefix.py --source /path/to/original --pool --reverse --out fresh-adjoint.json
python3 -I -B slot2944_triples.py --source /path/to/original --pool --out fresh-slot2944.json
cmp fresh-forward.json FWD-POOL.json
cmp fresh-adjoint.json ADJ-POOL.json
cmp fresh-slot2944.json SLOT2944-TRIPLES.json
```
