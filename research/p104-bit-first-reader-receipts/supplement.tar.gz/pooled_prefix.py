#!/usr/bin/env python3
"""Could two cheaper direct receipts replace one old receipt at its first read?"""
import argparse
from collections import Counter, defaultdict
from itertools import combinations
import json
from pathlib import Path
import sys
from bisect import bisect_left

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--reverse',action='store_true')
parser.add_argument('--pool',action='store_true')
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
sys.path.insert(0,str(args.source))
import network as n
from two_hole import grade

end=len(n.W['program'])
if args.reverse:
    values,routes,rows = n.Y,n.DR,n.DROWS
    owners=n.W['final']
    clock={r:end-1-u for r,u in n.CLOCK.items()}
else:
    values,routes,rows=n.X,n.R,n.ROWS
    owners,clock=n.W['start'],n.CLOCK
values={i:1<<i for i in range(n.W['public'])}|values
uses=defaultdict(list)
for reader,bits in rows.items():
    for label in n.labels(bits):
        if label in routes:
            uses[label].append(reader)
history=defaultdict(list)
for h,c in enumerate(owners):
    history[c].append((-1,h))
for r in sorted(routes,key=clock.__getitem__):
    history[routes[r][1]].append((clock[r],r))
nested={b:[(g,a) for a in history if a!=b and (g:=grade(a,b)) is not None and 0<g<=5] for b in history}
assert max(n.G.values())<=6

class Quotient:
    def __init__(self):
        self.rows={}

    def reduce(self,row,marks=0):
        rem=0
        while row:
            bit=row&-row
            known=self.rows.get(bit)
            if known:
                value,coeff=known
                row^=value
                marks^=coeff
            else:
                row^=bit
                rem|=bit
        return rem,marks

    def add(self,row,marks=0):
        row,marks=self.reduce(row,marks)
        if row:
            self.rows[row&-row]=(row,marks)

def before(bank,time,drop):
    h=history[bank]
    return [p for _,p in h[:bisect_left(h,(time,-1))] if p!=drop]

def run():
    grade_cases=Counter()
    slots=Counter()
    hits=[]
    pools=[]
    for slot in sorted(routes,key=clock.__getitem__):
        g0=n.G[slot]
        if slot==3553 or g0<3:
            continue
        dst=routes[slot][1]
        deadline=min((clock[u] if u>=0 else end for u in uses[slot]),default=end)
        assert deadline>clock[slot]
        receiver=Quotient()
        for v in before(dst,deadline,slot):
            receiver.add(values[v],1<<v)
        residual,_=receiver.reduce(values[slot])
        assert residual,(slot,dst)
        donors=[]
        for g,a in nested[dst]:
            if g>=g0-(0 if args.pool else 1): continue
            ds=Quotient()
            for v in before(a,deadline,slot):
                row,_=receiver.reduce(values[v])
                ds.add(row,1<<v)
            if ds.rows:
                donors.append((g,a,ds))
        if args.pool:
            joint=Quotient()
            for _,_,ds in donors:
                for row,tags in ds.rows.values():
                    joint.add(row,tags)
            rem,tags=joint.reduce(residual)
            if not rem:
                loc={p:bank for bank in history for p in before(bank,deadline,slot)}
                label_groups=defaultdict(list)
                for p in n.labels(tags): label_groups[loc[p]].append(p)
                pools.append(dict(old=slot,grade=g0,bank=dst,deadline=deadline,
                    donor_case_count=len(donors),basis_witness={str(x):y for x,y in label_groups.items()},
                    witness_grades=[grade(x,dst) for x in label_groups]))
            slots[g0]+=1
            continue
        for (g,a,d1),(h,b,d2) in combinations(donors,2):
            if g+h>=g0: continue
            grade_cases[g0,*sorted([g,h])]+=1
            joint=Quotient()
            for row,marks in d1.rows.values():
                joint.add(row,marks)
            for row,marks in d2.rows.values():
                joint.add(row,marks)
            rem,marks=joint.reduce(residual)
            if rem: continue
            source=list(n.labels(marks))
            parts=[]
            for bank in (a,b):
                labels=set(before(bank,deadline,slot))
                parts.append([j for j in source if j in labels])
            rr,read=receiver.reduce(values[slot]^n.xsum(values[j] for j in source))
            assert not rr and set(parts[0]).isdisjoint(parts[1]) and sum(map(len,parts))==len(source)
            hits.append({'old':slot,'old_grade':g0,'receiver':dst,'deadline':deadline,
                         'grades':[g,h],'donors':[a,b],'support':parts,
                         'readout_support':list(n.labels(read))})
        slots[g0]+=1
    tested=sum(grade_cases.values())
    out={'source':n.public_source(),'direction':'adjoint' if args.reverse else 'forward',
         'old_grade_counts':[[g,c] for g,c in sorted(slots.items())],
         'price_cases':[[*k,v] for k,v in sorted(grade_cases.items())],
         'tested_donor_pairs':tested,'span_hits':hits}
    if args.pool:
        out['pooled_unbudgeted_hits']=pools
    args.out.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(tested,len(hits),len(pools),flush=True)

if __name__=='__main__':
    run()
