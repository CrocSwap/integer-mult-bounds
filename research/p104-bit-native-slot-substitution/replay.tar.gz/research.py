#!/usr/bin/env python3
"""Mixed actual LOCAL slots: forward vs complemented transpose native word."""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import copy,gzip,json,sys,tarfile
HERE=Path(__file__).resolve().parent
S=HERE/'source-7952';sys.path[:0]=[str(S),str(S/'vendor')]
import common as C
import price
import bit_native as N
L=C.literal

def need(v,msg):
 if not v:raise ValueError(msg)
def load(path):
 p=HERE/path;raw=p.read_bytes();return json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw)
def digest(v):return sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def hist(x):return {int(k):v for k,v in sorted(x.items()) if v}
def pin(path,expected):need(sha256((HERE/path).read_bytes()).hexdigest()==expected,'input pin '+str(path))
def verify_upstream():
 need(load('PR-7952-PUBLICATION.json')['head']=='755fcee748d4e90feda281f27d06e7bc66ecf954','7952 exact head')
 pin('PR-7952-REPLAY.tar.gz','2280a3b790eab3d714572a3bf84128fd3adeec2b50d3998033a655d812ab8366')
 pin('PR-7912-REPLAY.tar.gz','87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096')
 with tarfile.open(HERE/'PR-7952-REPLAY.tar.gz','r:gz') as archive:
  for member in archive.getmembers():
   if not member.isfile():continue
   dest=S/member.name.removeprefix('./')
   need(archive.extractfile(member).read()==dest.read_bytes(),'7952 archive member '+member.name)
 with tarfile.open(HERE/'PR-7912-REPLAY.tar.gz','r:gz') as archive:
  for name in ('bit_native.py','price.py'):
   need(archive.extractfile('./inputs/'+name).read()==(S/'vendor'/name).read_bytes(),'7912 compiler member '+name)
 for line in (S/'SHA256SUMS').read_text().splitlines():
  h,name=line.split('  ',1);need(sha256((S/name).read_bytes()).hexdigest()==h,'source archive member '+name)
 pin('source-7952/inputs/WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9')
 pin('source-7952/CALLER.json.gz','f38ad467dc02450f35a57d6e5868bc91e34d356576c926ea839f0a55894bef21')
 pin('source-7952/vendor/price.py','d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b')
 pin('source-7952/vendor/bit_native.py','4368c62a5d42f81189d6776b8dba8c85a311b6a199b816244b545c6bb7d3dc1e')

def native_adjoint(w,swap=True):
 n=w['public'];offset=1+max(map(int,w['frames']))
 def p(i):return (i+111 if i<111 else i-111 if i<222 else i) if swap else i
 def c(i):return i+offset
 frames={str(c(int(k))):{'dim':8-v['dim'],'B':v['A'],'A':v['B']} for k,v in w['frames'].items()}
 program=[]
 for op,a,*z in reversed(w['program']):
  if op=='INIT':program.append(['CLEAR',p(a),c(z[0])])
  elif op=='CLEAR':program.append(['INIT',p(a),c(z[0])])
  elif op=='ADD':program.append(['ADD',p(z[0]),p(a),c(z[1])])
  elif op=='SWAP':program.append(['SWAP',p(a),p(z[0])])
  elif op=='MOVE':program.append(['MOVE',p(a),c(z[1]),c(z[0])])
  else:raise ValueError('opcode')
 return {'schema':w['schema'],'public':n,'owned_fields':w['owned_fields'],'frames':frames,
         'start':[c(w['final'][p(i)]) for i in range(n)],'final':[c(w['start'][p(i)]) for i in range(n)],'program':program}

def split_owner_411(w):
 """Recompile 679 independent owners plus one exact isolated owner path."""
 initial,final,moves,rows,clocks=N.extract(w)
 need(moves[3553]==(509,1) and rows[3553]==1<<411 and rows[~411]==1<<3553,
      'isolated 411 packet and returned output')
 mask=(1<<411)|(1<<3553)
 need(all(not(row&mask) for key,row in rows.items() if key not in (3553,~411)),
      'no remaining packet or output reads either isolated owner or bridge')
 ni={j:v for j,v in initial.items() if j!=411};nf={j:v for j,v in final.items() if j!=411}
 nm={j:v for j,v in moves.items() if j!=3553}
 nr={j:v&~mask for j,v in rows.items() if j not in (3553,~411)}
 order=N.schedule(ni,nf,nm,nr);N.basis(ni,nm,nr,order)
 cohort=N.emit_word(w,ni,nf,nm,nr,order)
 need(cohort['public']==679 and cohort['owned_fields']==3552,'actual independent 679 cohort')
 # Reserve original public address 411. Every following address, including
 # every owned field, is shifted one place when returned to the 680 namespace.
 def a(i):return i if i<411 else i+1
 program=[]
 for op,dst,*arg in cohort['program']:
  if op in ('ADD','SWAP'):program.append([op,a(dst),a(arg[0]),*arg[1:]])
  else:program.append([op,a(dst),*arg])
 scratch=680+cohort['owned_fields']
 program += [['INIT',scratch,509],['SWAP',411,scratch],['MOVE',scratch,509,1],
             ['SWAP',411,scratch],['CLEAR',scratch,509]]
 combined={'schema':w['schema'],'public':680,'owned_fields':cohort['owned_fields']+1,
           'frames':w['frames'],'start':w['start'],'final':w['final'],'program':program}
 # Bind every 679-cohort move to its source packet identity in the actual new
 # order. Original packet 3553 becomes the final, separately owned move.
 newmoves=[(t,row) for t,row in enumerate(program) if row[0]=='MOVE']
 need(len(newmoves)==2874,'split full paid occurrence count')
 packet_map=[]
 for original,(clock,row) in zip(order,newmoves[:-1],strict=True):
  need(tuple(row[2:])==moves[original],'retained packet chart pair')
  packet_map.append([original,clocks[original],clock,row[1],*row[2:]])
 clock,row=newmoves[-1];need(row==['MOVE',scratch,509,1],'isolated direct 411 route')
 packet_map.append([3553,clocks[3553],clock,scratch,509,1])
 need(len({x[0] for x in packet_map})==2874,'full original packet identities')
 return combined,cohort,{'retained_original_owners':list(sorted(ni)),
        'isolated_original_owner':411,'original_packet_3553':'sole bridge for 411',
        'source_packet_count':len(moves),'recompiled_packet_count':len(packet_map),
        'packet_mapping_sha256':digest(packet_map),'new_separate_scratch':scratch,
        'new_separate_move_clock':clock,'new_separate_route':[509,1],
        'literal_679_cohort_canonical':digest(cohort)}

def close_value(word,scratch,reverse):
 n=word['public'];bank=[1<<i for i in range(n)]+[0]*word['owned_fields']
 seq=range(len(word['program'])-1,-1,-1) if reverse else range(len(word['program']))
 for clock in seq:
  op,a,*arg=word['program'][clock]
  if a==scratch and ((op=='INIT' and reverse) or (op=='CLEAR' and not reverse)):
   return bank[a]
  if op=='ADD':
   if reverse:bank[arg[0]]^=bank[a]
   else:bank[a]^=bank[arg[0]]
  elif op=='SWAP':j=arg[0];bank[a],bank[j]=bank[j],bank[a]
  elif op in ('INIT','CLEAR'):bank[a]=0
  elif op!='MOVE':raise ValueError('scratch trace opcode')
 raise ValueError('scratch closure')

def same_plane(a,i,b,j):
 A=a.frames[i];B=b.frames[j]
 return len(A[0])==len(B[0]) and L.orthogonal(A[0],B[1]) and L.orthogonal(B[0],A[1])

def vector_trace(w,clock):
 n=w['public'];bank=[1<<j for j in range(n)]+[0]*w['owned_fields']
 for t,(op,a,*arg) in enumerate(w['program']):
  if t==clock:return w['program'][t],bank[a]
  if op=='ADD':bank[a]^=bank[arg[0]]
  elif op=='SWAP':j=arg[0];bank[a],bank[j]=bank[j],bank[a]
  elif op in ('INIT','CLEAR'):bank[a]=0
  elif op!='MOVE':raise ValueError('trace opcode')
 raise ValueError('trace clock')

def xshift(row,stages=(),q=0):
 out={}
 for (qp,exps),mask in row.items():
  ee=list(exps)
  for s in stages:ee[s-1]+=1
  key=(qp^q,tuple(ee));out[key]=out.get(key,0)^mask
 return {k:v for k,v in out.items() if v}
def xor(a,b):
 out=a.copy()
 for k,v in b.items():
  out[k]=out.get(k,0)^v
  if not out[k]:del out[k]
 return out

def caller_poly(caller,orientations,reverse=False,wrong_slot=None):
 """Each LOCAL's two-port q matrix was checked against a literal interface.
 `wrong_slot` transposes just that native main shear as a negative control.
 """
 events=caller['events'];zero=(0,(0,)*18);rows=[{zero:1<<i} for i in range(38)]
 sequence=range(len(events)-1,-1,-1) if reverse else range(len(events))
 for clock in sequence:
  op,*x=events[clock]
  if op in ('ADD','QUERY'):
   a,z=x[::-1] if reverse else x
   rows[a]=xor(rows[a],xshift(rows[z],q=(op=='QUERY')))
  elif op=='LOCAL':
   stage,a,z=x
   need(orientations[clock] in ('forward','complemented-adjoint','split-411'),'every actual LOCAL bound')
   # The derived matrix is [[1,0],[q,1]], its transpose for reverse.
   if reverse ^ (clock==wrong_slot):a,z=z,a
   source=rows[a];dest=rows[z]
   rows[a]=xshift(source,(stage,));rows[z]=xshift(xor(dest,xshift(source,q=1)),(stage,))
  elif op=='IDLE_ONE':a,ss=x;rows[a]=xshift(rows[a],ss)
  elif op=='SWAP':a,z=x;rows[a],rows[z]=rows[z],rows[a]
  else:raise ValueError('caller opcode')
 want=[]
 for i,d in enumerate(caller['diagonal']):want.append({(d['q'],tuple(int(s in d['stages']) for s in range(1,19))):1<<i})
 return rows,want

def main():
 verify_upstream();source=C.inputs();w,oldcaller,bit,rat=source
 caller=load('source-7952/CALLER.json.gz');receipt=load('source-7952/CALLER-RESULT.json')
 need(digest(w)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','7830 pinned native')
 need(digest(caller)=='9de443fa08e766e5b054c6100398ffe11341a8c27dec5c5303573ec6d467cd8b','7952 pinned caller')
 need(caller['diagonal']==oldcaller['diagonal'],'real 38 root ownership')
 dual=native_adjoint(w);split,cohort,split_receipt=split_owner_411(w)
 wc=L.Charts(w['frames']);dc=L.Charts(dual['frames'])
 wc.main_contacts(w['start'],w['final']);dc.main_contacts(dual['start'],dual['final'])
 need(all(v%3 for v in wc.prime_factors|dc.prime_factors),'old and complementary 3-adic unit frames')
 checks={};native_hist={};helper_hist={};ops={}
 for name,word,charts in (('forward',w,wc),('complemented-adjoint',dual,dc),('split-411',split,wc)):
  f,df,_=L.tape(word,charts);r,dr,_=L.tape(word,charts,adjoint=True)
  need(f==L.expected_rows(680,False) and r==L.expected_rows(680,True),'complete native operator and transpose '+name)
  need(df['paid']==dr['paid'],'symmetric literal paid rank '+name)
  native_hist[name]=df['paid'];ops[name]=df['counts']
  helper_hist[name]=Counter(charts.leg(a,z) for a,z in zip(word['start'][222:],word['final'][222:],strict=True))
  need(len(helper_hist[name]) and sum(helper_hist[name].values())==458,'all 458 returned productive helper owners')
  checks[name]={'sha256':digest(word),'forward_and_adjoint_public_matrix':[680,680],'native_paid':hist(df['paid']),'native_helper_targets':hist(helper_hist[name]),'forward_dirty_private_retirements':df['erase_dirty'],'adjoint_dirty_private_retirements':dr['erase_dirty'],'instruction_counts':dict(df['counts'])}
 need(all(native_hist['forward']==native_hist[j] and helper_hist['forward']==helper_hist[j] for j in native_hist),'exact native grade invariance')
 need(ops['forward']==ops['complemented-adjoint'],'exact complemented-adjoint instruction counts')
 need(all(not close_value(split,split_receipt['new_separate_scratch'],rev) for rev in (False,True)),'separate 411 scratch clean in both orientations')
 for rev in (False,True):
  out,_,_=L.tape(cohort,L.Charts(cohort['frames']),adjoint=rev)
  need(out==L.expected_rows(679,rev),'independent 679 cohort operator')
 need(len(w['program'])==len(dual['program']) and w['owned_fields']==dual['owned_fields'],'native instruction and ownership invariance')
 # Establish per-original-occurrence payment; not merely equal grade totals.
 f_moves=[(i,row) for i,row in enumerate(w['program']) if row[0]=='MOVE']
 for clock,(_,bank,a,z) in f_moves:
  newclock=len(w['program'])-1-clock;entry=dual['program'][newclock]
  need(entry==['MOVE',bank,636+z,636+a] and wc.leg(a,z)==dc.leg(636+z,636+a),'exact paid occurrence bijection')
 need(all(dual['frames'][str(636+int(k))]['B']==v['A'] and dual['frames'][str(636+int(k))]['A']==v['B'] for k,v in w['frames'].items()),'exact orthogonal complement on every frame')
 main_equal=[i for i in range(222) if same_plane(wc,w['start'][i],dc,dual['start'][i]) and same_plane(wc,w['final'][i],dc,dual['final'][i])]
 helper_equal=[i for i in range(222,680) if same_plane(wc,w['start'][i],dc,dual['start'][i]) and same_plane(wc,w['final'][i],dc,dual['final'][i])]
 need(len(main_equal)==222 and len(helper_equal)==389,'main plane equality and genuinely different helper boundaries')
 for i in range(222,680):need(wc.leg(w['start'][i],w['final'][i])==dc.leg(dual['start'][i],dual['final'][i]),'owned helper grade per identity')
 bridgeclock=next(i for i,row in enumerate(w['program']) if row[0]=='MOVE' and row[1]==3553)
 oldinst,oldvalue=vector_trace(w,bridgeclock);newclock=len(w['program'])-1-bridgeclock;newinst,newvalue=vector_trace(dual,newclock)
 need(bridgeclock==31290 and oldvalue==newvalue==1<<411,'411-only bridge in both orientations')
 first=next((i,row) for i,row in enumerate(w['program'][bridgeclock+1:],bridgeclock+1) if row[0]=='ADD' and row[2]==3553)
 need(first==(35800,['ADD',3965,3553,1]) and w['program'][39546]==['SWAP',411,3965],'411 first reader and owned output')
 adjfirst=next((i,row) for i,row in enumerate(dual['program'][newclock+1:],newclock+1) if row[0]=='ADD' and row[2]==3553)
 need(adjfirst==(11668,['ADD',411,3553,1145]),'adjoint 411 first reader and owned output')
 sc=split_receipt['new_separate_move_clock'];ss=split_receipt['new_separate_scratch']
 need(split['program'][sc+1]==['SWAP',411,ss] and split['program'][sc+2]==['CLEAR',ss,509],'split 411 immediate labelled return and clean retirement')
 try:L.tape(w,wc,omit=bridgeclock)
 except ValueError:pass
 else:raise ValueError('unfunded 411 transfer accepted')
 try:L.tape(split,wc,omit=split_receipt['new_separate_move_clock'])
 except ValueError:pass
 else:raise ValueError('unfunded separate 411 transfer accepted')
 # An adjoint without swapping main roles gives the wrong native orientation.
 wrong=native_adjoint(w,swap=False);wr,_,_=L.tape(wrong,L.Charts(wrong['frames']))
 wrongcoeff=L.different(wr,L.expected_rows(680,False))[1];need(wrongcoeff>0,'unconjugated adjoint detected')
 events=caller['events'];slotclocks=[i for i,e in enumerate(events) if e[0]=='LOCAL'];need(len(slotclocks)==36,'actual 36 LOCALs')
 paid0=Counter();targets0=Counter();ops0=Counter(e[0] for e in events)
 paid0,targets0=L.paired_invoice(caller,native_hist['forward'],helper_hist['forward'],ops0)
 need(hist(paid0)=={int(k):v for k,v in bit['native']['paid'].items()} and hist(targets0)=={int(k):v for k,v in bit['native']['targets'].items()},'all old full actual caller bins')
 need(receipt['old_full_paid']==receipt['new_full_paid'] and receipt['old_full_productive']==receipt['new_full_productive'],'7952 original control')
 ordinary={}
 for name,word in (('forward',w),('complemented-adjoint',dual),('split-411',split)):
  ordinary[name]=L.ordinary(word,caller,ops0,paid0,targets0)
  checks[name]['full_caller_ordinary_if_all_36']=ordinary[name]
 need(ordinary['forward']==ordinary['complemented-adjoint'],'adjoint raw funding exactly equal')
 need(ordinary['split-411']['owned_backing']==ordinary['forward']['owned_backing']-36 and ordinary['split-411']['ordinary_records']<ordinary['forward']['ordinary_records'],'split raw funding')
 slots=[];owner_tags=set();prev_by_stage={}
 for idx,clock in enumerate(slotclocks):
  _,stage,a,z=events[clock];following=events[clock+1]
  need(following==['ADD',z,a],'first caller reader of both returned roles')
  prev=prev_by_stage.setdefault(stage,set());need(not prev.intersection((a,z)),'stage main-owner disjointness');prev.update((a,z))
  for h in range(222,680):owner_tags.add((clock,h))
  slots.append({'ordinal':idx,'clock':clock,'stage':stage,'source_role':a,'destination_role':z,'first_reader_clock':clock+1,'first_reader':following,'independent_helper_returns':458,'original_and_alternate_native_paid':hist(native_hist['forward']),'original_and_alternate_helper_targets':hist(helper_hist['forward'])})
 need(len(owner_tags)==36*458 and all(len(v)==4 for v in prev_by_stage.values()),'all caller-local helper identities and disjoint main pairs')
 patterns={'all-forward':{t:'forward' for t in slotclocks},'all-adjoint':{t:'complemented-adjoint' for t in slotclocks},'all-split':{t:'split-411' for t in slotclocks},'alternating':{t:('forward' if j%2==0 else 'complemented-adjoint') for j,t in enumerate(slotclocks)},'three-way':{t:('forward','complemented-adjoint','split-411')[j%3] for j,t in enumerate(slotclocks)},'first-half-adjoint':{t:('complemented-adjoint' if j<18 else 'forward') for j,t in enumerate(slotclocks)}}
 pattern_results={}
 for name,bind in patterns.items():
  for rev in (False,True):
   got,want=caller_poly(caller,bind,rev);need(got==want,'q polynomial caller owner and orientation '+name)
  # Bill each actual call with its own bound native grade histogram.
  p=Counter();t=Counter()
  for e in events:
   if e[0]=='QUERY':p[1]+=111
   elif e[0]=='IDLE_ONE':p[7*len(e[2])]+=111
  for d in caller['diagonal']:t[1+7*len(d['stages'])]+=111
  for clock in slotclocks:p.update(native_hist[bind[clock]]);t.update(helper_hist[bind[clock]])
  need(p==paid0 and t==targets0,'complete mixed 36-slot target and paid bill')
  nsplit=sum(v=='split-411' for v in bind.values());base=ordinary['forward'];sp=ordinary['split-411']
  mixed_records=base['ordinary_records']+nsplit*(sp['native_bank_transits_per_call']-base['native_bank_transits_per_call'])
  mixed_owned=base['owned_backing']-nsplit
  need(mixed_records<10**12 and mixed_owned<10**7,'mixed raw caller funding')
  pattern_results[name]={'forward_and_adjoint_q_polynomial_rows':38,'native_adjoint_calls':sum(v=='complemented-adjoint' for v in bind.values()),'split_411_calls':nsplit,'paid_equal_full_baseline':True,'productive_equal_full_baseline':True,'ordinary_records':mixed_records,'owned_backing':mixed_owned}
 wrongrows,want=caller_poly(caller,patterns['all-forward'],wrong_slot=slotclocks[0]);need(wrongrows!=want,'one incorrect q/shear orientation rejected')
 signed=Counter(targets0);signed.subtract(paid0);rates={}
 rpay=Counter({int(k):v for k,v in rat['signed']['paid'].items()});rtarget=Counter({int(k):v for k,v in rat['signed']['productive'].items()})
 need(rat['signed']['native_calls']==48 and hist(rpay)=={int(k):v for k,v in receipt['rational_paid'].items()} and hist(rtarget)=={int(k):v for k,v in receipt['rational_productive'].items()},'unchanged rational 48-call full bins')
 rsigned=Counter(rtarget);rsigned.subtract(rpay)
 for rate in ('0.003879928046156','0.003879929046155'):
  q=Fraction(rate);bp=price.moment(signed,q);rp=price.moment(rsigned,q)
  rates[rate]={'bit':price.decimal_interval(bp,30),'rational':price.decimal_interval(rp,30),'mixed_bit_signed_delta':'0 exactly','mixed_rational_signed_delta':'0 exactly'}
  need(bp[1]<0 and rp[0]>0,'both trial signed directions')
 seam=[{'clock':i,'event':e} for i,e in enumerate(events) if e[0]=='QUERY']
 need([x['clock'] for x in seam]==[154,158,162,167],'actual four seam QUERY clocks')
 result={'status':'NO_GAIN_MIXED_NATIVE_AND_DISJOINT_411_COHORTS','sources':{'7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','7952_head':'755fcee748d4e90feda281f27d06e7bc66ecf954','7952_archive_sha256':'2280a3b790eab3d714572a3bf84128fd3adeec2b50d3998033a655d812ab8366','native_canonical':digest(w),'caller_canonical':digest(caller)},'scope':'Actual #7952 caller; any selection among 36 LOCALs of original forward native, explicitly complemented main-swapped transpose, or 679-plus-isolated-411 direct cohort, with all 680 public outputs and all 458 per-call helper obligations retained. No shared QUERY/native contact or alternate physical supplier is constructed or excluded.','native_interfaces':checks,'native_move_occurrence_bijection':len(f_moves),'complemented_move_quotient_projectors_identical':'For every reversed nested pair, P(complement(A))=I-P(A); reversal gives the same difference projector.','split_411_cohorts':split_receipt,'split_411_additional_scratch_clean_both_directions':True,'main_port_planes_identical_count':len(main_equal),'helper_identity_count':458,'helper_same_start_and_return_plane_count':len(helper_equal),'helper_changed_start_or_return_plane_count':458-len(helper_equal),'per_identity_helper_grades_equal':True,'arbitrary_36_slot_assignments':str(3**36),'proof_of_arbitrary_assignment':'Every native instance has the same labelled scalar map, same 222 actual main input/output planes, equal per-owned-helper grades and bijective paid MOVE grades; replacement is independent at the 36 frozen caller clocks. Thus substituting any subset preserves the q polynomial and the full additive rank bill.','actual_local_slots':slots,'main_first_reader_every_slot':'immediate next macro ADD on both returned main roles','per_call_fresh_helper_owner_tags':len(owner_tags),'four_actual_query_seam':seam,'pattern_replays':pattern_results,'full_bit_paid':hist(paid0),'full_bit_productive':hist(targets0),'rational_native_calls':48,'rational_paid':hist(rpay),'rational_productive':hist(rtarget),'rates':rates,'owner_411_bridge':{'old_clock':bridgeclock,'old_move':oldinst,'adjoint_clock':newclock,'adjoint_move':newinst,'both_sender_support':[411],'old_first_reader_clock':first[0],'old_first_reader':first[1],'adjoint_first_reader_clock':adjfirst[0],'adjoint_first_reader':adjfirst[1],'split_first_reader_clock':sc+1,'split_first_reader':['SWAP',411,ss],'old_public_return_clock':39546,'old_public_return':['SWAP',411,3965],'surrendered':False},'corruptions':{'unconjugated_adjoint_changed_public_coefficients':wrongcoeff,'wrong_single_local_q_orientation_rejected':True,'omitted_411_bridge_rejected':True,'omitted_split_411_bridge_rejected':True},'limitations':['Literal CLEAR discards 3554 nonzero private values in both directions for forward/adjoint, and 3552 for the split construction; physical erasure remains unproved.','Complementary helper endpoints need their own physical bindings and compiler/cover/precision qualification.','No joint incidence was created between the four seam QUERYs and an individual native payment; a new construction that changes those paid contacts remains open.']}
 if len(sys.argv)==3 and sys.argv[1]=='--words':
  dest=Path(sys.argv[2]);dest.mkdir(parents=True,exist_ok=True)
  for name,word in [('COMPLEMENTED-ADJOINT-WORD.json.gz',dual),('SPLIT-411-WORD.json.gz',split),('679-COHORT-WORD.json.gz',cohort)]:
   (dest/name).write_bytes(gzip.compress(json.dumps(word,sort_keys=True,separators=(',',':')).encode(),mtime=0))
 elif len(sys.argv)!=1:raise ValueError('usage: research.py [--words directory]')
 print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
