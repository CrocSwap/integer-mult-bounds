#!/usr/bin/env python3
"""Inventory, clean reproducibility and independent decimal interval checks."""
from collections import Counter
from decimal import Decimal
from hashlib import sha256
from pathlib import Path
import gzip,json,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent

def need(x,msg):
 if not x:raise ValueError(msg)
def main():
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);p=HERE/name
  need(p.is_file() and sha256(p.read_bytes()).hexdigest()==digest,'inventory '+name)
 result=json.loads((HERE/'RESULT.json').read_bytes())
 sys.path.insert(0,str(HERE/'source-7952'));import common as C
 cases=[('full_bit_paid','full_bit_productive','bit'),('rational_paid','rational_productive','rational')]
 for p,t,name in cases:
  paid=Counter({int(k):v for k,v in result[p].items()});target=Counter({int(k):v for k,v in result[t].items()})
  for rate,rec in result['rates'].items():
   lo,hi=C.moment(paid,target,Decimal(rate));a,b=map(Decimal,rec[name])
   need(a<=lo<=hi<=b,'independent decimal interval '+name+' '+rate)
 with tempfile.TemporaryDirectory(prefix='p104-nonuniform-native-') as root:
  tmp=Path(root);shutil.copytree(HERE/'source-7952',tmp/'source-7952')
  for name in ('research.py','PR-7952-PUBLICATION.json','PR-7952-REPLAY.tar.gz','PR-7912-REPLAY.tar.gz'):
   shutil.copy2(HERE/name,tmp/name)
  run=subprocess.run([sys.executable,'-I','-B',str(tmp/'research.py'),'--words',str(tmp)],capture_output=True,check=True)
  need(run.stdout==(HERE/'RESULT.json').read_bytes(),'deterministic cold receipt')
  for name in ('COMPLEMENTED-ADJOINT-WORD.json.gz','SPLIT-411-WORD.json.gz','679-COHORT-WORD.json.gz'):
   need(gzip.decompress((tmp/name).read_bytes())==gzip.decompress((HERE/name).read_bytes()),'independent regenerated word '+name)
 print('PASS_MIXED_NATIVE_36_SLOTS_411_COHORTS_FULL_48_RATIONAL_AND_CORRUPTION_CONTROLS')
if __name__=='__main__':main()
