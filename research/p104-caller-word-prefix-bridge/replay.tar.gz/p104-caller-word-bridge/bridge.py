#!/usr/bin/env python3
"""Independent exact #7113 source/CallerWord/physical-contact bridge check.

Pure stdlib arithmetic. The ring has independent D exponents (not bitsets),
Gaussian-rational coefficients, and q exponents modulo four. This is not a
Lean proof; see BRIDGE.md. Run Python with assertions enabled.
"""
import argparse
import copy
from fractions import Fraction as F
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CALLER = 'research/p104-certkit-pricekit-to-lean/data/7113_CALLER.json'
NATIVE = 'research/signed-caller-8x9/replay/supplier7112/WORD.json.gz'
CALLER_SHA = '255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc'
NATIVE_GZIP_SHA = 'fe0b1dc3049a6b72760a705af2e698e0e9998e969e19862a696eba63434eb233'
NATIVE_SHA = '3454c4900245ed1814ceeff79a741a45160eb3a93cf8d15f891fe2a67ba036fc'
WITNESS_SHA = '93567ded8b979291455634609debf51f0a141750900cff2d3bc2a4d67cc5f2a8'
Z = (F(0), F(0)); ONE = (F(1), F(0)); NIL = (0,) * 17


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':')).encode()


def module(path):
    s = importlib.util.spec_from_file_location('binding_check', path)
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m)
    return m


# A row is a sparse dict (input role, q exponent, D exponent tuple) -> a+bi.
# This implements Q[i,q,D_0,...,D_16]/(i^2+1,q^4-1). q is NOT identified
# with i or -i; D exponents are arbitrary nonnegative integers, not masks.
def linear(*terms):
    out = {}
    for row, c, qe, ds in terms:
        a, b = c
        for (col, q, powers), (x, y) in row.items():
            key = (col, (q + qe) % 4, tuple(p + d for p, d in zip(powers, ds)))
            u, v = out.get(key, Z)
            z = (u + a*x - b*y, v + a*y + b*x)
            if z != Z:
                out[key] = z
            elif key in out:
                del out[key]
    return out


def shifted(row, c=ONE, qe=0, stages=()):
    ds = [0] * 17
    for t in stages:
        assert 0 <= t < 17
        ds[t] += 1
    return linear((row, c, qe, tuple(ds)))


def rows0():
    return [{(r, 0, NIL): ONE} for r in range(36)]


def primitive(rows, e):
    """Direct row semantics of the constructors in #7852 evMat."""
    op, r, *a = e
    old = rows[r]
    if op == 'add':
        rows[r] = linear((old, ONE, 0, NIL), (rows[a[0]], (F(a[1]), F(0)), 0, NIL))
    elif op == 'scale':
        rows[r] = shifted(old, (F(a[0]), F(0)))
    elif op == 'swap':
        rows[r], rows[a[0]] = rows[a[0]], old
    elif op == 'query':
        rows[r] = linear((old, ONE, 0, NIL), (rows[a[0]], ONE, a[1], NIL))
    elif op == 'lam':
        s = F(a[0]); half = F(1, 2)
        rows[r] = linear((old, (half, s*half), 0, NIL),
                         (old, (half, -s*half), 2, NIL))
    elif op == 'idle':
        rows[r] = shifted(old, ONE, a[1], a[0])
    elif op == 'host':
        t, aa, bb = a; aa, bb = F(aa), F(bb)
        assert r != t
        right = rows[t]
        rows[r] = linear((old, ONE, 0, NIL), (right, (aa, F(0)), 1, NIL))
        rows[t] = linear((old, (bb, F(0)), 3, NIL), (right, (1+aa*bb, F(0)), 0, NIL))
    else:
        raise AssertionError(('unknown primitive', e))


def source(rows_by_type, e, alpha):
    """Source record interpreter, including simultaneous J equations.

    It does not invoke primitive(), and reads global #7113 role numbers.
    """
    if e[0] == 'J':
        _, st, (x,y,u,v), (s,t,astr,bstr) = e
        s -= 36; t -= 36; ds = (st-1,); a, b = F(astr), F(bstr)
        A, B = rows_by_type['A'], rows_by_type['B']
        assert len({x,y,u,v}) == 4 and s != t
        ax, ay, au, av = A[x], A[y], A[u], A[v]
        bs, bt = B[s], B[t]
        A[x] = shifted(ax, stages=ds)
        A[y] = shifted(linear((ay, ONE, 0, NIL), (ax, ONE, -1, NIL)), stages=ds)
        A[u] = shifted(linear((au, ONE, 0, NIL), (av, (F(alpha), F(0)), 1, NIL)), stages=ds)
        A[v] = shifted(av, stages=ds)
        B[s] = shifted(linear((bs, ONE, 0, NIL), (bt, (a, F(0)), 1, NIL)), stages=ds)
        B[t] = shifted(linear((bs, (b, F(0)), -1, NIL), (bt, (1+a*b, F(0)), 0, NIL)), stages=ds)
        return
    ty, op, glob, *a = e; r = glob - (36 if ty == 'B' else 0)
    row = rows_by_type[ty]; old = row[r]
    if op == 'ADD':
        s = a[0] - (36 if ty == 'B' else 0)
        row[r] = linear((old, ONE, 0, NIL), (row[s], (F(a[1]), F(0)), 0, NIL))
    elif op == 'SCALE':
        row[r] = shifted(old, (F(a[0]), F(0)))
    elif op == 'SWAP':
        s = a[0] - (36 if ty == 'B' else 0); row[r], row[s] = row[s], old
    elif op == 'QUERY':
        s = a[0] - (36 if ty == 'B' else 0)
        row[r] = linear((old, ONE, 0, NIL), (row[s], ONE, a[1], NIL))
    elif op == 'LAMBDA':
        h = F(1,2); sign = F(a[0])
        row[r] = linear((old, (h, h*sign), 0, NIL), (old, (h, -h*sign), 2, NIL))
    elif op in ('IDLE_ONE', 'IDLE_ODD'):
        row[r] = shifted(old, qe=0 if op == 'IDLE_ONE' else a[1], stages=[j-1 for j in a[0]])
    else:
        raise AssertionError(('unknown source event', e))


def expand(e, alpha):
    """Parse an individual source record into the expected #7852 constructors."""
    if e[0] == 'J':
        _, stage, (x,y,u,v), (s,t,a,b) = e; st = stage-1; s -= 36; t -= 36
        return {'A': [['host',x,y,'0','1'], ['host',u,v,alpha,'0']]
                     + [['idle',r,[st],0] for r in (x,y,u,v)],
                'B': [['host',s,t,a,b], ['idle',s,[st],0], ['idle',t,[st],0]]}
    ty, op, r, *a = e; off = 36 if ty == 'B' else 0; r -= off
    if op in ('ADD','SWAP','QUERY'):
        a[0] -= off
    if op in ('IDLE_ONE','IDLE_ODD'):
        st = [j-1 for j in a[0]]; return {ty: [['idle',r,st,0 if op == 'IDLE_ONE' else a[1]]]}
    tag = {'ADD':'add','SCALE':'scale','SWAP':'swap','QUERY':'query','LAMBDA':'lam'}[op]
    return {ty: [[tag,r,*a]]}


def endpoint(rows, targets):
    out = []
    for r, (q, zero, st) in enumerate(targets):
        assert zero == 0
        power = tuple(int(j in st) for j in range(17))
        expected = {(r, q % 4, power): ONE}
        if rows[r] != expected:
            out.append(r)
    return out


def first_difference(left, right):
    for ty in ('A','B'):
        for r, (x,y) in enumerate(zip(left[ty],right[ty])):
            if x != y:
                for key in sorted(set(x) | set(y)):
                    if x.get(key,Z) != y.get(key,Z):
                        def val(v): return [str(v[0]),str(v[1])]
                        return {'type':ty,'output_role_local':r,'input_role_local':key[0],
                                'q_exponent_mod_4':key[1],'stage_exponents':list(key[2]),
                                'original_coefficient_real_imag':val(x.get(key,Z)),
                                'mutant_coefficient_real_imag':val(y.get(key,Z))}
    return None


def contact_tables(C, W):
    H = W['hosted']; da = H['Dports']; xs = H['X2']; ys = H['Y2']
    assert len(da) == len(xs) == len(ys) == 96
    assert da == C['types']['A']['ports']
    assert sorted(da + C['types']['B']['ports']) == list(range(104))
    assert (H['alpha'],H['beta'],H['alpha2'],H['beta2']) == ('-1','1/2','-1','0')
    assert C['types']['A']['alpha2'] == H['alpha2']
    second = dict(zip(da, zip(xs,ys)))
    ports = []
    for pi, x in enumerate(W['live']):
        y = x+112; q = W['ports'][pi]
        if pi in second:
            x2,y2 = second[pi]
            assert all(W[k][a] == W[k][b] for k in ('initial','final') for a,b in ((x,x2),(y,y2)))
        else:
            x2 = y2 = W['public']  # sentinel outside the native public range
        ports.append([pi,q,x,y,x2,y2])
    joints = []
    contacts = []
    for ci,e in enumerate(C['events']):
        if e[0] != 'J': continue
        _,st,a,b = e
        assert len(set(a)) == 4 and len(set(b[:2])) == 2
        assert b[2:] == ['-1','1/2'] and 0 <= min(a) <= max(a) < 36
        assert 36 <= min(b[:2]) <= max(b[:2]) < 72
        joints.append([ci,st,*a,*b[:2],-1,1,1,2])
        for pi,q,x,y,x2,y2 in ports:
            if pi in second:
                contacts.append([ci,st,pi,q,x,y,a[0],a[1],x2,y2,a[2],a[3]])
            else:
                contacts.append([ci,st,pi,q,x,y,b[0],b[1],x2,y2,72,72])
    assert [e[1] for e in joints] == list(range(1,18))
    assert len(contacts) == 17*104
    return ports,joints,contacts


def native_reverse(W):
    """Recompute #7112's chart-conjugated scalar map in reverse mode.

    MOVE has identity scalar transport in this model; frame validity and
    phase-polynomial physical contact geometry are separate obligations.
    The computed 1484x1484 transpose is compared with the full desired map,
    including all public helper coordinates, not merely the hosted pairs.
    """
    n = W['public']; adj = [{r:F(1)} for r in range(n)] + [{} for _ in range(W['owned_fields'])]
    for e in reversed(W['program']):
        op,r = e[:2]
        if op in ('INIT','CLEAR'):
            adj[r] = {}
        elif op == 'MOVE':
            pass
        elif op == 'SCALE':
            c = F(e[2]); adj[r] = {k:c*v for k,v in adj[r].items() if c*v}
        else:
            assert op in ('ADD','COPY')
            s,c = e[2],F(e[3]); assert s != r
            for k,v in adj[r].items():
                new = adj[s].get(k,F(0)) + c*v
                if new: adj[s][k] = new
                elif k in adj[s]: del adj[s][k]
            if op == 'COPY': adj[r] = {}
    target = [{r:F(1)} for r in range(n)]
    hosted = set(W['hosted']['Dports'])
    for pi,x in enumerate(W['live']):
        y = x+112
        if pi in hosted:
            target[y][x] = F(1)
        else:
            target[x][y] = F(-1); target[y] = {x:F(1,2),y:F(1,2)}
    for x,y in zip(W['hosted']['X2'],W['hosted']['Y2']):
        target[x][y] = F(-1)
    expect = [{} for _ in range(n)]
    for output,row in enumerate(target):
        for input_role,c in row.items(): expect[input_role][output] = c
    bad = [r for r in range(n) if adj[r] != expect[r]]
    assert not bad, bad
    return {'program_events':len(W['program']),'public_fields':n,'bad_public_transpose_rows':bad,
            'moves':'identity in conjugated scalar coordinates; frame and phase geometry separate'}


def lean_rat(x):
    v = F(x)
    if v.denominator == 1:
        return f'({v.numerator} : ℚ)'
    return f'(({v.numerator} : ℚ) / {v.denominator})'


def lean_event(e):
    op,r,*a = e
    if op == 'add': return f'.add {r} {a[0]} {lean_rat(a[1])}'
    if op == 'scale': return f'.scale {r} {lean_rat(a[0])}'
    if op == 'swap': return f'.swap {r} {a[0]}'
    if op == 'query': return f'.query {r} {a[0]} ({a[1]})'
    if op == 'lam': return f'.lam {r} ({a[0]})'
    if op == 'host': return f'.host {r} {a[0]} {lean_rat(a[1])} {lean_rat(a[2])}'
    if op == 'idle': return f'.idle {r} {lean_set(a[0])} ({a[1]})'
    raise AssertionError(e)


def lean_set(st):
    return '∅' if not st else '{' + ', '.join(map(str,st)) + '}'


def lean_word(w,ports,joints):
    lines = ['/- Exact concrete data derived from #7864 normalized witness; generated by bridge.py.',
             '   This file has not been compiled or proved legal. See BRIDGE.md for the boundary.',
             f'   Caller SHA-256 {CALLER_SHA}; witness SHA-256 {WITNESS_SHA}. -/',
             'import Nov15.CallerWord', '', 'set_option maxRecDepth 16384',
             'set_option maxHeartbeats 0', '', 'namespace Caller7113Concrete', '']
    for ty in ('A','B'):
        lines += [f'def word{ty} : CallerWord.CWord 36 17 where', '  evs :=']
        events = w['primitive'][ty]
        chunks = [events[i:i+128] for i in range(0,len(events),128)]
        for index,chunk in enumerate(chunks):
            lines += ['    [']
            lines += ['      '+lean_event(e)+(',' if i+1<len(chunk) else '') for i,e in enumerate(chunk)]
            lines += ['    ]'+(' ++' if index+1<len(chunks) else '')]
        assert all(row[0] == -1 and row[1] == 0 for row in w['targets'][ty])
        lines += ['  ex := fun _ => -1', '  mask := fun r => ([']
        lines += ['    ('+lean_set(row[2])+' : Finset (Fin 17))'+(',' if i<35 else '')
                  for i,row in enumerate(w['targets'][ty])]
        lines += ['  ] : List (Finset (Fin 17))).getD r.val ∅', '']
    lines += ['/- Native port rows: pi, q, x, y, x2, y2; 1484 marks absent.',
              '   J rows: source event, 1-based stage, 4 A globals, 2 B globals,',
              '   alpha numerator/denominator, beta numerator/denominator. -/',
              'def nativePorts : List (List ℕ) := [']
    lines += ['  ['+', '.join(map(str,row))+']'+(',' if i+1<len(ports) else '') for i,row in enumerate(ports)]
    lines += [']', '', 'def sourceJ : List (List ℤ) := [']
    lines += ['  ['+', '.join(str(v) if v>=0 else f'({v})' for v in row)+']'+(',' if i+1<len(joints) else '') for i,row in enumerate(joints)]
    lines += [']', '', 'end Caller7113Concrete', '']
    return '\n'.join(lines)


def main():
    if not __debug__:
        raise RuntimeError('run without Python -O or PYTHONOPTIMIZE')
    p = argparse.ArgumentParser()
    p.add_argument('--pr7113', type=Path, default=ROOT/'sources'/'7113')
    p.add_argument('--pr7829', type=Path, default=ROOT/'sources'/'7829')
    p.add_argument('--pr7852', type=Path, default=ROOT/'sources'/'7852')
    p.add_argument('--allow-exports', action='store_true')
    args = p.parse_args()
    roots = {'7113':args.pr7113.resolve(),'7829':args.pr7829.resolve(),'7852':args.pr7852.resolve()}
    old = module(ROOT/'check.py'); verified = old.check_inputs(roots,args.allow_exports)
    craw = (roots['7829']/CALLER).read_bytes(); nraw = (roots['7113']/NATIVE).read_bytes()
    assert sha(craw) == CALLER_SHA and sha(nraw) == NATIVE_GZIP_SHA
    C = json.loads(craw); W = json.loads(gzip.decompress(nraw)); assert sha(canon(W)) == NATIVE_SHA
    wraw = (ROOT/'NORMALIZED.json').read_bytes(); assert sha(wraw) == WITNESS_SHA
    w = json.loads(wraw); rebuilt, violations = old.normalize(C)
    assert not violations and canon(rebuilt) == wraw
    cf = module(roots['7829']/'research/p104-certkit-pricekit-to-lean/tools/callerfacts.py')
    packed = old.check_packed(C,w,cf)
    mutant = copy.deepcopy(C)
    assert mutant['events'][43] == ['J',1,[1,0,18,19],[36,37,'-1','1/2']]
    mutant['events'][43][2][0] = 2
    mw, mbad = old.normalize(mutant)
    assert not mbad and len(set(mutant['events'][43][2])) == 4
    assert cf.encode(C) == cf.encode(mutant) and cf.invoice(C) == cf.invoice(mutant)
    ports,joints,contacts = contact_tables(C,W)
    native = native_reverse(W)
    _,mjoints,mcontacts = contact_tables(mutant,W)
    changed_contacts = [(a,b) for a,b in zip(contacts,mcontacts) if a != b]
    assert len(changed_contacts) == 96
    src = {t:rows0() for t in ('A','B')}; prim = {t:rows0() for t in ('A','B')}
    mut = {t:rows0() for t in ('A','B')}
    pos = {'A':0,'B':0}; prefix_checks = 0; mismatch = None; js = []
    for ci,(e,me) in enumerate(zip(C['events'],mutant['events'])):
        source(src,e,C['types']['A']['alpha2']); source(mut,me,C['types']['A']['alpha2'])
        pieces = expand(e,C['types']['A']['alpha2'])
        for ty,chunk in pieces.items():
            assert w['primitive'][ty][pos[ty]:pos[ty]+len(chunk)] == chunk
            for event in chunk: primitive(prim[ty],event)
            pos[ty] += len(chunk)
        assert src == prim, ('prefix source/primitive mismatch',ci,first_difference(src,prim))
        prefix_checks += 1
        if ci == 43:
            mismatch = first_difference(src,mut)
        if e[0] == 'J': js.append({'source_event':ci,'stage':e[1],
                                    'term_count':{t:sum(map(len,src[t])) for t in ('A','B')}})
    assert pos == {'A':1008,'B':3911} and prefix_checks == 4783
    original_bad = {t:endpoint(src[t],w['targets'][t]) for t in ('A','B')}
    mutant_bad = {t:endpoint(mut[t],w['targets'][t]) for t in ('A','B')}
    assert original_bad == {'A':[],'B':[]} and mutant_bad['A'] and mutant_bad['B'] == []
    assert mismatch and mismatch['type'] == 'A'
    artifact = {'schema':'p104-7113-native-contacts/1','native_public':W['public'],
                'native_sha256':NATIVE_SHA,'caller_sha256':CALLER_SHA,
                'columns':['source_event','stage_1based','port_index','native_q',
                           'native_x','native_y','caller_x_global','caller_y_global',
                           'native_x2','native_y2','caller_x2_global','caller_y2_global'],
                'native_absent_sentinel':W['public'],'caller_absent_sentinel':72,
                'contacts':contacts}
    (ROOT/'CONTACTS.json').write_bytes(canon(artifact))
    (ROOT/'Caller7113Concrete.lean').write_text(lean_word(w,ports,joints))
    result = {'schema':'p104-7113-exact-word-bridge/1', 'source_verification':verified,
              'coefficient_ring':'Q[i,q,D0..D16]/(i^2+1,q^4-1); independent commuting D indeterminates',
              'caller_sha256':CALLER_SHA,'native_sha256':NATIVE_SHA,'witness_sha256':WITNESS_SHA,
              'caller_records':len(C['events']), 'source_prefixes_equal_primitive_prefixes':prefix_checks,
              'expanded_primitives':pos, 'original_endpoint_bad_local_roles':original_bad,
              'stages':js,'exact_packed_stage_checks':packed,
              'contact_tuples':len(contacts),'a_port_tuples':17*96,'b_port_tuples':17*8,
              'native_conjugated_linear_replay':native,
              'contacts_json_sha256':sha((ROOT/'CONTACTS.json').read_bytes()),
              'lean_data_sha256':sha((ROOT/'Caller7113Concrete.lean').read_bytes()),
              'mutation':{'source_event':43,'from_A_global_role':1,'to_A_global_role':2,
                          'mutant_j_A_roles':mutant['events'][43][2],
                          'host_pairs_and_all_A_roles_distinct':True,'packed_data_and_invoice_equal':True,
                          'different_native_contact_tuples':len(changed_contacts),
                          'first_original_contact':changed_contacts[0][0],
                          'first_mutant_contact':changed_contacts[0][1],
                          'first_prefix_difference':mismatch,
                          'endpoint_bad_local_roles':mutant_bad,
                          'first_endpoint_difference':first_difference(src,mut)},
              'lean_compilation':'not run; generated Lean data are uncompiled',
              'scope':'Exact Python arithmetic and finite data; no kernel-checked parser, semantic soundness theorem or Legal instance.'}
    (ROOT/'BRIDGE-RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))


if __name__ == '__main__':
    main()
