#!/usr/bin/env python3
"""Verify the portable caller-word packet in a temporary independent copy."""
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

if not __debug__:
    raise RuntimeError('run without Python -O or PYTHONOPTIMIZE')
ROOT = Path(__file__).resolve().parent


def verify_hashes(root):
    count = 0
    for line in (root/'SHA256SUMS').read_text().splitlines():
        wanted,name = line.split('  ',1)
        path = root/name
        if len(wanted) != 64 or not path.is_file() or sha256(path.read_bytes()).hexdigest() != wanted:
            raise AssertionError('manifest mismatch: '+name)
        count += 1
    return count


def run(args,root):
    p = subprocess.run(args,cwd=root,capture_output=True,text=True,timeout=180)
    if p.returncode:
        raise AssertionError('command failed: '+p.stderr+'\n'+p.stdout)
    return p.stdout


def main():
    count = verify_hashes(ROOT)
    with tempfile.TemporaryDirectory(prefix='caller-word-replay-') as td:
        copy = Path(td)/'packet'
        shutil.copytree(ROOT,copy,ignore=shutil.ignore_patterns('__pycache__','*.pyc','replay.tar.gz','replay.tar.gz.sha256'))
        assert verify_hashes(copy) == count
        run([sys.executable,'-B','bridge.py','--allow-exports'],copy)
        data_check = run([sys.executable,'-B','check_lean_data.py'],copy).strip()
        assert verify_hashes(copy) == count
    print(f'PASS portable caller-word replay: {count} pinned packet files')
    print(data_check)
    print('Source exports: file-hash verification; Lean compilation: not performed.')


if __name__ == '__main__': main()
