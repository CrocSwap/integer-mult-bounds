#!/usr/bin/env python3
"""Read generated Lean literals back to the public witness and contacts.

This small format-specific parser checks data preservation only. It does not
parse Lean generally and does not replace elaboration or kernel checking.
"""
import ast
from fractions import Fraction
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
if not __debug__:
    raise RuntimeError('run without Python -O or PYTHONOPTIMIZE')


def rational(text):
    text = text.lstrip()
    m = re.match(r'^\(\((-?\d+) : ℚ\) / (\d+)\)',text)
    if m: return str(Fraction(int(m[1]),int(m[2]))),text[m.end():].lstrip()
    m = re.match(r'^\((-?\d+) : ℚ\)',text)
    assert m, text
    return str(Fraction(int(m[1]))),text[m.end():].lstrip()


def event(line):
    line = line.strip().rstrip(',')
    m = re.fullmatch(r'\.(\w+) (\d+) (.+)',line)
    assert m, line
    op,r,rest = m[1],int(m[2]),m[3]
    if op in ('add','host'):
        m = re.match(r'^(\d+) (.+)$',rest); assert m
        s,rest = int(m[1]),m[2]; a,rest = rational(rest)
        if op == 'add':
            assert not rest; return [op,r,s,a]
        b,rest = rational(rest); assert not rest
        return [op,r,s,a,b]
    if op == 'scale':
        a,rest = rational(rest); assert not rest; return [op,r,a]
    if op == 'swap':
        return [op,r,int(rest)]
    if op in ('lam','query'):
        m = re.fullmatch(r'(?:(\d+) )?\((-?\d+)\)',rest); assert m
        if op == 'lam': assert m[1] is None; return [op,r,int(m[2])]
        assert m[1] is not None; return [op,r,int(m[1]),int(m[2])]
    if op == 'idle':
        m = re.fullmatch(r'(∅|\{[\d, ]+\}) \((-?\d+)\)',rest); assert m
        stages = [] if m[1] == '∅' else [int(x) for x in re.findall(r'\d+',m[1])]
        return [op,r,stages,int(m[2])]
    raise AssertionError(('unknown',line))


def normalized(ev):
    out = ev.copy()
    for i in {'add':(3,), 'scale':(2,), 'host':(3,4)}.get(ev[0],()):
        out[i] = str(Fraction(out[i]))
    return out


def list_literal(lines,name):
    start = next(i for i,line in enumerate(lines) if line.startswith('def '+name+' :'))
    end = next(i for i in range(start+1,len(lines)) if lines[i] == ']')
    return ast.literal_eval('[' + '\n'.join(lines[start+1:end]) + ']')


def main():
    w = json.loads((ROOT/'NORMALIZED.json').read_bytes())
    contact = json.loads((ROOT/'CONTACTS.json').read_bytes())
    lines = (ROOT/'Caller7113Concrete.lean').read_text().splitlines()
    starts = {t:next(i for i,x in enumerate(lines) if x.startswith('def word'+t+' :')) for t in ('A','B')}
    ends = {'A':starts['B'], 'B':next(i for i,x in enumerate(lines) if x.startswith('/- Native port'))}
    for t in ('A','B'):
        chunk = lines[starts[t]:ends[t]]
        actual = [event(x) for x in chunk if x.strip().startswith('.')]
        expected = [normalized(e) for e in w['primitive'][t]]
        assert actual == expected, (t, len(actual),len(expected))
        assert sum('ex := fun _ => -1' in x for x in chunk) == 1
        masks = []
        for x in chunk:
            s = x.strip()
            if s.startswith('({') or s.startswith('(∅'):
                body = s.split(' : Finset',1)[0]
                masks.append([int(y) for y in re.findall(r'\d+',body)])
        assert masks == [row[2] for row in w['targets'][t]]
    ports = list_literal(lines,'nativePorts'); js = list_literal(lines,'sourceJ')
    assert len(ports) == 104 and len(js) == 17
    expected_js = []
    for i,e in enumerate(w['records']):
        if e[0] == 'J':
            _,st,a,b = e
            assert b[2:] == ['-1','1/2']
            expected_js.append([i,st+1,*a,b[0]+36,b[1]+36,-1,1,1,2])
    assert js == expected_js
    rebuilt = []
    for ci,st,a,b,c,d,s,t,an,ad,bn,bd in js:
        assert (an,ad,bn,bd) == (-1,1,1,2)
        for pi,q,x,y,x2,y2 in ports:
            if x2 != contact['native_absent_sentinel']:
                row = [ci,st,pi,q,x,y,a,b,x2,y2,c,d]
            else:
                row = [ci,st,pi,q,x,y,s,t,x2,y2,72,72]
            rebuilt.append(row)
    assert rebuilt == contact['contacts']
    print(json.dumps({'parsed_events':{'A':1008,'B':3911},'target_masks':72,
                      'native_ports':len(ports),'source_j':len(js),
                      'reconstructed_contact_tuples':len(rebuilt),
                      'lean_compilation':'not performed'},sort_keys=True))


if __name__ == '__main__': main()
