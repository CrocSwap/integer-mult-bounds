# P104 caller word: exact prefix, endpoint and native-contact bridge

This packet provides a reproducible local check linking the pinned #7113 caller
records and #7112 native field assignments to the concrete event data expected
by #7852 `CallerWord`. It keeps q, i and all stage variables independent apart
from `q⁴ = 1` and `i² = -1`. The companion `BRIDGE.md` gives the equations,
the two distinct-role control witnesses, the scope and the remaining proof
obligations.

**Lean was not run.** `Caller7113Concrete.lean` contains generated concrete
data, but is uncompiled and has no checked `CallerWord.Legal` proof. The local
Python checks do not prove a Lean parser, source hash, polynomial evaluator,
or native physical geometry inside the kernel. No new κ claim is made.

The original direct-record and primitive-event row computations agree after
all 4,783 source records and match all 72 target rows. A first-J A-role change
`1 → 2` keeps all owners distinct and preserves the #7829 packed data and
invoice, yet changes 96 native contact tuples and breaks A output rows 0, 1,
and 2. A separate exact reverse computation checks all 1,484 public rows of
the #7112 native in chart-conjugated scalar coordinates; MOVE frame and phase
geometry remain separate. The 1,768 stage/port assignments are in
`CONTACTS.json`.

## Reproduce offline

The packet contains only the specific pinned source files required by this
check, not entire checkouts. Python 3 and the standard library are sufficient.
Run from this directory with assertions enabled:

```sh
python3 -B verify_packet.py
```

The verifier checks `SHA256SUMS`, copies the packet to a fresh temporary
directory, runs the one-process computation using the included source exports,
reads the emitted Lean literals back, then checks that all manifest files,
including the full receipt and emitted data, remain byte-identical. Its
subprocess timeout is 180 seconds. The initial recorded one-process run used a
4 GiB virtual-memory cap and about 94 MiB peak RSS. The offline fresh-copy
replay completed in 36.77 seconds and 94,324 KiB peak RSS on the contributor's
machine. In a separate temporary copy, appending one byte to the pinned caller
was rejected both by the packet manifest and, when invoking the bridge
directly, by the inherited source-file pin. On a POSIX shell, to impose
the same cap use:

```sh
(ulimit -v 4194304; python3 -B verify_packet.py)
```

For direct replay without a temporary copy, run
`python3 -B bridge.py --allow-exports` and then
`python3 -B check_lean_data.py`. `bridge.py` rewrites the receipt and two
generated data files in its own directory; deterministic output should match
the included manifest. Running with `-O` or `PYTHONOPTIMIZE` is unsupported.

## Source pinning and attribution

The `sources/` directories are partial, byte-for-byte source exports. Their
files are checked both by the packet manifest and by the inherited
`SOURCE-PINS.json`/`check.py` pins. An offline export has no `.git`, so the
receipt correctly reports **file-hash verification only**: the commit
associations below are provenance information, not an independently verified
Git HEAD from this offline replay. To verify against checkouts, obtain the
following commits, check `git rev-parse HEAD`, and pass their repository roots
using `--pr7113`, `--pr7829`, and `--pr7852` without `--allow-exports`.

| Source | Pinned commit | Public source |
| --- | --- | --- |
| #7113 | `07a76c5e2738882c0cb322278e56f6cae3c9885d` | [rohanarun/integer-mult-bounds](https://github.com/rohanarun/integer-mult-bounds/tree/07a76c5e2738882c0cb322278e56f6cae3c9885d/research/signed-caller-8x9) |
| #7829 | `1fdc9ecd1b1311d8ea6e02b6f81ae0d8d24999e2` | [DreamingOfClouds/integer-mult-bounds](https://github.com/DreamingOfClouds/integer-mult-bounds/tree/1fdc9ecd1b1311d8ea6e02b6f81ae0d8d24999e2/research/p104-certkit-pricekit-to-lean) |
| #7852 | `41beda1d6435760dc99e38bd7e65f36798aad212` | [DreamingOfClouds/integer-mult-bounds](https://github.com/DreamingOfClouds/integer-mult-bounds/tree/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit) |
| #7864 witness | `4cc3d68b2e114b17d7b4096c2012dd783da221f4` | [CrocSwap/integer-mult-bounds PR 7864](https://github.com/CrocSwap/integer-mult-bounds/pull/7864) |

`SOURCE-PINS.json` lists the precise relative source paths and SHA-256 values.
The public #7864 archive has SHA-256
`c272074680819ef0ea05eb30c5231bd13186b9d69cabfa2999f326cf64edb1ab`;
its normalized witness and checker are retained here. `PREDECESSOR-README.md`,
`PREDECESSOR-NOTICE.md` and `RECEIPT.json` are historical predecessor
materials. Their standalone/full-package reproduction instructions require
complete source packages and describe prior checks, not additional checks run
by this packet. The predecessor notice describes its own original archive;
this packet does redistribute the pinned partial source files in `sources/`.

The #7113 caller is by Rohan Arun with substantial OpenAI Codex assistance
and the contributors credited upstream. #7829 and #7852 are by DreamingOfClouds
with Claude Opus 5.5 via Claude Code, building on the credited P104 sources.
The #7864 witness is by Clear1nsight with substantial OpenAI Codex assistance.
The predecessor notices and upstream notices and licenses are retained in
`source-notices/`; the accompanying `LICENSE` is Apache-2.0.

## Open next questions

Compile the generated words against #7852's pinned Lean toolchain and Mathlib,
then prove the source-record/constructor correspondence, coefficient-ring
replay, quotient evaluation, and both `CallerWord.Legal` instances in the
kernel. The first blocker is that this packet has not run Lean; physical frame
and phase geometry and the connection to other native words remain separate.
