# BIT 469: a mixed-owner boundary screen

The two nominated windows cannot carry the new independent chart-524 input through the stipulated fixed old interface while preserving all old spectator outputs, even if the three owners `255`, `468`, and `469` are decoded together and an extra output at chart 601 is freely available. This is an exact **scoped negative result**; it is not a changed supplier, paid saving, or new κ bound. [Proof and scope](PROOF.md) · [Complete computed receipt](EXPECTED.json)

The local read is `x468+x469` and the only joint 1-boundary owner pulse is `e255+e469`, with pairing one. The verifier enumerates the six dual bases extending this pair. It checks all 677 spectator output equations, not just an assumed pure middle readout: their 22 first/second egress columns force first-chart changes to be readable from seven second-chart stocks. Those stocks have rank six even on spectator inputs alone, and their sole relation stays zero under all first-chart changes. The resulting dimension argument rules out the independent new signal even with coordinated exterior decoding and a free extra middle output.

The exact original source support and all 17+5 egress coefficients for **each** spectator output, plus the seven stock rows and full response matrices, are pinned in [SPECTATOR-ROWS.json](SPECTATOR-ROWS.json). Its SHA-256 is `7212658f503f8b064c641adf83989c8a8f926cc8495f22fd08b0d9efdab40d13`. An entirely spectator-only scalar witness, the six bases, exact ranks, the late-stock feedback check and positive and negative mutation controls appear in the receipt.

## Offline verification

From this directory, using the Python standard library:

```sh
python3 -IB verify.py
```

Expected:

```text
PASS_BIT469_COORDINATED_BOUNDARY bases=6 spectator_rows=677 old_rank=6 egress_rank=19 controls=7 baseline_coefficients_each_way=462400
```

The verifier authenticates the compressed word, extractor, complete 677-row fixture, and expected result; reconstructs exact rational chart containments and the original graph; checks every 680-column old forward and adjoint transfer by a separate literal interpreter; and exercises an omitted-CLEAR rejection. It calculates all stock, output and feedback ranks from the pinned bytes. It runs without network access, external libraries, or writes. The six other in-memory controls test the decisive matrix relations and a free extra-observation positive control. No modified physical program is replayed.

The fixed-interface relaxation grants arbitrary first egress functions, free and late copies of all seven listed stocks, arbitrary local second-window output recoding and free joint decoding across the named owner outputs. It does not include a changed old source route, another paid observation, a broader owner set, different windows or an additional cross-chart endpoint operation. A positive control shows exactly how an extra pristine copy of the first stock would invalidate the dimensional separator, but does not provide or price such a copy. [Source and provenance pins](SOURCES.json) · [Credits](NOTICE)
