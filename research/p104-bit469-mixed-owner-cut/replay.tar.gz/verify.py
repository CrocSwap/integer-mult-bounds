#!/usr/bin/env python3
"""Exact fixed-interface 3-owner, 2-window BIT separator. Standard library only.

The raw equations are replayed on all 680 columns, then the 22-column output
kernel is checked rather than assuming that the middle return is pure.  No
candidate word or price is claimed. See REPORT.md for the linear argument.
"""
from pathlib import Path
from fractions import Fraction
from itertools import product
import gzip, hashlib, importlib.util, json, sys

H = Path(__file__).resolve().parent
W = H / 'inputs' / 'WORD.json.gz'
E = H / 'inputs' / 'bit_native.py'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(W) == 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
assert sha(E) == '4368c62a5d42f81189d6776b8dba8c85a311b6a199b816244b545c6bb7d3dc1e'
w = json.loads(gzip.decompress(W.read_bytes()))
assert hashlib.sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest() == 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
spec=importlib.util.spec_from_file_location('pinned_bit_native', E)
edge=importlib.util.module_from_spec(spec); sys.modules[spec.name]=edge; spec.loader.exec_module(edge)
I,T,moves,rows,clocks=edge.extract(w); order=edge.schedule(I,T,moves,rows)
N=w['public']; assert N==680 and len(order)==2874
idx=lambda x:list(edge.indices(x))
def rank(xs):
    b={}
    for x in xs:
        while x:
            p=x.bit_length()-1
            if p in b: x ^= b[p]
            else: b[p]=x; break
    return len(b)
def kernel_columns(xs):
    b={}; out=[]
    for i,x in enumerate(xs):
        z=1<<i
        while x:
            p=x.bit_length()-1
            if p in b: x^=b[p][0]; z^=b[p][1]
            else: b[p]=(x,z); break
        if x==0: out.append(z)
    return out

def gf2_dot(x,y): return (x&y).bit_count()&1
values={i:1<<i for i in I}
for k in order: values[k]=edge.combine(rows[k],values)
columns={k:0 for k in I.keys() | moves.keys()}
for r in I:
    for j in edge.indices(rows[~r]): columns[j]^=1<<r
for k in reversed(order):
    for j in edge.indices(rows[k]): columns[j]^=columns[k]
for r in I:
    assert edge.combine(rows[~r], values)==((1<<r)^((1<<(r-111)) if 111<=r<222 else 0))
    assert columns[r]==((1<<r)^((1<<(r+111)) if r<111 else 0))

owners=(255,468,469)
O=sum(1<<i for i in owners); outside=((1<<N)-1)^O
q=(1<<468)|(1<<469); d=(1<<255)|(1<<469)
assert gf2_dot(q,d)==1 and all(I[i]==0 and T[i]==1 for i in owners)
assert w['program'][4294]==['MOVE',1862,251,447]
assert w['program'][9627]==['MOVE',2753,447,1]
assert values[1854]^values[1862]==q

def contained(a,b):
    x,y=w['frames'][str(a)],w['frames'][str(b)]
    return x['dim']<y['dim'] and all(sum(Fraction(i)*Fraction(j) for i,j in zip(u,v))==0 for u in x['B'] for v in y['A'])
assert [w['frames'][str(i)]['dim'] for i in (0,524,601,1)]==[0,4,7,8]
assert all(contained(a,b) for a,b in ((0,524),(524,601),(601,1),(251,524),(524,447),(447,601)))

# Every later chart-524 send and the continuation of the first cut, plus
# two chart-524 terminals. The 601 list analogously includes the second cut.
c1=sorted([k for k,(a,_) in moves.items() if a==524 and clocks[k]>4294]+[1862],key=clocks.get)
assert len(c1)==15 and c1[0]==1862
term1=sorted(r for r,z in T.items() if z==524); assert term1==[658,659]
E1=[columns[k] for k in c1]+[1<<r for r in term1]
labels1=[f'move:{k}@{clocks[k]}' for k in c1]+[f'terminal:{r}' for r in term1]
c2=sorted([k for k,(a,_) in moves.items() if a==601 and clocks[k]>9627],key=clocks.get)
term2=sorted(r for r,z in T.items() if z==601)
assert c2==[3163,3164,3291] and term2==[187]
assert not [k for k,(a,_) in moves.items() if a==601 and clocks[k]<=9627]
E2=[columns[k] for k in c2]+[1<<187,columns[2753]]
labels2=[f'move:{k}@{clocks[k]}' for k in c2]+['terminal:187','second-continuation:2753@9627']
assert len(E1)==17 and len(E2)==5 and rank(E1)==17 and rank(E2)==5 and rank(E1+E2)==19
assert rank(E1+[1<<i for i in owners])==20  # E1 has zero intersection with O
assert rank(E1+E2+[1<<i for i in owners])==21  # union intersects O in dimension 1
assert columns[3163]==d
j0=c1.index(1862);j1=c1.index(2407);j2=c1.index(3289)
assert E2[1] == d ^ E1[j0] ^ E1[j1]
assert E2[2] == d ^ E1[j0] ^ E1[j2]
assert E2[3] == d ^ E1[j0]
assert rank(E1+[d,E2[4]]) == 19

# All 677 spectator-output conditions on ALL first/second scalar egress
# changes. The complete nullspace has four parameters, including the three
# named egress relations and the one admissible owner response d.
K=kernel_columns([v&outside for v in E1+E2]); assert len(K)==4 and rank(K)==4
for z in K:
    f=z & ((1<<len(E1))-1); g=z>>len(E1)
    assert ((f>>j0)&1) == (((g>>1)^(g>>2)^(g>>3))&1)
    assert ((f>>j1)&1) == ((g>>1)&1)
    assert ((f>>j2)&1) == ((g>>2)&1)
    assert f & ~((1<<j0)|(1<<j1)|(1<<j2)) == 0
    assert (g>>4)&1 == 0
    total=0
    for i in edge.indices(z): total ^= (E1+E2)[i]
    assert total == (d if (g&15).bit_count()%2 else 0)

# R contains every 601 arrival plus ALL original 447 sender stocks at the
# second cut, even granted as free immediate copies. The S columns give their
# full response to independent first-egress changes; terminal controls have 0.
sender=[r for r,c in I.items() if c==447]+[k for k,(_,b) in moves.items() if b==447 and clocks[k]<9627]
receiver=[r for r,c in I.items() if c==601]+[k for k,(_,b) in moves.items() if b==601]
assert sender==[1862,2085,2239] and receiver==[2752,2762,3290,3505]
stock=sender+receiver
R=[values[k] for k in stock]
responses={r:0 for r in I}; ci={k:i for i,k in enumerate(c1)}
for k in order:
    v=edge.combine(rows[k],responses)
    if k in ci: v^=1<<ci[k]
    responses[k]=v
S=[responses[k] for k in stock]
# Include ALL feedback from the five second-chart egress changes into the
# seven recorded stocks, including the very late arrival at clock 28054.
# Terminal 187 is an endpoint, so has no outgoing packet of its own.
responses2={r:0 for r in I}; ci2={3163:0,3164:1,3291:2,2753:4}
for k in order:
    z=edge.combine(rows[k],responses2)
    if k in ci2: z^=1<<ci2[k]
    responses2[k]=z
T_feedback=[responses2[k] for k in stock]
assert T_feedback==[0]*len(stock)
assert rank(R)==rank([r&outside for r in R])==6
rel=kernel_columns(R); rel_spect=kernel_columns([r&outside for r in R])
assert rel==rel_spect==[sum(1<<stock.index(k) for k in (1862,2085,2239,2752))]
for relation in rel:
    assert not __import__('functools').reduce(int.__xor__,[S[i] for i in edge.indices(relation)],0)

# Enumerate all GL(3,2) dual bases. For each first dual row q and paired
# source direction d, project the old source to ker(q): P=I+dq. The seven
# old rows still have rank six (the 677 spectator columns already supply it).
# Only six of the 168 bases use BOTH actually observed q and actual egress d;
# other bases are algebraic controls, not claims of local admissibility.
def lift(v): return sum(1<<owners[j] for j in range(3) if v>>j&1)
def dual(cols):
    return tuple(next(r for r in range(8) if all(gf2_dot(r,c)==(i==j) for j,c in enumerate(cols))) for i in range(3))
bases=[]
for cols in product(range(1,8),repeat=3):
    if rank(cols)!=3: continue
    rows3=dual(cols); q3,d3=rows3[0],cols[0]
    assert gf2_dot(q3,d3)==1
    Q,D=lift(q3),lift(d3)
    projected=[r ^ (Q if gf2_dot(r,D) else 0) for r in R]
    assert rank(projected)==6 and kernel_columns(projected)==rel
    bases.append((cols,rows3))
assert len(bases)==168
chosen=[(c,r) for c,r in bases if lift(c[0])==d and lift(r[0])==q]
assert len(chosen)==6 and len({(c[0],r[0]) for c,r in bases})==28

def literal(reverse, omitted_clear=None):
    banks=[1<<j for j in range(N)]+[0]*w['owned_fields']; tags=list(w['final' if reverse else 'start'])+[None]*w['owned_fields']
    dirty=clears=0
    for t in (range(len(w['program'])-1,-1,-1) if reverse else range(len(w['program']))):
        op,r,*args=w['program'][t]
        if t==omitted_clear:
            assert op=='CLEAR'
            continue
        if op in ('INIT','CLEAR'):
            opens=(op=='CLEAR') if reverse else (op=='INIT'); chart=args[0]
            if opens: assert tags[r] is None; tags[r]=chart; banks[r]=0
            else: assert tags[r]==chart; dirty+=bool(banks[r]); clears+=1; tags[r]=None; banks[r]=0
        elif op=='ADD':
            s,chart=args; assert tags[r]==tags[s]==chart and r!=s
            if reverse: banks[s]^=banks[r]
            else: banks[r]^=banks[s]
        elif op=='SWAP':
            s=args[0]; assert tags[r] is not None and tags[s] is not None
            banks[r],banks[s]=banks[s],banks[r]; tags[r],tags[s]=tags[s],tags[r]
        else:
            assert op=='MOVE'; a,b=args[::-1] if reverse else args
            assert tags[r]==a; tags[r]=b
    assert tags==list(w['start' if reverse else 'final'])+[None]*w['owned_fields']
    assert not any(banks[N:]) and clears==w['owned_fields']
    expected=[((1<<r)^((1<<(r+111)) if r<111 else 0)) if reverse else ((1<<r)^((1<<(r-111)) if 111<=r<222 else 0)) for r in I]
    assert banks[:N]==expected
    return {'all_public_coefficients':N*N,'retirement_instructions':clears,'dirty_retirements':dirty}
forward=literal(False); backward=literal(True)
assert forward['dirty_retirements']==backward['dirty_retirements']==3554
# A removed CLEAR must be detected in the separate literal baseline engine.
omit=next(t for t,op in enumerate(w['program']) if op[0]=='CLEAR')
try:
    literal(False,omit)
except AssertionError:
    pass
else:
    raise AssertionError('omitted-CLEAR mutation was not detected')

# A fully spectator-only two-world witness independent of the owner basis.
def scalar_world(active,inject):
    banks=[int(i in active) for i in range(N)]+[0]*w['owned_fields']; tags=list(w['start'])+[None]*w['owned_fields']; found={}
    for t,(op,r,*args) in enumerate(w['program']):
        if t==9627:
            for k in sender:
                assert tags[k]==447; found[f'sender:{k}']=banks[k]
        if op=='INIT': assert tags[r] is None; banks[r]=0; tags[r]=args[0]
        elif op=='CLEAR': assert tags[r]==args[0]; banks[r]=0; tags[r]=None
        elif op=='ADD':
            s,c=args; assert tags[r]==tags[s]==c; banks[r]^=banks[s]
        elif op=='SWAP':
            s=args[0]; banks[r],banks[s]=banks[s],banks[r]; tags[r],tags[s]=tags[s],tags[r]
        else:
            assert op=='MOVE'; a,c=args; assert tags[r]==a
            if t==4294 and inject: banks[r]^=1
            if r in receiver and clocks[r]==t: found[f'arrival:{r}']=banks[r]
            tags[r]=c
    return found
world_a=scalar_world([],True); world_b=scalar_world([105,187],False)
assert world_a==world_b and len(world_a)==7
assert (q&((1<<105)|(1<<187)))==0 and (O&((1<<105)|(1<<187)))==0

# Positive control: a pristine extra copy of stock 1862 is a freely granted
# NEW communication, not a physical construction. It exposes z and allows
# F1862=G3163=Gterminal=z with zero change at every original final output.
modified=[R[i] ^ ((1<<N) if S[i]&1 else 0) for i in range(len(R))]+[R[0]]
assert rank(R+[R[0]])==6 and rank(modified)==7
assert E1[j0]^E2[0]^E2[3]==0
assert S[0]&1 and not (S[1]&1)

# Frozen *all* 677 spectator equations, not only a list of their indices.
# Every entry records its full original source support and the exact 17+5
# first/second egress coefficients. Seven full stock rows and their complete
# first-control responses are pinned in the same independently stored file.
fixture=H/'SPECTATOR-ROWS.json'
assert sha(fixture)=='7212658f503f8b064c641adf83989c8a8f926cc8495f22fd08b0d9efdab40d13'
frozen=json.loads(fixture.read_text())
actual=[]
for i in range(N):
    if i in owners: continue
    actual.append({'output':i,'old_source_support':idx(edge.combine(rows[~i],values)),
      'first_egress_mask':f"{sum((int(bool(v>>i&1))<<j) for j,v in enumerate(E1)):05x}",
      'second_egress_mask':f"{sum((int(bool(v>>i&1))<<j) for j,v in enumerate(E2)):02x}"})
assert len(actual)==677 and frozen['rows']==actual
assert frozen['excluded_owner_output_roles']==list(owners) and frozen['first_egress_order']==labels1 and frozen['second_egress_order']==labels2
assert frozen['stock_order']==stock and frozen['stock_old_source_support']==[idx(r) for r in R]
assert frozen['stock_first_egress_response_mask']==[f'{x:05x}' for x in S]
assert frozen['stock_second_egress_feedback_mask']==[f'{x:02x}' for x in T_feedback]
# Decisive in-memory mutations: disrupt the unique old relation, disrupt its
# response, corrupt one exact output identity, omit one required spectator,
# and deny the basis pairing. The positive missing-stock control is above.
bad_R=R.copy(); bad_R[0]^=1<<105
assert rank(bad_R)==7
bad_S=S.copy(); bad_S[0]^=1
assert __import__('functools').reduce(int.__xor__,[bad_S[i] for i in edge.indices(rel[0])],0)!=0
bad_E2=E2.copy(); bad_E2[1]^=1<<8
assert bad_E2[1] != d^E1[j0]^E1[j1] and rank(E1+bad_E2)==20
assert rank([(v&outside&~(1<<187)) for v in E1+E2])==17
assert rank([(v&outside) for v in E1+E2])==18
assert gf2_dot(q,1<<255)==0

receipt={
 'status':'SCOPED_NEGATIVE_COORDINATED_BOUNDARY','pr':7830,'head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'word_gzip_sha256':sha(W),'extractor_sha256':sha(E),'public_coefficients_per_direction':N*N,
 'owners':list(owners),'first_local_read':[468,469],'only_joint_owner_output_direction':[255,469],
 'charts':[0,524,601,1],'clocks':[4294,9627],
 'basis_enumeration':{'all_dual_bases':168,'all_q_d_pairs':28,'fixed_observed_q_and_d_bases':len(chosen),
   'basis_coordinates_order':list(owners),'fixed_q_and_d_bases':[{'columns':[idx(lift(x)) for x in c],'dual_rows':[idx(lift(x)) for x in r]} for c,r in chosen],
   'every_ker_q_old_stock_rank':6,'additional_162_are_algebraic_controls_only':True},
 'output_egress':{'first_labels':labels1,'second_labels':labels2,'first_rank':17,'second_rank':5,'combined_rank':19,
  'first_intersection_named_owner_space_rank':0,'combined_intersection_named_owner_space_rank':1,
  'spectator_nullity':len(K),'forced_equations':['F1862=G3164+G3291+Gterminal187','F2407=G3164','F3289=G3291','all other F=0','G2753=0'],
  'owner_response':'d*(G3163+G3164+G3291+Gterminal187)'},
 'stocks':{'senders':sender,'arrivals':receiver,'old_row_rank':6,'spectator_only_row_rank':6,
  'sole_row_relation':[1862,2085,2239,2752],'relation_annihilates_all_first_controls':True,'first_control_count':len(E1),
  'second_egress_feedback_into_stocks':T_feedback},
 'literal_baseline':{'forward':forward,'adjoint':backward},
 'spectator_only_scalar_witness':{'injected_world':world_a,'old_pulse':[105,187],'equal_world':world_b},
 'positive_control':{'additional_pristine_old_packet_1862_copy':'free, NOT an available unchanged stock or a priced construction',
   'old_rank':6,'rank_with_new_signal':7,'recodings':'F1862=G3163=Gterminal187=z','original_final_outputs_unchanged':True},
 'scope':'Linear modified word with fixed source rows and old exterior except the first/second window egresses; 601 sees only seven stated stock rows, though freely and without time or price. Both scalar chart outputs and all owner output decoding are allowed. An extra earlier observation/route, changed other exterior packets or an additional paid message are outside this cut.',
 'candidate_constructed':False,'invoice':'No achieved candidate; not priced as an achieved signed tariff.',
 'mutations':{'old_stock_row_corruption_changes_rank_6_to_7':True,'control_response_corruption_breaks_relation':True,
  'one_egress_bit_corruption_changes_union_rank_19_to_20':True,'omit_spectator_187_changes_projected_rank_18_to_17':True,
  'zero_pairing_rejected':True,'omitted_clear_rejected_by_literal_baseline':True,
  'pristine_observation_is_positive_control':True},
 'spectator_rows_sha256':'7212658f503f8b064c641adf83989c8a8f926cc8495f22fd08b0d9efdab40d13'}
expected=H/'EXPECTED.json'
assert sha(expected)=='55557a0381e3c652ef005d7e845dc3bf6941c3bfa70501dacc9e56ab974ea0e1'
assert receipt==json.loads(expected.read_text())
print('PASS_BIT469_COORDINATED_BOUNDARY bases=6 spectator_rows=677 old_rank=6 egress_rank=19 controls=7 baseline_coefficients_each_way=462400')
