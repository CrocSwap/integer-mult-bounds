# Coordinated three-owner boundary: exact fixed-interface obstruction

Work over GF(2). The frozen #7830 binary carrier has 680 old input and output roles. Roles `255`, `468`, and `469` each independently start at chart `0`, return at chart `1`, and have identity transfer. All other 677 output roles are spectators. We study the exact original windows `4294` and `9627`, with first intermediate chart `524` and second chart `601`. The first local old read is `q=x468+x469`; the sole attainable nonzero output direction supported on the three named owners is `d=e255+e469`, with `q d=1`. The six completions of this fixed pair to dual ordered bases are listed in [EXPECTED.json](EXPECTED.json). The verifier enumerates all 168 three-dimensional dual bases, but the other 162 are algebraic controls: no claim is made that their readouts are available locally.

The precise tested contract is an **optimistic linear relaxation**. The old word and all exterior routes are fixed. A proposed new independent signal `z` starts at chart 524. All 17 first-window egress changes `F` may be arbitrary linear functions of every old input and `z`, with no locality, price, timing, or dirty-carry restriction. The second-chart egress changes `G` may use free persistent copies of all seven stocks below, even after the actual deadline. A separately selected output at 601 may be *any* linear combination of these stocks. All three named chart-1 owner returns, and even this extra 601 value, may be jointly decoded without price. The 677 spectator outputs must nevertheless remain correct. The first chart-524 return is the specified old `q` return; this test does not permit replacing that return with the new independent `z`. No assumption requires a pure middle readout.

Allowing the first `q` return to remove its old direction leaves the source space `ker(q)`; the verifier checks the old stock rank below for that quotient for all six bases, and indeed for all 168 algebraic basis choices. The same argument also works if the full old source space is retained. An arbitrary encoding or decoding confined to the three named owners fixes all spectator inputs and cannot evade the row-rank check.

## The full spectator output kernel

Let `E1` have one 680-output impulse column for each of the 15 first-chart sender controls, including the subdivided continuation of packet `1862`, and the two existing chart-524 terminals. Let `E2` contain impulses for packet `3163`, packet `3164`, packet `3291`, terminal `187`, and the second-cut continuation of packet `2753`, in that order. These impulses are calculated on the complete old packet graph, not on a projected three-owner graph. The exact egress labels and clocks are in [EXPECTED.json](EXPECTED.json); [SPECTATOR-ROWS.json](SPECTATOR-ROWS.json) stores every one of the 677 original spectator source rows and its complete 17+5 impulse coefficients.

The checked ranks are

```
rank(E1) = 17,   rank(E2) = 5,   rank([E1 E2]) = 19,
span(E1) ∩ O = {0},    span([E1 E2]) ∩ O = span(d),
```

where `O` is the three-coordinate output space. The following identities hold as full 680-coordinate columns:

```
E2(3163) = d
E2(3164) = d + E1(1862) + E1(2407)
E2(3291) = d + E1(1862) + E1(3289)
E2(terminal 187) = d + E1(1862).
```

Projecting `[E1 E2]` to all 677 spectator coordinates has rank 18 and nullity 4. Complete elimination, not a single witness, shows that every perturbation whose spectator outputs all vanish must obey

```
F(1862) = G(3164) + G(3291) + G(terminal 187)
F(2407) = G(3164)
F(3289) = G(3291)
all other F = 0, and G(2753) = 0.
```

The remaining owner-only output is `d` times `G(3163)+G(3164)+G(3291)+G(terminal 187)`. Thus **every component of F is in the span of G**. These equations allow all owner output recodings: only the spectator outputs were constrained.

## The stock kernel forces loss of the new signal

Let `R` be the seven old-input rows for the three 447 sender stocks `[1862,2085,2239]` and all four 601 arrivals `[2752,2762,3290,3505]`. Let `S` be their response to the 17 first-chart controls, and let `T` be their response to the five second-chart egress changes. The receipt checks every coefficient and the exact future stock at packet `3505`:

```
rank(R) = 6;  rank(R restricted to spectator inputs) = 6;
R1862 + R2085 + R2239 + R2752 = 0;
S1862 + S2085 + S2239 + S2752 = 0;
T = 0  (all seven stocks by all five second-chart controls).
```

The displayed row relation is the **complete** left kernel of `R`, also after restricting to spectator inputs. It remains a stock relation even after any first or second egress changes. Since spectator inputs alone already give rank six, the same rank holds after any quotient of the three-owner input space that leaves spectators independent, including `ker(q)` in each checked dual basis.

Write `Y = R x + S F + T G` for the seven available stock values. All rows of `G` and any extra 601 return lie in `rowspan(Y)`. The spectator output kernel above implies all rows of `F` also lie in `rowspan(Y)`. Consequently

```
rowspan(R) ⊆ rowspan(Y),    rank(R) = 6,
rank(Y) ≤ 6                (the same nonzero seven-stock relation persists).
```

Hence `rowspan(Y)=rowspan(R)`. The old rows `R` contain no `z`, so neither the stocks nor `F` nor `G` contain `z`. The named exterior outputs and any 601 readout therefore have zero `z` coefficient. No invertible decoder of those outputs can restore this independent input. The 0→524 first return is fixed as above, so the additional signal required for the 524→601 daughter cannot be returned. This proves a **necessary fixed-interface obstruction**, not a global impossibility theorem.

A literal scalar witness illustrates a weaker but concrete fact: toggling only the first continuation with zero old inputs gives exactly the same seven stock values as no toggle and setting only old spectator inputs `105` and `187`. The witness uses no owner input, so it survives every basis of the three owners; the kernel proof, not this one witness, covers all first controls and coordinated output recodings.

## Controls and limits

If a separate, pristine copy of original stock `1862` were granted to 601 for free, the changed stocks would acquire rank seven. The explicit optimistic control `F1862=G3163=Gterminal187=z` leaves **all original final outputs unchanged**, while `z` is read as the XOR of the changed and pristine stock. That extra observation is not one of the old seven and has no demonstrated sender, route, price, restoration, or physical realization. It is a positive mathematical control, not a repair.

Other mutations break the checked certificate: changing an old stock coefficient raises its rank to seven; changing one control response breaks the exact zero relation; changing one egress bit increases the union rank from 19 to 20; omitting spectator `187` lowers the projected output rank from 18 to 17; a zero-pairing basis is rejected; and omitting an original `CLEAR` is rejected by the independent literal baseline. The complete old native operator is separately replayed in both directions on 680² coefficients, with 3,554 original dirty retirements per direction. This baseline check does not establish cleanup for a changed word.

Changing earlier packet values or other exterior routes, adding an observation or paid channel, shifting windows, using a broader owner set, or allowing a cross-chart endpoint operation outside the stated boundary changes this model. We do not claim those possibilities fail. No changed supplier, achieved signed invoice, new κ bound, independent application replay, or maintainer admission is produced.
