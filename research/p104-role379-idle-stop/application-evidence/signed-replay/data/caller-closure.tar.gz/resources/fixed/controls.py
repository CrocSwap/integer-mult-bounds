#!/usr/bin/env python3
"""Exercise retained tape guards on isolated synthetic mutations."""
import gzip,hashlib,json,resource,shutil,signal,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def need(x,m):
    if not x:raise ValueError(m)
def main():
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,121));signal.alarm(150)
    source=R/'stage';root=R/'controls-work';out=R/'CONTROLS.json'
    need(not root.exists() and not out.exists(),'exclusive output')
    need(sha(source/'WORD.json.gz')=='676c20c53ebd40120903af86bf17c2116f654ab8ce4aa1833f388a2fc400b511','candidate pin')
    need(sha(source/'short-caller/check_odd_fixed_tape_counts.py')=='d0d3a2b549a119f9132ad9cdc0c1d75a7bf1daac85435df51921661afb44d76c','retained adapted checker pin')
    root.mkdir();cases=[]
    names=['positive','candidate_hash','caller_hash','outer_strict','outer_functional','paid_positions','precision_cap','scalar_width']
    for case in names:
        d=root/case;d.mkdir();s=d/'short-caller';s.mkdir()
        shutil.copyfile(source/'WORD.json.gz',d/'WORD.json.gz')
        for name in ('check_odd_fixed_tape_counts.py','ODD-TYPE-AB-CALLER.json','ODD-ADMISSION-PARTIAL.json','ODD-PRECISION.json','ODD-PHYSICAL-BINDING.json','ODD-CALLER-EXACT-GRID.json'):
            shutil.copyfile(source/'short-caller'/name,s/name)
        def read(n):return json.loads((s/n).read_bytes())
        def write(n,v):(s/n).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
        if case=='candidate_hash':
            n='ODD-ADMISSION-PARTIAL.json';v=read(n);v['native_sha256']='0'*64;write(n,v)
        elif case=='caller_hash':
            n='ODD-PRECISION.json';v=read(n);v['caller_sha256']='0'*64;write(n,v)
        elif case in ('outer_strict','outer_functional'):
            n='ODD-ADMISSION-PARTIAL.json';v=read(n);v['compiler_outer']['outer']['strict_count' if case=='outer_strict' else 'functional_count']-=1;write(n,v)
        elif case=='paid_positions':
            n='ODD-PHYSICAL-BINDING.json';v=read(n);v['occurrence_and_geometry']['paid_positions']+=1;write(n,v)
        elif case=='precision_cap':
            n='ODD-PRECISION.json';v=read(n);v['context_c']=4097;write(n,v)
        elif case=='scalar_width':
            w=json.loads(gzip.decompress((d/'WORD.json.gz').read_bytes()))
            e=next(e for e in w['program'] if e[0]=='SCALE');e[2]='16777217'
            raw=json.dumps(w,sort_keys=True,separators=(',',':')).encode();new=hashlib.sha256(raw).hexdigest()
            (d/'WORD.json.gz').write_bytes(gzip.compress(raw,mtime=0))
            for n in ('ODD-ADMISSION-PARTIAL.json','ODD-PRECISION.json','ODD-PHYSICAL-BINDING.json'):
                v=read(n);v['native_sha256']=new;write(n,v)
        run=subprocess.run([sys.executable,'-I','-B',str(s/'check_odd_fixed_tape_counts.py')],cwd=s,capture_output=True,text=True,timeout=30,check=False)
        (d/'stdout.log').write_text(run.stdout);(d/'stderr.log').write_text(run.stderr)
        if case=='positive':need(run.returncode==0 and (s/'ODD-FIXED-TAPE-COUNTS.json').exists(),'positive control')
        else:
            anchors={'candidate_hash':'assert all(r["caller_sha256"]','caller_hash':'assert all(r["caller_sha256"]',
              'outer_strict':'assert g["outer"]["strict_count"]','outer_functional':'assert g["outer"]["strict_count"]',
              'paid_positions':'assert b["paid_positions"]','precision_cap':'assert cc<=4096','scalar_width':'assert bits<=24'}
            need(run.returncode!=0 and anchors[case] in run.stderr and not (s/'ODD-FIXED-TAPE-COUNTS.json').exists(),'expected guard '+case)
        cases.append({'case':case,'returncode':run.returncode,'stdout_sha256':sha(d/'stdout.log'),'stderr_sha256':sha(d/'stderr.log')})
    result={'status':'PASS_SYNTHETIC_FIXED_TAPE_GUARD_CONTROLS','positive':1,'rejecting':len(names)-1,'cases':cases,
       'scope':'Synthetic local guard coverage on retained fixed-tape counter; no new physical run, native provider, supplier or actual-tape proof.'}
    out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
