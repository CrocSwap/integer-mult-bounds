#!/usr/bin/env python3
"""Scoped #7113 caller regeneration against exact 7641 successor. Apache-2.0."""
import collections,gzip,hashlib,json,os,resource,runpy,shutil,signal,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent
R=D.parent/'resources'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def need(x,m):
 if not x:raise ValueError(m)
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(480,480))
signal.alarm(600)
need(__debug__,'optimized mode forbidden')
manifest=read(D/'FREEZE.json')
for path,digest in manifest['files'].items():need(sha((D/path).read_bytes())==digest,'freeze '+path)
wordbytes=(R/'REPAIR-WORD.json.gz').read_bytes();raw=gzip.decompress(wordbytes)
need(sha(wordbytes)=='676c20c53ebd40120903af86bf17c2116f654ab8ce4aa1833f388a2fc400b511','gzip pin')
need(sha(raw)=='f9f9a485712c0c94c9d14370e2a8436414e1b53bdf86550d9d6436835e9e06cb','candidate pin')
w=json.loads(raw); price=read(R/'REPAIR-PRICE.json')
need(sha((R/'REPAIR-PRICE.json').read_bytes())==manifest['price_sha256'],'price pin')
paid=collections.Counter(abs(len(w['frames'][e[3]])-len(w['frames'][e[2]])) for e in w['program'] if e[0]=='MOVE')
mains=set(w['live'])|{r+112 for r in w['live']}|set(w['hosted']['X2'])|set(w['hosted']['Y2'])
helpers=collections.Counter(len(w['frames'][w['final'][r]])-len(w['frames'][w['initial'][r]]) for r in range(w['public']) if r not in mains)
need(all(k>0 for k in paid) and all(k>0 for k in helpers),'positive ranks')
need({str(k):v for k,v in paid.items()}==price['native_paid'] and {str(k):v for k,v in helpers.items()}==price['native_helpers'],'literal recount matches receipt')
working=D/'work';shutil.copytree(D/'replay',working)
folder=working/'supplier7112/short-caller'
(folder.parent/'RESULT.json').write_text(json.dumps({'word_canonical_sha256':sha(raw),'native':{'paid':paid,'helpers':helpers}}))
(folder/'COHORT-PRICE.json').write_text(json.dumps({'target':price['targets'],'paid':price['paid'],'bracket':['0.0037136318149','0.0037136318150']}))
p=folder/'emit_odd_type_ab.py';code=p.read_text();old='invoice=next(x for x in json.loads((root/"SHORT-CALLER-RAW-PRICE.json").read_text())["rows"] if tuple(x["shape"])==shape)';new='invoice=json.loads((root/"COHORT-PRICE.json").read_text())'
need(code.count(old)==1,'exact single adapter');p.write_text(code.replace(old,new))
sys.path.insert(0,str(folder));os.chdir(folder)
start=time.monotonic()
for script in ('emit_odd_type_b.py','emit_odd_type_ab.py','check_odd_caller_exact_grid.py'):
 print('RUN',script,flush=True);runpy.run_path(str(folder/script),run_name='__main__')
expected=(D/'expected/ODD-TYPE-AB-CALLER.json').read_bytes();actual=(folder/'ODD-TYPE-AB-CALLER.json').read_bytes()
need(sha(expected)=='255d89f38cd45e38e5770f559bc43dc217e989032359768cdc7e8cdfd64b47bc' and actual==expected,'exact expected caller bytes')
replay=read(folder/'ODD-TYPE-AB-REPLAY.json');need(replay['source_word_sha256']==sha(raw),'candidate binding')
need(replay['target']==price['targets'] and replay['paid']==price['paid'],'complete histogram')
files=('ODD-TYPE-B-REPLAY.json','ODD-TYPE-AB-REPLAY.json','ODD-CALLER-EXACT-GRID.json')
result={'status':'PASS_SIGNED_CALLER_ONLY','candidate_canonical_sha256':sha(raw),'candidate_gzip_sha256':sha(wordbytes),'caller_sha256':sha(actual),'driver_sha256':sha((D/'run_caller.py').read_bytes()),'freeze_sha256':sha((D/'FREEZE.json').read_bytes()),'adapted_script_sha256':sha(p.read_bytes()),'checks':{n:sha((folder/n).read_bytes()) for n in files},'seconds':time.monotonic()-start,'scope':'Exact 17-call signed caller endpoint and integer grid plus candidate histogram. Native actual-input semantics, 104 physical boundaries, catalogue, complete outer predicates and common U remain unqualified; bracket reused from separately calculated signed price.'}
with (D/'RESULT.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result),flush=True)
