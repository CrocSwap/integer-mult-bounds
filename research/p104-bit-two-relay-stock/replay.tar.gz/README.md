# Three BIT returns: two atlas relays and one stock exchange

This is a bounded, negative stock screen. It is not a changed operator, a
κ improvement, a complete application proof, or a claim about networks outside
the explicitly fixed model below.

## Frozen sources and clocks

The parent is [#7921 at `7962491529f871300f02bb5b7e3abfc0333bc8c8`](https://github.com/CrocSwap/integer-mult-bounds/pull/7921),
using [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830).
The latter pins the native word SHA-256
`d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.
The `source/` tree exactly matches the inner SHA-256 manifest of the
published #7921 replay archive, whose outer SHA-256 is
`6efcbe06bdf4f2a22897793c77d92f96a2ab180725ddc8085b9929ead49f747c`.
`source/SOURCES.md` preserves the original provenance. The #7830 replay
file has Git blob `95c6d4ec0f2f33f41f5dd44fe1dd925317727acc`, matching the
pinned public file. The separate rational pricing engine and its notice are
from Round 4 stream 02, [#7924](https://github.com/CrocSwap/integer-mult-bounds/pull/7924),
head `c83039ac63874fa9f9a2fd0bb650469886076dc6`.

The zero-based rank-21 return indices are `(2, 6, 7)`. Their source charts
are respectively `511`, `515`, and `516` at original clocks `10302`,
`10342`, `10352`; their final deliveries to chart 0 occur at `11488`,
`13065`, `15597`. The complete target rows have 680 independent public
coordinates. Earlier completed returns are explicitly available to every
later test, even if the old word no longer holds a convenient copy.

## Roster and stop

The first gate admits two **distinct** existing atlas charts, each of
dimension 1, 2, or 4. Each old source sends once at its stated original
source clock into a relay nested in that source chart; each of the three
forms makes one final relay-to-zero delivery at its stated original deadline.
Both relays must be used. A relay can have no source ingress and instead
contribute extant stock to a final delivery. The pair must cover all three
source ingresses. No inter-relay edge or changed exterior descendant is
allowed in this first gate.

There are 334 charts (111 dimension-1, 153 dimension-2, 70 dimension-4)
and 14,283 covering pairs. At each **actual** deadline we grant every
relay all three first-sender banks simultaneously, even where a bank is not
nested to that relay or one scalar would not carry the whole bank. We grant
all simultaneously live original stock at that relay and chart 0 that is
independent of current or later selected receipts. We also grant the earlier
completed target rows and all live original rows tagged only by earlier
selected paths. Those prior-path rows are optimistic free gifts; the altered
word has not been shown to reproduce them. None of the 334 charts spans any
of the three targets, so no covering pair survives. This is stronger than
the #7921 shared-relay screen, which required the one relay to be nested in
all three sender charts.

The next gate adds **one extra paid scalar exchange** between those relays.
The pair must be properly nested so that the exchange has positive grade;
either direction is allowed. This leaves 357 pairs, of which 90 have
dimensions `(1,2)`, 231 `(1,4)`, and 36 `(2,4)`. For each final deadline,
the test now grants the target relay the union of **every original stock row
ever seen by that deadline** at *both* relays and chart 0, all three sender
banks and earlier target forms. It gives unlimited exchanges and free
retention, while excluding rows whose original value depends on current or
later selected path receipts. Earlier selected-path-tainted stock is granted
for free even if its receipt would not survive. Every one of the 357 pairs
fails at all three deadlines: 1,071 separately checked assignments.

These are span **necessary conditions**, not complete causal constructions.
In particular the screen does not model an arbitrary change to other old
receipt descendants, altered source clocks, shifted final deadlines,
third-party rewrites, arbitrary new relay-generated values or productive
targets. Those changes require a new analysis of their actual stock, reader
restoration and prices. Conversely, no extrapolation is made to fresh
non-atlas charts or more than two relay charts.

## Price of a hypothetical additional exchange

The exact complete baseline paid and productive rank histograms are
included in `PRICE-BOUND.json`. Let `H(r)=r^(1-κ)`. With all other paid and
productive occurrences fixed, three old returns cost `3*(2*H(1)+H(5))`
per native call. An extra positive-grade stock exchange costs at least
`H(1)=1` per native call. At the two requested trials, the original full
36-call margins are approximately `-0.0000000007670015` and
`-0.0003851273166`.

If every return enters and exits the **same** one of its chosen relays,
independently choosing the best dimension gives a full 36-call margin at
most `-34.8723178793` and `-34.8727027165`, respectively. These bounds
already give every displaced reader, local operation and restoration for
free. They apply to that restricted subfamily only.

Cross-relay returns need a different bound: in the most optimistic arithmetic
screen we give **every** source the cheapest grade-3 ingress, **every**
final the cheapest grade-1 delivery, and the exchange its cheapest grade-1
price, regardless of simultaneous geometry, stock or rank. The resulting
full 36-call upper margins are approximately `+286.0165973038` and
`+286.0162116680`. These are not achievable claims; they show that the
same-relay price argument cannot exclude cross-relay returns. The stock
separators above exclude the tested fixed-exterior cross-relay roster.

No literal candidate survives, so there is no actual displaced reader or
changed-candidate invoice to certify. Any reader displaced by an exchange
would need its identity, legal restoration and actual charge before a new
candidate could be accepted. The saved estimates are **optimistic upper
bounds**, not invoices and not permission to leave a repair unpriced.

## Check the evidence

Run `python3 -I -B verify_all.py`. It verifies the archive checksums, replays
the #7921 source and caller controls, regenerates the two rosters and their
separators, checks all saved output, and independently reconstructs geometry
and chronological stocks with set-valued tags. That independent replay uses
direct 680-bit parity checks rather than the generator's row elimination:
1,002 live-stock and 1,071 historical-stock assignments are checked, and a
corrupted witness is rejected. It checks the original forward and adjoint
680-owner operators, the owner-411 bridge and omission control, 111 paired
contacts and 3,554 dirty retirements per direction. These are baseline
checks, not checks of a changed candidate. A separate exact rational-log and
fixed-point engine reproduces both price ceilings at both trials and rejects
an uncharged additional grade-1 paid occurrence.

The source files retain their original `NOTICE`, `LICENSE`, and provenance.
The work in this directory was prepared with OpenAI Codex assistance.
