#!/usr/bin/env python3
"""Optimistic deadline cuts for the pinned (2, 6, 7) two-relay roster.

The first gate keeps the original three source and final clocks. Each new
relay must be an existing atlas chart of dimension 1, 2 or 4; each source
must be nested into at least one member of the pair, while a relay need not
have its own source ingress. Each target has one final relay-to-0 delivery. There is no
inter-relay hop or shifted final delivery. We grant each relay ALL three
source banks, regardless of nesting and of the one-scalar-per-source limit.
We grant all untainted live rows at the relay and zero at the actual deadline,
all earlier completed targets at zero even if no longer live, and, in a
second more generous screen, all live original rows tainted ONLY by earlier
completed return paths. All 680 owner coordinates are retained. In particular
the latter rows are gifts, not a claim that altered paths reproduce them.
This is a necessary span test under the stated fixed-exterior-row model;
it is not a candidate word, an invoice, or an exclusion of other architectures.
"""
from collections import defaultdict, Counter
from fractions import Fraction
from itertools import combinations, product
from pathlib import Path
import gzip, hashlib, json, sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'source'))
import verify_decoder_triples as v

source = HERE / 'source'
blob = (source / 'BIT-WORD.json.gz').read_bytes()
assert hashlib.sha256(blob).hexdigest() == v.WORD_SHA
w = json.loads(gzip.decompress(blob)); F = {int(k): x for k, x in w['frames'].items()}
s = v.run_tape(w, False); a = v.run_tape(w, True)
returns = [t for t, (_, b, _) in s.items() if b == 0]
groups = [[t for t in sorted(s) if a[t][2] == a[returns[g]][2]] for g in range(9)]
tri = (2, 6, 7)
assert [groups[g] for g in tri] == [[10302, 11483, 11488], [10342, 13060, 13065], [10352, 15592, 15597]]
marks = {t: 3*j+k for j, g in enumerate(tri) for k, t in enumerate(groups[g])}
watch_first = {groups[g][0]: g for g in tri}; watch_last = {groups[g][2]: g for g in tri}
chart = list(w['start']) + [None]*w['owned_fields']
row = [1 << i for i in range(w['public'])] + [0]*w['owned_fields']
MASK = (1 << w['public']) - 1
assert w['public'] == 680
first, deadline = {}, {}
for t, (op, addr, *args) in enumerate(w['program']):
    if t in watch_first:
        g = watch_first[t]; src = s[t][0]
        first[g] = [(i, x & MASK) for i, (c, x) in enumerate(zip(chart, row)) if c == src and x & MASK]
    if t in watch_last:
        g = watch_last[t]; banks = defaultdict(list)
        for i, (c, x) in enumerate(zip(chart, row)):
            if c is not None and x & MASK:
                banks[c].append((i, x & MASK, x >> w['public']))
        deadline[g] = banks
    if op == 'INIT': chart[addr] = args[0]; row[addr] = 0
    elif op == 'CLEAR': chart[addr] = None; row[addr] = 0
    elif op == 'ADD': row[addr] ^= row[args[0]]
    elif op == 'SWAP':
        peer = args[0]; row[addr], row[peer] = row[peer], row[addr]; chart[addr], chart[peer] = chart[peer], chart[addr]
    elif op == 'MOVE':
        chart[addr] = args[1]
        if t in marks: row[addr] ^= 1 << (w['public'] + marks[t])
    else: raise AssertionError(op)

def nested(c, parent):
    return all(sum(Fraction(x)*Fraction(y) for x, y in zip(u,z)) == 0
               for u in F[c]['B'] for z in F[parent]['A'])

sources = {g: s[groups[g][0]][0] for g in tri}
eligible = {c: [g for g in tri if nested(c, sources[g])]
            for c in sorted(F) if F[c]['dim'] in (1, 2, 4)}
srcrows = [x for g in tri for _, x in first[g]]
target = {g: s[groups[g][2]][2] for g in tri}

def separate(target, rows):
    b = v.binary_basis(rows); rem = v.reduce_binary(target, b); assert rem
    free = rem.bit_length()-1; assert free not in b
    witness = 1 << free
    for pivot in sorted(b):
        if (b[pivot] & witness).bit_count() & 1: witness ^= 1 << pivot
    assert all(not ((x & witness).bit_count() & 1) for x in rows)
    assert (target & witness).bit_count() & 1
    return list(v.indices(witness))

profiles = []
for c, gs in eligible.items():
    p = {'chart': c, 'dimension': F[c]['dim'], 'nested_senders': gs, 'deadlines': []}
    for j, g in enumerate(tri):
        banks = deadline[g]
        prior_mask = (1 << (3*j)) - 1
        untouched = [x for bank in (c, 0) for _, x, mark in banks[bank] if mark == 0]
        extra_prior = [x for bank in (c, 0) for _, x, mark in banks[bank] if mark and not (mark & ~prior_mask)]
        done = [target[k] for k in tri[:j]]
        rows = srcrows + untouched + extra_prior + done
        rem = v.reduce_binary(target[g], v.binary_basis(rows))
        p['deadlines'].append({'return': g, 'clock': groups[g][2],
            'unaffected_relay_fields': sum(mark == 0 for _, _, mark in banks[c]),
            'prior_tainted_relay_fields_granted': sum(bool(mark) and not (mark & ~prior_mask) for _, _, mark in banks[c]),
            'unaffected_zero_fields': sum(mark == 0 for _, _, mark in banks[0]),
            'prior_tainted_zero_fields_granted': sum(bool(mark) and not (mark & ~prior_mask) for _, _, mark in banks[0]),
            'rank': len(v.binary_basis(rows)), 'span_pass': rem == 0,
            'separating_owner_support': None if rem == 0 else separate(target[g], rows)})
    profiles.append(p)

roster = []
for x, y in combinations(profiles, 2):
    source_assignments = [choice for choice in product((x['chart'], y['chart']), repeat=3)
                          if all(g in eligible[c] for g, c in zip(tri, choice))]
    if not source_assignments: continue
    deadline_choices = [[p['chart'] for p in (x,y) if p['deadlines'][j]['span_pass']] for j in range(3)]
    pair = {'relays': [x['chart'], y['chart']], 'eligible_source_assignments': len(source_assignments),
            'deadline_pass_relays': deadline_choices}
    if all(deadline_choices):
        pair['optimistic_full_route_exists'] = any(len(set(src + out)) == 2
            for src in source_assignments for out in product(*deadline_choices))
    else: pair['optimistic_full_route_exists'] = False
    roster.append(pair)

result = {'description': __doc__, 'word_sha256': v.WORD_SHA, 'source_sha256': hashlib.sha256((source/'screen_one_relay.py').read_bytes()).hexdigest(),
          'triple': tri, 'source_charts': sources, 'first_bank_field_counts': {str(g): len(first[g]) for g in tri},
          'relay_count': len(profiles), 'dimensions': dict(Counter(p['dimension'] for p in profiles)),
          'passes_by_deadline': {str(g): [p['chart'] for p in profiles if p['deadlines'][j]['span_pass']] for j,g in enumerate(tri)},
          'pair_count': len(roster), 'pair_survivors': [r for r in roster if r['optimistic_full_route_exists']],
          'profiles': profiles, 'roster': roster}
(HERE/'FIRST-GATE.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ('relay_count','dimensions','passes_by_deadline','pair_count','pair_survivors')}, indent=2))
