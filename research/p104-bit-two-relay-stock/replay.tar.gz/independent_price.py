#!/usr/bin/env python3
"""Cross-check price intervals using the R4 stream-02 rational engine."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib, json, sys
HERE=Path(__file__).resolve().parent
assert hashlib.sha256((HERE/'pricing_source/target_exact.py').read_bytes()).hexdigest()=='8e06b109926b471cdb887fe3fbc631cc71a69a17aadf1a818fa238b8e1dd9bce'
sys.path.insert(0,str(HERE/'pricing_source'))
import target_exact as arith
record=json.loads((HERE/'PRICE-BOUND.json').read_text())
paid=Counter({int(k):v for k,v in record['baseline_paid_histogram'].items()})
prod=Counter({int(k):v for k,v in record['baseline_productive_histogram'].items()})
def overlaps(b,decimal_bounds):
    lo,hi=map(Fraction,decimal_bounds)
    return Fraction(b[0],arith.GRID)<=lo<=hi<=Fraction(b[1],arith.GRID)
out={'arithmetic':'exact rational atanh series, fixed point Taylor and outward squaring',
     'same_price_engine_as_generator':False,'trials':{}}
for t,rec in record['trials'].items():
    baseline=arith.signed(paid,prod,t);assert overlaps(baseline,rec['baseline_margin_interval'])
    cases={}
    for name,case in rec['cases'].items():
        pc=Counter({int(k):v for k,v in case['optimistic_paid_histogram'].items()})
        x=arith.signed(pc,prod,t)
        assert overlaps(x,case['optimistic_complete_36_call_margin_interval'])
        changed=pc.copy();changed[1]+=1
        plus=arith.signed(changed,prod,t)
        assert plus[1]<x[0]
        cases[name]={'fixed_point_interval':arith.interval_output(x),'extra_grade_one_detected':True}
    out['trials'][t]={'baseline_interval':arith.interval_output(baseline),'cases':cases}
(HERE/'INDEPENDENT-PRICE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS independent exact price bounds for baseline and both price ceilings at both trials; extra paid grade-1 controls')
