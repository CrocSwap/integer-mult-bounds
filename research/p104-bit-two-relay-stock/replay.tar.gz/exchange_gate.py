#!/usr/bin/env python3
"""Overgenerous one-exchange cut for the fixed-clock two-relay roster.

An admitted pair consists of distinct dimension 1/2/4 atlas charts,
together nested in and covering the three sender charts. One may have no
sender ingress and instead be used for its extant stock or as a receiver.
The two relays must be properly nested to allow one positive-grade MOVE.
Final deliveries occur at the actual three original clocks. At each clock we
grant all rows ever present by that clock at *both* relays and at chart 0,
all three first-sender banks, and earlier completed target rows. This grants
free shadows, every possible exchange time and unlimited exchanges; it is
strictly more generous than one funded scalar exchange. Current and later
selected-receipt-tainted rows are excluded. Earlier completed-path-tainted
original rows are granted as free shadows, not asserted to survive the edit.
No arbitrary changed exterior descendants are modeled. A separation is an
exact 680-owner necessary obstruction for this stated, fixed-exterior model.
"""
from collections import defaultdict, Counter
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import gzip, hashlib, json, sys, time
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE/'source'))
import verify_decoder_triples as v

blob = (HERE/'source/BIT-WORD.json.gz').read_bytes()
began=time.monotonic()
assert hashlib.sha256(blob).hexdigest() == v.WORD_SHA
w = json.loads(gzip.decompress(blob)); F = {int(k): x for k,x in w['frames'].items()}
s = v.run_tape(w,False); a = v.run_tape(w,True)
returns = [t for t,(_,b,_) in s.items() if b == 0]
groups = [[t for t in sorted(s) if a[t][2] == a[returns[g]][2]] for g in range(9)]
tri = (2,6,7)
assert [groups[g] for g in tri] == [[10302,11483,11488],[10342,13060,13065],[10352,15592,15597]]
marks = {t:3*j+k for j,g in enumerate(tri) for k,t in enumerate(groups[g])}
first_watch = {groups[g][0]:g for g in tri}; last_watch = {groups[g][2]:g for g in tri}
chart = list(w['start'])+[None]*w['owned_fields']
row = [1 << i for i in range(w['public'])]+[0]*w['owned_fields']
assert w['public'] == 680
mask = (1<<w['public'])-1
history = defaultdict(set)
def record(i):
    if chart[i] is not None and (row[i]&mask): history[chart[i]].add((row[i]&mask,row[i]>>w['public']))
for i in range(w['public']): record(i)
first, snap = {}, {}
for t,(op,addr,*args) in enumerate(w['program']):
    if t in first_watch:
        g=first_watch[t]; src=s[t][0]
        first[g]=[x&mask for c,x in zip(chart,row) if c==src and x&mask]
    if t in last_watch:
        g=last_watch[t]; j=tri.index(g); prior=(1<<(3*j))-1
        snap[g]={c:[x for x,tag in sorted(bank) if not (tag & ~prior)] for c,bank in history.items()}
    changed = []
    if op=='INIT': chart[addr]=args[0];row[addr]=0
    elif op=='CLEAR': chart[addr]=None;row[addr]=0
    elif op=='ADD': row[addr]^=row[args[0]];changed=[addr]
    elif op=='SWAP':
        peer=args[0];row[addr],row[peer]=row[peer],row[addr];chart[addr],chart[peer]=chart[peer],chart[addr];changed=[addr,peer]
    elif op=='MOVE':
        chart[addr]=args[1]
        if t in marks: row[addr]^=1<<(w['public']+marks[t])
        changed=[addr]
    else: raise AssertionError(op)
    for i in changed: record(i)

def nested(c,parent):
    return all(sum(x*y for x,y in zip(u,z))==0
        for u in F[c]['B'] for z in F[parent]['A'])
assert all(isinstance(x,int) for f in F.values() for kind in ('A','B') for r in f[kind] for x in r)
src={g:s[groups[g][0]][0] for g in tri}
eligible={c:[g for g in tri if nested(c,src[g])] for c in sorted(F) if F[c]['dim'] in (1,2,4)}
assert len(eligible)==334
srcrows=[x for g in tri for x in first[g]]
targets={g:s[groups[g][2]][2] for g in tri}
def separate(target,b):
    rem=v.reduce_binary(target,b); assert rem
    q=rem.bit_length()-1; assert q not in b
    z=1<<q
    for pivot in sorted(b):
        if (b[pivot]&z).bit_count()&1: z^=1<<pivot
    assert all(not ((x&z).bit_count()&1) for x in b.values())
    assert (target&z).bit_count()&1
    return list(v.indices(z))

def add_basis(base, rows):
    for row in rows:
        rem=v.reduce_binary(row,base)
        if rem: base[rem.bit_length()-1]=rem
    return base

# Cache exact chart bases once. Rebuilding the full historical empty-chart bank
# at every pair is substantially slower but mathematically identical.
cached_bases={g:{c:tuple(v.binary_basis(rows).values()) for c,rows in snap[g].items()} for g in tri}
base_bases={}
for j,g in enumerate(tri):
    base_bases[g]=v.binary_basis(srcrows+snap[g].get(0,[])+[targets[k] for k in tri[:j]])
print('snapshots ready, elapsed %.2f s' % (time.monotonic()-began),flush=True)
pairs=[]; covered=0
for x,y in combinations(eligible,2):
    if set(eligible[x])|set(eligible[y]) != set(tri): continue
    covered+=1
    if F[x]['dim'] == F[y]['dim']: continue
    small,large=(x,y) if F[x]['dim']<F[y]['dim'] else (y,x)
    if not nested(small,large): continue
    p={'relays':[x,y], 'dimensions':[F[x]['dim'],F[y]['dim']],
       'nested_sender_sets':[eligible[x],eligible[y]],
       'exchange_grade':F[large]['dim']-F[small]['dim'], 'deadlines':[]}
    for j,g in enumerate(tri):
        banks=snap[g]; b=base_bases[g].copy()
        add_basis(b,cached_bases[g].get(x,()));add_basis(b,cached_bases[g].get(y,()))
        rem=v.reduce_binary(targets[g],b)
        p['deadlines'].append({'return':g,'clock':groups[g][2], 'span_pass':rem==0,
            'history_relay_row_counts':[len(banks.get(x,[])),len(banks.get(y,[]))],
            'history_zero_row_count':len(banks.get(0,[])),
            'separating_owner_support':None if rem==0 else separate(targets[g],b)})
    pairs.append(p)

result={'description':__doc__, 'word_sha256':v.WORD_SHA, 'triple':tri,
        'eligible_charts':len(eligible),'coverage_pairs':covered,'proper_nested_coverage_pairs':len(pairs),
        'dimension_pairs':dict(Counter(str(sorted(p['dimensions'])) for p in pairs)),
        'target_pass_counts':{str(g):sum(p['deadlines'][j]['span_pass'] for p in pairs) for j,g in enumerate(tri)},
        'all_deadlines_pass':[p['relays'] for p in pairs if all(x['span_pass'] for x in p['deadlines'])], 'pairs':pairs}
(HERE/'EXCHANGE-GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:result[k] for k in ('eligible_charts','coverage_pairs','proper_nested_coverage_pairs','dimension_pairs','target_pass_counts','all_deadlines_pass')},indent=2))
