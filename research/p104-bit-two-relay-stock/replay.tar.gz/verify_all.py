#!/usr/bin/env python3
"""Isolated serial replay of the bounded screens and their controls."""
from hashlib import sha256
from pathlib import Path
import json, shutil, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent
for line in (ROOT/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1);path=ROOT/name
    if not path.is_file() or sha256(path.read_bytes()).hexdigest()!=digest:
        raise ValueError('checksum mismatch: '+name)

with tempfile.TemporaryDirectory(prefix='p104-two-relay-') as td:
    temp=Path(td)/'replay';shutil.copytree(ROOT,temp)
    def run(script,cwd):
        p=subprocess.run([sys.executable,'-I','-B',script],cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        if p.returncode:raise ValueError(script+' failed:\n'+p.stdout[-4000:]+'\n'+p.stderr[-4000:])
        print('PASS',script,flush=True)
    run('verify.py',temp/'source')
    for script in ('first_gate.py','exchange_gate.py','price_bound.py','independent_check.py','independent_price.py'):
        run(script,temp)
    for name in ('FIRST-GATE.json','EXCHANGE-GATE.json','PRICE-BOUND.json','INDEPENDENT-CHECK.json','INDEPENDENT-PRICE.json'):
        if json.loads((temp/name).read_text()) != json.loads((ROOT/name).read_text()):
            raise ValueError('regenerated result differs: '+name)
    print('PASS saved exact rosters, separating witnesses and both independent replays')
