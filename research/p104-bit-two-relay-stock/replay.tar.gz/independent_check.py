#!/usr/bin/env python3
"""Independent stock/geometry replay and direct parity checks for the cuts.

Uses the pinned #7830 operator engine to establish original forward and
adjoint packets and its omission controls. A separately written replay tracks
tags as Python sets and checks every saved owner assignment by dot product;
it does not import either generating script or use its elimination routine.
"""
from collections import defaultdict
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import gzip, hashlib, json, sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import binary_operator as b

blob=(HERE/'source/BIT-WORD.json.gz').read_bytes()
assert hashlib.sha256(blob).hexdigest()==b.WORD_GZIP
w=json.loads(gzip.decompress(blob)); atlas=b.Atlas(w['frames'])
assert atlas.main_contacts(w['start'],w['final'])==111
fw,ad,deleted=b.native_checks(w,atlas)
forward={p.clock:p for p in fw.packets.values()}; reverse={p.clock:p for p in ad.packets.values()}
returns=sorted(t for t,p in forward.items() if p.receiver==0)
tri=(2,6,7)
groups={g:sorted(t for t in forward if reverse[t].arrival.row==reverse[returns[g]].arrival.row) for g in tri}
assert [groups[g] for g in tri]==[[10302,11483,11488],[10342,13060,13065],[10352,15592,15597]]
marks={t:(g,j) for g in tri for j,t in enumerate(groups[g])}
first_clock={groups[g][0]:g for g in tri}; final_clock={groups[g][2]:g for g in tri}
values=[1<<i for i in range(680)]+[0]*w['owned_fields']; tags=[set() for _ in values]
charts=list(w['start'])+[None]*w['owned_fields']; past=defaultdict(set)
def save(i):
    if charts[i] is not None and values[i]: past[charts[i]].add((values[i],frozenset(tags[i])))
for i in range(680):save(i)
first={}; live={}; history={}; goal={}
for clock,(op,addr,*args) in enumerate(w['program']):
    if clock in first_clock:
        g=first_clock[clock]; c=forward[clock].source
        first[g]=[values[i] for i in range(len(values)) if charts[i]==c and values[i]]
    if clock in final_clock:
        g=final_clock[clock]; j=tri.index(g); earlier=set(tri[:j]); banks=defaultdict(list)
        for c,x,tag in zip(charts,values,tags):
            if c is not None and x and all(group in earlier for group,_ in tag): banks[c].append(x)
        live[g]=banks
        history[g]={c:[x for x,tag in bank if all(group in earlier for group,_ in tag)] for c,bank in past.items()}
        goal[g]=values[addr]
        assert goal[g]==forward[clock].arrival.row
    changed=[]
    if op=='ADD':
        peer=args[0]; assert charts[addr]==charts[peer]==args[1]
        values[addr]^=values[peer];tags[addr]^=tags[peer];changed=[addr]
    elif op=='SWAP':
        peer=args[0];values[addr],values[peer]=values[peer],values[addr];tags[addr],tags[peer]=tags[peer],tags[addr];charts[addr],charts[peer]=charts[peer],charts[addr];changed=[addr,peer]
    elif op=='INIT': assert charts[addr] is None;charts[addr]=args[0];values[addr]=0;tags[addr]=set()
    elif op=='CLEAR': assert charts[addr]==args[0];charts[addr]=None;values[addr]=0;tags[addr]=set()
    elif op=='MOVE':
        assert charts[addr]==args[0];charts[addr]=args[1]
        if clock in marks: tags[addr]^={marks[clock]}
        changed=[addr]
    else:raise AssertionError(op)
    for i in changed:save(i)

def dotok(support,rows,target):
    if len(set(support))!=len(support) or any(i<0 or i>=680 for i in support):return False
    z=sum(1<<i for i in support)
    return all(not ((x&z).bit_count()&1) for x in rows) and bool((target&z).bit_count()&1)

dims={int(c):r['dim'] for c,r in w['frames'].items()}
sources={g:forward[groups[g][0]].source for g in tri}
def nested(c,d):
    f=w['frames'][str(c)];h=w['frames'][str(d)]
    return all(sum(Fraction(x)*Fraction(y) for x,y in zip(z,a))==0 for z in f['B'] for a in h['A'])
eligible={c:{g for g in tri if nested(c,sources[g])} for c in dims if dims[c] in (1,2,4)}
assert len(eligible)==334
source=sum((first[g] for g in tri),[])
first_doc=json.loads((HERE/'FIRST-GATE.json').read_text())
profiles={p['chart']:p for p in first_doc['profiles']}
assert set(profiles)==set(eligible) and all(not v for v in first_doc['passes_by_deadline'].values())
first_n=0
for c,p in profiles.items():
    assert set(p['nested_senders'])==eligible[c]
    for j,g in enumerate(tri):
        r=p['deadlines'][j]; assert r['return']==g and r['clock']==groups[g][2] and not r['span_pass']
        rows=source+live[g][c]+live[g][0]+[goal[q] for q in tri[:j]]
        assert dotok(r['separating_owner_support'],rows,goal[g]);first_n+=1

coverage={tuple(sorted((x,y))) for x,y in combinations(eligible,2) if eligible[x]|eligible[y]==set(tri)}
assert len(coverage)==14283
assert {tuple(p['relays']) for p in first_doc['roster']}==coverage
assert not first_doc['pair_survivors']
proper=set()
for x,y in coverage:
    if dims[x]==dims[y]:continue
    small,large=(x,y) if dims[x]<dims[y] else (y,x)
    if nested(small,large):proper.add((x,y))
second=json.loads((HERE/'EXCHANGE-GATE.json').read_text())
assert len(proper)==357 and {tuple(p['relays']) for p in second['pairs']}==proper
assert not second['all_deadlines_pass']
exchange_n=0; sample=None
for p in second['pairs']:
    x,y=p['relays']
    assert p['exchange_grade']==abs(dims[x]-dims[y])
    for j,g in enumerate(tri):
        r=p['deadlines'][j];assert r['return']==g and r['clock']==groups[g][2] and not r['span_pass']
        rows=source+history[g].get(0,[])+history[g].get(x,[])+history[g].get(y,[])+[goal[q] for q in tri[:j]]
        assert dotok(r['separating_owner_support'],rows,goal[g]);exchange_n+=1
        if sample is None:sample=(r['separating_owner_support'],rows,goal[g])

support,rows,tar=sample; pivot=(tar & -tar).bit_length()-1
corrupted=sorted(set(support)^{pivot})
assert not dotok(corrupted,rows,tar)
out={'word_sha256':b.WORD_GZIP,'base_forward_adjoint_maps_checked':True,'protected_owner_411_and_omission_checked':True,
     'dirty_retirements_each_direction':[fw.dirty,ad.dirty],'eligible_chart_count':len(eligible),
     'coverage_pairs':len(coverage),'proper_nested_coverage_pairs':len(proper),
     'live_deadline_separator_checks':first_n,'historical_exchange_separator_checks':exchange_n,
     'corrupted_witness_rejected':True,'used_generating_elimination':False,'deleted_owner_411_add_clock':deleted}
(HERE/'INDEPENDENT-CHECK.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
