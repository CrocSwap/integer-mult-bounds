#!/usr/bin/env python3
"""Outward price bounds for the fixed-clock single-EXTRA-exchange roster.

This is not the invoice of a candidate. We optimistically retain the complete
baseline productive histogram and every other paid occurrence, charge just
one smallest positive-grade additional exchange per native call, and give
every displaced reader, shadow, local operation and repair for free. One
bound optimistically chooses the cheapest ingress grade 3 and cheapest
delivery grade 1 independently, INCLUDING cross-relay returns. A second,
clearly restricted bound requires each return's ingress and delivery to
use the same relay; it does not cover cross-relay returns.
There is no surviving physical candidate from which to price an actual repair.
If a candidate changes other paid slots or productive targets this bound
does not apply. Each 36-call baseline and delta uses the whole caller histogram.
"""
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING, ROUND_HALF_EVEN
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
source=json.loads((HERE/'source/expected/BASELINE-CHECK.json').read_text())
paid={int(k):int(v) for k,v in source['caller_paid_ranks'].items()}
prod={int(k):int(v) for k,v in source['caller_productive_ranks'].items()}
assert source['native_calls']==36
assert source['native_paid_ranks']=={'1':1376,'2':1281,'3':54,'4':44,'5':17,'6':102}
PREC=80

def h_interval(rank,k):
    if rank==1:return Decimal(1),Decimal(1)
    # Decimal.ln and exp are correctly rounded to nearest. The adjacent
    # representable numbers enclose their real values. Multiplication is
    # explicitly outward; monotonicity of exp carries the enclosure forward.
    with localcontext() as c:
        c.prec=PREC;c.rounding=ROUND_HALF_EVEN
        ell=Decimal(rank).ln(); llo=ell.next_minus(); lhi=ell.next_plus()
        p=Decimal(1)-k
    assert p>0
    with localcontext() as c:
        c.prec=PREC;c.rounding=ROUND_FLOOR;xlo=llo*p
    with localcontext() as c:
        c.prec=PREC;c.rounding=ROUND_CEILING;xhi=lhi*p
    with localcontext() as c:
        c.prec=PREC;c.rounding=ROUND_HALF_EVEN
        return xlo.exp().next_minus(),xhi.exp().next_plus()

def interval(coeff,k):
    terms=[(int(n),*h_interval(r,k)) for r,n in sorted(coeff.items()) if n]
    with localcontext() as c:
        c.prec=PREC;c.rounding=ROUND_FLOOR
        lo=sum((n*(l if n>0 else u) for n,l,u in terms),Decimal(0))
    with localcontext() as c:
        c.prec=PREC;c.rounding=ROUND_CEILING
        hi=sum((n*(u if n>0 else l) for n,l,u in terms),Decimal(0))
    return lo,hi
def add(*maps):
    out={}
    for m in maps:
        for r,n in m.items():out[r]=out.get(r,0)+n
    return {r:n for r,n in sorted(out.items()) if n}
def pair(x):return [str(x[0]),str(x[1])]

baseline=add(prod,{r:-n for r,n in paid.items()})
old={1:2,5:1}
trials=['0.003879928046156','0.003879929046155']
out={'description':__doc__,'precision_decimal_digits':PREC,'caller_native_calls':36,
     'baseline_paid_histogram':paid,'baseline_productive_histogram':prod,'trials':{}}
for trial in trials:
    k=Decimal(trial); gain={}
    for d in (1,2,4):
        newer={}
        for r in (7-d,d):newer[r]=newer.get(r,0)+1
        gain[d]=interval(add(old,{r:-n for r,n in newer.items()}),k)
    assert gain[1][0]>gain[2][1] and gain[1][0]>gain[4][1]
    # Same relay only: three dimension-1 replacements have the best saving.
    # Cross-relay is broader: optimistically choose grade 3 at EVERY ingress
    # and grade 1 at EVERY delivery, irrespective of geometry and rank.
    cases={}
    for name,delta_coeff in (('same_relay_only',{1:72,5:108,6:-108}),
                             ('any_cross_relay',{1:72,5:108,3:-108})):
        upper=interval(add(baseline,delta_coeff),k)
        delta=interval(delta_coeff,k)
        optimistic_paid=add(paid,{r:-n for r,n in delta_coeff.items()})
        assert min(optimistic_paid.values())>=0
        cases[name]={'optimistic_paid_histogram':optimistic_paid,
            'optimistic_changed_minus_baseline_interval':pair(delta),
            'optimistic_complete_36_call_margin_interval':pair(upper)}
    assert Decimal(cases['same_relay_only']['optimistic_complete_36_call_margin_interval'][1])<0
    assert Decimal(cases['any_cross_relay']['optimistic_complete_36_call_margin_interval'][0])>0
    out['trials'][trial]={'baseline_margin_interval':pair(interval(baseline,k)),
        'one_return_hypothetical_saving_intervals':{str(d):pair(gain[d]) for d in gain},
        'extra_exchange_min_grade':1,'productive_histogram':prod,'cases':cases}
(HERE/'PRICE-BOUND.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
for k,r in out['trials'].items():
    print(k,'baseline',r['baseline_margin_interval'])
    for name,c in r['cases'].items():print(name,'optimistic delta',c['optimistic_changed_minus_baseline_interval'],
          'optimistic complete margin',c['optimistic_complete_36_call_margin_interval'])
