#!/usr/bin/env python3
"""Independent first-depositor sink identity and P104 relay control.
Uses the frozen #7871 fixture and #7852 source-table blobs. The only
change to the independent review script is its portable source/ path.
"""
from fractions import Fraction as Q
from copy import deepcopy
from pathlib import Path
import runpy
import sys
sys.dont_write_bytecode=True
p=Path(__file__).resolve().parent/'source'
s=runpy.run_path(str(p/'check_separator.py'))
N0=deepcopy(s['two_low'])
n=len(N0['a'])
dep=[k for k in range(n) if any(row[k] for row in N0['G'])]
gat=[k for k in range(n) if any(N0['F'][k])]
d0,d1=dep[:2]
assert (d0,d1)==(2,3) and not N0['H'][d1][d0]
# Introduce a direct depositor relay, making the first b zero so its
# original G column may be compensated without an output-label restriction.
N0['b'][d0]=[]
for row in N0['G']:
    row[d0]-=row[d1]
N0['H'][d1][d0]=Q(1)
M,gg,dd,D,dims=s['verify']('compensated depositor relay',N0)
assert M==s['M0'] and gg==gat and dd==dep and D==57
assert dims[d0][1]==0 and dims[d1][1]==1

# W is the independently computed exact path-sum matrix.
def paths(H):
    n=len(H)
    V=[[Q(i==j) for j in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            V[i][j]=Q(i==j)+sum((H[i][k]*V[k][j] for k in range(i)),Q(0))
    return V

def sub(V,I,J): return [[V[i][j] for j in J] for i in I]
def mul(A,B): return [[sum((A[i][k]*B[k][j] for k in range(len(B))),Q(0)) for j in range(len(B[0]))] for i in range(len(A))]
def echelon(A):
    B=[list(map(Q,row)) for row in A]; piv=[]; row=0
    for col in range(len(B[0])):
        p=next((r for r in range(row,len(B)) if B[r][col]),None)
        if p is None: continue
        B[p],B[row]=B[row],B[p]
        t=B[row][col]; B[row]=[x/t for x in B[row]]
        for r in range(len(B)):
            if r!=row and B[r][col]:
                t=B[r][col]; B[r]=[x-t*y for x,y in zip(B[r],B[row])]
        piv.append(col);row+=1
        if row==len(B):break
    return B,piv

def kernel(A):
    B,piv=echelon(A); free=[j for j in range(len(A[0])) if j not in piv]
    assert len(free)==1
    v=[Q(0)]*len(A[0]); v[free[0]]=Q(1)
    for i,j in enumerate(piv): v[j]=-B[i][free[0]]
    assert all(sum(a*b for a,b in zip(row,v))==0 for row in A)
    return v

H=N0['H']; hs=deepcopy(H)
removed=[]
for k in range(n):
    for j in dep:
        if hs[k][j]: removed.append((j,k,hs[k][j]))
        hs[k][j]=Q(0)
assert removed==[(d0,d1,Q(1))]
N=paths(H); Ns=paths(hs)
A=sub(N,dep,dep); C=sub(N,dep,gat); Cs=sub(Ns,dep,gat)
assert all(A[i][j]==Q(i==j) for i in range(len(dep)) for j in range(i,len(dep)))
assert mul(A,Cs)==C
assert len(echelon(C)[1])==len(echelon(Cs)[1])==8
v=kernel(C); vs=kernel(Cs)
assert v==vs and v[0] and v[1]
print('first-depositor identity: C=A*C_sink; A unit lower triangular')
print('both gather matrices rank=8; identical circuit:',[str(x) for x in v])
print('depositor relay:',removed,'; D remains 57 after edge deletion')

# The original relay network has the exact pinned Gram transfer. The sink
# graph keeps the compensated G but removes the edge which it compensated;
# independently recompute every odd P104 cell.
states=[]
for k in range(n):
    states.append([N0['F'][k][p]+sum((hs[k][j]*states[j][p] for j in range(k)),Q(0)) for p in range(104)])
errors=[]
for q in range(104):
    for p0 in range(104):
        if s['dot2'](s['labels'][q],s['labels'][p0]):
            val=sum((N0['G'][q][k]*states[k][p0] for k in range(n)),Q(0))
            if val!=Q(q==p0): errors.append((q,p0,val))
assert errors and any(q==p0 for q,p0,_ in errors)
print('sink transfer loses P104 hM:',len(errors),'odd failures;',sum(q==p0 for q,p0,_ in errors),'diagonal failures')
print('ALL COMPENSATED RELAY SINK CHECKS PASSED')

# Independent abstract DAG with three comparable depositors, a gatherer
# that is itself a depositor, an indirect relay, and exact cancellation.
# It tests the entire sink identity, not P104 label or transfer claims.
Htoy=[[Q(0) for _ in range(8)] for _ in range(8)]
for i,j,value in [(1,0,1),(2,1,2),(3,2,1),(3,0,-2),
                  (4,3,3),(5,4,1),(6,5,1),(7,6,1)]:
    Htoy[i][j]=Q(value)
Dt=[1,3,6]; Gt=[0,1,2,4,5]
Nt=paths(Htoy); At=sub(Nt,Dt,Dt); Ct=sub(Nt,Dt,Gt)
assert Nt[3][0]==0 and Nt[6][1]!=0 and 1 in set(Dt)&set(Gt)
H0=deepcopy(Htoy)
for i in range(8):
    for j in Dt:H0[i][j]=Q(0)
C0=sub(paths(H0),Dt,Gt)
assert mul(At,C0)==Ct
assert len(echelon(Ct)[1])==len(echelon(C0)[1])==3
# Removing only direct depot->depot edges misses indirect depot relays.
Hwrong=deepcopy(Htoy)
for i in Dt:
    for j in Dt:Hwrong[i][j]=Q(0)
Cwrong=sub(paths(Hwrong),Dt,Gt)
assert Cwrong==Ct and mul(At,Cwrong)!=Ct
print('synthetic 3-depot identity passes: depot-gather source, two-hop relay, exact cancellation')
print('negative control rejects removing only direct depot-to-depot edges')
