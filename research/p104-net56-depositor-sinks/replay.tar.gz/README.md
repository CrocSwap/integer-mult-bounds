# Depositor relays: a sink reduction and two scoped rank cuts

This is a paper argument with exact controls, **not a Lean theorem**, not a
D=55 example, and not a general proof of NET-D56. The P104 input is
DreamingOfClouds and Claude Opus 5.5's PR #7852, pinned at
`41beda1d6435760dc99e38bd7e65f36798aad212`, including its 8-row rigidity;
the word bridge is #7869 at `06c207a9feb3994a4b987dc3010657b6e85b7956`.
The prior [antichain proofs](https://github.com/CrocSwap/integer-mult-bounds/pull/7871), pinned at
`f4c554afebe370133ed1d04fec8947fe51d85fac`, establish the same two
profile-specific D≥56 results when no distinct depositors are comparable.
They leave depositor relay paths open. The earlier [small-network and fixture
work](https://github.com/CrocSwap/integer-mult-bounds/pull/7860), pinned at
`2d5bb6b08a22f7cb448c1836170eaaced001ecf4`, supplies the sharp P104
controls. The necessary replay code and fixture are under `source/`; the
upstream P104 [notice](source/NOTICE-P104.md) and [license](source/LICENSE-7852)
are retained.

## Claims

Let a P104 `NetW` satisfy `b_j⊆a_j` for all nodes, with exactly nine
active gatherers of dimensions `7,7,≥8,≥8,≥8,≥8,≥8,≥8,≥8` and exactly
eight active depositors. Then `D≥56` in either of these two cases:

1. Every depositor's `a` chart has dimension at least 7; or
2. Exactly two depositors have `dim a<8`, and their dimensions are 6 and 7.

More precisely, write T for the total drop at nondepositors, let E be the
sum over depositors of `max(dim a_d−8,0)`, and let B count depositors
with `dim b_d=0`. In case 1, if m depositor charts have dimension 7,
then **T≥m**. In case 2, **T≥3**. In either case the original-network
accounting gives the stronger **D≥56+E+B**. These T bounds do not assume
D≤55, E=0, or B=0. The exact relay control below attains
`D=56+E+B=57` when E=1 and B=0.

**There is no depositor-antichain hypothesis.** An arbitrary number of
ordered pairs of distinct depositors may be connected, including paths
through nondepositors or other depositors and rational cancellation. This
subsumes the requested one-comparable-pair 6/7 case. It does not settle
other depositor dimension profiles, other gather profiles, the entire
NET-D56 conjecture, or realizability of these examples by legal words.

These claims extend the prior rank arguments by a sink reduction; they do
not assert that deleting relays produces another P104 network.

## First-depositor sink reduction

For any finite acyclic rational network and any ordered set of depositor
nodes Dset, let H0 delete all edges leaving nodes in Dset. With N, N0, A,
C and C0 as defined below, the **sink-reduction identity** is `C=A C0`,
where A is unit lower triangular. Consequently C and C0 have the same
row rank and the same column kernel, even when paths cancel and gatherers
overlap depositors. The proof is the first-depositor path partition below.

The P104-specific deductions in this paragraph refer to the **original** valid P104
`NetW`. Let `N=(I−H)⁻¹`, let `Dset` be the eight depositors in
chronological order, and `S` the nine gatherers. The P104 odd-cell clique
and eight-depositor factorization give rank `M=8` and rank `C=8` for
`C=N[Dset,S]`. The original P104 eight-depositor rigidity (`N8.dep_dim`)
gives `dim b_d≤1` for every depositor. The unique (up to scale) column relation of
C has nonzero coefficients at both 7D gatherers; those two input charts
are distinct and span a space of dimension at least 8. These are the
rigidity consequences used in the prior proof. They must be taken from
**the original P104 transfer**, before the following graph operation.

Form `H0` by setting to zero every edge leaving a depositor; explicitly,
`H0[k,j]=0` if `j∈Dset`, and otherwise `H0[k,j]=H[k,j]`. Put
`N0=(I−H0)⁻¹`, `C0=N0[Dset,S]`, `A=N[Dset,Dset]`.

Partition each original directed path from `g∈S` to `d∈Dset` at its
**first** depositor `z∈Dset`. The part before and including z has the
same weighted sum as `N0[z,g]`; the part from z to d has sum `N[d,z]`.
Thus, over the rationals,

```
C = A C0.                                               (1)
```

Here length-zero paths are included, so (1) also holds when a gathering
node is itself a depositor. A path is classified combinatorially before
summing, so arbitrary cancellations are harmless, including a vanishing
entry of A despite existing paths. The acyclic ordering makes A unit lower
triangular, hence invertible. Therefore `rank C0=8` and C0 has **exactly
the same column kernel** as C. In particular both 7D coefficients remain
nonzero; all subcollections of its eight rows are independent.

The H0 graph has no path from one depositor to a different depositor. It
retains the original charts, node drops, gatherer/depositor sets and local
relay inclusions. This is only an auxiliary DAG: with the original F,G,
its full transfer usually is not the original transfer and can fail the
P104 odd-cell condition. Equation (1) restores the full transfer as
`G_D A C0 F_S`, but replacing `G_D` by `G_D A` can violate depositor
support. The exact control below demonstrates **both** failures. No
P104 theorem is applied anew to the sinked DAG.

## Rank-cut argument for all depositor dimensions ≥7

Use the sinked DAG only with the unchanged rank, relation and chart facts.
Let m, B, E and T be as in the claim. The original bound `dim b_d≤1` gives

```
D = 56 − m + E + B + T.                                (2)
```

For m=0 the asserted T≥m is immediate. For m≥1, suppose for contradiction
that `T≤m−1` and select those m low depositor rows of C0, calling the resulting matrix C_L. They are
independent. Let C_H denote its seven high-gather columns. The unique
gatherer relation has nonzero coefficients on both remaining columns, so
at most one additional rank comes from them:

```
rank C_H ≥ m−1.                                        (3)
```

Let X be the positive-drop nondepositors. Every high-gather-to-low-depot
path in H0 meets X: otherwise zero-drop relay inclusions would carry an
at-least-8D gather chart into a 7D depot. No depositor can occur earlier
on such a path in the sinked DAG. This also covers a source that is a
depositor, as a depositor can no longer leave its node.

Enumerate X topologically. Let U[d,x] sum paths from x to a low depot d
with no other X vertex, K[y,x] sum paths from x to y with no other X
vertex, and E_X[x,g] sum paths from g to x with no other X vertex. For
the high columns the exact path partition is

```
C_H = U (I−K)⁻¹ E_X,       rank C_H ≤ |X| ≤ T.          (4)
```

Combine (3)–(4) with `T≤m−1` to obtain
`m−1≤rank C_H≤|X|≤T≤m−1`. All inequalities are equalities. Thus
`|X|=T=m−1`, every x∈X has drop one, and U has full column rank. When m=1, X is empty and the
following argument still applies, with U the zero-column matrix.

For `m>1`, (4) also makes E_X full row rank. Each x consequently has an
X-free path from a high gatherer and an X-free path to a low depot. The
first path gives `dim a_x≥8`; the second gives `b_x⊆a_d`, `dim a_d=7`.
With drop one this forces `dim a_x=8`, `dim b_x=7`, and `b_x=a_d`.
Every nonzero entry U[d,x] therefore belongs to a depot with that same
chart `a_d=b_x`. Partition the m coordinates by equal low-depot charts;
then `im U` is a direct sum of subspaces supported on individual chart
groups.

For either 7D gatherer, split its C_L column into paths meeting X and
paths avoiding X. The first contribution lies in `im U`. The second is
supported only on depots having the same chart as that gatherer: if the
source is not a depositor, zero-drop propagation proves inclusion and
both charts have dimension 7; if it is a depositor, only its length-zero
path remains. (If the source lies in X, there is no bypass.)

The two gatherer charts are distinct. Modulo `im U`, their bypass vectors
belong to distinct direct-sum components, while the high columns vanish.
The preserved gatherer relation has both 7D coefficients nonzero, so
each bypass vanishes in the quotient. Hence all nine columns of C_L lie
in `im U`, contrary to `rank C_L=m>|X|=m−1`. This contradiction proves T≥m; (2) then
gives D≥56+E+B, establishing case 1. ∎

## Rank-cut argument for the 6D/7D depositor profile

Let d6,d7 denote the unique low depositors, `A6=a_d6`, `A7=a_d7`, and X
the positive-drop nondepositors in the sinked DAG. For the original
network, with B, E and T as above,

```
D = 53 + E + B + T.                                    (5)
```

Write C_L for the d6,d7 rows of C0; they have rank 2. As before, all
high-gather paths to either low depot meet X, so their columns lie in
`im U`. A 7D-gather bypass of X cannot reach d6, and can reach d7 only
if its chart is A7. Since the two low-gather charts are distinct, at most
one low-gather column has a nonzero bypass. The preserved relation forces
this exceptional bypass into `im U` too. Thus all of C_L lies in `im U`;
`rank U=2`, so `|X|≥2` and `T≥2`. Suppose for contradiction that
T≤2. Then T=2, and X consists of exactly two nodes, x and y, each of
drop 1. No condition on E or B is used in this argument.
The high columns of C_L have rank at least 1.

Pick a high-to-low support path and let y be its first X node. Its
zero-drop prefix gives `dim a_y≥8`. Since U has two columns and rank 2,
y's U column is nonzero; it has an X-free path to d6 or d7. The former is
impossible because `dim b_y≥7`, so `b_y=A7`, `dim a_y=8`, and
y's U column is supported only at d7. The other U column must be nonzero
at d6, giving `b_x⊆A6` and `dim a_x≤7`.

Put `t=N0[{d6,d7},y]`. Any high-to-low path avoiding y would have to hit
x first, contradicting `dim a_x≤7` by zero-drop propagation. Hence all
high columns lie in `span(t)`, and t is nonzero. Split each low-gather
column into the through-y part and a y-avoiding part. A y-avoiding path
that visits x can start at at most one of the two low gatherers: its
prefix forces that gatherer's 7D chart to equal `a_x`. A path avoiding
both x and y can only end at d7, and only from a gatherer with chart A7.

* If `a_x=A7`, at most one low gatherer has any y-avoiding path. The
  gatherer relation forces its column into `span(t)`, contradicting
  `rank C_L=2`.
* If `a_x≠A7`, y cannot reach x, since such a path would force
  `A7=b_y⊆a_x` and hence equality. A y-to-d6 path avoiding x would force
  `A7⊆A6`, also impossible. Therefore t is supported only at d7 and
  spans its coordinate line. Paths avoiding x and y also land in this
  line. At most one low gatherer can contribute anything outside it via
  x, and the gatherer relation again forces its column into the line,
  contradicting `rank C_L=2`.

All paths in this argument are in the sinked DAG, so no intermediate
depositor is present. The argument partitions signed path sums, not just
reachability; nonzero sums imply the existence of a support path, while
cancellation is otherwise unrestricted. Thus T≥3; (5) gives
D≥56+E+B, establishing case 2. ∎

## Exact controls

Run with Python 3 and only the standard library, from this directory:

```
python3 -B check_relay.py
python3 -B check_independent_sink.py
python3 -B check_restricted_bases.py
```

The copied and attributed `source/` package verifies its source blobs and
fixture and constructs the previous D=56 6/7 antichain control. The new
checker inserts an intermediate nondepositor and a **nonzero** 2/3 relay
from the 6D depositor to a distinct depositor, then compensates the latter's
input and expands its a-chart by one. The original complete 104×104 P104
transfer is exactly unchanged; the resulting network has 9 gatherers,
8 depositors, 6/7 low depositor dimensions, exactly one ordered depositor
pair, E=1, B=0, T=3, and **D=57=56+E+B**. Thus it is a genuine
comparable-depositor P104 control meeting the strengthened bound at E=1;
it is not a D=56 equality or a D=55 construction. The sinked matrix has rank
8 and the same unique circuit. Applying the unchanged G to the sinked
graph breaks 1,450 original odd/diagonal cells; using `G_D A` instead
restores every transfer cell but violates 30 depositor support cells.

A separate small rational DAG checks (1) with multiple depositor pairs,
a cancelled nonempty path sum, a nonzero relay sum, and all three
synthetic depositors also appearing as gatherer sources.

An independent R2 AI network lane reviewed the arguments and built a
distinct valid P104 direct-depositor-relay example in
`check_independent_sink.py`. It reaches **D=57=56+E+B** with E=0, B=1,
T=0, and again loses P104 transfer after sink deletion. Its restricted
basis screen `check_restricted_bases.py` examines the 8,766 independent
sets of eight pinned null lines and finds eight that support the specified
bi-rigid dual Gram construction; none admits a cross-depositor chart
inclusion. This is not an exhaustive D=56 network search.

The examples do not exhaust graphs or coefficients. The exact source and
archive pins and byte manifest are in `SOURCES.json` and `SHA256SUMS`;
recorded fresh-copy outputs are in `REPLAY-*.log`. These are AI paper/code
checks, not Lean replay.

## Word-model scope and next question

The pinned #7869 bridge derives a nested P104 network from a word under
its stated verifier and labeling hypotheses, with network D equal to
owned descent. Therefore this theorem applies to such a word if its
**induced network additionally has the stated nine-gather/eight-depositor
counts and one of the two depositor profiles**. It does not prove that a
particular caller word has those counts or profiles, that either concrete
network is word-realizable, or the general NET-D56/Wall56 assertion. It
establishes no rise bound, complete caller saving, or κ improvement.

The next bounded mathematical question is the remaining case with one or
more depositor charts of dimension at most 6 outside the exact 6D/7D
profile. The sink identity removes depositor comparability as a separate
obstacle for path arguments, but the 6/7 proof's two-drop budget and
chart structure need not extend to those profiles.
