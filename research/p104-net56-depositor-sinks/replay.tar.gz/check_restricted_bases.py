from itertools import combinations
import runpy
from pathlib import Path
p=Path(__file__).resolve().parent/'source'
z=runpy.run_path(str(p/'check_hyperplanes.py'))
bad=z['bad']; vec=z['bad_vectors']; rank=z['rank_mod']
dot=lambda x,y:sum(a*b for a,b in zip(x,y))
par=lambda x,y:(x&y).bit_count()&1
dotmat=[[dot(x,y) for y in vec] for x in vec]
count=good=0
for comb in combinations(range(16),8):
 if rank([vec[i] for i in comb])!=8: continue
 count+=1
 options=[[] for _ in range(8)]
 for j in range(16):
  nonzero=[k for k,i in enumerate(comb) if dotmat[i][j]]
  if len(nonzero)==1 and not par(bad[comb[nonzero[0]]],bad[j]): options[nonzero[0]].append(j)
 if all(options):
  assert all(len(o)==1 for o in options), options
  good+=1
  picks=[o[0] for o in options]
  edges=[(i,j) for i in range(8) for j in range(8) if i!=j and not par(bad[picks[i]],bad[comb[j]])]
  if edges:
   raise AssertionError(('unexpected cross inclusion', comb, picks, edges))
assert count == 8766 and good == 8
print('No cross-inclusion for any bi-rigid basis; bases tested:', count,'both-side rigid bases:',good)
