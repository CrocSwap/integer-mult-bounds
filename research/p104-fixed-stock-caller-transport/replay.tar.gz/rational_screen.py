#!/usr/bin/env python3
"""Bounded local screen of a cross-contact idle transfer. No physical qualification."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal, localcontext
import sys, gzip, json, hashlib, time, resource, inspect
BASE=Path(__file__).resolve().parent
p=BASE/'sources/rational'
sys.path.insert(0,str(p)); import mixed_grid as mg
assert hashlib.sha256((p/'mixed_grid.py').read_bytes()).hexdigest()=='95b0526530467e84e1dd295e98fb1442d68e97a724b1b8724d04fcd2284d646b'
assert hashlib.sha256((p/'mixed_caller.py').read_bytes()).hexdigest()=='4824b2aaadb592550d3a25c16ff0a453705e10b8868f5c22fe10c2874bcb9bae'
raw=gzip.decompress((p/'data/CONJUGATE-CALLER.json.gz').read_bytes()); sha=hashlib.sha256(raw).hexdigest()
assert sha=='54a44134a6f9bb3d9e1a27d3bd7ba5fb1cffea3cdfe00f6a72e80f0bbd99d2d7'
w=json.loads(raw); ev=w['events']; targets=w['diagonal']; t0=time.process_time()
assert ev[1193]==['IDLE_ONE',0,[7]]
assert ev[1200]==['ADD',0,7,['0','1/2']]
assert ev[1513]==['HOST_B',7,0,15]
assert ev[1653]==['IDLE_ONE',0,[14,13,12,11,10,9,8]]
# Independent formal evaluator, derived from the pinned source. Exposes the first endpoint
# discrepancy and tests an IDEAL, separately priced whole-body shear into scratch.
source=inspect.getsource(mg.exact).replace('def exact(', 'def exact_observe(',1)
source=source.replace("rows = [{(i, 0, 0): (grid, 0)} for i in range(len(targets))]", "rows = [{(i, 0, 0): (grid, 0)} for i in range(len(targets))] + [{}]")
source=source.replace("elif op == 'LAMBDA':\n", "elif op == 'BODY_QUERY':\n            donor, stage, direction = v\n            rows[target] = add(rows[target], term(rows[donor], a=direction, body=unit[stage]))\n        elif op == 'LAMBDA':\n",1)
old="        need(rows[i] == {(i, q % 4, sum(unit[j] for j in mask)): (grid, 0)}, 'signed diagonal endpoint')"
new="""        target_row = {(i, q % 4, sum(unit[j] for j in mask)): (grid, 0)}
        if rows[i] != target_row:
            keys = sorted(set(rows[i]) | set(target_row))
            key = next(k for k in keys if rows[i].get(k, (0,0)) != target_row.get(k,(0,0)))
            return dict(status='reject', output_role=i, key=list(key), got=list(rows[i].get(key,(0,0))), expected=list(target_row.get(key,(0,0))), exponent_bits=bits, scratch_empty=not bool(rows[-1]))"""
assert old in source; source=source.replace(old,new,1)
source=source.replace("    return dict(minimum_grid=", "    need(not rows[-1], 'scratch not cleared')\n    return dict(status='pass', scratch_empty=True, minimum_grid=",1)
ns=mg.__dict__.copy(); exec(source,ns); replay=ns['exact_observe']
# Move across 6 disjoint ADDs only: exact zero-price positive control.
comm=[x.copy() for x in ev]; move=comm.pop(1193); comm.insert(1199,move)
# Across one more ADD: ideal body-shear compute, use, uncompute.
# Each BODY_QUERY is a *hypothetical* rank-8 complete shear; its source-level
# semantics and charged calls are explicit, physical realization not supplied.
repair=[x.copy() for x in ev]; repair.pop(1193); insertion=1200
repair[insertion:insertion]=[
 ['IDLE_ONE',0,[7]],
 ['BODY_QUERY',30,7,7,1],
 ['ADD',0,7,['0','1/2']],
 ['ADD',0,30,['0','-1/2']],
 ['BODY_QUERY',30,7,7,-1],
]
# Assert index shifted correctly: inserted immediately after the source ADD 1200.
assert repair[insertion-1]==ev[1200]
late=[x.copy() for x in ev];late.pop(1193);late[1652]=['IDLE_ONE',0,[14,13,12,11,10,9,8,7]]
results={name:replay(events,targets,2025<<9) for name,events in [('original',ev),('commuted_across_disjoint_adds',comm),('repaired_across_first_reader',repair),('delayed_fused_unrepaired',late)]}
assert results['original']['status']==results['commuted_across_disjoint_adds']['status']==results['repaired_across_first_reader']['status']=='pass'
assert results['delayed_fused_unrepaired']['status']=='reject'
# Transport the original paid direction through the intervening path at h=i,
# D7=2 and all other D_j=1. Scalar arithmetic is exact rational Gaussian.
def add(z,w): return (z[0]+w[0],z[1]+w[1])
def mul(z,w): return (z[0]*w[0]-z[1]*w[1],z[0]*w[1]+z[1]*w[0])
def scale(z,s):return (z[0]*s,z[1]*s)
zero=(F(0),F(0));one=(F(1),F(0))
def apply(v,e,d=F(2),selected=7):
 op=e[0];j=e[1]
 if op=='ADD':v[j]=add(v[j],mul(v[e[2]],tuple(map(F,e[3]))))
 elif op=='SCALE':v[j]=mul(v[j],tuple(map(F,e[2])))
 elif op=='SWAP':v[j],v[e[2]]=v[e[2]],v[j]
 elif op=='QUERY':v[j]=add(v[j],mul(v[e[2]],(F(0),F(e[3]))))
 elif op=='LAMBDA':v[j]=mul(v[j],(F(0),F(e[2])))
 elif op in ('IDLE_ONE','IDLE_ODD'):
  v[j]=scale(v[j],d**(selected in e[2]))
  if op=='IDLE_ODD':v[j]=mul(v[j],(F(0),F(e[3])))
 elif op=='HOST_A':
  stage,x,y,u,z=e[1:];v[y]=add(v[y],mul(v[x],(F(0),F(-1))));v[u]=add(v[u],mul(v[z],(F(0),F(-1))))
  if stage==selected:
   for k in (x,y,u,z):v[k]=scale(v[k],d)
 elif op=='HOST_B':
  stage,x,y=e[1:];a,b=v[x],v[y];v[x]=add(a,mul(b,(F(0),F(-1))));v[y]=scale(add(b,mul(a,(F(0),F(-1)))),F(1,2))
  if stage==selected:
   for k in (x,y):v[k]=scale(v[k],d)
 else:raise ValueError(e)
 return v
v=[zero]*30;v[0]=one
for event in ev[1194:1653]:apply(v,event)
vec={str(i):list(map(str,z)) for i,z in enumerate(v) if z!=zero}
assert len(vec)>1 and '8' in vec
# Actual #7830 rotated caller: source CUT=1641, body color plus 8 modulo 16.
rot=[]
for event in ev[1641:]+ev[:1641]:
 op,first,*args=event
 if op.startswith('HOST_'):rot.append([op,(first+8)%16,*args])
 elif op=='IDLE_ONE':rot.append([op,first,[(j+8)%16 for j in args[0]]])
 else:rot.append(event.copy())
rot_targets=[[q,[(j+8)%16 for j in mask]] for q,mask in targets]
rot_hash=hashlib.sha256(json.dumps([rot,rot_targets],separators=(',',':')).encode()).hexdigest()
assert rot_hash=='cb3b76c34d4b9ad93316d44297a1e918232c0491c8d3e028df5a01b60d7bf454'
early,reader,last=951,958,2189
assert rot[early]==['IDLE_ONE',15,[0]] and rot[reader]==['ADD',15,29,['0','1/2']]
assert rot[last]==['IDLE_ONE',15,[9,10,11,12,13,14,15]]
rot_comm=[x.copy() for x in rot];m=rot_comm.pop(early);rot_comm.insert(reader-1,m)
rot_repair=[x.copy() for x in rot];rot_repair.pop(early)
rot_repair[reader:reader]=[
 ['IDLE_ONE',15,[0]], ['BODY_QUERY',30,29,0,1],
 ['ADD',15,29,['0','1/2']], ['ADD',15,30,['0','-1/2']],
 ['BODY_QUERY',30,29,0,-1],
]
assert rot_repair[reader-1]==rot[reader]
rot_late=[x.copy() for x in rot];rot_late.pop(early);rot_late[last-1]=['IDLE_ONE',15,[9,10,11,12,13,14,15,0]]
rot_results={name:replay(events,rot_targets,2025<<9) for name,events in [('original',rot),('commuted_across_disjoint_adds',rot_comm),('repaired_across_first_reader',rot_repair),('delayed_fused_unrepaired',rot_late)]}
assert all(rot_results[k]['status']=='pass' for k in ('original','commuted_across_disjoint_adds','repaired_across_first_reader'))
assert rot_results['delayed_fused_unrepaired']['status']=='reject'
rv=[zero]*30;rv[15]=one
for event in rot[early+1:last]:apply(rv,event,selected=0)
rot_vec={str(i):list(map(str,z)) for i,z in enumerate(rv) if z!=zero}
assert len(rot_vec)>1
rot_hosts=[e[1] for e in rot[early+1:last] if e[0].startswith('HOST_')]
assert len(rot_hosts)==9
rot_receipt={'rotated_word_sha256':rot_hash,'early_event':early,'first_affected_add':reader,'late_event':last,
 'source_event_indices':[2592,2599,40],'intervening_host_stages':rot_hosts,
 'formal_results':rot_results,'transported_paid_direction_h_i_D0_2_other_D_1':rot_vec}
# Decimal figures are explanatory; strict sign follows 0<t<1 and H56<H64.
with localcontext() as c:
 c.prec=70; exponent=Decimal(1)-Decimal('0.003879929046155');H=lambda r:Decimal(r)**exponent
 gross=H(8)+H(56)-H(64)
 price={
  'target_kappa':'0.003879929046155', 't':str(exponent),
  'gross_unsupported_single_fusion':str(gross),
  'gross_for_192_mixed_roots':str(192*gross),
  'net_if_one_extra_grade8_and_free_everything_else':str(gross-H(8)),
  'net_if_two_extra_grade8_for_compute_and_uncompute':str(gross-2*H(8)),
  'fixed_root_targets_delta':{},
  'strict_sign_reason':'gross-H8=H56-H64<0 for 0<t<1',
 }
out={'source_uncompressed_sha256':sha,'source_events':len(ev),'source_roles':len(targets),
 'events_0based':{'earlier_idle':1193,'first_affected_add':1200,'central_B':1513,'later_idle':1653},
 'formal_results':results,'transported_paid_direction_h_i_D7_2_other_D_1':vec,
 'price':price,
 'actual_rotated_caller':rot_receipt,
 'body_query_contract':'IDEAL X += sign*D7*Y on independent scratch, unchanged donor; not source grammar or physical implementation',
 'scope':'fixed 30-role stock, no earlier uncatalogued D7 multiple; all four formal head powers for endpoint replay; no arbitrary changed intermediates claim',
 'cpu_seconds':time.process_time()-t0,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
print(json.dumps(out,indent=2,sort_keys=True))
