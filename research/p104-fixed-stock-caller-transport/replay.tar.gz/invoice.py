#!/usr/bin/env python3
"""Directed invoice screen using the unchanged independently published engine."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
from collections import Counter
import importlib.util,json
HERE=Path(__file__).resolve().parent
source=HERE/'sources/invoice/independent.py';receipt=HERE/'sources/invoice/BIT.json'
assert sha256(source.read_bytes()).hexdigest()=='a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca'
assert sha256(receipt.read_bytes()).hexdigest()=='8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'
spec=importlib.util.spec_from_file_location('fixed_grid_invoice',source)
I=importlib.util.module_from_spec(spec);spec.loader.exec_module(I)
r=json.loads(receipt.read_bytes())['native'];paid=Counter({int(k):v for k,v in r['paid'].items()});targets=Counter({int(k):v for k,v in r['targets'].items()})
k=Fraction('0.003879929046155');t=1-k
H=lambda r:I.power(r,t)
margin=I.sub(I.moment(targets,t),I.moment(paid,t))
bit_gross=I.sub(I.add(H(56),H(7)),H(63));rational_gross=I.sub(I.add(H(56),H(8)),H(64))
bit_repair_delta=I.scale(H(7),-1);rat_repair_delta=I.scale(H(8),-2)
assert margin[1]<0 and bit_gross[0]>0 and bit_repair_delta[1]<0
print(json.dumps({'kappa':str(k),'kappa_decimal':'0.003879929046155','full_fixed_BIT_signed_balance':I.report_interval(margin),
 'BIT_unachieved_fusion_gross_per_group':I.report_interval(bit_gross),
 'BIT_unachieved_fusion_gross_111_groups':I.report_interval(I.scale(bit_gross,111)),
 'BIT_specific_reuse_with_two_grade7_minus_original_one_per_group':I.report_interval(bit_repair_delta),
 'BIT_specific_reuse_111_groups':I.report_interval(I.scale(bit_repair_delta,111)),
 'rational_unachieved_fusion_gross_per_root':I.report_interval(rational_gross),
 'rational_actual_ideal_local_repair_delta_per_root':I.report_interval(rat_repair_delta),
 'method':'directed rational-grid logarithm and exponential enclosures from authenticated prior independent review; unchanged BIT histogram'} ,indent=2,sort_keys=True))
