#!/usr/bin/env python3
from pathlib import Path
from hashlib import sha256
from decimal import Decimal, localcontext
from collections import Counter
import gzip,json,time,resource
BASE=Path(__file__).resolve().parent
p=BASE/'sources/bit/EFREE-CALLER.json.gz'
b=p.read_bytes(); assert sha256(b).hexdigest()=='757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
w=json.loads(gzip.decompress(b));E=w['events'];N=38; zero=(0,)*18;start=time.process_time()
def shift(row,q=0,ss=()):
 out=set()
 for i,h,deg in row:
  d=list(deg)
  for s in ss:d[s-1]+=1
  out.add((i,h^q,tuple(d)))
 return out
def advance(rows,e):
 op=e[0]
 if op=='ADD':rows[e[1]] ^= rows[e[2]]
 elif op=='SWAP':rows[e[1]],rows[e[2]]=rows[e[2]],rows[e[1]]
 elif op=='QUERY':rows[e[1]] ^= shift(rows[e[2]],q=1)
 elif op=='IDLE_ONE':rows[e[1]]=shift(rows[e[1]],ss=e[2])
 elif op=='LOCAL':
  _,stage,a,b=e;rows[b] ^= shift(rows[a],q=1);rows[a]=shift(rows[a],ss=(stage,));rows[b]=shift(rows[b],ss=(stage,))
 else:raise ValueError(e)
def initials():return [{(i,0,zero)} for i in range(N)]
def reverse_functional(rows,e):
 op=e[0]
 if op=='ADD':rows[e[2]] ^= rows[e[1]]
 elif op=='SWAP':rows[e[1]],rows[e[2]]=rows[e[2]],rows[e[1]]
 elif op=='QUERY':rows[e[2]] ^= shift(rows[e[1]],q=1)
 elif op=='IDLE_ONE':rows[e[1]]=shift(rows[e[1]],ss=e[2])
 elif op=='LOCAL':
  _,stage,a,b=e;rows[a]=shift(rows[a],ss=(stage,));rows[b]=shift(rows[b],ss=(stage,));rows[a] ^= shift(rows[b],q=1)
 else:raise ValueError(e)
def encode(t):
 i,h,d=t;return {'input_role':i,'q':h,'stages':{str(j+1):v for j,v in enumerate(d) if v}}
def membership(target,rows):
 terms=sorted(set(target).union(*rows));ids={t:i for i,t in enumerate(terms)}
 def bits(row):
  b=0
  for t in row:b^=1<<ids[t]
  return b
 basis={}
 for row in rows:
  x=bits(row)
  while x:
   k=x.bit_length()-1
   if k in basis:x^=basis[k]
   else:basis[k]=x;break
 y=bits(target)
 while y:
  k=y.bit_length()-1
  if k in basis:y^=basis[k]
  else:break
 residual=[terms[j] for j in range(len(terms)) if y>>j&1]
 return {'found':not bool(y),'stock_rank':len(basis),'stock_generators':len(rows),'residual_nonzero':len(residual), 'residual_terms':[encode(t) for t in residual[:8]]}
assert E[19]==['IDLE_ONE',2,[2,3,4,5,6,7,8,9]] and E[397]==['IDLE_ONE',2,[10]]
assert E[158]==['ADD',2,1]
r=initials();P=None
for n,e in enumerate(E):
 if n==397:
  stock=[v.copy() for v in r];Y=r[2].copy();break
 advance(r,e)
 if n==19:P=r[2].copy()
assert P is not None and Y is not None
Z=Y ^ P;PY=shift(P,ss=(10,));DZ=shift(Z,ss=(10,));DY=shift(Y,ss=(10,))
expectedP={(0,0,tuple([1]*9+[0]*9)),(0,1,tuple([1]*9+[0]*9)),(1,1,tuple([1]*9+[0]*9))}
expectedZ={(1,1,tuple([1]*9+[0]*9)),(11,0,zero)}
assert P==expectedP and Z==expectedZ and DY==PY^DZ
stock_q=stock+[shift(v,q=1) for v in stock]
search={
 'D10Y_from_fixed_stock_and_free_q':membership(DY,stock_q),
 'D10Z_from_fixed_stock_held_P_and_Pplus_and_free_q':membership(DZ,stock_q+[P,PY,shift(P,q=1),shift(PY,q=1)]),
 'positive_D10Y_from_ideal_Pplus_and_D10Z':membership(DY,[PY,DZ]),
}
assert not search['D10Y_from_fixed_stock_and_free_q']['found']
assert not search['D10Z_from_fixed_stock_held_P_and_Pplus_and_free_q']['found']
assert search['positive_D10Y_from_ideal_Pplus_and_D10Z']['found']
# Explicit x11 projection proves the stock witness independently of elimination.
x11={j:{z for z in v if z[0]==11} for j,v in enumerate(stock) if any(z[0]==11 for z in v)}
d10=tuple([0]*9+[1]+[0]*8)
assert x11=={1:{(11,0,d10),(11,1,d10)},2:{(11,0,zero)}}
assert not any(z[0]==11 for z in P | PY)
# The attempted higher-grade early idle changes the paid observation P into D10 P.
# Compare the symbolic states with no other edits until the earliest donor read.
a=initials();c=initials();first_donor=None;first_target=None
for n,e in enumerate(E[:159]):
 if n==19:
  advance(a,e);advance(c,['IDLE_ONE',2,[2,3,4,5,6,7,8,9,10]])
 else:
  if n>19 and e[0] in ('ADD','QUERY'):
   if first_donor is None and a[e[2]] != c[e[2]]:first_donor={'event':n,'event_value':e,'donor_delta':len(a[e[2]]^c[e[2]])}
   if first_target is None and a[e[1]] != c[e[1]]:first_target={'event':n,'event_value':e,'target_delta':len(a[e[1]]^c[e[1]])}
  advance(a,e);advance(c,e)
assert first_donor['event']==158 and first_target['event']==129
# Original full identity and naive candidate failure, with a first coefficient witness.
r=initials()
for e in E:advance(r,e)
expected=[{(i,d['q'],tuple(int(j in d['stages']) for j in range(1,19)))} for i,d in enumerate(w['diagonal'])]
assert r==expected
back=initials()
for e in reversed(E):reverse_functional(back,e)
assert back==expected
# Mathematical replacement with virtual P and D10P plus a full residual D10Z.
# This exact identity checks all columns, but does not allocate or erase held stock.
rr=initials();virtualP=None
for n,e in enumerate(E):
 if n==397:
  assert virtualP==P
  rr[2]=shift(rr[2]^virtualP,ss=(10,))^shift(virtualP,ss=(10,))
 else:
  advance(rr,e)
  if n==19:virtualP=rr[2].copy()
assert rr==expected
bad=initials()
for n,e in enumerate(E):
 if n==19:advance(bad,['IDLE_ONE',2,[2,3,4,5,6,7,8,9,10]])
 elif n==397:continue
 else:advance(bad,e)
badroles=[i for i in range(N) if bad[i]!=expected[i]]
assert badroles
mutated=[(['IDLE_ONE',2,[2,3,4,5,6,7,8,9,10]] if n==19 else e) for n,e in enumerate(E) if n!=397]
backbad=initials()
for e in reversed(mutated):reverse_functional(backbad,e)
bad_reverse_roles=[i for i in range(N) if backbad[i]!=expected[i]]
assert bad_reverse_roles
wit=sorted(bad[badroles[0]] ^ expected[badroles[0]])[0]
with localcontext() as ctx:
 ctx.prec=60
 price={}
 for kappa in ('0.003879929046155',):
  t=Decimal(1)-Decimal(kappa);H=lambda n:Decimal(n)**t
  price[kappa]={'per_root_fused_gross_H56_plus_H7_minus_H63':str(H(56)+H(7)-H(63)),
   'unconditional_P_and_Pplus_before_residual_net':str(H(56)+H(7)-(H(56)+H(7))),
   'preserved_P_then_one_new_H7_for_Pplus_and_one_H7_for_residual_delta_paid':str(H(7)),
   '111_root_added_signed_debit':str(111*H(7)),
   'naive_regrade_paid_saving_per_root':str(H(56)+H(7)-H(63))}
out={'caller_gzip_sha256':sha256(b).hexdigest(),'cross_J_events':{'earlier_idle':19,'first_target_touch':first_target,'first_donor_reader':first_donor,'later_idle':397},
 'held_paid_observation_P':[encode(t) for t in sorted(P)],'late_input_Y':[encode(t) for t in sorted(Y)],'residual_Z_Y_xor_P':[encode(t) for t in sorted(Z)],
 'free_fixed_stock_exact_membership':search,'naive_endpoint':{'changed_roles':badroles,'reverse_changed_roles':bad_reverse_roles,'witness_output':badroles[0],'witness_term':encode(wit)},
 'original_all_column_exact':True,'original_reverse_functional_exact':True,'ideal_virtual_split_all_column_exact':True,'virtual_stock_allocation_and_erasure_proved':False,'count_affected_physical_groups':111,'price_diagnostics':price,
 'scope':'no physical native rewrites or other moved idle; fixed 38 current rows, one cached P, one cached D10P, free q multiplications, no new earlier P-dependent stock',
 'cpu_seconds':time.process_time()-start,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
print(json.dumps(out,indent=2,sort_keys=True))
