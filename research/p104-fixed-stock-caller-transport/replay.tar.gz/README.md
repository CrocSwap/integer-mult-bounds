# Two fixed-stock caller-transport screens

These bounded screens test specific reuse proposals in the rational and paired BIT callers of [PR #7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. They start from [PR #7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) head `41beda1d6435760dc99e38bd7e65f36798aad212`; they do not assert or refute its conditional theorems. They establish no physical caller improvement or new κ. All events below are **zero-based**.

The near trial is `0.003879929046155`, exactly `10⁻⁹` above the prior BIT raw-crossing upper endpoint `0.003879928046155`. The complete unchanged BIT signed balance at the trial is enclosed by

    [−0.000385127316613866441054139472099789196374646204,
     −0.000385127316613866441054139472099789196374646203].

A strictly positive BIT invoice therefore needs at least that deficit restored. This is a necessary price condition on the fixed comparator, not a new application. `invoice.py` recomputes it with the retained directed arithmetic and all paid and target histogram entries.

## BIT: keep the earlier paid observation

The byte-pinned 38-role paired caller has events `IDLE_ONE(2,[2,…,9])` at 19, and `IDLE_ONE(2,[10])` at 397. These act at different stage cuts, with 111 paired port groups. Let `D_s` be a formal body operator, `q²=1`, and `A=D₁⋯D₉`. The exact value of role 2 immediately after event 19, and its value immediately before event 397, are

    P = A[(1+q)x₀ + qx₁],       Y = A(1+q)x₀ + x₁₁,
    Z = Y + P = qAx₁ + x₁₁.     (addition is XOR)

A proposed reuse holds the already-paid observation `P`, creates `D₁₀P`, and combines it with `D₁₀Z` to produce the required `D₁₀Y`. This is a cross-stage mixed-source construction, not merely commuting two unchanged idles.

An attempt to obtain `D₁₀P` by changing event 19 from grade 56 to grade 63 and removing event 397 does not preserve the earlier observation. The first touched target is event 129 `ADD(1,0)`; the first donor reader is event 158 `ADD(2,1)`. The direct all-column final replay changes output roles 0, 1 and 11; the reverse functional replay also rejects. In particular, output 0 acquires input 1, q-degree 0 and one of each of the 18 body factors, which is absent in the required diagonal endpoint.

Holding the original `P` avoids that early mismatch, but the remaining `D₁₀Z` is not free in the stated stock model. At the cut immediately before event 397, project the 38 current rows onto independent input `x₁₁`. Role 1 has `(1+q)D₁₀x₁₁`, role 2 has `x₁₁`, and every other role has zero projection. The held `P` and the ideal held `D₁₀P` have no `x₁₁` component. Even granting arbitrary fixed XORs and multiplication of any available row by q for free, their span cannot produce `D₁₀x₁₁`: at q=1 the only nonzero stock projection is a scalar multiple of `x₁₁`, while the desired coefficient is `D₁₀`. The executable exact GF(2) elimination independently confirms the failure, while accepting the synthetic positive control `D₁₀Y=D₁₀P+D₁₀Z`.

The explicit virtual split preserves all 38 endpoint rows, but requires both `D₁₀P` and `D₁₀Z`; it does not allocate, physically preserve, or erase the held fields. Retaining the original grade-56 job and paying two grade-7 jobs instead of the original one adds `H₇` per group, or at least `771.155745003685…` in signed debit across 111 groups, before ownership, erasure, precision and ordinary work. The unachieved direct `56+7→63` fusion would have given gross credit `9.342206759310…` across those groups. The failed witness and that attractive gross number are not a saving.

The stock proof freezes all current source values, the stated original native contacts, and the single held observation (plus its ideal stage-10 image). It does not exclude alternate changed stock, a differently allocated or earlier native action, cheaper partial-rank delivery, a joint nonlocal rewrite, or another grammar. The calculation prices the **specified** two-grade-7 residual strategy; it does not prove a universal grade-7 lower bound.

## Rational: one restored reader and a scratch control

For the 30-role #7756 mixed template rotated as in #7776, event 951 is a grade-8 `IDLE_ONE(15,[0])` and event 2189 is a grade-56 `IDLE_ONE(15,[9,…,15])`. Nine native contacts intervene. Dropping the first and adding its axis to the later job yields an invalid endpoint: output 15 contains an extra coefficient −2 from input 15, head power 1, with body stages 1–15 present and stage 0 absent.

The first affected ADD, event 958 `ADD(15,29,i/2)`, requires the following correction if the idle moves immediately after it. For its independent pre-add fields X,Y, body operator D and c=i/2, the source order yields `DX+cY`, whereas the proposed order yields `D(X+cY)`. The missing term is `c(1−D)Y`.

For exactly the existing 30-role stock and fixed Gaussian-linear operations, this term is not available for free. Specialize the normalized head to i and the other body factors to 1. At D=1 the desired correction is zero and the current 30 rows form an invertible basis, so every fixed coefficient in a hypothetical stock representation must be zero. At D=2 the same prefix is invertible and Y can be nonzero, so the correction need not vanish. The proof permits only the stated fixed stock and does not rule out an existing extra copy, altered prefix, shared service or other repair.

`rational_screen.py` tests an **ideal** extra shear `BODY_QUERY(S,Y,D,±1)` into a clean scratch field. Two such grade-8 shears compute and uncompute `DY`; two Gaussian ADDs install the correction. The resulting local rewrite returns scratch to zero and preserves all 30 formal output rows, with head powers modulo four. Its exact symbolic minimum grid is 8, as in the original; it adds symbolic divisions and does not certify the physical tape, scratch routing, or the new shear interface. It also leaves the idle at the earlier reader: it is **not** a completed late fusion. The actual ideal-local signed change is `−2H₈` per root. Even if the unachieved grade-8-plus-grade-56 fusion and cleanup were otherwise free, an extra clean grade-8 repair makes its net `H₅₆−H₆₄<0` for every `0<t<1`.

## Reproduce and scope

With Python 3 and no network or nonstandard packages:

    sha256sum -c SOURCE-SHA256SUMS
    python3 -I -B replay.py

The scripts authenticate their relative source files; replay verifies both exact controls and compares semantic output against `results/`. Runtime fields may vary. The rational check adapts the copied source row interpreter **in memory** to expose its endpoint witness and to model the explicitly hypothetical body query; it is not an independent physical compiler. The BIT check is a separate set-based F₂ Laurent-row interpreter and checks all 1,444 input/output coefficients in both original orientations, the naive candidate in both directions, an exact stock-span obstruction, the explicit `x₁₁` projection, and the virtual split. The invoice uses the copied contributor-supplied directed rational-grid log/exp engine. No modified 36-call physical word, complete common application, tape-cost certificate, or independent human review was produced.

The short unrotated rational pair across central B is also checked as a control, but the #7776 rotation reverses its chronology at the root boundary; it is not presented as an available 48-call transfer. [#7839](https://github.com/CrocSwap/integer-mult-bounds/pull/7839) separately tested protected sibling readers and same-owner product-slab coalescence; its slab credit is not assumed here. A separate local companion screen tested the original idle-pair commutations, including BIT 19/397; the retained-observation and phase-projection test above is a distinct, narrower reuse obligation. [Discussion #7111](https://github.com/CrocSwap/integer-mult-bounds/discussions/7111) contains ToikY's fixed-placement/deletion work and Ali Romman's active caller/return experiments; these screens make no novelty or priority assertion over that work.

## Sources and credit

* Ali Romman's [#7756 mixed caller](https://github.com/CrocSwap/integer-mult-bounds/pull/7756), scientific head `9e051455757d1cc86b822e52e42e1e1c98ead417`, and [#7776 closed placement](https://github.com/CrocSwap/integer-mult-bounds/pull/7776). The uncompressed mixed word hashes to `54a44134a6f9bb3d9e1a27d3bd7ba5fb1cffea3cdfe00f6a72e80f0bbd99d2d7`; the rotated `[events,targets]` hashes to `cb3b76c34d4b9ad93316d44297a1e918232c0491c8d3e028df5a01b60d7bf454`. The source NOTICE, credits, parent pins and license are retained under `sources/rational/`.
* The paired BIT caller descends from DreamingOfClouds's #6834 and #6937, CubeJerry's [#6980](https://github.com/CrocSwap/integer-mult-bounds/pull/6980), and the native and framework contributors credited in `sources/bit/NOTICE` and its retained notice. The compressed caller hash is `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`.
* The #7830 BIT receipt hashes to `8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d`; its independent-review fixed-grid engine hashes to `a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca`. Its source manifest is retained. Clear1nsight and all #7830 predecessor authors retain their credited contributions. This local screen used OpenAI Codex assistance.

## Open next questions

Can a concretely scheduled changed native output produce the missing `D₁₀x₁₁` phase without reintroducing its caller price, while preserving the original `P` readers and clearing every borrowed field? Any such candidate needs an all-column changed caller, both directions and first-reader replay, exact paid and target histograms, stock/precision/ordinary accounting, and a new finite and common-application qualification.
