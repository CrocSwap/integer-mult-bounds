#!/usr/bin/env python3
"""Replay the two bounded caller screens and directed price against saved receipts."""
from pathlib import Path
import json,subprocess,sys
here=Path(__file__).resolve().parent
for script,record in [('bit_screen.py','BIT.json'),('rational_screen.py','RATIONAL.json'),('invoice.py','INVOICE.json')]:
 result=subprocess.run([sys.executable,'-I','-B',str(here/script)],check=True,capture_output=True,text=True)
 got=json.loads(result.stdout);expected=json.loads((here/'results'/record).read_text())
 for obj in (got,expected):
  obj.pop('cpu_seconds',None);obj.pop('peak_rss_kib',None)
 if got!=expected:raise AssertionError(f'{script} differs from the saved semantic receipt')
 print('PASS',script)
