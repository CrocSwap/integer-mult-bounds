#!/usr/bin/env python3
"""Independently check finite singleton-cover and F2 span certificates.

The separately audited CNF projection is explained in REVIEW.md. This checker
uses explicit enumeration of each F2 span (at most 512 elements), not the
producer's Gaussian elimination or scan. No SAT solver is invoked.
"""
from pathlib import Path
import collections, hashlib, importlib.util, json, sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE/'audit'
PINS={'source/drat/gen.py':'2109ace16a7b04aa399ab0a06739afbb6fe378348e06360ce26620b721a08472','source/drat/cubes.txt':'792af281bcb7d5652274ae201624fb69ab49fa99b29fba4522ab295924de3002','source/drat/hashes.tsv':'3cdd8553d2de9c1800daef10f8ea138f6ba3abe27ce8228b9a4ebb3ad678dce7','source/drat/data/e8base.json':'b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41','source/drat/data/perms.json':'1b4e6b64f605f78432d075928ae28696ebf1945679c0818eb319ad61b5e3a3a3','source/drat/data/zclauses.json':'7d586edab8c5527bc47dae89b5e396f69327da7f39707473706bdb7100b05e27','residual-cubes.tsv':'5326f358c5aee7c8849b7cdf7241580721c6f0cfa4d24c0f914357d8f03af2ae','inactive-cover-witnesses.tsv':'88b1681613fda52eff688df9c3a67d9bc7d6b6babd4056ad24b4e32dc8e15d4b'}
for file,want in PINS.items():
 assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==want, file
spec=importlib.util.spec_from_file_location('gen',ROOT/'source/drat/gen.py')
gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen)
b=gen.Base()
E=json.loads((ROOT/'source/drat/data/e8base.json').read_text())['C']
C=json.loads((ROOT/'source/drat/data/zclauses.json').read_text())
def vec(xs):return sum((int(v)&1)<<(i+1) for i,v in enumerate(xs))|1
h=list(map(vec,E[:104])); n=list(map(vec,E[104:]));assert len(h)==104 and len(n)==16
assert len(set(h))==104 and all(v not in h for v in n)
residual={s.split('\t')[0]:int(s.split('\t')[1]) for s in (ROOT/'residual-cubes.tsv').read_text().splitlines() if s and not s.startswith('#')}
covered={s.split('\t')[0] for s in (ROOT/'inactive-cover-witnesses.tsv').read_text().splitlines() if s and not s.startswith('#')}
cubes={parts[0]:parts for line in (ROOT/'source/drat/cubes.txt').read_text().splitlines() if line and not line.startswith('#') for parts in [line.split('\t')]}
hashes={parts[0]:parts[1] for line in (ROOT/'source/drat/hashes.tsv').read_text().splitlines() if line and not line.startswith('#') for parts in [line.split('\t')]}
cert_path=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'certificates.json'
cert=json.loads(cert_path.read_text());assert cert['schema']=='p104-singleton-rank-v1'
ids=set();verified=[]
for case in cert['certificates']:
 cid=case['id'];I=case['inactive_mask']
 assert cid not in ids and cid in residual and cid not in covered and cid!='f3591';ids.add(cid)
 assert I==residual[cid]
 parts=cubes[cid];assert parts[2]=='-'
 original_I=sum(1<<int(z) for z in parts[1].split(',')) if parts[1]!='-' else 0
 assert original_I==I
 extra=gen.cube_extra(b,cid)
 units=[cl[0] for cl in extra if len(cl)==1]
 assert len(units)==16 and set(units)=={b.used[z,8] if I>>z&1 else -b.used[z,8] for z in range(16)}
 payload=gen.cube_text(cid,b=b).encode()
 assert hashlib.sha256(payload).hexdigest()==hashes[cid],cid
 cov=set(b.cls[b.n_cov0:b.n_tot0])
 total=0;row_ids=set();row_counts=[]
 for row in case['rows']:
  z=row['z'];assert isinstance(z,int) and 0<=z<16 and not(I>>z&1) and z not in row_ids
  row_ids.add(z);span={0,n[z]};seen=set()
  for t,clause in row['ports']:
   assert isinstance(t,int) and 0<=t<104 and t not in seen;seen.add(t)
   assert isinstance(clause,int) and clause in C[t]
   assert (clause & ~I)==(1<<z), (cid,z,t,clause)
   assert tuple(b.m[j,t] for j in range(16) if clause>>j&1) in cov
   assert h[t] not in span,(cid,z,t,'dependent witness')
   span=span|{x^h[t] for x in span}
   assert len(span)<=512
  total+=len(row['ports']);row_counts.append((z,len(row['ports'])))
 assert total>55,(cid,total)
 verified.append((cid,I,total,row_counts))
assert len(verified)==29
for cid,I,total,rows in verified:print(cid,'inactive='+str(I),'lower_bound='+str(total),'rows='+','.join(f'{z}:{r}' for z,r in rows))
print('PASS',len(verified),'distinct residual cubes; all 29 regenerated hashes match pinned source rows')
print('PASS exact per-row finite-span independence for 56 forced labels per cube')
print('PASS minimum total abstract price >=56 > 55 on each listed cube')
