#!/usr/bin/env python3
"""Reproduce the proof checks without touching the source checkout."""
from pathlib import Path
import subprocess,sys
HERE=Path(__file__).resolve().parent
for path in ('audit/verify_fidelity.py','audit/verify_cover_eliminations.py','verify_certificates.py','verify_packing_certificates.py','verify_controls.py'):
 print('RUN',path,flush=True)
 subprocess.run([sys.executable,'-B',str(HERE/path)],cwd=HERE,check=True)
print('ALL CHECKS PASSED')
