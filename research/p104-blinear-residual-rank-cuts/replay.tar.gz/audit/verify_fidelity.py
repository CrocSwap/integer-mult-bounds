#!/usr/bin/env python3
"""Check the pinned P104 CNF blocks against independent structural specs.

Also exhaustively checks 2-dimensional RREF and three small comparator and
totalizer components. The mathematical projection arguments are in REVIEW.md.
No SAT solver or DRAT evidence is used here.
"""
from itertools import product
from pathlib import Path
import importlib.util
import sys

sys.dont_write_bytecode = True
DRAT = Path(__file__).resolve().parent / "source/drat"
spec = importlib.util.spec_from_file_location("pinned_gen", DRAT / "gen.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
b = gen.Base()
H, N, CL, _ = gen.load_geometry()

def req(x, message):
    if not x:
        raise AssertionError(message)

# RREF/prefix clauses: construct them without looking at b.cls.
expected = []
for z in range(16):
    for i in range(9):
        u = b.used[z, i]
        if i:
            expected.append((-u, b.used[z, i-1]))
        for c in range(9):
            expected.extend([(u, -b.f[z, i, c]), (u, -b.L[z, i, c])])
        expected.append(tuple([-u] + [b.L[z, i, c] for c in range(9)]))
        for c in range(9):
            for k in range(c+1, 9):
                expected.append((-b.L[z, i, c], -b.L[z, i, k]))
            expected.append((-b.L[z, i, c], b.f[z, i, c]))
            for k in range(c):
                expected.append((-b.L[z, i, c], -b.f[z, i, k]))
            for j in range(9):
                if j != i:
                    expected.append((-b.L[z, i, c], -b.f[z, j, c]))
            if i < 8:
                for k in range(c+1):
                    expected.append((-b.L[z, i, c], -b.L[z, i+1, k]))
row_count = len(expected)

# Match every XOR and every one-way m/nin implication. The author metadata is
# used only to name variables; every dependency is recomputed from H and N.
xs = iter(sorted(b.xdef))
def parity(lits):
    req(bool(lits), "empty support")
    a = lits[0]
    for v in lits[1:]:
        p = next(xs)
        req(b.xdef[p] == (a, v), "xor wiring")
        expected.extend([(-p, a, v), (-p, -a, -v),
                         (p, -a, v), (p, a, -v)])
        a = p
    return a

for z in range(16):
    for t in range(104):
        for i in range(9):
            out = parity([b.f[z, i, c] for c in range(9) if H[t][c]])
            expected.append((-b.m[z, t], -out))
for z in range(16):
    for i in range(9):
        out = parity([b.f[z, i, c] for c in range(9) if N[z][c]])
        expected.append((-b.nin[z], -out))
req(next(xs, None) is None, "extra XORs")
req(len(expected) == b.n_cov0 and expected == b.cls[:b.n_cov0],
    "row/membership CNF does not match specification")
print(f"PASS row + membership blocks: {row_count} + {b.n_cov0-row_count} clauses")

expected = [tuple(b.m[z, t] for z in range(16) if mask >> z & 1)
            for t in range(104) for mask in CL[t]]
req(expected == b.cls[b.n_cov0:b.n_tot0], "covering clauses differ")
req(all(row and all(mask > 0 for mask in row) for row in CL), "empty cover")
print(f"PASS {len(expected)} exact covering clauses (all nonempty)")

# Reconstruct the recursive one-sided totalizer from its postorder tree.
leaves = [b.used[z, i] for z in range(16) for i in range(9)] + [b.nin[z] for z in range(16)]
req(leaves == b.lits and gen.K == 89, "budget leaves/threshold")
nodes = iter(b.tnodes)
expected = []
totvars = []
def tot(xs):
    if len(xs) == 1:
        return xs
    cut = len(xs) // 2
    a, c = tot(xs[:cut]), tot(xs[cut:])
    out, have_a, have_c = next(nodes)
    req(a == have_a and c == have_c and len(out) == len(xs), "totalizer wiring")
    totvars.extend(out)
    for i in range(len(a)+1):
        for j in range(len(c)+1):
            k = i+j+1
            if k > len(xs):
                continue
            clause = [-out[k-1]]
            if i < len(a): clause.append(a[i])
            if j < len(c): clause.append(c[j])
            expected.append(tuple(clause))
    return out
out = tot(leaves)
req(next(nodes, None) is None, "extra totalizer node")
expected.append((out[88],))
req(expected == b.cls[b.n_tot0:b.n_tot1], "totalizer clauses differ")
print(f"PASS totalizer: {len(leaves)} inputs, threshold 89, {len(expected)} clauses")

# Every allocated variable has exactly one role; all variables are accounted.
primary = list(b.used.values()) + list(b.f.values()) + list(b.L.values())
primary += list(b.m.values()) + list(b.nin.values())
lexaux = [x for _, _, eq, ss in b.lex for x in [eq, *ss]]
variables = primary + list(b.xdef) + totvars + lexaux
req(len(variables) == len(set(variables)) == b.nv, "variable-role collision")
req(set(variables) == set(range(1, b.nv+1)), "variable numbering gap")
print(f"PASS {b.nv} variables have disjoint roles")

# Exhaust the 2 x 2 RREF/prefix piece, including malformed pivot flags.
accepted = 0
for u in product(range(2), repeat=2):
  for f in product(range(4), repeat=2):
    for L in product(range(4), repeat=2):
      code = (not u[1] or u[0])
      for i in range(2):
        code &= bool(u[i] or (not f[i] and not L[i]))
        code &= bool(not u[i] or L[i])
        code &= L[i] != 3
        for c in range(2):
          if L[i] >> c & 1:
            code &= bool(f[i] >> c & 1)
            code &= not any(f[i] >> k & 1 for k in range(c))
            code &= not (f[1-i] >> c & 1)
            if i == 0:
              code &= not any(L[1] >> k & 1 for k in range(c+1))
      d = sum(u)
      spec_ok = u == tuple(int(i < d) for i in range(2))
      piv = []
      for i in range(2):
        if i >= d:
          spec_ok &= f[i] == 0 and L[i] == 0
        elif f[i]:
          lead = (f[i] & -f[i]).bit_length()-1
          piv.append(lead)
          spec_ok &= L[i] == 1 << lead
          spec_ok &= not (f[1-i] >> lead & 1)
        else:
          spec_ok = False
      spec_ok &= piv == sorted(set(piv))
      req(bool(code) == bool(spec_ok), "2-dimensional RREF truth table")
      accepted += bool(code)
req(accepted == 5, "F2^2 must have five subspaces")
print("PASS exhaustive 2D RREF truth table: 1024 assignments; 5 subspaces")

# All possible local XOR assignments satisfy the four clauses iff p = a XOR c.
for p, a, c in product(range(2), repeat=3):
    cnf = ((not p or a or c) and (not p or not a or not c)
           and (p or not a or c) and (p or a or not c))
    req(bool(cnf) == (p == (a ^ c)), "XOR truth table")
print("PASS exhaustive XOR truth table")

# 2-position order-code lex block: quantify all 8 auxiliary bits for each
# of the 256 possible pair-of-dimension-vectors over 0..3.
for x0, x1, y0, y1 in product(range(4), repeat=4):
    x, y = (x0, x1), (y0, y1)
    exists = False
    for bits in range(256):
        prev = 1
        good = True
        for j in range(2):
            equal = (bits >> (4*j)) & 1
            strict = [(bits >> (4*j+1+v)) & 1 for v in range(3)]
            if prev and x[j] < y[j]: good = False
            if any(strict[v] and not (x[j] > v >= y[j]) for v in range(3)):
                good = False
            if prev and not equal and not any(strict): good = False
            prev = equal
        if good:
            exists = True
            break
    req(exists == (x >= y), "lex projection")
print("PASS exhaustive two-position lex projection: 256 input tuples")

# A 3-leaf one-sided totalizer, all inputs and all 5 auxiliary assignments.
clauses = []
nextvar = 4
def tot3(xs):
    global nextvar
    if len(xs) == 1: return xs
    a, c = tot3(xs[:len(xs)//2]), tot3(xs[len(xs)//2:])
    o = list(range(nextvar, nextvar+len(xs)))
    nextvar += len(xs)
    for i in range(len(a)+1):
      for j in range(len(c)+1):
        k = i+j+1
        if k <= len(xs):
          clauses.append([-o[k-1]] + ([a[i]] if i < len(a) else [])
                         + ([c[j]] if j < len(c) else []))
    return o
o = tot3([1, 2, 3])
req(nextvar == 9, "toy variable count")
for inp in range(8):
  for k in range(1, 4):
    exists = False
    for aux in range(32):
      val = inp | (aux << 3)
      lit = lambda l: bool(val >> (abs(l)-1) & 1) == (l > 0)
      if lit(o[k-1]) and all(any(lit(l) for l in clause) for clause in clauses):
        exists = True
        break
    req(exists == (inp.bit_count() >= k), "totalizer projection")
print("PASS exhaustive 3-leaf totalizer projection for all three thresholds")
