#!/usr/bin/env python3
"""Check direct inactive-row/cover contradictions, and list remaining cubes.

The archived `gen.cube_extra` supplies the actual units. If used[z,8] is
true, the row RREF has rank nine, U_z is zero and no nonzero affine h_t can
have m[z,t]=1. Thus a positive cover clause contained in the inactive set is
false. This is a finite-data check, not a SAT/DRAT replay.
"""
from pathlib import Path
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
DRAT = ROOT / "source/drat"
spec = importlib.util.spec_from_file_location("pinned_gen", DRAT / "gen.py")
gen = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gen)
b = gen.Base()
CL = json.loads((DRAT / "data/zclauses.json").read_text())
all_masks = {mask for clauses in CL for mask in clauses}
rows = []
for line in (DRAT / "cubes.txt").read_text().splitlines():
    if not line or line.startswith("#"):
        continue
    cid, names, _ = line.split("\t")
    mask = 0 if names == "-" else sum(1 << int(z) for z in names.split(","))
    units = {clause[0] for clause in gen.cube_extra(b, cid) if len(clause) == 1}
    assert all((b.used[z, 8] if mask >> z & 1 else -b.used[z, 8]) in units
               for z in range(16)), f"{cid}: actual units mismatch"
    rows.append((cid, mask))
assert len(rows) == len({cid for cid, _ in rows}) == 1001

supplied = {}
for line in (ROOT / "inactive-cover-witnesses.tsv").read_text().splitlines():
    if line.startswith("#") or not line:
        continue
    cid, mask, port, clause = line.split("\t")
    assert cid not in supplied
    supplied[cid] = (int(mask), int(port), int(clause))
residual = []
for cid, mask in rows:
    possible = any(clause & mask == clause for clause in all_masks)
    if possible:
        assert cid in supplied, f"missing witness for {cid}"
        want_mask, port, clause = supplied[cid]
        assert want_mask == mask and 0 <= port < 104
        assert clause in CL[port] and clause > 0 and clause & mask == clause
    else:
        assert cid not in supplied, f"unexpected witness for {cid}"
        residual.append((cid, mask))
assert len(supplied) == 612 and len(residual) == 389
assert len({mask for mask, _, _ in supplied.values()}) == 612
assert supplied["f3591"] == (3591, 3, 2565)

reported = []
for line in (ROOT / "residual-cubes.tsv").read_text().splitlines():
    if line.startswith("#") or not line:
        continue
    cid, mask = line.split("\t")
    reported.append((cid, int(mask)))
assert reported == residual
print("PASS 612/1001 actual cubes have a cover clause entirely in their inactive set")
print("PASS f3591: port 3, clause 2565 is contained in inactive mask 3591")
print("PASS residual-cubes.tsv lists exactly the other 389 cubes")
