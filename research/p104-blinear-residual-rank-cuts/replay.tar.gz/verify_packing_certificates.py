#!/usr/bin/env python3
"""Verify singleton row bases and independent port-packing certificates."""
from pathlib import Path
import hashlib, importlib.util, itertools, json, sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE/'audit'
PINS={'source/drat/gen.py':'2109ace16a7b04aa399ab0a06739afbb6fe378348e06360ce26620b721a08472','source/drat/cubes.txt':'792af281bcb7d5652274ae201624fb69ab49fa99b29fba4522ab295924de3002','source/drat/hashes.tsv':'3cdd8553d2de9c1800daef10f8ea138f6ba3abe27ce8228b9a4ebb3ad678dce7','source/drat/data/e8base.json':'b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41','source/drat/data/perms.json':'1b4e6b64f605f78432d075928ae28696ebf1945679c0818eb319ad61b5e3a3a3','source/drat/data/zclauses.json':'7d586edab8c5527bc47dae89b5e396f69327da7f39707473706bdb7100b05e27','residual-cubes.tsv':'5326f358c5aee7c8849b7cdf7241580721c6f0cfa4d24c0f914357d8f03af2ae','inactive-cover-witnesses.tsv':'88b1681613fda52eff688df9c3a67d9bc7d6b6babd4056ad24b4e32dc8e15d4b'}
for p,want in PINS.items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==want,p
spec=importlib.util.spec_from_file_location('gen',ROOT/'source/drat/gen.py');gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen);b=gen.Base()
E=json.loads((ROOT/'source/drat/data/e8base.json').read_text())['C'];C=json.loads((ROOT/'source/drat/data/zclauses.json').read_text())
def vec(xs):return 1|sum((int(v)&1)<<(i+1) for i,v in enumerate(xs))
h=list(map(vec,E[:104]));n=list(map(vec,E[104:]));assert len(h)==104 and len(n)==16 and len(set(h))==104
assert all(v not in h for v in n)
def rows(path):return [s.split('\t') for s in (ROOT/path).read_text().splitlines() if s and not s.startswith('#')]
residual={r[0]:int(r[1]) for r in rows('residual-cubes.tsv')};old={r[0] for r in rows('inactive-cover-witnesses.tsv')};cubes={r[0]:r for r in rows('source/drat/cubes.txt')};hashes={r[0]:r[1] for r in rows('source/drat/hashes.tsv')}
previous={x['id'] for x in json.loads((HERE/'certificates.json').read_text())['certificates']};assert len(previous)==29
cert_path=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'packing_certificates.json'
cert=json.loads(cert_path.read_text());assert cert['schema']=='p104-cover-packing-v1'
cov=set(b.cls[b.n_cov0:b.n_tot0]);ids=set();records=[]
def check_clause(t,c):
 assert isinstance(t,int) and 0<=t<104 and isinstance(c,int) and c in C[t]
 assert tuple(b.m[j,t] for j in range(16) if c>>j&1) in cov
for case in cert['certificates']:
 cid=case['id'];I=case['inactive_mask'];assert cid not in ids and cid in residual and cid not in old and cid not in previous and cid!='f3591';ids.add(cid);assert residual[cid]==I
 row=cubes[cid];assert row[2]=='-' and sum(1<<int(z) for z in row[1].split(','))==I
 units=[c[0] for c in gen.cube_extra(b,cid) if len(c)==1]
 assert len(units)==16 and set(units)=={b.used[z,8] if I>>z&1 else -b.used[z,8] for z in range(16)}
 assert hashlib.sha256(gen.cube_text(cid,b=b).encode()).hexdigest()==hashes[cid]
 active={z for z in range(16) if not(I>>z&1)};forced=case['forced_rows'];F={r['z'] for r in forced};U=case['other_rows'];assert len(F)==len(forced) and len(set(U))==len(U) and F.isdisjoint(U) and F|set(U)==active
 fm=sum(1<<z for z in F);base=0
 for r in forced:
  z=r['z'];span={0,n[z]};seen=set()
  for t,c in r['ports']:
   assert t not in seen;seen.add(t);check_clause(t,c);assert c&~I==1<<z
   assert h[t] not in span;span|={x^h[t] for x in span}
  base+=len(r['ports'])
 ports=case['ports'];ts=[r['t'] for r in ports];assert len(ts)==len(set(ts))
 for z in U:
  span={0,n[z]}
  for t in ts:
   assert isinstance(t,int) and 0<=t<104 and h[t] not in span,(cid,z,t)
   span|={x^h[t] for x in span}
  assert len(span)<=512
 need=0
 for r in ports:
  t,k=r['t'],r['minimum'];assert isinstance(k,int) and 0<k<=len(U)
  required={sum(1<<z for z in comb) for sz in range(k) for comb in itertools.combinations(U,sz)}
  supplied={}
  for subset,c in r['subsets']:
   assert subset not in supplied and subset in required;check_clause(t,c);assert not(c&(fm|subset))
   supplied[subset]=c
  assert set(supplied)==required
  need+=k
 assert base+need>55,(cid,base,need)
 records.append((cid,I,base,need,base+need))
assert len(records)==23
for cid,I,base,need,total in records:print(cid,'inactive='+str(I),'singleton_rows='+str(base),'packed_ports='+str(need),'lower_bound='+str(total))
print('PASS',len(records),'distinct additional residual cubes; all generated hashes match pinned source rows')
print('PASS explicit F2 spans and every subthreshold support subset witness')
print('PASS all totals exceed price 55')
