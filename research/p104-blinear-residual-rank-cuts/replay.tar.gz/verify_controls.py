#!/usr/bin/env python3
"""Confirm that certificate corruptions fail the independent verifiers."""
from pathlib import Path
import copy,json,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
base=json.loads((HERE/'certificates.json').read_text())
pack=json.loads((HERE/'packing_certificates.json').read_text())
controls=[]
for name in ('bad_clause','dependent_label','omit_label'):
 x=copy.deepcopy(base);row=x['certificates'][0]['rows'][0]
 if name=='bad_clause':row['ports'][0][1]=0
 elif name=='dependent_label':row['ports'][1]=row['ports'][0][:]
 else:row['ports'].pop()
 controls.append((name,'verify_certificates.py',x))
for name in ('packing_bad_clause','packing_missing_subset','packing_duplicate_port','packing_omit_rank'):
 x=copy.deepcopy(pack);case=x['certificates'][0]
 if name=='packing_bad_clause':case['ports'][0]['subsets'][0][1]=0
 elif name=='packing_missing_subset':case['ports'][0]['subsets'].pop()
 elif name=='packing_duplicate_port':case['ports'][1]['t']=case['ports'][0]['t']
 else:case['forced_rows'][0]['ports']=case['forced_rows'][0]['ports'][:-6]
 controls.append((name,'verify_packing_certificates.py',x))
with tempfile.TemporaryDirectory(prefix='p104-certificate-controls-') as td:
 for name,checker,obj in controls:
  p=Path(td)/(name+'.json');p.write_text(json.dumps(obj))
  r=subprocess.run([sys.executable,'-B',str(HERE/checker),str(p)],capture_output=True,text=True)
  assert r.returncode!=0 and 'AssertionError' in r.stderr,(name,r.returncode,r.stderr)
  print('PASS rejected',name,flush=True)
