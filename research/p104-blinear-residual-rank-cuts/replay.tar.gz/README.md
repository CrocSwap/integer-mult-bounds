# P104 B-linear: 52 more checked cube contradictions

These local, solver-free certificates exclude **52 further cube IDs** from the 389 residual IDs in [PR #7862](https://github.com/CrocSwap/integer-mult-bounds/pull/7862), at its exact head `550a08ab9bf3ee6bb1b310abbfb2874700e7c441`. That audit's pinned input is [PR #7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) at `41beda1d6435760dc99e38bd7e65f36798aad212`. The new 29 singleton/rank and 23 packing certificates are pairwise disjoint and exclude no ID already counted by the 612 original direct inactive-cover contradictions. The combined count is **664 of 1,001 cube IDs**, with **337 remaining outside these tests**. Previously replayed `f3591` is in the 612, not the new 52. The count is cube IDs, not unique model assignments.

The result concerns the precise abstract tight B-linear cover and price-55 CNF described in `audit/REVIEW.md`, not arbitrary decoder classes. It does not establish full price-55 unsatisfiability, a general decoder wall, a legal-word result, a hosted-rise bound, or a kappa improvement. No SAT solver or historical proof file is used for the 52 additional contradictions.

## Reproduce

From this directory, with Python 3 and a standard shell:

```sh
sha256sum -c SHA256SUMS
python3 -B verify_all.py
```

The check rebuilds and hashes each of the 52 full CNFs in memory against the pinned `hashes.tsv` row; it does not retain the large CNFs. To recreate an individual full DIMACS file, run `python3 -B audit/source/drat/gen.py cube i191 /tmp/i191.cnf`, and compare its SHA-256 with the `i191` row of `audit/source/drat/hashes.tsv`. The generator and source data are included with their license. The independently reconstructed row, membership, cover, and totalizer blocks and the original 612/389 partition are replayed first.

`verify_certificates.py` checks the 29 singleton/rank cases; `verify_packing_certificates.py` checks the 23 disjoint packing cases. Both independently check actual cube units, every required covering clause, explicit F2 span independence, source pins, and the regenerated CNF hashes. The packing checker also checks every subthreshold support subset against an explicit clause witness. `verify_controls.py` checks that seven deliberately corrupted certificates are rejected. The checks use explicit span enumeration rather than the discovery program's Gaussian elimination. This is finite executable evidence, not a proof-assistant formalization.

`audit/REVIEW.md` and `audit/residual-cubes.tsv` match the #7862 pinned-head Git blobs `3ae3b1bd413bca09c643c3c95e4a5177550467d8` and `acae73759d3b2ed8db177c3d8759cea4803843e0`. Their SHA-256 values `52cd99a9daf95b1a6f07ae0dd52191e78557f3bd99a1fabb4bfcb7cb95addc6c` and `5326f358c5aee7c8849b7cdf7241580721c6f0cfa4d24c0f914357d8f03af2ae` agree with that head's `SOURCES.json`. The original compact archive had SHA-256 `5f26a5032de29a21b9c7767fc0f1ae905fd98590cc65a66f4b4d62f875bb6bd8`; this package retains only the audit inputs needed here, not that whole archive. The exact original generator, cube inventory, historical hash rows, geometry, permutations, and cover clauses are pinned in both checkers.

## Why the certificates contradict price 55

For a cube's inactive set I, the actual generated units and audited row block give U_z=0 for z in I. For any port t, if a nonempty positive cover clause has exactly one row z outside I, all inactive entries are false and m[z,t] must be true. The membership block then implies h_t lies in U_z.

For normal n_z, a row's abstract price satisfies the exact identity

```text
price_z = dim(U_z) - 1[n_z in U_z] = dim(U_z + span(n_z)) - 1.
```

A certificate's r independent forced h labels together with n_z therefore give price_z >= r. The first certificate family supplies 56 such labels in total, distributed over rows. Each full-vector independence check includes the normal: the dimension and discount are tied jointly. The CNF's one-sided normal flag can only increase encoded cost over this mathematical price, and its audited totalizer forces encoded total at most 55.

The second family splits all active rows into two groups F and R. Singleton clauses and independent forced labels already lower-bound prices on F. It then grants every row of F free access to every port, a relaxation. For each of at most eight selected ports t, a short list of actual cover clauses proves that at least k_t rows of R must cover t: for every subset S of R with fewer than k_t members, the supplied clause is disjoint from F and S. These clauses cannot be satisfied if the true R members are contained in S. For every row z of R the selected labels are checked independent together with n_z, so the row's price is at least its number of selected memberships. Summing gives a further price of at least sum(k_t), disjoint from the F-row bound. Every listed total is between 56 and 61, contradicting the budget. The second family makes no assumption that the granted F memberships are real.

All certificate IDs are explicitly checked against the pinned residual list and old witness list, and the two new lists are checked disjoint. These particular cubes have no split literals; no lex or normalization argument is needed beyond the already fixed inactive-row unit and the audited CNF price projection. Historical author-reported UNSAT verdicts for the other cubes are not independently replayed by this work.
