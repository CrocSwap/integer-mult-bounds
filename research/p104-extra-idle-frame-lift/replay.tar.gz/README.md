# Exact e=1 frame: signed-idle and contact-prefix obstructions

The exact three-host, four-thin rank-three frame in #7861's
`check_transition.py` **cannot be lifted to the retained signed caller
record grammar with those same four thin transfers**. Its one reflection
would have to be an `IDLE_ODD` with a nonempty stage set, but the
reflection image fails the host-contact kernel condition for every one of
the three possible stages. This conclusion permits arbitrary target
masks, arbitrary permitted q-even events and arbitrary intervening
`LAMBDA` normalizers. It does **not** exclude another choice of thin
factors, another signed frame, or a grammar that permits an empty-stage
odd idle. It does not establish a legal word, a caller price, or a κ gain.

The argument below is paper mathematics with exact rational Python
checks. It applies the #7852 `CallerWordK.jB_xker` statement to this new
finite instance; **the application in this note has not been formalized
or kernel-checked in Lean**. The physical signed-idle condition comes
from the retained #7113 application and precision checks; it is stronger
than the #7852 abstract `CallerWord` datatype, which allows empty idle
sets. The earlier #7861 signed-frame-only sharpness claim remains true at
its stated frame level.

## Sources and pinned scope

* #7861, head `5cbe00f354aae5923205ec68370ddaa5296c2ea7`, staged tree
  `566e00bba0acfebf2a7bdcd9908fbed06360c193`: the campaign supplied its
  same-tree local staging; `source/check_transition.py` and
  `source/TWO-HUB-BOUNDARY.md` are byte-checked copies. We independently
  checked their SHA-256 against that local staging. The commit/tree
  equivalence was supplied by the campaign lead, not independently
  re-fetched here.
* #7852 head `41beda1d6435760dc99e38bd7e65f36798aad212`: the four
  `CallerWord*.lean` copies have Git blob IDs matching that tree. In
  particular `CallerWordK.jB_xker` states that each other incidence of a
  host stage has its incidence image annihilated by the host's B columns.
  The #7852 source and predecessor attributions remain in
  `NOTICE-P104.md`.
* #7113 retained source tree at commit `07a76c5e2738882c0cb322278e56f6cae3c9885d`:
  `check_odd_physical_binding.py` and `check_odd_precision.py` impose
  the signed child signature: one whole stage and exponent −1. The
  corresponding ordinary application requires a nonempty distinct whole
  stage set. `caller16.py` is an additional retained independent
  implementation of the same rule. These are the *retained* verifiers;
  no claim is made about every possible extension of the opcode grammar.

`check.py` verifies all vendored source SHA-256 values, the source rule
text, every host prefix, all matrix identities below, and the bounded
controls. It also imports the pinned `three_stage_witness` function and
compares its recovered host columns and thin matrices with the separate
transcription. It requires SymPy; the Lean and grammar source copies are
evidence and are not executed. Host positions 1–3 below are ordered
positions among the q-odd HOST slots; arbitrary q-even events may appear
between them.

## Fixed-gauge recovery

Use zero-based role indices. The original has n=7, k=3, four thin slots,
and ten odd columns, so e=10−7−2=1. Its three host column pairs
`(A_t,B_t)` have `B_tᵀ A_t = [[-1,-1],[1,-1]]`. Let

```
h(q) = [[1, -q], [q^(-1)/2, 1/2]],
h(1) = [[1, -1], [1/2, 1/2]],
h(-1) = [[1, 1], [-1/2, 1/2]].
```

For each host, the replay prints an invertible rational prefix `Q_t` and
verifies, using physical HOST fields 0 and 1, that

```
A_t[:,0] =  2 Q_t^(-1) h(1)^(-1) e_0
A_t[:,1] =   -Q_t^(-1) h(1)^(-1) e_1
B_t[:,0] =     Q_tᵀ e_1
B_t[:,1] =     Q_tᵀ e_0
Q_t^(-1) h(1)^(-1) h(-1) Q_t = I + A_t B_tᵀ.
```

The 2×2 `h` is embedded in the first two fields. At q=1 these are valid
individual prefix choices, achievable by rational elementary row
operations; this calculation is **not** a full word or an independent-D
identity. The specified chronological thin factors are `H,T3,T2,T1`,
where `H²=I`, `rank(H−I)=1`, and each `Tj−I` is rank-one nilpotent;
`T1 T2 T3 H` times the three host transfers equals `−I` exactly.

## No nonempty signed-idle stage

Let an `IDLE_ODD` be a distinct event with nonempty stage set S. Put all
body variables equal to 1 and use the q=1 prefix P immediately before
that event. Define `v=P⁻¹ e_r` and `wᵀ=e_rᵀ P`; then `wᵀv=1` and its
q=−1 relative transfer is `I−2vwᵀ`. Thus any idle realizing the exact
reflection H has `v` in the one-dimensional image of `(I−H)/2`.

For any `t ∈ S`, that idle is an incidence distinct from the two
immediate D_t contacts of the t-th type-B HOST. A legal independent-body
identity forces

```
B_tᵀ v = 0.                                    (★)
```

This is the exact condition in the pinned `CallerWordK.jB_xker`. For an
independent explanation, differentiate the endpoint in D_t at D=1 and
q=1. Its derivative is the target-mask projector `Π_t=VWᵀ`, where the
columns of V and W are the conjugated incidence images and covectors.
Each `w_jᵀv_j=1`; taking traces shows the number of incidences equals
`rank Π_t`. Hence V and W have full column rank and the idempotence of Π_t
implies `WᵀV=I`. The two host-contact covectors span the host B columns,
so (★) follows for every other stage-t incidence. This derivation relies
on an independently variable D_t, not on setting all D variables equal.

For this exact H, a representative image vector and its host Gram
columns are

```
v = (-6, 2, -3, 1, 1, -3, -1)ᵀ
B_1ᵀv = (-8, -8)ᵀ
B_2ᵀv = (-8,  4)ᵀ
B_3ᵀv = ( 4,  4)ᵀ.
```

All three violate (★). An odd QUERY has a unipotent relative transfer,
so it cannot realize this determinant-−1 reflection. The ordinary
q-even operations and `LAMBDA` give no odd q=±1 transfer, while the
three other fixed thin factors are unipotent. Consequently the actual
nonempty signed-idle requirement cannot be satisfied by this precise
frame and factorization. This obstruction does not depend on the target
mask choices or on the order of host and reflection events, provided the
individual frame factors are retained.

A control uses the different common-kernel vector
`(-2,2,-3,-1,-1,-3,1)ᵀ` to construct a genuine reflection that passes all
three kernel tests. Replacing H by it, however, breaks the specified
`−I` product; it is not a repair of the frame.

## Additional q=−1 prefix and incidence test

The original host-column support masks by role are two universal hubs
and five local roles, or equivalently stage target masks

```
S1={0,1,2,3}, S2={0,1,4}, S3={0,1,5,6}.
```

Keeping the given order (all hosts before all four thins), any legal
word with those precise target masks also fails before the second HOST
is completed. Let `Z` be the first q=−1 host transfer. The q=−1 versions
of the D_2 incidence-image and covector support conditions require the
second host's contact images and covectors to be supported on `S2`. The
first two physical contact images reconstructed from the fixed frame are

```
(3/2, 5/2, -1/2,  1/2,  0, 0, 0)ᵀ
( -1,  -1,   -1,   -1, -1, 0, 0)ᵀ.
```

Roles 2 and 3 are outside S2, giving explicit forbidden prefix entries.
The result is independent of the unused prefix rows; each contact-image
span is `Z⁻¹ im(A_2)`. The dual contact covector span is `im(B_2ᵀ Z)`.
The same differentiation and idempotent factorization used above holds
at q=−1: the endpoint is `−I` at D=1 and all prefix matrices are
invertible. At q=1 and q=−1 together, the three target masks would have
to contain, respectively,

```
{0,1,2,3}, {0,1,2,3,4}, {0,1,2,3,4,5,6}.
```

This forces at least five more **stage incidences** than the local-mask
pattern, under this prescribed host/thin order. It is not a price: one
idle can bundle multiple stages, and no complete word and invoice are
available. Enlarging the target masks removes this particular local-mask
contradiction, but cannot remove the signed-idle kernel contradiction.

## q⁴ screen, bounds and replay

The proof above already refutes the retained grammar through q=±1 and
independent body variables. As a separate bounded diagnostic, the replay
also lifts the fixed host transfer with

```
I + A_t diag((1−q)/2, (1−q⁻¹)/2) B_tᵀ,
```

lifts the three T factors as QUERYs with each of their eight possible
±1 orientations, and lifts H as the prescribed `IDLE_ODD(-1)`. It sets
all bodies to 1 and specializes q=i with i²=−1, a valid specialization of
the formal ring with q⁴=1. With **no `LAMBDA` q² corrections**, all eight
orientations fail the target `q⁻¹I`: for the all-−1 choice the (0,0)
coefficient error is `−5/2−(5/2)i`. The replay prints all eight exact
errors and verifies the q=i HOST formula against the physical gauge.
This is only a screen of the literal factorization without LAMBDA; a
q²-sensitive normalizer can change that result. It is not a universal
q⁴ no-go. The preceding nonempty-idle kernel contradiction is the stronger
conclusion and does allow arbitrary LAMBDA events.

Reproduce from this directory with Python 3 and SymPy 1.12:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B check.py
```

The bundled `replay.log` records a successful one-core run. No Lean
build, precision envelope, physical placement, true invoice, independent
replay by a second implementation, or upstream publication is claimed.
