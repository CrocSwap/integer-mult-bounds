#!/usr/bin/env python3
"""Rational prefix obstruction for the pinned e=1, k=3 witness.

One-core exact SymPy arithmetic. No Lean proof or actual legal caller claimed.
"""
from pathlib import Path
import hashlib
import itertools
import importlib.util
import contextlib
import io
import sympy as s

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'source'
HASHES={
    'check_transition.py':'3fc36afd570e8dec34d2a5c1165c29869f73b29e457e59f2ff728d9e863ad0c7',
    'TWO-HUB-BOUNDARY.md':'dfad3b7cd1f6c55a873ca1b5d9bf79b8a30c0b40f9b3331b57d5075a6efaf3dc',
    'CallerWord.lean':'02b34949c241701ed732a2e1b6ef3957f2b23518e07ba289fe7c7b84b8afdbc7',
    'CallerWordD.lean':'fdcebd863b7639811782c51255232c0c88288eaacd0ff0e2618ad01799e3f3d8',
    'CallerWordS.lean':'70864b67b0a446e544913e95514311fea88fd57464e3fae227220ac468129f9e',
    'CallerWordK.lean':'3d81d10494cca71531add750f26fbf317dec4e5ceff03c6ba7282b6a2a1256a6',
    'check_odd_physical_binding.py':'5c80c3b0415a7f91d216395248dd6f13297eed637732098e1ca8fb0548951b98',
    'check_odd_precision.py':'b2d9c13577158157a587ace766d9dadb7819a0164b372722329d9754e1be6c61',
    'upstream_application.py':'d98987db98553dc55bfc80e3ca47abfcd51c57af6f8cda61101391d8eae94184',
    'caller16.py':'ced48867f07ca0143604aa98cfd74fa7453696b9d3221f7c230d73e9ab9ba81f',
}
for name,expected in HASHES.items():
    actual=hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()
    assert actual==expected,(name,actual,expected)
assert 'theorem jB_xker' in (SOURCE/'CallerWordK.lean').read_text()
assert "len(selected)==1 and a[1:]==[-1]" in (SOURCE/'check_odd_physical_binding.py').read_text()
assert 'len(e[3]) == 1 and e[4] == -1' in (SOURCE/'check_odd_precision.py').read_text()
print('pinned input hashes and source rule text: PASS')

# Verbatim matrix construction in three_stage_witness() in the pinned script.
D = [s.Matrix([[-1,0],[-2,1]]), s.diag(1,-1), s.Matrix([[-1,2],[0,1]])]
J = s.Matrix([[1,-1],[1,1]])
V = [d.inv()*J for d in D]
Ah=s.zeros(7,6); Bh=s.zeros(7,6); row=2
for t in range(3):
    sl=slice(2*t,2*t+2)
    Ah[0:2,sl]=V[t]; Bh[0:2,sl]=s.eye(2)
    residual=J-2*s.eye(2)-V[t]
    C,E=residual.rank_decomposition(); r=residual.rank()
    Ah[row:row+r,sl]=E; Bh[row:row+r,sl]=C.T
    row+=r
assert row==7
I=s.eye(7)
hosts=[I+Ah[:,2*t:2*t+2]*Bh[:,2*t:2*t+2].T for t in range(3)]
assert all(Bh[:,2*t:2*t+2].T*Ah[:,2*t:2*t+2] == J-2*s.eye(2) for t in range(3))
mask=[{r for r in range(7) if any(Ah[r,2*t+j] != 0 or Bh[r,2*t+j] != 0 for j in range(2))} for t in range(3)]
assert mask==[{0,1,2,3},{0,1,4},{0,1,5,6}]
print('zero-based masks:', [sorted(x) for x in mask])
for t in range(3):
    print(f'host {t+1} A=',Ah[:,2*t:2*t+2].tolist())
    print(f'host {t+1} B=',Bh[:,2*t:2*t+2].tolist())

# HOST(a=-1,b=1/2) prescribed fields s=0,t=1, including gauge.
H1=s.eye(7); Hm=s.eye(7)
H1[0:2,0:2]=s.Matrix([[1,-1],[s.Rational(1,2),s.Rational(1,2)]])
Hm[0:2,0:2]=s.Matrix([[1,1],[-s.Rational(1,2),s.Rational(1,2)]])
e=[I[:,r] for r in range(7)]
pre=[]
for t in range(3):
    A=Ah[:,2*t:2*t+2]; B=Bh[:,2*t:2*t+2]
    # The two physical field rows and a basis of the left kernel of A.
    rest=A.T.nullspace()
    Q=s.Matrix.vstack(B[:,1].T, B[:,0].T, *(v.T for v in rest))
    assert Q.det() != 0
    assert Q.inv()*H1.inv()*e[0]*2==A[:,0]
    assert Q.inv()*H1.inv()*e[1]*(-1)==A[:,1]
    assert Q.T*e[1]==B[:,0] and Q.T*e[0]==B[:,1]
    assert Q.inv()*H1.inv()*Hm*Q==hosts[t]
    pre.append(Q)
    print(f'host {t+1} base prefix Q{t+1}='); print(Q)
print('all three individual fixed-gauge HOST prefixes: PASS')

# All ordinary q-even operations have equal q=+/-1 values. Assume no
# intervening q-odd slots: at host 2, P_-(pre) = Q2 * hosts[0].
Z=hosts[0]; Q=pre[1]
Pm_post=Hm*Q*Z
v0=Pm_post.inv()*e[0]; v1=Pm_post.inv()*e[1]
w0=(e[0].T*Pm_post); w1=(e[1].T*Pm_post)
print('at host 2 q=-1 contact images v_s, v_t:'); print(v0.T); print(v1.T)
print('outside-mask image coordinates:', [[(r,v[r]) for r in range(7) if r not in mask[1] and v[r]!=0] for v in (v0,v1)])
print('at host 2 q=-1 contact covectors w_s, w_t:'); print(w0); print(w1)
print('outside-mask covector coordinates:', [[(r,w[r]) for r in range(7) if r not in mask[1] and w[r]!=0] for w in (w0,w1)])
assert any(v[r]!=0 for v in (v0,v1) for r in range(7) if r not in mask[1])
print('host 2 violates independent-D contact support at q=-1: PASS (obstruction)')

# Three transvections + reflection as in the source. Verify the given frame.
Pbase=hosts[2]*hosts[1]*hosts[0]
assert Pbase.det()==1 and (Pbase+I).rank()==4
target=-Pbase.inv()
u=[s.Matrix([3,7,-2,1,1,0,-1]), s.Matrix([-4,-10,3,-1,-1,1,1]), s.Matrix([-s.Rational(2,5),2,-s.Rational(6,5),s.Rational(2,5),s.Rational(2,5),-s.Rational(2,5),-s.Rational(2,5)])]
f=[s.Matrix([1,3,8,-8,0,0,0]), s.Matrix([0,1,s.Rational(12,5),-2,-s.Rational(2,5),s.Rational(2,5),0]), s.Matrix([0,0,1,5,-6,1,-5])]
T=[I+u[j]*f[j].T for j in range(3)]
H=T[2].inv()*T[1].inv()*T[0].inv()*target
assert all((t-I).rank()==1 and (t-I)**2==s.zeros(7) for t in T)
assert (H-I).rank()==1 and H*H==I and H.det()==-1
assert T[0]*T[1]*T[2]*H*Pbase==-I
# Independently bind the above reconstructed matrices to the actual vendored
# #7861 witness function, including the four thin transfer matrices.
spec=importlib.util.spec_from_file_location('pinned_transition',SOURCE/'check_transition.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
original_report=mod.report
captured={}
def capture(label,a,b,blocks,k):
    captured.update(A=a.copy(),B=b.copy(),blocks=blocks,k=k)
    return original_report(label,a,b,blocks,k)
mod.report=capture
with contextlib.redirect_stdout(io.StringIO()):
    mod.three_stage_witness()
assert captured['A'][:,:6]==Ah and captured['B'][:,:6]==Bh
for j,transfer in enumerate([H,T[2],T[1],T[0]]):
    assert I+captured['A'][:,6+j]*captured['B'][:,6+j].T==transfer
print('pinned witness function matches all hosts and exact thin transfers: PASS')
print('original chronological thin transfers H,T3,T2,T1: PASS')
print('three unipotent rank-one factors and one reflection: PASS')

# CallerWordK.jB_xker obstruction: the real IDLE_ODD must contain at least
# one stage; an extra incidence at that stage has host B-orthogonal image.
# The direction is invariant under the scalar choice of rank-one factorization.
E=(I-H)/2
assert E*E==E and E.rank()==1
v=E[:,3]  # any nonzero column spans the reflection direction
assert v==s.Matrix([-6,2,-3,1,1,-3,-1])
print('reflection projector image v=',list(v))
for t in range(3):
    gram=Bh[:,2*t:2*t+2].T*v
    print('host',t+1,'B^T v=',list(gram))
    assert gram != s.zeros(2,1)
print('all three possible nonempty IDLE_ODD stages violate jB_xker: PASS')

# Discrimination control: a different reflection direction DOES satisfy
# these three kernel tests, but no longer completes the pinned frame.
common=Bh.T.nullspace()
assert len(common)==1
alternative=common[0]
assert alternative==s.Matrix([-2,2,-3,-1,-1,-3,1])
w=-e[0]/2
alt_h=I-2*alternative*w.T
assert w.dot(alternative)==1 and alt_h*alt_h==I and (alt_h-I).rank()==1
assert Bh.T*alternative==s.zeros(6,1)
assert T[0]*T[1]*T[2]*alt_h*Pbase != -I
print('control: different reflection passes kernel test but fails original -I closure')
print('no legal full word/invoice established')

# Natural q^4 lift with no q-even LAMBDA corrections, D=1.
# Evaluate exactly at the valid specialization q=i; represent complex matrices
# as pairs of rational real and imaginary matrices for speed.
def mm(x,y):
    ar,ai=x; br,bi=y
    return ar*br-ai*bi, ar*bi+ai*br
zero=s.zeros(7)
hostq=[]
for t in range(3):
    A=Ah[:,2*t:2*t+2]; B=Bh[:,2*t:2*t+2]
    hostq.append((I+A*s.diag(s.Rational(1,2),s.Rational(1,2))*B.T,
                  A*s.diag(-s.Rational(1,2),s.Rational(1,2))*B.T))
# Cross-check HOST's q=i transfer from the physical 2x2 matrix and its
# rational prefix against the A/B formula, including q^3=q^-1.
host_i=s.eye(7)
host_i[0:2,0:2]=s.Matrix([[1,-s.I],[-s.I/2,s.Rational(1,2)]])
for t in range(3):
    direct=pre[t].inv()*H1.inv()*host_i*pre[t]
    real,imag=hostq[t]
    assert all(s.expand(direct[r,c]-real[r,c]-s.I*imag[r,c])==0
               for r in range(7) for c in range(7))
print('HOST q=i specialization agrees with the fixed-gauge A/B formula: PASS')
qhost=mm(hostq[2],mm(hostq[1],hostq[0]))
E=(I-H)/2
reflection=(I-E,-E) # q^-1=-i, IDLE_ODD exponent -1
for signs in itertools.product([-1,1],repeat=3):
    tqs=[]
    for j,sig in enumerate(signs):
        N=T[j]-I
        tqs.append((I+N/2,-sig*N/2))
    product=mm(tqs[0],mm(tqs[1],mm(tqs[2],mm(reflection,qhost))))
    real,imag=product
    # target q^-1 I = -i I
    first=next(((r,c,real[r,c],imag[r,c]+int(r==c))
                for r in range(7) for c in range(7)
                if real[r,c] != 0 or imag[r,c]+int(r==c) != 0),None)
    print('q=i, D=1, QUERY orientations',signs,'first mismatch (row,col,real,imag)',first)
    assert first is not None
print('literal q^4 lift without LAMBDA: all 8 QUERY orientation choices fail at q=i')
print('q^2-sensitive LAMBDA corrections could change this screen; not excluded by it')

# Necessary target masks from contact support at both q=1 and q=-1.
# A later contact's q=-1 span/cospan is Z^-1 A and B^T Z,
# where Z is the product of all preceding q-odd frame transfers.
Z=I
required=[]
for t in range(3):
    A=Ah[:,2*t:2*t+2]; B=Bh[:,2*t:2*t+2]
    image=Z.inv()*A
    cov=B.T*Z
    need=set(mask[t]) | {r for r in range(7) if any(image[r,j]!=0 or cov[j,r]!=0 for j in range(2))}
    required.append(need)
    print('stage',t+1,'forced target mask from +/-1 contact support:',sorted(need))
    Z=hosts[t]*Z
assert required==[{0,1,2,3},{0,1,2,3,4},set(range(7))]
assert sum(map(len,required)) - sum(map(len,mask)) == 5
print('at least five additional stage incidences needed in this fixed frame')
