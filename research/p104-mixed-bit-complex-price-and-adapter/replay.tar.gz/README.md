# Mixed supplier and two-port contact screen at 0.00388

**No new κ or legal mixed supplier is established.** One complete binary and
one complete rational invoice have a positive normalized product moment at
the trial. A hypothetical common-type product with exactly those two invoices
also meets the explicit 80-pair finite strictification test below. The
existing outer application, however, consumes a completed ordinary BIT
service and the raw binary and complex jobs have different physical shapes.
A promising rank-one conversion is real; the same scalar conversion fails
for an actual rank-two complex tensor job. The missing common family and
the outer recurrence remain construction obligations.

## Source identities

* Complete 36-call BIT and 48-call rational source: #7830 head
  `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; native #7786 head
  `89a67c404226d51028e135de2b9169e9020d57af`. This package uses the
  independently recounted, fixed `BASELINE.json`, SHA-256
  `a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a`.
  The actual native word has literal gzip SHA-256
  `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`
  and canonical SHA-256
  `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
* #7863 head `b3e4412fe01f07dc58305616fabf96345f49a781`, independently
  replayed in #7973 head `ac3df5d5c8889f464f575e32dfea43714abf08ca`,
  supplies the retained conditional 451-factor consumer. Main framework
  pin `e54523517d0f03e58352e647c403a5af3e525a57` is the ambient-cap and
  physical-interface source. The five source premises remain
  `native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`,
  and `analytic_recovery`.
* #7868 `3f7c3c1f2a9a0963736562037e01fe41aec46b8c` documents the
  positive complex coordinate, binary interchanges and periodic compiler;
  its `check_periodic.py` explicitly represents complex fields as arrays of
  `2^n` amplitudes and the BIT example as separate `n`-element head/tail
  arrays. The example is a physical-shape control, not a complete mixed
  source-word replay.
* #7990 `db6ea61ffb10e28d911c36fcad84cf4a2bac5a98` contains the frozen
  38-role changed-contact caller and its two-port companion. The true
  intermediate physical route is not reconstructed here.

The older 451-factor consumer requires its tested saving to be below its
completed ordinary BIT cap. The source price routine takes a minimum of the
complex crossing and BIT cap; the gate asserts `tested < cap`. Its static
rational surplus cannot alone replace that standalone BIT service. A new
common typed supplier might lead to a different construction, but must prove
its own ordinary BIT interface or establish a different valid outer
recurrence.

## A physically conditional sufficient price

Let `t=1−0.00388`, `T_B,P_B` and `T_R,P_R` denote the sums of rank^t
for every distinct target and every paid occurrence in the complete 36- and
48-call words. The independent directed interval engines agree on

```
T_B = 289333.126731556588044801494278779035...
P_B = 289333.154442916778262391895271169476...
T_R = 737860.539577059582194113875692237127...
P_R = 737860.400602537247941404898104863610...
```

Thus the necessary raw condition for a *physically valid, exact*
one-B-by-one-R chronological product is

```
(P_B/T_B)(P_R/T_R) = 0.999999907428687727369578985132... < 1.
```

If, and only if, that construction has exactly the product histogram, its
unnormalized surplus is about `19762.8177517987265` in product-moment
units. A 2B:1R product instead has normalized ratio
`1.000000003205337770802813148875... > 1`. These are multiplicative
conditions, not a claim that the two original signed margins can simply be
added.

The following is a sufficient **finite signed condition**, not an admitted
construction. Assume a legal common-type unit exists with the stated exact
product labels and no additional paid or target losses. For 80 chronological
copies, split paid ranks at `150^80`, retain only complete targets of rank
at least `200^80`, and keep ambient `(134·153)^80`. The floor occurs, for
example, from the actual rank-8 binary and rank-25 rational target labels.
With `u=w=1/5`,

```
alpha  = P(t)/T(t)                         < 1 − 9/100000000
gamma  = P(t+u)/(150^u T(t))               < 827/1000
lambda = 200^w T(t−w)/T(t)                 < 855/1000
alpha^80 + 2 gamma^80 + lambda^80
  < 1/(1+80·9/100000000) + 2(827/1000)^80 + (855/1000)^80
  < 0.999996911127415793280896565190.
```

The split bound uses `u ≥ 0.00388`, complete disjoint slabs, charged
wrappers and all spectators. The dropped-target bound uses fresh owned zero
specializations, with their actual interior work retained. This calculation
does not construct the mixed job, price its adaptations, supply prime/cover
parameters, prove its ordinary bootstrap, or establish the outer conditions.

## Actual conversion candidate and rank-two obstruction

For one complex coordinate put `C=((1+i)I+(1−i)X)/2` and `D=X`. The
identities `D=(1+i)C−iI` and `C=((1+i)I+(1−i)D)/2` are exact.
Assuming the same complete chart, weights and arbitrary Gaussian payload,
one possible `C -> D` body is:

```
live x; owned y=0
y <- x;  C(y);  y <- (1+i)y - i x
SWAP(live,owned);  CLEAR(owned)
```

The output is `D x`; the displaced old input is the dirty owned value.
The retained #7776 `BIT-PROOF.md` explicitly uses output accumulators,
whole-field swaps, and clearing the displaced old input under the inherited
owned-erasure assumption, so treating this step as categorically forbidden
would be wrong. It still needs a source-bound adapter proving the old input
and returned output are simultaneously accessible in the *same* active
chart, with current weights, full spectators, legal owner transfer and
actual stock/clear/scalar charges. In the opposite direction the half
factor requires a candidate-specific exact grid and precision proof.
Operating BIT logic over the Gaussian representations must also be bound to
the actual word; a matching grade does not supply that binding.

The source complex rank-r job applies a positive operator on each of r
coordinate axes. Its Walsh phases are `i^popcount`. At rank 2 those phases
are `(1,i,i,−1)`. Even in an optimistic common tensor space where the
desired binary map is `C²`, its phases are `(1,−1,−1,1)`. The rank-one
coefficients force `(1+i)C−iI`, which gives `−1−2i` on the last basis
vector instead of `+1`. Conversely, a scalar combination of an involution
cannot distinguish the two `C²=+1` eigenspaces, where `C` is `1` and
`−1`. Therefore the one-call conversion with only same-chart scalar role
operations, copies and dirty clears is impossible for this named rank-two
tensor interface. The actual frozen invoices contain 37,920 rank-two
rational paid positions and 46,116 rank-two BIT paid positions.

The same failure survives arbitrary address-dependent **diagonal**
weights in a one-call retained-input adapter. On the four amplitude
coordinates `C₂` has no zero entries, while `D₂=C₂²` flips both index
bits and has exactly one off-diagonal nonzero in each row. Suppose
`D₂=A C₂ B+E` for arbitrary diagonal `A,B,E`, including zero entries.
Each desired off-diagonal entry forces its row entry of `A` and its
column entry of `B` to be nonzero. Since the flip is a permutation,
every diagonal entry of `A` and `B` must be nonzero. The product is then
dense, and diagonal `E` cannot remove the unwanted off-diagonals. The
executable checks all 256 pairs of possible support masks. The analogous
rank-one support test passes and the exact identity above supplies it.
This still assumes a single whole complex call, diagonal ingress/egress
and one same-index retained input; multiple retained permutations or
non-diagonal chart operations need their own analysis and tariff.

More generally, address-dependent phase operations, additional nontrivial
chart maps, partial input selection, multi-call words and changed interfaces
are outside this no-go. Two calls yield `C²` in the abstract tensor space,
but that alone is not a full BIT chart binding. For example, in one
eight-dimensional padded model at rank 3, `C_3²` has four negative Walsh
eigenvalues whereas three disjoint projector swaps plus two spectators have
three, precluding similarity in that model. Different encodings and
multiplicities remain open.

As a price-only upper bound, replace every rational grade-r paid occurrence
by r grade-one calls, while optimistically retaining all targets and
charging no adapter work. Its paid moment becomes the integer `743040`,
its surplus becomes `−5179.4604229404178...`, and the 1B:1R normalized
ratio becomes `1.0070196619971003...`. This rejects that wholesale split,
not selective splitting or a cheaper genuine joint primitive. Likewise,
doubling every rational whole call gives a normalized paired ratio of
`1.9999998148573754...` before other charges.

## Port-specific period-two control

The actual frozen native specifies

```
port 0: head <e0>; body <e1,e2,e3,e4,e5,e6,e7>
port 1: head <e1>; body <e0,e2,e3,e4,e5,e6,e7>.
```

In the one-hot pulse model give both ports the *same* seven fresh axes
`f0,...,f6`, with a bijective old-body-to-fresh matching for each. Fix
one port-0 matching, enumerate all 7! port-1 matchings, and form the
involutions `S0,S1`. Because `S0` fixes `e0` while `S1` sends `e0` to
some fresh `f`, and `S0` sends that `f` to an old body axis, they never
commute. Consequently `(S1 S0)^2 != I` in all 5,040 matchings. The
canonical like-ordered matching makes `S1 S0` a three-cycle on
`e0,e1,f0`. The result lists the complete finite order distribution.

The controlled fold `F(x,s)=(S_s x,s)` is not a single linear chart map:
`F(e0,0)+F(0,1)=(e0,1)` but `F(e0,1)=(f,1)`. This witness works for
every such matching; the identical-port control passes. These statements
concern one-hot coordinate permutations and a preserved linear slot label.
They do not rule out port-specific paid matchers, other fresh geometries,
role-dependent extraction, nonlinear slot routing, a true rank-14 direct
sum, or a new physical cochart.

For the price-only two-port grade-7 proposal, replacing two `H(7)` payments
by one `H(14)` saves `0.0373183449377360...`; the whole BIT account would
then be `+0.0096069847475184...`, but even one further grade-one paid job
would make it `−0.9903930152524815...`. Neither the required physical
grade-14 operator nor restored ownership has been constructed here.

## Reproduce and attribution

Run `python3 -I -B screen.py > /tmp/p104-tensor-contact-result.json` and
compare it to `RESULT.json`. `screen.py` authenticates the baseline and raw
word. Two outward integer interval engines independently bracket the four
moments and shifted powers. They share the fixed source histograms; this is
an arithmetic cross-check, not an independent literal-word recount. The
replay also checks the rank-two spectral example, rank-three padded control,
the 5,040 port matchings, a same-port control, and an abstract two-reflection
identity. The raw producers, source notices and earlier contributions are
credited in the pinned #7830, #7863, #7868, #7973 and #7990 notices.
`target_exact.py` and `interval80.py` are retained Apache-2.0 source files;
the accompanying license is preserved.
