#!/usr/bin/env python3
"""Raw mixed moments and a two-port one-hot period test; not an application proof."""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from itertools import permutations
from math import lcm
from pathlib import Path
import gzip
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
import target_exact as first
import interval80 as second

HERE = Path(__file__).resolve().parent
K = Q("0.00388")
T = 1 - K


def read_pinned(name, expected):
    raw = (HERE / name).read_bytes()
    assert sha256(raw).hexdigest() == expected, name
    return raw


def enclose_power(rank, exponent, engine):
    assert 0 <= exponent <= 2
    extra = rank if exponent > 1 else 1
    reduced = exponent - 1 if exponent > 1 else exponent
    if engine == 1:
        a, b = first.rank_power(rank, reduced)
        denominator = first.GRID
    else:
        # Compute r**reduced via exp(+reduced*ln(r)/8) and three
        # outward squarings. The small argument respects expminus's range.
        e = second.expminus(second.smul(second.log(rank),reduced/8))
        value = second.div(second.exact(1),e)
        for _ in range(3):
            value = second.mul(value,value)
        a, b = value
        denominator = second.B
    return Q(extra*a,denominator), Q(extra*b,denominator)


def enclose_sum(hist, engine, exponent=T):
    lo = hi = Q(0)
    for rank, count in hist.items():
        a, b = enclose_power(int(rank), exponent, engine)
        lo += count * a
        hi += count * b
    return lo, hi


def checked_sum(hist, exponent):
    a = enclose_sum(hist,1,exponent)
    b = enclose_sum(hist,2,exponent)
    assert max(a[0], b[0]) <= min(a[1], b[1])
    return max(a[0],b[0]), min(a[1],b[1])


def checked_power(rank, exponent):
    a = enclose_power(rank,exponent,1)
    b = enclose_power(rank,exponent,2)
    assert max(a[0], b[0]) <= min(a[1], b[1])
    return max(a[0],b[0]),min(a[1],b[1])


def plus(a, b):
    return a[0] + b[0], a[1] + b[1]


def minus(a, b):
    return a[0] - b[1], a[1] - b[0]


def times(a, b):
    vals = [x*y for x in a for y in b]
    return min(vals), max(vals)


def divide_positive(a, b):
    assert a[0] >= 0 and b[0] > 0
    return a[0]/b[1], a[1]/b[0]


def shown(interval, places=30):
    scale = 10 ** places
    a, b = interval
    lower = (a.numerator * scale) // a.denominator
    upper = -((-b.numerator * scale) // b.denominator)
    def fmt(n):
        sign = "-" if n < 0 else ""
        whole, part = divmod(abs(n), scale)
        return f"{sign}{whole}.{part:0{places}d}"
    return [fmt(lower), fmt(upper)]


base = json.loads(read_pinned("BASELINE.json", "a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a"))
parts = {}
for side in ("binary", "rational"):
    vals = {}
    for kind in ("targets", "paid"):
        a = enclose_sum(base[side][kind], 1)
        b = enclose_sum(base[side][kind], 2)
        assert max(a[0], b[0]) <= min(a[1], b[1]), (side, kind)
        vals[kind] = (max(a[0], b[0]), min(a[1], b[1]))
    vals["surplus"] = minus(vals["targets"], vals["paid"])
    vals["alpha"] = divide_positive(vals["paid"], vals["targets"])
    parts[side] = vals

B, R = parts["binary"], parts["rational"]
one = (Q(1), Q(1))
assert B["surplus"][1] < 0 < R["surplus"][0]
pair = times(B["alpha"], R["alpha"])
two_b_one_r = times(B["alpha"], pair)
assert pair[1] < 1 < two_b_one_r[0]
pair_surplus = minus(times(B["targets"], R["targets"]), times(B["paid"], R["paid"]))
assert pair_surplus[0] > 0
twice = (pair[0]*2, pair[1]*2)
assert twice[0] > 1
split_rational_mass = sum(int(rank)*num for rank,num in base["rational"]["paid"].items())
split_rational = (Q(split_rational_mass),Q(split_rational_mass))
split_rational_surplus = minus(R["targets"],split_rational)
split_alpha = times(B["alpha"],divide_positive(split_rational,R["targets"]))
assert split_rational_mass == 743040 and split_rational_surplus[1] < 0 and split_alpha[0] > 1

# Exact Walsh-spectrum control for one versus two complex coordinate axes.
# On r selected binary coordinates C has eigenvalues i**HammingWeight.
# D=C**2 is the full tensor flip in this abstract common space.  The
# fixed-rank BIT projector lives in a different 2n head/tail space; this
# calculation therefore tests the affine adapter, not physical equivalence.
g1 = [(1,0),(0,1)]
g2 = [(1,0),(0,1),(0,1),(-1,0)]
d2 = [1,-1,-1,1]
assert g2[0] != g2[3] and d2[0] == d2[3]
# The first two equalities force a=1+i,b=-i for D=a*C+b*I;
# the last equality fails already on the weight-two Walsh vector.
def affine_rank1(z):
    return z[0]-z[1], z[0]+z[1]-1
assert [affine_rank1(g) for g in g1] == [(1,0),(-1,0)]
assert [affine_rank1(g) for g in g2] == [(1,0),(-1,0),(-1,0),(-1,-2)]
# C2 is the following Gaussian-integer numerator divided by 2.
# Its square has denominator 4 and equals the permutation x -> x xor 3.
entries=((0,1),(1,0),(0,-1))
c2=tuple(tuple(entries[(r^c).bit_count()] for c in range(4)) for r in range(4))
assert all(z != (0,0) for row in c2 for z in row)
for r in range(4):
    for c in range(4):
        real=imag=0
        for j in range(4):
            a,b=c2[r][j];d,e=c2[j][c]
            real+=a*d-b*e;imag+=a*e+b*d
        assert (real,imag) == ((4,0) if c == (r^3) else (0,0))
# Necessary support equations for D=A C B+E with diagonal A,B,E.
# C has no zero entries; D flips every one of d address bits. A and B
# are allowed arbitrary zeros. E is unrestricted on the diagonal.
def support_solutions(d):
    n=1<<d
    solutions=[]
    for a in range(1<<n):
        for b in range(1<<n):
            ok=True
            for r in range(n):
                for c in range(n):
                    if r == c:
                        continue
                    required = c == (r^(n-1))
                    present = bool((a>>r&1) and (b>>c&1))
                    if present != required:
                        ok=False
                        break
                if not ok:
                    break
            if ok:
                solutions.append((a,b))
    return solutions
assert len(support_solutions(1)) == 1
assert not support_solutions(2)
# For a deliberately chosen eight-dimensional padded comparison at rank 3,
# C_3^2 has four negative Walsh eigenvalues; three independent swaps plus
# two fixed spectators have three. Similarity preserves this multiplicity.
rank3_tensor_negative = sum(i.bit_count() % 2 for i in range(8))
rank3_padded_projector_negative = 3
assert (rank3_tensor_negative,rank3_padded_projector_negative) == (4,3)

# A conditional strictification calculation for an already-constructed
# common-type product unit. Each paired raw factor contains one full B and R.
# The arithmetic does not construct that unit or assert the required type.
tilt = Q(1,5)
cutoff, floor, count = 150, 200, 80
pair_target = times(B["targets"], R["targets"])
paid_tilt = times(checked_sum(base["binary"]["paid"],T+tilt),
                  checked_sum(base["rational"]["paid"],T+tilt))
target_tilt = times(checked_sum(base["binary"]["targets"],T-tilt),
                    checked_sum(base["rational"]["targets"],T-tilt))
gamma = divide_positive(paid_tilt,times(checked_power(cutoff,tilt),pair_target))
lam = divide_positive(times(checked_power(floor,tilt),target_tilt),pair_target)
assert pair[1] < 1-Q(9,10**8)
assert gamma[1] < Q(827,1000) and lam[1] < Q(855,1000)
finite_bound = 1/(1+count*Q(9,10**8))+2*Q(827,1000)**count+Q(855,1000)**count
assert finite_bound < 1
assert base["binary"]["targets"]["8"] > 0 and base["rational"]["targets"]["25"] > 0
assert cutoff < floor and 8*25 == floor

def h(rank):
    x = first.rank_power(rank, T)
    return Q(x[0],first.GRID),Q(x[1],first.GRID)
credit = minus(plus(h(7),h(7)),h(14))
ideal_bit = plus(B["surplus"], credit)
assert ideal_bit[0] > 0 > minus(ideal_bit,one)[1]

raw = read_pinned("BIT-WORD.json.gz", "d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9")
word = json.loads(gzip.decompress(raw))
canonical = json.dumps(word, sort_keys=True, separators=(",", ":")).encode()
assert sha256(canonical).hexdigest() == "d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d"
heads, bodies = [], []
for port in (0, 1):
    head = word["frames"][str(word["start"][port])]["B"]
    body = word["frames"][str(word["final"][111+port])]["B"]
    assert all(sum(row) == 1 for row in head + body)
    heads.append([row.index(1) for row in head])
    bodies.append([row.index(1) for row in body])
assert heads == [[0], [1]]
assert bodies == [[1,2,3,4,5,6,7], [0,2,3,4,5,6,7]]

fresh = list(range(8,15))
def swap_map(axes, matching):
    mapping = list(range(15))
    for axis, f in zip(axes, matching):
        mapping[axis], mapping[f] = f, axis
    return tuple(mapping)

def compose(a,b):
    return tuple(a[b[i]] for i in range(15))

def order(p):
    seen = set()
    value = 1
    for i in range(15):
        if i not in seen:
            j = i
            n = 0
            while j not in seen:
                seen.add(j)
                j = p[j]
                n += 1
            value = lcm(value,n)
    return value

s0 = swap_map(bodies[0], fresh)
identity = tuple(range(15))
assert compose(s0,s0) == identity
distribution = Counter()
for matching in permutations(fresh):
    s1 = swap_map(bodies[1], matching)
    assert compose(s1,s1) == identity
    assert s0[0] == 0 and s1[0] in fresh
    assert compose(s1,s0) != compose(s0,s1)
    distribution[order(compose(s1,s0))] += 1
assert sum(distribution.values()) == 5040 and min(distribution) >= 3
s1 = swap_map(bodies[1], fresh)
period = compose(s1,s0)
assert order(period) == 3

def map_bits(mapping, value):
    out = 0
    for i in range(15):
        if value >> i & 1:
            out |= 1 << mapping[i]
    return out

def folded(value, m0, m1):
    x = value & ((1 << 15)-1)
    slot = value >> 15
    assert slot in (0,1)
    return map_bits((m0,m1)[slot],x) | (slot << 15)

x, y = 1, 1 << 15
observed = folded(x,s0,s1)^folded(y,s0,s1)
wanted = folded(x^y,s0,s1)
assert observed != wanted
assert folded(x,s0,s0)^folded(y,s0,s0) == folded(x^y,s0,s0)

# In an abstract common Q(i) field, two exchange-based reflections implement
# a phase on a live role and its inverse on a clean scratch role. This is a
# local algebra control, not a chart/ownership or physical-cost certificate.
z, o, ii, mi = (0,0), (1,0), (0,1), (0,-1)
def gadd(a,b):
    return a[0]+b[0],a[1]+b[1]
def gmul(a,b):
    return a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]
def gmatmul(a,b):
    return tuple(tuple(gadd(gmul(a[r][0],b[0][c]),gmul(a[r][1],b[1][c]))
                       for c in range(2)) for r in range(2))
GI = ((o,z),(z,o))
G1 = ((z,o),(o,z))
G2 = ((z,mi),(ii,z))
assert gmatmul(G1,G1) == gmatmul(G2,G2) == GI
assert gmatmul(G1,G2) == ((ii,z),(z,mi))

out = {
  "status": "PASS_BOUNDED_ARITHMETIC_AND_ONE_HOT_SCREEN_NO_NEW_BOUND",
  "trial_kappa": str(K),
  "directed_decimals": {side: {k:shown(v) for k,v in data.items()} for side,data in parts.items()},
  "normalized_product_1B_1R": shown(pair),
  "normalized_product_2B_1R": shown(two_b_one_r),
  "raw_product_target_minus_paid": shown(pair_surplus),
  "two_rational_executions_naive_ratio": shown(twice),
  "individual_coordinate_split_rational_paid_mass": split_rational_mass,
  "individual_coordinate_split_rational_surplus": shown(split_rational_surplus),
  "individual_coordinate_split_product_ratio": shown(split_alpha),
  "affine_whole_tensor_control": {
      "complex_rank1_eigenvalues": ["1","i"],
      "complex_rank2_eigenvalues": ["1","i","i","-1"],
      "rank2_tensor_flip_eigenvalues": ["1","-1","-1","1"],
      "diagonal_input_output_retention_support_solutions_rank1_rank2": [len(support_solutions(1)),len(support_solutions(2))],
      "rank3_eight_dimensional_padded_control_negative_multiplicities": [rank3_tensor_negative,rank3_padded_projector_negative],
      "scope": "ordinary same-chart scalar combinations of one whole complex call; coordinate-dependent maps remain open",
      "actual_rational_paid_grade2_count": base["rational"]["paid"]["2"],
      "actual_binary_paid_grade2_count": base["binary"]["paid"]["2"],
  },
  "conditional_formal_strictification": {
      "raw_factors": "80 chronological (BIT,rational) pairs, assuming exact common-type product grammar",
      "cutoff": "150^80", "floor": "200^80", "ambient": "(134*153)^80",
      "floor_witness": "BIT target rank 8 times rational target rank 25 at each pair",
      "u":str(tilt), "w":str(tilt), "gamma":shown(gamma), "lambda":shown(lam),
      "rational_upper_alpha": "1-9/100000000", "rational_upper_gamma":"827/1000",
      "rational_upper_lambda":"855/1000", "strict_bound":shown((finite_bound,finite_bound)),
      "strict_bound_formula": "1/(1+80*9/100000000)+2*(827/1000)^80+(855/1000)^80",
      "scope": "sufficient finite signed condition only if type-compatible unit and all original job costs exist",
  },
  "ideal_replace_two_grade7_by_one_grade14_credit": shown(credit),
  "ideal_bit_balance": shown(ideal_bit),
  "ideal_bit_balance_less_one_grade1": shown(minus(ideal_bit,one)),
  "raw_product_scope": "conditional formal histogram product before any mixed physical compiler or outer recurrence",
  "old_heads": heads, "old_bodies": bodies,
  "fresh_axis_order": fresh,
  "slot_alternating_cycle_orders_all_5040_second_matchings": {str(k):v for k,v in sorted(distribution.items())},
  "canonical_matching_period_order": order(period),
  "controlled_fold_linearity_witness": {"x":x,"y":y,"fold_x_xor_fold_y":observed,"fold_x_xor_y":wanted},
  "controlled_fold_linearity_witness_all_matchings": 5040,
  "abstract_two_reflection_control": "R1^2=R2^2=I; R1 R2=diag(i,-i), so C on live and C^-1 on zero scratch",
  "fold_scope": "one-hot coordinate permutation model, same seven fresh axes, arbitrary port-1 matching; not a full-array physical replay",
  "negative_controls": ["same matching on same old port removes folded linearity witness", "first and second directed interval engines intersect"],
}
print(json.dumps(out, indent=2, sort_keys=True))
