#!/usr/bin/env python3
"""Inventory, clean replay and corruption controls for the bounded diagnostic."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import shutil, subprocess, sys

ROOT=Path(__file__).resolve().parent

def need(ok,why):
 if not ok:raise ValueError(why)

def main():
 need(__debug__,'run without Python -O')
 entries=[]
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);path=Path(name)
  need(not path.is_absolute() and '..' not in path.parts,'invalid inventory path')
  need(sha256((ROOT/path).read_bytes()).hexdigest()==digest,'inventory mismatch: '+name)
  entries.append(name)
 need({'replay.py','verify.py','RESULT.json','TABLES.json.gz'}.issubset(entries),'incomplete inventory')
 with TemporaryDirectory(prefix='.verify-',dir=ROOT) as temp:
  dest=Path(temp)
  for name in entries:
   src=ROOT/name;dst=dest/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
  def run(*flags):
   return subprocess.run([sys.executable,*flags,'replay.py'],cwd=dest,capture_output=True,text=True)
  ok=run('-I','-B');need(ok.returncode==0,'clean replay failed: '+ok.stderr)
  need((dest/'RESULT.json').read_bytes()==(ROOT/'RESULT.json').read_bytes(),'receipt mismatch')
  bad=dest/'inputs/ZERO-CONTROL-WORD.json.gz';blob=bytearray(bad.read_bytes());blob[len(blob)//2]^=1;bad.write_bytes(blob)
  fail=run('-I','-B');need(fail.returncode!=0 and 'source pin:' in fail.stderr,'corrupted source accepted')
  opt=run('-O','-I','-B');need(opt.returncode!=0 and 'run without Python -O' in opt.stderr,'optimized execution accepted')
 print('PASS_INVENTORY_CLEAN_REPLAY_AND_CORRUPTION_CONTROLS')
if __name__=='__main__':main()
