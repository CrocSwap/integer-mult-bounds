#!/usr/bin/env python3
"""Finite chart-coordinate escrow and independent scalar-literal controls.

Not a native 451-fold supplier: see README.md for the exact limits.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip, json, random, sys, tarfile

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'upstream'))
from ternary_frames import (projector, transpose, inverse, frame_at_three,
                            multiply, identity, residue)

CAND = '09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be'
OLD = 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
PINS = {
 'REMOTE-7907.tar.gz':'e53e772469766f30ff6ed7d1aee9e4c21d7863fff5cec5185b4e2e3d11daa692',
 'REMOTE-7911.tar.gz':'4d7138d84a5af55c56316191db743c63b3a82d1f46d0fad7a851d34d0765f45e',
 'REMOTE-7912.tar.gz':'87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096',
 'TABLES.json.gz':'5358980ce183a7017084af9532077cbc60594d1f2a0cb386c959d1cdf689da69',
 'inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'inputs/ZERO-CONTROL-WORD.json.gz':'f0aa75a63cc9200f627721851bd68c27367ae80e7fca2f0fe6f515fe2bfc9f63',
 'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'inputs/EXPECTED-7911.json':'b99810b63ecce725db18c8bf3205a3e18b2262c036da03919a6c2659856e0053',
 'inputs/README-R4-12.md':'8b286666f48c603c5bbfdc04f3d6da334ee38b70f12dcd0f59a329510c67876c',
 'inputs/README-R4-05.md':'99a5662d60796993442aad421052499d4ec0f4dc40f2def8295502a2ef8f564d',
}

def need(ok, why):
 if not ok: raise ValueError(why)

def canonical(x):
 return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def source():
 for name,pin in PINS.items(): need(sha256((ROOT/name).read_bytes()).hexdigest()==pin,'source pin: '+name)
 for archive, pairs in [
  ('REMOTE-7907.tar.gz',[('./upstream/ternary_frames.py','upstream/ternary_frames.py')]),
  ('REMOTE-7912.tar.gz',[('./ZERO-CONTROL-WORD.json.gz','inputs/ZERO-CONTROL-WORD.json.gz'),('./inputs/WORD.json.gz','inputs/WORD.json.gz'),('./inputs/EFREE-CALLER.json.gz','inputs/EFREE-CALLER.json.gz')]),
  ('REMOTE-7911.tar.gz',[('./EXPECTED.json','inputs/EXPECTED-7911.json')])]:
  with tarfile.open(ROOT/archive,'r:gz') as t:
   for member,local in pairs:
    f=t.extractfile(member); need(f is not None and f.read()==(ROOT/local).read_bytes(),'archive member: '+member)
 def readgz(name):return json.loads(gzip.decompress((ROOT/name).read_bytes()))
 old,new,caller,tables=(readgz('inputs/WORD.json.gz'),readgz('inputs/ZERO-CONTROL-WORD.json.gz'),
                        readgz('inputs/EFREE-CALLER.json.gz'),readgz('TABLES.json.gz'))
 need(canonical(old)==OLD and canonical(new)==CAND,'canonical word')
 return old,new,caller,tables

def all_targets(word,caller):
 dims={int(k):v['dim'] for k,v in word['frames'].items()}
 out=[]
 for i,e in enumerate(caller['diagonal']):
  for p in range(caller['ports']):out.append((('root',i,p),1+7*len(e['stages'])))
 for c,e in enumerate(caller['events']):
  if e[0]=='LOCAL':
   for a in range(2*caller['ports'],len(word['start'])):
    out.append((('helper',c,a),abs(dims[word['final'][a]]-dims[word['start'][a]])))
 return out

def bind_tables(new,caller,tables):
 events=[(i,e) for i,e in enumerate(caller['events']) if e[0]=='LOCAL']
 need(len(events)==len(tables)==36,'actual call count')
 dims={int(k):v['dim'] for k,v in new['frames'].items()}
 helpers=[[a, (a if a<649 else a+1),new['start'][a],new['final'][a],
           abs(dims[new['start'][a]]-dims[new['final'][a]])]
          for a in range(222,new['public'])]
 moves=[]
 for clock,row in enumerate(new['program']):
  if row[0]=='MOVE':
   bank,a,b=row[1:]
   # Candidate banks use public=679 and original paid labels skip 3266.
   # Before 3266 the original packet is one larger than its new bank.
   orig=bank+1 if bank<3265 else bank+2
   moves.append([clock,bank,orig,a,b,abs(dims[a]-dims[b])])
 for t,(clock,event) in zip(tables,events,strict=True):
  need(t['word']==CAND,'wrong word namespace')
  need(t['caller_clock']==clock and t['event']==event,'wrong caller namespace')
  need(t['helper']==helpers,'wrong helper, grade or provenance')
  need(t['paid_move']==moves,'wrong paid address, grade or provenance')
 need(len(helpers)==457 and len(moves)==2873,'per-call counts')
 return helpers,moves

def rejected(f, why):
 try:f()
 except ValueError as e:
  need(why in str(e),'wrong rejection: '+str(e));return str(e)
 raise ValueError('failed to reject '+why)

def table_controls(new,caller,tables):
 bad=deepcopy(tables);bad[0]['word']=OLD
 a=rejected(lambda:bind_tables(new,caller,bad),'wrong word namespace')
 bad=deepcopy(tables);row=next(r for r in bad[0]['helper'] if r[0]==649)
 row[1:]=[649,506,1,4]
 b=rejected(lambda:bind_tables(new,caller,bad),'wrong helper')
 bad=deepcopy(tables);bad[0]['caller_clock']=bad[1]['caller_clock']
 c=rejected(lambda:bind_tables(new,caller,bad),'wrong caller')
 return {'old_word_namespace':a,'forged_stale_owner_grade':b,'different_call':c}

def invoice_histograms(old,new,caller):
 def count(word):
  targets=Counter(rank for _,rank in all_targets(word,caller))
  dims={int(k):v['dim'] for k,v in word['frames'].items()}
  native=Counter(abs(dims[r[2]]-dims[r[3]]) for r in word['program'] if r[0]=='MOVE')
  paid=Counter()
  for event in caller['events']:
   if event[0]=='LOCAL':paid.update(native)
   elif event[0] in ('QUERY','IDLE_ONE'):
    rank=1 if event[0]=='QUERY' else 7*len(event[2])
    paid[rank]+=caller['ports']
  return targets,paid
 t0,p0=count(old);t1,p1=count(new)
 def delta(a,b):
  c=Counter(a);c.subtract(b);return {k:v for k,v in sorted(c.items()) if v}
 td=delta(t1,t0);pd=delta(p1,p0)
 signed=Counter(t1);signed.subtract(t0);signed.subtract(p1);signed.update(p0)
 need(td=={4:-36} and pd=={4:-36} and not any(signed.values()),'complete signed histogram delta')
 return {'productive_delta':td,'paid_delta':pd,'target_minus_paid_delta':{},
         'interpretation':'no raw signed moment gain for the pinned control'}

def path_checks(old,new,caller):
 ot=all_targets(old,caller);nt=all_targets(new,caller)
 om=dict(ot);nm=dict(nt)
 need(len(om)==len(ot) and len(nm)==len(nt),'target tags not unique')
 root=('root',0,0);helper=('helper',4,649);common4=('helper',4,648)
 eight=next(k for k,v in nt if k[0]=='root' and v==8)
 sixtyfour=next(k for k,v in nt if k[0]=='root' and v==64)
 need((om[root],nm[root],om[helper],nm[helper])==(127,127,4,2),'exact 127 x 2 versus 127 x 4')
 need((old['start'][649],old['final'][649],new['start'][649],new['final'][649])==(506,1,374,1),'old and new helper charts')
 path=[helper]+[common4]*223+[eight]*2+[sixtyfour]*225
 need(len(path)==451,'451 path length')
 def locate(items,mp):
  by={tag:i for i,(tag,_) in enumerate(items)}
  indices=[by[t] for t in path]; base=len(items);ordinal=0;grade=1
  for i,tag in zip(indices,path,strict=True):ordinal=ordinal*base+i;grade*=mp[tag]
  recovered=[];q=ordinal
  for _ in path:q,r=divmod(q,base);recovered.append(r)
  need(q==0 and recovered[::-1]==indices,'451 ordinal round trip')
  return {'target_count':base,'first_ordinal':indices[0],
          'ordinal_sha256':sha256(str(ordinal).encode()).hexdigest(),
          'indices_sha256':canonical(indices),'grade':grade}
 o,n=locate(ot,om),locate(nt,nm)
 need(o['grade']==16**451 and n['grade']*2==o['grade'],'451 floor crossing')
 o['grade']='16^451';n['grade']='16^451/2'
 return {'tags':{'root':root,'old_and_new_helper_spelling':helper,
                  'other_grade4':common4,'grade8':eight,'grade64':sixtyfour},
         'old_two_factor':508,'new_two_factor':254,'two_factor_floor':256,
         'old_451':o,'new_451':n,'factor_counts':{'helper_changed':1,'other_grade4':223,'grade8':2,'grade64':225},
         'scope':'exact path and mixed-radix address only; no 451-product execution'}

def modmat(a,m):return [[residue(x,m) for x in row] for row in a]
def matvec(a,v,m):return [sum(x*y for x,y in zip(row,v,strict=True))%m for row in a]

def gauss_ops(a,m):
 a=[row[:] for row in a];ops=[];n=len(a)
 for j in range(n):
  pivot=next((i for i in range(j,n) if a[i][j]%3),None)
  need(pivot is not None,'no unit pivot')
  if pivot!=j:a[j],a[pivot]=a[pivot],a[j];ops.append(('swap',j,pivot,0))
  x=pow(a[j][j],-1,m)
  if x!=1:a[j]=[v*x%m for v in a[j]];ops.append(('scale',j,0,x))
  for i in range(n):
   if i!=j and a[i][j]:
    v=(-a[i][j])%m;a[i]=[(x+v*y)%m for x,y in zip(a[i],a[j],strict=True)];ops.append(('add',i,j,v))
 need(a==identity(n),'Gaussian frame reduction')
 return ops

def op(row,gate,m,back=False):
 kind,i,j,c=gate
 if kind=='swap':row[i],row[j]=row[j],row[i]
 elif kind=='scale':row[i]=row[i]*(pow(c,-1,m) if back else c)%m
 else:row[i]=(row[i]+(-c if back else c)*row[j])%m

def chart(rows,ops,m,back=False):
 sequence=list(reversed(ops)) if back else ops
 for row in rows:
  for g in sequence:op(row,g,m,back)

def prepare(rows,stock,ops,m):
 need(len(rows)==127 and all(len(r)==8 for r in rows),'host extent')
 need(len({id(row) for row in rows})==127,'aliased host fields')
 need(len(stock)==254,'clean stock exhausted')
 need(all(x==0 for x in stock),'stock is dirty')
 need(all(stock is not r for r in rows),'aliased stock')
 chart(rows,ops,m)
 for i,row in enumerate(rows):
  for j in range(2):row[j],stock[2*i+j]=stock[2*i+j],row[j]
 chart(rows,ops,m,True)

def checked_retire(rows,stock,ops,m,garbage=None):
 need(len(rows)==127 and all(len(r)==8 for r in rows) and len(stock)==254,'wrong retirement extent')
 need(len({id(row) for row in rows})==127,'aliased host fields')
 need(all(stock is not row for row in rows),'aliased stock')
 if garbage is not None:
  need(garbage is not stock and all(garbage is not r for r in rows),'aliased garbage')
  need(len(garbage)==254,'garbage stock exhausted')
  need(all(x==0 for x in garbage),'garbage stock dirty')
 chart(rows,ops,m)
 dirty=any(row[j] for row in rows for j in range(2))
 if dirty and garbage is None:
  chart(rows,ops,m,True)
  raise ValueError('owned target is dirty')
 for i,row in enumerate(rows):
  for j in range(2):
   k=2*i+j
   if dirty:row[j],garbage[k]=garbage[k],row[j]
   row[j],stock[k]=stock[k],row[j]
 chart(rows,ops,m,True)
 return dirty

def local_chart(new):
 frames=new['frames']
 def proj(k):
  f=frames[str(k)];return projector(transpose(f['B']+f['A']),f['dim'])
 p0,p1=proj(374),proj(1)
 p=[[y-x for x,y in zip(a,b,strict=True)] for a,b in zip(p0,p1,strict=True)]
 need(multiply(p,p)==p,'helper difference is not idempotent')
 f,rank=frame_at_three(p);need(rank==2,'helper rank at 3')
 fi=inverse(f);diag=identity(8)
 for j in range(2,8):diag[j][j]=0
 need(multiply(multiply(f,diag),fi)==p,'chart frame does not realize source projector')
 rng=random.Random(7912679254);cases=[]
 for digits in (1,2,3):
  m=3**digits;fm=modmat(f,m);fim=modmat(fi,m);pm=modmat(p,m)
  ops=gauss_ops(fm,m)
  for j in range(8):
   basis=[int(i==j) for i in range(8)];vec=basis[:]
   for gate in ops:op(vec,gate,m)
   need(vec==matvec(fim,basis,m),'compiled frame inverse basis')
  # 127 genuinely independent, arbitrarily populated coordinate vectors;
  # every old image sentinel is nonzero and all six retained coordinates vary.
  original_coords=[[rng.randrange(1,m),rng.randrange(1,m)]+[rng.randrange(m) for _ in range(6)] for _ in range(127)]
  original=[matvec(fm,r,m) for r in original_coords];rows=deepcopy(original);stock=[0]*254
  before=deepcopy(rows)
  alias_rows=deepcopy(rows);alias_rows[1]=alias_rows[0]
  alias=rejected(lambda:prepare(alias_rows,[0]*254,ops,m),'aliased host fields')
  exhaustion=rejected(lambda:prepare(rows,[0]*253,ops,m),'clean stock exhausted')
  need(rows==before,'preflight exhaustion changed input')
  dirty_stock=rejected(lambda:prepare(rows,[1]+[0]*253,ops,m),'stock is dirty')
  need(rows==before,'dirty stock changed input')
  prepare(rows,stock,ops,m)
  need(stock==[v for row in original_coords for v in row[:2]],'independent dirty image sentinels')
  for old,newrow in zip(original,rows,strict=True):
   need(matvec(pm,newrow,m)==[0]*8,'image not zero')
   oldp=matvec(pm,old,m)
   need([(v-q)%m for v,q in zip(old,oldp,strict=True)]==newrow,'complement not preserved')
  # Mutate the independent retained complement by an invertible coordinate shear.
  chart(rows,ops,m)
  for row in rows:row[2]=(row[2]+row[3])%m
  chart(rows,ops,m,True)
  saved=deepcopy(rows)
  chart(rows,ops,m)
  for row in rows:row[0]=(row[0]+1)%m
  chart(rows,ops,m,True)
  mutated=deepcopy(rows);escrow=stock[:]
  dirty_retire=rejected(lambda:checked_retire(rows,stock,ops,m),'owned target is dirty')
  need(rows==mutated and stock==escrow,'failed retirement lost state')
  short_garbage=rejected(lambda:checked_retire(rows,stock,ops,m,[0]*253),'garbage stock exhausted')
  need(rows==mutated and stock==escrow,'garbage exhaustion lost state')
  undo_rows=deepcopy(mutated);undo_stock=escrow[:]
  chart(undo_rows,ops,m)
  for row in undo_rows:row[0]=(row[0]-1)%m
  chart(undo_rows,ops,m,True)
  need(undo_rows==saved,'actual inverse mutation failed')
  garbage=[0]*254
  need(checked_retire(rows,stock,ops,m,garbage),'mutation was not captured')
  need(stock==[0]*254,'base zero stock not restored')
  need(garbage==[v for _ in range(127) for v in (1,0)],'mutated target not retained as garbage')
  expected=[]
  for v in original_coords:
   q=v[:];q[2]=(q[2]+q[3])%m;expected.append(matvec(fm,q,m))
  need(rows==expected,'original sentinels or retained mutation not restored')
  # Separate exact uncompute run: undo target mutation before retirement.
  rows=undo_rows;stock=undo_stock
  need(not checked_retire(rows,stock,ops,m),'unexpected dirty target')
  need(rows==expected and stock==[0]*254,'retained update or dirty sentinel lost')
  cases.append({'digits':digits,'modulus':m,'frame_elementary_gates':len(ops),
     'prepare_coordinate_gates':254*len(ops),'prepare_target_swaps':254,
     'successful_retire_coordinate_gates':254*len(ops),'successful_retire_target_swaps':254,
     'rejected_dirty_retirement_coordinate_gates':254*len(ops),
     'retained_shear_coordinate_gates':254*len(ops)+127,
     'undo_target_mutation_coordinate_gates':254*len(ops)+127,
     'extra_for_unreversed_mutation_ternary_digits':254*digits,
     'base_escrow_ternary_digits':254*digits,'ambient_ternary_digits':1016*digits,
     'aliased_host':alias,'clean_exhaustion':exhaustion,'dirty_stock':dirty_stock,'dirty_retirement':dirty_retire,
     'garbage_exhaustion':short_garbage})
 return {'source_charts':[374,1],'rank':rank,'root_channels':127,
   'matrix_frame_sha256':canonical([[str(x) for x in row] for row in f]),
   'projector_sha256':canonical([[str(x) for x in row] for row in p]),'cases':cases,
   'scope':'one abstract 127-channel tensor factor and the actual helper chart; retained shear is a diagnostic operator'}

def scalar_program(word,adjoint):
 tags=list(word['final'] if adjoint else word['start'])+[None]*word['owned_fields']
 out=[]
 sequence=range(len(word['program'])-1,-1,-1) if adjoint else range(len(word['program']))
 for clock in sequence:
  typ,r,*args=word['program'][clock]
  if typ in ('INIT','CLEAR'):
   opens=(typ=='CLEAR') if adjoint else (typ=='INIT'); chart_id=args[0]
   if opens:need(tags[r] is None,'scalar opening');tags[r]=chart_id;out.append(('open',r,chart_id))
   else:need(tags[r]==chart_id,'scalar closing');tags[r]=None;out.append(('close',r,chart_id))
  elif typ=='ADD':
   s,c=args;need(tags[r]==tags[s]==c and r!=s,'scalar ADD chart')
   out.append(('add',s,r) if adjoint else ('add',r,s))
  elif typ=='SWAP':
   s=args[0];need(tags[r] is not None and tags[s] is not None,'scalar SWAP chart')
   tags[r],tags[s]=tags[s],tags[r];out.append(('swap',r,s))
  else:
   need(typ=='MOVE','unknown literal op');a,b=args[::-1] if adjoint else args
   need(tags[r]==a,'scalar MOVE chart');tags[r]=b;out.append(('move',r,a,b))
 expect=list(word['start'] if adjoint else word['final'])+[None]*word['owned_fields']
 need(tags==expect,'scalar endpoint chart tags')
 return out

def scalar_apply(program,banks,escrow,public,reverse=False):
 for g in reversed(program) if reverse else program:
  typ=g[0]
  if typ in ('open','close'):
   r=g[1];k=r-public;banks[r],escrow[k]=escrow[k],banks[r]
  elif typ=='add':banks[g[1]]^=banks[g[2]]
  elif typ=='swap':banks[g[1]],banks[g[2]]=banks[g[2]],banks[g[1]]
  else:need(typ=='move','unknown scalar compiled op')

def literal_control(word):
 n=word['public'];k=word['owned_fields'];need((n,k)==(679,3552),'unexpected native shape')
 counts=Counter(x[0] for x in word['program'])
 need(counts=={'INIT':3552,'CLEAR':3552,'MOVE':2873,'ADD':32291,'SWAP':679},'unexpected op census')
 results=[]
 for adj in (False,True):
  # Bit j denotes independent original public input j; bit n+i is an
  # independent physical dirty sentinel at private bank i.
  banks=[(0 if j==649 else 1<<j) for j in range(n)]+[1<<(n+i) for i in range(k)]
  before=banks[:];escrow=[0]*k;program=scalar_program(word,adj)
  scalar_apply(program,banks,escrow,n)
  for j in range(n):
   want=before[j]
   if adj and j<111:want ^= before[j+111]
   if not adj and 111<=j<222:want ^= before[j-111]
   need(banks[j]==want,'wrong full arbitrary retained endpoint')
  need(banks[n:]==before[n:],'native private dirty sentinels not restored')
  need(all(x.bit_length()<=n for x in escrow),'private sentinels leaked into raw payload')
  nonzero=sum(bool(x) for x in escrow)
  need(word['program'][389]==['ADD',788,678,19],'omission control location')
  pos=(len(program)-1-389) if adj else 389
  bad=before[:];bad_escrow=[0]*k
  scalar_apply(program[:pos]+program[pos+1:],bad,bad_escrow,n)
  changed_rows=sum(bad[j]!=banks[j] for j in range(n))
  changed_bits=sum((bad[j]^banks[j]).bit_count() for j in range(n))
  need((changed_rows,changed_bits)==((1,64) if adj else (64,64)),'omitted ADD control')
  scalar_apply(program,banks,escrow,n,True)
  need(banks==before and not any(escrow),'scalar inverse did not restore all fields and stock')
  results.append({'orientation':'adjoint' if adj else 'forward','instructions':len(program),
     'live_history_blocks_after_local':nonzero,'maximum_history_blocks':k,
     'omitted_live_add_clock':389,'omission_changed_rows':changed_rows,
     'omission_changed_coefficients':changed_bits,
     'reverse_restores_every_independent_input_and_private_sentinel':True})
 return {'source_program_census':dict(counts),'cases':results,'private_escrow_blocks':k,
   'conceptual_width_bits':254,'private_escrow_bits':254*k,'all_native_banks_bits':254*(n+k),
   'target_escrow_bits':254,'total_banks_and_escrows_bits':254*(n+k+k+1),
   'scope':'uniform-width GF(2) scalar lift with symbolic basis, not physical 8-axis MOVE or a graded tensor execution'}

def main():
 need(__debug__,'run without Python -O')
 old,new,caller,tables=source();helpers,moves=bind_tables(new,caller,tables)
 controls=table_controls(new,caller,tables)
 need(next(r for r in helpers if r[0]==649)==[649,650,374,1,2],'candidate original identity')
 h=Counter(t['helper'][i][4] for t in tables for i in range(len(t['helper'])))
 del h
 result={'status':'PASS_FINITE_CHART_ESCROW_AND_SCALAR_HISTORY',
  'sources':{'candidate_pr':7912,'candidate_head':'83ece5a62d3addbee45bad9594ef4809851b833b',
             'fine_rate_pr':7911,'fine_rate_head':'4afc1ffbcde45da360e631a8634b1c86261ddc09',
             'candidate_canonical':CAND,'baseline_canonical':OLD,'r4_table_sha256':PINS['TABLES.json.gz'],
             'r4_12_readme_sha256':PINS['inputs/README-R4-12.md'],
             'r4_05_readme_sha256':PINS['inputs/README-R4-05.md']},
  'namespace':{'calls':36,'per_call_helpers':len(helpers),'per_call_paid':len(moves),
               'candidate_helper':[649,650,374,1,2],'old_helper':[649,649,506,1,4],
               'negative_controls':controls},
  'histograms':invoice_histograms(old,new,caller),
  'path_addressing':path_checks(old,new,caller),'local_chart_escrow':local_chart(new),
  'local_scalar_literal':literal_control(new),
  'not_established':['physical chart-aware chronological 679-word including native paid MOVE',
    'connection of this one path to a paid leaf or a full actual 451-factor raw run',
    'physical fixed-head time, controller, address routing or workspace tariff',
    'all below-floor paths and simultaneous stock, q=3 W^D cover reserves and restoration',
    'changed precision tape, owned_erasure supplier, application, positive signed moment or kappa gain']}
 (ROOT/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(result['status']);print(json.dumps({'chart_cases':result['local_chart_escrow']['cases'],
      'scalar_cases':result['local_scalar_literal']['cases']},sort_keys=True))
if __name__=='__main__':main()
