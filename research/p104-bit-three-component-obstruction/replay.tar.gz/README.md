# Three-component BIT chart screen

For the pinned [#7830 binary supplier](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), none of the **372 connected three-component supports** selected below has a strictly positive complete signed gain at any of these trials:

```
0.003879928046155
0.003879928046156
0.003879929046155
```

The screen permits arbitrary rational subspaces of Q⁸ for each of the three components. It keeps all other component charts, packet forms, productive directions, chronology, main-port endpoints, and the protected owner-411 bridge/tree fixed. Equal paid contacts are optimistically priced as free local operations. The result constructs **no changed word** and establishes **no new κ bound**.

The starting point is the 50 positive-price rank proposals that failed geometry in the preceding [#7881 adjacent-pair screen](https://github.com/CrocSwap/integer-mult-bounds/pull/7881), head `c2d6b3bae2e0b0fed3dd24b3166e3df1b833249c`. For each of those 50 pairs, release one distinct movable exterior neighbor of either endpoint. A neighbor may have a paid or productive incidence. After global deduplication there are 372 supports. A support appearing under more than one parent is assigned to its smallest original parent index; it is still screened with all three components free to choose any rank and rational frame. The verifier independently rebuilds the graph, verifies each exterior roster, and replays the complete 968-pair rational screen from the retained #7881 source before enumerating the triples.

| Exterior-compatible rank assignments | Count at each trial |
| --- | ---: |
| Strictly negative 36-call gain | 37,990 |
| Zero signed histogram | 372 |
| Positive price before joint geometry | 498 |
| Positive cases excluded by exact geometry | 498 |
| Price-positive cases left unresolved | 0 |
| Total | 38,860 |

The three trials have the same classification. The full affected signed histogram is priced, including every paid and productive incidence touching any released component, all common contacts, the factor of 36 native calls, and the unchanged caller terms. The 2,837 distinct signed histograms and their complete caller balances are recorded in [RESULT.json.gz](RESULT.json.gz). Directed rational-grid Taylor bounds and independent integer-square-root bounds agree on every histogram's sign and complete balance.

## Two named controls

For the old tempting pair `(-342, out)` / `(741, in)`, charts 374 / 267, releasing `(969, in)` on chart 176 gives 45 rank assignments: 43 negative, one zero, and one provisional positive. Releasing `(970, in)` on chart 177 gives 90: 87 negative, one zero, and two provisional positives. All three positive cases fail geometry. The literal incidences, rational exterior bases, prices and rank certificates are in [NAMED.json.gz](NAMED.json.gz).

The old apparent `(5, 4, 2)` improvement has 36-call gains about `0.01572932221965`, `0.01572932221965`, and `0.01572932621579` at the three respective trials. The third rank-two frame is forced to its original space by its fixed exterior. The rank-five parent must contain the forced rank-four second parent and its own exterior lower space, whose union has dimension six. It therefore cannot have rank five. For third node 970, a second apparent improvement at `(4, 4, 2)` is blocked twice: the two forced rank-four spaces have a six-dimensional span, and the fixed rank-two third space and the rank-four parent have a five-dimensional span. Thus neither required containment can hold.

The separate packet-2947 control starts with `(-680, out)` / `(2669, in)` and releases each of its four movable exterior neighbors. Its 624 assignments comprise 608 negative, four zero, and 12 provisional positive cases; all 12 have exact obstructions. The independent modular replay below recounts these cases and every other positive case directly. The earlier separate even-shard and packet-2947 receipts are retained in [controls](controls/), and `crosscheck_even.py` compares all their ranks, prices and full invoices with this package.

## Geometry and price certificates

For a proposed rank `d`, the span `L` of all fixed exterior frames of rank at most `d` must be contained in the new space, and the span `N` of normals to fixed exterior frames of rank at least `d` must annihilate it. The verifier checks `dim(L) ≤ d`, `dim(N) ≤ 8−d`, and `L ⟂ N`, plus each helper's strict input-to-output orientation. These are exact rational row-space calculations; equality in rank forces equality of spaces.

Every internal contact forces its lower-rank space into its higher-rank space. The verifier repeatedly propagates required lower spans upward and upper normals downward through those containments. Each of the 498 provisional positives forces an overlarge lower span, an overlarge normal span, or a nonorthogonal required lower/normal pair. The exact rational bases, offending rank and containment arcs are retained per case. The computation stops only after every selected support and every exterior-compatible rank tuple is enumerated, every price sign is decided, and every provisional positive has a checked obstruction.

`independent.py` rebuilds the exterior rank options using the source's **integral** frame rows modulo 65521. This is an optimistic superset for rational feasibility: a nonzero modular minor or dot product proves the corresponding rational rank or nonorthogonality obstruction. It independently matches every support, every rank tuple and signed histogram, directly walks the whole graph in both orders for every provisional positive, reconstructs complete 36-call paid and productive bins, and reprices them by directed 240-bit square roots. Its 498 witnesses comprise 440 excessive lower ranks, 34 excessive normal ranks and 24 nonorthogonal pairs. They are recorded with their original source-row coordinates in [INDEPENDENT.json.gz](INDEPENDENT.json.gz). This billing walk is not an operator replay of a changed word.

## Unchanged-source controls

The full source invoice has 107,460 paid and 20,706 productive positions. Its signed margins are negative at all three trials:

| κ | Complete BIT signed margin |
| --- | ---: |
| `0.003879928046155` | approximately `−0.0000000003818745669163364466103` |
| `0.003879928046156` | approximately `−0.0000000007670015024311302614640` |
| `0.003879929046155` | approximately `−0.0003851273166138664410541394721` |

The retained original word passes all 680² native scalar coefficients in each orientation, all 38² caller polynomial coefficients in each orientation, 3,554 dirty retirements in each direction, 111 main contacts, and the protected owner-411 bridge omission control. The source's ordinary allowance recount gives 934,182,831,504 records and 6,998,544 owned fields under its respective 10¹² and 10⁷ limits. These are checks of the **unchanged source**, not qualification of a candidate.

## Scope and limits

This does not exclude three-component supports that contain no member of the 50 listed parent pairs, non-neighboring third components, four or more released components, edits to protected components, new packet forms, changed caller structure, or a new paid interface. Pair selection is a search boundary, not an argument that other triples cannot improve the price. No changed word, finite-compiler qualification, ordinary-cost qualification for a change, new conditional theorem, or maintainer selection is claimed.

## Reproduce

Python 3.12 and its standard library are sufficient. From this directory:

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py > /tmp/p104-triple-result.json
gzip -dc RESULT.json.gz | cmp - /tmp/p104-triple-result.json
python3 -I -B independent.py > /tmp/p104-triple-independent.json
gzip -dc INDEPENDENT.json.gz | cmp - /tmp/p104-triple-independent.json
python3 -I -B named_controls.py > /tmp/p104-triple-named.json
gzip -dc NAMED.json.gz | cmp - /tmp/p104-triple-named.json
python3 -I -B crosscheck_even.py | cmp - CROSSCHECK.json
```

`verify.py` is the single complete global roster verifier, including the baseline operator/ownership recount and all 968 prior pairs; `independent.py` is the additional modular and full-billing check. Measured on the development machine with one CPU, the complete verifier took about 20 user seconds and 108 MiB peak RSS, and the independent pass about 10 user seconds and 67 MiB peak RSS. These timings are not performance claims.

## Sources and credit

The comparator is #7830 head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; the source gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`, and the canonical word hash is `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. The retained source package and its immutable paths, hashes, and predecessor notices are in [source](source/). `CHECKPOINT.json` records the 50-parent roster; the verifier checks it against both the credited pair certificates and the reconstructed literal graph. See [SOURCES.json](SOURCES.json) and [NOTICE](NOTICE).

Prepared for Clear1nsight with OpenAI Codex assistance. No independent human review is asserted.
