#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""All 50-parent three-component fixed-incidence rank screens.

Generate the connected exterior-neighbor triples from CHECKPOINT.json. A
triple occurring in several parents belongs to the lowest parent index.
Envelopes and directed prices are exact; geometry propagation is necessary,
so a price-positive survivor is reported as unresolved, never as a word.
"""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
import json,subprocess,sys

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source'; arb=SRC/'arbitrary.py'; checkpoint=ROOT/'CHECKPOINT.json'
assert sha256(arb.read_bytes()).hexdigest()=='b53b46c492860707b95e801c92b6bbf0608e5aa5061bd4fd5114fb28f27eacd9'
assert sha256(checkpoint.read_bytes()).hexdigest()=='156876c0ed8393cd494b5f9cce13e91006af233000c6bec04c60dc07c71be433'
code=arb.read_text().split('\nout=[]\nfor i,p in enumerate(pairs[:N],1):');assert len(code)==2
z={'__file__':str(arb)};exec(compile(code[0],str(arb),'exec'),z)
t=z['t'];v=z['v'];price=z['price'];edges=t.edges;chart=t.charts;rank=t.rank;inc=t.incident;frozen=z['frozen']
roster=json.loads(checkpoint.read_text())['released_neighborhoods'];assert len(roster)==50
arbitrary=json.loads((SRC/'ARBITRARY.json').read_text());ref=arbitrary['positive_exclusion_certificates']
assert sha256((SRC/'ARBITRARY.json').read_bytes()).hexdigest()=='10108d252c3648031a138d4f6269705e6d33684e9647fd0bd3a9515ae38182f0'
assert len(ref)==50
assert arbitrary['supports']==arbitrary['all_supports']==968
assert arbitrary['counts']=={'external_feasible_rank_pairs':12889,'zero_hist':1283,
 'nonpositive_hist':11556,'positive_before_joint_geometry':50,'positive_excluded_by_joint_geometry':50}
# Replay the credited predecessor's entire 968-pair census from the pinned word.
prior=subprocess.run([sys.executable,'-I','-B',str(arb)],check=True,stdout=subprocess.PIPE).stdout
assert prior==(SRC/'ARBITRARY.json').read_bytes()
freeze=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'))
assert {freeze((r['pair'],r['dimensions'],r['native_signed_hist'])) for r in ref}=={
 freeze((r['pair'],q['dimensions'],q['native_signed_hist'])) for r in roster for q in r['relaxed']}
KN=['0.003879928046155','0.003879928046156','0.003879929046155']
K=list(map(F,KN))
receipt=v.read('inputs/BIT.json')['native'];paid=Counter({int(k):n for k,n in receipt['paid'].items()});targets=Counter({int(k):n for k,n in receipt['targets'].items()})
assert sum(paid.values())==107460 and sum(targets.values())==20706
base=targets.copy();base.subtract(paid)

def baseline_replay():
 op=v.op;w=z['w'];caller=v.read('inputs/EFREE-CALLER.json.gz');atlas=op.Atlas(w['frames'])
 assert sha256(v.canon(w)).hexdigest()==v.WORD
 assert sha256(v.canon({k:w[k] for k in ('frames','start','final')})).hexdigest()==v.LAYOUT
 assert atlas.main_contacts(w['start'],w['final'])==111
 forward,adjoint,omitted=op.native_checks(w,atlas)
 np,nt,fp,ft=op.binary_invoice(w,caller,atlas,forward)
 for actual,name in [(np,'native_paid'),(nt,'native_targets'),(fp,'paid'),(ft,'targets')]:
  assert actual==Counter({int(k):n for k,n in receipt[name].items()})
 assert fp==paid and ft==targets
 ordinary=op.ordinary_boundary(w,caller,fp,ft)
 return {'native_coefficients_each_orientation':680**2,'caller_coefficients_each_orientation':38**2,
  'dirty_retirements_forward_adjoint':[forward.dirty,adjoint.dirty],
  'protected_owner_411_omission_add_clock':omitted,'main_contacts':111,'ordinary':ordinary,
  'native_paid':dict(np),'native_targets':dict(nt),'complete_paid':dict(fp),'complete_targets':dict(ft)}

@lru_cache(None)
def bound(g,k):return price.price(g,K[k])
@lru_cache(None)
def bound2(g,k):return v.power_bounds(g,1-K[k])
def moment(counter,k):
 lo=hi=0
 for r,n in counter.items():
  if not r or not n:continue
  a,b=bound(r,k);lo+=n*(a if n>0 else b);hi+=n*(b if n>0 else a)
 return lo,hi
def check2(counter,k,iv):
 lo=hi=F(0)
 for r,n in counter.items():
  if not r or not n:continue
  a,b=bound2(r,k);lo+=n*(a if n>0 else b);hi+=n*(b if n>0 else a)
 assert lo<=F(iv[1],price.GRID) and F(iv[0],price.GRID)<=hi
 return v.decimals((lo,hi))
def hkey(h):return tuple((g,h[g]) for g in sorted(h) if g and h[g])
def simple_hist(h):return {str(g):n for g,n in h}

catalogue={}
def price_hist(h):
 key=hkey(h)
 if key in catalogue:return catalogue[key]
 delta=Counter({r:36*n for r,n in key});full=base.copy();full.update(delta)
 signs=[];gains={};balances={}
 for k,name in enumerate(KN):
  iv=moment(delta,k);fv=moment(full,k)
  signs.append('zero' if not key else 'negative' if iv[1]<0 else 'positive' if iv[0]>0 else 'undecided')
  gains[name]=price.decimal_interval(iv,48);balances[name]=price.decimal_interval(fv,48)
  assert check2(delta,k,iv) and check2(full,k,fv)
 out={'native_signed_histogram':simple_hist(key),'gain_36':gains,'complete_balance':balances,'signs':signs}
 catalogue[key]=out
 return out

def get_supports():
 lookup=defaultdict(list)
 for idx,r in enumerate(roster):
  pair=tuple(map(tuple,r['pair']));assert len(set(pair))==2 and tuple(sorted(pair)) in z['pairs']
  # Verify roster's complete exterior peer list against the pinned literal graph.
  for node,listed in zip(pair,r['exterior']):
   actual=defaultdict(list)
   for i in inc[node]:
    ed=edges[i];other=ed.target if ed.source==node else ed.source
    if other in pair:continue
    actual[other].append([ed.kind,ed.key,ed.grade])
   assert len(actual)==len(listed)
   for row in listed:
    p=tuple(row['peer']);assert p in actual and chart[p]==row['chart'] and rank[chart[p]]==row['rank']
    assert bool(row['movable'])==(p not in frozen)
    assert sorted(actual[p])==sorted(row['exterior_edges'])
  peers={tuple(y['peer']) for block in r['exterior'] for y in block if y['movable']} - set(pair)
  for p in peers:
   support=tuple(sorted((*pair,p)));assert len(support)==3 and all(x not in frozen for x in support)
   lookup[support].append(idx)
 return lookup

def options(node,support):
 ids=[i for i in inc[node] if (edges[i].target if edges[i].source==node else edges[i].source) not in support]
 peers=tuple(sorted({chart[edges[i].target if edges[i].source==node else edges[i].source] for i in ids}))
 out=[]
 for d in range(9):
  env=z['envelope'](peers,d)
  if env is None:continue
  h=Counter()
  for i in ids:
   ed=edges[i];a=d if ed.source==node else rank[chart[ed.source]];b=d if ed.target==node else rank[chart[ed.target]]
   if ed.kind=='targets' and b<=a:break
   z['delta'](h,ed.kind,ed.grade,abs(a-b))
  else:out.append((d,env,h))
 return peers,out

def geo(dims,envs,internal):
 # Each internal contact forces its lower-dimensional space inside the higher.
 # Propagate all necessary lower spans upwards and upper normals downwards.
 L={n:envs[n][0] for n in dims};N={n:envs[n][1] for n in dims};arcs=set()
 for i in internal:
  ed=edges[i];a,b=ed.source,ed.target
  if dims[a]<=dims[b]:arcs.add((a,b))
  if dims[a]>=dims[b]:arcs.add((b,a))
 changed=True
 while changed:
  changed=False
  for lo,hi in sorted(arcs):
   low=z['rref']((*L[hi],*L[lo]));normal=z['rref']((*N[lo],*N[hi]))
   if low!=L[hi]:L[hi]=low;changed=True
   if normal!=N[lo]:N[lo]=normal;changed=True
  for n in dims:
   if len(L[n])>dims[n] or len(N[n])>8-dims[n] or not z['orth'](L[n],N[n]):
    return {'status':'propagated-envelope-obstruction','node':list(n),'rank':dims[n],
     'required_lower_dimension':len(L[n]),'upper_normal_dimension':len(N[n]),
     'lower_orthogonal_to_upper_normals':z['orth'](L[n],N[n]),
     'required_lower_basis':z['describe_basis'](L[n]),'upper_normal_basis':z['describe_basis'](N[n]),
     'arcs':[[list(a),list(b)] for a,b in sorted(arcs)]}
 checks=[]
 for i in internal:
  ed=edges[i];a,b=ed.source,ed.target;d,e=dims[a],dims[b];ea,eb=(L[a],N[a]),(L[b],N[b])
  if d>e:d,e,ea,eb=e,d,eb,ea
  possible,why=z['dimension_test'](ea,eb,d,e)
  assert possible==(z['coupled'](ea,eb,d,e) is not None)
  checks.append({'kind':ed.kind,'key':ed.key,'possible':possible,'certificate':why})
  if not possible:return {'status':'coupled-dimension-obstruction','checks':checks}
 return {'status':'unresolved-three-way-geometry','checks':checks}

def run(support,origins):
 choices=[options(n,set(support)) for n in support]
 internal=sorted({i for n in support for i in inc[n] if edges[i].source in support and edges[i].target in support})
 assert any(edges[i].kind=='paid' for i in internal)
 counts=Counter();hcounts=Counter();positives=[]
 for combo in product(*(c[1] for c in choices)):
  dims={n:x[0] for n,x in zip(support,combo)};envs={n:x[1] for n,x in zip(support,combo)}
  h=Counter()
  for _,_,extra in combo:h.update(extra)
  for i in internal:
   ed=edges[i];a,b=dims[ed.source],dims[ed.target]
   if ed.kind=='targets' and b<=a:break
   z['delta'](h,ed.kind,ed.grade,abs(a-b))
  else:
   # Independently walk all incident edges, counting each one once.
   direct=Counter()
   for i in {i for n in support for i in inc[n]}:
    ed=edges[i];a=dims[ed.source] if ed.source in dims else rank[chart[ed.source]]
    b=dims[ed.target] if ed.target in dims else rank[chart[ed.target]]
    assert ed.kind=='paid' or b>a
    z['delta'](direct,ed.kind,ed.grade,abs(a-b))
   assert hkey(direct)==hkey(h)
   key=hkey(h);priced=price_hist(h);hcounts[key]+=1;counts['rank_assignments']+=1
   sign=tuple(priced['signs']);counts['signs:'+','.join(sign)]+=1
   if any(x in ('positive','undecided') for x in sign):
    cert=geo(dims,envs,internal);counts[cert['status']]+=1
    positives.append({'ranks':[dims[n] for n in support],'histogram_id':','.join(f'{g}:{n}' for g,n in key),
                      'price_signs':list(sign),'geometry':cert})
 return {'support':[list(n) for n in support],'originating_parent_indices':origins,'assigned_parent_index':min(origins),
  'source_charts':[chart[n] for n in support],
  'external_choices':[{'node':list(n),'fixed_peer_charts':peer,'ranks':[x[0] for x in opts]} for n,(peer,opts) in zip(support,choices)],
  'internal_edges':[{'kind':edges[i].kind,'key':edges[i].key,'source':list(edges[i].source),'target':list(edges[i].target),'old_grade':edges[i].grade} for i in internal],
  'counts':dict(counts),'histogram_occurrences':{','.join(f'{g}:{n}' for g,n in k):c for k,c in sorted(hcounts.items())},
  'positive_or_undecided_cases':positives}

baseline=baseline_replay()
all_supports=get_supports();indices=list(range(50))
assert len(all_supports)==372
todo=sorted(((key,sorted(value)) for key,value in all_supports.items() if min(value) in indices),key=lambda x:(min(x[1]),x[0]))
out=[]
for j,(support,origins) in enumerate(todo,1):
 out.append(run(support,origins))
 print(f'{j}/{len(todo)} parent={min(origins)}',file=sys.stderr,flush=True)
summary=Counter()
for record in out:summary.update(record['counts'])
assert len(out)==372 and summary==Counter({'rank_assignments':38860,'signs:negative,negative,negative':37990,
 'signs:zero,zero,zero':372,'signs:positive,positive,positive':498,'propagated-envelope-obstruction':498})
# Independently requested packet-2947 four-third control is a subset of the full run.
special=[r for r in out if 0 in r['originating_parent_indices'] and
 {(-680,'out'),(2669,'in')}<=set(map(tuple,r['support']))]
sc=Counter()
for row in special:sc.update(row['counts'])
assert len(special)==4 and sc==Counter({'rank_assignments':624,'signs:negative,negative,negative':608,
 'signs:zero,zero,zero':4,'signs:positive,positive,positive':12,'propagated-envelope-obstruction':12})
result={'status':'PASS_ALL_372_FIXED_INCIDENCE_TRIPLE_PRICE_EXCLUSIONS',
 'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'prior_pair_screen_pr_7881_head':'c2d6b3bae2e0b0fed3dd24b3166e3df1b833249c',
 'scope':'Triples from movable exterior neighbors of the 50 rejected positive pair supports, globally deduplicated and assigned by smallest parent index. Exactly three components released; arbitrary rational subspaces; fixed packet forms, remaining charts and productive orientations. Equal paid contacts priced optimistically free. Pairwise and propagated certificates are necessary; any survivor is unresolved.',
 'selected_parent_indices':indices,'global_unique_triples':len(all_supports),'selected_supports':len(out),'counts':dict(summary),
 'predecessor_all_968_pair_replay':'exact byte match with source/ARBITRARY.json',
 'packet_2947_control':{'supports':len(special),'counts':dict(sc)},
 'baseline_operator_and_ownership':baseline,
 'baseline_signed_balance':{name:check2(base,k,moment(base,k)) for k,name in enumerate(KN)},
 'histogram_catalogue':{','.join(f'{g}:{n}' for g,n in key):value for key,value in sorted(catalogue.items())},
 'supports':out}
print(json.dumps(result,sort_keys=True,indent=2))
