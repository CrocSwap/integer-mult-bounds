#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Pinned P104 BIT three-component external-price and geometry screen.

Reads the adjacent-pair source package in ./source. Equal paid charts are
optimistically charged zero: no changed word is claimed. For each of two
supports, enumerate every exterior-compatible rank triple, price all affected
edges once and reject each positive case by a necessary pairwise dimension
bound. Run the unchanged native and 36-call operator/invoice controls.
"""
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
import json

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'source'
arbitrary=SRC/'arbitrary.py'
assert sha256(arbitrary.read_bytes()).hexdigest()=='b53b46c492860707b95e801c92b6bbf0608e5aa5061bd4fd5114fb28f27eacd9'
assert sha256((SRC/'ARBITRARY.json').read_bytes()).hexdigest()=='10108d252c3648031a138d4f6269705e6d33684e9647fd0bd3a9515ae38182f0'
code=arbitrary.read_text().split('\nout=[]\nfor i,p in enumerate(pairs[:N],1):')
assert len(code)==2
z={'__file__':str(arbitrary)}
exec(compile(code[0],str(arbitrary),'exec'),z)
v=z['v']; op=v.op; price=z['price']; t=z['t']; edges=t.edges; chart=t.charts; rank=t.rank; inc=t.incident
A=(-342,'out');B=(741,'in'); THIRDS=[(969,'in'),(970,'in')]
assert sha256(json.dumps(z['pairs'],separators=(',',':')).encode()).hexdigest()==v.PAIR_SHA
assert (A,B) in z['pairs'] and all(c not in z['frozen'] for c in THIRDS)
parent=json.loads((SRC/'ARBITRARY.json').read_text())
hits=[x for x in parent['positive_exclusion_certificates'] if x['pair']==[list(A),list(B)]]
assert len(hits)==1 and hits[0]['dimensions']==[5,4]
KAPPA=[F('0.003879928046155'),F('0.003879929046155')]
NAMES={KAPPA[0]:'0.003879928046155',KAPPA[1]:'0.003879929046155'}

@lru_cache(None)
def directed_power(g,k):return v.power_bounds(g,1-k)

def signed(hist,k):
 lo=hi=F(0)
 for g,n in hist.items():
  if not g or not n:continue
  low,high=directed_power(g,k)
  lo+=n*(low if n>0 else high);hi+=n*(high if n>0 else low)
 return lo,hi

def moment_check(hist,k):
 a,b=signed(hist,k); c,d=price.moment(hist,k)
 assert F(c,price.GRID)<=b and a<=F(d,price.GRID)
 return v.decimals((a,b))

def hist(h):return {str(g):h[g] for g in sorted(h) if g and h[g]}
def basis(b):return z['describe_basis'](b)
def node_record(node,released):
 rows=[]
 for i in inc[node]:
  e=edges[i];peer=e.target if e.source==node else e.source
  rows.append({'kind':e.kind,'key':e.key,'direction':'out' if e.source==node else 'in',
   'other':list(peer),'other_chart':chart[peer],'other_rank':rank[chart[peer]],
   'old_grade':e.grade,'internal':peer in released})
 return {'node':list(node),'chart':chart[node],'rank':rank[chart[node]],'incidences':rows}

def options(node,released):
 ids=[i for i in inc[node] if (edges[i].target if edges[i].source==node else edges[i].source) not in released]
 peers=tuple(sorted({chart[edges[i].target if edges[i].source==node else edges[i].source] for i in ids}))
 choices=[]
 for d in range(9):
  bound=z['envelope'](peers,d)
  if bound is None:continue
  h=Counter()
  for i in ids:
   ed=edges[i];a=d if ed.source==node else rank[chart[ed.source]];b=d if ed.target==node else rank[chart[ed.target]]
   if ed.kind=='targets' and b<=a:break
   z['delta'](h,ed.kind,ed.grade,abs(a-b))
  else:choices.append((d,bound,h))
 return peers,choices

def recount_baseline():
 w=z['w']; caller=v.read('inputs/EFREE-CALLER.json.gz'); receipt=v.read('inputs/BIT.json')
 assert sha256(v.canon(w)).hexdigest()==v.WORD
 assert sha256(v.canon({k:w[k] for k in ('frames','start','final')})).hexdigest()==v.LAYOUT
 atlas=op.Atlas(w['frames']);assert atlas.main_contacts(w['start'],w['final'])==111
 fwd,adj,omitted=op.native_checks(w,atlas)
 np,nt,paid,targets=op.binary_invoice(w,caller,atlas,fwd)
 for actual,name in [(np,'native_paid'),(nt,'native_targets'),(paid,'paid'),(targets,'targets')]:
  assert actual==Counter({int(k):n for k,n in receipt['native'][name].items()})
 ordinary=op.ordinary_boundary(w,caller,paid,targets)
 assert sum(paid.values())==107460 and sum(targets.values())==20706
 overall=targets.copy();overall.subtract(paid)
 return overall,{'word_sha256':v.WORD,'layout_sha256':v.LAYOUT,
  'native_coefficients_per_orientation':680**2,'caller_coefficients_per_orientation':38**2,
  'native_paid':hist(np),'native_targets':hist(nt),'complete_paid':hist(paid),'complete_targets':hist(targets),
  'dirty_retirements_forward_adjoint':[fwd.dirty,adj.dirty],'protected_owner_411_omission_add_clock':omitted,
  'main_contacts':111,'ordinary':ordinary,'signed_balance':{NAMES[k]:moment_check(overall,k) for k in KAPPA}}

def screen(third,baseline):
 support=[A,B,third];released=set(support);o=[options(n,released) for n in support]
 inedges=sorted({i for n in support for i in inc[n] if edges[i].source in released and edges[i].target in released})
 assert len(inedges)==2 and all(edges[i].kind=='paid' for i in inedges)
 entries=[];counts=Counter();positive=[]
 for combo in product(*(x[1] for x in o)):
  dims={n:c[0] for n,c in zip(support,combo)}; env={n:c[1] for n,c in zip(support,combo)}
  h=Counter()
  for _,_,value in combo:h.update(value)
  for i in inedges:
   ed=edges[i];a,b=dims[ed.source],dims[ed.target]
   assert ed.kind=='paid' or b>a
   z['delta'](h,ed.kind,ed.grade,abs(a-b))
  clean=Counter({g:n for g,n in h.items() if g and n});full=baseline.copy()
  direct=Counter()
  for ed in edges:
   if ed.source not in released and ed.target not in released:continue
   a=dims[ed.source] if ed.source in released else rank[chart[ed.source]]
   b=dims[ed.target] if ed.target in released else rank[chart[ed.target]]
   assert ed.kind=='paid' or b>a
   z['delta'](direct,ed.kind,ed.grade,abs(a-b))
  assert z['norm'](direct)==z['norm'](clean)
  for g,n in clean.items():full[g]+=36*n
  gains={};balances={};signs=[]
  for k in KAPPA:
   g=signed(Counter({r:36*n for r,n in clean.items()}),k)
   gains[NAMES[k]]=moment_check(Counter({r:36*n for r,n in clean.items()}),k)
   balances[NAMES[k]]=moment_check(full,k)
   signs.append('zero' if not clean else 'negative' if g[1]<0 else 'positive' if g[0]>0 else 'undecided')
  assert len(set(signs))==1 and signs[0]!='undecided'
  sign=signs[0];counts[sign]+=1
  entry={'ranks':[dims[n] for n in support],'native_signed_histogram':hist(clean),
         'gain_36_calls':gains,'complete_36_call_balance':balances,'sign':sign}
  if sign=='positive':
   certs=[]
   for i in inedges:
    ed=edges[i];a,b=ed.source,ed.target;d,e=dims[a],dims[b]
    ea,eb=env[a],env[b]
    if d>e:d,e,ea,eb=e,d,eb,ea
    feasible,why=z['dimension_test'](ea,eb,d,e)
    assert feasible==(z['coupled'](ea,eb,d,e) is not None)
    certs.append({'packet':ed.key,'feasible':feasible,'certificate':why})
   assert any(not c['feasible'] for c in certs)
   entry['pairwise_geometry']=certs;positive.append(entry)
  entries.append(entry)
 expected=(45,43,1,1) if third==THIRDS[0] else (90,87,1,2)
 assert (len(entries),counts['negative'],counts['zero'],counts['positive'])==expected
 # Independent, explicit rank witnesses for all three positive proposals.
 byrank={n:{d:bound for d,bound,h in choices} for n,(_,choices) in zip(support,o)}
 assert byrank[third][2][0]==z['B'][chart[third]]
 LB=byrank[B][4][0];assert LB==z['B'][267]
 LA5=byrank[A][5][0];union5=z['rref']((*LA5,*LB));assert len(union5)==6
 proof={'third_rank2_forced_basis':basis(byrank[third][2][0]),
  'rank5_parent_required_exterior_basis':basis(LA5),'rank4_parent_forced_basis':basis(LB),
  'rank5_required_union_basis':basis(union5),'rank5_required_union_dimension':len(union5)}
 if third==THIRDS[1]:
  LA4=byrank[A][4][0];C2=byrank[third][2][0]
  assert LA4==z['B'][314] and len(z['rref']((*LA4,*LB)))==6 and len(z['rref']((*LA4,*C2)))==5
  proof.update({'rank4_parent_forced_basis':basis(LA4),'rank4_parent_and_rank4_peer_union_dimension':6,
   'rank4_parent_and_rank2_third_union_dimension':5})
 return {'support':[list(n) for n in support],
  'nodes_and_incident_edges':[node_record(n,released) for n in support],
  'external_envelopes':[{'node':list(n),'charts':peers,'choices':[{'rank':d,'required_lower_basis':basis(b[0]),
   'required_upper_normals':basis(b[1]),'native_external_signed_histogram':hist(h),
   'external_gain_36_calls':{NAMES[k]:moment_check(Counter({r:36*x for r,x in h.items()}),k) for k in KAPPA}} for d,b,h in choices]}
   for n,(peers,choices) in zip(support,o)],
  'internal_edges':[{'packet':edges[i].key,'source':list(edges[i].source),'target':list(edges[i].target),'old_grade':edges[i].grade} for i in inedges],
  'counts':dict(counts),'assignments':entries,'positive_geometric_obstructions':positive,'explicit_rational_rank_witnesses':proof}

base,control=recount_baseline()
out={'status':'PASS_TWO_THIRD_SUPPORTS_NO_POSITIVE_GEOMETRY',
 'scope':'Exactly the indicated three movable cochart components; all other charts and packet forms, productive orientation, protected endpoints and original chronology fixed. Rational subspaces; equal paid contacts priced optimistically free. No candidate word constructed.',
 'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','baseline':control,
 'parent_pair_reference':hits[0], 'supports':[screen(x,base) for x in THIRDS]}
print(json.dumps(out,indent=2,sort_keys=True))
