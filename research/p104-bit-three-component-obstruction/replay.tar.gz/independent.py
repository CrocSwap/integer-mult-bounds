#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Independent modular superset, full billing and price replay of RESULT.

This deliberately does not import arbitrary.py or use its rational envelopes.
All subspace tests use the original integral source rows modulo 65521. The
field tests are necessary conditions for a rational solution, so nonzero
minors and dot products are rigorous rational obstructions.
"""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
import gzip,json,sys

ROOT=Path(__file__).resolve().parent;SRC=ROOT/'source'
sys.path.insert(0,str(SRC));sys.path.insert(0,str(SRC/'vendor'))
import verify as v

result_path=ROOT/'RESULT.json.gz';result_bytes=gzip.decompress(result_path.read_bytes());reference=json.loads(result_bytes)
assert reference['status']=='PASS_ALL_372_FIXED_INCIDENCE_TRIPLE_PRICE_EXCLUSIONS'
for name,digest in v.PINS.items():assert sha256((SRC/name).read_bytes()).hexdigest()==digest
word=v.read('inputs/WORD.json.gz');assert sha256(v.canon(word)).hexdigest()==v.WORD
chart,edges,frozen,pairs,routes=v.graph(word)
rank={int(k):fr['dim'] for k,fr in word['frames'].items()}
frames=v.prepare_frames(word);P=65521
inc=defaultdict(list)
for i,(_,_,a,b) in enumerate(edges):inc[a].append(i);inc[b].append(i)
KN=['0.003879928046155','0.003879928046156','0.003879929046155'];K=list(map(F,KN))
native=v.read('inputs/BIT.json')['native']
oldp=Counter({int(k):n for k,n in native['native_paid'].items()});oldt=Counter({int(k):n for k,n in native['native_targets'].items()})
fullp=Counter({int(k):n for k,n in native['paid'].items()});fullt=Counter({int(k):n for k,n in native['targets'].items()})
assert sum(fullp.values())==107460 and sum(fullt.values())==20706

@lru_cache(None)
def power(g,k):return v.power_bounds(g,1-K[k],240)
def moment(h,k):
 lo=hi=F(0)
 for r,n in h.items():
  if not r or not n:continue
  a,b=power(r,k);lo+=n*(a if n>0 else b);hi+=n*(b if n>0 else a)
 return lo,hi
def agree(iv,printed):
 lo,hi=map(F,printed);return iv[0]<=hi and lo<=iv[1]
def hkey(h):return tuple((g,h[g]) for g in sorted(h) if g and h[g])
def hid(h):return ','.join(f'{g}:{n}' for g,n in hkey(h))
def orth(a,b):return all(sum(x*y for x,y in zip(u,w))%P==0 for u in a for w in b)

@lru_cache(None)
def modular_envelope(labels,d):
 low=[r for c in labels if rank[c]<=d for r in frames[c]['B']]
 normal=[r for c in labels if rank[c]>=d for r in frames[c]['A']]
 return v.rankmod(low)<=d and v.rankmod(normal)<=8-d and orth(low,normal)

def ext_options(node,active):
 exterior=[i for i in inc[node] if not ({edges[i][2],edges[i][3]}<=active)]
 labs=tuple(sorted({chart[edges[i][3] if edges[i][2]==node else edges[i][2]] for i in exterior}))
 choices=[]
 for d in range(9):
  if not modular_envelope(labs,d):continue
  for i in exterior:
   kind,key,a,b=edges[i];da=d if a==node else rank[chart[a]];db=d if b==node else rank[chart[b]]
   if kind=='targets' and db<=da:break
  else:choices.append(d)
 return choices

@lru_cache(None)
def price_hist(h):
 delta=Counter({g:36*n for g,n in h});signs=[];ivs=[]
 for k in range(len(K)):
  iv=moment(delta,k);ivs.append(iv)
  signs.append('zero' if not h else 'negative' if iv[1]<0 else 'positive' if iv[0]>0 else 'undecided')
 return tuple(signs),tuple(ivs)

def source_row_obstruction(dims,active):
 # Transitive closure of containment forced solely by internal rank ordering.
 reach={(a,a) for a in active}
 for kind,key,a,b in edges:
  if a in active and b in active:
   if dims[a]<=dims[b]:reach.add((a,b))
   if dims[b]<=dims[a]:reach.add((b,a))
 for _ in range(len(active)):
  reach|={(a,c) for a,b in reach for bb,c in reach if b==bb}
 low=defaultdict(list);normal=defaultdict(list)
 for kind,key,a,b in edges:
  if (a in active)==(b in active):continue
  node=a if a in active else b;other=b if a in active else a;lab=chart[other];d=dims[node]
  if rank[lab]<=d:
   low[node].extend((lab,j,row) for j,row in enumerate(frames[lab]['B']))
  if rank[lab]>=d:
   normal[node].extend((lab,j,row) for j,row in enumerate(frames[lab]['A']))
 for node in sorted(active):
  l=[v for src in sorted(active) if (src,node) in reach for v in low[src]]
  n=[v for src in sorted(active) if (node,src) in reach for v in normal[src]]
  rl=v.rankmod([r for _,_,r in l]);rn=v.rankmod([r for _,_,r in n]);d=dims[node]
  if rl>d:return {'node':list(node),'type':'required_lower_rank','rank_mod_prime':rl,'allowed':d,'lower_sources':[(a,b) for a,b,_ in l]}
  if rn>8-d:return {'node':list(node),'type':'required_normal_rank','rank_mod_prime':rn,'allowed':8-d,'normal_sources':[(a,b) for a,b,_ in n]}
  for la,li,lv in l:
   for na,ni,nv in n:
    dot=sum(x*y for x,y in zip(lv,nv))%P
    if dot:return {'node':list(node),'type':'nonorthogonal','lower_row':[la,li],'normal_row':[na,ni],'dot_mod_prime':dot}
 raise AssertionError('no modular obstruction, rational certificate requires separate examination')

def direct_bill(dims,reverse=False):
 paid=Counter();target=Counter();h=Counter()
 for kind,key,a,b in (reversed(edges) if reverse else edges):
  da=dims.get(a,rank[chart[a]]);db=dims.get(b,rank[chart[b]])
  if kind=='targets':assert db>da
  old=abs(rank[chart[a]]-rank[chart[b]]);new=abs(da-db)
  if new:(paid if kind=='paid' else target)[new]+=1
  if a in dims or b in dims:
   s=1 if kind=='targets' else -1
   if old:h[old]-=s
   if new:h[new]+=s
 return paid,target,hkey(h)

def full_bill(p,t):
 pp=fullp.copy();tt=fullt.copy();dp=p.copy();dt=t.copy();dp.subtract(oldp);dt.subtract(oldt)
 for g,n in dp.items():pp[g]+=36*n
 for g,n in dt.items():tt[g]+=36*n
 return pp,tt

def run(rec):
 nodes=tuple(map(tuple,rec['support']));active=set(nodes);assert len(active)==3 and not(active & frozen)
 options=[ext_options(n,active) for n in nodes]
 assert options==[entry['ranks'] for entry in rec['external_choices']]
 touch=sorted({i for n in nodes for i in inc[n]});counts=Counter();cases=[];hcounts=Counter()
 for ds in product(*options):
  dims=dict(zip(nodes,ds));h=Counter()
  for i in touch:
   kind,key,a,b=edges[i];da=dims.get(a,rank[chart[a]]);db=dims.get(b,rank[chart[b]])
   if kind=='targets' and db<=da:break
   old=abs(rank[chart[a]]-rank[chart[b]]);new=abs(da-db);s=1 if kind=='targets' else -1
   if old:h[old]-=s
   if new:h[new]+=s
  else:
   counts['rank_assignments']+=1;key=hkey(h);hcounts[hid(h)]+=1
   signs,ivs=price_hist(key);counts['signs:'+','.join(signs)]+=1
   tab=reference['histogram_catalogue'][hid(h)]
   assert list(signs)==tab['signs']
   for k,name in enumerate(KN):assert agree(ivs[k],tab['gain_36'][name])
   if any(s in ('positive','undecided') for s in signs):
    assert signs==('positive',)*len(K)
    certificate=source_row_obstruction(dims,active)
    pa,ta,ha=direct_bill(dims);pb,tb,hb=direct_bill(dims,True)
    assert (pa,ta,ha)==(pb,tb,hb) and ha==key
    fp,ft=full_bill(pa,ta);signed=ft.copy();signed.subtract(fp)
    balances={}
    for k,name in enumerate(KN):
     iv=moment(signed,k);assert agree(iv,tab['complete_balance'][name]);balances[name]=v.decimals(iv)
    counts['modular_obstruction']+=1
    cases.append({'ranks':list(ds),'histogram_id':hid(h),'certificate':certificate,
     'complete_paid':dict(fp),'complete_targets':dict(ft),'complete_balance':balances})
 assert dict(hcounts)==rec['histogram_occurrences']
 want=Counter(rec['counts']);wanted=want.pop('propagated-envelope-obstruction',0)
 assert wanted==counts['modular_obstruction']
 actual=counts.copy();actual.pop('modular_obstruction',None);assert actual==want
 assert {(tuple(c['ranks']),c['histogram_id']) for c in cases}=={
  (tuple(c['ranks']),c['histogram_id']) for c in rec['positive_or_undecided_cases']}
 return {'support':rec['support'],'originating_parent_indices':rec['originating_parent_indices'],
         'counts':dict(counts),'positive_cases':cases}

out=[]
for i,rec in enumerate(reference['supports'],1):
 out.append(run(rec))
 if i%32==0:print(f'independent modular {i}/{len(reference["supports"])}',file=sys.stderr,flush=True)
summary=Counter()
for row in out:summary.update(row['counts'])
assert summary==Counter({'rank_assignments':38860,'signs:negative,negative,negative':37990,
 'signs:zero,zero,zero':372,'signs:positive,positive,positive':498,'modular_obstruction':498})
packet=[row for row in out if 0 in row['originating_parent_indices'] and
 {(-680,'out'),(2669,'in')}<=set(map(tuple,row['support']))]
packet_total=Counter()
for row in packet:packet_total.update(row['counts'])
assert len(packet)==4 and packet_total['rank_assignments']==624 and packet_total['modular_obstruction']==12
value={'status':'PASS_372_INDEPENDENT_MODULAR_SUPERSET_AND_FULL_BILLING',
 'reference_result_sha256':sha256(result_bytes).hexdigest(),
 'scope':'Independent modular exterior-rank superset and source-row obstruction checks; direct whole-graph native forward/reverse billing for every price-positive rank triple, complete 36-call paid and target profiles, and 240-bit directed root pricing. This does not replay a changed physical word.',
 'prime':P,'counts':dict(summary),'packet_2947_control':{'supports':4,'counts':dict(packet_total)},
 'obstruction_types':dict(Counter(case['certificate']['type'] for row in out for case in row['positive_cases'])),
 'supports':out}
print(json.dumps(value,indent=2,sort_keys=True))
