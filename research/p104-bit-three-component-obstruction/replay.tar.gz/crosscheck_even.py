#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Compare the separate even-shard and packet-2947 receipts with this package."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
import gzip,json

HERE=Path(__file__).resolve().parent
def raw(p):return gzip.decompress((HERE/p).read_bytes())
def read(p):return json.loads(raw(p))
main=read('RESULT.json.gz');audit=read('INDEPENDENT.json.gz')
even=read('controls/EVEN-25.json.gz');mod=read('controls/EVEN-INDEPENDENT.json.gz')
packet=read('controls/PACKET2947-INDEPENDENT.json.gz')
def key(s):return tuple(tuple(x) for x in s)
mainmap={key(x['support']):x for x in main['supports']}
auditmap={key(x['support']):x for x in audit['supports']}
modmap={key(x['support']):x for x in mod['results']}
def overlap(a,b):
 x,y=map(F,a);u,w=map(F,b);return x<=w and u<=y

assert len(even['supports'])==len(modmap)==187
count=0
for old in even['supports']:
 s=key(old['support']);new=mainmap[s];ind=auditmap[s];im=modmap[s]
 assert old['origin_indices']==new['originating_parent_indices']==im['origin_indices']
 assert old['rank_options']==[q['ranks'] for q in new['external_choices']]
 oldc=old['counts'];newc=new['counts']
 assert (oldc['exterior_feasible_rank_assignments'],oldc['strict_negative_both_trials'],oldc['zero_histogram'],
         oldc['positive_possible_at_some_trial'],oldc['excluded_by_necessary_geometry'])==(
  newc['rank_assignments'],newc['signs:negative,negative,negative'],newc['signs:zero,zero,zero'],
  newc['signs:positive,positive,positive'],newc['propagated-envelope-obstruction'])
 assert not old['positive_after_necessary_geometry']
 index={tuple(x['ranks']):x for x in new['positive_or_undecided_cases']}
 ix={tuple(x['ranks']):x for x in ind['positive_cases']}
 mi={tuple(x['dimensions']):x for x in im['certificates']}
 assert len(index)==len(ix)==len(mi)==len(old['rejected_positive'])
 for c in old['rejected_positive']:
  ranks=tuple(c['dimensions']);a=index[ranks];b=ix[ranks];m=mi[ranks]
  expected={str(k):v for k,v in c['native_signed_hist'].items()}
  assert main['histogram_catalogue'][a['histogram_id']]['native_signed_histogram']==expected
  assert b['histogram_id']==a['histogram_id'] and {str(k):v for k,v in m['histogram'].items()}==expected
  assert {str(k):v for k,v in c['full_invoice']['paid'].items()}=={str(k):v for k,v in b['complete_paid'].items()}
  assert {str(k):v for k,v in c['full_invoice']['targets'].items()}=={str(k):v for k,v in b['complete_targets'].items()}
  for trial in c['gains']:
   assert overlap(c['gains'][trial],main['histogram_catalogue'][a['histogram_id']]['gain_36'][trial])
  count+=1
assert count==257

packet_count=0
for case in packet['cases']:
 nodes=[(-680,'out'),(2669,'in'),tuple(case['third'])];dims=dict(zip(nodes,case['dimensions']))
 support=tuple(sorted(nodes));ranks=tuple(dims[x] for x in support)
 primary=next(c for c in mainmap[support]['positive_or_undecided_cases'] if tuple(c['ranks'])==ranks)
 expected={str(k):v for k,v in case['native_signed_hist'].items()}
 assert main['histogram_catalogue'][primary['histogram_id']]['native_signed_histogram']==expected
 for trial,iv in case['gains'].items():assert overlap(iv,main['histogram_catalogue'][primary['histogram_id']]['gain_36'][trial])
 packet_count+=1
assert packet_count==12
print(json.dumps({'status':'PASS_INDEPENDENT_EVEN_AND_PACKET_2947_RECEIPT_COMPARISON',
 'even_supports':187,'even_positive_cases':count,'packet_2947_positive_cases':packet_count,
 'uncompressed_controls_sha256':{p:sha256(raw(p)).hexdigest() for p in (
  'controls/EVEN-25.json.gz','controls/EVEN-INDEPENDENT.json.gz','controls/PACKET2947-INDEPENDENT.json.gz')}},indent=2,sort_keys=True))
