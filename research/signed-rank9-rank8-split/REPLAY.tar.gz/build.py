"""Transfer the #7107 retimed rank-eight split to the exact #7108 word."""

from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import gzip
import json
import sys

OLD = "34085a6c502ac07530001bdcbc85ad0ec9637f5dda28c9593a0b0d6dd6613d24"
AUDIT = "c7d81ad6620de5e46abf97259f62da0138b58a02759c3189e57b8ab176db6bd5"
CUT, MOVE, PIVOT, FRESH = 37412, 38784, 1468, 1481
LO, HI = 37403, 39691
G = [(PIVOT, 533, 1), (PIVOT, 1251, 4), (PIVOT, 1454, -2)]
J = [(533, PIVOT, -1), (843, PIVOT, 1), (PIVOT, 533, 1), (PIVOT, 1454, -2)]
A = {533: Q(1), 1454: Q(-2)}
B = {533: Q(1), PIVOT: Q(1), 843: Q(-1)}
C = {533: Q(1), 1251: Q(4), PIVOT: Q(1), 1454: Q(-2)}


def operands(event):
    return (1, 2) if event[0] in ("ADD", "COPY") else (1,)


def inverse(seq):
    return [(r, s, -v) for r, s, v in reversed(seq)]


def adds(seq, frame):
    return [["ADD", r, s, str(q), frame] for r, s, q in seq]


def substituted(event, after):
    out = event.copy()
    for k in operands(event):
        if out[k] >= FRESH:
            out[k] += 1
        elif after and out[k] == PIVOT:
            out[k] = FRESH
    return out


def put(v, k, a):
    if a:
        v[k] = a
    else:
        v.pop(k, None)


def cut_proof(old):
    """Independently evaluate one exact prefix row and one suffix column."""
    seq = old["program"]
    a = A.copy()
    for e in reversed(seq[:CUT]):
        op, r = e[:2]
        value = a.get(r, 0)
        if op in ("INIT", "CLEAR"):
            a.pop(r, None)
        elif value and op == "SCALE":
            put(a, r, Q(e[2]) * value)
        elif value and op in ("ADD", "COPY"):
            s = e[2]
            put(a, s, a.get(s, 0) + Q(e[3]) * value)
            if op == "COPY":
                a.pop(r, None)
    assert a == C
    b = B.copy()
    for e in seq[CUT:]:
        op, r = e[:2]
        if op in ("INIT", "CLEAR"):
            b.pop(r, None)
        elif op == "SCALE":
            put(b, r, b.get(r, 0) * Q(e[2]))
        elif op in ("ADD", "COPY"):
            put(b, r, (b.get(r, 0) if op == "ADD" else 0) + Q(e[3]) * b.get(e[2], 0))
    assert b == {PIVOT: Q(1)}
    assert sum(v * B.get(i, 0) for i, v in A.items()) == C[PIVOT] == 1
    assert all(old["initial"][i] == 3 and old["final"][i] == 245 for i in C)
    return {"prefix": {i: str(v) for i, v in a.items()}, "suffix": {i: str(v) for i, v in b.items()}}


def build(old):
    assert old["public"] == FRESH
    seq = old["program"]
    assert seq[MOVE] == ["MOVE", 533, 3, 747, False]
    assert [i for i in range(LO, HI) if any(seq[i][k] == 533 for k in operands(seq[i]))] == [MOVE]
    first = adds(inverse(G), 3)
    middle = [["MOVE", 533, 3, 745, False], *adds(J, 745),
              *(substituted(e, True) for e in adds(inverse(J), 745)), ["MOVE", 533, 745, 747, False]]
    last = [substituted(e, True) for e in adds(G, 245)]
    tagged = [(-100-i, e) for i, e in enumerate(first)]
    for i, e in enumerate(seq):
        if i == CUT:
            tagged.extend((-200-k, e) for k, e in enumerate(middle))
        if i != MOVE:
            tagged.append((i, substituted(e, i >= CUT)))
    tagged.extend((-300-i, e) for i, e in enumerate(last))
    final = [*old["final"], 245]
    final[PIVOT] = 745
    return dict(old, public=FRESH+1, initial=[*old["initial"], 745],
                final=final, program=[e for _, e in tagged]), tagged, first, middle, last


def main(old_path, audit_path, out):
    raw = gzip.decompress(old_path.read_bytes())
    assert sha256(raw).hexdigest() == OLD
    assert sha256(audit_path.read_bytes()).hexdigest() == AUDIT
    old = json.loads(raw)
    witness = cut_proof(old)
    new, tagged, first, middle, last = build(old)
    spec = spec_from_file_location("rank8_grid", audit_path)
    audit = module_from_spec(spec)
    sys.modules[spec.name] = audit
    spec.loader.exec_module(audit)
    a, old_grid = audit.replay(old, list(enumerate(old["program"])), set())
    b, grid = audit.replay(new, tagged, set())
    expected = [*a[0][:FRESH], {FRESH: 1125 * 2**24}]
    assert b[0][:FRESH+1] == expected
    paid = Counter(grid["paid"])
    paid.subtract(old_grid["paid"])
    assert {r: v for r, v in paid.items() if v} == {3: 2, 6: -1}
    assert all(old_grid[k] == grid[k] for k in ("owned_peak", "owned_lifetimes", "owned_rise_mass", "odd_grid_lcm"))
    assert all((*x[:2], x[2]+1) == y for x, y in zip(a[4], b[4], strict=True))
    payload = json.dumps(new, sort_keys=True, separators=(",", ":")).encode()
    out.write_bytes(gzip.compress(payload, mtime=0))
    print(json.dumps(dict(status="PASS_RANK8_RETIMER_NATIVE_GRID", original=OLD,
                          word_sha256=sha256(payload).hexdigest(), cut=CUT, moved_event=MOVE,
                          prefix_edits=first, cut_edits=middle, suffix_edits=last,
                          witness=witness, grid=grid, old_grid=old_grid), sort_keys=True, indent=2))


if __name__ == "__main__":
    assert __debug__
    main(*(Path(x) for x in sys.argv[1:]))
