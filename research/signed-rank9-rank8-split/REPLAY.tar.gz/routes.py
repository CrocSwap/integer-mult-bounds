"""Check all changed native chart columns and the unchanged signed caller routes."""
from contextlib import redirect_stdout
from io import StringIO
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

from build import CUT, OLD, substituted
from gate import CALLER, NEW, module


def word(path, pin):
    raw = gzip.decompress(path.read_bytes())
    assert sha256(raw).hexdigest() == pin
    return json.loads(raw)


def main(replay, rank9, old_path, new_path, caller_path):
    old, new = word(old_path, OLD), word(new_path, NEW)
    assert sha256(caller_path.read_bytes()).hexdigest() == CALLER
    vendor = replay / "research/shared-wire-split-composition"
    # Compare owned MOVE labels in the new coordinate convention.
    renamed = []
    for i, e in enumerate(old["program"]):
        renamed.append(substituted(e, i >= CUT))
    old = dict(old, program=renamed)
    maps = module("retimed_helper_maps", replay / "research/helper-boundary-rechart/helper_maps.py", (
        ("if helpers.keys() != old_helpers.keys():",
         "if helpers.keys() - old_helpers.keys() != {old['public']} or old_helpers.keys() - helpers.keys():"),
        ("pair != old_helpers[r]", "pair != old_helpers.get(r)"),
        ("[[r, *old_helpers[r], *pair]", "[[r, *old_helpers.get(r, ()), *pair]"),
    ))
    helper = maps.audit(old, new, vendor)
    assert helper["changed_helper_fields"] == [[1468, 3, 245, 3, 745], [1481, 745, 245]]
    assert {tuple(row["pair"]) for row in helper["changed_maps"]} == {(3, 745), (745, 747), (745, 245)}
    assert all(row["exact_columns"] == 512 and row["wrong_phase_rejected"] for row in helper["changed_maps"])
    assert helper["helper_fields"] == 1082
    assert helper["ordinary_maps_per_local"] == 2164

    sys.path.insert(0, str(rank9))
    physical = module("retimed_signed_routes", rank9 / "physical_child.py", (("cca66a7ec924bab47ccd1410968d16e071a01dc6110b5c08040bd207f753d066", NEW),))
    out = StringIO()
    with redirect_stdout(out):
        physical.main(new_path, vendor / "data/caller.json", caller_path)
    signed = json.loads(out.getvalue())
    assert signed["status"] == "PASS_PHYSICAL_RANK9_ALGEBRA"
    assert signed["word_sha"] == NEW and signed["proposed_sha"] == CALLER
    assert signed["paid_calls"] == 32
    assert 1000 * sum(len(x["caller_fields"])*x["ordinary_elementary_units"] for x in signed["bindings"]) == 1168000
    print(json.dumps(dict(status="PASS_RANK8_SPLIT_CHANGED_CHARTS_AND_SIGNED_ROUTES", helper=helper,
                          signed=signed), sort_keys=True))


if __name__ == "__main__":
    assert __debug__
    main(*(Path(p) for p in sys.argv[1:]))
