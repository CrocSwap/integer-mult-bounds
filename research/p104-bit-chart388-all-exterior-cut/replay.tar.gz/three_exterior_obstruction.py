#!/usr/bin/env python3
"""Rule out <=3 exterior recodes in the named side-recovery model.
Combines machine-checked 4-terminal reach covers, the exact 2194 source
obstruction, and chart-568 h demand. Exterior outputs are arbitrary causal
linear functions of their six respective retained source inputs.
"""
import json,itertools,sys
from collections import Counter
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R/'source/vendor'))
import binary_operator as op
from dual_donor_gate import model,n,mask,h,w
from triple_fullvector_gate import run,forms,banks
cover=json.loads((R/'exterior_lower_bound.json').read_bytes())
assert cover['necessary_covers']['1496']['only_minimum_cover']==[2021,2022,2025]
assert cover['necessary_covers']['1497']['only_minimum_cover']==[2189,2191,2194]
A={2021,2022,2025};B={2189,2191,2194};packets=list(range(2021,2027))+list(range(2189,2195))
for ext in packets:
 b,f,g=model(ext)
 assert g[568]==[154]
 assert all(((f[p]>>n) in (0,8) and not (f[p]&mask&h).bit_count()%2) for p in b[568])
 assert any((f[p]>>n)==8 for p in b[568])
 assert not 568 in cover['exterior_reach'][str(ext)]
b,f,_=model(2021)
assert (f[2023]>>n)==0 and not (f[2023]&mask&h).bit_count()%2
assert (f[2190]>>n)==2 and not (f[2190]&mask&h).bit_count()%2
# 630,635 each see only 2194, independent of both donor values.
assert all((forms[p]>>n) in (0,16) for c in (630,635) for p in banks[c])
forced_info=run(0)['signals']['2194'];assert forced_info['dimension']==0 and forced_info['condition_charts']==[630,635]
forced=sum(1<<i for i in forced_info['offset_support'])
a=op.Atlas(w['frames']);old=op.run_tape(w,a,False)
assert forced==old.packets[2194].arrival.row and (forced>>43)&1 and not (forced&h).bit_count()%2
other=[x for x in old.stock[311] if x.label!=1497]
assert len(other)==5 and all(not (x.row&h).bit_count()%2 and not (x.row>>43&1) for x in other)
counts=Counter()
for k in range(4):
 for combo in itertools.combinations(packets,k):
  chosen=set(combo)
  for h6,h7 in itertools.product((0,1),repeat=2):
   if h6 and not A<=chosen:counts['1496_terminal_cover']+=1;continue
   if h7 and not B<=chosen:counts['1497_terminal_cover']+=1;continue
   if h7:
    assert chosen==B and not h6
    counts['2194_source_obstruction']+=1;continue
   # 1497 has h=0. If 1496 has h=1, the only possible <=3 cover is A,
   # which changes neither 2023 nor 2190. Otherwise both exterior sources
   # are h-zero, so any causal recodes are h-zero. In each case 388 is h-zero.
   if h6:assert chosen==A and 2023 not in chosen and 2190 not in chosen
   counts['chart_568_h_obstruction']+=1
assert sum(counts.values())==4*sum(1 for k in range(4) for _ in itertools.combinations(packets,k))
print(json.dumps(dict(maximum_changed_exterior_sends=3,available_exterior_sends=packets,independent_donor_h_states=4,combinations_checked=sum(counts.values()),disposition_counts=dict(counts),source_receipt='630 and 635 uniquely force 2194 original; the other five 311 inputs are h-zero and lack x43',receiver_receipt='owner 154 at 568 needs h=1 and its only variable is 2583; on uncovered paths 388 has only h-zero inputs',model='919→158, 923 locally restored, 927 removed, 1495=x321, extra 0→160 x527, 1496/1497 any local stock combination, 1498/remaining exteriors frozen'),indent=2,sort_keys=True))
