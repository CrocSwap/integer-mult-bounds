#!/usr/bin/env python3
"""Original positive control and conditional paid histogram arithmetic."""
import json,sys
from pathlib import Path
from collections import Counter
R=Path(__file__).parent;sys.path.insert(0,str(R/'source/vendor'));sys.path.insert(0,str(R/'source'))
import binary_operator as op
import common
w=op.load_json(R/'source/inputs/WORD.json.gz',op.WORD_GZIP,True)
c=op.load_json(R/'source/inputs/EFREE-CALLER.json.gz',op.CALLER,True)
a=op.Atlas(w['frames']);forward,reverse,bridge_omit=op.native_checks(w,a)
native_paid,native_productive,paid,prod=op.binary_invoice(w,c,a,forward)
W0,caller,_,_,_,paid0,prod0,rat=common.baseline();assert dict(paid)==paid0 and dict(prod)==prod0
r=common.D('0.00388');base=common.moment(paid,prod,r)
delta=common.scale(common.moment({2:2},{1:1,5:1},r),36)
trial=common.plus(base,delta)
print(json.dumps(dict(rate=str(r),native_canonical=op.canonical_hash(w),binary_base=common.display(base),conditional_36_call_gain=common.display(delta),conditional_binary_margin=common.display(trial),native_paid_delta={'1':-1,'2':2,'5':-1},original_forward_and_adjoint=True,bridge_owner=411,bridge_packet=3553,bridge_add_clock=bridge_omit,bridge_omission_control=True,original_caller_forward_and_adjoint=True,original_productive_unchanged_only_if_endpoints_unchanged=True,conditional_only=True),indent=2,sort_keys=True))
