#!/usr/bin/env python3
"""Prove a 3-exterior-send necessary lower bound for h-visible donor recodes.

In the same side-recovery model, retain the eight terminal witnesses that
independently see only 1496 or only 1497. Each of the eight h-nonzero choices
for either donor fails each of its four target memberships. Determine exact
original propagation of each 283/311 paid output into those eight stocks;
even granting arbitrary payloads, <=2 changed outputs cannot reach all four
witnesses for either donor. Downstream fixed equations are linear, so the
union of individual reach sets upper-bounds their simultaneous influence.
"""
import itertools,json,sys
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R))
from dual_donor_gate import model,n,mask,source,h,bits,expected

def add(b,x):
 while x:
  p=(x&-x).bit_length()-1
  if p not in b:b[p]=x;return
  x^=b[p]
def reduce(b,x):
 for p in sorted(b):
  if x>>p&1:x^=b[p]
 return x
def separator(b,target):
 rem=reduce(b,target)
 if not rem:return None
 free=(rem&-rem).bit_length()-1;assert free not in b
 out=1<<free
 for p in sorted(b,reverse=True):
  if (out&b[p]).bit_count()%2:out|=1<<p
 assert all(not (out&v).bit_count()%2 for v in b.values()) and (out&target).bit_count()%2
 return out

witnesses={1496:((553,139),(581,167),(594,180),(625,211)),1497:((600,186),(605,191),(630,216),(635,221))}
packets=list(range(2021,2027))+list(range(2189,2195));banks,forms,groups=model(2023)
receipts={}
for donor,items in witnesses.items():
 tag=1 if donor==1496 else 2;other=3^tag;rows=[]
 for code in range(16):
  chosen=0
  for i,v in enumerate(source):
   if code>>i&1:chosen^=v
  if not (h&chosen).bit_count()%2:continue
  proof=[]
  for chart,owner in items:
   assert owner in groups[chart]
   scope=0
   for p in banks[chart]:scope|=forms[p]>>n
   assert scope==tag and not scope&other
   b={}
   for p in banks[chart]:
    f=forms[p];add(b,(f&mask)^(chosen if (f>>n)&tag else 0))
   sep=separator(b,expected[owner]);assert sep is not None
   proof.append(dict(chart=chart,owner=owner,stock_ids=banks[chart],separator=bits(sep)))
  rows.append(dict(code=code,source_support=bits(chosen),proof=proof))
 assert len(rows)==8;receipts[str(donor)]=rows
reach={}
for p in packets:
 b,f,_=model(p)
 reach[str(p)]=[chart for items in witnesses.values() for chart,owner in items if any((f[q]>>n)&4 for q in b[chart])]
mincovers={}
for donor,items in witnesses.items():
 needed={c for c,_ in items};covers=[]
 for k in range(1,len(packets)+1):
  for choice in itertools.combinations(packets,k):
   union=set().union(*(set(reach[str(p)]) for p in choice))
   if needed<=union:covers.append(list(choice))
  if covers:break
 assert k==3 and len(covers)==1
 mincovers[str(donor)]={'minimum_exterior_outputs_to_change':k,'only_minimum_cover':covers[0]}
print(json.dumps(dict(model='919→158, 923 restored, 927 deleted, 1495=x321, extra 0→160 x527, 1496/1497 independent, 1498 frozen',witnesses=receipts,exterior_reach=reach,necessary_covers=mincovers),indent=2,sort_keys=True))
