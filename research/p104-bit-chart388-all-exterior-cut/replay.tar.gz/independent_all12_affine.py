#!/usr/bin/env python3
"""Independent low-pivot nullspace audit of the two forced exterior values.
Reinterprets the raw tape, does not import the main affine/trace checker, and
solves 680 binary affine equations for each send's full original vector.
"""
import gzip,hashlib,json
from collections import defaultdict
from pathlib import Path
R=Path(__file__).parent
raw=(R/'source/inputs/WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));n=w['public'];assert n==680
mask=(1<<n)-1;h=sum(1<<i for i in (43,320,321,322,323))
names=(1496,1497,*range(2021,2027),*range(2189,2195),2583,2584,2585)
positions={p:n+i for i,p in enumerate(names)}

def add(b,x):
 while x:
  p=(x&-x).bit_length()-1
  if p not in b:b[p]=x;return
  x^=b[p]
def dot(x,y):return (x&y).bit_count()%2

def tape(changed):
 fields=[1<<i for i in range(n)]+[0]*w['owned_fields'];banks=defaultdict(list);moved={}
 for i,c in enumerate(w['start']):banks[c].append((i,fields[i]))
 p=n
 for clk,(kind,address,*args) in enumerate(w['program']):
  if kind=='ADD':fields[address]^=fields[args[0]]
  elif kind=='SWAP':fields[address],fields[args[0]]=fields[args[0]],fields[address]
  elif kind in ('INIT','CLEAR'):fields[address]=0
  else:
   assert kind=='MOVE';src,dst=args
   if changed and p==919:
    assert fields[address]==1<<320;banks[158].append((-919,fields[address]));fields[address]=0
   elif changed and p==923:fields[address]^=1<<320
   elif changed and p==927:fields[address]=0
   elif changed and p==1495:fields[address]=1<<321;banks[160].append((-1495,1<<527))
   elif changed and p in positions:fields[address]=1<<positions[p]
   moved[p]=fields[address]
   if not changed or p not in (919,927):banks[dst].append((p,fields[address]))
   p+=1
 return banks,moved
banks,moved=tape(True);_,old=tape(False)
groups=defaultdict(list)
for i,c in enumerate(w['final']):groups[c].append(i)
def target(i):return (1<<i)^((1<<(i-111)) if 111<=i<222 else 0)

def solve(signal,chart_pair):
 tag=1<<(positions[signal]-n);equations={};profiles=[]
 for c in chart_pair:
  rows=banks[c];scope=0
  for p,v in rows:scope|=v>>n
  assert scope==tag and len(groups[c])==1
  free={};ref=None
  for p,v in rows:
   v0=v&mask;flags=v>>n
   if flags&tag:
    if ref is None:ref=v0;continue
    v0^=ref
   add(free,v0)
  assert ref is not None
  rhs_target=ref^target(groups[c][0]);n_e=0
  for j in range(n):
   if j in free:continue
   dual=1<<j
   for pivot in sorted(free,reverse=True):
    if dot(dual,free[pivot]):dual|=1<<pivot
   assert all(not dot(dual,v) for v in free.values())
   row=dual;rhs=dot(dual,rhs_target)
   while row:
    pivot=(row&-row).bit_length()-1
    if pivot not in equations:equations[pivot]=(row,rhs);break
    row^=equations[pivot][0];rhs^=equations[pivot][1]
   else:assert rhs==0
   n_e+=1
  profiles.append(dict(chart=c,owner=groups[c][0],stocks=[p for p,v in rows],free_rank=len(free),nullspace_constraints=n_e))
 assert len(equations)==680
 candidate=0
 for pivot in sorted(equations,reverse=True):
  row,rhs=equations[pivot]
  if dot(row,candidate)^rhs:candidate|=1<<pivot
 assert all(dot(row,candidate)==rhs for row,rhs in equations.values())
 assert candidate==old[signal]
 return dict(signal=signal,charts=profiles,system_rank=len(equations),unique_equals_original=True,sha256_little_endian=hashlib.sha256(candidate.to_bytes(85,'little')).hexdigest(),h_value=dot(candidate,h),x43=(candidate>>43)&1)

results=[solve(2025,(553,625)),solve(2194,(630,635))]
# Other source arrivals are exactly the original h-zero, x43-zero inputs.
for c,omit in ((283,1496),(311,1497)):
 values=[v for p,v in banks[c] if p!=omit]
 assert len(values)==5 and all(not(v>>n) and not dot(v,h) and not(v>>43&1) for v in values)
# 568 sees only 2583; all fixed values evaluate h-zero while target is one.
assert groups[568]==[154] and dot(target(154),h)
tag=1<<(positions[2583]-n)
assert all((v>>n) in (0,tag) and not dot(v&mask,h) for p,v in banks[568])
print(json.dumps(dict(independent_interpreter=True,independent_low_pivot_solver=True,forced=results,other_source_inputs_h_zero_and_no_x43=True,chart_568_demand_h_one=True),indent=2,sort_keys=True))
