#!/usr/bin/env python3
"""Full terminal GF(2) screen for a named cut-crossing donor retarget.
Removal of 919..922 and 927; donor moved 0->388; each of four 45 exits
recoded independently in remaining four-source span; 388 late exits formal.
All terminal historical arrivals retained; downstream fixed equations propagate.
"""
import gzip,hashlib,json,sys,time
from collections import defaultdict
from itertools import product
from pathlib import Path
R=Path(__file__).parent
sys.path.insert(0,str(R));sys.path.insert(0,str(R/'source/vendor'))
import verify
from binary_operator import Atlas,expected_operator
raw=(R/'source/inputs/WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));n=w['public']; atlas=Atlas(w['frames'])

def model(packet,donor):
 cells=[1<<i for i in range(n)]+[0]*w['owned_fields']; banks=defaultdict(list); forms={i:1<<i for i in range(n)}
 for i,c in enumerate(w['start']):banks[c].append(i)
 early=(923,924,925,926);late=(2583,2584,2585);positions={p:n+i for i,p in enumerate(early+late)}
 routes={};clocks={};p=n
 for clk,(op,a,*args) in enumerate(w['program']):
  if op in ('INIT','CLEAR'):cells[a]=0
  elif op=='ADD':cells[a]^=cells[args[0]]
  elif op=='SWAP':cells[a],cells[args[0]]=cells[args[0]],cells[a]
  else:
   assert op=='MOVE';src,dst=args;routes[p]=src,dst;clocks[p]=clk
   if p==packet:
    assert cells[a]==1<<donor and (src,dst)==(0,45)
    forms[-p]=cells[a];banks[388].append(-p);cells[a]=0
   elif p==927:cells[a]=0
   elif p in positions:cells[a]=1<<positions[p]
   if p not in (packet,927):banks[dst].append(p)
   forms[p]=cells[a];p+=1
 groups=defaultdict(list)
 for i,c in enumerate(w['final']):groups[c].append(i)
 return dict(banks=banks,forms=forms,groups=groups,routes=routes,clocks=clocks,n=n,mask=(1<<n)-1,early=early,late=late,targets=expected_operator(False))

def add(b,x):
 while x:
  p=(x&-x).bit_length()-1
  if p not in b:b[p]=x;return
  x^=b[p]

def reduce(b,x):
 for p in sorted(b):
  if x>>p&1:x^=b[p]
 return x

def separator(b,target):
 rem=reduce(b,target)
 if not rem:return None
 free=(rem&-rem).bit_length()-1;assert free not in b
 h=1<<free
 for p in sorted(b,reverse=True):
  if (h&b[p]).bit_count()%2:h|=1<<p
 assert all(not (h&v).bit_count()%2 for v in b.values())
 assert (h&target).bit_count()%2
 return h

results={}
for packet,donor in zip((919,920,921,922),(320,321,322,323)):
 tic=time.monotonic();P=model(packet,donor);coords=tuple(i for i in (43,320,321,322,323) if i!=donor)
 source=sum(1<<i for i in coords);keep=P['mask']^source;witnesses=[];tested=0
 for c,owners in sorted(P['groups'].items()):
  bank=P['banks'][c];scope=0
  for p in bank:scope|=P['forms'][p]>>n
  if scope & (7<<4):continue
  tested+=1;b={}
  for p in bank:add(b,P['forms'][p]&keep)
  for owner in owners:
   demand=P['targets'][owner];h=separator(b,demand&keep)
   if h is None:continue
   assert not h&source
   assert all(not (h & (P['forms'][p] & P['mask'])).bit_count()%2 for p in bank)
   assert (h&demand).bit_count()%2
   witnesses.append(dict(chart=c,owner=owner,rank=len(b),stock_count=len(bank),stock_ids=bank,early_scope=scope,separator_support=list(verify.indices(h)),demand_support=list(verify.indices(demand))))
 results[str(packet)]=dict(donor=donor,source_coordinates=coords,unaffected_terminals_tested=tested,witness_count=len(witnesses),witnesses=witnesses,seconds=round(time.monotonic()-tic,3))
 print(json.dumps({str(packet):{k:v for k,v in results[str(packet)].items() if k!='witnesses'},'first_witness':witnesses[:1]},sort_keys=True),file=sys.stderr,flush=True)
print(json.dumps(results,indent=2,sort_keys=True))
