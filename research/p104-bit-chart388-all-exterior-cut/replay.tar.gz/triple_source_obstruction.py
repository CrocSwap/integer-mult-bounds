#!/usr/bin/env python3
"""Exact 311-source obstruction for the minimal exterior triple.
630/635 force the full original row 2194; test that value in each freely
retained six-row local source span after recoding 1497.
"""
import hashlib,json,sys
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R/'source/vendor'))
import binary_operator as op
import verify
from dual_donor_gate import source,h,bits,w
from triple_fullvector_gate import run,forms,banks,n
atlas=op.Atlas(w['frames']);original=op.run_tape(w,atlas,False)
old2194=original.packets[2194].arrival.row
old1497=original.packets[1497].arrival.row
stocks=original.stock[311]
assert [x.label for x in stocks]==[1425,1497,1545,1609,1653,1849]
assert all((forms[p]>>n)==16 or (forms[p]>>n)==0 for c in (630,635) for p in banks[c])
assert [banks[c] for c in (630,635)]==[[2874,2879,2884,3406],[2876,2882,2885,3408]]
rows=[]
for code in range(16):
 chosen=0
 for j,v in enumerate(source):
  if code>>j&1:chosen^=v
 result=run(code);p=result['signals']['2194']
 assert p['condition_charts']==[630,635] and p['dimension']==0 and p['empty_intersection_at'] is None
 forced=sum(1<<i for i in p['offset_support']);assert forced==old2194
 space=verify.Space()
 for obs in stocks:space.insert(chosen if obs.label==1497 else obs.row)
 missing=space.reduce(forced)[0]
 rows.append(dict(code=code,chosen_support=bits(chosen),h_value=(chosen&h).bit_count()%2,source_rank=len(space.rows),forced_in_source_span=not bool(missing),reduced_support=bits(missing)))
assert [r['code'] for r in rows if r['forced_in_source_span']]==[3]
assert old1497==(source[0]^source[1])
assert not (old2194&h).bit_count()%2
# Regardless of the arbitrary h=1 row chosen for 1497, all other source rows
# have h=0, so any representation of h-zero 2194 must omit 1497. The original
# 2194 contains x43, which none of the other five incoming rows contains.
other=[x for x in stocks if x.label!=1497]
assert all(not (x.row&h).bit_count()%2 and not (x.row>>43&1) for x in other)
assert (old2194>>43)&1
print(json.dumps(dict(exterior_triple=[2189,2191,2194],forced_by_terminals=[630,635],forced_packet=2194,forced_row_support=bits(old2194),forced_row_sha256_little_endian=hashlib.sha256(old2194.to_bytes(85,'little')).hexdigest(),source_chart=311,original_arrival_ids=[x.label for x in stocks],only_source_feasible_1497_code=3,arbitrary_h1_source_impossible=True,explanation='The five unmodified 311 arrivals have h=0 and x43=0. A hypothetical h=1 1497 must be omitted from any linear expression for h=0 2194, leaving no x43; forced 2194 has x43=1.',codes=rows),indent=2,sort_keys=True))
