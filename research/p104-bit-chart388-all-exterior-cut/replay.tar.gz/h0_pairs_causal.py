#!/usr/bin/env python3
"""Check causal h cut for all remaining 1496/1497 source choices, not only old rows."""
import json,sys
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R))
from dual_donor_gate import model,source,h,n,mask,bits
choices=[]
for code in range(16):
 row=0
 for j,v in enumerate(source):
  if code>>j&1:row^=v
 if not (row&h).bit_count()%2:choices.append((code,row))
assert len(choices)==8
cases=0
for e in list(range(2021,2027))+list(range(2189,2195)):
 banks,forms,groups=model(e)
 for (c1,r1) in choices:
  for (c2,r2) in choices:
   def val(v):
    fixed=v&mask;tags=v>>n
    if tags&1:fixed^=r1
    if tags&2:fixed^=r2
    # Any exterior and 388 late outputs have zero h by causal source induction.
    return (fixed&h).bit_count()%2
   for chart,expected_count in ((283,6),(311,6),(388,2),(1,537)):
    assert len(banks[chart])==expected_count
    assert all(not val(forms[p]) for p in banks[chart]),(e,c1,c2,chart)
   cases+=1
assert cases==12*8*8 and (h>>43)&1
print(json.dumps(dict(h=bits(h),h_zero_codes=[c for c,r in choices],exterior_choices=12,independent_donor_pairs=64,checks=cases,all_source_banks_and_terminal_h_zero=True,owner_43_target_h=1,extension='Any <=2 exterior recodes are h-zero once their donor sources are h-zero; linear h-propagation is identical to this zero-symbol model.'),indent=2,sort_keys=True))
