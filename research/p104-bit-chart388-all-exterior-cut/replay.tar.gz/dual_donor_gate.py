#!/usr/bin/env python3
"""Independent early-terminal gates for simultaneous 1496 and 1497 recodes.
Same 919->158 side restoration and paid 0->160 x527 grant as side_recovery.
One exterior 283/311 equation and all three late equations are unconstrained.
At terminals not seeing those signals, select constraints that see exactly
one of 1496/1497; this permits independent exhaustive 16x16 source coding.
"""
import gzip,hashlib,json,sys
from collections import defaultdict
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R/'source/vendor'))
from binary_operator import Atlas,expected_operator
raw=(R/'source/inputs/WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));n=w['public']; atlas=Atlas(w['frames']);expected=expected_operator(False)
mask=(1<<n)-1;source=[(1<<43)^(1<<321),(1<<74)^(1<<405),1<<321,1<<527]; h=sum(1<<i for i in (43,320,321,322,323))

def add(b,x):
 while x:
  p=(x&-x).bit_length()-1
  if p not in b:b[p]=x;return
  x^=b[p]
def reduce(b,x):
 for p in sorted(b):
  if x>>p&1:x^=b[p]
 return x
def bits(v):
 a=[]
 while v:
  q=v&-v;a.append(q.bit_length()-1);v^=q
 return a

def model(exterior):
 cells=[1<<i for i in range(n)]+[0]*w['owned_fields'];banks=defaultdict(list);forms={i:1<<i for i in range(n)}
 for i,c in enumerate(w['start']):banks[c].append(i)
 positions={p:n+j for j,p in enumerate((1496,1497,exterior,2583,2584,2585))};p=n
 for clk,(op,a,*args) in enumerate(w['program']):
  if op in ('INIT','CLEAR'):cells[a]=0
  elif op=='ADD':cells[a]^=cells[args[0]]
  elif op=='SWAP':cells[a],cells[args[0]]=cells[args[0]],cells[a]
  else:
   assert op=='MOVE';src,dst=args
   if p==919:
    assert cells[a]==1<<320 and (src,dst)==(0,45);forms[-919]=cells[a];banks[158].append(-919);cells[a]=0
   elif p==923:
    assert cells[a]==1<<43 and dst==158;cells[a]^=1<<320
   elif p==927:cells[a]=0
   elif p==1495:
    assert cells[a]==1<<527;cells[a]=1<<321;forms[-1495]=1<<527;banks[160].append(-1495)
   elif p in positions:cells[a]=1<<positions[p]
   if p not in (919,927):banks[dst].append(p)
   forms[p]=cells[a];p+=1
 groups=defaultdict(list)
 for i,c in enumerate(w['final']):groups[c].append(i)
 return banks,forms,groups

def run(exterior):
 banks,forms,groups=model(exterior); result={'exterior':exterior,'constraints':{}}
 for sender,tag in ((1496,1),(1497,2)):
  charts=[]
  for c,owners in sorted(groups.items()):
   stock=[forms[p] for p in banks[c]];scope=0
   for v in stock:scope|=v>>n
   if scope!=tag:continue
   charts.append((c,owners,stock))
  survivors=[];failures={}
  for code in range(16):
   chosen=0
   for j,x in enumerate(source):
    if code>>j&1:chosen^=x
   first=None
   for c,owners,stock in charts:
    b={}
    for v in stock:add(b,(v&mask)^(chosen if (v>>n)&tag else 0))
    for owner in owners:
     if reduce(b,expected[owner]):first={'chart':c,'owner':owner};break
    if first:break
   if first:failures[str(code)]=first
   else:survivors.append({'code':code,'support':bits(chosen),'h':(h&chosen).bit_count()%2})
  result['constraints'][str(sender)]={'single_sender_early_terminal_count':len(charts),'survivors':survivors,'first_failure_by_code':failures}
 return result
if __name__=='__main__':
 results=[run(e) for e in list(range(2021,2027))+list(range(2189,2195))]
 assert all([x['code'] for x in z['constraints']['1496']['survivors']]==[11] and [x['code'] for x in z['constraints']['1497']['survivors']]==[3] for z in results)
 print(json.dumps(results,indent=2,sort_keys=True))
