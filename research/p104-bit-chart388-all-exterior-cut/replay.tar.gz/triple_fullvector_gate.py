#!/usr/bin/env python3
"""Singleton-exterior full-680-bit necessary conditions for 311 triple.
The 0->158 side route/0->160 extra donor and 1495=x321 are as in the other
round 9 model. 1496 is fixed to its forced old value, 1497 spans all 16
4-stock combinations, and 2189,2191,2194,2583,2584,2585 are independent
unrestricted formal payloads. Terminal decoding grants all historical rows.
For terminals that see exactly one of the three exterior symbols and no late
symbol, intersect all affine membership requirements on that signal.
"""
import json,sys
from collections import defaultdict
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R/'source/vendor'))
import verify
from dual_donor_gate import w,n,mask,source,h,bits,expected

exts=(2189,2191,2194);late=(2583,2584,2585)

def model():
 cells=[1<<i for i in range(n)]+[0]*w['owned_fields'];banks=defaultdict(list);forms={i:1<<i for i in range(n)}
 for i,c in enumerate(w['start']):banks[c].append(i)
 positions={p:n+j for j,p in enumerate((1496,1497)+exts+late)};p=n
 for op,a,*args in w['program']:
  if op in ('INIT','CLEAR'):cells[a]=0
  elif op=='ADD':cells[a]^=cells[args[0]]
  elif op=='SWAP':cells[a],cells[args[0]]=cells[args[0]],cells[a]
  else:
   assert op=='MOVE';src,dst=args
   if p==919:forms[-919]=cells[a];banks[158].append(-919);cells[a]=0
   elif p==923:cells[a]^=1<<320
   elif p==927:cells[a]=0
   elif p==1495:cells[a]=1<<321;forms[-1495]=1<<527;banks[160].append(-1495)
   elif p in positions:cells[a]=1<<positions[p]
   if p not in (919,927):banks[dst].append(p)
   forms[p]=cells[a];p+=1
 groups=defaultdict(list)
 for i,c in enumerate(w['final']):groups[c].append(i)
 return banks,forms,groups

banks,forms,groups=model()
def code_row(code):
 row=0
 for j,v in enumerate(source):
  if code>>j&1:row^=v
 return row

def run(code):
 donor6=code_row(11);donor7=code_row(code);assigned={}
 for p,v in forms.items():
  fixed=v&mask;flags=v>>n
  if flags&1:fixed^=donor6
  if flags&2:fixed^=donor7
  assigned[p]=(fixed,flags>>2)
 out={'code':code,'support':bits(donor7),'h_value':(donor7&h).bit_count()%2,'signals':{}}
 for j,ext in enumerate(exts):
  tag=1<<j;conditions=[];charts=0;impossible=[]
  for c,owners in sorted(groups.items()):
   bank=banks[c];scope=0
   for p in bank:scope|=assigned[p][1]
   if scope!=tag:continue
   charts+=1;free=verify.Space();ref=None
   for p in bank:
    v,flags=assigned[p]
    if flags&tag:
     if ref is None:ref=v;continue
     v^=ref
    free.insert(v)
   assert ref is not None
   defects={free.reduce(expected[i])[0] for i in owners}-{0}
   if len(defects)>1:impossible.append(dict(chart=c,owner_count=len(owners),defects=len(defects)));continue
   if defects:conditions.append((next(iter(defects))^ref,free,c))
  if impossible:
   out['signals'][str(ext)]={'chart_count':charts,'conditions':len(conditions),'impossible':impossible};continue
  if not conditions:
   out['signals'][str(ext)]={'chart_count':charts,'conditions':0,'dimension':680};continue
  conditions.sort(key=lambda x:len(x[1].rows));offset,s0,c0=conditions[0];directions=s0.basis();failed=None
  for other,space,c in conditions[1:]:
   sol=verify.affine_meet(offset,directions,other,space)
   if sol is None:failed=c;break
   offset,directions=sol
  out['signals'][str(ext)]={'chart_count':charts,'conditions':len(conditions),'empty_intersection_at':failed,'dimension':None if failed else len(directions),'condition_charts':[c for _,_,c in conditions], 'offset_support':None if failed else bits(offset)}
 return out
if __name__=='__main__':
 result=[run(code) for code in range(16)]
 print(json.dumps(result,indent=2,sort_keys=True))
