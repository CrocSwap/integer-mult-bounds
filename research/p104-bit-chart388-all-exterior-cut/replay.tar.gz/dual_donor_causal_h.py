#!/usr/bin/env python3
"""h-projection for forced dual donor choices and one arbitrary exterior output."""
import json,sys
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R))
from dual_donor_gate import model,source,h,n,mask,bits
old1496=source[0]^source[1]^source[3]
old1497=source[0]^source[1]
assert not (old1496&h).bit_count()%2 and not (old1497&h).bit_count()%2
out=[]
for exterior in list(range(2021,2027))+list(range(2189,2195)):
 banks,forms,groups=model(exterior)
 def value(v):
  fixed=v&mask;flags=v>>n
  if flags&1:fixed^=old1496
  if flags&2:fixed^=old1497
  # Exterior, 2583,2584,2585 are zero on h by causal induction.
  return (fixed&h).bit_count()%2
 def observed(c):return [(p,value(forms[p])) for p in banks[c]]
 d={str(c):observed(c) for c in (158,160,283,311,388,1)}
 assert len(d['283'])==6 and len(d['311'])==6
 assert all(v==0 for c in ('283','311','388','1') for _,v in d[c])
 assert len(d['388'])==2 and len(d['1'])==537
 assert any(v==1 for _,v in d['158']) and any(v==1 for _,v in d['160'])
 assert (h>>43)&1
 out.append(dict(exterior=exterior,chart_counts={c:len(rows) for c,rows in d.items()},visible={c:[p for p,v in rows if v] for c,rows in d.items()},required_owner_43=1))
print(json.dumps(dict(h=bits(h),forced_1496=bits(old1496),forced_1497=bits(old1497),proof='All six incoming rows of each exterior source are zero on h. Its arbitrary causal linear recode is zero; all chart-388 inputs are zero, hence all its causal linear exits are zero; every remaining terminal chart-1 row is zero, but owner 43 needs one.',cases=out),indent=2,sort_keys=True))
