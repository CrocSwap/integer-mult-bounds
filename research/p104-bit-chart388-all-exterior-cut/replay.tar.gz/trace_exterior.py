#!/usr/bin/env python3
import json,gzip,hashlib,sys
from collections import defaultdict
from pathlib import Path
R=Path(__file__).parent
sys.path.insert(0,str(R/'source/vendor'))
from binary_operator import Atlas, expected_operator
raw=(R/'source/inputs/WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw)); n=w['public']; atlas=Atlas(w['frames']);
h=sum(1<<i for i in (43,320,321,322,323))
parity=lambda r: (r&h).bit_count()%2
support=lambda r: [i for i in range(n) if r>>i&1]

def run(remove):
 cells=[(c,1<<i) for i,c in enumerate(w['start'])]+[None]*w['owned_fields']
 bank=defaultdict(list)
 for i,c in enumerate(w['start']):bank[c].append((i,-1,1<<i,'initial'))
 moves={}; first={}; logs=[]
 for clk,(op,a,*args) in enumerate(w['program']):
  if op=='INIT':cells[a]=(args[0],0)
  elif op=='CLEAR':cells[a]=None
  elif op=='SWAP':cells[a],cells[args[0]]=cells[args[0]],cells[a]
  elif op=='ADD':
   ch,v=cells[a];q,sv=cells[args[0]]; assert ch==q==args[1]
   cells[a]=(ch,v^sv)
  else:
   assert op=='MOVE'
   p=n+len(moves); ch,v=cells[a];src,dst=args; assert ch==src
   oldv=v
   if p==927 and remove:v=0
   cells[a]=(dst,v)
   bank[dst].append((p,clk,v,'move'))
   moves[p]=(clk,src,dst,v,a,oldv)
  # first h-visible live field at chart. Track at specific stage only.
  for f in ([a,args[0]] if op=='SWAP' else [a]):
   if cells[f] is None:continue
   ch,v=cells[f]
   if ch in (160,283,311,388,1) and parity(v) and ch not in first:
    first[ch]=dict(clock=clk,operation=[op,a,*args],field=f,support=support(v),h_value=1)
 return cells,bank,moves,first
cells,bank,moves,first=run(True);oldcells,oldbanks,oldmoves,oldfirst=run(False)
assert [v for c,v in oldcells[:n]]==expected_operator(False)
interesting={}
for c in (45,158,160,283,311,388,1,517,560):
 ins=[];outs=[]
 for p,(clk,src,dst,v,a,ov) in moves.items():
  if c in (src,dst):
   row=dict(packet=p,clock=clk,source=src,destination=dst,grade=atlas.grade(src,dst),h=parity(v),support=support(v),field=a)
   (ins if dst==c else outs).append(row)
 interesting[c]=dict(first_h=first.get(c),initial=[dict(field=i,h=parity(v),support=support(v)) for i,t,v,k in bank[c] if t==-1],incoming=ins,outgoing=outs)
# h-visible live witnesses on the source charts before 388 exits and source-target grades.
print(json.dumps(dict(h=[43,320,321,322,323],removed=927,grades={str(c):{str(d):atlas.grade(c,d) for d in (1,160,283,311,388,560)} for c in (45,160,283,311)},charts=interesting),indent=2,sort_keys=True))
