# Round 9 chart-388 changed-exterior scout

## Outcome and scope

No new operator or κ bound. The named price-positive side-recovery model is impossible under the fixed remaining sender equations described below, even when both chart-160 sends and all twelve exterior sends are recoded and terminal charts retain all their historical incoming rows. This result does not rule out other rewrites, changed productive targets or ownership, altered 1488–1490/1498 or the five other input rows at either exterior source, or new inbound contacts to charts 283/311. It is a necessary GF(2) test on an abstract, deliberately relaxed model, not a literal implementation, reverse-operator validation of a candidate, human review, or a finite-theorem transfer.

The exact original native word and source package are the #7830/#7995 archived inputs. WORD.json.gz SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`, canonical native SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`; #7830 head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. The source baseline and archived #7995 seven-variable model remain distinct from the changed-incidence scout here.

## Strict h stock, original 927 removed

For `h={43,320,321,322,323}` all values below are evaluated over GF(2); the table is conditional on the original four chart-45 outputs, which are independently forced only in #7995's stated frozen-exterior screen.

| Chart | Relevant live or incoming stock | h | Original outgoing consequences |
|---|---|---:|---|
| 45 | owner 43, original 919–922 = x320,x321,x322,x323 | 1 each | 923–926 are x43+x320, x43+x321, x43+x322, x43+x323, all h=0; deleted 927 was x43, h=1 |
| 160 | 924=x43+x321; 1122=x74+x405; 1495=x527 | 0 each | 1496→283, 1497→311, 1498→508 all h=0 |
| 283 | 988, 1111, 1496, 1604, 1756, 1816 | 0 each | 2021–2026, including 2023→388, are h=0 |
| 311 | 1425, 1497, 1545, 1609, 1653, 1849 | 0 each | 2189–2194, including 2190→388, are h=0 |
| 388 | only 2023, 2190 remain after deleting 927 | 0 each | 2583–2585 cannot obtain h=1 causally from this stock |
| 1 | 537 incoming historical rows | 0 each | owner 43 requires value 1 |

Strict h cannot itself force the early rows; it is used only after separate terminal membership constraints. Actual rational atlas grades: 0→45=1, 0→158=2, 0→160=2, 0→283=0→311=4, 0→388=6, 160→283=160→311=2, 160→388=4, 283→388=311→388=2. `trace_exterior.json` contains exact supports, clocks, destinations, and source grades.

## Concrete changed-incidence path

1. At original clock 852 retarget 919 (`x320`) from 0→45 to 0→158, grade 2. The rational nesting is valid. Remove the old 45-local use of 919. Thus 923 leaves 45 at clock 865 as x43. At 158, XOR the new 919 into 923, recovering x43+x320 before its first original reader at clock 2890. This preserves the old 923 downstream value in the scout.
2. Delete 927, grade 5. Change existing 1495 (0→160, grade 2) from x527 to x321, and grant one additional paid 0→160 transfer carrying x527, grade 2, before clock 2922. In the original word, source fields 321 and 527 remain live and equal x321 and x527 at chart 0 immediately before clock 2916. The changed bank at 160 consequently spans independently `a=x43+x321`, `b=x74+x405`, `c=x321`, `d=x527`.
3. Permit 1496 and 1497 independently to be any of the 16 combinations of `(a,b,c,d)`, yielding 256 pairs. Keep 1498 and the other original sender equations fixed except for one arbitrary selected exterior send among 2021–2026 at 283 or 2189–2194 at 311. Grant that exterior send a completely unrestricted formal vector, all three 388 exits unrestricted independent formal vectors, and all terminals free historical-stock retention. These grants are more permissive than actual causal local coding at the exterior send and receiver.

For each of all 12 exterior choices, terminal charts unaffected by that exterior/late output and seeing only 1496 force it to `a+b+d=x43+x74+x321+x405+x527` (code 11). Different unaffected terminal charts seeing only 1497 force it to `a+b=x43+x74+x321+x405` (code 3). The code exhausts 16 possibilities per sender, so it covers all 256 pairs. There are at least 2 such terminal charts per sender for every exterior choice. Both uniquely forced values are zero on h. The exact terminal/owner first-failure witnesses for all rejected choices are in `dual_donor_gate.json`.

Causal continuation: all six arrivals at each of 283 and 311 are zero on h, hence any chosen exterior recoding computed from those arrivals is zero. The two retained 388 arrivals are zero; its causal sends are zero; all 537 historical fixed stock rows at chart 1 are zero; owner 43 needs one. The newly h-visible stock at 158 (`919`) and at 160 (`1495`) remains trapped by the fixed equations and terminal membership. `dual_donor_causal_h.py` checks all 12 choices. This excludes the specified model even with the supplied extra paid x527, but it does not exclude rewrites that change other sender equations or incidences.

The result extends to **two** arbitrarily recoded exterior sends. Each of the eight h-nonzero choices for 1496 fails all four terminals 553, 581, 594 and 625, independently of 1497. To affect all four using any of the twelve exterior sends requires at least three: the unique three-send cover is {2021,2022,2025}. Each of the eight h-nonzero choices for 1497 likewise fails terminals 600, 605, 630 and 635, independently of 1496; the unique three-send cover is {2189,2191,2194}. Reach is computed from the original fixed downstream equations and the exterior payloads are granted unrestricted formal vectors. Thus with at most two exterior recodes both donor sends must be h-zero. With both zero on h, all causal exterior sends and chart-388 sends remain h-zero, and chart-1 owner 43 is still unobtainable. The 64 remaining source-code pairs are checked for all 12 exterior labels in `h0_pairs_causal.json`. These are necessary cover conditions, not a claim that any three-send construction succeeds.

## Strongest result: all twelve exterior sends mutable

Grant 1496 and 1497 any independent 680-bit vectors, all twelve sends 2021–2026 and 2189–2194 independently mutable, all three late 388 sends independently mutable, and all terminal charts all historical incoming stock. Keep the five other original arrivals at each of 283 and 311 and the remaining surrounding sender equations fixed; in particular do not add an inbound source at either chart. The altered 919→158 path still restores 923 locally, and the extra paid x527 is still available at 160.

Terminal charts 553/625 see only one of these formal values, 2025, and their full GF(2) membership constraints have a unique intersection: the original 2025, whose 85-byte little-endian SHA-256 is `6ab4d81ca43859b19b6dd2d5b2bba61c6730aa3d1735e1bc9177ad3ffe0442fd`. Charts 630/635 similarly force original 2194, SHA-256 `778835b6045bf1107e4bd324b05687c291e86366bde87ce601c5a362886c9a15`. Each two-chart system has rank 680. Neither result depends on the values of the other eleven exterior sends, the two donor sends, or the late sends.

Both forced source outputs evaluate h=0 and contain x43. At their respective sources, each of the other five original input rows has h=0 and contains no x43. Therefore a hypothetical h=1 on 1496 or 1497 cannot help form the forced h=0 source output: it must be omitted by parity, after which x43 is unavailable. Thus both donor sends are h=0. Every arbitrary causal recoding from either six-row exterior bank is h=0, so both chart-388 inputs and its late sends are h=0. Terminal chart 568 owner 154 demands x43+x154, which is one on h; its only changed formal stock is a descendant of 2583, and all its fixed stocks are h=0. This contradicts the demanded output.

`all_exterior_obstruction.py` computes the full formal tape, terminal affine intersections and source/receiver canaries. `independent_all12_affine.py` independently reinterprets the raw instructions and solves the same two systems using low-pivot nullspace equations, with rank 680 for each. This is a stronger scope-specific result than the earlier two- and three-exterior-send controls. It still permits none of the five other original source arrivals at either exterior chart to change.

## Price and controls

At κ=0.00388 let H(g)=g^(1−κ). If all original caller and productive targets were preserved, the above local paid histogram change would be `−H(1)+2H(2)−H(5)` per native call. Its directed 36-call signed gain is +71.2662257302935424, giving a hypothetical binary signed margin +71.2385143701033248 from the pinned baseline −0.02771136019021759. This arithmetic has no candidate operator behind it; ownership, legal lifetime, reverse direction, bridge, all prices, and productive endpoints would require revalidation for any actual construction. No additional grade-5 transfer is assumed.

For comparison, #7924's emitted restored control changes the native paid account by `+H(1)+2H(2)+H(3)−H(5)` and loses 108.2743915578161 across 36 calls at this rate. The #7995 chart-160 replacement by itself has a 35.6519418730 saving; paying even one new grade-1 hop changes that to −0.3480581270. No assumption that this budget funds a new grade-5 transfer is made.

A separate retarget-only screen moves one of 919–922 directly 0→388 (grade 6), removes 927, allows all four chart-45 sends to choose independently in the remaining source span, and grants free late sends. Its conditional 36-call signed gain is +0.37590097997; terminal membership rules out all four. The first compact dual separators are 919: chart 528 owner 114, `{3,320}`; 920: chart 526 owner 112, `{1,321}`; 921: chart 533 owner 119, `{8,322}`; 922: chart 526 owner 112, `{1,323}`. All have surviving terminal witnesses. The `one_exterior_gate` additionally tests moving each donor to 283 or 311 and changing one of that chart's six original sends as a completely unrestricted symbol; all 48 cases fail unaffected-terminal membership. These controls have their own scopes.

## Reproduction

Run from this directory with Python 3.12 and compare to the saved results:

```sh
python3 -I -B all_exterior_obstruction.py > /tmp/r9-all12-check.json
cmp all_exterior_obstruction.json /tmp/r9-all12-check.json
python3 -I -B independent_all12_affine.py > /tmp/r9-independent-check.json
cmp independent_all12_affine.json /tmp/r9-independent-check.json
python3 -I -B dual_donor_gate.py > /tmp/r9-dual-check.json
cmp dual_donor_gate.json /tmp/r9-dual-check.json
python3 -I -B dual_donor_causal_h.py > /tmp/r9-h-check.json
cmp dual_donor_causal_h.json /tmp/r9-h-check.json
python3 -I -B exterior_lower_bound.py > /tmp/r9-cover-check.json
cmp exterior_lower_bound.json /tmp/r9-cover-check.json
python3 -I -B h0_pairs_causal.py > /tmp/r9-pairs-check.json
cmp h0_pairs_causal.json /tmp/r9-pairs-check.json
python3 -I -B baseline_and_price.py > /tmp/r9-baseline-check.json
cmp baseline_and_price.json /tmp/r9-baseline-check.json
python3 -I -B one_exterior_gate.py > /tmp/r9-exterior-check.json
cmp one_exterior_gate.json /tmp/r9-exterior-check.json
sha256sum -c R9-SHA256SUMS
```

The original baseline positive control (`baseline_and_price.py`) replays the full 680-row forward and adjoint operators, both complete paired caller polynomials, unchanged original helper/productive geometry, protected owner-411 bridge packet 3553 and its omission canary. No altered literal is claimed.

`verify.py` is the retained #7995 verifier, included here as an imported GF(2) helper for the R9 checkers. It is not a standalone replay entry point in this reduced archive. The archived `NOTICE` and `SOURCES.json` describe the inherited #7995 source package; `R9-SHA256SUMS` is the file inventory and checksum manifest for this R9 package. The original notices and license are retained.
