#!/usr/bin/env python3
"""Necessary GF(2) terminal test for cut-crossing retarget plus one exterior recode.
Retarget one 0->45 donor (919..922) directly to chart 283 or 311, remove
927, let 45 exits choose any combinations of four surviving local inputs,
allow one original 283/311 outgoing send to be an unrestricted symbol, and
allow the three 388 exits independent symbols. Terminal historical stock is
free, and charts seeing an exterior or late symbol are omitted entirely.
"""
import gzip,hashlib,json,sys
from collections import defaultdict
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R/'source/vendor'))
from binary_operator import Atlas,expected_operator
raw=(R/'source/inputs/WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));n=w['public'];atlas=Atlas(w['frames'])
assert atlas.grade(0,283)==atlas.grade(0,311)==4

def add(b,x):
 while x:
  p=(x&-x).bit_length()-1
  if p not in b:b[p]=x;return
  x^=b[p]
def reduce(b,x):
 for p in sorted(b):
  if x>>p&1:x^=b[p]
 return x
def separator(b,target):
 rem=reduce(b,target)
 if not rem:return None
 free=(rem&-rem).bit_length()-1;assert free not in b
 h=1<<free
 for p in sorted(b,reverse=True):
  if (h&b[p]).bit_count()%2:h|=1<<p
 assert all(not (h&v).bit_count()%2 for v in b.values()) and (h&target).bit_count()%2
 return h
def bits(v):
 a=[]
 while v:
  q=v&-v;a.append(q.bit_length()-1);v^=q
 return a

def gate(packet,donor,dest,exterior):
 early=(923,924,925,926);late=(2583,2584,2585);positions={p:n+i for i,p in enumerate(early+(exterior,)+late)}
 cells=[1<<i for i in range(n)]+[0]*w['owned_fields'];banks=defaultdict(list);forms={i:1<<i for i in range(n)}
 for i,c in enumerate(w['start']):banks[c].append(i)
 p=n;routes={};clocks={}
 for clk,(op,a,*args) in enumerate(w['program']):
  if op in ('INIT','CLEAR'):cells[a]=0
  elif op=='ADD':cells[a]^=cells[args[0]]
  elif op=='SWAP':cells[a],cells[args[0]]=cells[args[0]],cells[a]
  else:
   assert op=='MOVE';src,dst=args;routes[p]=src,dst;clocks[p]=clk
   if p==packet:
    assert cells[a]==1<<donor and (src,dst)==(0,45)
    forms[-p]=cells[a];banks[dest].append(-p);cells[a]=0
   elif p==927:cells[a]=0
   elif p in positions:cells[a]=1<<positions[p]
   if p not in (packet,927):banks[dst].append(p)
   forms[p]=cells[a];p+=1
 assert routes[exterior][0]==dest
 groups=defaultdict(list)
 for i,c in enumerate(w['final']):groups[c].append(i)
 targets=expected_operator(False);source=sum(1<<i for i in (43,320,321,322,323) if i!=donor)
 keep=((1<<n)-1)^source;witnesses=[];tested=0
 for c,owners in sorted(groups.items()):
  bank=banks[c];scope=0
  for p in bank:scope|=forms[p]>>n
  # Skip all terminals seeing the exterior or any late symbol: strong relaxation.
  if scope & (15<<4):continue
  tested+=1;b={}
  for p in bank:add(b,forms[p]&keep)
  for owner in owners:
   h=separator(b,targets[owner]&keep)
   if h is None:continue
   assert not h&source and all(not (h&forms[p]).bit_count()%2 for p in bank)
   witnesses.append(dict(chart=c,owner=owner,rank=len(b),stock_count=len(bank),stock_ids=bank,early_scope=scope,separator_support=bits(h),demand_support=bits(targets[owner])))
 return dict(packet=packet,donor=donor,retarget_destination=dest,retarget_grade=4,exterior=exterior,exterior_route=routes[exterior],exterior_clock=clocks[exterior],unaffected_terminals_tested=tested,witness_count=len(witnesses),witnesses=witnesses)
if __name__=='__main__':
 results=[]
 for packet,donor in zip((919,920,921,922),(320,321,322,323)):
  for dest,exts in ((283,range(2021,2027)),(311,range(2189,2195))):
   for exterior in exts:results.append(gate(packet,donor,dest,exterior))
 print(json.dumps(results,indent=2,sort_keys=True))
