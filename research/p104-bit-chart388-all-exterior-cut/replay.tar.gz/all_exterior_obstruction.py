#!/usr/bin/env python3
"""Exclude all 12 mutable 283/311 sends in the changed-incidence side model.

Separate terminal chart pairs force 2025 and 2194 to their original full
680-bit vectors even if all 12 exterior outputs, both 160 donor sends, and
all 388 outputs are independently formal, unrestricted vectors. Each forced
vector is h-zero, contains x43, and its source's other five original arrivals
are h-zero with no x43. Therefore the respective donor send cannot be h-one.
With both donor sends h-zero, both exterior source banks and 388 are h-zero,
and terminal owner 154 at chart 568 cannot be obtained. Terminal charts retain
all historical incoming vectors. This is a necessary abstract test, not a
literal operator construction or a global impossibility.
"""
import hashlib,json,sys
from collections import defaultdict
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));sys.path.insert(0,str(R/'source/vendor'))
import binary_operator as op
import verify
from dual_donor_gate import w,n,mask,h,bits,expected

exts=tuple(range(2021,2027))+tuple(range(2189,2195));late=(2583,2584,2585);donors=(1496,1497)
names=donors+exts+late;bit={p:1<<i for i,p in enumerate(names)}

# Formal, independent 680-coordinate payloads; no local-source restriction.
cells=[1<<i for i in range(n)]+[0]*w['owned_fields'];banks=defaultdict(list);forms={i:1<<i for i in range(n)}
for i,c in enumerate(w['start']):banks[c].append(i)
p=n
for opn,a,*args in w['program']:
 if opn in ('INIT','CLEAR'):cells[a]=0
 elif opn=='ADD':cells[a]^=cells[args[0]]
 elif opn=='SWAP':cells[a],cells[args[0]]=cells[args[0]],cells[a]
 else:
  assert opn=='MOVE';src,dst=args
  if p==919:
   assert cells[a]==1<<320 and (src,dst)==(0,45)
   forms[-919]=cells[a];banks[158].append(-919);cells[a]=0
  elif p==923:
   assert cells[a]==1<<43 and dst==158;cells[a]^=1<<320
  elif p==927:cells[a]=0
  elif p==1495:
   assert cells[a]==1<<527;cells[a]=1<<321;forms[-1495]=1<<527;banks[160].append(-1495)
  elif p in bit:cells[a]=1<<(n+names.index(p))
  if p not in (919,927):banks[dst].append(p)
  forms[p]=cells[a];p+=1
assert p==3554
groups=defaultdict(list)
for i,c in enumerate(w['final']):groups[c].append(i)
a=op.Atlas(w['frames']);original=op.run_tape(w,a,False)

def force(signal,charts):
 tag=bit[signal];conditions=[];records=[]
 for c in charts:
  stock=banks[c];scope=0
  for p in stock:scope|=forms[p]>>n
  assert scope==tag,(signal,c,scope,tag)
  free=verify.Space();ref=None
  for p in stock:
   v=forms[p]&mask;flags=forms[p]>>n
   if flags&tag:
    if ref is None:ref=v;continue
    v^=ref
   free.insert(v)
  assert ref is not None
  defects={free.reduce(expected[i])[0] for i in groups[c]}-{0}
  assert len(defects)==1
  condition=next(iter(defects))^ref
  conditions.append((condition,free,c))
  records.append(dict(chart=c,owners=groups[c],stock_ids=stock,free_rank=len(free.rows)))
 offset,s0,c=conditions[0];directions=s0.basis()
 for other,space,c in conditions[1:]:
  solution=verify.affine_meet(offset,directions,other,space);assert solution is not None
  offset,directions=solution
 assert not directions and offset==original.packets[signal].arrival.row
 return offset,records

forced25,charts25=force(2025,(553,625))
forced94,charts94=force(2194,(630,635))
receipts={}
for signal,donor,source,forced,charts in ((2025,1496,283,forced25,charts25),(2194,1497,311,forced94,charts94)):
 stock=original.stock[source];other=[x for x in stock if x.label!=donor]
 assert len(stock)==6 and len(other)==5
 assert banks[source]==[x.label for x in stock]
 assert all(forms[x.label]==x.row for x in other)
 assert all(not (x.row&h).bit_count()%2 and not (x.row>>43&1) for x in other)
 assert not (forced&h).bit_count()%2 and (forced>>43)&1
 # The formal source arrivals contain no exterior or late signal; they predate
 # every outgoing exterior equation, so recoding those cannot add source stock.
 assert all(not ((forms[p]>>n)&~(bit[1496]|bit[1497])) for p in banks[source])
 receipts[str(signal)]=dict(source_chart=source,mutable_donor=donor,original_source_packets=[x.label for x in stock],terminal_constraints=charts,forced_original_support=bits(forced),forced_row_sha256_little_endian=hashlib.sha256(forced.to_bytes(85,'little')).hexdigest(),forced_h=0,forced_x43=1,other_five_h_and_x43_zero=True)
# At chart 568 no sender symbol except 2583 can affect its historical stock,
# and its remaining fixed component is h-zero; owner 154=x43+x154 needs 1.
assert groups[568]==[154] and (expected[154]&h).bit_count()%2==1
for p in banks[568]:
 flags=forms[p]>>n
 assert flags in (0,bit[2583]) and not (forms[p]&mask&h).bit_count()%2
assert any((forms[p]>>n)==bit[2583] for p in banks[568])
print(json.dumps(dict(h=bits(h),formal_payloads=list(names),arbitrary_exterior_sends=list(exts),early_forced_rows=receipts,terminal_568=dict(owner=154,target_support=bits(expected[154]),stock_ids=banks[568],only_formal_signal=2583,fixed_h_zero=True),causal_conclusion='The forced 2025 and 2194 source obligations exclude h=1 at 1496 and 1497, respectively. All six source inputs of each 283/311 bank are then h=0, all their arbitrary causal exterior outputs are h=0, and both inputs of 388 are h=0. All 388 outputs are h=0, contradicting owner 154 at chart 568.',scope='Side-recovery incidence and source stocks fixed; 1496,1497 arbitrary; all 12 283/311 exterior sends and all three 388 outputs free; no added inbound exterior sources or changes to 1498/other original sends.'),indent=2,sort_keys=True))
