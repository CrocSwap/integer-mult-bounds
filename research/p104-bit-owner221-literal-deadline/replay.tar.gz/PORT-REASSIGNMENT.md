# Owner 17: fixed native body reassignment gate

This independent check addresses one narrow question: with the candidate's
head fixed at its moved native input chart, can any of the existing 111 native
body ports be reassigned to it while preserving their charts and ranks and the
original eight-dimensional main-contact contract? The answer is **no**.

The retained source's `Atlas.main_contacts` requires a quartet with dimensions
`(head, body, body start, head end) = (1, 7, 0, 8)`, orthogonal head and body,
and combined rational rank eight. The independent literal `Charts` rule
requires the same dimensions and an invertible head/body basis. In the pinned
original, head owner 17 starts at chart 19, while body owner 128 starts at
chart 0 and ends at chart 542. The original quartet has dimensions `(1,7,0,8)`;
its head is `(1,0,1,0,-1,0,-1,0)`, and head followed by the seven body rows
has exact determinant `-4`.

The supplied candidate changes precisely one public starting chart: owner 17
moves from 19 to 0. Its final charts and rational frames match the original.
This makes the head dimension zero. Each of the 111 candidate bodies starts
at a zero-dimensional chart and ends at a seven-dimensional chart of rank 7.
Hence every moved-head/body pair has dimensions `(0,7,0,8)` and rank 7. Both
source implementations reject all 111 choices. The computational test
*duplicates* each body at slot 17 rather than requiring a permutation; that is
a relaxation containing every possible reassignment or permutation.

The exact [roster](OWNER17-REASSIGNMENT.json) records all 111 bodies and their
checks. As a positive control, restoring the original head makes all 111
original contacts pass both source implementations. The old head is compatible
with only body index 17 among the existing body roster. A second abstract
control shows that each body has a rational dual vector that would supply the
missing independent dimension. This is linear-algebraic existence only: it
does not construct or fund a new physical axis or changed wrapper.

Thus retaining the original rank-eight contact needs an additional independent
dimension and a revised binding, or a change outside the stated model such as
restoring the old one-dimensional head. Merely relabeling the existing body
ports cannot do it. Changing native charts, ranks, the target dimension or the
wrapper/caller is outside this result; a seven-dimensional replacement target
would be a different interface. Physical erasure, stock, caller costs, the
outer application and any κ improvement are not established.

The embedded source archive is the supplied Round 10 native replay, SHA-256
`41d208aa309f366ccf64eedd406651309be38562941cee2aa8314dcbdc961f79`.
The original #7830 word and supplied changed word are individually pinned
inside the verifier. The campaign supplied the #8006 head as context; this
packet does not refresh its remote state. Python 3.11+ with assertions enabled
is sufficient:

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify_owner17.py
```

The verifier authenticates every entry of the embedded archive, checks the
source's two actual contact implementations, independently computes the
rational ranks for all 111 bodies, and byte-compares the saved receipt without
overwriting it.
