# Exact binary stock before the original owner-221 cutoff

The exact 680-owner native rebind in [#8017](https://github.com/CrocSwap/integer-mult-bounds/pull/8017) also meets the original numeric chart-635 cutoff after retiming one terminal-only packet. Its four owner-221 stock arrivals occur at instruction indices **10118, 10142, 10154 and 19906**. The last precedes the original final receipt at **19907**. The earlier #8017 tape had its last receipt at 19910; its stock was before the relative feedback event but after the original numeric cutoff. These times certify stock availability. The emitted tape computes and swaps its public outputs later.

Move the four-instruction block for the original **3406** (`112→630`) from its old position to immediately after the original **3408**. Its receiver only supplies the eventual owner-216 output, so no intervening paid reader is moved. The corresponding 3407 paid event now occurs at 19902. The new 0→19 receipt still delivers x17 before 785, and the original early chart-268 values, four chart-635 receipts, and all 63 former 3410 reader values survive. The re-timed tape matches every packet transfer coefficient in the original #8017 tape and all **680 forward and 680 literal-adjoint outputs**. Owner 221 returns x110+x221 forward and x221 in the adjoint. Owner 679 returns x679 in both. Word SHA-256 `6073e796eacaf9cdb6e282752dc61c1db0e1baf7e2b734369b0652a781ba9603`.

Retiming preserves every paid grade and all endpoint layouts. The pinned paired caller therefore still rejects the zero-dimensional new head at port 17. The independent reassignment check in `PORT-REASSIGNMENT.md` shows that all **111** original bodies have rank seven. Reassigning any one leaves the pair at rank seven rather than the required eight. One further independent dimension is necessary to retain the old interface. The required dimension alone supplies neither a physical axis nor its price. Even granting the original #8017 hypothetical 36-fold native target credit, the binary margin remains about **−0.07064423157095918** at κ = 0.00388. The separate incumbent 48-call rational margin is about **+0.13897452233425271**. Owned retirement is dirty in 3554 fields per orientation. Physical erasure, a revised outer binding and its complete price, and a new κ bound remain open.

## Sources and reproduction

The nested archive is the exact named #8017 package at head `6e090c180ad5c8c9a3ed50e94737fd2be04adf54` (archive SHA-256 `41d208aa309f366ccf64eedd406651309be38562941cee2aa8314dcbdc961f79`). It retains the original native sources and inputs from [#7830](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier). The round starts from [#8006](https://github.com/CrocSwap/integer-mult-bounds/pull/8006) at `4035f150285513852cab8d00b8bfc233c699ea0a`. The independent port test reuses the exact caller source. Its absence of a geometry-compatible body does not claim that changing the caller or native frames is impossible.

Use Python 3.12 or later. Both scripts compare against the frozen receipts. This contribution was prepared for Clear1nsight with substantial OpenAI Codex assistance. Source licenses and notices are retained in the nested package.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify_clock.py
python3 -I -B verify_owner17.py
```
