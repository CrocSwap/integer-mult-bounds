# SPDX-License-Identifier: Apache-2.0
"""Deliver old feedback stock and keep owner 221 before its numeric cutoff."""
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = '41d208aa309f366ccf64eedd406651309be38562941cee2aa8314dcbdc961f79'


def run(source):
    sys.path.insert(0, str(source / 'source/vendor'))
    import binary_operator as op
    import bit_native

    raw = (source/'productive17-word.json.gz').read_bytes()
    assert sha256(raw).hexdigest() == '02c0c7c0c0be4875a9e2265ba4c37559648035304f3fe95cb6b9a8932439640b'
    rebound = json.loads(gzip.decompress(raw))
    old = op.load_json(source/'source/inputs/WORD.json.gz', op.WORD_GZIP, True)
    _, _, old_moves, _, old_clocks = bit_native.extract(old)
    initial, final, moves, rows, clocks = bit_native.extract(rebound)
    order = sorted(old_moves, key=old_clocks.get)
    order.remove(3410)
    order.insert(order.index(785), 3554)
    labels = dict(zip(order, sorted(moves, key=clocks.get), strict=True))
    for packet, terminal in [(3388,172), (3406,216)]:
        moved = labels[packet]
        assert [k for k,v in rows.items() if v >> moved & 1] == [~terminal]
        order.remove(packet)
    order.remove(3409)
    after_2947 = order.index(2947) + 1
    order[after_2947:after_2947] = [3409]
    after_3408 = order.index(3408) + 1
    order[after_3408:after_3408] = [3388, 3406]
    timed = bit_native.emit_word(rebound, initial, final, moves, rows, [labels[k] for k in order])
    _, _, timed_moves, new_rows, timed_clocks = bit_native.extract(timed)
    new = dict(zip(order, sorted(timed_moves, key=timed_clocks.get), strict=True))
    assert all(timed_moves[new[k]] == moves[labels[k]] for k in order)
    read221 = [2876, 2882, 2885, 3408]
    assert set(bit_native.indices(new_rows[~221])) == {new[k] for k in read221}
    atlas = op.Atlas(old['frames'])
    native = op.run_tape(old, atlas, False)
    for reverse in (False, True):
        first = op.run_tape(rebound, atlas, reverse)
        after = op.run_tape(timed, atlas, reverse)
        assert [after.packets[new[k]].grade for k in order] == [first.packets[labels[k]].grade for k in order]
        assert [after.packets[new[k]].arrival.row for k in order] == [first.packets[labels[k]].arrival.row for k in order]
        assert after.output == first.output == op.expected_operator(reverse)
        assert after.dirty == first.dirty == 3554
        if not reverse:
            assert initial[17] == 0 and timed_moves[new[3409]] == (421,0)
            assert after.packets[new[3409]].arrival.row ^ (1<<17) == native.packets[3410].arrival.row
            assert all(after.packets[new[k]].arrival.row == native.packets[k].arrival.row for k in read221)
    assert timed_clocks[new[3409]] == 10396
    assert timed_clocks[new[3407]] == 19902 < old_clocks[3407] == 19903
    assert timed_clocks[new[3408]] == 19906 < old_clocks[3408] == 19907
    raw = gzip.compress(json.dumps(timed,sort_keys=True,separators=(',',':')).encode(),mtime=0)
    return dict(new_word_sha256=sha256(raw).hexdigest(),
                paid_clocks={k:timed_clocks[new[k]] for k in (2947,3388,3406,3407,3408,3409)},
                owner221_receipts=[timed_clocks[new[k]] for k in read221],
                exact_old_3410_in_chart0_stock_by=10396, literal_output_rows_each_way=680,
                same_paid_fields_and_prices=True, dirty_retirement_each_way=3554), raw


archive = ROOT/'source-replay.tar.gz'
assert sha256(archive.read_bytes()).hexdigest() == SOURCE
with tempfile.TemporaryDirectory() as directory:
    with tarfile.open(archive) as files:
        files.extractall(directory, filter='data')
    result, native_word = run(Path(directory))
receipt = ROOT/'EARLY-FEEDBACK.json'
text = json.dumps(result, indent=2, sort_keys=True) + '\n'
if sys.argv[1:] == ['--write-receipt']:
    receipt.write_text(text)
    (ROOT/'EARLY-FEEDBACK-WORD.json.gz').write_bytes(native_word)
else:
    assert not sys.argv[1:] and receipt.read_text() == text
    assert (ROOT/'EARLY-FEEDBACK-WORD.json.gz').read_bytes() == native_word
print(text, end='')
