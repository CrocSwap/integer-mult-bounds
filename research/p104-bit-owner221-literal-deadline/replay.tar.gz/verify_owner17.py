#!/usr/bin/env python3
"""Independent exact-rational port-17 body-reassignment cut; no kappa claim."""
import gzip,hashlib,importlib.util,io,json,sys,tarfile,tempfile
from collections import Counter
from fractions import Fraction as F
from pathlib import Path

P=Path(__file__).resolve().parent
ARCH='41d208aa309f366ccf64eedd406651309be38562941cee2aa8314dcbdc961f79'
OLD='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
NEW='02c0c7c0c0be4875a9e2265ba4c37559648035304f3fe95cb6b9a8932439640b'
OP='36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349'
LIT='4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c'
def sha(s):return hashlib.sha256(s).hexdigest()
def rank(rows):
 if not rows:return 0
 a=[[F(x) for x in r] for r in rows];i=0
 for j in range(len(a[0])):
  pivot=next((k for k in range(i,len(a)) if a[k][j]),None)
  if pivot is None:continue
  a[i],a[pivot]=a[pivot],a[i];v=a[i][j];a[i]=[x/v for x in a[i]]
  for k in range(i+1,len(a)):
   v=a[k][j]
   if v:a[k]=[x-v*y for x,y in zip(a[k],a[i])]
  i+=1
  if i==len(a):break
 return i
def determinant(rows):
 a=[[F(x) for x in r] for r in rows];n=len(a);assert n and all(len(x)==n for x in a);result=F(1)
 for i in range(n):
  p=next((j for j in range(i,n) if a[j][i]),None)
  if p is None:return F(0)
  if p!=i:a[i],a[p]=a[p],a[i];result=-result
  c=a[i][i];result*=c
  for j in range(i+1,n):
   q=a[j][i]/c
   a[j]=[x-q*y for x,y in zip(a[j],a[i])]
 return result
def orth(a,b):return all(sum(F(x)*F(y) for x,y in zip(u,v))==0 for u in a for v in b)
def loadmodule(name,data,dest):
 path=dest/(name+'.py');path.write_bytes(data);spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

def run():
 raw=(P/'source-replay.tar.gz').read_bytes();assert sha(raw)==ARCH,'source archive hash'
 with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as t:
  members=t.getmembers();assert all(m.isfile() and '..' not in Path(m.name).parts and not Path(m.name).is_absolute() for m in members)
  files={m.name:t.extractfile(m).read() for m in members};assert len(files)==len(members)
 manifest={line.split('  ',1)[1]:line.split('  ',1)[0] for line in files['SHA256SUMS'].decode().splitlines()};assert set(files)==set(manifest)|{'SHA256SUMS'}
 assert all(sha(files[n])==v for n,v in manifest.items())
 assert sha(files['source/inputs/WORD.json.gz'])==OLD and sha(files['productive17-word.json.gz'])==NEW
 assert sha(files['source/vendor/binary_operator.py'])==OP and sha(files['source/vendor/literal.py'])==LIT
 w0=json.loads(gzip.decompress(files['source/inputs/WORD.json.gz']));w=json.loads(gzip.decompress(files['productive17-word.json.gz']));sources=json.loads(files['source/SOURCES.json'])
 assert sources['construction']['head']=='87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'
 assert sha(json.dumps(w0,sort_keys=True,separators=(',',':')).encode())=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
 assert w0['public']==w['public']==680 and w0['frames']==w['frames'] and w0['final']==w['final']
 diff=[(i,a,b) for i,(a,b) in enumerate(zip(w0['start'],w['start'],strict=True)) if a!=b];assert diff==[(17,19,0)]
 f=w['frames'];B=lambda c:f[str(c)]['B'];A=lambda c:f[str(c)]['A'];d=lambda c:f[str(c)]['dim']
 assert (w0['start'][17],w['start'][17],w['final'][17],w['start'][128],w['final'][128])==(19,0,1,0,542)
 oldhead,newhead,oldbody=B(19),B(0),B(542)
 assert (d(19),d(0),d(1),d(542))==(1,0,8,7)
 assert rank(oldhead)==1 and rank(newhead)==0 and rank(oldbody)==7 and rank(oldhead+oldbody)==8 and rank(newhead+oldbody)==7
 assert orth(oldhead,oldbody) and orth(newhead,oldbody) and determinant(oldhead+oldbody)!=0
 assert len(A(542))==1 and all(F(x)==-F(y) for x,y in zip(A(542)[0],oldhead[0]))
 with tempfile.TemporaryDirectory(prefix='owner17-source-') as tmp:
  td=Path(tmp);op=loadmodule('owner17_source_atlas',files['source/vendor/binary_operator.py'],td);lit=loadmodule('owner17_source_literal',files['source/vendor/literal.py'],td)
  atlas=op.Atlas(w['frames']);charts=lit.Charts(w['frames'])
  assert atlas.main_contacts(w0['start'],w0['final'])==111 and charts.main_contacts(w0['start'],w0['final'])==111
  def source_failure(starts,ends):
   try:atlas.main_contacts(starts,ends)
   except ValueError as e:return str(e)
   raise AssertionError('source Atlas accepted moved head')
  def literal_failure(starts,ends):
   try:charts.main_contacts(starts,ends)
   except ValueError as e:return str(e)
   raise AssertionError('literal Charts accepted moved head')
  assert source_failure(w['start'],w['final'])=='contact dimensions at 17'
  assert literal_failure(w['start'],w['final'])=='literal main port quartet'
  fixed=list(w['start']);fixed[17]=19
  assert atlas.main_contacts(fixed,w['final'])==111 and charts.main_contacts(fixed,w['final'])==111
  roster=[]
  for j in range(111):
   owner=j+111;sc=w['start'][owner];ec=w['final'][owner];body=B(ec);comp=A(ec)
   assert d(sc)==0 and d(ec)==7 and len(body)==7 and len(comp)==1 and rank(body)==7 and rank(comp+body)==8 and orth(comp,body)
   dims=(d(w['start'][17]),d(ec),d(sc),d(w['final'][17]));joint=rank(newhead+body)
   assert dims==(0,7,0,8) and joint==7
   # This duplicates body j at slot 17, an intentional relaxation: a true
   # permutation can only choose one of these same 111 candidates for slot 17.
   ss=list(w['start']);ee=list(w['final']);ss[128]=sc;ee[128]=ec
   aerr=source_failure(ss,ee);lerr=literal_failure(ss,ee)
   assert aerr=='contact dimensions at 17' and lerr=='literal main port quartet'
   roster.append({'body_index':j,'body_owner':owner,'body_start_chart':sc,'body_final_chart':ec,'body_rank':rank(body),'zero_head_body_rank':joint,'deficit_vs_rank8':8-joint,'old_head_would_match_this_body':orth(oldhead,body) and rank(oldhead+body)==8,'atlas_rejection':aerr,'literal_rejection':lerr,'abstract_dual_axis_yields_rank8':True})
  assert len(roster)==111 and len({r['body_final_chart'] for r in roster})==111
  compatible=[x['body_index'] for x in roster if x['old_head_would_match_this_body']]
  result={'status':'PASS_BOUNDED_FIXED_8_AXIS_OBSTRUCTION_NO_KAPPA_CLAIM',
    'source':{'provided_campaign_pr8006_head':'4035f150285513852cab8d00b8bfc233c699ea0a','pr7830_head_from_archive':sources['construction']['head'],'archive_sha256':ARCH,'archive_manifest_entries_verified':len(manifest),'original_word_sha256':OLD,'new_word_sha256':NEW,'source_atlas_sha256':OP,'source_literal_sha256':LIT,'campaign_head_scope':'#8006 is contextual pin supplied by campaign; this local result does not refresh its remote status'},
    'source_rule':{'ports':111,'quartet_dimensions':[1,7,0,8],'orthogonality_required':True,'sum_rational_rank':8,'working_axis_interpretation':'For the old wrapper contract only; physical source also requires complementary projectors and invertible stage basis.'},
    'port17':{'original_head_chart':19,'moved_head_chart':0,'head_final_chart':1,'paired_body_owner':128,'body_start_chart':0,'body_final_chart':542,'old_dimensions':[1,7,0,8],'new_dimensions':[0,7,0,8],'old_head_vector':oldhead[0],'body_dual_vector':A(542)[0],'body_dual_is_negative_old_head':True,'original_head_plus_body_determinant':str(determinant(oldhead+oldbody)),'old_head_body_rank':8,'moved_head_body_rank':7,'moved_head_body_orthogonal_vacuously':True,'atlas_candidate_failure':'contact dimensions at 17','literal_candidate_failure':'literal main port quartet'},
    'reassignment':{'total_candidate_body_ports':len(roster),'distinct_body_final_charts':len({r['body_final_chart'] for r in roster}),'all_body_dimensions':dict(Counter(str(r['body_rank']) for r in roster)),'moved_head_body_rank_counts':dict(Counter(str(r['zero_head_body_rank']) for r in roster)),'dimension_compatible_candidates':0,'independent_axis_deficit_for_8_dimensional_interface':1,'old_head_compatible_body_indices':compatible,'all_actual_atlas_source_checks_reject':True,'all_actual_literal_source_checks_reject':True,'scope':'Every pairing uses one of the existing 111 unchanged native body ports. A true permutation is contained in this relaxation. Frames, endpoint charts, ranks and 8-dimensional required contact are fixed.'},
    'controls':{'original_caller_111_contacts_pass_both_source_implementations':True,'restore_old_head_candidate_passes_both_source_implementations':True,'abstract_body_dual_fills_missing_axis_all_111':True,'abstract_completion_scope':'An exact rational-space existence control only. Does not provide a physical axis, a modified wrapper, or an outer invoice.'},
    'conclusion':'No permutation or reassignment of the 111 preserved native bodies supplies a one-dimensional head or reaches the old rank-8 contact with the moved zero-dimensional head. To retain that same 8D head/body contract, some new independent dimension must be supplied and bound; restoring the old one-dimensional native head is one possibility but reverses this head move. A wrapper reduced to a 7D target, changed charts or ranks, or a different caller lies outside this cut. No physical construction or kappa result is established.',
    'body_roster':roster}
  return result

def main():
 out=run();rendered=json.dumps(out,indent=2,sort_keys=True)+'\n';dest=P/'OWNER17-REASSIGNMENT.json'
 if '--write' in sys.argv:dest.write_text(rendered)
 else:assert dest.read_text()==rendered,'saved roster mismatch; receipt unchanged'
 print('PASS 111/111 source/literal exclusions, body rank7 vs required rank8; original 17/128 passes')
 print('old head compatible body indices',out['reassignment']['old_head_compatible_body_indices'])
 print('original determinant',out['port17']['original_head_plus_body_determinant'])
if __name__=='__main__':main()
