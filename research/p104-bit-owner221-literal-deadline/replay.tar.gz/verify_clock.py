# SPDX-License-Identifier: Apache-2.0
"""Move only a terminal-only packet block and check the literal owner-221 clock."""
from collections import Counter
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE_ARCHIVE = '41d208aa309f366ccf64eedd406651309be38562941cee2aa8314dcbdc961f79'
OLD_WORD = 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
REBIND = '02c0c7c0c0be4875a9e2265ba4c37559648035304f3fe95cb6b9a8932439640b'
RECEIPTS = [2876, 2882, 2885, 3408]


def digest(data):
    return sha256(data).hexdigest()


def public_word(path, expected):
    data = path.read_bytes()
    assert digest(data) == expected
    return json.loads(gzip.decompress(data))


def study(source):
    sys.path.insert(0, str(source/'source'/'vendor'))
    import binary_operator as op
    import bit_native

    old = public_word(source/'source'/'inputs'/'WORD.json.gz', OLD_WORD)
    rebound = public_word(source/'productive17-word.json.gz', REBIND)
    _, _, old_moves, old_rows, old_clocks = bit_native.extract(old)
    expected = sorted(old_moves, key=old_clocks.get)
    expected.remove(3410)
    expected.insert(expected.index(785), 3554)
    _, _, moves, rows, clocks = bit_native.extract(rebound)
    labels = dict(zip(expected, sorted(moves, key=clocks.get), strict=True))
    displaced = labels[3406]
    assert [k for k, row in rows.items() if row >> displaced & 1] == [~216]
    assert moves[displaced] == (112, 630)
    end = clocks[displaced] + 1
    start = end - 4
    program = rebound['program']
    block = program[start:end]
    assert [row[0] for row in block] == ['INIT', 'ADD', 'ADD', 'MOVE']
    assert len({e[1] for e in block}) == 1
    insert = clocks[labels[3408]] + 1
    assert end < clocks[labels[3407]] < insert - 1 < clocks[labels[3409]]
    retimed = rebound | {'program': program[:start] + program[end:insert] + block + program[insert:]}
    expected.remove(3406)
    expected.insert(expected.index(3408) + 1, 3406)
    _, _, timed_moves, timed_rows, timed_clocks = bit_native.extract(retimed)
    new_labels = dict(zip(expected, sorted(timed_moves, key=timed_clocks.get), strict=True))
    assert all(timed_moves[new_labels[k]] == moves[labels[k]] for k in expected)

    atlas = op.Atlas(old['frames'])
    full = []
    for reverse in (False, True):
        before = op.run_tape(rebound, atlas, reverse)
        after = op.run_tape(retimed, atlas, reverse)
        assert after.output == before.output == op.expected_operator(reverse)
        assert after.dirty == before.dirty == 3554
        assert Counter(p.grade for p in after.packets.values()) == Counter(p.grade for p in before.packets.values())
        assert all(after.packets[new_labels[k]].arrival.row == before.packets[labels[k]].arrival.row for k in expected)
        full.append(after)

    assert list(bit_native.indices(old_rows[~221])) == RECEIPTS
    assert sorted(bit_native.indices(timed_rows[~221])) == sorted(new_labels[k] for k in RECEIPTS)
    original = [old_clocks[k] for k in RECEIPTS]
    before = [clocks[labels[k]] for k in RECEIPTS]
    after = [timed_clocks[new_labels[k]] for k in RECEIPTS]
    assert original[-1] == 19907 and before[-1] == 19910 and after[-1] == 19906
    assert max(after) < original[-1]
    assert after[-1] < timed_clocks[new_labels[3406]] < timed_clocks[new_labels[3409]]
    rs = dict(old_paid_221_clocks=original, previous_paid_221_clocks=before,
              retimed_paid_221_clocks=after, retimed_3407=timed_clocks[new_labels[3407]],
              retimed_3406=timed_clocks[new_labels[3406]], retimed_3409=timed_clocks[new_labels[3409]],
              all_680_rows_exact_both_orientations=True, identical_paid_grades=True,
              forward221=list(bit_native.indices(full[0].output[221])), adjoint221=[221],
              forward679=[679], adjoint679=[679], dirty=[p.dirty for p in full],
              word_sha256=digest(gzip.compress(json.dumps(retimed,sort_keys=True,separators=(',',':')).encode(),mtime=0)))
    return rs


archive = ROOT/'source-replay.tar.gz'
assert digest(archive.read_bytes()) == SOURCE_ARCHIVE
with tempfile.TemporaryDirectory() as temp:
    root = Path(temp)
    with tarfile.open(archive) as files:
        files.extractall(root, filter='data')
    rendered = json.dumps(study(root), indent=2, sort_keys=True)+'\n'
receipt = ROOT/'OWNER221-LITERAL-CLOCK.json'
if sys.argv[1:] == ['--write-receipt']:
    receipt.write_text(rendered)
else:
    assert not sys.argv[1:] and receipt.read_text() == rendered
print('PASS: terminal-only 3406 retimed; owner 221 ready at 19906; both 680-row operators and exact prices preserved.')
