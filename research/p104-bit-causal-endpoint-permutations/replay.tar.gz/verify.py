#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Exhaustive chart-legal permutation, causality and endpoint matrix-rank check."""
import argparse
from collections import Counter,defaultdict
from functools import cache
from hashlib import sha256
from itertools import combinations
from math import lcm
from pathlib import Path
import json
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'/'vendor'));sys.path.insert(0,str(ROOT/'source'))
import bit_native as primitive
import binary_operator as tape
import common

def need(ok,message):
    if not ok:raise ValueError(message)

def xor(seq):
    x=0
    for v in seq:x^=v
    return x

class Basis:
    def __init__(self):self.rows={}
    def reduce(self,w):
        tags=0
        while w:
            i=w.bit_length()
            if i not in self.rows:break
            v,t=self.rows[i];w^=v;tags^=t
        return w,tags
    def insert(self,w,t=0):
        r,q=self.reduce(w)
        if r:self.rows[r.bit_length()]=r,t^q

class Audit:
    def __init__(self):
        w,caller,_,_,_,paid,targets,rational=common.baseline()
        self.word=w;self.ori=primitive.extract(w);self.start,self.end,self.route,self.rows,clock=self.ori
        self.keys=sorted(set(self.route)-{3553});need(len(self.keys)==2873,'nonbridge roster')
        self.atlas=tape.Atlas(w['frames'])
        f,r=(tape.run_tape(w,self.atlas,x) for x in (False,True))
        self.X={p:q.arrival.row for p,q in f.packets.items()};self.Y={p:q.arrival.row for p,q in r.packets.items()}
        need(f.output==tape.expected_operator(False) and r.output==tape.expected_operator(True),'two full literal operators')
        self.out=f.output;self.col=r.output;self.localX=defaultdict(int);self.localY=defaultdict(int)
        for i,c in self.start.items():self.localX[c]|=1<<i
        for i,c in self.end.items():self.localY[c]|=1<<i
        self.anc={}
        for p in sorted(self.route,key=clock.get):
            hits=0
            for j in primitive.indices(self.rows[p]):
                if j in self.anc:hits|=self.anc[j]
            self.anc[p]=hits|(1<<p)
        def ints(row):
            d=lcm(*(x.denominator for x in row));return tuple(int(d*v) for v in row)
        self.fr={c:tuple(map(ints,vs)) for c,vs in self.atlas.body.items()};self.dual={c:tuple(map(ints,vs)) for c,vs in self.atlas.dual.items()}
        self.old={p:q.grade for p,q in f.packets.items()}
        self.rates=tuple(map(common.D,('0.00388','0.0038800000000000083')))
        self.base=[common.moment(paid,targets,k) for k in self.rates]
        self.rational=[common.moment(rational['signed']['paid'],rational['signed']['productive'],k) for k in self.rates]
    @cache
    def leg(self,a,b):
        if a==b:return 0
        x,y=sorted((a,b),key=lambda t:len(self.fr[t]))
        grade=len(self.fr[y])-len(self.fr[x])
        if grade and not any(sum(k*l for k,l in zip(u,v)) for u in self.fr[x] for v in self.dual[y]):return grade
        return -1
    @cache
    def price(self,olds,news):
        sig=Counter(olds);sig.subtract(news)
        P={g:-v for g,v in sig.items() if g and v<0};T={g:v for g,v in sig.items() if g and v>0}
        ds=[common.scale(common.moment(P,T,k),36) for k in self.rates]
        if all(not z for z in [*P,*T]):return 0,False
        need(all(d[0]>0 or d[1]<0 for d in ds),'resolved primitive tariff sign')
        need((ds[0][0]>0)==(ds[1][0]>0),'stable tariff sign')
        totals=[common.plus(b,d) for b,d in zip(self.base,ds)]
        need(all(z[0]>0 or z[1]<0 for z in totals),'resolved complete caller sign')
        return 1 if ds[0][0]>0 else -1,all(z[0]>0 for z in totals)
    @cache
    def block(self,a,b):
        C,R=Basis(),Basis()
        for i in primitive.indices(self.localX[a]):C.insert(self.col[i]&self.localY[b],1<<i)
        for i in primitive.indices(self.localY[b]):R.insert(self.out[i]&self.localX[a])
        need(len(C.rows)==len(R.rows),'baseline subblock rank')
        return C,R
    def single(self,p,q,x,y):
        if self.anc[q]>>p&1:return 'cyclic',None
        need(x and y,'nondegenerate fixed switch')
        # M^-1=M for the pinned square public shear.
        inv=y^((y&((1<<111)-1))<<111)
        if (x&inv).bit_count()&1:return 'singular',None
        for a,m in self.localX.items():
            u=m&x
            if not u:continue
            for b,n in self.localY.items():
                v=n&y
                if not v:continue
                C,R=self.block(a,b);cr,rep=C.reduce(v);rr,_=R.reduce(u)
                change=1 if cr and rr else -1 if not cr and not rr and (u&rep).bit_count()&1 else 0
                if change:
                    # Independently recompute both ranks of the named subblock
                    # directly from the literal public columns.
                    B=Basis()
                    for j in primitive.indices(m):B.insert((self.col[j]&n)^(v if u>>j&1 else 0))
                    need(len(B.rows)-len(C.rows)==change,'literal changed subblock rank')
                    return 'changed_subblock',(a,b,len(C.rows),len(B.rows))
        raise ValueError('potential local endpoint equivalence')
    def control(self,p,q,status):
        routes=self.route.copy();rows=self.rows.copy()
        a,b=routes[p];A,B=routes[q]
        routes[p],routes[q]=(A,b),(a,B)
        rows[p],rows[q]=rows[q],rows[p]
        try:order=primitive.schedule(self.start,self.end,routes,rows)
        except ValueError as exc:
            need(status=='cyclic' and str(exc)=='causal binary packet schedule','literal cyclic control')
            return dict(packets=[p,q],closed_by='physical dependency')
        need(status!='cyclic','causal control')
        for k in order:
            if routes[k][0]!=routes[k][1]:continue
            t=rows.pop(k);routes.pop(k)
            for j,w in rows.items():
                if w>>k&1:rows[j]^=t^(1<<k)
        order=primitive.schedule(self.start,self.end,routes,rows)
        changed=primitive.emit_word(self.word,self.start,self.end,routes,rows,order)
        f,r=(tape.run_tape(changed,self.atlas,rev) for rev in (False,True))
        x,y=self.X[p]^self.X[q],self.Y[p]^self.Y[q]
        target=[row^(x if y>>i&1 else 0) for i,row in enumerate(self.out)]
        dual=[col^(y if x>>i&1 else 0) for i,col in enumerate(self.col)]
        need(f.output==target and r.output==dual,'two literal lines of the computed rank-one disturbance')
        old=Counter(self.old.values());old.subtract([self.old[p],self.old[q]]);old.update(g for g in (self.leg(A,b),self.leg(a,B)) if g)
        need(Counter(k.grade for k in f.packets.values())==+old==Counter(k.grade for k in r.packets.values()),'both charged controls')
        return dict(packets=[p,q],word=tape.canonical_hash(changed),changed_forward_rows=y.bit_count(),changed_adjoint_rows=x.bit_count(),dirty=[f.dirty,r.dirty])
    def cycle(self,swaps):
        # Determine the dependencies on the cut labels in each new sender
        # expression after all untouched rows are eliminated. OR retains true
        # causal dependencies, including paths whose algebraic effects cancel.
        slots=sorted(set(j for pair in swaps for j in pair))
        peer={i:j for p,q in swaps for i,j in ((p,q),(q,p))}
        labels={j:1<<i for i,j in enumerate(slots)};cache_={i:0 for i in self.start}
        def up(j):
            if j in labels:return labels[j]
            if j not in cache_:
                v=0
                for k in primitive.indices(self.rows[j]):v|=up(k)
                cache_[j]=v
            return cache_[j]
        parents=[]
        for j in slots:
            v=0
            for k in primitive.indices(self.rows[peer[j]]):v|=up(k)
            parents.append(v)
        done=0
        for _ in slots:
            for i,parents_i in enumerate(parents):
                if not parents_i&~done:done|=1<<i
        return done!=(1<<len(slots))-1
    def run(self):
        solo=Counter();double=Counter();cache_by=defaultdict(list);strict=[];cert=sha256();dwit=sha256();controls={}
        for p,q in combinations(self.keys,2):
            a,b=self.route[p];A,B=self.route[q]
            g=self.leg(a,B);h=self.leg(A,b)
            if min(g,h)<0:continue
            old=tuple(sorted((self.old[p],self.old[q])));new=tuple(sorted((g,h)))
            sign,funded=self.price(old,new)
            x=self.X[p]^self.X[q];y=self.Y[p]^self.Y[q]
            if a!=A and b!=B:
                solo['nested_different_ends']+=1
                if funded:
                    solo['qualified']+=1
                    status,detail=self.single(p,q,x,y);solo[status]+=1
                    if status not in controls:controls[status]=self.control(p,q,status)
                    cert.update(f'{p},{q},{status},{detail}\n'.encode())
            direct=(self.rows[q]>>p)&1 or (self.rows[p]>>q)&1
            if direct:continue
            double['legal_without_direct_self']+=1
            pair=(p,q,old,new)
            cache_by[x,y].append(pair)
            if sign>0:
                need(x and y,'all nonself positive switches have both ranks one')
                strict.append((pair,x,y))
        seen=set()
        for one,x,y in strict:
            for key in [(0,0),(x,0),(0,y),(x,y)]:
                for two in cache_by.get(key,()):
                    a,b=one[:2],two[:2]
                    if len(set(a+b))!=4:continue
                    pair=tuple(sorted((a,b)))
                    if pair in seen:continue
                    seen.add(pair);double['rank_compatible']+=1
                    old=tuple(sorted(one[2]+two[2]));new=tuple(sorted(one[3]+two[3]))
                    if not self.price(old,new)[1]:continue
                    double['qualified']+=1
                    need(self.cycle(pair),'every rank-compatible funded double switch has genuine causal cycle')
                    double['cyclic']+=1;dwit.update(str(pair).encode()+b'\n')
        double['strict_positive_first']=len(strict)
        need(solo=={'nested_different_ends':294118,'qualified':11441,'cyclic':6176,'singular':2208,'changed_subblock':3057},'full single census')
        result=dict(pins=dict(native=tape.WORD,gzip=tape.WORD_GZIP),baseline={str(k):dict(binary=common.display(b),rational=common.display(r)) for k,b,r in zip(self.rates,self.base,self.rational)},single=solo,double=double,controls=controls,single_certificate_digest=cert.hexdigest(),double_certificate_digest=dwit.hexdigest())
        return result
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--write',action='store_true');args=ap.parse_args()
    obj=Audit().run();s=json.dumps(obj,indent=2,sort_keys=True)+'\n'
    if args.write:(ROOT/'RESULT.json').write_text(s)
    else:need((ROOT/'RESULT.json').read_text()==s,'complete deterministic census and ranks')
    print('PASS',obj['single'],obj['double'],flush=True)
