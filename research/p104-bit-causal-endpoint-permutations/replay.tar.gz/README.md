# Paid endpoint permutations on the P104 binary word

The native binary program from [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) permits 294,118 chart-nested interchanges of two nonbridge scalar senders with distinct original origins and distinct original destinations. Of these, 11,441 would give a positive complete signed 36-call BIT margin at both 0.00388 and 0.0038800000000000083. All fail one of three necessary tests.

| Outcome of a funded single exchange | Number |
| --- | ---: |
| Actual sender dependencies contain a directed cycle | 6,176 |
| The resulting full 680-by-680 operator loses invertibility | 2,208 |
| A block between a named initial chart and a named terminal chart changes rank | 3,057 |

The latter two tests permit arbitrary invertible changes of basis among public inputs at each initial chart and arbitrary invertible recombinations of the original public output rows at each terminal chart. Surviving internal sender equations are fixed apart from the explicitly interchanged sources. Additional historical stock at a terminal is outside this endpoint-basis hypothesis.

A second census permits two disjoint sender exchanges on four distinct paid labels, including a neutral cocharted exchange. With fixed original terminal equations, no pair can realize the full required operator and a strictly positive complete trial margin. This result allows both individual exchanges to be cyclic when viewed in isolation. It tests their combined physical dependency graph.

## Single exchange

For a paid label p, let Xp be its global binary value as a row on the original inputs. Let Yp be its global output influence as a column. At p and q interchange their original supplier chart and supplier XOR expression. Keep each original recipient label, destination chart and subsequent operand reference. A same-chart result is a local XOR expression with zero transport charge. Every genuine transfer must have nested rational charts.

The original operator M is invertible and M inverse equals M for the 111 native shears. If p is an ancestor of q, the new assignment to p depends on its own value, through the old supplier expression for q. Consequently the modified graph contains a directed cycle. This includes dependencies whose formal GF(2) contributions cancel. For an acyclic single exchange the new transfer is

    M' = M + (Yp + Yq) (Xp + Xq).

The verifier replays one changed primitive in each acyclic rejection class. Its forward and adjoint operators independently match this rank-one formula. It also compiles a directed-cycle control through the physical stock scheduler, which rejects it.

A rank-one update of invertible M is singular exactly when (Xp+Xq) M inverse (Yp+Yq) equals one. For any remaining update, restrict the input columns to one original chart and the output rows to one other chart. Independent invertible maps at the initial and terminal charts preserve the rank of every such block. The verifier produces a changing block for each of the 3,057 residual cases, then recomputes its old and new rank from the actual 680-coordinate columns.

## Two disjoint exchanges

Let each exchange i have input difference xi between its two old paid payloads and output difference yi between its two old output influences. For each switch its two innovations, measured relative to the old sender equations on the changed history, are identical over GF(2). Denote this common innovation by zi. Acyclicity of the original and changed circuits gives a uniquely solvable two-variable response system

    z = x + T z.

Indeed an unforced nonzero solution would be a nonzero internal trajectory of the acyclic changed network with all public inputs zero. Equivalently the original acyclic equations first reconstruct every changed receipt from the specified innovations, and the two new switch equations then enforce this system. Therefore the row rank of the two innovations equals the row rank of the two original input differences. The changed output differs by y1 z1 + y2 z2. Vanishing requires

    rank(x1,x2) + rank(y1,y2) <= 2.

At least one of the two exchanges must be strictly price-positive. A direct self-reference in any individual exchanged supplier expression survives a disjoint second exchange. After removing such cases there are 576,300 legally nested single exchanges, including neutral cocharted candidates. Exactly 5,858 are strictly price-positive. Each has nonzero x and nonzero y. Consequently the second input difference must be either zero or the first input difference, and the same condition applies to the output differences. The digest-checked search finds exactly 816 disjoint pairs satisfying the rank condition. All 816 are economically funded and have a directed cycle after both modifications. The verifier recomputes their four-label dependency graphs by eliminating the untouched scheduler dependencies using Boolean reachability.

## Source and price

The protected 3553 bridge is outside both exchange rosters. The trial checks canonically cancel equal grade bins, reprice the changed scalar MOVE multiset 36 times, and recompute the signed whole binary invoice. Both controls retain the exact original public endpoints. The separate 48-call rational invoice has positive margin at both rates. No feasible changed primitive in this family supplies a new conditional lower bound. The complete consumer comparison remains available in [#7863](https://github.com/CrocSwap/integer-mult-bounds/pull/7863) and its [independent replay](https://github.com/CrocSwap/integer-mult-bounds/pull/7973).

The code uses Python 3.12 and the standard library. It regenerates the exchange catalogue from the pinned raw word and exact rational chart containment.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```
