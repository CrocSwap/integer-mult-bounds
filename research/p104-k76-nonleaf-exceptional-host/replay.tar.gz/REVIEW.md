# Internal proof and scope review

This is a self-review, not an independent mathematical review.

* The rank-two kernel contradiction excludes `h` and does not assume the
  e-stage HOST belongs to a leaf. For `s≠t`, the degree-two `r0` is absent
  from the overlap, so a distinct nonhub nonleaf must separate `e,s`.
* The global partition guarantees event IDs are distinct and each role's
  pieces are disjoint. Per-stage matching alone is insufficient. Strict
  support of the assigned role is not required; event support on the overlap
  is the separate `CallerEv.x_supp` premise.
* The baseline counts the two hub HOST assignments, each leaf event, and one
  optimistic unsplit event for every remaining nonleaf. Replacing `r0`'s
  unsplit event by `{e},{t}` charges both singleton pieces once, including
  the exceptional HOST and a non-HOST residual. No extra HOST charge follows.
* The legal-word odd-IDLE exclusion is inherited in form from #7919 and
  depends on the separate thin time slot, D-incidence bridge, host support,
  76 leaves, and `P=-I`. The arithmetic checker does not establish it.
* The DP is deliberately generous about pair coverage and role count. It
  verifies a maximum of a price relaxation, not the existence of a maximizing
  legal word or the exact maximum of actual invoices.

The independently written root/DP calculation, the #7919 leaf replay, and
negative local-mask and odd-IDLE controls pass. Before any upstream
publication, a separate reviewer should scrutinize the word-level support,
global partition, role counting, baseline identity, and inequality (1).
