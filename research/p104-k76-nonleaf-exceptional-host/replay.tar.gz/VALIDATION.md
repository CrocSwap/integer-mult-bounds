# Validation record

On 2026-11-21, Python 3 standard-library checks passed:

```text
python3 -I -B verify_sources.py
python3 -I -B check.py
python3 -I -B independent_check.py
```

The exact primary ceiling is
`122406021878059699/950000000000000`. The independently implemented bounded
72-role DP and Newton-root enclosure produce the upper
`153007527347570207/1187500000000000`. Root comparisons use integer powers,
not floating-point acceptance tests. The programs also verify the 74-pair
coverage optimization and reject missing/overlapping local singleton pieces.

From the SHA-256-pinned #7919 replay archive, the archived `SHA256SUMS`,
`check.py`, `independent_check.py`, `review_check.py`, and `verify_sources.py`
all passed. The full leaf proof's primary and independent exact dual checks
were replayed, although those duals are not needed for the present branch.
See `calibration/leaf-primary.log`, `leaf-independent.log` and
`leaf-review.log`. The archive's generated `RESULT.json` remained byte
identical to its manifest after execution.

The #7918 archive matches its published SHA-256, its copied readable source
matches the archive, and all internal manifest entries verify. The strict
separator and independent algebra certificate replayed successfully; see
`calibration/flag-strict-replay.log` and `calibration/flag-independent.log`.
After replay the flag manifest also remained valid.

All files in both pinned upstream archives were hashed, but no claim is made
that this verifies every theorem within them. In particular, the new
mathematical implication from the legal-word, frame and assigned partition
premises to pair coverage and the corrected invoice is not Lean-checked or
independently mathematically reviewed here.
