#!/usr/bin/env python3
"""Verify fetched Git blobs, pinned replay bytes, and both archive manifests."""
from hashlib import sha1, sha256
from io import BytesIO
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent


def git_blob(data):
    return sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def verified(relative, expected, git=False):
    raw = (HERE/relative).read_bytes()
    actual = git_blob(raw) if git else sha256(raw).hexdigest()
    assert actual == expected, (relative, actual, expected)
    return raw


def archive_check(raw, manifest_name):
    with tarfile.open(fileobj=BytesIO(raw), mode='r:gz') as archive:
        members = {member.name.removeprefix('./'): member
                   for member in archive.getmembers() if member.isfile()}
        entries = archive.extractfile(members[manifest_name]).read().decode().splitlines()
        for line in entries:
            digest, name = line.split(None, 1)
            name = name.lstrip('*')
            file_raw = archive.extractfile(members[name]).read()
            assert sha256(file_raw).hexdigest() == digest, name
        return len(entries)


def main():
    # Blob IDs observed through GitHub's contents API at the named commit.
    verified('source/7919/PUBLISHED-README.md', '795dc30f86af4157750f23e08ffea627ea647775', True)
    verified('source/7919/SOURCES.json', 'bc6a63a84ed13778e1a280af78230747c1170a91', True)
    verified('source/7918-published/SOURCES.json', '937a4ebef5b77c0a2faf3358ccc2a94e6b983038', True)
    verified('source/7869/OPEN-PROBLEMS.md', 'f753dbab5ea9d84b9332261a93f8d0e7adfce6f6', True)
    leaf = verified('source/7919/replay.tar.gz',
                    '8db10187cce075453fb7678b252e3d909e86a0c0b44fe95cebd0ab9c1746bea4')
    flag = verified('source/7918-published/replay.tar.gz',
                    'beab0fdb56c3b3fabbe9650048d24c784ea82c3ef45e744ab240462f1b00403e')
    leaf_count = archive_check(leaf, 'SHA256SUMS')
    flag_count = archive_check(flag, 'MANIFEST.sha256')
    assert leaf_count == 14 and flag_count == 21
    # The readable Round 4 stream copy is byte-identical to the 7918 archive.
    with tarfile.open(fileobj=BytesIO(flag), mode='r:gz') as archive:
        for member in archive.getmembers():
            if member.isfile():
                name = member.name.removeprefix('./')
                assert (HERE/'source/7918'/name).read_bytes() == archive.extractfile(member).read(), name
    print('PASS pinned #7919 blobs and replay; internal manifest entries:', leaf_count)
    print('PASS pinned #7918 blob and replay; readable source matches; entries:', flag_count)
    print('PASS #7869 OPEN-PROBLEMS git blob at the named head')
    print('Byte checks establish provenance, not the mathematical premises.')


if __name__ == '__main__':
    main()
