#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""One donated source-contact, explicit old-recipient restoration, terminal cut.

Original source clocks are named in the result even though literal insertions
shift the changed tape. The rank proof grants an arbitrary shared scalar and
free retention of all original chart-1 arrivals other than the two selected
exits. It does not cover changing the other arrivals or destinations.
"""
from collections import Counter, defaultdict
from copy import deepcopy
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import json, sys, tarfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import verify as v
op=v.op

def R(ok,msg):
 if not ok: raise ValueError(msg)
def canon(o): return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def digest(o): return sha256(canon(o)).hexdigest()
def support(x): return [i for i in range(x.bit_length()) if x>>i&1]
def rank(rows):
 basis={}
 for row in rows:
  while row:
   p=row.bit_length()-1
   if p in basis: row^=basis[p]
   else: basis[p]=row; break
 return len(basis)
def separator(rows,targets):
 """Solve row dot witness = rhs, pivots high to low, then assign low to high."""
 eq={}
 for row,rhs in [(x,0) for x in rows]+list(targets):
  while row:
   p=row.bit_length()-1
   if p in eq: row^=eq[p][0];rhs^=eq[p][1]
   else: eq[p]=(row,rhs); break
  else: R(rhs==0,'inconsistent separator system')
 cert=0
 for p,(row,rhs) in sorted(eq.items()):
  if ((row&cert).bit_count()&1)!=rhs: cert^=1<<p
 R(all((row&cert).bit_count()%2==0 for row in rows),'separator annihilation')
 R(all((row&cert).bit_count()%2==rhs for row,rhs in targets),'separator targets')
 return cert

def capture(word,cuts,history_charts=()):
 cells=[(c,1<<i) for i,c in enumerate(word['start'])]+[None]*word['owned_fields']
 hist=defaultdict(list);out={};cuts=set(cuts);charts=set(history_charts)
 for i,c in enumerate(word['start']):
  if c in charts:hist[c].append((f'owner:{i}',1<<i))
 for t,(code,a,*z) in enumerate(word['program']):
  if t in cuts:out[t]=(cells.copy(),{c:hist[c].copy() for c in charts})
  if code=='INIT':R(cells[a] is None,'INIT');cells[a]=(z[0],0)
  elif code=='CLEAR':R(cells[a] is not None and cells[a][0]==z[0],'CLEAR');cells[a]=None
  elif code=='ADD':R(cells[a] and cells[z[0]] and cells[a][0]==cells[z[0]][0]==z[1],'ADD');cells[a]=(z[1],cells[a][1]^cells[z[0]][1])
  elif code=='SWAP':cells[a],cells[z[0]]=cells[z[0]],cells[a]
  else:
   R(code=='MOVE' and cells[a] is not None and cells[a][0]==z[0],'MOVE');cells[a]=(z[1],cells[a][1])
   if z[1] in charts:hist[z[1]].append((f'move:{a}@{t}',cells[a][1]))
 R(set(out)==cuts,'capture all cuts')
 return out

def quote(hist,rate):
 lo=hi=Q(0)
 for grade,n in hist.items():
  if not n:continue
  a,b=v.power_bounds(grade,1-Q(rate),204)
  lo+=n*(a if n>0 else b);hi+=n*(b if n>0 else a)
 return v.decimals((lo,hi),30)
def price(paid,targets):
 h=Counter(targets);h.subtract(paid)
 return {k:quote(h,k) for k in ('0.003879928046156','0.003879929046155')}
def ordinary(word,caller,paid,targets):
 ev=Counter(x[0] for x in caller['events']);calls,queries,idles=(ev[k] for k in ('LOCAL','QUERY','IDLE_ONE'))
 ports,roles=caller['ports'],caller['roles'];owned,public,scratch=word['owned_fields'],word['public'],4
 native=calls*16*(owned+public+scratch)*len(word['program'])
 caller_rec=ports*(8*(ev['ADD']+3*ev['SWAP'])+256*(calls+queries+roles))
 groups=4*(sum(paid.values())+sum(targets.values()))+8*ports*(calls+idles)
 records=native+caller_rec+groups*80*134*135
 fields=calls*(owned+scratch)+2*ports*roles*len(caller['events'])+16*ports*(calls+queries+roles)
 R(records<10**12 and fields<10**7,'ordinary limits')
 return {'raw_records':records,'owned_fields':fields,'raw_records_limit':10**12,'owned_fields_limit':10**7}

def build(w,fused=False,corrupt=False):
 """Steal 1928's 267->392 contact for A->374 and repay C->392.
 In fused form delete 2473's A->1 and use A+B from 2544 for its reads.
 This is a literal legal tape, but fused form is intentionally wrong.
 """
 nw=deepcopy(w);P=[];mapping={};extra=w['public']+w['owned_fields'];nw['owned_fields']+=1
 for t,e0 in enumerate(w['program']):
  e=e0.copy();mapping[t]=len(P)
  if t==4572:
   R(e==['MOVE',1928,267,392],'donor send')
   P.extend([['ADD',1928,1356,267],['ADD',1928,1628,267],['MOVE',1928,267,374],['INIT',extra,267]])
   for a in (741,1356,1460,1508,1580):
    if not (corrupt and a==741):P.append(['ADD',extra,a,267])
   P.append(['MOVE',extra,267,392]);continue
  if t in (8997,9002,9006):R(e[0]=='ADD' and e[2]==1928 and e[3]==392,'recipient reader');e[2]=extra
  if t==41332:
   R(e==['CLEAR',1928,392],'donor retirement')
   P.extend([['CLEAR',1928,374],['CLEAR',extra,392]]);continue
  if fused:
   if t in (8519,8520,8521,41877):continue
   if e[0]=='ADD' and e[2]==2473 and e[3]==1:e[2]=2544
   if t==8801:P.append(['ADD',2544,1928,374])
  P.append(e)
 nw['program']=P
 return nw,mapping,extra

def compare_outputs(actual,base):
 d=[x^y for x,y in zip(actual,base)]
 return {'changed_rows':sum(bool(x) for x in d),'changed_coefficients':sum(x.bit_count() for x in d),
         'first_changed_owners':[i for i,x in enumerate(d) if x][:24], 'difference_sha256':digest([hex(x) for x in d])}
def check_transpose(f,b):
 for j,row in enumerate(f):
  for i in range(len(f)):
   R((row>>i&1)==(b[i]>>j&1),'full matrix transpose')

def main():
 for name,h in v.PINS.items():R(sha256((HERE/'source'/name).read_bytes()).hexdigest()==h,'source pin '+name)
 archives={'upstream-7937.tar.gz':'9d776ce06757f29123c1b9c29e290b22aa5af15f180e2985e84e528c9c7f3039',
           'upstream-7913.tar.gz':'acd35b771b132bf34a2ff15ccf1e054a8c4e73dbbdaaf53ffac7aa6392902139'}
 for name,h in archives.items():R(sha256((HERE/name).read_bytes()).hexdigest()==h,'archive pin '+name)
 with tarfile.open(HERE/'upstream-7937.tar.gz','r:gz') as tar:
  for path in v.PINS:
   R(tar.extractfile('./source/'+path).read()==(HERE/'source'/path).read_bytes(),'actual #7937 source '+path)
  R(tar.extractfile('./upstream-7913.tar.gz').read()==(HERE/'upstream-7913.tar.gz').read_bytes(),'#7913 nested archive')
 with tarfile.open(HERE/'upstream-7913.tar.gz','r:gz') as tar:
  for path in v.PINS:R(tar.extractfile('./source/'+path).read()==(HERE/'source'/path).read_bytes(),'actual #7913 source '+path)
 w=v.read('inputs/WORD.json.gz');caller=v.read('inputs/EFREE-CALLER.json.gz');receipt=v.read('inputs/BIT.json');P=w['program']
 R(sha256(v.canon(w)).hexdigest()==v.WORD,'canonical word')
 R(w['public']==680,'all owners')
 atlas=op.Atlas(w['frames']);R(atlas.main_contacts(w['start'],w['final'])==111,'main contacts')
 R(P[4559]==['MOVE',1926,267,349] and P[4565]==['MOVE',1927,267,374],'source destinations')
 R(P[8511]==['ADD',2471,1926,349] and P[8792]==['ADD',2542,1927,374],'source first reads')
 outs={2471:(349,511,8513),2472:(349,536,8518),2473:(349,1,8521),
       2542:(374,574,8794),2543:(374,578,8798),2544:(374,1,8801)}
 for field,(a,b,t) in outs.items():R(P[t]==['MOVE',field,a,b],'all six dispositions')
 R(P[31344]==['ADD',3560,2473,1] and P[31965]==['ADD',3613,2544,1],'terminal first readers')
 for field,t in ((2473,31344),(2544,31965)):
  R(next(i for i,e in enumerate(P) if e[0]=='ADD' and e[2]==field)==t,'actual first read')
 R(atlas.grade(349,374)==0,'receivers cannot directly MOVE')
 cuts=(4552,4559,4565,4572,4579,4586,8266,8511,8792,8997,9203,9404,31344,31965)
 rec=capture(w,cuts,(1,326,392,410,428));A=rec[4559][0][1926][1];B=rec[4565][0][1927][1]
 source=(741,1356,1460,1508,1580,1628)
 def xor_values(c,ix):
  x=0
  for i in ix:x^=c[i][1]
  return x
 R(A==xor_values(rec[4559][0],(741,1460,1508,1580,1628)),'A definition')
 R(B==xor_values(rec[4565][0],(741,1356,1508,1628)),'B definition')
 # Four original, same-source contacts in the explicitly enumerated window.
 donor_spec=((1925,4552,326,8266),(1928,4572,392,8997),(1929,4579,410,9203),(1930,4586,428,9404))
 donors=[]
 for a,t,d,first in donor_spec:
  R(P[t]==['MOVE',a,267,d] and P[first][0]=='ADD' and P[first][2:]==[a,d],'donor and reader')
  R(next(j for j in range(t+1,len(P)) if P[j][0]=='ADD' and P[j][2]==a)==first,'first donor reader')
  source_rows=[rec[t][0][i][1] for i in source]
  R(rank(source_rows)==6 and rank(source_rows+[A,B])==6,'A and B available at donor')
  h=[(lab,row) for lab,row in rec[first][1][d] if lab!=f'move:{a}@{t}'];old=rec[t][0][a][1]
  R(rank([x[1] for x in h]+[old])==rank([x[1] for x in h])+1,'old donor recipient deficit')
  sep=separator([x[1] for x in h],[(old,1)])
  live=[{'address':i,'row_support':support(x[1])} for i,x in enumerate(rec[first][0]) if x and x[0]==d and i!=a]
  donors.append({'address':a,'clock':t,'old_route':[267,d],'old_grade':atlas.grade(267,d),
    'legal_retargets':[{'route':[267,to],'grade':atlas.grade(267,to)} for to in (349,374)],
    'sender_live_fields':list(source)+[a], 'first_old_reader_clock':first,'first_old_reader':P[first],
    'recipient_live_stock_excluding_donor':live,'recipient_all_prior_arrivals_excluding_donor':[lab for lab,row in h],
    'recipient_all_prior_rank':rank([row for lab,row in h]),'old_row_rank_increment':1,
    'old_row_separator_support':support(sep)})
 h1=[(lab,row) for lab,row in rec[31344][1][1] if lab not in ('move:2473@8521','move:2544@8801')]
 h2=[(lab,row) for lab,row in rec[31965][1][1] if lab not in ('move:2473@8521','move:2544@8801')]
 R(h1==h2,'same original other arrival history at both cuts')
 H=[row for lab,row in h1];r=rank(H)
 R((len(H),r,rank(H+[A]),rank(H+[B]),rank(H+[A^B]),rank(H+[A,B]))==(535,535,536,536,536,537),'two independent demanded rows')
 ca=separator(H,[(A,1),(B,0)]);cb=separator(H,[(A,0),(B,1)])
 live_first=[i for i,x in enumerate(rec[31344][0]) if x and x[0]==1]
 live_without=[rec[31344][0][i][1] for i in live_first if i not in (2473,2544)]
 R(rank(live_without)==r and rank(H+live_without)==r,'first actual receiver live span (other than the two selected fields)')
 R(rank(H+[rec[31344][0][3560][1],rec[31965][0][3613][1]])==r,'first consumer partial rows carry no missing information')
 live_349=[i for i,x in enumerate(rec[8511][0]) if x and x[0]==349]
 live_374=[i for i,x in enumerate(rec[8792][0]) if x and x[0]==374]
 # Full source and changed tapes, including both orientations.
 basef,baseb,bridge=op.native_checks(w,atlas);np,nt,paid,targets=op.binary_invoice(w,caller,atlas,basef)
 for got,name in ((np,'native_paid'),(nt,'native_targets'),(paid,'paid'),(targets,'targets')):
  R(got==Counter({int(k):v for k,v in receipt['native'][name].items()}),'baseline '+name)
 R(ordinary(w,caller,paid,targets)=={'raw_records':934182831504,'owned_fields':6998544,'raw_records_limit':10**12,'owned_fields_limit':10**7},'baseline ordinary')
 control,mapc,extra=build(w);cf=op.run_tape(control,atlas,False);cbk=op.run_tape(control,atlas,True)
 R(cf.output==basef.output and cbk.output==baseb.output,'restored control both complete operators')
 cnp,cnt,cp,ct=op.binary_invoice(control,caller,atlas,cf)
 R(cnt==nt and ct==targets and cnp-np==Counter({2:1}) and not (np-cnp),'complete control invoice')
 # At donor first reader every old field other than its rehomed address remains
 # identical; the newly paid field exactly restores the old donor stock.
 changed_cut=capture(control,(mapc[8792],mapc[8997]))
 bstock=rec[8997][0];newstock=changed_cut[mapc[8997]][0]
 R(newstock[extra]==bstock[1928] and newstock[1928]==(374,A),'first donor recipient restored')
 R(all(newstock[i]==bstock[i] for i in range(len(bstock)) if i!=1928),'all other stock equal at first donor read')
 new374=[i for i,x in enumerate(changed_cut[mapc[8792]][0]) if x and x[0]==374]
 R(new374==sorted(live_374+[1928]),'actual connected first receiver stock')
 # Protected bridge/tree by word-clock mapping. The packet identifiers shift
 # by one after the inserted paid move, so compare the actual MOVE clocks.
 for tape,base in ((cf,basef),(cbk,baseb)):
  byclock={p.clock:p for p in tape.packets.values()}
  for label in (2942,2943,2944,3553):
   old=base.packets[label];new=byclock[mapc[old.clock]]
   R((new.source,new.receiver,new.grade,new.arrival.row)==(old.source,old.receiver,old.grade,old.arrival.row),'protected routes and values')
  R([p for p in tape.packets.values() if p.arrival.row & (1<<411)]==[byclock[mapc[base.packets[3553].clock]]],'411 isolation')
 fused,_,_=build(w,fused=True);ff=op.run_tape(fused,atlas,False);fb=op.run_tape(fused,atlas,True)
 fnp,fnt,fp,ft=op.binary_invoice(fused,caller,atlas,ff)
 R((fnp,fnt,fp,ft)==(np,nt,paid,targets),'fused literal invoice unchanged')
 diff_f=compare_outputs(ff.output,basef.output);diff_b=compare_outputs(fb.output,baseb.output)
 R(diff_f['changed_coefficients'] and diff_b['changed_coefficients'],'fused literal rejected in both directions')
 check_transpose(ff.output,fb.output)
 corrupt,_,_=build(w,corrupt=True);xf=op.run_tape(corrupt,atlas,False);xb=op.run_tape(corrupt,atlas,True)
 cor_f=compare_outputs(xf.output,basef.output);cor_b=compare_outputs(xb.output,baseb.output)
 R(cor_f['changed_coefficients'] and cor_b['changed_coefficients'],'corrupt old restoration rejected both ways')
 gain=Counter(ct);gain.subtract(cp);gain.subtract(targets);gain.update(paid)
 out={'status':'PASS_BOUNDED_RETARGET_RESTORATION_AND_TWO_SCALAR_CUT',
  'source_heads':{'7937':'899896b42ef57e5292db07978ef5acd87a6c8daf','7913':'b252f7dad5c36ab6382d68a42ee90d95cf4d33eb','7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'},
  'archives':archives,'word_sha256':v.PINS['inputs/WORD.json.gz'],'canonical_word_sha256':v.WORD,
  'scope':'Exactly one retargeted 267-origin contact from 1925,1928,1929,1930 at its original clock, delivering arbitrary source stock to chart 349 or 374. All other original paid routes/arrival rows into chart 1 fixed; the two original grade-2 terminal exits may be replaced by one arbitrary scalar. Old recipient must be restored. Free retention and computation granted. No bound on changing other arrivals, retiming, other donor rosters, higher-dimensional contacts, or productive targets.',
  'source':{'A_address':1926,'B_address':1927,'A_owner_support':support(A),'B_owner_support':support(B),
            'A_coordinates':[741,1460,1508,1580,1628],'B_coordinates':[741,1356,1508,1628],
            'six_named_original_dispositions':{str(k):{'route':[a,b],'clock':t,'grade':atlas.grade(a,b)} for k,(a,b,t) in outs.items()},
            'original_first_receiver_stocks':{'349_before_8511':live_349,'374_before_8792':live_374},
            'direct_349_374_is_legal':False},
  'donor_roster':donors,
  'two_terminal_cut':{'chart':1,'first_read_A_clock':31344,'first_read_A':P[31344],'first_read_B_clock':31965,'first_read_B':P[31965],
    'actual_first_receiver_live_addresses':live_first,'actual_first_receiver_live_count':len(live_first),'other_live_span_rank_at_first_read':rank(live_without),
    'all_other_prior_original_arrivals_same_at_both_cuts':True,'other_arrival_labels': [lab for lab,row in h1],
    'other_arrival_labels_sha256':digest([lab for lab,row in h1]),'other_arrival_count':len(H),'other_arrival_rank':r,
    'rank_with_A':r+1,'rank_with_B':r+1,'rank_with_A_xor_B':r+1,'rank_with_both':r+2,
    'separator_A_1_B_0':support(ca),'separator_A_0_B_1':support(cb),
    'interpretation':'One arbitrary added scalar can increase dimension by at most one; both independent A and B are required, even if the scalar is available for free before either read and all other arrivals are retained.'},
  'original_control':{'paid':dict(sorted(paid.items())),'productive':dict(sorted(targets.items())),'full_signed_margin':price(paid,targets),
     'ordinary':ordinary(w,caller,paid,targets),'both_native_operators_exact':True,'caller_polynomial_exact':True,'native_coefficient_checks_per_orientation':680*680,'caller_coefficients_per_orientation':38*38,'native_calls':36,'bridge_omission_clock':bridge},
  'retarget_and_direct_restore_control':{'donor':1928,'old_route':[267,392],'new_route':[267,374],
    'retarget_payload':'A, using 1928 XOR 1356 XOR 1628 at chart 267',
    'new_restoration_route':[267,392],'restoration_field':extra,'restoration_payload_coordinates':[741,1356,1460,1508,1580],
    'actual_374_stock_before_original_first_read_clock_8792':new374,
    'actual_392_old_field_restored_before_clock_8997':True,'all_other_original_fields_unchanged_at_first_old_read':True,
    'native_paid_delta':{'2':1},'gain_from_baseline':{rate:quote(gain,rate) for rate in ('0.003879928046156','0.003879929046155')},
    'paid':dict(sorted(cp.items())),'productive':dict(sorted(ct.items())),'full_signed_margin':price(cp,ct),'ordinary':ordinary(control,caller,cp,ct),
    'both_native_operators_exact':True,'caller_polynomial_exact':True,'protected_tree_and_411_bridge_intact_both_directions':True,
    'dirty_private_retirements':[cf.dirty,cbk.dirty]},
  'literal_fusion_counterexample':{'operation':'Donor 1928 supplies A to 374, original donor C is restored by an extra grade-2 contact, remove 2473, encode 2544 as A XOR B, and substitute 2544 at all old 2473 reads.',
    'native_paid_delta':{},'productive_delta':{},'gain_from_baseline':{'0.003879928046156':['0','0'],'0.003879929046155':['0','0']},
    'paid':dict(sorted(fp.items())),'productive':dict(sorted(ft.items())),'full_signed_margin':price(fp,ft),'ordinary':ordinary(fused,caller,fp,ft),
    'forward_discrepancy':diff_f,'adjoint_discrepancy':diff_b,'full_forward_adjoint_transpose_checked':True,
    'acceptance':'REJECT: changed native operator; unchanged invoice does not imply a valid construction'},
  'corrupted_restoration_control':{'mutation':'Remove ADD of owner field 741 into the new replacement payload.',
    'forward_discrepancy':cor_f,'adjoint_discrepancy':cor_b,'accepted':False},
  'result':'No gain. The concrete legal donor restoration costs one grade-2 paid contact per call. Saving one grade-2 exit would cancel that cost, and the literal A+B fusion fails both native operators. The rank-two cut excludes every arbitrary one-scalar replacement only within the fixed-other-arrival domain.'}
 print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
