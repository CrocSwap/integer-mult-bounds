#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Replay 1-bit cut certificates, plus separate literal and pricing engines."""
from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import json, sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'/'vendor'))
sys.path.insert(0,str(HERE))
import literal, price, check

def need(ok,why):
 if not ok:raise ValueError(why)

def signal(w,ones,bank,clock,excluded):
 """Single-bit propagation, no rank elimination or 680-bit rows."""
 vals=[int(i in ones) for i in range(w['public'])]+[0]*w['owned_fields']
 tags=list(w['start'])+[None]*w['owned_fields']; arrivals=[];special={}
 for i,c in enumerate(w['start']):
  if c==bank:arrivals.append((f'owner:{i}',vals[i]))
 for t,(code,a,*z) in enumerate(w['program']):
  if t==clock:break
  if code=='INIT':need(tags[a] is None,'signal INIT');tags[a]=z[0];vals[a]=0
  elif code=='CLEAR':need(tags[a]==z[0],'signal CLEAR');tags[a]=None;vals[a]=0
  elif code=='ADD':need(tags[a]==tags[z[0]]==z[1],'signal ADD');vals[a]^=vals[z[0]]
  elif code=='SWAP':tags[a],tags[z[0]]=tags[z[0]],tags[a];vals[a],vals[z[0]]=vals[z[0]],vals[a]
  else:
   need(code=='MOVE' and tags[a]==z[0],'signal MOVE')
   if a in (1925,1926,1927,1928,1929,1930) and t in (4552,4559,4565,4572,4579,4586):special[a]=vals[a]
   tags[a]=z[1]
   if z[1]==bank and f'move:{a}@{t}' not in excluded:arrivals.append((f'move:{a}@{t}',vals[a]))
 return arrivals,special

def test_terminal(w,cut,cert,want_A,want_B):
 arrivals,special=signal(w,set(cert),1,cut,{'move:2473@8521','move:2544@8801'})
 return len(arrivals)==535 and all(x==0 for _,x in arrivals) and special[1926]==want_A and special[1927]==want_B

def main():
 result=json.loads((HERE/'RESULT.json').read_text());w=check.v.read('inputs/WORD.json.gz');caller=check.v.read('inputs/EFREE-CALLER.json.gz')
 cut=result['two_terminal_cut'];certs=[]
 for name,wa,wb in [('separator_A_1_B_0',1,0),('separator_A_0_B_1',0,1)]:
  for clock in (31344,31965):
   need(test_terminal(w,clock,cut[name],wa,wb),'terminal separator '+name)
   certs.append({'certificate':name,'cut':clock,'all_535_nonselected_arrivals_zero':True,'A':wa,'B':wb})
 need(not test_terminal(w,31344,[],1,0),'zeroed terminal certificate must be rejected')
 donor_checks=[]
 for d in result['donor_roster']:
  ex={f"move:{d['address']}@{d['clock']}"}
  arrivals,special=signal(w,set(d['old_row_separator_support']),d['old_route'][1],d['first_old_reader_clock'],ex)
  need([x for x,v in arrivals]==d['recipient_all_prior_arrivals_excluding_donor'],'donor arrival labels')
  need(all(v==0 for x,v in arrivals) and special[d['address']]==1,'donor separator')
  donor_checks.append({'address':d['address'],'old_destination':d['old_route'][1],'first_reader':d['first_old_reader_clock'],'checked_arrivals':len(arrivals),'old_row':1})
  bad,bad_s=signal(w,set(),d['old_route'][1],d['first_old_reader_clock'],ex)
  need(bad_s[d['address']]==0,'zeroed donor cert rejected')
 charts=literal.Charts(w['frames']);need(charts.main_contacts(w['start'],w['final'])==111,'111 main contacts')
 variants={'baseline':w,'retarget_restore':check.build(w)[0], 'fused':check.build(w,fused=True)[0],
           'corrupt_restoration':check.build(w,corrupt=True)[0]}
 signed={};tape_checks={};events=Counter(e[0] for e in caller['events'])
 native_targets=Counter(charts.leg(a,b) for a,b in zip(w['start'][222:],w['final'][222:]))
 for name,word in variants.items():
  details=[];native_paid=None
  for reverse in (False,True):
   rows,meta,_=literal.tape(word,charts,adjoint=reverse)
   bad,coeff=literal.different(rows,literal.expected_rows(w['public'],reverse))
   if name in ('baseline','retarget_restore'):need(not bad,'independent exact operator '+name)
   else:need(bad and coeff,'independent mutation detection '+name)
   details.append({'orientation':'adjoint' if reverse else 'forward','changed_rows':len(bad),'changed_coefficients':coeff,
                   'dirty_retirements':meta['erase_dirty']})
   if not reverse:native_paid=meta['paid']
   else:need(meta['paid']==native_paid,'same forward/backward paid histogram')
  paid,targets=literal.paired_invoice(caller,native_paid,native_targets,events)
  key={'baseline':'original_control','retarget_restore':'retarget_and_direct_restore_control','fused':'literal_fusion_counterexample'}.get(name)
  if key:
   expected=result[key];need(paid==Counter({int(k):v for k,v in expected['paid'].items()}),'independent paid '+name)
   need(targets==Counter({int(k):v for k,v in expected['productive'].items()}),'independent targets '+name)
   margins={}
   for rate in ('0.003879928046156','0.003879929046155'):
    x=price.moment(price.signed_profile(targets,paid),F(rate));lo,hi=map(F,expected['full_signed_margin'][rate])
    need(lo<=F(x[0],price.GRID)<=F(x[1],price.GRID)<=hi,'independent directed price '+name)
    margins[rate]=price.decimal_interval(x,30)
   signed[name]=margins
  tape_checks[name]={'directions':details,'native_paid':dict(sorted(native_paid.items()))}
 print(json.dumps({'status':'PASS_INDEPENDENT_PARITY_AND_LITERAL_REPLAY',
  'method':'Independent one-bit signal simulation checks separators; separate rational atlas, literal tape, polynomial caller, and rational-log interval engines replay the controls.',
  'terminal_certificates':certs,'donor_certificates':donor_checks,'zeroed_certificate_rejected':True,
  'literal_tapes':tape_checks,'independent_full_signed_margins':signed},indent=2,sort_keys=True))
if __name__=='__main__':main()
