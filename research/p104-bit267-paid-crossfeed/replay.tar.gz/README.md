# Chart-267 donated contact and coupled terminal receipts

This bounded screen found **no valid κ improvement**. It retargets a real existing contact so that chart 374 receives chart 349's packet row, explicitly restores the donor's old destination, and tests whether the two grade-2 exits into chart 1 can be reduced to one. The paid restoration is valid but costs one extra grade-2 contact per native call. The literal attempt to save an exit has zero net paid change, but changes the native operator in both directions. A rank-two cut excludes any single replacement scalar for the two terminal first readers when the other original chart-1 arrivals and their payloads remain fixed.

The 680-owner word is from [#7830, head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15). This takes the distinct receiver histories of [#7913, head `b252f7dad5c36ab6382d68a42ee90d95cf4d33eb`](https://github.com/CrocSwap/integer-mult-bounds/tree/b252f7dad5c36ab6382d68a42ee90d95cf4d33eb), beyond the fixed-arrival six-basis screen in [#7937, head `899896b42ef57e5292db07978ef5acd87a6c8daf`](https://github.com/CrocSwap/integer-mult-bounds/tree/899896b42ef57e5292db07978ef5acd87a6c8daf). The other Round 5 parent was the fixed-exterior two-relay stock screen [#7938, head `63d2210f15fd288ad6ed535ddca6c28826d05a97`](https://github.com/CrocSwap/integer-mult-bounds/tree/63d2210f15fd288ad6ed535ddca6c28826d05a97); its method motivates checking the donor's actual first old recipient, but its rank-21 triple is not used as a proof of this chart-267 result. The actual #7937 and #7913 replay archives and the comparator inputs are pinned and checked byte for byte. Original zero-based clocks refer to #7830's word, before inserted instructions.

## Six dispositions and donor roster

The original packet rows are

```text
A = 1926 = 741 + 1460 + 1508 + 1580 + 1628    267 → 349 at 4559
B = 1927 = 741 + 1356 + 1508 + 1628           267 → 374 at 4565
```

They open at `ADD 2471,1926` in chart 349 at 8511 and `ADD 2542,1927` in chart 374 at 8792. The actual stock at those clocks is respectively `[1926,1986,2282,2471]` and `[650,1560,1564,1927,2207,2542]` (the destinations 2471 and 2542 have already been initialized). Neither receiver is nested in the other, so a direct MOVE 349↔374 is illegal. Preserve the three original semantic dispositions from each:

| Receiver | Original paid fields and destinations | Grades |
| --- | --- | --- |
| 349 | 2471→511, 2472→536, 2473→1 | 1, 1, 2 |
| 374 | 2542→574, 2543→578, 2544→1 | 1, 1, 2 |

We enumerate four other paid contacts in the chart-267 burst and permit any of them to be retargeted at its original clock to **either** 349 or 374, with arbitrary free linear recoding from the sender's actual six live fields. Both A and B are in that stock in each case. All old and replacement routes in this table have grade 2. The two original A/B sends are kept; the roster is deliberately only these four donors, not every contact in the whole word.

| Donor | Original clock and destination | First old recipient read | Other original arrivals available at that read |
| --- | --- | --- | --- |
| 1925 | 4552 → 326 | `ADD 2408,1925` at 8266 | 1919 at 4511; 2292 at 7027 |
| 1928 | 4572 → 392 | `ADD 2594,1928` at 8997 | 2267 at 6838; 2330 at 7341 |
| 1929 | 4579 → 410 | `ADD 2646,1929` at 9203 | 2238 at 6645; 2342 at 7474 |
| 1930 | 4586 → 428 | `ADD 2697,1930` at 9404 | 2274 at 6885; 2316 at 7231 |

For every donor, all other original arrivals at the old recipient span rank 2, and the omitted donor adds one independent row. Exact separating certificates and live fields appear in [RESULT.json](RESULT.json), and a separate one-bit propagation checks each certificate in [INDEPENDENT.json](INDEPENDENT.json). This assumes the other arrivals are unchanged; changing their routes or payloads needs a new causal and cost analysis. In particular, it establishes an old-recipient obligation, not a universal grade-2 lower bound for every possible repair.

## Literal donor restoration

At the 1928 send, its original row is `C = 741+1356+1460+1508+1580`. Two local adds, by 1356 and 1628, turn C into A; the existing MOVE is retargeted from 267→392 to **267→374**. At 374's actual first reader clock 8792, the live stock is now `[650,1560,1564,1927,1928,2207,2542]`: both original rows B and A are present. A new owned field 4234 is built as C at 267 and sent 267→392, restoring the original 1928 value. Immediately before chart 392's first reader at 8997, field 4234 exactly equals the original 1928 field, and every other original active field has its original value and chart; its other live fields are 2267, 2330, and initialized zero field 2594.

With all six original outgoing dispositions retained, this is a legal literal word, not a free-information assumption. Its forward and adjoint 680×680 operators are identical to the original, as are all 38×38 caller polynomial coefficients. All 111 main contacts and the protected tree and owner-411 bridge routes and payloads pass in both orientations. The new grade-2 restoration is counted at all 36 native calls. Ordinary usage is 934,440,388,752 records and 6,998,580 owned fields, below the original ceilings.

## Why one common terminal exit is insufficient in this domain

At chart 1 the first reads are `ADD 3560,2473` at **31344** and `ADD 3613,2544` at **31965**, requiring A and B respectively after the known local additions. The first actual receiver stock has 544 live field addresses, listed in [RESULT.json](RESULT.json). After excluding fields 2473 and 2544, its other live fields span rank 535. Grant the receiver **free retention of all 535 other original prior arrival rows**: their history is the same at both named clocks and has rank 535. Their span contains both first-reader partial values, while adding A and B gives:

```text
rank(H) = 535
rank(H + A) = rank(H + B) = rank(H + A+B) = 536
rank(H + A + B) = 537
```

Thus two distinct missing dimensions are required. One arbitrary replacement scalar q—even one supplied before either read, with arbitrary co-chart computation and free retention—adds at most one dimension to H. It cannot restore both original first-consumer values. The two explicit separating inputs in [RESULT.json](RESULT.json) annihilate every H arrival and independently distinguish A from B; independent bit propagation checks both cuts and rejects zeroed certificates.

This is a changed-history question: the literal donor actually delivers A to the other receiver, and q may be any linear form. The cut fixes the other original chart-1 arrival rows, including other exit descendants, rather than testing the six original two-packet bases. It does **not** rule out changing those other arrivals, their destinations, retiming, a donor outside the four listed, multiple replacement scalars, altered productive targets, or other whole-word constructions. Nor does it show that an omitted grade-1 exit is impossible in every changed network.

To test the proposed saving concretely, the script keeps the paid donor restoration, removes 2473, changes the remaining 2544 field to A+B, and uses 2544 at every original 2473 read. All chart routes and field lifetimes are legal, and the saved grade-2 exit exactly offsets the new grade-2 restoration. Nevertheless the resulting native operator differs in **361 scalar coefficients in each orientation**, so this is a rejected counterexample, not a new witness. The unchanged caller histogram and price of that faulty word do not validate the composed operation. Separately removing a source add in the donor restoration changes 57 native coefficients in each orientation and is rejected by both independent literal runs.

## Complete 36-call prices

The complete native and caller paid and productive histograms, including their unchanged productive occurrences, are recorded in the result. The directed intervals below are full `productive − paid` margins, not merely local savings.

| κ | Original margin | Retarget + direct donor restoration | Retarget + restore + failed fusion |
| --- | --- | --- | --- |
| `0.003879928046156` | [−0.000000000767001502431130261464, −0.000000000767001502431130261463] | [−71.806626138008372869520486907060, −71.806626138008372869520486907059] | same as original, invalid operator |
| `0.003879929046155` | [−0.000385127316613866441054139473, −0.000385127316613866441054139472] | [−71.807011214785474570789750772735, −71.807011214785474570789750772734] | same as original, invalid operator |

The valid control's change from original is approximately −71.806626137241371367 and −71.806626087468860704 respectively. The attempted saving and its debit each equal one grade-2 contact per native call, so even a hypothetical valid realization with this exact invoice would not improve the bound.

## Offline replay

Python 3.12, standard library only:

```sh
sha256sum -c SHA256SUMS
python3 -I -B check.py > /tmp/p104-r6-bit267-result.json
cmp RESULT.json /tmp/p104-r6-bit267-result.json
python3 -I -B independent.py > /tmp/p104-r6-bit267-independent.json
cmp INDEPENDENT.json /tmp/p104-r6-bit267-independent.json
```

`independent.py` uses one-bit signal propagation for the six dual witnesses and separately implemented rational-atlas, literal-word, caller-polynomial, and rational-log interval engines. The archive reproduction and computational replay are not independent human review, a physical-erasure or precision-tape qualification, or an outer-theorem proof. The source notices and license remain under [source/](source/); this work was prepared with OpenAI Codex assistance.
