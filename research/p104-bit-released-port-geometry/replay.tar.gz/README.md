# One released main port on the frozen native quotient

All 111 individually projected main ports have a negative complete signed
upper bound in the retained-quotient model below. At κ
`0.003879928046156`, the largest outward ceiling is for port 89:
**−7.9551614708362550**. At `0.003879929046155`, it is
**−7.9551547942024445**. The separately requested port 89 plus projected
helper 660 has ceilings **−7.6420789376396004** and
**−7.6420721805957879**, respectively. These are ceilings for a dimension
relaxation, not realized rational embeddings; none imply a κ improvement.

The calculation pins native #7830 at
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, canonical main context
`e54523517d0f03e58352e647c403a5af3e525a57`, and native word digest
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
It reconstructs the original **656-node** cochart quotient and the complete
owner-to-inlet/outlet mapping from the literal packet forms.

## What is released and what stays fixed

For port `p`, project its original two main owners `p` and `p+111` at both
ends and release exactly their inlet and outlet anchors. A quotient node
remains frozen whenever *any* of the other 110 ports, owner 411, or a
protected tree endpoint still anchors it. Protected packet IDs
`2942, 2943, 2944, 3553` are retained. `WINDOWS.json` contains all owner
bindings and all reasons each originally frozen node is protected. The
original 229 frozen nodes lose exactly two nodes for each of the 111 ports;
the released graph has 56–58 nodes whose subspace interval has freedom,
versus 50 before release.

The original cochart equalities and nesting direction of **every** original
paid or productive incidence are deliberately retained even when a
projected packet becomes zero. A real deletion might split these cochart
components or remove an ordering constraint, so this is **not** a bound
on a rebuilt post-deletion graph. Changed packet payloads, additional
paid omissions, different helper projections, altered routing, different
caller substitutes and releasing several main ports are outside scope.

The projected packet word is iterated to a zero-packet fixed point in both
directions while the protected tree packets remain present. The resulting
word is checked on every surviving output row: **678 forward and 678
adjoint rows** for a released port, or **677** each when helper 660 is
also projected. All 110 other main ports and the owner-411 return remain
in those checks. A zero paid packet is given its full original paid saving.
An omitted or grade-zero productive helper instead loses its productive
credit; the two types are never both counted as paid savings.

## Rank-only price ceiling

For each unanchored node, exact rational joins and intersections of the
remaining frozen neighbors give a necessary interval `L ⊆ V ⊆ U`. The
relaxation permits every integer dimension between `dim(L)` and `dim(U)`
and enforces every original lower-to-upper nesting inequality. It does not
require a rational subspace of that dimension to exist, so it can only
increase the price ceiling. The free-node graph splits into independent
components of at most **10 nodes** and at most **1,536** candidate rank
assignments. All **112,983** component assignments for the 111 ports were
enumerated, of which **73,179** satisfy the rank-order constraints. The
port-89/helper-660 control adds 889 assignments, 565 compatible.

The bound retains each of the original **36 native-call charges**, less
the actually zero projected paid packets. Removing the original caller port
also removes its 38 productive targets and its 32 paid IDLEs and four paid
QUERYs. This is the actual lost-target and caller-fee accounting for the
whole-port projection, not an assumed free replacement. The unchanged
48-call rational companion is unaffected by the calculation; its margins
are approximately `+0.212262470163347` and `+0.211243929926514` at the
two trials. The original complete BIT margins are approximately
`−0.0000000007670015024` and `−0.000385127316614`, respectively.

For port 89, exact projection alone has a signed change at most
`−27.1061571921844179`; the most favorable dimension-only rechart adds at
most `+19.1509957213481629`, giving the stated first-trial ceiling. The
zero packet grades are `{1: 2, 2: 1, 4: 1, 6: 1}` per native call. At
the optimizing rank assignment, **69 retained paid incidences** and
**9 retained productive helper incidences** have grade zero. Those are
features of a rank relaxation, not proof of a consistent rational geometry.
The helper-660 variant has eight zero paid packets with grades
`{1: 4, 2: 2, 4: 1, 6: 1}` and loses one grade-4 helper target per native
call.

The certificates use outward 90-digit Decimal enclosures, rounded to
integer units of `10⁻²⁸`. `verify.py` independently re-enumerates the
individual-port rank choices and reprices paid and productive incidences
separately. It checks each enclosure against a separate 120-digit Decimal
calculation and reproduces the negative conclusion for all **112** cases.
It shares the packet reconstruction and rational interval code with the
producer, so this is an independent arithmetic/enumeration audit, not an
independent cold reconstruction of the native word.

No physical changed caller or supplier is constructed. Ordinary work,
owner/chart rebinding, zero-field disposal, finite precision, stock,
compiler and analytic-recovery assumptions remain separate obligations.

## Reproduce

The package uses the standard library and assertions. From this directory:

```sh
(cd source && sha256sum -c SHA256SUMS)
python3 -I -B windows.py > WINDOWS.check.json
cmp WINDOWS.json WINDOWS.check.json
python3 -I -B optimize.py > OPTIMISTIC.check.json
cmp OPTIMISTIC.json OPTIMISTIC.check.json
python3 -I -B verify.py > INDEPENDENT.check.json
cmp INDEPENDENT.json INDEPENDENT.check.json
```

The copied `source/` contains its Apache license, source pins and prior
notices. The earlier ninth-axis notice and license are retained in
`vendor/`. `COLD-REPLAY.json` records a separate-copy validation.
