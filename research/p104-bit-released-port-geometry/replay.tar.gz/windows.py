#!/usr/bin/env python3
"""Exact frozen ownership and individual-port release windows on old quotient."""
from collections import Counter,defaultdict,deque
from math import prod
from pathlib import Path
from time import monotonic
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'vendor'))
import hull as H
import port_cut as PC

def ownership():
 W=H.W; n=W['public']; d=H.mincut.Components()
 for j in range(n):d.root((j,'in'));d.root((~j,'out'))
 for k in PC.R:d.root((k,'out'));d.root((k,'in'))
 for k,form in PC.ROWS.items():
  for j in PC.labels(form):d.join((j,'in'),(k,'out'))
 nodes=sorted({d.root(v) for v in d.parent});ids={v:i for i,v in enumerate(nodes)}
 assert nodes==H.nodes
 def at(v):return ids[d.root(v)]
 own_in=[at((j,'in')) for j in range(n)];own_out=[at((~j,'out')) for j in range(n)]
 owners=defaultdict(set);tree=set();reason=defaultdict(list)
 for j in list(range(222))+[411]:
  for io,node in (('in',own_in[j]),('out',own_out[j])):
   owners[node].add(j);reason[node].append({'owner':j,'endpoint':io})
 treepairs={(509,0),(390,509),(517,390)}
 for k,(a,b) in PC.R.items():
  if k==3553 or (a,b) in treepairs:
   for io,node in (('sender',at((k,'out'))),('arrival',at((k,'in')))):
    tree.add(node);reason[node].append({'protected_packet':k,'route':[a,b],'endpoint':io})
 frozen=set(owners)|tree
 assert frozen==H.F and len(frozen)==229
 paid=[]
 for k,(a,b) in PC.R.items():
  x,y=at((k,'out')),at((k,'in'));g=PC.G[k]
  assert H.C[x]==a and H.C[y]==b
  paid.append({'id':k,'a':x,'b':y,'grade':g})
 productive=[]
 for j in range(222,n):
  x,y=own_in[j],own_out[j];g=H.dim[y]-H.dim[x];assert g>0
  productive.append({'owner':j,'a':x,'b':y,'grade':g})
 assert len(paid)==2874 and len(productive)==458
 return own_in,own_out,owners,tree,reason,paid,productive

def windows(frozen):
 L=[H.old[i] if i in frozen else H.zero for i in range(H.n)]
 U=[H.old[i] if i in frozen else H.full for i in range(H.n)]
 for i in H.order:
  for j in H.nb[i]:
   if H.dim[i]<H.dim[j]:L[j]=H.join(L[i],L[j])
 for i in H.order[::-1]:
  for j in H.nb[i]:
   if H.dim[j]<H.dim[i]:U[j]=H.meet(U[i],U[j])
 assert all(H.join(L[i],H.old[i])==H.old[i] and H.join(H.old[i],U[i])==U[i] for i in range(H.n))
 assert all(L[i]==H.old[i]==U[i] for i in frozen)
 return L,U

def components(free,L,U):
 todo=set(free);out=[]
 while todo:
  start=min(todo);todo.remove(start);seen={start};q=deque([start])
  while q:
   for j in H.nb[q.popleft()]&todo:
    todo.remove(j);seen.add(j);q.append(j)
  ids=sorted(seen)
  out.append({'nodes':ids,'count':len(ids),'dimension_options_product':prod(len(U[i])-len(L[i])+1 for i in ids)})
 return sorted(out,key=lambda x:(-x['count'],x['nodes']))

def main():
 started=monotonic();ii,oo,owners,tree,reasons,paid,productive=ownership()
 results=[]
 for j in range(111):
  gone={j,j+111};frozen=tree|{v for v,people in owners.items() if people-gone}
  L,U=windows(frozen);free={i for i in range(H.n) if L[i]!=U[i]}
  components0=components(free,L,U)
  vals=[]
  for i in sorted(free):
   assert H.join(L[i],U[i])==U[i]
   vals.append({'component':i,'chart':H.C[i],'lower_rank':len(L[i]),'original_rank':H.dim[i],
                'upper_rank':len(U[i]),'formerly_free':H.L[i]!=H.U[i]})
  results.append({'port':j,'released_owners':sorted(gone),
     'released_anchor_nodes':sorted(set((ii[j],oo[j],ii[j+111],oo[j+111]))),
     'actually_unfrozen_nodes':sorted(H.F-frozen),'frozen_count':len(frozen),
     'free_count':len(free),'newly_free_count':sum(not x['formerly_free'] for x in vals),
     'free_windows':vals,'free_connected_components':components0,
     'largest_component_size':max((c['count'] for c in components0),default=0),
     'largest_component_dimension_options_product':max((c['dimension_options_product'] for c in components0),default=0),
     'negative_groups_with_two_free_ends':sum(m<0 and a in free and b in free for a,b,m,g in H.arcs)})
  if j%20==19:print('processed',j+1,'seconds',round(monotonic()-started,2),file=sys.stderr,flush=True)
 count=Counter((len(x['actually_unfrozen_nodes']),x['newly_free_count'],x['largest_component_size']) for x in results)
 out={'source':{**H.public_source(),'canonical_main_context':'e54523517d0f03e58352e647c403a5af3e525a57'},'scope':'Original 656-node cochart quotient; retain every other main anchor, owner 411, and all protected tree endpoints. Constraints from zero/projected packets have not been removed; this is not a rebuilt projected graph.',
  'original_components':H.n,'original_frozen_components':len(H.F),'baseline_free_components':sum(H.L[i]!=H.U[i] for i in range(H.n)),
  'tree_protected_nodes':sorted(tree),'port_anchor_roster':[
   {'port':j,'X_in':ii[j],'X_out':oo[j],'Y_in':ii[j+111],'Y_out':oo[j+111]} for j in range(111)],
  'frozen_provenance':{str(k):v for k,v in sorted(reasons.items())},
  'paid_incidence_count':len(paid),'productive_helper_incidence_count':len(productive),
  'shape_counts':{str(k):v for k,v in sorted(count.items())},'ports':results}
 print(json.dumps(out,sort_keys=True,indent=2))

if __name__=='__main__':main()
