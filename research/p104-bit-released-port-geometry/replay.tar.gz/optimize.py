#!/usr/bin/env python3
"""All 111 individually released ports, dimension-only optimistic bounds."""
from collections import Counter,defaultdict
from decimal import ROUND_CEILING,ROUND_FLOOR
from itertools import product
from pathlib import Path
from time import monotonic
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import windows as W
import hull as H
import port_cut as P

SCALE=10**28
RATES=H.prices.RATES
TREE={(509,0),(390,509),(517,390)}
PROTECTED={k for k,e in P.R.items() if k==3553 or e in TREE}

def directed(k):
 lo=[];hi=[]
 for g in range(128):
  a,b=H.prices.power(g,k)
  lo.append(int(H.prices.LO.multiply(a,SCALE).to_integral_value(rounding=ROUND_FLOOR)))
  hi.append(int(H.prices.HI.multiply(b,SCALE).to_integral_value(rounding=ROUND_CEILING)))
 return lo,hi

def closure(port,helpers=()):
 gone=set(helpers)|{port,port+111};mask=sum(1<<j for j in gone);holes=set();passes=0
 while True:
  added=0
  for rev in (False,True):
   passes+=1;order,forms=(P.O[::-1],P.DROWS) if rev else (P.O,P.ROWS)
   vals=[0 if mask>>j&1 else 1<<j for j in range(680)]+[0]*len(P.R)
   for k in order:
    if k in holes:continue
    v=0
    for j in P.labels(forms[k]):v^=vals[j]
    vals[k]=v
    if not v and k not in PROTECTED:
     holes.add(k);added+=1
  if not added:break
  assert passes<100
 assert not holes&PROTECTED
 # Independently check every surviving original owner row after the holes are
 # removed, including owner 411 and all 110 other main ports.
 for rev in (False,True):
  order,forms=(P.O[::-1],P.DROWS) if rev else (P.O,P.ROWS)
  vals=[0 if mask>>j&1 else 1<<j for j in range(680)]+[0]*len(P.R)
  for k in order:
   if k in holes:continue
   for i in P.labels(forms[k]):vals[k]^=vals[i]
  for j in range(680):
   if j in gone:continue
   got=0
   for i in P.labels(forms[~j]):got^=vals[i]
   want=1<<j
   if rev and j<111 and j+111 not in gone:want^=1<<(j+111)
   if not rev and 111<=j<222 and j-111 not in gone:want^=1<<(j-111)
   assert got==want,(port,tuple(helpers),rev,j)
 return holes,passes

def baseline_hist(holes,helpers,productive):
 # Signed improvement against the full 111-port original. The caller loss
 # is all 38 roots and all paid idles/queries of one whole original port.
 hist=Counter()
 for k in holes:hist[P.G[k]]+=36
 for row in productive:
  if row['owner'] in helpers:hist[row['grade']]-=36
 hist[1]+=4
 for i in range(1,9):hist[7*i]+=4
 hist[127]-=2
 for i in range(1,10):hist[1+7*i]-=4
 return {k:v for k,v in sorted(hist.items()) if v}

def grouped(paid,productive,holes,helpers):
 g=Counter()
 for e in paid:
  if e['id'] not in holes:g[tuple(sorted((e['a'],e['b'])))]+=1
 for e in productive:
  if e['owner'] not in helpers:g[tuple(sorted((e['a'],e['b']))) ]-=1
 return g

def cert_for(port,helpers=()):
 ii,oo,owners,tree,reasons,paid,productive=W.ownership()
 gone={port,port+111};frozen=tree|{v for v,people in owners.items() if people-gone}
 L,U=W.windows(frozen);free={i for i in range(H.n) if L[i]!=U[i]}
 comps=W.components(free,L,U);holes,passes=closure(port,helpers);groups=grouped(paid,productive,holes,set(helpers))
 # Check that edge scores really are the net of separate retained paid and
 # retained productive occurrences. Deleted/zero occurrences are not folded
 # into that signed weight.
 origgroups=grouped(paid,productive,set(),set())
 assert all(origgroups[key]==m for key,(m,g) in H.group.items())
 hist=baseline_hist(holes,set(helpers),productive)
 weights={str(k):directed(k) for k in RATES}
 opt={str(k):{'sum':0,'selections':[]} for k in RATES}
 total=0;valid=0
 for comp in comps:
  ns=comp['nodes'];nsset=set(ns); edges=[]
  for a,b,_,grade in H.arcs:
   if a in nsset or b in nsset:
    assert not (a in free and b in free) or (a in nsset and b in nsset)
    edges.append((a,b,groups[tuple(sorted((a,b)))],grade))
  best={str(k):None for k in RATES};bestvars={}
  values=[range(len(L[i]),len(U[i])+1) for i in ns]
  for ds in product(*values):
   total+=1;d=dict(zip(ns,ds));terms=[]
   for a,b,m,g0 in edges:
    lo=d.get(a,H.dim[a]);hi=d.get(b,H.dim[b]);g=hi-lo
    if g<0:break
    assert g in range(9)
    if m:terms.append((m,g0,g))
   else:
    valid+=1
    for k in RATES:
     low,high=weights[str(k)]
     upper=sum(m*(high[g0]-low[g] if m>0 else low[g0]-high[g]) for m,g0,g in terms)
     if best[str(k)] is None or upper>best[str(k)]:best[str(k)]=upper;bestvars[str(k)]=ds
  for k in RATES:
   assert best[str(k)] is not None
   opt[str(k)]['sum']+=best[str(k)]
   opt[str(k)]['selections'].append({'nodes':ns,'ranks':list(bestvars[str(k)]),'upper_units':str(best[str(k)])})
 rates={}
 for k in RATES:
  low,high=weights[str(k)]
  projupper=sum(c*(high[g] if c>0 else low[g]) for g,c in hist.items())
  geom=36*opt[str(k)]['sum'];end=projupper+geom
  # Materialize each extremal dimension assignment, and recompute paid and
  # productive zero grades separately from the raw incidence roster.
  ranks=H.dim.copy()
  for choice in opt[str(k)]['selections']:
   for node,value in zip(choice['nodes'],choice['ranks']):ranks[node]=value
  h=Counter(hist);paid_zero=[];target_zero=[]
  for e in paid:
   if e['id'] in holes:continue
   new=abs(ranks[e['a']]-ranks[e['b']]);h[e['grade']]+=36;h[new]-=36
   if new==0:paid_zero.append(e['id'])
  for e in productive:
   if e['owner'] in helpers:continue
   new=abs(ranks[e['a']]-ranks[e['b']]);h[e['grade']]-=36;h[new]+=36
   if new==0:target_zero.append(e['owner'])
  h={g:c for g,c in sorted(h.items()) if c}
  recomputed=sum(c*(high[g] if c>0 else low[g]) for g,c in h.items())
  assert recomputed<=end
  rates[str(k)]={'projected_upper_units':str(projupper),'geometry_upper_units':str(geom),
    'complete_upper_units':str(end),'upper_display':str(H.prices.HI.divide(H.prices.D(end),H.prices.D(SCALE))),
    'upper_positive':end>0,'dimension_witness':opt[str(k)]['selections'],
    'witness_zero_paid_incidence_ids':paid_zero,'witness_zero_productive_helper_owners':target_zero,
    'witness_complete_signed_grade_histogram':h,'witness_recomputed_upper_units':str(recomputed)}
 return {'port':port,'optional_projected_helpers':list(helpers),'frozen_count':len(frozen),'free_count':len(free),
  'projected_zero_paid_packet_ids':sorted(holes),'projected_zero_paid_by_original_grade':dict(sorted(Counter(P.G[k] for k in holes).items())),
  'projected_lost_helper_grades':dict(sorted(Counter(e['grade'] for e in productive if e['owner'] in helpers).items())),
  'projection_fixed_point_passes':passes,'base_signed_grade_histogram':hist,
  'surviving_original_public_rows_each_direction':680-2-len(helpers),
  'tested_dimension_assignments':total,'order_compatible_dimension_assignments':valid,
  'max_component_nodes':max(c['count'] for c in comps),'rates':rates}

def main():
 started=monotonic();rows=[]
 for port in range(111):
  row=cert_for(port);rows.append(row)
  positive=[k for k in row['rates'] if row['rates'][k]['upper_positive']]
  if positive:print('POSITIVE_UPPER',port,[(k,row['rates'][k]['upper_display']) for k in positive],file=sys.stderr,flush=True)
  if port%10==9:print('ports',port+1,'seconds',round(monotonic()-started,2),file=sys.stderr,flush=True)
 extra=cert_for(89,[660])
 positive=[k for k in extra['rates'] if extra['rates'][k]['upper_positive']]
 if positive:print('POSITIVE_UPPER 89+660',[(k,extra['rates'][k]['upper_display']) for k in positive],file=sys.stderr,flush=True)
 print(json.dumps({'source':{**H.public_source(),'canonical_main_context':'e54523517d0f03e58352e647c403a5af3e525a57'},'scope':'Original cochart quotient and original nesting incidences retained; whole original caller port projected, zero paid packets omitted, all other main and protected tree anchors retained. Integer rank windows and all old-direction order inequalities form a relaxation, not a rational frame construction or a bound on a rebuilt post-deletion graph.',
 'scale':SCALE,'protected_tree_packet_ids':sorted(PROTECTED),'ports':rows,'port89_helper660':extra},sort_keys=True,indent=2))

if __name__=='__main__':main()
