#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Sharp direct-routing and same-start owner-retargeting bound at the full BIT sink."""
from collections import Counter, defaultdict
from functools import cache
from pathlib import Path
from hashlib import sha256
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / 'vendor'))
import common
import binary_operator as native


def bits(value):
    while value:
        bit = value & -value
        yield bit.bit_length() - 1
        value ^= bit


def add_pivot(table, row, witness=0):
    while row and row.bit_length() in table:
        vector, support = table[row.bit_length()]
        row ^= vector
        witness ^= support
    if row:
        table[row.bit_length()] = row, witness
        return True
    return False


def represent(table, row):
    witness = 0
    while row:
        vector, support = table[row.bit_length()]
        row ^= vector
        witness ^= support
    return witness


def intersection(rows, allowed):
    """Kernel of projection onto inputs outside one permitted source chart."""
    pivots = {}
    result = []
    for value in rows:
        restricted = value & ~allowed
        while restricted and restricted.bit_length() in pivots:
            vector, original = pivots[restricted.bit_length()]
            restricted ^= vector
            value ^= original
        if restricted:
            pivots[restricted.bit_length()] = restricted, value
        elif value:
            result.append(value)
    return result


def verify():
    word, caller, _, _, _, paid, productive, rational = common.baseline()
    atlas = native.Atlas(word['frames'])
    forward = native.run_tape(word, atlas, False)
    reverse = native.run_tape(word, atlas, True)
    assert forward.output == native.expected_operator(False)
    assert reverse.output == native.expected_operator(True)
    sink = 1
    incoming = forward.stock[sink]
    outputs = forward.demand[sink]
    assert len(incoming) == len(outputs) == 537
    assert all(item.label >= word['public'] for item in incoming)
    assert all(item.label < 0 for item in outputs)
    original = {}
    for j, item in enumerate(incoming):
        assert add_pivot(original, item.row, 1 << j)
    terminal_columns = [0] * len(incoming)
    for output in outputs:
        for j in bits(represent(original, output.row)):
            terminal_columns[j] |= 1 << ~output.label

    # The main operator is (X,Y) -> (X,Y+X) and is its own inverse. Helpers are identities.
    main_x = (1 << 111) - 1
    inputs = [column ^ ((column & main_x) << 111) for column in terminal_columns]

    @cache
    def response(row):
        return sum(((row & column).bit_count() & 1) << j for j, column in enumerate(inputs))

    for j, item in enumerate(incoming):
        assert response(item.row) == 1 << j
    for j, row in enumerate(forward.output):
        if word['final'][j] != sink:
            assert response(row) == 0
    original_grades = [forward.packets[item.label].grade for item in incoming]
    protected = (1 << 222) - 1 | 1 << 411
    omission_only = [j for j, col in enumerate(terminal_columns) if not col & protected]
    assert len(omission_only) == 97

    old_helpers = defaultdict(int)
    for owner, (start, end) in enumerate(zip(word['start'], word['final'])):
        if owner >= 222 and owner != 411 and end == sink:
            old_helpers[start] |= 1 << owner
    assert len(old_helpers) == 20
    available = {chart: [o.row for o in obs] for chart, obs in forward.stock.items() if chart != sink}
    assert len(available) == 635
    counts = Counter()
    pairings = Counter()
    loss_types = set()
    direct_by_grade = defaultdict(list)

    def evaluate(kind, row, charged_grade, regained_grade=0):
        observed = response(row)
        if not observed:
            return
        counts[kind, 'nonzero_projected_stock_rows'] += 1
        for j in bits(observed):
            pairings[kind, charged_grade, regained_grade, original_grades[j]] += 1

    for chart, rows in available.items():
        grade = atlas.grade(chart, sink)
        assert grade > 0
        direct_by_grade[grade].extend(rows)
        for row in rows:
            evaluate('paid', row, grade)

    for start, sink_owners in old_helpers.items():
        allowed = sum(1 << owner for owner, c in enumerate(word['start']) if c == start and owner != 411)
        old_grade = atlas.grade(start, sink)
        for chart, rows in available.items():
            new_grade = atlas.grade(start, chart)
            if not new_grade and start != chart:
                continue
            permitted = intersection(rows, allowed)
            if not any(row & sink_owners for row in permitted):
                continue
            # If some linear combination can carry an independent retargeted owner, the whole
            # stock basis is granted in the bound. Extra retargets must individually pay >= 0.
            assert old_grade >= new_grade
            loss_types.add((old_grade, new_grade))
            counts['retarget', 'eligible_source_receiver_pairs'] += 1
            for row in permitted:
                evaluate('retarget', row, old_grade, new_grade)

    trials = {}
    for rate in common.RATES:
        def signed_difference(charged, regained, old):
            histogram = Counter([charged])
            histogram[regained] -= 1
            histogram[old] -= 1
            positive = {g:n for g,n in histogram.items() if g and n > 0}
            negative = {g:-n for g,n in histogram.items() if g and n < 0}
            return common.moment(negative, positive, rate), not (negative or positive)

        strict = Counter()
        ties = Counter()
        gaps = []
        for (kind, charged, regained, old), multiplicity in pairings.items():
            interval, exact_zero = signed_difference(charged, regained, old)
            if exact_zero:
                ties[kind] += multiplicity
            else:
                assert interval[0] > 0, (kind, charged, regained, old, interval)
                strict[kind] += multiplicity
                gaps.append(interval[0])
        # A fictitious free sender with unit pairing against any grade-two old receipt breaks the bound.
        assert signed_difference(0, 0, 2)[0][1] < 0
        assert all(old >= new for old, new in loss_types)
        trials[str(rate)] = {
            'strict_basis_pairings': dict(strict), 'identically_equal_pairings': dict(ties),
            'smallest_strict_loss_minus_old_cost_lower': str(min(gaps)),
            'sharp_full_BIT_change_upper': '0',
            'full_BIT_margin': common.display(common.moment(paid, productive, rate)),
            'companion_rational_margin': common.display(common.moment(rational['signed']['paid'], rational['signed']['productive'], rate)),
        }

    # A separate direct-only cut grants every cheap bank's whole stock for free. A rank deficit
    # is therefore a lower bound on the number of individually paid higher-grade scalar ingresses.
    cumulative = {}
    thresholds = []
    for grade in range(9):
        for row in direct_by_grade[grade]:
            add_pivot(cumulative, row)
        joined = cumulative.copy()
        for item in incoming:
            add_pivot(joined, item.row)
        shared = len(cumulative) + len(incoming) - len(joined)
        old = sum(g <= grade for g in original_grades)
        assert shared == old
        thresholds.append({'grade':grade, 'pooled_stock_rank':len(cumulative), 'dimension_in_target_space':shared,
                           'required_more_expensive_ingresses':len(incoming)-shared})

    result = {
        'native_canonical_sha256': native.canonical_hash(word), 'caller_canonical_sha256': native.canonical_hash(caller),
        'public_native_owners': word['public'], 'existing_nonsink_charts':len(available),
        'sink':sink, 'original_basis_size':len(incoming), 'old_paid_grades':dict(sorted(Counter(original_grades).items())),
        'omission_only_protected_safe_packets': [incoming[j].label for j in omission_only],
        'omission_only_subsets':str(2**len(omission_only)), 'source_charts_with_sink_helpers':sorted(old_helpers),
        'permitted_source_receiver_grade_pairs':sorted(map(list,loss_types)),
        'counts':{' '.join(k):v for k,v in counts.items()},
        'all_nonzero_basis_pairings_by_cost':[{'kind':k,'charged_grade':u,'regained_grade':v,'old_paid_grade':g,'count':n}
                                               for (k,u,v,g),n in sorted(pairings.items())],
        'funded_threshold_cuts':thresholds, 'trials':trials, 'negative_control_detects_free_sender':True,
    }
    return result

if __name__ == '__main__':
    encoded = json.dumps(verify(), indent=2, sort_keys=True) + '\n'
    if '--write-certificate' in sys.argv:
        (HERE/'RESULT.json').write_text(encoded)
    else:
        assert encoded == (HERE/'RESULT.json').read_text()
    print('PASS 537 input and output directions, all nonsink paid stocks, 20 source groups, both signed trials, and all nine direct-routing grade cuts')
