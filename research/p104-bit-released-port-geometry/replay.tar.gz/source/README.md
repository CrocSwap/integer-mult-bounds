# Exact signed cost of replacing the 537 BIT sink ingresses

At both `κ = 0.003879928046156` and `κ = 0.003879929046155`, the original chart-1 sink on the #7830 BIT word has **minimum total cost** in the direct-routing and helper-retargeting family below. The original 537 scalar ingresses attain the bound. The maximum complete 36-call signed improvement is **exactly zero**. [Source construction](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) · [Earlier one-helper retarget](https://github.com/CrocSwap/integer-mult-bounds/pull/7927)

The replacement may delete any subset of original sink operations and buy any number of direct scalar transfers from any of the 635 other existing charts. It may choose arbitrary XORs of a sender's old source inputs and old paid arrivals. The bound grants all those rows simultaneously, even when a real implementation would need parking or a later deadline. New paid rows may contain unwanted inputs which cancel at the sink. The sink decoder may change completely. Any number of independent original sink helper outputs may move to other existing charts, with arbitrary local source recoding within the same original input chart and with every changed productive grade charged. The protected main map, owner 411 and all other original nonsink rows are retained. Nonsink packet stocks and chart geometry are fixed. 

The original basis has **342 grade-one, 189 grade-two and six grade-four transfers**. The proof reconstructs 537 independent native input perturbations. For each possible replacement row, the cost is at least the price of every original direction it can detect. A full-rank replacement therefore pays for all 537 original directions. For the 20 possible start-chart groups, every additional eligible independent retarget has nonnegative debit. A separate count of the full stock available at each paid grade shows that at least 195 original-dimension equivalents still need grades above one and at least six need grades above two or three when all original outputs stay at the sink. [Proof and scope](PROOF.md)

| Comparison | Original BIT margin | Companion rational margin | Best signed change here |
| --- | ---: | ---: | ---: |
| `0.003879928046156` | `−0.00000000076700150243113…` | `+0.212262470163346755…` | `0` |
| `0.003879929046155` | `−0.000385127316613866…` | `+0.211243929926514344…` | `0` |

Run these checks from the extracted directory with CPython 3.12 and its standard library. The two independent-replay commands write their reports to standard output. `cmp` returns success when the regenerated report is byte-identical to the included receipt.

```sh
sha256sum -c SHA256SUMS
python3 -IB verify.py
python3 -IB replay_combined.py | cmp - COMBINED-REPLAY.json
python3 -IB replay_sink.py | cmp - SINK-REPLAY.json
```

`RESULT.json` contains the complete source and recipient counts, comparison types and directed arithmetic. The separate implementation reconstructs the frozen tape using least-bit elimination and a different basis of admissible receiver rows. Both identify the same sharp cost and the same grade filtration. A deliberately free synthetic route fails the cost test. The smaller omission-only comparison in `SINK-REPLAY.json` covers all subsets of the 97 original ingresses eligible when the main and 411 returns stay fixed and no replacement ingress is purchased. The larger 537-direction claim also allows purchased replacements.

The upstream 36-call binary and 48-call rational invoices and the current finite, physical and outer premises remain those of the source construction. The comparison is an exact obstruction on the given stock. It establishes no new conditional lower bound or general upper bound on κ. [Native and directed-arithmetic provenance](SOURCES.json) · [Credit](NOTICE)
