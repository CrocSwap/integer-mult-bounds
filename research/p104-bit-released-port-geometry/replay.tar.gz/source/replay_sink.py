#!/usr/bin/env python3
"""Independently reconstruct chart-1 and source intersections from native tape.

Linear matroid costs grant every older/casually unrelated stock for free;
they are not a physical construction.  Includes zero-projection features
so extra retargets cannot silently be credited without accounting for them.
"""
import hashlib,json,importlib.util
from collections import Counter,defaultdict
from pathlib import Path
from fractions import Fraction
from decimal import Decimal
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base',H/'replay_bit.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
need=b.need
PIN='853f3e3c322f644bee3bef69076c21c0177ab29ac13cc37c832757d1142c8348'
def bits(x):
 while x:
  lb=x&-x;yield lb.bit_length()-1;x^=lb

def add(piv,x,record=0):
 while x:
  k=(x&-x).bit_length()-1
  if k not in piv:piv[k]=(x,record);return True
  y,r=piv[k];x^=y;record^=r
 return False

def solve(piv,x):
 m=0
 while x:
  k=(x&-x).bit_length()-1
  need(k in piv,'vector outside sink stock span')
  y,r=piv[k];x^=y;m^=r
 return m

def raw_tape(w):
 n=w['public'];need(n==680,'baseline n')
 state=[(c,1<<i) for i,c in enumerate(w['start'])]+[None]*w['owned_fields']
 stock=defaultdict(list);demand=defaultdict(list);moves={}
 for i,c in enumerate(w['start']):stock[c].append((i,1<<i))
 p=n
 for clock,(op,a,*args) in enumerate(w['program']):
  if op=='INIT':need(state[a] is None,'init');state[a]=(args[0],0)
  elif op=='CLEAR':need(state[a] is not None and state[a][0]==args[0],'clear');state[a]=None
  elif op=='ADD':
   j,c=args;need(a!=j and state[a][0]==state[j][0]==c,'add chart');state[a]=(c,state[a][1]^state[j][1])
  elif op=='SWAP':
   j=args[0];need(a!=j and state[a] is not None and state[j] is not None,'swap');state[a],state[j]=state[j],state[a]
  else:
   need(op=='MOVE' and state[a] is not None,'move');s,c=args;need(state[a][0]==s,'move chart');x=state[a][1]
   stock[c].append((p,x));demand[s].append((p,x));moves[p]=(clock,s,c);p+=1;state[a]=(c,x)
 need(all(x is None for x in state[n:]),'retirement');need([v[0] for v in state[:n]]==w['final'],'endpoint tags')
 for i,(c,row) in enumerate(state[:n]):demand[c].append((~i,row))
 return stock,demand,moves

def intersection(stock,allowed):
 # First remove linear dependencies *inside* the old stock, then compute
 # the kernel of projection to outside coordinates using least-bit pivots.
 sb={}
 for _,row in stock:add(sb,row)
 quotient={};inter={}
 for row,_ in sb.values():
  x=row&~allowed;v=row
  while x:
   k=(x&-x).bit_length()-1
   if k not in quotient:quotient[k]=(x,v);break
   z,r=quotient[k];x^=z;v^=r
  else:
   if v:add(inter,v)
 return [x for x,_ in inter.values()]

def addhist(a,b,coef=1):
 c=Counter(a);c[b]+=coef
 return tuple(sorted((i,n) for i,n in c.items() if i and n))
def sig(old,new):
 h=Counter({old:1})
 if new:h[new]-=1
 return tuple(sorted((i,n) for i,n in h.items() if i and n))
def cost_interval(sig,k):
 lo=hi=Decimal(0)
 for grade,n in sig:
  a,c=b.pow_interval(grade,Decimal(1)-Decimal(k))
  if n>=0:lo=b.L.add(lo,b.L.multiply(a,Decimal(n)));hi=b.U.add(hi,b.U.multiply(c,Decimal(n)))
  else:lo=b.L.add(lo,b.L.multiply(c,Decimal(n)));hi=b.U.add(hi,b.U.multiply(a,Decimal(n)))
 return lo,hi

def main():
 source=(H/'inputs/SINK-MATROID.json').read_bytes();need(hashlib.sha256(source).hexdigest()==PIN,'Astra receipt pin');source=json.loads(source)
 w=b.load('WORD.json.gz');frames=b.frames(w);stock,demand,moves=raw_tape(w)
 inc=stock[1];need(len(inc)==537,'sink stock occurrence count');basis={}
 for i,(label,row) in enumerate(inc):need(add(basis,row,1<<i),'sink stock full independence')
 # Sink must have no outgoing paid reads for this to be a terminal decoder.
 need(all(label<0 for label,row in demand[1]),'not a full terminal sink')
 dependencies=[0]*len(inc)
 for label,row in demand[1]:
  representation=solve(basis,row);owner=~label
  for i in bits(representation):dependencies[i]|=1<<owner
 protected=(1<<222)-1|(1<<411);eligible=[i for i,d in enumerate(dependencies) if not d&protected];packets=[inc[i][0] for i in eligible];need(packets==source['eligible_packets'] and len(eligible)==97,'all protected-safe ingress roster')
 subdep=[dependencies[i] for i in eligible];starts=sorted({w['start'][j] for j in range(222,680) if j!=411 and w['final'][j]==1});need(starts==source['all_chart1_helper_source_charts'],'all helper source charts')
 options=defaultdict(list);costs=defaultdict(int);unprojected=Counter();omitted_hist=Counter()
 for i,(idx,p) in enumerate(zip(eligible,packets,strict=True)):
  _,s,t=moves[p];g=b.leg(frames,s,t);options[sig(g,0)].append(1<<i);omitted_hist[g]+=1
 dim={k:len(v['B']) for k,v in frames.items()}
 for start in starts:
  allowed=sum(1<<j for j,c in enumerate(w['start']) if c==start and j!=411)
  old=b.leg(frames,start,1)
  for dest,rows in stock.items():
   if dest==1:continue
   if dest==start:new=0
   else:
    a,z=sorted((start,dest),key=lambda q:dim[q]);new=dim[z]-dim[a]
    if not new or any(sum(x*y for x,y in zip(u,v)) for u in frames[a]['B'] for v in frames[z]['A']):continue
   inter=intersection(rows,allowed)
   if inter:unprojected[(old,new)]+=len(inter)
   for row in inter:
    vec=sum(((row&dep).bit_count()&1)<<i for i,dep in enumerate(subdep))
    costs[(old,new,bool(vec))]+=1
    if vec:options[sig(old,new)].append(vec)
 layers={};trials={}
 for rate in ('0.003879928046156','0.003879929046155'):
  cost={s:cost_interval(s,rate) for s in options};order=sorted(options,key=lambda x:cost[x][0])
  for x,y in zip(order,order[1:]):need(cost[x][1]<cost[y][0],'ambiguous weighted ordering')
  basis2={};detail=[];paidcost=Counter();
  for signature in order:
   before=len(basis2)
   for vec in options[signature]:
    if add(basis2,vec):paidcost.update(dict(signature))
   detail.append({'signature':[list(x) for x in signature],'rank':len(basis2),'added':len(basis2)-before,'cost_interval':[str(v) for v in cost[signature]]})
  need(len(basis2)==97,'full matroid rank')
  delta=Counter(omitted_hist);delta.subtract(paidcost);delta={k:v for k,v in delta.items() if v}
  need(not delta,'nonzero matroid optimum')
  need([x['rank'] for x in detail]==[x['cumulative_rank'] for x in source['trials'][rate]['rank_filtration']],'independent rank filtration')
  trials[rate]={'filtration':detail,'full_36_call_gain_upper':'0 exactly','baseline_margin':[str(x) for x in b.margin(Counter({int(k):v for k,v in b.load('BIT.json')['native']['targets'].items()}),Counter({int(k):v for k,v in b.load('BIT.json')['native']['paid'].items()}),rate)]}
 # Stronger coordinatewise certificate: each existing alternative that
 # detects an omitted ingress costs at least that ingress's original rank.
 # Check basis vectors; linearity extends zero coordinates to all their XORs.
 ingress_grades=[b.leg(frames,*moves[p][1:]) for p in packets]
 matching_checks=0
 for rate in ('0.003879928046156','0.003879929046155'):
  for signature,vecs in options.items():
   lo,_=cost_interval(signature,rate)
   for vec in vecs:
    for i in bits(vec):
     matching_checks+=1;g=ingress_grades[i]
     need(signature==((g,1),) or lo>b.pow_interval(g,Decimal(1)-Decimal(rate))[1],'underpriced paired coordinate')
 # Synthetic stress control: a genuinely new free observation of the first
 # protected-safe coordinate must turn the optimum into a positive gain.
 synthetic={k:list(v) for k,v in options.items()};synthetic.setdefault((),[]).append(1)
 test_basis={};test_cost=Counter()
 for signature in sorted(synthetic,key=lambda x:cost_interval(x,'0.003879928046156')[0]):
  for vec in synthetic[signature]:
   if add(test_basis,vec):test_cost.update(dict(signature))
 test_gain=Counter(omitted_hist);test_gain.subtract(test_cost);test_gain={k:v for k,v in test_gain.items() if v}
 test_interval=cost_interval(tuple(sorted(test_gain.items())),'0.003879928046156')
 need(len(test_basis)==97 and test_interval[0]>0,'free observation stress control')
 # Every alternative including zero projected rows has nonnegative cost iff no
 # actual grade rises above the original source->full-sink grade.  If any such
 # row exists, extra retargets may not be dropped from an upper-bound proof.
 adverse=[{'old_grade':old,'new_grade':new,'projected':projected,'count':count} for (old,new,projected),count in sorted(costs.items()) if new>old]
 print(json.dumps({'status':'PASS_RECONSTRUCTED_97_MATROID' if not adverse else 'ATTENTION_EXTRA_RETARGET_NEGATIVE_COST','word':b.canon(w),'source_receipt_sha256':PIN,'sink_basis_dimension':len(inc),'eligible_packets':packets,'eligible_count':len(eligible),'subsets':str(1<<len(eligible)),'old_grade_counts':dict(omitted_hist),'source_groups':starts,'independent_unprojected_basis_counts':{str(k):v for k,v in sorted(unprojected.items())},'additional_retarget_negative_cost_candidates':adverse,'coordinatewise_cost_pairs_checked':matching_checks,'synthetic_free_observation_control':{'direction':0,'native_gain_histogram':test_gain,'native_gain_interval':[str(x) for x in test_interval],'scope':'synthetic mutation only, no real route or stock'},'trial_results':trials,'scope':'Only original incoming chart-1 omissions with main owners and 411 protected, arbitrary decoder and within-source basis, retargeted helper outputs from pre-existing chart stocks granted wholesale without chronology cost, no new paid packet or changed nonsink stock. Relaxed weighted binary matroid may use source intersections more freely than physical multiplicity allows. Not a completed physical supplier or a universal no-gain theorem.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
