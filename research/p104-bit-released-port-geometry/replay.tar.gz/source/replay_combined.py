#!/usr/bin/env python3
"""Independent 537-dimensional funded ingress + retarget sink certificate."""
import hashlib,json,importlib.util
from collections import Counter,defaultdict
from decimal import Decimal
from pathlib import Path
H=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('sink',H/'replay_sink.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
b=s.b;need=b.need
RATES=('0.003879928046156','0.003879929046155')
def main():
 producer=(H/'inputs/COMBINED-SINK.json').read_bytes();need(hashlib.sha256(producer).hexdigest()=='97534c3e3c2318f421e161b923020411c6cf2f4321e8c60bab592566760c8631','combined producer receipt pin');producer=json.loads(producer)
 funded=(H/'inputs/FUNDED-SINK.json').read_bytes();need(hashlib.sha256(funded).hexdigest()=='817b03b1629eaa4e651968ee6846c4864a198586af0b3ce95589f0b4a5e340f7','funded producer receipt pin');funded=json.loads(funded)
 need(producer['dimension']==537 and not producer['cheaper_pairing_counts'] and not producer['signed_relaxed_hist'] and all(row['rank_relaxation_excess']==0 for row in funded['layers']),'producer recorded scoped result')
 w=b.load('WORD.json.gz');frames=b.frames(w);stock,demand,moves=s.raw_tape(w);inc=stock[1];need(len(inc)==537 and all(label in moves for label,row in inc),'537 actual incoming paid rows')
 bp={}
 for i,(_,row) in enumerate(inc):need(s.add(bp,row,1<<i),'all sink arrivals independent')
 dual_output=[0]*len(inc)
 for label,row in demand[1]:
  need(label<0,'no outgoing sink paid rows')
  for i in s.bits(s.solve(bp,row)):dual_output[i]|=1<<~label
 # The literal public transform has Y <- Y+X. Its inverse is itself. Pull
 # each output-coordinate dependence back to an input-space dual direction.
 dual=[d^((d&((1<<111)-1))<<111) for d in dual_output];N=len(dual)
 def projection(row):return sum(((row&direction).bit_count()&1)<<i for i,direction in enumerate(dual))
 for i,(_,row) in enumerate(inc):need(projection(row)==1<<i,'source sink dual basis')
 # Every unchanged public output outside the terminal sink annihilates these
 # directions; otherwise the 537-dimensional cut would not be necessary.
 for j,chart in enumerate(w['final']):
  if chart==1:continue
  row=(1<<j)^((1<<(j-111)) if 111<=j<222 else 0)
  need(projection(row)==0,'external terminal cut leakage')
 grades=[b.leg(frames,moves[p][1],moves[p][2]) for p,_ in inc]
 old=Counter(grades);need(old=={1:342,2:189,4:6},'actual original 537 paid prices')
 options=defaultdict(list);counts=Counter()
 def add(signature,row,kind):
  z=projection(row)
  if z:options[signature].append(z);counts[kind]+=1
 for (label,row),g in zip(inc,grades,strict=True):add(s.sig(g,0),row,'old')
 # Grant the whole frozen nonsink stock of every chart, including arrivals
 # whose actual lifetimes or clocks would prohibit a proposed use.
 for c,rows in stock.items():
  if c==1:continue
  g=b.leg(frames,c,1)
  for label,row in rows:add(s.sig(g,0),row,'new_paid_relaxation')
 starts=sorted({w['start'][j] for j in range(222,680) if j!=411 and w['final'][j]==1});dim={k:len(v['B']) for k,v in frames.items()};extra=Counter()
 for start in starts:
  allowed=sum(1<<j for j,c in enumerate(w['start']) if c==start and j!=411);g0=b.leg(frames,start,1)
  for dest,rows in stock.items():
   if dest==1:continue
   if dest==start:g=0
   else:
    a,z=sorted((start,dest),key=lambda q:dim[q]);g=dim[z]-dim[a]
    if not g or any(sum(x*y for x,y in zip(u,v)) for u in frames[a]['B'] for v in frames[z]['A']):continue
   for row in s.intersection(rows,allowed):
    extra[g0,g]+=1
    add(s.sig(g0,g),row,'retarget_relaxation')
 need(all(new<=oldg for oldg,new in extra),'negative cost extra retarget')
 grade_masks={g:sum(1<<i for i,v in enumerate(grades) if v==g) for g in old}
 trials={};pairchecks=0
 for rate in RATES:
  prices={g:b.pow_interval(g,Decimal(1)-Decimal(rate)) for g in old}
  intervals={sig:s.cost_interval(sig,rate) for sig in options}
  # Exhaust every basis direction of every cost class. A linear combination
  # within the same class cannot acquire a coordinate absent in every basis.
  for sig,vecs in options.items():
   for g,mask in grade_masks.items():
    low,_=intervals[sig];bad=(sig!=((g,1),) and low<=prices[g][1])
    for vec in vecs:
     pairchecks+=1
     need(not (bad and vec&mask),'a cheaper candidate pairs with an old sink direction')
  order=sorted(options,key=lambda x:intervals[x][0])
  for a,z in zip(order,order[1:]):need(intervals[a][1]<intervals[z][0],'ambiguous cost class ordering')
  basis={};paid=Counter();layers=[]
  for sig in order:
   prior=len(basis)
   for vec in options[sig]:
    if s.add(basis,vec):paid.update(dict(sig))
   layers.append({'cost_signature':[list(x) for x in sig],'rank':len(basis),'added':len(basis)-prior,'cost_interval':[str(x) for x in intervals[sig]]})
  diff=Counter(old);diff.subtract(paid);diff={k:v for k,v in diff.items() if v}
  need(len(basis)==537 and not diff,'combined relaxed optimal exact zero')
  trials[rate]={'cumulative_rank_by_price':layers,'complete_36_call_signed_gain_upper':'0 exactly'}
 # A fictitious free new route to one grade-one target must become profitable.
 altered={k:list(v) for k,v in options.items()};altered.setdefault((),[]).append(1<<grades.index(1));bb={};paid=Counter()
 for sig in sorted(altered,key=lambda x:s.cost_interval(x,RATES[0])[0]):
  for vec in altered[sig]:
   if s.add(bb,vec):paid.update(dict(sig))
 diff=Counter(old);diff.subtract(paid);diff={k:v for k,v in diff.items() if v};gain=s.cost_interval(tuple(sorted(diff.items())),RATES[0]);need(len(bb)==537 and gain[0]>0,'free paid path must alter optimum')
 out={'status':'PASS_COMBINED_537_FUNDED_SINK','word':b.canon(w),'producer_receipts_sha256':{'combined':'97534c3e3c2318f421e161b923020411c6cf2f4321e8c60bab592566760c8631','funded':'817b03b1629eaa4e651968ee6846c4864a198586af0b3ce95589f0b4a5e340f7'},'old_sink_basis_dimension':N,'old_sink_paid_grades':dict(old),'actual_features_considered':dict(counts),'same_start_source_groups':starts,'all_input_duals_checked':N,'protected_nonsink_terminal_checks':'PASS','cost_class_coordinate_checks':pairchecks,'negative_extra_retarget_classes':[],'trials':trials,'synthetic_free_paid_route':{'native_gain_histogram':diff,'native_gain_interval':[str(x) for x in gain],'scope':'injected control only; no such free paid route constructed'},'scope':'Full frozen nonsink historical stock and arbitrary causal retention are granted free. Arbitrarily many direct paid routes to the original terminal chart-1 and same-start helper output retargets are allowed, with their full grade tariffs; non-sink packet values and protected main/411 terminals stay fixed, and no cross-start input action or changed exterior packet is allowed. It is an optimistic necessary-condition screen, not a physical supplier or general κ theorem.'}
 print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
