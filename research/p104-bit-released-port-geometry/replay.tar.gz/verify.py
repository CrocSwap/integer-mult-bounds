#!/usr/bin/env python3
"""Independent paid-vs-productive incidence audit of all 112 rank ceilings."""
from collections import Counter,defaultdict
from decimal import Decimal,localcontext
from itertools import product
from pathlib import Path
from hashlib import sha256
import json,sys,time

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import windows as W
import hull as H
import port_cut as P

SCALE=10**28

def main():
 saved=json.loads((ROOT/'OPTIMISTIC.json').read_text());window=json.loads((ROOT/'WINDOWS.json').read_text())
 assert sha256((ROOT/'vendor/physical.py').read_bytes()).hexdigest()=='34dbf131f9d305d8e98b7284476dab2d2a250a28a02d3cf4c55b4232cfd0d435'
 assert sha256((ROOT/'vendor/finite.py').read_bytes()).hexdigest()=='c780cea060f4a9efef064b239636162a7e8e84e40369abc1a1c4679dfbeb3041'
 word,caller,_,np,nt,basepaid,basetarget,rat=H.prices.baseline()
 assert sum(np.values())==2874 and sum(nt.values())==458
 rational={str(k):H.prices.display(H.prices.moment(rat['signed']['paid'],rat['signed']['productive'],k)) for k in H.prices.RATES}
 ii,oo,owners,tree,_,paid,prod=W.ownership()
 assert len(tree)==len(window['tree_protected_nodes'])
 rates=H.prices.RATES
 bounds={}
 for rate in rates:
  lo=[];hi=[]
  for g in range(128):
   a,b=H.prices.power(g,rate)
   with localcontext() as ctx:
    ctx.prec=120
    l=int((a*Decimal(SCALE)).to_integral_value(rounding='ROUND_FLOOR'))
    h=int((b*Decimal(SCALE)).to_integral_value(rounding='ROUND_CEILING'))
    z=Decimal(g) if g<=1 else ((Decimal(1)-rate)*Decimal(g).ln()).exp()
    assert Decimal(l)/SCALE<=z<=Decimal(h)/SCALE,(rate,g)
   lo.append(l);hi.append(h)
  bounds[str(rate)]=(lo,hi)
 starts=time.monotonic();reports=[]
 cases=saved['ports']+[saved['port89_helper660']]
 for num,case in enumerate(cases):
  port=case['port'];helpers=set(case['optional_projected_helpers']);gone={port,port+111}|helpers
  frozen=tree|{v for v,o in owners.items() if o-{port,port+111}}
  lower,upper=W.windows(frozen);free={i for i in range(H.n) if lower[i]!=upper[i]}
  comps=W.components(free,lower,upper); assert len(free)==case['free_count']
  # Existing separate projection interpreter is only an input for the hole
  # roster; the bounds below reconstruct paid and productive prices anew.
  _,_,_,prior=P.projection([port],tuple(sorted(helpers)))
  holes=set(case['projected_zero_paid_packet_ids']);assert holes==prior
  assert not holes&set(saved['protected_tree_packet_ids'])
  index={v:i for i,c in enumerate(comps) for v in c['nodes']}
  constraints=[[] for _ in comps];incidences=[Counter() for _ in comps]
  for a,b,_,g in H.arcs:
   if a in index or b in index:
    comp=index[a] if a in index else index[b]
    if a in index and b in index:assert index[a]==index[b]
    constraints[comp].append((a,b))
  for category,items in ((1,paid),(-1,prod)):
   for e in items:
    if category==1 and e['id'] in holes:continue
    if category==-1 and e['owner'] in helpers:continue
    a,b=e['a'],e['b']
    if a not in index and b not in index:continue
    comp=index[a] if a in index else index[b]
    if a in index and b in index:assert index[a]==index[b]
    if H.dim[a]>H.dim[b]:a,b=b,a
    incidences[comp][(a,b,e['grade'],category)]+=1
  out={}
  for rate in rates:
   lo,hi=bounds[str(rate)]
   # Reprice each paid and productive event separately, with opposite
   # directed endpoints, so grade-zero target losses cannot be overlooked.
   base=sum(36*hi[P.G[k]] for k in holes)
   base-=sum(36*lo[e['grade']] for e in prod if e['owner'] in helpers)
   base+=4*hi[1]+4*sum(hi[7*i] for i in range(1,9))
   base-=2*lo[127]+4*sum(lo[1+7*i] for i in range(1,10))
   total=base;enumerated=0
   for idx,c in enumerate(comps):
    nodes=c['nodes'];best=None
    for values in product(*(range(len(lower[x]),len(upper[x])+1) for x in nodes)):
     enumerated+=1;d=dict(zip(nodes,values))
     if any(d.get(a,H.dim[a])>d.get(b,H.dim[b]) for a,b in constraints[idx]):continue
     score=0
     for (a,b,oldg,category),count in incidences[idx].items():
      newg=d.get(b,H.dim[b])-d.get(a,H.dim[a]);assert 0<=newg<=8
      score+=count*((hi[oldg]-lo[newg]) if category==1 else (hi[newg]-lo[oldg]))
     if best is None or score>best:best=score
    assert best is not None;total+=36*best
   assert total<0,(port,helpers,rate,total)
   reported=int(case['rates'][str(rate)]['complete_upper_units'])
   assert total>=reported
   out[str(rate)]={'separate_incidence_upper_units':str(total),
      'separate_incidence_upper':str(Decimal(total)/SCALE),
      'producer_upper_units':str(reported),'outward_slack_units':str(total-reported)}
  reports.append({'port':port,'helpers':sorted(helpers),'holes_match_separate_projection':True,
                  'enumerated_per_trial':enumerated,'rates':out})
  if num%20==19:print('independently checked',num+1,'seconds',round(time.monotonic()-starts,2),file=sys.stderr,flush=True)
 bests={str(k):max((Decimal(r['rates'][str(k)]['separate_incidence_upper']),r['port'],r['helpers']) for r in reports) for k in rates}
 print(json.dumps({'status':'PASS_ALL_112_NEGATIVE','scope':saved['scope'],'rates':{k:[str(v[0]),v[1],v[2]] for k,v in bests.items()},
  'baseline_full_680_by_680_forward_and_adjoint':True,'baseline_native_paid_per_call':dict(np),
  'baseline_native_productive_per_call':dict(nt),'fixed_48_call_rational_margin':rational,
  'price_enclosure_tested_ranks':128,'cases':reports},sort_keys=True,indent=2))

if __name__=='__main__':main()
