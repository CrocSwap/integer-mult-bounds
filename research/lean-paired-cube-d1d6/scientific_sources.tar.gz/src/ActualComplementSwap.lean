import ActualRootLeftLowering
namespace ActualComplementSwap
open BinarySpace24 ChartComposition ActualRootCanonicalBinding FourthRootLift BinaryBilinearCertificate
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def swapChart := compose (cx 21 22 (by decide)) (compose (cx 22 21 (by decide)) (cx 21 22 (by decide)))
def completed := compose RootJointGeometry.joint swapChart

theorem all_columns_checked : (List.finRange 24).all (fun j => (List.finRange 24).all (fun k =>
    decide (sourceChart.forward (unit j) k=completed.forward (unit j) k)))=true := by decide

theorem all_columns (j : Index) : sourceChart.forward (unit j)=completed.forward (unit j) := by
  apply SourceLineCase.vector_check
  exact List.all_eq_true.mp all_columns_checked j (List.mem_ofFn.mpr ⟨j,rfl⟩)

theorem forward_equal (x : Vec) : sourceChart.forward x=completed.forward x := by
  funext k
  apply linear_basis_ext (fun y => sourceChart.forward y k) (fun y => completed.forward y k)
  · intro y z
    exact congrFun (sourceChart.forward_add y z) k
  · intro y z
    exact congrFun (completed.forward_add y z) k
  · intro j
    exact congrFun (all_columns j) k

theorem inverse_equal (x : Vec) : sourceChart.inverse x=completed.inverse x := by
  have h := congrArg sourceChart.inverse (forward_equal (completed.inverse x))
  rw [sourceChart.inverse_left,completed.inverse_right] at h
  exact h.symm

theorem swap_formula (x : Vec) : swapChart.forward x=fun j =>
    if j=21 then x 22 else if j=22 then x 21 else x j := by
  change (cx 21 22 (by decide)).forward ((cx 22 21 (by decide)).forward ((cx 21 22 (by decide)).forward x))=_
  rw [cx_address,cx_address,cx_address]
  funext j
  by_cases h21 : j=21 <;> by_cases h22 : j=22 <;>
    simp_all [Q21AddressProgram.execute,add,scale,unit,eq_comm,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

end ActualComplementSwap
#print axioms ActualComplementSwap.all_columns_checked
#print axioms ActualComplementSwap.all_columns
#print axioms ActualComplementSwap.forward_equal
#print axioms ActualComplementSwap.inverse_equal
#print axioms ActualComplementSwap.swap_formula
