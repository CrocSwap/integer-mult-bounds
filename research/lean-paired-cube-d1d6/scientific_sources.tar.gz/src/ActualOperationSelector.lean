import OperationFrameCatalog
import WordCatalogBounds
import CatalogKeySelector
namespace ActualOperationSelector
open BinarySpace24 BinaryCompletion VariableCertificates CatalogSpanBridge CatalogSelector Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

abbrev InRange := CatalogKeySelector.InRange 17400

noncomputable def witness (k : Nat) (hk : InRange k) :=
  CatalogKeySelector.witness OperationFrameCatalog.certificates 17400 OperationFrameCatalog.key_range k hk

theorem witness_member (k : Nat) (hk : InRange k) : witness k hk ∈ OperationFrameCatalog.certificates :=
  (CatalogKeySelector.witness_properties _ _ OperationFrameCatalog.key_range OperationFrameCatalog.valid k hk).1

theorem witness_key (k : Nat) (hk : InRange k) : (witness k hk).key=k :=
  (CatalogKeySelector.witness_properties _ _ OperationFrameCatalog.key_range OperationFrameCatalog.valid k hk).2.1

theorem witness_valid (k : Nat) (hk : InRange k) : check (witness k hk)=true :=
  (CatalogKeySelector.witness_properties _ _ OperationFrameCatalog.key_range OperationFrameCatalog.valid k hk).2.2

noncomputable def keyRepresentative (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : InRange k) :=
  CatalogKeySelector.representative i hi htwo OperationFrameCatalog.certificates 17400
    OperationFrameCatalog.key_range OperationFrameCatalog.valid k hk

theorem key_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : InRange k) (f : Vec → F) :
    let r := keyRepresentative i hi htwo k hk
    r.decode (r.encode f)=f ∧ r.encode (r.decode f)=f :=
  CatalogKeySelector.inverses i hi htwo _ _ OperationFrameCatalog.key_range OperationFrameCatalog.valid k hk f

theorem key_preimage (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : InRange k) (v : Vec × Vec) :
    ((keyRepresentative i hi htwo k hk).label v).1=zero ↔ Frame (Span (witness k hk)) v :=
  CatalogKeySelector.preimage i hi htwo _ _ OperationFrameCatalog.key_range OperationFrameCatalog.valid k hk v

theorem key_Pauli (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : InRange k)
    (v : Vec × Vec) (f : Vec → F) :
    let r := keyRepresentative i hi htwo k hk
    r.encode (ExactQuadraticLift.pauli v.1 v.2 (r.decode f))=fun x => r.phase v*ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 f x :=
  CatalogKeySelector.exact_Pauli i hi htwo _ _ OperationFrameCatalog.key_range OperationFrameCatalog.valid k hk v f

noncomputable def stepRepresentative (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (s : PairedWord.Step) (hs : s ∈ PairedWordData.word) :=
  keyRepresentative i hi htwo (ActualFrameKeys.key s) (WordCatalogBounds.step_key_bounds s hs)

theorem every_word_step_covered (s : PairedWord.Step) (hs : s ∈ PairedWordData.word) :
    ∃c, c ∈ OperationFrameCatalog.certificates ∧ c.key=ActualFrameKeys.key s ∧ check c=true := by
  let hk := WordCatalogBounds.step_key_bounds s hs
  exact ⟨witness _ hk,witness_member _ hk,witness_key _ hk,witness_valid _ hk⟩

theorem same_key_same_representative (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (s t : PairedWord.Step) (hs : s ∈ PairedWordData.word) (ht : t ∈ PairedWordData.word)
    (h : ActualFrameKeys.key s=ActualFrameKeys.key t) :
    (stepRepresentative i hi htwo s hs).encode=(stepRepresentative i hi htwo t ht).encode := by
  exact CatalogKeySelector.same_key_same_operator i hi htwo _ _ OperationFrameCatalog.key_range OperationFrameCatalog.valid _ _ _ _ h

theorem same_key_common_mix (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (s t : PairedWord.Step) (hs : s ∈ PairedWordData.word) (ht : t ∈ PairedWordData.word)
    (h : ActualFrameKeys.key s=ActualFrameKeys.key t) (a b : F) (f g : Vec → F) :
    CommonExactFrame.mix a b ((stepRepresentative i hi htwo s hs).encode f) ((stepRepresentative i hi htwo t ht).encode g)=
      (stepRepresentative i hi htwo s hs).encode (CommonExactFrame.mix a b f g) := by
  rw [← same_key_same_representative i hi htwo s t hs ht h]
  exact CommonExactFrame.common_mix (stepRepresentative i hi htwo s hs).toExactFrame a b f g

end ActualOperationSelector
#print axioms ActualOperationSelector.witness_member
#print axioms ActualOperationSelector.witness_key
#print axioms ActualOperationSelector.witness_valid
#print axioms ActualOperationSelector.key_inverses
#print axioms ActualOperationSelector.key_preimage
#print axioms ActualOperationSelector.key_Pauli
#print axioms ActualOperationSelector.every_word_step_covered
#print axioms ActualOperationSelector.same_key_same_representative
#print axioms ActualOperationSelector.same_key_common_mix
