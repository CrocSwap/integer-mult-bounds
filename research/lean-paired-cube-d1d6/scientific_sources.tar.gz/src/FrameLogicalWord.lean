import FrameLogicalStep
namespace FrameLogicalWord
open CommonExactFrame ExactTransportTrace FrameLogicalStep Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {X : Type u} {F : Type v} [Field F]

def logicalRun : List PairedWord.Step → Arrays X F → Arrays X F
  | [],v => v
  | s::ss,v => logicalRun ss (logicalStep s v)

theorem logical_pointwise (ss : List PairedWord.Step) (v : Arrays X F) (r : Nat) (x : X) :
    logicalRun ss v r x=FieldWordTrace.run ss (fun j => v j x) r := by
  induction ss generalizing v with
  | nil => rfl
  | cons s ss ih =>
    rw [logicalRun,ih]
    rfl

theorem logical_as_field_run (ss : List PairedWord.Step) (v : Arrays X F) :
    logicalRun ss v=fun r x => FieldWordTrace.run ss (fun j => v j x) r := by
  funext r x
  exact logical_pointwise ss v r x

theorem run_correct (select : Nat → ExactFrame X F) (ss : List PairedWord.Step)
    (g : GaugeKeyTrace.State) (v : Arrays X F) :
    ExactTransportTrace.run select ss g (encode select g v)=
      (GaugeKeyTrace.run ss g,encode select (GaugeKeyTrace.run ss g) (logicalRun ss v)) := by
  induction ss generalizing g v with
  | nil => rfl
  | cons s ss ih =>
    simp only [ExactTransportTrace.run,GaugeKeyTrace.run,logicalRun]
    rw [step_correct,ih]

theorem run_correct_pointwise (select : Nat → ExactFrame X F) (ss : List PairedWord.Step)
    (g : GaugeKeyTrace.State) (v : Arrays X F) :
    ExactTransportTrace.run select ss g (encode select g v)=
      (GaugeKeyTrace.run ss g,encode select (GaugeKeyTrace.run ss g)
        (fun r x => FieldWordTrace.run ss (fun j => v j x) r)) := by
  rw [run_correct,logical_as_field_run]

theorem decoded_run (select : Nat → ExactFrame X F) (ss : List PairedWord.Step)
    (g : GaugeKeyTrace.State) (v : Arrays X F) :
    decode select (GaugeKeyTrace.run ss g) (ExactTransportTrace.run select ss g (encode select g v)).2=
      logicalRun ss v := by
  rw [run_correct,decode_encode]

theorem arbitrary_entrance (select : Nat → ExactFrame X F) (ss : List PairedWord.Step)
    (g : GaugeKeyTrace.State) (v : Arrays X F) :
    decode select (GaugeKeyTrace.run ss g) (ExactTransportTrace.run select ss g v).2=
      logicalRun ss (decode select g v) := by
  have h := decoded_run select ss g (decode select g v)
  rw [encode_decode] at h
  exact h

theorem decoded_run_pointwise (select : Nat → ExactFrame X F) (ss : List PairedWord.Step)
    (g : GaugeKeyTrace.State) (v : Arrays X F) (r : Nat) (x : X) :
    decode select (GaugeKeyTrace.run ss g) (ExactTransportTrace.run select ss g (encode select g v)).2 r x=
      FieldWordTrace.run ss (fun j => v j x) r := by
  rw [decoded_run,logical_pointwise]

end FrameLogicalWord
#print axioms FrameLogicalWord.logical_pointwise
#print axioms FrameLogicalWord.logical_as_field_run
#print axioms FrameLogicalWord.run_correct
#print axioms FrameLogicalWord.run_correct_pointwise
#print axioms FrameLogicalWord.decoded_run
#print axioms FrameLogicalWord.arbitrary_entrance
#print axioms FrameLogicalWord.decoded_run_pointwise
