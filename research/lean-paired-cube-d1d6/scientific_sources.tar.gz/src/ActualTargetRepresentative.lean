import CoordinateRepresentative
namespace ActualTargetRepresentative
open BinarySpace24 BinaryCompletion EndpointBinding CoordinateRepresentative Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def indices : List Index := (List.finRange 24).take 23

theorem indices_nodup : indices.Nodup := by decide

theorem index_membership (j : Index) : j ∈ indices ↔ j≠23 := by
  have h : (List.finRange 24).all (fun k => decide (k ∈ indices ↔ k≠23))=true := by decide
  exact of_decide_eq_true (List.all_eq_true.mp h j (List.mem_ofFn.mpr ⟨j,rfl⟩))

theorem space_hyperplane (x : Vec) : CoordinateWordFrames.Space indices x ↔ x 23=false := by
  constructor
  · intro h
    exact h 23 (by decide)
  · intro h j hj
    by_cases he : j=23
    · simpa only [he] using h
    · exact False.elim (hj ((index_membership j).mpr he))

theorem image_hyperplane (y : Vec) : Image targetChart.forward (CoordinateWordFrames.Space indices) y ↔ dot SourceLineCase.q y=false := by
  constructor
  · rintro ⟨x,hx,rfl⟩
    rw [target_dual]
    exact (space_hyperplane x).mp hx
  · intro hy
    rcases (target_image y).mpr hy with ⟨x,hx,he⟩
    exact ⟨x,(space_hyperplane x).mpr hx,he⟩

def chosen (i : F) := representative i targetChart indices
def chosenInverse (i : F) := inverseRepresentative i targetChart indices

theorem chosen_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    chosenInverse i (chosen i f)=f ∧ chosen i (chosenInverse i f)=f :=
  ⟨inverse_left i hi htwo _ _ f,inverse_right i hi htwo _ _ f⟩

theorem chosen_Pauli (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (v : Vec × Vec) (f : Vec → F) :
    chosen i (ExactQuadraticLift.pauli v.1 v.2 (chosenInverse i f))=fun x => exactPhase i targetChart indices v*
      ExactQuadraticLift.pauli (label targetChart indices v).1 (label targetChart indices v).2 f x :=
  pauli_conjugation i hi htwo _ _ v f

theorem chosen_frame_preimage (v : Vec × Vec) :
    (label targetChart indices v).1=zero ↔ Frame (fun u => dot SourceLineCase.q u=false) v := by
  rw [frame_preimage targetChart indices indices_nodup]
  exact ActualFrameAdapter.frame_ext _ _ image_hyperplane v

theorem chosen_phase_fourth (i : F) (hi : i*i= -1) (v : Vec × Vec) :
    (exactPhase i targetChart indices v*exactPhase i targetChart indices v)*
      (exactPhase i targetChart indices v*exactPhase i targetChart indices v)=1 :=
  exact_phase_fourth i hi _ _ v

end ActualTargetRepresentative
#print axioms ActualTargetRepresentative.indices_nodup
#print axioms ActualTargetRepresentative.index_membership
#print axioms ActualTargetRepresentative.space_hyperplane
#print axioms ActualTargetRepresentative.image_hyperplane
#print axioms ActualTargetRepresentative.chosen_inverses
#print axioms ActualTargetRepresentative.chosen_Pauli
#print axioms ActualTargetRepresentative.chosen_frame_preimage
#print axioms ActualTargetRepresentative.chosen_phase_fourth
