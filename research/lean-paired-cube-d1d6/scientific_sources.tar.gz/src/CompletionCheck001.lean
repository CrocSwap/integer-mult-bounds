import CompletionData
namespace CompletionCheck001
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch001.all CompletionCertificates.check=true := by decide
end CompletionCheck001
#print axioms CompletionCheck001.valid
