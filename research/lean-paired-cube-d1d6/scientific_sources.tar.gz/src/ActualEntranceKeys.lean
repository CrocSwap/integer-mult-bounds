import EntranceChunk000
import EntranceChunk001
import EntranceChunk002
import EntranceChunk003
import EntranceChunk004
import EntranceChunk005
import EntranceChunk006
import EntranceChunk007
import EntranceChunk008
import EntranceChunk009
import EntranceChunk010
import EntranceChunk011
import EntranceChunk012
import EntranceChunk013
import EntranceChunk014
import EntranceChunk015
import EntranceChunk016
import EntranceChunk017
import EntranceChunk018
import EntranceChunk019
import EntranceChunk020
import EntranceChunk021
import EntranceChunk022
import EntranceChunk023
import EntranceChunk024
import EntranceChunk025
import EntranceChunk026
import EntranceChunk027
import EntranceChunk028
import EntranceChunk029
import EntranceChunk030
import EntranceChunk031
import EntranceChunk032
import EntranceChunk033
import EntranceChunk034
import EntranceChunk035
import EntranceChunk036
import EntranceChunk037
import EntranceChunk038
import EntranceChunk039
import EntranceChunk040
import EntranceChunk041
import EntranceChunk042
import EntranceChunk043
import EntranceChunk044
import EntranceChunk045
import EntranceChunk046
import EntranceChunk047
import EntranceChunk048
import EntranceChunk049
import EntranceChunk050
import EntranceChunk051
import EntranceChunk052
import EntranceChunk053
import EntranceChunk054
import EntranceChunk055
import EntranceChunk056
import EntranceChunk057
import EntranceChunk058
import EntranceChunk059
import EntranceChunk060
import EntranceChunk061
import EntranceChunk062
import EntranceChunk063
import EntranceChunk064
import EntranceChunk065
import EntranceChunk066
import EntranceChunk067
import EntranceChunk068
import EntranceChunk069
import EntranceChunk070
import EntranceChunk071
import EntranceChunk072
import EntranceChunk073
import EntranceChunk074
import EntranceChunk075
import EntranceChunk076
import EntranceChunk077
import EntranceChunk078
import EntranceChunk079
import EntranceChunk080
import EntranceChunk081
import EntranceChunk082
import EntranceChunk083
import EntranceChunk084
import EntranceChunk085
import EntranceChunk086
import EntranceChunk087
import EntranceChunk088
import EntranceChunk089
import EntranceChunk090
import EntranceChunk091
import EntranceChunk092
import EntranceChunk093
import EntranceChunk094
import EntranceChunk095
import EntranceChunk096
import EntranceChunk097
import EntranceChunk098
import EntranceChunk099
import EntranceChunk100
import EntranceChunk101
import EntranceChunk102
import EntranceChunk103
namespace ActualEntranceKeys
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000
def chunks : List (List Nat) := [EntranceChunk000.keys, EntranceChunk001.keys, EntranceChunk002.keys, EntranceChunk003.keys, EntranceChunk004.keys, EntranceChunk005.keys, EntranceChunk006.keys, EntranceChunk007.keys, EntranceChunk008.keys, EntranceChunk009.keys, EntranceChunk010.keys, EntranceChunk011.keys, EntranceChunk012.keys, EntranceChunk013.keys, EntranceChunk014.keys, EntranceChunk015.keys, EntranceChunk016.keys, EntranceChunk017.keys, EntranceChunk018.keys, EntranceChunk019.keys, EntranceChunk020.keys, EntranceChunk021.keys, EntranceChunk022.keys, EntranceChunk023.keys, EntranceChunk024.keys, EntranceChunk025.keys, EntranceChunk026.keys, EntranceChunk027.keys, EntranceChunk028.keys, EntranceChunk029.keys, EntranceChunk030.keys, EntranceChunk031.keys, EntranceChunk032.keys, EntranceChunk033.keys, EntranceChunk034.keys, EntranceChunk035.keys, EntranceChunk036.keys, EntranceChunk037.keys, EntranceChunk038.keys, EntranceChunk039.keys, EntranceChunk040.keys, EntranceChunk041.keys, EntranceChunk042.keys, EntranceChunk043.keys, EntranceChunk044.keys, EntranceChunk045.keys, EntranceChunk046.keys, EntranceChunk047.keys, EntranceChunk048.keys, EntranceChunk049.keys, EntranceChunk050.keys, EntranceChunk051.keys, EntranceChunk052.keys, EntranceChunk053.keys, EntranceChunk054.keys, EntranceChunk055.keys, EntranceChunk056.keys, EntranceChunk057.keys, EntranceChunk058.keys, EntranceChunk059.keys, EntranceChunk060.keys, EntranceChunk061.keys, EntranceChunk062.keys, EntranceChunk063.keys, EntranceChunk064.keys, EntranceChunk065.keys, EntranceChunk066.keys, EntranceChunk067.keys, EntranceChunk068.keys, EntranceChunk069.keys, EntranceChunk070.keys, EntranceChunk071.keys, EntranceChunk072.keys, EntranceChunk073.keys, EntranceChunk074.keys, EntranceChunk075.keys, EntranceChunk076.keys, EntranceChunk077.keys, EntranceChunk078.keys, EntranceChunk079.keys, EntranceChunk080.keys, EntranceChunk081.keys, EntranceChunk082.keys, EntranceChunk083.keys, EntranceChunk084.keys, EntranceChunk085.keys, EntranceChunk086.keys, EntranceChunk087.keys, EntranceChunk088.keys, EntranceChunk089.keys, EntranceChunk090.keys, EntranceChunk091.keys, EntranceChunk092.keys, EntranceChunk093.keys, EntranceChunk094.keys, EntranceChunk095.keys, EntranceChunk096.keys, EntranceChunk097.keys, EntranceChunk098.keys, EntranceChunk099.keys, EntranceChunk100.keys, EntranceChunk101.keys, EntranceChunk102.keys, EntranceChunk103.keys]
def keys := chunks.flatten
def key (r : Nat) : Nat := keys[r]?.getD 0

theorem all_bounded : keys.all (fun k => decide (k≤1980))=true := by
  simp only [keys,chunks,List.all_flatten,List.all_cons,List.all_nil,EntranceChunk000.bounded,EntranceChunk001.bounded,EntranceChunk002.bounded,EntranceChunk003.bounded,EntranceChunk004.bounded,EntranceChunk005.bounded,EntranceChunk006.bounded,EntranceChunk007.bounded,EntranceChunk008.bounded,EntranceChunk009.bounded,EntranceChunk010.bounded,EntranceChunk011.bounded,EntranceChunk012.bounded,EntranceChunk013.bounded,EntranceChunk014.bounded,EntranceChunk015.bounded,EntranceChunk016.bounded,EntranceChunk017.bounded,EntranceChunk018.bounded,EntranceChunk019.bounded,EntranceChunk020.bounded,EntranceChunk021.bounded,EntranceChunk022.bounded,EntranceChunk023.bounded,EntranceChunk024.bounded,EntranceChunk025.bounded,EntranceChunk026.bounded,EntranceChunk027.bounded,EntranceChunk028.bounded,EntranceChunk029.bounded,EntranceChunk030.bounded,EntranceChunk031.bounded,EntranceChunk032.bounded,EntranceChunk033.bounded,EntranceChunk034.bounded,EntranceChunk035.bounded,EntranceChunk036.bounded,EntranceChunk037.bounded,EntranceChunk038.bounded,EntranceChunk039.bounded,EntranceChunk040.bounded,EntranceChunk041.bounded,EntranceChunk042.bounded,EntranceChunk043.bounded,EntranceChunk044.bounded,EntranceChunk045.bounded,EntranceChunk046.bounded,EntranceChunk047.bounded,EntranceChunk048.bounded,EntranceChunk049.bounded,EntranceChunk050.bounded,EntranceChunk051.bounded,EntranceChunk052.bounded,EntranceChunk053.bounded,EntranceChunk054.bounded,EntranceChunk055.bounded,EntranceChunk056.bounded,EntranceChunk057.bounded,EntranceChunk058.bounded,EntranceChunk059.bounded,EntranceChunk060.bounded,EntranceChunk061.bounded,EntranceChunk062.bounded,EntranceChunk063.bounded,EntranceChunk064.bounded,EntranceChunk065.bounded,EntranceChunk066.bounded,EntranceChunk067.bounded,EntranceChunk068.bounded,EntranceChunk069.bounded,EntranceChunk070.bounded,EntranceChunk071.bounded,EntranceChunk072.bounded,EntranceChunk073.bounded,EntranceChunk074.bounded,EntranceChunk075.bounded,EntranceChunk076.bounded,EntranceChunk077.bounded,EntranceChunk078.bounded,EntranceChunk079.bounded,EntranceChunk080.bounded,EntranceChunk081.bounded,EntranceChunk082.bounded,EntranceChunk083.bounded,EntranceChunk084.bounded,EntranceChunk085.bounded,EntranceChunk086.bounded,EntranceChunk087.bounded,EntranceChunk088.bounded,EntranceChunk089.bounded,EntranceChunk090.bounded,EntranceChunk091.bounded,EntranceChunk092.bounded,EntranceChunk093.bounded,EntranceChunk094.bounded,EntranceChunk095.bounded,EntranceChunk096.bounded,EntranceChunk097.bounded,EntranceChunk098.bounded,EntranceChunk099.bounded,EntranceChunk100.bounded,EntranceChunk101.bounded,EntranceChunk102.bounded,EntranceChunk103.bounded,Bool.true_and]

theorem count : keys.length=26417 := by
  simp only [keys,chunks,List.length_flatten,List.map_cons,List.map_nil,List.sum_cons,List.sum_nil,EntranceChunk000.count,EntranceChunk001.count,EntranceChunk002.count,EntranceChunk003.count,EntranceChunk004.count,EntranceChunk005.count,EntranceChunk006.count,EntranceChunk007.count,EntranceChunk008.count,EntranceChunk009.count,EntranceChunk010.count,EntranceChunk011.count,EntranceChunk012.count,EntranceChunk013.count,EntranceChunk014.count,EntranceChunk015.count,EntranceChunk016.count,EntranceChunk017.count,EntranceChunk018.count,EntranceChunk019.count,EntranceChunk020.count,EntranceChunk021.count,EntranceChunk022.count,EntranceChunk023.count,EntranceChunk024.count,EntranceChunk025.count,EntranceChunk026.count,EntranceChunk027.count,EntranceChunk028.count,EntranceChunk029.count,EntranceChunk030.count,EntranceChunk031.count,EntranceChunk032.count,EntranceChunk033.count,EntranceChunk034.count,EntranceChunk035.count,EntranceChunk036.count,EntranceChunk037.count,EntranceChunk038.count,EntranceChunk039.count,EntranceChunk040.count,EntranceChunk041.count,EntranceChunk042.count,EntranceChunk043.count,EntranceChunk044.count,EntranceChunk045.count,EntranceChunk046.count,EntranceChunk047.count,EntranceChunk048.count,EntranceChunk049.count,EntranceChunk050.count,EntranceChunk051.count,EntranceChunk052.count,EntranceChunk053.count,EntranceChunk054.count,EntranceChunk055.count,EntranceChunk056.count,EntranceChunk057.count,EntranceChunk058.count,EntranceChunk059.count,EntranceChunk060.count,EntranceChunk061.count,EntranceChunk062.count,EntranceChunk063.count,EntranceChunk064.count,EntranceChunk065.count,EntranceChunk066.count,EntranceChunk067.count,EntranceChunk068.count,EntranceChunk069.count,EntranceChunk070.count,EntranceChunk071.count,EntranceChunk072.count,EntranceChunk073.count,EntranceChunk074.count,EntranceChunk075.count,EntranceChunk076.count,EntranceChunk077.count,EntranceChunk078.count,EntranceChunk079.count,EntranceChunk080.count,EntranceChunk081.count,EntranceChunk082.count,EntranceChunk083.count,EntranceChunk084.count,EntranceChunk085.count,EntranceChunk086.count,EntranceChunk087.count,EntranceChunk088.count,EntranceChunk089.count,EntranceChunk090.count,EntranceChunk091.count,EntranceChunk092.count,EntranceChunk093.count,EntranceChunk094.count,EntranceChunk095.count,EntranceChunk096.count,EntranceChunk097.count,EntranceChunk098.count,EntranceChunk099.count,EntranceChunk100.count,EntranceChunk101.count,EntranceChunk102.count,EntranceChunk103.count]
  rfl

theorem key_bounded (r : Nat) : key r≤1980 := by
  unfold key
  cases h : keys[r]? with
  | none => simp only [Option.getD_none]; decide
  | some k =>
    simp only [Option.getD_some]
    exact of_decide_eq_true (List.all_eq_true.mp all_bounded k (List.mem_of_getElem? h))

theorem zero_role : key 0=1 := rfl

theorem three_role : key 3=2 := rfl

theorem outside_roles (r : Nat) (hr : 26417≤r) : key r=0 := by
  unfold key
  have hn : keys[r]?=none := List.getElem?_eq_none (by rw [count]; exact hr)
  rw [hn]
  rfl

end ActualEntranceKeys
#print axioms ActualEntranceKeys.all_bounded
#print axioms ActualEntranceKeys.count
#print axioms ActualEntranceKeys.key_bounded
#print axioms ActualEntranceKeys.zero_role
#print axioms ActualEntranceKeys.three_role
#print axioms ActualEntranceKeys.outside_roles
