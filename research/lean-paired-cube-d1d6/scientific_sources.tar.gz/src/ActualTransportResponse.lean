import FiniteWordTransport
import ActualFieldExecution
namespace ActualTransportResponse
open BinarySpace24 CommonExactFrame ExactTransportTrace FiniteWordTransport Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def inject (payload : Arrays Vec F) : Arrays Vec F :=
  fun r x => FieldWordTrace.inject (fun j => payload j x) r

theorem injection_pointwise (payload : Arrays Vec F) (x : Vec) :
    (fun r => inject payload r x)=FieldWordTrace.inject (fun j => payload j x) := rfl

theorem actual_scaled_response (select : Nat → ExactFrame Vec F) (g : GaugeKeyTrace.State)
    (payload : Arrays Vec F) (target : Nat) (ht : target<1760) (x : Vec) :
    ActualFieldExecution.decoderResponse target (decodedState select g (inject payload) x)+
      ActualFieldExecution.correctionResponse target (fun j => payload j x)=(6:F)*payload target x := by
  rw [decoded_state_eq,injection_pointwise]
  exact ActualFieldExecution.actual_scaled_execution target ht (fun j => payload j x)

theorem actual_normalized_response (select : Nat → ExactFrame Vec F) (g : GaugeKeyTrace.State)
    (payload : Arrays Vec F) (target : Nat) (ht : target<1760) (x : Vec) (hsix : (6:F)≠0) :
    ActualFieldExecution.decoderResponse target (decodedState select g (inject payload) x)/6+
      ActualFieldExecution.correctionResponse target (fun j => payload j x)/6=payload target x := by
  rw [decoded_state_eq,injection_pointwise]
  exact ActualFieldExecution.actual_normalized_execution target ht (fun j => payload j x) hsix

end ActualTransportResponse
#print axioms ActualTransportResponse.injection_pointwise
#print axioms ActualTransportResponse.actual_scaled_response
#print axioms ActualTransportResponse.actual_normalized_response
