import FrameIndependence
namespace CarrierCoordinates
open BinaryFrame
abbrev Coordinates := Bool × Bool × Bool

def zero : Coordinates := (false,false,false)
def add (c d : Coordinates) : Coordinates :=
  (c.1 ^^ d.1,c.2.1 ^^ d.2.1,c.2.2 ^^ d.2.2)
def coefficients (c : Coordinates) : List Bool := [c.1,c.2.1,c.2.2]
def chart (q0 q1 q2 : Nat) (c : Coordinates) : Nat :=
  (if c.1 then q0 else 0) ^^^ ((if c.2.1 then q1 else 0) ^^^ (if c.2.2 then q2 else 0))

theorem combination_chart (q0 q1 q2 : Nat) (c : Coordinates) :
    combination [q0,q1,q2] (coefficients c) = chart q0 q1 q2 c := by
  simp [combination,coefficients,chart]

theorem select_xor (q : Nat) (c d : Bool) :
    (if c ^^ d then q else 0) = (if c then q else 0) ^^^ (if d then q else 0) := by
  cases c <;> cases d <;> simp

theorem chart_add (q0 q1 q2 : Nat) (c d : Coordinates) :
    chart q0 q1 q2 (add c d) = chart q0 q1 q2 c ^^^ chart q0 q1 q2 d := by
  simp only [chart,add,select_xor]
  ac_rfl

theorem chart_zero (q0 q1 q2 : Nat) : chart q0 q1 q2 zero = 0 := by
  simp [chart,zero]

theorem chart_mem (q0 q1 q2 : Nat) (c : Coordinates) :
    Span [q0,q1,q2] (chart q0 q1 q2 c) := by
  unfold chart
  apply Span.add
  · split
    · exact Span.generator (by simp)
    · exact Span.zero
  · apply Span.add
    · split
      · exact Span.generator (by simp)
      · exact Span.zero
    · split
      · exact Span.generator (by simp)
      · exact Span.zero

theorem chart_surjective (q0 q1 q2 : Nat) (x : Nat) (hx : Span [q0,q1,q2] x) :
    ∃ c, chart q0 q1 q2 c=x := by
  induction hx with
  | zero => exact ⟨zero,chart_zero q0 q1 q2⟩
  | generator h =>
    simp [List.mem_cons,List.mem_singleton] at h
    rcases h with h | h | h
    · exact ⟨(true,false,false),by simpa [chart] using h.symm⟩
    · exact ⟨(false,true,false),by simpa [chart] using h.symm⟩
    · exact ⟨(false,false,true),by simpa [chart] using h.symm⟩
  | add hx hy ihx ihy =>
    rcases ihx with ⟨c,hc⟩
    rcases ihy with ⟨d,hd⟩
    exact ⟨add c d, by rw [chart_add,hc,hd]⟩

theorem chart_injective (q0 q1 q2 : Nat) (hi : Independent [q0,q1,q2])
    (c d : Coordinates) (h : chart q0 q1 q2 c=chart q0 q1 q2 d) : c=d := by
  have hz : combination [q0,q1,q2] (coefficients (add c d))=0 := by
    rw [combination_chart,chart_add,h,Nat.xor_self]
  have he := hi (coefficients (add c d)) (by rfl) hz
  rcases c with ⟨c0,c1,c2⟩
  rcases d with ⟨d0,d1,d2⟩
  cases c0 <;> cases c1 <;> cases c2 <;> cases d0 <;> cases d1 <;> cases d2 <;>
    simp_all [coefficients,add]

def allCoordinates : List Coordinates :=
  [(false,false,false),(false,false,true),(false,true,false),(false,true,true),
   (true,false,false),(true,false,true),(true,true,false),(true,true,true)]

theorem all_coordinates (c : Coordinates) : c ∈ allCoordinates := by
  rcases c with ⟨c0,c1,c2⟩
  cases c0 <;> cases c1 <;> cases c2 <;> decide

theorem coordinates_count : allCoordinates.length=8 ∧ allCoordinates.Nodup := by decide

end CarrierCoordinates
#print axioms CarrierCoordinates.combination_chart
#print axioms CarrierCoordinates.select_xor
#print axioms CarrierCoordinates.chart_add
#print axioms CarrierCoordinates.chart_zero
#print axioms CarrierCoordinates.chart_mem
#print axioms CarrierCoordinates.chart_surjective
#print axioms CarrierCoordinates.chart_injective
#print axioms CarrierCoordinates.all_coordinates
#print axioms CarrierCoordinates.coordinates_count
