import CatalogSelector
namespace CatalogKeySelector
open BinarySpace24 BinaryCompletion VariableCertificates CatalogSpanBridge CatalogSelector Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def InRange (n k : Nat) := 1≤k ∧ k≤n

theorem witness_exists (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n)
    (k : Nat) (hk : InRange n k) : ∃c, c ∈ cs ∧ c.key=k := by
  have hm : k ∈ cs.map Witness.key := by
    rw [hr,List.mem_range']
    rcases hk with ⟨h1,h2⟩
    refine ⟨k-1,?_,?_⟩
    · omega
    · simp only [Nat.one_mul]
      omega
  exact List.mem_map.mp hm

noncomputable def witness (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n)
    (k : Nat) (hk : InRange n k) := Classical.choose (witness_exists cs n hr k hk)

theorem witness_properties (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n)
    (hv : cs.all check=true) (k : Nat) (hk : InRange n k) :
    witness cs n hr k hk ∈ cs ∧ (witness cs n hr k hk).key=k ∧ check (witness cs n hr k hk)=true := by
  have h := Classical.choose_spec (witness_exists cs n hr k hk)
  exact ⟨h.1,h.2,List.all_eq_true.mp hv _ h.1⟩

noncomputable def representative (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n) (hv : cs.all check=true)
    (k : Nat) (hk : InRange n k) :=
  catalog i hi htwo cs hv (Span (witness cs n hr k hk))
    (Or.inr ⟨witness cs n hr k hk,(witness_properties cs n hr hv k hk).1,rfl⟩)

theorem inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n) (hv : cs.all check=true)
    (k : Nat) (hk : InRange n k) (f : Vec → F) :
    let r := representative i hi htwo cs n hr hv k hk
    r.decode (r.encode f)=f ∧ r.encode (r.decode f)=f :=
  all_inverses i hi htwo cs hv _ _ f

theorem preimage (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n) (hv : cs.all check=true)
    (k : Nat) (hk : InRange n k) (v : Vec × Vec) :
    ((representative i hi htwo cs n hr hv k hk).label v).1=zero ↔ Frame (Span (witness cs n hr k hk)) v :=
  all_preimages i hi htwo cs hv _ _ v

theorem exact_Pauli (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n) (hv : cs.all check=true)
    (k : Nat) (hk : InRange n k) (v : Vec × Vec) (f : Vec → F) :
    let r := representative i hi htwo cs n hr hv k hk
    r.encode (ExactQuadraticLift.pauli v.1 v.2 (r.decode f))=fun x => r.phase v*ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 f x :=
  all_exact_Pauli i hi htwo cs hv _ _ v f

theorem same_key_same_operator (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (cs : List Witness) (n : Nat) (hr : cs.map Witness.key=List.range' 1 n) (hv : cs.all check=true)
    (k l : Nat) (hk : InRange n k) (hl : InRange n l) (h : k=l) :
    (representative i hi htwo cs n hr hv k hk).encode=(representative i hi htwo cs n hr hv l hl).encode := by
  cases h
  rfl

end CatalogKeySelector
#print axioms CatalogKeySelector.witness_exists
#print axioms CatalogKeySelector.witness_properties
#print axioms CatalogKeySelector.inverses
#print axioms CatalogKeySelector.preimage
#print axioms CatalogKeySelector.exact_Pauli
#print axioms CatalogKeySelector.same_key_same_operator
