import RightPassAddressPhase
namespace ActualRootOneChildProgram
open BinarySpace24 RootFactorRawData Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def lowered (i : F) (f : Vec → F) :=
  LeftPassAddressPhase.program i (CoordinateChild.gate i 21 (RightPassAddressPhase.program i f))
def inverseLowered (i : F) (f : Vec → F) :=
  RightPassAddressPhase.inverseProgram i (CoordinateChild.undoGate i 21 (LeftPassInverseProgram.inverseProgram i f))

theorem selected_forward (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (selectedOutgoing i hi htwo).encode ((selectedIncoming i hi htwo).decode f)=lowered i f := by
  rw [ActualRootLeftLowering.selected_forward,RightPassAddressPhase.exact_program]
  rfl

theorem selected_inverse (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (selectedIncoming i hi htwo).encode ((selectedOutgoing i hi htwo).decode f)=inverseLowered i f := by
  rw [ActualRootLeftLowering.selected_inverse,RightPassAddressPhase.exact_inverse_program]
  rfl

theorem actual_event (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (g : GaugeKeyTrace.State) (f : Vec → F) :
    CommonExactFrame.adapter (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 3 g 17326))
      (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 4 g 17326)) f=lowered i f := by
  rw [ActualRootLeftLowering.actual_event,RightPassAddressPhase.exact_program]
  rfl

theorem inverse_left (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    inverseLowered i (lowered i f)=f := by
  unfold inverseLowered lowered
  rw [LeftPassInverseProgram.program_inverse_left i hi,CoordinateChild.gate_inverse_left i hi htwo,
    RightPassAddressPhase.program_inverse_left i hi]

theorem inverse_right (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    lowered i (inverseLowered i f)=f := by
  unfold inverseLowered lowered
  rw [RightPassAddressPhase.program_inverse_right i hi,CoordinateChild.gate_inverse_right i hi htwo,
    LeftPassInverseProgram.program_inverse_right i hi]

end ActualRootOneChildProgram
#print axioms ActualRootOneChildProgram.selected_forward
#print axioms ActualRootOneChildProgram.selected_inverse
#print axioms ActualRootOneChildProgram.actual_event
#print axioms ActualRootOneChildProgram.inverse_left
#print axioms ActualRootOneChildProgram.inverse_right
