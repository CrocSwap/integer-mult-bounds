import Lean
namespace EntranceChunk103
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000
def keys : List Nat := [1934, 1935, 1935, 1935, 1936, 1936, 1936, 1937, 1937, 1937, 1938, 1938, 1938, 1939, 1939, 1939, 1940, 1940, 1940, 1931, 1931, 1931, 1932, 1932, 1932, 1933, 1933, 1933, 1934, 1934, 1934, 1935, 1935, 1935, 1936, 1936, 1936, 1937, 1937, 1937, 1938, 1938, 1938, 1939, 1939, 1939, 1940, 1940, 1940]
theorem bounded : keys.all (fun k => decide (k≤1980))=true := by decide
theorem count : keys.length=49 := rfl
end EntranceChunk103
#print axioms EntranceChunk103.bounded
#print axioms EntranceChunk103.count
