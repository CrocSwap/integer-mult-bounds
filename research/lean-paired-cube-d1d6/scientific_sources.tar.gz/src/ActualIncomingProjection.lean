import ExactTransportTrace
import PrefixGaugeEventLink
namespace ActualIncomingProjection
open GaugeKeyTrace ActualPrefixGauge CommonExactFrame Lean.Grind
variable {X : Type u} {F : Type v} [Field F]

theorem never_destination (r : Nat) (ss : List PairedWord.Step)
    (h : (ss.filter (touches r)).all (fun s => decide (s.dst≠r))=true)
    (s : PairedWord.Step) (hs : s ∈ ss) : s.dst≠r := by
  intro hd
  have ht : touches r s=true := by
    simp only [touches,← hd,decide_true,Bool.true_or]
  have hm := List.mem_filter.mpr ⟨hs,ht⟩
  have hn : s.dst≠r := of_decide_eq_true (List.all_eq_true.mp h s hm)
  exact hn hd

theorem zero_never_destination (s : PairedWord.Step) (hs : s ∈ initialSteps) : s.dst≠0 := by
  apply never_destination 0 initialSteps _ s hs
  rw [zero_touches]
  decide

theorem three_never_destination (s : PairedWord.Step) (hs : s ∈ initialSteps) : s.dst≠3 := by
  apply never_destination 3 initialSteps _ s hs
  rw [three_touches]
  decide

theorem stable_zero : initialSteps.all (ExactTransportTrace.stable 0 1)=true := by
  apply List.all_eq_true.mpr
  intro s hs
  apply Bool.and_eq_true_iff.mpr
  exact ⟨(Bool.and_eq_true_iff.mp (List.all_eq_true.mp prefix_checked s hs)).1,
    decide_eq_true (zero_never_destination s hs)⟩

theorem stable_three : initialSteps.all (ExactTransportTrace.stable 3 2)=true := by
  apply List.all_eq_true.mpr
  intro s hs
  apply Bool.and_eq_true_iff.mpr
  exact ⟨(Bool.and_eq_true_iff.mp (List.all_eq_true.mp prefix_checked s hs)).2,
    decide_eq_true (three_never_destination s hs)⟩

theorem actual_projections (select : Nat → ExactFrame X F) (g : State) (h0 : g 0=1) (h3 : g 3=2)
    (v : ExactTransportTrace.Arrays X F) :
    (ExactTransportTrace.run select (PairedWordData.word.take 3520) g v).1 0=1 ∧
    (ExactTransportTrace.run select (PairedWordData.word.take 3520) g v).1 3=2 ∧
    (ExactTransportTrace.run select (PairedWordData.word.take 3520) g v).2 0=v 0 ∧
    (ExactTransportTrace.run select (PairedWordData.word.take 3520) g v).2 3=v 3 := by
  rw [actual_prefix]
  have ha := ExactTransportTrace.projection_unchanged select 0 1 initialSteps stable_zero g h0 v
  have hb := ExactTransportTrace.projection_unchanged select 3 2 initialSteps stable_three g h3 v
  exact ⟨ha.1,hb.1,ha.2,hb.2⟩

end ActualIncomingProjection
#print axioms ActualIncomingProjection.never_destination
#print axioms ActualIncomingProjection.zero_never_destination
#print axioms ActualIncomingProjection.three_never_destination
#print axioms ActualIncomingProjection.stable_zero
#print axioms ActualIncomingProjection.stable_three
#print axioms ActualIncomingProjection.actual_projections
