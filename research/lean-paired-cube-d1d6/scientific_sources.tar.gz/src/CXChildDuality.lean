import CXLiftFormula
namespace CXChildDuality
open BinarySpace24 FourthRootRecipe CanonicalFourthRootLift ChartComposition Q21AddressProgram CoordinateChild CXLiftFormula GaussianGate Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
set_option maxHeartbeats 4000000

theorem reverse_address (c t : Index) (h : c≠t) (x : Vec) :
    execute ⟨t,c⟩ x=(if x c then flip t else id) ((if x t then flip c else id) (execute ⟨c,t⟩ x)) := by
  cases hx : x c <;> cases hy : x t <;>
    simp only [hx,hy,Bool.false_eq_true,if_false,if_true,id_eq]
  all_goals
    funext j
    simp only [execute,CoordinateChild.flip,add,BinarySpace24.scale,hx,hy,Bool.false_and,Bool.true_and,
      Bool.xor_false,Bool.false_xor,Bool.xor_assoc,Bool.xor_self,Bool.xor_left_comm,Bool.xor_comm]

theorem local_duality (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c t : Index) (h : c≠t) (f : Vec → F) :
    gate i c (gate i t (localLift i c t (undoGate i t (undoGate i c f))))=
      localLift (-i) t c f := by
  funext x
  have hinv := inverse_coefficients i
  have hcoef := coefficient_square i hi htwo
  have hp := phase_coefficients i hi
  have hct : t≠c := Ne.symm h
  simp only [gate,undoGate,InvolutionGate.inverse,InvolutionGate.gate,localLift,localPhase,
    hinv.1,hinv.2,Ring.neg_neg,execute_flip_control c t h,execute_flip_target c t h,
    flip_here,flip_other c t h,flip_other t c hct,
    flip_commute c t,flip_twice,reverse_address c t h]
  cases hc : x c <;> cases ht : x t <;>
    simp only [hc,ht,rootPhase,Bool.false_eq_true,if_false,if_true,id_eq,
      Bool.false_xor,Bool.true_xor,Bool.xor_false,Bool.xor_true,Bool.not_true,Bool.not_false,
      flip_commute c t,flip_twice] <;> grind

end CXChildDuality
#print axioms CXChildDuality.reverse_address
#print axioms CXChildDuality.local_duality
