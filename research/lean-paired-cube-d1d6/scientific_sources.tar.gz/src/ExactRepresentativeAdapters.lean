import NestedCoordinateTransition
namespace ExactRepresentativeAdapters
open BinarySpace24 CertifiedRepresentative CommonExactFrame Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem phase_nonzero {U : Vec → Prop} (r : Rep F U) (v : Vec × Vec) : r.phase v≠0 := by
  intro h
  have he := r.phase_fourth v
  rw [h] at he
  simp only [Semiring.zero_mul] at he
  exact Field.zero_ne_one he

theorem encode_injective {U : Vec → Prop} (r : Rep F U) (f g : Vec → F) (h : r.encode f=r.encode g) : f=g := by
  have he := congrArg r.decode h
  simpa only [r.left_inverse] using he

theorem decode_pullthrough {U : Vec → Prop} (r : Rep F U) (v : Vec × Vec) (f : Vec → F) :
    r.decode (ExactQuadraticLift.pauli v.1 v.2 f)=fun x => (r.phase (r.label v))⁻¹*
      ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 (r.decode f) x := by
  apply encode_injective r
  rw [r.right_inverse,r.scale_linear,r.pullthrough,r.label_involution,r.right_inverse]
  funext x
  have h := Field.inv_mul_cancel (phase_nonzero r (r.label v))
  grind

def label {U V : Vec → Prop} (A : Rep F U) (B : Rep F V) (v : Vec × Vec) := B.label (A.label v)
def phase {U V : Vec → Prop} (A : Rep F U) (B : Rep F V) (v : Vec × Vec) :=
  (A.phase (A.label v))⁻¹*B.phase (A.label v)

theorem exact_Pauli {U V : Vec → Prop} (A : Rep F U) (B : Rep F V) (v : Vec × Vec) (f : Vec → F) :
    adapter A.toExactFrame B.toExactFrame (ExactQuadraticLift.pauli v.1 v.2
      (adapter B.toExactFrame A.toExactFrame f))=
      fun x => phase A B v*ExactQuadraticLift.pauli (label A B v).1 (label A B v).2 f x := by
  unfold adapter
  rw [decode_pullthrough,A.left_inverse,B.scale_linear,B.pullthrough,B.right_inverse]
  funext x
  simp only [phase,label,Semiring.mul_assoc]

theorem same_frame_preserves_zero_X {U V : Vec → Prop} (A : Rep F U) (B : Rep F V) (he : U=V)
    (v : Vec × Vec) (hv : v.1=zero) : (label A B v).1=zero :=
  NestedCoordinateTransition.same_preimage_adapter_label A B he v hv

end ExactRepresentativeAdapters
#print axioms ExactRepresentativeAdapters.phase_nonzero
#print axioms ExactRepresentativeAdapters.encode_injective
#print axioms ExactRepresentativeAdapters.decode_pullthrough
#print axioms ExactRepresentativeAdapters.exact_Pauli
#print axioms ExactRepresentativeAdapters.same_frame_preserves_zero_X
