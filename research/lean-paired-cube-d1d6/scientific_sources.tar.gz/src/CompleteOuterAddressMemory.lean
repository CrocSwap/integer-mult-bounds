import ActualPermutationSwaps
namespace CompleteOuterAddressMemory
open BinarySpace24 BinaryCompletion Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {V : Type u}

@[irreducible] def forwardPermutation (s : PairLoadStoreMachine.State Vec V) :=
  BitTranspositionProgram.program ActualPermutationSwaps.specs s
@[irreducible] def inversePermutation (s : PairLoadStoreMachine.State Vec V) :=
  BitTranspositionProgram.program ActualPermutationSwaps.specs.reverse s
@[irreducible] def leftCX (s : PairLoadStoreMachine.State Vec V) :=
  CountedCXProgram.program ActualOuterCXPrograms.leftCX s
@[irreducible] def rightCX (s : PairLoadStoreMachine.State Vec V) :=
  CountedCXProgram.program ActualOuterCXPrograms.rightCX s

theorem forward_memory (s : PairLoadStoreMachine.State Vec V) :
    (forwardPermutation s).1.memory=fun x=>s.memory (permute RootAddressInstructions.permutation x) := by
  rw [forwardPermutation,ActualPermutationSwaps.forward_memory]

theorem inverse_memory (s : PairLoadStoreMachine.State Vec V) :
    (inversePermutation s).1.memory=fun x=>s.memory (unpermute RootAddressInstructions.permutation x) := by
  rw [inversePermutation,ActualPermutationSwaps.inverse_memory]

theorem left_CX_memory (s : PairLoadStoreMachine.State Vec V) :
    (leftCX s).1.memory=fun x=>s.memory (Q21AddressProgram.run ActualOuterCXPrograms.leftCX x) := by
  rw [leftCX,ActualOuterCXPrograms.left_memory]

theorem right_CX_memory (s : PairLoadStoreMachine.State Vec V) :
    (rightCX s).1.memory=fun x=>s.memory (Q21AddressProgram.run ActualOuterCXPrograms.rightCX x) := by
  rw [rightCX,ActualOuterCXPrograms.right_memory]

theorem forward_cost (s : PairLoadStoreMachine.State Vec V) :
    (forwardPermutation s).2=⟨134217728,134217728,0⟩ := by rw [forwardPermutation,ActualPermutationSwaps.forward_receipt]

theorem inverse_cost (s : PairLoadStoreMachine.State Vec V) :
    (inversePermutation s).2=⟨134217728,134217728,0⟩ := by rw [inversePermutation,ActualPermutationSwaps.inverse_receipt]

theorem left_CX_cost (s : PairLoadStoreMachine.State Vec V) :
    (leftCX s).2=⟨83886080,83886080,41943040,83886080,0⟩ := by rw [leftCX,ActualOuterCXPrograms.left_cost]

theorem right_CX_cost (s : PairLoadStoreMachine.State Vec V) :
    (rightCX s).2=⟨83886080,83886080,41943040,83886080,0⟩ := by rw [rightCX,ActualOuterCXPrograms.right_cost]

end CompleteOuterAddressMemory
#print axioms CompleteOuterAddressMemory.forward_memory
#print axioms CompleteOuterAddressMemory.inverse_memory
#print axioms CompleteOuterAddressMemory.left_CX_memory
#print axioms CompleteOuterAddressMemory.right_CX_memory
#print axioms CompleteOuterAddressMemory.forward_cost
#print axioms CompleteOuterAddressMemory.inverse_cost
#print axioms CompleteOuterAddressMemory.left_CX_cost
#print axioms CompleteOuterAddressMemory.right_CX_cost
