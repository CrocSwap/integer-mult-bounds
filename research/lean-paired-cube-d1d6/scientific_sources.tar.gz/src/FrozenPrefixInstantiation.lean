import FrozenMSelector
import PrefixEventComposition
namespace FrozenPrefixInstantiation
open BinarySpace24 CommonExactFrame ExactTransportTrace Lean.Grind ProjectedEvent3520
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem local_compatibility (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) :
    Compatibility (FrozenMSelector.select i hi htwo) i hi htwo :=
  ⟨FrozenMSelector.operation_key i hi htwo 1 (by constructor <;> decide),
   FrozenMSelector.operation_key i hi htwo 2 (by constructor <;> decide),
   FrozenMSelector.operation_key i hi htwo 1981 (by constructor <;> decide)⟩

theorem actual_incoming_arrays (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (v : Arrays Vec F) :
    (ExactTransportTrace.run (FrozenMSelector.select i hi htwo) (PairedWordData.word.take 3520) ActualEntranceKeys.key v).1 0=1 ∧
    (ExactTransportTrace.run (FrozenMSelector.select i hi htwo) (PairedWordData.word.take 3520) ActualEntranceKeys.key v).1 3=2 ∧
    (ExactTransportTrace.run (FrozenMSelector.select i hi htwo) (PairedWordData.word.take 3520) ActualEntranceKeys.key v).2 0=v 0 ∧
    (ExactTransportTrace.run (FrozenMSelector.select i hi htwo) (PairedWordData.word.take 3520) ActualEntranceKeys.key v).2 3=v 3 :=
  ActualIncomingProjection.actual_projections (FrozenMSelector.select i hi htwo) ActualEntranceKeys.key
    ActualEntranceKeys.zero_role ActualEntranceKeys.three_role v

theorem actual_3521_projections (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (v : Arrays Vec F) (f h : Vec → F)
    (hv0 : v 0=(first i hi htwo).encode f) (hv3 : v 3=(second i hi htwo).encode h) :
    let t := ExactTransportTrace.run (FrozenMSelector.select i hi htwo) (PairedWordData.word.take 3521) ActualEntranceKeys.key v
    t.1 0=1981 ∧ t.1 3=1981 ∧
    t.2 0=(plane i hi htwo).encode (fun x => f x+h x) ∧ t.2 3=(plane i hi htwo).encode h :=
  PrefixEventComposition.actual_3521_projections (FrozenMSelector.select i hi htwo) i hi htwo
    (local_compatibility i hi htwo) ActualEntranceKeys.key ActualEntranceKeys.zero_role ActualEntranceKeys.three_role v f h hv0 hv3

end FrozenPrefixInstantiation
#print axioms FrozenPrefixInstantiation.local_compatibility
#print axioms FrozenPrefixInstantiation.actual_incoming_arrays
#print axioms FrozenPrefixInstantiation.actual_3521_projections
