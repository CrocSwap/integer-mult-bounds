import ActualEntranceKeys
import WordCatalogBounds
import GaugeKeyTrace
namespace EntranceDomain
open GaugeKeyTrace

def Covered (g : State) : Prop := ∀ r, g r≤17400

theorem entrance_covered : Covered ActualEntranceKeys.key := by
  intro r
  have h := ActualEntranceKeys.key_bounded r
  omega

theorem update_covered (s : PairedWord.Step) (hs : ActualFrameKeys.key s≤17400)
    (g : State) (hg : Covered g) : Covered (update s g) := by
  intro r
  unfold update
  split
  · exact hs
  · exact hg r

theorem run_covered (ss : List PairedWord.Step) (hs : ∀ s ∈ ss, ActualFrameKeys.key s≤17400)
    (g : State) (hg : Covered g) : Covered (run ss g) := by
  induction ss generalizing g with
  | nil => exact hg
  | cons s ss ih =>
    apply ih (fun t ht => hs t (by simp [ht])) (update s g)
    exact update_covered s (hs s (by simp)) g hg

theorem all_word_prefixes_covered (n : Nat) : Covered (run (PairedWordData.word.take n) ActualEntranceKeys.key) := by
  apply run_covered _ _ _ entrance_covered
  intro s hs
  exact (WordCatalogBounds.step_key_bounds s (List.mem_of_mem_take hs)).2

theorem whole_word_covered : Covered (run PairedWordData.word ActualEntranceKeys.key) :=
  run_covered _ (fun s hs => (WordCatalogBounds.step_key_bounds s hs).2) _ entrance_covered

theorem prefix_key_zero_or_positive (n r : Nat) :
    run (PairedWordData.word.take n) ActualEntranceKeys.key r=0 ∨
    (1≤run (PairedWordData.word.take n) ActualEntranceKeys.key r ∧
      run (PairedWordData.word.take n) ActualEntranceKeys.key r≤17400) := by
  have h := all_word_prefixes_covered n r
  omega

end EntranceDomain
#print axioms EntranceDomain.entrance_covered
#print axioms EntranceDomain.update_covered
#print axioms EntranceDomain.run_covered
#print axioms EntranceDomain.all_word_prefixes_covered
#print axioms EntranceDomain.whole_word_covered
#print axioms EntranceDomain.prefix_key_zero_or_positive
