import SpanSeparator
namespace EndpointSpanSeparation
open BinarySpace24 EndpointGeometry EndpointSeparation PiecewiseSelector

theorem hyper_orthogonal_span (w p : Vec) (hw : dot w w=true)
    (h : ∀x,Hyper w x → dot p x=false) : p=scale (dot p w) w := by
  funext j
  have hx : Hyper w (add (unit j) (scale (w j) w)) := by
    change dot w (add (unit j) (scale (w j) w))=false
    rw [dot_add,dot_unit_right,dot_scale,hw,Bool.and_true,Bool.xor_self]
  have he := h _ hx
  rw [dot_add,dot_unit_right,dot_scale] at he
  change p j=(dot p w && w j)
  cases h1 : p j <;> cases h2 : w j <;> cases h3 : dot p w <;> simp_all

theorem norm_hyper_orthogonal_unique (w p : Vec) (hw : dot w w=true) (hp : dot p p=true)
    (h : ∀x,Hyper w x → dot p x=false) : p=w := by
  have hs := hyper_orthogonal_span w p hw h
  cases he : dot p w
  · rw [he] at hs
    exact False.elim (norm_nonzero p hp hs)
  · simpa only [he,scale,Bool.true_and] using hs

theorem unit_nonzero (j : Index) : unit j≠zero := by
  intro h
  have he := congrFun h j
  simp only [unit,decide_true,zero] at he
  contradiction

theorem unit_distinct (j k : Index) (h : j≠k) : unit j≠unit k := by
  intro he
  have hh := congrFun he j
  simp only [unit,decide_true,Ne.symm h,decide_false] at hh
  contradiction

theorem other_of_witnesses (U : Vec → Prop) (u v p q : Vec)
    (hu : U u) (hv : U v) (hu0 : u≠zero) (hv0 : v≠zero) (huv : u≠v)
    (hp : dot p p=true) (hq : dot q q=true) (hpq : p≠q)
    (hpo : ∀x,U x → dot p x=false) (hqo : ∀x,U x → dot q x=false) : Other U := by
  refine ⟨?_,?_,?_,?_⟩
  · intro he
    have hz : ZeroSpace u := he ▸ hu
    exact hu0 hz
  · intro he
    have hu' : U p := by rw [he]; trivial
    have hz := hpo p hu'
    rw [hp] at hz
    contradiction
  · rintro ⟨w,_,he⟩
    have hu' : Line w u := he ▸ hu
    have hv' : Line w v := he ▸ hv
    exact huv ((hu'.resolve_left hu0).trans (hv'.resolve_left hv0).symm)
  · rintro ⟨w,hw,he⟩
    have hwp := norm_hyper_orthogonal_unique w p hw hp (fun x hx => hpo x (he.symm ▸ hx))
    have hwq := norm_hyper_orthogonal_unique w q hw hq (fun x hx => hqo x (he.symm ▸ hx))
    exact hpq (hwp.trans hwq.symm)

end EndpointSpanSeparation
#print axioms EndpointSpanSeparation.hyper_orthogonal_span
#print axioms EndpointSpanSeparation.norm_hyper_orthogonal_unique
#print axioms EndpointSpanSeparation.unit_nonzero
#print axioms EndpointSpanSeparation.unit_distinct
#print axioms EndpointSpanSeparation.other_of_witnesses
