import LeftPassInverseProgram
namespace ActualLeftPhaseRecipe
open BinarySpace24 FourthRootRecipe CanonicalGramRecipe LeftPassAddressPhase CXLiftFormula Q21AddressProgram Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def terms : List Term := [.cross (unit 21) (unit 21),.cross (unit 21) (unit 18),.cross (unit 21) (unit 20)]

theorem local_sign (i : F) (hi : i*i= -1) (y : Vec) :
    localQuarter i y=QuadraticPhase.sign (y 21 && !(y 18 ^^ y 20)) := by
  cases h18 : y 18 <;> cases h20 : y 20 <;> cases h21 : y 21 <;>
    simp only [localQuarter,localPhase,rootPhase,Ring.neg_neg,h18,h20,h21,
      Bool.false_xor,Bool.true_xor,Bool.xor_false,Bool.xor_true,Bool.false_and,Bool.true_and,
      Bool.not_true,Bool.not_false,Bool.false_eq_true,if_false,if_true,QuadraticPhase.sign] <;> grind

theorem exact_recipe (i : F) (hi : i*i= -1) (y : Vec) : localQuarter i y=phase i terms y := by
  rw [local_sign i hi]
  simp only [terms,phase,termPhase,dot_unit]
  cases y 18 <;> cases y 20 <;> cases y 21 <;>
    simp only [Bool.false_xor,Bool.true_xor,Bool.false_and,Bool.true_and,Bool.not_true,Bool.not_false,
      QuadraticPhase.sign,Bool.false_eq_true,if_false,if_true] <;> grind

theorem local_support (i : F) (x y : Vec)
    (h18 : x 18=y 18) (h20 : x 20=y 20) (h21 : x 21=y 21) :
    localQuarter i x=localQuarter i y := by
  simp only [localQuarter,localPhase,h18,h20,h21]

theorem address_xor_formula (y : Vec) :
    run LeftPassAddressPhase.code y=add y (BinarySpace24.scale (y 21) (add (unit 20) (unit 18))) := by
  change execute ⟨21,18⟩ (execute ⟨21,20⟩ y)=_
  rw [execute,execute_other ⟨21,20⟩ 21 (by decide),execute]
  funext j
  simp only [add,BinarySpace24.scale,Bool.and_xor_distrib_left,Bool.xor_assoc]

theorem spectators_unchanged (y : Vec) (j : Index) (h18 : j≠18) (h20 : j≠20) :
    run LeftPassAddressPhase.code y j=y j := by
  change execute ⟨21,18⟩ (execute ⟨21,20⟩ y) j=_
  rw [execute_other ⟨21,18⟩ j (Ne.symm h18),execute_other ⟨21,20⟩ j (Ne.symm h20)]

theorem exact_left_formula (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) (x : Vec) :
    RootOneChildPass.leftPass i hi htwo f x=
      (coordinatePhase i x*coordinatePhase (-i) (RootJointGeometry.rootChart.inverse x))*
        phase i terms (RootJointGeometry.rootChart.inverse x)*f (address x) := by
  rw [exact_program]
  simp only [program,scalar,exact_recipe i hi]

end ActualLeftPhaseRecipe
#print axioms ActualLeftPhaseRecipe.local_sign
#print axioms ActualLeftPhaseRecipe.exact_recipe
#print axioms ActualLeftPhaseRecipe.local_support
#print axioms ActualLeftPhaseRecipe.address_xor_formula
#print axioms ActualLeftPhaseRecipe.spectators_unchanged
#print axioms ActualLeftPhaseRecipe.exact_left_formula
