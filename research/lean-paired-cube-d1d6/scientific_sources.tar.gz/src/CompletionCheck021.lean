import CompletionData
namespace CompletionCheck021
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch021.all CompletionCertificates.check=true := by decide
end CompletionCheck021
#print axioms CompletionCheck021.valid
