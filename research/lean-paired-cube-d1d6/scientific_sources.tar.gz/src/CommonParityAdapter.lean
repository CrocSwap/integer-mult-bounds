import PlaneLiftFormula
namespace CommonParityAdapter
open BinarySpace24 PlaneLiftFormula GaussianGate Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def address (u v r : Vec) (x : Vec) := add x (scale (dot r x) (add u v))
def phase (r : Vec) (x : Vec) : F := -QuadraticPhase.sign (dot r x)
def adapter (u v r : Vec) (f : Vec → F) (x : Vec) := phase r x*f (address u v r x)

theorem address_parity (u v r : Vec) (hu : dot r u=false) (hv : dot r v=false) (x : Vec) :
    dot r (address u v r x)=dot r x := by
  simp only [address,dot_add,dot_scale,hu,hv,Bool.false_xor,Bool.and_false,Bool.xor_false]

theorem address_involution (u v r : Vec) (hu : dot r u=false) (hv : dot r v=false) (x : Vec) :
    address u v r (address u v r x)=x := by
  rw [address,address_parity u v r hu hv,address,add_assoc,add_self,add_zero]

theorem adapter_involution (u v r : Vec) (hu : dot r u=false) (hv : dot r v=false) (f : Vec → F) :
    adapter u v r (adapter u v r f)=f := by
  funext x
  simp only [adapter,phase,address_parity u v r hu hv,address_involution u v r hu hv]
  have h := QuadraticPhase.sign_square (F:=F) (dot r x)
  grind

theorem swap_shifts (x u v : Vec) : add (add x u) v=add (add x v) u := by
  funext k
  simp only [add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem sum_cancel (x u v : Vec) : add (add x (add u v)) u=add x v := by
  rw [← add_assoc,swap_shifts (add x u) v u,add_assoc x u u,add_self,add_zero]

theorem exact_nested_formula (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (u v r : Vec)
    (hu : dot r u=false) (hv : dot r v=false) (f : Vec → F) :
    twisted i u r (twisted i v r (TranslationKernel.gate i v f))=
      adapter u v r (TranslationKernel.gate (-i) u f) := by
  funext x
  have hcoef := coefficient_square i hi htwo
  have hphase := phase_coefficients i hi
  have hdiff := CoordinateChild.coefficient_difference i hi htwo
  have hinv := inverse_coefficients i
  simp only [twisted,TranslationKernel.gate,InvolutionGate.gate,TranslationKernel.flip,adapter,phase,
    address,dot_add,hu,hv,Bool.xor_false,hinv.1,hinv.2]
  cases hr : dot r x
  · simp only [hr,QuadraticPhase.sign,Bool.false_eq_true,if_false]
    change _= -(1:F)*(b i*f (add x zero)+a i*f (add (add x zero) u))
    simp only [add_zero,add_assoc,add_self]
    grind
  · simp only [hr,QuadraticPhase.sign,if_true]
    change _= -(-1:F)*(b i*f (add x (add u v))+a i*f (add (add x (add u v)) u))
    rw [sum_cancel]
    simp only [add_assoc,add_self,add_zero]
    grind

end CommonParityAdapter
#print axioms CommonParityAdapter.address_parity
#print axioms CommonParityAdapter.address_involution
#print axioms CommonParityAdapter.adapter_involution
#print axioms CommonParityAdapter.swap_shifts
#print axioms CommonParityAdapter.sum_cancel
#print axioms CommonParityAdapter.exact_nested_formula
