import BitTranspositionSoundness
namespace ActualPermutationSwaps
open BinarySpace24 BinaryCompletion BitTranspositionProgram BitSwapCounter BitTranspositionSoundness
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (BinaryPairEnumeration.Bits n) := BinaryAddressEquality.decidableEquality

def specs : List Spec := [
  ⟨0,23,IndexTransposition.check_sound 0 23 (by decide)⟩,
  ⟨0,4,IndexTransposition.check_sound 0 4 (by decide)⟩,
  ⟨0,19,IndexTransposition.check_sound 0 19 (by decide)⟩,
  ⟨0,3,IndexTransposition.check_sound 0 3 (by decide)⟩,
  ⟨0,20,IndexTransposition.check_sound 0 20 (by decide)⟩,
  ⟨0,2,IndexTransposition.check_sound 0 2 (by decide)⟩,
  ⟨0,21,IndexTransposition.check_sound 0 21 (by decide)⟩,
  ⟨0,1,IndexTransposition.check_sound 0 1 (by decide)⟩,
  ⟨0,22,IndexTransposition.check_sound 0 22 (by decide)⟩,
  ⟨5,18,IndexTransposition.check_sound 5 18 (by decide)⟩,
  ⟨6,17,IndexTransposition.check_sound 6 17 (by decide)⟩,
  ⟨7,16,IndexTransposition.check_sound 7 16 (by decide)⟩,
  ⟨8,15,IndexTransposition.check_sound 8 15 (by decide)⟩,
  ⟨9,14,IndexTransposition.check_sound 9 14 (by decide)⟩,
  ⟨10,13,IndexTransposition.check_sound 10 13 (by decide)⟩,
  ⟨11,12,IndexTransposition.check_sound 11 12 (by decide)⟩]

theorem sixteen_swaps : specs.length=16 ∧ specs.reverse.length=16 := by decide

theorem exact_pairs : specs.map (fun s=>(s.a,s.b))=
  [(0,23),(0,4),(0,19),(0,3),(0,20),(0,2),(0,21),(0,1),(0,22),(5,18),(6,17),(7,16),(8,15),(9,14),(10,13),(11,12)] := rfl

theorem table_checked : (List.finRange 24).all (fun j=>decide
    (lookup specs j=RootAddressInstructions.permutation.inverse j ∧
     lookup specs.reverse j=RootAddressInstructions.permutation.forward j))=true := by decide

theorem table_exact (j : Index) : lookup specs j=RootAddressInstructions.permutation.inverse j ∧
    lookup specs.reverse j=RootAddressInstructions.permutation.forward j :=
  of_decide_eq_true (List.all_eq_true.mp table_checked j (List.mem_ofFn.mpr ⟨j,rfl⟩))

theorem forward_exact (x : Vec) : run specs x=permute RootAddressInstructions.permutation x := by
  funext j
  rw [run_lookup]
  exact congrArg x (table_exact j).1

theorem inverse_exact (x : Vec) : run specs.reverse x=unpermute RootAddressInstructions.permutation x := by
  funext j
  rw [run_lookup]
  exact congrArg x (table_exact j).2

theorem forward_memory (s : PairLoadStoreMachine.State Vec V) :
    (program specs s).1.memory=fun x=>s.memory (permute RootAddressInstructions.permutation x) := by
  rw [program_memory]
  funext x
  rw [forward_exact]

theorem inverse_memory (s : PairLoadStoreMachine.State Vec V) :
    (program specs.reverse s).1.memory=fun x=>s.memory (unpermute RootAddressInstructions.permutation x) := by
  rw [program_memory]
  funext x
  rw [inverse_exact]

theorem forward_receipt (s : PairLoadStoreMachine.State Vec V) :
    (program specs s).2=⟨134217728,134217728,0⟩ := by
  rw [program_cost,sixteen_swaps.1]
  rfl

theorem inverse_receipt (s : PairLoadStoreMachine.State Vec V) :
    (program specs.reverse s).2=⟨134217728,134217728,0⟩ := by
  rw [program_cost,sixteen_swaps.2]
  rfl

theorem memory_roundtrip (s : PairLoadStoreMachine.State Vec V) :
    (program specs.reverse (program specs s).1).1.memory=s.memory := by
  rw [inverse_memory,forward_memory]
  funext x
  exact congrArg s.memory (permutation_right RootAddressInstructions.permutation x)

theorem memory_roundtrip_reverse (s : PairLoadStoreMachine.State Vec V) :
    (program specs (program specs.reverse s).1).1.memory=s.memory := by
  rw [forward_memory,inverse_memory]
  funext x
  exact congrArg s.memory (permutation_left RootAddressInstructions.permutation x)

end ActualPermutationSwaps
#print axioms ActualPermutationSwaps.sixteen_swaps
#print axioms ActualPermutationSwaps.exact_pairs
#print axioms ActualPermutationSwaps.table_checked
#print axioms ActualPermutationSwaps.table_exact
#print axioms ActualPermutationSwaps.forward_exact
#print axioms ActualPermutationSwaps.inverse_exact
#print axioms ActualPermutationSwaps.forward_memory
#print axioms ActualPermutationSwaps.inverse_memory
#print axioms ActualPermutationSwaps.forward_receipt
#print axioms ActualPermutationSwaps.inverse_receipt
#print axioms ActualPermutationSwaps.memory_roundtrip
#print axioms ActualPermutationSwaps.memory_roundtrip_reverse
