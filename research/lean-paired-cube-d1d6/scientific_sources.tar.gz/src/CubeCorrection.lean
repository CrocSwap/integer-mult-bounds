import WeightedRows
import DecoderCongruence
import PairedCubeIdentities
namespace CubeCorrection
open PairedWord PairedDecoder WeightedRows DagSemantics

/- K6 = 6 K = 3 K2. The existing cube matrix has K2^2 = 4 I. -/
def baseTerms (residue : Nat) : List ReadTerm :=
  (List.range 8).filterMap (fun j => if PairedCubeIdentities.k2 residue j = 0 then none
    else some ⟨j+1, 3*PairedCubeIdentities.k2 residue j⟩)

def shift (offset : Nat) (term : ReadTerm) : ReadTerm := ⟨offset+term.role, term.coefficient⟩
def terms (target : Nat) : List ReadTerm :=
  (baseTerms (target%8)).map (shift (8*(target/8)))

def response (target : Nat) (payload : State) : Int :=
  PairedDecoder.evaluate (terms target) (fun sourceNode => payload (sourceNode-1))

theorem base_weight : ∀ residue : Fin 8, weight (baseTerms residue.val) = 12 := by decide

theorem base_bounds : ∀ residue : Fin 8,
    (baseTerms residue.val).all (fun term => decide (1 ≤ term.role ∧ term.role ≤ 8)) = true := by decide

theorem shifted_weight (offset : Nat) (ts : List ReadTerm) : weight (ts.map (shift offset)) = weight ts := by
  induction ts with
  | nil => rfl
  | cons t ts ih => simp [weight, shift, ih]

theorem correction_weight (target : Nat) : weight (terms target) = 12 := by
  rw [terms, shifted_weight]
  exact base_weight ⟨target%8, by omega⟩

theorem correction_sources (target : Nat) (h : target<1760) :
    ∀ term ∈ terms target, 1 ≤ term.role ∧ term.role ≤ 1760 := by
  intro term ht
  have hm : ∃ t, t ∈ baseTerms (target%8) ∧ shift (8*(target/8)) t = term := List.mem_map.mp ht
  rcases hm with ⟨t, hbase, rfl⟩
  have hb := of_decide_eq_true ((List.all_eq_true.mp (base_bounds ⟨target%8, by omega⟩)) t hbase)
  simp only [shift]
  omega

theorem graph_response (g : Graph) (hg : sourceGraphCheck g = true)
    (target : Nat) (ht : target<1760) (payload : State) :
    PairedDecoder.evaluate (terms target) (value g payload) = response target payload := by
  apply PairedDecoder.evaluate_congr
  intro term hterm
  have hb := correction_sources target ht term hterm
  have hi : term.role-1<1760 := by omega
  have hn : g.node ((term.role-1)+1) = .input (term.role-1) := of_decide_eq_true
    ((List.all_eq_true.mp hg) (term.role-1) (List.mem_range.mpr hi))
  have he : (term.role-1)+1=term.role := by omega
  rw [he] at hn
  exact value_input g payload term.role (term.role-1) hn

end CubeCorrection
#print axioms CubeCorrection.base_weight
#print axioms CubeCorrection.base_bounds
#print axioms CubeCorrection.shifted_weight
#print axioms CubeCorrection.correction_weight
#print axioms CubeCorrection.correction_sources
#print axioms CubeCorrection.graph_response
