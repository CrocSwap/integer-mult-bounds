import DagSemantics
namespace DagSemantics
open TraceTable

def initialBlockCheck (t : Table Nat) (block : Nat) : Bool :=
  (List.range 1024).all (fun offset =>
    decide (TraceTable.get t (1024*block+offset) = sourceIndex (1024*block+offset)))

theorem initial_blocks_sound (t : Table Nat)
    (h : (List.range 32).all (initialBlockCheck t) = true) : initialCheck 15 t = true := by
  apply List.all_eq_true.mpr
  intro i hi
  have hib : i < 32768 := List.mem_range.mp hi
  have hb : i/1024 < 32 := by omega
  have ho : i%1024 < 1024 := by omega
  have block := (List.all_eq_true.mp h) (i/1024) (List.mem_range.mpr hb)
  have entry := (List.all_eq_true.mp block) (i%1024) (List.mem_range.mpr ho)
  have heq : 1024*(i/1024)+i%1024=i := by omega
  simpa only [heq] using entry

end DagSemantics
#print axioms DagSemantics.initial_blocks_sound
