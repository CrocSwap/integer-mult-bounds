import CompletionData
namespace CompletionCheck022
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch022.all CompletionCertificates.check=true := by decide
end CompletionCheck022
#print axioms CompletionCheck022.valid
