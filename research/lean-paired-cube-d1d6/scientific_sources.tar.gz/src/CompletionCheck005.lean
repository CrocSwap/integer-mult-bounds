import CompletionData
namespace CompletionCheck005
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch005.all CompletionCertificates.check=true := by decide
end CompletionCheck005
#print axioms CompletionCheck005.valid
