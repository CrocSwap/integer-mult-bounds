import TraceTable
import DecoderSemantics

namespace DagSemantics
open PairedWord TraceTable

inductive Spec where
  | zero
  | input (index : Nat)
  | add (left right : Nat) (negative : Bool)
  deriving DecidableEq

structure Graph where
  node : Nat → Spec
  topological : ∀ n l r neg, node n = .add l r neg → l < n ∧ r < n

def value (g : Graph) (payload : State) (n : Nat) : Int :=
  match h : g.node n with
  | .zero => 0
  | .input i => payload i
  | .add l r neg => value g payload l + if neg then -(value g payload r) else value g payload r
termination_by n
decreasing_by
  all_goals first | exact (g.topological n _ _ _ h).1 | exact (g.topological n _ _ _ h).2

theorem value_zero (g : Graph) (payload : State) (n : Nat) (h : g.node n = .zero) :
    value g payload n = 0 := by rw [value, h]

theorem value_input (g : Graph) (payload : State) (n i : Nat) (h : g.node n = .input i) :
    value g payload n = payload i := by rw [value, h]

theorem value_add (g : Graph) (payload : State) (n l r : Nat) (neg : Bool)
    (h : g.node n = .add l r neg) :
    value g payload n = value g payload l + if neg then -(value g payload r) else value g payload r := by
  rw [value, h]

def specValid (index : Nat) : Spec → Bool
  | .add l r _ => decide (l < index ∧ r < index)
  | _ => true

def tableNode (size : Nat) (t : Table Spec) (n : Nat) : Spec :=
  if n < size then get t n else .zero

def graphCheck (size : Nat) (t : Table Spec) : Bool :=
  (List.range size).all (fun n => specValid n (get t n))

theorem graphCheck_sound (size : Nat) (t : Table Spec) (h : graphCheck size t = true) :
    ∀ n l r neg, tableNode size t n = .add l r neg → l < n ∧ r < n := by
  intro n l r neg hn
  by_cases hns : n < size
  · have hg : get t n = .add l r neg := by simpa [tableNode, hns] using hn
    have hc := (List.all_eq_true.mp h) n (List.mem_range.mpr hns)
    rw [hg] at hc
    exact of_decide_eq_true hc
  · simp [tableNode, hns] at hn

def checkedGraph (size : Nat) (t : Table Spec) (h : graphCheck size t = true) : Graph :=
  ⟨tableNode size t, graphCheck_sound size t h⟩

def compatible (node : Nat → Spec) (a : Annotation) : Bool :=
  decide (a.oldDst = 0 ∧ a.oldSrc = a.result ∧ a.step.negative = false) ||
  match node a.result with
  | .add l r neg =>
    decide (a.oldDst = l ∧ a.oldSrc = r ∧ a.step.negative = neg) ||
    decide (a.oldDst = r ∧ a.oldSrc = l ∧ a.step.negative = false ∧ neg = false)
  | _ => false

theorem compatible_sound (g : Graph) (payload : State) (a : Annotation)
    (hz : g.node 0 = .zero) (hc : compatible g.node a = true) :
    localIdentity (value g payload) a := by
  have hzero := value_zero g payload 0 hz
  rcases Bool.or_eq_true_iff.mp hc with hcopy | hadd
  · have hh : a.oldDst = 0 ∧ a.oldSrc = a.result ∧ a.step.negative = false := of_decide_eq_true hcopy
    simp only [localIdentity, hh.1, hh.2.1, hh.2.2, Bool.false_eq_true, ↓reduceIte, hzero, Int.zero_add]
  · cases hn : g.node a.result with
    | zero => simp [hn] at hadd
    | input i => simp [hn] at hadd
    | add l r neg =>
      simp only [hn] at hadd
      have hv := value_add g payload a.result l r neg hn
      rcases Bool.or_eq_true_iff.mp hadd with hd | hs
      · have hh : a.oldDst=l ∧ a.oldSrc=r ∧ a.step.negative=neg := of_decide_eq_true hd
        simpa only [localIdentity, hh.1, hh.2.1, hh.2.2] using hv
      · have hh : a.oldDst=r ∧ a.oldSrc=l ∧ a.step.negative=false ∧ neg=false := of_decide_eq_true hs
        simp only [localIdentity, hh.1, hh.2.1, hh.2.2.1, Bool.false_eq_true, ↓reduceIte]
        simp only [hh.2.2.2, Bool.false_eq_true, ↓reduceIte] at hv
        omega

def sourceIndex (role : Nat) : Nat :=
  if role % 3 = 0 ∧ role / 3 < 1760 then role / 3 + 1 else 0

def sourceGraphCheck (g : Graph) : Bool :=
  (List.range 1760).all (fun i => decide (g.node (i+1) = .input i))

def initialCheck (depth : Nat) (t : Table Nat) : Bool :=
  (List.range (2^depth)).all (fun i => decide (get t i = sourceIndex i))

theorem initial_sound (depth : Nat) (t : Table Nat) (g : Graph) (payload : State)
    (hz : g.node 0 = .zero) (hg : sourceGraphCheck g = true)
    (hi : initialCheck depth t = true) :
    ∀ i, i < 2^depth → value g payload (get t i) = PairedDecoder.inject payload i := by
  intro i hib
  have ht : get t i = sourceIndex i := of_decide_eq_true
    ((List.all_eq_true.mp hi) i (List.mem_range.mpr hib))
  rw [ht]
  by_cases hs : i % 3 = 0 ∧ i / 3 < 1760
  · have hn : g.node (i/3+1) = .input (i/3) := of_decide_eq_true
      ((List.all_eq_true.mp hg) (i/3) (List.mem_range.mpr hs.2))
    simpa only [sourceIndex, PairedDecoder.inject, if_pos hs] using value_input g payload _ _ hn
  · simpa only [sourceIndex, PairedDecoder.inject, if_neg hs] using value_zero g payload 0 hz

end DagSemantics
#print axioms DagSemantics.value_zero
#print axioms DagSemantics.value_input
#print axioms DagSemantics.value_add
#print axioms DagSemantics.graphCheck_sound
#print axioms DagSemantics.compatible_sound

#print axioms DagSemantics.initial_sound
