import Lean
namespace BinarySpace24
abbrev Index := Fin 24
abbrev Vec := Index → Bool

def zero : Vec := fun _ => false
def add (x y : Vec) : Vec := fun k => x k ^^ y k
def scale (b : Bool) (x : Vec) : Vec := fun k => b && x k
def unit (j : Index) : Vec := fun k => decide (j=k)
def dotList : List Index → Vec → Vec → Bool
  | [],_,_ => false
  | j::js,x,y => (x j && y j) ^^ dotList js x y
def dot (x y : Vec) : Bool := dotList (List.finRange 24) x y

theorem add_self (x : Vec) : add x x=zero := by funext k; simp [add,zero]
theorem add_zero (x : Vec) : add x zero=x := by funext k; simp [add,zero]
theorem zero_add (x : Vec) : add zero x=x := by funext k; simp [add,zero]
theorem add_assoc (x y z : Vec) : add (add x y) z=add x (add y z) := by
  funext k; exact Bool.xor_assoc _ _ _
theorem add_comm (x y : Vec) : add x y=add y x := by funext k; exact Bool.xor_comm _ _

theorem dotList_add (js : List Index) (x y z : Vec) :
    dotList js x (add y z)=(dotList js x y ^^ dotList js x z) := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    simp only [dotList,add,Bool.and_xor_distrib_left,ih]
    simp only [Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem dotList_symmetric (js : List Index) (x y : Vec) : dotList js x y=dotList js y x := by
  induction js with
  | nil => rfl
  | cons j js ih => simp only [dotList,Bool.and_comm,ih]

theorem dot_add (x y z : Vec) : dot x (add y z)=(dot x y ^^ dot x z) := dotList_add _ _ _ _
theorem dot_symmetric (x y : Vec) : dot x y=dot y x := dotList_symmetric _ _ _
theorem dot_add_left (x y z : Vec) : dot (add x y) z=(dot x z ^^ dot y z) := by
  rw [dot_symmetric,dot_add,dot_symmetric z x,dot_symmetric z y]

theorem dotList_zero (js : List Index) (x : Vec) : dotList js x zero=false := by
  induction js with
  | nil => rfl
  | cons j js ih => simp [dotList,zero,ih]

theorem dot_zero (x : Vec) : dot x zero=false := dotList_zero _ _

theorem dot_scale (x y : Vec) (b : Bool) : dot x (scale b y)=(b && dot x y) := by
  cases b
  · exact dot_zero x
  · rfl

theorem dotList_unit_absent (js : List Index) (j : Index) (hj : j ∉ js) (x : Vec) :
    dotList js (unit j) x=false := by
  induction js with
  | nil => rfl
  | cons k ks ih =>
    have hne : j≠k := by intro h; subst k; exact hj (by simp)
    have ht : j ∉ ks := fun h => hj (by simp [h])
    simp [dotList,unit,hne,ih ht]

theorem dotList_unit_present (js : List Index) (hn : js.Nodup) (j : Index) (hj : j ∈ js) (x : Vec) :
    dotList js (unit j) x=x j := by
  induction js with
  | nil => cases hj
  | cons k ks ih =>
    have hn' := List.nodup_cons.mp hn
    rcases List.mem_cons.mp hj with he | ht
    · subst k
      simp [dotList,unit,dotList_unit_absent ks j hn'.1 x]
    · by_cases he : j=k
      · subst k
        exact False.elim (hn'.1 ht)
      · simp [dotList,unit,he,ih hn'.2 ht]

theorem dot_unit (j : Index) (x : Vec) : dot (unit j) x=x j := by
  apply dotList_unit_present
  · decide
  · exact List.mem_ofFn.mpr ⟨j,rfl⟩

theorem dot_unit_right (x : Vec) (j : Index) : dot x (unit j)=x j := by
  rw [dot_symmetric,dot_unit]

theorem dotList_perm {as bs : List Index} (hp : as.Perm bs) (x y : Vec) :
    dotList as x y=dotList bs x y := by
  induction hp with
  | nil => rfl
  | cons j hp ih => simp only [dotList,ih]
  | swap j k js => exact Bool.xor_left_comm _ _ _
  | trans hp hq ih ih' => exact ih.trans ih'

theorem dotList_map (js : List Index) (p : Index → Index) (x y : Vec) :
    dotList (js.map p) x y=dotList js (fun j => x (p j)) (fun j => y (p j)) := by
  induction js with
  | nil => rfl
  | cons j js ih => simp only [List.map_cons,dotList,ih]

theorem permutation_dot (p : Index → Index) (hp : ((List.finRange 24).map p).Perm (List.finRange 24))
    (x y : Vec) : dot (fun j => x (p j)) (fun j => y (p j))=dot x y := by
  rw [dot,← dotList_map]
  exact dotList_perm hp x y

end BinarySpace24
#print axioms BinarySpace24.add_self
#print axioms BinarySpace24.add_zero
#print axioms BinarySpace24.zero_add
#print axioms BinarySpace24.add_assoc
#print axioms BinarySpace24.add_comm
#print axioms BinarySpace24.dotList_add
#print axioms BinarySpace24.dotList_symmetric
#print axioms BinarySpace24.dot_add
#print axioms BinarySpace24.dot_symmetric
#print axioms BinarySpace24.dot_add_left
#print axioms BinarySpace24.dotList_zero
#print axioms BinarySpace24.dot_zero
#print axioms BinarySpace24.dot_scale
#print axioms BinarySpace24.dotList_unit_absent
#print axioms BinarySpace24.dotList_unit_present
#print axioms BinarySpace24.dot_unit
#print axioms BinarySpace24.dot_unit_right
#print axioms BinarySpace24.dotList_perm
#print axioms BinarySpace24.dotList_map
#print axioms BinarySpace24.permutation_dot
