import ConstantSetupStorage13955

/- The generic setup is connected to the unchanged event: role 17326,
   root index 3, incoming/outgoing frames after 3/4 roots. Field laws, a
   supplied square root of -1, and nonzero two remain explicit premises. -/
namespace ConstantSetupBridge13955
open CountedConstantSetup13955 BinarySpace24 BinaryPairEnumeration Coordinate21Pairs Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def storedGate (s : Memory F) (v : F × F) : F × F :=
  (coefficientA s*v.1+coefficientB s*v.2,coefficientB s*v.1+coefficientA s*v.2)

def storedPairs (s : Memory F) (f : Vec → F) (x : Vec) : F :=
  let y := Coordinate21Pairs.drop x
  let v := storedGate s (f (embed false y),f (embed true y))
  if x 21 then v.2 else v.1

theorem stored_gate_exact (i : F) (s : Memory F) (v : F × F) :
    storedGate (setup i s) v=GaussianGate.C i v := by
  simp only [storedGate,coefficient_a_exact,coefficient_b_exact,GaussianGate.C]

theorem stored_pairs_exact (i : F) (s : Memory F) (f : Vec → F) :
    storedPairs (setup i s) f=Coordinate21PairProgram.applyPairs i f := by
  funext x
  simp only [storedPairs,stored_gate_exact,Coordinate21PairProgram.applyPairs,
    Coordinate21PairProgram.expression_exact]

theorem lookup_exact (i : F) (s : Memory F) (q : TwoBitQuarter.Quarter) :
    SuppliedQuarterTable.lookup (table (setup i s)) q=TwoBitQuarter.value i q := by
  rw [table_exact,SuppliedQuarterTable.canonical_lookup]

theorem stored_gate_squared (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (s : Memory F) (v : F × F) :
    storedGate (setup i s) (storedGate (setup i s) v)=GaussianGate.X v := by
  rw [stored_gate_exact,stored_gate_exact,GaussianGate.c_square i hi htwo]

theorem computed_coefficients (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (s : Memory F) :
    coefficientA (setup i s)*coefficientA (setup i s)+
      coefficientB (setup i s)*coefficientB (setup i s)=0 ∧
    coefficientA (setup i s)*coefficientB (setup i s)+
      coefficientB (setup i s)*coefficientA (setup i s)=1 := by
  simp only [coefficient_a_exact,coefficient_b_exact]
  exact GaussianGate.coefficient_square i hi htwo

theorem actual_event_from_setup (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (s : Memory F) (g : GaugeKeyTrace.State) (f : Vec → F) :
    CommonExactFrame.adapter (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 3 g 17326))
      (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 4 g 17326)) f=
      SuppliedQuarterTable.leftPass (table (setup i s))
        (storedPairs (setup i s) (SuppliedQuarterTable.rightPass (table (setup i s)) f)) := by
  have h := SuppliedQuarterTable.actual_event i hi htwo
    (table (setup i s)) (table_exact i s) g f
  have hp := stored_pairs_exact i s (SuppliedQuarterTable.rightPass (table (setup i s)) f)
  exact h.trans (congrArg (SuppliedQuarterTable.leftPass (table (setup i s))) hp.symm)

end ConstantSetupBridge13955
#print axioms ConstantSetupBridge13955.stored_gate_exact
#print axioms ConstantSetupBridge13955.stored_pairs_exact
#print axioms ConstantSetupBridge13955.lookup_exact
#print axioms ConstantSetupBridge13955.stored_gate_squared
#print axioms ConstantSetupBridge13955.computed_coefficients
#print axioms ConstantSetupBridge13955.actual_event_from_setup
