import BinaryCompletion
import ActualCarrierGate
namespace CompletionCertificates
open BinarySpace24 BinaryCompletion TensorThree

def axes : List Axis := [.first,.second,.third]
def index : Axis → Index
  | .first => 0
  | .second => 1
  | .third => 2

theorem axis_mem (axis : Axis) : axis ∈ axes := by cases axis <;> simp [axes]
theorem index_injective (a b : Axis) (h : index a=index b) : a=b := by
  cases a <;> cases b <;> simp_all [index]

structure Witness where
  cube : List Nat
  parity : Bool
  forward : List Index
  inverse : List Index

def forward (c : Witness) (j : Index) : Index := c.forward[j.val]?.getD 0
def inverse (c : Witness) (j : Index) : Index := c.inverse[j.val]?.getD 0
def pivot (c : Witness) (axis : Axis) : Index := forward c (index axis)
def source (c : Witness) (axis : Axis) : Nat := ActualCarrierGate.direction c.cube c.parity axis
def vector (c : Witness) (axis : Axis) : Vec := fun j => (source c axis).testBit j.val

def privatePosition (c : Witness) (axis : Axis) (j : Nat) : Bool :=
  (source c axis).testBit j && (axes.all (fun other => decide (other=axis) || !(source c other).testBit j))
def normalForm (c : Witness) : List Index :=
  axes.map (pivot c) ++ (List.finRange 24).filter (fun j => !(axes.map (pivot c)).contains j)

def check (c : Witness) : Bool :=
  decide (c.forward.length=24 ∧ c.inverse.length=24) &&
  ((List.finRange 24).all (fun j => decide (inverse c (forward c j)=j ∧ forward c (inverse c j)=j)) &&
  (((List.finRange 24).map (inverse c)).isPerm (List.finRange 24) &&
  ((axes.all (fun a => axes.all (fun b => decide (vector c a (pivot c b)=decide (a=b))))) &&
  (decide (c.forward=normalForm c) &&
  axes.all (fun a => (List.range (pivot c a).val).all (fun j => !(privatePosition c a j)))))))

structure Facts (c : Witness) : Prop where
  lengths : c.forward.length=24 ∧ c.inverse.length=24
  left : ∀ j, inverse c (forward c j)=j
  right : ∀ j, forward c (inverse c j)=j
  inverse_perm : ((List.finRange 24).map (inverse c)).Perm (List.finRange 24)
  private_pivots : ∀ a b, vector c a (pivot c b)=decide (a=b)
  normal_form : c.forward=normalForm c
  least_private : ∀ a j, j<(pivot c a).val → privatePosition c a j=false

theorem check_sound (c : Witness) (hc : check c=true) : Facts c := by
  have h0 := Bool.and_eq_true_iff.mp hc
  have h1 := Bool.and_eq_true_iff.mp h0.2
  have h2 := Bool.and_eq_true_iff.mp h1.2
  have h3 := Bool.and_eq_true_iff.mp h2.2
  have h4 := Bool.and_eq_true_iff.mp h3.2
  have hinv (j : Index) := of_decide_eq_true (List.all_eq_true.mp h1.1 j (List.mem_ofFn.mpr ⟨j,rfl⟩))
  refine ⟨of_decide_eq_true h0.1,fun j => (hinv j).1,fun j => (hinv j).2,
    List.isPerm_iff.mp h2.1,?_,of_decide_eq_true h4.1,?_⟩
  · intro a b
    exact of_decide_eq_true (List.all_eq_true.mp (List.all_eq_true.mp h3.1 a (axis_mem a)) b (axis_mem b))
  · intro a j hj
    have h := List.all_eq_true.mp (List.all_eq_true.mp h4.2 a (axis_mem a)) j (List.mem_range.mpr hj)
    simpa using h

def permutation (c : Witness) (hc : Facts c) : Permutation :=
  ⟨forward c,inverse c,hc.left,hc.right,hc.inverse_perm⟩
def residual (c : Witness) (axis : Axis) : Vec := add (vector c axis) (unit (pivot c axis))

theorem pivot_injective (c : Witness) (hc : Facts c) (a b : Axis) (h : pivot c a=pivot c b) : a=b := by
  apply index_injective
  have he := congrArg (inverse c) h
  simpa only [pivot,hc.left] using he

theorem residual_vanish (c : Witness) (hc : Facts c) (a b : Axis) : residual c a (pivot c b)=false := by
  simp only [residual,add,unit,hc.private_pivots]
  have he : (pivot c a=pivot c b) ↔ a=b := ⟨pivot_injective c hc a b,fun h => h ▸ rfl⟩
  simp [he]

def fullMap (c : Witness) (hc : Facts c) : Vec → Vec := G (permutation c hc) (pivot c) (residual c)
def fullInverse (c : Witness) (hc : Facts c) : Vec → Vec := Ginv (permutation c hc) (pivot c) (residual c)
def inverseTranspose (c : Witness) (hc : Facts c) : Vec → Vec := GinvT (permutation c hc) (pivot c) (residual c)
def blockMap (c : Witness) (hc : Facts c) : Vec × Vec → Vec × Vec := KG (permutation c hc) (pivot c) (residual c)

theorem full_inverse_left (c : Witness) (hc : Facts c) (x : Vec) : fullInverse c hc (fullMap c hc x)=x :=
  BinaryCompletion.inverse_left _ _ _ (residual_vanish c hc) x
theorem full_inverse_right (c : Witness) (hc : Facts c) (x : Vec) : fullMap c hc (fullInverse c hc x)=x :=
  BinaryCompletion.inverse_right _ _ _ (residual_vanish c hc) x

theorem permute_unit (c : Witness) (hc : Facts c) (j : Index) :
    permute (permutation c hc) (unit j)=unit (forward c j) := by
  funext k
  simp only [permute,permutation,unit]
  have he : (j=inverse c k) ↔ forward c j=k := by
    constructor
    · intro h; rw [h,hc.right]
    · intro h
      have h' := congrArg (inverse c) h
      simpa only [hc.left] using h'
  simp only [he]

theorem coefficients_unit_pivot (c : Witness) (hc : Facts c) (axis : Axis) :
    PrivateShear.combine (residual c) (PrivateShear.coefficients (pivot c) (unit (pivot c axis)))=residual c axis := by
  have he (a b : Axis) : (pivot c a=pivot c b) ↔ a=b := ⟨pivot_injective c hc a b,fun h => h ▸ rfl⟩
  cases axis <;> funext k <;> simp [PrivateShear.combine,PrivateShear.coefficients,unit,he,add,scale]

theorem source_columns (c : Witness) (hc : Facts c) (axis : Axis) : fullMap c hc (unit (index axis))=vector c axis := by
  unfold fullMap G
  rw [permute_unit]
  change add (unit (pivot c axis))
    (PrivateShear.combine (residual c) (PrivateShear.coefficients (pivot c) (unit (pivot c axis))))=vector c axis
  rw [coefficients_unit_pivot c hc]
  funext k
  simp only [residual,add]
  rw [Bool.xor_left_comm,Bool.xor_self,Bool.xor_false]

theorem actual_binary_block (c : Witness) (hc : Facts c) (x z : Vec) :
    blockMap c hc (x,z)=(fullMap c hc x,
      add (add (fullMap c hc x) (inverseTranspose c hc x)) (inverseTranspose c hc z)) :=
  block_formula _ _ _ x z

theorem block_symplectic (c : Witness) (hc : Facts c) (v w : Vec × Vec) :
    symplectic (blockMap c hc v) (blockMap c hc w)=symplectic v w :=
  KG_symplectic _ _ _ (residual_vanish c hc) v w

theorem block_frame_transport (c : Witness) (hc : Facts c) (U : Vec → Prop) (v : Vec × Vec) :
    Frame (Image (fullMap c hc) U) (blockMap c hc v) ↔ Frame U v :=
  KG_frame_transport _ _ _ (residual_vanish c hc) U v

end CompletionCertificates
#print axioms CompletionCertificates.axis_mem
#print axioms CompletionCertificates.index_injective
#print axioms CompletionCertificates.check_sound
#print axioms CompletionCertificates.pivot_injective
#print axioms CompletionCertificates.residual_vanish
#print axioms CompletionCertificates.full_inverse_left
#print axioms CompletionCertificates.full_inverse_right
#print axioms CompletionCertificates.permute_unit
#print axioms CompletionCertificates.coefficients_unit_pivot
#print axioms CompletionCertificates.source_columns
#print axioms CompletionCertificates.actual_binary_block
#print axioms CompletionCertificates.block_symplectic
#print axioms CompletionCertificates.block_frame_transport
