import ActualDecoder
import WeightedRows
namespace ActualDecoderWeights
open WeightedRows
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem chunk000_weight : ActualDecoder.chunk000.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk001_weight : ActualDecoder.chunk001.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk002_weight : ActualDecoder.chunk002.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk003_weight : ActualDecoder.chunk003.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk004_weight : ActualDecoder.chunk004.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk005_weight : ActualDecoder.chunk005.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk006_weight : ActualDecoder.chunk006.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk007_weight : ActualDecoder.chunk007.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk008_weight : ActualDecoder.chunk008.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk009_weight : ActualDecoder.chunk009.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk010_weight : ActualDecoder.chunk010.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk011_weight : ActualDecoder.chunk011.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk012_weight : ActualDecoder.chunk012.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk013_weight : ActualDecoder.chunk013.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk014_weight : ActualDecoder.chunk014.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk015_weight : ActualDecoder.chunk015.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk016_weight : ActualDecoder.chunk016.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk017_weight : ActualDecoder.chunk017.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk018_weight : ActualDecoder.chunk018.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk019_weight : ActualDecoder.chunk019.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk020_weight : ActualDecoder.chunk020.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk021_weight : ActualDecoder.chunk021.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk022_weight : ActualDecoder.chunk022.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk023_weight : ActualDecoder.chunk023.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk024_weight : ActualDecoder.chunk024.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk025_weight : ActualDecoder.chunk025.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk026_weight : ActualDecoder.chunk026.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk027_weight : ActualDecoder.chunk027.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk028_weight : ActualDecoder.chunk028.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk029_weight : ActualDecoder.chunk029.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk030_weight : ActualDecoder.chunk030.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk031_weight : ActualDecoder.chunk031.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk032_weight : ActualDecoder.chunk032.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk033_weight : ActualDecoder.chunk033.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk034_weight : ActualDecoder.chunk034.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk035_weight : ActualDecoder.chunk035.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk036_weight : ActualDecoder.chunk036.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk037_weight : ActualDecoder.chunk037.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk038_weight : ActualDecoder.chunk038.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk039_weight : ActualDecoder.chunk039.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk040_weight : ActualDecoder.chunk040.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk041_weight : ActualDecoder.chunk041.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk042_weight : ActualDecoder.chunk042.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk043_weight : ActualDecoder.chunk043.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk044_weight : ActualDecoder.chunk044.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk045_weight : ActualDecoder.chunk045.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk046_weight : ActualDecoder.chunk046.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk047_weight : ActualDecoder.chunk047.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk048_weight : ActualDecoder.chunk048.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk049_weight : ActualDecoder.chunk049.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk050_weight : ActualDecoder.chunk050.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk051_weight : ActualDecoder.chunk051.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk052_weight : ActualDecoder.chunk052.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk053_weight : ActualDecoder.chunk053.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk054_weight : ActualDecoder.chunk054.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk055_weight : ActualDecoder.chunk055.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk056_weight : ActualDecoder.chunk056.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk057_weight : ActualDecoder.chunk057.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk058_weight : ActualDecoder.chunk058.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk059_weight : ActualDecoder.chunk059.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk060_weight : ActualDecoder.chunk060.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk061_weight : ActualDecoder.chunk061.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk062_weight : ActualDecoder.chunk062.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk063_weight : ActualDecoder.chunk063.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk064_weight : ActualDecoder.chunk064.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk065_weight : ActualDecoder.chunk065.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk066_weight : ActualDecoder.chunk066.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk067_weight : ActualDecoder.chunk067.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk068_weight : ActualDecoder.chunk068.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk069_weight : ActualDecoder.chunk069.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk070_weight : ActualDecoder.chunk070.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk071_weight : ActualDecoder.chunk071.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk072_weight : ActualDecoder.chunk072.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk073_weight : ActualDecoder.chunk073.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk074_weight : ActualDecoder.chunk074.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk075_weight : ActualDecoder.chunk075.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk076_weight : ActualDecoder.chunk076.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk077_weight : ActualDecoder.chunk077.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk078_weight : ActualDecoder.chunk078.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk079_weight : ActualDecoder.chunk079.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk080_weight : ActualDecoder.chunk080.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk081_weight : ActualDecoder.chunk081.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk082_weight : ActualDecoder.chunk082.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk083_weight : ActualDecoder.chunk083.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk084_weight : ActualDecoder.chunk084.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk085_weight : ActualDecoder.chunk085.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk086_weight : ActualDecoder.chunk086.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk087_weight : ActualDecoder.chunk087.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk088_weight : ActualDecoder.chunk088.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk089_weight : ActualDecoder.chunk089.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk090_weight : ActualDecoder.chunk090.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk091_weight : ActualDecoder.chunk091.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk092_weight : ActualDecoder.chunk092.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk093_weight : ActualDecoder.chunk093.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk094_weight : ActualDecoder.chunk094.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk095_weight : ActualDecoder.chunk095.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk096_weight : ActualDecoder.chunk096.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk097_weight : ActualDecoder.chunk097.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk098_weight : ActualDecoder.chunk098.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk099_weight : ActualDecoder.chunk099.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk100_weight : ActualDecoder.chunk100.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk101_weight : ActualDecoder.chunk101.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk102_weight : ActualDecoder.chunk102.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk103_weight : ActualDecoder.chunk103.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk104_weight : ActualDecoder.chunk104.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk105_weight : ActualDecoder.chunk105.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk106_weight : ActualDecoder.chunk106.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk107_weight : ActualDecoder.chunk107.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk108_weight : ActualDecoder.chunk108.all (fun row => decide (weight row=48)) = true := by decide
theorem chunk109_weight : ActualDecoder.chunk109.all (fun row => decide (weight row=48)) = true := by decide
theorem all_checked : ActualDecoder.rows.all (fun row => decide (weight row=48)) = true := by
  simp only [ActualDecoder.rows, List.all_flatten, ActualDecoder.chunks, List.all_cons, List.all_nil, chunk000_weight, chunk001_weight, chunk002_weight, chunk003_weight, chunk004_weight, chunk005_weight, chunk006_weight, chunk007_weight, chunk008_weight, chunk009_weight, chunk010_weight, chunk011_weight, chunk012_weight, chunk013_weight, chunk014_weight, chunk015_weight, chunk016_weight, chunk017_weight, chunk018_weight, chunk019_weight, chunk020_weight, chunk021_weight, chunk022_weight, chunk023_weight, chunk024_weight, chunk025_weight, chunk026_weight, chunk027_weight, chunk028_weight, chunk029_weight, chunk030_weight, chunk031_weight, chunk032_weight, chunk033_weight, chunk034_weight, chunk035_weight, chunk036_weight, chunk037_weight, chunk038_weight, chunk039_weight, chunk040_weight, chunk041_weight, chunk042_weight, chunk043_weight, chunk044_weight, chunk045_weight, chunk046_weight, chunk047_weight, chunk048_weight, chunk049_weight, chunk050_weight, chunk051_weight, chunk052_weight, chunk053_weight, chunk054_weight, chunk055_weight, chunk056_weight, chunk057_weight, chunk058_weight, chunk059_weight, chunk060_weight, chunk061_weight, chunk062_weight, chunk063_weight, chunk064_weight, chunk065_weight, chunk066_weight, chunk067_weight, chunk068_weight, chunk069_weight, chunk070_weight, chunk071_weight, chunk072_weight, chunk073_weight, chunk074_weight, chunk075_weight, chunk076_weight, chunk077_weight, chunk078_weight, chunk079_weight, chunk080_weight, chunk081_weight, chunk082_weight, chunk083_weight, chunk084_weight, chunk085_weight, chunk086_weight, chunk087_weight, chunk088_weight, chunk089_weight, chunk090_weight, chunk091_weight, chunk092_weight, chunk093_weight, chunk094_weight, chunk095_weight, chunk096_weight, chunk097_weight, chunk098_weight, chunk099_weight, chunk100_weight, chunk101_weight, chunk102_weight, chunk103_weight, chunk104_weight, chunk105_weight, chunk106_weight, chunk107_weight, chunk108_weight, chunk109_weight, Bool.true_and]
theorem all_row_weights : ∀ row ∈ ActualDecoder.rows, weight row=48 := by
  intro row hr; exact of_decide_eq_true ((List.all_eq_true.mp all_checked) row hr)
theorem target_row_weight (target : Nat) (ht : target<1760) : weight (ActualDecoder.rows[target]?.getD []) = 48 := by
  have hi : target<ActualDecoder.rows.length := by rw [ActualDecoder.target_count]; exact ht
  rw [List.getElem?_eq_getElem hi]
  exact all_row_weights _ (List.getElem_mem hi)
end ActualDecoderWeights
#print axioms ActualDecoderWeights.chunk000_weight
#print axioms ActualDecoderWeights.chunk001_weight
#print axioms ActualDecoderWeights.chunk002_weight
#print axioms ActualDecoderWeights.chunk003_weight
#print axioms ActualDecoderWeights.chunk004_weight
#print axioms ActualDecoderWeights.chunk005_weight
#print axioms ActualDecoderWeights.chunk006_weight
#print axioms ActualDecoderWeights.chunk007_weight
#print axioms ActualDecoderWeights.chunk008_weight
#print axioms ActualDecoderWeights.chunk009_weight
#print axioms ActualDecoderWeights.chunk010_weight
#print axioms ActualDecoderWeights.chunk011_weight
#print axioms ActualDecoderWeights.chunk012_weight
#print axioms ActualDecoderWeights.chunk013_weight
#print axioms ActualDecoderWeights.chunk014_weight
#print axioms ActualDecoderWeights.chunk015_weight
#print axioms ActualDecoderWeights.chunk016_weight
#print axioms ActualDecoderWeights.chunk017_weight
#print axioms ActualDecoderWeights.chunk018_weight
#print axioms ActualDecoderWeights.chunk019_weight
#print axioms ActualDecoderWeights.chunk020_weight
#print axioms ActualDecoderWeights.chunk021_weight
#print axioms ActualDecoderWeights.chunk022_weight
#print axioms ActualDecoderWeights.chunk023_weight
#print axioms ActualDecoderWeights.chunk024_weight
#print axioms ActualDecoderWeights.chunk025_weight
#print axioms ActualDecoderWeights.chunk026_weight
#print axioms ActualDecoderWeights.chunk027_weight
#print axioms ActualDecoderWeights.chunk028_weight
#print axioms ActualDecoderWeights.chunk029_weight
#print axioms ActualDecoderWeights.chunk030_weight
#print axioms ActualDecoderWeights.chunk031_weight
#print axioms ActualDecoderWeights.chunk032_weight
#print axioms ActualDecoderWeights.chunk033_weight
#print axioms ActualDecoderWeights.chunk034_weight
#print axioms ActualDecoderWeights.chunk035_weight
#print axioms ActualDecoderWeights.chunk036_weight
#print axioms ActualDecoderWeights.chunk037_weight
#print axioms ActualDecoderWeights.chunk038_weight
#print axioms ActualDecoderWeights.chunk039_weight
#print axioms ActualDecoderWeights.chunk040_weight
#print axioms ActualDecoderWeights.chunk041_weight
#print axioms ActualDecoderWeights.chunk042_weight
#print axioms ActualDecoderWeights.chunk043_weight
#print axioms ActualDecoderWeights.chunk044_weight
#print axioms ActualDecoderWeights.chunk045_weight
#print axioms ActualDecoderWeights.chunk046_weight
#print axioms ActualDecoderWeights.chunk047_weight
#print axioms ActualDecoderWeights.chunk048_weight
#print axioms ActualDecoderWeights.chunk049_weight
#print axioms ActualDecoderWeights.chunk050_weight
#print axioms ActualDecoderWeights.chunk051_weight
#print axioms ActualDecoderWeights.chunk052_weight
#print axioms ActualDecoderWeights.chunk053_weight
#print axioms ActualDecoderWeights.chunk054_weight
#print axioms ActualDecoderWeights.chunk055_weight
#print axioms ActualDecoderWeights.chunk056_weight
#print axioms ActualDecoderWeights.chunk057_weight
#print axioms ActualDecoderWeights.chunk058_weight
#print axioms ActualDecoderWeights.chunk059_weight
#print axioms ActualDecoderWeights.chunk060_weight
#print axioms ActualDecoderWeights.chunk061_weight
#print axioms ActualDecoderWeights.chunk062_weight
#print axioms ActualDecoderWeights.chunk063_weight
#print axioms ActualDecoderWeights.chunk064_weight
#print axioms ActualDecoderWeights.chunk065_weight
#print axioms ActualDecoderWeights.chunk066_weight
#print axioms ActualDecoderWeights.chunk067_weight
#print axioms ActualDecoderWeights.chunk068_weight
#print axioms ActualDecoderWeights.chunk069_weight
#print axioms ActualDecoderWeights.chunk070_weight
#print axioms ActualDecoderWeights.chunk071_weight
#print axioms ActualDecoderWeights.chunk072_weight
#print axioms ActualDecoderWeights.chunk073_weight
#print axioms ActualDecoderWeights.chunk074_weight
#print axioms ActualDecoderWeights.chunk075_weight
#print axioms ActualDecoderWeights.chunk076_weight
#print axioms ActualDecoderWeights.chunk077_weight
#print axioms ActualDecoderWeights.chunk078_weight
#print axioms ActualDecoderWeights.chunk079_weight
#print axioms ActualDecoderWeights.chunk080_weight
#print axioms ActualDecoderWeights.chunk081_weight
#print axioms ActualDecoderWeights.chunk082_weight
#print axioms ActualDecoderWeights.chunk083_weight
#print axioms ActualDecoderWeights.chunk084_weight
#print axioms ActualDecoderWeights.chunk085_weight
#print axioms ActualDecoderWeights.chunk086_weight
#print axioms ActualDecoderWeights.chunk087_weight
#print axioms ActualDecoderWeights.chunk088_weight
#print axioms ActualDecoderWeights.chunk089_weight
#print axioms ActualDecoderWeights.chunk090_weight
#print axioms ActualDecoderWeights.chunk091_weight
#print axioms ActualDecoderWeights.chunk092_weight
#print axioms ActualDecoderWeights.chunk093_weight
#print axioms ActualDecoderWeights.chunk094_weight
#print axioms ActualDecoderWeights.chunk095_weight
#print axioms ActualDecoderWeights.chunk096_weight
#print axioms ActualDecoderWeights.chunk097_weight
#print axioms ActualDecoderWeights.chunk098_weight
#print axioms ActualDecoderWeights.chunk099_weight
#print axioms ActualDecoderWeights.chunk100_weight
#print axioms ActualDecoderWeights.chunk101_weight
#print axioms ActualDecoderWeights.chunk102_weight
#print axioms ActualDecoderWeights.chunk103_weight
#print axioms ActualDecoderWeights.chunk104_weight
#print axioms ActualDecoderWeights.chunk105_weight
#print axioms ActualDecoderWeights.chunk106_weight
#print axioms ActualDecoderWeights.chunk107_weight
#print axioms ActualDecoderWeights.chunk108_weight
#print axioms ActualDecoderWeights.chunk109_weight
#print axioms ActualDecoderWeights.all_checked
#print axioms ActualDecoderWeights.all_row_weights
#print axioms ActualDecoderWeights.target_row_weight
