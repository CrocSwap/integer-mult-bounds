import FourthRootLift
namespace BinaryBilinearCertificate
open BinarySpace24 FourthRootRecipe FourthRootLift

def sumUnits : List Index → Vec → Vec
  | [],_ => zero
  | j::js,x => add (scale (x j) (unit j)) (sumUnits js x)

theorem sum_units_dot (js : List Index) (x : Vec) (k : Index) :
    sumUnits js x k=dotList js x (unit k) := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    simp only [sumUnits,add,scale,unit,dotList,ih,eq_comm]

theorem unit_expansion (x : Vec) : sumUnits (List.finRange 24) x=x := by
  funext k
  rw [sum_units_dot]
  exact dot_unit_right x k

def BoolLinear (f : Vec → Bool) : Prop := ∀ x y, f (add x y)=(f x ^^ f y)

theorem bool_linear_zero (f : Vec → Bool) (hf : BoolLinear f) : f zero=false := by
  have h := hf zero zero
  simpa only [add_zero,Bool.xor_self] using h

theorem linear_compare_sum (f g : Vec → Bool) (hf : BoolLinear f) (hg : BoolLinear g)
    (hb : ∀ j, f (unit j)=g (unit j)) (js : List Index) (x : Vec) :
    f (sumUnits js x)=g (sumUnits js x) := by
  unfold BoolLinear at hf hg
  induction js with
  | nil => exact (bool_linear_zero f hf).trans (bool_linear_zero g hg).symm
  | cons j js ih =>
    simp only [sumUnits,hf,hg,ih]
    cases hx : x j
    · change (f zero ^^ g (sumUnits js x))=(g zero ^^ g (sumUnits js x))
      rw [bool_linear_zero f hf,bool_linear_zero g hg]
    · change (f (unit j) ^^ g (sumUnits js x))=(g (unit j) ^^ g (sumUnits js x))
      rw [hb]

theorem linear_basis_ext (f g : Vec → Bool) (hf : BoolLinear f) (hg : BoolLinear g)
    (hb : ∀ j, f (unit j)=g (unit j)) (x : Vec) : f x=g x := by
  have h := linear_compare_sum f g hf hg hb (List.finRange 24) x
  simpa only [unit_expansion] using h

theorem bilinear_basis_ext (B C : Vec → Vec → Bool)
    (hBl : ∀ y, BoolLinear (fun x => B x y)) (hBr : ∀ x, BoolLinear (B x))
    (hCl : ∀ y, BoolLinear (fun x => C x y)) (hCr : ∀ x, BoolLinear (C x))
    (hb : ∀ j k, B (unit j) (unit k)=C (unit j) (unit k)) (x y : Vec) : B x y=C x y := by
  apply linear_basis_ext (fun x => B x y) (fun x => C x y) (hBl y) (hCl y) _ x
  intro j
  exact linear_basis_ext (B (unit j)) (C (unit j)) (hBr _) (hCr _) (hb j) y

theorem term_shear_add (t : Term) (x y : Vec) : termShear t (add x y)=add (termShear t x) (termShear t y) := by
  cases t <;> funext k <;>
    simp only [termShear,dot_add,add,scale,Bool.and_xor_distrib_right] <;>
    simp only [Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem shear_add (ts : List Term) (x y : Vec) : shear ts (add x y)=add (shear ts x) (shear ts y) := by
  induction ts with
  | nil => exact (add_self zero).symm
  | cons t ts ih =>
    simp only [shear,term_shear_add,ih]
    funext k
    simp only [add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem recipe_left_linear (ts : List Term) (y : Vec) : BoolLinear (fun x => dot x (shear ts y)) :=
  fun x z => dot_add_left x z _

theorem recipe_right_linear (ts : List Term) (x : Vec) : BoolLinear (fun y => dot x (shear ts y)) := by
  intro y z
  change dot x (shear ts (add y z))=(dot x (shear ts y) ^^ dot x (shear ts z))
  rw [shear_add,dot_add]

def gramDefect (c : Chart) (x y : Vec) : Bool := dot (c.forward x) (c.forward y) ^^ dot x y

theorem gram_left_linear (c : Chart) (y : Vec) : BoolLinear (fun x => gramDefect c x y) := by
  intro x z
  simp only [gramDefect,c.forward_add,dot_add_left,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem gram_right_linear (c : Chart) (x : Vec) : BoolLinear (gramDefect c x) := by
  intro y z
  simp only [gramDefect,c.forward_add,dot_add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

def basisCheck (c : Chart) (ts : List Term) : Bool :=
  (List.finRange 24).all (fun j => (List.finRange 24).all (fun k =>
    decide (dot (unit j) (shear ts (unit k))=gramDefect c (unit j) (unit k))))

theorem basis_check_sound (c : Chart) (ts : List Term) (h : basisCheck c ts=true) : GramCompatible c ts := by
  apply bilinear_basis_ext (fun x y => dot x (shear ts y)) (gramDefect c)
    (recipe_left_linear ts) (recipe_right_linear ts) (gram_left_linear c) (gram_right_linear c)
  intro j k
  have hj := List.all_eq_true.mp h j (List.mem_ofFn.mpr ⟨j,rfl⟩)
  have hk := List.all_eq_true.mp hj k (List.mem_ofFn.mpr ⟨k,rfl⟩)
  exact of_decide_eq_true hk

end BinaryBilinearCertificate
#print axioms BinaryBilinearCertificate.sum_units_dot
#print axioms BinaryBilinearCertificate.unit_expansion
#print axioms BinaryBilinearCertificate.bool_linear_zero
#print axioms BinaryBilinearCertificate.linear_compare_sum
#print axioms BinaryBilinearCertificate.linear_basis_ext
#print axioms BinaryBilinearCertificate.bilinear_basis_ext
#print axioms BinaryBilinearCertificate.term_shear_add
#print axioms BinaryBilinearCertificate.shear_add
#print axioms BinaryBilinearCertificate.recipe_left_linear
#print axioms BinaryBilinearCertificate.recipe_right_linear
#print axioms BinaryBilinearCertificate.gram_left_linear
#print axioms BinaryBilinearCertificate.gram_right_linear
#print axioms BinaryBilinearCertificate.basis_check_sound
