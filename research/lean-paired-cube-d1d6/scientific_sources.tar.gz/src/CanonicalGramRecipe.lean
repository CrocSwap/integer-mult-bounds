import BinaryBilinearCertificate
namespace CanonicalGramRecipe
open BinarySpace24 FourthRootRecipe FourthRootLift BinaryBilinearCertificate Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def row (c : Chart) (j : Index) : Vec := fun k => c.forward (unit k) j

theorem row_value (c : Chart) (j : Index) (x : Vec) : dot (row c j) x=c.forward x j := by
  apply linear_basis_ext (fun x => dot (row c j) x) (fun x => c.forward x j)
  · exact fun y z => dot_add _ y z
  · intro y z
    exact congrFun (c.forward_add y z) j
  · intro k
    rw [dot_unit_right]
    rfl

theorem phase_append (i : F) (as bs : List Term) (x : Vec) :
    phase i (as++bs) x=phase i as x*phase i bs x := by
  induction as with
  | nil => simp only [List.nil_append,phase,Semiring.one_mul]
  | cons a as ih => simp only [List.cons_append,phase,ih,Semiring.mul_assoc]

theorem shear_append (as bs : List Term) (x : Vec) :
    shear (as++bs) x=add (shear as x) (shear bs x) := by
  induction as with
  | nil => simp only [List.nil_append,shear,zero_add]
  | cons a as ih => simp only [List.cons_append,shear,ih,add_assoc]

def rowTerms (c : Chart) (js : List Index) : List Term := js.map (fun j => .diagonal (row c j))
def unitTerms (js : List Index) : List Term := js.map (fun j => .diagonal (unit j))
def inverseUnitTerms : List Index → List Term
  | [] => []
  | j::js => .diagonal (unit j) :: .cross (unit j) (unit j) :: inverseUnitTerms js

def terms (c : Chart) : List Term := rowTerms c (List.finRange 24)++inverseUnitTerms (List.finRange 24)
def coordinatePhase (i : F) (x : Vec) : F := phase i (unitTerms (List.finRange 24)) x

theorem root_times_sign (i : F) (b : Bool) : rootPhase i b*QuadraticPhase.sign b=rootPhase (-i) b := by
  cases b <;> simp only [rootPhase,QuadraticPhase.sign,Bool.false_eq_true,if_false,if_true] <;> grind

theorem row_terms_polar (c : Chart) (js : List Index) (x u : Vec) :
    dot x (shear (rowTerms c js) u)=dotList js (c.forward x) (c.forward u) := by
  induction js with
  | nil => exact dot_zero x
  | cons j js ih =>
    simp only [rowTerms] at ih
    simp only [rowTerms,List.map_cons,shear,termShear,dot_add,dot_scale,dot_symmetric x (row c j),row_value,ih,dotList,Bool.and_comm]

theorem inverse_unit_shear (js : List Index) (x : Vec) : shear (inverseUnitTerms js) x=sumUnits js x := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    simp only [inverseUnitTerms,shear,termShear,dot_unit,add_self,zero_add,ih,sumUnits]

theorem canonical_gram_compatible (c : Chart) : GramCompatible c (terms c) := by
  intro x u
  rw [terms,shear_append,dot_add,row_terms_polar,inverse_unit_shear,unit_expansion]
  rfl

theorem row_terms_phase (i : F) (c : Chart) (js : List Index) (x : Vec) :
    phase i (rowTerms c js) x=phase i (unitTerms js) (c.forward x) := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    simp only [rowTerms,unitTerms] at ih
    simp only [rowTerms,unitTerms,List.map_cons,phase,termPhase,dot_unit,row_value,ih]

theorem inverse_unit_phase (i : F) (js : List Index) (x : Vec) :
    phase i (inverseUnitTerms js) x=phase (-i) (unitTerms js) x := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    simp only [inverseUnitTerms,unitTerms,List.map_cons,phase,termPhase,dot_unit,Bool.and_self,ih]
    rw [← Semiring.mul_assoc,root_times_sign]

theorem canonical_phase_formula (i : F) (c : Chart) (x : Vec) :
    phase i (terms c) x=coordinatePhase i (c.forward x)*coordinatePhase (-i) x := by
  rw [terms,phase_append,row_terms_phase,inverse_unit_phase]
  rfl

theorem coordinate_phase_inverse (i : F) (hi : i*i= -1) (x : Vec) :
    coordinatePhase (-i) x*coordinatePhase i x=1 := phase_inverse i hi _ x

theorem canonical_inverse_phase_formula (i : F) (c : Chart) (x : Vec) :
    phase (-i) (terms c) x=coordinatePhase (-i) (c.forward x)*coordinatePhase i x := by
  rw [canonical_phase_formula,Ring.neg_neg]

end CanonicalGramRecipe
#print axioms CanonicalGramRecipe.row_value
#print axioms CanonicalGramRecipe.phase_append
#print axioms CanonicalGramRecipe.shear_append
#print axioms CanonicalGramRecipe.root_times_sign
#print axioms CanonicalGramRecipe.row_terms_polar
#print axioms CanonicalGramRecipe.inverse_unit_shear
#print axioms CanonicalGramRecipe.canonical_gram_compatible
#print axioms CanonicalGramRecipe.row_terms_phase
#print axioms CanonicalGramRecipe.inverse_unit_phase
#print axioms CanonicalGramRecipe.canonical_phase_formula
#print axioms CanonicalGramRecipe.coordinate_phase_inverse
#print axioms CanonicalGramRecipe.canonical_inverse_phase_formula
