import CompletionData
namespace CompletionCheck007
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch007.all CompletionCertificates.check=true := by decide
end CompletionCheck007
#print axioms CompletionCheck007.valid
