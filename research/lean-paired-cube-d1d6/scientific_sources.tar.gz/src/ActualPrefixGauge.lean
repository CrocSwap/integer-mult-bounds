import PrefixGaugeCheck000
import PrefixGaugeCheck001
import PrefixGaugeCheck002
import PrefixGaugeCheck003
import PrefixGaugeCheck004
import PrefixGaugeCheck005
import PrefixGaugeCheck006
import PrefixGaugeCheck007
import PrefixGaugeCheck008
import PrefixGaugeCheck009
import PrefixGaugeCheck010
import PrefixGaugeCheck011
import PrefixGaugeCheck012
import PrefixGaugeCheck013
import TwoRoleProgram
namespace ActualPrefixGauge
open PairedWord (Step)
open GaugeKeyTrace
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def initialSteps : List Step := (PairedWordData.chunks.take 13).flatten++PairedWordData.chunk013.take 192

theorem chunks_first13 : PairedWordData.chunks.take 13=[PairedWordData.chunk000, PairedWordData.chunk001, PairedWordData.chunk002, PairedWordData.chunk003, PairedWordData.chunk004, PairedWordData.chunk005, PairedWordData.chunk006, PairedWordData.chunk007, PairedWordData.chunk008, PairedWordData.chunk009, PairedWordData.chunk010, PairedWordData.chunk011, PairedWordData.chunk012] := rfl

theorem prefix_chunks : initialSteps=PrefixGaugeCheck000.steps ++ PrefixGaugeCheck001.steps ++ PrefixGaugeCheck002.steps ++ PrefixGaugeCheck003.steps ++ PrefixGaugeCheck004.steps ++ PrefixGaugeCheck005.steps ++ PrefixGaugeCheck006.steps ++ PrefixGaugeCheck007.steps ++ PrefixGaugeCheck008.steps ++ PrefixGaugeCheck009.steps ++ PrefixGaugeCheck010.steps ++ PrefixGaugeCheck011.steps ++ PrefixGaugeCheck012.steps ++ PrefixGaugeCheck013.steps := by
  unfold initialSteps
  rw [chunks_first13]
  simp only [List.flatten_cons,List.flatten_nil,List.append_nil,List.append_assoc]
  rfl

theorem actual_prefix : PairedWordData.word.take 3520=initialSteps := by
  have he : PairedWordData.word=(PairedWordData.chunks.take 13).flatten++(PairedWordData.chunks.drop 13).flatten := by
    rw [← List.flatten_append,List.take_append_drop]
    rfl
  have htail : PairedWordData.chunks.drop 13=PairedWordData.chunk013::PairedWordData.chunks.drop 14 := rfl
  have hlen : ((PairedWordData.chunks.take 13).flatten).length+192=3520 := by
    rw [PlaneEventBinding.prefix_length]
  rw [he,← hlen,List.take_append,htail,List.flatten_cons,
    List.take_append_of_le_length (by decide)]
  rfl

theorem prefix_length : initialSteps.length=3520 := by
  rw [← actual_prefix,List.length_take,PairedWordData.word_length]
  rfl

theorem prefix_checked : initialSteps.all checked=true := by
  rw [prefix_chunks]
  simp only [List.all_append,PrefixGaugeCheck000.checked,PrefixGaugeCheck001.checked,PrefixGaugeCheck002.checked,PrefixGaugeCheck003.checked,PrefixGaugeCheck004.checked,PrefixGaugeCheck005.checked,PrefixGaugeCheck006.checked,PrefixGaugeCheck007.checked,PrefixGaugeCheck008.checked,PrefixGaugeCheck009.checked,PrefixGaugeCheck010.checked,PrefixGaugeCheck011.checked,PrefixGaugeCheck012.checked,PrefixGaugeCheck013.checked,Bool.true_and]

theorem zero_touches : initialSteps.filter (touches 0)=[⟨1,0,1,false⟩,⟨2,0,1,false⟩] := by
  rw [prefix_chunks]
  simp only [List.filter_append,PrefixGaugeCheck000.touches_zero,PrefixGaugeCheck001.touches_zero,PrefixGaugeCheck002.touches_zero,PrefixGaugeCheck003.touches_zero,PrefixGaugeCheck004.touches_zero,PrefixGaugeCheck005.touches_zero,PrefixGaugeCheck006.touches_zero,PrefixGaugeCheck007.touches_zero,PrefixGaugeCheck008.touches_zero,PrefixGaugeCheck009.touches_zero,PrefixGaugeCheck010.touches_zero,PrefixGaugeCheck011.touches_zero,PrefixGaugeCheck012.touches_zero,PrefixGaugeCheck013.touches_zero,List.append_nil,List.nil_append]

theorem three_touches : initialSteps.filter (touches 3)=[⟨4,3,2,false⟩,⟨5,3,2,false⟩] := by
  rw [prefix_chunks]
  simp only [List.filter_append,PrefixGaugeCheck000.touches_three,PrefixGaugeCheck001.touches_three,PrefixGaugeCheck002.touches_three,PrefixGaugeCheck003.touches_three,PrefixGaugeCheck004.touches_three,PrefixGaugeCheck005.touches_three,PrefixGaugeCheck006.touches_three,PrefixGaugeCheck007.touches_three,PrefixGaugeCheck008.touches_three,PrefixGaugeCheck009.touches_three,PrefixGaugeCheck010.touches_three,PrefixGaugeCheck011.touches_three,PrefixGaugeCheck012.touches_three,PrefixGaugeCheck013.touches_three,List.append_nil,List.nil_append]

theorem actual_first_four : PairedWordData.word[0]?=some ⟨1,0,1,false⟩ ∧
    PairedWordData.word[1]?=some ⟨2,0,1,false⟩ ∧
    PairedWordData.word[2]?=some ⟨4,3,2,false⟩ ∧
    PairedWordData.word[3]?=some ⟨5,3,2,false⟩ := ⟨rfl,rfl,rfl,rfl⟩

theorem incoming_keys (g : State) (h0 : g 0=1) (h3 : g 3=2) :
    run (PairedWordData.word.take 3520) g 0=1 ∧ run (PairedWordData.word.take 3520) g 3=2 := by
  rw [actual_prefix]
  exact checked_sound initialSteps prefix_checked g h0 h3

theorem after_event_keys (g : State) : update PlaneEventBinding.event g 0=1981 ∧
    update PlaneEventBinding.event g 3=1981 := by
  simp only [update,touches,PlaneEventBinding.event]
  change ActualFrameKeys.key PlaneEventBinding.event=1981 ∧ ActualFrameKeys.key PlaneEventBinding.event=1981
  exact ⟨PlaneEventBinding.event_key,PlaneEventBinding.event_key⟩

end ActualPrefixGauge
#print axioms ActualPrefixGauge.chunks_first13
#print axioms ActualPrefixGauge.prefix_chunks
#print axioms ActualPrefixGauge.actual_prefix
#print axioms ActualPrefixGauge.prefix_length
#print axioms ActualPrefixGauge.prefix_checked
#print axioms ActualPrefixGauge.zero_touches
#print axioms ActualPrefixGauge.three_touches
#print axioms ActualPrefixGauge.actual_first_four
#print axioms ActualPrefixGauge.incoming_keys
#print axioms ActualPrefixGauge.after_event_keys
