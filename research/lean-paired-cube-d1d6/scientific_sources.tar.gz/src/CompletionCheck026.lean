import CompletionData
namespace CompletionCheck026
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch026.all CompletionCertificates.check=true := by decide
end CompletionCheck026
#print axioms CompletionCheck026.valid
