import CompletionDeterminism
namespace CompletionColumns
open BinarySpace24 BinaryCompletion CompletionCertificates PrivateShear TensorThree

theorem index_bound (axis : Axis) : (index axis).val<3 := by cases axis <;> decide

theorem complement_columns (c : Witness) (hc : Facts c) (j : Index) (hj : 3≤j.val) :
    fullMap c hc (unit j)=unit (forward c j) := by
  have hne (axis : Axis) : forward c j ≠ pivot c axis := by
    intro h
    have he := congrArg (inverse c) h
    simp only [pivot,hc.left] at he
    have hb := index_bound axis
    have hv := congrArg Fin.val he
    omega
  have hz : coefficients (pivot c) (unit (forward c j))=(false,false,false) := by
    simp [coefficients,unit,hne]
  unfold fullMap G
  rw [permute_unit,shear,hz,combine_zero,add_zero]

theorem full_map_injective (c : Witness) (hc : Facts c) (x y : Vec) (h : fullMap c hc x=fullMap c hc y) : x=y := by
  have he := congrArg (fullInverse c hc) h
  simpa only [full_inverse_left] using he

theorem full_map_kernel (c : Witness) (hc : Facts c) (x : Vec) : fullMap c hc x=zero ↔ x=zero := by
  constructor
  · intro h
    apply full_map_injective c hc x zero
    rw [h]
    exact (G_zero _ _ _).symm
  · intro h; subst x; exact G_zero _ _ _

theorem full_map_surjective (c : Witness) (hc : Facts c) (y : Vec) :
    ∃ x, fullMap c hc x=y ∧ ∀ z, fullMap c hc z=y → z=x := by
  refine ⟨fullInverse c hc y,full_inverse_right c hc y,?_⟩
  intro z hz
  exact full_map_injective c hc z _ (hz.trans (full_inverse_right c hc y).symm)

end CompletionColumns
#print axioms CompletionColumns.index_bound
#print axioms CompletionColumns.complement_columns
#print axioms CompletionColumns.full_map_injective
#print axioms CompletionColumns.full_map_kernel
#print axioms CompletionColumns.full_map_surjective
