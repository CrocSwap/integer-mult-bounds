import VariablePilotCheck000
import VariablePilotCheck001
import VariablePilotCheck002
import VariablePilotCheck003
import VariableOrderedColumns
namespace ActualVariablePilot
open BinarySpace24 VariableCertificates VariableOrderedColumns FourthRootLift CanonicalGramRecipe CanonicalFourthRootLift Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem all_valid : VariablePilotData.certificates.all check=true := by
  simp only [VariablePilotData.certificates,List.all_flatten,VariablePilotData.batches,List.all_cons,List.all_nil,
    VariablePilotCheck000.valid,VariablePilotCheck001.valid,VariablePilotCheck002.valid,VariablePilotCheck003.valid]
  rfl

theorem pilot_count : VariablePilotData.certificates.length=32 := by decide

def facts (c : Witness) (hc : c ∈ VariablePilotData.certificates) : Facts c :=
  check_sound c (List.all_eq_true.mp all_valid c hc)

theorem all_chart_inverses (c : Witness) (hc : c ∈ VariablePilotData.certificates) (x : Vec) :
    (chart c (facts c hc)).inverse ((chart c (facts c hc)).forward x)=x ∧
      (chart c (facts c hc)).forward ((chart c (facts c hc)).inverse x)=x := full_inverses c _ x

theorem all_ordered_columns (c : Witness) (hc : c ∈ VariablePilotData.certificates) (j : Index) :
    (∀ hj : j.val<c.slots.length, (chart c (facts c hc)).forward (unit j)=CompletionFrames.fromNat (c.slots[j.val]'hj).2) ∧
    (c.slots.length≤j.val → (chart c (facts c hc)).forward (unit j)=unit (forward c j)) :=
  ⟨ordered_source_column c _ j,ordered_complement_column c _ j⟩

theorem all_exact_lift_inverses (i : F) (hi : i*i= -1) (c : Witness) (hc : c ∈ VariablePilotData.certificates) (f : Vec → F) :
    Kinv i (chart c (facts c hc)) (K i (chart c (facts c hc)) f)=f ∧
    K i (chart c (facts c hc)) (Kinv i (chart c (facts c hc)) f)=f :=
  ⟨K_inverse_left i hi _ f,K_inverse_right i hi _ f⟩

theorem all_exact_Pauli_actions (i : F) (hi : i*i= -1) (c : Witness) (hc : c ∈ VariablePilotData.certificates)
    (u z : Vec) (f : Vec → F) :
    K i (chart c (facts c hc)) (ExactQuadraticLift.pauli u z (Kinv i (chart c (facts c hc)) f))=
      fun y => (coordinatePhase (-i) ((chart c (facts c hc)).forward u)*coordinatePhase i u)*
        ExactQuadraticLift.pauli (label (chart c (facts c hc)) (u,z)).1 (label (chart c (facts c hc)) (u,z)).2 f y :=
  K_Pauli i hi _ u z f

end ActualVariablePilot
#print axioms ActualVariablePilot.all_valid
#print axioms ActualVariablePilot.pilot_count
#print axioms ActualVariablePilot.all_chart_inverses
#print axioms ActualVariablePilot.all_ordered_columns
#print axioms ActualVariablePilot.all_exact_lift_inverses
#print axioms ActualVariablePilot.all_exact_Pauli_actions
