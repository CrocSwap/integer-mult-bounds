import PiecewiseSelector
namespace ExactGaugeAdapter
open BinarySpace24 BinaryCompletion CertifiedRepresentative Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F] {U : Vec → Prop}

def inversePhase (r : Rep F U) (v : Vec × Vec) : F :=
  let a := r.phase (r.label v)
  a*(a*a)
def adapter (A B : Rep F U) (f : Vec → F) := B.encode (A.decode f)
def label (A B : Rep F U) (v : Vec × Vec) := B.label (A.label v)
def phase (A B : Rep F U) (v : Vec × Vec) := inversePhase A v*B.phase (A.label v)

theorem encode_injective (r : Rep F U) (f g : Vec → F) (h : r.encode f=r.encode g) : f=g := by
  have he := congrArg r.decode h
  simpa only [r.left_inverse] using he

theorem inverse_phase_cancel (r : Rep F U) (v : Vec × Vec) : inversePhase r v*r.phase (r.label v)=1 := by
  have h := r.phase_fourth (r.label v)
  simp only [inversePhase]
  grind

theorem inverse_pullthrough (r : Rep F U) (v : Vec × Vec) (f : Vec → F) :
    r.decode (ExactQuadraticLift.pauli v.1 v.2 f)=fun x => inversePhase r v*
      ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 (r.decode f) x := by
  apply encode_injective r
  rw [r.right_inverse,r.scale_linear,r.pullthrough,r.label_involution,r.right_inverse]
  funext x
  rw [← Semiring.mul_assoc,inverse_phase_cancel,Semiring.one_mul]

theorem exact_pullthrough (A B : Rep F U) (v : Vec × Vec) (f : Vec → F) :
    adapter A B (ExactQuadraticLift.pauli v.1 v.2 f)=fun x => phase A B v*
      ExactQuadraticLift.pauli (label A B v).1 (label A B v).2 (adapter A B f) x := by
  unfold adapter
  rw [inverse_pullthrough,B.scale_linear,B.pullthrough]
  funext x
  simp only [phase,label,Semiring.mul_assoc]

theorem inverse_left (A B : Rep F U) (f : Vec → F) : adapter B A (adapter A B f)=f := by
  simp only [adapter,B.left_inverse,A.right_inverse]

theorem inverse_right (A B : Rep F U) (f : Vec → F) : adapter A B (adapter B A f)=f := by
  simp only [adapter,A.left_inverse,B.right_inverse]

theorem exact_conjugation (A B : Rep F U) (v : Vec × Vec) (f : Vec → F) :
    adapter A B (ExactQuadraticLift.pauli v.1 v.2 (adapter B A f))=fun x => phase A B v*
      ExactQuadraticLift.pauli (label A B v).1 (label A B v).2 f x := by
  rw [exact_pullthrough,inverse_right]

theorem rank_zero (A B : Rep F U) (v : Vec × Vec) (hv : v.1=zero) : (label A B v).1=zero := by
  apply (B.preimage (A.label v)).mpr
  apply (A.preimage (A.label v)).mp
  rw [A.label_involution]
  exact hv

theorem inverse_labels (A B : Rep F U) (v : Vec × Vec) : label B A (label A B v)=v := by
  simp only [label,B.label_involution,A.label_involution]

theorem phase_fourth (A B : Rep F U) (v : Vec × Vec) :
    (phase A B v*phase A B v)*(phase A B v*phase A B v)=1 := by
  have h0 := A.phase_fourth (A.label v)
  have h1 := B.phase_fourth (A.label v)
  simp only [phase,inversePhase]
  grind

theorem exact_alignment (A B : Rep F U) (f : Vec → F) : adapter A B (A.encode f)=B.encode f := by
  rw [adapter,A.left_inverse]

theorem exact_common_mix (A B C : Rep F U) (a b : F) (f g : Vec → F) :
    CommonExactFrame.mix a b (adapter A C (A.encode f)) (adapter B C (B.encode g))=
      C.encode (CommonExactFrame.mix a b f g) := by
  rw [exact_alignment,exact_alignment]
  exact CommonExactFrame.common_mix C.toExactFrame a b f g

end ExactGaugeAdapter
#print axioms ExactGaugeAdapter.encode_injective
#print axioms ExactGaugeAdapter.inverse_phase_cancel
#print axioms ExactGaugeAdapter.inverse_pullthrough
#print axioms ExactGaugeAdapter.exact_pullthrough
#print axioms ExactGaugeAdapter.inverse_left
#print axioms ExactGaugeAdapter.inverse_right
#print axioms ExactGaugeAdapter.exact_conjugation
#print axioms ExactGaugeAdapter.rank_zero
#print axioms ExactGaugeAdapter.inverse_labels
#print axioms ExactGaugeAdapter.phase_fourth
#print axioms ExactGaugeAdapter.exact_alignment
#print axioms ExactGaugeAdapter.exact_common_mix
