import ExactQuadraticLift
import ActualCompletion
namespace ActualQuadraticLifts
open BinarySpace24 CompletionCertificates CompletionFrames ActualCompletion GramQuadratic ExactQuadraticLift Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem all_inverses (c : Witness) (hc : c ∈ CompletionData.certificates) (f : Vec → F) :
    unlift c (facts c hc) (lift c (facts c hc) f)=f ∧
    lift c (facts c hc) (unlift c (facts c hc) f)=f :=
  ⟨ExactQuadraticLift.inverse_left c _ f,ExactQuadraticLift.inverse_right c _ f⟩

theorem all_pauli_actions (c : Witness) (hc : c ∈ CompletionData.certificates) (u z : Vec) (f : Vec → F) :
    lift c (facts c hc) (pauli u z (unlift c (facts c hc) f))=
      fun y => QuadraticPhase.sign (quadratic c (facts c hc) u)*
        pauli (blockMap c (facts c hc) (u,z)).1 (blockMap c (facts c hc) (u,z)).2 f y :=
  ExactQuadraticLift.pauli_conjugation c _ (source_member c hc) u z f

theorem all_zero_phases (c : Witness) (hc : c ∈ CompletionData.certificates) :
    quadratic c (facts c hc) zero=false := full_zero c _

theorem all_basis_phases (c : Witness) (hc : c ∈ CompletionData.certificates) (j : Index) :
    quadratic c (facts c hc) (unit j)=false := full_basis_zero c _ j

theorem all_carrier_restrictions (c : Witness) (hc : c ∈ CompletionData.certificates)
    (bits : CarrierCoordinates.Coordinates) (f : Vec → F) :
    lift c (facts c hc) f (fromNat (ActualCarrierCharts.encode c.cube c.parity bits))=
      QuadraticPhase.sign (QuadraticPhase.quadratic bits)*f (coordinates bits) :=
  lift_on_actual_carrier c _ bits f

theorem all_gram_polarizations (c : Witness) (hc : c ∈ CompletionData.certificates) (x y : Vec) :
    quadratic c (facts c hc) (add x y)=(quadratic c (facts c hc) x ^^ quadratic c (facts c hc) y ^^
      (dot (fullMap c (facts c hc) x) (fullMap c (facts c hc) y) ^^ dot x y)) :=
  full_polar c _ (source_member c hc) x y

theorem actual_full_lift (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    ∃ c, c.cube=cube ∧ c.parity=parity ∧ ∃ h : Facts c,
      (∀ f : Vec → F, unlift c h (lift c h f)=f ∧ lift c h (unlift c h f)=f) ∧
      (∀ u z (f : Vec → F), lift c h (pauli u z (unlift c h f))=
        fun y => QuadraticPhase.sign (quadratic c h u)*pauli (blockMap c h (u,z)).1 (blockMap c h (u,z)).2 f y) := by
  rcases source_coverage cube hc parity with ⟨c,hm,he,hp⟩
  exact ⟨c,he,hp,facts c hm,all_inverses c hm,all_pauli_actions c hm⟩

end ActualQuadraticLifts
#print axioms ActualQuadraticLifts.all_inverses
#print axioms ActualQuadraticLifts.all_pauli_actions
#print axioms ActualQuadraticLifts.all_zero_phases
#print axioms ActualQuadraticLifts.all_basis_phases
#print axioms ActualQuadraticLifts.all_carrier_restrictions
#print axioms ActualQuadraticLifts.all_gram_polarizations
#print axioms ActualQuadraticLifts.actual_full_lift
