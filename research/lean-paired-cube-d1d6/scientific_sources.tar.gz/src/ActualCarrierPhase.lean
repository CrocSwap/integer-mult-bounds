import ActualCarrierGram
import QuadraticPhase
import ActualCarrierGate
namespace ActualCarrierPhase
open CarrierCoordinates ActualCarrierCharts ActualCarrierGate TensorThree QuadraticPhase ActualCarrierGram Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def axisIndex : Axis → Nat
  | .first => 0
  | .second => 1
  | .third => 2

theorem axisIndex_bound (axis : Axis) : axisIndex axis<3 := by cases axis <;> decide

def defectCharacter (cube : List Nat) (parity : Bool) (axis : Axis) (c : Coordinates) : Bool :=
  (gramDefect cube parity (axisIndex axis) 0 && c.1) ^^
  (gramDefect cube parity (axisIndex axis) 1 && c.2.1) ^^
  (gramDefect cube parity (axisIndex axis) 2 && c.2.2)

theorem actual_defect_character (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool)
    (axis : Axis) (c : Coordinates) : defectCharacter cube parity axis c=neighbor axis c := by
  unfold defectCharacter
  rw [actual_gram_defect cube hc parity (axisIndex axis) 0 (axisIndex_bound axis) (by decide),
      actual_gram_defect cube hc parity (axisIndex axis) 1 (axisIndex_bound axis) (by decide),
      actual_gram_defect cube hc parity (axisIndex axis) 2 (axisIndex_bound axis) (by decide)]
  cases axis <;> simp [axisIndex,neighbor]

theorem actual_pauli_conjugation (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool)
    (axis : Axis) (f : Coordinates → F) :
    diagonal (shift axis (diagonal f))=modulate (defectCharacter cube parity axis) (shift axis f) := by
  have he : defectCharacter cube parity axis=neighbor axis :=
    funext (actual_defect_character cube hc parity axis)
  rw [he]
  exact pauli_conjugation axis f

theorem actual_shift_intertwine (cube : List Nat) (parity : Bool) (axis : Axis) (f : Nat → F) :
    shift axis (restrict cube parity f)=restrict cube parity (fun x => f (x ^^^ direction cube parity axis)) := by
  funext c
  simp only [shift,restrict,encode,direction,chart_flip]

theorem actual_generator_phase (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool)
    (axis : Axis) (f : Nat → F) :
    diagonal (shift axis (diagonal (restrict cube parity f)))=
      modulate (defectCharacter cube parity axis)
        (restrict cube parity (fun x => f (x ^^^ direction cube parity axis))) := by
  rw [actual_pauli_conjugation cube hc parity,actual_shift_intertwine]

theorem actual_corrected_square (i : F) (hi : i*i= -1) (htwo : (2:F) ≠ 0)
    (cube : List Nat) (parity : Bool) (f : Nat → F) (c : Coordinates) :
    corrected i (corrected i (restrict cube parity f)) c=
      -f (encode cube parity c ^^^ (q cube parity 0 ^^^ q cube parity 1 ^^^ q cube parity 2)) := by
  rw [corrected_square i hi htwo]
  simp only [restrict,encode,chart_flip_all]

theorem actual_quadratic_connection (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    (∀ j k, j<3 → k<3 → BinaryPort.dot 24 (q cube parity j) (q cube parity k)=true) ∧
    (∀ axis (f : Coordinates → F), diagonal (shift axis (diagonal f))=
      modulate (defectCharacter cube parity axis) (shift axis f)) :=
  ⟨actual_gram cube hc parity,actual_pauli_conjugation cube hc parity⟩

end ActualCarrierPhase
#print axioms ActualCarrierPhase.axisIndex_bound
#print axioms ActualCarrierPhase.actual_defect_character
#print axioms ActualCarrierPhase.actual_pauli_conjugation
#print axioms ActualCarrierPhase.actual_shift_intertwine
#print axioms ActualCarrierPhase.actual_generator_phase
#print axioms ActualCarrierPhase.actual_corrected_square
#print axioms ActualCarrierPhase.actual_quadratic_connection
