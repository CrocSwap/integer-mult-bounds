import OuterCXPhaseBinding
namespace BaseBitTransposition
open BinarySpace24 BinaryPairEnumeration
variable {V : Type u}

def embed (a b : Bool) (k : Bits 22) : Vec := cons a (cons b k)
def drop (x : Vec) : Bits 22 := tail (tail x)
def swap (x : Vec) : Vec := embed (x 1) (x 0) (drop x)
def exchange (v : V × V) : V × V := (v.2,v.1)

theorem embed0 (a b : Bool) (k : Bits 22) : embed a b k 0=a := rfl
theorem embed1 (a b : Bool) (k : Bits 22) : embed a b k 1=b := rfl

theorem drop_embed (a b : Bool) (k : Bits 22) : drop (embed a b k)=k := rfl

theorem reconstruct (x : Vec) : embed (x 0) (x 1) (drop x)=x := by
  change cons (x 0) (cons ((tail x) 0) (tail (tail x)))=x
  rw [cons_tail,cons_tail]

theorem swap_twice (x : Vec) : swap (swap x)=x := by
  simp only [swap,embed0,embed1,drop_embed,reconstruct]

theorem swap_embed (a b : Bool) (k : Bits 22) : swap (embed a b k)=embed b a k := rfl

theorem swap_fixed (x : Vec) (h : x 0=x 1) : swap x=x := by
  rw [swap,← h]
  have hh:=reconstruct x
  rw [← h] at hh
  exact hh

def geometry : DisjointPairLoop.Geometry (embed false true) (embed true false) where
  left_injective := fun x y h=>congrArg drop h
  right_injective := fun x y h=>congrArg drop h
  disjoint := by
    intro x y h
    have hh:=congrFun h 0
    contradiction

theorem from_pairs_and_fixed (m f : Vec → V)
    (hp : ∀k : Bits 22,(m (embed false true k),m (embed true false k))=
      exchange (f (embed false true k),f (embed true false k)))
    (hf : ∀x : Vec,x 0=x 1→m x=f x) : m=fun x=>f (swap x) := by
  funext x
  have he:=reconstruct x
  have hh:=hp (drop x)
  cases h0 : x 0 <;> cases h1 : x 1
  · rw [swap_fixed x (by rw [h0,h1])]
    exact hf x (by rw [h0,h1])
  · rw [h0,h1] at he
    rw [← he,swap_embed]
    exact congrArg Prod.fst hh
  · rw [h0,h1] at he
    rw [← he,swap_embed]
    exact congrArg Prod.snd hh
  · rw [swap_fixed x (by rw [h0,h1])]
    exact hf x (by rw [h0,h1])

theorem fixed_outside (x : Vec) (h : x 0=x 1) (k : Bits 22) :
    x≠embed false true k ∧ x≠embed true false k := by
  constructor <;> intro he <;> rw [he] at h <;> contradiction

end BaseBitTransposition
#print axioms BaseBitTransposition.embed0
#print axioms BaseBitTransposition.embed1
#print axioms BaseBitTransposition.drop_embed
#print axioms BaseBitTransposition.reconstruct
#print axioms BaseBitTransposition.swap_twice
#print axioms BaseBitTransposition.swap_embed
#print axioms BaseBitTransposition.swap_fixed
#print axioms BaseBitTransposition.from_pairs_and_fixed
#print axioms BaseBitTransposition.fixed_outside
