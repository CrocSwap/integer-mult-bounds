import CoordinateWord
namespace CoordinateWordFrames
open BinarySpace24 BinaryCompletion BinaryBilinearCertificate CoordinateWord

def Space (js : List Index) (x : Vec) : Prop := ∀ j, j ∉ js → x j=false

theorem projection_value (js : List Index) (hn : js.Nodup) (z : Vec) (k : Index) :
    projection js z k=if k ∈ js then z k else false := by
  rw [projection,sum_units_dot,dotList_symmetric]
  by_cases hk : k ∈ js
  · rw [if_pos hk,dotList_unit_present js hn k hk]
  · rw [if_neg hk,dotList_unit_absent js k hk]

theorem projection_space (js : List Index) (hn : js.Nodup) (z : Vec) : Space js (projection js z) := by
  intro j hj
  rw [projection_value js hn,if_neg hj]

theorem unit_space (js : List Index) (j : Index) (hj : j ∈ js) : Space js (unit j) := by
  intro k hk
  have he : j≠k := by intro h; subst k; exact hk hj
  simp only [unit,he,decide_false]

theorem dotList_false (js : List Index) (x y : Vec) (h : ∀ k ∈ js, (x k && y k)=false) : dotList js x y=false := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    rw [dotList,h j (by simp),ih (fun k hk => h k (by simp [hk])),Bool.xor_self]

theorem dot_false (x y : Vec) (h : ∀ k, (x k && y k)=false) : dot x y=false :=
  dotList_false _ x y (fun k _ => h k)

theorem frame_projection (js : List Index) (hn : js.Nodup) (v : Vec × Vec) :
    Frame (Space js) v ↔ v.1=projection js v.2 := by
  constructor
  · intro ⟨hx,ho⟩
    funext k
    rw [projection_value js hn]
    by_cases hk : k ∈ js
    · rw [if_pos hk]
      have h := ho (unit k) (unit_space js k hk)
      rw [dot_unit] at h
      change (v.1 k ^^ v.2 k)=false at h
      cases h1 : v.1 k <;> cases h2 : v.2 k <;> simp_all
    · rw [if_neg hk]
      exact hx k hk
  · intro hv
    refine ⟨?_,?_⟩
    · rw [hv]
      exact projection_space js hn v.2
    · intro u hu
      apply dot_false
      intro k
      simp only [add,hv,projection_value js hn]
      by_cases hk : k ∈ js
      · simp only [if_pos hk,Bool.xor_self,Bool.and_false]
      · rw [hu k hk,Bool.false_and]

theorem frame_preimage (js : List Index) (hn : js.Nodup) (v : Vec × Vec) :
    (label js v).1=zero ↔ Frame (Space js) v := by
  change add v.1 (projection js v.2)=zero ↔ _
  rw [CoordinateFrames.add_eq_zero,frame_projection js hn]

theorem label_involution (js : List Index) (v : Vec × Vec) : label js (label js v)=v := by
  simp only [label,add_assoc,add_self,add_zero]

end CoordinateWordFrames
#print axioms CoordinateWordFrames.projection_value
#print axioms CoordinateWordFrames.projection_space
#print axioms CoordinateWordFrames.unit_space
#print axioms CoordinateWordFrames.dotList_false
#print axioms CoordinateWordFrames.dot_false
#print axioms CoordinateWordFrames.frame_projection
#print axioms CoordinateWordFrames.frame_preimage
#print axioms CoordinateWordFrames.label_involution
