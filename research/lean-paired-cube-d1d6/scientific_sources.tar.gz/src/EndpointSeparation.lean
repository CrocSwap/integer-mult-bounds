import EndpointGeometry
namespace EndpointSeparation
open BinarySpace24 EndpointGeometry

theorem hyper_two (p : Vec) : ∃u v, Hyper p u ∧ Hyper p v ∧ u≠zero ∧ v≠zero ∧ u≠v := by
  by_cases h0 : p 0=true
  · let u := add (unit 1) (scale (p 1) (unit 0))
    let v := add (unit 2) (scale (p 2) (unit 0))
    refine ⟨u,v,?_,?_,?_,?_,?_⟩
    · simp only [u,Hyper,dot_add,dot_unit_right,dot_scale,h0,Bool.and_true,Bool.xor_self]
    · simp only [v,Hyper,dot_add,dot_unit_right,dot_scale,h0,Bool.and_true,Bool.xor_self]
    · intro h; have hh := congrFun h 1; simp [u,add,unit,scale,zero] at hh
    · intro h; have hh := congrFun h 2; simp [v,add,unit,scale,zero] at hh
    · intro h; have hh := congrFun h 1; simp [u,v,add,unit,scale] at hh
  · have h0 : p 0=false := by cases h : p 0 <;> simp_all
    by_cases h1 : p 1=true
    · let u := unit 0
      let v := add (unit 2) (scale (p 2) (unit 1))
      refine ⟨u,v,?_,?_,?_,?_,?_⟩
      · exact (dot_unit_right p 0).trans h0
      · simp only [v,Hyper,dot_add,dot_unit_right,dot_scale,h1,Bool.and_true,Bool.xor_self]
      · intro h; have hh := congrFun h 0; simp [u,unit,zero] at hh
      · intro h; have hh := congrFun h 2; simp [v,add,unit,scale,zero] at hh
      · intro h; have hh := congrFun h 0; simp [u,v,add,unit,scale] at hh
    · have h1 : p 1=false := by cases h : p 1 <;> simp_all
      refine ⟨unit 0,unit 1,?_,?_,?_,?_,?_⟩
      · exact (dot_unit_right p 0).trans h0
      · exact (dot_unit_right p 1).trans h1
      · intro h; have hh := congrFun h 0; simp [unit,zero] at hh
      · intro h; have hh := congrFun h 1; simp [unit,zero] at hh
      · intro h; have hh := congrFun h 0; simp [unit] at hh

theorem line_hyper_disjoint (p q : Vec) : Line p≠Hyper q := by
  intro h
  obtain ⟨u,v,hu,hv,hu0,hv0,huv⟩ := hyper_two q
  have hu' : Line p u := h ▸ hu
  have hv' : Line p v := h ▸ hv
  have hup : u=p := hu'.resolve_left hu0
  have hvp : v=p := hv'.resolve_left hv0
  exact huv (hup.trans hvp.symm)

def ZeroSpace (x : Vec) := x=zero
def FullSpace (_ : Vec) := True

theorem zero_full_disjoint : ZeroSpace≠FullSpace := by
  intro h
  have he : ZeroSpace (unit 0) := h ▸ True.intro
  have hh := congrFun he 0
  simp [unit,zero] at hh

theorem line_zero_disjoint (q : Vec) (hq : dot q q=true) : Line q≠ZeroSpace := by
  intro h
  have he : ZeroSpace q := h ▸ Or.inr rfl
  exact norm_nonzero q hq he

theorem hyper_full_disjoint (q : Vec) (hq : dot q q=true) : Hyper q≠FullSpace := by
  intro h
  have he : Hyper q q := h ▸ True.intro
  rw [Hyper,hq] at he
  contradiction

theorem hyper_zero_disjoint (q : Vec) : Hyper q≠ZeroSpace := by
  intro h
  obtain ⟨u,v,hu,hv,hu0,hv0,huv⟩ := hyper_two q
  have he : ZeroSpace u := h ▸ hu
  exact hu0 he

theorem line_full_disjoint (q : Vec) : Line q≠FullSpace := by
  intro h
  have h0 : Line q (unit 0) := h ▸ True.intro
  have h1 : Line q (unit 1) := h ▸ True.intro
  have hn0 : unit 0≠zero := by intro he; have hh := congrFun he 0; simp [unit,zero] at hh
  have hn1 : unit 1≠zero := by intro he; have hh := congrFun he 1; simp [unit,zero] at hh
  have he := (h0.resolve_left hn0).trans (h1.resolve_left hn1).symm
  have hh := congrFun he 0
  simp [unit] at hh

end EndpointSeparation
#print axioms EndpointSeparation.hyper_two
#print axioms EndpointSeparation.line_hyper_disjoint
#print axioms EndpointSeparation.zero_full_disjoint
#print axioms EndpointSeparation.line_zero_disjoint
#print axioms EndpointSeparation.hyper_full_disjoint
#print axioms EndpointSeparation.hyper_zero_disjoint
#print axioms EndpointSeparation.line_full_disjoint
