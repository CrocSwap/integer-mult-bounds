import ActualAlignmentInPlace
namespace CountedConditionalSwap
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

structure Cost where
  memoryLoads : Nat
  memoryStores : Nat
  controlReads : Nat
  valueSelections : Nat
  scalarOperations : Nat
  deriving DecidableEq

def Cost.zero : Cost := ⟨0,0,0,0,0⟩
def Cost.add (a b : Cost) : Cost := ⟨a.memoryLoads+b.memoryLoads,a.memoryStores+b.memoryStores,
  a.controlReads+b.controlReads,a.valueSelections+b.valueSelections,a.scalarOperations+b.scalarOperations⟩

def readControl (c : Index) (k : Bits 23) : Bool × Nat := (ConditionalCXPair.control c k,1)
def selectValue (b : Bool) (v w : V) : V × Nat := (if b then v else w,1)
def compute (c : Index) (k : Bits 23) (v : V × V) : (V × V) × Nat × Nat :=
  let b:=readControl c k
  let l:=selectValue b.1 v.2 v.1
  let r:=selectValue b.1 v.1 v.2
  ((l.1,r.1),b.2,l.2+r.2)

theorem compute_exact (c : Index) (k : Bits 23) (v : V × V) :
    compute c k v=(ConditionalCXPair.op c k v,1,2) := rfl

def loadCode : List PairLoadStoreMachine.Instruction := [.loadLeft,.loadRight]
def storeCode : List PairLoadStoreMachine.Instruction := [.storeLeft,.storeRight]

def pair (c : Index) (k : Bits 23) (s : PairLoadStoreMachine.State Vec V) : PairLoadStoreMachine.State Vec V × Cost :=
  let loaded:=PairLoadStoreMachine.run (embed false) (embed true) (ConditionalCXPair.op c k) k loadCode s
  let out:=compute c k (loaded.left,loaded.right)
  let ready:={loaded with left:=out.1.1,right:=out.1.2}
  let stored:=PairLoadStoreMachine.run (embed false) (embed true) (ConditionalCXPair.op c k) k storeCode ready
  (stored,⟨PairLoadStoreMachine.count PairLoadStoreMachine.loads loadCode,
    PairLoadStoreMachine.count PairLoadStoreMachine.stores storeCode,out.2.1,out.2.2,0⟩)

theorem pair_exact (c : Index) (k : Bits 23) (s : PairLoadStoreMachine.State Vec V) :
    pair c k s=(PairLoadStoreMachine.run (embed false) (embed true) (ConditionalCXPair.op c k) k PairLoadStoreMachine.program s,
      ⟨2,2,1,2,0⟩) := rfl

theorem read_both_first (c : Index) (k : Bits 23) (s : PairLoadStoreMachine.State Vec V) :
    let loaded:=PairLoadStoreMachine.run (embed false) (embed true) (ConditionalCXPair.op c k) k loadCode s
    loaded.memory=s.memory ∧ (loaded.left,loaded.right)=(s.memory (embed false k),s.memory (embed true k)) := ⟨rfl,rfl⟩

theorem unchanged_pair_memory (c : Index) (k : Bits 23) (s : PairLoadStoreMachine.State Vec V)
    (h : ConditionalCXPair.control c k=false) : (pair c k s).1.memory=s.memory := by
  rw [pair_exact,PairLoadStoreMachine.exact_step]
  funext x
  by_cases ht : x=embed true k <;> by_cases hf : x=embed false k <;>
    simp_all [DisjointPairLoop.step,DisjointPairLoop.readPair,ConditionalCXPair.op,ConditionalCXPair.swapIf,DisjointPairLoop.write]

theorem unchanged_pair_cost (c : Index) (k : Bits 23) (s : PairLoadStoreMachine.State Vec V)
    (_h : ConditionalCXPair.control c k=false) : (pair c k s).2=⟨2,2,1,2,0⟩ := rfl

def loop (c : Index) : List (Bits 23) → PairLoadStoreMachine.State Vec V → PairLoadStoreMachine.State Vec V × Cost
  | [],s => (s,Cost.zero)
  | k::ks,s =>
    let next:=pair c k s
    let out:=loop c ks next.1
    (out.1,Cost.add next.2 out.2)

def loopCost (n : Nat) : Cost := ⟨2*n,2*n,n,2*n,0⟩

theorem loop_exact (c : Index) (ks : List (Bits 23)) (s : PairLoadStoreMachine.State Vec V) :
    loop c ks s=(IndexedPairLoop.machine (embed false) (embed true) (ConditionalCXPair.op c) ks s,loopCost ks.length) := by
  induction ks generalizing s with
  | nil => rfl
  | cons k ks ih =>
    simp only [loop,pair_exact,ih,IndexedPairLoop.machine,List.length_cons,loopCost,Cost.add,Nat.mul_add,Nat.mul_one,Nat.add_comm]

theorem actual_loop (c : Index) (s : PairLoadStoreMachine.State Vec V) :
    loop c (addresses 23) s=(ActualAlignmentInPlace.stage c s,⟨16777216,16777216,8388608,16777216,0⟩) := by
  rw [loop_exact,Coordinate21Pairs.pair_count]
  rfl

end CountedConditionalSwap
#print axioms CountedConditionalSwap.compute_exact
#print axioms CountedConditionalSwap.pair_exact
#print axioms CountedConditionalSwap.read_both_first
#print axioms CountedConditionalSwap.unchanged_pair_memory
#print axioms CountedConditionalSwap.unchanged_pair_cost
#print axioms CountedConditionalSwap.loop_exact
#print axioms CountedConditionalSwap.actual_loop
