import CompletionData
namespace CompletionCheck015
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch015.all CompletionCertificates.check=true := by decide
end CompletionCheck015
#print axioms CompletionCheck015.valid
