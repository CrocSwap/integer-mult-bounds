import CompletionData
namespace CompletionCheck012
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch012.all CompletionCertificates.check=true := by decide
end CompletionCheck012
#print axioms CompletionCheck012.valid
