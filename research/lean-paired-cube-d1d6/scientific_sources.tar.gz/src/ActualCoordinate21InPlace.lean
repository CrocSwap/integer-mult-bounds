import PairMemoryReadout
namespace ActualCoordinate21InPlace
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

def geometry : DisjointPairLoop.Geometry (embed false) (embed true) where
  left_injective := embed_injective false
  right_injective := embed_injective true
  disjoint := embed_disjoint

def stage (i : F) (f : Vec → F) (scratchLeft scratchRight : F) :=
  PairLoadStoreMachine.runPairs (embed false) (embed true) (Coordinate21PairProgram.evalPair i)
    (addresses 23) ⟨f,scratchLeft,scratchRight⟩

theorem memory_exact (i : F) (f : Vec → F) (scratchLeft scratchRight : F) :
    (stage i f scratchLeft scratchRight).memory=Coordinate21PairProgram.applyPairs i f := by
  rw [stage,PairLoadStoreMachine.memory_run]
  apply PairMemoryReadout.from_pairs (Coordinate21PairProgram.evalPair i)
  intro y
  have h := DisjointPairLoop.run_pair (embed false) (embed true) geometry (Coordinate21PairProgram.evalPair i)
    (addresses 23) (addresses_nodup 23) f y
  rw [if_pos (all_addresses 23 y)] at h
  exact h

theorem gate_exact (i : F) (f : Vec → F) (scratchLeft scratchRight : F) :
    (stage i f scratchLeft scratchRight).memory=CoordinateChild.gate i 21 f := by
  rw [memory_exact,Coordinate21PairProgram.function_semantics]

theorem actual_event (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (g : GaugeKeyTrace.State)
    (f : Vec → F) (scratchLeft scratchRight : F) :
    CommonExactFrame.adapter (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 3 g 17326))
      (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 4 g 17326)) f=
      ActualQuarterPhase.leftPass i (stage i (ActualQuarterPhase.rightPass i f) scratchLeft scratchRight).memory := by
  rw [memory_exact]
  exact ActualQuarterPhase.actual_event i hi htwo g f

theorem load_store_receipt : PairLoadStoreMachine.loopLoads (addresses 23)=16777216 ∧
    PairLoadStoreMachine.loopStores (addresses 23)=16777216 := by
  have h := PairLoadStoreMachine.loop_receipt (addresses 23)
  rw [Coordinate21Pairs.pair_count] at h
  exact h

theorem old_pair_prepared (i : F) (k : Bits 23) (s : PairLoadStoreMachine.State Vec F) :
    (PairLoadStoreMachine.run (embed false) (embed true) (Coordinate21PairProgram.evalPair i) k
      PairLoadStoreMachine.preparation s).memory=s.memory ∧
    ((PairLoadStoreMachine.run (embed false) (embed true) (Coordinate21PairProgram.evalPair i) k
      PairLoadStoreMachine.preparation s).left,
     (PairLoadStoreMachine.run (embed false) (embed true) (Coordinate21PairProgram.evalPair i) k
      PairLoadStoreMachine.preparation s).right)=
      Coordinate21PairProgram.evalPair i (s.memory (embed false k),s.memory (embed true k)) :=
  ⟨rfl,rfl⟩

end ActualCoordinate21InPlace
#print axioms ActualCoordinate21InPlace.memory_exact
#print axioms ActualCoordinate21InPlace.gate_exact
#print axioms ActualCoordinate21InPlace.actual_event
#print axioms ActualCoordinate21InPlace.load_store_receipt
#print axioms ActualCoordinate21InPlace.old_pair_prepared
