import ActualDecoder
namespace PairedDecoder
open PairedWord

theorem evaluate_congr (terms : List ReadTerm) (x y : State)
    (h : ∀ t ∈ terms, x t.role = y t.role) : evaluate terms x = evaluate terms y := by
  induction terms with
  | nil => rfl
  | cons t ts ih =>
    simp only [evaluate, h t (by simp), ih (fun u hu => h u (by simp [hu]))]

theorem decode6_congr (rows : List (List ReadTerm)) (x y : State)
    (h : ∀ row ∈ rows, ∀ t ∈ row, x t.role = y t.role) : decode6 rows x = decode6 rows y := by
  funext target
  unfold decode6
  cases hr : rows[target]? with
  | none => rfl
  | some row =>
    exact evaluate_congr row x y (h row (List.mem_of_getElem? hr))

theorem actual_decoder_bounded_congr (x y : State)
    (h : ∀ role, role < 26417 → x role = y role) :
    decode6 ActualDecoder.rows x = decode6 ActualDecoder.rows y := by
  apply decode6_congr
  intro row hr t ht
  exact h t.role (((ActualDecoder.every_row_valid row hr).2 t ht).1)

end PairedDecoder
#print axioms PairedDecoder.evaluate_congr
#print axioms PairedDecoder.decode6_congr
#print axioms PairedDecoder.actual_decoder_bounded_congr
