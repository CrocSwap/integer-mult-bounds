import AddressConjugation
import VariablePrivateShear
namespace AnchoredAddress
open BinarySpace24 VariablePrivateShear

def entries (q : Vec) (j : Index) : List Entry := [⟨j,add q (unit j)⟩]
def R (q : Vec) (j : Index) := shear (entries q j)
def RT (q : Vec) (j : Index) := transpose (entries q j)

theorem private_anchor (q : Vec) (j : Index) (hq : q j=true) : Private (entries q j) := by
  intro a ha b hb
  have ha : a=⟨j,add q (unit j)⟩ := by simpa only [entries,List.mem_singleton] using ha
  have hb : b=⟨j,add q (unit j)⟩ := by simpa only [entries,List.mem_singleton] using hb
  rw [ha,hb]
  simp only [add,unit,hq,decide_true,Bool.xor_self]

theorem formula (q : Vec) (j : Index) (x : Vec) : R q j x=add x (scale (x j) (add q (unit j))) := by
  simp only [R,shear,entries,correction,add_zero]

theorem involution (q : Vec) (j : Index) (hq : q j=true) (x : Vec) : R q j (R q j x)=x :=
  shear_involution _ (private_anchor q j hq) x

theorem axis_image (q : Vec) (j : Index) : R q j (unit j)=q := by
  rw [formula]
  have hu : unit j j=true := by simp only [unit,decide_true]
  rw [hu]
  change add (unit j) (add q (unit j))=q
  rw [add_comm q,← add_assoc,add_self,zero_add]

def chart (q : Vec) (j : Index) (hq : q j=true) : FourthRootLift.Chart where
  forward := R q j
  inverse := R q j
  inverseTranspose := RT q j
  inverse_left := involution q j hq
  inverse_right := involution q j hq
  forward_add := shear_add (entries q j)
  transpose_pairing := inverse_transpose_pairing (entries q j) (private_anchor q j hq)

theorem coordinate_image (q : Vec) (j : Index) (hq : q j=true) : (chart q j hq).forward (unit j)=q := axis_image q j

theorem inverse_C_lowering {F : Type u} [Lean.Grind.Field F] (i : F) (q : Vec) (j : Index) (hq : q j=true) (f : Vec → F) :
    AddressConjugation.P (chart q j hq)
      (CoordinateChild.undoGate i j (AddressConjugation.Pinv (chart q j hq) f))=
      TranslationKernel.gate (-i) q f :=
  AddressConjugation.inverse_coordinate_conjugation i _ j q (coordinate_image q j hq) f

end AnchoredAddress
#print axioms AnchoredAddress.private_anchor
#print axioms AnchoredAddress.formula
#print axioms AnchoredAddress.involution
#print axioms AnchoredAddress.axis_image
#print axioms AnchoredAddress.coordinate_image
#print axioms AnchoredAddress.inverse_C_lowering
