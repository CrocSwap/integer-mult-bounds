import ActualTargetRepresentative
namespace CoordinateTranslations
open BinarySpace24 CoordinateWord Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def shift (u : Vec) (f : Vec → F) (x : Vec) : F := f (add x u)

theorem translations_commute (u v : Vec) (f : Vec → F) : shift u (shift v f)=shift v (shift u f) := by
  funext x
  simp only [shift]
  congr 1
  funext k
  simp only [add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem translation_gate_commute (i : F) (v u : Vec) (f : Vec → F) :
    InvolutionGate.gate i (fun x => add x v) (shift u f)=shift u (InvolutionGate.gate i (fun x => add x v) f) := by
  funext x
  simp only [InvolutionGate.gate,shift]
  have h : add (add x v) u=add (add x u) v := by
    funext k
    simp only [add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]
  rw [h]

theorem coordinate_gate_commute (i : F) (j : Index) (u : Vec) (f : Vec → F) :
    CoordinateChild.gate i j (shift u f)=shift u (CoordinateChild.gate i j f) :=
  translation_gate_commute i (unit j) u f

theorem child_translation_commute (i : F) (js : List Index) (u : Vec) (f : Vec → F) :
    child i js (shift u f)=shift u (child i js f) := by
  induction js with
  | nil => rfl
  | cons j js ih => simp only [child,ih,coordinate_gate_commute]

def inheritedTarget (i : F) (f : Vec → F) : Vec → F :=
  child i (List.finRange 24) (InvolutionGate.gate i (fun x => add x SourceLineCase.q) f)

theorem inherited_target_commutes (i : F) (u : Vec) (f : Vec → F) :
    inheritedTarget i (shift u f)=shift u (inheritedTarget i f) := by
  rw [inheritedTarget,translation_gate_commute,child_translation_commute]
  rfl

end CoordinateTranslations
#print axioms CoordinateTranslations.translations_commute
#print axioms CoordinateTranslations.translation_gate_commute
#print axioms CoordinateTranslations.coordinate_gate_commute
#print axioms CoordinateTranslations.child_translation_commute
#print axioms CoordinateTranslations.inherited_target_commutes
