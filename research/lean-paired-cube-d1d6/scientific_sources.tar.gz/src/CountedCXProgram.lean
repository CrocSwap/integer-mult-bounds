import TransportedSwapCounter
namespace CountedCXProgram
open BinarySpace24 BinaryPairEnumeration CountedConditionalSwap Q21AddressProgram
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

-- Reverse memory order implements the pullback of the forward address program.
def program : List CX → PairLoadStoreMachine.State Vec V → PairLoadStoreMachine.State Vec V × Cost
  | [],s => (s,Cost.zero)
  | a::as,s =>
    let tail:=program as s
    let head:=TransportedSwapCounter.loop a.target a.control (addresses 23) tail.1
    (head.1,Cost.add tail.2 head.2)

def programCost (n : Nat) : Cost := ⟨16777216*n,16777216*n,8388608*n,16777216*n,0⟩

theorem program_cost (as : List CX) (s : PairLoadStoreMachine.State Vec V) :
    (program as s).2=programCost as.length := by
  induction as generalizing s with
  | nil => rfl
  | cons a as ih =>
    simp only [program,TransportedSwapCounter.actual_loop,ih,programCost,Cost.add,List.length_cons,Nat.mul_add,Nat.mul_one]

theorem program_memory (as : List CX) (ha : as.all legal=true) (s : PairLoadStoreMachine.State Vec V) :
    (program as s).1.memory=fun x=>s.memory (Q21AddressProgram.run as x) := by
  induction as generalizing s with
  | nil => rfl
  | cons a as ih =>
    have hh : a.control≠a.target:=of_decide_eq_true (List.all_eq_true.mp ha a (by simp))
    have ht : as.all legal=true:=List.all_eq_true.mpr (fun b hb=>List.all_eq_true.mp ha b (List.mem_cons_of_mem a hb))
    simp only [program,TransportedSwapCounter.actual_loop]
    rw [TransportedCXSemantics.memory_exact _ _ hh,ih ht]
    rfl

theorem address_map (as : List CX) (x : Vec) :
    RootAddressInstructions.run (as.map RootAddressInstructions.Instruction.cx) x=Q21AddressProgram.run as x := by
  induction as generalizing x with
  | nil => rfl
  | cons a as ih =>
    simp only [List.map_cons,RootAddressInstructions.run,RootAddressInstructions.execute,Q21AddressProgram.run,ih]

theorem program_mapped_memory (as : List CX) (ha : as.all legal=true) (s : PairLoadStoreMachine.State Vec V) :
    (program as s).1.memory=fun x=>s.memory (RootAddressInstructions.run (as.map RootAddressInstructions.Instruction.cx) x) := by
  rw [program_memory as ha]
  funext x
  rw [address_map]

end CountedCXProgram
#print axioms CountedCXProgram.program_cost
#print axioms CountedCXProgram.program_memory
#print axioms CountedCXProgram.address_map
#print axioms CountedCXProgram.program_mapped_memory
