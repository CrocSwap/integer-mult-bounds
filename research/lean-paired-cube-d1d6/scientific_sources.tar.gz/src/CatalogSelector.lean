import CatalogSpanBridge
import ActualEndpointSelector
namespace CatalogSelector
open BinarySpace24 BinaryCompletion VariableCertificates PiecewiseSelector CatalogSpanBridge Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def Domain (cs : List Witness) (U : Vec → Prop) :=
  ActualEndpointSelector.EndpointDomain U ∨ ∃c, c ∈ cs ∧ U=Span c

theorem nonendpoint_witness (cs : List Witness) (U : Vec → Prop) (hU : Domain cs U) (ho : Other U) :
    ∃c, c ∈ cs ∧ U=Span c := by
  rcases hU with he | he
  · rcases he with h | h | h | h
    · exact False.elim (ho.1 h)
    · exact False.elim (ho.2.1 h)
    · exact False.elim (ho.2.2.1 h)
    · exact False.elim (ho.2.2.2 h)
  · exact he

noncomputable def fallback (cs : List Witness) (hc : cs.all check=true) (U : Vec → Prop)
    (hU : Domain cs U) (ho : Other U) : CanonicalData U := by
  let he := nonendpoint_witness cs U hU ho
  let c := Classical.choose he
  have hm : c ∈ cs := (Classical.choose_spec he).1
  have hf : Facts c := check_sound c (List.all_eq_true.mp hc c hm)
  exact (Classical.choose_spec he).2 ▸ data c hf

noncomputable def catalog (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (cs : List Witness) (hc : cs.all check=true)
    (U : Vec → Prop) (hU : Domain cs U) := select i hi htwo (Domain cs) (fallback cs hc) U hU

theorem all_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (cs : List Witness) (hc : cs.all check=true)
    (U : Vec → Prop) (hU : Domain cs U) (f : Vec → F) :
    let r := catalog i hi htwo cs hc U hU
    r.decode (r.encode f)=f ∧ r.encode (r.decode f)=f :=
  select_inverses i hi htwo _ (fallback cs hc) U hU f

theorem all_preimages (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (cs : List Witness) (hc : cs.all check=true)
    (U : Vec → Prop) (hU : Domain cs U) (v : Vec × Vec) :
    ((catalog i hi htwo cs hc U hU).label v).1=zero ↔ Frame U v :=
  select_preimage i hi htwo _ (fallback cs hc) U hU v

theorem all_exact_Pauli (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (cs : List Witness) (hc : cs.all check=true)
    (U : Vec → Prop) (hU : Domain cs U) (v : Vec × Vec) (f : Vec → F) :
    let r := catalog i hi htwo cs hc U hU
    r.encode (ExactQuadraticLift.pauli v.1 v.2 (r.decode f))=fun x => r.phase v*ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 f x :=
  select_exact_Pauli i hi htwo _ (fallback cs hc) U hU v f

theorem all_source_preserved (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (cs : List Witness) (hc : cs.all check=true)
    (q : Vec) (hq : dot q q=true) :
    (catalog i hi htwo cs hc (EndpointGeometry.Line q)
      (Or.inl (Or.inr (Or.inr (Or.inl ⟨q,hq,rfl⟩))))).encode=InheritedEndpoints.source i q :=
  select_source i hi htwo _ (fallback cs hc) q hq _

theorem all_target_preserved (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (cs : List Witness) (hc : cs.all check=true)
    (q : Vec) (hq : dot q q=true) :
    (catalog i hi htwo cs hc (EndpointGeometry.Hyper q)
      (Or.inl (Or.inr (Or.inr (Or.inr ⟨q,hq,rfl⟩))))).encode=InheritedEndpoints.target i q :=
  select_target i hi htwo _ (fallback cs hc) q hq _

theorem all_same_frame (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (cs : List Witness) (hc : cs.all check=true)
    (U V : Vec → Prop) (hU : Domain cs U) (hV : Domain cs V) (h : U=V) :
    (catalog i hi htwo cs hc U hU).encode=(catalog i hi htwo cs hc V hV).encode :=
  same_subspace_same_operator i hi htwo _ (fallback cs hc) U V hU hV h

noncomputable def pilot (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ VariablePilotData.certificates) :=
  catalog i hi htwo VariablePilotData.certificates ActualVariablePilot.all_valid (Span c) (Or.inr ⟨c,hc,rfl⟩)

theorem pilot_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ VariablePilotData.certificates) (f : Vec → F) :
    (pilot i hi htwo c hc).decode ((pilot i hi htwo c hc).encode f)=f ∧
    (pilot i hi htwo c hc).encode ((pilot i hi htwo c hc).decode f)=f :=
  all_inverses i hi htwo _ ActualVariablePilot.all_valid _ _ f

theorem pilot_preimages (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ VariablePilotData.certificates) (v : Vec × Vec) :
    ((pilot i hi htwo c hc).label v).1=zero ↔ Frame (Span c) v :=
  all_preimages i hi htwo _ ActualVariablePilot.all_valid _ _ v

theorem pilot_Pauli (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ VariablePilotData.certificates) (v : Vec × Vec) (f : Vec → F) :
    let r := pilot i hi htwo c hc
    r.encode (ExactQuadraticLift.pauli v.1 v.2 (r.decode f))=fun x => r.phase v*ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 f x :=
  all_exact_Pauli i hi htwo _ ActualVariablePilot.all_valid _ _ v f

end CatalogSelector
#print axioms CatalogSelector.nonendpoint_witness
#print axioms CatalogSelector.all_inverses
#print axioms CatalogSelector.all_preimages
#print axioms CatalogSelector.all_exact_Pauli
#print axioms CatalogSelector.all_source_preserved
#print axioms CatalogSelector.all_target_preserved
#print axioms CatalogSelector.all_same_frame
#print axioms CatalogSelector.pilot_inverses
#print axioms CatalogSelector.pilot_preimages
#print axioms CatalogSelector.pilot_Pauli
