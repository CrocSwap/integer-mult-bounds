import InversePairProgram
import FirstEventBinding
namespace FirstLoweringProgram
open BinarySpace24 Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

inductive Op where
  | address : List Q21AddressProgram.CX → Op
  | inversePair : Op

def executeOp (i : F) : Op → (Vec → F) → (Vec → F)
  | .address code,f => fun x => f (Q21AddressProgram.run code x)
  | .inversePair,f => InversePairProgram.applyPairs i f

def execute (i : F) : List Op → (Vec → F) → (Vec → F)
  | [],f => f
  | a::as,f => execute i as (executeOp i a f)

def program : List Op := [.address Q21AddressProgram.code,.inversePair,.address Q21AddressProgram.code]

theorem exact_program (i : F) (f : Vec → F) : execute i program f=Q21AddressProgram.lowered i f := by
  simp only [program,execute,executeOp,InversePairProgram.coordinate_function_semantics]
  rfl

theorem actual_event_program (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    execute i program f=(ActualOperationSelector.stepRepresentative i hi htwo
      FirstEventBinding.firstStep FirstEventBinding.actual_first_member).encode f := by
  rw [exact_program,FirstEventBinding.actual_step_lowering i hi htwo]

def firstGate (i : F) (f g : Vec → F) := fun x => execute i program f x+SourceLineOperator.inheritedLine i g x

theorem actual_first_scalar_update (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f g : Vec → F) :
    firstGate i f g=(ActualOperationSelector.stepRepresentative i hi htwo
      FirstEventBinding.firstStep FirstEventBinding.actual_first_member).encode (fun x => f x+g x) := by
  calc
    firstGate i f g=SourceLineOperator.inheritedLine i (fun x => f x+g x) := by
      unfold firstGate
      rw [exact_program,Q21AddressProgram.exact_lowering]
      exact (CertifiedRepresentative.translation_add (-i) SourceLineCase.q f g).symm
    _ = Q21AddressProgram.lowered i (fun x => f x+g x) := (Q21AddressProgram.exact_lowering i _).symm
    _ = _ := FirstEventBinding.actual_step_lowering i hi htwo _

structure Cost where
  addressXors : Nat
  permutationRelocations : Nat
  scalarMultiplications : Nat
  scalarAdditions : Nat
  permutationPasses : Nat
  coordinateChildren : Nat
  deriving DecidableEq

def Cost.zero : Cost := ⟨0,0,0,0,0,0⟩
def Cost.add (a b : Cost) : Cost :=
  ⟨a.addressXors+b.addressXors,a.permutationRelocations+b.permutationRelocations,
   a.scalarMultiplications+b.scalarMultiplications,a.scalarAdditions+b.scalarAdditions,
   a.permutationPasses+b.permutationPasses,a.coordinateChildren+b.coordinateChildren⟩

def opCost (n : Nat) : Op → Cost
  | .address code => ⟨2^(n+1)*code.length,2^(n+1),0,0,1,0⟩
  | .inversePair => ⟨0,0,2^n*(InversePairProgram.mults InversePairProgram.first+InversePairProgram.mults InversePairProgram.second),
      2^n*(InversePairProgram.adds InversePairProgram.first+InversePairProgram.adds InversePairProgram.second),0,1⟩

def programCost (n : Nat) : List Op → Cost
  | [] => Cost.zero
  | a::as => Cost.add (opCost n a) (programCost n as)

theorem primitive_count_formula (n : Nat) : programCost n program=
    ⟨4*2^(n+1),2*2^(n+1),4*2^n,2*2^n,2,1⟩ := by
  simp only [program,programCost,opCost,Q21AddressProgram.instruction_count,Cost.add,Cost.zero,
    InversePairProgram.pair_primitive_counts.1,InversePairProgram.pair_primitive_counts.2]
  congr 1 <;> omega

theorem actual_primitive_counts : programCost 23 program=
    ⟨67108864,33554432,33554432,16777216,2,1⟩ := by
  rw [primitive_count_formula]

theorem pair_schedule_count : (BinaryPairEnumeration.addresses 23).length=8388608 := BinaryPairEnumeration.pair_count

theorem permutation_schedule_count : (BinaryPairEnumeration.addresses 24).length=16777216 := BinaryPairEnumeration.full_address_count

theorem address_and_pair_coverage :
    (∀ x : BinaryPairEnumeration.Bits 24, x ∈ BinaryPairEnumeration.addresses 24) ∧
    (BinaryPairEnumeration.addresses 24).Nodup ∧
    (∀ x : BinaryPairEnumeration.Bits 23, x ∈ BinaryPairEnumeration.addresses 23) ∧
    (BinaryPairEnumeration.addresses 23).Nodup :=
  ⟨BinaryPairEnumeration.all_addresses 24,BinaryPairEnumeration.addresses_nodup 24,
   BinaryPairEnumeration.all_addresses 23,BinaryPairEnumeration.addresses_nodup 23⟩

end FirstLoweringProgram
#print axioms FirstLoweringProgram.exact_program
#print axioms FirstLoweringProgram.actual_event_program
#print axioms FirstLoweringProgram.primitive_count_formula
#print axioms FirstLoweringProgram.actual_primitive_counts
#print axioms FirstLoweringProgram.pair_schedule_count
#print axioms FirstLoweringProgram.permutation_schedule_count
#print axioms FirstLoweringProgram.address_and_pair_coverage
#print axioms FirstLoweringProgram.actual_first_scalar_update
