import Lean

/-! Explicit integer-pair semantics for the fixed assembly expressions.
`ExactValue x n d` checks positive denominators and x.num*d = n*x.den.
Every arithmetic operation retains its full, unreduced integer expression.
The min/max comparisons are meaningful for the positive denominators proved here.
There is no real-analysis or general rational-field embedding claim. -/
namespace PairedCubeAssembly13955
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

structure Pair where
  num : Int
  den : Int
  deriving DecidableEq, Repr

instance (n : Nat) : OfNat Pair n := ⟨⟨(n : Int), 1⟩⟩
instance : Add Pair := ⟨fun x y => ⟨x.num*y.den+y.num*x.den,x.den*y.den⟩⟩
instance : Sub Pair := ⟨fun x y => ⟨x.num*y.den-y.num*x.den,x.den*y.den⟩⟩
instance : Mul Pair := ⟨fun x y => ⟨x.num*y.num,x.den*y.den⟩⟩
instance : Div Pair := ⟨fun x y => ⟨x.num*y.den,x.den*y.num⟩⟩

def pairMin (x y : Pair) : Pair := if x.num*y.den ≤ y.num*x.den then x else y
def pairMax (x y : Pair) : Pair := if x.num*y.den ≤ y.num*x.den then y else x

def Positive (x : Pair) : Prop := 0 < x.den ∧ 0 < x.num
def SameValue (x y : Pair) : Prop := 0 < x.den ∧ 0 < y.den ∧ x.num*y.den = y.num*x.den
def ExactValue (x : Pair) (n d : Int) : Prop := 0 < x.den ∧ 0 < d ∧ x.num*d = n*x.den
def Below (x y : Pair) : Prop := 0 < x.den ∧ 0 < y.den ∧ x.num*y.den < y.num*x.den
def AtMost (x y : Pair) : Prop := 0 < x.den ∧ 0 < y.den ∧ x.num*y.den ≤ y.num*x.den

instance (x : Pair) : Decidable (Positive x) := inferInstanceAs (Decidable (0 < x.den ∧ 0 < x.num))
instance (x y : Pair) : Decidable (SameValue x y) := inferInstanceAs (Decidable (0 < x.den ∧ 0 < y.den ∧ x.num*y.den = y.num*x.den))
instance (x : Pair) (n d : Int) : Decidable (ExactValue x n d) := inferInstanceAs (Decidable (0 < x.den ∧ 0 < d ∧ x.num*d = n*x.den))
instance (x y : Pair) : Decidable (Below x y) := inferInstanceAs (Decidable (0 < x.den ∧ 0 < y.den ∧ x.num*y.den < y.num*x.den))
instance (x y : Pair) : Decidable (AtMost x y) := inferInstanceAs (Decidable (0 < x.den ∧ 0 < y.den ∧ x.num*y.den ≤ y.num*x.den))

-- The external row formula is the literal pinned formula, with its coefficient
-- expanded using the previously compiled halving/bit-width identity.
def rowCoefficient : Pair := 4*2571+9909+252
def rowGap : Pair := 70000-(51*rowCoefficient/25)

def AC : Pair := ⟨4856569, (10 ^ 10)⟩
def COARSE : Pair := ⟨4617656, (10 ^ 10)⟩
def ATOM : Pair := ⟨1, 1000⟩
def OLD : Pair := ⟨384599, (10 ^ 10)⟩
def AB : Pair := (((1 - ATOM) * COARSE) + (ATOM * OLD))
def PHASE_STOP : Pair := ⟨1, (10 ^ 6)⟩
def ASSEMBLY_BIT : Pair := (pairMin AB (((1 - PHASE_STOP) * AC) - ⟨1, (10 ^ 10)⟩))
def KAPPA : Pair := ⟨4609169, (10 ^ 10)⟩
def eta : Pair := ⟨1, (10 ^ 8)⟩
def beta : Pair := PHASE_STOP
def a : Pair := ASSEMBLY_BIT
def b : Pair := AC
def tau : Pair := (1 - a)
def sigma : Pair := (1 - b)
def q : Pair := (a * (1 - (2 * eta)))
def lp : Pair := (1 - q)
def lam : Pair := ((tau + lp) / 2)
def c : Pair := (q * (1 + eta))
def eps : Pair := ((1 - eta) / ((1 + c) + q))
def minimum : Pair := (eps * q)
def r : Pair := (((minimum + 1) - eps) / 2)
def delta : Pair := (eta / 8)
def internal : Pair := (tau + ((1 - beta) * (pairMax (sigma - tau) 0)))
def leaf : Pair := (sigma + (beta * (1 - sigma)))
def margin_original_prefix : Pair := (1 - (eps * (1 + c)))
def margin_coordinate_movement : Pair := a
def margin_compact_phase_layer : Pair := minimum
def margin_bulk_exposure : Pair := a
def margin_Gaussian_arithmetic : Pair := (pairMin ((1 - eps) - delta) (r - delta))
def margin_scalar_work : Pair := ((1 - eps) - delta)
def margin_dimension : Pair := eps
def slack_bit_positive : Pair := a
def slack_complex_above_bit : Pair := (b - a)
def slack_complex_below_one_over32 : Pair := (⟨1, 32⟩ - b)
def slack_beta_positive : Pair := beta
def slack_beta_below_one : Pair := (1 - beta)
def slack_leaf_saving_above_bit : Pair := (((1 - beta) * b) - a)
def slack_q_positive : Pair := q
def slack_q_below_internal : Pair := ((1 - internal) - q)
def slack_q_below_leaf : Pair := ((1 - leaf) - q)
def slack_c_positive : Pair := c
def slack_c_below_one : Pair := (1 - c)
def slack_q_below_reservations : Pair := (c - q)
def slack_lambda_above_tau : Pair := (lam - tau)
def slack_lambda_above_sigma : Pair := (lam - sigma)
def slack_lambda_above_internal : Pair := (lam - internal)
def slack_lambda_prime_above_lambda : Pair := (lp - lam)
def slack_compact_leaf : Pair := (lp - leaf)
def slack_compact_reservations : Pair := (lp - (1 - c))
def slack_lambda_prime_below_one : Pair := q
def slack_epsilon_positive : Pair := eps
def slack_epsilon_below_one : Pair := (1 - eps)
def slack_guard_width : Pair := (1 - eps)
def slack_K_geometry : Pair := (1 - (eps * (1 + c)))
def slack_K_dominates_log : Pair := (eps * c)
def slack_record_suffix : Pair := (1 - eps)
def slack_phase_local : Pair := ((1 - eps) - delta)
def slack_phase_boundary : Pair := (r - delta)
def slack_gamma_sublinear : Pair := ((1 - eps) - r)
def slack_cell_above_band : Pair := (eps - ((1 - r) / 2))
def slack_prime_interval_packing : Pair := (1 - eps)
def slack_alpha_positive : Pair := r
def slack_alpha_below_one : Pair := (1 - r)
def slack_alpha_below_one_fourth : Pair := (⟨1, 4⟩ - r)
def slack_delta_positive : Pair := delta
def slack_delta_below_one_eighth : Pair := (⟨1, 8⟩ - delta)
def slack_short_record_fallback : Pair := (eps - a)
def slack_small_field_exposure : Pair := ((1 - eps) - minimum)
def slack_artificial_boundary : Pair := ((((8 - eps) + r) - delta) - minimum)
def slack_row_product_gap : Pair := rowGap
def slack_original_prefix_above_kappa : Pair := margin_original_prefix-KAPPA
def slack_coordinate_movement_above_kappa : Pair := margin_coordinate_movement-KAPPA
def slack_compact_phase_layer_above_kappa : Pair := margin_compact_phase_layer-KAPPA
def slack_bulk_exposure_above_kappa : Pair := margin_bulk_exposure-KAPPA
def slack_Gaussian_arithmetic_above_kappa : Pair := margin_Gaussian_arithmetic-KAPPA
def slack_scalar_work_above_kappa : Pair := margin_scalar_work-KAPPA
def slack_dimension_above_kappa : Pair := margin_dimension-KAPPA

theorem stopped_bit_sample : ExactValue a 4613422943 10000000000000 := by
  decide


theorem epsilon_sample : ExactValue eps 49999999500000000000000000000 50046134228737986553936577057 := by
  decide


theorem phase_boundary_sample : ExactValue slack_phase_boundary 27680687058255018102013446063422943 40036907382990389243149261645600000000 := by
  decide

end PairedCubeAssembly13955
#print axioms PairedCubeAssembly13955.stopped_bit_sample
#print axioms PairedCubeAssembly13955.epsilon_sample
#print axioms PairedCubeAssembly13955.phase_boundary_sample
