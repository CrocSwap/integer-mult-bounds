import CertifiedRepresentative
namespace AddressConjugation
open BinarySpace24 FourthRootLift Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def P (c : Chart) (f : Vec → F) (y : Vec) := f (c.inverse y)
def Pinv (c : Chart) (f : Vec → F) (x : Vec) := f (c.forward x)

theorem inverse_left (c : Chart) (f : Vec → F) : Pinv c (P c f)=f := by
  funext x
  simp only [Pinv,P,c.inverse_left]

theorem inverse_right (c : Chart) (f : Vec → F) : P c (Pinv c f)=f := by
  funext x
  simp only [Pinv,P,c.inverse_right]

theorem axis_translation (c : Chart) (j : Index) (q : Vec) (hq : c.forward (unit j)=q) (x : Vec) :
    c.forward (add (c.inverse x) (unit j))=add x q := by
  rw [c.forward_add,c.inverse_right,hq]

theorem coordinate_conjugation (a : F) (c : Chart) (j : Index) (q : Vec)
    (hq : c.forward (unit j)=q) (f : Vec → F) :
    P c (CoordinateChild.gate a j (Pinv c f))=TranslationKernel.gate a q f := by
  funext x
  simp only [P,Pinv,CoordinateChild.gate,InvolutionGate.gate,CoordinateChild.flip,
    c.inverse_right,axis_translation c j q hq,TranslationKernel.gate,TranslationKernel.flip]

theorem inverse_coordinate_conjugation (i : F) (c : Chart) (j : Index) (q : Vec)
    (hq : c.forward (unit j)=q) (f : Vec → F) :
    P c (CoordinateChild.undoGate i j (Pinv c f))=TranslationKernel.gate (-i) q f :=
  coordinate_conjugation (-i) c j q hq f

def label (c : Chart) (v : Vec × Vec) := (c.forward v.1,c.inverseTranspose v.2)

theorem exact_Pauli (c : Chart) (u z : Vec) (f : Vec → F) :
    P c (ExactQuadraticLift.pauli u z (Pinv c f))=
      ExactQuadraticLift.pauli (c.forward u) (c.inverseTranspose z) f := by
  funext y
  have h := c.transpose_pairing (c.inverse y) z
  rw [c.inverse_right,dot_symmetric y,dot_symmetric (c.inverse y)] at h
  simp only [P,Pinv,ExactQuadraticLift.pauli,c.forward_add,c.inverse_right,h]

theorem zero_X_preserved (c : Chart) (z : Vec) : (label c (zero,z)).1=zero := GeneralChartFrames.forward_zero c

theorem pure_permutation (c : Chart) (f : Vec → F) (x : Vec) : P c f x=f (c.inverse x) := rfl

end AddressConjugation
#print axioms AddressConjugation.inverse_left
#print axioms AddressConjugation.inverse_right
#print axioms AddressConjugation.axis_translation
#print axioms AddressConjugation.coordinate_conjugation
#print axioms AddressConjugation.inverse_coordinate_conjugation
#print axioms AddressConjugation.exact_Pauli
#print axioms AddressConjugation.zero_X_preserved
#print axioms AddressConjugation.pure_permutation
