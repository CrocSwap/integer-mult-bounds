import GaugeKeyTrace
namespace FilteredLastTouch
open PairedWord (Step)
open GaugeKeyTrace

def project (r : Nat) : List Step → Nat → Nat
  | [],k => k
  | s::ss,k => project r ss (if touches r s then ActualFrameKeys.key s else k)

theorem run_projection (r : Nat) (ss : List Step) (g : State) : run ss g r=project r ss (g r) := by
  induction ss generalizing g with
  | nil => rfl
  | cons s ss ih =>
    rw [run,ih]
    rfl

theorem filter_projection (r : Nat) (ss : List Step) (k : Nat) :
    project r ss k=project r (ss.filter (touches r)) k := by
  induction ss generalizing k with
  | nil => rfl
  | cons s ss ih =>
    cases h : touches r s <;> simp only [List.filter_cons,h,project,Bool.false_eq_true,if_false,if_true]
    · exact ih k
    · exact ih (ActualFrameKeys.key s)

theorem run_filtered (r : Nat) (ss : List Step) (g : State) :
    run ss g r=project r (ss.filter (touches r)) (g r) := by
  rw [run_projection,filter_projection]

theorem zip_first {α : Type u} (ss : List α) (start : Nat) : (ss.zipIdx start).map Prod.fst=ss := by
  induction ss generalizing start with
  | nil => rfl
  | cons s ss ih => simp only [List.zipIdx_cons,List.map_cons,ih]

theorem filter_indexed (r : Nat) (ss : List Step) (start : Nat) :
    ss.filter (touches r)=((ss.zipIdx start).filter (fun p => touches r p.1)).map Prod.fst := by
  change ss.filter (touches r)=((ss.zipIdx start).filter (touches r ∘ Prod.fst)).map Prod.fst
  rw [← List.filter_map,zip_first]

end FilteredLastTouch
#print axioms FilteredLastTouch.run_projection
#print axioms FilteredLastTouch.filter_projection
#print axioms FilteredLastTouch.run_filtered
#print axioms FilteredLastTouch.zip_first
#print axioms FilteredLastTouch.filter_indexed
