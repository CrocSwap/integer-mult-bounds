import RootFactorRawData
import ExactTransitionFactor
namespace ActualRootFactorization
open RootFactorRawData BinarySpace24 BinaryCompletion CatalogSpanBridge CertifiedRepresentative CommonExactFrame Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem exact_selected_transition (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (selectedOutgoing i hi htwo).encode ((selectedIncoming i hi htwo).decode f)=
      leftRatio i hi htwo (NestedCoordinateTransition.child i RootJointGeometry.joint 21 (rightRatio i hi htwo f)) :=
  ExactTransitionFactor.through_child (selectedIncoming i hi htwo).toExactFrame (selectedOutgoing i hi htwo).toExactFrame
    (JointRawFrames.incomingRep i hi htwo).toExactFrame (JointRawFrames.outgoingRep i hi htwo).toExactFrame
    (NestedCoordinateTransition.child i RootJointGeometry.joint 21) (JointRawFrames.center_as_adapter i hi htwo) f

theorem exact_selected_inverse (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (selectedIncoming i hi htwo).encode ((selectedOutgoing i hi htwo).decode f)=
      rightInverse i hi htwo (NestedCoordinateTransition.undoChild i RootJointGeometry.joint 21 (leftInverse i hi htwo f)) :=
  ExactTransitionFactor.through_child (selectedOutgoing i hi htwo).toExactFrame (selectedIncoming i hi htwo).toExactFrame
    (JointRawFrames.outgoingRep i hi htwo).toExactFrame (JointRawFrames.incomingRep i hi htwo).toExactFrame
    (NestedCoordinateTransition.undoChild i RootJointGeometry.joint 21) (JointRawFrames.inverse_center_as_adapter i hi htwo) f

theorem actual_event_transition (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (g : GaugeKeyTrace.State) (f : Vec → F) :
    adapter (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 3 g 17326))
      (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 4 g 17326)) f=
      leftRatio i hi htwo (NestedCoordinateTransition.child i RootJointGeometry.joint 21 (rightRatio i hi htwo f)) := by
  rw [RootLifecycleFrameBinding.incoming_selected,RootLifecycleFrameBinding.outgoing_selected_pilot]
  exact exact_selected_transition i hi htwo f

end ActualRootFactorization
#print axioms ActualRootFactorization.exact_selected_transition
#print axioms ActualRootFactorization.exact_selected_inverse
#print axioms ActualRootFactorization.actual_event_transition
