import CompletionData
namespace CompletionCheck025
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch025.all CompletionCertificates.check=true := by decide
end CompletionCheck025
#print axioms CompletionCheck025.valid
