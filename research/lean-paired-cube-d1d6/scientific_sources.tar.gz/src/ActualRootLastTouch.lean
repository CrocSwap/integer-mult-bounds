import RootTouchShard000
import RootTouchShard001
import RootTouchShard002
import RootTouchShard003
import RootTouchShard004
import RootTouchShard005
import RootTouchShard006
import RootTouchShard007
import RootTouchShard008
import RootTouchShard009
import RootTouchShard010
import RootTouchShard011
import RootTouchShard012
namespace ActualRootLastTouch
open PairedWord (Step)
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000
def events : List (Step × Nat) := [(⟨17326,9837,11825,false⟩,23958),(⟨10239,17326,11902,false⟩,29547),(⟨17326,15287,11831,false⟩,31656),(⟨20015,17326,11831,false⟩,31657),(⟨9607,17326,12095,false⟩,35957),(⟨17326,18320,11861,false⟩,40802),(⟨21587,17326,11861,false⟩,40803)]
theorem word_chunks : PairedWordData.word=RootTouchShard000.steps ++ RootTouchShard001.steps ++ RootTouchShard002.steps ++ RootTouchShard003.steps ++ RootTouchShard004.steps ++ RootTouchShard005.steps ++ RootTouchShard006.steps ++ RootTouchShard007.steps ++ RootTouchShard008.steps ++ RootTouchShard009.steps ++ RootTouchShard010.steps ++ RootTouchShard011.steps ++ RootTouchShard012.steps := by
  simp only [PairedWordData.word,PairedWordData.chunks,RootTouchShard000.steps,RootTouchShard001.steps,RootTouchShard002.steps,RootTouchShard003.steps,RootTouchShard004.steps,RootTouchShard005.steps,RootTouchShard006.steps,RootTouchShard007.steps,RootTouchShard008.steps,RootTouchShard009.steps,RootTouchShard010.steps,RootTouchShard011.steps,RootTouchShard012.steps,List.flatten_cons,List.flatten_nil,List.append_nil,List.append_assoc]
theorem indexed_touches : (PairedWordData.word.zipIdx 0).filter (fun p => GaugeKeyTrace.touches 17326 p.1)=events := by
  rw [word_chunks]
  simp only [List.zipIdx_append,List.length_append,RootTouchShard000.count,RootTouchShard001.count,RootTouchShard002.count,RootTouchShard003.count,RootTouchShard004.count,RootTouchShard005.count,RootTouchShard006.count,RootTouchShard007.count,RootTouchShard008.count,RootTouchShard009.count,RootTouchShard010.count,RootTouchShard011.count,RootTouchShard012.count,Nat.reduceAdd,List.filter_append,RootTouchShard000.indexed_touches,RootTouchShard001.indexed_touches,RootTouchShard002.indexed_touches,RootTouchShard003.indexed_touches,RootTouchShard004.indexed_touches,RootTouchShard005.indexed_touches,RootTouchShard006.indexed_touches,RootTouchShard007.indexed_touches,RootTouchShard008.indexed_touches,RootTouchShard009.indexed_touches,RootTouchShard010.indexed_touches,RootTouchShard011.indexed_touches,RootTouchShard012.indexed_touches,List.nil_append,List.append_nil,List.cons_append,events]
theorem actual_touches : PairedWordData.word.filter (GaugeKeyTrace.touches 17326)=events.map Prod.fst := by
  rw [FilteredLastTouch.filter_indexed 17326 PairedWordData.word 0,indexed_touches]
theorem touch_positions : ((PairedWordData.word.zipIdx 0).filter (fun p => GaugeKeyTrace.touches 17326 p.1)).map Prod.snd=[23958,29547,31656,31657,35957,40802,40803] := by
  rw [indexed_touches]
  rfl
theorem last_two : events.drop 5=[(⟨17326,18320,11861,false⟩,40802),(⟨21587,17326,11861,false⟩,40803)] := rfl

theorem project_events (k : Nat) : FilteredLastTouch.project 17326 (events.map Prod.fst) k=15704 := rfl

theorem after_M (g : GaugeKeyTrace.State) : GaugeKeyTrace.run PairedWordData.word g 17326=15704 := by
  rw [FilteredLastTouch.run_filtered,actual_touches,project_events]

end ActualRootLastTouch
#print axioms ActualRootLastTouch.word_chunks
#print axioms ActualRootLastTouch.indexed_touches
#print axioms ActualRootLastTouch.actual_touches
#print axioms ActualRootLastTouch.touch_positions
#print axioms ActualRootLastTouch.last_two
#print axioms ActualRootLastTouch.project_events
#print axioms ActualRootLastTouch.after_M
