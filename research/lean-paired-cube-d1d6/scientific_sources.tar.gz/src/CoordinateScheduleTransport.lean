import ActualAlignmentReceipt
namespace CoordinateScheduleTransport
open BinarySpace24 BinaryPairEnumeration

def index (t j : Index) : Index := if j=21 then t else if j=t then 21 else j
def rename (t : Index) (x : Vec) (j : Index) := x (index t j)

theorem index_twice (t j : Index) : index t (index t j)=j := by
  by_cases h : t=21 <;> by_cases h1 : j=21 <;> by_cases h2 : j=t <;> simp_all [index]

theorem index_target (t j : Index) : index t j=21 ↔ j=t := by
  by_cases h : t=21 <;> by_cases h1 : j=21 <;> by_cases h2 : j=t <;> simp_all [index]

theorem index21 (t : Index) : index t 21=t := by simp [index]
theorem index_t (t : Index) : index t t=21 := by by_cases h : t=21 <;> simp_all [index]

theorem rename_twice (t : Index) (x : Vec) : rename t (rename t x)=x := by
  funext j
  exact congrArg x (index_twice t j)

theorem rename_injective (t : Index) (x y : Vec) (h : rename t x=rename t y) : x=y := by
  have hh:=congrArg (rename t) h
  simpa only [rename_twice] using hh

theorem rename_execute (t c : Index) (x : Vec) :
    rename t (Q21AddressProgram.execute ⟨index t c,21⟩ x)=Q21AddressProgram.execute ⟨c,t⟩ (rename t x) := by
  funext j
  simp only [rename,Q21AddressProgram.execute,add,BinarySpace24.scale,unit,eq_comm,index_target]

def embed (t : Index) (b : Bool) (k : Bits 23) := rename t (Coordinate21Pairs.embed b k)
def drop (t : Index) (x : Vec) := Coordinate21Pairs.drop (rename t x)

theorem embed_head (t : Index) (b : Bool) (k : Bits 23) : embed t b k t=b := by
  simp only [embed,rename,index_t,Coordinate21Pairs.embed_head]

theorem drop_embed (t : Index) (b : Bool) (k : Bits 23) : drop t (embed t b k)=k := by
  rw [drop,embed,rename_twice,Coordinate21Pairs.drop_embed]

theorem embed_drop (t : Index) (x : Vec) : embed t (x t) (drop t x)=x := by
  have h:=congrArg (rename t) (Coordinate21Pairs.embed_drop (rename t x))
  simpa only [rename,index21,embed,drop,rename_twice] using h

def geometry (t : Index) : DisjointPairLoop.Geometry (embed t false) (embed t true) where
  left_injective := fun x y h=>Coordinate21Pairs.embed_injective false x y (rename_injective t _ _ h)
  right_injective := fun x y h=>Coordinate21Pairs.embed_injective true x y (rename_injective t _ _ h)
  disjoint := fun x y h=>Coordinate21Pairs.embed_disjoint x y (rename_injective t _ _ h)

theorem pair_flip (t : Index) (k : Bits 23) : CoordinateChild.flip t (embed t false k)=embed t true k := by
  have h:=congrArg (rename t) (Coordinate21Pairs.pair_flip k)
  simp only [embed]
  rw [← h]
  funext j
  simp only [CoordinateChild.flip,embed,rename,add,unit,eq_comm,index_target]

theorem all_covered (t : Index) (x : Vec) :
    x∈(addresses 23).map (embed t false)++(addresses 23).map (embed t true) := by
  have h:=all_addresses 23 (drop t x)
  have he:=embed_drop t x
  cases hb : x t
  · rw [hb] at he
    exact List.mem_append.mpr (Or.inl (List.mem_map.mpr ⟨drop t x,h,he⟩))
  · rw [hb] at he
    exact List.mem_append.mpr (Or.inr (List.mem_map.mpr ⟨drop t x,h,he⟩))

theorem control_legal (t c : Index) (h : c≠t) : index t c≠21 := by
  intro he
  exact h ((index_target t c).mp he)

end CoordinateScheduleTransport
#print axioms CoordinateScheduleTransport.index_twice
#print axioms CoordinateScheduleTransport.index_target
#print axioms CoordinateScheduleTransport.index21
#print axioms CoordinateScheduleTransport.index_t
#print axioms CoordinateScheduleTransport.rename_twice
#print axioms CoordinateScheduleTransport.rename_injective
#print axioms CoordinateScheduleTransport.rename_execute
#print axioms CoordinateScheduleTransport.embed_head
#print axioms CoordinateScheduleTransport.drop_embed
#print axioms CoordinateScheduleTransport.embed_drop
#print axioms CoordinateScheduleTransport.pair_flip
#print axioms CoordinateScheduleTransport.all_covered
#print axioms CoordinateScheduleTransport.control_legal
