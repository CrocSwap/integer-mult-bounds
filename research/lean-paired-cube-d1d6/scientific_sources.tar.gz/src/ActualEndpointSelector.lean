import ExactGaugeAdapter
import CoordinateTranslations
namespace ActualEndpointSelector
open BinarySpace24 EndpointGeometry EndpointSeparation PiecewiseSelector Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def EndpointDomain (U : Vec → Prop) := U=ZeroSpace ∨ U=FullSpace ∨ IsSource U ∨ IsTarget U

def endpointFallback (U : Vec → Prop) (hU : EndpointDomain U) (ho : Other U) : CanonicalData U := by
  apply False.elim
  rcases hU with h | h | h | h
  · exact False.elim (ho.1 h)
  · exact False.elim (ho.2.1 h)
  · exact False.elim (ho.2.2.1 h)
  · exact False.elim (ho.2.2.2 h)

noncomputable def endpointSelector (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (U : Vec → Prop) (hU : EndpointDomain U) :=
  select i hi htwo EndpointDomain endpointFallback U hU

theorem all_source_exact (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (q : Vec) (hq : dot q q=true) :
    (endpointSelector i hi htwo (Line q) (Or.inr (Or.inr (Or.inl ⟨q,hq,rfl⟩)))).encode=InheritedEndpoints.source i q :=
  select_source i hi htwo _ endpointFallback q hq _

theorem all_target_exact (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (q : Vec) (hq : dot q q=true) :
    (endpointSelector i hi htwo (Hyper q) (Or.inr (Or.inr (Or.inr ⟨q,hq,rfl⟩)))).encode=InheritedEndpoints.target i q :=
  select_target i hi htwo _ endpointFallback q hq _

theorem all_endpoint_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (U : Vec → Prop)
    (hU : EndpointDomain U) (f : Vec → F) :
    let r := endpointSelector i hi htwo U hU
    r.decode (r.encode f)=f ∧ r.encode (r.decode f)=f :=
  select_inverses i hi htwo _ endpointFallback U hU f

theorem all_endpoint_preimages (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (U : Vec → Prop)
    (hU : EndpointDomain U) (v : Vec × Vec) :
    ((endpointSelector i hi htwo U hU).label v).1=zero ↔ BinaryCompletion.Frame U v :=
  select_preimage i hi htwo _ endpointFallback U hU v

theorem actual_source_formula (i : F) (hi : i*i= -1) :
    InheritedEndpoints.source i SourceLineCase.q=SourceLineOperator.inheritedLine i := by
  unfold InheritedEndpoints.source
  rw [SourceLineCase.coordinate_phase_source i hi]
  rfl

theorem actual_target_formula (i : F) (hi : i*i= -1) :
    InheritedEndpoints.target i SourceLineCase.q=CoordinateTranslations.inheritedTarget i := by
  funext f
  unfold InheritedEndpoints.target InheritedEndpoints.sourceInverse TranslationKernel.undoGate InvolutionGate.inverse
  rw [SourceLineCase.coordinate_phase_source i hi,Ring.neg_neg]
  rfl

theorem actual_source_selector (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) :
    (endpointSelector i hi htwo (Line SourceLineCase.q)
      (Or.inr (Or.inr (Or.inl ⟨SourceLineCase.q,SourceLineCase.source_norm,rfl⟩)))).encode=SourceLineOperator.inheritedLine i := by
  rw [all_source_exact i hi htwo _ SourceLineCase.source_norm,actual_source_formula i hi]

theorem actual_target_selector (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) :
    (endpointSelector i hi htwo (Hyper SourceLineCase.q)
      (Or.inr (Or.inr (Or.inr ⟨SourceLineCase.q,SourceLineCase.source_norm,rfl⟩)))).encode=CoordinateTranslations.inheritedTarget i := by
  rw [all_target_exact i hi htwo _ SourceLineCase.source_norm,actual_target_formula i hi]

end ActualEndpointSelector
#print axioms ActualEndpointSelector.all_source_exact
#print axioms ActualEndpointSelector.all_target_exact
#print axioms ActualEndpointSelector.all_endpoint_inverses
#print axioms ActualEndpointSelector.all_endpoint_preimages
#print axioms ActualEndpointSelector.actual_source_formula
#print axioms ActualEndpointSelector.actual_target_formula
#print axioms ActualEndpointSelector.actual_source_selector
#print axioms ActualEndpointSelector.actual_target_selector
