import LiftTransport
namespace CarrierRepresentative
open BinarySpace24 BinaryCompletion CompletionCertificates CompletionFrames GramQuadratic ExactQuadraticLift LiftTransport Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def representative (i : F) (c : Witness) (hc : Facts c) (f : Vec → F) : Vec → F :=
  lift c hc (FullCoordinateChild.child i (unlift c hc f))
def inverseRepresentative (i : F) (c : Witness) (hc : Facts c) (f : Vec → F) : Vec → F :=
  lift c hc (FullCoordinateChild.unchild i (unlift c hc f))
def label (c : Witness) (hc : Facts c) (v : Vec × Vec) : Vec × Vec :=
  blockMap c hc (CoordinateFrames.label (inverseBlock c hc v))
def exactPhase (i : F) (c : Witness) (hc : Facts c) (v : Vec × Vec) : F :=
  let r := inverseBlock c hc v
  QuadraticPhase.sign (quadratic c hc r.1)*FullCoordinateChild.phase i r.2*
    QuadraticPhase.sign (quadratic c hc (CoordinateFrames.label r).1)

theorem inverse_left (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : Facts c) (f : Vec → F) : inverseRepresentative i c hc (representative i c hc f)=f := by
  simp only [inverseRepresentative,representative,ExactQuadraticLift.inverse_left,
    FullCoordinateChild.inverse_left i hi htwo,ExactQuadraticLift.inverse_right]

theorem inverse_right (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : Facts c) (f : Vec → F) : representative i c hc (inverseRepresentative i c hc f)=f := by
  simp only [inverseRepresentative,representative,ExactQuadraticLift.inverse_left,
    FullCoordinateChild.inverse_right i hi htwo,ExactQuadraticLift.inverse_right]

theorem pauli_pullthrough (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : Facts c) (hs : c.cube ∈ ActualInputCubes.cubes) (v : Vec × Vec) (f : Vec → F) :
    representative i c hc (pauli v.1 v.2 f)=
      fun x => exactPhase i c hc v*pauli (label c hc v).1 (label c hc v).2 (representative i c hc f) x := by
  unfold representative
  rw [unlift_pullthrough c hc hs,FullCoordinateChild.child_scale,
    FullCoordinateChild.pauli_pullthrough i hi htwo,
    ExactQuadraticLift.lift_scale,ExactQuadraticLift.lift_scale,lift_pullthrough c hc hs]
  funext x
  simp only [exactPhase,label]
  grind

theorem pauli_conjugation (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : Facts c) (hs : c.cube ∈ ActualInputCubes.cubes) (v : Vec × Vec) (f : Vec → F) :
    representative i c hc (pauli v.1 v.2 (inverseRepresentative i c hc f))=
      fun x => exactPhase i c hc v*pauli (label c hc v).1 (label c hc v).2 f x := by
  rw [pauli_pullthrough i hi htwo c hc hs,inverse_right i hi htwo]

theorem label_involution (c : Witness) (hc : Facts c) (v : Vec × Vec) : label c hc (label c hc v)=v := by
  simp only [label,block_inverse_left,CoordinateFrames.label_involution,block_inverse_right]

theorem frame_preimage (c : Witness) (hc : Facts c) (hs : c.cube ∈ ActualInputCubes.cubes) (v : Vec × Vec) :
    (label c hc v).1=zero ↔ Frame (ActualCarrier c) v := by
  change fullMap c hc (CoordinateFrames.label (inverseBlock c hc v)).1=zero ↔ _
  rw [CompletionColumns.full_map_kernel,CoordinateFrames.frame_preimage]
  have h := actual_carrier_frame c hc hs (inverseBlock c hc v)
  rw [block_inverse_right] at h
  exact h.symm

end CarrierRepresentative
#print axioms CarrierRepresentative.inverse_left
#print axioms CarrierRepresentative.inverse_right
#print axioms CarrierRepresentative.pauli_pullthrough
#print axioms CarrierRepresentative.pauli_conjugation
#print axioms CarrierRepresentative.label_involution
#print axioms CarrierRepresentative.frame_preimage
