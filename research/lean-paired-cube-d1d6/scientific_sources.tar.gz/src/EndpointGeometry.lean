import CoordinateWordFrames
import GeneralChartFrames
namespace EndpointGeometry
open BinarySpace24 BinaryCompletion

def Line (q x : Vec) : Prop := x=zero ∨ x=q
def Hyper (q x : Vec) : Prop := dot q x=false
def lineLabel (q : Vec) (v : Vec × Vec) := (add v.1 (scale (dot v.2 q) q),v.2)
def targetLabel (q : Vec) (v : Vec × Vec) := (add (lineLabel q v).1 v.2,v.2)

theorem norm_nonzero (q : Vec) (hq : dot q q=true) : q≠zero := by
  intro h
  rw [h,dot_zero] at hq
  contradiction

theorem scalar_cases (b : Bool) (q : Vec) : Line q (scale b q) := by
  cases b
  · exact Or.inl rfl
  · exact Or.inr rfl

theorem line_frame (q : Vec) (hq : dot q q=true) (v : Vec × Vec) :
    Frame (Line q) v ↔ v.1=scale (dot v.2 q) q := by
  constructor
  · intro ⟨hx,ho⟩
    have h := ho q (Or.inr rfl)
    rw [dot_add,dot_symmetric q v.2] at h
    rcases hx with hx | hx
    · rw [hx,dot_zero] at h
      simp only [Bool.false_xor] at h
      rw [h]
      exact hx
    · rw [hx,hq] at h
      have hz : dot v.2 q=true := by cases he : dot v.2 q <;> simp_all
      rw [hz]
      exact hx
  · intro hx
    refine ⟨hx ▸ scalar_cases _ _,?_⟩
    intro u hu
    rcases hu with hu | hu
    · rw [hu,dot_symmetric,dot_zero]
    · rw [hu,dot_add,hx,dot_scale,hq,dot_symmetric q v.2]
      simp

theorem line_preimage (q : Vec) (hq : dot q q=true) (v : Vec × Vec) :
    (lineLabel q v).1=zero ↔ Frame (Line q) v := by
  change add v.1 (scale (dot v.2 q) q)=zero ↔ _
  rw [CoordinateFrames.add_eq_zero,line_frame q hq]

theorem hyper_orthogonal (q : Vec) (hq : dot q q=true) (x : Vec) :
    (∀ w, Hyper q w → dot w x=false) ↔ x=scale (dot q x) q := by
  constructor
  · intro h
    funext k
    have hw : Hyper q (add (unit k) (scale (q k) q)) := by
      simp only [Hyper,dot_add,dot_unit_right,dot_scale,hq,Bool.and_true,Bool.xor_self]
    have he := h _ hw
    rw [dot_add_left,dot_unit,dot_symmetric (scale (q k) q) x,dot_scale,dot_symmetric x q] at he
    change x k=(dot q x && q k)
    cases hx : x k <;> cases hd : dot q x <;> cases hk : q k <;> simp_all
  · intro hx w hw
    rw [hx,dot_scale,dot_symmetric w q,hw,Bool.and_false]

theorem hyper_frame (q : Vec) (hq : dot q q=true) (v : Vec × Vec) :
    Frame (Hyper q) v ↔ v.1=add v.2 (scale (dot q v.2) q) := by
  constructor
  · intro ⟨hx,ho⟩
    have he := (hyper_orthogonal q hq (add v.1 v.2)).mp ho
    rw [dot_add,hx,Bool.false_xor] at he
    have hc := congrArg (fun x => add x v.2) he
    dsimp only at hc
    rw [add_assoc,add_self,add_zero] at hc
    exact hc.trans (add_comm _ _)
  · intro hx
    constructor
    · simp only [Hyper,hx,dot_add,dot_scale,hq,Bool.and_true,Bool.xor_self]
    · apply (hyper_orthogonal q hq _).mpr
      rw [hx]
      have he : add (add v.2 (scale (dot q v.2) q)) v.2=scale (dot q v.2) q := by
        rw [add_comm v.2,add_assoc,add_self,add_zero]
      rw [he,dot_scale,hq,Bool.and_true]

theorem target_preimage (q : Vec) (hq : dot q q=true) (v : Vec × Vec) :
    (targetLabel q v).1=zero ↔ Frame (Hyper q) v := by
  rw [hyper_frame q hq]
  change add (add v.1 (scale (dot v.2 q) q)) v.2=zero ↔ _
  rw [add_assoc,dot_symmetric v.2 q,add_comm (scale _ q),CoordinateFrames.add_eq_zero]

theorem line_unique (p q : Vec) (hp : dot p p=true) (hq : dot q q=true)
    (h : Line p=Line q) : p=q := by
  have he : Line q p := h ▸ Or.inr rfl
  rcases he with he | he
  · exact False.elim (norm_nonzero p hp he)
  · exact he

theorem hyper_unique (p q : Vec) (hp : dot p p=true) (hq : dot q q=true)
    (h : Hyper p=Hyper q) : p=q := by
  have ho : ∀w, Hyper q w → dot w p=false := by
    intro w hw
    have he : Hyper p w := h ▸ hw
    exact (dot_symmetric w p).trans he
  have he := (hyper_orthogonal q hq p).mp ho
  cases hd : dot q p
  · rw [hd] at he
    exact False.elim (norm_nonzero p hp he)
  · simpa only [hd] using he

end EndpointGeometry
#print axioms EndpointGeometry.norm_nonzero
#print axioms EndpointGeometry.scalar_cases
#print axioms EndpointGeometry.line_frame
#print axioms EndpointGeometry.line_preimage
#print axioms EndpointGeometry.hyper_orthogonal
#print axioms EndpointGeometry.hyper_frame
#print axioms EndpointGeometry.target_preimage
#print axioms EndpointGeometry.line_unique
#print axioms EndpointGeometry.hyper_unique
