import SequentialPairLoop
namespace ActualSequentialC
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs SequentialPairKernel SequentialPairLoop Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

@[irreducible] def child (a b : F) (s : State Vec F) :=
  loop a b (embed false) (embed true) (addresses 23) s

theorem memory_exact (i a b : F) (ha : a=GaussianGate.a i) (hb : b=GaussianGate.b i) (s : State Vec F) :
    (child a b s).1.memory=Coordinate21PairProgram.applyPairs i s.memory := by
  subst a
  subst b
  rw [child,loop_memory]
  apply PairMemoryReadout.from_pairs (Coordinate21PairProgram.evalPair i)
  intro k
  have h:=DisjointPairLoop.run_pair (embed false) (embed true) ActualCoordinate21InPlace.geometry
    (transform (GaussianGate.a i) (GaussianGate.b i)) (addresses 23) (addresses_nodup 23) s.memory k
  rw [if_pos (all_addresses 23 k)] at h
  exact h

theorem gate_exact (i a b : F) (ha : a=GaussianGate.a i) (hb : b=GaussianGate.b i) (s : State Vec F) :
    (child a b s).1.memory=CoordinateChild.gate i 21 s.memory := by
  rw [memory_exact i a b ha hb,Coordinate21PairProgram.function_semantics]

theorem child_receipt (a b : F) (s : State Vec F) :
    (child a b s).2=⟨16777216,16777216,33554432,16777216⟩ := by
  rw [child,loop_cost,Coordinate21Pairs.pair_count]
  rfl

theorem prefix_invariant (a b : F) (n : Nat) (s : State Vec F) (k : Bits 23) :
    DisjointPairLoop.readPair (embed false) (embed true)
      (loop a b (embed false) (embed true) ((addresses 23).take n) s).1.memory k=
    if k∈(addresses 23).take n then transform a b (DisjointPairLoop.readPair (embed false) (embed true) s.memory k)
    else DisjointPairLoop.readPair (embed false) (embed true) s.memory k :=
  pair_invariant a b (embed false) (embed true) ActualCoordinate21InPlace.geometry _ ((addresses_nodup 23).take) s k

theorem arbitrary_register_entrance (i a b : F) (ha : a=GaussianGate.a i) (hb : b=GaussianGate.b i)
    (f : Vec → F) (r q : Register → F) : (child a b ⟨f,r⟩).1.memory=(child a b ⟨f,q⟩).1.memory := by
  rw [memory_exact i a b ha hb,memory_exact i a b ha hb]

end ActualSequentialC
#print axioms ActualSequentialC.memory_exact
#print axioms ActualSequentialC.gate_exact
#print axioms ActualSequentialC.child_receipt
#print axioms ActualSequentialC.prefix_invariant
#print axioms ActualSequentialC.arbitrary_register_entrance
