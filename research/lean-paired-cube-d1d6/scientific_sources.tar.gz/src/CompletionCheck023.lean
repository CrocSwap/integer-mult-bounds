import CompletionData
namespace CompletionCheck023
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch023.all CompletionCertificates.check=true := by decide
end CompletionCheck023
#print axioms CompletionCheck023.valid
