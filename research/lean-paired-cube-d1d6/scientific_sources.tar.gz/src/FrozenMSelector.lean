import EntranceDomain
import ActualWordTransport
namespace FrozenMSelector
open BinarySpace24 CommonExactFrame Lean.Grind FiniteWordTransport FrameLogicalStep ExactTransportTrace
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

noncomputable def select (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) : ExactFrame Vec F := by
  classical
  exact if hk : ActualOperationSelector.InRange k then
    (ActualOperationSelector.keyRepresentative i hi htwo k hk).toExactFrame
  else CertifiedRepresentative.zeroRep.toExactFrame

theorem operation_key (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : ActualOperationSelector.InRange k) :
    select i hi htwo k=(ActualOperationSelector.keyRepresentative i hi htwo k hk).toExactFrame := by
  simp only [select,dif_pos hk]

theorem zero_key (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) :
    select i hi htwo 0=(CertifiedRepresentative.zeroRep (F:=F)).toExactFrame := by
  have hn : ¬ActualOperationSelector.InRange 0 := by
    intro h
    have hpos := h.1
    omega
  simp only [select,dif_neg hn]

theorem zero_encode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (select i hi htwo 0).encode f=f := by rw [zero_key]; rfl

theorem zero_decode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (select i hi htwo 0).decode f=f := by rw [zero_key]; rfl

theorem compatible (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) :
    ActualWordTransport.Compatible (select i hi htwo) i hi htwo := operation_key i hi htwo

theorem every_prefix_uses_covered_representative (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (n r : Nat) :
    let k := GaugeKeyTrace.run (PairedWordData.word.take n) ActualEntranceKeys.key r
    (k=0 ∧ select i hi htwo k=(CertifiedRepresentative.zeroRep (F:=F)).toExactFrame) ∨
    (∃ hk : ActualOperationSelector.InRange k,
      select i hi htwo k=(ActualOperationSelector.keyRepresentative i hi htwo k hk).toExactFrame) := by
  rcases EntranceDomain.prefix_key_zero_or_positive n r with hz | hk
  · exact Or.inl ⟨hz,hz ▸ zero_key i hi htwo⟩
  · exact Or.inr ⟨hk,operation_key i hi htwo _ hk⟩

theorem actual_frozen_word_commuting (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (v : Arrays Vec F) :
    (∀ s (hs : s ∈ PairedWordData.word),
      select i hi htwo (ActualFrameKeys.key s)=(ActualOperationSelector.stepRepresentative i hi htwo s hs).toExactFrame) ∧
    physical (select i hi htwo) ActualEntranceKeys.key (encode (select i hi htwo) ActualEntranceKeys.key v)=
      (finalKeys ActualEntranceKeys.key,encode (select i hi htwo) (finalKeys ActualEntranceKeys.key)
        (fun r x => FieldWordTrace.run PairedWordData.word (fun j => v j x) r)) :=
  ActualWordTransport.actual_bound_word (select i hi htwo) i hi htwo (compatible i hi htwo) ActualEntranceKeys.key v

theorem actual_decoded_word (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (v : Arrays Vec F) (x : Vec) :
    decodedState (select i hi htwo) ActualEntranceKeys.key v x=
      FieldWordTrace.run PairedWordData.word (fun j => v j x) :=
  decoded_state_eq (select i hi htwo) ActualEntranceKeys.key v x

end FrozenMSelector
#print axioms FrozenMSelector.operation_key
#print axioms FrozenMSelector.zero_key
#print axioms FrozenMSelector.zero_encode
#print axioms FrozenMSelector.zero_decode
#print axioms FrozenMSelector.compatible
#print axioms FrozenMSelector.every_prefix_uses_covered_representative
#print axioms FrozenMSelector.actual_frozen_word_commuting
#print axioms FrozenMSelector.actual_decoded_word
