import NestedCoordinateTransition
namespace ExactTransitionFactor
open BinarySpace24 CommonExactFrame Lean.Grind
variable {F : Type u} [Field F]

theorem through_child (A B J K : ExactFrame Vec F) (child : (Vec → F) → (Vec → F))
    (hc : ∀f,adapter J K f=child f) (f : Vec → F) :
    adapter A B f=adapter K B (child (adapter A J f)) := calc
  adapter A B f=adapter K B (adapter J K (adapter A J f)) := NestedCoordinateTransition.factor_through A B J K f
  _=adapter K B (child (adapter A J f)) := congrArg (adapter K B) (hc _)

end ExactTransitionFactor
#print axioms ExactTransitionFactor.through_child
