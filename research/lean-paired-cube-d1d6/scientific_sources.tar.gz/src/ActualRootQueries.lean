import EndpointSpanSeparation
namespace ActualRootQueries
open BinarySpace24 BinaryCompletion VariableCertificates CatalogSpanBridge CompletionFrames SpanSeparator EndpointSpanSeparation

def sourceQuery : Query := ⟨RootJointGeometry.incoming,[37,21,3]⟩
def rootQuery : Query := ⟨RootJointGeometry.root,[37,21]⟩

theorem source_valid : queryCheck sourceQuery=true := by decide

theorem root_valid : queryCheck rootQuery=true := by decide

theorem source_facts : Facts sourceQuery.basis :=
  check_sound _ (List.all_eq_true.mp OperationFrameCatalog.valid _ RootReadoutBinding.incoming_member)

theorem root_facts : Facts rootQuery.basis :=
  RootPilotGeometry.facts RootPilotData.cert0 RootPilotGeometry.member0

theorem query_keys : sourceQuery.basis.key=15704 ∧ rootQuery.basis.key=17401 := ⟨rfl,rfl⟩

theorem unit23_literal : fromNat 8388608=unit 23 := by apply SourceLineCase.vector_check; decide

theorem unit22_literal : fromNat 4194304=unit 22 := by apply SourceLineCase.vector_check; decide

theorem source_units : Span sourceQuery.basis (unit 23) ∧ Span sourceQuery.basis (unit 22) := by
  have h23 := has_row_in_span sourceQuery.basis source_facts 8388608 (by decide)
  have h22 := has_row_in_span sourceQuery.basis source_facts 4194304 (by decide)
  rw [unit23_literal] at h23
  rw [unit22_literal] at h22
  exact ⟨h23,h22⟩

theorem root_units : Span rootQuery.basis (unit 23) ∧ Span rootQuery.basis (unit 22) := by
  have h23 := has_row_in_span rootQuery.basis root_facts 8388608 (by decide)
  have h22 := has_row_in_span rootQuery.basis root_facts 4194304 (by decide)
  rw [unit23_literal] at h23
  rw [unit22_literal] at h22
  exact ⟨h23,h22⟩

theorem normals_distinct : fromNat 37≠fromNat 21 := by
  intro he
  have h := congrFun he 5
  change true=false at h
  contradiction

theorem source_other : PiecewiseSelector.Other (Span sourceQuery.basis) :=
  other_of_witnesses (Span sourceQuery.basis) (unit 23) (unit 22) (fromNat 37) (fromNat 21)
    source_units.1 source_units.2 (unit_nonzero 23) (unit_nonzero 22) (unit_distinct 23 22 (by decide))
    (by decide) (by decide) normals_distinct
    (fun y hy => query_orthogonal sourceQuery source_valid 37 (by decide) y hy)
    (fun y hy => query_orthogonal sourceQuery source_valid 21 (by decide) y hy)

theorem root_other : PiecewiseSelector.Other (Span rootQuery.basis) :=
  other_of_witnesses (Span rootQuery.basis) (unit 23) (unit 22) (fromNat 37) (fromNat 21)
    root_units.1 root_units.2 (unit_nonzero 23) (unit_nonzero 22) (unit_distinct 23 22 (by decide))
    (by decide) (by decide) normals_distinct
    (fun y hy => query_orthogonal rootQuery root_valid 37 (by decide) y hy)
    (fun y hy => query_orthogonal rootQuery root_valid 21 (by decide) y hy)

end ActualRootQueries
#print axioms ActualRootQueries.source_valid
#print axioms ActualRootQueries.root_valid
#print axioms ActualRootQueries.source_facts
#print axioms ActualRootQueries.root_facts
#print axioms ActualRootQueries.query_keys
#print axioms ActualRootQueries.unit23_literal
#print axioms ActualRootQueries.unit22_literal
#print axioms ActualRootQueries.source_units
#print axioms ActualRootQueries.root_units
#print axioms ActualRootQueries.normals_distinct
#print axioms ActualRootQueries.source_other
#print axioms ActualRootQueries.root_other
