import CompletionData
namespace CompletionPilot
theorem pilot_valid : CompletionCertificates.check CompletionData.cert000_0=true := by decide
end CompletionPilot
#print axioms CompletionPilot.pilot_valid
