import CompletionFrames
namespace CoordinateFrames
open BinarySpace24 BinaryCompletion CompletionCertificates CompletionFrames PrivateShear TensorThree

def projection (z : Vec) : Vec := coordinates (z 0,z 1,z 2)
def label (v : Vec × Vec) : Vec × Vec := (add v.1 (projection v.2),v.2)

theorem add_eq_zero (x y : Vec) : add x y=zero ↔ x=y := by
  constructor
  · intro h
    funext k
    have he := congrFun h k
    cases hx : x k <;> cases hy : y k <;> simp_all [add,zero]
  · intro h; subst y; exact add_self x

theorem coordinates_values (bits : CarrierCoordinates.Coordinates) :
    (coordinates bits 0,coordinates bits 1,coordinates bits 2)=bits := by
  simp [coordinates,combine,add,scale,unit,index]

theorem projection_in_space (z : Vec) : CoordinateSpace (projection z) := ⟨(z 0,z 1,z 2),rfl⟩

theorem projection_identity (u : Vec) (hu : CoordinateSpace u) : projection u=u := by
  rcases hu with ⟨bits,rfl⟩
  unfold projection
  rw [coordinates_values]

theorem selected_unit (axis : Axis) : CoordinateSpace (unit (index axis)) := by
  cases axis
  · exact ⟨(true,false,false),by funext k; simp [coordinates,combine,add,scale,unit,index]⟩
  · exact ⟨(false,true,false),by funext k; simp [coordinates,combine,add,scale,unit,index]⟩
  · exact ⟨(false,false,true),by funext k; simp [coordinates,combine,add,scale,unit,index]⟩

theorem selected_projection (z : Vec) (axis : Axis) : projection z (index axis)=z (index axis) := by
  cases axis <;> simp [projection,coordinates,combine,add,scale,unit,index]

theorem coordinate_frame (v : Vec × Vec) : Frame CoordinateSpace v ↔ v.1=projection v.2 := by
  constructor
  · rintro ⟨hU,horth⟩
    have hbits (axis : Axis) : v.1 (index axis)=v.2 (index axis) := by
      have h := horth (unit (index axis)) (selected_unit axis)
      rw [dot_unit] at h
      change (v.1 (index axis) ^^ v.2 (index axis))=false at h
      cases h0 : v.1 (index axis) <;> cases h1 : v.2 (index axis) <;> simp_all
    rw [← projection_identity v.1 hU]
    unfold projection
    have h0 : v.1 0=v.2 0 := hbits .first
    have h1 : v.1 1=v.2 1 := hbits .second
    have h2 : v.1 2=v.2 2 := hbits .third
    rw [h0,h1,h2]
  · intro he
    refine ⟨he ▸ projection_in_space v.2,?_⟩
    rintro y ⟨bits,rfl⟩
    rw [he]
    simp only [coordinates,dot_combine,dot_unit]
    have hz (axis : Axis) : add (projection v.2) v.2 (index axis)=false := by
      simp only [add,selected_projection,Bool.xor_self]
    rw [hz .first,hz .second,hz .third]
    simp

theorem frame_preimage (v : Vec × Vec) : (label v).1=zero ↔ Frame CoordinateSpace v := by
  change add v.1 (projection v.2)=zero ↔ _
  rw [add_eq_zero,coordinate_frame]

theorem label_involution (v : Vec × Vec) : label (label v)=v := by
  simp only [label,add_assoc,add_self,add_zero]

end CoordinateFrames
#print axioms CoordinateFrames.add_eq_zero
#print axioms CoordinateFrames.coordinates_values
#print axioms CoordinateFrames.projection_in_space
#print axioms CoordinateFrames.projection_identity
#print axioms CoordinateFrames.selected_unit
#print axioms CoordinateFrames.selected_projection
#print axioms CoordinateFrames.coordinate_frame
#print axioms CoordinateFrames.frame_preimage
#print axioms CoordinateFrames.label_involution
