import OuterAddressCircuits
namespace CountedPhaseLanguage
open BinarySpace24 FourthRootRecipe Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

structure Cost where
  bitReads : Nat
  booleanXors : Nat
  booleanAnds : Nat
  booleanNots : Nat
  fieldSelections : Nat
  scalarMultiplications : Nat
  deriving DecidableEq

def zero : Cost := ⟨0,0,0,0,0,0⟩
def add (a b : Cost) : Cost := ⟨a.bitReads+b.bitReads,a.booleanXors+b.booleanXors,
  a.booleanAnds+b.booleanAnds,a.booleanNots+b.booleanNots,
  a.fieldSelections+b.fieldSelections,a.scalarMultiplications+b.scalarMultiplications⟩
def readCost : Cost := ⟨1,0,0,0,0,0⟩
def xorCost : Cost := ⟨0,1,0,0,0,0⟩
def andCost : Cost := ⟨0,0,1,0,0,0⟩
def notCost : Cost := ⟨0,0,0,1,0,0⟩
def selectCost : Cost := ⟨0,0,0,0,1,0⟩
def multiplyCost : Cost := ⟨0,0,0,0,0,1⟩

inductive BExpr where
  | read : Nat → Index → BExpr
  | xor : BExpr → BExpr → BExpr
  | and : BExpr → BExpr → BExpr
  | not : BExpr → BExpr

def BExpr.eval (r : Nat → Vec) : BExpr → Bool
  | .read k j => r k j
  | .xor a b => a.eval r ^^ b.eval r
  | .and a b => a.eval r && b.eval r
  | .not a => !a.eval r

def BExpr.cost : BExpr → Cost
  | .read _ _ => readCost
  | .xor a b => add (add a.cost b.cost) xorCost
  | .and a b => add (add a.cost b.cost) andCost
  | .not a => add a.cost notCost

def BExpr.run (r : Nat → Vec) : BExpr → Bool × Cost
  | .read k j => (r k j,readCost)
  | .xor a b => let x:=a.run r; let y:=b.run r; (x.1 ^^ y.1,add (add x.2 y.2) xorCost)
  | .and a b => let x:=a.run r; let y:=b.run r; (x.1 && y.1,add (add x.2 y.2) andCost)
  | .not a => let x:=a.run r; (!x.1,add x.2 notCost)

theorem boolean_evaluation (r : Nat → Vec) (e : BExpr) : e.run r=(e.eval r,e.cost) := by
  induction e with
  | read k j => rfl
  | xor a b ha hb => simp only [BExpr.run,ha,hb,BExpr.eval,BExpr.cost]
  | and a b ha hb => simp only [BExpr.run,ha,hb,BExpr.eval,BExpr.cost]
  | not a ha => simp only [BExpr.run,ha,BExpr.eval,BExpr.cost]

inductive PExpr where
  | one
  | root : Bool → BExpr → PExpr
  | sign : BExpr → PExpr
  | times : PExpr → PExpr → PExpr

def PExpr.eval (i : F) (r : Nat → Vec) : PExpr → F
  | .one => 1
  | .root neg b => rootPhase (if neg then -i else i) (b.eval r)
  | .sign b => QuadraticPhase.sign (b.eval r)
  | .times a b => a.eval i r*b.eval i r

def PExpr.cost : PExpr → Cost
  | .one => zero
  | .root _ b => add b.cost selectCost
  | .sign b => add b.cost selectCost
  | .times a b => add (add a.cost b.cost) multiplyCost

def PExpr.run (i : F) (r : Nat → Vec) : PExpr → F × Cost
  | .one => (1,zero)
  | .root neg b => let v:=b.run r; (rootPhase (if neg then -i else i) v.1,add v.2 selectCost)
  | .sign b => let v:=b.run r; (QuadraticPhase.sign v.1,add v.2 selectCost)
  | .times a b => let x:=a.run i r; let y:=b.run i r; (x.1*y.1,add (add x.2 y.2) multiplyCost)

theorem phase_evaluation (i : F) (r : Nat → Vec) (e : PExpr) : e.run i r=(e.eval i r,e.cost) := by
  induction e with
  | one => rfl
  | root neg b => simp only [PExpr.run,boolean_evaluation,PExpr.eval,PExpr.cost]
  | sign b => simp only [PExpr.run,boolean_evaluation,PExpr.eval,PExpr.cost]
  | times a b ha hb => simp only [PExpr.run,ha,hb,PExpr.eval,PExpr.cost]

def coordinate (negative : Bool) (reg : Nat) : List Index → PExpr
  | [] => .one
  | j::js => .times (.root negative (.read reg j)) (coordinate negative reg js)

theorem coordinate_eval (i : F) (r : Nat → Vec) (negative : Bool) (reg : Nat) (js : List Index) :
    (coordinate negative reg js).eval i r=
      phase (if negative then -i else i) (CanonicalGramRecipe.unitTerms js) (r reg) := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    simp only [coordinate,PExpr.eval,BExpr.eval,ih,CanonicalGramRecipe.unitTerms,List.map_cons,phase,termPhase,dot_unit]

theorem coordinate_cost (negative : Bool) (reg : Nat) (js : List Index) :
    (coordinate negative reg js).cost=⟨js.length,0,0,0,js.length,js.length⟩ := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    simp only [coordinate,PExpr.cost,BExpr.cost,ih,add,readCost,selectCost,multiplyCost,List.length_cons]
    congr 1 <;> omega

end CountedPhaseLanguage
#print axioms CountedPhaseLanguage.boolean_evaluation
#print axioms CountedPhaseLanguage.phase_evaluation
#print axioms CountedPhaseLanguage.coordinate_eval
#print axioms CountedPhaseLanguage.coordinate_cost
