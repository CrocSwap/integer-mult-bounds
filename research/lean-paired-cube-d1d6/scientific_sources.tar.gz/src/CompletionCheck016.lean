import CompletionData
namespace CompletionCheck016
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch016.all CompletionCertificates.check=true := by decide
end CompletionCheck016
#print axioms CompletionCheck016.valid
