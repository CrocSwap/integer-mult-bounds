import CompletionData
namespace CompletionCheck009
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch009.all CompletionCertificates.check=true := by decide
end CompletionCheck009
#print axioms CompletionCheck009.valid
