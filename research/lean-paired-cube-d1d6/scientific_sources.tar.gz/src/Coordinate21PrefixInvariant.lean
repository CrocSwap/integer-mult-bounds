import ActualCoordinate21InPlace
namespace Coordinate21PrefixInvariant
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

def prefixState (n : Nat) (i : F) (f : Vec → F) (scratchLeft scratchRight : F) :=
  PairLoadStoreMachine.runPairs (embed false) (embed true) (Coordinate21PairProgram.evalPair i)
    ((addresses 23).take n) ⟨f,scratchLeft,scratchRight⟩

theorem prefix_pair (n : Nat) (i : F) (f : Vec → F) (scratchLeft scratchRight : F) (k : Bits 23) :
    DisjointPairLoop.readPair (embed false) (embed true) (prefixState n i f scratchLeft scratchRight).memory k=
      if k∈(addresses 23).take n then Coordinate21PairProgram.evalPair i (f (embed false k),f (embed true k))
      else (f (embed false k),f (embed true k)) := by
  rw [prefixState,PairLoadStoreMachine.memory_run]
  exact DisjointPairLoop.run_pair _ _ ActualCoordinate21InPlace.geometry _ _ (addresses_nodup 23).take f k

theorem untouched_address (n : Nat) (i : F) (f : Vec → F) (scratchLeft scratchRight : F)
    (x : Vec) (h : Coordinate21Pairs.drop x∉(addresses 23).take n) :
    (prefixState n i f scratchLeft scratchRight).memory x=f x := by
  rw [prefixState,PairLoadStoreMachine.memory_run]
  apply DisjointPairLoop.run_untouched
  intro k hk
  constructor
  · intro he
    apply h
    rw [he,drop_embed]
    exact hk
  · intro he
    apply h
    rw [he,drop_embed]
    exact hk

theorem processed_pair (n : Nat) (i : F) (f : Vec → F) (scratchLeft scratchRight : F)
    (k : Bits 23) (h : k∈(addresses 23).take n) :
    DisjointPairLoop.readPair (embed false) (embed true) (prefixState n i f scratchLeft scratchRight).memory k=
      Coordinate21PairProgram.evalPair i (f (embed false k),f (embed true k)) := by
  rw [prefix_pair,if_pos h]

theorem scratch_independent (i : F) (f : Vec → F) (a b c d : F) :
    (ActualCoordinate21InPlace.stage i f a b).memory=(ActualCoordinate21InPlace.stage i f c d).memory := by
  rw [ActualCoordinate21InPlace.memory_exact,ActualCoordinate21InPlace.memory_exact]

theorem prefix_load_store_count (n : Nat) :
    PairLoadStoreMachine.loopLoads ((addresses 23).take n)=2*min n 8388608 ∧
    PairLoadStoreMachine.loopStores ((addresses 23).take n)=2*min n 8388608 := by
  have h := PairLoadStoreMachine.loop_receipt ((addresses 23).take n)
  rw [List.length_take,Coordinate21Pairs.pair_count] at h
  exact h

end Coordinate21PrefixInvariant
#print axioms Coordinate21PrefixInvariant.prefix_pair
#print axioms Coordinate21PrefixInvariant.untouched_address
#print axioms Coordinate21PrefixInvariant.processed_pair
#print axioms Coordinate21PrefixInvariant.scratch_independent
#print axioms Coordinate21PrefixInvariant.prefix_load_store_count
