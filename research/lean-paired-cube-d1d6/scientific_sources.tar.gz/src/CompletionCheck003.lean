import CompletionData
namespace CompletionCheck003
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch003.all CompletionCertificates.check=true := by decide
end CompletionCheck003
#print axioms CompletionCheck003.valid
