import BinaryPortOrthogonality
import FrameIndependence
import CubeGeometry
namespace BinaryPort
open BinaryFrame
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def selectorParity (i : Nat) : Bool := decide (CubeGeometry.bitCount 3 i % 2 = 1)
def sourceIndices (parity : Bool) : List Nat :=
  if parity then [1,2,4,7] else [0,3,5,6]
def ports (cube : List Nat) (parity : Bool) : List Nat :=
  (sourceIndices parity).map (fun i => cube[i]?.getD 0)
def carrier (cube : List Nat) (parity : Bool) : List Nat := (ports cube parity).take 3

def witnesses (cube : List Nat) (parity : Bool) : List (List Nat) :=
  let qs := ports cube parity
  [[qs[0]?.getD 0],[qs[1]?.getD 0],[qs[2]?.getD 0],
    [qs[0]?.getD 0,qs[1]?.getD 0,qs[2]?.getD 0]]

structure CarrierCertificate where
  pivots : List Nat
  triplePivots : List (List Nat)

def triplesCheck (cube : List Nat) (parity : Bool) (cert : CarrierCertificate) : Bool :=
  (List.range 4).all (fun omitted =>
    rankCheck ((ports cube parity).eraseIdx omitted) (cert.triplePivots[omitted]?.getD []) 3)

def carrierCheck (cube : List Nat) (parity : Bool) (cert : CarrierCertificate) : Bool :=
  decide (cube.length=8) &&
  (cube.all (fun q => decide (0<q ∧ q<2^24)) &&
  (rankCheck (carrier cube parity) cert.pivots 3 &&
  (containmentCheck (ports cube parity) (carrier cube parity) (witnesses cube parity) &&
  ((ports cube (!parity)).all (fun q => (carrier cube parity).all (fun b => decide (dot 24 q b=false))) &&
    triplesCheck cube parity cert))))

structure CarrierFacts (cube : List Nat) (parity : Bool) : Prop where
  cube_length : cube.length=8
  inputs_valid : ∀ q ∈ cube, 0<q ∧ q<2^24
  carrier_rank : (carrier cube parity).length=3 ∧ Independent (carrier cube parity)
  source_contains : ∀ x, Span (ports cube parity) x → Span (carrier cube parity) x
  carrier_orthogonal : ∀ q ∈ ports cube (!parity), ∀ x, Span (carrier cube parity) x → dot 24 q x=false
  triples_rank : ∀ omitted, omitted<4 →
    ((ports cube parity).eraseIdx omitted).length=3 ∧ Independent ((ports cube parity).eraseIdx omitted)

theorem ports_count (cube : List Nat) (parity : Bool) : (ports cube parity).length=4 := by
  cases parity <;> simp [ports, sourceIndices]

theorem selector_indices_exact (parity : Bool) :
    sourceIndices parity = (List.range 8).filter (fun i => selectorParity i == parity) := by
  cases parity <;> decide

theorem k2_uses_opposite_parity : ∀ i j : Fin 8,
    PairedCubeIdentities.k2 i.val j.val ≠ 0 → selectorParity i.val ≠ selectorParity j.val := by decide

theorem carrierCheck_sound (cube : List Nat) (parity : Bool) (cert : CarrierCertificate)
    (h : carrierCheck cube parity cert=true) : CarrierFacts cube parity := by
  have h0 := Bool.and_eq_true_iff.mp h
  have h1 := Bool.and_eq_true_iff.mp h0.2
  have h2 := Bool.and_eq_true_iff.mp h1.2
  have h3 := Bool.and_eq_true_iff.mp h2.2
  have h4 := Bool.and_eq_true_iff.mp h3.2
  refine ⟨of_decide_eq_true h0.1, ?_, rankCheck_sound _ _ 3 h2.1,
    containmentCheck_sound _ _ _ h3.1, ?_, ?_⟩
  · intro q hq
    exact of_decide_eq_true ((List.all_eq_true.mp h1.1) q hq)
  · intro q hq
    apply span_orthogonal 24 q (carrier cube parity)
    intro b hb
    exact of_decide_eq_true ((List.all_eq_true.mp ((List.all_eq_true.mp h4.1) q hq)) b hb)
  · intro omitted ho
    exact rankCheck_sound _ _ 3 ((List.all_eq_true.mp h4.2) omitted (List.mem_range.mpr ho))

theorem source_line_enters (cube : List Nat) (parity : Bool) (hf : CarrierFacts cube parity)
    (q : Nat) (hq : q ∈ ports cube parity) :
    ∀ x, Span [q] x → Span (carrier cube parity) x := by
  apply span_mono [q] (carrier cube parity)
  intro b hb
  have he : b=q := List.mem_singleton.mp hb
  subst b
  exact hf.source_contains q (Span.generator hq)

theorem carrier_span_equals_sources (cube : List Nat) (parity : Bool) (hf : CarrierFacts cube parity)
    (x : Nat) : Span (carrier cube parity) x ↔ Span (ports cube parity) x := by
  constructor
  · apply span_mono (carrier cube parity) (ports cube parity)
    intro b hb
    exact Span.generator (List.mem_of_mem_take hb)
  · exact hf.source_contains x

structure CubeCertificate where
  cube : List Nat
  even : CarrierCertificate
  odd : CarrierCertificate

def cubePortCheck (c : CubeCertificate) : Bool :=
  carrierCheck c.cube false c.even && carrierCheck c.cube true c.odd

theorem cubePortCheck_sound (c : CubeCertificate) (h : cubePortCheck c=true) :
    ∀ parity, CarrierFacts c.cube parity := by
  have hh := Bool.and_eq_true_iff.mp h
  intro parity
  cases parity with
  | false => exact carrierCheck_sound c.cube false c.even hh.1
  | true => exact carrierCheck_sound c.cube true c.odd hh.2

end BinaryPort
#print axioms BinaryPort.ports_count
#print axioms BinaryPort.selector_indices_exact
#print axioms BinaryPort.k2_uses_opposite_parity
#print axioms BinaryPort.carrierCheck_sound
#print axioms BinaryPort.source_line_enters
#print axioms BinaryPort.carrier_span_equals_sources
#print axioms BinaryPort.cubePortCheck_sound
