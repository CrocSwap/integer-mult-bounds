import Coordinate21Pairs
namespace Coordinate21PairProgram
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def evalPair (i : F) (v : F × F) :=
  (InversePairProgram.eval (GaussianGate.a i) (GaussianGate.b i) v InversePairProgram.first,
   InversePairProgram.eval (GaussianGate.a i) (GaussianGate.b i) v InversePairProgram.second)
def applyPairs (i : F) (f : Vec → F) (x : Vec) :=
  let y := Coordinate21Pairs.drop x
  let v := evalPair i (f (embed false y),f (embed true y))
  if x 21 then v.2 else v.1

theorem expression_exact (i : F) (v : F × F) : evalPair i v=GaussianGate.C i v := rfl

theorem pair_semantics (i : F) (f : Vec → F) (y : Bits 23) :
    (CoordinateChild.gate i 21 f (embed false y),CoordinateChild.gate i 21 f (embed true y))=
      evalPair i (f (embed false y),f (embed true y)) := by
  have h := InvolutionGate.gate_pair i (CoordinateChild.flip 21) (CoordinateChild.flip_twice 21) f (embed false y)
  rw [pair_flip] at h
  exact h

theorem function_semantics (i : F) (f : Vec → F) : applyPairs i f=CoordinateChild.gate i 21 f := by
  funext x
  have h := pair_semantics i f (Coordinate21Pairs.drop x)
  have hx := embed_drop x
  cases hb : x 21
  · rw [hb] at hx
    simp only [applyPairs,hb,Bool.false_eq_true,if_false]
    exact (congrArg Prod.fst h).symm.trans (congrArg (CoordinateChild.gate i 21 f) hx)
  · rw [hb] at hx
    simp only [applyPairs,hb,if_true]
    exact (congrArg Prod.snd h).symm.trans (congrArg (CoordinateChild.gate i 21 f) hx)

theorem per_pair_counts :
    InversePairProgram.mults InversePairProgram.first+InversePairProgram.mults InversePairProgram.second=4 ∧
    InversePairProgram.adds InversePairProgram.first+InversePairProgram.adds InversePairProgram.second=2 :=
  InversePairProgram.pair_primitive_counts

theorem scheduled_counts :
    (addresses 23).length*(InversePairProgram.mults InversePairProgram.first+InversePairProgram.mults InversePairProgram.second)=33554432 ∧
    (addresses 23).length*(InversePairProgram.adds InversePairProgram.first+InversePairProgram.adds InversePairProgram.second)=16777216 := by
  rw [Coordinate21Pairs.pair_count,per_pair_counts.1,per_pair_counts.2]
  decide

theorem actual_event (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (g : GaugeKeyTrace.State) (f : Vec → F) :
    CommonExactFrame.adapter (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 3 g 17326))
      (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 4 g 17326)) f=
      OuterAddressCircuits.leftPass i (applyPairs i (OuterAddressCircuits.rightPass i f)) := by
  rw [OuterAddressCircuits.actual_event,OuterAddressCircuits.lowered,function_semantics]

end Coordinate21PairProgram
#print axioms Coordinate21PairProgram.expression_exact
#print axioms Coordinate21PairProgram.pair_semantics
#print axioms Coordinate21PairProgram.function_semantics
#print axioms Coordinate21PairProgram.per_pair_counts
#print axioms Coordinate21PairProgram.scheduled_counts
#print axioms Coordinate21PairProgram.actual_event
