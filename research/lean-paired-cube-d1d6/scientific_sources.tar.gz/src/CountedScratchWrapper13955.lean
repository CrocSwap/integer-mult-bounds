import FiniteScratchStoreLoad13955

namespace CountedScratchWrapper13955

open ScratchRestoreContract13955 FiniteScratchStoreLoad13955

variable {P : Type u} {V : Type v} {n : Nat}

/-- Counted memory traffic. A store reads a scratch register; a load writes one.
    Those register endpoints are part of the instruction, not extra hidden copies. -/
structure Traffic where
  loads : Nat
  stores : Nat
  deriving DecidableEq

def Traffic.zero : Traffic := ⟨0, 0⟩
def Traffic.add (a b : Traffic) : Traffic := ⟨a.loads + b.loads, a.stores + b.stores⟩

def instructionTraffic : Instruction n → Traffic
  | .storeSpill _ => ⟨0, 1⟩
  | .loadSpill _ => ⟨1, 0⟩

def codeTraffic : List (Instruction n) → Traffic
  | [] => Traffic.zero
  | i :: code => (instructionTraffic i).add (codeTraffic code)

def countedRun : List (Instruction n) → Machine P V n → Machine P V n × Traffic
  | [], s => (s, Traffic.zero)
  | i :: code, s =>
    let tail := countedRun code (execute i s)
    (tail.1, (instructionTraffic i).add tail.2)

theorem countedRun_exact (code : List (Instruction n)) (s : Machine P V n) :
    countedRun code s = (run code s, codeTraffic code) := by
  induction code generalizing s with
  | nil => rfl
  | cons i code ih => simp only [countedRun, ih, run, codeTraffic]

theorem store_traffic (is : List (Fin n)) :
    codeTraffic (is.map Instruction.storeSpill) = ⟨0, is.length⟩ := by
  induction is with
  | nil => rfl
  | cons i rest ih =>
    simp only [List.map_cons, codeTraffic, instructionTraffic, ih, Traffic.add,
      List.length_cons, Nat.zero_add, Nat.add_comm]

theorem load_traffic (is : List (Fin n)) :
    codeTraffic (is.map Instruction.loadSpill) = ⟨is.length, 0⟩ := by
  induction is with
  | nil => rfl
  | cons i rest ih =>
    simp only [List.map_cons, codeTraffic, instructionTraffic, ih, Traffic.add,
      List.length_cons, Nat.zero_add, Nat.add_comm]

theorem save_counted (s : Machine P V n) :
    countedRun (saveCode n) s = (copySave s, ⟨0, n⟩) := by
  rw [countedRun_exact, save_implements_copySave]
  simp only [saveCode, store_traffic, List.length_finRange]

theorem restore_counted (s : Machine P V n) :
    countedRun (restoreCode n) s = (copyRestore s, ⟨n, 0⟩) := by
  rw [countedRun_exact, restore_implements_copyRestore]
  simp only [restoreCode, load_traffic, List.length_finRange]

/-- A counted operation on the caller state leaves the disjoint spill bank inaccessible. -/
def liftCountedBody (body : State P (Registers n V) → State P (Registers n V) × Traffic)
    (s : Machine P V n) : Machine P V n × Traffic :=
  let out := body s.1
  ((out.1, s.2), out.2)

theorem liftCountedBody_preserves_spill
    (body : State P (Registers n V) → State P (Registers n V) × Traffic)
    (s : Machine P V n) : (liftCountedBody body s).1.2 = s.2 := rfl

/-- The body reports its own traffic, which is retained rather than treated as free. -/
def countedWrapper (body : Machine P V n → Machine P V n × Traffic)
    (s : Machine P V n) : Machine P V n × Traffic :=
  let saved := countedRun (saveCode n) s
  let middle := body saved.1
  let restored := countedRun (restoreCode n) middle.1
  (restored.1, (saved.2.add middle.2).add restored.2)

theorem countedWrapper_state (body : Machine P V n → Machine P V n × Traffic)
    (s : Machine P V n) :
    (countedWrapper body s).1 = implementedWrapper (fun t => (body t).1) s := by
  simp only [countedWrapper, countedRun_exact, implementedWrapper]

theorem countedWrapper_traffic (body : Machine P V n → Machine P V n × Traffic)
    (s : Machine P V n) :
    (countedWrapper body s).2 =
      ⟨(body (copySave s)).2.loads + n, n + (body (copySave s)).2.stores⟩ := by
  simp only [countedWrapper, save_counted, restore_counted, Traffic.add,
    Nat.zero_add, Nat.add_zero]

theorem countedWrapper_exact (body : Machine P V n → Machine P V n × Traffic)
    (hspill : ∀ s, (body s).1.2 = s.2) (s : Machine P V n) :
    countedWrapper body s =
      ((((body (copySave s)).1.1.1, s.1.2), s.1.2),
        ⟨(body (copySave s)).2.loads + n, n + (body (copySave s)).2.stores⟩) := by
  apply Prod.ext
  · rw [countedWrapper_state, implementedWrapper_exact _ hspill]
  · exact countedWrapper_traffic body s

/-- Explicit disjoint-bank lifting discharges only the saved-spill premise. -/
theorem lifted_countedWrapper_exact
    (body : State P (Registers n V) → State P (Registers n V) × Traffic)
    (s : Machine P V n) :
    countedWrapper (liftCountedBody body) s =
      ((((body s.1).1.1, s.1.2), s.1.2),
        ⟨(body s.1).2.loads + n, n + (body s.1).2.stores⟩) :=
  countedWrapper_exact _ (liftCountedBody_preserves_spill body) s

theorem countedWrapper_full_restoration_obstruction
    (body : Machine P V n → Machine P V n × Traffic) (s : Machine P V n)
    (hne : s.1.2 ≠ s.2) :
    ¬ ((countedWrapper body s).1.1.2 = s.1.2 ∧
        (countedWrapper body s).1.2 = s.2) := by
  rw [countedWrapper_state, implementedWrapper_matches]
  exact unequal_entry_banks_obstruct_full_restoration _ s hne

theorem countedWrapper_constant_receipt
    (body : Machine P V n → Machine P V n × Traffic) (cost : Traffic)
    (hcost : ∀ s, (body s).2 = cost) (s : Machine P V n) :
    (countedWrapper body s).2 = ⟨cost.loads + n, n + cost.stores⟩ := by
  rw [countedWrapper_traffic, hcost]

theorem countedWrapper_scratch_restored
    (body : Machine P V n → Machine P V n × Traffic)
    (hspill : ∀ s, (body s).1.2 = s.2) (s : Machine P V n) :
    (countedWrapper body s).1.1.2 = s.1.2 := by
  rw [countedWrapper_exact body hspill]

theorem countedWrapper_original_spill_iff
    (body : Machine P V n → Machine P V n × Traffic)
    (hspill : ∀ s, (body s).1.2 = s.2) (s : Machine P V n) :
    (countedWrapper body s).1.2 = s.2 ↔ s.1.2 = s.2 := by
  rw [countedWrapper_exact body hspill]

/-- Distinct tagged cells prevent scratch/spill aliasing in the storage accounting. -/
abbrev Cell (n : Nat) := Fin n ⊕ Fin n

def scratchCells (n : Nat) : List (Cell n) := (List.finRange n).map Sum.inl
def spillCells (n : Nat) : List (Cell n) := (List.finRange n).map Sum.inr
def residentCells (n : Nat) : List (Cell n) := scratchCells n ++ spillCells n

theorem scratch_and_spill_distinct (i j : Fin n) :
    (Sum.inl i : Cell n) ≠ Sum.inr j := by intro h; cases h

theorem extra_spill_words : (spillCells n).length = n := by simp [spillCells]

theorem resident_scratch_and_spill_words : (residentCells n).length = 2 * n := by
  simp only [residentCells, List.length_append, scratchCells, spillCells,
    List.length_map, List.length_finRange, Nat.two_mul]

theorem every_cell_accounted (c : Cell n) : c ∈ residentCells n := by
  cases c with
  | inl i =>
    apply List.mem_append_left
    exact List.mem_map.mpr ⟨i, finRange_covers i, rfl⟩
  | inr i =>
    apply List.mem_append_right
    exact List.mem_map.mpr ⟨i, finRange_covers i, rfl⟩

/-- Four saved registers incur four stores, four loads, and four extra spill words. -/
theorem four_register_receipt
    (body : Machine P V 4 → Machine P V 4 × Traffic) (cost : Traffic)
    (hcost : ∀ s, (body s).2 = cost) (s : Machine P V 4) :
    (countedWrapper body s).2 = ⟨cost.loads + 4, 4 + cost.stores⟩ ∧
      (spillCells 4).length = 4 ∧ (residentCells 4).length = 8 := by
  exact ⟨countedWrapper_constant_receipt body cost hcost s,
    extra_spill_words, resident_scratch_and_spill_words⟩

theorem four_register_restoration
    (body : Machine P V 4 → Machine P V 4 × Traffic)
    (hspill : ∀ s, (body s).1.2 = s.2) (s : Machine P V 4) :
    (countedWrapper body s).1.1.2 = s.1.2 ∧
      ((countedWrapper body s).1.2 = s.2 ↔ s.1.2 = s.2) :=
  ⟨countedWrapper_scratch_restored body hspill s,
    countedWrapper_original_spill_iff body hspill s⟩

end CountedScratchWrapper13955

#print axioms CountedScratchWrapper13955.countedRun_exact
#print axioms CountedScratchWrapper13955.store_traffic
#print axioms CountedScratchWrapper13955.load_traffic
#print axioms CountedScratchWrapper13955.save_counted
#print axioms CountedScratchWrapper13955.restore_counted
#print axioms CountedScratchWrapper13955.countedWrapper_state
#print axioms CountedScratchWrapper13955.countedWrapper_traffic
#print axioms CountedScratchWrapper13955.countedWrapper_exact
#print axioms CountedScratchWrapper13955.countedWrapper_constant_receipt
#print axioms CountedScratchWrapper13955.countedWrapper_scratch_restored
#print axioms CountedScratchWrapper13955.countedWrapper_original_spill_iff
#print axioms CountedScratchWrapper13955.scratch_and_spill_distinct
#print axioms CountedScratchWrapper13955.extra_spill_words
#print axioms CountedScratchWrapper13955.resident_scratch_and_spill_words
#print axioms CountedScratchWrapper13955.every_cell_accounted
#print axioms CountedScratchWrapper13955.four_register_receipt
#print axioms CountedScratchWrapper13955.four_register_restoration
#print axioms CountedScratchWrapper13955.liftCountedBody_preserves_spill
#print axioms CountedScratchWrapper13955.lifted_countedWrapper_exact
#print axioms CountedScratchWrapper13955.countedWrapper_full_restoration_obstruction
