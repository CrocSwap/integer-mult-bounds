import FiniteWordTransport
import ActualOperationSelector
namespace ActualWordTransport
open CommonExactFrame ExactTransportTrace FrameLogicalStep FrameLogicalWord FiniteWordTransport Lean.Grind BinarySpace24
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def Compatible (select : Nat → ExactFrame Vec F) (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) : Prop :=
  ∀ k (hk : ActualOperationSelector.InRange k),
    select k=(ActualOperationSelector.keyRepresentative i hi htwo k hk).toExactFrame

theorem step_selector_binding (select : Nat → ExactFrame Vec F) (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (hc : Compatible select i hi htwo) (s : PairedWord.Step) (hs : s ∈ PairedWordData.word) :
    select (ActualFrameKeys.key s)=(ActualOperationSelector.stepRepresentative i hi htwo s hs).toExactFrame :=
  hc _ _

theorem actual_bound_word (select : Nat → ExactFrame Vec F) (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (hc : Compatible select i hi htwo) (g : GaugeKeyTrace.State) (v : Arrays Vec F) :
    (∀ s (hs : s ∈ PairedWordData.word),
      select (ActualFrameKeys.key s)=(ActualOperationSelector.stepRepresentative i hi htwo s hs).toExactFrame) ∧
    physical select g (encode select g v)=
      (finalKeys g,encode select (finalKeys g) (fun r x => FieldWordTrace.run PairedWordData.word (fun j => v j x) r)) :=
  ⟨step_selector_binding select i hi htwo hc,actual_commuting select g v⟩

end ActualWordTransport
#print axioms ActualWordTransport.step_selector_binding
#print axioms ActualWordTransport.actual_bound_word
