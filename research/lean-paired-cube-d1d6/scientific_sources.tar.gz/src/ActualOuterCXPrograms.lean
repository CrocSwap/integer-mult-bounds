import TransportedScheduleCoverage
namespace ActualOuterCXPrograms
open BinarySpace24 BinaryPairEnumeration Q21AddressProgram CountedCXProgram CountedConditionalSwap
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

def leftCX : List CX := [⟨18,23⟩,⟨20,22⟩,⟨18,22⟩,⟨21,20⟩,⟨21,18⟩]
def rightCX : List CX := [⟨18,21⟩,⟨20,21⟩,⟨18,22⟩,⟨20,22⟩,⟨18,23⟩]
def remaining : List CX := [⟨18,22⟩,⟨20,22⟩,⟨18,23⟩,⟨21,20⟩,⟨21,18⟩]

theorem legal_lists : leftCX.all legal=true ∧ rightCX.all legal=true ∧ remaining.all legal=true := by decide

theorem actual_left_list : OuterAddressCircuits.leftCode=.unpermute::leftCX.map RootAddressInstructions.Instruction.cx := rfl

theorem actual_right_list : OuterAddressCircuits.rightCode=rightCX.map RootAddressInstructions.Instruction.cx++[.permute] := rfl

theorem actual_left_control_reads (k : Bits 23) :
    leftCX.map (fun a=>readControl (CoordinateScheduleTransport.index a.target a.control) k)=
      [(k 17,1),(k 19,1),(k 17,1),(k 19,1),(k 17,1)] := rfl

theorem actual_right_control_reads (k : Bits 23) :
    rightCX.map (fun a=>readControl (CoordinateScheduleTransport.index a.target a.control) k)=
      [(k 17,1),(k 19,1),(k 17,1),(k 19,1),(k 17,1)] := rfl

theorem remaining_five (a : CX) (ha : a∈remaining) (s : PairLoadStoreMachine.State Vec V) :
    (TransportedSwapCounter.loop a.target a.control (addresses 23) s).1.memory=
      (fun x=>s.memory (Q21AddressProgram.execute a x)) ∧
    (TransportedSwapCounter.loop a.target a.control (addresses 23) s).2=⟨16777216,16777216,8388608,16777216,0⟩ := by
  have h : a.control≠a.target:=of_decide_eq_true (List.all_eq_true.mp legal_lists.2.2 a ha)
  rw [TransportedSwapCounter.actual_loop]
  exact ⟨TransportedCXSemantics.memory_exact a.target a.control h s,rfl⟩

theorem left_memory (s : PairLoadStoreMachine.State Vec V) :
    (program leftCX s).1.memory=fun x=>s.memory (Q21AddressProgram.run leftCX x) := program_memory leftCX legal_lists.1 s

theorem right_memory (s : PairLoadStoreMachine.State Vec V) :
    (program rightCX s).1.memory=fun x=>s.memory (Q21AddressProgram.run rightCX x) := program_memory rightCX legal_lists.2.1 s

theorem five_each : leftCX.length=5 ∧ rightCX.length=5 ∧ (leftCX++rightCX).length=10 := by decide

theorem left_cost (s : PairLoadStoreMachine.State Vec V) :
    (program leftCX s).2=⟨83886080,83886080,41943040,83886080,0⟩ := by
  rw [program_cost,five_each.1]
  rfl

theorem right_cost (s : PairLoadStoreMachine.State Vec V) :
    (program rightCX s).2=⟨83886080,83886080,41943040,83886080,0⟩ := by
  rw [program_cost,five_each.2.1]
  rfl

-- The two passes act at different points around the C stage. This is their summed receipt.
theorem combined_receipt (leftState rightState : PairLoadStoreMachine.State Vec V) :
    Cost.add (program leftCX leftState).2 (program rightCX rightState).2=
      ⟨167772160,167772160,83886080,167772160,0⟩ := by
  rw [left_cost,right_cost]
  rfl

end ActualOuterCXPrograms
#print axioms ActualOuterCXPrograms.legal_lists
#print axioms ActualOuterCXPrograms.actual_left_list
#print axioms ActualOuterCXPrograms.actual_right_list
#print axioms ActualOuterCXPrograms.actual_left_control_reads
#print axioms ActualOuterCXPrograms.actual_right_control_reads
#print axioms ActualOuterCXPrograms.remaining_five
#print axioms ActualOuterCXPrograms.left_memory
#print axioms ActualOuterCXPrograms.right_memory
#print axioms ActualOuterCXPrograms.five_each
#print axioms ActualOuterCXPrograms.left_cost
#print axioms ActualOuterCXPrograms.right_cost
#print axioms ActualOuterCXPrograms.combined_receipt
