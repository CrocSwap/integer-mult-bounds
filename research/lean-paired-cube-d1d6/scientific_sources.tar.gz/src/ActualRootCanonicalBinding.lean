import RootCatalogSeparation
import RootPilotSeparation
import UniqueCatalogRepresentative
namespace ActualRootCanonicalBinding
open BinarySpace24 VariableCertificates CatalogSpanBridge ActualRootQueries PiecewiseSelector Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

noncomputable def sourceChart := VariableCertificates.chart sourceQuery.basis source_facts
noncomputable def rootChart := VariableCertificates.chart rootQuery.basis root_facts

theorem source_encode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (hk : ActualOperationSelector.InRange 15704) :
    (ActualOperationSelector.keyRepresentative i hi htwo 15704 hk).encode=
      CoordinateRepresentative.representative i sourceChart (initial 21) := by
  let cs := OperationFrameCatalog.certificates
  let hv := OperationFrameCatalog.valid
  have he : Span (ActualOperationSelector.witness 15704 hk)=Span sourceQuery.basis := by
    exact congrArg Span (RootReadoutBinding.incoming_witness hk)
  have hU : CatalogSelector.Domain cs (Span (ActualOperationSelector.witness 15704 hk)) :=
    Or.inr ⟨_,ActualOperationSelector.witness_member 15704 hk,rfl⟩
  have hV : CatalogSelector.Domain cs (Span sourceQuery.basis) :=
    Or.inr ⟨_,RootReadoutBinding.incoming_member,rfl⟩
  change (CatalogSelector.catalog i hi htwo cs hv _ hU).encode=_
  rw [CatalogSelector.all_same_frame i hi htwo cs hv _ _ hU hV he]
  exact UniqueCatalogRepresentative.encode_unique i hi htwo cs hv sourceQuery.basis source_facts source_other
    RootCatalogSeparation.source_unique hV

theorem root_encode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) :
    (RootPilotSelection.root i hi htwo RootPilotData.cert0 RootPilotGeometry.member0).encode=
      CoordinateRepresentative.representative i rootChart (initial 22) := by
  change (ConservativeCatalog.select i hi htwo OperationFrameCatalog.certificates RootPilotData.certificates
    OperationFrameCatalog.valid RootPilotData.valid (Span rootQuery.basis) _).encode=_
  rw [ConservativeCatalog.new_when_absent i hi htwo _ _ _ _ _ _ RootCatalogSeparation.root_not_old
    (Or.inr ⟨_,RootPilotGeometry.member0,rfl⟩)]
  exact UniqueCatalogRepresentative.encode_unique i hi htwo _ RootPilotData.valid rootQuery.basis root_facts root_other
    RootPilotSeparation.unique_root _

theorem source_decode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (hk : ActualOperationSelector.InRange 15704) (f : Vec → F) :
    (ActualOperationSelector.keyRepresentative i hi htwo 15704 hk).decode f=
      CoordinateRepresentative.inverseRepresentative i sourceChart (initial 21) f :=
  UniqueCatalogRepresentative.inverse_unique _ _ _ (source_encode i hi htwo hk)
    (CoordinateRepresentative.inverse_right i hi htwo sourceChart (initial 21)) f

theorem root_decode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (RootPilotSelection.root i hi htwo RootPilotData.cert0 RootPilotGeometry.member0).decode f=
      CoordinateRepresentative.inverseRepresentative i rootChart (initial 22) f :=
  UniqueCatalogRepresentative.inverse_unique _ _ _ (root_encode i hi htwo)
    (CoordinateRepresentative.inverse_right i hi htwo rootChart (initial 22)) f

end ActualRootCanonicalBinding
#print axioms ActualRootCanonicalBinding.source_encode
#print axioms ActualRootCanonicalBinding.root_encode
#print axioms ActualRootCanonicalBinding.source_decode
#print axioms ActualRootCanonicalBinding.root_decode
