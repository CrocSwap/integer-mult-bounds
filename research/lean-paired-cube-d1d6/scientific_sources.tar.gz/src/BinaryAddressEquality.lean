import ActualQuarterPhase
namespace BinaryAddressEquality
open BinaryPairEnumeration

def equalCheck {n : Nat} (x y : Bits n) := (List.finRange n).all (fun j => decide (x j=y j))

theorem check_sound {n : Nat} (x y : Bits n) (h : equalCheck x y=true) : x=y := by
  funext j
  exact of_decide_eq_true (List.all_eq_true.mp h j (List.mem_ofFn.mpr ⟨j,rfl⟩))

theorem check_complete {n : Nat} (x y : Bits n) (h : x=y) : equalCheck x y=true := by
  subst y
  apply List.all_eq_true.mpr
  intro j _
  exact decide_eq_true rfl

def decidableEquality {n : Nat} (x y : Bits n) : Decidable (x=y) :=
  if h : equalCheck x y=true then isTrue (check_sound x y h)
  else isFalse (fun he => h (check_complete x y he))

end BinaryAddressEquality
#print axioms BinaryAddressEquality.check_sound
#print axioms BinaryAddressEquality.check_complete
