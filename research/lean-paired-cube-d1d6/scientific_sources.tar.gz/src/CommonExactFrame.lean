import CarrierRepresentative
namespace CommonExactFrame
open Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {X : Type u} {F : Type v} [Field F]

structure ExactFrame (X : Type u) (F : Type v) [Field F] where
  encode : (X → F) → (X → F)
  decode : (X → F) → (X → F)
  left_inverse : ∀ f, decode (encode f)=f
  right_inverse : ∀ f, encode (decode f)=f
  add_linear : ∀ f g, encode (fun x => f x+g x)=fun x => encode f x+encode g x
  scale_linear : ∀ s f, encode (fun x => s*f x)=fun x => s*encode f x

def mix (a b : F) (f g : X → F) := fun x => a*f x+b*g x
def adapter (A B : ExactFrame X F) (f : X → F) := B.encode (A.decode f)

theorem common_mix (A : ExactFrame X F) (a b : F) (f g : X → F) :
    mix a b (A.encode f) (A.encode g)=A.encode (mix a b f g) := by
  unfold mix
  rw [A.add_linear,A.scale_linear,A.scale_linear]

theorem adapt_encoded (A B : ExactFrame X F) (f : X → F) :
    adapter A B (A.encode f)=B.encode f := by
  simp only [adapter,A.left_inverse]

theorem adapter_inverse (A B : ExactFrame X F) (f : X → F) :
    adapter B A (adapter A B f)=f := by
  simp only [adapter,B.left_inverse,A.right_inverse]

theorem adapter_transitive (A B C : ExactFrame X F) (f : X → F) :
    adapter B C (adapter A B f)=adapter A C f := by
  simp only [adapter,B.left_inverse]

theorem adapter_identity (A : ExactFrame X F) (f : X → F) :
    adapter A A f=f := A.right_inverse f

theorem adapted_mix (A B C : ExactFrame X F) (a b : F) (f g : X → F) :
    mix a b (adapter A C (A.encode f)) (adapter B C (B.encode g))=
      C.encode (mix a b f g) := by
  rw [adapt_encoded,adapt_encoded,common_mix]

theorem decoded_adapted_mix (A B C : ExactFrame X F) (a b : F) (f g : X → F) :
    C.decode (mix a b (adapter A C (A.encode f)) (adapter B C (B.encode g)))=mix a b f g := by
  rw [adapted_mix,C.left_inverse]

theorem selector_same_key {Key : Type w} (select : Key → ExactFrame X F)
    (k l : Key) (h : k=l) (f : X → F) : (select k).encode f=(select l).encode f := by
  rw [h]

theorem selector_common_mix {Key : Type w} (select : Key → ExactFrame X F)
    (k l : Key) (h : k=l) (a b : F) (f g : X → F) :
    mix a b ((select k).encode f) ((select l).encode g)=(select k).encode (mix a b f g) := by
  rw [← h,common_mix]

end CommonExactFrame
#print axioms CommonExactFrame.common_mix
#print axioms CommonExactFrame.adapt_encoded
#print axioms CommonExactFrame.adapter_inverse
#print axioms CommonExactFrame.adapter_transitive
#print axioms CommonExactFrame.adapter_identity
#print axioms CommonExactFrame.adapted_mix
#print axioms CommonExactFrame.decoded_adapted_mix
#print axioms CommonExactFrame.selector_same_key
#print axioms CommonExactFrame.selector_common_mix
