import CompletionData
namespace CompletionCheck000
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch000.all CompletionCertificates.check=true := by decide
end CompletionCheck000
#print axioms CompletionCheck000.valid
