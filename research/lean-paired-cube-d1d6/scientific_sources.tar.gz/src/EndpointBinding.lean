import SourceLineAdapter
namespace EndpointBinding
open BinarySpace24 SourceLineCase VariableCertificates BinaryBilinearCertificate

theorem actual_source_port : ActualInputCubes.cube000[0]?=some 21 := rfl

theorem source_weight_three : ((List.range 24).filter (fun k => (21:Nat).testBit k)).length=3 := by decide

theorem source_key : chosen.key=1 ∧ chosen.slots.length=1 := by decide

def targetWitness : Witness := VariablePilotData.cert023
def targetFacts : Facts targetWitness := check_sound targetWitness
  (List.all_eq_true.mp VariablePilotCheck002.valid targetWitness (by
    simp only [VariablePilotData.batch002,List.mem_cons,List.mem_singleton]
    exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Or.inl rfl)))))))))
def targetChart : FourthRootLift.Chart := chart targetWitness targetFacts

theorem target_key : targetWitness.key=17405 ∧ targetWitness.slots.length=23 := by decide

theorem target_basis_dual : (List.finRange 24).all (fun j =>
    decide (dot q (targetChart.forward (unit j))=unit j 23))=true := by decide

theorem target_dual (x : Vec) : dot q (targetChart.forward x)=x 23 := by
  apply linear_basis_ext (fun x => dot q (targetChart.forward x)) (fun x => x 23)
  · intro y z
    change dot q (targetChart.forward (add y z))=(dot q (targetChart.forward y) ^^ dot q (targetChart.forward z))
    rw [targetChart.forward_add,dot_add]
  · intro y z
    rfl
  · intro j
    exact of_decide_eq_true (List.all_eq_true.mp target_basis_dual j (List.mem_ofFn.mpr ⟨j,rfl⟩))

theorem target_image (y : Vec) : (∃ x, x 23=false ∧ targetChart.forward x=y) ↔ dot q y=false := by
  constructor
  · rintro ⟨x,hx,rfl⟩
    rw [target_dual,hx]
  · intro hy
    refine ⟨targetChart.inverse y,?_,targetChart.inverse_right y⟩
    rw [← target_dual (targetChart.inverse y),targetChart.inverse_right,hy]

end EndpointBinding
#print axioms EndpointBinding.actual_source_port
#print axioms EndpointBinding.source_weight_three
#print axioms EndpointBinding.source_key
#print axioms EndpointBinding.target_key
#print axioms EndpointBinding.target_basis_dual
#print axioms EndpointBinding.target_dual
#print axioms EndpointBinding.target_image
