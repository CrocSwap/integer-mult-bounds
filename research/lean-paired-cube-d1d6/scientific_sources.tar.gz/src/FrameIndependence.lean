import FrameSpan

namespace BinaryFrame
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def combination : List Nat → List Bool → Nat
  | b :: bs, c :: cs => (if c then b else 0) ^^^ combination bs cs
  | _, _ => 0

def Independent (basis : List Nat) : Prop :=
  ∀ coefficients, coefficients.length = basis.length →
    combination basis coefficients = 0 →
    coefficients = List.replicate basis.length false

def pivotCheck : List Nat → List Nat → Bool
  | [], [] => true
  | b :: bs, p :: ps =>
      decide (b.testBit p = true) &&
      bs.all (fun x => decide (x.testBit p = false)) && pivotCheck bs ps
  | _, _ => false

theorem combination_no_pivot (basis : List Nat) (p : Nat)
    (h : ∀ x ∈ basis, x.testBit p = false) :
    ∀ coefficients, (combination basis coefficients).testBit p = false := by
  induction basis with
  | nil => intro coefficients; simp [combination]
  | cons b bs ih =>
    intro coefficients
    have hb := h b (by simp)
    have ht : ∀ x ∈ bs, x.testBit p = false := fun x hx => h x (by simp [hx])
    cases coefficients with
    | nil => simp [combination]
    | cons c cs =>
      cases c <;> simp [combination, Nat.testBit_xor, hb, ih ht cs]

theorem pivotCheck_sound (basis pivots : List Nat) :
    pivotCheck basis pivots = true → Independent basis := by
  induction basis generalizing pivots with
  | nil =>
    intro h cs hlen hz
    cases cs with
    | nil => rfl
    | cons c cs => simp at hlen
  | cons b bs ih =>
    cases pivots with
    | nil => intro h; cases h
    | cons p ps =>
      intro h cs hlen hz
      have hh := Bool.and_eq_true_iff.mp h
      have hp := Bool.and_eq_true_iff.mp hh.1
      have hb : b.testBit p = true := of_decide_eq_true hp.1
      have ht : ∀ x ∈ bs, x.testBit p = false := by
        intro x hx
        exact of_decide_eq_true ((List.all_eq_true.mp hp.2) x hx)
      cases cs with
      | nil => simp at hlen
      | cons c cs =>
        have hlen' : cs.length = bs.length := Nat.succ.inj hlen
        have htail := combination_no_pivot bs p ht cs
        cases c with
        | false =>
          have hz' : combination bs cs = 0 := by simpa [combination] using hz
          have hs := ih ps hh.2 cs hlen' hz'
          simp only [List.length_cons, List.replicate_succ]
          exact congrArg (fun xs => false :: xs) hs
        | true =>
          have hbit := congrArg (fun x => x.testBit p) hz
          simp [combination, Nat.testBit_xor, hb, htail] at hbit

def rankCheck (basis pivots : List Nat) (n : Nat) : Bool :=
  decide (basis.length = n) && pivotCheck basis pivots

theorem rankCheck_sound (basis pivots : List Nat) (n : Nat)
    (h : rankCheck basis pivots n = true) : basis.length = n ∧ Independent basis := by
  have hh := Bool.and_eq_true_iff.mp h
  exact ⟨of_decide_eq_true hh.1, pivotCheck_sound basis pivots hh.2⟩

structure RankCertificate where
  basis : List Nat
  pivots : List Nat
  size : Nat

def rankValid (r : RankCertificate) : Bool := rankCheck r.basis r.pivots r.size

theorem rank_list_sound (rs : List RankCertificate) (h : rs.all rankValid = true) :
    ∀ r ∈ rs, r.basis.length = r.size ∧ Independent r.basis := by
  intro r hr
  exact rankCheck_sound r.basis r.pivots r.size ((List.all_eq_true.mp h) r hr)

end BinaryFrame

#print axioms BinaryFrame.combination_no_pivot
#print axioms BinaryFrame.pivotCheck_sound
#print axioms BinaryFrame.rankCheck_sound
#print axioms BinaryFrame.rank_list_sound
