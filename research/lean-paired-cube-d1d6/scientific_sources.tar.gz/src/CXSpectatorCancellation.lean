import CXChildDuality
namespace CXSpectatorCancellation
open BinarySpace24 Q21AddressProgram CoordinateChild CXLiftFormula CoordinateWord Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem execute_flip_other (c t k : Index) (h : c≠k) (x : Vec) :
    execute ⟨c,t⟩ (CoordinateChild.flip k x)=CoordinateChild.flip k (execute ⟨c,t⟩ x) := by
  rw [execute,flip_other k c (Ne.symm h)]
  funext j
  simp only [CoordinateChild.flip,execute,add,scale,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem gate_commute (i : F) (c t k : Index) (hc : c≠k) (ht : t≠k) (f : Vec → F) :
    gate i k (localLift i c t f)=localLift i c t (gate i k f) := by
  funext x
  simp only [gate,InvolutionGate.gate,localLift,localPhase,flip_other k c (Ne.symm hc),
    flip_other k t (Ne.symm ht),execute_flip_other c t k hc]
  grind

theorem child_commute (i : F) (c t : Index) (js : List Index)
    (hc : c∉js) (ht : t∉js) (f : Vec → F) :
    child i js (localLift i c t f)=localLift i c t (child i js f) := by
  induction js generalizing f with
  | nil => rfl
  | cons j js ih =>
    have hcj : c≠j := fun h => hc (by simp [h])
    have htj : t≠j := fun h => ht (by simp [h])
    have hcs : c∉js := fun h => hc (List.mem_cons_of_mem j h)
    have hts : t∉js := fun h => ht (List.mem_cons_of_mem j h)
    simp only [child,ih hcs hts,gate_commute i c t j hcj htj]

theorem unchild_append (i : F) (as bs : List Index) (f : Vec → F) :
    unchild i (as++bs) f=unchild i bs (unchild i as f) := by
  induction as generalizing f with
  | nil => rfl
  | cons a as ih => simp only [List.cons_append,unchild,ih]

theorem unchild_permutation (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    {as bs : List Index} (h : as.Perm bs) (f : Vec → F) : unchild i as f=unchild i bs f := by
  have hh := congrArg (unchild i bs) (child_permutation i h (unchild i as f))
  rw [inverse_right i hi htwo,inverse_left i hi htwo] at hh
  exact hh.symm

theorem full_duality (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c t : Index) (h : c≠t) (all rest : List Index) (hp : all.Perm ([c,t]++rest))
    (hc : c∉rest) (ht : t∉rest) (f : Vec → F) :
    child i all (localLift i c t (unchild i all f))=localLift (-i) t c f := by
  rw [child_permutation i hp,unchild_permutation i hi htwo hp,child_append,unchild_append,
    child_commute i c t rest hc ht,inverse_right i hi htwo]
  exact CXChildDuality.local_duality i hi htwo c t h f

end CXSpectatorCancellation
#print axioms CXSpectatorCancellation.execute_flip_other
#print axioms CXSpectatorCancellation.gate_commute
#print axioms CXSpectatorCancellation.child_commute
#print axioms CXSpectatorCancellation.unchild_append
#print axioms CXSpectatorCancellation.unchild_permutation
#print axioms CXSpectatorCancellation.full_duality
