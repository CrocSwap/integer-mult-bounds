import InheritedEndpoints
import CoordinateRepresentative
namespace CertifiedRepresentative
open BinarySpace24 BinaryCompletion EndpointGeometry EndpointSeparation InheritedEndpoints Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

structure Rep (F : Type u) [Field F] (U : Vec → Prop) extends CommonExactFrame.ExactFrame Vec F where
  label : (Vec × Vec) → (Vec × Vec)
  phase : (Vec × Vec) → F
  label_involution : ∀v, label (label v)=v
  preimage : ∀v, (label v).1=zero ↔ Frame U v
  pullthrough : ∀v f, encode (ExactQuadraticLift.pauli v.1 v.2 f)=fun x => phase v*
    ExactQuadraticLift.pauli (label v).1 (label v).2 (encode f) x
  phase_fourth : ∀v, (phase v*phase v)*(phase v*phase v)=1

theorem line_label_involution (q : Vec) (v : Vec × Vec) : lineLabel q (lineLabel q v)=v := by
  simp only [lineLabel,add_assoc,add_self,add_zero]

theorem target_label_involution (q : Vec) (v : Vec × Vec) : targetLabel q (targetLabel q v)=v := by
  apply Prod.ext
  · funext k
    simp only [targetLabel,lineLabel,add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm,Bool.xor_self,Bool.xor_false,Bool.false_xor,Bool.xor_assoc]
    cases scale (dot v.2 q) q k <;> cases v.1 k <;> rfl
  · rfl

theorem translation_add (a : F) (q : Vec) (f g : Vec → F) :
    TranslationKernel.gate a q (fun x => f x+g x)=fun x => TranslationKernel.gate a q f x+TranslationKernel.gate a q g x := by
  funext x
  simp only [TranslationKernel.gate,InvolutionGate.gate]
  grind

def sourceRep (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (q : Vec) (hq : dot q q=true) : Rep F (Line q) where
  encode := source i q
  decode := sourceInverse i q
  left_inverse := source_left i hi htwo q hq
  right_inverse := source_right i hi htwo q hq
  add_linear := translation_add _ q
  scale_linear := TranslationKernel.gate_scale _ q
  label := lineLabel q
  phase := fun v => sourcePhase i q v.2
  label_involution := line_label_involution q
  preimage := line_preimage q hq
  pullthrough := fun v f => source_Pauli i hi htwo q hq v.1 v.2 f
  phase_fourth := fun v => FourthRootRecipe.root_fourth _ (InheritedPhase.norm_one_square i hi q hq) (dot v.2 q)

def fullRep (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) : Rep F FullSpace where
  encode := full i
  decode := fullInverse i
  left_inverse := full_left i hi htwo
  right_inverse := full_right i hi htwo
  add_linear := CoordinateWord.child_add i _
  scale_linear := CoordinateWord.child_scale i _
  label := fun v => (add v.1 v.2,v.2)
  phase := fun v => CanonicalGramRecipe.coordinatePhase i v.2
  label_involution := fun v => by simp only [add_assoc,add_self,add_zero]
  preimage := full_preimage
  pullthrough := fun v f => full_Pauli i hi htwo v.1 v.2 f
  phase_fourth := fun v => CoordinateWord.phase_fourth i hi _ v.2

theorem target_add (i : F) (q : Vec) (f g : Vec → F) : target i q (fun x => f x+g x)=fun x => target i q f x+target i q g x := by
  unfold target sourceInverse TranslationKernel.undoGate InvolutionGate.inverse full
  change CoordinateWord.child i (List.finRange 24) (TranslationKernel.gate _ q (fun x => f x+g x))=_
  rw [translation_add,CoordinateWord.child_add]
  rfl

theorem target_scale (i : F) (q : Vec) (s : F) (f : Vec → F) : target i q (fun x => s*f x)=fun x => s*target i q f x := by
  unfold target sourceInverse TranslationKernel.undoGate InvolutionGate.inverse full
  change CoordinateWord.child i (List.finRange 24) (TranslationKernel.gate _ q (fun x => s*f x))=_
  rw [TranslationKernel.gate_scale,CoordinateWord.child_scale]
  rfl

theorem target_phase_fourth (i : F) (hi : i*i= -1) (q : Vec) (hq : dot q q=true) (z : Vec) :
    (targetPhase i q z*targetPhase i q z)*(targetPhase i q z*targetPhase i q z)=1 := by
  have h0 := FourthRootRecipe.root_fourth (-CanonicalGramRecipe.coordinatePhase i q)
    (FourthRootRecipe.neg_square _ (InheritedPhase.norm_one_square i hi q hq)) (dot z q)
  have h1 := CoordinateWord.phase_fourth i hi (List.finRange 24) z
  change let a := FourthRootRecipe.rootPhase (-CanonicalGramRecipe.coordinatePhase i q) (dot z q)*CoordinateWord.phase i (List.finRange 24) z; (a*a)*(a*a)=1
  grind

def targetRep (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (q : Vec) (hq : dot q q=true) : Rep F (Hyper q) where
  encode := target i q
  decode := targetInverse i q
  left_inverse := target_left i hi htwo q hq
  right_inverse := target_right i hi htwo q hq
  add_linear := target_add i q
  scale_linear := target_scale i q
  label := targetLabel q
  phase := fun v => targetPhase i q v.2
  label_involution := target_label_involution q
  preimage := target_preimage q hq
  pullthrough := fun v f => target_Pauli i hi htwo q hq v.1 v.2 f
  phase_fourth := fun v => target_phase_fourth i hi q hq v.2

def zeroRep : Rep F ZeroSpace where
  encode := id
  decode := id
  left_inverse := fun _ => rfl
  right_inverse := fun _ => rfl
  add_linear := fun _ _ => rfl
  scale_linear := fun _ _ => rfl
  label := id
  phase := fun _ => 1
  label_involution := fun _ => rfl
  preimage := fun v => (zero_frame v).symm
  pullthrough := fun v f => by funext x; exact (Semiring.one_mul _).symm
  phase_fourth := fun _ => by simp only [Semiring.one_mul]

theorem Kinv_add (i : F) (c : FourthRootLift.Chart) (f g : Vec → F) :
    CanonicalFourthRootLift.Kinv i c (fun x => f x+g x)=fun x => CanonicalFourthRootLift.Kinv i c f x+CanonicalFourthRootLift.Kinv i c g x := by
  funext x
  simp only [CanonicalFourthRootLift.Kinv,FourthRootLift.unlift,Semiring.left_distrib]

theorem Kinv_scale (i : F) (c : FourthRootLift.Chart) (s : F) (f : Vec → F) :
    CanonicalFourthRootLift.Kinv i c (fun x => s*f x)=fun x => s*CanonicalFourthRootLift.Kinv i c f x := by
  funext x
  simp only [CanonicalFourthRootLift.Kinv,FourthRootLift.unlift]
  grind

theorem canonical_add (i : F) (c : FourthRootLift.Chart) (js : List Index) (f g : Vec → F) :
    CoordinateRepresentative.representative i c js (fun x => f x+g x)=fun x => CoordinateRepresentative.representative i c js f x+CoordinateRepresentative.representative i c js g x := by
  simp only [CoordinateRepresentative.representative,Kinv_add,CoordinateWord.child_add,CanonicalFourthRootLift.K_add]

theorem canonical_scale (i : F) (c : FourthRootLift.Chart) (js : List Index) (s : F) (f : Vec → F) :
    CoordinateRepresentative.representative i c js (fun x => s*f x)=fun x => s*CoordinateRepresentative.representative i c js f x := by
  simp only [CoordinateRepresentative.representative,Kinv_scale,CoordinateWord.child_scale,CanonicalFourthRootLift.K_scale]

def canonicalRep (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (c : FourthRootLift.Chart) (js : List Index) (hn : js.Nodup) :
    Rep F (Image c.forward (CoordinateWordFrames.Space js)) where
  encode := CoordinateRepresentative.representative i c js
  decode := CoordinateRepresentative.inverseRepresentative i c js
  left_inverse := CoordinateRepresentative.inverse_left i hi htwo c js
  right_inverse := CoordinateRepresentative.inverse_right i hi htwo c js
  add_linear := canonical_add i c js
  scale_linear := canonical_scale i c js
  label := CoordinateRepresentative.label c js
  phase := CoordinateRepresentative.exactPhase i c js
  label_involution := CoordinateRepresentative.label_involution c js
  preimage := CoordinateRepresentative.frame_preimage c js hn
  pullthrough := CoordinateRepresentative.pauli_pullthrough i hi htwo c js
  phase_fourth := CoordinateRepresentative.exact_phase_fourth i hi c js

theorem exact_conjugation {U : Vec → Prop} (r : Rep F U) (v : Vec × Vec) (f : Vec → F) :
    r.encode (ExactQuadraticLift.pauli v.1 v.2 (r.decode f))=fun x => r.phase v*ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 f x := by
  rw [r.pullthrough,r.right_inverse]

end CertifiedRepresentative
#print axioms CertifiedRepresentative.line_label_involution
#print axioms CertifiedRepresentative.target_label_involution
#print axioms CertifiedRepresentative.translation_add
#print axioms CertifiedRepresentative.target_add
#print axioms CertifiedRepresentative.target_scale
#print axioms CertifiedRepresentative.target_phase_fourth
#print axioms CertifiedRepresentative.Kinv_add
#print axioms CertifiedRepresentative.Kinv_scale
#print axioms CertifiedRepresentative.canonical_add
#print axioms CertifiedRepresentative.canonical_scale
#print axioms CertifiedRepresentative.exact_conjugation
