import MemoryStageComposition
namespace CompleteOuterAddressProgram
open BinarySpace24 BinaryCompletion CompleteOuterAddressMemory Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {V : Type u}

structure Cost where
  loads : Nat
  stores : Nat
  controlReads : Nat
  valueSelections : Nat
  extraRegisterMoves : Nat
  scalarOperations : Nat
  deriving DecidableEq

def combine (c : CountedConditionalSwap.Cost) (p : BitSwapCounter.Cost) : Cost :=
  ⟨c.memoryLoads+p.loads,c.memoryStores+p.stores,c.controlReads,c.valueSelections,p.registerMoves,c.scalarOperations⟩

def left (s : PairLoadStoreMachine.State Vec V) := MemoryStageComposition.compose leftCX inversePermutation combine s
def right (s : PairLoadStoreMachine.State Vec V) := MemoryStageComposition.compose forwardPermutation rightCX (fun p c=>combine c p) s

theorem left_memory (s : PairLoadStoreMachine.State Vec V) :
    (left s).1.memory=fun x=>s.memory (RootAddressInstructions.run OuterAddressCircuits.leftCode x) := by
  have h:=MemoryStageComposition.memory leftCX inversePermutation combine
    (Q21AddressProgram.run ActualOuterCXPrograms.leftCX) (unpermute RootAddressInstructions.permutation)
    left_CX_memory inverse_memory s
  simp only [← OuterCXPhaseBinding.left_address] at h
  exact h

theorem right_memory (s : PairLoadStoreMachine.State Vec V) :
    (right s).1.memory=fun x=>s.memory (RootAddressInstructions.run OuterAddressCircuits.rightCode x) := by
  have h:=MemoryStageComposition.memory forwardPermutation rightCX (fun p c=>combine c p)
    (permute RootAddressInstructions.permutation) (Q21AddressProgram.run ActualOuterCXPrograms.rightCX)
    forward_memory right_CX_memory s
  simp only [← OuterCXPhaseBinding.right_address] at h
  exact h

theorem left_receipt (s : PairLoadStoreMachine.State Vec V) :
    (left s).2=⟨218103808,218103808,41943040,83886080,0,0⟩ :=
  MemoryStageComposition.cost leftCX inversePermutation combine _ _ left_CX_cost inverse_cost s

theorem right_receipt (s : PairLoadStoreMachine.State Vec V) :
    (right s).2=⟨218103808,218103808,41943040,83886080,0,0⟩ :=
  MemoryStageComposition.cost forwardPermutation rightCX (fun p c=>combine c p) _ _ forward_cost right_CX_cost s

variable {F : Type u} [Field F]

theorem left_phase_binding (i : F) (hi : i*i= -1) (s : PairLoadStoreMachine.State Vec F) :
    ActualQuarterPhase.leftPass i s.memory=fun x=>LeftPassAddressPhase.scalar i x*(left s).1.memory x := by
  rw [ActualQuarterPhase.exact_left i hi,left_memory]
  rfl

theorem right_phase_binding (i : F) (hi : i*i= -1) (s : PairLoadStoreMachine.State Vec F) :
    ActualQuarterPhase.rightPass i s.memory=fun x=>RightPassAddressPhase.scalar i x*(right s).1.memory x := by
  rw [ActualQuarterPhase.exact_right i hi,right_memory]
  rfl

end CompleteOuterAddressProgram
#print axioms CompleteOuterAddressProgram.left_memory
#print axioms CompleteOuterAddressProgram.right_memory
#print axioms CompleteOuterAddressProgram.left_receipt
#print axioms CompleteOuterAddressProgram.right_receipt
#print axioms CompleteOuterAddressProgram.left_phase_binding
#print axioms CompleteOuterAddressProgram.right_phase_binding
