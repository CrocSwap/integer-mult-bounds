import ActualRootSelection
import RootUseCatalog
namespace CompleteFrameSelector
open BinarySpace24 CommonExactFrame Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

noncomputable def select (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) : ExactFrame Vec F := by
  classical
  exact if hk : ActualRootSelection.InRange k then
    (ActualRootSelection.keyRepresentative i hi htwo k hk).toExactFrame
  else FrozenMSelector.select i hi htwo k

theorem operation_unchanged (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : k≤17400) :
    select i hi htwo k=FrozenMSelector.select i hi htwo k := by
  have hn : ¬ActualRootSelection.InRange k := by
    intro h
    have hp := h.1
    omega
  simp only [select,dif_neg hn]

theorem root_key (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : ActualRootSelection.InRange k) :
    select i hi htwo k=(ActualRootSelection.keyRepresentative i hi htwo k hk).toExactFrame := by
  simp only [select,dif_pos hk]

theorem zero_encode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (select i hi htwo 0).encode f=f := by
  rw [operation_unchanged i hi htwo 0 (by decide)]
  exact FrozenMSelector.zero_encode i hi htwo f

theorem zero_decode (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (select i hi htwo 0).decode f=f := by
  rw [operation_unchanged i hi htwo 0 (by decide)]
  exact FrozenMSelector.zero_decode i hi htwo f

theorem compatible (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) :
    ActualWordTransport.Compatible (select i hi htwo) i hi htwo := by
  intro k hk
  rw [operation_unchanged i hi htwo k hk.2]
  exact FrozenMSelector.operation_key i hi htwo k hk

theorem root_use_covered (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (p : Nat × Nat) (hp : p ∈ RootUseCatalog.uses) :
    p.1<26417 ∧
    ((∃ hk : ActualOperationSelector.InRange p.2,
      select i hi htwo p.2=(ActualOperationSelector.keyRepresentative i hi htwo p.2 hk).toExactFrame) ∨
     (∃ hk : ActualRootSelection.InRange p.2,
      select i hi htwo p.2=(ActualRootSelection.keyRepresentative i hi htwo p.2 hk).toExactFrame)) := by
  have hb := RootUseCatalog.use_bounds p hp
  refine ⟨hb.1,?_⟩
  by_cases h : p.2≤17400
  · have hk : ActualOperationSelector.InRange p.2 := ⟨hb.2.1,h⟩
    exact Or.inl ⟨hk,compatible i hi htwo p.2 hk⟩
  · have hk : ActualRootSelection.InRange p.2 := by
      change 17401≤p.2 ∧ p.2<17401+2640
      omega
    exact Or.inr ⟨hk,root_key i hi htwo p.2 hk⟩

theorem all_frame_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (f : Vec → F) :
    (select i hi htwo k).decode ((select i hi htwo k).encode f)=f ∧
    (select i hi htwo k).encode ((select i hi htwo k).decode f)=f :=
  ⟨(select i hi htwo k).left_inverse f,(select i hi htwo k).right_inverse f⟩

end CompleteFrameSelector
#print axioms CompleteFrameSelector.operation_unchanged
#print axioms CompleteFrameSelector.root_key
#print axioms CompleteFrameSelector.zero_encode
#print axioms CompleteFrameSelector.zero_decode
#print axioms CompleteFrameSelector.compatible
#print axioms CompleteFrameSelector.root_use_covered
#print axioms CompleteFrameSelector.all_frame_inverses
