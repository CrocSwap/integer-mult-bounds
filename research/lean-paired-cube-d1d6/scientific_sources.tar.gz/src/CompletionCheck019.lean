import CompletionData
namespace CompletionCheck019
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch019.all CompletionCertificates.check=true := by decide
end CompletionCheck019
#print axioms CompletionCheck019.valid
