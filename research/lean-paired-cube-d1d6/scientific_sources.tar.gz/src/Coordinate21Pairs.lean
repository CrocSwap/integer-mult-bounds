import OuterAddressCircuits
import InversePairProgram
namespace Coordinate21Pairs
open BinarySpace24 BinaryPairEnumeration CoordinateChild Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def swap (x : Vec) (j : Index) := if j=0 then x 21 else if j=21 then x 0 else x j

theorem swap_zero (x : Vec) : swap x 0=x 21 := rfl
theorem swap_twentyone (x : Vec) : swap x 21=x 0 := rfl

theorem swap_twice (x : Vec) : swap (swap x)=x := by
  funext j
  by_cases h0 : j=0 <;> by_cases h21 : j=21 <;> simp_all [swap]

def embed (b : Bool) (y : Bits 23) := swap (cons b y)
def drop (x : Vec) := tail (swap x)

theorem embed_head (b : Bool) (y : Bits 23) : embed b y 21=b := rfl

theorem drop_embed (b : Bool) (y : Bits 23) : drop (embed b y)=y := by
  rw [drop,embed,swap_twice,tail_cons]

theorem embed_drop (x : Vec) : embed (x 21) (drop x)=x := by
  have h := congrArg swap (cons_tail (swap x))
  simpa only [swap_zero,swap_twice,embed,drop] using h

theorem embed_injective (b : Bool) (x y : Bits 23) (h : embed b x=embed b y) : x=y := by
  have hh := congrArg drop h
  simpa only [drop_embed] using hh

theorem embed_disjoint (x y : Bits 23) : embed false x≠embed true y := by
  intro h
  have hh := congrFun h 21
  contradiction

theorem swap_flip_zero (x : Vec) : swap (CoordinateChild.flip 0 x)=CoordinateChild.flip 21 (swap x) := by
  funext j
  by_cases h0 : j=0 <;> by_cases h21 : j=21 <;>
    simp_all [swap,CoordinateChild.flip,add,unit,eq_comm]

theorem pair_flip (y : Bits 23) : CoordinateChild.flip 21 (embed false y)=embed true y := by
  rw [embed,← swap_flip_zero,coordinate_pair_flip]
  rfl

def zeroAddresses := (addresses 23).map (embed false)
def oneAddresses := (addresses 23).map (embed true)

theorem pair_count : (addresses 23).length=8388608 := BinaryPairEnumeration.pair_count

theorem zero_count : zeroAddresses.length=8388608 := by rw [zeroAddresses,List.length_map,pair_count]
theorem one_count : oneAddresses.length=8388608 := by rw [oneAddresses,List.length_map,pair_count]

theorem zero_nodup : zeroAddresses.Nodup :=
  List.Pairwise.map (embed false) (fun x y hxy he => hxy (embed_injective false x y he)) (addresses_nodup 23)

theorem one_nodup : oneAddresses.Nodup :=
  List.Pairwise.map (embed true) (fun x y hxy he => hxy (embed_injective true x y he)) (addresses_nodup 23)

theorem complete_nodup : (zeroAddresses++oneAddresses).Nodup := by
  apply List.pairwise_append.mpr
  refine ⟨zero_nodup,one_nodup,?_⟩
  intro x hx y hy
  obtain ⟨a,_,rfl⟩ := List.mem_map.mp hx
  obtain ⟨b,_,rfl⟩ := List.mem_map.mp hy
  exact embed_disjoint a b

theorem all_covered (x : Vec) : x ∈ zeroAddresses++oneAddresses := by
  have h := all_addresses 23 (drop x)
  have he := embed_drop x
  cases hb : x 21
  · rw [hb] at he
    exact List.mem_append.mpr (Or.inl (List.mem_map.mpr ⟨drop x,h,he⟩))
  · rw [hb] at he
    exact List.mem_append.mpr (Or.inr (List.mem_map.mpr ⟨drop x,h,he⟩))

theorem complete_count : (zeroAddresses++oneAddresses).length=16777216 := by
  rw [List.length_append,zero_count,one_count]

end Coordinate21Pairs
#print axioms Coordinate21Pairs.swap_zero
#print axioms Coordinate21Pairs.swap_twentyone
#print axioms Coordinate21Pairs.swap_twice
#print axioms Coordinate21Pairs.embed_head
#print axioms Coordinate21Pairs.drop_embed
#print axioms Coordinate21Pairs.embed_drop
#print axioms Coordinate21Pairs.embed_injective
#print axioms Coordinate21Pairs.embed_disjoint
#print axioms Coordinate21Pairs.swap_flip_zero
#print axioms Coordinate21Pairs.pair_flip
#print axioms Coordinate21Pairs.pair_count
#print axioms Coordinate21Pairs.zero_count
#print axioms Coordinate21Pairs.one_count
#print axioms Coordinate21Pairs.zero_nodup
#print axioms Coordinate21Pairs.one_nodup
#print axioms Coordinate21Pairs.complete_nodup
#print axioms Coordinate21Pairs.all_covered
#print axioms Coordinate21Pairs.complete_count
