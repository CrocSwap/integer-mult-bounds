import CountedPhaseLanguage
namespace ActualPhaseEvaluation
open BinarySpace24 CountedPhaseLanguage CanonicalGramRecipe Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def registers (x y : Vec) : Nat → Vec := fun k => if k=0 then x else y

def leftExpr : PExpr := .times
  (.times (coordinate false 0 (List.finRange 24)) (coordinate true 1 (List.finRange 24)))
  (.sign (.and (.read 1 21) (.not (.xor (.read 1 18) (.read 1 20)))))
def rightExpr : PExpr := .times (coordinate true 1 (List.finRange 24)) (coordinate false 0 (List.finRange 24))

theorem left_cost : leftExpr.cost=⟨51,1,1,1,49,50⟩ := by decide
theorem right_cost : rightExpr.cost=⟨48,0,0,0,48,49⟩ := by decide

theorem left_eval (i : F) (hi : i*i= -1) (x y : Vec) :
    leftExpr.eval i (registers x y)=
      (coordinatePhase i x*coordinatePhase (-i) y)*LeftPassAddressPhase.localQuarter i y := by
  rw [ActualLeftPhaseRecipe.local_sign i hi]
  simp only [leftExpr,PExpr.eval,coordinate_eval,BExpr.eval,registers,coordinatePhase,
    Bool.false_eq_true,if_false,if_true]
  rfl

theorem right_eval (i : F) (x y : Vec) :
    rightExpr.eval i (registers x y)=coordinatePhase (-i) y*coordinatePhase i x := by
  simp only [rightExpr,PExpr.eval,coordinate_eval,registers,coordinatePhase,
    Bool.false_eq_true,if_false,if_true]
  rfl

def leftIntermediate (x : Vec) := RootAddressInstructions.run ActualRootAddressCircuit.inverseCode x

theorem left_intermediate (x : Vec) : leftIntermediate x=RootJointGeometry.rootChart.inverse x :=
  ActualRootAddressCircuit.exact_inverse x

theorem left_counted (i : F) (hi : i*i= -1) (x : Vec) :
    leftExpr.run i (registers x (leftIntermediate x))=(LeftPassAddressPhase.scalar i x,⟨51,1,1,1,49,50⟩) := by
  rw [phase_evaluation,left_eval i hi,left_cost,left_intermediate]
  rfl

theorem right_counted (i : F) (x : Vec) :
    rightExpr.run i (registers x (RootAddressInstructions.run OuterAddressCircuits.rightCode x))=
      (RightPassAddressPhase.scalar i x,⟨48,0,0,0,48,49⟩) := by
  rw [phase_evaluation,right_eval,right_cost,OuterAddressCircuits.right_address]
  rfl

def leftLocalCode : List RootAddressInstructions.Instruction := [.cx ⟨21,20⟩,.cx ⟨21,18⟩]

def leftPass (i : F) (f : Vec → F) (x : Vec) :=
  let y := leftIntermediate x
  let phaseResult := leftExpr.run i (registers x y)
  let z := RootAddressInstructions.run leftLocalCode y
  phaseResult.1*f z

def rightPass (i : F) (f : Vec → F) (x : Vec) :=
  let y := RootAddressInstructions.run OuterAddressCircuits.rightCode x
  let phaseResult := rightExpr.run i (registers x y)
  phaseResult.1*f y

theorem left_split_address (x : Vec) :
    RootAddressInstructions.run leftLocalCode (leftIntermediate x)=RootAddressInstructions.run OuterAddressCircuits.leftCode x := by
  rw [OuterAddressCircuits.leftCode,RootAddressInstructions.run_append]
  rfl

theorem exact_left_pass (i : F) (hi : i*i= -1) (f : Vec → F) : leftPass i f=OuterAddressCircuits.leftPass i f := by
  funext x
  simp only [leftPass,left_counted i hi,left_split_address,OuterAddressCircuits.leftPass]

theorem exact_right_pass (i : F) (f : Vec → F) : rightPass i f=OuterAddressCircuits.rightPass i f := by
  funext x
  simp only [rightPass,right_counted,OuterAddressCircuits.rightPass]

end ActualPhaseEvaluation
#print axioms ActualPhaseEvaluation.left_cost
#print axioms ActualPhaseEvaluation.right_cost
#print axioms ActualPhaseEvaluation.left_eval
#print axioms ActualPhaseEvaluation.right_eval
#print axioms ActualPhaseEvaluation.left_intermediate
#print axioms ActualPhaseEvaluation.left_counted
#print axioms ActualPhaseEvaluation.right_counted
#print axioms ActualPhaseEvaluation.left_split_address
#print axioms ActualPhaseEvaluation.exact_left_pass
#print axioms ActualPhaseEvaluation.exact_right_pass
