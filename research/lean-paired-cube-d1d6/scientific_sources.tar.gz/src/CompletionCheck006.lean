import CompletionData
namespace CompletionCheck006
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch006.all CompletionCertificates.check=true := by decide
end CompletionCheck006
#print axioms CompletionCheck006.valid
