import ActualCarrierCharts
import TensorThree
namespace ActualCarrierGate
open CarrierCoordinates ActualCarrierCharts TensorThree Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def axisVector (q0 q1 q2 : Nat) : Axis → Nat
  | .first => q0
  | .second => q1
  | .third => q2

theorem select_not (q : Nat) (c : Bool) :
    (if !c then q else 0)=(if c then q else 0) ^^^ q := by
  cases c <;> simp

theorem chart_flip (q0 q1 q2 : Nat) (axis : Axis) (c : Coordinates) :
    chart q0 q1 q2 (flip axis c)=chart q0 q1 q2 c ^^^ axisVector q0 q1 q2 axis := by
  cases axis <;> simp only [chart,TensorThree.flip,select_not,axisVector] <;> ac_rfl

theorem chart_flip_all (q0 q1 q2 : Nat) (c : Coordinates) :
    chart q0 q1 q2 (add c (true,true,true))=
      chart q0 q1 q2 c ^^^ (q0 ^^^ q1 ^^^ q2) := by
  rw [chart_add]
  simp [chart,Nat.xor_assoc]

def direction (cube : List Nat) (parity : Bool) : Axis → Nat :=
  axisVector (q cube parity 0) (q cube parity 1) (q cube parity 2)
def restrict (cube : List Nat) (parity : Bool) (f : Nat → F) : Coordinates → F :=
  fun c => f (encode cube parity c)
def ambientGate (i : F) (cube : List Nat) (parity : Bool) (axis : Axis) : (Nat → F) → (Nat → F) :=
  InvolutionGate.gate i (fun x => x ^^^ direction cube parity axis)
def ambientTensor (i : F) (cube : List Nat) (parity : Bool) (f : Nat → F) : Nat → F :=
  ambientGate i cube parity .first (ambientGate i cube parity .second (ambientGate i cube parity .third f))
def ambientUndo (i : F) (cube : List Nat) (parity : Bool) (f : Nat → F) : Nat → F :=
  ambientGate (-i) cube parity .third (ambientGate (-i) cube parity .second (ambientGate (-i) cube parity .first f))

theorem actual_axis_intertwine (i : F) (cube : List Nat) (parity : Bool) (axis : Axis) (f : Nat → F) :
    TensorThree.gate i axis (restrict cube parity f)=restrict cube parity (ambientGate i cube parity axis f) :=
  InvolutionGate.pullback i (TensorThree.flip axis) (fun x => x ^^^ direction cube parity axis) (encode cube parity)
    (chart_flip (q cube parity 0) (q cube parity 1) (q cube parity 2) axis) f

theorem actual_tensor_intertwine (i : F) (cube : List Nat) (parity : Bool) (f : Nat → F) :
    tensor i (restrict cube parity f)=restrict cube parity (ambientTensor i cube parity f) := by
  unfold tensor ambientTensor
  rw [actual_axis_intertwine,actual_axis_intertwine,actual_axis_intertwine]

theorem actual_undo_intertwine (i : F) (cube : List Nat) (parity : Bool) (f : Nat → F) :
    undo i (restrict cube parity f)=restrict cube parity (ambientUndo i cube parity f) := by
  change TensorThree.gate (-i) .third (TensorThree.gate (-i) .second
    (TensorThree.gate (-i) .first (restrict cube parity f)))=_
  unfold ambientUndo
  rw [actual_axis_intertwine,actual_axis_intertwine,actual_axis_intertwine]

theorem actual_square (i : F) (hi : i*i= -1) (htwo : (2:F) ≠ 0)
    (cube : List Nat) (parity : Bool) (f : Nat → F) (c : Coordinates) :
    ambientTensor i cube parity (ambientTensor i cube parity f) (encode cube parity c)=
      f (encode cube parity c ^^^ (q cube parity 0 ^^^ q cube parity 1 ^^^ q cube parity 2)) := by
  have h := tensor_square i hi htwo (restrict cube parity f)
  rw [actual_tensor_intertwine,actual_tensor_intertwine] at h
  have hp := congrArg (fun g => g c) h
  simpa only [restrict,encode,chart_flip_all] using hp

theorem actual_inverse (i : F) (hi : i*i= -1) (htwo : (2:F) ≠ 0)
    (cube : List Nat) (parity : Bool) (f : Nat → F) :
    restrict cube parity (ambientUndo i cube parity (ambientTensor i cube parity f))=restrict cube parity f ∧
    restrict cube parity (ambientTensor i cube parity (ambientUndo i cube parity f))=restrict cube parity f := by
  constructor
  · rw [← actual_undo_intertwine,← actual_tensor_intertwine,tensor_inverse_left i hi htwo]
  · rw [← actual_tensor_intertwine,← actual_undo_intertwine,tensor_inverse_right i hi htwo]

theorem actual_phase_bridge (i : F) (hi : i*i= -1)
    (cube : List Nat) (parity : Bool) (f : Nat → F) :
    phases i (tensor i (phases i (restrict cube parity f)))=bridges i (restrict cube parity f) :=
  tensor_phase_bridge i hi _

theorem actual_chart_operator (i : F) (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    (∀ c d, encode cube parity c=encode cube parity d → c=d) ∧
    (∀ x, (∃ c, encode cube parity c=x) ↔ BinaryFrame.Span (BinaryPort.carrier cube parity) x) ∧
    (∀ f : Nat → F, tensor i (restrict cube parity f)=restrict cube parity (ambientTensor i cube parity f)) :=
  ⟨actual_injective cube hc parity,actual_range cube hc parity,actual_tensor_intertwine i cube parity⟩

theorem actual_source_coordinate (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes)
    (parity : Bool) (source : Nat) (hs : source ∈ BinaryPort.ports cube parity) :
    ∃ c, encode cube parity c=source ∧ ∀ d, encode cube parity d=source → d=c := by
  have hm : BinaryFrame.Span (BinaryPort.carrier cube parity) source :=
    (ActualCubePorts.all_actual_carriers cube hc parity).source_contains source (BinaryFrame.Span.generator hs)
  rcases (actual_range cube hc parity source).mpr hm with ⟨c,hc'⟩
  refine ⟨c,hc',?_⟩
  intro d hd
  exact actual_injective cube hc parity d c (hd.trans hc'.symm)

theorem actual_square_translation_nonzero (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes)
    (parity : Bool) : q cube parity 0 ^^^ q cube parity 1 ^^^ q cube parity 2 ≠ 0 := by
  intro h
  have he : encode cube parity (true,true,true)=encode cube parity (false,false,false) := by
    simpa [encode,chart,Nat.xor_assoc] using h
  have hc' := actual_injective cube hc parity (true,true,true) (false,false,false) he
  cases hc'

end ActualCarrierGate
#print axioms ActualCarrierGate.select_not
#print axioms ActualCarrierGate.chart_flip
#print axioms ActualCarrierGate.chart_flip_all
#print axioms ActualCarrierGate.actual_axis_intertwine
#print axioms ActualCarrierGate.actual_tensor_intertwine
#print axioms ActualCarrierGate.actual_undo_intertwine
#print axioms ActualCarrierGate.actual_square
#print axioms ActualCarrierGate.actual_inverse
#print axioms ActualCarrierGate.actual_phase_bridge
#print axioms ActualCarrierGate.actual_chart_operator
#print axioms ActualCarrierGate.actual_source_coordinate
#print axioms ActualCarrierGate.actual_square_translation_nonzero
