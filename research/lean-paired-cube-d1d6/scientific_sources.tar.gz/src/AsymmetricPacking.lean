import WeightedRows
namespace SignedPacking

theorem bounded_difference_radii (a b : List Int) (A B : Nat) (hsmall : A+B<128)
    (ha : ∀ x ∈ a, -(A:Int) ≤ x ∧ x ≤ (A:Int))
    (hb : ∀ y ∈ b, -(B:Int) ≤ y ∧ y ≤ (B:Int)) :
    bounded (List.zipWith (fun x y => x-y) a b) := by
  induction a generalizing b with
  | nil => simp [bounded]
  | cons x xs ih =>
    cases b with
    | nil => simp [bounded]
    | cons y ys =>
      intro d hd
      have hm : d=x-y ∨ d ∈ List.zipWith (fun x y => x-y) xs ys := by simpa using hd
      rcases hm with heq | ht
      · have hx := ha x (by simp)
        have hy := hb y (by simp)
        omega
      · exact ih ys (fun z hz => ha z (by simp [hz])) (fun z hz => hb z (by simp [hz])) d ht

theorem encode_injective_radii (a b : List Int) (A B : Nat) (hsmall : A+B<128)
    (hlen : a.length=b.length)
    (ha : ∀ x ∈ a, -(A:Int) ≤ x ∧ x ≤ (A:Int))
    (hb : ∀ y ∈ b, -(B:Int) ≤ y ∧ y ≤ (B:Int))
    (heq : encode a = encode b) : a=b :=
  encode_injective_difference_bound a b hlen (bounded_difference_radii a b A B hsmall ha hb) heq

theorem scaled_basis_bound (n i : Nat) :
    ∀ d ∈ (basis n i).map (fun x => (6:Int)*x), -6 ≤ d ∧ d ≤ 6 := by
  intro d hd
  rcases List.mem_map.mp hd with ⟨x, hx, rfl⟩
  rcases List.mem_map.mp hx with ⟨j, hj, rfl⟩
  split <;> omega

theorem weighted_response_from_packing (width target : Nat) (rows : Nat → MaskRows.Row)
    (terms : List PairedDecoder.ReadTerm) (ht : target<width) (hw : WeightedRows.weight terms ≤ 60)
    (hp : PairedDecoder.evaluate terms (fun role => MaskModels.encoded width (rows role)) = 6*(128:Int)^target)
    (payload : PairedWord.State) :
    PairedDecoder.evaluate terms (fun role => MaskModels.evaluated width (rows role) payload) = 6*payload target := by
  have he : encode (WeightedRows.vector width rows terms) = encode ((basis width target).map (fun x => (6:Int)*x)) := by
    rw [WeightedRows.encode_vector, encode_scale, encode_basis width target ht]
    exact hp
  have hv : WeightedRows.vector width rows terms = (basis width target).map (fun x => (6:Int)*x) := by
    apply encode_injective_radii _ _ 60 6 (by decide)
    · simp [WeightedRows.vector_length, basis]
    · intro d hd
      have h := WeightedRows.vector_bound width rows terms d hd
      omega
    · exact scaled_basis_bound width target
    · exact he
  rw [← WeightedRows.evaluate_vector, hv, evaluate_scale,
      evaluate_basis width target _ (by simp) ht]
  simp [List.getElem?_map, List.getElem?_range ht]

end SignedPacking
#print axioms SignedPacking.bounded_difference_radii
#print axioms SignedPacking.encode_injective_radii
#print axioms SignedPacking.scaled_basis_bound
#print axioms SignedPacking.weighted_response_from_packing
