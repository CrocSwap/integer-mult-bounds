import CompletionCertificates
namespace CompletionFrames
open BinarySpace24 BinaryCompletion CompletionCertificates PrivateShear TensorThree

def fromNat (x : Nat) : Vec := fun j => x.testBit j.val
def coordinates (bits : CarrierCoordinates.Coordinates) : Vec :=
  combine (fun axis => unit (index axis)) bits
def CoordinateSpace (x : Vec) : Prop := ∃ bits, coordinates bits=x
def ActualCarrier (c : Witness) (x : Vec) : Prop :=
  ∃ n, BinaryFrame.Span (BinaryPort.carrier c.cube c.parity) n ∧ fromNat n=x

theorem full_map_add (c : Witness) (hc : Facts c) (x y : Vec) :
    fullMap c hc (add x y)=add (fullMap c hc x) (fullMap c hc y) := G_add _ _ _ x y

theorem full_map_scale (c : Witness) (hc : Facts c) (b : Bool) (x : Vec) :
    fullMap c hc (scale b x)=scale b (fullMap c hc x) := by
  cases b
  · exact G_zero _ _ _
  · rfl

theorem combine_actual_chart (c : Witness) (bits : CarrierCoordinates.Coordinates) :
    combine (vector c) bits=fromNat (ActualCarrierCharts.encode c.cube c.parity bits) := by
  funext j
  rcases bits with ⟨b0,b1,b2⟩
  cases b0 <;> cases b1 <;> cases b2 <;>
    simp [combine,vector,source,ActualCarrierGate.direction,ActualCarrierGate.axisVector,
      ActualCarrierCharts.encode,CarrierCoordinates.chart,fromNat,add,scale,Nat.testBit_xor]

theorem source_chart (c : Witness) (hc : Facts c) (bits : CarrierCoordinates.Coordinates) :
    fullMap c hc (coordinates bits)=fromNat (ActualCarrierCharts.encode c.cube c.parity bits) := by
  unfold coordinates combine
  rw [full_map_add,full_map_add,full_map_scale,full_map_scale,full_map_scale,
    source_columns,source_columns,source_columns]
  exact combine_actual_chart c bits

theorem coordinate_image (c : Witness) (hc : Facts c) (x : Vec) :
    Image (fullMap c hc) CoordinateSpace x ↔
      ∃ bits, fromNat (ActualCarrierCharts.encode c.cube c.parity bits)=x := by
  constructor
  · rintro ⟨y,⟨bits,rfl⟩,he⟩
    exact ⟨bits,by rwa [source_chart] at he⟩
  · rintro ⟨bits,he⟩
    exact ⟨coordinates bits,⟨bits,rfl⟩,by rw [source_chart,he]⟩

theorem carrier_image (c : Witness) (hc : Facts c) (hsource : c.cube ∈ ActualInputCubes.cubes) (x : Vec) :
    Image (fullMap c hc) CoordinateSpace x ↔ ActualCarrier c x := by
  rw [coordinate_image]
  constructor
  · rintro ⟨bits,he⟩
    refine ⟨ActualCarrierCharts.encode c.cube c.parity bits,?_,he⟩
    exact (ActualCarrierCharts.actual_range c.cube hsource c.parity _).mp ⟨bits,rfl⟩
  · rintro ⟨n,hn,he⟩
    rcases (ActualCarrierCharts.actual_range c.cube hsource c.parity n).mpr hn with ⟨bits,hb⟩
    exact ⟨bits,by rw [hb,he]⟩

theorem actual_carrier_frame (c : Witness) (hc : Facts c) (hsource : c.cube ∈ ActualInputCubes.cubes)
    (v : Vec × Vec) : Frame (ActualCarrier c) (blockMap c hc v) ↔ Frame CoordinateSpace v := by
  have he : ActualCarrier c=Image (fullMap c hc) CoordinateSpace :=
    funext (fun x => propext (carrier_image c hc hsource x).symm)
  rw [he]
  exact block_frame_transport c hc CoordinateSpace v

end CompletionFrames
#print axioms CompletionFrames.full_map_add
#print axioms CompletionFrames.full_map_scale
#print axioms CompletionFrames.combine_actual_chart
#print axioms CompletionFrames.source_chart
#print axioms CompletionFrames.coordinate_image
#print axioms CompletionFrames.carrier_image
#print axioms CompletionFrames.actual_carrier_frame
