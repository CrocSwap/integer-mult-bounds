import ActualWord
import Lean.Elab.Tactic.Omega

namespace PairedWordCorollaries
open PairedWord PairedWordData

def sub {ι : Type} (x y : ι → Int) : ι → Int := fun i => x i - y i
def targetAdd {ι : Type} (x y : ι → Int) : ι → Int := fun i => x i + y i

theorem actual_dirty_auxiliary_restored (z v : State) :
    sub (undo word (run word (add z v))) v = z := by
  rw [actual_word_restores]
  funext i
  simp only [sub, add]
  omega

theorem actual_dirty_decoded_response
    {κ : Type} (J : State → (κ → Int))
    (hJ : ∀ x y, J (add x y) = targetAdd (J x) (J y))
    (z v : State) (y : κ → Int) :
    targetAdd (sub y (J (run word z))) (J (run word (add z v))) =
      targetAdd y (J (run word v)) := by
  rw [actual_word_additive, hJ]
  funext i
  simp only [targetAdd, sub]
  omega

theorem actual_cleanup_requires_restored_payload (z original current : State) :
    sub (undo word (run word (add z original))) current = z ↔ original = current := by
  rw [actual_word_restores]
  constructor
  · intro h
    funext i
    have hi := congrArg (fun f => f i) h
    simp only [sub, add] at hi
    omega
  · intro h
    rw [h]
    funext i
    simp only [sub, add]
    omega

end PairedWordCorollaries

#print axioms PairedWordCorollaries.actual_dirty_auxiliary_restored
#print axioms PairedWordCorollaries.actual_dirty_decoded_response
#print axioms PairedWordCorollaries.actual_cleanup_requires_restored_payload
