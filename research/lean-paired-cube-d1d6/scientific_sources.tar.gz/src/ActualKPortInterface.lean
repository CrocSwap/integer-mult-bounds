import ActualCubePorts
namespace ActualKPortInterface
open BinaryPort BinaryFrame CubeGeometry
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

theorem port_mem_of_index (cube : List Nat) (i : Nat) (hi : i<8) :
    cube[i]?.getD 0 ∈ ports cube (selectorParity i) := by
  apply List.mem_map.mpr
  refine ⟨i, ?_, rfl⟩
  rw [selector_indices_exact]
  exact List.mem_filter.mpr ⟨List.mem_range.mpr hi, by simp⟩

theorem port_from_cube (cube : List Nat) (hc : cube.length=8) (parity : Bool)
    (q : Nat) (hq : q ∈ ports cube parity) : q ∈ cube := by
  rcases List.mem_map.mp hq with ⟨i,hi,rfl⟩
  rw [selector_indices_exact] at hi
  have hi8 : i<8 := List.mem_range.mp (List.mem_filter.mp hi).1
  have hib : i<cube.length := by rw [hc]; exact hi8
  rw [List.getElem?_eq_getElem hib]
  exact List.getElem_mem hib

theorem span_bounded (width : Nat) (basis : List Nat)
    (hb : ∀ b ∈ basis, b<2^width) : ∀ x, Span basis x → x<2^width := by
  intro x hx
  induction hx with
  | zero => exact Nat.two_pow_pos width
  | generator h => exact hb _ h
  | add hx hy ihx ihy => exact Nat.xor_lt_two_pow ihx ihy

theorem actual_carrier_bounded (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    ∀ x, Span (carrier cube parity) x → x<2^24 := by
  have hf := ActualCubePorts.all_actual_carriers cube hc parity
  apply span_bounded 24 (carrier cube parity)
  intro b hb
  have hp : b ∈ ports cube parity := List.mem_of_mem_take hb
  exact (hf.inputs_valid b (port_from_cube cube hf.cube_length parity b hp)).2

theorem actual_K_port_connection (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes)
    (target source : Fin 8) (hk : inputK2 cube target.val source.val ≠ 0) :
    (carrier cube (selectorParity source.val)).length=3 ∧
    Independent (carrier cube (selectorParity source.val)) ∧
    (∀ x, Span [cube[source.val]?.getD 0] x → Span (carrier cube (selectorParity source.val)) x) ∧
    (∀ x, Span (carrier cube (selectorParity source.val)) x →
      x<2^24 ∧ dot 24 (cube[target.val]?.getD 0) x=false) := by
  have hk' : PairedCubeIdentities.k2 target.val source.val ≠ 0 := by
    rw [← ActualInputCubes.actual_matrices cube hc target source]
    exact hk
  have hne := k2_uses_opposite_parity target source hk'
  have hp : selectorParity target.val = !(selectorParity source.val) := by
    cases ht : selectorParity target.val <;> cases hs : selectorParity source.val <;> simp_all
  have hsource := port_mem_of_index cube source.val source.isLt
  have htarget := port_mem_of_index cube target.val target.isLt
  rw [hp] at htarget
  have hf := ActualCubePorts.all_actual_carriers cube hc (selectorParity source.val)
  refine ⟨hf.carrier_rank.1, hf.carrier_rank.2,
    source_line_enters cube _ hf _ hsource, ?_⟩
  intro x hx
  exact ⟨actual_carrier_bounded cube hc _ x hx, hf.carrier_orthogonal _ htarget x hx⟩

end ActualKPortInterface
#print axioms ActualKPortInterface.port_mem_of_index
#print axioms ActualKPortInterface.port_from_cube
#print axioms ActualKPortInterface.span_bounded
#print axioms ActualKPortInterface.actual_carrier_bounded
#print axioms ActualKPortInterface.actual_K_port_connection
