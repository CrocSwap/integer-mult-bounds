import CompletionData
namespace CompletionCheck024
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch024.all CompletionCertificates.check=true := by decide
end CompletionCheck024
#print axioms CompletionCheck024.valid
