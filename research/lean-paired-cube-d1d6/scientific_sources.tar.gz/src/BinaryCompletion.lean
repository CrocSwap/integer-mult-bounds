import PrivateShear
namespace BinaryCompletion
open BinarySpace24 PrivateShear TensorThree

structure Permutation where
  forward : Index → Index
  inverse : Index → Index
  left : ∀ j, inverse (forward j)=j
  right : ∀ j, forward (inverse j)=j
  inverse_perm : ((List.finRange 24).map inverse).Perm (List.finRange 24)

def permute (p : Permutation) (x : Vec) : Vec := fun j => x (p.inverse j)
def unpermute (p : Permutation) (x : Vec) : Vec := fun j => x (p.forward j)

theorem permutation_left (p : Permutation) (x : Vec) : unpermute p (permute p x)=x := by
  funext j; simp only [unpermute,permute,p.left]
theorem permutation_right (p : Permutation) (x : Vec) : permute p (unpermute p x)=x := by
  funext j; simp only [unpermute,permute,p.right]
theorem permutation_pairing (p : Permutation) (x y : Vec) : dot (permute p x) (permute p y)=dot x y :=
  permutation_dot p.inverse p.inverse_perm x y

theorem permutation_adjoint (p : Permutation) (x z : Vec) : dot (permute p x) z=dot x (unpermute p z) := by
  have h := permutation_pairing p x (unpermute p z)
  simpa only [permutation_right] using h

def G (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x : Vec) : Vec :=
  shear pivot r (permute p x)
def Ginv (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x : Vec) : Vec :=
  unpermute p (shear pivot r x)
def GinvT (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x : Vec) : Vec :=
  transpose pivot r (permute p x)
def GT (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x : Vec) : Vec :=
  unpermute p (transpose pivot r x)

theorem inverse_left (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (x : Vec) : Ginv p pivot r (G p pivot r x)=x := by
  simp only [Ginv,G,shear_involution pivot r hr,permutation_left]
theorem inverse_right (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (x : Vec) : G p pivot r (Ginv p pivot r x)=x := by
  simp only [Ginv,G,permutation_right,shear_involution pivot r hr]
theorem transpose_inverse_left (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (x : Vec) : GT p pivot r (GinvT p pivot r x)=x := by
  simp only [GT,GinvT,transpose_involution pivot r hr,permutation_left]
theorem transpose_inverse_right (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (x : Vec) : GinvT p pivot r (GT p pivot r x)=x := by
  simp only [GT,GinvT,permutation_right,transpose_involution pivot r hr]

theorem G_zero (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) : G p pivot r zero=zero := by
  change shear pivot r zero=zero
  exact shear_zero _ _
theorem G_add (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x y : Vec) :
    G p pivot r (add x y)=add (G p pivot r x) (G p pivot r y) :=
  shear_add _ _ _ _
theorem GinvT_zero (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) : GinvT p pivot r zero=zero := by
  change transpose pivot r zero=zero
  exact transpose_zero _ _
theorem GinvT_add (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x y : Vec) :
    GinvT p pivot r (add x y)=add (GinvT p pivot r x) (GinvT p pivot r y) :=
  transpose_add _ _ _ _

theorem G_transpose (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x z : Vec) :
    dot (G p pivot r x) z=dot x (GT p pivot r z) := by
  rw [G,GT,adjoint,permutation_adjoint]

theorem inverse_transpose_pairing (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (x z : Vec) :
    dot (G p pivot r x) (GinvT p pivot r z)=dot x z := by
  rw [G_transpose,transpose_inverse_left p pivot r hr]

def KG (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (v : Vec × Vec) : Vec × Vec :=
  (G p pivot r v.1,add (G p pivot r v.1) (GinvT p pivot r (add v.1 v.2)))
def KGinv (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (v : Vec × Vec) : Vec × Vec :=
  let x := Ginv p pivot r v.1
  (x,add x (GT p pivot r (add v.1 v.2)))

theorem block_formula (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x z : Vec) :
    KG p pivot r (x,z)=(G p pivot r x,
      add (add (G p pivot r x) (GinvT p pivot r x)) (GinvT p pivot r z)) := by
  simp only [KG,GinvT_add,add_assoc]

theorem KG_inverse_left (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (v : Vec × Vec) : KGinv p pivot r (KG p pivot r v)=v := by
  simp only [KGinv,KG,inverse_left p pivot r hr]
  have hx (a b : Vec) : add a (add a b)=b := by rw [← add_assoc,add_self,zero_add]
  rw [hx,transpose_inverse_left p pivot r hr,hx]

theorem KG_inverse_right (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (v : Vec × Vec) : KG p pivot r (KGinv p pivot r v)=v := by
  simp only [KGinv,KG,inverse_right p pivot r hr]
  have hx (a b : Vec) : add a (add a b)=b := by rw [← add_assoc,add_self,zero_add]
  rw [hx,transpose_inverse_right p pivot r hr,hx]

def symplectic (v w : Vec × Vec) : Bool := dot v.1 w.2 ^^ dot v.2 w.1

theorem KG_symplectic (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (v w : Vec × Vec) :
    symplectic (KG p pivot r v) (KG p pivot r w)=symplectic v w := by
  simp only [symplectic,KG,dot_add,dot_add_left,inverse_transpose_pairing p pivot r hr]
  rw [dot_symmetric (GinvT p pivot r _),inverse_transpose_pairing p pivot r hr]
  simp only [dot_add,dot_symmetric v.1 w.1,dot_symmetric v.2 w.1,
    Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm,Bool.xor_self,Bool.false_xor,Bool.xor_false]
  rw [← Bool.xor_assoc (dot w.1 v.1) (dot w.1 v.1),Bool.xor_self,Bool.false_xor]

theorem KG_zero_frame (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (z : Vec) :
    KG p pivot r (zero,z)=(zero,GinvT p pivot r z) := by
  simp only [KG,G_zero,zero_add]
theorem KG_diagonal_frame (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec) (x : Vec) :
    KG p pivot r (x,x)=(G p pivot r x,G p pivot r x) := by
  simp only [KG,add_self,GinvT_zero,add_zero]

def Frame (U : Vec → Prop) (v : Vec × Vec) : Prop :=
  U v.1 ∧ ∀ u, U u → dot u (add v.1 v.2)=false
def Image (g : Vec → Vec) (U : Vec → Prop) (y : Vec) : Prop := ∃ x, U x ∧ g x=y

theorem KG_frame_transport (p : Permutation) (pivot : Axis → Index) (r : Axis → Vec)
    (hr : ∀ a b, r a (pivot b)=false) (U : Vec → Prop) (v : Vec × Vec) :
    Frame (Image (G p pivot r) U) (KG p pivot r v) ↔ Frame U v := by
  have hx (a b : Vec) : add a (add a b)=b := by rw [← add_assoc,add_self,zero_add]
  constructor
  · intro ⟨hU,horth⟩
    rcases hU with ⟨x,hxU,hxeq⟩
    have he : x=v.1 := by
      have h := congrArg (Ginv p pivot r) hxeq
      simpa only [KG,inverse_left p pivot r hr] using h
    refine ⟨he ▸ hxU,?_⟩
    intro u hu
    have h := horth (G p pivot r u) ⟨u,hu,rfl⟩
    simpa only [KG,hx,inverse_transpose_pairing p pivot r hr] using h
  · intro ⟨hU,horth⟩
    refine ⟨⟨v.1,hU,rfl⟩,?_⟩
    rintro y ⟨u,hu,rfl⟩
    simpa only [KG,hx,inverse_transpose_pairing p pivot r hr] using horth u hu

end BinaryCompletion
#print axioms BinaryCompletion.permutation_left
#print axioms BinaryCompletion.permutation_right
#print axioms BinaryCompletion.permutation_pairing
#print axioms BinaryCompletion.permutation_adjoint
#print axioms BinaryCompletion.inverse_left
#print axioms BinaryCompletion.inverse_right
#print axioms BinaryCompletion.transpose_inverse_left
#print axioms BinaryCompletion.transpose_inverse_right
#print axioms BinaryCompletion.G_zero
#print axioms BinaryCompletion.G_add
#print axioms BinaryCompletion.GinvT_zero
#print axioms BinaryCompletion.GinvT_add
#print axioms BinaryCompletion.G_transpose
#print axioms BinaryCompletion.inverse_transpose_pairing
#print axioms BinaryCompletion.block_formula
#print axioms BinaryCompletion.KG_inverse_left
#print axioms BinaryCompletion.KG_inverse_right
#print axioms BinaryCompletion.KG_symplectic
#print axioms BinaryCompletion.KG_zero_frame
#print axioms BinaryCompletion.KG_diagonal_frame
#print axioms BinaryCompletion.KG_frame_transport
