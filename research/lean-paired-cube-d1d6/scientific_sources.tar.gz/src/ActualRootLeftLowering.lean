import ActualLeftPhaseRecipe
namespace ActualRootLeftLowering
open BinarySpace24 RootFactorRawData LeftPassAddressPhase LeftPassInverseProgram Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem selected_forward (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (selectedOutgoing i hi htwo).encode ((selectedIncoming i hi htwo).decode f)=
      program i (CoordinateChild.gate i 21 (RootOneChildPass.rightPass i hi htwo f)) := by
  rw [RootOneChildPass.selected_one_coordinate_C,exact_program]

theorem selected_inverse (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    (selectedIncoming i hi htwo).encode ((selectedOutgoing i hi htwo).decode f)=
      RootOneChildPass.rightPassInverse i hi htwo (CoordinateChild.undoGate i 21 (inverseProgram i f)) := by
  rw [RootOneChildPass.selected_one_inverse_C,exact_inverse_program]

theorem actual_event (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (g : GaugeKeyTrace.State) (f : Vec → F) :
    CommonExactFrame.adapter (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 3 g 17326))
      (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 4 g 17326)) f=
      program i (CoordinateChild.gate i 21 (RootOneChildPass.rightPass i hi htwo f)) := by
  rw [RootOneChildPass.actual_root_event_one_child,exact_program]

end ActualRootLeftLowering
#print axioms ActualRootLeftLowering.selected_forward
#print axioms ActualRootLeftLowering.selected_inverse
#print axioms ActualRootLeftLowering.actual_event
