import RootFrameCatalog
import RootRecordKey
import RootCatalogExtension
import RootPilotSelection
import FrozenMSelector
namespace ActualRootSelection
open BinarySpace24 BinaryCompletion VariableCertificates CatalogSpanBridge RootCapCertificates CertifiedRepresentative Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def InRange (k : Nat) := RootRecordKey.InRange 17401 2640 k
noncomputable def record (k : Nat) (hk : InRange k) : Record :=
  RootRecordKey.witness RootFrameCatalog.records 17401 2640 RootFrameCatalog.key_range k hk

theorem record_member (k : Nat) (hk : InRange k) : record k hk ∈ RootFrameCatalog.records :=
  (RootRecordKey.witness_properties _ _ _ RootFrameCatalog.key_range k hk).1

theorem record_key (k : Nat) (hk : InRange k) : (frame (record k hk)).key=k :=
  (RootRecordKey.witness_properties _ _ _ RootFrameCatalog.key_range k hk).2

theorem record_cap (k : Nat) (hk : InRange k) : Span (frame (record k hk))=cap (record k hk) :=
  RootFrameCatalog.all_caps _ (record_member k hk)

def oldDomain (k : Nat) (hk : ActualOperationSelector.InRange k) :
    CatalogSelector.Domain OperationFrameCatalog.certificates (Span (ActualOperationSelector.witness k hk)) :=
  Or.inr ⟨ActualOperationSelector.witness k hk,ActualOperationSelector.witness_member k hk,rfl⟩

noncomputable def operation (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : ActualOperationSelector.InRange k) :=
  RootCatalogExtension.select i hi htwo OperationFrameCatalog.certificates RootPilotData.certificates RootFrameCatalog.certificates
    OperationFrameCatalog.valid RootPilotData.valid RootFrameCatalog.frame_valid (Span (ActualOperationSelector.witness k hk)) (Or.inl (Or.inl (oldDomain k hk)))

theorem operation_record_unchanged (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : ActualOperationSelector.InRange k) :
    operation i hi htwo k hk=ActualOperationSelector.keyRepresentative i hi htwo k hk := by
  rw [operation,RootCatalogExtension.old_preserved i hi htwo _ _ _ _ _ _ _ _ (oldDomain k hk)]
  rfl

noncomputable def root (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (r : Record) (hr : r ∈ RootFrameCatalog.records) :=
  RootCatalogExtension.select i hi htwo OperationFrameCatalog.certificates RootPilotData.certificates RootFrameCatalog.certificates
    OperationFrameCatalog.valid RootPilotData.valid RootFrameCatalog.frame_valid (Span (frame r))
    (Or.inr (Or.inr ⟨frame r,List.mem_map.mpr ⟨r,hr,rfl⟩,rfl⟩))

noncomputable def pilot (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ RootPilotData.certificates) :=
  RootCatalogExtension.select i hi htwo OperationFrameCatalog.certificates RootPilotData.certificates RootFrameCatalog.certificates
    OperationFrameCatalog.valid RootPilotData.valid RootFrameCatalog.frame_valid (Span c)
    (Or.inl (Or.inr (Or.inr ⟨c,hc,rfl⟩)))

theorem pilot_record_unchanged (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ RootPilotData.certificates) :
    pilot i hi htwo c hc=RootPilotSelection.root i hi htwo c hc := by
  apply RootCatalogExtension.prior_preserved

noncomputable def keyRepresentative (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (k : Nat) (hk : InRange k) :=
  root i hi htwo (record k hk) (record_member k hk)

theorem root_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (k : Nat) (hk : InRange k) (f : Vec → F) :
    (keyRepresentative i hi htwo k hk).decode ((keyRepresentative i hi htwo k hk).encode f)=f ∧
    (keyRepresentative i hi htwo k hk).encode ((keyRepresentative i hi htwo k hk).decode f)=f :=
  ⟨(keyRepresentative i hi htwo k hk).left_inverse f,(keyRepresentative i hi htwo k hk).right_inverse f⟩

theorem root_preimage (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (k : Nat) (hk : InRange k) (v : Vec × Vec) :
    ((keyRepresentative i hi htwo k hk).label v).1=zero ↔ Frame (cap (record k hk)) v := by
  rw [← record_cap]
  exact (keyRepresentative i hi htwo k hk).preimage v

theorem root_Pauli (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (k : Nat) (hk : InRange k) (v : Vec × Vec) (f : Vec → F) :
    let r := keyRepresentative i hi htwo k hk
    r.encode (ExactQuadraticLift.pauli v.1 v.2 (r.decode f))=
      fun x => r.phase v*ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 f x :=
  CertifiedRepresentative.exact_conjugation (keyRepresentative i hi htwo k hk) v f

theorem hyper_inherited (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (q : Nat) (hr : Record.hyper c q ∈ RootFrameCatalog.records) :
    (root i hi htwo (.hyper c q) hr).encode=InheritedEndpoints.target i (CompletionFrames.fromNat q) := by
  have hn := RootCapCertificates.hyper_norm c q (List.all_eq_true.mp RootFrameCatalog.geometry_valid _ hr)
  have he := RootFrameCatalog.all_caps (.hyper c q) hr
  exact RootCatalogExtension.inherited_target i hi htwo _ _ _ _ _ _ _ _ _ hn he

theorem root_same_subspace (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (r s : Record) (hr : r ∈ RootFrameCatalog.records) (hs : s ∈ RootFrameCatalog.records)
    (he : cap r=cap s) :
    (root i hi htwo r hr).toExactFrame=(root i hi htwo s hs).toExactFrame := by
  apply RootCatalogExtension.same_frame
  rw [RootFrameCatalog.all_caps r hr,RootFrameCatalog.all_caps s hs,he]

theorem root_old_same_subspace (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (r : Record) (hr : r ∈ RootFrameCatalog.records)
    (k : Nat) (hk : ActualOperationSelector.InRange k)
    (he : cap r=Span (ActualOperationSelector.witness k hk)) :
    (root i hi htwo r hr).toExactFrame=(ActualOperationSelector.keyRepresentative i hi htwo k hk).toExactFrame := by
  rw [← operation_record_unchanged i hi htwo k hk]
  apply RootCatalogExtension.same_frame
  rw [RootFrameCatalog.all_caps r hr,he] <;> rfl

theorem root_pilot_same_subspace (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (r : Record) (hr : r ∈ RootFrameCatalog.records)
    (c : Witness) (hc : c ∈ RootPilotData.certificates) (he : cap r=Span c) :
    (root i hi htwo r hr).toExactFrame=(RootPilotSelection.root i hi htwo c hc).toExactFrame := by
  rw [← pilot_record_unchanged i hi htwo c hc]
  apply RootCatalogExtension.same_frame
  rw [RootFrameCatalog.all_caps r hr,he] <;> rfl

end ActualRootSelection
#print axioms ActualRootSelection.record_member
#print axioms ActualRootSelection.record_key
#print axioms ActualRootSelection.record_cap
#print axioms ActualRootSelection.operation_record_unchanged
#print axioms ActualRootSelection.pilot_record_unchanged
#print axioms ActualRootSelection.root_inverses
#print axioms ActualRootSelection.root_preimage
#print axioms ActualRootSelection.root_Pauli
#print axioms ActualRootSelection.hyper_inherited
#print axioms ActualRootSelection.root_same_subspace
#print axioms ActualRootSelection.root_old_same_subspace

#print axioms ActualRootSelection.root_pilot_same_subspace
