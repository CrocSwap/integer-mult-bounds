import FieldEvaluation
import FullCoefficientIdentity
namespace ActualFieldNormalization
open Lean.Grind SignedPacking ReadoutAlgebra
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

/- This is the scalar extension of the certified integer coefficient matrix.
It does not instantiate a concrete rational type or reinterpret physical gates. -/
def combinedCoefficients (target : Nat) : List Int :=
  WeightedRows.vector 1760 FullModelData.rows
    ((FullTargetPacking.readout target).map (remap FullTargetPacking.roleNode) ++ CubeCorrection.terms target)

def combinedResponse (target : Nat) (payload : Nat → F) : F :=
  FieldEvaluation.evaluate (combinedCoefficients target) ((List.range 1760).map payload)

theorem coefficient_scalar_extension (target : Nat) (ht : target<1760) :
    (combinedCoefficients target).map (fun c : Int => (c : F)) =
      ((basis 1760 target).map (fun c => (6:Int)*c)).map (fun c : Int => (c : F)) :=
  congrArg (List.map (fun c : Int => (c : F))) (FullCoefficientIdentity.actual_combined_coefficients target ht)

theorem actual_scaled_response (target : Nat) (ht : target<1760) (payload : Nat → F) :
    combinedResponse target payload = (6:F)*payload target := by
  unfold combinedResponse combinedCoefficients
  rw [FullCoefficientIdentity.actual_combined_coefficients target ht]
  exact FieldEvaluation.scaled_basis_response 1760 target ht payload

theorem actual_normalized_response (target : Nat) (ht : target<1760) (payload : Nat → F)
    (hsix : (6:F) ≠ 0) : combinedResponse target payload / 6 = payload target := by
  rw [actual_scaled_response target ht payload]
  exact FieldEvaluation.divide_six _ hsix

end ActualFieldNormalization
#print axioms ActualFieldNormalization.coefficient_scalar_extension
#print axioms ActualFieldNormalization.actual_scaled_response
#print axioms ActualFieldNormalization.actual_normalized_response
