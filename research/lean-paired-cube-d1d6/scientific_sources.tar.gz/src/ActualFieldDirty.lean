import ActualFieldExecution
import FieldWordLaws
namespace ActualFieldDirty
open Lean.Grind FieldWordTrace FieldWordLaws ActualFieldExecution PairedWordData
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

theorem actual_word_restores (state : FState F) : undo word (run word state)=state :=
  FieldWordLaws.undo_run word word_legal state

theorem actual_word_inverse_other_direction (state : FState F) : run word (undo word state)=state :=
  FieldWordLaws.run_undo word word_legal state

theorem actual_auxiliary_restored (z payload : FState F) :
    sub (undo word (run word (add z (inject payload)))) (inject payload)=z := by
  rw [actual_word_restores]
  funext i
  simp [sub, add, Ring.sub_eq_add_neg, Semiring.add_assoc, Ring.add_neg_cancel, Semiring.add_zero]

theorem decoder_add (target : Nat) (x y : FState F) :
    decoderResponse target (add x y)=decoderResponse target x+decoderResponse target y :=
  FieldWordLaws.readout_add (FullTargetPacking.readout target) x y

theorem actual_dirty_scaled_response (z payload : FState F) (y : F) (target : Nat) (ht : target<1760) :
    (y-decoderResponse target (run word z)) +
      decoderResponse target (run word (add z (inject payload))) + correctionResponse target payload =
    y+(6:F)*payload target := by
  rw [FieldWordLaws.run_add, decoder_add]
  have hf := actual_scaled_execution target ht payload
  have hcancel (a b : F) : -a+(a+b)=b := by
    rw [← Semiring.add_assoc, Ring.neg_add_cancel, Semiring.zero_add]
  calc
    _ = y+(decoderResponse target (run word (inject payload))+correctionResponse target payload) := by
      simp [Ring.sub_eq_add_neg, Semiring.add_assoc, Ring.neg_add_cancel, Semiring.zero_add, hcancel]
    _ = _ := by rw [hf]

theorem actual_dirty_normalized_response (z payload : FState F) (y : F) (target : Nat) (ht : target<1760)
    (hsix : (6:F) ≠ 0) :
    (y-decoderResponse target (run word z)/6) +
      decoderResponse target (run word (add z (inject payload)))/6 + correctionResponse target payload/6 =
    y+payload target := by
  rw [FieldWordLaws.run_add, decoder_add, FieldWordLaws.divide_add]
  have hf := actual_normalized_execution target ht payload hsix
  have hcancel (a b : F) : -a+(a+b)=b := by
    rw [← Semiring.add_assoc, Ring.neg_add_cancel, Semiring.zero_add]
  calc
    _ = y+(decoderResponse target (run word (inject payload))/6+correctionResponse target payload/6) := by
      simp [Ring.sub_eq_add_neg, Semiring.add_assoc, Ring.neg_add_cancel, Semiring.zero_add, hcancel]
    _ = _ := by rw [hf]

end ActualFieldDirty
#print axioms ActualFieldDirty.actual_word_restores
#print axioms ActualFieldDirty.actual_word_inverse_other_direction
#print axioms ActualFieldDirty.actual_auxiliary_restored
#print axioms ActualFieldDirty.decoder_add
#print axioms ActualFieldDirty.actual_dirty_scaled_response
#print axioms ActualFieldDirty.actual_dirty_normalized_response
