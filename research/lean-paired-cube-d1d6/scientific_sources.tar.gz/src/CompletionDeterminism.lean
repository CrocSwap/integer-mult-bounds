import CompletionFrames
namespace CompletionDeterminism
open BinarySpace24 CompletionCertificates TensorThree

theorem pivot_private (c : Witness) (hc : Facts c) (axis : Axis) :
    privatePosition c axis (pivot c axis).val=true := by
  unfold privatePosition
  have hs := hc.private_pivots axis axis
  change (vector c axis (pivot c axis) && _)=true
  rw [hs]
  simp only [decide_true,Bool.true_and,List.all_eq_true]
  intro other ho
  have h := hc.private_pivots other axis
  change (decide (other=axis) || !(vector c other (pivot c axis)))=true
  rw [h]
  cases decide (other=axis) <;> rfl

theorem private_position_equal (c d : Witness) (hCube : c.cube=d.cube) (hParity : c.parity=d.parity)
    (axis : Axis) (j : Nat) : privatePosition c axis j=privatePosition d axis j := by
  simp only [privatePosition,source,hCube,hParity]

theorem pivot_deterministic (c d : Witness) (hc : Facts c) (hd : Facts d)
    (hCube : c.cube=d.cube) (hParity : c.parity=d.parity) : pivot c=pivot d := by
  funext axis
  apply Fin.ext
  have hpC := pivot_private c hc axis
  have hpD := pivot_private d hd axis
  rw [private_position_equal c d hCube hParity] at hpC
  rw [← private_position_equal c d hCube hParity] at hpD
  have hnotC : ¬ (pivot c axis).val < (pivot d axis).val := by
    intro h
    have hf := hd.least_private axis _ h
    rw [hpC] at hf
    cases hf
  have hnotD : ¬ (pivot d axis).val < (pivot c axis).val := by
    intro h
    have hf := hc.least_private axis _ h
    rw [hpD] at hf
    cases hf
  omega

theorem permutation_deterministic (c d : Witness) (hc : Facts c) (hd : Facts d)
    (hCube : c.cube=d.cube) (hParity : c.parity=d.parity) :
    forward c=forward d ∧ inverse c=inverse d := by
  have hp := pivot_deterministic c d hc hd hCube hParity
  have hl : c.forward=d.forward := by rw [hc.normal_form,hd.normal_form,normalForm,normalForm,hp]
  have hf : forward c=forward d := by funext j; simp only [forward,hl]
  refine ⟨hf,?_⟩
  funext j
  have hh := hc.left (inverse d j)
  rw [hf,hd.right] at hh
  exact hh

theorem full_map_deterministic (c d : Witness) (hc : Facts c) (hd : Facts d)
    (hCube : c.cube=d.cube) (hParity : c.parity=d.parity) : fullMap c hc=fullMap d hd := by
  have hp := pivot_deterministic c d hc hd hCube hParity
  have hi := (permutation_deterministic c d hc hd hCube hParity).2
  have hr : residual c=residual d := by
    funext axis k
    simp only [residual,add,unit,vector,source,hCube,hParity,hp]
  have hperm : BinaryCompletion.permute (permutation c hc)=BinaryCompletion.permute (permutation d hd) := by
    funext x j
    exact congrArg x (congrFun hi j)
  funext x
  simp only [fullMap,BinaryCompletion.G,hperm,hp,hr]


end CompletionDeterminism
#print axioms CompletionDeterminism.pivot_private
#print axioms CompletionDeterminism.private_position_equal
#print axioms CompletionDeterminism.pivot_deterministic
#print axioms CompletionDeterminism.permutation_deterministic
#print axioms CompletionDeterminism.full_map_deterministic
