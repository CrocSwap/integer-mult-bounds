import RegisterStageComposition
namespace FourRegisterStages
open BinarySpace24 BinaryCompletion SequentialCXKernel SuppliedQuarterTable RegisterStateAdapters Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

@[irreducible] def forwardPermutation (s : State Vec F) := lift CompleteOuterAddressMemory.forwardPermutation s
@[irreducible] def inversePermutation (s : State Vec F) := lift CompleteOuterAddressMemory.inversePermutation s
@[irreducible] def leftCX (s : State Vec F) := SequentialCXProgram.program ActualSequentialCXPrograms.leftSpecs s
@[irreducible] def rightCX (s : State Vec F) := SequentialCXProgram.program ActualSequentialCXPrograms.rightSpecs s
@[irreducible] def leftPhase (t : Table F) (s : State Vec F) := lift (ActualPointPhase.left t) s
@[irreducible] def rightPhase (t : Table F) (s : State Vec F) := lift (ActualPointPhase.right t) s

theorem forward_memory (s : State Vec F) : (forwardPermutation s).1.work.memory=fun x=>s.work.memory (permute RootAddressInstructions.permutation x) := by
  rw [forwardPermutation,lift_memory,CompleteOuterAddressMemory.forward_memory];rfl

theorem inverse_memory (s : State Vec F) : (inversePermutation s).1.work.memory=fun x=>s.work.memory (unpermute RootAddressInstructions.permutation x) := by
  rw [inversePermutation,lift_memory,CompleteOuterAddressMemory.inverse_memory];rfl

theorem left_CX_memory (s : State Vec F) : (leftCX s).1.work.memory=fun x=>s.work.memory (Q21AddressProgram.run ActualOuterCXPrograms.leftCX x) := by
  rw [leftCX,ActualSequentialCXPrograms.left_memory]

theorem right_CX_memory (s : State Vec F) : (rightCX s).1.work.memory=fun x=>s.work.memory (Q21AddressProgram.run ActualOuterCXPrograms.rightCX x) := by
  rw [rightCX,ActualSequentialCXPrograms.right_memory]

theorem forward_cost (s : State Vec F) : (forwardPermutation s).2=⟨134217728,134217728,0⟩ := by
  rw [forwardPermutation,lift_cost,CompleteOuterAddressMemory.forward_cost]

theorem inverse_cost (s : State Vec F) : (inversePermutation s).2=⟨134217728,134217728,0⟩ := by
  rw [inversePermutation,lift_cost,CompleteOuterAddressMemory.inverse_cost]

theorem left_CX_cost (s : State Vec F) : (leftCX s).2=⟨83886080,83886080,41943040,83886080⟩ := by
  rw [leftCX,ActualSequentialCXPrograms.left_receipt]

theorem right_CX_cost (s : State Vec F) : (rightCX s).2=⟨83886080,83886080,41943040,83886080⟩ := by
  rw [rightCX,ActualSequentialCXPrograms.right_receipt]

theorem left_phase_memory (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (s : State Vec F) :
    (leftPhase t s).1.work.memory=fun x=>LeftPassAddressPhase.scalar i x*s.work.memory x := by
  rw [leftPhase,lift_memory,ActualPointPhase.left_memory i hi t ht];rfl

theorem right_phase_memory (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (s : State Vec F) :
    (rightPhase t s).1.work.memory=fun x=>RightPassAddressPhase.scalar i x*s.work.memory x := by
  rw [rightPhase,lift_memory,ActualPointPhase.right_memory i hi t ht];rfl

theorem left_phase_cost (t : Table F) (s : State Vec F) : (leftPhase t s).2=PointPhaseMachine.scaleCost 16777216 ActualPointPhase.leftPointCost := by
  rw [leftPhase,lift_cost,ActualPointPhase.left_cost]

theorem right_phase_cost (t : Table F) (s : State Vec F) : (rightPhase t s).2=PointPhaseMachine.scaleCost 16777216 ActualPointPhase.rightPointCost := by
  rw [rightPhase,lift_cost,ActualPointPhase.right_cost]

end FourRegisterStages
#print axioms FourRegisterStages.forward_memory
#print axioms FourRegisterStages.inverse_memory
#print axioms FourRegisterStages.left_CX_memory
#print axioms FourRegisterStages.right_CX_memory
#print axioms FourRegisterStages.forward_cost
#print axioms FourRegisterStages.inverse_cost
#print axioms FourRegisterStages.left_CX_cost
#print axioms FourRegisterStages.right_CX_cost
#print axioms FourRegisterStages.left_phase_memory
#print axioms FourRegisterStages.right_phase_memory
#print axioms FourRegisterStages.left_phase_cost
#print axioms FourRegisterStages.right_phase_cost
