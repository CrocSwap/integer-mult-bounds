import AssemblyExpressions13955
namespace PairedCubeAssembly13955
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

theorem parameter_a_bit_derived : ExactValue a 4613422943 10000000000000 ∧ Positive a := by
  decide

theorem parameter_a_complex_derived : ExactValue b 4856569 10000000000 ∧ Positive b := by
  decide

theorem parameter_actual_bit_saving_derived : ExactValue AB 4613422943 10000000000000 ∧ Positive AB := by
  decide

theorem parameter_alpha_squared_power_derived : ExactValue r 34600921380486558550000000 50046134228737986553936577057 ∧ Positive r := by
  decide

theorem parameter_beta_derived : ExactValue beta 1 1000000 ∧ Positive beta := by
  decide

theorem parameter_c_derived : ExactValue c 23067114484328848236577057 50000000000000000000000000000 ∧ Positive c := by
  decide

theorem parameter_delta_derived : ExactValue delta 1 800000000 ∧ Positive delta := by
  decide

theorem parameter_epsilon_derived : ExactValue eps 49999999500000000000000000000 50046134228737986553936577057 ∧ Positive eps := by
  decide

theorem parameter_eta_derived : ExactValue eta 1 100000000 ∧ Positive eta := by
  decide

theorem parameter_kappa_derived : ExactValue KAPPA 4609169 10000000000 ∧ Positive KAPPA := by
  decide

theorem parameter_lambda__derived : ExactValue lam 999538657710313422943 1000000000000000000000 ∧ Positive lam := by
  decide

theorem parameter_lambda_prime_derived : ExactValue lp 499769328857463422943 500000000000000000000 ∧ Positive lp := by
  decide

theorem parameter_q_derived : ExactValue q 230671142536577057 500000000000000000000 ∧ Positive q := by
  decide

theorem parameter_sigma_derived : ExactValue sigma 9995143431 10000000000 ∧ Positive sigma := by
  decide

theorem parameter_tau_derived : ExactValue tau 9995386577057 10000000000000 ∧ Positive tau := by
  decide

theorem recurrence_internal_derived : ExactValue internal 9995386577057 10000000000000 ∧ Positive internal := by
  decide

theorem recurrence_leaf_derived : ExactValue leaf 9995143435856569 10000000000000000 ∧ Positive leaf := by
  decide

theorem recurrence_reservations_derived : ExactValue (1-c) 49976932885515671151763422943 50000000000000000000000000000 ∧ Positive (1-c) := by
  decide

theorem actual_bit_selected : ASSEMBLY_BIT = AB ∧ AtMost AB ((1-PHASE_STOP)*AC-⟨1,10000000000⟩) := by
  decide

theorem internal_max_branch : pairMax (sigma-tau) 0 = 0 ∧ SameValue internal tau := by
  decide

theorem gaussian_min_branch : pairMin (1-eps-delta) (r-delta) = r-delta := by
  decide

theorem division_denominators_positive : Positive (1+c+q) ∧ Positive (2 : Pair) ∧ Positive (8 : Pair) ∧ Positive (25 : Pair) := by
  decide

theorem row_coefficient_derived : ExactValue rowCoefficient 20445 1 := by
  decide

theorem row_gap_derived : ExactValue rowGap 141461 5 ∧ Positive rowGap := by
  decide

theorem minimum_derived : ExactValue minimum 23067114022986563163422943 50046134228737986553936577057 ∧ Positive minimum := by
  decide

theorem absorption_gap_derived : ExactValue (minimum-KAPPA) 49772927594887408131062764367 500461342287379865539365770570000000000 ∧ Positive (minimum-KAPPA) := by
  decide

theorem strict_absorption : Below KAPPA minimum := by
  decide

theorem next_grid_point_rejected : Below minimum (KAPPA+⟨1,10000000000⟩) := by
  decide

theorem original_prefix_difference : SameValue (margin_original_prefix-minimum) eta := by
  decide

theorem selected_dyadic_range : Below ⟨1,4096⟩ KAPPA ∧ Below KAPPA ⟨1,2048⟩ := by
  decide

end PairedCubeAssembly13955
#print axioms PairedCubeAssembly13955.parameter_a_bit_derived
#print axioms PairedCubeAssembly13955.parameter_a_complex_derived
#print axioms PairedCubeAssembly13955.parameter_actual_bit_saving_derived
#print axioms PairedCubeAssembly13955.parameter_alpha_squared_power_derived
#print axioms PairedCubeAssembly13955.parameter_beta_derived
#print axioms PairedCubeAssembly13955.parameter_c_derived
#print axioms PairedCubeAssembly13955.parameter_delta_derived
#print axioms PairedCubeAssembly13955.parameter_epsilon_derived
#print axioms PairedCubeAssembly13955.parameter_eta_derived
#print axioms PairedCubeAssembly13955.parameter_kappa_derived
#print axioms PairedCubeAssembly13955.parameter_lambda__derived
#print axioms PairedCubeAssembly13955.parameter_lambda_prime_derived
#print axioms PairedCubeAssembly13955.parameter_q_derived
#print axioms PairedCubeAssembly13955.parameter_sigma_derived
#print axioms PairedCubeAssembly13955.parameter_tau_derived
#print axioms PairedCubeAssembly13955.recurrence_internal_derived
#print axioms PairedCubeAssembly13955.recurrence_leaf_derived
#print axioms PairedCubeAssembly13955.recurrence_reservations_derived
#print axioms PairedCubeAssembly13955.actual_bit_selected
#print axioms PairedCubeAssembly13955.internal_max_branch
#print axioms PairedCubeAssembly13955.gaussian_min_branch
#print axioms PairedCubeAssembly13955.division_denominators_positive
#print axioms PairedCubeAssembly13955.row_coefficient_derived
#print axioms PairedCubeAssembly13955.row_gap_derived
#print axioms PairedCubeAssembly13955.minimum_derived
#print axioms PairedCubeAssembly13955.absorption_gap_derived
#print axioms PairedCubeAssembly13955.strict_absorption
#print axioms PairedCubeAssembly13955.next_grid_point_rejected
#print axioms PairedCubeAssembly13955.original_prefix_difference
#print axioms PairedCubeAssembly13955.selected_dyadic_range
