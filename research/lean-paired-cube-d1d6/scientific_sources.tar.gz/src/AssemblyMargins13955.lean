import AssemblyExpressions13955
namespace PairedCubeAssembly13955
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

theorem margin_original_prefix_derived : ExactValue margin_original_prefix 2306761448432885054328848236577057 5004613422873798655393657705700000000 ∧ AtMost minimum margin_original_prefix ∧ Below KAPPA margin_original_prefix := by
  decide

theorem margin_coordinate_movement_derived : ExactValue margin_coordinate_movement 4613422943 10000000000000 ∧ AtMost minimum margin_coordinate_movement ∧ Below KAPPA margin_coordinate_movement := by
  decide

theorem margin_compact_phase_layer_derived : ExactValue margin_compact_phase_layer 23067114022986563163422943 50046134228737986553936577057 ∧ AtMost minimum margin_compact_phase_layer ∧ Below KAPPA margin_compact_phase_layer := by
  decide

theorem margin_bulk_exposure_derived : ExactValue margin_bulk_exposure 4613422943 10000000000000 ∧ AtMost minimum margin_bulk_exposure ∧ Below KAPPA margin_bulk_exposure := by
  decide

theorem margin_Gaussian_arithmetic_derived : ExactValue margin_Gaussian_arithmetic 27680687058255018102013446063422943 40036907382990389243149261645600000000 ∧ AtMost minimum margin_Gaussian_arithmetic ∧ Below KAPPA margin_Gaussian_arithmetic := by
  decide

theorem margin_scalar_work_derived : ExactValue margin_scalar_work 36907732944255014411275091663422943 40036907382990389243149261645600000000 ∧ AtMost minimum margin_scalar_work ∧ Below KAPPA margin_scalar_work := by
  decide

theorem margin_dimension_derived : ExactValue margin_dimension 49999999500000000000000000000 50046134228737986553936577057 ∧ AtMost minimum margin_dimension ∧ Below KAPPA margin_dimension := by
  decide

end PairedCubeAssembly13955
#print axioms PairedCubeAssembly13955.margin_original_prefix_derived
#print axioms PairedCubeAssembly13955.margin_coordinate_movement_derived
#print axioms PairedCubeAssembly13955.margin_compact_phase_layer_derived
#print axioms PairedCubeAssembly13955.margin_bulk_exposure_derived
#print axioms PairedCubeAssembly13955.margin_Gaussian_arithmetic_derived
#print axioms PairedCubeAssembly13955.margin_scalar_work_derived
#print axioms PairedCubeAssembly13955.margin_dimension_derived
