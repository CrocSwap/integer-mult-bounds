import Q21AddressProgram
import ActualOperationSelector
import Init.Data.List.Nat.Range
namespace FirstEventBinding
open BinarySpace24 VariableCertificates CatalogSpanBridge EndpointGeometry Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def firstStep : PairedWord.Step := ⟨1,0,1,false⟩
def entranceKey : Nat := 0
def destinationKey : Nat := 1

theorem actual_first_step : PairedWordData.word[0]?=some firstStep := rfl

theorem actual_first_member : firstStep ∈ PairedWordData.word := List.mem_of_getElem? actual_first_step

theorem actual_first_key : ActualFrameKeys.key firstStep=destinationKey := by decide

theorem first_role_transition : entranceKey=0 ∧ destinationKey=1 ∧ firstStep.dst=1 ∧ firstStep.src=0 := by decide

theorem map_key_injective (cs : List Witness) (hn : (cs.map Witness.key).Nodup)
    (c d : Witness) (hc : c ∈ cs) (hd : d ∈ cs) (he : c.key=d.key) : c=d := by
  induction cs with
  | nil => exact False.elim (List.not_mem_nil hc)
  | cons a as ih =>
    have hh := List.nodup_cons.mp hn
    rcases List.mem_cons.mp hc with hc | hc
    · subst c
      rcases List.mem_cons.mp hd with hd | hd
      · exact hd.symm
      · exact False.elim (hh.1 (List.mem_map.mpr ⟨d,hd,he.symm⟩))
    · rcases List.mem_cons.mp hd with hd | hd
      · subst d
        exact False.elim (hh.1 (List.mem_map.mpr ⟨c,hc,he⟩))
      · exact ih hh.2 hc hd

theorem catalog_keys_unique : (OperationFrameCatalog.certificates.map Witness.key).Nodup := by
  rw [OperationFrameCatalog.key_range]
  exact List.nodup_range'

theorem first_certificate_member : OperationFrameShard0000.cert0 ∈ OperationFrameCatalog.certificates := by
  apply List.mem_of_getElem? (i := 0)
  rfl

theorem witness_one (hk : ActualOperationSelector.InRange 1) :
    ActualOperationSelector.witness 1 hk=OperationFrameShard0000.cert0 := by
  apply map_key_injective OperationFrameCatalog.certificates catalog_keys_unique
    _ _ (ActualOperationSelector.witness_member 1 hk) first_certificate_member
  exact ActualOperationSelector.witness_key 1 hk

theorem first_certificate_span : Span OperationFrameShard0000.cert0=Line SourceLineCase.q := by
  funext y
  apply propext
  change (∃x : Vec, add (scale (x 0) SourceLineCase.q) zero=y) ↔ _
  simp only [add_zero]
  constructor
  · rintro ⟨x,hx⟩
    rw [← hx]
    exact scalar_cases _ _
  · intro hy
    rcases hy with hy | hy
    · exact ⟨zero,hy.symm⟩
    · exact ⟨unit 0,hy.symm⟩

theorem selected_first_operator (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (hk : ActualOperationSelector.InRange 1) :
    (ActualOperationSelector.keyRepresentative i hi htwo 1 hk).encode=SourceLineOperator.inheritedLine i := by
  let cs := OperationFrameCatalog.certificates
  let hv := OperationFrameCatalog.valid
  have he : Span (ActualOperationSelector.witness 1 hk)=Line SourceLineCase.q := by
    rw [witness_one,first_certificate_span]
  have hU : CatalogSelector.Domain cs (Span (ActualOperationSelector.witness 1 hk)) :=
    Or.inr ⟨ActualOperationSelector.witness 1 hk,ActualOperationSelector.witness_member 1 hk,rfl⟩
  have hV : CatalogSelector.Domain cs (Line SourceLineCase.q) :=
    Or.inl (Or.inr (Or.inr (Or.inl ⟨SourceLineCase.q,SourceLineCase.source_norm,rfl⟩)))
  have hs := CatalogSelector.all_same_frame i hi htwo cs hv _ _ hU hV he
  change (CatalogSelector.catalog i hi htwo cs hv _ hU).encode=_
  rw [hs,CatalogSelector.all_source_preserved i hi htwo cs hv _ SourceLineCase.source_norm,
    ActualEndpointSelector.actual_source_formula i hi]

theorem first_event_lowering (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (hk : ActualOperationSelector.InRange 1) (f : Vec → F) :
    Q21AddressProgram.lowered i f=(ActualOperationSelector.keyRepresentative i hi htwo 1 hk).encode f := by
  rw [Q21AddressProgram.exact_lowering,selected_first_operator i hi htwo]

theorem actual_step_lowering (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    Q21AddressProgram.lowered i f=(ActualOperationSelector.stepRepresentative i hi htwo firstStep actual_first_member).encode f := by
  unfold ActualOperationSelector.stepRepresentative
  exact first_event_lowering i hi htwo _ f

end FirstEventBinding
#print axioms FirstEventBinding.actual_first_step
#print axioms FirstEventBinding.actual_first_member
#print axioms FirstEventBinding.actual_first_key
#print axioms FirstEventBinding.first_role_transition
#print axioms FirstEventBinding.map_key_injective
#print axioms FirstEventBinding.catalog_keys_unique
#print axioms FirstEventBinding.first_certificate_member
#print axioms FirstEventBinding.witness_one
#print axioms FirstEventBinding.first_certificate_span
#print axioms FirstEventBinding.selected_first_operator
#print axioms FirstEventBinding.first_event_lowering
#print axioms FirstEventBinding.actual_step_lowering
