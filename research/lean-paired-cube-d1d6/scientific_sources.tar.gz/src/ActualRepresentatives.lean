import RepresentativeSquare
import ActualCompletion
namespace ActualRepresentatives
open BinarySpace24 BinaryCompletion CompletionCertificates CompletionFrames ActualCompletion ExactQuadraticLift CarrierRepresentative Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem all_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ CompletionData.certificates) (f : Vec → F) :
    inverseRepresentative i c (facts c hc) (representative i c (facts c hc) f)=f ∧
    representative i c (facts c hc) (inverseRepresentative i c (facts c hc) f)=f :=
  ⟨CarrierRepresentative.inverse_left i hi htwo c _ f,CarrierRepresentative.inverse_right i hi htwo c _ f⟩

theorem all_pauli_conjugations (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ CompletionData.certificates) (v : Vec × Vec) (f : Vec → F) :
    representative i c (facts c hc) (pauli v.1 v.2 (inverseRepresentative i c (facts c hc) f))=
      fun x => exactPhase i c (facts c hc) v*pauli (label c (facts c hc) v).1 (label c (facts c hc) v).2 f x :=
  CarrierRepresentative.pauli_conjugation i hi htwo c _ (source_member c hc) v f

theorem all_phase_units (i : F) (hi : i*i= -1) (c : Witness) (hc : c ∈ CompletionData.certificates) (v : Vec × Vec) :
    exactPhase i c (facts c hc) v≠0 := RepresentativePhase.exact_phase_nonzero i hi c _ v

theorem all_preimage_frames (c : Witness) (hc : c ∈ CompletionData.certificates) (v : Vec × Vec) :
    (label c (facts c hc) v).1=zero ↔ Frame (ActualCarrier c) v :=
  CarrierRepresentative.frame_preimage c _ (source_member c hc) v

theorem all_exact_squares (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (c : Witness) (hc : c ∈ CompletionData.certificates) (f : Vec → F) :
    representative i c (facts c hc) (representative i c (facts c hc) f)=
      fun x => -pauli (blockMap c (facts c hc) (RepresentativeSquare.displacement,zero)).1
        (blockMap c (facts c hc) (RepresentativeSquare.displacement,zero)).2 f x :=
  RepresentativeSquare.representative_square i hi htwo c _ (source_member c hc) f

theorem actual_representative (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    ∃ c, c.cube=cube ∧ c.parity=parity ∧ ∃ h : Facts c,
      (∀ f : Vec → F, inverseRepresentative i c h (representative i c h f)=f ∧
        representative i c h (inverseRepresentative i c h f)=f) ∧
      (∀ v (f : Vec → F), representative i c h (pauli v.1 v.2 (inverseRepresentative i c h f))=
        fun x => exactPhase i c h v*pauli (label c h v).1 (label c h v).2 f x) ∧
      (∀ v, (label c h v).1=zero ↔ Frame (ActualCarrier c) v) := by
  rcases source_coverage cube hc parity with ⟨c,hm,he,hp⟩
  exact ⟨c,he,hp,facts c hm,all_inverses i hi htwo c hm,
    all_pauli_conjugations i hi htwo c hm,all_preimage_frames c hm⟩

end ActualRepresentatives
#print axioms ActualRepresentatives.all_inverses
#print axioms ActualRepresentatives.all_pauli_conjugations
#print axioms ActualRepresentatives.all_phase_units
#print axioms ActualRepresentatives.all_preimage_frames
#print axioms ActualRepresentatives.all_exact_squares
#print axioms ActualRepresentatives.actual_representative
