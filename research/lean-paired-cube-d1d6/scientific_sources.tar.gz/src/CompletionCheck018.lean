import CompletionData
namespace CompletionCheck018
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch018.all CompletionCertificates.check=true := by decide
end CompletionCheck018
#print axioms CompletionCheck018.valid
