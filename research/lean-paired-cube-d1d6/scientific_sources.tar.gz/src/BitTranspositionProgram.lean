import GenericReverseMachine
namespace BitTranspositionProgram
open BinarySpace24 BinaryPairEnumeration BinaryCompletion BitSwapCounter
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

structure Spec where
  a : Index
  b : Index
  facts : IndexTransposition.Facts a b

def Spec.permutation (s : Spec) := IndexTransposition.permutation s.a s.b s.facts

def run : List Spec → Vec → Vec
  | [],x => x
  | a::as,x => run as (IndexTransposition.address a.a a.b x)

def lookup : List Spec → Index → Index
  | [],j => j
  | a::as,j => IndexTransposition.exchange a.a a.b (lookup as j)

theorem run_lookup (as : List Spec) (x : Vec) (j : Index) : run as x j=x (lookup as j) := by
  induction as generalizing x with
  | nil => rfl
  | cons a as ih => rw [run,ih]; rfl

def program (as : List Spec) (s : PairLoadStoreMachine.State Vec V) :=
  GenericReverseMachine.fold (fun a : Spec => BitSwapCounter.execute a.permutation) Cost.zero Cost.add as s

def programCost (n : Nat) : Cost := ⟨8388608*n,8388608*n,0⟩


theorem cost_formula (as : List Spec) :
    GenericReverseMachine.receipt (fun _ : Spec=>(⟨8388608,8388608,0⟩:Cost)) Cost.zero Cost.add as=programCost as.length := by
  induction as with
  | nil => rfl
  | cons a as ih =>
    simp only [GenericReverseMachine.receipt,ih,programCost,Cost.add,List.length_cons,Nat.mul_add,Nat.mul_one]

theorem program_cost (as : List Spec) (s : PairLoadStoreMachine.State Vec V) :
    (program as s).2=programCost as.length :=
  (GenericReverseMachine.cost (fun a : Spec=>BitSwapCounter.execute a.permutation) Cost.zero Cost.add
    (fun _ : Spec=>(⟨8388608,8388608,0⟩:Cost)) (fun a s=>BitSwapCounter.execute_cost a.permutation s) as s).trans (cost_formula as)

end BitTranspositionProgram
#print axioms BitTranspositionProgram.run_lookup
#print axioms BitTranspositionProgram.program_cost
#print axioms BitTranspositionProgram.cost_formula
