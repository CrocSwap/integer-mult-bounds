import AsymmetricPacking
import ReadoutAlgebra
namespace FreshResponseInterface
open PairedWord PairedDecoder DagSemantics MaskRows MaskModels PackedModels WeightedRows ReadoutAlgebra

/- The remaining hypotheses are concrete finite certificate checks, not axioms.
This theorem alone does not assert their validity for the merged source. -/
theorem response_from_certificates (g : Graph) (rows : Nat → Row) (packed : State)
    (hr : ∀ n, rowCheck 1760 g.node rows n = true)
    (hp : ∀ n, packedCheck 1760 g.node packed n = true)
    (hg : sourceGraphCheck g = true)
    (target : Nat) (ht : target<1760) (readout : List ReadTerm) (f : Nat → Nat)
    (hw : weight readout = 48)
    (hc : PairedDecoder.evaluate (readout.map (remap f) ++ CubeCorrection.terms target) packed = 6*(128:Int)^target)
    (payload : State) :
    PairedDecoder.evaluate readout (fun role => value g payload (f role)) + CubeCorrection.response target payload =
      6*payload target := by
  let ts := readout.map (remap f) ++ CubeCorrection.terms target
  have he : PairedDecoder.evaluate ts (fun n => encoded 1760 (rows n)) = 6*(128:Int)^target := by
    calc
      PairedDecoder.evaluate ts (fun n => encoded 1760 (rows n)) = PairedDecoder.evaluate ts packed := by
        apply PairedDecoder.evaluate_congr
        intro term hterm
        exact (packed_equals_coefficient_encoding 1760 g rows packed hr hp term.role).symm
      _ = _ := hc
  have hweight : weight ts ≤ 60 := by
    rw [show weight ts = 60 from combined_weight target readout f hw]
    exact Nat.le_refl 60
  have hv := SignedPacking.weighted_response_from_packing 1760 target rows ts ht hweight he payload
  have heval : PairedDecoder.evaluate ts (fun n => evaluated 1760 (rows n) payload) = PairedDecoder.evaluate ts (value g payload) := by
    apply PairedDecoder.evaluate_congr
    intro term hterm
    exact coefficient_evaluation_equals_graph 1760 g rows hr payload term.role
  rw [heval] at hv
  change PairedDecoder.evaluate (readout.map (remap f) ++ CubeCorrection.terms target) (value g payload) = _ at hv
  rw [evaluate_append, evaluate_remap, CubeCorrection.graph_response g hg target ht payload] at hv
  exact hv

end FreshResponseInterface
#print axioms FreshResponseInterface.response_from_certificates
