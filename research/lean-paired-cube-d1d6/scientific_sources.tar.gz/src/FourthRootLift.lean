import FourthRootRecipe
import ExactQuadraticLift
namespace FourthRootLift
open BinarySpace24 FourthRootRecipe Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

structure Chart where
  forward : Vec → Vec
  inverse : Vec → Vec
  inverseTranspose : Vec → Vec
  inverse_left : ∀ x, inverse (forward x)=x
  inverse_right : ∀ x, forward (inverse x)=x
  forward_add : ∀ x y, forward (add x y)=add (forward x) (forward y)
  transpose_pairing : ∀ x z, dot (forward x) (inverseTranspose z)=dot x z

def GramCompatible (c : Chart) (ts : List Term) : Prop :=
  ∀ x u, dot x (shear ts u)=(dot (c.forward x) (c.forward u) ^^ dot x u)

def label (c : Chart) (v : Vec × Vec) : Vec × Vec :=
  (c.forward v.1,add (c.forward v.1) (c.inverseTranspose (add v.1 v.2)))

def lift (i : F) (c : Chart) (ts : List Term) (f : Vec → F) (y : Vec) : F :=
  phase i ts (c.inverse y)*f (c.inverse y)
def unlift (i : F) (c : Chart) (ts : List Term) (f : Vec → F) (x : Vec) : F :=
  phase (-i) ts x*f (c.forward x)

theorem inverse_left (i : F) (hi : i*i= -1) (c : Chart) (ts : List Term) (f : Vec → F) :
    unlift i c ts (lift i c ts f)=f := by
  funext x
  simp only [unlift,lift,c.inverse_left,← Semiring.mul_assoc,phase_inverse i hi,Semiring.one_mul]

theorem inverse_right (i : F) (hi : i*i= -1) (c : Chart) (ts : List Term) (f : Vec → F) :
    lift i c ts (unlift i c ts f)=f := by
  funext y
  have h := phase_inverse i hi ts (c.inverse y)
  simp only [unlift,lift,c.inverse_right]
  grind

theorem lift_add (i : F) (c : Chart) (ts : List Term) (f g : Vec → F) :
    lift i c ts (fun x => f x+g x)=fun y => lift i c ts f y+lift i c ts g y := by
  funext y
  simp only [lift,Semiring.left_distrib]

theorem lift_scale (i : F) (c : Chart) (ts : List Term) (s : F) (f : Vec → F) :
    lift i c ts (fun x => s*f x)=fun y => s*lift i c ts f y := by
  funext y
  simp only [lift]
  grind

theorem label_phase (c : Chart) (ts : List Term) (hc : GramCompatible c ts) (u z x : Vec) :
    dot (label c (u,z)).2 (c.forward x)=(dot z x ^^ dot x (shear ts u)) := by
  simp only [label,dot_add_left]
  rw [dot_symmetric (c.forward u),dot_symmetric (c.inverseTranspose _),c.transpose_pairing,dot_add]
  rw [hc x u,dot_symmetric z x]
  simp only [Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem pauli_conjugation (i : F) (hi : i*i= -1) (c : Chart) (ts : List Term)
    (hc : GramCompatible c ts) (u z : Vec) (f : Vec → F) :
    lift i c ts (ExactQuadraticLift.pauli u z (unlift i c ts f))=
      fun y => phase (-i) ts u*ExactQuadraticLift.pauli (label c (u,z)).1 (label c (u,z)).2 f y := by
  funext y
  let x := c.inverse y
  have hy : c.forward x=y := c.inverse_right y
  have hp := phase_polar (-i) (neg_square i hi) ts x u
  have hinv := phase_inverse i hi ts x
  have hl : dot (label c (u,z)).2 y=(dot z x ^^ dot x (shear ts u)) := by rw [← hy,label_phase c ts hc]
  have ha : c.forward (add x u)=add y (c.forward u) := by rw [c.forward_add,hy]
  change phase i ts x*(QuadraticPhase.sign (dot z x)*(phase (-i) ts (add x u)*f (c.forward (add x u))))=
    phase (-i) ts u*(QuadraticPhase.sign (dot (label c (u,z)).2 y)*f (add y (c.forward u)))
  rw [hp,ha,hl,QuadraticPhase.sign_xor]
  grind

theorem pauli_scalar_fourth (i : F) (hi : i*i= -1) (ts : List Term) (u : Vec) :
    (phase (-i) ts u*phase (-i) ts u)*(phase (-i) ts u*phase (-i) ts u)=1 :=
  phase_fourth (-i) (neg_square i hi) ts u

theorem pauli_scalar_nonzero (i : F) (hi : i*i= -1) (ts : List Term) (u : Vec) : phase (-i) ts u≠0 :=
  phase_nonzero (-i) (neg_square i hi) ts u

end FourthRootLift
#print axioms FourthRootLift.inverse_left
#print axioms FourthRootLift.inverse_right
#print axioms FourthRootLift.lift_add
#print axioms FourthRootLift.lift_scale
#print axioms FourthRootLift.label_phase
#print axioms FourthRootLift.pauli_conjugation
#print axioms FourthRootLift.pauli_scalar_fourth
#print axioms FourthRootLift.pauli_scalar_nonzero
