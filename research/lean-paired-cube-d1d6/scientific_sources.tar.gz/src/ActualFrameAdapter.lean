import CommonExactFrame
namespace ActualFrameAdapter
open BinarySpace24 BinaryCompletion CompletionCertificates CompletionFrames ExactQuadraticLift CarrierRepresentative CommonExactFrame Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem unlift_add (c : Witness) (hc : Facts c) (f g : Vec → F) :
    unlift c hc (fun x => f x+g x)=fun x => unlift c hc f x+unlift c hc g x := by
  funext x
  simp only [unlift,Semiring.left_distrib]

theorem unlift_scale (c : Witness) (hc : Facts c) (s : F) (f : Vec → F) :
    unlift c hc (fun x => s*f x)=fun x => s*unlift c hc f x := by
  funext x
  simp only [unlift]
  grind

theorem coordinate_gate_add (i : F) (j : Index) (f g : Vec → F) :
    CoordinateChild.gate i j (fun x => f x+g x)=fun x => CoordinateChild.gate i j f x+CoordinateChild.gate i j g x := by
  funext x
  simp only [CoordinateChild.gate,InvolutionGate.gate]
  grind

theorem child_add (i : F) (f g : Vec → F) :
    FullCoordinateChild.child i (fun x => f x+g x)=fun x => FullCoordinateChild.child i f x+FullCoordinateChild.child i g x := by
  simp only [FullCoordinateChild.child,coordinate_gate_add]

theorem representative_add (i : F) (c : Witness) (hc : Facts c) (f g : Vec → F) :
    representative i c hc (fun x => f x+g x)=fun x => representative i c hc f x+representative i c hc g x := by
  simp only [representative,unlift_add,child_add,ExactQuadraticLift.lift_add]

theorem representative_scale (i : F) (c : Witness) (hc : Facts c) (s : F) (f : Vec → F) :
    representative i c hc (fun x => s*f x)=fun x => s*representative i c hc f x := by
  simp only [representative,unlift_scale,FullCoordinateChild.child_scale,ExactQuadraticLift.lift_scale]

def actualFrame (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (c : Witness) (hc : Facts c) : ExactFrame Vec F where
  encode := representative i c hc
  decode := inverseRepresentative i c hc
  left_inverse := CarrierRepresentative.inverse_left i hi htwo c hc
  right_inverse := CarrierRepresentative.inverse_right i hi htwo c hc
  add_linear := representative_add i c hc
  scale_linear := representative_scale i c hc

theorem actual_common_mix (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (c : Witness) (hc : Facts c)
    (a b : F) (f g : Vec → F) :
    mix a b (representative i c hc f) (representative i c hc g)=representative i c hc (mix a b f g) :=
  common_mix (actualFrame i hi htwo c hc) a b f g

theorem frame_ext (U V : Vec → Prop) (h : ∀ x, U x ↔ V x) (v : Vec × Vec) : Frame U v ↔ Frame V v := by
  simp only [Frame]
  constructor
  · intro ⟨hx,hz⟩
    exact ⟨(h _).mp hx,fun u hu => hz u ((h u).mpr hu)⟩
  · intro ⟨hx,hz⟩
    exact ⟨(h _).mpr hx,fun u hu => hz u ((h u).mp hu)⟩

theorem same_carrier_adapter_preserves_L0 (c d : Witness) (hc : Facts c) (hd : Facts d)
    (hcs : c.cube ∈ ActualInputCubes.cubes) (hds : d.cube ∈ ActualInputCubes.cubes)
    (hU : ∀ x, ActualCarrier c x ↔ ActualCarrier d x) (v : Vec × Vec) :
    (label d hd (label c hc v)).1=zero ↔ v.1=zero := by
  rw [frame_preimage d hd hds,← frame_ext (ActualCarrier c) (ActualCarrier d) hU,
    ← frame_preimage c hc hcs,label_involution]

end ActualFrameAdapter
#print axioms ActualFrameAdapter.unlift_add
#print axioms ActualFrameAdapter.unlift_scale
#print axioms ActualFrameAdapter.coordinate_gate_add
#print axioms ActualFrameAdapter.child_add
#print axioms ActualFrameAdapter.representative_add
#print axioms ActualFrameAdapter.representative_scale
#print axioms ActualFrameAdapter.actual_common_mix
#print axioms ActualFrameAdapter.frame_ext
#print axioms ActualFrameAdapter.same_carrier_adapter_preserves_L0
