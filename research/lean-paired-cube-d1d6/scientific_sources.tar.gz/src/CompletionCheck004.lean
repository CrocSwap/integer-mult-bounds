import CompletionData
namespace CompletionCheck004
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch004.all CompletionCertificates.check=true := by decide
end CompletionCheck004
#print axioms CompletionCheck004.valid
