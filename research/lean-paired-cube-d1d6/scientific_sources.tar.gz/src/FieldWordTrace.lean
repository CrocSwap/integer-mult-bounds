import FieldMaskSemantics
import TraceCertificates
namespace FieldWordTrace
open Lean.Grind PairedWord TraceTable DagSemantics
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

abbrev FState (F : Type u) := Nat → F

def increment (s : Step) (x : FState F) : F := if s.negative then -(x s.src) else x s.src
def forward (s : Step) (x : FState F) : FState F :=
  fun i => if i=s.dst then x s.dst + increment s x else x i

def run : List Step → FState F → FState F
  | [], x => x
  | s :: ss, x => run ss (forward s x)

def inject (x : FState F) : FState F :=
  fun role => if role%3=0 ∧ role/3<1760 then x (role/3) else 0

def localIdentity (value : Nat → F) (a : Annotation) : Prop :=
  value a.result = value a.oldDst +
    (if a.step.negative then -(value a.oldSrc) else value a.oldSrc)

theorem step_sound (depth : Nat) (t : Table Nat) (a : Annotation)
    (value : Nat → F) (state : FState F)
    (hc : stepCheck depth t a = true) (hl : localIdentity value a)
    (hs : ∀ i, i < 2^depth → value (get t i) = state i) :
    ∀ i, i < 2^depth →
      value (get (put depth t a.step.dst a.result) i) = forward a.step state i := by
  have hh : a.step.dst < 2^depth ∧ a.step.src < 2^depth ∧
      get t a.step.dst = a.oldDst ∧ get t a.step.src = a.oldSrc ∧
      a.result = a.step.node := of_decide_eq_true hc
  have hd : value a.oldDst = state a.step.dst := by
    rw [← hh.2.2.1]; exact hs _ hh.1
  have hr : value a.oldSrc = state a.step.src := by
    rw [← hh.2.2.2.1]; exact hs _ hh.2.1
  intro i hi
  rw [get_put depth t a.step.dst i a.result hh.1 hi]
  by_cases he : i = a.step.dst
  · subst i
    simp only [if_pos rfl, forward, increment]
    change value a.result = state a.step.dst + _
    simpa only [localIdentity, hd, hr] using hl
  · simp only [if_neg he, forward]
    exact hs i hi

theorem trace_sound (depth : Nat) (t : Table Nat) (as : List Annotation)
    (value : Nat → F) (state : FState F)
    (hc : traceCheck depth t as = true)
    (hl : ∀ a ∈ as, localIdentity value a)
    (hs : ∀ i, i < 2^depth → value (get t i) = state i) :
    ∀ i, i < 2^depth →
      value (get (replay depth t as) i) = run (as.map Annotation.step) state i := by
  induction as generalizing t state with
  | nil => exact hs
  | cons a rest ih =>
    have hh := Bool.and_eq_true_iff.mp hc
    have hstep := step_sound depth t a value state hh.1 (hl a (by simp)) hs
    exact ih (put depth t a.step.dst a.result) (forward a.step state) hh.2
      (fun b hb => hl b (by simp [hb])) hstep

theorem compatible_sound (node : Nat → Spec) (value : Nat → F) (a : Annotation)
    (hz : value 0 = 0)
    (ha : ∀ n l r negative, node n = .add l r negative →
      value n = value l + if negative then -(value r) else value r)
    (hc : compatible node a = true) : localIdentity value a := by
  rcases Bool.or_eq_true_iff.mp hc with hcopy | hadd
  · have hh : a.oldDst=0 ∧ a.oldSrc=a.result ∧ a.step.negative=false := of_decide_eq_true hcopy
    simp only [localIdentity, hh.1, hh.2.1, hh.2.2, Bool.false_eq_true, ↓reduceIte, hz, Semiring.zero_add]
  · cases hn : node a.result with
    | zero => simp [hn] at hadd
    | input i => simp [hn] at hadd
    | add l r negative =>
      simp only [hn] at hadd
      have hv := ha a.result l r negative hn
      rcases Bool.or_eq_true_iff.mp hadd with hd | hs
      · have hh : a.oldDst=l ∧ a.oldSrc=r ∧ a.step.negative=negative := of_decide_eq_true hd
        simpa only [localIdentity, hh.1, hh.2.1, hh.2.2] using hv
      · have hh : a.oldDst=r ∧ a.oldSrc=l ∧ a.step.negative=false ∧ negative=false := of_decide_eq_true hs
        simp only [localIdentity, hh.1, hh.2.1, hh.2.2.1, Bool.false_eq_true, ↓reduceIte]
        simp only [hh.2.2.2, Bool.false_eq_true, ↓reduceIte] at hv
        exact hv.trans (Semiring.add_comm _ _)

theorem initial_sound (depth : Nat) (t : Table Nat) (value : Nat → F) (payload : FState F)
    (hz : value 0=0) (hin : ∀ i, i<1760 → value (i+1)=payload i)
    (hc : initialCheck depth t=true) :
    ∀ i, i<2^depth → value (get t i)=inject payload i := by
  intro i hib
  have ht : get t i=sourceIndex i := of_decide_eq_true ((List.all_eq_true.mp hc) i (List.mem_range.mpr hib))
  rw [ht]
  by_cases hs : i%3=0 ∧ i/3<1760
  · simpa only [sourceIndex, inject, if_pos hs] using hin (i/3) hs.2
  · simpa only [sourceIndex, inject, if_neg hs] using hz

end FieldWordTrace
#print axioms FieldWordTrace.step_sound
#print axioms FieldWordTrace.trace_sound
#print axioms FieldWordTrace.compatible_sound
#print axioms FieldWordTrace.initial_sound
