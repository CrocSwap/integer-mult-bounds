import ActualRootLastTouch
import RootLifecycleTrace
import RootUseCatalog
namespace ActualRootLifecycle
open RootLifecycleTrace
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def afterRoots (n : Nat) (g : State) : State :=
  run (RootUseCatalog.uses.take n) (GaugeKeyTrace.run PairedWordData.word g)

theorem first_three : RootUseCatalog.uses.take 3=[(20436,1761),(17262,15668),(17230,15650)] := rfl

theorem first_four : RootUseCatalog.uses.take 4=[(20436,1761),(17262,15668),(17230,15650),(17326,17401)] := rfl

theorem preceding_roles_distinct : (RootUseCatalog.uses.take 3).all (fun p => decide (17326≠p.1))=true := by
  rw [first_three]
  decide

theorem before_root_index3 (g : State) : afterRoots 3 g 17326=15704 := by
  unfold afterRoots
  rw [projection_preserved _ _ _ preceding_roles_distinct]
  exact ActualRootLastTouch.after_M g

theorem after_root_index3 (g : State) : afterRoots 4 g 17326=17401 := by
  unfold afterRoots
  rw [first_four]
  rfl

theorem actual_transition (g : State) :
    afterRoots 3 g 17326=15704 ∧ RootUseCatalog.uses[3]?=some (17326,17401) ∧ afterRoots 4 g 17326=17401 :=
  ⟨before_root_index3 g,RootUseCatalog.first_new_root,after_root_index3 g⟩

end ActualRootLifecycle
#print axioms ActualRootLifecycle.first_three
#print axioms ActualRootLifecycle.first_four
#print axioms ActualRootLifecycle.preceding_roles_distinct
#print axioms ActualRootLifecycle.before_root_index3
#print axioms ActualRootLifecycle.after_root_index3
#print axioms ActualRootLifecycle.actual_transition
