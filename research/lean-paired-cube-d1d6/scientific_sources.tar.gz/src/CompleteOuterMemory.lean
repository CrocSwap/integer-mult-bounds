import WeightedMemoryComposition
namespace CompleteOuterMemory
open BinarySpace24 SuppliedQuarterTable Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

structure Cost where
  loads : Nat
  stores : Nat
  addressControlReads : Nat
  valueSelections : Nat
  payloadMultiplications : Nat
  extraRegisterMoves : Nat
  addressScalarOperations : Nat
  phase : QuarterPhaseCompiler.Cost
  deriving DecidableEq

def combine (a : CompleteOuterAddressProgram.Cost) (p : PointPhaseMachine.Cost) : Cost :=
  ⟨a.loads+p.loads,a.stores+p.stores,a.controlReads,a.valueSelections+p.selections,
    p.multiplications,a.extraRegisterMoves,a.scalarOperations,p.phase⟩

def left (t : Table F) (s : PairLoadStoreMachine.State Vec F) :=
  MemoryStageComposition.compose CompleteOuterAddressProgram.left (ActualPointPhase.left t) combine s

def right (t : Table F) (s : PairLoadStoreMachine.State Vec F) :=
  MemoryStageComposition.compose CompleteOuterAddressProgram.right (ActualPointPhase.right t) combine s

def leftReceipt := combine ⟨218103808,218103808,41943040,83886080,0,0⟩
  (PointPhaseMachine.scaleCost 16777216 ActualPointPhase.leftPointCost)
def rightReceipt := combine ⟨218103808,218103808,41943040,83886080,0,0⟩
  (PointPhaseMachine.scaleCost 16777216 ActualPointPhase.rightPointCost)

theorem left_memory (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (s : PairLoadStoreMachine.State Vec F) :
    (left t s).1.memory=ActualQuarterPhase.leftPass i s.memory := by
  have h:=WeightedMemoryComposition.memory CompleteOuterAddressProgram.left (ActualPointPhase.left t) combine
    (RootAddressInstructions.run OuterAddressCircuits.leftCode) (LeftPassAddressPhase.scalar i)
    CompleteOuterAddressProgram.left_memory (ActualPointPhase.left_memory i hi t ht) s
  rw [ActualQuarterPhase.exact_left i hi]
  exact h

theorem right_memory (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (s : PairLoadStoreMachine.State Vec F) :
    (right t s).1.memory=ActualQuarterPhase.rightPass i s.memory := by
  have h:=WeightedMemoryComposition.memory CompleteOuterAddressProgram.right (ActualPointPhase.right t) combine
    (RootAddressInstructions.run OuterAddressCircuits.rightCode) (RightPassAddressPhase.scalar i)
    CompleteOuterAddressProgram.right_memory (ActualPointPhase.right_memory i hi t ht) s
  rw [ActualQuarterPhase.exact_right i hi]
  exact h

theorem left_receipt (t : Table F) (s : PairLoadStoreMachine.State Vec F) : (left t s).2=leftReceipt :=
  MemoryStageComposition.cost CompleteOuterAddressProgram.left (ActualPointPhase.left t) combine _ _
    CompleteOuterAddressProgram.left_receipt (ActualPointPhase.left_cost t) s

theorem right_receipt (t : Table F) (s : PairLoadStoreMachine.State Vec F) : (right t s).2=rightReceipt :=
  MemoryStageComposition.cost CompleteOuterAddressProgram.right (ActualPointPhase.right t) combine _ _
    CompleteOuterAddressProgram.right_receipt (ActualPointPhase.right_cost t) s

theorem left_formula : leftReceipt=⟨14*2^24,14*2^24,5*2^23,7*2^24,2^24,0,0,
    ⟨51*2^24,151*2^24,51*2^24,2^24,51*2^24,50*2^24⟩⟩ := rfl

theorem right_formula : rightReceipt=⟨14*2^24,14*2^24,5*2^23,7*2^24,2^24,0,0,
    ⟨48*2^24,147*2^24,49*2^24,0,50*2^24,49*2^24⟩⟩ := rfl

theorem selected_left (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (t : Table F) (ht : t=canonical i)
    (s : PairLoadStoreMachine.State Vec F) : (left t s).1.memory=RootOneChildPass.leftPass i hi htwo s.memory := by
  rw [left_memory i hi t ht,ActualQuarterPhase.exact_left i hi,OuterAddressCircuits.exact_left,
    LeftPassAddressPhase.exact_program i hi htwo]

theorem selected_right (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (t : Table F) (ht : t=canonical i)
    (s : PairLoadStoreMachine.State Vec F) : (right t s).1.memory=RootOneChildPass.rightPass i hi htwo s.memory := by
  rw [right_memory i hi t ht,ActualQuarterPhase.exact_right i hi,OuterAddressCircuits.exact_right,
    RightPassAddressPhase.exact_program i hi htwo]

theorem summed_payload_memory : leftReceipt.loads+rightReceipt.loads=469762048 ∧
    leftReceipt.stores+rightReceipt.stores=469762048 ∧
    leftReceipt.payloadMultiplications+rightReceipt.payloadMultiplications=33554432 := by decide

theorem summed_phase_evaluation :
    leftReceipt.phase.bitReads+rightReceipt.phase.bitReads=99*2^24 ∧
    leftReceipt.phase.booleanXors+rightReceipt.phase.booleanXors=298*2^24 ∧
    leftReceipt.phase.booleanAnds+rightReceipt.phase.booleanAnds=100*2^24 ∧
    leftReceipt.phase.booleanNots+rightReceipt.phase.booleanNots=2^24 ∧
    leftReceipt.phase.exponentConstructions+rightReceipt.phase.exponentConstructions=101*2^24 ∧
    leftReceipt.phase.exponentAdditions+rightReceipt.phase.exponentAdditions=99*2^24 := by decide

end CompleteOuterMemory
#print axioms CompleteOuterMemory.left_memory
#print axioms CompleteOuterMemory.right_memory
#print axioms CompleteOuterMemory.left_receipt
#print axioms CompleteOuterMemory.right_receipt
#print axioms CompleteOuterMemory.left_formula
#print axioms CompleteOuterMemory.right_formula
#print axioms CompleteOuterMemory.selected_left
#print axioms CompleteOuterMemory.selected_right
#print axioms CompleteOuterMemory.summed_payload_memory
#print axioms CompleteOuterMemory.summed_phase_evaluation
