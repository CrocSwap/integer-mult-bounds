import LocalPhaseCancellation
namespace CXLiftFormula
open BinarySpace24 FourthRootRecipe CanonicalGramRecipe CanonicalFourthRootLift ChartComposition Q21AddressProgram CoordinateChild Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def localPhase (i : F) (c t : Index) (x : Vec) : F :=
  rootPhase i (x t)*rootPhase (-i) (x t ^^ x c)
def localLift (i : F) (c t : Index) (f : Vec → F) (x : Vec) : F :=
  localPhase i c t x*f (execute ⟨c,t⟩ x)

theorem exact_local (i : F) (hi : i*i= -1) (c t : Index) (h : c≠t) (f : Vec → F) :
    K i (cx c t h) f=localLift i c t f := by
  rw [exact_S_permutation_S_inverse]
  funext x
  simp only [S,CanonicalFourthRootLift.permutation,cx_inverse_address,← Semiring.mul_assoc]
  have he := LocalPhaseCancellation.coordinate_single_ratio i hi t x (execute ⟨c,t⟩ x)
    (fun j hj => (execute_other ⟨c,t⟩ j (Ne.symm hj) x).symm)
  rw [he,execute_target]
  rfl

theorem flip_commute (c t : Index) (x : Vec) : flip c (flip t x)=flip t (flip c x) := by
  funext j
  simp only [CoordinateChild.flip,add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem flip_here (c : Index) (x : Vec) : flip c x c= !x c := by
  simp only [CoordinateChild.flip,add,unit,decide_true,Bool.xor_true]

theorem flip_other (c j : Index) (h : c≠j) (x : Vec) : flip c x j=x j := by
  simp only [CoordinateChild.flip,add,unit,h,decide_false,Bool.xor_false]

theorem execute_flip_control (c t : Index) (h : c≠t) (x : Vec) :
    execute ⟨c,t⟩ (flip c x)=flip c (flip t (execute ⟨c,t⟩ x)) := by
  funext j
  by_cases hc : c=j <;> by_cases ht : t=j <;>
    simp_all [eq_comm,execute,CoordinateChild.flip,add,scale,unit,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem execute_flip_target (c t : Index) (h : c≠t) (x : Vec) :
    execute ⟨c,t⟩ (flip t x)=flip t (execute ⟨c,t⟩ x) := by
  funext j
  by_cases hc : c=j <;> by_cases ht : t=j <;>
    simp_all [eq_comm,execute,CoordinateChild.flip,add,scale,unit,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

end CXLiftFormula
#print axioms CXLiftFormula.exact_local
#print axioms CXLiftFormula.flip_commute
#print axioms CXLiftFormula.flip_here
#print axioms CXLiftFormula.flip_other
#print axioms CXLiftFormula.execute_flip_control
#print axioms CXLiftFormula.execute_flip_target
