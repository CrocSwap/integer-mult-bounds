import CompletionData
namespace CompletionCheck010
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch010.all CompletionCertificates.check=true := by decide
end CompletionCheck010
#print axioms CompletionCheck010.valid
