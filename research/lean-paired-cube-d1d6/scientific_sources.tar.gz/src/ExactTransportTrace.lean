import GaugeKeyTrace
namespace ExactTransportTrace
open PairedWord (Step)
open CommonExactFrame Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {X : Type u} {F : Type v} [Field F]
abbrev Arrays (X : Type u) (F : Type v) := Nat → X → F

def prepared (select : Nat → ExactFrame X F) (s : Step) (g : GaugeKeyTrace.State)
    (v : Arrays X F) (r : Nat) : X → F :=
  if GaugeKeyTrace.touches r s then adapter (select (g r)) (select (ActualFrameKeys.key s)) (v r) else v r

def step (select : Nat → ExactFrame X F) (s : Step) (g : GaugeKeyTrace.State)
    (v : Arrays X F) : Arrays X F := fun r =>
  if r=s.dst then fun x => prepared select s g v s.dst x+
    (if s.negative then -(prepared select s g v s.src x) else prepared select s g v s.src x)
  else prepared select s g v r

def run (select : Nat → ExactFrame X F) : List Step → GaugeKeyTrace.State → Arrays X F → GaugeKeyTrace.State × Arrays X F
  | [],g,v => (g,v)
  | s::ss,g,v => run select ss (GaugeKeyTrace.update s g) (step select s g v)

def stable (r k : Nat) (s : Step) : Bool := GaugeKeyTrace.preserves r k s && decide (s.dst≠r)

theorem prepared_unchanged (select : Nat → ExactFrame X F) (r k : Nat) (s : Step)
    (h : GaugeKeyTrace.preserves r k s=true) (g : GaugeKeyTrace.State) (hg : g r=k) (v : Arrays X F) :
    prepared select s g v r=v r := by
  unfold prepared
  cases ht : GaugeKeyTrace.touches r s
  · simp only [ht,Bool.false_eq_true,if_false]
  · have hk : ActualFrameKeys.key s=k := by
      unfold GaugeKeyTrace.preserves at h
      simp only [ht,if_true] at h
      exact of_decide_eq_true h
    simp only [ht,if_true,hg,hk,adapter_identity]

theorem step_unchanged (select : Nat → ExactFrame X F) (r k : Nat) (s : Step)
    (h : stable r k s=true) (g : GaugeKeyTrace.State) (hg : g r=k) (v : Arrays X F) :
    step select s g v r=v r := by
  have hh := Bool.and_eq_true_iff.mp h
  have hd : s.dst≠r := of_decide_eq_true hh.2
  rw [step,if_neg (Ne.symm hd),prepared_unchanged select r k s hh.1 g hg]

theorem key_projection (select : Nat → ExactFrame X F) (ss : List Step) (g : GaugeKeyTrace.State) (v : Arrays X F) :
    (run select ss g v).1=GaugeKeyTrace.run ss g := by
  induction ss generalizing g v with
  | nil => rfl
  | cons s ss ih => exact ih _ _

theorem projection_unchanged (select : Nat → ExactFrame X F) (r k : Nat) (ss : List Step)
    (h : ss.all (stable r k)=true) (g : GaugeKeyTrace.State) (hg : g r=k) (v : Arrays X F) :
    (run select ss g v).1 r=k ∧ (run select ss g v).2 r=v r := by
  induction ss generalizing g v with
  | nil => exact ⟨hg,rfl⟩
  | cons s ss ih =>
    have hh := Bool.and_eq_true_iff.mp h
    have hstep := Bool.and_eq_true_iff.mp hh.1
    have hg' := GaugeKeyTrace.update_preserves r k s hstep.1 g hg
    have hv' := step_unchanged select r k s hh.1 g hg v
    have hout := ih hh.2 (GaugeKeyTrace.update s g) hg' (step select s g v)
    exact ⟨hout.1,hout.2.trans hv'⟩

theorem run_append (select : Nat → ExactFrame X F) (as bs : List Step) (g : GaugeKeyTrace.State) (v : Arrays X F) :
    run select (as++bs) g v=run select bs (run select as g v).1 (run select as g v).2 := by
  induction as generalizing g v with
  | nil => rfl
  | cons s ss ih => exact ih _ _

end ExactTransportTrace
#print axioms ExactTransportTrace.prepared_unchanged
#print axioms ExactTransportTrace.step_unchanged
#print axioms ExactTransportTrace.key_projection
#print axioms ExactTransportTrace.projection_unchanged
#print axioms ExactTransportTrace.run_append
