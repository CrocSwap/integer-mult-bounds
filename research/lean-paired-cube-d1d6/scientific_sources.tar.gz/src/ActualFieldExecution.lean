import FieldWordTrace
import ActualFieldNormalization
import FullTraceComposition
namespace ActualFieldExecution
open Lean.Grind PairedWord PairedWordData PairedDecoder TraceTable DagSemantics FullTraceData
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

def nodeValue (payload : Nat → F) : Nat → F :=
  FieldMaskSemantics.value 1760 FullModelData.rows payload

theorem node_zero (payload : Nat → F) : nodeValue payload 0=0 :=
  FieldMaskSemantics.value_zero 1760 graph.node FullModelData.rows payload
    FullModelData.all_row_checks 0 graph_zero

theorem node_source (payload : Nat → F) (i : Nat) (hi : i<1760) :
    nodeValue payload (i+1)=payload i := by
  have hn : graph.node (i+1)=.input i := of_decide_eq_true
    ((List.all_eq_true.mp graph_sources) i (List.mem_range.mpr hi))
  exact FieldMaskSemantics.value_input 1760 graph.node FullModelData.rows payload
    FullModelData.all_row_checks (i+1) i hn

theorem initial_matches (payload : Nat → F) : ∀ role, role<2^15 →
    nodeValue payload (TraceTable.get checkpoint000 role) = FieldWordTrace.inject payload role :=
  FieldWordTrace.initial_sound 15 checkpoint000 (nodeValue payload) payload
    (node_zero payload) (node_source payload) FullInitialization.initial_valid

theorem actual_word_matches (payload : Nat → F) : ∀ role, role<2^15 →
    nodeValue payload (TraceTable.get checkpoint194 role) =
      FieldWordTrace.run word (FieldWordTrace.inject payload) role := by
  have hs := FieldWordTrace.trace_sound 15 checkpoint000 FullTraceComposition.suffix000
    (nodeValue payload) (FieldWordTrace.inject payload) FullTraceComposition.certified000.traced
    (fun a ha => FieldWordTrace.compatible_sound graph.node (nodeValue payload) a (node_zero payload)
      (FieldMaskSemantics.value_add 1760 graph.node FullModelData.rows payload FullModelData.all_row_checks)
      ((List.all_eq_true.mp FullTraceComposition.certified000.compatible) a ha))
    (initial_matches payload)
  rw [FullTraceComposition.certified000.replayed, FullTraceComposition.all_word_linked] at hs
  exact hs

def decoderResponse (target : Nat) (state : Nat → F) : F :=
  FieldLinearEvaluation.readout (FullTargetPacking.readout target) state

def correctionResponse (target : Nat) (payload : Nat → F) : F :=
  FieldLinearEvaluation.readout (CubeCorrection.terms target) (fun sourceNode => payload (sourceNode-1))

theorem decoder_matches (target : Nat) (ht : target<1760) (payload : Nat → F) :
    decoderResponse target (FieldWordTrace.run word (FieldWordTrace.inject payload)) =
      FieldLinearEvaluation.readout (FullTargetPacking.readout target)
        (fun role => nodeValue payload (FullTargetPacking.roleNode role)) := by
  apply FieldLinearEvaluation.readout_congr
  intro term hterm
  have hi : target<ActualDecoder.rows.length := by rw [ActualDecoder.target_count]; exact ht
  have hm : FullTargetPacking.readout target ∈ ActualDecoder.rows := by
    unfold FullTargetPacking.readout
    rw [List.getElem?_eq_getElem hi]
    exact List.getElem_mem hi
  have hb := ((ActualDecoder.every_row_valid _ hm).2 term hterm).1
  exact (actual_word_matches payload term.role (by omega)).symm

theorem correction_matches (target : Nat) (ht : target<1760) (payload : Nat → F) :
    FieldLinearEvaluation.readout (CubeCorrection.terms target) (nodeValue payload) =
      correctionResponse target payload := by
  apply FieldLinearEvaluation.readout_congr
  intro term hterm
  have hb := CubeCorrection.correction_sources target ht term hterm
  have hi : term.role-1<1760 := by omega
  have he : (term.role-1)+1=term.role := by omega
  simpa only [he] using node_source payload (term.role-1) hi

theorem coefficient_response_is_execution (target : Nat) (ht : target<1760) (payload : Nat → F) :
    ActualFieldNormalization.combinedResponse target payload =
      decoderResponse target (FieldWordTrace.run word (FieldWordTrace.inject payload)) +
        correctionResponse target payload := by
  unfold ActualFieldNormalization.combinedResponse ActualFieldNormalization.combinedCoefficients
  rw [FieldLinearEvaluation.evaluate_vector, FieldLinearEvaluation.readout_append, FieldLinearEvaluation.readout_remap]
  rw [decoder_matches target ht payload]
  change _ + FieldLinearEvaluation.readout (CubeCorrection.terms target) (nodeValue payload) = _
  rw [correction_matches target ht payload]
  rfl

theorem actual_scaled_execution (target : Nat) (ht : target<1760) (payload : Nat → F) :
    decoderResponse target (FieldWordTrace.run word (FieldWordTrace.inject payload)) +
      correctionResponse target payload = (6:F)*payload target := by
  rw [← coefficient_response_is_execution target ht payload]
  exact ActualFieldNormalization.actual_scaled_response target ht payload

theorem actual_normalized_execution (target : Nat) (ht : target<1760) (payload : Nat → F)
    (hsix : (6:F) ≠ 0) :
    decoderResponse target (FieldWordTrace.run word (FieldWordTrace.inject payload))/6 +
      correctionResponse target payload/6 = payload target := by
  have he := ActualFieldNormalization.actual_normalized_response target ht payload hsix
  rw [coefficient_response_is_execution target ht payload] at he
  simpa only [Field.div_eq_mul_inv, Semiring.right_distrib] using he

end ActualFieldExecution
#print axioms ActualFieldExecution.node_zero
#print axioms ActualFieldExecution.node_source
#print axioms ActualFieldExecution.initial_matches
#print axioms ActualFieldExecution.actual_word_matches
#print axioms ActualFieldExecution.decoder_matches
#print axioms ActualFieldExecution.correction_matches
#print axioms ActualFieldExecution.coefficient_response_is_execution
#print axioms ActualFieldExecution.actual_scaled_execution
#print axioms ActualFieldExecution.actual_normalized_execution
