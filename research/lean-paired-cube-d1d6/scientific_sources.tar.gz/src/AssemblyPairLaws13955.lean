import AssemblyExpressions13955
namespace PairedCubeAssembly13955

/-! The arithmetic definitions are explicit fraction cross products. These
lemmas expose their generic denominator side conditions without treating Pair
as a normalized rational field. -/

theorem add_integer_formula (x y : Pair) :
    (x+y).num=x.num*y.den+y.num*x.den ∧ (x+y).den=x.den*y.den := by
  exact ⟨rfl,rfl⟩

theorem sub_integer_formula (x y : Pair) :
    (x-y).num=x.num*y.den-y.num*x.den ∧ (x-y).den=x.den*y.den := by
  exact ⟨rfl,rfl⟩

theorem mul_integer_formula (x y : Pair) :
    (x*y).num=x.num*y.num ∧ (x*y).den=x.den*y.den := by
  exact ⟨rfl,rfl⟩

theorem div_integer_formula (x y : Pair) :
    (x/y).num=x.num*y.den ∧ (x/y).den=x.den*y.num := by
  exact ⟨rfl,rfl⟩

theorem add_den_positive (x y : Pair) (hx : 0<x.den) (hy : 0<y.den) :
    0 < (x+y).den := by
  exact Int.mul_pos hx hy

theorem sub_den_positive (x y : Pair) (hx : 0<x.den) (hy : 0<y.den) :
    0 < (x-y).den := by
  exact Int.mul_pos hx hy

theorem mul_den_positive (x y : Pair) (hx : 0<x.den) (hy : 0<y.den) :
    0 < (x*y).den := by
  exact Int.mul_pos hx hy

theorem div_den_positive (x y : Pair) (hx : 0<x.den) (hy : 0<y.num) :
    0 < (x/y).den := by
  exact Int.mul_pos hx hy

theorem min_left (x y : Pair) (h : x.num*y.den ≤ y.num*x.den) :
    pairMin x y = x := by
  simp only [pairMin,if_pos h]

theorem min_right (x y : Pair) (h : ¬ x.num*y.den ≤ y.num*x.den) :
    pairMin x y = y := by
  simp only [pairMin,if_neg h]

theorem max_left (x y : Pair) (h : ¬ x.num*y.den ≤ y.num*x.den) :
    pairMax x y = x := by
  simp only [pairMax,if_neg h]

theorem max_right (x y : Pair) (h : x.num*y.den ≤ y.num*x.den) :
    pairMax x y = y := by
  simp only [pairMax,if_pos h]

end PairedCubeAssembly13955
#print axioms PairedCubeAssembly13955.add_integer_formula
#print axioms PairedCubeAssembly13955.sub_integer_formula
#print axioms PairedCubeAssembly13955.mul_integer_formula
#print axioms PairedCubeAssembly13955.div_integer_formula
#print axioms PairedCubeAssembly13955.add_den_positive
#print axioms PairedCubeAssembly13955.sub_den_positive
#print axioms PairedCubeAssembly13955.mul_den_positive
#print axioms PairedCubeAssembly13955.div_den_positive
#print axioms PairedCubeAssembly13955.min_left
#print axioms PairedCubeAssembly13955.min_right
#print axioms PairedCubeAssembly13955.max_left
#print axioms PairedCubeAssembly13955.max_right
