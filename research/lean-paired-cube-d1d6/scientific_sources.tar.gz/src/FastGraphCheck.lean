import DagSemantics
namespace DagSemantics
open TraceTable

def treeGraphCheck (base stride : Nat) : Table Spec → Bool
  | .leaf (.add l r _) => decide (l < base ∧ r < base)
  | .leaf _ => true
  | .fork left right =>
      treeGraphCheck base (2*stride) left && treeGraphCheck (base+stride) (2*stride) right

theorem stride_decompose (stride index : Nat) :
    stride*index = stride*(index%2) + (2*stride)*(index/2) := by
  calc
    stride*index = stride*(index%2 + 2*(index/2)) := congrArg (fun x => stride*x) (Nat.mod_add_div index 2).symm
    _ = _ := by simp [Nat.mul_add, Nat.mul_assoc, Nat.mul_comm, Nat.mul_left_comm]

theorem treeGraphCheck_sound (t : Table Spec) (base stride : Nat)
    (h : treeGraphCheck base stride t = true) :
    ∀ index l r neg, TraceTable.get t index = .add l r neg →
      l < base+stride*index ∧ r < base+stride*index := by
  induction t generalizing base stride with
  | leaf spec =>
    intro index l r neg hn
    simp only [TraceTable.get] at hn
    subst spec
    have hh : l < base ∧ r < base := of_decide_eq_true h
    constructor <;> omega
  | fork left right ihl ihr =>
    intro index l r neg hn
    have hh := Bool.and_eq_true_iff.mp h
    by_cases he : index%2=0
    · have hn' : TraceTable.get left (index/2) = .add l r neg := by simpa [TraceTable.get, he] using hn
      have ht := ihl base (2*stride) hh.1 (index/2) l r neg hn'
      have hd : stride*index = (2*stride)*(index/2) := by simpa [he] using stride_decompose stride index
      simpa [hd] using ht
    · have hm : index%2=1 := by omega
      have hn' : TraceTable.get right (index/2) = .add l r neg := by simpa [TraceTable.get, he] using hn
      have ht := ihr (base+stride) (2*stride) hh.2 (index/2) l r neg hn'
      have hd : stride*index = stride + (2*stride)*(index/2) := by simpa [hm] using stride_decompose stride index
      simpa [hd, Nat.add_assoc] using ht

def fastCheckedGraph (size : Nat) (t : Table Spec) (h : treeGraphCheck 0 1 t = true) : Graph where
  node := tableNode size t
  topological := by
    intro n l r neg hn
    by_cases hns : n < size
    · have hg : TraceTable.get t n = .add l r neg := by simpa [tableNode, hns] using hn
      simpa using treeGraphCheck_sound t 0 1 h n l r neg hg
    · simp [tableNode, hns] at hn

end DagSemantics
#print axioms DagSemantics.stride_decompose
#print axioms DagSemantics.treeGraphCheck_sound
