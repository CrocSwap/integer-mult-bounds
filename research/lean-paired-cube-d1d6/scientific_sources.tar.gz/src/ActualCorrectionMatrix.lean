import ActualInputCubes
namespace ActualCorrectionMatrix
open PairedWord PairedDecoder CubeCorrection CubeGeometry

theorem sparse_dense (js : List Nat) (c : Nat → Int) (offset : Nat) (payload : State) :
    PairedDecoder.evaluate
      ((js.filterMap (fun j => if c j = 0 then none else some (⟨j+1,3*c j⟩ : ReadTerm))).map (shift offset))
      (fun n => payload (n-1)) =
    (js.map (fun j => 3*c j*payload (offset+j))).sum := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    by_cases h : c j = 0
    · simp [List.filterMap_cons, h, ih]
    · simp [List.filterMap_cons, h, PairedDecoder.evaluate, shift, ih, Nat.add_assoc]

def canonicalResponse (target : Nat) (payload : State) : Int :=
  ((List.range 8).map (fun j => 3*PairedCubeIdentities.k2 (target%8) j *
    payload (8*(target/8)+j))).sum

def actualInputResponse (target : Nat) (payload : State) : Int :=
  ((List.range 8).map (fun j => 3*inputK2 (ActualInputCubes.cubes[target/8]?.getD []) (target%8) j *
    payload (8*(target/8)+j))).sum

theorem correction_is_canonical (target : Nat) (payload : State) :
    CubeCorrection.response target payload = canonicalResponse target payload :=
  sparse_dense (List.range 8) (PairedCubeIdentities.k2 (target%8)) (8*(target/8)) payload

theorem correction_is_actual_input_matrix (target : Nat) (ht : target<1760) (payload : State) :
    CubeCorrection.response target payload = actualInputResponse target payload := by
  rw [correction_is_canonical]
  unfold canonicalResponse actualInputResponse
  apply congrArg List.sum
  apply List.map_congr_left
  intro j hj
  have hj8 : j<8 := List.mem_range.mp hj
  have hc : target/8<ActualInputCubes.cubes.length := by rw [ActualInputCubes.cube_count]; omega
  have hm : ActualInputCubes.cubes[target/8]?.getD [] ∈ ActualInputCubes.cubes := by
    rw [List.getElem?_eq_getElem hc]
    exact List.getElem_mem hc
  have he := ActualInputCubes.actual_matrices _ hm ⟨target%8, by omega⟩ ⟨j,hj8⟩
  rw [he]

end ActualCorrectionMatrix
#print axioms ActualCorrectionMatrix.sparse_dense
#print axioms ActualCorrectionMatrix.correction_is_canonical
#print axioms ActualCorrectionMatrix.correction_is_actual_input_matrix
