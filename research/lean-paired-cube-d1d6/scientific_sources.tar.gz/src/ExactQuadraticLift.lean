import GramQuadratic
namespace ExactQuadraticLift
open BinarySpace24 BinaryCompletion CompletionCertificates CompletionFrames GramQuadratic Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def pauli (u z : Vec) (f : Vec → F) (x : Vec) : F := QuadraticPhase.sign (dot z x)*f (add x u)
def lift (c : Witness) (hc : Facts c) (f : Vec → F) (y : Vec) : F :=
  QuadraticPhase.sign (quadratic c hc (fullInverse c hc y))*f (fullInverse c hc y)
def unlift (c : Witness) (hc : Facts c) (f : Vec → F) (x : Vec) : F :=
  QuadraticPhase.sign (quadratic c hc x)*f (fullMap c hc x)

theorem inverse_left (c : Witness) (hc : Facts c) (f : Vec → F) : unlift c hc (lift c hc f)=f := by
  funext x
  simp only [unlift,lift,full_inverse_left,← Semiring.mul_assoc,QuadraticPhase.sign_square,Semiring.one_mul]

theorem inverse_right (c : Witness) (hc : Facts c) (f : Vec → F) : lift c hc (unlift c hc f)=f := by
  funext y
  simp only [unlift,lift,full_inverse_right,← Semiring.mul_assoc,QuadraticPhase.sign_square,Semiring.one_mul]

theorem lift_add (c : Witness) (hc : Facts c) (f g : Vec → F) :
    lift c hc (fun x => f x+g x)=fun y => lift c hc f y+lift c hc g y := by
  funext y
  simp only [lift,Semiring.left_distrib]

theorem lift_scale (c : Witness) (hc : Facts c) (s : F) (f : Vec → F) :
    lift c hc (fun x => s*f x)=fun y => s*lift c hc f y := by
  funext y
  simp only [lift]
  grind

theorem label_phase (c : Witness) (hc : Facts c) (u z x : Vec) :
    dot (blockMap c hc (u,z)).2 (fullMap c hc x)=
      (dot z x ^^ (dot (fullMap c hc x) (fullMap c hc u) ^^ dot x u)) := by
  change dot (add (fullMap c hc u) (inverseTranspose c hc (add u z))) (fullMap c hc x)=_
  rw [dot_add_left,dot_symmetric (fullMap c hc u),dot_symmetric (inverseTranspose c hc _)]
  have hp : dot (fullMap c hc x) (inverseTranspose c hc (add u z))=dot x (add u z) :=
    BinaryCompletion.inverse_transpose_pairing (permutation c hc) (pivot c) (residual c) (residual_vanish c hc) x (add u z)
  rw [hp]
  rw [dot_add,dot_symmetric x z]
  simp only [Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem pauli_conjugation (c : Witness) (hc : Facts c) (hs : c.cube ∈ ActualInputCubes.cubes)
    (u z : Vec) (f : Vec → F) :
    lift c hc (pauli u z (unlift c hc f))=
      fun y => QuadraticPhase.sign (quadratic c hc u)*
        pauli (blockMap c hc (u,z)).1 (blockMap c hc (u,z)).2 f y := by
  funext y
  let x := fullInverse c hc y
  have hy : fullMap c hc x=y := full_inverse_right c hc y
  have hl : dot (blockMap c hc (u,z)).2 y=
      (dot z x ^^ (dot (fullMap c hc x) (fullMap c hc u) ^^ dot x u)) := by
    rw [← hy,label_phase]
  have harg : fullMap c hc (add x u)=add y (fullMap c hc u) := by
    rw [full_map_add,hy]
  have hsq := QuadraticPhase.sign_square (F:=F) (quadratic c hc x)
  change QuadraticPhase.sign (quadratic c hc x)*
    (QuadraticPhase.sign (dot z x)*(QuadraticPhase.sign (quadratic c hc (add x u))*f (fullMap c hc (add x u))))=
    QuadraticPhase.sign (quadratic c hc u)*
      (QuadraticPhase.sign (dot (blockMap c hc (u,z)).2 y)*f (add y (fullMap c hc u)))
  rw [harg,hl,full_polar c hc hs]
  simp only [QuadraticPhase.sign_xor]
  grind

theorem lift_on_actual_carrier (c : Witness) (hc : Facts c) (bits : CarrierCoordinates.Coordinates) (f : Vec → F) :
    lift c hc f (fromNat (ActualCarrierCharts.encode c.cube c.parity bits))=
      QuadraticPhase.sign (QuadraticPhase.quadratic bits)*f (coordinates bits) := by
  have hi : fullInverse c hc (fromNat (ActualCarrierCharts.encode c.cube c.parity bits))=coordinates bits := by
    rw [← source_chart c hc bits,full_inverse_left]
  simp only [lift,hi,restrict_three]

end ExactQuadraticLift
#print axioms ExactQuadraticLift.inverse_left
#print axioms ExactQuadraticLift.inverse_right
#print axioms ExactQuadraticLift.lift_add
#print axioms ExactQuadraticLift.lift_scale
#print axioms ExactQuadraticLift.label_phase
#print axioms ExactQuadraticLift.pauli_conjugation
#print axioms ExactQuadraticLift.lift_on_actual_carrier
