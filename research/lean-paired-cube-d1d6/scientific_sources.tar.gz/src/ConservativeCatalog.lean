import CatalogSelector
namespace ConservativeCatalog
open BinarySpace24 BinaryCompletion VariableCertificates CatalogSpanBridge CatalogSelector CertifiedRepresentative Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def Domain (old fresh : List Witness) (U : Vec → Prop) := CatalogSelector.Domain old U ∨ CatalogSelector.Domain fresh U

noncomputable def select (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) : Rep F U := by
  classical
  exact if hOld : CatalogSelector.Domain old U then catalog i hi htwo old ho U hOld
    else catalog i hi htwo fresh hn U (hU.resolve_left hOld)

theorem old_preserved (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) (hOld : CatalogSelector.Domain old U) :
    select i hi htwo old fresh ho hn U hU=catalog i hi htwo old ho U hOld := by
  simp only [select,dif_pos hOld]

theorem new_when_absent (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) (hOld : ¬CatalogSelector.Domain old U)
    (hNew : CatalogSelector.Domain fresh U) :
    select i hi htwo old fresh ho hn U hU=catalog i hi htwo fresh hn U hNew := by
  simp only [select,dif_neg hOld]

theorem exact_inverses (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) (f : Vec → F) :
    let r := select i hi htwo old fresh ho hn U hU
    r.decode (r.encode f)=f ∧ r.encode (r.decode f)=f :=
  ⟨(select i hi htwo old fresh ho hn U hU).left_inverse f,
   (select i hi htwo old fresh ho hn U hU).right_inverse f⟩

theorem exact_preimage (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) (v : Vec × Vec) :
    ((select i hi htwo old fresh ho hn U hU).label v).1=zero ↔ Frame U v :=
  (select i hi htwo old fresh ho hn U hU).preimage v

theorem exact_Pauli (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) (v : Vec × Vec) (f : Vec → F) :
    let r := select i hi htwo old fresh ho hn U hU
    r.encode (ExactQuadraticLift.pauli v.1 v.2 (r.decode f))=
      fun x => r.phase v*ExactQuadraticLift.pauli (r.label v).1 (r.label v).2 f x :=
  CertifiedRepresentative.exact_conjugation (select i hi htwo old fresh ho hn U hU) v f

theorem same_frame (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U V : Vec → Prop) (hU : Domain old fresh U) (hV : Domain old fresh V) (h : U=V) :
    (select i hi htwo old fresh ho hn U hU).toExactFrame=(select i hi htwo old fresh ho hn V hV).toExactFrame := by
  cases h
  rfl

theorem inherited_target (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) (q : Vec) (hq : dot q q=true) (he : U=EndpointGeometry.Hyper q) :
    (select i hi htwo old fresh ho hn U hU).encode=InheritedEndpoints.target i q := by
  subst U
  have hOld : CatalogSelector.Domain old (EndpointGeometry.Hyper q) :=
    Or.inl (Or.inr (Or.inr (Or.inr ⟨q,hq,rfl⟩)))
  rw [old_preserved i hi htwo old fresh ho hn _ hU hOld]
  exact CatalogSelector.all_target_preserved i hi htwo old ho q hq

theorem inherited_source (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (old fresh : List Witness) (ho : old.all check=true) (hn : fresh.all check=true)
    (U : Vec → Prop) (hU : Domain old fresh U) (q : Vec) (hq : dot q q=true) (he : U=EndpointGeometry.Line q) :
    (select i hi htwo old fresh ho hn U hU).encode=InheritedEndpoints.source i q := by
  subst U
  have hOld : CatalogSelector.Domain old (EndpointGeometry.Line q) :=
    Or.inl (Or.inr (Or.inr (Or.inl ⟨q,hq,rfl⟩)))
  rw [old_preserved i hi htwo old fresh ho hn _ hU hOld]
  exact CatalogSelector.all_source_preserved i hi htwo old ho q hq

end ConservativeCatalog
#print axioms ConservativeCatalog.old_preserved
#print axioms ConservativeCatalog.new_when_absent
#print axioms ConservativeCatalog.exact_inverses
#print axioms ConservativeCatalog.exact_preimage
#print axioms ConservativeCatalog.exact_Pauli
#print axioms ConservativeCatalog.same_frame
#print axioms ConservativeCatalog.inherited_target
#print axioms ConservativeCatalog.inherited_source
