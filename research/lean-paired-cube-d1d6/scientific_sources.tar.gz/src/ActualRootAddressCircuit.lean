import RootAddressInstructions
namespace ActualRootAddressCircuit
open BinarySpace24 RootAddressInstructions BinaryBilinearCertificate
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

def code : List Instruction := [.cx ⟨18,22⟩,.cx ⟨20,22⟩,.cx ⟨18,23⟩,.permute]
def inverseCode : List Instruction := [.unpermute,.cx ⟨18,23⟩,.cx ⟨20,22⟩,.cx ⟨18,22⟩]

theorem code_legal : code.all legal=true := by decide
theorem reverse_code : reverse code=inverseCode := rfl

theorem permutation_forward_table : (List.finRange 24).map permutation.forward=
    [23,22,21,20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,3,2,1,0,4] := rfl

theorem permutation_inverse_table : (List.finRange 24).map permutation.inverse=
    [22,21,20,19,23,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0] := rfl

theorem columns_checked : (List.finRange 24).all (fun j => (List.finRange 24).all (fun k =>
    decide (run code (unit j) k=RootJointGeometry.rootChart.forward (unit j) k)))=true := by decide

theorem columns (j : Index) : run code (unit j)=RootJointGeometry.rootChart.forward (unit j) := by
  apply SourceLineCase.vector_check
  exact List.all_eq_true.mp columns_checked j (List.mem_ofFn.mpr ⟨j,rfl⟩)

theorem exact_forward (x : Vec) : run code x=RootJointGeometry.rootChart.forward x := by
  funext k
  apply linear_basis_ext (fun y => run code y k) (fun y => RootJointGeometry.rootChart.forward y k)
  · intro y z
    exact congrFun (run_add code y z) k
  · intro y z
    exact congrFun (RootJointGeometry.rootChart.forward_add y z) k
  · intro j
    exact congrFun (columns j) k

theorem exact_inverse (x : Vec) : run inverseCode x=RootJointGeometry.rootChart.inverse x := by
  have h := reverse_left code code_legal (RootJointGeometry.rootChart.inverse x)
  rw [exact_forward,RootJointGeometry.rootChart.inverse_right,reverse_code] at h
  exact h

theorem inverse_left (x : Vec) : run inverseCode (run code x)=x := by
  rw [← reverse_code]
  exact reverse_left code code_legal x

theorem inverse_right (x : Vec) : run code (run inverseCode x)=x := by
  rw [← reverse_code]
  exact reverse_right code code_legal x

end ActualRootAddressCircuit
#print axioms ActualRootAddressCircuit.code_legal
#print axioms ActualRootAddressCircuit.reverse_code
#print axioms ActualRootAddressCircuit.permutation_forward_table
#print axioms ActualRootAddressCircuit.permutation_inverse_table
#print axioms ActualRootAddressCircuit.columns_checked
#print axioms ActualRootAddressCircuit.columns
#print axioms ActualRootAddressCircuit.exact_forward
#print axioms ActualRootAddressCircuit.exact_inverse
#print axioms ActualRootAddressCircuit.inverse_left
#print axioms ActualRootAddressCircuit.inverse_right
