import CompletionData
namespace CompletionCheck011
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch011.all CompletionCertificates.check=true := by decide
end CompletionCheck011
#print axioms CompletionCheck011.valid
