import CXSpectatorCancellation
namespace ActualAlignmentDuality
open BinarySpace24 ChartComposition CanonicalFourthRootLift CoordinateWord CatalogSpanBridge CXLiftFormula Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
set_option maxRecDepth 10000
set_option maxHeartbeats 2000000

def rest20 : List Index := initial 20
def rest18 : List Index := (initial 18)++[19,20]

theorem split20 : (initial 22).Perm ([20,21]++rest20) ∧ (20:Index)∉rest20 ∧ (21:Index)∉rest20 := by decide
theorem split18 : (initial 22).Perm ([18,21]++rest18) ∧ (18:Index)∉rest18 ∧ (21:Index)∉rest18 := by decide

theorem dual20 (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    child i (initial 22) (K i (cx 20 21 (by decide)) (unchild i (initial 22) f))=
      K (-i) (cx 21 20 (by decide)) f := by
  rw [exact_local i hi,exact_local (-i) (FourthRootRecipe.neg_square i hi)]
  exact CXSpectatorCancellation.full_duality i hi htwo 20 21 (by decide) _ rest20 split20.1 split20.2.1 split20.2.2 f

theorem dual18 (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    child i (initial 22) (K i (cx 18 21 (by decide)) (unchild i (initial 22) f))=
      K (-i) (cx 21 18 (by decide)) f := by
  rw [exact_local i hi,exact_local (-i) (FourthRootRecipe.neg_square i hi)]
  exact CXSpectatorCancellation.full_duality i hi htwo 18 21 (by decide) _ rest18 split18.1 split18.2.1 split18.2.2 f

def dualChart := compose (cx 21 20 (by decide)) (cx 21 18 (by decide))

theorem exact_alignment_duality (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (f : Vec → F) :
    child i (initial 22) (K i RootJointGeometry.alignment (unchild i (initial 22) f))=
      K (-i) dualChart f := by
  rw [RootJointGeometry.alignment,K_composition i hi,dualChart,K_composition (-i) (FourthRootRecipe.neg_square i hi)]
  rw [← dual18 i hi htwo,← dual20 i hi htwo]
  rw [CoordinateWord.inverse_left i hi htwo]

end ActualAlignmentDuality
#print axioms ActualAlignmentDuality.split20
#print axioms ActualAlignmentDuality.split18
#print axioms ActualAlignmentDuality.dual20
#print axioms ActualAlignmentDuality.dual18
#print axioms ActualAlignmentDuality.exact_alignment_duality
