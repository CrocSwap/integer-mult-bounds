import FieldEvaluation
import WeightedRows
import ReadoutAlgebra
namespace FieldLinearEvaluation
open Lean.Grind MaskRows PairedDecoder
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem evaluate_add (a b : List Int) (payload : List F) (hlen : a.length=b.length) :
    FieldEvaluation.evaluate (List.zipWith (fun x y => x+y) a b) payload =
      FieldEvaluation.evaluate a payload + FieldEvaluation.evaluate b payload := by
  induction a generalizing b payload with
  | nil =>
    cases b with
    | nil => simp [FieldEvaluation.evaluate, Semiring.add_zero]
    | cons y ys => simp at hlen
  | cons x xs ih =>
    cases b with
    | nil => simp at hlen
    | cons y ys =>
      have ht : xs.length=ys.length := by simpa using hlen
      cases payload with
      | nil => simp [FieldEvaluation.evaluate, Semiring.add_zero]
      | cons p ps =>
        simp only [List.zipWith_cons_cons, FieldEvaluation.evaluate, Ring.intCast_add,
          Semiring.right_distrib, ih ys ps ht]
        simp [Semiring.add_assoc, Semiring.add_comm, Semiring.add_left_comm]

def readout : List ReadTerm → (Nat → F) → F
  | [], _ => 0
  | t :: ts, x => (t.coefficient : F)*x t.role + readout ts x

theorem readout_congr (ts : List ReadTerm) (x y : Nat → F)
    (h : ∀ t ∈ ts, x t.role=y t.role) : readout ts x = readout ts y := by
  induction ts with
  | nil => rfl
  | cons t ts ih =>
    simp only [readout, h t (by simp), ih (fun u hu => h u (by simp [hu]))]

theorem readout_append (a b : List ReadTerm) (x : Nat → F) :
    readout (a++b) x = readout a x + readout b x := by
  induction a with
  | nil => simp [readout, Semiring.zero_add]
  | cons t ts ih => simp [readout, ih, Semiring.add_assoc]

theorem readout_remap (f : Nat → Nat) (ts : List ReadTerm) (x : Nat → F) :
    readout (ts.map (ReadoutAlgebra.remap f)) x = readout ts (fun n => x (f n)) := by
  induction ts with
  | nil => rfl
  | cons t ts ih => simp [readout, ReadoutAlgebra.remap, ih]

theorem evaluate_vector (width : Nat) (rows : Nat → Row) (ts : List ReadTerm) (payload : List F) :
    FieldEvaluation.evaluate (WeightedRows.vector width rows ts) payload =
      readout ts (fun role => FieldEvaluation.evaluate (coefficients width (rows role)) payload) := by
  induction ts with
  | nil => exact FieldEvaluation.evaluate_zeros width payload
  | cons t ts ih =>
    rw [WeightedRows.vector, evaluate_add _ _ payload (by simp [coefficients, WeightedRows.vector_length]),
      FieldEvaluation.evaluate_scale, ih]
    rfl

end FieldLinearEvaluation
#print axioms FieldLinearEvaluation.evaluate_add
#print axioms FieldLinearEvaluation.readout_congr
#print axioms FieldLinearEvaluation.readout_append
#print axioms FieldLinearEvaluation.readout_remap
#print axioms FieldLinearEvaluation.evaluate_vector
