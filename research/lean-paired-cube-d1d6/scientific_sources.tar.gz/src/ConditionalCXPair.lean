import IndexedPairReadout
namespace ConditionalCXPair
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs
variable {V : Type u}

def control (c : Index) (k : Bits 23) := embed false k c
def swapIf (b : Bool) (v : V × V) : V × V := (if b then v.2 else v.1,if b then v.1 else v.2)
def op (c : Index) (k : Bits 23) (v : V × V) := swapIf (control c k) v

theorem flip_embed (b : Bool) (y : Bits 23) : CoordinateChild.flip 21 (embed b y)=embed (!b) y := by
  cases b
  · exact pair_flip y
  · have h := congrArg (CoordinateChild.flip 21) (pair_flip y)
    rw [CoordinateChild.flip_twice] at h
    exact h.symm

theorem partner_at (x : Vec) : embed (!(x 21)) (Coordinate21Pairs.drop x)=CoordinateChild.flip 21 x := by
  rw [← flip_embed,embed_drop]

theorem control_at_drop (c : Index) (hc : c≠21) (x : Vec) : control c (Coordinate21Pairs.drop x)=x c := by
  have hx := congrFun (embed_drop x) c
  cases hb : x 21
  · simpa only [hb,control] using hx
  · rw [hb] at hx
    have hp := congrFun (pair_flip (Coordinate21Pairs.drop x)) c
    have hf : CoordinateChild.flip 21 (embed false (Coordinate21Pairs.drop x)) c=embed false (Coordinate21Pairs.drop x) c := by
      simp [CoordinateChild.flip,add,unit,hc,Ne.symm hc]
    rw [hf] at hp
    exact hp.trans hx

theorem execute_as_flip (c : Index) (x : Vec) :
    Q21AddressProgram.execute ⟨c,21⟩ x=if x c then CoordinateChild.flip 21 x else x := by
  cases h : x c <;> funext j <;> simp [Q21AddressProgram.execute,CoordinateChild.flip,add,BinarySpace24.scale,h]

theorem gather_semantics (c : Index) (hc : c≠21) (f : Vec → V) :
    IndexedPairReadout.gather (op c) f=fun x=>f (Q21AddressProgram.execute ⟨c,21⟩ x) := by
  funext x
  have he := embed_drop x
  have hp := partner_at x
  have hh := control_at_drop c hc x
  rw [execute_as_flip]
  cases hb : x 21 <;> cases hx : x c <;>
    simp only [IndexedPairReadout.gather,op,swapIf,hh,hb,hx,Bool.false_eq_true,if_false,if_true] <;>
    simp only [hb,Bool.not_false,Bool.not_true] at he hp <;>
    first | exact congrArg f he | exact congrArg f hp

theorem control18 (k : Bits 23) : control 18 k=k 17 := rfl
theorem control20 (k : Bits 23) : control 20 k=k 19 := rfl

theorem unchanged (v : V × V) : swapIf false v=v := by cases v; rfl
end ConditionalCXPair
#print axioms ConditionalCXPair.flip_embed
#print axioms ConditionalCXPair.partner_at
#print axioms ConditionalCXPair.control_at_drop
#print axioms ConditionalCXPair.execute_as_flip
#print axioms ConditionalCXPair.gather_semantics
#print axioms ConditionalCXPair.control18
#print axioms ConditionalCXPair.control20
#print axioms ConditionalCXPair.unchanged
