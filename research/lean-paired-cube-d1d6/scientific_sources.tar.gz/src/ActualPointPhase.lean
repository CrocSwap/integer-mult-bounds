import PointPhaseMachine
namespace ActualPointPhase
open BinarySpace24 BinaryPairEnumeration PointPhaseMachine SuppliedQuarterTable Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

@[irreducible] def stage (eval : Vec → CountedQuarterCoefficient.Result F) (s : PairLoadStoreMachine.State Vec F) :=
  PointPhaseMachine.loop eval (addresses 24) s

theorem memory_exact (eval : Vec → CountedQuarterCoefficient.Result F) (s : PairLoadStoreMachine.State Vec F) :
    (stage eval s).1.memory=fun x=>(eval x).value*s.memory x := by
  rw [stage,loop_memory]
  exact PointMemoryLoop.complete _ (addresses 24) (addresses_nodup 24) (all_addresses 24) s.memory

theorem cost_exact (eval : Vec → CountedQuarterCoefficient.Result F) (c : Cost)
    (hc : ∀x,pointCost (eval x)=c) (s : PairLoadStoreMachine.State Vec F) :
    (stage eval s).2=scaleCost 16777216 c := by
  rw [stage,loop_cost eval c hc,address_count]

def left (t : Table F) := stage (CountedQuarterCoefficient.left t)
def right (t : Table F) := stage (CountedQuarterCoefficient.right t)
def leftPointCost : Cost := ⟨1,1,1,2,⟨51,151,51,1,51,50⟩⟩
def rightPointCost : Cost := ⟨1,1,1,2,⟨48,147,49,0,50,49⟩⟩

theorem left_point_cost (t : Table F) (x : Vec) : pointCost (CountedQuarterCoefficient.left t x)=leftPointCost := by
  have h:=CountedQuarterCoefficient.left_receipt t x
  simp only [pointCost,h.1,h.2,leftPointCost]

theorem right_point_cost (t : Table F) (x : Vec) : pointCost (CountedQuarterCoefficient.right t x)=rightPointCost := by
  have h:=CountedQuarterCoefficient.right_receipt t x
  simp only [pointCost,h.1,h.2,rightPointCost]

theorem left_cost (t : Table F) (s : PairLoadStoreMachine.State Vec F) :
    (left t s).2=scaleCost 16777216 leftPointCost := cost_exact _ _ (left_point_cost t) s

theorem right_cost (t : Table F) (s : PairLoadStoreMachine.State Vec F) :
    (right t s).2=scaleCost 16777216 rightPointCost := cost_exact _ _ (right_point_cost t) s

theorem left_memory (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (s : PairLoadStoreMachine.State Vec F) :
    (left t s).1.memory=fun x=>LeftPassAddressPhase.scalar i x*s.memory x := by
  rw [left,memory_exact]
  funext x
  rw [CountedQuarterCoefficient.left_exact i hi t ht]

theorem right_memory (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (s : PairLoadStoreMachine.State Vec F) :
    (right t s).1.memory=fun x=>RightPassAddressPhase.scalar i x*s.memory x := by
  rw [right,memory_exact]
  funext x
  rw [CountedQuarterCoefficient.right_exact i hi t ht]

theorem prefix_invariant (eval : Vec → CountedQuarterCoefficient.Result F) (n : Nat)
    (s : PairLoadStoreMachine.State Vec F) (x : Vec) :
    (PointPhaseMachine.loop eval ((addresses 24).take n) s).1.memory x=
      if x∈(addresses 24).take n then (eval x).value*s.memory x else s.memory x := by
  rw [loop_memory]
  exact PointMemoryLoop.run_at _ _ ((addresses_nodup 24).take) s.memory x

end ActualPointPhase
#print axioms ActualPointPhase.memory_exact
#print axioms ActualPointPhase.cost_exact
#print axioms ActualPointPhase.left_point_cost
#print axioms ActualPointPhase.right_point_cost
#print axioms ActualPointPhase.left_cost
#print axioms ActualPointPhase.right_cost
#print axioms ActualPointPhase.left_memory
#print axioms ActualPointPhase.right_memory
#print axioms ActualPointPhase.prefix_invariant
