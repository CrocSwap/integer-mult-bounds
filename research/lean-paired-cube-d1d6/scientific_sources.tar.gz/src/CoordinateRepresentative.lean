import GeneralChartFrames
namespace CoordinateRepresentative
open BinarySpace24 BinaryCompletion FourthRootRecipe FourthRootLift CanonicalGramRecipe CanonicalFourthRootLift GeneralChartFrames Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

theorem K_injective (i : F) (hi : i*i= -1) (c : Chart) (f g : Vec → F) (h : K i c f=K i c g) : f=g := by
  have he := congrArg (Kinv i c) h
  simpa only [K_inverse_left i hi] using he

theorem K_pullthrough (i : F) (hi : i*i= -1) (c : Chart) (v : Vec × Vec) (f : Vec → F) :
    K i c (ExactQuadraticLift.pauli v.1 v.2 f)=fun x => FourthRootRecipe.phase (-i) (terms c) v.1*
      ExactQuadraticLift.pauli (FourthRootLift.label c v).1 (FourthRootLift.label c v).2 (K i c f) x := by
  have h := FourthRootLift.pauli_conjugation i hi c (terms c) (canonical_gram_compatible c) v.1 v.2 (K i c f)
  simpa only [K,Kinv,FourthRootLift.inverse_left i hi] using h

theorem Kinv_pullthrough (i : F) (hi : i*i= -1) (c : Chart) (v : Vec × Vec) (f : Vec → F) :
    Kinv i c (ExactQuadraticLift.pauli v.1 v.2 f)=fun x => FourthRootRecipe.phase i (terms c) (inverseLabel c v).1*
      ExactQuadraticLift.pauli (inverseLabel c v).1 (inverseLabel c v).2 (Kinv i c f) x := by
  apply K_injective i hi c
  rw [K_inverse_right i hi,K_scale,K_pullthrough i hi,K_inverse_right i hi,label_inverse_right]
  funext x
  have h := FourthRootRecipe.phase_inverse i hi (terms c) (inverseLabel c v).1
  grind

def representative (i : F) (c : Chart) (js : List Index) (f : Vec → F) :=
  K i c (CoordinateWord.child i js (Kinv i c f))
def inverseRepresentative (i : F) (c : Chart) (js : List Index) (f : Vec → F) :=
  K i c (CoordinateWord.unchild i js (Kinv i c f))
def label (c : Chart) (js : List Index) (v : Vec × Vec) :=
  FourthRootLift.label c (CoordinateWord.label js (inverseLabel c v))
def exactPhase (i : F) (c : Chart) (js : List Index) (v : Vec × Vec) : F :=
  let w := inverseLabel c v
  FourthRootRecipe.phase i (terms c) w.1 * CoordinateWord.phase i js w.2 *
    FourthRootRecipe.phase (-i) (terms c) (CoordinateWord.label js w).1

theorem inverse_left (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (c : Chart) (js : List Index) (f : Vec → F) :
    inverseRepresentative i c js (representative i c js f)=f := by
  simp only [inverseRepresentative,representative,K_inverse_left i hi,CoordinateWord.inverse_left i hi htwo,K_inverse_right i hi]

theorem inverse_right (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (c : Chart) (js : List Index) (f : Vec → F) :
    representative i c js (inverseRepresentative i c js f)=f := by
  simp only [inverseRepresentative,representative,K_inverse_left i hi,CoordinateWord.inverse_right i hi htwo,K_inverse_right i hi]

theorem pauli_pullthrough (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (c : Chart) (js : List Index)
    (v : Vec × Vec) (f : Vec → F) :
    representative i c js (ExactQuadraticLift.pauli v.1 v.2 f)=fun x => exactPhase i c js v*
      ExactQuadraticLift.pauli (label c js v).1 (label c js v).2 (representative i c js f) x := by
  unfold representative
  rw [Kinv_pullthrough i hi,CoordinateWord.child_scale,CoordinateWord.pauli_pullthrough i hi htwo,
    K_scale,K_scale,K_pullthrough i hi]
  funext x
  simp only [exactPhase,label]
  grind

theorem pauli_conjugation (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (c : Chart) (js : List Index)
    (v : Vec × Vec) (f : Vec → F) :
    representative i c js (ExactQuadraticLift.pauli v.1 v.2 (inverseRepresentative i c js f))=fun x => exactPhase i c js v*
      ExactQuadraticLift.pauli (label c js v).1 (label c js v).2 f x := by
  rw [pauli_pullthrough i hi htwo,inverse_right i hi htwo]

theorem label_involution (c : Chart) (js : List Index) (v : Vec × Vec) : label c js (label c js v)=v := by
  simp only [label,label_inverse_left,CoordinateWordFrames.label_involution,label_inverse_right]

theorem frame_preimage (c : Chart) (js : List Index) (hn : js.Nodup) (v : Vec × Vec) :
    (label c js v).1=zero ↔ Frame (Image c.forward (CoordinateWordFrames.Space js)) v := by
  change c.forward (CoordinateWord.label js (inverseLabel c v)).1=zero ↔ _
  rw [forward_kernel,CoordinateWordFrames.frame_preimage js hn,inverse_frame_transport]

theorem exact_phase_fourth (i : F) (hi : i*i= -1) (c : Chart) (js : List Index) (v : Vec × Vec) :
    (exactPhase i c js v*exactPhase i c js v)*(exactPhase i c js v*exactPhase i c js v)=1 := by
  have h0 := FourthRootRecipe.phase_fourth i hi (terms c) (inverseLabel c v).1
  have h1 := CoordinateWord.phase_fourth i hi js (inverseLabel c v).2
  have h2 := FourthRootRecipe.phase_fourth (-i) (neg_square i hi) (terms c) (CoordinateWord.label js (inverseLabel c v)).1
  simp only [exactPhase]
  grind

end CoordinateRepresentative
#print axioms CoordinateRepresentative.K_injective
#print axioms CoordinateRepresentative.K_pullthrough
#print axioms CoordinateRepresentative.Kinv_pullthrough
#print axioms CoordinateRepresentative.inverse_left
#print axioms CoordinateRepresentative.inverse_right
#print axioms CoordinateRepresentative.pauli_pullthrough
#print axioms CoordinateRepresentative.pauli_conjugation
#print axioms CoordinateRepresentative.label_involution
#print axioms CoordinateRepresentative.frame_preimage
#print axioms CoordinateRepresentative.exact_phase_fourth
