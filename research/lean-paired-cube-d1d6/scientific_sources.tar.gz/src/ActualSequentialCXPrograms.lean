import SequentialCXProgram
namespace ActualSequentialCXPrograms
open BinarySpace24 SequentialCXKernel SequentialCXProgram Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def leftSpecs : List Spec := [⟨⟨18,23⟩,by decide⟩,⟨⟨20,22⟩,by decide⟩,⟨⟨18,22⟩,by decide⟩,⟨⟨21,20⟩,by decide⟩,⟨⟨21,18⟩,by decide⟩]
def rightSpecs : List Spec := [⟨⟨18,21⟩,by decide⟩,⟨⟨20,21⟩,by decide⟩,⟨⟨18,22⟩,by decide⟩,⟨⟨20,22⟩,by decide⟩,⟨⟨18,23⟩,by decide⟩]

theorem exact_lists : leftSpecs.map Spec.gate=ActualOuterCXPrograms.leftCX ∧
    rightSpecs.map Spec.gate=ActualOuterCXPrograms.rightCX := ⟨rfl,rfl⟩

theorem left_memory (s : State Vec F) :
    (program leftSpecs s).1.work.memory=fun x=>s.work.memory (Q21AddressProgram.run ActualOuterCXPrograms.leftCX x) := by
  rw [program_memory]
  funext x
  rw [run_exact,exact_lists.1]

theorem right_memory (s : State Vec F) :
    (program rightSpecs s).1.work.memory=fun x=>s.work.memory (Q21AddressProgram.run ActualOuterCXPrograms.rightCX x) := by
  rw [program_memory]
  funext x
  rw [run_exact,exact_lists.2]

theorem left_receipt (s : State Vec F) :
    (program leftSpecs s).2=⟨83886080,83886080,41943040,83886080⟩ := by
  rw [SequentialCXProgram.program_cost]
  rfl

theorem right_receipt (s : State Vec F) :
    (program rightSpecs s).2=⟨83886080,83886080,41943040,83886080⟩ := by
  rw [SequentialCXProgram.program_cost]
  rfl

theorem summed_receipt (s t : State Vec F) : Cost.add (program leftSpecs s).2 (program rightSpecs t).2=
    ⟨167772160,167772160,83886080,167772160⟩ := by rw [left_receipt,right_receipt];rfl

end ActualSequentialCXPrograms
#print axioms ActualSequentialCXPrograms.exact_lists
#print axioms ActualSequentialCXPrograms.left_memory
#print axioms ActualSequentialCXPrograms.right_memory
#print axioms ActualSequentialCXPrograms.left_receipt
#print axioms ActualSequentialCXPrograms.right_receipt
#print axioms ActualSequentialCXPrograms.summed_receipt
