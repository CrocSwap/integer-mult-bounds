import CompletionData
namespace CompletionCheck013
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch013.all CompletionCertificates.check=true := by decide
end CompletionCheck013
#print axioms CompletionCheck013.valid
