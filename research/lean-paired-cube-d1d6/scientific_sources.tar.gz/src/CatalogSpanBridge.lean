import PiecewiseSelector
import ActualVariablePilot
namespace CatalogSpanBridge
open BinarySpace24 BinaryCompletion BinaryBilinearCertificate VariableCertificates

def initial (r : Nat) : List Index := (List.finRange 24).filter (fun j => j.val<r)
def sumRows (row : Index → Vec) : List Index → Vec → Vec
  | [],_ => zero
  | j::js,x => add (scale (x j) (row j)) (sumRows row js x)
def rows (c : Witness) (j : Index) : Vec := CompletionFrames.fromNat (c.slots[j.val]?.getD (0,0)).2
def Span (c : Witness) (y : Vec) : Prop := ∃x, sumRows (rows c) (initial c.slots.length) x=y

theorem prefix_nodup (r : Nat) : (initial r).Nodup :=
  (show (List.finRange 24).Nodup from by decide).filter _

theorem prefix_member (r : Nat) (j : Index) : j ∈ initial r ↔ j.val<r := by
  have hj : j ∈ List.finRange 24 := List.mem_ofFn.mpr ⟨j,rfl⟩
  simp only [initial,List.mem_filter,hj,true_and,decide_eq_true_eq]

theorem projection_fixed (js : List Index) (hn : js.Nodup) (x : Vec) (hx : CoordinateWordFrames.Space js x) :
    CoordinateWord.projection js x=x := by
  funext k
  rw [CoordinateWordFrames.projection_value js hn]
  by_cases hk : k ∈ js
  · rw [if_pos hk]
  · rw [if_neg hk,hx k hk]

theorem forward_scale (c : FourthRootLift.Chart) (b : Bool) (x : Vec) : c.forward (scale b x)=scale b (c.forward x) := by
  cases b
  · exact GeneralChartFrames.forward_zero c
  · rfl

theorem forward_sum (c : FourthRootLift.Chart) (js : List Index) (x : Vec) :
    c.forward (CoordinateWord.projection js x)=sumRows (fun j => c.forward (unit j)) js x := by
  induction js with
  | nil => exact GeneralChartFrames.forward_zero c
  | cons j js ih =>
    change c.forward (add (scale (x j) (unit j)) (CoordinateWord.projection js x))=_
    rw [c.forward_add,forward_scale,ih]
    rfl

theorem sumRows_congr (a b : Index → Vec) (js : List Index) (h : ∀j∈js,a j=b j) (x : Vec) :
    sumRows a js x=sumRows b js x := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    rw [sumRows,sumRows,h j (by simp),ih (fun k hk => h k (by simp [hk]))]

theorem source_rows (c : Witness) (hc : Facts c) (j : Index) (hj : j ∈ initial c.slots.length) :
    (chart c hc).forward (unit j)=rows c j := by
  have hlt := (prefix_member _ j).mp hj
  rw [VariableOrderedColumns.ordered_source_column c hc j hlt]
  simp only [rows,List.getElem?_eq_getElem hlt,Option.getD_some]

theorem image_span (c : Witness) (hc : Facts c) :
    Image (chart c hc).forward (CoordinateWordFrames.Space (initial c.slots.length))=Span c := by
  funext y
  apply propext
  constructor
  · rintro ⟨x,hx,rfl⟩
    refine ⟨x,?_⟩
    rw [← sumRows_congr _ (rows c) _ (source_rows c hc) x,← forward_sum,
      projection_fixed _ (prefix_nodup _) x hx]
  · rintro ⟨x,rfl⟩
    refine ⟨CoordinateWord.projection (initial c.slots.length) x,
      CoordinateWordFrames.projection_space _ (prefix_nodup _) x,?_⟩
    rw [forward_sum,sumRows_congr _ (rows c) _ (source_rows c hc) x]

def data (c : Witness) (hc : Facts c) : PiecewiseSelector.CanonicalData (Span c) where
  chart := chart c hc
  coordinates := initial c.slots.length
  distinct := prefix_nodup _
  image := (image_span c hc).symm

theorem data_exact_span (c : Witness) (hc : Facts c) (v : Vec × Vec) :
    (CoordinateRepresentative.label (data c hc).chart (data c hc).coordinates v).1=zero ↔ Frame (Span c) v := by
  rw [CoordinateRepresentative.frame_preimage _ _ (data c hc).distinct,← (data c hc).image]

end CatalogSpanBridge
#print axioms CatalogSpanBridge.prefix_nodup
#print axioms CatalogSpanBridge.prefix_member
#print axioms CatalogSpanBridge.projection_fixed
#print axioms CatalogSpanBridge.forward_scale
#print axioms CatalogSpanBridge.forward_sum
#print axioms CatalogSpanBridge.sumRows_congr
#print axioms CatalogSpanBridge.source_rows
#print axioms CatalogSpanBridge.image_span
#print axioms CatalogSpanBridge.data_exact_span
