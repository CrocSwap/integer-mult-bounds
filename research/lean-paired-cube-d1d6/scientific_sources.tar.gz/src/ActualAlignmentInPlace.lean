import ConditionalCXPair
namespace ActualAlignmentInPlace
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

def stage (c : Index) (s : PairLoadStoreMachine.State Vec V) :=
  IndexedPairLoop.machine (embed false) (embed true) (ConditionalCXPair.op c) (addresses 23) s

theorem memory_exact (c : Index) (hc : c≠21) (s : PairLoadStoreMachine.State Vec V) :
    (stage c s).memory=fun x=>s.memory (Q21AddressProgram.execute ⟨c,21⟩ x) := by
  rw [stage,IndexedPairLoop.machine_memory]
  apply Eq.trans (b:=IndexedPairReadout.gather (ConditionalCXPair.op c) s.memory)
  · apply IndexedPairReadout.from_pairs (ConditionalCXPair.op c)
    intro y
    have h := IndexedPairLoop.run_pair (embed false) (embed true) ActualCoordinate21InPlace.geometry
      (ConditionalCXPair.op c) (addresses 23) (addresses_nodup 23) s.memory y
    rw [if_pos (all_addresses 23 y)] at h
    exact h
  · exact ConditionalCXPair.gather_semantics c hc s.memory

-- Pullback execution reverses the address instruction order, and reuses the state.
def alignment (s : PairLoadStoreMachine.State Vec V) := stage 18 (stage 20 s)
def inverseAlignment (s : PairLoadStoreMachine.State Vec V) := stage 20 (stage 18 s)

theorem alignment_exact (s : PairLoadStoreMachine.State Vec V) :
    (alignment s).memory=fun x=>s.memory (Q21AddressProgram.run RootJointGeometry.code x) := by
  rw [alignment,memory_exact 18 (by decide),memory_exact 20 (by decide)]
  rfl

theorem inverse_alignment_exact (s : PairLoadStoreMachine.State Vec V) :
    (inverseAlignment s).memory=fun x=>s.memory (Q21AddressProgram.run RootJointGeometry.code.reverse x) := by
  rw [inverseAlignment,memory_exact 20 (by decide),memory_exact 18 (by decide)]
  rfl

theorem chart_exact (s : PairLoadStoreMachine.State Vec V) :
    (alignment s).memory=fun x=>s.memory (RootJointGeometry.alignment.forward x) := by
  rw [alignment_exact]
  funext x
  rw [RootJointGeometry.alignment_forward]

theorem inverse_chart_exact (s : PairLoadStoreMachine.State Vec V) :
    (inverseAlignment s).memory=fun x=>s.memory (RootJointGeometry.alignment.inverse x) := by
  rw [inverse_alignment_exact]
  funext x
  rw [RootJointGeometry.alignment_inverse]

theorem memory_restored (s : PairLoadStoreMachine.State Vec V) :
    (inverseAlignment (alignment s)).memory=s.memory := by
  rw [inverse_chart_exact,chart_exact]
  funext x
  exact congrArg s.memory (RootJointGeometry.alignment.inverse_right x)

theorem actual_right_prefix :
    OuterAddressCircuits.rightCode=(RootJointGeometry.code.map RootAddressInstructions.Instruction.cx)++ActualRootAddressCircuit.code := rfl

theorem old_pair_prepared (c : Index) (k : Bits 23) (s : PairLoadStoreMachine.State Vec V) :
    (PairLoadStoreMachine.run (embed false) (embed true) (ConditionalCXPair.op c k) k
      PairLoadStoreMachine.preparation s).memory=s.memory ∧
    ((PairLoadStoreMachine.run (embed false) (embed true) (ConditionalCXPair.op c k) k
      PairLoadStoreMachine.preparation s).left,
     (PairLoadStoreMachine.run (embed false) (embed true) (ConditionalCXPair.op c k) k
      PairLoadStoreMachine.preparation s).right)=
      ConditionalCXPair.op c k (s.memory (embed false k),s.memory (embed true k)) := ⟨rfl,rfl⟩

end ActualAlignmentInPlace
#print axioms ActualAlignmentInPlace.memory_exact
#print axioms ActualAlignmentInPlace.alignment_exact
#print axioms ActualAlignmentInPlace.inverse_alignment_exact
#print axioms ActualAlignmentInPlace.chart_exact
#print axioms ActualAlignmentInPlace.inverse_chart_exact
#print axioms ActualAlignmentInPlace.memory_restored
#print axioms ActualAlignmentInPlace.actual_right_prefix
#print axioms ActualAlignmentInPlace.old_pair_prepared
