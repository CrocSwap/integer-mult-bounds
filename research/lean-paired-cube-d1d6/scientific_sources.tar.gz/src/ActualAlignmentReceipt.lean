import CountedConditionalSwap
namespace ActualAlignmentReceipt
open BinarySpace24 BinaryPairEnumeration Coordinate21Pairs CountedConditionalSwap Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

def countedAlignment (s : PairLoadStoreMachine.State Vec V) : PairLoadStoreMachine.State Vec V × Cost :=
  let first:=loop 20 (addresses 23) s
  let second:=loop 18 (addresses 23) first.1
  (second.1,Cost.add first.2 second.2)

theorem counted_alignment_exact (s : PairLoadStoreMachine.State Vec V) :
    countedAlignment s=(ActualAlignmentInPlace.alignment s,⟨33554432,33554432,16777216,33554432,0⟩) := by
  simp only [countedAlignment,actual_loop]
  rfl

theorem actual_control_reads (k : Bits 23) : readControl 18 k=(k 17,1) ∧ readControl 20 k=(k 19,1) := ⟨rfl,rfl⟩

theorem counted_memory_exact (s : PairLoadStoreMachine.State Vec V) :
    (countedAlignment s).1.memory=fun x=>s.memory (RootJointGeometry.alignment.forward x) := by
  rw [counted_alignment_exact]
  exact ActualAlignmentInPlace.chart_exact s

theorem prefix_count (c : Index) (n : Nat) (s : PairLoadStoreMachine.State Vec V) :
    (loop c ((addresses 23).take n) s).2=loopCost (min n 8388608) := by
  rw [loop_exact,List.length_take,Coordinate21Pairs.pair_count]

theorem prefix_pair (c : Index) (n : Nat) (s : PairLoadStoreMachine.State Vec V) (k : Bits 23) :
    DisjointPairLoop.readPair (embed false) (embed true) (loop c ((addresses 23).take n) s).1.memory k=
    if k∈(addresses 23).take n then ConditionalCXPair.op c k (DisjointPairLoop.readPair (embed false) (embed true) s.memory k)
    else DisjointPairLoop.readPair (embed false) (embed true) s.memory k := by
  rw [loop_exact,IndexedPairLoop.machine_memory]
  exact IndexedPairLoop.run_pair (embed false) (embed true) ActualCoordinate21InPlace.geometry (ConditionalCXPair.op c)
    ((addresses 23).take n) ((addresses_nodup 23).take) s.memory k

variable {F : Type u} [Field F]
-- This is a supplied memory invariant, not a second buffer or an implementation of the root chart.
theorem right_address_segment (f : Vec → F) (s : PairLoadStoreMachine.State Vec F)
    (hs : s.memory=fun y=>f (RootJointGeometry.rootChart.forward y)) :
    (countedAlignment s).1.memory=fun x=>f (RightPassAddressPhase.address x) := by
  rw [counted_memory_exact,hs]
  funext x
  simp only [RootJointGeometry.alignment_forward,RightPassAddressPhase.address]

theorem right_pass_binding (i : F) (hi : i*i= -1) (f : Vec → F) (s : PairLoadStoreMachine.State Vec F)
    (hs : s.memory=fun y=>f (RootJointGeometry.rootChart.forward y)) :
    ActualQuarterPhase.rightPass i f=fun x=>RightPassAddressPhase.scalar i x*(countedAlignment s).1.memory x := by
  rw [ActualQuarterPhase.exact_right i hi,OuterAddressCircuits.exact_right,right_address_segment f s hs]
  rfl

end ActualAlignmentReceipt
#print axioms ActualAlignmentReceipt.counted_alignment_exact
#print axioms ActualAlignmentReceipt.actual_control_reads
#print axioms ActualAlignmentReceipt.counted_memory_exact
#print axioms ActualAlignmentReceipt.prefix_count
#print axioms ActualAlignmentReceipt.prefix_pair
#print axioms ActualAlignmentReceipt.right_address_segment
#print axioms ActualAlignmentReceipt.right_pass_binding
