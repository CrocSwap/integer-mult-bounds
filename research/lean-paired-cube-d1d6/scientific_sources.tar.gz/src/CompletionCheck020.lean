import CompletionData
namespace CompletionCheck020
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch020.all CompletionCertificates.check=true := by decide
end CompletionCheck020
#print axioms CompletionCheck020.valid
