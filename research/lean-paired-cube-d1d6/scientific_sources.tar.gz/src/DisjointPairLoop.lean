import BinaryAddressEquality
namespace DisjointPairLoop
variable {X : Type u} {I : Type v} {V : Type w} [DecidableEq X] [DecidableEq I]

structure Geometry (a b : I → X) : Prop where
  left_injective : ∀i j,a i=a j → i=j
  right_injective : ∀i j,b i=b j → i=j
  disjoint : ∀i j,a i≠b j

def write (m : X → V) (x : X) (v : V) : X → V := fun y => if y=x then v else m y

def readPair (a b : I → X) (m : X → V) (i : I) := (m (a i),m (b i))

def step (a b : I → X) (op : V × V → V × V) (i : I) (m : X → V) :=
  let oldPair := readPair a b m i
  let newPair := op oldPair
  write (write m (a i) newPair.1) (b i) newPair.2

def run (a b : I → X) (op : V × V → V × V) : List I → (X → V) → (X → V)
  | [],m => m
  | i::is,m => run a b op is (step a b op i m)

theorem write_here (m : X → V) (x : X) (v : V) : write m x v x=v := by simp [write]

theorem write_other (m : X → V) (x y : X) (v : V) (h : y≠x) : write m x v y=m y := by
  simp only [write,if_neg h]

theorem step_same (a b : I → X) (g : Geometry a b) (op : V × V → V × V) (i : I) (m : X → V) :
    readPair a b (step a b op i m) i=op (readPair a b m i) := by
  simp only [readPair,step,write_other _ (b i) (a i) _ (g.disjoint i i),write_here]

theorem step_other_pair (a b : I → X) (g : Geometry a b) (op : V × V → V × V)
    (i j : I) (h : i≠j) (m : X → V) :
    readPair a b (step a b op j m) i=readPair a b m i := by
  have hl : a i≠a j := fun he => h (g.left_injective i j he)
  have hr : b i≠b j := fun he => h (g.right_injective i j he)
  have hc : b i≠a j := Ne.symm (g.disjoint j i)
  simp only [readPair,step,write_other _ (b j) (a i) _ (g.disjoint i j),
    write_other _ (a j) (a i) _ hl,write_other _ (b j) (b i) _ hr,write_other _ (a j) (b i) _ hc]

theorem step_untouched (a b : I → X) (op : V × V → V × V) (i : I) (m : X → V)
    (x : X) (ha : x≠a i) (hb : x≠b i) : step a b op i m x=m x := by
  simp only [step,write_other _ (b i) x _ hb,write_other _ (a i) x _ ha]

theorem run_pair (a b : I → X) (g : Geometry a b) (op : V × V → V × V)
    (is : List I) (hn : is.Nodup) (m : X → V) (i : I) :
    readPair a b (run a b op is m) i=
      if i∈is then op (readPair a b m i) else readPair a b m i := by
  induction is generalizing m with
  | nil => simp only [run,List.not_mem_nil,if_false]
  | cons j js ih =>
    have hh := List.nodup_cons.mp hn
    rw [run,ih hh.2]
    by_cases he : i=j
    · subst i
      simp only [hh.1,if_false,step_same a b g,List.mem_cons_self,if_true]
    · rw [step_other_pair a b g op i j he]
      simp only [List.mem_cons,he,false_or]

theorem run_untouched (a b : I → X) (op : V × V → V × V) (is : List I)
    (m : X → V) (x : X) (h : ∀i∈is,x≠a i ∧ x≠b i) : run a b op is m x=m x := by
  induction is generalizing m with
  | nil => rfl
  | cons i is ih =>
    have hh := h i (by simp)
    rw [run,ih (step a b op i m) (fun j hj => h j (List.mem_cons_of_mem i hj)),step_untouched a b op i m x hh.1 hh.2]

end DisjointPairLoop
#print axioms DisjointPairLoop.write_here
#print axioms DisjointPairLoop.write_other
#print axioms DisjointPairLoop.step_same
#print axioms DisjointPairLoop.step_other_pair
#print axioms DisjointPairLoop.step_untouched
#print axioms DisjointPairLoop.run_pair
#print axioms DisjointPairLoop.run_untouched
