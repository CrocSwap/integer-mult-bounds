import PackedModels
namespace FiniteModelChecks
open PairedWord TraceTable DagSemantics MaskRows MaskModels PackedModels

def blockCheck (p : Nat → Bool) (block : Nat) : Bool :=
  (List.range 128).all (fun offset => p (128*block+offset))

theorem blocks_sound (p : Nat → Bool) (h : (List.range 208).all (blockCheck p) = true) :
    ∀ n, n<26624 → p n=true := by
  intro n hn
  have hb : n/128<208 := by omega
  have ho : n%128<128 := by omega
  have hh := (List.all_eq_true.mp h) (n/128) (List.mem_range.mpr hb)
  have hx := (List.all_eq_true.mp hh) (n%128) (List.mem_range.mpr ho)
  have heq : 128*(n/128)+n%128=n := by omega
  simpa only [heq] using hx

def guardedRows (size : Nat) (table : Table Row) (n : Nat) : Row :=
  if n<size then TraceTable.get table n else ⟨0,0⟩

def guardedPacked (size : Nat) (table : Table Int) (n : Nat) : Int :=
  if n<size then TraceTable.get table n else 0

theorem rows_outside (width size : Nat) (g : Graph) (table : Table Row)
    (hg : ∀ n, size≤n → g.node n = .zero) (n : Nat) (hn : size≤n) :
    rowCheck width g.node (guardedRows size table) n = true := by
  simp [rowCheck, guardedRows, hg n hn, Nat.not_lt.mpr hn]

theorem packed_outside (width size : Nat) (g : Graph) (table : Table Int)
    (hg : ∀ n, size≤n → g.node n = .zero) (n : Nat) (hn : size≤n) :
    packedCheck width g.node (guardedPacked size table) n = true := by
  simp [packedCheck, guardedPacked, hg n hn, Nat.not_lt.mpr hn]

theorem full_rows_from_blocks (width size : Nat) (hs : size≤26624) (g : Graph) (table : Table Row)
    (hg : ∀ n, size≤n → g.node n = .zero)
    (hc : (List.range 208).all (blockCheck (rowCheck width g.node (guardedRows size table))) = true) :
    ∀ n, rowCheck width g.node (guardedRows size table) n = true := by
  intro n
  by_cases hn : n<26624
  · exact blocks_sound _ hc n hn
  · exact rows_outside width size g table hg n (by omega)

theorem full_packed_from_blocks (width size : Nat) (hs : size≤26624) (g : Graph) (table : Table Int)
    (hg : ∀ n, size≤n → g.node n = .zero)
    (hc : (List.range 208).all (blockCheck (packedCheck width g.node (guardedPacked size table))) = true) :
    ∀ n, packedCheck width g.node (guardedPacked size table) n = true := by
  intro n
  by_cases hn : n<26624
  · exact blocks_sound _ hc n hn
  · exact packed_outside width size g table hg n (by omega)

end FiniteModelChecks
#print axioms FiniteModelChecks.blocks_sound
#print axioms FiniteModelChecks.rows_outside
#print axioms FiniteModelChecks.packed_outside
#print axioms FiniteModelChecks.full_rows_from_blocks
#print axioms FiniteModelChecks.full_packed_from_blocks
