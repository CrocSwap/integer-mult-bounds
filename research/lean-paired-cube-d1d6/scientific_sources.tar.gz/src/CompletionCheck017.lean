import CompletionData
namespace CompletionCheck017
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch017.all CompletionCertificates.check=true := by decide
end CompletionCheck017
#print axioms CompletionCheck017.valid
