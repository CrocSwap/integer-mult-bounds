import PointMemoryLoop
import SuppliedQuarterTable
namespace CountedQuarterCoefficient
open BinarySpace24 SuppliedQuarterTable QuarterPhaseCompiler ActualPhaseEvaluation Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def lookupCounted (t : Table F) (q : TwoBitQuarter.Quarter) : F × Nat :=
  if q.2 then
    let v:=CountedConditionalSwap.selectValue q.1 t.three t.two
    (v.1,1+v.2)
  else
    let v:=CountedConditionalSwap.selectValue q.1 t.one t.zero
    (v.1,1+v.2)

theorem lookup_exact (t : Table F) (q : TwoBitQuarter.Quarter) : lookupCounted t q=(lookup t q,2) := by
  rcases q with ⟨lo,hi⟩
  cases lo <;> cases hi <;> rfl

structure Result (F : Type u) where
  value : F
  selections : Nat
  phaseCost : QuarterPhaseCompiler.Cost

def evaluate (t : Table F) (e : Expr) (r : Nat → Vec) : Result F :=
  let q:=e.run r
  let v:=lookupCounted t q.1
  ⟨v.1,v.2,q.2⟩

theorem evaluation_exact (t : Table F) (e : Expr) (r : Nat → Vec) :
    evaluate t e r=⟨lookup t (e.run r).1,2,e.cost⟩ := by
  simp only [evaluate,lookup_exact,counted_evaluation]

def left (t : Table F) (x : Vec) := evaluate t ActualQuarterPhase.leftCode (registers x (leftIntermediate x))
def right (t : Table F) (x : Vec) := evaluate t ActualQuarterPhase.rightCode
  (registers x (RootAddressInstructions.run OuterAddressCircuits.rightCode x))

theorem left_exact (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (x : Vec) :
    left t x=⟨LeftPassAddressPhase.scalar i x,2,⟨51,151,51,1,51,50⟩⟩ := by
  rw [left,evaluation_exact,ht,canonical_lookup,ActualQuarterPhase.left_value i hi,ActualQuarterPhase.left_cost]

theorem right_exact (i : F) (hi : i*i= -1) (t : Table F) (ht : t=canonical i) (x : Vec) :
    right t x=⟨RightPassAddressPhase.scalar i x,2,⟨48,147,49,0,50,49⟩⟩ := by
  rw [right,evaluation_exact,ht,canonical_lookup,ActualQuarterPhase.right_value i hi,ActualQuarterPhase.right_cost]

theorem left_receipt (t : Table F) (x : Vec) : (left t x).selections=2 ∧
    (left t x).phaseCost=⟨51,151,51,1,51,50⟩ := by
  rw [left,evaluation_exact,ActualQuarterPhase.left_cost]
  exact ⟨rfl,rfl⟩

theorem right_receipt (t : Table F) (x : Vec) : (right t x).selections=2 ∧
    (right t x).phaseCost=⟨48,147,49,0,50,49⟩ := by
  rw [right,evaluation_exact,ActualQuarterPhase.right_cost]
  exact ⟨rfl,rfl⟩

end CountedQuarterCoefficient
#print axioms CountedQuarterCoefficient.lookup_exact
#print axioms CountedQuarterCoefficient.evaluation_exact
#print axioms CountedQuarterCoefficient.left_exact
#print axioms CountedQuarterCoefficient.right_exact
#print axioms CountedQuarterCoefficient.left_receipt
#print axioms CountedQuarterCoefficient.right_receipt
