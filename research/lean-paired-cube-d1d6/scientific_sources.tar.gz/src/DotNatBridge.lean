import CompletionFrames
namespace DotNatBridge
open BinarySpace24 CompletionFrames

theorem dot_fromNat (x y : Nat) : dot (fromNat x) (fromNat y)=BinaryPort.dot 24 x y := by
  change dotList [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23] (fromNat x) (fromNat y)=_
  simp only [dotList,fromNat,BinaryPort.dot]
  simp only [Bool.xor_assoc,Bool.false_xor,Bool.xor_false]
  rfl

end DotNatBridge
#print axioms DotNatBridge.dot_fromNat
