import FrameSpan
namespace BinaryPort
open BinaryFrame

def dot : Nat → Nat → Nat → Bool
  | 0, _, _ => false
  | n+1, q, x => Bool.xor (dot n q x) (q.testBit n && x.testBit n)

theorem dot_zero (width q : Nat) : dot width q 0=false := by
  induction width with
  | zero => rfl
  | succ n ih => simp [dot, ih]

theorem dot_xor (width q x y : Nat) :
    dot width q (x ^^^ y) = Bool.xor (dot width q x) (dot width q y) := by
  induction width with
  | zero => rfl
  | succ n ih =>
    simp only [dot, ih, Nat.testBit_xor]
    cases dot n q x <;> cases dot n q y <;> cases q.testBit n <;>
      cases x.testBit n <;> cases y.testBit n <;> rfl

theorem dot_symmetric (width q x : Nat) : dot width q x=dot width x q := by
  induction width with
  | zero => rfl
  | succ n ih => simp only [dot, ih, Bool.and_comm]

theorem span_orthogonal (width q : Nat) (basis : List Nat)
    (h : ∀ b ∈ basis, dot width q b=false) :
    ∀ x, Span basis x → dot width q x=false := by
  intro x hx
  induction hx with
  | zero => exact dot_zero width q
  | generator hb => exact h _ hb
  | add hx hy ihx ihy => rw [dot_xor, ihx, ihy]; rfl

end BinaryPort
#print axioms BinaryPort.dot_zero
#print axioms BinaryPort.dot_xor
#print axioms BinaryPort.dot_symmetric
#print axioms BinaryPort.span_orthogonal
