import CanonicalGramRecipe
import CommonExactFrame
namespace CanonicalFourthRootLift
open BinarySpace24 FourthRootRecipe FourthRootLift CanonicalGramRecipe Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def S (i : F) (f : Vec → F) (x : Vec) : F := coordinatePhase i x*f x
def permutation (c : Chart) (f : Vec → F) (y : Vec) : F := f (c.inverse y)
def K (i : F) (c : Chart) : (Vec → F) → (Vec → F) := lift i c (terms c)
def Kinv (i : F) (c : Chart) : (Vec → F) → (Vec → F) := unlift i c (terms c)

theorem exact_S_permutation_S_inverse (i : F) (c : Chart) (f : Vec → F) :
    K i c f=S i (permutation c (S (-i) f)) := by
  funext y
  simp only [K,lift,canonical_phase_formula,c.inverse_right,S,permutation,Semiring.mul_assoc]

theorem S_inverse_left (i : F) (hi : i*i= -1) (f : Vec → F) : S (-i) (S i f)=f := by
  funext x
  simp only [S,← Semiring.mul_assoc,coordinate_phase_inverse i hi,Semiring.one_mul]

theorem K_inverse_left (i : F) (hi : i*i= -1) (c : Chart) (f : Vec → F) : Kinv i c (K i c f)=f :=
  FourthRootLift.inverse_left i hi c _ f

theorem K_inverse_right (i : F) (hi : i*i= -1) (c : Chart) (f : Vec → F) : K i c (Kinv i c f)=f :=
  FourthRootLift.inverse_right i hi c _ f

theorem K_add (i : F) (c : Chart) (f g : Vec → F) : K i c (fun x => f x+g x)=fun y => K i c f y+K i c g y :=
  FourthRootLift.lift_add i c _ f g

theorem K_scale (i : F) (c : Chart) (s : F) (f : Vec → F) : K i c (fun x => s*f x)=fun y => s*K i c f y :=
  FourthRootLift.lift_scale i c _ s f

theorem K_Pauli (i : F) (hi : i*i= -1) (c : Chart) (u z : Vec) (f : Vec → F) :
    K i c (ExactQuadraticLift.pauli u z (Kinv i c f))=
      fun y => (coordinatePhase (-i) (c.forward u)*coordinatePhase i u)*
        ExactQuadraticLift.pauli (label c (u,z)).1 (label c (u,z)).2 f y := by
  change lift i c (terms c) (ExactQuadraticLift.pauli u z (unlift i c (terms c) f))=_
  rw [FourthRootLift.pauli_conjugation i hi c (terms c) (canonical_gram_compatible c),canonical_inverse_phase_formula]

theorem K_scalar_fourth (i : F) (hi : i*i= -1) (c : Chart) (u : Vec) :
    let a := coordinatePhase (-i) (c.forward u)*coordinatePhase i u
    (a*a)*(a*a)=1 := by
  rw [← canonical_inverse_phase_formula]
  exact pauli_scalar_fourth i hi _ u

def exactFrame (i : F) (hi : i*i= -1) (c : Chart) : CommonExactFrame.ExactFrame Vec F where
  encode := K i c
  decode := Kinv i c
  left_inverse := K_inverse_left i hi c
  right_inverse := K_inverse_right i hi c
  add_linear := K_add i c
  scale_linear := K_scale i c

theorem root_not_real_sign (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) : i≠1 ∧ i≠ -1 := by
  have h2 : (2:F)=1+1 := Semiring.ofNat_add 1 1
  rw [h2] at htwo
  have hn : (1:F)≠ -1 := by
    intro h
    apply htwo
    calc
      1+1 = (-1)+1 := congrArg (fun x : F => x+1) h
      _ = 0 := Ring.neg_add_cancel 1
  constructor
  · intro he
    rw [he,Semiring.one_mul] at hi
    exact hn hi
  · intro he
    have hm : (-1:F)*(-1)=1 := by
      rw [Ring.neg_mul,Ring.mul_neg,Semiring.one_mul,Ring.neg_neg]
    rw [he,hm] at hi
    exact hn hi

end CanonicalFourthRootLift
#print axioms CanonicalFourthRootLift.exact_S_permutation_S_inverse
#print axioms CanonicalFourthRootLift.S_inverse_left
#print axioms CanonicalFourthRootLift.K_inverse_left
#print axioms CanonicalFourthRootLift.K_inverse_right
#print axioms CanonicalFourthRootLift.K_add
#print axioms CanonicalFourthRootLift.K_scale
#print axioms CanonicalFourthRootLift.K_Pauli
#print axioms CanonicalFourthRootLift.K_scalar_fourth
#print axioms CanonicalFourthRootLift.root_not_real_sign
