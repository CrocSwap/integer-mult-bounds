import BitTranspositionProgram
namespace BitTranspositionSoundness
open BinarySpace24 BinaryPairEnumeration BinaryCompletion BitTranspositionProgram
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

theorem step_memory (a : Spec) (s : PairLoadStoreMachine.State Vec V) :
    (BitSwapCounter.execute a.permutation s).1.memory=fun x=>s.memory (IndexTransposition.address a.a a.b x) := by
  apply Eq.trans (BitSwapCounter.execute_memory a.permutation s)
  funext x
  exact congrArg s.memory (IndexTransposition.transported_exact a.permutation a.a a.b a.facts.first a.facts.second x)

theorem run_eq_generic (as : List Spec) (x : Vec) :
    run as x=GenericReverseMachine.run (fun a : Spec=>IndexTransposition.address a.a a.b) as x := by
  induction as generalizing x with
  | nil => rfl
  | cons a as ih => simp only [run,GenericReverseMachine.run,ih]

theorem program_memory (as : List Spec) (s : PairLoadStoreMachine.State Vec V) :
    (program as s).1.memory=fun x=>s.memory (run as x) := by
  have h:=GenericReverseMachine.memory (fun a : Spec=>BitSwapCounter.execute a.permutation)
    BitSwapCounter.Cost.zero BitSwapCounter.Cost.add
    (fun a : Spec=>IndexTransposition.address a.a a.b) step_memory as s
  simp only [← run_eq_generic] at h
  exact h

theorem equal_bits_preserved (a : Spec) (s : PairLoadStoreMachine.State Vec V) (x : Vec) (h : x a.a=x a.b) :
    (BitSwapCounter.execute a.permutation s).1.memory x=s.memory x := by
  have hm:=congrFun (step_memory a s) x
  have hx : IndexTransposition.address a.a a.b x=x := by
    funext j
    by_cases hja : j=a.a <;> by_cases hjb : j=a.b <;>
      simp_all [IndexTransposition.address,IndexTransposition.exchange]
  exact hm.trans (congrArg s.memory hx)

end BitTranspositionSoundness
#print axioms BitTranspositionSoundness.step_memory
#print axioms BitTranspositionSoundness.run_eq_generic
#print axioms BitTranspositionSoundness.program_memory
#print axioms BitTranspositionSoundness.equal_bits_preserved
