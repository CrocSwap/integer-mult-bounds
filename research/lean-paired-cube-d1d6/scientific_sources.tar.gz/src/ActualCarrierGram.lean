import ActualCarrierCharts
namespace ActualCarrierGram
open ActualCarrierCharts BinaryPort
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

def gramCheck (cube : List Nat) : Bool :=
  [false,true].all (fun parity => (List.range 3).all (fun j =>
    (List.range 3).all (fun k => dot 24 (q cube parity j) (q cube parity k))))

def batch000 : List (List Nat) := [ActualInputCubes.cube000, ActualInputCubes.cube001, ActualInputCubes.cube002, ActualInputCubes.cube003, ActualInputCubes.cube004, ActualInputCubes.cube005, ActualInputCubes.cube006, ActualInputCubes.cube007, ActualInputCubes.cube008, ActualInputCubes.cube009, ActualInputCubes.cube010, ActualInputCubes.cube011, ActualInputCubes.cube012, ActualInputCubes.cube013, ActualInputCubes.cube014, ActualInputCubes.cube015]
theorem batch000_valid : batch000.all gramCheck=true := by decide

def batch001 : List (List Nat) := [ActualInputCubes.cube016, ActualInputCubes.cube017, ActualInputCubes.cube018, ActualInputCubes.cube019, ActualInputCubes.cube020, ActualInputCubes.cube021, ActualInputCubes.cube022, ActualInputCubes.cube023, ActualInputCubes.cube024, ActualInputCubes.cube025, ActualInputCubes.cube026, ActualInputCubes.cube027, ActualInputCubes.cube028, ActualInputCubes.cube029, ActualInputCubes.cube030, ActualInputCubes.cube031]
theorem batch001_valid : batch001.all gramCheck=true := by decide

def batch002 : List (List Nat) := [ActualInputCubes.cube032, ActualInputCubes.cube033, ActualInputCubes.cube034, ActualInputCubes.cube035, ActualInputCubes.cube036, ActualInputCubes.cube037, ActualInputCubes.cube038, ActualInputCubes.cube039, ActualInputCubes.cube040, ActualInputCubes.cube041, ActualInputCubes.cube042, ActualInputCubes.cube043, ActualInputCubes.cube044, ActualInputCubes.cube045, ActualInputCubes.cube046, ActualInputCubes.cube047]
theorem batch002_valid : batch002.all gramCheck=true := by decide

def batch003 : List (List Nat) := [ActualInputCubes.cube048, ActualInputCubes.cube049, ActualInputCubes.cube050, ActualInputCubes.cube051, ActualInputCubes.cube052, ActualInputCubes.cube053, ActualInputCubes.cube054, ActualInputCubes.cube055, ActualInputCubes.cube056, ActualInputCubes.cube057, ActualInputCubes.cube058, ActualInputCubes.cube059, ActualInputCubes.cube060, ActualInputCubes.cube061, ActualInputCubes.cube062, ActualInputCubes.cube063]
theorem batch003_valid : batch003.all gramCheck=true := by decide

def batch004 : List (List Nat) := [ActualInputCubes.cube064, ActualInputCubes.cube065, ActualInputCubes.cube066, ActualInputCubes.cube067, ActualInputCubes.cube068, ActualInputCubes.cube069, ActualInputCubes.cube070, ActualInputCubes.cube071, ActualInputCubes.cube072, ActualInputCubes.cube073, ActualInputCubes.cube074, ActualInputCubes.cube075, ActualInputCubes.cube076, ActualInputCubes.cube077, ActualInputCubes.cube078, ActualInputCubes.cube079]
theorem batch004_valid : batch004.all gramCheck=true := by decide

def batch005 : List (List Nat) := [ActualInputCubes.cube080, ActualInputCubes.cube081, ActualInputCubes.cube082, ActualInputCubes.cube083, ActualInputCubes.cube084, ActualInputCubes.cube085, ActualInputCubes.cube086, ActualInputCubes.cube087, ActualInputCubes.cube088, ActualInputCubes.cube089, ActualInputCubes.cube090, ActualInputCubes.cube091, ActualInputCubes.cube092, ActualInputCubes.cube093, ActualInputCubes.cube094, ActualInputCubes.cube095]
theorem batch005_valid : batch005.all gramCheck=true := by decide

def batch006 : List (List Nat) := [ActualInputCubes.cube096, ActualInputCubes.cube097, ActualInputCubes.cube098, ActualInputCubes.cube099, ActualInputCubes.cube100, ActualInputCubes.cube101, ActualInputCubes.cube102, ActualInputCubes.cube103, ActualInputCubes.cube104, ActualInputCubes.cube105, ActualInputCubes.cube106, ActualInputCubes.cube107, ActualInputCubes.cube108, ActualInputCubes.cube109, ActualInputCubes.cube110, ActualInputCubes.cube111]
theorem batch006_valid : batch006.all gramCheck=true := by decide

def batch007 : List (List Nat) := [ActualInputCubes.cube112, ActualInputCubes.cube113, ActualInputCubes.cube114, ActualInputCubes.cube115, ActualInputCubes.cube116, ActualInputCubes.cube117, ActualInputCubes.cube118, ActualInputCubes.cube119, ActualInputCubes.cube120, ActualInputCubes.cube121, ActualInputCubes.cube122, ActualInputCubes.cube123, ActualInputCubes.cube124, ActualInputCubes.cube125, ActualInputCubes.cube126, ActualInputCubes.cube127]
theorem batch007_valid : batch007.all gramCheck=true := by decide

def batch008 : List (List Nat) := [ActualInputCubes.cube128, ActualInputCubes.cube129, ActualInputCubes.cube130, ActualInputCubes.cube131, ActualInputCubes.cube132, ActualInputCubes.cube133, ActualInputCubes.cube134, ActualInputCubes.cube135, ActualInputCubes.cube136, ActualInputCubes.cube137, ActualInputCubes.cube138, ActualInputCubes.cube139, ActualInputCubes.cube140, ActualInputCubes.cube141, ActualInputCubes.cube142, ActualInputCubes.cube143]
theorem batch008_valid : batch008.all gramCheck=true := by decide

def batch009 : List (List Nat) := [ActualInputCubes.cube144, ActualInputCubes.cube145, ActualInputCubes.cube146, ActualInputCubes.cube147, ActualInputCubes.cube148, ActualInputCubes.cube149, ActualInputCubes.cube150, ActualInputCubes.cube151, ActualInputCubes.cube152, ActualInputCubes.cube153, ActualInputCubes.cube154, ActualInputCubes.cube155, ActualInputCubes.cube156, ActualInputCubes.cube157, ActualInputCubes.cube158, ActualInputCubes.cube159]
theorem batch009_valid : batch009.all gramCheck=true := by decide

def batch010 : List (List Nat) := [ActualInputCubes.cube160, ActualInputCubes.cube161, ActualInputCubes.cube162, ActualInputCubes.cube163, ActualInputCubes.cube164, ActualInputCubes.cube165, ActualInputCubes.cube166, ActualInputCubes.cube167, ActualInputCubes.cube168, ActualInputCubes.cube169, ActualInputCubes.cube170, ActualInputCubes.cube171, ActualInputCubes.cube172, ActualInputCubes.cube173, ActualInputCubes.cube174, ActualInputCubes.cube175]
theorem batch010_valid : batch010.all gramCheck=true := by decide

def batch011 : List (List Nat) := [ActualInputCubes.cube176, ActualInputCubes.cube177, ActualInputCubes.cube178, ActualInputCubes.cube179, ActualInputCubes.cube180, ActualInputCubes.cube181, ActualInputCubes.cube182, ActualInputCubes.cube183, ActualInputCubes.cube184, ActualInputCubes.cube185, ActualInputCubes.cube186, ActualInputCubes.cube187, ActualInputCubes.cube188, ActualInputCubes.cube189, ActualInputCubes.cube190, ActualInputCubes.cube191]
theorem batch011_valid : batch011.all gramCheck=true := by decide

def batch012 : List (List Nat) := [ActualInputCubes.cube192, ActualInputCubes.cube193, ActualInputCubes.cube194, ActualInputCubes.cube195, ActualInputCubes.cube196, ActualInputCubes.cube197, ActualInputCubes.cube198, ActualInputCubes.cube199, ActualInputCubes.cube200, ActualInputCubes.cube201, ActualInputCubes.cube202, ActualInputCubes.cube203, ActualInputCubes.cube204, ActualInputCubes.cube205, ActualInputCubes.cube206, ActualInputCubes.cube207]
theorem batch012_valid : batch012.all gramCheck=true := by decide

def batch013 : List (List Nat) := [ActualInputCubes.cube208, ActualInputCubes.cube209, ActualInputCubes.cube210, ActualInputCubes.cube211, ActualInputCubes.cube212, ActualInputCubes.cube213, ActualInputCubes.cube214, ActualInputCubes.cube215, ActualInputCubes.cube216, ActualInputCubes.cube217, ActualInputCubes.cube218, ActualInputCubes.cube219]
theorem batch013_valid : batch013.all gramCheck=true := by decide

theorem all_valid : ActualInputCubes.cubes.all gramCheck=true := by
  change (batch000 ++ batch001 ++ batch002 ++ batch003 ++ batch004 ++ batch005 ++ batch006 ++ batch007 ++ batch008 ++ batch009 ++ batch010 ++ batch011 ++ batch012 ++ batch013 ++ []).all gramCheck=true
  simp only [List.all_append,List.all_nil,batch000_valid,batch001_valid,batch002_valid,batch003_valid,batch004_valid,batch005_valid,batch006_valid,batch007_valid,batch008_valid,batch009_valid,batch010_valid,batch011_valid,batch012_valid,batch013_valid,Bool.and_self]

theorem actual_gram (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool)
    (j k : Nat) (hj : j<3) (hk : k<3) : dot 24 (q cube parity j) (q cube parity k)=true := by
  have h := (List.all_eq_true.mp all_valid) cube hc
  have hp : parity ∈ [false,true] := by cases parity <;> simp
  have hparity := List.all_eq_true.mp h parity hp
  have hrow := List.all_eq_true.mp hparity j (List.mem_range.mpr hj)
  exact List.all_eq_true.mp hrow k (List.mem_range.mpr hk)

def gramDefect (cube : List Nat) (parity : Bool) (j k : Nat) : Bool :=
  dot 24 (q cube parity j) (q cube parity k) ^^ decide (j=k)

theorem actual_gram_defect (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool)
    (j k : Nat) (hj : j<3) (hk : k<3) : gramDefect cube parity j k=decide (j≠k) := by
  rw [gramDefect,actual_gram cube hc parity j k hj hk]
  by_cases he : j=k <;> simp [he]

end ActualCarrierGram
#print axioms ActualCarrierGram.batch000_valid
#print axioms ActualCarrierGram.batch001_valid
#print axioms ActualCarrierGram.batch002_valid
#print axioms ActualCarrierGram.batch003_valid
#print axioms ActualCarrierGram.batch004_valid
#print axioms ActualCarrierGram.batch005_valid
#print axioms ActualCarrierGram.batch006_valid
#print axioms ActualCarrierGram.batch007_valid
#print axioms ActualCarrierGram.batch008_valid
#print axioms ActualCarrierGram.batch009_valid
#print axioms ActualCarrierGram.batch010_valid
#print axioms ActualCarrierGram.batch011_valid
#print axioms ActualCarrierGram.batch012_valid
#print axioms ActualCarrierGram.batch013_valid
#print axioms ActualCarrierGram.all_valid
#print axioms ActualCarrierGram.actual_gram
#print axioms ActualCarrierGram.actual_gram_defect
