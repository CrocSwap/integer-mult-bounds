import CubeCorrection
namespace CubeGeometry
open PairedCubeIdentities

def bitCount : Nat → Nat → Nat
  | 0, _ => 0
  | width+1, n => n%2 + bitCount width (n/2)

def inputDistance (inputs : List Nat) (i j : Nat) : Nat :=
  bitCount 24 ((inputs[i]?.getD 0) ^^^ (inputs[j]?.getD 0))

def cubeCheck (inputs : List Nat) : Bool :=
  decide (inputs.length=8) && inputs.all (fun x => decide (x<2^24)) &&
    (List.range 8).all (fun i => (List.range 8).all (fun j =>
      decide (inputDistance inputs i j = 2*distance i j)))

theorem checked_distance (inputs : List Nat) (h : cubeCheck inputs = true)
    (i j : Nat) (hi : i<8) (hj : j<8) : inputDistance inputs i j = 2*distance i j := by
  have hh := Bool.and_eq_true_iff.mp h
  exact of_decide_eq_true ((List.all_eq_true.mp ((List.all_eq_true.mp hh.2) i (List.mem_range.mpr hi))) j (List.mem_range.mpr hj))

def inputK2 (inputs : List Nat) (i j : Nat) : Int :=
  if inputDistance inputs i j = 6 then 1 else if inputDistance inputs i j = 2 then -1 else 0

theorem checked_matrix (inputs : List Nat) (h : cubeCheck inputs = true)
    (i j : Nat) (hi : i<8) (hj : j<8) : inputK2 inputs i j = k2 i j := by
  have hd := checked_distance inputs h i j hi hj
  have h3 : 2*distance i j = 6 ↔ distance i j=3 := by omega
  have h1 : 2*distance i j = 2 ↔ distance i j=1 := by omega
  simp only [inputK2, hd, h3, h1, k2]

theorem checked_shape (inputs : List Nat) (h : cubeCheck inputs = true) :
    inputs.length=8 ∧ ∀ x ∈ inputs, x<2^24 := by
  have hh := Bool.and_eq_true_iff.mp (Bool.and_eq_true_iff.mp h).1
  exact ⟨of_decide_eq_true hh.1, fun x hx => of_decide_eq_true ((List.all_eq_true.mp hh.2) x hx)⟩

end CubeGeometry
#print axioms CubeGeometry.checked_distance
#print axioms CubeGeometry.checked_matrix
#print axioms CubeGeometry.checked_shape
