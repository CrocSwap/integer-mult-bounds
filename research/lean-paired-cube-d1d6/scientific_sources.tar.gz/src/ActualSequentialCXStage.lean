import SequentialCXLoop
namespace ActualSequentialCXStage
open BinarySpace24 BinaryPairEnumeration CoordinateScheduleTransport SequentialCXKernel SequentialCXLoop Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

@[irreducible] def stage (t c : Index) (s : State Vec F) :=
  loop (ConditionalCXPair.control (index t c)) (embed t false) (embed t true) (addresses 23) s

theorem memory_exact (t c : Index) (hc : c≠t) (s : State Vec F) :
    (stage t c s).1.work.memory=fun x=>s.work.memory (Q21AddressProgram.execute ⟨c,t⟩ x) := by
  rw [stage,loop_memory]
  apply TransportedCXSemantics.from_pairs t c hc
  intro k
  have h:=IndexedPairLoop.run_pair (embed t false) (embed t true) (geometry t)
    (fun k=>ConditionalCXPair.swapIf (ConditionalCXPair.control (index t c) k))
    (addresses 23) (addresses_nodup 23) s.work.memory k
  rw [if_pos (all_addresses 23 k)] at h
  exact h

theorem stage_receipt (t c : Index) (s : State Vec F) :
    (stage t c s).2=⟨16777216,16777216,8388608,16777216⟩ := by
  rw [stage,loop_cost,Coordinate21Pairs.pair_count]
  rfl

end ActualSequentialCXStage
#print axioms ActualSequentialCXStage.memory_exact
#print axioms ActualSequentialCXStage.stage_receipt
