import CompletionData
namespace CompletionCheck014
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch014.all CompletionCertificates.check=true := by decide
end CompletionCheck014
#print axioms CompletionCheck014.valid
