import FrameLogicalWord
namespace FiniteWordTransport
open CommonExactFrame ExactTransportTrace FrameLogicalStep FrameLogicalWord Lean.Grind BinarySpace24
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def finalKeys (g : GaugeKeyTrace.State) := GaugeKeyTrace.run PairedWordData.word g

def physical (select : Nat → ExactFrame Vec F) (g : GaugeKeyTrace.State) (v : Arrays Vec F) :=
  ExactTransportTrace.run select PairedWordData.word g v

def decodedState (select : Nat → ExactFrame Vec F) (g : GaugeKeyTrace.State) (v : Arrays Vec F) (x : Vec) : Nat → F :=
  fun r => decode select (finalKeys g) (physical select g (encode select g v)).2 r x

theorem actual_word_length : PairedWordData.word.length=49424 := PairedWordData.word_length

theorem actual_commuting (select : Nat → ExactFrame Vec F) (g : GaugeKeyTrace.State) (v : Arrays Vec F) :
    physical select g (encode select g v)=
      (finalKeys g,encode select (finalKeys g) (fun r x => FieldWordTrace.run PairedWordData.word (fun j => v j x) r)) :=
  run_correct_pointwise select PairedWordData.word g v

theorem decoded_state_eq (select : Nat → ExactFrame Vec F) (g : GaugeKeyTrace.State) (v : Arrays Vec F) (x : Vec) :
    decodedState select g v x=FieldWordTrace.run PairedWordData.word (fun j => v j x) := by
  funext r
  exact decoded_run_pointwise select PairedWordData.word g v r x

theorem arbitrary_entrance_decoded (select : Nat → ExactFrame Vec F) (g : GaugeKeyTrace.State) (v : Arrays Vec F) :
    decode select (finalKeys g) (physical select g v).2=
      fun r x => FieldWordTrace.run PairedWordData.word (fun j => decode select g v j x) r := by
  rw [physical,finalKeys,arbitrary_entrance,logical_as_field_run]

end FiniteWordTransport
#print axioms FiniteWordTransport.actual_word_length
#print axioms FiniteWordTransport.actual_commuting
#print axioms FiniteWordTransport.decoded_state_eq
#print axioms FiniteWordTransport.arbitrary_entrance_decoded
