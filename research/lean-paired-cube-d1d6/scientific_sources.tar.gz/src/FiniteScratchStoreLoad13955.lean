import ScratchRestoreContract13955

namespace FiniteScratchStoreLoad13955

open ScratchRestoreContract13955

abbrev Registers (n : Nat) (V : Type v) := Fin n → V
abbrev Machine (P : Type u) (V : Type v) (n : Nat) :=
  SpilledState P (Registers n V)

variable {P : Type u} {V : Type v} {n : Nat}

/-- Scratch registers and spill cells are distinct banks, with n cells in each. -/
inductive Instruction (n : Nat) where
  | storeSpill (i : Fin n)
  | loadSpill (i : Fin n)
  deriving DecidableEq

def write (r : Registers n V) (i : Fin n) (value : V) : Registers n V :=
  fun j => if j = i then value else r j

def execute : Instruction n → Machine P V n → Machine P V n
  | .storeSpill i, s => (s.1, write s.2 i (s.1.2 i))
  | .loadSpill i, s => ((s.1.1, write s.1.2 i (s.2 i)), s.2)

def run : List (Instruction n) → Machine P V n → Machine P V n
  | [], s => s
  | i :: code, s => run code (execute i s)

/-- The source bank is live and unchanged while each destination cell is written. -/
def copyCells : List (Fin n) → Registers n V → Registers n V → Registers n V
  | [], _, dst => dst
  | i :: rest, src, dst => copyCells rest src (write dst i (src i))

def saveCode (n : Nat) : List (Instruction n) :=
  (List.finRange n).map Instruction.storeSpill

def restoreCode (n : Nat) : List (Instruction n) :=
  (List.finRange n).map Instruction.loadSpill

theorem write_same (r : Registers n V) (i : Fin n) (value : V) :
    write r i value i = value := by simp [write]

theorem write_other (r : Registers n V) (i j : Fin n) (value : V) (hne : j ≠ i) :
    write r i value j = r j := by simp [write, hne]

theorem run_append (a b : List (Instruction n)) (s : Machine P V n) :
    run (a ++ b) s = run b (run a s) := by
  induction a generalizing s with
  | nil => rfl
  | cons i rest ih => simp only [List.cons_append, run, ih]

theorem copyCells_value (is : List (Fin n)) (src dst : Registers n V) (j : Fin n) :
    copyCells is src dst j = if j ∈ is then src j else dst j := by
  induction is generalizing dst with
  | nil => simp [copyCells]
  | cons i rest ih =>
    rw [copyCells, ih]
    by_cases hj : j ∈ rest
    · simp [hj]
    · by_cases he : j = i
      · subst j; simp [hj, write]
      · simp [hj, he, write]

theorem copyCells_complete (is : List (Fin n)) (hcover : ∀ i, i ∈ is)
    (src dst : Registers n V) : copyCells is src dst = src := by
  funext i
  simp [copyCells_value, hcover i]

theorem finRange_covers (i : Fin n) : i ∈ List.finRange n := by
  apply List.mem_ofFn.mpr
  exact ⟨i, rfl⟩

theorem copyCells_all (src dst : Registers n V) :
    copyCells (List.finRange n) src dst = src :=
  copyCells_complete _ finRange_covers src dst

theorem store_program_exact (is : List (Fin n)) (s : Machine P V n) :
    run (is.map Instruction.storeSpill) s = (s.1, copyCells is s.1.2 s.2) := by
  induction is generalizing s with
  | nil => rfl
  | cons i rest ih => simp only [List.map_cons, run, execute, ih, copyCells]

theorem load_program_exact (is : List (Fin n)) (s : Machine P V n) :
    run (is.map Instruction.loadSpill) s = ((s.1.1, copyCells is s.2 s.1.2), s.2) := by
  induction is generalizing s with
  | nil => rfl
  | cons i rest ih => simp only [List.map_cons, run, execute, ih, copyCells]

theorem save_implements_copySave (s : Machine P V n) :
    run (saveCode n) s = copySave s := by
  rw [saveCode, store_program_exact, copyCells_all]
  rfl

theorem restore_implements_copyRestore (s : Machine P V n) :
    run (restoreCode n) s = copyRestore s := by
  rw [restoreCode, load_program_exact, copyCells_all]
  rfl

theorem save_code_length : (saveCode n).length = n := by
  simp [saveCode]

theorem restore_code_length : (restoreCode n).length = n := by
  simp [restoreCode]

/-- The complete caller-state operation is bracketed by real per-cell instructions. -/
def implementedWrapper (body : Machine P V n → Machine P V n) (s : Machine P V n) :
    Machine P V n := run (restoreCode n) (body (run (saveCode n) s))

theorem implementedWrapper_matches (body : Machine P V n → Machine P V n)
    (s : Machine P V n) : implementedWrapper body s = wrapped body s := by
  simp only [implementedWrapper, save_implements_copySave, restore_implements_copyRestore,
    wrapped]

theorem implementedWrapper_exact (body : Machine P V n → Machine P V n)
    (hbody : PreservesSpill body) (s : Machine P V n) :
    implementedWrapper body s = (((body (copySave s)).1.1, s.1.2), s.1.2) := by
  rw [implementedWrapper_matches, wrapper_exact body hbody]

theorem implementedWrapper_spill_obstruction (body : Machine P V n → Machine P V n)
    (hbody : PreservesSpill body) (s : Machine P V n) :
    (implementedWrapper body s).2 = s.2 ↔ s.1.2 = s.2 := by
  rw [implementedWrapper_matches, original_spill_preserved_iff body hbody]

end FiniteScratchStoreLoad13955

#print axioms FiniteScratchStoreLoad13955.write_same
#print axioms FiniteScratchStoreLoad13955.write_other
#print axioms FiniteScratchStoreLoad13955.run_append
#print axioms FiniteScratchStoreLoad13955.copyCells_value
#print axioms FiniteScratchStoreLoad13955.copyCells_complete
#print axioms FiniteScratchStoreLoad13955.finRange_covers
#print axioms FiniteScratchStoreLoad13955.copyCells_all
#print axioms FiniteScratchStoreLoad13955.store_program_exact
#print axioms FiniteScratchStoreLoad13955.load_program_exact
#print axioms FiniteScratchStoreLoad13955.save_implements_copySave
#print axioms FiniteScratchStoreLoad13955.restore_implements_copyRestore
#print axioms FiniteScratchStoreLoad13955.save_code_length
#print axioms FiniteScratchStoreLoad13955.restore_code_length
#print axioms FiniteScratchStoreLoad13955.implementedWrapper_matches
#print axioms FiniteScratchStoreLoad13955.implementedWrapper_exact
#print axioms FiniteScratchStoreLoad13955.implementedWrapper_spill_obstruction
