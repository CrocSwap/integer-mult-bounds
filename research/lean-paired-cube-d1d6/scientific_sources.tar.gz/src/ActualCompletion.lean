import CompletionCheck000
import CompletionCheck001
import CompletionCheck002
import CompletionCheck003
import CompletionCheck004
import CompletionCheck005
import CompletionCheck006
import CompletionCheck007
import CompletionCheck008
import CompletionCheck009
import CompletionCheck010
import CompletionCheck011
import CompletionCheck012
import CompletionCheck013
import CompletionCheck014
import CompletionCheck015
import CompletionCheck016
import CompletionCheck017
import CompletionCheck018
import CompletionCheck019
import CompletionCheck020
import CompletionCheck021
import CompletionCheck022
import CompletionCheck023
import CompletionCheck024
import CompletionCheck025
import CompletionCheck026
import CompletionCheck027
import CompletionColumns
import DotNatBridge
namespace ActualCompletion
open CompletionCertificates CompletionData BinaryCompletion CompletionFrames BinarySpace24
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem all_valid : certificates.all check=true := by
  simp only [certificates,List.all_flatten,batches,List.all_cons,List.all_nil,CompletionCheck000.valid, CompletionCheck001.valid, CompletionCheck002.valid, CompletionCheck003.valid, CompletionCheck004.valid, CompletionCheck005.valid, CompletionCheck006.valid, CompletionCheck007.valid, CompletionCheck008.valid, CompletionCheck009.valid, CompletionCheck010.valid, CompletionCheck011.valid, CompletionCheck012.valid, CompletionCheck013.valid, CompletionCheck014.valid, CompletionCheck015.valid, CompletionCheck016.valid, CompletionCheck017.valid, CompletionCheck018.valid, CompletionCheck019.valid, CompletionCheck020.valid, CompletionCheck021.valid, CompletionCheck022.valid, CompletionCheck023.valid, CompletionCheck024.valid, CompletionCheck025.valid, CompletionCheck026.valid, CompletionCheck027.valid,Bool.true_and]

theorem count : certificates.length=440 := by decide

theorem source_projection : certificates.map (fun c => (c.cube,c.parity))=
    ActualInputCubes.cubes.flatMap (fun cube => [(cube,false),(cube,true)]) := by decide

theorem source_member (c : Witness) (hc : c ∈ certificates) : c.cube ∈ ActualInputCubes.cubes := by
  have hm : (c.cube,c.parity) ∈ certificates.map (fun c => (c.cube,c.parity)) := List.mem_map.mpr ⟨c,hc,rfl⟩
  rw [source_projection] at hm
  rcases List.mem_flatMap.mp hm with ⟨cube,hcube,hpair⟩
  simp at hpair
  rcases hpair with h | h <;> rcases h with ⟨he,hp⟩ <;> simpa [he] using hcube

theorem source_coverage (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    ∃ c ∈ certificates, c.cube=cube ∧ c.parity=parity := by
  have hm : (cube,parity) ∈ certificates.map (fun c => (c.cube,c.parity)) := by
    rw [source_projection]
    apply List.mem_flatMap.mpr
    refine ⟨cube,hc,?_⟩
    cases parity <;> simp
  rcases List.mem_map.mp hm with ⟨c,hc',he⟩
  exact ⟨c,hc',congrArg Prod.fst he,congrArg Prod.snd he⟩

def facts (c : Witness) (hc : c ∈ certificates) : Facts c :=
  check_sound c (List.all_eq_true.mp all_valid c hc)

theorem all_full_inverses (c : Witness) (hc : c ∈ certificates) (x : Vec) :
    fullInverse c (facts c hc) (fullMap c (facts c hc) x)=x ∧
    fullMap c (facts c hc) (fullInverse c (facts c hc) x)=x :=
  ⟨full_inverse_left c _ x,full_inverse_right c _ x⟩

theorem all_source_columns (c : Witness) (hc : c ∈ certificates) (axis : TensorThree.Axis) :
    fullMap c (facts c hc) (unit (index axis))=vector c axis := source_columns c _ axis

theorem all_complement_columns (c : Witness) (hc : c ∈ certificates) (j : Index) (hj : 3≤j.val) :
    fullMap c (facts c hc) (unit j)=unit (forward c j) := CompletionColumns.complement_columns c _ j hj

theorem all_source_frames (c : Witness) (hc : c ∈ certificates) (v : Vec × Vec) :
    Frame (ActualCarrier c) (blockMap c (facts c hc) v) ↔ Frame CoordinateSpace v :=
  actual_carrier_frame c _ (source_member c hc) v

theorem all_block_symplectic (c : Witness) (hc : c ∈ certificates) (v w : Vec × Vec) :
    symplectic (blockMap c (facts c hc) v) (blockMap c (facts c hc) w)=symplectic v w :=
  block_symplectic c _ v w

theorem actual_completion (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    ∃ c, c.cube=cube ∧ c.parity=parity ∧ ∃ h : Facts c,
      (∀ x, fullInverse c h (fullMap c h x)=x ∧ fullMap c h (fullInverse c h x)=x) ∧
      (∀ axis, fullMap c h (unit (index axis))=vector c axis) ∧
      (∀ v, Frame (ActualCarrier c) (blockMap c h v) ↔ Frame CoordinateSpace v) := by
  rcases source_coverage cube hc parity with ⟨c,hm,he,hp⟩
  exact ⟨c,he,hp,facts c hm,all_full_inverses c hm,all_source_columns c hm,all_source_frames c hm⟩

end ActualCompletion
#print axioms ActualCompletion.all_valid
#print axioms ActualCompletion.count
#print axioms ActualCompletion.source_projection
#print axioms ActualCompletion.source_member
#print axioms ActualCompletion.source_coverage
#print axioms ActualCompletion.all_full_inverses
#print axioms ActualCompletion.all_source_columns
#print axioms ActualCompletion.all_complement_columns
#print axioms ActualCompletion.all_source_frames
#print axioms ActualCompletion.all_block_symplectic
#print axioms ActualCompletion.actual_completion
