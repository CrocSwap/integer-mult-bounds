import EndpointBinding
import ActualFrameAdapter
import RepresentativeSquare
namespace CoordinateWord
open BinarySpace24 BinaryBilinearCertificate CoordinateChild Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def child (i : F) : List Index → (Vec → F) → (Vec → F)
  | [],f => f
  | j::js,f => gate i j (child i js f)
def unchild (i : F) : List Index → (Vec → F) → (Vec → F)
  | [],f => f
  | j::js,f => unchild i js (undoGate i j f)
def projection (js : List Index) (z : Vec) := sumUnits js z
def label (js : List Index) (v : Vec × Vec) := (add v.1 (projection js v.2),v.2)
def phase (i : F) (js : List Index) (z : Vec) := FourthRootRecipe.phase i (CanonicalGramRecipe.unitTerms js) z

theorem phase_cons (i : F) (j : Index) (js : List Index) (z : Vec) :
    phase i (j::js) z=axisPhase i j z*phase i js z := by
  simp only [phase,CanonicalGramRecipe.unitTerms,List.map_cons,FourthRootRecipe.phase,FourthRootRecipe.termPhase,
    dot_unit,FourthRootRecipe.rootPhase,axisPhase]

theorem inverse_left (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (js : List Index) (f : Vec → F) :
    unchild i js (child i js f)=f := by
  induction js generalizing f with
  | nil => rfl
  | cons j js ih => simp only [unchild,child,gate_inverse_left i hi htwo,ih]

theorem inverse_right (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (js : List Index) (f : Vec → F) :
    child i js (unchild i js f)=f := by
  induction js generalizing f with
  | nil => rfl
  | cons j js ih => simp only [unchild,child,ih,gate_inverse_right i hi htwo]

theorem child_scale (i : F) (js : List Index) (s : F) (f : Vec → F) :
    child i js (fun x => s*f x)=fun x => s*child i js f x := by
  induction js with
  | nil => rfl
  | cons j js ih => simp only [child,ih,gate_scale]

theorem child_add (i : F) (js : List Index) (f g : Vec → F) :
    child i js (fun x => f x+g x)=fun x => child i js f x+child i js g x := by
  induction js with
  | nil => rfl
  | cons j js ih => simp only [child,ih,ActualFrameAdapter.coordinate_gate_add]

theorem label_cons (j : Index) (js : List Index) (u z : Vec) :
    add (add u (projection js z)) (BinarySpace24.scale (z j) (unit j))=add u (projection (j::js) z) := by
  funext k
  simp only [projection,sumUnits,add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem pauli_pullthrough (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (js : List Index)
    (u z : Vec) (f : Vec → F) :
    child i js (ExactQuadraticLift.pauli u z f)=fun x => phase i js z*
      ExactQuadraticLift.pauli (label js (u,z)).1 (label js (u,z)).2 (child i js f) x := by
  induction js generalizing u f with
  | nil => simp only [child,phase,CanonicalGramRecipe.unitTerms,List.map_nil,FourthRootRecipe.phase,
      label,projection,sumUnits,add_zero,Semiring.one_mul]
  | cons j js ih =>
    simp only [child]
    rw [ih,gate_scale,CoordinateChild.gate_pauli_pullthrough i hi htwo]
    simp only [label,Prod.fst,Prod.snd] at *
    rw [label_cons,phase_cons]
    funext x
    grind

theorem pauli_conjugation (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (js : List Index)
    (u z : Vec) (f : Vec → F) :
    child i js (ExactQuadraticLift.pauli u z (unchild i js f))=fun x => phase i js z*
      ExactQuadraticLift.pauli (label js (u,z)).1 (label js (u,z)).2 f x := by
  rw [pauli_pullthrough i hi htwo,inverse_right i hi htwo]

theorem phase_fourth (i : F) (hi : i*i= -1) (js : List Index) (z : Vec) :
    (phase i js z*phase i js z)*(phase i js z*phase i js z)=1 := FourthRootRecipe.phase_fourth i hi _ z

theorem child_append (i : F) (as bs : List Index) (f : Vec → F) : child i (as++bs) f=child i as (child i bs f) := by
  induction as with
  | nil => rfl
  | cons a as ih => simp only [List.cons_append,child,ih]

theorem gate_child_commute (i : F) (j : Index) (js : List Index) (f : Vec → F) :
    gate i j (child i js f)=child i js (gate i j f) := by
  induction js with
  | nil => rfl
  | cons k ks ih => simp only [child,RepresentativeSquare.coordinate_gates_commute i j k,ih]

theorem child_permutation (i : F) {as bs : List Index} (h : as.Perm bs) (f : Vec → F) : child i as f=child i bs f := by
  induction h with
  | nil => rfl
  | cons j h ih => simp only [child,ih]
  | swap j k js => exact RepresentativeSquare.coordinate_gates_commute i k j _
  | trans h h' ih ih' => exact ih.trans ih'

end CoordinateWord
#print axioms CoordinateWord.phase_cons
#print axioms CoordinateWord.inverse_left
#print axioms CoordinateWord.inverse_right
#print axioms CoordinateWord.child_scale
#print axioms CoordinateWord.child_add
#print axioms CoordinateWord.label_cons
#print axioms CoordinateWord.pauli_pullthrough
#print axioms CoordinateWord.pauli_conjugation
#print axioms CoordinateWord.phase_fourth
#print axioms CoordinateWord.child_append
#print axioms CoordinateWord.gate_child_commute
#print axioms CoordinateWord.child_permutation
