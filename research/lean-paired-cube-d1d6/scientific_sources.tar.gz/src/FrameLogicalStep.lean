import ExactTransportTrace
import FieldWordTrace
namespace FrameLogicalStep
open CommonExactFrame ExactTransportTrace Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {X : Type u} {F : Type v} [Field F]

def encode (select : Nat → ExactFrame X F) (g : GaugeKeyTrace.State) (v : Arrays X F) : Arrays X F :=
  fun r => (select (g r)).encode (v r)
def decode (select : Nat → ExactFrame X F) (g : GaugeKeyTrace.State) (v : Arrays X F) : Arrays X F :=
  fun r => (select (g r)).decode (v r)

theorem decode_encode (select : Nat → ExactFrame X F) (g : GaugeKeyTrace.State) (v : Arrays X F) :
    decode select g (encode select g v)=v := by
  funext r
  exact (select (g r)).left_inverse (v r)

theorem encode_decode (select : Nat → ExactFrame X F) (g : GaugeKeyTrace.State) (v : Arrays X F) :
    encode select g (decode select g v)=v := by
  funext r
  exact (select (g r)).right_inverse (v r)

theorem frame_neg (A : ExactFrame X F) (f : X → F) : A.encode (fun x => -(f x))=fun x => -(A.encode f x) := by
  have he : (fun x => -(f x))=(fun x => (-1:F)*f x) := by funext x; grind
  rw [he,A.scale_linear]
  funext x
  grind

theorem destination_key (s : PairedWord.Step) (g : GaugeKeyTrace.State) :
    GaugeKeyTrace.update s g s.dst=ActualFrameKeys.key s := by
  simp only [GaugeKeyTrace.update,GaugeKeyTrace.touches,decide_true,Bool.true_or,if_true]

theorem source_key (s : PairedWord.Step) (g : GaugeKeyTrace.State) :
    GaugeKeyTrace.update s g s.src=ActualFrameKeys.key s := by
  simp only [GaugeKeyTrace.update,GaugeKeyTrace.touches,decide_true,Bool.or_true,if_true]

theorem prepared_correct (select : Nat → ExactFrame X F) (s : PairedWord.Step)
    (g : GaugeKeyTrace.State) (v : Arrays X F) (r : Nat) :
    prepared select s g (encode select g v) r=(select (GaugeKeyTrace.update s g r)).encode (v r) := by
  unfold prepared GaugeKeyTrace.update
  cases ht : GaugeKeyTrace.touches r s
  · simp only [ht,Bool.false_eq_true,if_false,encode]
  · simp only [ht,if_true,encode,adapter,(select (g r)).left_inverse]

def logicalStep (s : PairedWord.Step) (v : Arrays X F) : Arrays X F :=
  fun r x => FieldWordTrace.forward s (fun j => v j x) r

theorem logical_destination (s : PairedWord.Step) (v : Arrays X F) :
    logicalStep s v s.dst=fun x => v s.dst x+(if s.negative then -(v s.src x) else v s.src x) := by
  funext x
  simp only [logicalStep,FieldWordTrace.forward,FieldWordTrace.increment,if_pos rfl,if_true]

theorem logical_other (s : PairedWord.Step) (v : Arrays X F) (r : Nat) (hr : r≠s.dst) : logicalStep s v r=v r := by
  funext x
  simp only [logicalStep,FieldWordTrace.forward,if_neg hr]

theorem step_correct (select : Nat → ExactFrame X F) (s : PairedWord.Step)
    (g : GaugeKeyTrace.State) (v : Arrays X F) :
    step select s g (encode select g v)=encode select (GaugeKeyTrace.update s g) (logicalStep s v) := by
  have hd := prepared_correct select s g v s.dst
  have hs := prepared_correct select s g v s.src
  rw [destination_key] at hd
  rw [source_key] at hs
  funext r
  by_cases hr : r=s.dst
  · subst r
    rw [step,if_pos rfl]
    change (fun x => prepared select s g (encode select g v) s.dst x+
      (if s.negative then -(prepared select s g (encode select g v) s.src x) else
        prepared select s g (encode select g v) s.src x))=
      (select (GaugeKeyTrace.update s g s.dst)).encode (logicalStep s v s.dst)
    rw [hd,hs,destination_key,logical_destination]
    cases hn : s.negative
    · simp only [hn,Bool.false_eq_true,if_false,(select (ActualFrameKeys.key s)).add_linear]
    · simp only [hn,if_true,(select (ActualFrameKeys.key s)).add_linear,frame_neg]
  · rw [step,if_neg hr]
    change _=(select (GaugeKeyTrace.update s g r)).encode (logicalStep s v r)
    rw [logical_other s v r hr]
    exact prepared_correct select s g v r

end FrameLogicalStep
#print axioms FrameLogicalStep.decode_encode
#print axioms FrameLogicalStep.encode_decode
#print axioms FrameLogicalStep.frame_neg
#print axioms FrameLogicalStep.destination_key
#print axioms FrameLogicalStep.source_key
#print axioms FrameLogicalStep.prepared_correct
#print axioms FrameLogicalStep.logical_destination
#print axioms FrameLogicalStep.logical_other
#print axioms FrameLogicalStep.step_correct
