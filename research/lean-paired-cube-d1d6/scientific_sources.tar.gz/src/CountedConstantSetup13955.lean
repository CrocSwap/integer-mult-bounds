import SuppliedQuarterTable
import GaussianGate

/- A finite straight-line constant-pool program. The root i is an input, not
   constructed here. Slots are abstract, separately allocated field cells.
   Reads/writes count cell accesses, not a concrete machine's byte transfers. -/
namespace CountedConstantSetup13955
open Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

abbrev Slot := Fin 7
abbrev Memory (F : Type u) := Slot → F

inductive Operation where
  | literalOne
  | suppliedRoot
  | negate : Slot → Operation
  | add : Slot → Slot → Operation
  | inverse : Slot → Operation
  | multiply : Slot → Slot → Operation
  deriving DecidableEq

structure Instruction where
  destination : Slot
  operation : Operation
  deriving DecidableEq

def write (s : Memory F) (j : Slot) (v : F) : Memory F :=
  fun k => if k=j then v else s k

def Operation.eval (i : F) (s : Memory F) : Operation → F
  | .literalOne => 1
  | .suppliedRoot => i
  | .negate j => -s j
  | .add j k => s j+s k
  | .inverse j => (s j)⁻¹
  | .multiply j k => s j*s k

def execute (i : F) (p : Instruction) (s : Memory F) : Memory F :=
  write s p.destination (p.operation.eval i s)

def run (i : F) : List Instruction → Memory F → Memory F
  | [],s => s
  | p::ps,s => run i ps (execute i p s)

/- Table slots 0..3; slot 4 is first two, then its inverse; slots 5 and 6
   first hold the numerators, then the two Gaussian coefficients. -/
def preparation : List Instruction :=
  [⟨0,.literalOne⟩,⟨1,.suppliedRoot⟩,⟨2,.negate 0⟩,⟨3,.negate 1⟩,⟨4,.add 0 0⟩]

def completion : List Instruction :=
  [⟨4,.inverse 4⟩,⟨5,.add 0 1⟩,⟨5,.multiply 5 4⟩,⟨6,.add 0 3⟩,⟨6,.multiply 6 4⟩]

def program : List Instruction := preparation++completion

def setup (i : F) (s : Memory F) : Memory F := run i program s

def table (s : Memory F) : SuppliedQuarterTable.Table F := ⟨s 0,s 1,s 2,s 3⟩
def coefficientA (s : Memory F) := s 5
def coefficientB (s : Memory F) := s 6

structure Cost where
  literalLoads : Nat
  inputLoads : Nat
  cellReads : Nat
  cellWrites : Nat
  negations : Nat
  additions : Nat
  inversions : Nat
  multiplications : Nat
  deriving DecidableEq

def Cost.zero : Cost := ⟨0,0,0,0,0,0,0,0⟩
def Cost.plus (x y : Cost) : Cost :=
  ⟨x.literalLoads+y.literalLoads,x.inputLoads+y.inputLoads,x.cellReads+y.cellReads,
   x.cellWrites+y.cellWrites,x.negations+y.negations,x.additions+y.additions,
   x.inversions+y.inversions,x.multiplications+y.multiplications⟩

def Operation.cost : Operation → Cost
  | .literalOne => ⟨1,0,0,1,0,0,0,0⟩
  | .suppliedRoot => ⟨0,1,0,1,0,0,0,0⟩
  | .negate _ => ⟨0,0,1,1,1,0,0,0⟩
  | .add _ _ => ⟨0,0,2,1,0,1,0,0⟩
  | .inverse _ => ⟨0,0,1,1,0,0,1,0⟩
  | .multiply _ _ => ⟨0,0,2,1,0,0,0,1⟩

def cost : List Instruction → Cost
  | [] => Cost.zero
  | p::ps => p.operation.cost.plus (cost ps)

def runCounted (i : F) : List Instruction → Memory F → Memory F × Cost
  | [],s => (s,Cost.zero)
  | p::ps,s =>
    let out := runCounted i ps (execute i p s)
    (out.1,p.operation.cost.plus out.2)

theorem run_append (i : F) (ps qs : List Instruction) (s : Memory F) :
    run i (ps++qs) s=run i qs (run i ps s) := by
  induction ps generalizing s with
  | nil => rfl
  | cons p ps ih => exact ih (execute i p s)

theorem counted_execution (i : F) (ps : List Instruction) (s : Memory F) :
    runCounted i ps s=(run i ps s,cost ps) := by
  induction ps generalizing s with
  | nil => rfl
  | cons p ps ih => simp only [runCounted,ih,run,cost]

theorem exact_operation_receipt : cost program=⟨1,1,13,10,2,3,1,2⟩ := by decide

theorem ten_instructions : program.length=10 := by decide

theorem counted_setup (i : F) (s : Memory F) :
    runCounted i program s=(setup i s,⟨1,1,13,10,2,3,1,2⟩) := by
  rw [counted_execution,exact_operation_receipt]
  rfl

theorem two_prepared (i : F) (s : Memory F) : run i preparation s 4=(2:F) := by
  change (1:F)+1=2
  grind

theorem prepared_denominator_nonzero (i : F) (s : Memory F) (htwo : (2:F)≠0) :
    run i preparation s 4≠0 := by
  rw [two_prepared]
  exact htwo

theorem table_exact (i : F) (s : Memory F) :
    table (setup i s)=SuppliedQuarterTable.canonical i := by
  rfl

theorem coefficient_a_exact (i : F) (s : Memory F) :
    coefficientA (setup i s)=GaussianGate.a i := by
  have htwo : (1:F)+1=2 := by grind
  change ((1:F)+i)*((1:F)+1)⁻¹=(1+i)/2
  rw [htwo,Field.div_eq_mul_inv]

theorem coefficient_b_exact (i : F) (s : Memory F) :
    coefficientB (setup i s)=GaussianGate.b i := by
  have htwo : (1:F)+1=2 := by grind
  have hsub : (1:F)+(-i)=1-i := by grind
  change ((1:F)+(-i))*((1:F)+1)⁻¹=(1-i)/2
  rw [htwo,hsub,Field.div_eq_mul_inv]

theorem inverse_two_exact (i : F) (s : Memory F) : setup i s 4=(2:F)⁻¹ := by
  have htwo : (1:F)+1=2 := by grind
  change ((1:F)+1)⁻¹=(2:F)⁻¹
  rw [htwo]

theorem output_exact (i : F) (s : Memory F) :
    table (setup i s)=SuppliedQuarterTable.canonical i ∧
    coefficientA (setup i s)=GaussianGate.a i ∧
    coefficientB (setup i s)=GaussianGate.b i ∧ setup i s 4=(2:F)⁻¹ :=
  ⟨table_exact i s,coefficient_a_exact i s,coefficient_b_exact i s,inverse_two_exact i s⟩

end CountedConstantSetup13955
#print axioms CountedConstantSetup13955.run_append
#print axioms CountedConstantSetup13955.counted_execution
#print axioms CountedConstantSetup13955.exact_operation_receipt
#print axioms CountedConstantSetup13955.ten_instructions
#print axioms CountedConstantSetup13955.counted_setup
#print axioms CountedConstantSetup13955.two_prepared
#print axioms CountedConstantSetup13955.prepared_denominator_nonzero
#print axioms CountedConstantSetup13955.table_exact
#print axioms CountedConstantSetup13955.coefficient_a_exact
#print axioms CountedConstantSetup13955.coefficient_b_exact
#print axioms CountedConstantSetup13955.inverse_two_exact
#print axioms CountedConstantSetup13955.output_exact
