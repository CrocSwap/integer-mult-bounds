import BinarySpace24
import QuadraticPhase
namespace FourthRootRecipe
open BinarySpace24 Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

inductive Term where
  | diagonal : Vec → Term
  | cross : Vec → Vec → Term

def rootPhase (i : F) (b : Bool) : F := if b then i else 1

def termPhase (i : F) : Term → Vec → F
  | .diagonal d,x => rootPhase i (dot d x)
  | .cross a b,x => QuadraticPhase.sign (dot a x && dot b x)

def termShear : Term → Vec → Vec
  | .diagonal d,y => scale (dot d y) d
  | .cross a b,y => add (scale (dot b y) a) (scale (dot a y) b)

def phase (i : F) : List Term → Vec → F
  | [],_ => 1
  | t::ts,x => termPhase i t x * phase i ts x

def shear : List Term → Vec → Vec
  | [],_ => zero
  | t::ts,y => add (termShear t y) (shear ts y)

theorem neg_square (i : F) (hi : i*i= -1) : (-i)*(-i)= -1 := by grind

theorem root_polar (i : F) (hi : i*i= -1) (b c : Bool) :
    rootPhase i (b ^^ c)=rootPhase i b*rootPhase i c*QuadraticPhase.sign (b && c) := by
  cases b <;> cases c <;> simp only [rootPhase,QuadraticPhase.sign,Bool.false_xor,Bool.true_xor,
    Bool.not_true,Bool.not_false,Bool.and_self,Bool.false_and,Bool.true_and,Bool.false_eq_true,if_false,if_true] <;> grind

theorem root_inverse (i : F) (hi : i*i= -1) (b : Bool) : rootPhase (-i) b*rootPhase i b=1 := by
  cases b <;> simp only [rootPhase,Bool.false_eq_true,if_false,if_true] <;> grind

theorem root_fourth (i : F) (hi : i*i= -1) (b : Bool) :
    (rootPhase i b*rootPhase i b)*(rootPhase i b*rootPhase i b)=1 := by
  cases b <;> simp only [rootPhase,Bool.false_eq_true,if_false,if_true] <;> grind

theorem cross_polar (a b c d : Bool) :
    ((a ^^ c) && (b ^^ d))=((a && b) ^^ (c && d) ^^ ((a && d) ^^ (b && c))) := by
  cases a <;> cases b <;> cases c <;> cases d <;> decide

theorem term_polar (i : F) (hi : i*i= -1) (t : Term) (x y : Vec) :
    termPhase i t (add x y)=termPhase i t x*termPhase i t y*QuadraticPhase.sign (dot x (termShear t y)) := by
  cases t with
  | diagonal d =>
    simp only [termPhase,termShear,dot_add,dot_scale,dot_symmetric x d]
    rw [Bool.and_comm]
    exact root_polar i hi _ _
  | cross a b =>
    simp only [termPhase,termShear,dot_add,dot_scale,dot_symmetric x a,dot_symmetric x b]
    rw [cross_polar]
    simp only [QuadraticPhase.sign_xor]
    simp only [Bool.and_comm]

theorem term_inverse (i : F) (hi : i*i= -1) (t : Term) (x : Vec) :
    termPhase (-i) t x*termPhase i t x=1 := by
  cases t with
  | diagonal d => exact root_inverse i hi _
  | cross a b => exact QuadraticPhase.sign_square _

theorem term_fourth (i : F) (hi : i*i= -1) (t : Term) (x : Vec) :
    (termPhase i t x*termPhase i t x)*(termPhase i t x*termPhase i t x)=1 := by
  cases t with
  | diagonal d => exact root_fourth i hi _
  | cross a b => simp only [termPhase,QuadraticPhase.sign_square,Semiring.one_mul]

theorem phase_polar (i : F) (hi : i*i= -1) (ts : List Term) (x y : Vec) :
    phase i ts (add x y)=phase i ts x*phase i ts y*QuadraticPhase.sign (dot x (shear ts y)) := by
  induction ts with
  | nil => simp only [phase,shear,dot_zero,QuadraticPhase.sign,Bool.false_eq_true,if_false,Semiring.one_mul]
  | cons t ts ih =>
    simp only [phase,shear,term_polar i hi,ih,dot_add,QuadraticPhase.sign_xor]
    grind

theorem phase_inverse (i : F) (hi : i*i= -1) (ts : List Term) (x : Vec) :
    phase (-i) ts x*phase i ts x=1 := by
  induction ts with
  | nil => exact Semiring.one_mul _
  | cons t ts ih =>
    have h := term_inverse i hi t x
    simp only [phase]
    grind

theorem phase_fourth (i : F) (hi : i*i= -1) (ts : List Term) (x : Vec) :
    (phase i ts x*phase i ts x)*(phase i ts x*phase i ts x)=1 := by
  induction ts with
  | nil => simp only [phase,Semiring.one_mul]
  | cons t ts ih =>
    have h := term_fourth i hi t x
    simp only [phase]
    grind

theorem phase_nonzero (i : F) (hi : i*i= -1) (ts : List Term) (x : Vec) : phase i ts x≠0 := by
  intro h
  have he := phase_inverse i hi ts x
  rw [h,Semiring.mul_zero] at he
  exact Field.zero_ne_one he

end FourthRootRecipe
#print axioms FourthRootRecipe.neg_square
#print axioms FourthRootRecipe.root_polar
#print axioms FourthRootRecipe.root_inverse
#print axioms FourthRootRecipe.root_fourth
#print axioms FourthRootRecipe.cross_polar
#print axioms FourthRootRecipe.term_polar
#print axioms FourthRootRecipe.term_inverse
#print axioms FourthRootRecipe.term_fourth
#print axioms FourthRootRecipe.phase_polar
#print axioms FourthRootRecipe.phase_inverse
#print axioms FourthRootRecipe.phase_fourth
#print axioms FourthRootRecipe.phase_nonzero
