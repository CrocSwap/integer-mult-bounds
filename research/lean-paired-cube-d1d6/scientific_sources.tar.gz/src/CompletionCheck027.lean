import CompletionData
namespace CompletionCheck027
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch027.all CompletionCertificates.check=true := by decide
end CompletionCheck027
#print axioms CompletionCheck027.valid
