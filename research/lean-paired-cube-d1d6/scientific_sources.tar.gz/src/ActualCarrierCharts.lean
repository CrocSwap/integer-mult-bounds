import CarrierCoordinates
import ActualKPortInterface
namespace ActualCarrierCharts
open BinaryFrame BinaryPort CarrierCoordinates

def q (cube : List Nat) (parity : Bool) (j : Nat) : Nat :=
  (carrier cube parity)[j]?.getD 0
def encode (cube : List Nat) (parity : Bool) : Coordinates → Nat :=
  chart (q cube parity 0) (q cube parity 1) (q cube parity 2)

theorem list_three (qs : List Nat) (h : qs.length=3) :
    qs=[qs[0]?.getD 0,qs[1]?.getD 0,qs[2]?.getD 0] := by
  cases qs with
  | nil => simp at h
  | cons a rest =>
    cases rest with
    | nil => simp at h
    | cons b rest =>
      cases rest with
      | nil => simp at h
      | cons c rest =>
        have hr : rest=[] := List.length_eq_zero.mp (by simpa using h)
        subst rest
        rfl

theorem actual_basis (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    carrier cube parity=[q cube parity 0,q cube parity 1,q cube parity 2] :=
  list_three _ (ActualCubePorts.all_actual_carriers cube hc parity).carrier_rank.1

theorem actual_injective (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool)
    (c d : Coordinates) (h : encode cube parity c=encode cube parity d) : c=d := by
  have hi := (ActualCubePorts.all_actual_carriers cube hc parity).carrier_rank.2
  rw [actual_basis cube hc parity] at hi
  exact chart_injective _ _ _ hi c d h

theorem actual_range (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) (x : Nat) :
    (∃ c, encode cube parity c=x) ↔ Span (carrier cube parity) x := by
  rw [actual_basis cube hc parity]
  constructor
  · rintro ⟨c,rfl⟩
    exact chart_mem _ _ _ c
  · exact chart_surjective _ _ _ x

theorem actual_eight (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool) :
    (allCoordinates.map (encode cube parity)).length=8 ∧
    (allCoordinates.map (encode cube parity)).Nodup ∧
    (∀ x, x ∈ allCoordinates.map (encode cube parity) ↔ Span (carrier cube parity) x) := by
  refine ⟨by simp [coordinates_count.1], ?_, ?_⟩
  · apply List.Pairwise.map (encode cube parity) _ coordinates_count.2
    intro c d hne heq
    exact hne (actual_injective cube hc parity c d heq)
  · intro x
    rw [List.mem_map]
    constructor
    · rintro ⟨c,hc',he⟩
      exact (actual_range cube hc parity x).mp ⟨c,he⟩
    · intro hx
      rcases (actual_range cube hc parity x).mpr hx with ⟨c,he⟩
      exact ⟨c,all_coordinates c,he⟩

theorem actual_bounds (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes) (parity : Bool)
    (c : Coordinates) : encode cube parity c<2^24 :=
  ActualKPortInterface.actual_carrier_bounded cube hc parity _
    ((actual_range cube hc parity _).mp ⟨c,rfl⟩)

theorem actual_target_orthogonality (cube : List Nat) (hc : cube ∈ ActualInputCubes.cubes)
    (parity : Bool) (target : Nat) (ht : target ∈ ports cube (!parity)) (c : Coordinates) :
    dot 24 target (encode cube parity c)=false :=
  (ActualCubePorts.all_actual_carriers cube hc parity).carrier_orthogonal target ht _
    ((actual_range cube hc parity _).mp ⟨c,rfl⟩)

end ActualCarrierCharts
#print axioms ActualCarrierCharts.list_three
#print axioms ActualCarrierCharts.actual_basis
#print axioms ActualCarrierCharts.actual_injective
#print axioms ActualCarrierCharts.actual_range
#print axioms ActualCarrierCharts.actual_eight
#print axioms ActualCarrierCharts.actual_bounds
#print axioms ActualCarrierCharts.actual_target_orthogonality
