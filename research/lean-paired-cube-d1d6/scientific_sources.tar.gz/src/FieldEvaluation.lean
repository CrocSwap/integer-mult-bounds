import PackingBasis
import Init.Grind.CommRing.Field
namespace FieldEvaluation
open Lean.Grind SignedPacking
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def evaluate : List Int → List F → F
  | [], _ => 0
  | _, [] => 0
  | c :: cs, x :: xs => (c : F)*x + evaluate cs xs

theorem evaluate_zeros (n : Nat) (payload : List F) :
    evaluate (List.replicate n 0) payload = 0 := by
  induction n generalizing payload with
  | zero => simp [evaluate]
  | succ n ih =>
    cases payload with
    | nil => simp [evaluate]
    | cons x xs => simp [evaluate, List.replicate_succ, ih, Ring.intCast_zero, Semiring.zero_mul, Semiring.add_zero]

theorem evaluate_scale (cs : List Int) (payload : List F) (k : Int) :
    evaluate (cs.map (fun c => k*c)) payload = (k : F)*evaluate cs payload := by
  induction cs generalizing payload with
  | nil => simp [evaluate, Semiring.mul_zero]
  | cons c cs ih =>
    cases payload with
    | nil => simp [evaluate, Semiring.mul_zero]
    | cons x xs =>
      simp only [List.map_cons, evaluate, ih, Ring.intCast_mul, Semiring.left_distrib, Semiring.mul_assoc]

theorem evaluate_basis (n i : Nat) (payload : List F) (hlen : payload.length=n) (hi : i<n) :
    evaluate (basis n i) payload = payload[i]?.getD 0 := by
  induction n generalizing i payload with
  | zero => omega
  | succ n ih =>
    cases payload with
    | nil => simp at hlen
    | cons x xs =>
      have ht : xs.length=n := by simpa using hlen
      cases i with
      | zero => simp [basis_zero, evaluate, evaluate_zeros, Ring.intCast_one, Semiring.one_mul, Semiring.add_zero]
      | succ i =>
        have hlt : i<n := by omega
        simpa [basis_succ, evaluate, Ring.intCast_zero, Semiring.zero_mul, Semiring.zero_add] using ih i xs ht hlt

theorem scaled_basis_response (width target : Nat) (ht : target<width) (payload : Nat → F) :
    evaluate ((basis width target).map (fun x => (6:Int)*x)) ((List.range width).map payload) =
      (6:F)*payload target := by
  rw [evaluate_scale, evaluate_basis width target _ (by simp) ht]
  have h6 : ((6:Int):F) = (6:F) := Ring.intCast_ofNat 6
  rw [h6]
  simp [List.getElem?_map, List.getElem?_range ht]

theorem divide_six (x : F) (hsix : (6:F) ≠ 0) : ((6:F)*x)/6=x := by
  rw [Field.div_eq_mul_inv, Semiring.mul_assoc, CommSemiring.mul_comm x,
    ← Semiring.mul_assoc, Field.mul_inv_cancel hsix, Semiring.one_mul]

end FieldEvaluation
#print axioms FieldEvaluation.evaluate_zeros
#print axioms FieldEvaluation.evaluate_scale
#print axioms FieldEvaluation.evaluate_basis
#print axioms FieldEvaluation.scaled_basis_response
#print axioms FieldEvaluation.divide_six
