import ExactQuadraticLift
import GaussianGate
import InvolutionGate
namespace CoordinateChild
open BinarySpace24 ExactQuadraticLift GaussianGate Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def flip (j : Index) (x : Vec) : Vec := add x (unit j)
def gate (i : F) (j : Index) := InvolutionGate.gate i (flip j)
def undoGate (i : F) (j : Index) := InvolutionGate.inverse i (flip j)
def axisPhase (i : F) (j : Index) (z : Vec) : F := if z j then i else 1

theorem flip_twice (j : Index) (x : Vec) : flip j (flip j x)=x := by
  rw [flip,flip,add_assoc,add_self,add_zero]

theorem gate_inverse_left (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (j : Index) (f : Vec → F) :
    undoGate i j (gate i j f)=f := InvolutionGate.inverse_left i hi htwo _ (flip_twice j) f

theorem gate_inverse_right (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (j : Index) (f : Vec → F) :
    gate i j (undoGate i j f)=f := InvolutionGate.inverse_right i hi htwo _ (flip_twice j) f

theorem gate_scale (i : F) (j : Index) (s : F) (f : Vec → F) :
    gate i j (fun x => s*f x)=fun x => s*gate i j f x := by
  funext x
  simp only [gate,InvolutionGate.gate]
  grind

theorem coefficient_difference (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) : a i*a i-b i*b i=i := by
  have hp := phase_coefficients i hi
  have hm := (coefficient_square i hi htwo).2
  have he : a i*a i-b i*b i=i*(a i*b i+b i*a i) := by grind
  rw [he,hm,Semiring.mul_one]

theorem flip_translate (j : Index) (x u : Vec) : add (flip j x) u=flip j (add x u) := by
  funext k
  simp only [flip,add,Bool.xor_assoc,Bool.xor_left_comm,Bool.xor_comm]

theorem gate_pauli_conjugation (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (j : Index) (u z : Vec) (f : Vec → F) :
    gate i j (pauli u z (undoGate i j f))=
      fun x => axisPhase i j z*pauli (add u (scale (z j) (unit j))) z f x := by
  funext x
  have hcoef := coefficient_square i hi htwo
  have hdiff := coefficient_difference i hi htwo
  have hinv := inverse_coefficients i
  have hshift : dot z (flip j x)=(dot z x ^^ z j) := by rw [flip,dot_add,dot_unit_right]
  have harg0 : flip j (add (flip j x) u)=add x u := by rw [flip_translate,flip_twice]
  have harg1 : add x (add u (unit j))=flip j (add x u) := (add_assoc _ _ _).symm
  simp only [gate,undoGate,InvolutionGate.inverse,InvolutionGate.gate,pauli,hinv.1,hinv.2,
    hshift,QuadraticPhase.sign_xor,harg0,flip_translate,flip_twice]
  have hs0 : BinarySpace24.scale false (unit j)=zero := rfl
  have hs1 : BinarySpace24.scale true (unit j)=unit j := rfl
  cases hz : z j
  · simp only [hz,axisPhase,hs0,add_zero,QuadraticPhase.sign,Bool.false_eq_true,if_false]
    grind
  · simp only [hz,axisPhase,hs1,QuadraticPhase.sign,if_true,harg1]
    grind

theorem gate_pauli_pullthrough (i : F) (hi : i*i= -1) (htwo : (2:F)≠0)
    (j : Index) (u z : Vec) (f : Vec → F) :
    gate i j (pauli u z f)=fun x => axisPhase i j z*
      pauli (add u (scale (z j) (unit j))) z (gate i j f) x := by
  have h := gate_pauli_conjugation i hi htwo j u z (gate i j f)
  simpa only [gate_inverse_left i hi htwo] using h

end CoordinateChild
#print axioms CoordinateChild.flip_twice
#print axioms CoordinateChild.gate_inverse_left
#print axioms CoordinateChild.gate_inverse_right
#print axioms CoordinateChild.gate_scale
#print axioms CoordinateChild.coefficient_difference
#print axioms CoordinateChild.flip_translate
#print axioms CoordinateChild.gate_pauli_conjugation
#print axioms CoordinateChild.gate_pauli_pullthrough
