import AssemblyExpressions13955
namespace PairedCubeAssembly13955
set_option maxRecDepth 10000
set_option maxHeartbeats 4000000

theorem slack_bit_positive_derived : ExactValue slack_bit_positive 4613422943 10000000000000 ∧ Positive slack_bit_positive := by
  decide

theorem slack_complex_above_bit_derived : ExactValue slack_complex_above_bit 243146057 10000000000000 ∧ Positive slack_complex_above_bit := by
  decide

theorem slack_complex_below_one_over32_derived : ExactValue slack_complex_below_one_over32 307643431 10000000000 ∧ Positive slack_complex_below_one_over32 := by
  decide

theorem slack_beta_positive_derived : ExactValue slack_beta_positive 1 1000000 ∧ Positive slack_beta_positive := by
  decide

theorem slack_beta_below_one_derived : ExactValue slack_beta_below_one 999999 1000000 ∧ Positive slack_beta_below_one := by
  decide

theorem slack_leaf_saving_above_bit_derived : ExactValue slack_leaf_saving_above_bit 243141200431 10000000000000000 ∧ Positive slack_leaf_saving_above_bit := by
  decide

theorem slack_q_positive_derived : ExactValue slack_q_positive 230671142536577057 500000000000000000000 ∧ Positive slack_q_positive := by
  decide

theorem slack_q_below_internal_derived : ExactValue slack_q_below_internal 4613422943 500000000000000000000 ∧ Positive slack_q_below_internal := by
  decide

theorem slack_q_below_leaf_derived : ExactValue slack_q_below_leaf 12157064634972943 500000000000000000000 ∧ Positive slack_q_below_leaf := by
  decide

theorem slack_c_positive_derived : ExactValue slack_c_positive 23067114484328848236577057 50000000000000000000000000000 ∧ Positive slack_c_positive := by
  decide

theorem slack_c_below_one_derived : ExactValue slack_c_below_one 49976932885515671151763422943 50000000000000000000000000000 ∧ Positive slack_c_below_one := by
  decide

theorem slack_q_below_reservations_derived : ExactValue slack_q_below_reservations 230671142536577057 50000000000000000000000000000 ∧ Positive slack_q_below_reservations := by
  decide

theorem slack_lambda_above_tau_derived : ExactValue slack_lambda_above_tau 4613422943 1000000000000000000000 ∧ Positive slack_lambda_above_tau := by
  decide

theorem slack_lambda_above_sigma_derived : ExactValue slack_lambda_above_sigma 24314610313422943 1000000000000000000000 ∧ Positive slack_lambda_above_sigma := by
  decide

theorem slack_lambda_above_internal_derived : ExactValue slack_lambda_above_internal 4613422943 1000000000000000000000 ∧ Positive slack_lambda_above_internal := by
  decide

theorem slack_lambda_prime_above_lambda_derived : ExactValue slack_lambda_prime_above_lambda 4613422943 1000000000000000000000 ∧ Positive slack_lambda_prime_above_lambda := by
  decide

theorem slack_compact_leaf_derived : ExactValue slack_compact_leaf 12157064634972943 500000000000000000000 ∧ Positive slack_compact_leaf := by
  decide

theorem slack_compact_reservations_derived : ExactValue slack_compact_reservations 230671142536577057 50000000000000000000000000000 ∧ Positive slack_compact_reservations := by
  decide

theorem slack_lambda_prime_below_one_derived : ExactValue slack_lambda_prime_below_one 230671142536577057 500000000000000000000 ∧ Positive slack_lambda_prime_below_one := by
  decide

theorem slack_epsilon_positive_derived : ExactValue slack_epsilon_positive 49999999500000000000000000000 50046134228737986553936577057 ∧ Positive slack_epsilon_positive := by
  decide

theorem slack_epsilon_below_one_derived : ExactValue slack_epsilon_below_one 46134728737986553936577057 50046134228737986553936577057 ∧ Positive slack_epsilon_below_one := by
  decide

theorem slack_guard_width_derived : ExactValue slack_guard_width 46134728737986553936577057 50046134228737986553936577057 ∧ Positive slack_guard_width := by
  decide

theorem slack_K_geometry_derived : ExactValue slack_K_geometry 2306761448432885054328848236577057 5004613422873798655393657705700000000 ∧ Positive slack_K_geometry := by
  decide

end PairedCubeAssembly13955
#print axioms PairedCubeAssembly13955.slack_bit_positive_derived
#print axioms PairedCubeAssembly13955.slack_complex_above_bit_derived
#print axioms PairedCubeAssembly13955.slack_complex_below_one_over32_derived
#print axioms PairedCubeAssembly13955.slack_beta_positive_derived
#print axioms PairedCubeAssembly13955.slack_beta_below_one_derived
#print axioms PairedCubeAssembly13955.slack_leaf_saving_above_bit_derived
#print axioms PairedCubeAssembly13955.slack_q_positive_derived
#print axioms PairedCubeAssembly13955.slack_q_below_internal_derived
#print axioms PairedCubeAssembly13955.slack_q_below_leaf_derived
#print axioms PairedCubeAssembly13955.slack_c_positive_derived
#print axioms PairedCubeAssembly13955.slack_c_below_one_derived
#print axioms PairedCubeAssembly13955.slack_q_below_reservations_derived
#print axioms PairedCubeAssembly13955.slack_lambda_above_tau_derived
#print axioms PairedCubeAssembly13955.slack_lambda_above_sigma_derived
#print axioms PairedCubeAssembly13955.slack_lambda_above_internal_derived
#print axioms PairedCubeAssembly13955.slack_lambda_prime_above_lambda_derived
#print axioms PairedCubeAssembly13955.slack_compact_leaf_derived
#print axioms PairedCubeAssembly13955.slack_compact_reservations_derived
#print axioms PairedCubeAssembly13955.slack_lambda_prime_below_one_derived
#print axioms PairedCubeAssembly13955.slack_epsilon_positive_derived
#print axioms PairedCubeAssembly13955.slack_epsilon_below_one_derived
#print axioms PairedCubeAssembly13955.slack_guard_width_derived
#print axioms PairedCubeAssembly13955.slack_K_geometry_derived
