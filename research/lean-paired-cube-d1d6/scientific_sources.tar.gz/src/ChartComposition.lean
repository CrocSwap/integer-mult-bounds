import Q21AddressProgram
import CatalogSpanBridge
namespace ChartComposition
open BinarySpace24 FourthRootLift CanonicalFourthRootLift CatalogSpanBridge BinaryCompletion Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def compose (a b : Chart) : Chart where
  forward := fun x => a.forward (b.forward x)
  inverse := fun y => b.inverse (a.inverse y)
  inverseTranspose := fun z => a.inverseTranspose (b.inverseTranspose z)
  inverse_left := fun x => by rw [a.inverse_left,b.inverse_left]
  inverse_right := fun x => by rw [b.inverse_right,a.inverse_right]
  forward_add := fun x y => by rw [b.forward_add,a.forward_add]
  transpose_pairing := fun x z => by rw [a.transpose_pairing,b.transpose_pairing]

theorem K_composition (i : F) (hi : i*i= -1) (a b : Chart) (f : Vec → F) :
    K i (compose a b) f=K i a (K i b f) := by
  rw [exact_S_permutation_S_inverse,exact_S_permutation_S_inverse i a,
    exact_S_permutation_S_inverse i b,S_inverse_left i hi]
  rfl

theorem anchor (c t : Index) (h : c≠t) : add (unit c) (unit t) c=true := by
  have ht : t≠c := Ne.symm h
  simp only [add,unit,ht,decide_true,decide_false,Bool.xor_false]

def cx (c t : Index) (h : c≠t) : Chart := AnchoredAddress.chart (add (unit c) (unit t)) c (anchor c t h)

theorem cx_address (c t : Index) (h : c≠t) (x : Vec) : (cx c t h).forward x=Q21AddressProgram.execute ⟨c,t⟩ x := by
  change AnchoredAddress.R (add (unit c) (unit t)) c x=_
  rw [AnchoredAddress.formula]
  have hr : add (add (unit c) (unit t)) (unit c)=unit t := by
    rw [add_comm (unit c) (unit t),add_assoc,add_self,add_zero]
  rw [hr]
  rfl

theorem cx_inverse_address (c t : Index) (h : c≠t) (x : Vec) :
    (cx c t h).inverse x=Q21AddressProgram.execute ⟨c,t⟩ x := cx_address c t h x

theorem image_from_columns (c : Chart) (w : VariableCertificates.Witness)
    (hc : ∀j∈initial w.slots.length,c.forward (unit j)=rows w j) :
    Image c.forward (CoordinateWordFrames.Space (initial w.slots.length))=Span w := by
  funext y
  apply propext
  constructor
  · rintro ⟨x,hx,rfl⟩
    refine ⟨x,?_⟩
    rw [← sumRows_congr _ (rows w) _ hc x,← forward_sum,
      projection_fixed _ (prefix_nodup _) x hx]
  · rintro ⟨x,rfl⟩
    refine ⟨CoordinateWord.projection (initial w.slots.length) x,
      CoordinateWordFrames.projection_space _ (prefix_nodup _) x,?_⟩
    rw [forward_sum,sumRows_congr _ (rows w) _ hc x]

theorem image_precompose (a b : Chart) (U : Vec → Prop) (hb : ∀x,U (b.forward x) ↔ U x) :
    Image (compose a b).forward U=Image a.forward U := by
  funext y
  apply propext
  constructor
  · rintro ⟨x,hx,he⟩
    exact ⟨b.forward x,(hb x).mpr hx,he⟩
  · rintro ⟨x,hx,he⟩
    refine ⟨b.inverse x,?_,?_⟩
    · apply (hb _).mp
      rw [b.inverse_right]
      exact hx
    · change a.forward (b.forward (b.inverse x))=y
      rw [b.inverse_right,he]

end ChartComposition
#print axioms ChartComposition.K_composition
#print axioms ChartComposition.anchor
#print axioms ChartComposition.cx_address
#print axioms ChartComposition.cx_inverse_address
#print axioms ChartComposition.image_from_columns
#print axioms ChartComposition.image_precompose
