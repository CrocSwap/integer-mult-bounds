import FieldWordTrace
namespace FieldWordLaws
open Lean.Grind FieldWordTrace
open PairedWord (Step good legal)
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def add (x y : FState F) : FState F := fun i => x i+y i
def sub (x y : FState F) : FState F := fun i => x i-y i
def backward (s : Step) (x : FState F) : FState F :=
  fun i => if i=s.dst then x s.dst-increment s x else x i

def undo : List Step → FState F → FState F
  | [], x => x
  | s :: ss, x => backward s (undo ss x)

theorem backward_forward (s : Step) (h : s.dst ≠ s.src) (x : FState F) :
    backward s (forward s x)=x := by
  funext i
  have hs : s.src ≠ s.dst := Ne.symm h
  by_cases hi : i=s.dst
  · subst i
    simp only [backward, forward, increment, if_pos rfl, if_neg hs]
    simp [Ring.sub_eq_add_neg, Semiring.add_assoc, Ring.add_neg_cancel, Semiring.add_zero]
  · simp only [backward, forward, if_neg hi]

theorem forward_backward (s : Step) (h : s.dst ≠ s.src) (x : FState F) :
    forward s (backward s x)=x := by
  funext i
  have hs : s.src ≠ s.dst := Ne.symm h
  by_cases hi : i=s.dst
  · subst i
    simp only [backward, forward, increment, if_pos rfl, if_neg hs]
    simp [Ring.sub_eq_add_neg, Semiring.add_assoc, Ring.neg_add_cancel, Semiring.add_zero]
  · simp only [backward, forward, if_neg hi]

theorem forward_add (s : Step) (x y : FState F) :
    forward s (add x y)=add (forward s x) (forward s y) := by
  funext i
  by_cases hi : i=s.dst
  · subst i
    cases hn : s.negative <;> simp [forward, increment, add, hn, Ring.neg_add,
      Semiring.add_assoc, Semiring.add_comm, Semiring.add_left_comm]
  · simp only [forward, add, if_neg hi]

theorem undo_run (ss : List Step) : ss.all good = true → ∀ x : FState F, undo ss (run ss x)=x := by
  induction ss with
  | nil => intro h x; rfl
  | cons s ss ih =>
    intro h x
    have hh : good s=true ∧ ss.all good=true := Bool.and_eq_true_iff.mp h
    have hs : legal s := of_decide_eq_true hh.1
    simp only [run, undo]
    rw [ih hh.2, backward_forward s hs.2.2]

theorem run_undo (ss : List Step) : ss.all good = true → ∀ x : FState F, run ss (undo ss x)=x := by
  induction ss with
  | nil => intro h x; rfl
  | cons s ss ih =>
    intro h x
    have hh : good s=true ∧ ss.all good=true := Bool.and_eq_true_iff.mp h
    have hs : legal s := of_decide_eq_true hh.1
    simp only [run, undo]
    rw [forward_backward s hs.2.2, ih hh.2]

theorem run_add (ss : List Step) (x y : FState F) :
    run ss (add x y)=add (run ss x) (run ss y) := by
  induction ss generalizing x y with
  | nil => rfl
  | cons s ss ih =>
    simp only [run]
    rw [forward_add, ih]

theorem readout_add (ts : List PairedDecoder.ReadTerm) (x y : FState F) :
    FieldLinearEvaluation.readout ts (add x y) =
      FieldLinearEvaluation.readout ts x + FieldLinearEvaluation.readout ts y := by
  induction ts with
  | nil => simp [FieldLinearEvaluation.readout, Semiring.add_zero]
  | cons t ts ih =>
    simp only [FieldLinearEvaluation.readout, add, Semiring.left_distrib, ih]
    simp [Semiring.add_assoc, Semiring.add_comm, Semiring.add_left_comm]

theorem divide_add (x y d : F) : (x+y)/d=x/d+y/d := by
  simp only [Field.div_eq_mul_inv, Semiring.right_distrib]

end FieldWordLaws
#print axioms FieldWordLaws.backward_forward
#print axioms FieldWordLaws.forward_backward
#print axioms FieldWordLaws.forward_add
#print axioms FieldWordLaws.undo_run
#print axioms FieldWordLaws.run_undo
#print axioms FieldWordLaws.run_add
#print axioms FieldWordLaws.readout_add
#print axioms FieldWordLaws.divide_add
