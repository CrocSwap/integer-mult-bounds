import QuarterPhaseCompiler
import RootComponentReceipt
namespace ActualQuarterPhase
open BinarySpace24 ActualPhaseEvaluation QuarterPhaseCompiler TwoBitQuarter Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def leftCode := compile leftExpr
def rightCode := compile rightExpr

theorem left_cost : leftCode.cost=⟨51,151,51,1,51,50⟩ := by decide
theorem right_cost : rightCode.cost=⟨48,147,49,0,50,49⟩ := by decide

theorem left_value (i : F) (hi : i*i= -1) (x : Vec) :
    value i (leftCode.run (registers x (leftIntermediate x))).1=LeftPassAddressPhase.scalar i x := by
  rw [leftCode,compiler_run_correct i hi,ActualPhaseEvaluation.left_eval i hi,left_intermediate]
  rfl

theorem right_value (i : F) (hi : i*i= -1) (x : Vec) :
    value i (rightCode.run (registers x (RootAddressInstructions.run OuterAddressCircuits.rightCode x))).1=
      RightPassAddressPhase.scalar i x := by
  rw [rightCode,compiler_run_correct i hi,ActualPhaseEvaluation.right_eval,OuterAddressCircuits.right_address]
  rfl

theorem left_run_cost (x : Vec) : (leftCode.run (registers x (leftIntermediate x))).2=⟨51,151,51,1,51,50⟩ := by
  rw [counted_evaluation,left_cost]

theorem right_run_cost (x : Vec) :
    (rightCode.run (registers x (RootAddressInstructions.run OuterAddressCircuits.rightCode x))).2=⟨48,147,49,0,50,49⟩ := by
  rw [counted_evaluation,right_cost]

def leftPass (i : F) (f : Vec → F) (x : Vec) :=
  let y := leftIntermediate x
  let phaseResult := leftCode.run (registers x y)
  let z := RootAddressInstructions.run leftLocalCode y
  value i phaseResult.1*f z

def rightPass (i : F) (f : Vec → F) (x : Vec) :=
  let y := RootAddressInstructions.run OuterAddressCircuits.rightCode x
  let phaseResult := rightCode.run (registers x y)
  value i phaseResult.1*f y

theorem exact_left (i : F) (hi : i*i= -1) (f : Vec → F) : leftPass i f=OuterAddressCircuits.leftPass i f := by
  funext x
  simp only [leftPass,left_value i hi,left_split_address,OuterAddressCircuits.leftPass]

theorem exact_right (i : F) (hi : i*i= -1) (f : Vec → F) : rightPass i f=OuterAddressCircuits.rightPass i f := by
  funext x
  simp only [rightPass,right_value i hi,OuterAddressCircuits.rightPass]

def lowered (i : F) (f : Vec → F) := leftPass i (Coordinate21PairProgram.applyPairs i (rightPass i f))

theorem exact_lowered (i : F) (hi : i*i= -1) (f : Vec → F) : lowered i f=OuterAddressCircuits.lowered i f := by
  simp only [lowered,exact_left i hi,exact_right i hi,Coordinate21PairProgram.function_semantics,OuterAddressCircuits.lowered]

theorem actual_event (i : F) (hi : i*i= -1) (htwo : (2:F)≠0) (g : GaugeKeyTrace.State) (f : Vec → F) :
    CommonExactFrame.adapter (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 3 g 17326))
      (CompleteFrameSelector.select i hi htwo (ActualRootLifecycle.afterRoots 4 g 17326)) f=lowered i f := by
  rw [exact_lowered i hi]
  exact OuterAddressCircuits.actual_event i hi htwo g f

end ActualQuarterPhase
#print axioms ActualQuarterPhase.left_cost
#print axioms ActualQuarterPhase.right_cost
#print axioms ActualQuarterPhase.left_value
#print axioms ActualQuarterPhase.right_value
#print axioms ActualQuarterPhase.left_run_cost
#print axioms ActualQuarterPhase.right_run_cost
#print axioms ActualQuarterPhase.exact_left
#print axioms ActualQuarterPhase.exact_right
#print axioms ActualQuarterPhase.exact_lowered
#print axioms ActualQuarterPhase.actual_event
