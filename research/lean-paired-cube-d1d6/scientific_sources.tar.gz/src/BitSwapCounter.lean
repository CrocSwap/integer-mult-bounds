import TransportedBitSwap
namespace BitSwapCounter
open BinarySpace24 BinaryPairEnumeration BinaryCompletion BaseBitTransposition TransportedBitSwap
variable {V : Type u}
local instance bitsEquality (n : Nat) : DecidableEq (Bits n) := BinaryAddressEquality.decidableEquality

structure Cost where
  loads : Nat
  stores : Nat
  registerMoves : Nat
  deriving DecidableEq

def Cost.zero : Cost := ⟨0,0,0⟩
def Cost.add (a b : Cost) : Cost := ⟨a.loads+b.loads,a.stores+b.stores,a.registerMoves+b.registerMoves⟩
def loadCode : List PairLoadStoreMachine.Instruction := [.loadLeft,.loadRight]
-- Reverse the address arguments and store the old right value first.
def crossStoreCode : List PairLoadStoreMachine.Instruction := [.storeRight,.storeLeft]
def pairCost : Cost := ⟨PairLoadStoreMachine.count PairLoadStoreMachine.loads loadCode,
  PairLoadStoreMachine.count PairLoadStoreMachine.stores crossStoreCode,0⟩

def pair (p : Permutation) (k : Bits 22) (s : PairLoadStoreMachine.State Vec V) :=
  let loaded:=PairLoadStoreMachine.run (left p) (right p) exchange k loadCode s
  PairLoadStoreMachine.run (right p) (left p) exchange k crossStoreCode loaded

theorem pair_receipt : pairCost=⟨2,2,0⟩ := rfl

theorem pair_memory (p : Permutation) (k : Bits 22) (s : PairLoadStoreMachine.State Vec V) :
    (pair p k s).memory=DisjointPairLoop.step (left p) (right p) exchange k s.memory := rfl

theorem read_both_first (p : Permutation) (k : Bits 22) (s : PairLoadStoreMachine.State Vec V) :
    let loaded:=PairLoadStoreMachine.run (left p) (right p) exchange k loadCode s
    loaded.memory=s.memory ∧ (loaded.left,loaded.right)=(s.memory (left p k),s.memory (right p k)) := ⟨rfl,rfl⟩

theorem scratch_holds_inputs (p : Permutation) (k : Bits 22) (s : PairLoadStoreMachine.State Vec V) :
    ((pair p k s).left,(pair p k s).right)=(s.memory (left p k),s.memory (right p k)) := rfl

def loop (p : Permutation) : List (Bits 22) → PairLoadStoreMachine.State Vec V → PairLoadStoreMachine.State Vec V × Cost
  | [],s => (s,Cost.zero)
  | k::ks,s =>
    let out:=loop p ks (pair p k s)
    (out.1,Cost.add pairCost out.2)

def loopCost (n : Nat) : Cost := ⟨2*n,2*n,0⟩

theorem loop_memory (p : Permutation) (ks : List (Bits 22)) (s : PairLoadStoreMachine.State Vec V) :
    (loop p ks s).1.memory=DisjointPairLoop.run (left p) (right p) exchange ks s.memory := by
  induction ks generalizing s with
  | nil => rfl
  | cons k ks ih =>
    simp only [loop,ih,pair_memory,DisjointPairLoop.run]

theorem loop_cost (p : Permutation) (ks : List (Bits 22)) (s : PairLoadStoreMachine.State Vec V) :
    (loop p ks s).2=loopCost ks.length := by
  induction ks generalizing s with
  | nil => rfl
  | cons k ks ih =>
    simp only [loop,ih,List.length_cons,loopCost,Cost.add,pair_receipt,Nat.mul_add,Nat.mul_one,Nat.add_comm]

theorem actual_memory (p : Permutation) (s : PairLoadStoreMachine.State Vec V) :
    (loop p (addresses 22) s).1.memory=fun x=>s.memory (address p x) := by
  rw [loop_memory]
  have h:=TransportedBitSwap.memory_exact p s
  rw [stage,PairLoadStoreMachine.memory_run] at h
  exact h

theorem actual_cost (p : Permutation) (s : PairLoadStoreMachine.State Vec V) :
    (loop p (addresses 22) s).2=⟨8388608,8388608,0⟩ := by
  rw [loop_cost,TransportedBitSwap.pair_count]
  rfl

@[irreducible] def execute (p : Permutation) (s : PairLoadStoreMachine.State Vec V) := loop p (addresses 22) s

theorem execute_memory (p : Permutation) (s : PairLoadStoreMachine.State Vec V) :
    (execute p s).1.memory=fun x=>s.memory (address p x) := by
  rw [execute,actual_memory]

theorem execute_cost (p : Permutation) (s : PairLoadStoreMachine.State Vec V) :
    (execute p s).2=⟨8388608,8388608,0⟩ := by
  rw [execute,actual_cost]

end BitSwapCounter
#print axioms BitSwapCounter.pair_receipt
#print axioms BitSwapCounter.pair_memory
#print axioms BitSwapCounter.read_both_first
#print axioms BitSwapCounter.scratch_holds_inputs
#print axioms BitSwapCounter.loop_memory
#print axioms BitSwapCounter.loop_cost
#print axioms BitSwapCounter.actual_memory
#print axioms BitSwapCounter.actual_cost
#print axioms BitSwapCounter.execute_memory
#print axioms BitSwapCounter.execute_cost
