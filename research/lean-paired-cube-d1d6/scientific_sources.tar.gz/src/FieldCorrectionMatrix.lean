import ActualFieldDirty
import ActualInputCubes
namespace FieldCorrectionMatrix
open Lean.Grind FieldWordTrace FieldWordLaws ActualFieldExecution PairedWordData PairedDecoder CubeCorrection CubeGeometry
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000

theorem sparse_dense (js : List Nat) (c : Nat → Int) (offset : Nat) (payload : FState F) :
    FieldLinearEvaluation.readout
      ((js.filterMap (fun j => if c j=0 then none else some (⟨j+1,3*c j⟩ : ReadTerm))).map (shift offset))
      (fun n => payload (n-1)) =
    (js.map (fun j => ((3*c j : Int):F)*payload (offset+j))).sum := by
  induction js with
  | nil => rfl
  | cons j js ih =>
    by_cases h : c j=0
    · simp [List.filterMap_cons, h, ih, Ring.intCast_zero, Semiring.zero_mul, Semiring.zero_add]
    · simp [List.filterMap_cons, h, FieldLinearEvaluation.readout, shift, ih, Nat.add_assoc]

def canonicalResponse (target : Nat) (payload : FState F) : F :=
  ((List.range 8).map (fun j => ((3*PairedCubeIdentities.k2 (target%8) j : Int):F)*
    payload (8*(target/8)+j))).sum

def actualInputResponse (target : Nat) (payload : FState F) : F :=
  ((List.range 8).map (fun j => ((3*inputK2 (ActualInputCubes.cubes[target/8]?.getD []) (target%8) j : Int):F)*
    payload (8*(target/8)+j))).sum

theorem correction_is_canonical (target : Nat) (payload : FState F) :
    correctionResponse target payload=canonicalResponse target payload :=
  sparse_dense (List.range 8) (PairedCubeIdentities.k2 (target%8)) (8*(target/8)) payload

theorem correction_is_actual_input_matrix (target : Nat) (ht : target<1760) (payload : FState F) :
    correctionResponse target payload=actualInputResponse target payload := by
  rw [correction_is_canonical]
  unfold canonicalResponse actualInputResponse
  apply congrArg List.sum
  apply List.map_congr_left
  intro j hj
  have hj8 : j<8 := List.mem_range.mp hj
  have hc : target/8<ActualInputCubes.cubes.length := by rw [ActualInputCubes.cube_count]; omega
  have hm : ActualInputCubes.cubes[target/8]?.getD [] ∈ ActualInputCubes.cubes := by
    rw [List.getElem?_eq_getElem hc]
    exact List.getElem_mem hc
  have he := ActualInputCubes.actual_matrices _ hm ⟨target%8,by omega⟩ ⟨j,hj8⟩
  rw [he]

theorem actual_source_normalized_execution (target : Nat) (ht : target<1760) (payload : FState F)
    (hsix : (6:F) ≠ 0) :
    decoderResponse target (run word (inject payload))/6 + actualInputResponse target payload/6 = payload target := by
  rw [← correction_is_actual_input_matrix target ht payload]
  exact actual_normalized_execution target ht payload hsix

theorem actual_source_dirty_normalized_execution (z payload : FState F) (y : F) (target : Nat) (ht : target<1760)
    (hsix : (6:F) ≠ 0) :
    (y-decoderResponse target (run word z)/6) +
      decoderResponse target (run word (add z (inject payload)))/6 + actualInputResponse target payload/6 =
    y+payload target := by
  rw [← correction_is_actual_input_matrix target ht payload]
  exact ActualFieldDirty.actual_dirty_normalized_response z payload y target ht hsix

end FieldCorrectionMatrix
#print axioms FieldCorrectionMatrix.sparse_dense
#print axioms FieldCorrectionMatrix.correction_is_canonical
#print axioms FieldCorrectionMatrix.correction_is_actual_input_matrix
#print axioms FieldCorrectionMatrix.actual_source_normalized_execution
#print axioms FieldCorrectionMatrix.actual_source_dirty_normalized_execution
