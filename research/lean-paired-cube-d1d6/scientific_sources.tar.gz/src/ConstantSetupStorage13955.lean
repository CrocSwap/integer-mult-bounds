import CountedConstantSetup13955

/- The instruction receipt does not include an allocator implementation.
   This module states the allocation contract, checks initialization order,
   and realizes the same program in seven distinct writable cells, disjoint
   from the retained input cell. Initial pool contents are unrestricted. -/
namespace ConstantSetupStorage13955
open CountedConstantSetup13955 Lean.Grind
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def sources : Operation → List Slot
  | .literalOne | .suppliedRoot => []
  | .negate j | .inverse j => [j]
  | .add j k | .multiply j k => [j,k]

def initialized : List Slot → List Instruction → Bool
  | _,[] => true
  | live,p::ps =>
    (sources p.operation).all (fun j => live.contains j) && initialized (p.destination::live) ps

theorem every_read_initialized : initialized [] program=true := by decide

def inverseAllowed (s : Memory F) : Operation → Prop
  | .inverse j => s j≠0
  | _ => True

def inversesNonzero (i : F) : List Instruction → Memory F → Prop
  | [],_ => True
  | p::ps,s => inverseAllowed s p.operation ∧ inversesNonzero i ps (execute i p s)

theorem inverse_inputs_nonzero (i : F) (s : Memory F) (htwo : (2:F)≠0) :
    inversesNonzero i program s := by
  have htwo' : (1:F)+1≠0 := by
    have heq : (1:F)+1=2 := by grind
    rw [heq]
    exact htwo
  change True ∧ True ∧ True ∧ True ∧ True ∧
    ((1:F)+1≠0 ∧ True ∧ True ∧ True ∧ True ∧ True)
  exact ⟨trivial,trivial,trivial,trivial,trivial,htwo',trivial,trivial,trivial,trivial,trivial⟩

structure Allocation (A : Type v) where
  cells : Slot → A
  input : A
  distinct : ∀ j k, cells j=cells k → j=k
  inputDisjoint : ∀ j, input≠cells j

variable {A : Type v} [DecidableEq A]

def restrict (l : Allocation A) (m : A → F) : Memory F := fun j => m (l.cells j)

def physicalWrite (m : A → F) (j : A) (v : F) : A → F :=
  fun k => if k=j then v else m k

def physicalExecute (l : Allocation A) (p : Instruction) (m : A → F) : A → F :=
  physicalWrite m (l.cells p.destination) (p.operation.eval (m l.input) (restrict l m))

def physicalRun (l : Allocation A) : List Instruction → (A → F) → (A → F)
  | [],m => m
  | p::ps,m => physicalRun l ps (physicalExecute l p m)

def physicalRunCounted (l : Allocation A) : List Instruction → (A → F) → (A → F) × Cost
  | [],m => (m,Cost.zero)
  | p::ps,m =>
    let out := physicalRunCounted l ps (physicalExecute l p m)
    (out.1,p.operation.cost.plus out.2)

theorem physical_counted_execution (l : Allocation A) (ps : List Instruction) (m : A → F) :
    physicalRunCounted l ps m=(physicalRun l ps m,cost ps) := by
  induction ps generalizing m with
  | nil => rfl
  | cons p ps ih => simp only [physicalRunCounted,ih,physicalRun,cost]

theorem physical_setup_receipt (l : Allocation A) (m : A → F) :
    physicalRunCounted l program m=(physicalRun l program m,⟨1,1,13,10,2,3,1,2⟩) := by
  rw [physical_counted_execution,exact_operation_receipt]

theorem step_preserves_input (l : Allocation A) (p : Instruction) (m : A → F) :
    physicalExecute l p m l.input=m l.input := by
  simp [physicalExecute,physicalWrite,l.inputDisjoint]

theorem run_preserves_input (l : Allocation A) (ps : List Instruction) (m : A → F) :
    physicalRun l ps m l.input=m l.input := by
  induction ps generalizing m with
  | nil => rfl
  | cons p ps ih => rw [physicalRun,ih,step_preserves_input]

theorem step_simulation (l : Allocation A) (p : Instruction) (m : A → F) :
    restrict l (physicalExecute l p m)=execute (m l.input) p (restrict l m) := by
  funext j
  have heq : l.cells j=l.cells p.destination ↔ j=p.destination :=
    ⟨l.distinct j p.destination,fun h => congrArg l.cells h⟩
  simp [restrict,physicalExecute,physicalWrite,execute,write,heq]

theorem run_simulation (l : Allocation A) (ps : List Instruction) (m : A → F) :
    restrict l (physicalRun l ps m)=run (m l.input) ps (restrict l m) := by
  induction ps generalizing m with
  | nil => rfl
  | cons p ps ih =>
    rw [physicalRun,ih,step_preserves_input,step_simulation,run]

theorem step_outside_unchanged (l : Allocation A) (p : Instruction) (m : A → F)
    (a : A) (ha : ∀ j, a≠l.cells j) : physicalExecute l p m a=m a := by
  simp [physicalExecute,physicalWrite,ha]

theorem run_outside_unchanged (l : Allocation A) (ps : List Instruction) (m : A → F)
    (a : A) (ha : ∀ j, a≠l.cells j) : physicalRun l ps m a=m a := by
  induction ps generalizing m with
  | nil => rfl
  | cons p ps ih => rw [physicalRun,ih,step_outside_unchanged l p m a ha]

def slotList : List Slot := [0,1,2,3,4,5,6]
def allocatedCells (l : Allocation A) : List A := slotList.map l.cells

theorem seven_allocated_cells (l : Allocation A) : (allocatedCells l).length=7 := by
  simp [allocatedCells,slotList]

theorem allocated_cells_distinct (l : Allocation A) : (allocatedCells l).Nodup := by
  have hslots : slotList.Nodup := by decide
  exact List.Pairwise.map l.cells (fun j k hne h => hne (l.distinct j k h)) hslots

theorem input_not_allocated (l : Allocation A) : l.input∉allocatedCells l := by
  simp only [allocatedCells,List.mem_map]
  rintro ⟨j,_,h⟩
  exact l.inputDisjoint j h.symm

theorem physical_setup_output (l : Allocation A) (m : A → F) :
    table (restrict l (physicalRun l program m))=SuppliedQuarterTable.canonical (m l.input) ∧
    coefficientA (restrict l (physicalRun l program m))=GaussianGate.a (m l.input) ∧
    coefficientB (restrict l (physicalRun l program m))=GaussianGate.b (m l.input) ∧
    physicalRun l program m l.input=m l.input := by
  rw [run_simulation]
  exact ⟨table_exact (m l.input) (restrict l m),
    coefficient_a_exact (m l.input) (restrict l m),
    coefficient_b_exact (m l.input) (restrict l m),run_preserves_input l program m⟩

end ConstantSetupStorage13955
#print axioms ConstantSetupStorage13955.every_read_initialized
#print axioms ConstantSetupStorage13955.inverse_inputs_nonzero
#print axioms ConstantSetupStorage13955.step_preserves_input
#print axioms ConstantSetupStorage13955.run_preserves_input
#print axioms ConstantSetupStorage13955.step_simulation
#print axioms ConstantSetupStorage13955.run_simulation
#print axioms ConstantSetupStorage13955.step_outside_unchanged
#print axioms ConstantSetupStorage13955.run_outside_unchanged
#print axioms ConstantSetupStorage13955.seven_allocated_cells
#print axioms ConstantSetupStorage13955.allocated_cells_distinct
#print axioms ConstantSetupStorage13955.input_not_allocated
#print axioms ConstantSetupStorage13955.physical_setup_output
#print axioms ConstantSetupStorage13955.physical_counted_execution
#print axioms ConstantSetupStorage13955.physical_setup_receipt
