import CompletionData
namespace CompletionCheck008
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch008.all CompletionCertificates.check=true := by decide
end CompletionCheck008
#print axioms CompletionCheck008.valid
