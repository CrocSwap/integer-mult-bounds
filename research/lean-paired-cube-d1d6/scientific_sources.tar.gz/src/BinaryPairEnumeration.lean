import Q21AddressProgram
namespace BinaryPairEnumeration
abbrev Bits (n : Nat) := Fin n → Bool

def cons {n : Nat} (b : Bool) (x : Bits n) : Bits (n+1) := Fin.cases b x
def tail {n : Nat} (x : Bits (n+1)) : Bits n := fun j => x j.succ

def addresses : (n : Nat) → List (Bits n)
  | 0 => [fun j => Fin.elim0 j]
  | n+1 => (addresses n).map (cons false) ++ (addresses n).map (cons true)

theorem cons_zero {n : Nat} (b : Bool) (x : Bits n) : cons b x 0=b := rfl

theorem cons_succ {n : Nat} (b : Bool) (x : Bits n) (j : Fin n) : cons b x j.succ=x j := by
  simp only [cons,Fin.cases_succ]

theorem tail_cons {n : Nat} (b : Bool) (x : Bits n) : tail (cons b x)=x := by
  funext j
  exact cons_succ b x j

theorem cons_tail {n : Nat} (x : Bits (n+1)) : cons (x 0) (tail x)=x := by
  funext j
  refine Fin.cases ?_ (fun k => ?_) j
  · rfl
  · exact cons_succ _ _ _

theorem cons_injective {n : Nat} (b : Bool) (x y : Bits n) (h : cons b x=cons b y) : x=y := by
  have he := congrArg tail h
  simpa only [tail_cons] using he

theorem cons_disjoint {n : Nat} (x y : Bits n) : cons false x≠cons true y := by
  intro h
  have he := congrFun h 0
  contradiction

theorem address_count (n : Nat) : (addresses n).length=2^n := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [addresses,List.length_append,List.length_map,ih,Nat.pow_succ]
    omega

theorem all_addresses (n : Nat) (x : Bits n) : x ∈ addresses n := by
  induction n with
  | zero =>
    apply List.mem_singleton.mpr
    funext j
    exact Fin.elim0 j
  | succ n ih =>
    have hx := ih (tail x)
    rw [← cons_tail x]
    cases h : x 0
    · exact List.mem_append.mpr (Or.inl (List.mem_map.mpr ⟨tail x,hx,rfl⟩))
    · exact List.mem_append.mpr (Or.inr (List.mem_map.mpr ⟨tail x,hx,rfl⟩))

theorem addresses_nodup (n : Nat) : (addresses n).Nodup := by
  induction n with
  | zero => exact List.pairwise_singleton _ _
  | succ n ih =>
    apply List.pairwise_append.mpr
    refine ⟨List.Pairwise.map (cons false) (fun x y hxy he => hxy (cons_injective false x y he)) ih,
      List.Pairwise.map (cons true) (fun x y hxy he => hxy (cons_injective true x y he)) ih,?_⟩
    intro x hx y hy
    rcases List.mem_map.mp hx with ⟨a,ha,rfl⟩
    rcases List.mem_map.mp hy with ⟨b,hb,rfl⟩
    exact cons_disjoint a b

theorem coordinate_pair_flip (x : Bits 23) :
    CoordinateChild.flip 0 (cons false x)=cons true x := by
  funext j
  refine Fin.cases ?_ (fun k => ?_) j
  · rfl
  · simp only [CoordinateChild.flip,BinarySpace24.add,BinarySpace24.unit,cons_succ]
    have hk : (0 : Fin 24)≠k.succ := by intro h; have he := congrArg Fin.val h; simp at he
    simp only [hk,decide_false,Bool.xor_false]

theorem pair_count : (addresses 23).length=8388608 := address_count 23

theorem full_address_count : (addresses 24).length=16777216 := address_count 24

theorem pair_partition (x : Bits 24) (b : Bool) (y : Bits 23) :
    cons b y=x ↔ b=x 0 ∧ y=tail x := by
  constructor
  · intro h
    refine ⟨?_,?_⟩
    · exact congrFun h 0
    · have he := congrArg tail h
      simpa only [tail_cons] using he
  · rintro ⟨rfl,rfl⟩
    exact cons_tail x

end BinaryPairEnumeration
#print axioms BinaryPairEnumeration.cons_zero
#print axioms BinaryPairEnumeration.cons_succ
#print axioms BinaryPairEnumeration.tail_cons
#print axioms BinaryPairEnumeration.cons_tail
#print axioms BinaryPairEnumeration.cons_injective
#print axioms BinaryPairEnumeration.cons_disjoint
#print axioms BinaryPairEnumeration.address_count
#print axioms BinaryPairEnumeration.all_addresses
#print axioms BinaryPairEnumeration.addresses_nodup
#print axioms BinaryPairEnumeration.coordinate_pair_flip
#print axioms BinaryPairEnumeration.pair_count
#print axioms BinaryPairEnumeration.full_address_count
#print axioms BinaryPairEnumeration.pair_partition
