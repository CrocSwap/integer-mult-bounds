import CompletionData
namespace CompletionCheck002
set_option maxRecDepth 20000
set_option maxHeartbeats 8000000
theorem valid : CompletionData.batch002.all CompletionCertificates.check=true := by decide
end CompletionCheck002
#print axioms CompletionCheck002.valid
