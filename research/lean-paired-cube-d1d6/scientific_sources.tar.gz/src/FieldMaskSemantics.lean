import FieldLinearEvaluation
namespace FieldMaskSemantics
open Lean.Grind MaskRows MaskModels DagSemantics
attribute [local instance] Semiring.natCast Ring.intCast
variable {F : Type u} [Field F]

def rowValue (width : Nat) (row : Row) (payload : Nat → F) : F :=
  FieldEvaluation.evaluate (coefficients width row) ((List.range width).map payload)

def value (width : Nat) (rows : Nat → Row) (payload : Nat → F) (n : Nat) : F :=
  rowValue width (rows n) payload

theorem row_zero (width : Nat) (payload : Nat → F) : rowValue width ⟨0,0⟩ payload = 0 := by
  unfold rowValue
  rw [coefficients_zero]
  exact FieldEvaluation.evaluate_zeros _ _

theorem row_input (width i : Nat) (hi : i<width) (payload : Nat → F) :
    rowValue width ⟨2^i,0⟩ payload = payload i := by
  unfold rowValue
  rw [SignedPacking.mask_singleton_basis, FieldEvaluation.evaluate_basis width i _ (by simp) hi]
  simp [List.getElem?_map, List.getElem?_range hi]

theorem row_plus (width : Nat) (a b : Row) (hd : disjoint a b) (payload : Nat → F) :
    rowValue width (plus a b) payload = rowValue width a payload + rowValue width b payload := by
  unfold rowValue
  rw [coefficients_plus width a b hd]
  exact FieldLinearEvaluation.evaluate_add _ _ _ (by simp [coefficients])

theorem row_negate (width : Nat) (r : Row) (payload : Nat → F) :
    rowValue width (negate r) payload = -(rowValue width r payload) := by
  unfold rowValue
  rw [coefficients_negate, FieldEvaluation.evaluate_scale]
  rw [Ring.intCast_neg_one, Ring.neg_mul, Semiring.one_mul]

theorem row_signed (width : Nat) (a b : Row) (negative : Bool) (hd : disjoint a b) (payload : Nat → F) :
    rowValue width (signed a b negative) payload = rowValue width a payload +
      if negative then -(rowValue width b payload) else rowValue width b payload := by
  cases negative with
  | false => exact row_plus width a b hd payload
  | true =>
    change rowValue width (plus a (negate b)) payload = _
    rw [row_plus width a (negate b) (disjoint_negate a b hd), row_negate]
    rfl

theorem value_zero (width : Nat) (node : Nat → Spec) (rows : Nat → Row) (payload : Nat → F)
    (hc : ∀ n, rowCheck width node rows n = true) (n : Nat) (hn : node n = .zero) :
    value width rows payload n = 0 := by
  have h := hc n
  simp only [rowCheck, hn] at h
  have hr : rows n=⟨0,0⟩ := of_decide_eq_true h
  unfold value
  rw [hr]
  exact row_zero width payload

theorem value_input (width : Nat) (node : Nat → Spec) (rows : Nat → Row) (payload : Nat → F)
    (hc : ∀ n, rowCheck width node rows n = true) (n i : Nat) (hn : node n = .input i) :
    value width rows payload n = payload i := by
  have h := hc n
  simp only [rowCheck, hn] at h
  have hr : i<width ∧ rows n=⟨2^i,0⟩ := of_decide_eq_true h
  unfold value
  rw [hr.2]
  exact row_input width i hr.1 payload

theorem value_add (width : Nat) (node : Nat → Spec) (rows : Nat → Row) (payload : Nat → F)
    (hc : ∀ n, rowCheck width node rows n = true) (n l r : Nat) (negative : Bool)
    (hn : node n = .add l r negative) :
    value width rows payload n = value width rows payload l +
      if negative then -(value width rows payload r) else value width rows payload r := by
  have h := hc n
  simp only [rowCheck, hn] at h
  have hr : disjoint (rows l) (rows r) ∧ rows n = signed (rows l) (rows r) negative := of_decide_eq_true h
  unfold value
  rw [hr.2]
  exact row_signed width (rows l) (rows r) negative hr.1 payload

end FieldMaskSemantics
#print axioms FieldMaskSemantics.row_zero
#print axioms FieldMaskSemantics.row_input
#print axioms FieldMaskSemantics.row_plus
#print axioms FieldMaskSemantics.row_negate
#print axioms FieldMaskSemantics.row_signed
#print axioms FieldMaskSemantics.value_zero
#print axioms FieldMaskSemantics.value_input
#print axioms FieldMaskSemantics.value_add
