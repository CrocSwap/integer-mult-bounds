import DagSemantics
namespace DagSemantics
open PairedWord

def Realizes (g : Graph) (payload f : State) : Prop := ∀ n,
  f n = match g.node n with
  | .zero => 0
  | .input i => payload i
  | .add l r neg => f l + if neg then -(f r) else f r

theorem value_realizes (g : Graph) (payload : State) : Realizes g payload (value g payload) := by
  intro n
  rw [value]
  cases g.node n <;> rfl

theorem realization_unique (g : Graph) (payload f : State) (h : Realizes g payload f) :
    ∀ n, f n = value g payload n := by
  intro n
  induction n using Nat.strongRecOn with
  | ind n ih =>
    have hh := h n
    cases hn : g.node n with
    | zero => simpa only [hn, value_zero g payload n hn] using hh
    | input i => simpa only [hn, value_input g payload n i hn] using hh
    | add l r neg =>
      have bounds := g.topological n l r neg hn
      have hl := ih l bounds.1
      have hr := ih r bounds.2
      simpa only [hn, hl, hr, value_add g payload n l r neg hn] using hh

theorem realizations_equal (g : Graph) (payload f₁ f₂ : State)
    (h₁ : Realizes g payload f₁) (h₂ : Realizes g payload f₂) : f₁ = f₂ := by
  funext n
  rw [realization_unique g payload f₁ h₁ n, realization_unique g payload f₂ h₂ n]

end DagSemantics
#print axioms DagSemantics.value_realizes
#print axioms DagSemantics.realization_unique
#print axioms DagSemantics.realizations_equal
