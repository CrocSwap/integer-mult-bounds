import ActualWordCorollaries

namespace PairedDecoder
open PairedWord

/- Integer decoder after multiplying all rational readout coefficients by six. -/
structure ReadTerm where
  role : Nat
  coefficient : Int
  deriving DecidableEq

def evaluate : List ReadTerm → State → Int
  | [], _ => 0
  | t :: ts, x => t.coefficient * x t.role + evaluate ts x

def decode6 (rows : List (List ReadTerm)) (x : State) : State :=
  fun target => evaluate (rows[target]?.getD []) x

def inject (x : State) : State :=
  fun role => if role % 3 = 0 ∧ role / 3 < 1760 then x (role / 3) else 0

theorem evaluate_add (terms : List ReadTerm) (x y : State) :
    evaluate terms (add x y) = evaluate terms x + evaluate terms y := by
  induction terms with
  | nil => simp [evaluate]
  | cons t ts ih =>
    simp only [evaluate, add, Int.mul_add, ih]
    omega

theorem decode6_add (rows : List (List ReadTerm)) (x y : State) :
    decode6 rows (add x y) = PairedWordCorollaries.targetAdd (decode6 rows x) (decode6 rows y) := by
  funext target
  exact evaluate_add _ x y

theorem inject_add (x y : State) : inject (add x y) = add (inject x) (inject y) := by
  funext role
  simp only [inject, add]
  split <;> simp

theorem inject_at_source (x : State) (i : Nat) (h : i < 1760) : inject x (3*i) = x i := by
  simp [inject, Nat.mul_comm 3 i, h]

theorem inject_away_from_sources (x : State) (role : Nat)
    (h : ¬ (role % 3 = 0 ∧ role / 3 < 1760)) : inject x role = 0 := by
  simp [inject, h]

def termValid (t : ReadTerm) : Bool :=
  decide (t.role < 26417 ∧
    (t.coefficient = -3 ∨ t.coefficient = -1 ∨ t.coefficient = 2 ∨ t.coefficient = 3))

def rowValid (row : List ReadTerm) : Bool :=
  decide (row.length = 31) && row.all termValid

theorem valid_row_sound (row : List ReadTerm) (h : rowValid row = true) :
    row.length = 31 ∧ ∀ t ∈ row, t.role < 26417 ∧
      (t.coefficient = -3 ∨ t.coefficient = -1 ∨ t.coefficient = 2 ∨ t.coefficient = 3) := by
  have hh := Bool.and_eq_true_iff.mp h
  exact ⟨of_decide_eq_true hh.1, fun t ht => of_decide_eq_true ((List.all_eq_true.mp hh.2) t ht)⟩

end PairedDecoder
#print axioms PairedDecoder.evaluate_add
#print axioms PairedDecoder.decode6_add
#print axioms PairedDecoder.inject_add
#print axioms PairedDecoder.inject_at_source
#print axioms PairedDecoder.inject_away_from_sources
#print axioms PairedDecoder.valid_row_sound
