"""Generate a 38-owner binary caller directly over q=1+epsilon, epsilon^2=0."""
from collections import Counter
from itertools import permutations
from hashlib import sha256
from pathlib import Path
import gzip,json,sys

H=Path(__file__).resolve().parent
sys.path.insert(0, str(H))
import common as C

def bits(x):
    while x:
        bit=x & -x
        yield bit.bit_length()-1
        x ^= bit

def xor_vec(ids,values):
    v=0
    for i in bits(ids):v^=values[i]
    return v

def inverse_columns(cols):
    n=len(cols);piv={}
    for i,x in enumerate(cols):
        v=1<<i
        while x and x.bit_length() in piv:
            y,s=piv[x.bit_length()];x^=y;v^=s
        if not x:return None
        piv[x.bit_length()]=(x,v)
    inv=[]
    for i in range(n):
        x=1<<i;v=0
        while x:
            y,s=piv[x.bit_length()];x^=y;v^=s
        inv.append(v)
    return [sum(((inv[i]>>j)&1)<<i for i in range(n)) for j in range(n)]

def query(u,v):
    """Conjugate one QUERY and one ADD to I+epsilon*u*v^T."""
    assert u and v and not (u&v).bit_count()%2
    best=None
    for p in bits(v):
        for d in bits(u&~(1<<p)):
            grab=[['ADD',p,j] for j in bits(v&~(1<<p))]
            spread=[['ADD',j,d] for j in bits(u&~((1<<p)|(1<<d)))]
            pre=grab+spread
            cur=pre+[['QUERY',d,p],['ADD',d,p]]+pre[::-1]
            if best is None or len(cur)<len(best):best=cur
    assert best;return best

def small_seam(u,v):
    best=None;bestterms=None
    for cols in permutations(range(1,16),4):
        inv=inverse_columns(cols)
        if not inv:continue
        terms=[(xor_vec(c,u),xor_vec(r,v)) for c,r in zip(cols,inv)]
        if any((a&b).bit_count()%2 for a,b in terms):continue
        # Conjugate into six already-compressed owner registers; other owners are independent.
        e=sum((query(a,b) for a,b in terms),[])
        e=compact(e)
        if best is None or len(e)<len(best):best=e;bestterms=terms
    assert best is not None;return best,bestterms

def compact(evs):
    out=[]
    for e in evs:
        if out and e==out[-1] and e[0] in ('ADD','SWAP'):
            out.pop()
        else:out.append(e)
    return out

def make(a=9,b=9):
    L=a+b;h=L+1;assert L%2==0 and L>=4
    def stages(t):
        out=[]
        for hub in (0,h):
            arm=hub+t
            out.extend([['ADD',hub,arm],['LOCAL',t,hub,arm],['ADD',arm,hub],['ADD',hub,arm]])
        return out
    ev=[]
    for s in range(1,a+1):ev.extend(stages(s))
    for hub in (0,h):
        for arm in range(1,a):ev.append(['IDLE_ONE',hub+arm,list(range(arm+1,a+1))])
    cut=len(ev)
    change=[];us=[];vs=[]
    for hub in (0,h):
        first,last=hub+1,hub+L
        change.extend([['ADD',j,first] for j in range(first+1,last+1)])
        change.extend([['ADD',last,j] for j in range(first+1,last)])
        us.extend([1<<hub,1<<first]);vs.extend([(1<<hub)|(1<<last),1<<hub]);
    seam,terms=small_seam(us,vs)
    ev+=change+seam+change[::-1]
    end=len(ev)
    for hub in (0,h):
        for arm in range(a+2,L+1):ev.append(['IDLE_ONE',hub+arm,list(range(a+1,arm))])
    for s in range(a+1,L+1):ev.extend(stages(s))
    diagonal=[]
    for hub in (0,h):
        diagonal.append({'q':1,'stages':list(range(1,L+1))})
        for i in range(1,L+1):diagonal.append({'q':1,'stages':list(range(i,a+1)) if i<=a else list(range(a+1,i+1))})
    return (dict(schema='paired-efree-bit/1',roles=2*h,stages=L,ports=111,native_per_stage=2,body_rank=7,ambient_rank=7*L+1,events=compact(ev),diagonal=diagonal),{'expanded_seam_range':[cut,end],'compact_seam_terms':[[list(bits(x)),list(bits(y))] for x,y in terms],'small_seam_word':seam,'pre_and_post_length':len(change)})

def verify():
    w,old,_,np,nt,P,T,rat=C.baseline();new,detail=make();ops=Counter(e[0] for e in new['events']);po,to=C.literal.paired_invoice(new,np,nt,ops);assert P==po and T==to
    assert C.literal.caller_rows(new)==C.literal.caller_rows(old) and C.literal.caller_rows(new,True)==C.literal.caller_rows(old,True)
    C.check(old['diagonal']==new['diagonal'],'exact unchanged owner-to-stage association')
    rawfn=C.literal.ordinary
    oo=Counter(e[0] for e in old['events']);c1=rawfn(w,old,oo,P,T);c2=rawfn(w,new,ops,po,to)
    raw=json.dumps(new,sort_keys=True,separators=(',',':')).encode()
    assert raw==gzip.decompress((H/'CALLER.json.gz').read_bytes())
    out={'scope':'new binary-only 9+9 caller, fixed 680-owner native and original rational companion; literal GF(2)[D_1,..,D_18,q]/(q^2-1) full operator and transpose','caller_canonical_sha256':sha256(raw).hexdigest(),'caller_gzip_sha256':sha256((H/'CALLER.json.gz').read_bytes()).hexdigest(),'forward_adj_each_coefficients':38**2,'native_forward_adj_each_coefficients':680**2,'native_paid':np,'native_productive':nt,'old_full_paid':P,'old_full_productive':T,'new_full_paid':po,'new_full_productive':to,'old_macro_counts':oo,'new_macro_counts':ops,'old_macro_total':len(old['events']),'new_macro_total':len(new['events']),'old_resources':c1,'new_resources':c2,'BIT_margins':{str(k):C.display(C.moment(po,to,k)) for k in C.RATES},'seam':detail}
    rr=rat['signed'];out['rational_source']=rr['caller_sha256'];out['rational_native_calls']=rr['native_calls'];out['rational_paid']=rr['paid'];out['rational_productive']=rr['productive'];out['rational_margins']={str(k):C.display(C.moment(rr['paid'],rr['productive'],k)) for k in C.RATES}
    assert json.dumps(out,indent=2)+'\n'==(H/'CALLER-RESULT.json').read_text()
    return new,out
if __name__=='__main__':
    _,result=verify()
    print('PASS', result['new_macro_total'], 'binary caller instructions, 1,444 coefficients per orientation and identical full tariffs')
