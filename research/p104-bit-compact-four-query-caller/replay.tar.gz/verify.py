#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Rebuild the literal caller and verify the four-query signed-tariff obstruction."""
from collections import Counter
from copy import deepcopy
from itertools import product
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import common as C
from caller import bits,verify

def rank(rows):
    table={}
    for row in rows:
        while row and row.bit_length() in table:row^=table[row.bit_length()]
        if row:table[row.bit_length()]=row
    return len(table)

def mul_row(row,mat):
    output=0
    for index in bits(row):output^=mat[index]
    return output

def main():
    caller,results=verify();shapes=Counter();clean=[]
    for M in product(range(16),repeat=4):
        if rank(M)!=2 or any(mul_row(row,M) for row in M):continue
        arm=(M[2]>>2,M[3]>>2);shapes[rank((arm[0]^1,arm[1]^2))]+=1
        if arm!=(1,2):continue
        B=(M[0]>>2,M[1]>>2);Cblock=(M[2]&3,M[3]&3)
        assert rank(B)==rank(Cblock)==2
        for S in product(range(4),repeat=2):
            assert rank((S[0]|B[0]<<2,S[1]|B[1]<<2,*Cblock))==4
        clean.append(list(M))
    assert sum(shapes.values())==210 and len(clean)==6
    old_q=results['old_macro_counts']['QUERY'];assert old_q==4
    debts={}
    for k in C.RATES:
        increments=[C.minus(C.power(g,k),C.power(g-1,k)) for g in (8,15,22,29,36,43,50,57,64,127)]
        increments.extend(C.minus(C.power(g+1,k),C.power(g,k)) for g in range(7,57,7))
        least=min(x[0] for x in increments);assert 5*least>4
        debts[str(k)]={'minimum_head_debit':str(least),'count_five_strictly_over_four':True,'maximum_touched_stage_arm_pairs_before_rank_check':4,'minimum_untouched_clean_stages_if_t_at_most_3':18-4-3}
    expected=C.literal.caller_rows(caller)
    mask_mut=deepcopy(caller);mask_mut['diagonal'][0]['q']=0
    actual=[{C.literal.caller_monomial(x['stages'])|x['q']:1<<j} for j,x in enumerate(mask_mut['diagonal'])]
    assert expected!=actual
    controls={}
    for op in ('LOCAL','QUERY','IDLE_ONE','ADD'):
        j=next(i for i,e in enumerate(caller['events']) if e[0]==op);bad=deepcopy(caller);bad['events'].pop(j)
        df=sum(a!=b for a,b in zip(expected,C.literal.caller_rows(bad)));da=sum(a!=b for a,b in zip(expected,C.literal.caller_rows(bad,True)));assert df and da
        controls[op]={'clock':j,'bad_forward_rows':df,'bad_adjoint_rows':da}
    cert={'rank_two_square_zero_matrices_on_four_fields':sum(shapes.values()),'by_rank_of_I_plus_arm_block':dict(sorted(shapes.items())),'clean_full_rank_matrices':clean,'all_possible_four_by_four_hub_blocks_rechecked_per_clean_stage':16,'number_of_independent_stage_choices_as_decimal':str(210**18),'outward_increment_checks':debts,'deleting_a_paid_or_ordinary_event':controls,'flipping_target_q_rejected':True}
    dump=json.dumps(cert,indent=2)+'\n'
    if '--write-certificate' in sys.argv:(ROOT/'SEAM-BOUND.json').write_text(dump)
    else:assert dump==(ROOT/'SEAM-BOUND.json').read_text()
    print('PASS 324 macro events, all BIT and native coefficients in both orientations, identical signed profiles, four deletion controls, 210 square-zero stage maps, rank-four cut')
if __name__=='__main__':main()
