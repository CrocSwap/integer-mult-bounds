# The unique funded contact pair after chart-268's side repair

Starting with the 89-forward-error chart-268 word, a general change to earlier payloads still has to put enough scalar capacity on the graph. When the zero 421→1 send is freed for reuse and the other paid incidences are retained, **51,659 of 51,660 funded two-contact choices violate the full binary operator's cut rank**. The one remaining pair consists of the same 421→1 send and a new 0→19 send. Removing the zero send yields no new candidate incidence pattern in this family. Returning its old scalar incidence and adding 0→19 passes the cuts in this package. Whether its senders can implement the entire operator remains open. [Round 9 construction](https://github.com/CrocSwap/integer-mult-bounds/pull/8006)

## Starting program and funding

The native binary map has 680 owners. Owners 111 through 221 request the XOR of their input and the corresponding owner 0 through 110. Each other owner requests its own input. The concrete side repair changes the native routes 421→19→0 into 421→0 and rebinds the 0→182 transmission to 19→182. It recovers owners 221, 411 and 679 in both orientations. It still fails 89 forward and 29 literal adjoint rows. The native source and the concrete damaged tape are both included and individually hash-checked. [Frozen native input](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier)

At the trial rate 0.00388 the full 36-call binary margin starts at −0.02771136019021759 on the unmodified profile and +36.15481217569851 on the damaged side word. Retiring its zero grade-two 421→1 send leaves +107.96143473161292. Three new grade-one sends would leave −0.03856526838708. Two grade-two sends or a grade-one plus a grade-three also exceed the budget. A single grade-three send could still be paid, but a single contact would have to join chart 0 to chart 1 directly. Their grade is eight, leaving −177.724262832286. The necessary pairs, with the grade of the chart-0 send listed first, are therefore (1,1), (2,1) and (1,2). Each pair of grades (1,2) leaves +0.15481217569851. The unchanged 48-call rational margin is +0.13897452233425. RESULT.json contains directed whole-caller intervals and all nonzero paid and productive bins for both 0.00388 and 0.0038800000000000083.

## Complete binary cut proof

For a set of charts S, retain only input columns that start inside S and output rows that terminate outside S. Call the exact binary rank of this submatrix r. The exterior sees those interior inputs only through the ordered list of scalar sends from S to its complement. If there are m sends, every exterior output factors through at most m binary coordinates, so m must be at least r. Feedback and causal reordering preserve this inequality.

Chart 0 contains 524 independent input owners and no final owners. After the 1583 change only 523 sends leave chart 0. Chart 1 contains all 537 independent target owners terminating there and has no initial owners. Retiring 2678 leaves 536 sends entering chart 1. Consequently one payment must leave 0 and one must enter 1. The directed grade-eight contact 0→1 is the only single payment satisfying both requirements.

- **A grade-one send into chart 1.** For each of its 120 legal senders H, choose the complement of {1,H} as the cut. The send H→1 lies within the two-chart receiving side. A chart-0 send of grade one or two cannot enter that side. The exact restricted operator rank exceeds the new incoming capacity by one. This excludes all 13,320 pairs of grades (1,1) and all 18,360 pairs of grades (2,1).
- **A grade-one send from chart 0 and grade-two send into chart 1.** For any of the 110 lines L other than 19, the cut {0,L} has 525 independent directions to deliver and 524 outgoing sends. The viable first incidence has to be 0→19. For each six-dimensional sender K other than 421, use the cut complementary to chart 1, K, and its two native seven-dimensional neighbors. The grade-two send K→1 lies within this four-chart receiving side. Each exact rank exceeds the available capacity by one. The test covers all 179 alternative senders, including eight where one of the two native neighbor incidences is incoming. Among the 19,980 pairs of grades (1,2), only (0→19,421→1) remains.
- **Keeping the 421→1 send throughout.** At most one extra grade-one send can then be afforded and it must leave chart 0. The same 110 four-hundred-plus-rank source checks leave only 0→19.

The verifier computes the rows, chart grade relationships, original and changed multiplicities and 409 cut certificates directly from the pinned bytes. It checks each of the 51,659 exclusions individually and verifies that the remaining pair respects every exhibited partition. Donors and decoder equations on all retained incidences may change, including the two chart-268 branches, the 421 stock, every chart-0 output and the terminal decoders. These exclusions use physical counts and the desired public operator. Other incidence changes or a changed productive boundary would require their own tariff and proof.

## Reproduce

Use Python 3.11 or later with its standard library.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
```

The oracle for the original profile verifies all 680 rows in both orientations, the 111 productive main contacts, the 36-event local caller and the complete native paid/productive profile. The second interpreter replays the damaged tape and checks the counted differences. The rational profile retains its separate 48-call assumptions. This family supplies no new conditional κ value and makes no finite outer adoption claim. [Selected 451 comparator](https://github.com/CrocSwap/integer-mult-bounds/pull/7863) · [Independent replay](https://github.com/CrocSwap/integer-mult-bounds/pull/7973)
