# SPDX-License-Identifier: Apache-2.0
"""Verify the chart-0 and chart-1 emission cuts and complete caller prices."""
from collections import Counter
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))
import common
import binary_operator as operator


def require(condition, message):
    if not condition:
        raise ValueError(message)


def gf2_rank(rows):
    pivots = {}
    for row in rows:
        while row:
            lead = row.bit_length() - 1
            if lead not in pivots:
                pivots[lead] = row
                break
            row ^= pivots[lead]
    return len(pivots)


def replay():
    native, caller, _, native_grades, helpers, orig_paid, productive, rational = common.baseline()
    atlas = operator.Atlas(native['frames'])
    charts = frozenset(atlas.body)
    require(charts == frozenset(range(636)), 'chart inventory')
    start, end = native['start'], native['final']
    target = operator.expected_operator(False)
    orientations = [operator.expected_operator(r) for r in (False, True)]
    native_tapes = [operator.run_tape(native, atlas, r) for r in (False, True)]
    require(all(t.output == want for t, want in zip(native_tapes, orientations)), 'native complete transfer and adjoint')
    native_edges = Counter((p.source, p.receiver) for p in native_tapes[0].packets.values())
    orig = native_tapes[0].packets
    require([(orig[j].source, orig[j].receiver) for j in (1583, 2678, 3409, 3410, 3553)]
            == [(0,182),(421,1),(421,19),(19,0),(509,1)], 'original label incidences')
    raw_side = (ROOT / 'RESTORED-SIDE-WORD.json.gz').read_bytes()
    side_hash = sha256(raw_side).hexdigest()
    require(side_hash == '84b53c2d8c69c77f9e36b45e238f8be7dae62e6a5ebffeac45c108fe7be0e98a', 'Round 9 concrete side word')
    side_word = json.loads(gzip.decompress(raw_side))
    require((start, end) == (side_word['start'], side_word['final']) and native['frames'] == side_word['frames'], 'fixed public boundary and common atlas')
    both = [operator.run_tape(side_word, atlas, r) for r in (False, True)]
    failures = [[i for i,(x,y) in enumerate(zip(t.output,want)) if x!=y] for t,want in zip(both,orientations)]
    require(list(map(len,failures))==[89,29], 'Round 9 full literal damaged controls')
    require(all(i not in f for i in (221,411,679) for f in failures), 'protected, timed, and helper control rows')
    require(all(not (p.arrival.row & 1<<679) for p in both[0].packets.values() if p.receiver == 1), 'saturated sink on helper')
    side = Counter((p.source,p.receiver) for p in both[0].packets.values())
    expected_side = native_edges.copy()
    expected_side.subtract([(0,182),(421,19),(19,0)])
    expected_side.update([(19,182),(421,0)])
    require(side == expected_side, 'complete side-word incidence changes')
    remaining = side.copy()
    remaining.subtract([(421,1)])
    require(min(remaining.values())>=0, 'existing 2678 deletion')
    require(any(p.source==421 and p.receiver==1 and p.arrival.row==0 for p in both[0].packets.values()), 'concrete zero 2678 incidence')
    def invoice(grades):
        pd,pt = common.literal.paired_invoice(caller, grades, helpers,
                          Counter(e[0] for e in caller['events']))
        require(pt==productive, 'fixed productive operator and helper invoice')
        return pd
    side_grades = Counter(p.grade for p in both[0].packets.values())
    require(sum(side_grades.values())==2873, 'changed literal MOVE count')
    remaining_grades=side_grades.copy()
    remaining_grades[2]-=1
    signed_r = rational['signed']
    rp={int(k):v for k,v in signed_r['paid'].items()}
    rt={int(k):v for k,v in signed_r['productive'].items()}
    rates=[common.D('0.00388'),common.D('0.0038800000000000083')]
    budget={}
    for rate in rates:
        def info(extra):
            grades=remaining_grades.copy()
            grades.update(extra)
            paid=invoice(grades)
            return dict(primitive_paid=dict(sorted(grades.items())),binary_paid=dict(sorted(paid.items())),
                        binary_margin=common.display(common.moment(paid,productive,rate)))
        m=common.moment(invoice(remaining_grades),productive,rate)
        by_grades={
            ','.join(map(str,grades)):info(grades)
            for grades in [(),(1,),(2,),(3,),(4,),(8,),(1,1),(1,2),(1,3),(2,2),(1,1,1)]
        }
        for gr,yes in [('',True),('3',True),('4',False),('8',False),('1,1',True),
                       ('1,2',True),('1,3',False),('2,2',False),('1,1,1',False)]:
            lo,hi=map(common.D,by_grades[gr]['binary_margin'])
            require(lo>0 if yes else hi<0, 'strict funding at both trial rates: '+gr)
        budget[str(rate)]=dict(original_binary=common.display(common.moment(orig_paid,productive,rate)),
               restored_side=common.display(common.moment(invoice(side_grades),productive,rate)),
               after_removing_2678=common.display(m),rational_48=common.display(common.moment(rp,rt,rate)),
               grades=by_grades)
    @lru_cache(None)
    def fixed_cut(s):
        ins=sum(1<<i for i,t in enumerate(start) if t in s)
        rank=gf2_rank(target[i]&ins for i,t in enumerate(end) if t not in s)
        nat=sum(n for (a,b),n in native_edges.items() if a in s and b not in s)
        after=sum(n for (a,b),n in remaining.items() if a in s and b not in s)
        require(nat>=rank,'original meets every cut')
        return rank,nat,after
    def crosses(a,b,s):
        return int(a in s and b not in s)
    def check_plan(s, extras):
        rank,native_cap,cap=fixed_cut(frozenset(s))
        cap+=sum(crosses(a,b,s) for a,b in extras)
        return rank,native_cap,cap
    at0=check_plan({0},[])
    at1=check_plan(charts-{1},[])
    require(at0==(524,524,523) and at1==(537,537,536),'unconditional output/input deficits')
    n0={g:sorted(c for c in charts if atlas.grade(0,c)==g) for g in (1,2)}
    n1={g:sorted(c for c in charts if atlas.grade(c,1)==g) for g in (1,2)}
    require([len(n0[1]),len(n0[2]),len(n1[1]),len(n1[2])]==[111,153,120,180],'finite neighbor rosters')
    require(atlas.grade(0,1)==8, 'joint single contact grade')
    require(19 in n0[1] and 421 in n1[2], 'remaining legal incidences')
    certificates={}
    def register(s):
        s=frozenset(s)
        rank,original,reduced=fixed_cut(s)
        key=('inside' if len(s)<318 else 'outside')+'-'+','.join(map(str,sorted(s if len(s)<318 else charts-s)))
        certificates.setdefault(key,dict(side_kind=key.split('-')[0],chart_labels=sorted(s if len(s)<318 else charts-s),
                                        rank=rank,native_capacity=original,capacity_after_three_changes_and_2678_removal=reduced))
        return key
    singleton={}
    for line in n0[1]:
        if line!=19:
            side0=frozenset([0,line])
            spec=check_plan(side0,[(421,1),(0,line)])
            require(spec==(525,525,524),'line-specific 525-direction source cut')
            singleton[line]=register(side0)
    sink1={h:register(charts-{1,h}) for h in n1[1]}
    sink2={}
    for k in n1[2]:
        neighbors={b for (a,b),n in native_edges.items() if n and a==k and len(atlas.body[b])==7}
        neighbors.update(a for (a,b),n in native_edges.items() if n and b==k and len(atlas.body[a])==7)
        if k!=421:
            require(len(neighbors)==2, 'two native hyperplane neighbors of each alternative six-dimensional chart')
            sink2[k]=register(charts-{1,k,*neighbors})
    counts={}
    survivors=[]
    for g0,g1 in ((1,1),(2,1),(1,2)):
        ct=Counter()
        for a in n0[g0]:
            for b in n1[g1]:
                extras=((0,a),(b,1))
                if g1==1:key=sink1[b]
                elif a!=19:key=singleton[a]
                elif b!=421:key=sink2[b]
                else:
                    survivors.append(list(extras));ct['survives_these_cuts']+=1;continue
                item=certificates[key]
                s=set(item['chart_labels'])
                if item['side_kind']=='outside':s=charts-s
                # The positive scalar capacity only changes at the two proposed incidences.
                rank,_,after=check_plan(s,extras)
                require(rank==after+1 and item['rank']==rank,'rank exceeds actual physical capacity by one')
                ct['excluded']+=1
        counts[str((g0,g1))]=dict(ct)
    require(survivors==[[(0,19),(421,1)]], 'one incidence pair remains')
    require(sum(sum(c.values()) for c in counts.values())==51660 and sum(c.get('excluded',0) for c in counts.values())==51659,'two-receipt census')
    require(sum(1 for _ in singleton)==110,'complete one-addition alternatives on retained 2678')
    for item in certificates.values():
        s=set(item['chart_labels'])
        if item['side_kind']=='outside':s=charts-s
        r,_,cap=check_plan(s,[(0,19),(421,1)])
        require(cap>=r,'surviving control respects every exhibited partition')
    return dict(source_gzip=operator.WORD_GZIP,native_canonical=operator.WORD,restored_side_gzip=side_hash,
            protected_native_bridge=3553,baseline_680_errors=list(map(len,failures)),both_correct_on=[221,411,679],
            signed=budget,binary_productive=dict(sorted(productive.items())),native_paid=dict(sorted(orig_paid.items())),
            after_removal_single_chart_cuts={'source0':at0,'sink1':at1},grade_0_to_1=8,
            neighbor_rosters={'from0':n0,'into1':n1},single_new_receipt_with_2678_retained={'excluded':110,'survivor':[0,19]},
            paired_receipts=counts,surviving_incidence_pair=survivors[0],partitions=certificates,
            caveat='The surviving topology passes the exhibited cuts. No successful encoder is inferred.')

if __name__=='__main__':
    result=replay()
    encoded=json.dumps(result,sort_keys=True,indent=2)+'\n'
    if '--write' in sys.argv:
        (ROOT/'RESULT.json').write_text(encoded)
    else:
        require((ROOT/'RESULT.json').read_text()==encoded,'deterministic receipt matches')
    print('PASS: literal controls, both complete caller prices, 110 single-contact exclusions and 51,659 of 51,660 funded replacement pairs.')
