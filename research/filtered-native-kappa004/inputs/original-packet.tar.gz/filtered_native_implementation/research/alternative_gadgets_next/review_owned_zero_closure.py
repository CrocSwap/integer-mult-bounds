#!/usr/bin/env python3
"""Independent SSA/flow-certificate review for the owned-zero supplier.

No maximum-flow optimizer or root replay is called.  One reverse bitset pass
binds every singleton implication; a few independently specialized executions
check the liveness semantics directly.
"""
from collections import Counter,defaultdict,deque
from decimal import Decimal as D,localcontext
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import gzip
import json
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def add(dst,src,a):
    for key,v in list(src.items()):
        z=dst.get(key,Fr(0))+a*v
        if z:dst[key]=z
        else:dst.pop(key,None)


def replay(blob,chosen):
    chosen=set(chosen);c=blob['canonical'];size=641
    rows=[{(i,()):Fr(1)} if 112<=i<224 or i in chosen else {} for i in range(size)]
    frames=c['start'][:]+[None]*(size-632)
    def support(row):
        mask=0
        for i,w in row:mask|=1<<(i-112)
        return mask
    nodes=[{'owner':i,'event':None,'index':None,'deps':[],
            'support':support(rows[i]),'frame':frames[i]} for i in range(size)]
    state=list(range(size))
    events=[e for e in blob['programs']['backward'] if e[0]!='physical_add']
    def ix(ref):
        assert ref[0] in ('L','C')
        x=ref[1]+(632 if ref[0]=='C' else 0)
        assert 0<=x<size
        return x
    for pos,e in enumerate(events):
        typ=e[0];dst=None;deps=[]
        if typ=='scalar':
            op,f=e[1:];kind=op[0];dst=ix(op[1])
            if kind=='clear':
                assert dst>=632;rows[dst]={};frames[dst]=f
            else:
                assert frames[dst]==f
                if kind in ('copy','add'):
                    src=ix(op[2]);assert frames[src]==f and src!=dst
                    if kind=='copy':
                        assert dst>=632;rows[dst]=dict(rows[src]);deps=[state[src]]
                    else:
                        add(rows[dst],rows[src],Fr(op[3],op[4]));deps=[state[dst],state[src]]
                else:
                    assert kind=='scale';a=Fr(op[2],op[3]);assert a or dst>=632
                    rows[dst]={k:a*v for k,v in rows[dst].items() if a*v};deps=[state[dst]]
        elif typ=='warp':
            _,ref,letter,f,g=e;dst=ix(ref);assert frames[dst]==f
            letter=(1 if letter>0 else -1)*(1000000+abs(letter))
            dest={}
            for (i,w),v in rows[dst].items():
                nw=w[1:] if w and w[0]==-letter else (letter,)+w
                dest[i,nw]=dest.get((i,nw),Fr(0))+v
            rows[dst]={k:v for k,v in dest.items() if v};frames[dst]=g;deps=[state[dst]]
        elif typ=='climb':
            _,_,dst,f,g,rank=e;assert frames[dst]==f
            assert rank==len(c['frames'][g])-len(c['frames'][f]) and rank>0
            frames[dst]=g;deps=[state[dst]]
        elif typ=='adapter':
            dst=e[2];deps=[state[dst]]
        else:assert typ=='phase'
        if dst is not None:
            nodes.append({'owner':dst,'event':e,'index':pos,'deps':deps if rows[dst] else [],
                          'support':support(rows[dst]),'frame':frames[dst]})
            state[dst]=len(nodes)-1
    assert frames[:632]==c['final'] and all(not r for r in rows[632:])
    return rows,nodes,state


def live_queries(nodes,state,helpers,mask=None):
    live=set();todo=[state[i] for i in list(range(112))+list(helpers)]
    while todo:
        j=todo.pop()
        if j in live:continue
        live.add(j)
        if nodes[j]['support'] and (mask is None or nodes[j]['support']&mask):todo.extend(nodes[j]['deps'])
    q={j for j in live if nodes[j]['event'] and nodes[j]['event'][0]=='climb'
       and nodes[j]['support'] and (mask is None or nodes[j]['support']&mask)}
    return q,live


def main():
    started=time.monotonic()
    source=ROOT/'research/retained_state_next/F9-SOURCE-DAG-ALL8-WORD.json.gz'
    wp=ROOT/'research/integration_next/OWNED-ZERO-CLOSURE-WITNESS.json.gz'
    rp=ROOT/'research/integration_next/OWNED-ZERO-ONE-SIDED.json'
    rmatpath=ROOT/'research/tensor_obstruction/inputs/R.json'
    raw=source.read_bytes();blob=json.loads(gzip.decompress(raw))
    witness=json.loads(gzip.decompress(wp.read_bytes()));claim=json.loads(rp.read_text())
    assert witness['source_word_sha256']==claim['source_word_sha256']==sha256(raw).hexdigest()
    c=blob['canonical'];R=[[Fr(v) for v in row] for row in json.loads(rmatpath.read_text())]
    rows,nodes,state=replay(blob,range(224,632));assert len(nodes)==claim['SSA_nodes']==22768
    for i in range(112):
        expect={(112+i,()):Fr(-1)}
        for j in range(112):add(expect,{(112+j,()):Fr(1)},sum(row[i]*row[j] for row in R)/4)
        assert rows[i]==expect
    assert all(rows[i]=={(i,()):Fr(1)} for i in range(112,632))
    allq,alllive=live_queries(nodes,state,range(224,632))
    assert Counter(nodes[j]['event'][-1] for j in allq)==Counter({int(k):v for k,v in claim['live_SSA_paid'].items()})
    ymask=(1<<112)-1;ALL=(1<<408)-1
    baseq,_=live_queries(nodes,state,[],ymask)
    assert baseq=={row[0] for row in witness['base_queries']}
    # Simultaneously check all singleton trigger implications in one reverse
    # DAG sweep, rather than repeating408 specialized searches.
    needs=[0]*len(nodes)
    for i in range(112):needs[state[i]]|=ALL
    for h in range(224,632):needs[state[h]]|=1<<(h-224)
    contexts={}
    for j in reversed(range(len(nodes))):
        support=nodes[j]['support']
        active=ALL if support&ymask else support>>112
        propagating=needs[j]&active
        e=nodes[j]['event']
        if e and e[0]=='climb' and propagating:contexts[j]=propagating
        if propagating:
            for parent in nodes[j]['deps']:
                assert parent<j;needs[parent]|=propagating
    triggers={int(h):set(qs) for h,qs in witness['helper_query_triggers'].items()}
    assert set(triggers)==set(range(224,632))
    for h in range(224,632):
        got={q for q,bits in contexts.items() if bits>>(h-224)&1}
        assert baseq<=got and got-baseq==triggers[h]
    extraq=sorted(set().union(*triggers.values()))
    assert extraq==[row[0] for row in witness['extra_queries']]
    for metadata in witness['base_queries']+witness['extra_queries']:
        q,index,rank=metadata if len(metadata)==3 else (metadata[0],metadata[2],metadata[3])
        assert nodes[q]['index']==index and nodes[q]['event'][0]=='climb' and nodes[q]['event'][-1]==rank
    print('PASS_FULL_ENDPOINT_AND_ALL17260_SINGLETON_IMPLICATIONS',flush=True)

    examples=[[],[224],[277],[449],[525],[631], [224,277], [224,277,449,525,631]]
    example_receipts=[];example_queries={}
    for chosen in examples:
        direct_rows,direct_nodes,direct_state=replay(blob,chosen)
        dq,dlive=live_queries(direct_nodes,direct_state,chosen)
        mask=ymask|sum(1<<(h-112) for h in chosen)
        projected,plive=live_queries(nodes,state,chosen,mask)
        assert dq==projected and dlive==plive
        for i,row in enumerate(rows):assert direct_rows[i]=={key:v for key,v in row.items() if key[0]<224 or key[0] in chosen}
        example_queries[tuple(chosen)]=dq
        example_receipts.append({'helpers':chosen,'required_queries':len(dq),
            'query_profile':dict(sorted(Counter(nodes[j]['event'][-1] for j in dq).items())),
            'direct_replay_equals_mask_specialization':True})
    pairs=0
    for a,qa in example_queries.items():
        for b,qb in example_queries.items():
            if set(a)<=set(b):assert qa<=qb;pairs+=1
    print('PASS_DIRECT_SUBSET_REPLAYS_AND_MONOTONE_QUERY_SETS',flush=True)

    helperrank={h:len(c['frames'][c['final'][h]])-len(c['frames'][c['start'][h]]) for h in range(224,632)}
    assert {int(h):v for h,v in witness['helper_rank'].items()}==helperrank
    qrank={q:nodes[q]['event'][-1] for q in baseq|set(extraq)}
    qvertex={q:409+i for i,q in enumerate(extraq)}
    certificate_receipts=[]
    for cs,cert in witness['certificates'].items():
        cap={(u,v):w for u,v,w in cert['capacities']}
        flow={(u,v):w for u,v,w in cert['antisymmetric_flow']}
        assert len(cap)==len(cert['capacities']) and len(flow)==len(cert['antisymmetric_flow'])
        scale=cert['integer_rounding_scale'];sink=cert['sink'];source0=cert['source'];nv=cert['vertices']
        credits={int(k):v for k,v in cert['helper_credits_rounded_up'].items()}
        costs={int(k):v for k,v in cert['extra_query_costs_rounded_down'].items()}
        assert source0==0 and sink==409+len(extraq) and nv==sink+1
        inf=sum(credits.values())+1;assert inf<2**31
        expected={}
        for h in range(224,632):
            hv=1+h-224;expected[0,hv]=credits[h]
            for q in triggers[h]:expected[hv,qvertex[q]]=inf
        for q in extraq:expected[qvertex[q],sink]=costs[q]
        assert cap==expected
        balance=[0]*nv
        for (u,v),f in flow.items():
            assert flow.get((v,u),0)==-f
            assert f<=cap.get((u,v),0)
            balance[u]+=f
        assert balance[0]==cert['flow_value'] and balance[sink]==-cert['flow_value']
        assert not any(balance[1:sink])
        adjacency=defaultdict(list)
        for edge in set(cap)|set(flow):
            if cap.get(edge,0)-flow.get(edge,0)>0:adjacency[edge[0]].append(edge[1])
        reach={0};todo=deque([0])
        while todo:
            u=todo.popleft()
            for v in adjacency[u]:
                if v not in reach:reach.add(v);todo.append(v)
        assert sink not in reach and reach==set(cert['source_side'])
        cut=sum(w for (u,v),w in cap.items() if u in reach and v not in reach)
        assert cut==cert['flow_value']
        upper=Fr(cert['base_target_credit_rounded_up']-cert['base_query_cost_rounded_down']+sum(credits.values())-cut,scale)
        assert upper==Fr(cert['rigorous_optimistic_margin_upper_bound'])
        # Integer exponent0 capacity weights are proved exactly.  Decimal
        # exponent weights are independently recomputed at100 digits; an
        # additional rational bound below removes any transcendental issue
        # from the benchmark rejection itself.
        with localcontext() as ctx:
            ctx.prec=100;ex=D(1)-D(cs)
            assert credits=={h:int((D(r)**ex*scale).to_integral_value(rounding='ROUND_CEILING')) for h,r in helperrank.items()}
            assert costs=={q:int((D(qrank[q])**ex*scale).to_integral_value(rounding='ROUND_FLOOR')) for q in extraq}
            assert cert['base_target_credit_rounded_up']==int((D(112)*D(9)**ex*scale).to_integral_value(rounding='ROUND_CEILING'))
            assert cert['base_query_cost_rounded_down']==sum(int((D(qrank[q])**ex*scale).to_integral_value(rounding='ROUND_FLOOR')) for q in baseq)
        certificate_receipts.append({'exponent_defect':cs,'vertices':nv,'capacity_edges':len(cap),
            'nonzero_signed_flow_edges':len(flow),'flow_and_cut_value':cut,
            'all_flow_constraints_exact':True,'cut_reachability_exact':True,
            'source_bound_weights_rechecked':True,'optimistic_upper_bound':str(upper)})

    # Fully rational corollary: r^(1-c)>=r(1-c(r-1)), while target moments
    # are <=their first masses.  Every subset's queries are contained in
    # the all-helper query set, so use its entire6208 penalty conservatively.
    c0upper=Fr(witness['certificates']['0']['rigorous_optimistic_margin_upper_bound'])
    penalty=sum(nodes[q]['event'][-1]*(nodes[q]['event'][-1]-1) for q in allq)
    benchmark=Fr('0.0030217758');rational_upper=c0upper+benchmark*penalty
    assert penalty==6208 and rational_upper<0
    result={
        'schema':'independent-owned-zero-closure-review/v1',
        'status':'PASS_EXACT_SSA_MONOTONICITY_AND_FLOW_CUT_CERTIFICATES',
        'pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in (source,wp,rp,rmatpath)},
        'independent_method':'Own scalar/free-word interpreter, one reverse408-bit DAG pass, eight direct subset executions, pure-Python edgewise flow and cut checks. No native_core, root script, SciPy, maximum-flow call, or subset optimization was executed.',
        'all632_endpoint_rows_checked':True,'SSA_nodes':len(nodes),'base_queries':len(baseq),
        'extra_singleton_queries':len(extraq),'all_singleton_implication_edges_checked':sum(map(len,triggers.values())),
        'direct_specialization_examples':example_receipts,'nested_example_pairs_checked':pairs,
        'flow_certificates':certificate_receipts,
        'logical_proof':[
            'Each exact node row is a sum of terms indexed by an independent original owner and a free warp word. Removing helper owners restricts this sum; retaining more independent owners cannot cancel terms from another owner.',
            'The retained-output set grows with the helper set. A traversal edge is used only when the current row has a retained owner. Both predicates are monotone, so required query sets are monotone.',
            'Every retained set must contain the base queries plus every selected helper singleton trigger. Omitting additional joint-only queries makes the maximum-closure objective an upper bound.',
            'The supplied feasible antisymmetric flow and equal-capacity source-side cut certify the optimum of the rounded closure network exactly. Upward credit rounding and downward query-cost rounding give the correct inequality direction.'
        ],
        'rational_benchmark_rejection':{'first_mass_upper_bound':str(c0upper),
            'full_query_sum_r_times_rminus1':penalty,'c':str(benchmark),
            'moment_upper_bound_exact_fraction':str(rational_upper),
            'moment_upper_bound_decimal':str(D(rational_upper.numerator)/D(rational_upper.denominator)),
            'proof':'For r>=1, exp(-c log r)>=1-c log r>=1-c(r-1). Target r^(1-c)<=r. Hence margin_c<=margin_0+c*sum_paid r(r-1)<=-732+c*6208<0.',
            'uses_transcendental_rounding':False},
        'scope':'Only the literal owned-zero backward source with this exact free-letter SSA zero/liveness pruning, all408 helper-retention subsets. Complete-value memoization, actual physical warp aliases, changed circuits, alternative targets, and sacrificial helper carriers are outside the bound.',
        'new_kappa_claimed':False,'elapsed_seconds':time.monotonic()-started,
    }
    (HERE/'OWNED-ZERO-CLOSURE-INDEPENDENT-REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':main()
