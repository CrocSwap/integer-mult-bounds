#!/usr/bin/env python3
"""Independent replay of the emitted opposite-role causal companion.

No emitter or native_core replay is imported.  Scalar/free-word execution,
ownership, frame incidence, cross words and endpoint construction live here.
"""
from collections import Counter
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def need(ok, message):
    if not ok:
        raise AssertionError(message)


def add(dst, src, scalar):
    for key, value in list(src.items()):
        out = dst.get(key, Fr(0)) + scalar * value
        if out:
            dst[key] = out
        else:
            dst.pop(key, None)


def load_ce():
    path = ROOT / 'research/tensor_obstruction/inputs/clifford_exact.py'
    spec = importlib.util.spec_from_file_location('companion_independent_ce', path)
    ce = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = ce
    spec.loader.exec_module(ce)
    return ce, path


def compile_word(ce, n, word):
    result = ce.ident(n)
    for e in word:
        if e[0] == 'P':
            item = ce.perm(n, tuple(e[1]))
        elif e[0] == 'D':
            item = ce.diag(n, tuple(e[1]), tuple(e[2]))
        elif e[0] == 'X':
            item = ce.xgate(n, e[1])
        elif e[0] == 'phase':
            item = ce.Op(n, ce.identity(n), [('phase', e[1])])
        elif e[0] == 'C':
            item = ce.cgate(n, e[1], e[2])
        else:
            raise AssertionError(('Unknown Clifford opcode', e))
        result = result.then(item)
    return result


def conjugate(ce, op):
    word = []
    for e in op.circuit:
        if e[0] == 'D':
            word.append(('D', e[1], tuple((-v) % 4 for v in e[2])))
        elif e[0] == 'C':
            word.append(('C', e[1], -e[2]))
        elif e[0] == 'phase':
            word.append(('phase', -e[1] % 4))
        else:
            word.append(e)
    return compile_word(ce, op.n, word)


def same(a, b):
    return a.tab == b.tab and a.zero_state() == b.zero_state()


def main():
    started = time.monotonic()
    path = ROOT / 'research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz'
    rpath = ROOT / 'research/tensor_obstruction/inputs/R.json'
    claimpath = ROOT / 'research/retained_state_next/CAUSAL-COMPANION-INVOLUTION.json'
    nativepath = ROOT / 'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    packed = path.read_bytes()
    payload = gzip.decompress(packed)
    blob, claim = json.loads(payload), json.loads(claimpath.read_text())
    original = json.loads(gzip.decompress(nativepath.read_bytes()))
    need(sha256(packed).hexdigest() == claim['word_sha256'], 'Compressed word pin')
    need(sha256(payload).hexdigest() == claim['word_payload_sha256'], 'Payload pin')
    c = blob['canonical']
    need(c == original['canonical'], 'Changed canonical source frames')
    R = [[Fr(x) for x in row] for row in json.loads(rpath.read_text())]
    gram = [[sum(x*y for x, y in zip(u, v)) for v in R] for u in R]
    need(gram == [[Fr(56 * (i == j)) for j in range(8)] for i in range(8)], 'Actual R Gram')
    B = [[sum(row[i] * row[j] for row in R) for j in range(112)] for i in range(112)]
    A = [[Fr(i == j) - B[i][j]/4 for j in range(112)] for i in range(112)]
    # Validate the full operator polynomial directly, not only its eigenvalues.
    need(all(sum(A[i][k]*A[k][j] for k in range(112)) == Fr(i == j) + 3*B[i][j]
             for i in range(112) for j in range(112)), 'I-A^2=-3R^T R')
    ce, cepath = load_ce()
    F = ce.fourier(9)
    barF = conjugate(ce, F)
    crossX = compile_word(ce, 9, blob['cross_X_word'])
    need(all(e[0] in ('P', 'D', 'X', 'phase') for e in blob['cross_X_word']), 'X cross not monomial')
    need(same(crossX, F.then(F)), 'X cross differs from F^2, including phase')
    need(same(F.then(crossX), barF), 'X cross source/target physical frame')
    crossY = {}
    for entry in blob['cross_Y_words']:
        i = entry['port']
        need(i not in crossY, 'Duplicate Y cross port')
        word = entry['word']
        need(all(e[0] in ('P', 'D', 'X', 'phase') for e in word), 'Y cross not monomial')
        W = compile_word(ce, 9, word)
        S = ce.canonical_frame(9, c['frames'][c['final'][112+i]])
        need(same(conjugate(ce, S).then(W), S), ('Y cross phase/frame', i))
        crossY[i] = word
    need(set(crossY) == set(range(112)), 'Incomplete Y crosses')
    print('PASS_ALL_PHYSICAL_CROSS_WORDS_AND_ACTUAL_R', flush=True)

    extra = blob['owned_extra_slots_by_copy']
    sizes = [633+x for x in extra]
    rows = [[{(632*copy+i, ()): Fr(1)} for i in range(632)] +
            [{} for _ in range(sizes[copy]-632)] for copy in range(2)]
    frames = [c['start'][:] + [None]*(sizes[copy]-632) for copy in range(2)]
    modes = [{} for _ in range(8)]
    paid = [Counter(), Counter()]
    counts = Counter()
    maxnorm, peak = Fr(1), 0
    live_owned = set()
    cuts = []
    original_writes = Counter()

    def index(ref, copy):
        need(ref[0] in ('L', 'C'), 'Unknown owner namespace')
        d = ref[1] + (632 if ref[0] == 'C' else 0)
        need(0 <= d < sizes[copy], 'Owner outside allocation')
        if ref[0] == 'L':
            need(d < 632, 'Misdeclared original owner')
        return d

    for pos, e in enumerate(blob['program']):
        typ = e[0]
        counts[typ] += 1
        touched, owner = None, None
        if typ == 'native':
            _, copy, v = e
            op = v[0]
            if op == 'scalar':
                instr, frame = v[1:]
                kind, dst = instr[0], index(instr[1], copy)
                if kind == 'clear':
                    need(dst >= 632, 'Erasing arbitrary original')
                    rows[copy][dst] = {}
                    frames[copy][dst] = frame
                else:
                    need(frames[copy][dst] == frame, ('Target frame', pos))
                    if kind in ('copy', 'add'):
                        src = index(instr[2], copy)
                        need(frames[copy][src] == frame, ('Source frame', pos))
                        need(src != dst, 'Self operation')
                        if kind == 'copy':
                            need(dst >= 632, 'Overwriting arbitrary original')
                            rows[copy][dst] = dict(rows[copy][src])
                        else:
                            add(rows[copy][dst], rows[copy][src], Fr(instr[3], instr[4]))
                    else:
                        need(kind == 'scale', ('Unknown scalar', kind))
                        scale = Fr(instr[2], instr[3])
                        need(scale != 0 or dst >= 632, 'Zero-scaling an original')
                        rows[copy][dst] = {key: val*scale for key, val in rows[copy][dst].items() if val*scale}
                touched, owner = rows[copy][dst], (copy, dst)
            elif op == 'warp':
                _, ref, letter, f, g = v
                dst = index(ref, copy)
                need(frames[copy][dst] == f, ('Warp incidence', pos))
                signed = (1 if letter > 0 else -1) * (abs(letter) + 1000000*copy)
                new = {}
                for (i, w), val in rows[copy][dst].items():
                    outword = w[1:] if w and w[0] == -signed else (signed,) + w
                    new[i, outword] = new.get((i, outword), Fr(0)) + val
                rows[copy][dst] = {key: val for key, val in new.items() if val}
                frames[copy][dst] = g
                touched, owner = rows[copy][dst], (copy, dst)
            elif op == 'climb':
                _, _, dst, f, g, rank = v
                need(0 <= dst < 632 and frames[copy][dst] == f, ('Climb incidence', pos))
                need(rank > 0 and rank == len(c['frames'][g])-len(c['frames'][f]), 'Paid rank mismatch')
                frames[copy][dst] = g
                paid[copy][rank] += 1
            else:
                need(op in ('phase', 'adapter'), ('Unexpected native opcode', op))
        elif typ == 'cross_y_add':
            _, i, word = e
            need(word == crossY[i], 'Cross Y word differs from validated word')
            need(frames[0][112+i] == frames[1][112+i] == c['final'][112+i], 'Cross Y incidence')
            add(rows[0][112+i], rows[1][112+i], Fr(1))
            touched, owner = rows[0][112+i], (0, 112+i)
        elif typ == 'mode_clear':
            modes[e[1]] = {}
        elif typ == 'mode_add_forward_X':
            _, mode, i, value = e
            need(frames[0][i] == 1, 'Mode gathered before F output')
            need(rows[0][i] == {(i, ()): Fr(1)}, 'Mode gathered from polluted X')
            need(value == R[mode][i], 'Wrong mode sign')
            add(modes[mode], rows[0][i], Fr(value))
            touched = modes[mode]
        elif typ == 'cross_X_mode_add':
            _, i, mode, value, word = e
            need(frames[1][i] == 1, 'Cross X incidence')
            need(word == blob['cross_X_word'], 'Cross X word differs from validation')
            need(value == -3*R[mode][i], 'Wrong cross X coefficient')
            add(rows[1][i], modes[mode], Fr(value))
            touched, owner = rows[1][i], (1, i)
        else:
            need(typ == 'phase', ('Unexpected event', typ))
            if e == ['phase', 'both_opposite_consumer_inputs_still_unread']:
                for i in range(112):
                    need(rows[0][i] == {(i, ()): Fr(1)} and frames[0][i] == 1, 'Forward source incomplete')
                    need(rows[0][112+i] == {(112+i, ()): Fr(1)} and frames[0][112+i] == 0, 'Forward consumer already read')
                    need(rows[1][i] == {(632+i, ()): Fr(1)} and frames[1][i] == c['start'][i], 'Backward consumer already read')
                    need(rows[1][112+i] == {(744+i, ()): Fr(1)} and frames[1][112+i] == c['final'][112+i], 'Backward source incomplete')
                cuts.append(pos)
        if touched is not None:
            maxnorm = max(maxnorm, sum(map(abs, touched.values()), Fr(0)))
        if owner is not None:
            copy, dst = owner
            if dst >= 632:
                if touched:
                    live_owned.add(owner)
                else:
                    live_owned.discard(owner)
            else:
                original_writes[owner] += 1
        peak = max(peak, len(live_owned) + sum(bool(row) for row in modes))

    endpoint = [[{(632*copy+i, ()): Fr(1)} for i in range(632)] for copy in range(2)]
    for i in range(112):
        add(endpoint[0][112+i], {(744+i, ()): Fr(1)}, Fr(1))
        for j in range(112):
            add(endpoint[0][112+i], {(j, ()): Fr(1)}, A[i][j])
            add(endpoint[1][i], {(744+j, ()): Fr(1)}, -A[i][j])
            add(endpoint[1][i], {(j, ()): Fr(1)}, -3*B[i][j])
    for copy in range(2):
        need(rows[copy][:632] == endpoint[copy], ('Full endpoint mismatch', copy))
        need(frames[copy][:632] == c['final'], 'Original final frames')
        need(all(not row for row in rows[copy][632:]), 'Owned array left live')
        need(paid[copy] == Counter({1:2201, 2:412, 3:510, 4:127, 5:40}), 'Wrong query invoice')
        need(all(rows[copy][i] == {(632*copy+i, ()): Fr(1)} for i in range(224,632)), 'Helper not autonomous')
    need(not live_owned and all(not row for row in modes), 'Live owned endpoint')
    need(len(cuts) == 1, 'Missing or duplicate synchronized source cut')
    print('PASS_ALL_1264_ORIGINAL_ROWS_816_HELPERS_AND_CHRONOLOGY', flush=True)

    # Source-bound algebra needed to move the single shared Q: every K_i
    # commutes F including phase, hence so do C and I-C^2.
    npath = ROOT / 'upstream/research/coded-native-caller/NORMALIZERS.json'
    normal = json.loads(npath.read_text())
    for i, port in enumerate(normal['ports']):
        K = ce.perm(9, port['G_rows']).then(ce.diag(9, (0,)*9,
            tuple(2*((port['Z_mask'] >> j) & 1) for j in range(9))))
        need(same(K.then(F), F.then(K)), ('Actual K does not commute F', i))
    # M=[[C,I],[I-C^2,-C]] squares to identity by C(I-C^2)=(I-C^2)C.
    # A physical source recoding has upper-right Q, so the common-Q chart
    # involution is not a monomial ordinary physical code.
    q = ce.cgate(9, 1)
    need(ce.rank([x for x,z,p in q.tab[9:]]) == 1, 'Negative gauge control')
    need(q.tab != ce.ident(9).tab, 'Q wrongly treated as identity')
    flat_endpoint = [[(i, list(w), str(v)) for (i,w),v in sorted(row.items())]
                     for bank in rows for row in bank[:632]]
    digest = sha256(json.dumps(flat_endpoint, separators=(',', ':')).encode()).hexdigest()
    result = {
        'schema':'independent-causal-companion-review/v1',
        'status':'PASS_INDEPENDENT_LITERAL_REPLAY_AND_PHYSICAL_CROSS_WORDS; CALLER_OPEN',
        'pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                for p in (path, rpath, nativepath, cepath, npath)},
        'word_payload_sha256':sha256(payload).hexdigest(),
        'independent_interpreter':'No import or execution of emitter, native_core, or other reviewer. All scalar/free-word, ownership, frame and endpoint semantics implemented here.',
        'all_original_columns':1264,'independent_helper_columns':816,
        'all_original_endpoints_verified':True,'all_helpers_autonomous':True,
        'all_physical_crosses_phase_exact':True,'all_owned_final_zero':True,
        'synchronized_source_cut_positions':cuts,
        'actual_K_commutes_F_phase_exact_ports':112,
        'paid_profile_each':dict(sorted(paid[0].items())),
        'opcode_census':dict(counts),'max_l1_normalized_row':str(maxnorm),
        'peak_nonzero_owned_including_cross_modes':peak,
        'full_endpoint_sha256':digest,
        'logical_endpoint':{
            'xf':'xf','yb':'yb','yf':'yf + A xf + yb',
            'xb':'xb + (I-A^2) xf - A yb',
            'A':'I-R^T R/4', 'I-A^2':'-3R^T R'},
        'normalized_physical_edge':'[[D C Q^-1,D],[(I-C^2)D,-Q D C]]',
        'role_charts':'H_source=diag(I,Q), H_consumer=diag(Q,I)',
        'chart_edge':'H_consumer E H_source^-1 = [[C,I],[I-C^2,-C]] diag(D,D)',
        'negative_gauge_control':'H_source^-1 M H_source has upper-right Q of rank 1. The abstract involution is not an ordinary physical source code.',
        'all_width_scope':'Free-word identities, exact column tableau and phase identities tensor-lift. Scalar owner coefficients apply once. All originals remain independent.',
        'kappa_improvement_claimed':False,
        'elapsed_seconds':time.monotonic()-started,
    }
    out = HERE / 'CAUSAL-COMPANION-INDEPENDENT-REVIEW.json'
    out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
