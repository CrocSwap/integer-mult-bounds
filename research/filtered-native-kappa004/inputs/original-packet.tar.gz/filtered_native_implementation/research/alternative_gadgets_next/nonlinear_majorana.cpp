#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <random>
#include <unordered_map>
#include <vector>
using U=uint64_t;
struct G {int t,b,c,d,s,r;};
struct P {int q,z,p; std::array<int,8> root;};
int m, mask;
std::vector<G> gates;
U spread(int q,int bits){U v=0;for(int j=0;j<9;j++)if(q>>j&1)v|=U(bits)<<(j*m);return v;}
int rot(int a,int s){s%=m;return ((a<<s)|(a>>(m-s)))&mask;}
U gate(U x,const G &g){int b=(x>>(g.b*m))&mask,c=(x>>(g.c*m))&mask,d=(x>>(g.d*m))&mask;return x^(U(b&rot(c,g.s)&rot(d,g.r))<<(g.t*m));}
U W(U x,bool inverse){if(inverse){for(auto i=gates.rbegin();i!=gates.rend();++i)x=gate(x,*i);}else for(auto g:gates)x=gate(x,g);return x;}
std::pair<U,int> Gamma(U x,int k){x=W(x,true);int b=k/2;int prefix=(1<<b)-1;if(k&1)prefix|=1<<b;int par=__builtin_parityll(x&spread(prefix,mask));int p=((k&1)*m+2*par)&3;x^=spread(1<<b,mask);return {W(x,false),p};}
struct S {long long cols=0,nnz=0;int minimum=100000,maximum=0;std::map<int,long long> hist;};
S probe(const std::vector<P>&ports,const std::vector<U>&xs,bool all_observers){S out; const int scale=1<<m;for(auto P:ports)for(int a=0;a<(all_observers?9:1);a++)for(U x:xs){std::unordered_map<U,std::array<int,2>> vals;vals.reserve(4*scale*scale);int zword=0;for(int b=0;b<9;b++)if(P.z>>b&1)zword^=(x>>(b*m))&mask;
for(int u=0;u<scale;u++){U y=x^spread(P.q,u);int phase=((P.p+1)*__builtin_popcount(u)+2*__builtin_parity(u&zword))&3;if(a){auto z=Gamma(y,a-1);y=z.first;phase=(phase+z.second)&3;}
for(int k=0;k<8;k++)if(P.root[k]){auto z=Gamma(y,k);int p=(phase+z.second+(P.root[k]<0?2:0))&3;for(int v=0;v<scale;v++){U dest=z.first^spread(1,v);int e=(p-__builtin_popcount(v))&3;auto &b=vals[dest];if(e==0)b[0]++;if(e==1)b[1]++;if(e==2)b[0]--;if(e==3)b[1]--;}}}
int count=0;long long norm=0;for(auto v:vals){int r=v.second[0],i=v.second[1];if(r||i)count++;norm+=r*r+i*i;}if(norm!=4LL*scale*scale){std::cerr<<"norm fail "<<norm<<" expected "<<4LL*scale*scale<<"\n";std::exit(3);}out.cols++;out.nnz+=count;out.minimum=std::min(out.minimum,count);out.maximum=std::max(out.maximum,count);out.hist[count]++;}return out;}
void emit(const S&s){std::cout<<"{\"columns\":"<<s.cols<<",\"nonzeros\":"<<s.nnz<<",\"minimum\":"<<s.minimum<<",\"maximum\":"<<s.maximum<<",\"histogram\":{";bool first=true;for(auto kv:s.hist){if(!first)std::cout<<",";first=false;std::cout<<"\""<<kv.first<<"\":"<<kv.second;}std::cout<<"}}";}
int main(int argc,char**argv){m=argc>1?atoi(argv[1]):3;int samples=argc>2?atoi(argv[2]):16;int trials=argc>3?atoi(argv[3]):64;mask=(1<<m)-1;int n;std::cin>>n;std::vector<P>ports(n);for(auto &P:ports){std::cin>>P.q>>P.z>>P.p;for(int &r:P.root)std::cin>>r;}std::vector<G>fixed;int ng=0;if(std::cin>>ng)for(int j=0;j<ng;j++){G g;std::cin>>g.t>>g.b>>g.c>>g.d>>g.s>>g.r;fixed.push_back(g);}std::mt19937_64 rng(argc>4?strtoull(argv[4],nullptr,10):20261023);std::vector<U>xs;U full=(U(1)<<(9*m))-1;if(samples<0)for(U x=0;x<=full;x++)xs.push_back(x);else{xs={0,full};while(int(xs.size())<samples)xs.push_back(rng()&full);}
S base=probe(ports,xs,true);gates=fixed;S best=probe(ports,xs,true);std::vector<G>bestg=fixed;std::cout<<"{\"width\":"<<m<<",\"baseline\":";emit(base);std::cout<<",\"trials\":[";
for(int t=0;t<trials;t++){gates=bestg;if(t%8==0)gates.clear();int len=1+rng()%4;for(int j=0;j<len;j++){std::array<int,9>v;for(int b=0;b<9;b++)v[b]=b;std::shuffle(v.begin(),v.end(),rng);gates.push_back({v[0],v[1],v[2],v[3],int(rng()%m),int(rng()%m)});}if(gates.size()>10)gates.erase(gates.begin(),gates.begin()+gates.size()-10);S s=probe(ports,xs,true);if(t)std::cout<<",";std::cout<<"{\"id\":"<<t<<",\"nonzeros\":"<<s.nnz<<",\"min\":"<<s.minimum<<",\"max\":"<<s.maximum<<"}";if(s.nnz<best.nnz){best=s;bestg=gates;}}
std::cout<<"],\"best\":";emit(best);std::cout<<",\"gates\":[";bool first=true;for(auto g:bestg){if(!first)std::cout<<",";first=false;std::cout<<"["<<g.t<<","<<g.b<<","<<g.c<<","<<g.d<<","<<g.s<<","<<g.r<<"]";}std::cout<<"]}\n";
}
