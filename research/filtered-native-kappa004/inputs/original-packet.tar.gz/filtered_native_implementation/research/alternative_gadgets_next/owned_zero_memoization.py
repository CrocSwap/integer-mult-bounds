#!/usr/bin/env python3
"""Source-bound complete-value memoization for the owned-zero contract.

This deliberately changes the fixed SSA dependencies audited by the helper
closure bound.  Every cached value is separately owned.  Actual backward
K_G monomials, including their quadratic and linear phases, identify logical
operators.  A further mode identifies rows up to a common admitted physical
monomial, using exact relative operator rows and a Lagrangian invariant.
"""
from collections import Counter
from decimal import Decimal as D,localcontext
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
from review_owned_zero_closure import add


def load_ce():
    p=ROOT/'research/tensor_obstruction/inputs/clifford_exact.py'
    spec=importlib.util.spec_from_file_location('memo_ce',p)
    ce=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ce;spec.loader.exec_module(ce)
    return ce,p


def rref(vectors):
    pivots={}
    for value in vectors:
        for p,v in sorted(pivots.items(),reverse=True):
            if value>>p&1:value^=v
        if value:
            p=value.bit_length()-1
            for q,v in list(pivots.items()):
                if v>>p&1:pivots[q]=v^value
            pivots[p]=value
    return tuple(v for p,v in sorted(pivots.items(),reverse=True))


class PhysicalWords:
    def __init__(self,ce,canonical):
        self.ce=ce;self.c=canonical;self.ops=[ce.ident(9)];self.ids={self.ops[0].tab:0}
        self.letters={};self.products={};self.inverses={0:0};self.lags={};self.frame_tabs={}
        for row in canonical['warps']:
            G=ce.transpose(tuple(row['G_columns']),9);gi=ce.inv(G,9)
            cols=ce.transpose(gi,9)
            Q=tuple((1<<i)^sum(ce.parity(a&b)<<j for j,b in enumerate(cols)) for i,a in enumerate(cols))
            # Literal backward operator is conjugate(K_G), not its transpose.
            alpha=tuple(-((Q[i]>>i)&1)%4 for i in range(9))
            op=ce.perm(9,G).then(ce.diag(9,Q,alpha))
            assert op.zero_state()==ce.ident(9).zero_state()
            self.letters[row['op']]=self.intern(op)
            self.letters[-row['op']]=self.intern(op.adjoint())
    def intern(self,op):
        if op.tab not in self.ids:self.ids[op.tab]=len(self.ops);self.ops.append(op)
        return self.ids[op.tab]
    def product(self,a,b):
        key=a,b
        if key not in self.products:self.products[key]=self.intern(self.ops[b].then(self.ops[a]))
        return self.products[key]
    def inverse(self,a):
        if a not in self.inverses:self.inverses[a]=self.intern(self.ops[a].adjoint())
        return self.inverses[a]
    def physical_lagrangian(self,frame,anchor):
        key=frame,anchor
        if key not in self.lags:
            ce=self.ce
            if frame not in self.frame_tabs:
                f=ce.canonical_frame(9,self.c['frames'][frame]);self.frame_tabs[frame]=ce.inverse(f.tab)
            # Complex conjugation does not alter the binary symplectic map.
            invA=ce.compose(self.ops[self.inverse(anchor)].tab,self.frame_tabs[frame])
            self.lags[key]=rref(x|(z<<9) for x,z,p in invA[9:])
        return self.lags[key]


def execute(blob,chosen,physical=None,memo='none'):
    c=blob['canonical'];chosen=set(chosen);size=641
    token=0 if physical else ()
    rows=[{(i,token):Fr(1)} if 112<=i<224 or i in chosen else {} for i in range(size)]
    frames=c['start'][:]+[None]*(size-632)
    nodes=[{'deps':[],'query':None,'event':None,'frame':frames[i],'owner':i,'row_nonzero':bool(rows[i]),'qbits':0}
           for i in range(size)]
    state=list(range(size));cache={};aliases=[];query_ranks=[];cost_cache={0:0};keytime=0.0
    def score(bits):
        if bits not in cost_cache:
            w=bits;total=0
            while w:
                bit=w&-w;total+=query_ranks[bit.bit_length()-1];w^=bit
            cost_cache[bits]=total
        return cost_cache[bits]
    def key_for(row,frame):
        if not row:return None,None,None
        first=min(row);factor=row[first]
        if memo=='physical':
            anchor=first[1];inv=physical.inverse(anchor)
            terms=tuple(sorted(((owner,physical.product(inv,op)),value/factor) for (owner,op),value in row.items()))
            return (physical.physical_lagrangian(frame,anchor),terms),factor,anchor
        terms=tuple((k,v/factor) for k,v in sorted(row.items()))
        return (frame,terms),factor,first[1]
    for i in range(size):
        if rows[i] and memo!='none':
            key,factor,anchor=key_for(rows[i],frames[i]);cache[key]=(i,factor,anchor)
    events=[e for e in blob['programs']['backward'] if e[0]!='physical_add']
    ix=lambda ref:ref[1]+(632 if ref[0]=='C' else 0)
    for pos,e in enumerate(events):
        typ=e[0];dst=None;deps=[];paid=None
        if typ=='scalar':
            op,f=e[1:];kind=op[0];dst=ix(op[1])
            if kind=='clear':assert dst>=632;rows[dst]={};frames[dst]=f
            else:
                assert frames[dst]==f
                if kind in ('copy','add'):
                    src=ix(op[2]);assert frames[src]==f
                    if kind=='copy':assert dst>=632;rows[dst]=dict(rows[src]);deps=[state[src]]
                    else:add(rows[dst],rows[src],Fr(op[3],op[4]));deps=[state[dst],state[src]]
                else:
                    assert kind=='scale';a=Fr(op[2],op[3]);rows[dst]={k:a*v for k,v in rows[dst].items() if a*v};deps=[state[dst]]
        elif typ=='warp':
            _,ref,letter,f,g=e;dst=ix(ref);assert frames[dst]==f;changed={}
            for (owner,w),value in rows[dst].items():
                if physical:nw=physical.product(physical.letters[letter],w)
                else:
                    symbol=(1 if letter>0 else -1)*(1000000+abs(letter))
                    nw=w[1:] if w and w[0]==-symbol else (symbol,)+w
                changed[owner,nw]=changed.get((owner,nw),Fr(0))+value
            rows[dst]={k:v for k,v in changed.items() if v};frames[dst]=g;deps=[state[dst]]
        elif typ=='climb':
            _,_,dst,f,g,rank=e;assert frames[dst]==f;frames[dst]=g;deps=[state[dst]]
            if rows[dst]:paid=rank
        elif typ=='adapter':dst=e[2];deps=[state[dst]]
        else:assert typ=='phase'
        if dst is None:continue
        if not rows[dst]:deps=[];paid=None
        oldbits=0
        for d in deps:oldbits|=nodes[d]['qbits']
        trialcost=score(oldbits)+(paid or 0)
        key=factor=anchor=None;reuse=None
        if rows[dst] and memo!='none':
            key,factor,anchor=key_for(rows[dst],frames[dst])
            if key in cache:
                prev,pfactor,panchor=cache[key]
                # This is a concrete greedy implementation, not an optimal
                # circuit lower bound.  Choose the lower standalone first mass.
                if score(nodes[prev]['qbits'])<=trialcost:
                    reuse=(prev,pfactor,panchor);deps=[prev];paid=None;oldbits=nodes[prev]['qbits']
        qid=None
        if paid:
            qid=len(query_ranks);query_ranks.append(paid);oldbits|=1<<qid
        j=len(nodes)
        nodes.append({'deps':deps,'query':qid,'event':pos,'frame':frames[dst],
                      'owner':dst,'row_nonzero':bool(rows[dst]),'qbits':oldbits})
        state[dst]=j
        if reuse:
            prev,pfactor,panchor=reuse
            aliases.append({'node':j,'event':pos,'opcode':typ,'previous_node':prev,
                'previous_event':nodes[prev]['event'],'from_frame':nodes[prev]['frame'],
                'to_frame':frames[dst],'scale':str(factor/pfactor),
                'from_anchor':panchor,'to_anchor':anchor,'removed_direct_query_rank':e[-1] if typ=='climb' else 0})
        if key is not None:
            if key not in cache or score(oldbits)<score(nodes[cache[key][0]]['qbits']):cache[key]=(j,factor,anchor)
    assert frames[:632]==c['final'] and all(not row for row in rows[632:])
    live=set();todo=[state[i] for i in list(range(112))+list(chosen)]
    while todo:
        j=todo.pop()
        if j in live:continue
        live.add(j);todo.extend(nodes[j]['deps'])
    paid=Counter(query_ranks[nodes[j]['query']] for j in live if nodes[j]['query'] is not None)
    targets=Counter({9:112})
    for h in chosen:targets[len(c['frames'][c['final'][h]])-len(c['frames'][c['start'][h]])]+=1
    livealiases=[x for x in aliases if x['node'] in live]
    with localcontext() as ctx:
        ctx.prec=60;ex=D(1)-D('0.0030217758')
        margin=sum(D(k)*D(r)**ex for r,k in targets.items())-sum(D(k)*D(r)**ex for r,k in paid.items())
    receipt={'helpers':len(chosen),'operator_model':'actual phase-bearing backward K_G' if physical else 'free warp letters',
        'memoization':memo,'paid_profile':dict(sorted(paid.items())),
        'target_profile':dict(sorted(targets.items())),
        'first_mass_margin':sum(r*k for r,k in targets.items())-sum(r*k for r,k in paid.items()),
        'moment_margin_at_c0030217758':str(margin),'live_SSA_nodes':len(live),
        'all_canonical_aliases':len(aliases),'live_aliases':len(livealiases),
        'live_query_replacements':sum(x['removed_direct_query_rank']>0 for x in livealiases),
        'live_query_replacement_mass':sum(x['removed_direct_query_rank'] for x in livealiases),
        'phase_exact_monomial_operators_seen':len(physical.ops) if physical else None,
        'alias_examples':sorted(livealiases,key=lambda x:(-x['removed_direct_query_rank'],x['event']))[:12]}
    return receipt,rows,nodes,livealiases


def main():
    start=time.monotonic();path=ROOT/'research/retained_state_next/F9-SOURCE-DAG-ALL8-WORD.json.gz'
    raw=path.read_bytes();blob=json.loads(gzip.decompress(raw));ce,cepath=load_ce()
    actual=PhysicalWords(ce,blob['canonical']);records=[]
    for helpers in ([],list(range(224,632))):
        expected=None
        for words,memo in ((None,'none'),(actual,'none'),(None,'same_frame'),(actual,'same_frame'),(actual,'physical')):
            rec,rows,nodes,aliases=execute(blob,helpers,words,memo)
            if words:
                normalized=[{(i,() if op==0 else op):a for (i,op),a in row.items()} for row in rows]
            else:normalized=rows
            if expected is None:expected=normalized
            assert normalized==expected
            records.append(rec)
            print('MEMO',len(helpers),rec['operator_model'],memo,rec['paid_profile'],
                  'margin',rec['moment_margin_at_c0030217758'],flush=True)
    out={'schema':'owned-zero-source-physical-memoization/v1',
        'status':'PASS_EXACT_ENDPOINT_MEMOIZATION_CENSUS; EMITTER_AND_PRICE_ADMISSION_PENDING',
        'pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in (path,cepath)},
        'records':records,
        'physical_key_proof':'Write a row as A times its anchor-normalized relative monomial row, with A=bar(T_frame)W_anchor. Equal relative rows and equal pullbacks A^-1(Z-Lagrangian) imply A_new A_old^-1 is monomial. It maps every independent input coefficient term exactly, with the scalar ratio applied once. Native warp words fix |0> with phase1, so equal logical tableaus have equal absolute phase.',
        'ownership':'Every retained SSA version is separately owned scratch. Alias dependencies point strictly backward. No arbitrary original is erased or reused as zero. A positive census would still require emitting the selected physical monomial wrappers, source liveness schedule, cleanup and precision invoice.',
        'search_scope':'Two helper policies, greedy minimum standalone first-mass representative for each complete value. No optimality claim.',
        'new_kappa_claimed':False,'elapsed_seconds':time.monotonic()-start}
    (HERE/'OWNED-ZERO-MEMOIZATION.json').write_text(json.dumps(out,indent=2)+'\n')
    print('DONE',out['elapsed_seconds'],flush=True)


if __name__=='__main__':main()
