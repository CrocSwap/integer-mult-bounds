#!/usr/bin/env python3
"""Exact rational two-copy inverse codes for the helper-clean F9 center.

This proves the algebra and its ordinary payload recipe.  It deliberately
does not promote the native shear to a completed Gaussian target.  The
actual source-DAG and raw-dual implementations are independently owned by
retained_state_next and operator_alignment_next.
"""
from collections import defaultdict
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def p(*coefficients):
    ans = [Fr(0)] * 4
    for k, c in enumerate(coefficients):
        ans[k % 4] += Fr(c)
    return tuple(ans)


ZERO, ONE, F = p(), p(1), p(0, 1)


def add(*xs):
    return tuple(sum(x[k] for x in xs) for k in range(4))


def mul(*xs):
    z = ONE
    for x in xs:
        t = [Fr(0)] * 4
        for j in range(4):
            for k in range(4):
                t[(j + k) % 4] += z[j] * x[k]
        z = tuple(t)
    return z


def scale(x, c):
    return tuple(Fr(c) * v for v in x)


def mm(a, b):
    return [[add(*(mul(a[i][k], b[k][j]) for k in range(len(b))))
             for j in range(len(b[0]))] for i in range(len(a))]


def ma(a, b):
    return [[add(x, y) for x, y in zip(ar, br)] for ar, br in zip(a, b)]


def ms(a, c):
    return [[scale(x, c) for x in row] for row in a]


def mt(a):
    return list(map(list, zip(*a)))


def show(a):
    return [[[str(c) for c in x] for x in row] for row in a]


def projector_check(rows):
    n = len(rows[0])
    gram = [[sum(a * b for a, b in zip(ri, rj)) for rj in rows] for ri in rows]
    assert gram == [[56 * int(i == j) for j in range(len(rows))]
                    for i in range(len(rows))]
    s = [[sum(row[i] * row[j] for row in rows) for j in range(n)] for i in range(n)]
    # This entrywise check does not assume the row-Gram proof above.
    for i in range(n):
        for j in range(n):
            assert sum(s[i][k] * s[k][j] for k in range(n)) == 56 * s[i][j]
    return s, {
        "rank": len(rows),
        "owners": n,
        "projector_entries_checked": n * n,
        "P_squared_equals_P": True,
        "P_equals_P_transpose": s == list(map(list, zip(*s))),
        "max_projector_row_l1": str(max(sum(abs(v) for v in row) for row in s) / Fr(56)),
    }


def full_code_check(s, eplus, eminus):
    """Verify every two-copy owner block using the exact P^2 entries.

    C_E = I + (E-I) tensor P.  This is evaluated as a finite owner matrix;
    the whole owner matrix is never tensor-powered across digit columns.
    """
    n = len(s)
    eye = [[ONE, ZERO], [ZERO, ONE]]
    u = ma(eplus, ms(eye, -1))
    v = ma(eminus, ms(eye, -1))
    uv = mm(u, v)
    failures = 0
    for a in range(2):
        for b in range(2):
            for i in range(n):
                for j in range(n):
                    sij = Fr(s[i][j], 56)
                    ssij = Fr(sum(s[i][k] * s[k][j] for k in range(n)), 56 * 56)
                    residual = add(scale(add(u[a][b], v[a][b]), sij), scale(uv[a][b], ssij))
                    if residual != ZERO:
                        failures += 1
    assert failures == 0
    return {"all_two_copy_inverse_entries_checked": 4 * n * n,
            "all_entries_exact_over_Q_F_mod_F4_minus_1": True,
            "failed_entries": failures}


def native_interface_checks():
    path = ROOT / "upstream/research/coded-native-caller/gauge.py"
    spec = importlib.util.spec_from_file_location("inverse_code_gauge", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    a = mod.Algebra(2)
    q = a.gen(1)
    qi = a.inv(q)
    c = a.gen(2)
    ci = a.inv(c)
    d = a.D(0)
    dd = a.diag(d, d)
    nf = a.mm(dd, a.L(a.mul(c, qi)))
    nb = a.mm(dd, a.U(a.neg(a.mul(q, ci))))
    h = a.diag(a.one, q)
    hi = a.diag(a.one, qi)
    assert a.mm(h, nf, hi) == a.mm(a.L(c), dd)
    assert a.mm(h, nb, hi) == a.mm(a.U(a.neg(ci)), dd)
    # The abstract reciprocal shears do make a switch.
    switch = [[a.zero, a.neg(ci)], [c, a.zero]]
    assert a.mm(a.L(c), a.U(a.neg(ci)), a.L(c)) == switch
    # The actual D-bearing calls cannot be substituted into that identity.
    native_triple = a.mm(a.L(c), dd, a.U(a.neg(ci)), dd, a.L(c), dd)
    d3 = a.mul(d, d, d)
    false_target = a.mm(switch, a.diag(d3, d3))
    assert native_triple != false_target
    return {"H_chart_forward": "H F_C H^-1 = L(C) diag(D,D)",
            "H_chart_backward": "H B_Cinv H^-1 = U(-C^-1) diag(D,D)",
            "H": "diag(I,Q)",
            "abstract_inverse_shear_switch_verified": True,
            "dropping_actual_D_factors_rejected": True,
            "scope": "Free C,Q semidirect algebra: D C D^-1=Q^-1 C Q; no claim that every caller fails."}


def main():
    rpath = ROOT / "research/tensor_obstruction/inputs/R.json"
    r = [[int(Fr(x)) for x in row] for row in json.loads(rpath.read_text())]
    eye = [[ONE, ZERO], [ZERO, ONE]]
    g = [[ZERO, scale(p(0, 0, 0, 1), Fr(6, 7))], [F, ZERO]]
    assert mm(g, g) == ms(eye, Fr(6, 7))
    ep = ma(ms(eye, -13), ms(g, 14))
    em = ma(ms(eye, -13), ms(g, -14))
    assert mm(ep, em) == eye and mm(em, ep) == eye
    assert ma(ep, em) == ms(eye, -26)
    assert mm(mt(ep), mt(em)) == eye
    assert mt(g) != g

    # Equivalent ordinary constant matrix in a nonordinary copy chart.
    j = [[ONE, ZERO], [ZERO, F]]
    ji = [[ONE, ZERO], [ZERO, p(0, 0, 0, 1)]]
    a = [[p(-13), p(12)], [p(14), p(-13)]]
    assert ep == mm(mm(j, a), ji)
    # The pre/post implementation uses one already-returned F payload per
    # copy.  F^2 is an ordinary monomial, so no extra F query is hidden.
    ordinary_post = [[ZERO, scale(p(0, 0, 1), Fr(6, 7))], [ONE, ZERO]]
    already_returned = [[F, ZERO], [ZERO, F]]
    assert mm(ordinary_post, already_returned) == g
    ordinary_post_transpose = [[ZERO, ONE], [scale(p(0, 0, 1), Fr(6, 7)), ZERO]]
    assert mm(ordinary_post_transpose, already_returned) == mt(g)

    checked = {}
    for name, modes in [("source_mode5", [5]), ("all_eight_modes", list(range(8)))]:
        s, rec = projector_check([r[k] for k in modes])
        rec.update(full_code_check(s, ep, em))
        rec["source_modes"] = modes
        checked[name] = rec

    dagpath = ROOT / "research/retained_state_next/F9-SOURCE-DAG-MODE5.json"
    dag = json.loads(dagpath.read_text()) if dagpath.exists() else None
    out = {
        "schema": "rational-two-copy-partial-center-inverse-codes/v1",
        "source_pins": {str(rpath.relative_to(ROOT)): sha256(rpath.read_bytes()).hexdigest()},
        "ring": "Q[F]/(F^4-I); each coefficient is ordered [1,F,F^2,F^3]",
        "G": show(g), "exceptional_Cplus": show(ep), "exceptional_Cminus": show(em),
        "ordinary_constant_A": show(a),
        "projected_code_formula": "Cplus/minus = I-P + P(-13I +/- 14G)",
        "G_squared": "6/7 I", "Cplus_Cminus": "I",
        "Cplus_plus_Cminus": "2(I-14P), an ordinary owner recoding",
        "ordinary_payload_recipe": {
            "inputs": "already-paid clean outputs F t1, F t2, with independent original inputs in the two source copies",
            "forward_G": "((6/7) F^2 (F t2), F t1)",
            "forward_minus_G_transpose": "(-F t2, -(6/7) F^2 (F t1))",
            "new_recursive_queries": 0,
            "scalar_6_over_7_applied_once": True,
            "F2_is_whole_width_monomial": True,
        },
        "helper_clean_payload": {
            "copy_c_center_input": "sum_b G_cb(r X_b) + S H_c",
            "difference_from_original_center": "sum_b G_cb(r X_b) - r X_c",
            "helper_cross_copy_terms": "none",
            "each_source_copy_original_inputs": 632,
            "each_source_copy_independent_helpers": 408,
            "original_helper_endpoint_jobs_preserved": True,
            "premise": "An actual source-DAG schedule makes every F rX mode available before its center, retaining all boundary uses and ground SH separately.",
            "mode5_DAG_receipt_present": dag is not None,
            "mode5_DAG_receipt_status": dag.get("status") if dag else None,
        },
        "raw_dual": {
            "transpose_not_adjoint": True,
            "G_is_not_symmetric": True,
            "inverse_code_raw_dual_is_from_forward_residual": "-G^T",
            "off_diagonal_copy_coefficients_reverse_under_transpose": True,
            "actual_source_replay": "Owned by operator_alignment_next; this receipt proves the code/transpose algebra only.",
        },
        "entrywise_checks": checked,
        "noncommutative_native_interface": native_interface_checks(),
        "copy_chart": "Cplus = J A_P J^-1, J=diag(I,F); A_P=I-P+P A",
        "all_width_proof": [
            "Set F=F9^(tensor m), so F^4=I and F^2 is an admitted monomial for every m>=1.",
            "Each actual signed K_i commutes F; conjugate the finite owner projector by diag K_i.",
            "R_modes R_modes^T=56I gives P^2=P. The two-copy operator G commutes P.",
            "(-13I+14G)(-13I-14G)=169I-196*(6/7)I=I.",
            "Evaluate the finite owner/copied-field formulas at whole-width F; do not tensor a scalar sum or the owner matrix.",
            "The scalar 6/7 and the constants 12,13,14 are applied once at the ordinary fixed-precision interface, with normal rounding charges.",
        ],
        "status": "PASS_EXACT_INVERSE_CODES_AND_ORDINARY_REUSED_PAYLOAD_RECIPE; COMPLETE_CALLER_OPEN",
        "new_supplier_or_kappa": False,
    }
    target = HERE / "PARTIAL-CENTER-INVERSE-CODES.json"
    target.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({"status": out["status"], "entrywise_checks": checked,
                      "native_interface": out["noncommutative_native_interface"]}, indent=2))


if __name__ == "__main__":
    main()
