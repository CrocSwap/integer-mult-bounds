#!/usr/bin/env python3
"""Normalize retained decoder factors and preserve nondegenerate seeds.

Outside dimensions of a redundant factor list can be misleading: unused
columns may carry arbitrary outside vectors. This review removes zero
products and merges proportional factors on either side exactly.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json

import decoder_gauge_search as d


def canonical(v):
    x=next((x for x in v if x),None)
    return (None,F(0)) if x is None else (tuple(y/x for y in v),x)


def reduce_factors(P,Q):
    P,Q=[x[:] for x in P],[x[:] for x in Q]
    while True:
        before=len(P)
        keep=[k for k,(p,q) in enumerate(zip(P,Q)) if any(p) and any(q)]
        P,Q=[P[k] for k in keep],[Q[k] for k in keep]
        groups={}
        for p,q in zip(P,Q):
            key,x=canonical(p)
            if key not in groups:groups[key]=[F(0)]*d.N
            groups[key]=[a+x*b for a,b in zip(groups[key],q)]
        P,Q=[list(p) for p,q in groups.items() if any(q)],[q for p,q in groups.items() if any(q)]
        groups={}
        for p,q in zip(P,Q):
            key,x=canonical(q)
            if key not in groups:groups[key]=[F(0)]*d.N
            groups[key]=[a+x*b for a,b in zip(groups[key],p)]
        P,Q=[p for q,p in groups.items() if any(p)],[list(q) for q,p in groups.items() if any(p)]
        if len(P)==before:break
    return P,Q


def diagnostics(P,Q):
    ranks,pm,qm=d.profiles(P,Q)
    PP,QQ=reduce_factors(P,Q)
    reduced,_,_=d.profiles(PP,QQ)
    return {'stored_terms':len(P),'stored_ranks':ranks,
            'zero_product_terms':[k for k,(p,q) in enumerate(zip(P,Q)) if not any(p) or not any(q)],
            'stored_outside_dimensions':[d.qrank([*d.CP,*P])-8,d.qrank([*d.CP,*Q])-8],
            'normalized_terms':len(PP),'normalized_ranks':reduced,
            'normalized_outside_dimensions':[d.qrank([*d.CP,*PP])-8,d.qrank([*d.CP,*QQ])-8],
            'normalized_moment':str(d.exact_moment(reduced)),
            'normalization_changed_term_count':len(PP)!=len(P)}


def main():
    reports=[]
    for name in ['DECODER-GAUGE-S20261023.json','DECODER-PAIR-GAUGE-S20261024.json']:
        source=d.HERE/name
        data=json.loads(source.read_text())
        checks=[]
        for number,item in enumerate(data['retained']):
            P=[[F(x) for x in col] for col in item['P']]
            Q=[[F(x) for x in col] for col in item['Q']]
            checks.append({'retained_index':number,**diagnostics(P,Q)})
        reports.append({'source':name,'sha256':sha256(source.read_bytes()).hexdigest(),
                        'moves_priced':data.get('exact_support_moves_priced',data.get('candidate_pair_basis_changes_priced')),
                        'retained_diagnostics':checks})
    seeds=[]
    for s,t in [(2,1),(2,2)]:
        P,Q,meta=d.root_swap_seed(s,t)
        item=d.snapshot(P,Q,meta)
        item['normalization_diagnostics']=diagnostics(P,Q)
        seeds.append(item)
    baseline=d.exact_moment([8]*8)
    known=[7,1,7,1]+[8]*6
    result={'status':'EXACT_DECODER_NORMALIZATION_REVIEW',
            'reviewed_searches':reports,
            'nonzero_root_swap_attainers':seeds,
            'known_K3_tight_witness_profile':known,
            'known_K3_moment':str(d.exact_moment(known)),
            'known_K3_excess_over_baseline':str(d.exact_moment(known)-baseline),
            'warning':'The minimum-cost retained gauge snapshots have zero products. Their stored outside dimensions are not the dimensions of a normalized nonzero-term decoder.',
            'scope':'Finite exact replay and normalization. No stronger lower bound, no improved scalar decoder, and no physical supplier claim.'}
    target=d.HERE/'DECODER-SEARCH-REVIEW.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print('RECEIPT',target)
    for r in reports:print(r['source'],'best',r['retained_diagnostics'][0])
    for s in seeds:print('ROOT_SWAP',s['normalization_diagnostics'])


if __name__=='__main__':main()
