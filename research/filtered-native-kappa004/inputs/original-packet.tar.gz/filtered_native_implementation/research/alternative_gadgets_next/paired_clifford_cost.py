#!/usr/bin/env python3
"""Source-bound finite checks for the all-width paired-chart cost proof."""
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'constructive_observers'))
import cross_column_routes as cc
import check_majorana_admission as ma


def basis(rows):
    pivots = {}
    for row in rows:
        value = row
        while value:
            bit = value.bit_length() - 1
            if bit not in pivots:
                pivots[bit] = value
                break
            value ^= pivots[bit]
    return list(pivots.values())


def in_span(value, rows):
    return len(basis(rows + [value])) == len(rows)


def symplectic(v, w, n):
    mask = (1 << n) - 1
    return (((v & mask) & (w >> n)).bit_count() +
            ((w & mask) & (v >> n)).bit_count()) & 1


def main():
    ce, canonical, normalizers, R, routes = cc.source_data()
    paulis = ma.source_paulis(ce, canonical)
    labels = [q | (z << 9) for q, z, p in paulis]
    head_basis = basis(labels)
    q_basis_ports = []
    q_basis = []
    for i, (q, z, p) in enumerate(paulis):
        if len(basis(q_basis + [q])) > len(q_basis):
            q_basis_ports.append(i)
            q_basis.append(q)
    commutator_rows = [sum(symplectic(v, w, 9) << j for j, w in enumerate(head_basis))
                       for v in head_basis]
    assert len(head_basis) == 13
    assert len(basis(commutator_rows)) == 10
    assert len(q_basis) == 9
    assert all(p == 0 and ce.parity(q & z) == 0 for q, z, p in paulis)

    # The phase-aware formula for the paired head in the Bell/Pauli basis is
    # U P U = P P_i if P commutes with P_i, and i P otherwise.
    # Verify it from the exact source compiler on identity and generators;
    # the formula itself applies to every Pauli, not only these samples.
    phase_checks = 0
    for i, head in enumerate(paulis):
        U = ce.canonical_frame(9, canonical['frames'][canonical['start'][i]])
        for P in [(0, 0, 0)] + list(ce.identity(9)):
            conjugated = ce.apply(U.tab, P)
            lhs = ce.pmul(conjugated, head)
            if symplectic(P[0] | (P[1] << 9), labels[i], 9):
                rhs = (P[0], P[1], (P[2] + 1) % 4)
            else:
                rhs = ce.pmul(P, head)
            assert lhs == rhs
            phase_checks += 1

    widths = []
    for width in (2, 4, 6, 8):
        n = 9 * width
        mask = (1 << n) - 1
        # Diagonal Pauli labels between paired columns span the Bell chart.
        L = []
        for pair in range(width // 2):
            a, b = 2 * pair, 2 * pair + 1
            for axis in range(9):
                x = (1 << (9 * a + axis)) | (1 << (9 * b + axis))
                L += [x, x << n]
        L = basis(L)
        assert len(L) == n
        assert all(symplectic(u, v, n) == 0 for u in L for v in L)
        for p in labels:
            q, z = p & 511, p >> 9
            parts = [(q << (9 * c)) | (z << (n + 9 * c)) for c in range(width)]
            for v in L:
                image = v
                for part in parts:
                    if symplectic(v, part, n):
                        image ^= part
                assert in_span(image, L)
        gaussian_rank = len(basis([v & mask for v in L]))
        assert gaussian_rank == 9 * width // 2
        widths.append({'width': width, 'lagrangian_dimension': n,
                       'verified_invariant_heads': 112,
                       'bell_chart_gaussian_rank': gaussian_rank,
                       'proven_lower_bound': 9 * ((width + 1) // 2)})

    result = {
        'status': 'PASS_EXACT_PAIRED_CLIFFORD_CHART_COST',
        'source_ports_sha256': sha256((HERE / 'SOURCE-PORTS.txt').read_bytes()).hexdigest(),
        'head_pauli_span_dimension': len(head_basis),
        'head_commutator_rank': len(basis(commutator_rows)),
        'head_radical_dimension': len(head_basis) - len(basis(commutator_rows)),
        'head_translation_rank': len(q_basis),
        'translation_basis_ports': q_basis_ports,
        'translation_basis_vectors': q_basis,
        'phase_aware_bell_generator_checks': phase_checks,
        'finite_invariant_chart_checks': widths,
        'all_width_necessary_gaussian_rank': '9*ceil(m/2)',
        'all_even_width_attained_gaussian_rank': '9*m/2',
        'proof': 'For an invariant Lagrangian L, each coefficient image C_i={([p_i,v_c])_c:v in L} is self-orthogonal in F2^m. Hence dim(C_i)<=floor(m/2). For A=L intersect standard_Z, nine independent q_i make A embed into a direct sum of nine such C_i. Therefore dim(A)<=9 floor(m/2), and the chart rank9m-dim(A)>=9 ceil(m/2). Paired Bell charts attain the even-width bound.',
        'scope': 'A common exact Clifford change of basis making all source heads U_i tensor-power(m) monomial. No lower bound for non-Clifford basis changes, projected/operator-valued observers, different gauges at different ports, or retained caller-state amortization. This is not a kappa improvement.',
        'literature': [
            {'url': 'https://arxiv.org/abs/1705.09176',
             'title': 'Shorter stabilizer circuits via Bruhat decomposition and quantum circuit transformations',
             'authors': 'Dmitri Maslov and Martin Roetteler',
             'exact_excerpt': 'a circuit in this normal form is optimal in the number of Hadamard gates used',
             'use': 'Relates the monomial/Hadamard decomposition to the correct basis-change resource. The source-specific lower bound above is proved here.'},
            {'url': 'https://arxiv.org/abs/2208.01688',
             'title': 'Duality theory for Clifford tensor powers',
             'authors': 'Felipe Montealegre-Mora and David Gross',
             'exact_excerpt': 'a unified framework for the duality approach that also covers qubit systems',
             'use': 'Motivates isotropic multiplicity-space and projected-code alternatives; no compiler admission is imported.'}
        ]
    }
    out = HERE / 'PAIRED-CLIFFORD-COST.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
