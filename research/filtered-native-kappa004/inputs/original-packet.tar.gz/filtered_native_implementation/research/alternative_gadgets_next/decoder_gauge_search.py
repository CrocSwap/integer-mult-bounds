#!/usr/bin/env python3
"""Exact-support search for 11/12-term two-sided scalar decoders.

Every factor update preserves P Q^T = R^T R over the rationals. Candidate
prices use the actual binary source-label pairing, not support cardinality.
The search is finite and heuristic; a failed search is not a floor theorem.
"""
from collections import Counter
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import argparse
import json
import math
import random
import sys
import time

HERE = Path(__file__).resolve().parent
PORTS = HERE / 'SOURCE-PORTS.txt'
ROWS = [list(map(int, line.split())) for line in PORTS.read_text().splitlines()[1:]]
q = [r[0] for r in ROWS]
C = [r[3:] for r in ROWS]
N = len(C)
assert N == 112
CP = [[F(C[i][k]) for i in range(N)] for k in range(8)]
TARGET = [[sum(a*b for a,b in zip(C[i],C[j])) for j in range(N)] for i in range(N)]
assert all(((q[i]&q[j]).bit_count() & 1) == int(i == j or TARGET[i][j] == 0)
           for i in range(N) for j in range(N))
EXP = 1 - .0030217758
PRICE = [0] + [r**EXP for r in range(1,10)]
BASELINE = 8*PRICE[8]


def mask(values):
    return sum(1 << i for i,x in enumerate(values) if x)


@lru_cache(maxsize=200000)
def basis(bits):
    piv = [0]*9
    while bits:
        low = bits & -bits
        x = q[low.bit_length()-1]
        bits ^= low
        while x:
            k = x.bit_length()-1
            if piv[k]:
                x ^= piv[k]
            else:
                piv[k] = x
                break
    return tuple(x for x in piv if x)


@lru_cache(maxsize=300000)
def pair_rank_bases(a,b):
    piv = [0]*9
    rank = 0
    for x in a:
        row = sum(((x&y).bit_count() & 1) << j for j,y in enumerate(b))
        while row:
            k = row.bit_length()-1
            if piv[k]: row ^= piv[k]
            else:
                piv[k] = row
                rank += 1
                break
    return rank


def cost(a,b):
    return pair_rank_bases(basis(a),basis(b))


def profiles(P,Q):
    pm,qm = list(map(mask,P)),list(map(mask,Q))
    ranks = [cost(a,b) for a,b in zip(pm,qm)]
    return ranks,pm,qm


def exact_moment(ranks):
    with localcontext() as ctx:
        ctx.prec=65
        exponent = D(1)-D('0.0030217758')
        return sum((D(r)**exponent for r in ranks if r),D(0))


def qrank(rows):
    a = [[F(x) for x in row] for row in rows]
    if not a: return 0
    r=0
    for j in range(len(a[0])):
        k=next((k for k in range(r,len(a)) if a[k][j]),None)
        if k is None: continue
        a[r],a[k]=a[k],a[r]
        v=a[r][j];a[r]=[x/v for x in a[r]]
        for k in range(r+1,len(a)):
            if a[k][j]:
                v=a[k][j];a[k]=[x-v*y for x,y in zip(a[k],a[r])]
        r+=1
        if r == len(a): break
    return r


def verify(P,Q):
    for i in range(N):
        for j in range(N):
            assert sum((p[i]*r[j] for p,r in zip(P,Q) if p[i] and r[j]),F(0)) == TARGET[i][j]


def snapshot(P,Q,meta):
    ranks,pm,qm=profiles(P,Q)
    verify(P,Q)
    baseline = exact_moment([8]*8)
    moment = exact_moment(ranks)
    return {'meta':meta,'terms':len(P),'ranks':ranks,
            'rank_mass':sum(ranks),'moment':str(moment),
            'baseline_moment':str(baseline),'improvement':str(baseline-moment),
            'outside_dimensions': [qrank([*CP,*P])-8,qrank([*CP,*Q])-8],
            'left_support_sizes':[x.bit_count() for x in pm],
            'right_support_sizes':[x.bit_count() for x in qm],
            'left_label_dimensions':[len(basis(x)) for x in pm],
            'right_label_dimensions':[len(basis(x)) for x in qm],
            'all_12544_entries_checked':True,
            'P':[[str(x) for x in col] for col in P],
            'Q':[[str(x) for x in col] for col in Q]}


def make_ansatz(A,B,E,FF):
    # A and B are lists of eight-coordinate column vectors.
    assert all(sum(a*b for a,b in zip(aa,bb)) == 0 for aa in A for bb in B)
    P=[[CP[k][i]+sum(e[i]*a[k] for e,a in zip(E,A)) for i in range(N)] for k in range(8)]
    Q=[[CP[k][i]+sum(f[i]*b[k] for f,b in zip(FF,B)) for i in range(N)] for k in range(8)]
    for e,a in zip(E,A):
        P.append([-x for x in e]);Q.append([sum(F(c)*v for c,v in zip(row,a)) for row in C])
    for f,b in zip(FF,B):
        P.append([sum(F(c)*v for c,v in zip(row,b)) for row in C]);Q.append([-x for x in f])
    return P,Q


def root_swap_seed(kr,kc):
    sys.path.insert(0,str(HERE/'tightness_replay'))
    import swapfam as sf
    _,ex=sf.feasible_search(kr,kc)
    if ex is None: return None
    X,Y,E,FF,names=sf.build_family(*ex,verbose=False)
    PP,QQ=sf.build(X,Y,E,FF)
    def canon(v):
        sg=1 if next(x for x in v if x)>0 else -1
        return tuple(sg*x for x in v),sg
    old={canon(v)[0]:(i,canon(v)[1]) for i,v in enumerate(sf.C)}
    mapping=[]
    for row in C:
        key,sg=canon(row)
        i,oldsg=old[key]
        mapping.append((i,sg*oldsg))
    # Upstream factors multiply to C C^T/4; scale both by two.
    P=[[2*sg*col[i] for i,sg in mapping] for col in PP]
    Q=[[2*sg*col[i] for i,sg in mapping] for col in QQ]
    return P,Q,{'kind':'source-bound root-swap seed','outside':[kr,kc],
                'upstream_configuration':ex,'names':names}


def generated_seed(kind,rng,index):
    coords=rng.sample(range(8),4 if kind=='22' else 3)
    def put(vals):
        out=[0]*8
        for k,v in zip(coords,vals):out[k]=v
        return out
    if kind=='21':
        A=[put([1,-1,0]),put([0,1,-1])]
        B=[put([1,1,1])]
    else:
        A=[put([1,1,1,1]),put([1,1,-1,-1])]
        B=[put([1,-1,1,-1]),put([1,-1,-1,1])]
    def factor(j):
        mode=rng.choice(coords)
        char=rng.randrange(1,512)
        bit=rng.randrange(2)
        typ=index%6
        if typ==0:
            # Signed singletons and small cosets offer genuinely low-rank corrections.
            selected=set(rng.sample(range(N),rng.choice([1,2,3,4,6,8])))
            return [F(rng.choice([-2,-1,1,2])) if i in selected else F(0) for i in range(N)]
        if typ==1:
            other=rng.choice(coords)
            vals=[F(row[mode]+rng.choice([-1,1])*row[other],2) for row in C]
        else:
            vals=[F(row[mode]) for row in C]
        if typ==2:
            char2=rng.randrange(1,512); bit2=rng.randrange(2)
            cut=[((v&char).bit_count()&1)==bit and ((v&char2).bit_count()&1)==bit2 for v in q]
        elif typ==3:
            other=rng.choice(coords)
            cut=[row[other]==rng.choice([-1,0,1]) for row in C]
        elif typ==4:
            cut=[((v&char).bit_count()&1)==bit for v in q]
        else:
            # Whole-mode truncation plus a tiny outside perturbation.
            cut=[True]*N
            for i in rng.sample(range(N),2):cut[i]=False
        return [-v if keep else F(0) for v,keep in zip(vals,cut)]
    E=[factor(j) for j in range(len(A))]
    FF=[factor(j+2) for j in range(len(B))]
    P,Q=make_ansatz(A,B,E,FF)
    return P,Q,{'kind':'orthogonal outside ansatz','outside':list(map(int,kind)),
                'sample':index,'coordinates':coords,'A':A,'B':B,
                'E':[[str(x) for x in v] for v in E],
                'F':[[str(x) for x in v] for v in FF]}


def search(P0,Q0,rng,steps,beam_pairs,temperature):
    P=[p[:] for p in P0]; Q=[p[:] for p in Q0]
    ranks,pm,qm=profiles(P,Q)
    current=sum(PRICE[r] for r in ranks)
    best=(current,[p[:] for p in P],[p[:] for p in Q],[],ranks[:])
    moves=[]; proposed=0
    for step in range(steps):
        pairs=[(a,b) for a in range(len(P)) for b in range(len(P)) if a!=b]
        rng.shuffle(pairs)
        choices=[]
        for a,b in pairs[:beam_pairs]:
            # A cancelled coefficient has an exact rational ratio. All other
            # t share the same union supports, hence cannot improve the rank.
            pc={};qc={}
            for i in range(N):
                if P[a][i] and P[b][i]:
                    t=-P[b][i]/P[a][i]
                    if t:pc[t]=pc.get(t,0)|(1<<i)
                if Q[a][i] and Q[b][i]:
                    t=Q[a][i]/Q[b][i]
                    if t:qc[t]=qc.get(t,0)|(1<<i)
            for t in pc.keys()|qc.keys():
                # Bound coefficient growth during discovery; this is a
                # declared search restriction, never an algebraic claim.
                if abs(t.numerator)>64 or t.denominator>64:continue
                np=(pm[a]|pm[b])&~pc.get(t,0)
                nq=(qm[a]|qm[b])&~qc.get(t,0)
                ra,rb=cost(pm[a],nq),cost(np,qm[b])
                value=current-PRICE[ranks[a]]-PRICE[ranks[b]]+PRICE[ra]+PRICE[rb]
                nnz=np.bit_count()+nq.bit_count()-pm[b].bit_count()-qm[a].bit_count()
                choices.append((value,nnz,a,b,t,np,nq,ra,rb))
                proposed+=1
        if not choices:break
        choices.sort(key=lambda z:(round(z[0],11),z[1]))
        if rng.random()<temperature:
            near=[x for x in choices[:50] if x[0]<=current+2.05]
            ch=rng.choice(near) if near else choices[0]
        else:ch=choices[0]
        value,nnz,a,b,t,np,nq,ra,rb=ch
        if value>current+2.05:break
        P[b]=[v+t*u for u,v in zip(P[a],P[b])]
        Q[a]=[u-t*v for u,v in zip(Q[a],Q[b])]
        assert mask(P[b])==np and mask(Q[a])==nq
        pm[b],qm[a]=np,nq;ranks[a],ranks[b]=ra,rb
        current=value;moves.append([a,b,str(t)])
        if current<best[0]-1e-9:
            best=(current,[p[:] for p in P],[p[:] for p in Q],moves[:],ranks[:])
        if current<BASELINE-1e-9:
            break
    return best,proposed


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seeds',type=int,default=160)
    ap.add_argument('--keep',type=int,default=12)
    ap.add_argument('--steps',type=int,default=80)
    ap.add_argument('--pairs',type=int,default=48)
    ap.add_argument('--seed',type=int,default=20261023)
    args=ap.parse_args()
    rng=random.Random(args.seed);begin=time.monotonic()
    seeds=[];screen=Counter()
    for kr,kc in [(2,1),(2,2)]:
        z=root_swap_seed(kr,kc)
        if z:
            seeds.append(z)
            print('ROOT_SEED',kr,kc,profiles(z[0],z[1])[0],flush=True)
    for k in range(args.seeds):
        z=generated_seed('21' if k%2==0 else '22',rng,k)
        rs,_,_=profiles(z[0],z[1]);score=sum(PRICE[x] for x in rs)
        screen[sum(rs)]+=1
        seeds.append(z)
    seeds.sort(key=lambda z:sum(PRICE[x] for x in profiles(z[0],z[1])[0]))
    selected=seeds[:args.keep]
    print('SCREEN',len(seeds),'mass_histogram',dict(sorted(screen.items())),flush=True)
    retained=[];total=0
    for number,(P,Q,meta) in enumerate(selected):
        best,count=search(P,Q,rng,args.steps,args.pairs,.18)
        total+=count
        price,PP,QQ,moves,ranks=best
        data=snapshot(PP,QQ,{**meta,'accepted_moves':moves,'search_seed':args.seed})
        retained.append(data)
        print('SEARCH',number,'initial',sum(profiles(P,Q)[0]),'best',ranks,
              'outside',data['outside_dimensions'],'improvement',data['improvement'],
              'seconds',round(time.monotonic()-begin,2),flush=True)
    retained.sort(key=lambda z:D(z['moment']))
    out={'status':'FINITE_EXACT_DECODER_GAUGE_SEARCH','source_sha256':sha256(PORTS.read_bytes()).hexdigest(),
         'parameters':vars(args),'screened_seeds':len(seeds),
         'seed_mass_histogram':dict(sorted(screen.items())),
         'exact_support_moves_priced':total,'best':retained[0] if retained else None,
         'retained':retained,'elapsed_seconds':time.monotonic()-begin,
         'scope':'Finite rational 11/12-term factor search on actual source R andq. Two-sided outside ranks checked exactly. Every retained factorization checked onall112^2 entries. No physical frame/hosting/ordinary bill or kappa claim; no universal lowerbound.'}
    target=HERE/f'DECODER-GAUGE-S{args.seed}.json'
    target.write_text(json.dumps(out,indent=2)+'\n')
    print('RECEIPT',target,'moves',total,flush=True)


if __name__=='__main__':main()
