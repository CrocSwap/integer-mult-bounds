#!/usr/bin/env python3
"""Finite exact probes; these are not uniform route/admission certificates."""
import argparse, hashlib, json, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'constructive_observers'))
import cross_column_routes as cc
import check_majorana_admission as ma
p=argparse.ArgumentParser();p.add_argument('--width',type=int,default=3);p.add_argument('--samples',type=int,default=16);p.add_argument('--trials',type=int,default=64);p.add_argument('--gates',type=Path);p.add_argument('--seed',type=int,default=20261023);a=p.parse_args()
assert a.width%2==1 and 1<=a.width<=5
ce,canonical,normals,R,routes=cc.source_data();ps=ma.source_paulis(ce,canonical)
body=str(len(ps))+'\n'+'\n'.join(' '.join(map(str,[q,z,phase]+[int(R[k][i]) for k in range(8)])) for i,(q,z,phase) in enumerate(ps))+'\n'
(HERE/'SOURCE-PORTS.txt').write_text(body)
exe=HERE/'nonlinear_majorana'
subprocess.run(['g++','-O3','-std=c++17',str(HERE/'nonlinear_majorana.cpp'),'-o',str(exe)],check=True)
fixed=json.loads(a.gates.read_text())['gates'] if a.gates else []
body_input=body+str(len(fixed))+'\n'+'\n'.join(' '.join(map(str,g)) for g in fixed)+'\n'
r=subprocess.run([str(exe),str(a.width),str(a.samples),str(a.trials),str(a.seed)],input=body_input,text=True,capture_output=True,check=True)
x=json.loads(r.stdout);x['source_port_sha256']=hashlib.sha256(body.encode()).hexdigest();x['scope']='Finite exact sampled-column source-bound probe of monomial Majoranas obtained by shared nonlinear cubic address conjugation. Every sampled physical column has exactly verified squared norm4. No complete column or all-width route-admission claim unless samples=-1.'
x['input_gate_file']=str(a.gates) if a.gates else None;x['seed']=a.seed
suffix=f'-FIXED-SEED{a.seed}' if a.gates else ''
out=HERE/f'NONLINEAR-MAJORANA-W{a.width}-S{a.samples}-T{a.trials}{suffix}.json';out.write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps({'result':str(out),'baseline':x['baseline'],'best':x['best'],'gates':x['gates']},indent=2))
