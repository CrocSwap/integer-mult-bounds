#!/usr/bin/env python3
"""Conditional invoice for eight rank8 centers replaced by eight rank1 jobs.

This is arithmetic and a static dependency audit, not a supplier construction.
The unchanged-word rank1 snapshot identities do NOT establish the replacement.
Source controller, interval, compiler and outer machinery retain their original
attribution. Apache-2.0; substantial OpenAI assistance.
"""
from collections import Counter
from decimal import Decimal as D, localcontext
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
NATIVE = {1: 2201, 2: 412, 3: 510, 4: 127, 5: 40, 8: 8}
HELPERS = {4: 28, 7: 7, 8: 47, 9: 326}
BENCHMARK = Q('.0030217758')
SOURCES = {
    'native': 'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz',
    'snapshot': 'research/operator_alignment_next/RANK1-SNAPSHOT-COMPLETION.json',
    'deleted_snapshot_review': 'research/integration_next/RANK1-CENTER-DEPENDENCY-INDEPENDENT-REVIEW.json',
    'controller': 'upstream/research/joint-helper-lattice/CONTROLLER.json',
    'controller_code': 'upstream/research/query-thinned-controllers/controller.py',
    'selected': 'research/integration_next/current_source/certificates/selected-result.json',
    'selected_review': 'upstream/docs/research/pr-intake-evidence/pr4470/PROOF-REVIEW.md',
    'bit': 'upstream/research/query-thinned-controllers/RESULT.json',
    'intervals': 'upstream/research/higher-moment-strictification/verify.py',
    'outer': 'upstream/research/pr4359-p7-padding/dependencies/compiler-refill/endpoint.py',
}


def read(path):
    b = path.read_bytes()
    return json.loads(gzip.decompress(b) if path.suffix == '.gz' else b)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def encode(value):
    if isinstance(value, Q):
        return str(value)
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(v) for v in value]
    return value


def native_price(source):
    profiles = {}
    for orientation, word in source['programs'].items():
        paid = Counter()
        for e in word:
            if e[0] == 'climb':
                paid[e[5]] += 1
            elif e[0] == 'center':
                paid[e[4]] += 1
        assert dict(paid) == NATIVE
        profiles[orientation] = dict(sorted(paid.items()))
    return profiles


def dependency_audit(source, snapshot):
    """Static may-depend ancestry; never infers nonzero algebraic dependence."""
    needed = {(a['after_event'], a['owner'])
              for row in snapshot['results'] for t in row['targets']
              if t['bank'] == 'Y' for a in t['cleanup_recipe']}
    masks = [0] * 633
    captured, centers = {}, []
    for pos, e in enumerate(source['programs']['backward']):
        typ, dest = e[0], None
        if typ == 'scalar':
            a = e[1]
            dest = a[1][1] + (632 if a[1][0] == 'C' else 0)
            if a[0] == 'clear':
                masks[dest] = 0
            elif a[0] in ('add', 'copy'):
                src = a[2][1] + (632 if a[2][0] == 'C' else 0)
                if a[0] == 'copy':
                    masks[dest] = masks[src]
                else:
                    masks[dest] |= masks[src]
            elif a[0] == 'scale' and a[2] == 0:
                masks[dest] = 0
        elif typ == 'center':
            dest = 632 + e[1]
            masks[dest] |= 1 << len(centers)
            centers.append(pos)
        elif typ == 'climb':
            dest = e[2]
        elif typ == 'warp':
            dest = e[1][1] + (632 if e[1][0] == 'C' else 0)
        if dest is not None and (pos, dest) in needed:
            captured[pos, dest] = masks[dest]
    assert set(captured) == needed and len(centers) == 8
    records = []
    for row in snapshot['results']:
        assert len(row['target_modes']) == 1
        mode = int(next(iter(row['target_modes'])))
        y = next(t for t in row['targets'] if t['bank'] == 'Y')
        terms = [{**a, 'center_ancestor_mask': captured[a['after_event'], a['owner']]}
                 for a in y['cleanup_recipe']]
        assert sorted(t['center_ancestor_mask'] for t in terms) == [0, 1 << mode]
        records.append({'mode': mode, 'removed_center_event': centers[mode],
                        'precenter_rank1_inputs': row['retained_precenter_input_gather'],
                        'unchanged_word_cleanup': terms})
    return {
        'method': 'Static dependency-union audit, independent of the native row interpreter.',
        'center_events': centers,
        'records': sorted(records, key=lambda r: r['mode']),
        'all_eight_use_their_own_center_descendant': True,
        'implication': 'The unchanged-word identities are not center-deletion certificates. Each uses a late snapshot whose dependency path includes the center it proposes to replace. This structural audit alone does not prove a nonzero residual or rule out another reconstruction.',
    }


def margin(E, targets, paid, c):
    a, b = E.moment(targets, 1-c), E.moment(paid, 1-c)
    return a[0]-b[1], a[1]-b[0]


def crossing(E, targets, paid):
    with localcontext() as ctx:
        ctx.prec = 65
        def moment(h, c):
            return sum(D(n)*D(r)**(1-c) for r, n in h.items())
        lo, hi = D(0), D('.02')
        for _ in range(160):
            mid = (lo+hi)/2
            if moment(targets, mid) > moment(paid, mid):
                lo = mid
            else:
                hi = mid
        denominator = 10**14
        left = Q(int(lo*denominator), denominator)
        right = left + Q(1, denominator)
    ml, mr = margin(E, targets, paid, left), margin(E, targets, paid, right)
    assert ml[0] > 0 and mr[1] < 0
    signed = Counter(targets)
    signed.subtract(paid)
    derivative_lower = None
    for j in range(16):
        a, b = Q(j, 800), Q(j+1, 800)
        low = Q(0)
        for r, n in signed.items():
            term = E.mul(E.power(r, 1-b if n > 0 else 1-a), E.log_bounds(r))
            low += n*term[0 if n > 0 else 1]
        derivative_lower = low if derivative_lower is None else min(low, derivative_lower)
    assert derivative_lower > 0
    return {'exact_bracket': [left, right], 'decimal_diagnostic': str(lo),
            'lower_margin': E.display(ml), 'upper_margin': E.display(mr),
            'strictly_decreasing_on': [Q(0), Q(1, 50)],
            'negative_derivative_magnitude_lower': E.display((derivative_lower,)*2),
            'scope': 'Unique crossing in [0,.02] for this fixed actual p16 invoice; not a globally optimized controller.'}


def safe_power(E, n, exponent):
    """Preserve source exp-point guard by exact exponent splitting."""
    if abs(exponent)*E.log_bounds(n)[1] < 15:
        return E.power(n, exponent)
    half = safe_power(E, n, exponent/2)
    return E.mul(half, half)


def outer_example(E, L, targets, paid, kappa, tested, bit_admitted, ordinary_bit):
    d = (tested-kappa)/7
    assert d > 0 and d.numerator == 1 and tested < bit_admitted < ordinary_bit
    t, u, v, cutoff, floor = 1-tested, Q(1, 5), 1024, 20, 21
    tm = E.moment(targets, t)
    alpha = E.divide(E.moment(paid, t), tm)
    gamma = E.divide(E.moment(paid, t+u), E.mul(E.power(cutoff, u), tm))
    delta = E.divide((Q(sum(targets.values())*floor),)*2,
                     E.mul(E.power(cutoff, tested), tm))
    gap, decay = Q(1, 1000), Q(97, 100)
    assert alpha[1] < 1-gap and gamma[1] < decay and delta[1] < decay
    assert decay**128 < Q(1, 16)
    normalized = 1/(1+v*gap) + Q(4, 2**32)
    assert normalized < 1 and cutoff**64 < floor**63
    theta, power = Q(63, 64), 1200
    eta = E.scale(safe_power(E, 145, -v*tested), t)
    assert 2*(cutoff**v)**64 <= (145**v)**63
    assert eta[0] > theta**power
    assert safe_power(E, 145, v*tested)[1] < 2**power
    old_power_fails = eta[1] < theta**1000
    step = d.denominator
    def passes(j):
        return (step*j+1)**power < 2**j
    lo, hi = 1, 2
    while not passes(hi):
        lo, hi = hi, 2*hi
    while hi-lo > 1:
        mid = (lo+hi)//2
        if passes(mid):
            hi = mid
        else:
            lo = mid
    assert passes(hi) and not passes(hi-1) and step*hi > 8*v
    params = {'kappa': kappa, 'tested_saving': tested,
              'complex_uniform_saving': kappa+6*d, 'b': kappa+5*d,
              'a': kappa+4*d, 'q': kappa+3*d, 'bit_saving': bit_admitted,
              'epsilon': 1-d, 'beta': 1-3*d, 'r0': d/10,
              'stop': d, 'layout': d, 'd': d}
    result = L.ledger(params)
    result['functional_checks']['actual_new_BIT_stock_sublinear'] = params['beta']*(1-Q('.004'))
    assert len(result['strict_checks']) == 54 and len(result['functional_checks']) == 4
    assert all(x > 0 for group in ('strict_checks', 'functional_checks') for x in result[group].values())
    controls = {}
    for name, changes in [('closed_bit', {'bit_saving': params['a']}),
                          ('closed_complex', {'complex_uniform_saving': params['b']}),
                          ('closed_epsilon', {'epsilon': Q(1)})]:
        bad = L.ledger(dict(params, **changes))
        failures = [k for k, x in bad['strict_checks'].items() if x <= 0]
        assert failures
        controls[name] = failures
    return {
        'conditional_kappa': kappa, 'tested_saving': tested,
        'admitted_bit_saving': bit_admitted, 'ordinary_bit_saving': ordinary_bit,
        'alpha': E.display(alpha), 'gamma': E.display(gamma), 'delta': E.display(delta),
        'tail_tensor_power': v, 'paid_cutoff_base': cutoff, 'target_floor_base': floor,
        'alpha_gap': gap, 'decay_limit': decay, 'normalized_paid_bound': normalized,
        'compiler_theta': theta, 'compiler_logarithm_power': power,
        'selected_power1000_fails_complement_check': old_power_fails,
        'compiler_eta': E.display(eta), 'uniform_rank_encoding': '2^'+str(step*hi),
        'integer_threshold_j': hi, 'outer': result,
        'strict_limiting_outer_slack': min(result['margins'].values())-kappa,
        'negative_controls': controls,
        'conditional_on': 'An exact supplier with the assumed unchanged native endpoint, all632 independent original columns and408 helper jobs, legal extra owned snapshots and erasure, and a finite paid ordinary/precision/storage bound compatible with the retained compiler hypotheses. None is supplied by this arithmetic file.',
    }


def one_mode_tail_reprice(E, targets, paid, examples):
    """Reuse existing outer/compiler parameters; only the paid tail changes."""
    records = []
    for example in examples:
        tested = example['tested_saving']
        t, u, v = 1-tested, Q(1, 5), 1024
        tm = E.moment(targets, t)
        alpha = E.divide(E.moment(paid, t), tm)
        gamma = E.divide(E.moment(paid, t+u), E.mul(E.power(20, u), tm))
        delta = E.divide((Q(sum(targets.values())*21),)*2,
                         E.mul(E.power(20, tested), tm))
        gap, decay = Q(1, 100000), Q(97, 100)
        assert alpha[1] < 1-gap and gamma[1] < decay and delta[1] < decay
        assert decay**128 < Q(1, 16)
        bound = 1/(1+v*gap)+Q(4, 2**32)
        assert bound < 1
        records.append({
            'conditional_kappa': example['conditional_kappa'],
            'tested_saving': tested,
            'alpha': E.display(alpha), 'gamma': E.display(gamma), 'delta': E.display(delta),
            'alpha_gap': gap, 'normalized_paid_bound': bound,
            'moment_margin': E.display(margin(E, targets, paid, tested)),
            'reused_unchanged_checks': 'Target count/profile, ambient145, cutoff20, floor21, tensor power1024, compiler power1200, all outer parameters,54 strict predicates and4 functional guards from the corresponding existing outer example. Only paid-moment and tail ratios are repriced here.',
        })
    return records


def main():
    started = time.monotonic()
    inputs = {name: ROOT/path for name, path in SOURCES.items()}
    source, snapshots, word = (read(inputs[k]) for k in ('native', 'snapshot', 'controller'))
    profiles = native_price(source)
    audit = dependency_audit(source, snapshots)
    bit = read(inputs['bit'])['ordinary_BIT']
    ordinary = (1-Q(bit['atom']))*Q(bit['after_cover'])+Q(bit['atom'])*Q('.0000384599')
    assert ordinary == Q(bit['ordinary_saving']) == Q('0.0034363538396')
    E = load(inputs['intervals'], 'conditional_replacement_intervals')
    L = load(inputs['outer'], 'conditional_replacement_outer')
    targets, paid = Counter(), Counter()
    counts = Counter()
    for e in word['physical_events']:
        if e[0] == 'LOCAL':
            counts['backward' if e[3] else 'forward'] += 1
            targets.update(HELPERS)
            paid.update(NATIVE)
        elif e[0] == 'QUERY_SHEAR':
            counts['thin'] += 1
            paid[1] += 112
        elif e[0] == 'IDLE':
            paid[8*len(e[2])] += 224
    for term in word['diagonal']:
        targets[1+8*sum(term[1:])] += 112
    assert counts == {'forward': 2, 'backward': 16, 'thin': 15}
    assert sum(targets.values()) == 10928 and sum(paid.values()) == 64404
    cases = []
    for replaced, per_call in ((0, 0), (16, 1), (16, 8), (18, 8)):
        p = paid.copy()
        p[8] -= per_call*replaced
        p[1] += per_call*replaced
        p = +p
        cases.append({'replaced_full_calls': replaced,
                      'replaced_centers_per_call': per_call,
                      'orientation_scope': {0:'unchanged source',16:'backward only',18:'both orientations'}[replaced],
                      'productive_targets': dict(sorted(targets.items())),
                      'complete_paid': dict(sorted(p.items())),
                      'productive_count': sum(targets.values()), 'paid_count': sum(p.values()),
                      'productive_mass': sum(r*n for r,n in targets.items()),
                      'paid_mass': sum(r*n for r,n in p.items()),
                      'rank_surplus': sum(r*n for r,n in targets.items())-sum(r*n for r,n in p.items()),
                      'benchmark_margin': E.display(margin(E, targets, p, BENCHMARK)),
                      'raw_crossing': crossing(E, targets, p)})
    # Price the weaker backward-only premise, so no forward transpose is assumed.
    backward_paid = cases[2]['complete_paid']
    examples = [
        outer_example(E, L, targets, backward_paid, Q('.00339999'), Q('.003399995'), Q('.0034'), ordinary),
        outer_example(E, L, targets, backward_paid, Q('.00343635'), Q('.0034363507'), Q('.003436353'), ordinary),
    ]
    one_mode_tails = one_mode_tail_reprice(E, targets, cases[1]['complete_paid'], examples)
    # Check strict completion/compiler margins at the BIT budget itself.
    # Only the outer admission endpoint is open; continuity then permits
    # cofinal rational parameters from below without a hidden tail barrier.
    limit_paid, lt = cases[1]['complete_paid'], 1-ordinary
    limit_target = E.moment(targets, lt)
    limit_alpha = E.divide(E.moment(limit_paid, lt), limit_target)
    limit_gamma = E.divide(E.moment(limit_paid, lt+Q(1,5)),
                           E.mul(E.power(20,Q(1,5)),limit_target))
    limit_delta = E.divide((Q(sum(targets.values())*21),)*2,
                           E.mul(E.power(20,ordinary),limit_target))
    limit_eta = E.scale(safe_power(E,145,-1024*ordinary),lt)
    assert limit_alpha[1] < 1-Q(1,100000)
    assert max(limit_gamma[1],limit_delta[1]) < Q(97,100)
    assert limit_eta[0] > Q(63,64)**1200
    assert safe_power(E,145,1024*ordinary)[1] < 2**1200
    deletion_review = read(inputs['deleted_snapshot_review'])
    assert deletion_review['status'] == 'PASS'
    assert all(t['output_terms'] == 0 and t['exact_match']
               for t in deletion_review['helper_clean_center_free_word']['tests'])
    out = {
        'schema': 'unrealized-center-replacement-conditional-economics/v1',
        'status': 'PASS_CONDITIONAL_ARITHMETIC_ONLY; NATIVE_REPLACEMENT_NOT_ESTABLISHED',
        'new_kappa_claimed': False,
        'source_sha256': {str(path.relative_to(ROOT)): sha256(path.read_bytes()).hexdigest() for path in inputs.values()},
        'baseline_selected_kappa': read(inputs['selected'])['decimal'],
        'actual_native_profiles': profiles,
        'conditional_changed_native_profile': {1:2209, 2:412, 3:510, 4:127, 5:40},
        'conditional_one_mode_native_profile': {1:2202, 2:412, 3:510, 4:127, 5:40, 8:7},
        'helper_targets_unchanged': HELPERS,
        'all632_originals_and408_helpers_required': True,
        'extra_owned_snapshots_productive_credit': 0,
        'snapshot_dependency_audit': audit,
        'actual_eight_recipe_failure': {'independent_receipt': SOURCES['deleted_snapshot_review'],
            'conclusion': deletion_review['conclusion'],
            'scope': 'The eight unchanged-word recipes fail after all centers are removed. The conditional economic profiles below remain unrealized; this does not exclude another observation or a one-mode construction.'},
        'controller_direction_counts': dict(counts),
        'benchmark_c': BENCHMARK,
        'per_replaced_call_moment_saving': E.display(tuple(8*(x-1) for x in E.power(8,1-BENCHMARK))),
        'cases': cases,
        'conditional_outer_examples': examples,
        'one_mode_backward_outer_feasibility': one_mode_tails,
        'outer_suprema': {
            'with_existing_admitted_BIT_budget': Q('.0034'),
            'with_rational_readmission_below_existing_ordinary_BIT_budget': ordinary,
            'reason': 'Every legal outer choice has kappa<epsilon*q<q<a<admitted_BIT. The displayed cofinal slack family approaches any smaller bit saving because the hypothetical complex root is larger. These are strict suprema, not attained endpoints. Changing delayed-cover or native BIT budgets is outside this calculation.',
            'one_mode_strict_completion_at_ordinary_BIT_limit': {
                'tested_saving': ordinary, 'alpha': E.display(limit_alpha),
                'gamma': E.display(limit_gamma), 'delta': E.display(limit_delta),
                'compiler_eta': E.display(limit_eta),
                'cofinal_parameter_family': 'For d=1/n>0 sufficiently small: kappa=B−9d, tested=B−2d, admitted_BIT=B−d, uniform=B−3d, b=B−4d, a=B−5d, q=B−6d, epsilon=1−d, beta=1−3d, stop=layout=d, r0=d/10. Here B is the fixed ordinary BIT budget. Strict tail/compiler margins at B persist by continuity; the retained outer slack inequalities hold cofinally. No equality at kappa=B is admitted.'},
        },
        'remaining_adoption_gates': [
            'Exact center-deleted endpoint in every original column, including arbitrary helper inputs; original unchanged-word snapshot identities are insufficient.',
            'Chronological capture/query/use/erase schedule with actual physical frames, absolute phases, source-bound lifts, and all extra-owned streams restored zero.',
            'All-width identity and scalar coefficients outside tensor powers; stage embedding and spectator legality in the original p16 caller.',
            'Backward-only replacement is sufficient for the displayed economics; both-orientation pricing needs a separately valid forward endpoint.',
            'Changed local scalar/route work, fixed-tape movement, live storage, prefix size and error propagation must be bounded; snapshots are not charged as productive original jobs.',
            'Chronological product, paid and target completion, strict child/target separation, and finite compiler hypotheses apply to the new literal supplier.',
            'Compiler logarithm power must be retuned: inherited power1000 fails at the displayed stronger savings; power1200 passes the stated exact arithmetic checks.',
            'Readmission above0.0034 must explicitly use the existing ordinary_BIT_saving0.0034363538396 with strict slack; no higher BIT budget is assumed.',
            'All nine outer rows,54 strict predicates,4 functional guards and inherited analytic/prime/exact-recovery premises remain applicable.',
            'Independent changed-construction review and source-bound incorporation are required before selected-frontier adoption.',
        ],
        'scope': 'Exact conditional p16 invoice, interval brackets, tail/compiler arithmetic, outer parameters, and static snapshot ancestry. No native center replacement, complete new supplier, independent endpoint replay, or kappa increase is claimed.',
        'elapsed_seconds': time.monotonic()-started,
    }
    path = HERE/'CONDITIONAL-CENTER-REPLACEMENT-PRICE.json'
    path.write_text(json.dumps(encode(out),indent=2)+'\n')
    print(json.dumps(encode({'status': out['status'], 'raw_roots': [c['raw_crossing']['exact_bracket'] for c in cases],
                            'conditional_kappas': [e['conditional_kappa'] for e in examples],
                            'elapsed_seconds': out['elapsed_seconds']}), indent=2))


if __name__ == '__main__':
    main()
