#!/usr/bin/env python3
"""Bounded mixed-integer search for a cheaper independent output row basis.

Query-union implications are literal SSA requirements.  Missing matroid rank
constraints are separated by exact modular-span cuts, each valid over Q.
Any positive candidate is validated with exact query mass and rational
independence. Solver infeasibility is recorded as computational evidence,
not promoted to a universal circuit obstruction.
"""
from collections import Counter, defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from math import gcd
from pathlib import Path
import gzip
import json
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from review_owned_zero_closure import replay
from subset_y_portfolio import ModBasis, PRIME


def normalize(row):
    common = 0
    for value in row:
        common = gcd(common, value)
    if not common:
        return None
    first = next(value for value in row if value)
    common *= 1 if first > 0 else -1
    return tuple(value // common for value in row)


def main():
    import numpy as np
    from scipy.optimize import milp, Bounds, LinearConstraint
    from scipy.sparse import csr_matrix

    started = time.monotonic()
    source = ROOT / 'research/retained_state_next/F9-SOURCE-DAG-ALL8-WORD.json.gz'
    raw = source.read_bytes()
    blob = json.loads(gzip.decompress(raw))
    _, nodes, state = replay(blob, range(224, 632))
    R = [[int(Q(x)) for x in row] for row in json.loads((ROOT / 'research/tensor_obstruction/inputs/R.json').read_text())]
    subset = [i for i in range(112) if sum(int(bool(R[k][i])) << k for k in range(8)) == 60]
    assert len(subset) == 8
    matrix = [[4 * int(i == j) - sum(row[i] * row[j] for row in R) for j in subset] for i in range(112)]
    mask = sum(1 << i for i in subset)
    query_rank = []
    query_node = []
    query_event = []
    query_sets = [0] * len(nodes)
    for node, metadata in enumerate(nodes):
        if not metadata['support'] & mask:
            continue
        value = 0
        for predecessor in metadata['deps']:
            value |= query_sets[predecessor]
        event = metadata['event']
        if event and event[0] == 'climb':
            value |= 1 << len(query_rank)
            query_rank.append(event[-1])
            query_node.append(node)
            query_event.append(metadata['index'])
        query_sets[node] = value
    endpoints = [{'output': i, 'row': matrix[i], 'direction': normalize(matrix[i]),
                  'queries': query_sets[state[i]]} for i in range(112) if any(matrix[i])]
    # Proportional rows with a larger literal required-query set are dominated.
    kept = []
    for i, endpoint in enumerate(endpoints):
        dominated = False
        for j, other in enumerate(endpoints):
            if i == j or endpoint['direction'] != other['direction']:
                continue
            if other['queries'] & ~endpoint['queries'] == 0:
                if other['queries'] != endpoint['queries'] or other['output'] < endpoint['output']:
                    dominated = True
                    break
        if not dominated:
            kept.append(endpoint)
    active = 0
    for endpoint in kept:
        active |= endpoint['queries']
    active_ids = [qid for qid in range(len(query_rank)) if active >> qid & 1]
    qvar = {qid: len(kept) + i for i, qid in enumerate(active_ids)}
    variables = len(kept) + len(active_ids)
    objective = np.zeros(variables)
    for qid, var in qvar.items():
        objective[var] = query_rank[qid]
    integrality = np.ones(variables, dtype=np.int32)
    constraints = []
    # Exactly8 independent rows suffice.  The rank cuts below reject all
    # dependent8-row choices without fixing any particular decoder basis.
    constraints.append(({i: 1 for i in range(len(kept))}, 8, 8))
    for i, endpoint in enumerate(kept):
        for qid in active_ids:
            if endpoint['queries'] >> qid & 1:
                constraints.append(({i: 1, qvar[qid]: -1}, -np.inf, 0))
    # Rank9 targets with child ranks<=5 cannot gain at c>0 without strictly
    # positive first-mass excess.  A profitable8-input portfolio needs <=71.
    constraints.append(({qvar[qid]: query_rank[qid] for qid in active_ids}, -np.inf, 71))
    iterations = []
    candidates = []
    terminal = None
    seen_cuts = set()
    print('BASIS_MODEL', subset, 'candidate_rows', len(kept), 'directions',
          len(set(endpoint['direction'] for endpoint in kept)), 'query_vars', len(active_ids), flush=True)
    for step in range(40):
        ir, ic, values, lower, upper = [], [], [], [], []
        for row, (coefficients, lo, hi) in enumerate(constraints):
            for column, value in coefficients.items():
                ir.append(row); ic.append(column); values.append(value)
            lower.append(lo); upper.append(hi)
        sparse = csr_matrix((np.asarray(values, dtype=float), (ir, ic)), shape=(len(constraints), variables))
        result = milp(objective, integrality=integrality, bounds=Bounds(0, 1),
                      constraints=LinearConstraint(sparse, lower, upper),
                      options={'time_limit': 5.0, 'mip_rel_gap': 0.0})
        record = {'iteration': step, 'solver_status': int(result.status), 'message': str(result.message),
                  'objective': float(result.fun) if result.fun is not None else None,
                  'mip_dual_bound': float(result.mip_dual_bound) if getattr(result, 'mip_dual_bound', None) is not None else None}
        if result.x is None:
            terminal = 'solver_infeasible' if result.status == 2 else 'solver_limit_without_candidate'
            iterations.append(record)
            break
        x = np.rint(result.x).astype(int)
        assert np.max(np.abs(result.x - x)) < 1e-5
        chosen = [i for i in range(len(kept)) if x[i]]
        assert len(chosen) == 8
        needed = 0
        for i in chosen:
            needed |= kept[i]['queries']
        profile = Counter(query_rank[qid] for qid in active_ids if needed >> qid & 1)
        mass = sum(rank * count for rank, count in profile.items())
        assert mass <= 71
        basis = ModBasis()
        for i in chosen:
            reduced = basis.reduce(kept[i]['row'])
            if any(reduced):
                basis.insert(reduced)
        rank = len(basis.rows)
        record.update({'selected_X_rows': [kept[i]['output'] for i in chosen],
                       'exact_query_profile': dict(sorted(profile.items())),
                       'exact_query_first_mass': mass, 'exact_rank_mod_prime': rank})
        iterations.append(record)
        print('BASIS_ITER', step, 'mass', mass, 'rank', rank, 'status', result.status, flush=True)
        if rank == 8:
            candidates.append(record | {'query_ids': [qid for qid in active_ids if needed >> qid & 1]})
            terminal = 'positive_first_mass_candidate'
            break
        outside = tuple(i for i, endpoint in enumerate(kept) if any(basis.reduce(endpoint['row'])))
        # Modular flat exclusion is only valid over Q if its inside rows
        # belong to the rational span. Check that containment exactly below.
        exact = []
        pivots = []
        for i in chosen:
            row = list(map(Q, kept[i]['row']))
            for pivot, echelon in zip(pivots, exact):
                a = row[pivot]
                if a:
                    row = [x - a * y for x, y in zip(row, echelon)]
            if any(row):
                pivot = next(j for j, value in enumerate(row) if value)
                a = row[pivot]
                exact.append([x / a for x in row]); pivots.append(pivot)
        assert len(exact) == rank
        exact_outside = []
        for i, endpoint in enumerate(kept):
            row = list(map(Q, endpoint['row']))
            for pivot, echelon in zip(pivots, exact):
                a = row[pivot]
                if a:
                    row = [x - a * y for x, y in zip(row, echelon)]
            if any(row):
                exact_outside.append(i)
        assert tuple(exact_outside) == outside
        cutkey = outside, 8 - rank
        assert cutkey not in seen_cuts
        seen_cuts.add(cutkey)
        constraints.append(({i: 1 for i in outside}, 8 - rank, np.inf))
        record['new_valid_rational_flat_cut'] = {'outside_candidate_indices': outside,
                                                'minimum_selected_outside': 8 - rank}
    if terminal is None:
        terminal = 'rank_cut_iteration_limit'
    receipt = {'schema': 'selected-Y-query-sharing-row-basis/v1', 'status': terminal,
               'source_word_sha256': sha256(raw).hexdigest(),
               'independent_Y_ports': subset, 'independent_inputs': 8,
               'all_other_native_ports': 'Owned zeros, including all408 helpers; no helper target credit.',
               'productive_targets': {9: 8}, 'first_mass_budget_for_possible_gain': 71,
               'first_mass_screen_proof': 'If paid first mass>=72 and every child rank<=5<9, then sum paid r^(1−c)>=9^(−c)*sum paid r>=8*9^(1−c). Thus no c>0 excess is possible without paid first mass<=71.',
               'all112_output_rows_considered': True,
               'candidate_rows_after_exact_proportional_query_domination': len(kept),
               'candidate_directions': len(set(endpoint['direction'] for endpoint in kept)),
               'active_query_variables': len(active_ids),
               'candidate_outputs': [{'output': e['output'], 'row': e['row'],
                                     'query_ids': [qid for qid in active_ids if e['queries'] >> qid & 1]}
                                    for e in kept],
               'query_bindings': [[qid, query_node[qid], query_event[qid], query_rank[qid]] for qid in active_ids],
               'iterations': iterations, 'positive_candidates': candidates,
               'solver_scope': 'HiGHS integer optimization is used for a bounded candidate search. Every candidate and generated rank cut is checked exactly. An infeasibility status is computational evidence for this fixed source/query-dependency family, not a standalone formal mixed-integer certificate or a general circuit lower bound.',
               'elapsed_seconds': time.monotonic() - started,
               'new_kappa_claimed': False}
    (HERE / 'SUBSET-Y-EXACT-BASIS.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('DONE', terminal, receipt['elapsed_seconds'], flush=True)


if __name__ == '__main__':
    main()
