#!/usr/bin/env python3
"""Exact phase-bearing physical bridges between two distinct companions.

Unlike the coordinate-permutation toy group, S and CZ phases can change
Gaussian-rank parity under composition.  We retain complete Clifford
tableaus and specialize tensor width to a multiple of four, so the exact
global i phases disappear without imposing an incorrect physical identity.
"""
from collections import Counter
from itertools import permutations, product
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import two_stage_companion as core


def load_ce():
    p=ROOT/'research/tensor_obstruction/inputs/clifford_exact.py'
    spec=importlib.util.spec_from_file_location('phase_bridge_ce',p)
    ce=importlib.util.module_from_spec(spec);sys.modules[spec.name]=ce
    spec.loader.exec_module(ce)
    return ce,p


def main():
    started=time.monotonic();ce,cepath=load_ce();n=3
    def grade(tab):return ce.rank([x for x,z,p in tab[n:]])
    def group_word(g):
        e,p=g
        op=ce.perm(n,tuple(1<<p.index(i) for i in range(n)))
        for i,a in enumerate(e):
            for _ in range(a):op=op.then(ce.cgate(n,1<<i))
        return op
    allg=[(e,p) for e in product(range(4),repeat=3) for p in permutations(range(3))]
    tabs={g:group_word(g).tab for g in allg}
    assert len(set(tabs.values()))==384
    assert all(grade(tabs[g])==sum(x%2 for x in g[0]) for g in allg)
    # Concrete control: S changes a two-C product's rank parity.
    Q=ce.cgate(3,1);S=ce.diag(3,(1,0,0),(1,0,0))
    assert grade(Q.then(Q).tab)==0
    assert grade(Q.then(S).then(Q).tab)==1
    src=[core.stage(s) for s in (1,2)]
    ns=[[[{tabs[g]:a for g,a in x.items()} for x in row] for row in m] for m in src]
    a1,a2=core.augmentation(src[0]),core.augmentation(src[1])
    invs=[core.minus([[2*x for x in row] for row in core.eye(8)],a) for a in (a1,a2)]
    eye=ce.ident(3).tab
    phases=[]
    for axis in range(3):
        for power in (1,3):
            q=tuple(1<<i if i==axis else 0 for i in range(3))
            alpha=tuple(power if i==axis else 0 for i in range(3))
            phases.append(({'kind':'S','axis':axis,'power':power},ce.diag(3,q,alpha).tab))
    for a,b in ((0,1),(0,2),(1,2)):
        q=[0]*3;q[a]=1<<b;q[b]=1<<a
        phases.append(({'kind':'CZ','axes':[a,b]},ce.diag(3,q,(0,0,0)).tab))
    patterns=[({'kind':'identity'},(eye,)*4)]
    for description,tab in phases:
        for bank in range(4):
            words=[eye]*4;words[bank]=tab
            patterns.append(({'placement':'single_bank','bank':bank,**description},tuple(words)))
        patterns.append(({'placement':'all_banks',**description},(tab,)*4))
    assert len(patterns)==46
    assert all(grade(tab)==0 for _,tabs0 in patterns for tab in tabs0)
    allbridges=[]
    for rp in permutations(range(4)):
        for tail in product((-1,1),repeat=3):
            signs=(1,)+tail;b=core.bridge(rp,signs);bi=[list(row) for row in zip(*b)]
            ai=core.mm(invs[0],bi,invs[1])
            edges=[(2*k+owner,2*rp[k]+owner,signs[k],k) for k in range(4) for owner in range(2)]
            allbridges.append((rp,signs,ai,edges))
    triples={};grade_cache={}
    def triple(a,p,b):
        key=(a,p,b)
        if key not in triples:
            out=ce.compose(a,ce.compose(p,b));triples[key]=out
            grade_cache[out]=grade(out)
        return triples[key]
    def compose(edges,phases0):
        out=[[{} for _ in range(8)] for _ in range(8)]
        for i,j in product(range(8),repeat=2):
            dest=out[i][j]
            for k,l,sign,bank in edges:
                for a,va in ns[1][i][k].items():
                    for b,vb in ns[0][l][j].items():
                        key=triple(a,phases0[bank],b)
                        dest[key]=dest.get(key,0)+sign*va*vb
            out[i][j]={g:a for g,a in dest.items() if a}
        return out
    screened=0;aug_survivors=[];profile_survivors=[];census=Counter();patterns_report=[]
    for pattern,phasewords in patterns:
        local=0
        for rp,signs,ai,edges in allbridges:
            mat=compose(edges,phasewords);screened+=1
            pieces=[[[0]*8 for _ in range(8)] for _ in range(4)]
            fullgrades=Counter()
            for i,j in product(range(8),repeat=2):
                for g,a in mat[i][j].items():
                    r=grade_cache[g];pieces[r][i][j]+=a;fullgrades[r]+=1
            normalized=[core.mm(piece,ai) for piece in pieces]
            # Fast reject at the first failed idempotence relation.
            first_failure=next((r for r,a in enumerate(normalized) if core.mm(a,a)!=a),None)
            if first_failure is not None:
                census[f'fails_idempotence_grade{first_failure}']+=1
                continue
            assert all(core.zero(core.mm(normalized[r],normalized[s])) for r in range(4) for s in range(4) if r!=s)
            multiplicities=[core.rank(x) for x in normalized]
            local+=1
            forbidden={r for r,count in enumerate(multiplicities) if not count}
            witnesses=[]
            for i,j in product(range(8),repeat=2):
                for g,a in mat[i][j].items():
                    if grade_cache[g] in forbidden and len(witnesses)<2:
                        witnesses.append({'row':i,'column':j,'coefficient':a,'grade':grade_cache[g],
                                          'tableau':[list(v) for v in g]})
            rec={'phase_pattern':pattern,'role_permutation':rp,'signs':signs,
                 'necessary_target_rank_multiplicities':multiplicities,
                 'target_first_mass':sum(r*k for r,k in enumerate(multiplicities)),
                 'baseline_first_mass':16,
                 'nonzero_group_term_grades':dict(sorted(fullgrades.items())),
                 'absent_target_grade_witnesses':witnesses}
            aug_survivors.append(rec)
            if not witnesses:profile_survivors.append(rec)
        patterns_report.append({'pattern':pattern,'augmented_survivors':local})
        if len(patterns_report)%10==0:
            print('PHASE_BRIDGES',len(patterns_report),'of',len(patterns),'cases',screened,
                  'augmented',len(aug_survivors),'full_profile',len(profile_survivors),flush=True)
    result={
        'schema':'two-stage-phase-bridge-boundary-screen/v1',
        'status':'PASS_EXACT_PHASE_BRIDGE_SCREEN; NO_SUPPLIER_ADMITTED',
        'source_pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                       for p in (cepath,HERE/'two_stage_companion.py')},
        'toy':'Same two active owner coordinates and exact physical companion as TWO-STAGE-COMPANION.json; shared Q with two distinct fresh D axes.',
        'ordinary_boundary_span':'Arbitrary invertible owner matrices over finite sums of whole-width lifts of one-column monomial Cliffords, including diagonal S/CZ and general binary-linear permutations.',
        'width_specialization':'Widths divisible by4 remove every global i phase of the Q(i) Clifford circuits. Projectively distinct group elements have independent tensor powers for all sufficiently large such widths.',
        'grade_argument':'Grade projection commutes with ordinary left/right multiplication. Group augmentation then requires normalized grade components to be mutually orthogonal idempotents. Any nonzero coefficient in a grade absent from the necessary target profile is a second exact rejection.',
        'phase_patterns':len(patterns),'signed_role_bridges_per_pattern':len(allbridges),
        'physical_networks_screened':screened,'S_phase_rank_parity_control':{'C_C_rank':0,'C_S_C_rank':1},
        'phase_pattern_summary':patterns_report,'rejection_census':dict(census),
        'augmentation_survivor_count':len(aug_survivors),'full_profile_survivor_count':len(profile_survivors),
        'augmentation_survivors':aug_survivors,'full_profile_survivors':profile_survivors,
        'all_width_claim':'Only exclusion of the enumerated toy networks within the stated ordinary boundary span. A survivor would still require an explicit invertible boundary construction.',
        'scope_exclusions':['Actual112-port-specific identities','Additional intermediate scalar/owner shears','Multiple distinct phase insertions','More than two stages','Non-Clifford or cross-column monomial maps','Source-interior caches/projections'],
        'kappa_improvement_claimed':False,'elapsed_seconds':time.monotonic()-started,
    }
    (HERE/'TWO-STAGE-PHASE-BRIDGES.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('augmentation_survivors','phase_pattern_summary')},indent=2),flush=True)


if __name__=='__main__':main()
