# Primary literature checked for this construction search

Checked during the 2026-10-23 research turn. These sources motivated specific
probes or clarified a model boundary. None is treated as an admitted supplier
without the source-bound implementation and invoice.

| Primary source | Use and limitation |
|---|---|
| [Alman and Rao, arXiv:2211.06459](https://arxiv.org/abs/2211.06459) | Low-rank-plus-sparse Walsh/DFT constructions motivated ordinary-side corrections. The published gains used here are leading-constant improvements, not a fixed-power supplier gain. |
| [Alman, arXiv:2211.04643](https://arxiv.org/abs/2211.04643) | Kronecker-power transforms over fixed finite fields motivate whole-width bit complexity. The finite-field bit model and logarithmic-factor improvement cannot simply be substituted into the current exact-complex supplier. |
| [Alman, Guan, and Padaki, arXiv:2211.05217](https://arxiv.org/pdf/2211.05217) | Sparse low-depth factorizations of Kronecker powers. Circuit wire counts require a separate conversion to the physical ordinary-tape bill. |
| [Maslov and Roetteler, arXiv:1705.09176](https://arxiv.org/abs/1705.09176) | Clifford normal forms and Hadamard optimization informed exact chart pricing. The local implementation separately verifies every lowering by tableau and absolute phase. |
| [Bravyi and Maslov, arXiv:2003.09412](https://arxiv.org/abs/2003.09412) | Hadamard-free Clifford decomposition helps separate ordinary wrappers from genuine query rank. It does not grant a free arbitrary basis change. |
| [Montealegre-Mora and Gross, arXiv:2208.01688](https://arxiv.org/abs/2208.01688) | Tensor-power Clifford dualities motivated sector and paired-copy investigations. No unpriced representation transform was imported. |
| [Appleby and coauthors, arXiv:1102.1268](https://arxiv.org/abs/1102.1268) | Monomial Clifford representations in square dimension suggested a paired-copy route. Its cyclic-qudit setting is not by itself a proof for the present many-qubit family; the actual Bell construction is checked independently. |
| [Leopardi, arXiv:1504.02827v5](https://arxiv.org/html/1504.02827v5) | Monomial real Clifford representations and bent functions motivated nonlinear Majorana conjugations. Their finite tests did not improve worst-case tensor support. |
| [Morier-Genoud and Ovsienko, arXiv:1304.0949v3](https://arxiv.org/html/1304.0949v3) | Cubic forms and Hurwitz–Radon constructions motivated an explicitly bounded cubic probe. No all-width physical admission followed. |

Short source quotations used in the earlier sweep:

* Alman–Rao: “we decompose the WHT matrix as the sum of a low-rank matrix and a sparse matrix”
* Alman: “This generalizes to any transform defined as a Kronecker power of a fixed matrix.”
* Maslov–Roetteler: “a circuit in this normal form is optimal in the number of Hadamard gates used”
* Montealegre-Mora–Gross: “a unified framework for the duality approach that also covers qubit systems”
* Appleby et al.: “can be represented by monomial phase-permutation matrices if and only if the dimension is a square number.”

Each quotation is shorter than 25 words. They are motivation and model
context; the operative claims in this directory have exact local receipts.

## Current public Fourier repositories checked

The official primary README
[Finite tensor savings and exact Fourier circuits](https://github.com/openai/math/blob/main/preprints/Finite-tensor-savings-and-exact-Fourier-circuits-September-25-2026/README.md)
and its sibling exact-DFT preprint describe the framework already underlying
the frozen repository. They were not counted as new improvements.

The live primary repository
[shea256/fourier-transform-below-nlogn](https://github.com/shea256/fourier-transform-below-nlogn)
was also checked. Its selected PR588 entry is recorded on October 12, and
its named round6/10/11 complex witnesses are preserved older work. Despite
their round numbers, they do not supply a newer native profile than the
source currently selected here. No deep reintegration was attempted on that
basis. The complex-arithmetic circuit model also needs an explicit separate
integer-multiplication transfer.

## Scope of the literature conclusions

No literature gap is claimed. The searches identified mechanisms worth
testing, followed by exact source-bound probes. The useful new implementation
in this directory is the shared-output average provider; the scalar decoder
search and nonlinear Majorana tests remain finite exploratory results.
