#!/usr/bin/env python3
"""Exact edge-family charts for the actual center5 shared-input scatter.

The charts are constructive identities, not a claim of a cheap returned
scatter.  All output-chart restoration is displayed in the invoice.
"""
from collections import Counter
from hashlib import sha256
from itertools import combinations
from fractions import Fraction
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'research/tensor_obstruction/inputs'))
import clifford_exact as ce


def grade(op):
    return ce.rank([x for x, z, p in op.tab[op.n:]])


def main():
    source = ROOT / 'research/retained_state_next/CENTER5-SUFFIX.json'
    receipt = json.loads(source.read_text())
    ports = receipt['actual_Y_repair']['active_ports']
    assert len(ports) == 56
    source_R_file = ROOT / 'research/tensor_obstruction/inputs/R.json'
    source_R = [[Fraction(x) for x in row]
                for row in json.loads(source_R_file.read_text())]
    assert receipt['R_row'] == 5
    assert [i for i, x in enumerate(source_R[5]) if x] == [p['port'] for p in ports]
    assert all(Fraction(p['R5']) == source_R[5][p['port']] for p in ports)
    fs = [1 << j for j in range(7)] + [127]
    edge_map = {fs[a] ^ fs[b]: [a, b] for a, b in combinations(range(8), 2)}
    assert len(edge_map) == 28
    assert {q['q'] for q in ports} == {h ^ v for h in (128, 256) for v in edge_map}
    assert ce.rank(list(edge_map)) == 6

    cases = []
    for differences in (6, 7):
        # G maps new coordinates to the original physical coordinates.
        cols = ([65, 66, 68, 72, 80, 96, 64, 128, 256]
                if differences == 6 else
                [65, 66, 68, 72, 80, 96, 384, 64, 128])
        G = ce.transpose(cols, 9)
        W = ce.perm(9, ce.inv(G, 9)).then(ce.hadamard(9, range(differences)))
        F9 = ce.fourier(9)
        shifted = F9.adjoint().then(W)
        heads, checks = set(), []
        for port in ports:
            q = port['q']
            x, z, p = ce.apply(W.tab, (q, 0, 0))
            assert p == 0 and x.bit_count() == 1 and not (x & z)
            heads.add(x)
            target = W.adjoint().then(ce.cgate(9, q, -1)).then(W)
            # Root(X_x Z_z)^-1 = M_z Root(X_x)^-1.
            M = ce.cgate(9, x).then(target)
            mon, emitted = ce.monomial(M)
            compiled = ce.cgate(9, x, -1).then(mon)
            assert compiled.tab == target.tab
            assert compiled.zero_state() == target.zero_state()
            # No global phase is hidden in the conditional monomial.
            assert emitted['phase'] == 0
            for address in range(512):
                parity = ce.parity(z & address)
                assert ce.mv(emitted['matrix_rows'], address) ^ emitted['offset'] == address ^ (x if parity else 0)
                assert ce.qvalue(emitted['quadratic_rows'], emitted['linear_Z4'], address, 9) == (-parity) % 4
            # The shifted chart is also valid because F9 commutes with Q_q.
            target2 = shifted.adjoint().then(ce.cgate(9, q, -1)).then(shifted)
            assert target2.tab == target.tab
            assert target2.zero_state() == target.zero_state()
            checks.append({'port': port['port'], 'q': q,
                           'edge': edge_map[q & 127], 'high_bit': q & 384,
                           'common_head': x, 'spectator_parity_mask': z,
                           'monomial_word': mon.circuit, 'monomial': emitted})
        assert len(heads) == (2 if differences == 6 else 1)
        cases.append({'difference_dimension': differences,
                      'G_columns': cols, 'G_rows': G,
                      'chart_W_circuit': W.circuit,
                      'chart_W_tableau': W.tab,
                      'chart_W_grade': grade(W),
                      'logical_chart_from_final_tF_WF9_grade': grade(F9.then(W)),
                      'commutant_shifted_chart_WF9inverse_circuit': shifted.circuit,
                      'commutant_shifted_chart_grade': grade(shifted),
                      'shifted_chart_logical_from_final_tF_grade': grade(F9.then(shifted)),
                      'common_heads': sorted(heads),
                      'fresh_standard_chart_cost': {
                          'entry_rank': grade(W), 'common_rank1_queries': len(heads),
                          'exit_rank_per_target': grade(W), 'targets': 56,
                          'rank_mass_upper_bound': grade(W) * 57 + len(heads)},
                      'actual_ports': checks})

    result = {
        'status': 'PASS_EXACT_ACTUAL_CENTER5_SCATTER_CHARTS',
        'source_sha256': sha256(source.read_bytes()).hexdigest(),
        'independent_source_R_sha256': sha256(source_R_file.read_bytes()).hexdigest(),
        'source_R5_support_and_all_signs_verified': True,
        'source_pins': receipt['source_pins'],
        'input': 't_F=F9 tensor-power(m) times(R5 X), arbitrary whole array',
        'required_outputs': '(R5_i/4) post_i Q_qi^(-tensor m) t_F, all56actualYsuffixes',
        'edge_generators_f': fs,
        'edge_count': 28, 'low_difference_rank': 6,
        'all_difference_rank': ce.rank([p['q'] ^ ports[0]['q'] for p in ports]),
        'identity': 'W Q_q^-1 W^-1 = M_z Q_x^-1; M_z|a>=(-i)^parity(z&a)|a xor x*parity(z&a)>',
        'all_width_rule': 'Tensor W and each M over allmcolumns; evaluate control parity separately ineachcolumn; phases multiply, so total is(-i)^popcount(controlword). ScalarR5_i/4 is appliedonce outside tensorpower.',
        'absolute_phase_validation': 'Every56port checked by tableau, exact zero-state, andall512 conditional-monomial addresses forbothcharts.',
        'cases': cases,
        'scope': 'Exact correlated-input factorization. Returning each independent Y output toits required physical chart ischarged; fresh charts do not beat the deletedrank8call. Retained caller charts or a shared inverse remainopen. No kappa increaseclaimed.'}
    out = HERE / 'SHARED-SCATTER-CHARTS.json'
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('source_pins', 'cases')}, indent=2))
    print(json.dumps([{k: v for k, v in case.items() if k not in ('actual_ports', 'chart_W_circuit', 'chart_W_tableau', 'commutant_shifted_chart_WF9inverse_circuit')} for case in cases], indent=2))


if __name__ == '__main__':
    main()
