#!/usr/bin/env python3
"""Exhaust all rational strengths of one intermediate scalar bank shear.

The bridge is (I + lambda E_ab) P, with a != b, and P a signed four-bank
permutation acting identically on the two active owners.  Grade defects are
univariate polynomials, so exact polynomial gcd replaces a coefficient grid.
"""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from itertools import permutations, product
from math import gcd as integer_gcd, isqrt, lcm
from pathlib import Path
import json
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import two_stage_companion as core


def trim(p):
    p = list(p)
    while p and p[-1] == 0:
        p.pop()
    return tuple(p)


def monic(p):
    p = trim(p)
    return tuple(Q(x, p[-1]) for x in p) if p else ()


def remainder(a, b):
    a = list(map(Q, trim(a)))
    b = tuple(map(Q, trim(b)))
    assert b
    while len(a) >= len(b):
        offset = len(a) - len(b)
        scale = a[-1] / b[-1]
        for j, value in enumerate(b):
            a[offset + j] -= scale * value
        a = list(trim(a))
    return tuple(a)


def gcd(a, b):
    a, b = trim(a), trim(b)
    while b:
        a, b = b, remainder(a, b)
    return monic(a)


def madd(a, b):
    return [[x + y for x, y in zip(arow, brow)] for arow, brow in zip(a, b)]


def mscale(a, scalar):
    return [[scalar * x for x in row] for row in a]


def peval(p, value):
    out = Q(0)
    for coefficient in reversed(p):
        out = out * value + coefficient
    return out


def matrix_eval(coefficients, value):
    out = [[Q(0)] * 8 for _ in range(8)]
    for coefficient in reversed(coefficients):
        out = madd(mscale(out, value), coefficient)
    return out


def defect_entry(q, i, j):
    values = [0] * 5
    for degree in range(5):
        for left in range(3):
            right = degree - left
            if not 0 <= right < 3:
                continue
            values[degree] += sum(q[left][i][k] * q[right][k][j] for k in range(8))
        if degree < 3:
            values[degree] -= q[degree][i][j]
    return trim(values)


def rational_roots(poly):
    def integer_primitive(p):
        denominator = lcm(*(Q(x).denominator for x in p))
        integers = [int(x * denominator) for x in p]
        common = 0
        for value in integers:
            common = integer_gcd(common, value)
        return tuple(x // common for x in integers)

    def divisors(n):
        assert n > 0
        output = []
        for divisor in range(1, isqrt(n) + 1):
            if n % divisor == 0:
                output.append(divisor)
                if divisor * divisor != n:
                    output.append(n // divisor)
        return output

    def divide_root(p, root):
        quotient = [Q(0)] * (len(p) - 1)
        carry = p[-1]
        quotient[-1] = carry
        for i in range(len(p) - 2, 0, -1):
            carry = p[i] + root * carry
            quotient[i - 1] = carry
        assert p[0] + root * carry == 0
        return trim(quotient)

    remaining = tuple(map(Q, poly))
    roots = []
    factors = []
    while len(remaining) > 1:
        degree = len(remaining) - 1
        if remaining[0] == 0:
            root = Q(0)
        elif degree == 1:
            root = -remaining[0] / remaining[1]
        elif degree == 2:
            c, b, a = integer_primitive(remaining)
            discriminant = b * b - 4 * a * c
            if discriminant < 0 or isqrt(discriminant)**2 != discriminant:
                break
            root = Q(-b + isqrt(discriminant), 2 * a)
        else:
            integers = integer_primitive(remaining)
            root = None
            # Reduced rational roots p/q divide the primitive constant and
            # leading coefficients. This finite test is exact, not a grid.
            for numerator in divisors(abs(integers[0])):
                for denominator in divisors(abs(integers[-1])):
                    if integer_gcd(numerator, denominator) != 1:
                        continue
                    for sign in (-1, 1):
                        candidate = Q(sign * numerator, denominator)
                        if peval(remaining, candidate) == 0:
                            root = candidate
                            break
                    if root is not None:
                        break
                if root is not None:
                    break
            if root is None:
                break
        multiplicity = 0
        while len(remaining) > 1 and peval(remaining, root) == 0:
            remaining = divide_root(remaining, root)
            multiplicity += 1
        roots.append(root)
        factors.append({'rational_root': str(root), 'multiplicity': multiplicity})
    assert all(peval(poly, value) == 0 for value in roots)
    return sorted(roots), {'rational_linear_factors': factors,
                           'remaining_polynomial_ascending': list(map(str, remaining)),
                           'remaining_polynomial_has_no_rational_root': True,
                           'method': 'Exact linear/quadratic formulas, then rational-root theorem for degree3/4.'}


def group_linear(a, b, scalar):
    return [[core.ga(left, core.gs(right, scalar)) for left, right in zip(arow, brow)]
            for arow, brow in zip(a, b)]


def full_profile_check(matrix, normalized):
    assert all(core.mm(component, component) == component for component in normalized)
    assert all(core.zero(core.mm(normalized[r], normalized[s]))
               for r in range(4) for s in range(4) if r != s)
    ranks = [core.rank(component) for component in normalized]
    assert sum(ranks) == 8
    grades = Counter()
    absent = []
    for i, j in product(range(8), repeat=2):
        for word, coefficient in matrix[i][j].items():
            grade = sum(value % 2 for value in word[0])
            grades[grade] += 1
            if not ranks[grade] and len(absent) < 4:
                absent.append({'output': i, 'input': j, 'grade': grade,
                               'word': word, 'coefficient': str(coefficient)})
    return {'target_rank_multiplicities': ranks,
            'target_first_mass': sum(r * k for r, k in enumerate(ranks)),
            'two_stage_paid_geometry_first_mass': 16,
            'nonzero_coefficient_grade_census': dict(sorted(grades.items())),
            'absent_target_grade_witnesses': absent,
            'full_profile_survives': not absent}


def main():
    started = time.monotonic()
    n1, n2 = core.stage(1), core.stage(2)
    a1, a2 = core.augmentation(n1), core.augmentation(n2)
    inv1, inv2 = [core.minus([[2 * x for x in row] for row in core.eye(8)], a) for a in (a1, a2)]
    records = []
    candidates = []
    all_parameter_cases = []
    gcd_census = Counter()
    degree_census = Counter()
    checked_evaluations = 0

    # Identity bridge is deliberately first, so the requested initial12
    # ordered bank pairs are handled before the full signed family.
    patterns = [((0, 1, 2, 3), (1, 1, 1, 1))]
    patterns += [(rp, (1,) + tail) for rp in permutations(range(4))
                 for tail in product((-1, 1), repeat=3)
                 if (rp, (1,) + tail) != patterns[0]]
    assert len(patterns) == 192

    for pattern_index, (roleperm, signs) in enumerate(patterns):
        b0 = core.bridge(roleperm, signs)
        b0inv = [list(row) for row in zip(*b0)]
        n0 = core.compose(n2, b0, n1)
        grades0 = core.grade_components(n0)
        inverse0 = core.mm(inv1, b0inv, inv2)
        aug0 = core.augmentation(n0)
        assert core.mm(aug0, inverse0) == core.eye(8)
        for a, b in permutations(range(4), 2):
            elementary = [[0] * 8 for _ in range(8)]
            for owner in range(2):
                elementary[2 * a + owner][2 * b + owner] = 1
            inverse1 = mscale(core.mm(inv1, b0inv, elementary, inv2), -1)
            nlinear = [[{} for _ in range(8)] for _ in range(8)]
            for i, j in product(range(8), repeat=2):
                nlinear[i][j] = core.ga(*(core.gs(core.gp(n2[i][2 * a + owner],
                                               n1[2 * roleperm[b] + owner][j]), signs[b])
                                         for owner in range(2)))
            grades1 = core.grade_components(nlinear)
            aug1 = core.augmentation(nlinear)
            assert core.zero(core.mm(aug1, inverse1))
            assert core.zero(madd(core.mm(aug0, inverse1), core.mm(aug1, inverse0)))
            normalized = [[core.mm(grades0[r], inverse0),
                           madd(core.mm(grades0[r], inverse1), core.mm(grades1[r], inverse0)),
                           core.mm(grades1[r], inverse1)] for r in range(4)]

            if pattern_index == 0:
                for strength in (Q(-1), Q(0), Q(1), Q(2)):
                    direct = group_linear(n0, nlinear, strength)
                    actual_components = core.grade_components(direct)
                    actual_inverse = madd(inverse0, mscale(inverse1, strength))
                    assert core.mm(core.augmentation(direct), actual_inverse) == core.eye(8)
                    for r in range(4):
                        actual = core.mm(actual_components[r], actual_inverse)
                        assert actual == matrix_eval(normalized[r], strength)
                        actual_defect = core.minus(core.mm(actual, actual), actual)
                        for i, j in product(range(8), repeat=2):
                            assert actual_defect[i][j] == peval(defect_entry(normalized[r], i, j), strength)
                    checked_evaluations += 1

            common = ()
            witnesses = []
            entries_examined = 0
            rejected = False
            for r, i, j in product(range(4), range(8), range(8)):
                polynomial = defect_entry(normalized[r], i, j)
                entries_examined += 1
                if not polynomial:
                    continue
                degree_census[len(polynomial) - 1] += 1
                next_common = gcd(common, polynomial)
                if next_common != common:
                    witnesses.append({'grade': r, 'output': i, 'input': j,
                                      'defect_coefficients_ascending': list(map(str, polynomial)),
                                      'running_monic_gcd': list(map(str, next_common))})
                common = next_common
                if len(common) == 1:
                    rejected = True
                    break

            record = {'role_permutation': roleperm, 'role_signs': signs,
                      'shear_target_bank': a, 'shear_source_bank': b,
                      'defect_entries_examined': entries_examined,
                      'monic_defect_gcd_ascending': list(map(str, common)),
                      'gcd_change_witnesses': witnesses}
            if rejected:
                gcd_census['constant_no_complex_root'] += 1
                record['rational_candidates'] = []
            elif common:
                roots, factors = rational_roots(common)
                gcd_census[f'degree{len(common)-1}'] += 1
                record['gcd_factorization'] = factors
                record['rational_candidates'] = list(map(str, roots))
                for strength in roots:
                    q_at_strength = [matrix_eval(q, strength) for q in normalized]
                    # Exact complete replay at every rational gcd root.
                    matrix = group_linear(n0, nlinear, strength)
                    profile = full_profile_check(matrix, q_at_strength)
                    candidates.append({key: record[key] for key in ('role_permutation', 'role_signs',
                                           'shear_target_bank', 'shear_source_bank')} |
                                      {'lambda': str(strength), **profile})
            else:
                gcd_census['identically_zero_all_rational_parameters'] += 1
                ranks = [core.rank(q[0]) for q in normalized]
                # Polynomial idempotents have constant integral trace/rank.
                assert all(sum(q[degree][i][i] for i in range(8)) == 0
                           for q in normalized for degree in (1, 2))
                missing_gcd = ()
                missing_witnesses = []
                for i, j in product(range(8), repeat=2):
                    for word in set(n0[i][j]) | set(nlinear[i][j]):
                        grade = sum(x % 2 for x in word[0])
                        if not ranks[grade]:
                            polynomial = trim((n0[i][j].get(word, 0), nlinear[i][j].get(word, 0)))
                            if polynomial:
                                next_missing = gcd(missing_gcd, polynomial)
                                if next_missing != missing_gcd:
                                    missing_witnesses.append({'output': i, 'input': j, 'grade': grade,
                                                             'group_word': word,
                                                             'coefficient_polynomial_ascending': list(map(str, polynomial)),
                                                             'running_monic_gcd': list(map(str, next_missing))})
                                missing_gcd = next_missing
                assert missing_gcd, 'Unrestricted full-profile family requires further construction.'
                record['constant_necessary_target_rank_multiplicities'] = ranks
                record['absent_grade_coefficient_gcd'] = list(map(str, missing_gcd))
                record['absent_grade_gcd_change_witnesses'] = missing_witnesses
                roots, factors = rational_roots(missing_gcd) if len(missing_gcd) > 1 else ([], [])
                record['rational_candidates_after_full_profile'] = list(map(str, roots))
                all_parameter_cases.append(record.copy())
                for strength in roots:
                    profile = full_profile_check(group_linear(n0, nlinear, strength),
                                                 [matrix_eval(q, strength) for q in normalized])
                    candidates.append({key: record[key] for key in ('role_permutation', 'role_signs',
                                           'shear_target_bank', 'shear_source_bank')} |
                                      {'lambda': str(strength), **profile})
            records.append(record)
        if pattern_index == 0 or (pattern_index + 1) % 24 == 0:
            print('SHEAR', pattern_index + 1, 'patterns', len(records), 'families',
                  len(candidates), 'rational candidates',
                  sum(x['full_profile_survives'] for x in candidates), 'full survivors', flush=True)

    survivors = [candidate for candidate in candidates if candidate['full_profile_survives']]
    receipt = {
        'schema': 'two-stage-all-rational-single-scalar-shear/v1',
        'status': 'EXACT_BOUNDED_PARAMETER_FAMILY_SCREEN; NO_SUPPLIER_ADMITTED',
        'source_pin': sha256((HERE / 'two_stage_companion.py').read_bytes()).hexdigest(),
        'network': 'N2 * (I + lambda E_ab tensor I_owner) * P_role_signed * N1',
        'role_order': ['X_forward', 'Y_forward', 'X_backward', 'Y_backward'],
        'ordered_distinct_bank_pairs': 12, 'signed_role_permutations': 192,
        'one_parameter_families': len(records),
        'parameter_domain': 'Every rational lambda, including zero. All scalar coefficients apply once to owners, not per tensor digit.',
        'opposite_order_covered': 'P(I+lambda E_ab)=(I+lambda P E_ab P^-1)P; signed permutation conjugation permutes the ordered bank pair and optionally changes lambda sign.',
        'polynomial_method': 'N(lambda) and its augmented inverse are affine; normalized grade matrices have degree <=2; idempotence entries have degree <=4. A common exact rational polynomial gcd captures every simultaneous root. Constant gcd gives exclusion even for complex lambda. Every rational root is replayed against all grade relations and full group coefficients.',
        'polynomial_evaluation_controls': checked_evaluations,
        'defect_degree_census_for_entries_examined': dict(sorted(degree_census.items())),
        'gcd_census': dict(gcd_census),
        'isolated_rational_candidate_count': len(candidates),
        'nonzero_isolated_rational_candidate_count': sum(Q(x['lambda']) != 0 for x in candidates),
        'identically_idempotent_parameter_family_count': len(all_parameter_cases),
        'full_profile_survivor_count': len(survivors),
        'all_parameter_families': all_parameter_cases,
        'rational_candidates': candidates,
        'full_profile_survivors': survivors,
        'family_certificates': records,
        'scope': 'Exact two-active-owner toy, two distinct stages, one scalar bank shear and one signed role permutation between stages. Boundary grade argument allows arbitrary invertible owner matrices over finite sums of whole-width monomial Clifford lifts. This is not an actual112-port or general caller obstruction; source-interior caches, multiple shears and cross-column maps are outside scope.',
        'new_kappa_claimed': False,
        'elapsed_seconds': time.monotonic() - started
    }
    (HERE / 'TWO-STAGE-SCALAR-SHEAR.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in ('family_certificates', 'rational_candidates')}, indent=2), flush=True)


if __name__ == '__main__':
    main()
