#!/usr/bin/env python3
"""Exact source-normalizer sector census; no route/decoder admission claim."""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'constructive_observers'))
import cross_column_routes as cc


def main():
    ce, canonical, normals, R, routes = cc.source_data()
    permutations = []
    ops = []
    signed = []
    for route in routes:
        word = route['Kstar_word']
        op = ce.ident(9)
        for event in word:
            if event[0] == 'P':
                step = ce.perm(9, event[1])
            elif event[0] == 'D':
                step = ce.diag(9, event[1], event[2])
            elif event[0] == 'X':
                step = ce.xgate(9, event[1])
            elif event[0] == 'phase':
                step = ce.Op(9, ce.identity(9), [tuple(event)])
            else:
                raise AssertionError(event)
            op = op.then(step)
        ops.append(op)

        def apply(x):
            phase = 0
            for event in word:
                if event[0] == 'P':
                    x = ce.mv(event[1], x)
                elif event[0] == 'D':
                    phase += ce.qvalue(event[1], event[2], x, 9)
                elif event[0] == 'X':
                    x ^= event[1]
                elif event[0] == 'phase':
                    phase += event[1]
            return x, phase % 4

        original = [apply(x) for x in range(512)]
        assert all(p in (0, 2) for x, p in original)
        assert all(original[y] == (x, p) for x, (y, p) in enumerate(original))
        assert original[0] == (0, 0)
        columns = [original[1 << b][0] for b in range(9)]
        linear_phase = sum((original[1 << b][1] // 2) << b for b in range(9))
        rows = ce.transpose(columns, 9)
        assert all(original[x] == (ce.mv(rows, x), 2 * ce.parity(linear_phase & x))
                   for x in range(512))
        inverse_transpose = ce.transpose(ce.inv(rows, 9), 9)
        perm = [ce.mv(inverse_transpose, x ^ linear_phase) for x in range(512)]
        assert all(perm[perm[x]] == x for x in range(512))
        assert sum(x == y and p == 0 for x, (y, p) in enumerate(original)) - sum(
            x == y and p == 2 for x, (y, p) in enumerate(original)
        ) == sum(perm[x] == x for x in range(512))
        permutations.append(perm)
        signed.append(original)

    remaining = set(range(512))
    orbits = []
    while remaining:
        queue = [min(remaining)]
        remaining.remove(queue[0])
        for x in queue:
            for perm in permutations:
                y = perm[x]
                if y in remaining:
                    remaining.remove(y)
                    queue.append(y)
        orbits.append(sorted(queue))

    traces = [sum(perm[x] == x for x in range(512)) for perm in permutations]
    orbit_data = []
    for orbit in orbits:
        ts = [sum(perm[x] == x for x in orbit) for perm in permutations]
        orbit_data.append({'size': len(orbit), 'least_element': min(orbit),
                           'fixed_point_histogram': dict(sorted(Counter(ts).items())),
                           'fixed_point_counts': ts,
                           'standard_sector_trace_histogram':
                               dict(sorted(Counter(t - 1 for t in ts).items()))})

    # Enumerating 2^18 Pauli labels is small, exact, and also checks phases.
    # A common commuting Pauli is a candidate cheap invariant projector.
    common = []
    for packed in range(1 << 18):
        x, z = packed & 511, packed >> 9
        pauli = (x, z, ce.parity(x & z))
        if all(ce.apply(op.tab, pauli) == pauli for op in ops):
            common.append(pauli)

    result = {
        'status': 'PASS_EXACT_SOURCE_NORMALIZER_SECTOR_CENSUS',
        'source_ports_sha256': sha256((HERE / 'SOURCE-PORTS.txt').read_bytes()).hexdigest(),
        'number_of_normalizers': 112,
        'dimension': 512,
        'all_normalizers_are_signed_linear_involutions': True,
        'walsh_conjugates_are_affine_permutation_involutions': True,
        'normalizer_trace_histogram': dict(sorted(Counter(traces).items())),
        'walsh_affine_orbits': orbit_data,
        'common_commuting_hermitian_paulis': common,
        'anticommutator_diagnostic': {
            'ansatz': '{Gamma_k,K_i}=2 R[k,i] I for all k,i on a common invariant quotient',
            'necessary_identity': 'tr(Gamma_k)=R[k,i] tr(K_i), obtained by multiplying by K_i and taking trace',
            'consequence': 'Every normalizer must have zero trace on the quotient, since every R row has zero entries and every R column has a nonzero entry.',
            'minimum_removed_dimension_at_width_one': max(traces),
            'scope': 'Only this exact scalar anticommutator interpolation ansatz. This is not a lower bound for general observer synthesis, side-information decoders, or correlated projections.'
        },
        'scope': 'Exact width-one representation census. No all-width sector implementation or kappa improvement is claimed.'
    }
    (HERE / 'NORMALIZER-SECTORS.json').write_text(json.dumps(result, indent=2) + '\n')
    (HERE / 'NORMALIZER-PERMUTATIONS.txt').write_text(
        '112 512\n' + '\n'.join(' '.join(map(str, p)) for p in permutations) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('walsh_affine_orbits',)}, indent=2))
    print(json.dumps([{'size': x['size'], 'fixed': x['fixed_point_histogram'],
                       'standard': x['standard_sector_trace_histogram']} for x in orbit_data], indent=2))


if __name__ == '__main__':
    main()
