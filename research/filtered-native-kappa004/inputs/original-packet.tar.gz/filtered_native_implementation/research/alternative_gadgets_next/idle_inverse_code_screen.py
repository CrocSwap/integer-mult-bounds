#!/usr/bin/env python3
"""Finite, optimistic Q=1 screen of literal paid-IDLE replacements.

Only one original FULL stage carries a new inverse code in each probe.
Up to two existing IDLE occurrences of the same geometry are replaced by
signed forward/backward native calls with C or C^-1.  All controller
bridges and their chronology are retained.  This is an exact finite-field
necessary screen, not a universal obstruction or a randomized identity
proof: every failed candidate has an explicit exact specialization.
"""
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import json
import random
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MOD = 65521
# The two roots have product one and sum -26, exactly the exceptional
# characteristic polynomial of the rational two-copy inverse code.
ROOTS = (17883, 47612)
assert ROOTS[0] * ROOTS[1] % MOD == 1
assert sum(ROOTS) % MOD == (-26) % MOD
D_ROOTS = (1, MOD - 1, 24297, 41224)
assert all(pow(x, 4, MOD) == 1 for x in D_ROOTS)

# The sign can be implemented by ordinary +/-1 bank scalings.  Choosing
# +G or -G makes C and C^-1; both source orientations are available.
OPTIONS = [(kind, power, sign) for kind in ("L", "U")
           for power in (1, -1) for sign in (1, -1)]


def candidate_assignments(slots, budget):
    ans = []
    for original_power in (1, -1):
        for k in range(budget + 1):
            for chosen in combinations(range(len(slots)), k):
                for variants in product(range(1, len(OPTIONS) + 1), repeat=k):
                    assignment = [0] * len(slots)
                    for j, v in zip(chosen, variants):
                        assignment[j] = v
                    ans.append((original_power, tuple(assignment)))
    return ans


def evaluate(events, stage, slots, candidates, cpair, seed=20261024):
    n = 2 * max(e[2] if e[0] in ("LOCAL", "QUERY_SHEAR") else e[1]
                for e in events if e[0] in ("LOCAL", "QUERY_SHEAR", "IDLE")) + 2
    rg = random.Random(seed)
    # Two independent D/input specializations, each evaluated at the same
    # inverse pair.  One witness of a discrepancy suffices for rejection.
    base = []
    for _ in range(2):
        x = [rg.randrange(1, MOD) for _ in range(n)]
        base.extend([x, x])
    cs = np.array([cpair[0], cpair[1], cpair[0], cpair[1]], dtype=np.int64)
    ds = {}
    for e in events:
        if e[0] == "LOCAL" and e[1] not in ds:
            d0, d1 = rg.choice(D_ROOTS), rg.choice(D_ROOTS)
            ds[e[1]] = np.array([d0, d0, d1, d1], dtype=np.int64)
    a = np.tile(np.array(base, dtype=np.int64)[None, :, :], (len(candidates), 1, 1))
    powers = np.array([x[0] for x in candidates], dtype=np.int8)
    assigns = np.array([x[1] for x in candidates], dtype=np.int8)
    cminus = np.array([pow(int(x), MOD - 2, MOD) for x in cs], dtype=np.int64)
    allcoeff = {1: cs, -1: cminus}
    slot_index = {e: j for j, e in enumerate(slots)}
    for index, e in enumerate(events):
        kind = e[0]
        if kind in ("LOCAL", "QUERY_SHEAR"):
            _, s, pair, back = e
            x, y = 2 * pair, 2 * pair + 1
            if kind == "LOCAL":
                a[:, :, x] = a[:, :, x] * ds[s] % MOD
                a[:, :, y] = a[:, :, y] * ds[s] % MOD
            if kind == "LOCAL" and s == stage:
                coeff = np.where(powers[:, None] == 1, cs, cminus)
                if back:
                    a[:, :, x] = (a[:, :, x] - coeff * a[:, :, y]) % MOD
                else:
                    a[:, :, y] = (a[:, :, y] + coeff * a[:, :, x]) % MOD
            elif back:
                a[:, :, x] = (a[:, :, x] - a[:, :, y]) % MOD
            else:
                a[:, :, y] = (a[:, :, y] + a[:, :, x]) % MOD
        elif kind == "IDLE":
            _, pair, selected = e
            x, y = 2 * pair, 2 * pair + 1
            factor = np.ones(4, dtype=np.int64)
            for s in selected:
                factor = factor * ds[s] % MOD
            a[:, :, x] = a[:, :, x] * factor % MOD
            a[:, :, y] = a[:, :, y] * factor % MOD
            if index in slot_index:
                choices = assigns[:, slot_index[index]]
                lcoef = np.zeros((len(candidates), 4), dtype=np.int64)
                ucoef = np.zeros_like(lcoef)
                for v, (orientation, exponent, sign) in enumerate(OPTIONS, 1):
                    coeff = sign * allcoeff[exponent]
                    target = lcoef if orientation == "L" else ucoef
                    target[choices == v, :] = coeff
                xx, yy = a[:, :, x].copy(), a[:, :, y].copy()
                a[:, :, x] = (xx + ucoef * yy) % MOD
                a[:, :, y] = (yy + lcoef * xx) % MOD
        elif kind == "ADD":
            _, dst, src, c = e
            a[:, :, dst] = (a[:, :, dst] + c * a[:, :, src]) % MOD
        elif kind == "SIGNED_SWAP":
            _, x, y = e
            xx = a[:, :, x].copy()
            a[:, :, x] = a[:, :, y]
            a[:, :, y] = -xx % MOD
        else:
            raise ValueError(e)
    diffs = np.stack(((a[:, 0, :] - a[:, 1, :]) % MOD,
                      (a[:, 2, :] - a[:, 3, :]) % MOD), axis=1)
    score = np.count_nonzero(diffs, axis=(1, 2))
    minimum = int(score.min())
    best = int(np.argmin(score))
    hits = np.where(score == 0)[0].tolist()
    spot = np.argwhere(diffs[best] != 0)
    witness = None
    if len(spot):
        specialization, row = map(int, spot[0])
        witness = {"specialization": specialization, "row": row,
                   "left": int(a[best, 2 * specialization, row]),
                   "right": int(a[best, 2 * specialization + 1, row])}
    return {"candidate_count": len(candidates), "survivor_indices": hits,
            "best_discrepancy_count": minimum,
            "best_candidate_index": best,
            "best_candidate_rejection": witness,
            "D_specializations": {str(k): [int(v[0]), int(v[2])] for k, v in ds.items()},
            "input_specializations": [base[0], base[2]]}


def serialize_candidate(candidate, slots):
    original, assignments = candidate
    return {"original_code_exponent": original,
            "replacements": [{"event": slots[j], "orientation": OPTIONS[v - 1][0],
                              "code_exponent": OPTIONS[v - 1][1], "shear_sign": OPTIONS[v - 1][2]}
                             for j, v in enumerate(assignments) if v]}


def main():
    srcpath = ROOT / "upstream/research/coded-native-caller/CONTROLLER.json"
    src = json.loads(srcpath.read_text())
    events = src["physical_events"]
    stages = [e[1] for e in events if e[0] == "LOCAL"]
    records = []
    for stage in stages:
        slots = [i for i, e in enumerate(events) if e[0] == "IDLE" and stage in e[2]]
        candidates = candidate_assignments(slots, min(2, len(slots)))
        out = evaluate(events, stage, slots, candidates, ROOTS)
        hits = out.pop("survivor_indices")
        best = out.pop("best_candidate_index")
        rec = {"modified_FULL_stage": stage, "eligible_actual_IDLE_events": slots,
               "maximum_IDLE_replacements": 2, **out,
               "best_candidate": serialize_candidate(candidates[best], slots),
               "inverse_pair_survivors": [serialize_candidate(candidates[j], slots) for j in hits]}
        if hits:
            selected = [candidates[j] for j in hits]
            free = evaluate(events, stage, slots, selected, (3, 7), seed=20261025)
            free_hits = free.pop("survivor_indices")
            free_best = free.pop("best_candidate_index")
            rec["free_code_second_screen"] = {**free,
                "survivors": [serialize_candidate(selected[j], slots) for j in free_hits]}
        records.append(rec)
        print(json.dumps({"stage": stage, "idle_slots": len(slots),
                          "candidates": out["candidate_count"], "survivors": len(hits),
                          "best_discrepancies": out["best_discrepancy_count"]}), flush=True)
    result = {
        "schema": "literal-controller-inverse-code-IDLE-screen/v1",
        "source": str(srcpath.relative_to(ROOT)), "source_sha256": sha256(srcpath.read_bytes()).hexdigest(),
        "modulus": MOD, "exceptional_inverse_roots": list(ROOTS),
        "D_specialization_values": list(D_ROOTS),
        "D_fourth_order_respected": True,
        "fixed_characteristic_polynomial": "c^2+26c+1=0",
        "optimistic_specialization": "Q=I; the sole selected code commutes every D_s. Original bridges, stage locations and IDLE words are retained.",
        "cost_limit": "At c=.0030217758, eight deleted rank8 centers save63.5991100441; one full8-code native replacing an existing rank8 IDLE costs23.86263636 extra moment. The screen permits at most two such replacements per one modified FULL.",
        "ordinary_even_code_allowance": "The inverse-pair screen permits every scalar polynomial in C+C^-1=2C0; a discrepancy at the two exact roots rejects that specialization.",
        "rejection_not_a_lower_bound": "The scope fixes all caller bridges and all other FULL stages. It does not exclude joint modifications with special cross-stage projector identities, new ordinary recodings, alternative controllers or cached-input extraction.",
        "records": records,
        "total_candidates": sum(r["candidate_count"] for r in records),
        "total_inverse_pair_survivors": sum(len(r["inverse_pair_survivors"]) for r in records),
        "new_supplier_or_kappa": False,
    }
    (HERE / "IDLE-INVERSE-CODE-SCREEN.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: result[k] for k in ("total_candidates", "total_inverse_pair_survivors")}, indent=2))


if __name__ == "__main__":
    main()
