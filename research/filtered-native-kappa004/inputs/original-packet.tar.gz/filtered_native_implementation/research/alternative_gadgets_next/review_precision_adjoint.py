#!/usr/bin/env python3
"""Independent forward-injection audit of sampled reverse sensitivities.

This interpreter does not import the reverse calculator or the source emitter.
It propagates separate formal error inputs through the phase-authenticated
normalized word.  Different noise inputs are never combined.
"""
from collections import defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip
import json
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main():
    started = time.monotonic()
    word_path = ROOT / 'research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz'
    witness_path = ROOT / 'research/integration_next/FILTERED-PRECISION-ADJOINT-SITES.json.gz'
    report_path = ROOT / 'research/integration_next/FILTERED-PRECISION-ADJOINT.json'
    raw = word_path.read_bytes()
    witness_raw = witness_path.read_bytes()
    word = json.loads(gzip.decompress(raw))
    witness = json.loads(gzip.decompress(witness_raw))
    report = json.loads(report_path.read_text())
    word_hash = sha256(raw).hexdigest()
    assert word_hash == witness['word_sha256'] == report['word_sha256']
    assert sha256(witness_raw).hexdigest() == report['site_witness_sha256']

    original_count = 2 * 632
    offset0 = original_count
    offset1 = offset0 + word['owned_extra_slots_by_copy'][0] + 1
    mode_offset = offset1 + word['owned_extra_slots_by_copy'][1] + 1
    field_count = mode_offset + word['shared_cross_mode_fields']
    rows = [{} for _ in range(field_count)]

    def field(copy, ref):
        if ref[0] == 'L':
            return 632 * copy + ref[1]
        assert ref[0] == 'C'
        return (offset0 if copy == 0 else offset1) + ref[1]

    def add_into(destination, source, scale):
        assert destination != source
        row = rows[destination]
        for key, coefficient in rows[source].items():
            value = row.get(key, Q(0)) + scale * coefficient
            if value:
                row[key] = value
            else:
                row.pop(key, None)

    samples = sorted(witness['exact_transfer_samples'].items())
    before = defaultdict(list)
    after = defaultdict(list)
    labels = []
    expected = []

    def new_test(name, position, destination, timing, transfer):
        noise = len(labels)
        labels.append(name)
        expected.append(transfer)
        (after if timing == 'after' else before)[position].append((noise, destination))

    for name, sample in samples:
        transfer = {(out, tuple(freeword)): Q(coefficient)
                    for out, freeword, coefficient in sample['transfer']}
        new_test(name, sample['event_index'], sample['noise_field'], 'after', transfer)

    # Timing controls use different error symbols.  Injection immediately
    # before a scale must acquire that scale; before a warp it acquires that
    # warp on the right of the endpoint transfer, not on its left.
    control_info = []
    for name in ('native0.scalar.scale', 'native0.warp', 'native1.warp'):
        sample = witness['exact_transfer_samples'][name]
        position = sample['event_index']
        event = word['program'][position]
        assert event[0] == 'native'
        copy, native = event[1], event[2]
        transfer = {}
        if native[0] == 'scalar':
            operation = native[1]
            assert operation[0] == 'scale'
            scalar = Q(operation[2], operation[3])
            for out, freeword, coefficient in sample['transfer']:
                transfer[out, tuple(freeword)] = scalar * Q(coefficient)
            control_info.append({'class': name, 'event_index': position,
                                 'timing_factor': str(scalar)})
        else:
            assert native[0] == 'warp'
            letter = (1 if native[2] > 0 else -1) * (abs(native[2]) + copy * 1000000)
            for out, freeword, coefficient in sample['transfer']:
                freeword = tuple(freeword)
                product = freeword[:-1] if freeword and freeword[-1] == -letter else freeword + (letter,)
                transfer[out, product] = transfer.get((out, product), Q(0)) + Q(coefficient)
            control_info.append({'class': name, 'event_index': position,
                                 'right_appended_warp_letter': letter})
        new_test(name + '.BEFORE_control', position, sample['noise_field'], 'before', transfer)

    # An error existing before an exact owned clear must vanish completely.
    clear_index = next(i for i, event in enumerate(word['program'])
                       if event[0] == 'native' and event[2][0] == 'scalar'
                       and event[2][1][0] == 'clear')
    clear_event = word['program'][clear_index]
    clear_field = field(clear_event[1], clear_event[2][1][1])
    new_test('exact_owned_clear.BEFORE_control', clear_index, clear_field, 'before', {})

    max_row_terms = 0
    for position, event in enumerate(word['program']):
        for noise, destination in before[position]:
            assert (noise, ()) not in rows[destination]
            rows[destination][noise, ()] = Q(1)
        kind = event[0]
        if kind == 'phase':
            pass
        elif kind == 'native':
            copy, native = event[1], event[2]
            kind = native[0]
            if kind == 'phase':
                pass
            elif kind == 'scalar':
                operation = native[1]
                kind, destination = operation[0], field(copy, operation[1])
                if kind == 'clear':
                    assert destination >= original_count
                    rows[destination] = {}
                elif kind == 'copy':
                    assert destination >= original_count
                    source = field(copy, operation[2])
                    assert source != destination
                    rows[destination] = dict(rows[source])
                elif kind == 'add':
                    source = field(copy, operation[2])
                    add_into(destination, source, Q(operation[3], operation[4]))
                else:
                    assert kind == 'scale'
                    scalar = Q(operation[2], operation[3])
                    rows[destination] = {key: scalar * value
                                         for key, value in rows[destination].items()
                                         if scalar * value}
            elif kind == 'warp':
                destination = field(copy, native[1])
                letter = (1 if native[2] > 0 else -1) * (abs(native[2]) + 1000000 * copy)
                replacement = {}
                for (noise, freeword), coefficient in rows[destination].items():
                    product = freeword[1:] if freeword and freeword[0] == -letter else (letter,) + freeword
                    key = noise, product
                    replacement[key] = replacement.get(key, Q(0)) + coefficient
                rows[destination] = {key: value for key, value in replacement.items() if value}
            else:
                assert kind in ('climb', 'adapter')
                # In authenticated coordinates these change physical frames
                # while carrying the logical value identically.
        elif kind == 'cross_y_add':
            add_into(112 + event[1], 632 + 112 + event[1], Q(1))
        elif kind == 'mode_clear':
            rows[mode_offset + event[1]] = {}
        elif kind == 'mode_add_forward_X':
            add_into(mode_offset + event[1], event[2], Q(event[3]))
        elif kind == 'cross_X_mode_add':
            add_into(632 + event[1], mode_offset + event[2], Q(event[3]))
        else:
            raise AssertionError(event)
        for noise, destination in after[position]:
            assert (noise, ()) not in rows[destination]
            rows[destination][noise, ()] = Q(1)
        if position % 5000 == 0:
            max_row_terms = max(max_row_terms, max(map(len, rows)))

    transfers = [dict() for _ in labels]
    for output, row in enumerate(rows[:original_count]):
        for (noise, freeword), coefficient in row.items():
            transfers[noise][output, freeword] = coefficient
    assert not any(rows[original_count:]), 'Owned fields must be exactly cleared even with sampled errors.'
    for name, got, wanted in zip(labels, transfers, expected):
        if got != wanted:
            difference = {key: got.get(key, Q(0)) - wanted.get(key, Q(0))
                          for key in set(got) | set(wanted)
                          if got.get(key, Q(0)) != wanted.get(key, Q(0))}
            raise AssertionError((name, list(difference.items())[:10]))

    sample_results = []
    for i, (name, sample) in enumerate(samples):
        budgets = defaultdict(Q)
        for (output, freeword), coefficient in transfers[i].items():
            budgets[output] += abs(coefficient)
        maximum = max(budgets.values(), default=Q(0))
        assert maximum == Q(sample['maximum_output_l1'])
        sample_results.append({'class': name, 'event_index': sample['event_index'],
                               'noise_field': sample['noise_field'],
                               'exact_transfer_terms': len(transfers[i]),
                               'maximum_output_l1': str(maximum),
                               'nonempty_freeword_terms': sum(bool(key[1]) for key in transfers[i]),
                               'status': 'PASS'})

    # Check the public scalar bound and avoid conflating it with a prefix
    # magnitude/headroom bound or with a local implementation error proof.
    initial = Q(report['original_input_error']['exact_maximum'])
    paid = Q(report['uniform_paid_child_error']['exact_maximum'])
    ordinary = Q(report['uniform_ordinary_macro_error']['exact_maximum'])
    assert (initial, paid, ordinary) == (Q(351), Q(3591, 2), Q(44713, 4))
    assert initial + paid + ordinary == Q(53299, 4) < 2**14

    receipt = {
        'schema': 'forward-injected-error-independent-review/v1',
        'status': 'PASS_ALL_SAMPLED_EXACT_TRANSFERS_AND_TIMING_CONTROLS',
        'source_word_sha256': word_hash,
        'reverse_witness_sha256': sha256(witness_raw).hexdigest(),
        'reverse_report_sha256': sha256(report_path.read_bytes()).hexdigest(),
        'independent_implementation': 'Fresh forward interpreter; no reverse-calculator or emitter imports.',
        'sample_count': len(samples), 'extra_timing_controls': len(labels) - len(samples),
        'program_events_replayed_once': len(word['program']),
        'independent_error_symbols': len(labels),
        'exact_transfer_terms_compared': sum(map(len, expected)),
        'all_final_owned_error_rows_zero': True,
        'sample_results': sample_results,
        'timing_controls': control_info + [{'class': 'exact_owned_clear', 'event_index': clear_index,
                                           'noise_field': clear_field, 'remaining_transfer_terms': 0}],
        'reported_bound': {'initial_delta': str(initial), 'paid_epsilon_q': str(paid),
                           'ordinary_epsilon_o': str(ordinary),
                           'uniform_sum': str(initial + paid + ordinary),
                           'uniform_sum_less_than_2_to_14': True},
        'logical_review': [
            'Post-operation reverse transfer matches forward injections exactly at all 15 event/role maxima.',
            'Within-site path cancellation uses exact rational coefficients and reduced unitary free words.',
            'Distinct error symbols remain independent; their bounds must be added by the triangle inequality.',
            'Unitary frame changes preserve the Euclidean norm of the local injected error.',
            'Exact owned clears erase earlier error symbols and introduce no new error in the stated model.'
        ],
        'scope': 'Validates sampled endpoint transfers, timing, and orientation; does not independently recompute all 47016 site sums. The reverse program itself checks all 1264 input columns. Prefix/headroom and local ordinary-macro error contracts remain separate obligations. No new kappa claim.',
        'elapsed_seconds': round(time.monotonic() - started, 3)
    }
    path = HERE / 'PRECISION-ADJOINT-INDEPENDENT-REVIEW.json'
    path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
