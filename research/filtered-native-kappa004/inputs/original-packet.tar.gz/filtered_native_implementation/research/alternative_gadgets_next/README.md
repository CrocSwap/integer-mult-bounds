# Source-bound constructive gadgets and caller probes

This directory contains constructive probes on the frozen 112-port source.
The completed source implementations include exact rational inverse codes
on two independent copies and an independent replay of the helper-clean
causal companion. The latter keeps all 1,264 original inputs, all 816 helpers
and their physical phases. These provide new source contracts. The latest
completed probes test changed target portfolios and selected independent
inputs against their actual query dependencies. They found no positive
excess. A new one-query partial-mode head is implemented in the collaborating
source branch; the exact checks below delimit its immediate caller use.
A caller that turns the new contracts into a better autonomous Gaussian
target list remains open.

The earlier exact provider for one weighted average of the source-R5 exit
transforms remains a useful phase calibration. It uses query ranks
**[6, 1, 1, 6]** instead of 56 independent rank-one calls; the independently
replayed Bell provider improves that profile to **[4,4]**.

## Paid mode head: exact caller sector and range checks

The new foreign-mode observer is a valid paid primitive. In the source
chart, define

\[
V_k=\operatorname{diag}(K^{-1})r_k^T,\qquad
L_k=r_k\operatorname{diag}(K)/56,\qquad
\Pi_k=V_kL_k.
\]

The source identity `R R^T=56 I` gives `L_k V_l=delta_kl I`. Consequently

\[
H_k=I-\Pi_k+V_kQ_{\rm mode}L_k,
\qquad H_k^4=I,
\]

and its square is ordinary. The literal implementation in
`research/retained_state_next/ENCODED-MODE-HEAD.json` uses one rank-one query,
56 mapped gather additions, 56 mapped scatter additions and two owned fields,
with all unrelated original and helper banks untouched. The scalar
normalization is applied once to the complete array, outside tensor powers.
The phase-exact foreign-stage observer and its authenticated early source
cut are pinned in `FOREIGN-MODE-HEAD-SECTOR.json`.

The useful distinction is between this encoded head and the caller's
global head. On the actual width-two sector consisting of two equal Fourier
frequencies, choose an even common source frequency `w`. Then
`Q_mode=+1`, while the caller head on owner `i` has sign
`(-1)^(1+w.q_i)`. The extra one is the actual signed `K_i` phase offset.
Thus the scattered paid head `J_k=14 V_k Q_mode L_k` restricts to the
already ordinary `-P_k`, and `H_k-I` restricts to zero.

This restriction does not remove the signs that obstruct the known p3
repair. The receipt constructs all eight independent source sign patterns
at owner pair `(4,5)`, with all 64 fresh-stage sign patterns still independent.
It checks 3,072 other-chart graph separations. It then rebuilds all 14,347
chronological scalar control columns and checks the previous two-term
functional directly, without a new reachability search. Every column has
functional value zero, while the required correction is `-1/4` for source
R5 and `+1/2` for all eight modes. The placements include retained earlier
bank values, internal transformed sources before the opposite input is
consumed, and retention of those sources for later bank updates. All six
original caller banks remain independent.

Therefore these paid heads add no direction to the stated first-order
correction equation, even if up to seven are supplied for one deleted
rank-eight center. This is a tangent statement; essential higher-order
interactions in a changed finite controller are not excluded.

The proposed direct substitution for the causal companion's global odd-Q
role charts has a stronger explicit failure. At `w=128`, the actual source
satisfies

\[
\Pi Q_{\rm global}\Pi=0,
\qquad Q_{\rm global}\Pi\ne0.
\]

Take the owner coefficient vector `v=r5^T` in the common source chart. Its
squared norm is 56. It lies in the selected mode, while `Q_global v` is
orthogonal to the entire eight-mode range. Every same-chart partial head
`H_k`, and every power or product of them, is the identity on this sector.
For the independently reviewed companion edge

\[
E=\begin{pmatrix}
DCQ^{-1}&D\\
(I-C^2)D&-QDC
\end{pmatrix},\qquad C=I-14\Pi,
\]

the true charts satisfy
`diag(Q,I) E diag(I,Q^-1)=M_C diag(D,D)`.
Replacing those charts by partial heads sends the first-role input `v` to
`zeta v` in the upper output, where the required result is
`zeta Q_global v`. Their squared difference is exactly 112; both lower
outputs are zero. This is checked for the single R5 mode and all eight
modes. The receipt also preserves exact 12-function minors on the 16 even
balanced frequencies, with determinants `16777216` and `4294967296`.

These checks retain the positive partial-head implementation and reject
two particular immediate uses. They do not exclude new intervening ordinary
address maps, other source charts, changed paid jobs, or a redesigned caller.
No center replacement or kappa increase is claimed.

```sh
python -B research/alternative_gadgets_next/foreign_mode_head_sector.py
```

## Conditional center-replacement economics

`conditional_center_replacement_price.py` prices a hypothetical native
endpoint with unchanged 632 independent original inputs and 408 helper jobs,
but with one or eight rank-eight center queries replaced by rank-one queries.
**This replacement is not implemented by the eight proposed snapshot
identities.** The independent source replay in
`research/integration_next/RANK1-CENTER-DEPENDENCY-INDEPENDENT-REVIEW.json`
shows that those identities recover the modes in the unchanged word and
become exactly zero in the actual helper-clean word with all centers removed.
Their later snapshots had supplied the original center signal. This failure
does not exclude a different observation or a one-mode construction.

The separate static ancestry audit here explains the dependency: each of
the eight two-snapshot cleanup recipes uses one center-free full snapshot
and one full snapshot descended from exactly its own rank-eight center.
Pre-center rank-one observations alone are center-free. The dependency audit
is a structural check; the separately pinned all-column replay establishes
the exact cancellation failure.

Conditional accounting uses the literal selected-family p16 controller,
which has 16 backward full calls, two forward full calls, 15 query shears
and the original paid idle windows. The actual local source profile is
`{1:2201,2:412,3:510,4:127,5:40,8:8}`. Helper targets stay
`{4:28,7:7,8:47,9:326}`. Every extra owned snapshot has zero productive
credit. The complete caller retains 10,928 productive originals and 64,404
paid jobs; changing query ranks changes the moment and mass, not those counts.

| Hypothetical replacement | Complete rank surplus | Exact raw-crossing bracket |
|---|---:|---|
| None | 752 | `(0.00302177587077, 0.00302177587078)` |
| One center in each of 16 backward calls | 864 | `(0.00347152646990, 0.00347152646991)` |
| All eight centers in 16 backward calls | 1648 | `(0.00661750907994, 0.00661750907995)` |
| All eight centers in all 18 full calls | 1760 | `(0.00706660320914, 0.00706660320915)` |

These brackets use exact rational moment enclosures and a strictly negative
derivative certificate on `[0,.02]`. They are fixed-p16 crossings, not
globally optimized supplier exponents. At `c=0.0030217758`, replacing all eight
centers in one call saves `55.59911004414015354624492810559` query-moment units.

The useful target is therefore only **one valid rank-eight-to-rank-one
replacement in the backward native supplier**. Its conditional crossing
already exceeds the available ordinary BIT budget. The existing admitted
BIT saving gives the strict outer supremum `0.0034`. Re-admitting a rational
saving below the already established ordinary BIT budget gives the strict
supremum `0.0034363538396`. This calculation does not retune the delayed
cover or the BIT source. Neither supremum is attained because the outer
inequalities require strict slack.

`CONDITIONAL-CENTER-REPLACEMENT-PRICE.json` contains two exact outer examples:
`kappa=0.00339999` with the existing admitted BIT saving `0.0034`, and
`kappa=0.00343635` with readmitted BIT saving `0.003436353`. Each passes all
54 strict inequalities and four functional guards. The one-mode backward
invoice is separately repriced against the same outer parameters: with
tensor power 1024, paid cutoff 20, target floor 21, tail limit `97/100` and
alpha gap `1/100000`, the complete paid-completion bound is below one.
The original compiler logarithm power 1000 fails the complement-capacity
check at these stronger savings; power 1200 passes. Compiler and outer
parameters do not supply the missing native endpoint.

Adoption still requires an exact changed native endpoint, chronological
owned capture/query/use/erase schedule, actual physical frames and phases,
an all-width identity with scalars outside tensor powers, and valid stage
embedding. The added ordinary routes, storage, prefix bounds and precision
must be priced. Chronological product, completion, compiler, fixed-tape,
analytic, prime and exact-recovery hypotheses must apply to the new literal
supplier. Only then would independent changed-construction review support a
kappa update. The current receipt is explicitly conditional and claims no
new supplier or kappa.

```sh
python -B research/alternative_gadgets_next/conditional_center_replacement_price.py
```

## Changed target portfolios: completed bounded probes

All margins in this section are productive target moment minus complete
paid query moment at `c=0.0030217758`, with moment `sum r^(1-c)`. Positive
margin is required. Rank mass is reported separately and is not used as a
substitute for the moment. No new kappa is claimed.

### Clean intermediate targets

`intermediate_target_portfolio.py` changes the target boundary of the actual
standalone forward source word. Instead of requiring every productive owner
to reach its final frame, it permits one earlier clean same-owner snapshot.
Its physical operator is `T_snapshot W_logical T_start^-1`, including the
actual quadratic phases in each native `K_G` warp. The implementation uses
`Q=I+G^(-T)G^(-1)` and `alpha=diag(Q)` in the forward warp compiler; it does
not substitute a plain address permutation for `K_G`.

All 632 original inputs remain arbitrary and independent. The 520 active
source owners are copied into owned SSA storage, while all originals are
retained. One chosen pure-owner snapshot can earn one productive transform
for that owner. Every unselected original is restored from its retained
input, and other owned versions are cleared. Copies never earn additional
productive credit.

The complete census contains 14,070 SSA nodes, 1,125 clean same-owner
snapshots and 758 strictly increasing target-rank milestones. Same-owner
ancestry is nested in this literal word, so a later snapshot of no greater
rank is dominated by an earlier one. Positive milestone increments and
predecessor arcs telescope to the credit for at most one target per owner.
Negative query vertices charge the union of required native queries.

For each minimum target rank from two through ten, the probe charges fresh
disjoint-coordinate padding when needed and splits original queries to
enforce strict child/target separation. Every first-mass optimum is zero.
Every benchmark moment optimum remains zero even with target credits
rounded favorably upward and paid costs downward. The empty portfolio
attains zero; this establishes no positive excess in the stated family,
not strict negativity for every nonempty portfolio.

At the fixed benchmark `c=0.0030217758`, the rank-nine certificate also
extends analytically to every larger integer minimum target rank. Every
native snapshot has rank `r<=9`, and native queries have rank at most five,
so their costs no longer require splitting when the minimum `M>=9`.
The net credit for a padded snapshot is `f(M)-f(M-r)`, where
`f(x)=x^(1-c)` and `f(0)=0`. Concavity makes this difference nonincreasing
in `M`, including the boundary `M=r=9` by continuity. Thus the true margin
of every fixed portfolio can only decrease after `M=9`. The saved MIN9
certificate, together with the finite checks for minima two through eight,
excludes positive excess for every integer minimum target rank at least
two in this padded snapshot family at the stated `c`. This is not a
claim for other exponents without repricing.

The favorable tariff is certified with exact rational enclosures, using
96 terms of the positive `atanh` series for `log(r)` plus a geometric tail,
and alternating exponential bounds through degrees 13 and 12. The moment
interval width is below `10^-15` for ranks one through ten. Integer rounding
uses scale 100,000. Every flow is checked for capacities, antisymmetry,
conservation, residual reachability and equality with its cut.

`INTERMEDIATE-TARGET-PORTFOLIO.json` preserves the complete census and
results. `INTERMEDIATE-TARGET-FLOW-MIN6.json.gz` and
`INTERMEDIATE-TARGET-FLOW-MIN9.json.gz` preserve full graph capacities,
signed flows, cuts, source bindings, milestones and the rational tariff
method. The source word is pinned by
`078cfdf19b7acee0f733f991ee34c8e47eb934eed25b54454f1ad8f0ffb4ece5`.

This is a certificate for clean same-owner singleton-operator snapshots
in the literal source word. It does not cover general clean subspace
decoders, changed scalar dependencies, coordinate packing, or multi-stage
query fusion. The receipt's `EMISSION_PENDING_IF_POSITIVE` status describes
a conditional implementation gate; the completed search has no positive
candidate, so no profitable schedule is waiting to be emitted.

### Selected independent Y inputs and X-row decoders

`subset_y_portfolio.py` changes both the input portfolio and the demanded
output rows. With all native X inputs declared owned zeros and the filtered
tail omitted, the actual backward endpoint is

\[
X_{\rm raw}=\overline{F_9}(-A Y),\qquad A=I-R^TR/4.
\]

For independent input ports `S` and a nonsingular square row minor `J`,
write `A4=4I-R^TR`. Then the exact ordinary decoder is

\[
\overline{F_9}Y_S=-4(A4_{J,S})^{-1}X_{{\rm raw},J}.
\]

Only the selected Y ports are original arbitrary inputs. All unselected
Y ports and all X ports are explicitly owned zeros. Helpers are either all
408 arbitrary originals with all their transformed outputs demanded, or
all owned zeros with no helper target credit. The decoder credits exactly
`|S|` independent rank-nine targets. With arbitrary helpers, the 28 rank-four
helper targets are padded to rank six with 28 paid rank-two jobs, so every
target rank exceeds every child rank.

The baseline sweep covers 142 distinct input subsets under each helper
policy: all 112 singletons, all 14 eight-port source-support classes, all
eight root-mode supports, the empty set and a short prefix menu. Query
liveness and the invoice of each chosen output basis are exact. Output-row
bases are chosen greedily by incremental query-moment cost, with rational
independence certified by a full-rank integer minor modulo 2,147,483,647.
This greedy choice is not a global optimum over row bases.

No positive candidate was found. Useful reference portfolios are:

| Independent inputs | Selected output rows | Paid rank profile | First-mass margin | Moment margin |
|---|---|---|---:|---:|
| `Y64`, helpers owned zero | `X19` | `2,2,5` | 0 | -0.0269306030852251 |
| Eight ports of support class 60, helpers owned zero | `0,7,10,11,14,52,41,106` | `1:14, 2:18, 3:4, 4:4` | -6 | -6.29448158309553 |
| No Y inputs, all 408 helper inputs | All helper endpoints | `1:1762, 2:259, 3:468, 4:93, 5:12` | -589 | -604.382259438215 |

Here `r:n` means `n` paid queries of rank `r`; helper padding is included.
The complete records and query IDs are in `SUBSET-Y-PORTFOLIO.json.gz`, with
summary `SUBSET-Y-PORTFOLIO.json`. The backward source word is pinned by
`934fea11e51f674ce2031b7d3127b994a921a9d83317b00359292752563a1775`.

### Full class-60 row-basis screen and bounded input-subset sweep

Support class 60 consists of ports
`[14,15,41,42,52,53,105,106]`. Because its greedy eight-input portfolio was
only six first-mass units short, `subset_y_exact_basis.py` considers all 112
output rows for that fixed full input set. Exact proportional/query-set
domination leaves 82 candidate rows, 20 directions and 271 query variables.

Any positive portfolio for eight rank-nine targets must have paid first
mass at most 71: every child has rank at most five, and
`sum r^(1-c) >= 9^(-c) sum r`. The bounded MILP first found a mass-58 set of
eight rows with rank four. One exact rational-flat cut forced at least four
selected rows outside that span. After this valid rank cut, HiGHS reported
the mass-at-most-71 problem infeasible. `SUBSET-Y-EXACT-BASIS.json` preserves
the candidates, query bindings, cut and solver result. All candidate
invoices and cuts are exact, but no standalone rational MILP infeasibility
certificate was emitted. This is a bounded solver result, not a general
circuit lower bound.

The final `--within-class60` run is complete: it prices all 256 subsets of
these eight input ports, with helpers owned zero and a greedy independent
output-row decoder for each subset. None has positive excess. The best
nonempty candidates are singletons, with paid ranks `2,2,2,3`, one rank-nine
target and moment margin
`-0.037060916928928672090916879339087855018294610723722947805184461048964`.
The empty portfolio has margin zero. `SUBSET-Y-CLASS60-SUBSETS.json` and its
`.json.gz` full receipt are separate from the baseline sweep and preserve
all selected row bases and query invoices. This subset census does not
optimize every possible output basis for each subset; the separate bounded
MILP applies only to the full eight-input class.

All scripts and receipts in this section are complete. No partially written
schedule, positive-candidate implementation, or unfinished search is
included. The existing source and flow witnesses were preserved.

```sh
python -B research/alternative_gadgets_next/intermediate_target_portfolio.py
python -B research/alternative_gadgets_next/subset_y_portfolio.py
python -B research/alternative_gadgets_next/subset_y_exact_basis.py
python -B research/alternative_gadgets_next/subset_y_portfolio.py --within-class60
```

## Rational inverse codes and the causal companion

`PARTIAL-CENTER-INVERSE-CODES.json` proves the rational construction

\[
G=\begin{pmatrix}0&(6/7)F^{-1}\\F&0\end{pmatrix},\qquad
G^2=(6/7)I,
\]

\[
C_\pm=I-P+P(-13I\pm14G),\qquad C_+C_-=I.
\]

Here `F=F9^(tensor m)` and `P` is the source-bound selected-mode projector.
All scalar owner coefficients apply once, rather than being tensor-powered.
The available pair `(Ft1,Ft2)` supplies `G(t1,t2)` using only the monomial
`F^2` and rational scaling. The inverse raw-dual word must use the transpose
companion `-G^T`; `G` is not symmetric. The full physical source replay is in
`research/operator_alignment_next/CLEAN-DAG-INDEPENDENT-REVIEW.json`.

`review_causal_companion.py` independently interprets the integrated literal
word in `research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz`. It does
not import the emitter, `native_core`, or another reviewer. The current
compressed word is pinned by
`99e10c9b61c60627cfc4a7df627ac396d073b05f2b37c2f7416973f9a06ddd53`.
The full endpoint hash is
`dc2a82e9042adcb0ab0f1ff94f3875da295f5fd2f0fbcb3d56dd6b8d3aeedb21`.

With `A=I-R^T R/4`, the four independent main banks obey

\[
x_f'=x_f,\quad y_b'=y_b,\quad
y_f'=y_f+A x_f+y_b,\quad
x_b'=x_b+(I-A^2)x_f-Ay_b.
\]

The physical cross updates are monomial. The first maps every completed
backward Y frame to its forward counterpart with the actual phase included.
The second uses `F^2` to map completed forward X fields to backward X frames.
The eight mode gathers and every cache lifetime are replayed explicitly.
The independent receipt verifies 1,264 original columns, 816 autonomous
helpers, the synchronized source cut, and all owned final zeros. The current
peak is 1,915 nonzero owned fields, including cross-mode fields.

For `C=diag(K)^-1 A diag(K)`, its source-to-consumer edge in physical normalized
coordinates is

\[
E=\begin{pmatrix}D C Q^{-1}&D\\(I-C^2)D&-QDC\end{pmatrix}.
\]

The source and consumer role charts give

\[
\operatorname{diag}(Q,I)E\operatorname{diag}(I,Q^{-1})
=\begin{pmatrix}C&I\\I-C^2&-C\end{pmatrix}
 \operatorname{diag}(D,D).
\]

The displayed companion squares to the identity for any `C`. Its physical
source conjugation has an upper-right `Q`, of Gaussian rank one; therefore
the chart involution is not itself an ordinary physical recoding.

```sh
python -B research/alternative_gadgets_next/partial_center_inverse_codes.py
python -B research/alternative_gadgets_next/review_causal_companion.py
```

### Independent endpoint precision audit

`review_precision_adjoint.py` checks the new reverse sensitivity calculation
against fresh forward injections in the literal 51,183-event companion. It
uses 19 independent error symbols: the largest nonzero sensitivity in each
of 15 event/role classes, plus before-scale, before-warp and exact-clear
timing controls. All 1,093 endpoint `(output, freeword, rational coefficient)`
terms agree, and every owned error field clears. In particular, the warp
checks distinguish right composition of the endpoint transfer from an
incorrect left composition.

The resulting endpoint bound is

\[
351\delta+\frac{3591}{2}\varepsilon_q+
\frac{44713}{4}\varepsilon_o.
\]

For a uniform error scale the coefficient sum is `53299/4 = 13324.75`,
strictly below `2^14`. Path cancellations occur only within one error site's
transfer; errors at different sites remain independent and are bounded by
the triangle inequality. This sampled independent audit does not recompute
every site's aggregate sum. It also does not replace the separate prefix
magnitude/headroom certificate or the local ordinary-macro error contracts.

```sh
python -B research/alternative_gadgets_next/review_precision_adjoint.py
```

## Owned-zero suppliers: certificate and synthesis probes

The one-sided source retains arbitrary Y inputs, sets its X inputs to owned
zeros, and optionally keeps original helpers. Its endpoint has
`X=-A Y`, with the actual common backward F9 output frame. Since
`A^-1=I-R^T R/52` is ordinary, this would be a productive supplier if its
remaining query invoice were small enough.

`review_owned_zero_closure.py` independently authenticates the fixed-SSA
helper-subset certificate. A single reverse bitset pass checks all 17,260
helper/query implications. Eight direct subset replays agree with support
specialization, and 23 nested subset examples obey query-set monotonicity.
The two 2,313-vertex flow certificates pass edgewise capacity, antisymmetry,
conservation, residual reachability and matching-cut checks without calling
the original optimizer.

The scoped maximum-closure bound is `-732` at first mass and at most
`-751.44493` at `c=0.0030217758`. An independent rational-only fallback gives
`-732+6208c = -713.2408158336`, still negative. These bounds cover all
`2^408` helper choices in the specified SSA/zero-pruning model. They do not
cover changed physical circuits, complete-value reuse or sacrificial-helper
transport.

Two constructive searches explicitly change that dependency model:

| Probe | Best observed result | Scope |
|---|---|---|
| Complete-value memoization | No-helper moment margin `-945.640504...` | Same-frame actual phase-bearing values, scalar aliases |
| Physical monomial aliases | No positive invoice | Anchor-normalized operator rows and exact Lagrangian equivalence |
| Chronological rational spans | No cheaper paid output with all 408 arbitrary helpers | Earlier same-frame owned caches, one earliest echelon basis |

With all 408 helpers, all three tested mechanisms retain the paid profile
`{1:2201, 2:412, 3:510, 4:127, 5:40}` and moment margin
`-803.30818495893...`. The earliest-basis span circuit can worsen global query
sharing in the no-helper case, so its standalone greedy score is not an
optimality certificate. Exact combinations and selected aliases are kept in
the receipts, but no supplier has been admitted from these probes.

```sh
python -B research/alternative_gadgets_next/review_owned_zero_closure.py
python -B research/alternative_gadgets_next/owned_zero_memoization.py
python -B research/alternative_gadgets_next/owned_zero_linear_span.py
```

## Scoped caller searches

The exact actual-IDLE screen tested 25,492 choices of one changed FULL and
at most two reciprocal-code replacements in its existing paid IDLE slots.
Its fixed bridges had no survivor. A separate involution specialization
had the same result. This does not cover a redesigned controller.

`ORDINARY-BOUNDARY-GRADE.json` records a sharper one-stage boundary result.
For the actual all-eight-mode source, the grade-eight component on the main
fields is invertible, while all new couplings have different Gaussian
grades. Invertible boundaries in the finite span of whole-width lifted
monomial Cliffords preserve this fact. Consequently, a static one-stage
decoder in that span cannot replace any main rank-eight job by a different
Gaussian rank. Retained intermediate values and multi-stage products are
outside this argument.

Two fresh stages were then tested in an exact three-address-bit model with
a shared Q axis and two distinct D axes. Its active code is the two-owner
block `C_s=[[-6I,-7K_s],[-7K_s,-6I]]`, where `K_s` swaps the shared axis and
the stage axis. This is the active block of a fourteen-owner rank-one code;
it does not reproduce every identity of the actual 112-port construction.

The signed-permutation screen covered 192 physical role bridges. A second
batch included single-bank and common `S`, `S^-1`, and `CZ` phase bridges,
for 8,832 physical networks. For each network, exact Gaussian-grade
components were normalized by the group augmentation. Autonomous Gaussian
targets require these components to be mutually orthogonal idempotents.
The 92 phase-batch survivors of that necessary condition all retained
explicit nonzero coefficients in grades absent from their necessary target
profile. No candidate in these finite families survived.

`TWO-STAGE-COORDINATE-BRIDGES.json` additionally moves the address geometry:
all six common axis permutations and eight translations are combined with
the 192 signed role bridges, giving 9,216 physical networks. Its 16
augmentation survivors all have the identity coordinate permutation and
the known sign patterns. Each forces eight rank-two jobs while retaining
nonzero grade-one/three coefficients, so none survives the full coefficient
test. Nontrivial axis permutations already fail the augmentation condition.

The final bounded bridge extension is symbolic: one ordinary scalar bank
shear `I+lambda E_ab`, before or after a signed role permutation. The twelve
ordered distinct bank pairs and all 192 signed role permutations give 2,304
one-parameter families. `TWO-STAGE-SCALAR-SHEAR.json` covers every rational
`lambda`, using exact gcds of degree-at-most-four idempotence-defect
polynomials rather than a coefficient grid.

Of these families, 2,280 have constant defect gcd. Sixteen have the sole
candidate `lambda=0`, which retains the previously excluded full
coefficients. The remaining eight are idempotent under augmentation for
every parameter, but their forbidden-grade coefficient polynomials have
constant gcd. No parameter survives the complete grade-profile test.
Explicit polynomial witnesses and 48 evaluation controls are preserved.
This stops the one-shear/two-stage toy family; it is not a general caller
obstruction.

The boundary argument permits the full one-column monomial Clifford span,
including ordinary diagonal phases and binary-linear permutations. The
source and intermediate-bridge families remain the stated small models.
Further work should change the intermediate coupling, use retained values,
or change the number of stages rather than enlarge the signed-permutation
batch.

```sh
python -B research/alternative_gadgets_next/ordinary_boundary_grade.py
python -B research/alternative_gadgets_next/two_stage_companion.py
python -B research/alternative_gadgets_next/two_stage_phase_bridges.py
python -B research/alternative_gadgets_next/two_stage_coordinate_bridges.py
python -B research/alternative_gadgets_next/two_stage_scalar_shear.py
```

## Exact weighted average

For the actual 56 ports with source `R[5,i] != 0`, let

\[
T_m=\frac1{56}\sum_i C(-X_{q_i})^{\otimes m}.
\]

The source labels are exactly `q=h+v`, with `h` equal to 128 or 256 and
`v` running over the 28 edge labels of K8. Write the eight vertex labels as
`[1,2,4,8,16,32,64,127]`; an edge label is the xor of its endpoints.
The low-label difference space has dimension six.

The literal six-direction chart `W` in `SHARED-SCATTER-CHARTS.json` obeys

\[
WQ_{h+v}^{-1}W^{-1}=M_{h,v}Q_h^{-1},
\qquad
M_{h,v}|a\rangle=(-i)^{\langle z_v,a\rangle}
 |a+h\langle z_v,a\rangle\rangle.
\]

Every operation `M` is an admitted monomial. Therefore, with
`A_(h,m)=sum_v M_(h,v)^(tensor m)`,

\[
T_m=\frac{i^m}{56}W^{-\otimes m}
 \left(A_{128,m}Q_{128}^{-\otimes m}
       +A_{256,m}Q_{256}^{-\otimes m}\right)
 W^{\otimes m}.
\]

The two head outputs are combined before the inverse chart. The two rank-six
charts are each paid once. The ordinary work is a fixed sum of 56 monomials,
copies, additions, and the scalar `i^m/56`. The existing whole-width Boolean
compiler applies to the fixed source-derived address and phase functions,
conditional on its established B1 premise.

`SELF-AVERAGE-PROVIDER.json` includes all four Gaussian query lowerings,
absolute phases, all 56 conditional monomials, a conservative four-scratch-
array schedule, and the all-width algebraic proof. The phase is `i^m`, not a
constant `i`. The six-bit `ce.hadamard` convention differs from normalized
Walsh by phase `-i`; its entry and exit phases cancel in the sandwich.

The replay checks every width-one basis input and two dense Gaussian-integer
width-two inputs of length 262,144. No floating-point tolerance is used.
It also authenticates the active support and all signs against the literal
source `R.json` row five. It does not use the NORMALIZERS mode numbering.

At `c=0.0030217758`, the provider moment is
`13.935204025719347226470677603450034457070620439499686228053248710`.
The separate paired-copy Bell implementation in
`research/operator_alignment_next/BELL-SELF-AVERAGE.json` improves this to
**[4,4]**. Both exact-array output hashes agree byte for byte with this
provider. The width-two hash is
`53b4a19eef4637a0f5bbe21ef87a6fd41e5691738b4f572eb565d96dae8441e6`.
The current file therefore remains an independent phase and complete-array
calibration. The Bell provider's fresh moment is still slightly larger than
one rank-eight call; retaining its chart across a module is a separate caller
question.

```sh
python -B research/alternative_gadgets_next/shared_scatter_chart.py
python -B research/alternative_gadgets_next/self_average_provider.py
```

## Eleven- and twelve-term exact decoders

The scalar objective is the exact binary pairing rank on the supports of
each factor pair, using the actual nine-bit source labels. A candidate must
also satisfy `P Q^T = R^T R` over the rationals on all 12,544 entries.

Two finite searches were completed:

| Probe | Scope | Priced support moves |
|---|---|---:|
| `decoder_gauge_search.py` | 162 seeds; elementary rational factor gauges | 80,887 |
| `decoder_pair_gauge.py` | 32 structured seeds; full two-column rational basis changes | 10,168,645 |

The second probe uses exact cancelling free rectangles, point and
hyperplane-truncated factors, and outside dimensions `(2,1)` or `(2,2)`.
A complete two-column change can cross a support barrier without charging
the intermediate elementary shears. Neither batch found a moment improvement.
This is a finite search result, not a floor theorem.

Normalization matters. A stored factor list can have outside dimensions
`(2,1)` while its outside vectors occur only in zero products. Likewise,
nonzero root-swap terms may merge because their opposite factors are
proportional. `DECODER-SEARCH-REVIEW.json` removes zero products and repeatedly
merges proportional factors on both sides. Its best baseline-cost search
snapshots reduce to the ordinary eight-term decoder with outside dimensions
`(0,0)`. They are not normalized outside-code constructions.

The structured `decoder_inflation_search.py` extends the same exact point
cancellation used in the known K3 tightness witnesses to the extra outside
directions. It retains only nonzero factorizations without proportional
factors on either side. Its receipt preserves one complete exact attainer
per discovered rank profile, including every factor and gauge move.

The `(2,1)` inflation tree examined 206 nodes and produced 175 normalized
rank-mass-64 factorizations, all with profile `1,1,1,7,7,7,8,8,8,8,8`.
The `(2,2)` tree examined 1,123 nodes and produced 900 normalized
rank-mass-64 factorizations, all with profile `1,1,1,1,7,7,7,7,8,8,8,8`.
These are actual outside-code attainers, unlike the reducible uninflated
lists. Their query moments are worse than the coordinate baseline; they are
preserved as exact starting points, not claimed improvements.

```sh
python -B research/alternative_gadgets_next/decoder_receipt_review.py
python -B research/alternative_gadgets_next/decoder_inflation_search.py
```

### Full query moment filter

Rank mass alone is not the objective. `RANK64-MOMENT-PROFILES.json` exhausts
the sorted positive-rank profiles of mass 64 with ranks at most nine, at the
stated `c`. The baseline is

`63.599110044140153546244928105590968386355456442107613238906705015`.

There are 21 improving profiles with eight positive terms, three with nine,
and none with ten or more. The three nine-term profiles are:

| Profile | Moment improvement over eight rank-eight calls |
|---|---:|
| `1,1,8,9,9,9,9,9,9` | 0.0065677543298455551 |
| `1,2,7,9,9,9,9,9,9` | 0.0016811481200407912 |
| `1,2,8,8,9,9,9,9,9` | 0.0013059412628186297 |

Thus a rank-mass-64 winner with 11 or 12 stored terms needs at least two or
three actual rank-zero terms. The least concentrated improving eight-term
profile is `7,8,8,8,8,8,8,9`, improving the moment by approximately
0.000375206857222162. Realizing any of these profiles remains a constructive
problem. Rank mass at least 65 cannot win: `r^(1-c) >= r*9^(-c)` gives the
lower bound `64.56986073572280133`, already above the baseline.

The existing normalized K3 ten-term witnesses were replayed exactly from a
local copy of the frozen checker, with its SymPy elimination replaced by
standard-library rational elimination. Their ranks are `7,1,7,1,8,8,8,8,8,8`.
They exceed the baseline moment by `0.0181425858896644643`.
The source theorem covers only normalized `(1,1)` ten-term decoders; it is
not a general 11/12-term obstruction.

## Earlier scoped probes retained here

The nonlinear Majorana tests reduced some average supports but retained the
same exponential worst-case support. The exact common-Clifford and flat-word
receipts delimit common monomialization, not general fast dense algorithms.
They do not obstruct multi-route, projected, operator-valued, retained-state,
or redesigned-caller constructions. These lanes were stopped when they ceased
producing a useful implementation direction.

All source modifications and new artifacts are confined to this research
directory. No frozen source or selected supplier has been changed.
