#!/usr/bin/env python3
"""Two-column rational basis changes on exact 11/12-term decoders.

Unlike an elementary shear, a full GL(2) change can cross a support barrier
without paying for the intermediate factors. All prices are actual binary
pairing ranks. This is a declared finite search, not a decoder floor.
"""
from collections import Counter
from decimal import Decimal
from fractions import Fraction as F
from hashlib import sha256
from itertools import combinations, combinations_with_replacement
from pathlib import Path
import argparse
import json
import random
import time

import decoder_gauge_search as d


def normalize(P, Q):
    """Projective factor scaling preserves every exact outer product."""
    for k in range(len(P)):
        x = next((v for v in P[k] if v), None)
        if x is not None:
            P[k] = [v / x for v in P[k]]
            Q[k] = [v * x for v in Q[k]]


def dual_directions(pa, pb, qa, qb, pma, pmb, qma, qmb):
    # None is infinity: p(infinity)=pb, q_dual(infinity)=-qa.
    pc, qc = {}, {}
    for i in range(d.N):
        if pb[i]:
            t = -pa[i] / pb[i]
            pc[t] = pc.get(t, 0) | (1 << i)
        if qa[i]:
            t = qb[i] / qa[i]
            qc[t] = qc.get(t, 0) | (1 << i)
    ratios = {F(0), F(1), F(-1)} | pc.keys() | qc.keys()
    result = [(None, pmb, qma)]
    for t in ratios:
        if abs(t.numerator) > 64 or t.denominator > 64:
            continue
        if t == 0:
            pm, qm = pma, qmb
        else:
            pm = (pma | pmb) & ~pc.get(t, 0)
            qm = (qma | qmb) & ~qc.get(t, 0)
        result.append((t, pm, qm))
    return result


def change(pa, pb, qa, qb, t, s):
    if t is None:
        # Swap the new directions, reducing to the finite/infinite case.
        ppb, ppa, qqb, qqa = change(pa, pb, qa, qb, s, None)
        return ppa, ppb, qqa, qqb
    if s is None:
        return ([a + t*b for a,b in zip(pa,pb)], pb[:], qa[:],
                [b - t*a for a,b in zip(qa,qb)])
    return ([a+t*b for a,b in zip(pa,pb)],
            [a+s*b for a,b in zip(pa,pb)],
            [(s*a-b)/(s-t) for a,b in zip(qa,qb)],
            [(b-t*a)/(s-t) for a,b in zip(qa,qb)])


def search(P0, Q0, rng, steps, active_pairs, temperature, barrier):
    P, Q = [x[:] for x in P0], [x[:] for x in Q0]
    normalize(P,Q)
    ranks, pm, qm = d.profiles(P,Q)
    current = sum(d.PRICE[r] for r in ranks)
    best = current, [p[:] for p in P], [q[:] for q in Q], [], ranks[:]
    moves = []
    proposals = 0
    visited = Counter()
    for step in range(steps):
        pairs = list(combinations(range(len(P)),2))
        rng.shuffle(pairs)
        choices = []
        for a,b in pairs[:active_pairs]:
            directions = dual_directions(P[a],P[b],Q[a],Q[b],pm[a],pm[b],qm[a],qm[b])
            for (t,pt,qt),(s,ps,qs) in combinations(directions,2):
                ra,rb = d.cost(pt,qs),d.cost(ps,qt)
                price = current-d.PRICE[ranks[a]]-d.PRICE[ranks[b]]+d.PRICE[ra]+d.PRICE[rb]
                if price > best[0]+barrier:
                    continue
                # Prefer fewer positive query terms before support size.
                positive = (ra>0)+(rb>0)-(ranks[a]>0)-(ranks[b]>0)
                size = pt.bit_count()+ps.bit_count()+qt.bit_count()+qs.bit_count()
                key = a,b,pt,ps,qs,qt
                choices.append((price,positive,size,visited[key],a,b,t,s,pt,ps,qs,qt,ra,rb,key))
                proposals += 1
        if not choices:
            break
        choices.sort(key=lambda z:(round(z[0],10),z[3],z[1],z[2]))
        if rng.random()<temperature:
            near=[z for z in choices if z[0]<=best[0]+barrier]
            # Rank-zero directions are useful outside-code freedom, so retain
            # some broader exploration instead of only sparsifying them away.
            chosen=rng.choice(near[:max(80,len(near)//3)])
        else:
            tied=[z for z in choices if abs(z[0]-choices[0][0])<1e-9 and z[3]==choices[0][3]]
            chosen=rng.choice(tied[:80])
        price,positive,size,seen,a,b,t,s,pt,ps,qt,qs,ra,rb,key=chosen
        pa,pb,qa,qb=change(P[a],P[b],Q[a],Q[b],t,s)
        assert [d.mask(pa),d.mask(pb),d.mask(qa),d.mask(qb)] == [pt,ps,qt,qs]
        P[a],P[b],Q[a],Q[b]=pa,pb,qa,qb
        normalize(P,Q)
        pm[a],pm[b],qm[a],qm[b]=pt,ps,qt,qs
        ranks[a],ranks[b]=ra,rb
        current=price
        moves.append([a,b,str(t),str(s)])
        visited[key]+=1
        if current<best[0]-1e-9:
            best=current,[p[:] for p in P],[q[:] for q in Q],moves[:],ranks[:]
        if current<d.BASELINE-1e-9:
            break
    return best,proposals


def anchor_seed(kind, rng, sample):
    k,l = rng.sample(range(8),2)
    a,b = rng.sample(range(d.N),2)
    def delta(i):
        return [F(j==i) for j in range(d.N)]
    def cut(mode,anchor):
        return [v if not ((q&d.q[anchor]).bit_count()&1) else F(0)
                for v,q in zip(d.CP[mode],d.q)]
    if kind == '21':
        ff=delta(a)
        if sample%3==0:
            es=[cut(k,a),cut(l,a)]
        elif sample%3==1:
            choices=[i for i in range(d.N) if not ((d.q[i]&d.q[a]).bit_count()&1)]
            c,e=rng.sample(choices,2)
            es=[delta(c),delta(e)]
        else:
            es=[cut(k,a),[x+y for x,y in zip(cut(k,a),cut(l,a))]]
        P=[p[:] for p in d.CP]+[es[0],es[1],[x+y for x,y in zip(*es)]]
        Q=[p[:] for p in d.CP]+[[-x for x in ff],[-x for x in ff],ff]
    else:
        es=[cut(k,a),cut(l,b)]
        fs=[delta(a),delta(b)]
        P=[p[:] for p in d.CP]+[es[0],es[1],es[0][:],es[1][:]]
        Q=[p[:] for p in d.CP]+[fs[0],fs[1],[-x for x in fs[0]],[-x for x in fs[1]]]
    if sample%2:
        P,Q=Q,P
    assert sum(d.profiles(P,Q)[0])==64
    return P,Q,{'kind':'exact cancelling free rectangles','dimensions':kind,
                'sample':sample,'modes':[k,l],'anchors':[a,b]}


def profile_census():
    baseline=d.exact_moment([8]*8)
    out={}
    for terms in range(8,13):
        good=[]
        for ranks in combinations_with_replacement(range(1,10),terms):
            if sum(ranks)==64 and sum(d.PRICE[r] for r in ranks)<d.BASELINE-1e-10:
                difference=baseline-d.exact_moment(ranks)
                good.append({'ranks':ranks,'moment_improvement':str(difference)})
        out[str(terms)]=good
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seeds',type=int,default=40)
    ap.add_argument('--steps',type=int,default=160)
    ap.add_argument('--pairs',type=int,default=28)
    ap.add_argument('--temperature',type=float,default=.25)
    ap.add_argument('--barrier',type=float,default=4.1)
    ap.add_argument('--seed',type=int,default=20261024)
    args=ap.parse_args()
    rng=random.Random(args.seed);start=time.monotonic()
    seeds=[]
    for kr,kc in [(2,1),(2,2)]:
        z=d.root_swap_seed(kr,kc)
        if z:seeds.append(z)
    for j in range(args.seeds):
        seeds.append(anchor_seed('21' if j%2==0 else '22',rng,j))
    retained=[];total=0
    for i,(P,Q,meta) in enumerate(seeds):
        best,count=search(P,Q,rng,args.steps,args.pairs,args.temperature,args.barrier)
        total+=count
        price,PP,QQ,moves,ranks=best
        receipt=d.snapshot(PP,QQ,{**meta,'accepted_GL2_moves':moves})
        retained.append(receipt)
        print('PAIR_SEARCH',i,'rank_profile',ranks,'outside',receipt['outside_dimensions'],
              'gain',receipt['improvement'],'tested',count,
              'seconds',round(time.monotonic()-start,2),flush=True)
        if price<d.BASELINE-1e-9:
            break
    retained.sort(key=lambda x:Decimal(x['moment']))
    out={'status':'EXACT_TWO_COLUMN_GAUGE_PROBE','parameters':vars(args),
         'source_sha256':sha256(d.PORTS.read_bytes()).hexdigest(),
         'candidate_pair_basis_changes_priced':total,'retained':retained,
         'best':retained[0],'elapsed_seconds':time.monotonic()-start,
         'scope':'Finite rational exact 11/12-term search, all retained products checked entrywise. No floor and no physical supplier claim.'}
    target=d.HERE/f'DECODER-PAIR-GAUGE-S{args.seed}.json'
    target.write_text(json.dumps(out,indent=2)+'\n')
    print('RECEIPT',target,flush=True)


if __name__=='__main__':
    main()
