#!/usr/bin/env python3
"""Changed one-sided supplier on selected independent Y inputs.

Only the declared Y coordinates and helpers are arbitrary originals.  Other
Y coordinates and all X coordinates are explicitly owned zeros.  A selected
full-column-rank row submatrix of A supplies exactly one rank9 output per
independent Y input.  All helper outputs are included, with padding to the
minimum target rank needed for recursive separation.
"""
from collections import Counter, defaultdict
from decimal import Decimal as D, localcontext
from fractions import Fraction as Q
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import gzip
import json
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from review_owned_zero_closure import replay


PRIME = 2147483647


class ModBasis:
    def __init__(self):
        self.rows = {}

    def reduce(self, values):
        row = [int(x) % PRIME for x in values]
        for pivot, basis in sorted(self.rows.items()):
            a = row[pivot]
            if a:
                row = [(x - a * y) % PRIME for x, y in zip(row, basis)]
        return row

    def insert(self, row):
        pivot = next(i for i, value in enumerate(row) if value)
        inverse = pow(row[pivot], PRIME - 2, PRIME)
        self.rows[pivot] = [value * inverse % PRIME for value in row]


def main():
    started = time.monotonic()
    source = ROOT / 'research/retained_state_next/F9-SOURCE-DAG-ALL8-WORD.json.gz'
    raw = source.read_bytes()
    blob = json.loads(gzip.decompress(raw))
    canonical = blob['canonical']
    rows, nodes, state = replay(blob, range(224, 632))
    rpath = ROOT / 'research/tensor_obstruction/inputs/R.json'
    R = [[Q(x) for x in row] for row in json.loads(rpath.read_text())]
    assert all(x.denominator == 1 for row in R for x in row)
    R = [[int(x) for x in row] for row in R]
    A4 = [[4 * int(i == j) - sum(r[i] * r[j] for r in R) for j in range(112)]
          for i in range(112)]
    assert all(rows[i] == {(112 + j, ()): -Q(A4[i][j], 4) for j in range(112) if A4[i][j]}
               for i in range(112))
    assert all(rows[i] == {(i, ()): Q(1)} for i in range(112, 632))

    query_id = {}
    rank_masks = defaultdict(int)
    for node, metadata in enumerate(nodes):
        event = metadata['event']
        if event and event[0] == 'climb':
            qid = len(query_id)
            query_id[node] = qid
            rank_masks[event[-1]] |= 1 << qid
    query_rank = [0] * len(query_id)
    for node, qid in query_id.items():
        query_rank[qid] = nodes[node]['event'][-1]

    helper_profile = Counter(len(canonical['frames'][canonical['final'][h]]) -
                             len(canonical['frames'][canonical['start'][h]])
                             for h in range(224, 632))
    assert helper_profile == Counter({4: 28, 7: 7, 8: 47, 9: 326})
    helper_mask = ((1 << 408) - 1) << 112
    cases = [('empty', [])]
    cases += [(f'singleton_{i}', [i]) for i in range(112)]
    support_classes = defaultdict(list)
    for i in range(112):
        support_classes[sum((int(bool(R[k][i])) << k) for k in range(8))].append(i)
    assert len(support_classes) == 14 and all(len(group) == 8 for group in support_classes.values())
    cases += [(f'support_class_{mask}', group) for mask, group in sorted(support_classes.items())]
    cases += [(f'root_mode_support_{k}', [i for i in range(112) if R[k][i]]) for k in range(8)]
    cases += [(f'prefix_{size}', list(range(size))) for size in (2, 4, 8, 16, 32, 64, 112)]
    unique = {}
    for label, subset in cases:
        unique.setdefault(tuple(subset), label)
    cases = [(label, list(subset)) for subset, label in unique.items()]
    within_class = '--within-class60' in sys.argv
    policies = ('all_helpers', 'owned_zero_helpers')
    output_stem = 'SUBSET-Y-PORTFOLIO'
    if within_class:
        cases = [(f'class60_subset_{size}_{index}', list(subset))
                 for size in range(9)
                 for index, subset in enumerate(combinations(support_classes[60], size))]
        policies = ('owned_zero_helpers',)
        output_stem = 'SUBSET-Y-CLASS60-SUBSETS'

    with localcontext() as context:
        context.prec = 70
        exponent = D(1) - D('0.0030217758')
        tariff = {r: D(r)**exponent for r in range(1, 10)}
        float_tariff = {r: float(v) for r, v in tariff.items()}
        def bit_profile(bits):
            return Counter({rank: (bits & mask).bit_count() for rank, mask in rank_masks.items()
                            if bits & mask})
        def bit_cost(bits):
            return sum(float_tariff[rank] * (bits & mask).bit_count() for rank, mask in rank_masks.items())
        records = []
        for helper_policy in policies:
            active_helpers = helper_mask if helper_policy == 'all_helpers' else 0
            active_helper_owners = list(range(224, 632)) if active_helpers else []
            for label, subset in cases:
                mask = active_helpers | sum(1 << i for i in subset)
                query_sets = [0] * len(nodes)
                for node, metadata in enumerate(nodes):
                    if not metadata['support'] & mask:
                        continue
                    value = 0
                    for predecessor in metadata['deps']:
                        value |= query_sets[predecessor]
                    if node in query_id:
                        value |= 1 << query_id[node]
                    query_sets[node] = value
                base = 0
                for helper in active_helper_owners:
                    base |= query_sets[state[helper]]
                endpoint_q = [query_sets[state[i]] for i in range(112)]
                basis = ModBasis()
                selected = []
                chosen_queries = base
                # Greedy query-union row basis. Modular nonzero pivots are
                # exact rational independence certificates for integer A4.
                # The choice is heuristic; its resulting invoice is exact.
                pending = set(range(112))
                reduced_rows = {output: [A4[output][i] % PRIME for i in subset] for output in pending}
                for _ in subset:
                    candidates = []
                    for output in pending:
                        reduced = reduced_rows[output]
                        if any(reduced):
                            extra = endpoint_q[output] & ~chosen_queries
                            candidates.append((bit_cost(extra), output, reduced))
                    assert candidates
                    _, output, reduced = min(candidates, key=lambda x: (x[0], x[1]))
                    basis.insert(reduced)
                    selected.append(output)
                    pending.remove(output)
                    chosen_queries |= endpoint_q[output]
                    pivot = next(i for i, value in enumerate(reduced) if value)
                    new_basis_row = basis.rows[pivot]
                    for other in pending:
                        a = reduced_rows[other][pivot]
                        if a:
                            reduced_rows[other] = [(x - a * y) % PRIME for x, y in zip(reduced_rows[other], new_basis_row)]
                assert len(selected) == len(subset) == len(basis.rows)
                paid = bit_profile(chosen_queries)
                targets = Counter({9: len(subset)}) if subset else Counter()
                if active_helpers:
                    for rank, count in helper_profile.items():
                        targets[max(6, rank)] += count
                        if rank < 6:
                            paid[6 - rank] += count
                if targets:
                    assert max(paid) < min(targets)
                credit = sum(tariff[rank] * count for rank, count in targets.items())
                cost = sum(tariff[rank] * count for rank, count in paid.items())
                first = sum(rank * count for rank, count in targets.items()) - sum(rank * count for rank, count in paid.items())
                full_x_bits = base
                for bits in endpoint_q:
                    full_x_bits |= bits
                records.append({'label': label, 'helper_policy': helper_policy,
                                'independent_Y_ports': subset, 'independent_Y_input_count': len(subset),
                                'independent_helper_count': len(active_helper_owners),
                                'selected_X_output_rows': selected,
                                'decoder_minor_rank_mod_prime': len(basis.rows), 'decoder_prime': PRIME,
                                'decoder_formula': 'Y_transformed=−4*(A4[J,S])^-1 * raw_X[J]; all selected raw X have common conjugate(F9) frame.',
                                'paid_profile_including_helper_padding': dict(sorted(paid.items())),
                                'productive_target_profile': dict(sorted(targets.items())),
                                'first_mass_margin': first, 'moment_margin': str(credit - cost),
                                'full_X_decoder_extra_query_profile': dict(sorted(bit_profile(full_x_bits & ~chosen_queries).items())),
                                'selected_query_count_before_padding': chosen_queries.bit_count(),
                                'selected_query_ids': [i for i in range(len(query_rank)) if chosen_queries >> i & 1]})
            ranked = sorted(records, key=lambda r: D(r['moment_margin']), reverse=True)
            print('SUBSET_POLICY', helper_policy, 'cases', len(cases), 'best',
                  [(r['label'], r['helper_policy'], r['moment_margin']) for r in ranked[:5]], flush=True)

    nonempty = [r for r in records if r['independent_Y_input_count'] or r['independent_helper_count']]
    best = sorted(nonempty, key=lambda r: D(r['moment_margin']), reverse=True)[:12]
    receipt = {'schema': 'selected-independent-Y-recursive-portfolio/v1',
               'status': 'EXACT_SPECIALIZED_ENDPOINT_AND_QUERY_LIVENESS; ROW_BASIS_CHOICE_HEURISTIC',
               'source_sha256': sha256(raw).hexdigest(), 'R_sha256': sha256(rpath.read_bytes()).hexdigest(),
               'original_independence': 'Each selected Y port and each retained helper is one arbitrary independent input. All X and every unselected Y/helper port are declared owned zeros. No original arbitrary owner is silently discarded. The output decoder credits one Gaussian transform per selected Y, never112 outputs for a lower-dimensional input.',
               'endpoint': 'With owned-zero X and filtered tail omitted, every raw X output is conjugate(F9)*(−A Y), A=I−R^T R/4. A row minor of full column rank gives exactly the selected independent F9^-1 jobs by ordinary rational decoding.',
               'query_liveness': 'Exact free-word support specialization and SSA predecessor closure. A known exact zero is materialized independently as zero. Helper final outputs are always demanded when arbitrary. Alternative X row bases are chosen greedily by added query moment; no optimality claim.',
               'recursive_separation': 'All native children have rank<=5. Rank4 helper outputs are padded to rank6 with28 additional rank2 jobs; other helper ranks7,8,9 and selected Y rank9 remain. Thus maximum child5<minimum productive target6 when helpers are retained, or9 without helpers.',
               'subsets_per_helper_policy': len(cases), 'policies': list(policies),
               'query_id_to_node_event_rank': [[node, nodes[node]['index'], nodes[node]['event'][-1]] for node in sorted(query_id, key=query_id.get)],
               'best_nonempty_portfolios': best,
               'positive_candidate_count': sum(D(r['moment_margin']) > 0 for r in nonempty),
               'records': records,
               'scope': ('All256 subsets of the eight-port support class60, with owned-zero helpers; greedy independent output row bases.' if within_class else 'All112 singletons; all14 eight-port source-support classes; all8 root-mode supports; a short prefix menu; all helpers or owned-zero helpers.') + ' Does not optimize all2^112 Y subsets, helper subsets simultaneously, or all row-basis choices. Positive candidates require literal owned schedule and decoder emission.',
               'new_kappa_claimed': False, 'elapsed_seconds': time.monotonic() - started}
    packed = gzip.compress(json.dumps(receipt, separators=(',', ':')).encode(), mtime=0)
    (HERE / (output_stem + '.json.gz')).write_bytes(packed)
    summary = {key: value for key, value in receipt.items() if key not in ('records', 'query_id_to_node_event_rank')}
    summary['best_nonempty_portfolios'] = [{k: v for k, v in r.items() if k != 'selected_query_ids'} for r in best]
    summary['complete_receipt_sha256'] = sha256(packed).hexdigest()
    (HERE / (output_stem + '.json')).write_text(json.dumps(summary, indent=2) + '\n')
    print('DONE', summary['positive_candidate_count'], summary['elapsed_seconds'], flush=True)


if __name__ == '__main__':
    main()
