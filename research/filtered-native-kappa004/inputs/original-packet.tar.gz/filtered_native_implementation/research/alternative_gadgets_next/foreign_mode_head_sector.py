#!/usr/bin/env python3
"""Exact limits of the new source-chart mode head on the actual p3 caller.

The paid primitive itself is retained.  This receipt checks a necessary
width-two sector and a concrete companion-chart counterexample.  It does
not search new controllers or exclude general finite feedback.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys
import time

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OTHER = ROOT / 'research/operator_alignment_next'
sys.path.insert(0, str(OTHER))
import cross_stage_projector_span as cs
import actual_tangent_reachability as ar


def rank2(vectors):
    basis = {}
    for x in vectors:
        while x:
            k = x.bit_length() - 1
            if k in basis:
                x ^= basis[k]
            else:
                basis[k] = x
                break
    return len(basis)


def sign_samples(physical, ports):
    i, j = 4, 5
    qi, qj = ports[i]['q'], ports[j]['q']
    assert (qi, qj) == (131, 259)
    # The extra constraint w0=0 does not identify any of the three signs.
    assert rank2([1, qi, qj, 511]) == 4
    samples, counts = {}, Counter()
    for w in range(0, 512, 2):
        bits = ((1 + (w & qi).bit_count()) % 2,
                (1 + (w & qj).bit_count()) % 2, w.bit_count() % 2)
        wi, wj = physical.inverse[i][w], physical.inverse[j][w]
        if (wi ^ wj) & 510:
            samples.setdefault(bits, w)
            counts[bits] += 1
    assert len(samples) == 8
    records = []
    for bits, w in sorted(samples.items()):
        wi, wj = physical.inverse[i][w], physical.inverse[j][w]
        assert (wi & 1, wj & 1, wi.bit_count() % 2) == bits
        assert wj.bit_count() % 2 == bits[2]
        records.append({
            'sign_bits_Q_output_Q_input_zeta': list(bits),
            'common_K_frequency': w,
            'mode_head_eigenvalue': 1,
            'physical_output_frequency': wi,
            'physical_input_frequency': wj,
            'source_private_coordinate_difference': (wi ^ wj) & 510,
            'available_representative_count': counts[bits],
        })
    patterns = sorted(samples)
    walsh = [[(-1) ** sum(a*b for a, b in zip(bits, mask))
              for mask in patterns] for bits in patterns]
    det = cs.determinant(walsh)
    assert abs(det) == 2**12

    def embedded(stage, owner, freq, inverse=False):
        table = physical.inverse if inverse else physical.forward
        shift = 8 * stage
        local = (freq & 1) | ((freq >> shift) & 510)
        value = table[owner][local]
        mask = 1 | (510 << shift)
        return (freq & ~mask) | (value & 1) | ((value & 510) << shift)

    graph_checks = 0
    for sample in records:
        for external in range(64):
            tail = sum(((external >> (t-1)) & 1) << (1+8*t)
                       for t in range(1, 7))
            start = sample['physical_input_frequency'] | tail
            finish = sample['physical_output_frequency'] | tail
            assert embedded(0, i, embedded(0, j, start), True) == finish
            assert start != finish
            for other in range(1, 7):
                image = embedded(other, i, embedded(other, j, start), True)
                assert (image & 510) == (start & 510)
                assert image != finish
                graph_checks += 1
    return {
        'fixed_owner_pair': [i, j],
        'rank_over_F2_of_masks_1_qi_qj_511': 4,
        'common_frequency_parity_constraint': 'w & 1 = 0',
        'samples': records,
        'three_sign_Walsh_integer_determinant': str(det),
        'external_sign_count': 64,
        'all_source_and_external_sign_choices': 512,
        'other_stage_chart_graph_separation_checks': graph_checks,
        'external_realization': 'Choose equal Fourier frequencies in each of the six fresh eight-axis blocks independently. Their D_t signs are independent; no external stage is set to the identity.',
    }


def balanced_sector(R, ports):
    qs = [p['q'] for p in ports]
    frequencies, qvals = [], {}
    for w in range(0, 512, 2):
        q = np.array([(-1) ** (1 + (w & qi).bit_count())
                      for qi in qs], dtype=np.int64)
        if not np.any((R * q) @ R.T):
            frequencies.append(w)
            qvals[w] = q
    assert frequencies == [128, 158, 170, 180, 204, 210, 230, 248,
                           256, 286, 298, 308, 332, 338, 358, 376]
    certificates = []
    prime = 65521
    for modes in ([5], list(range(8))):
        rr = R[modes].T @ R[modes]
        assert np.array_equal(rr @ rr, 56 * rr)
        basis, rows, samples = {}, [], []
        for w in frequencies:
            q = qvals[w]
            assert not np.any((rr * q) @ rr)
            zeta = (-1) ** w.bit_count()
            for i in range(112):
                for j in range(112):
                    values = [4 * int(i == j), 4 * int(i == j) * q[i]]
                    values += [-rr[i, j] * q[i]**a * q[j]**b
                               for a in (0, 1) for b in (0, 1)]
                    values = [int(x) for x in values + [zeta*x for x in values]]
                    v = [x % prime for x in values]
                    for k, b in sorted(basis.items()):
                        c = v[k]
                        if c:
                            v = [(x-c*y) % prime for x, y in zip(v, b)]
                    k = next((k for k, x in enumerate(v) if x), None)
                    if k is not None:
                        inv = pow(v[k], -1, prime)
                        basis[k] = [x*inv % prime for x in v]
                        rows.append(values)
                        samples.append([w, i, j])
                    if len(rows) == 12:
                        break
                if len(rows) == 12:
                    break
            if len(rows) == 12:
                break
        assert len(rows) == 12
        det = cs.determinant(rows)
        assert det
        certificates.append({
            'source_modes': modes,
            'functions': ['I', 'Q', 'P', 'PQ', 'QP', 'QPQ'],
            'each_function_also_multiplied_by_zeta': True,
            'function_count': 12,
            'rank': 12,
            'integer_matrix_scale': 4,
            'samples_w_output_owner_input_owner': samples,
            'integer_minor': rows,
            'exact_integer_minor_determinant': str(det),
        })
    return {
        'even_balanced_frequencies': frequencies,
        'all_16_times_64_RQR_entries_checked_zero': True,
        'mode_head_eigenvalue_at_every_frequency': 1,
        'identities': ['Q_global^2=I', 'D0=zeta Q_global',
                       'P^2=-14P', 'P Q_global P=0',
                       'J_plus=J_minus=-P', 'H_k-I=0'],
        'independence_certificates': certificates,
        'scope': 'An actual width-two necessary sector. These minors certify operator-function independence; they do not by themselves exclude arbitrary finite control circuits.',
    }


def companion_range_check(R, ports, physical):
    w = 128
    q = np.array([(-1) ** (1 + (w & p['q']).bit_count())
                  for p in ports], dtype=np.int64)
    zeta = (-1) ** w.bit_count()
    v = R[5].copy()
    qv = q*v
    assert zeta == -1 and w & 1 == 0
    assert int(v @ v) == 56 and int(v @ qv) == 0
    assert not np.any((R*q) @ R.T)
    records = []
    for modes in ([5], list(range(8))):
        rr = R[modes].T @ R[modes]
        assert np.array_equal(rr @ v, 56*v)
        assert not np.any(rr @ qv)
        assert not np.any((rr*q) @ rr)
        C4 = 4*np.eye(112, dtype=np.int64) - rr
        # On this sector Q^-1=Q, D=zeta Q and every H_k=I.
        # The first role input is v and the second role input is zero.
        actual4 = zeta*q*(C4 @ qv)       # 4 D C Q^-1 v
        target4 = C4 @ (zeta*qv)        # 4 C D v
        assert np.array_equal(actual4, 4*zeta*v)
        assert np.array_equal(target4, 4*zeta*qv)
        assert not np.array_equal(actual4, target4)
        assert np.array_equal(q*actual4, target4)
        difference2 = F(int((actual4-target4) @ (actual4-target4)), 16)
        assert difference2 == 112
        # Both lower-role outputs vanish: Dv is in the complementary code space.
        lower16 = (16*np.eye(112, dtype=np.int64)-C4@C4) @ (zeta*qv)
        assert not np.any(lower16)
        records.append({
            'source_modes': modes,
            'Pi_v_equals_v': True,
            'Pi_Qglobal_v_equals_zero': True,
            'Qglobal_v_norm_squared': 56,
            'Pi_Qglobal_Pi_equals_zero': True,
            'input_mode_norm_squared': 56,
            'global_Q_range_leakage_fraction': '1',
            'all_same_chart_H_k_act_as_identity': True,
            'partial_chart_upper_output': 'zeta v',
            'required_upper_output': 'zeta Q_global v',
            'upper_output_difference_norm_squared': str(difference2),
            'both_lower_role_outputs_zero': True,
            'true_global_Q_left_chart_repairs_this_input': True,
        })
    return {
        'common_K_frequency': w,
        'width': 2,
        'both_digit_columns_have_identical_frequency': True,
        'mode_head_eigenvalue': 1,
        'zeta': zeta,
        'owner_vector': [int(x) for x in v],
        'global_Q_owner_signs': [int(x) for x in q],
        'physical_owner_frequencies': [physical.inverse[i][w] for i in range(112)],
        'physical_edge': 'E=[[D C Q^-1,D],[(I-C^2)D,-Q D C]]',
        'actual_role_chart_identity': 'diag(Q,I) E diag(I,Q^-1) = [[C,I],[I-C^2,-C]] diag(D,D)',
        'proposed_substitution': 'Replace the two global Q role charts by same-source partial mode heads, powers, or products of H_k.',
        'results': records,
        'conclusion': 'The proposed direct substitution fails on an exact physical input. The global head carries the selected mode entirely outside its code range, while all the proposed same-chart partial heads are identity on this sector.',
        'not_claimed': 'No exclusion of intervening new ordinary address maps, different source charts, arbitrary redesigned controllers, or additional paid transforms.',
    }


def tangent_check(R, source, prior):
    _, prefix, suffix = ar.ac.source_matrices(source)
    d = (1, 1, 0, 0, 0, 0)
    weight = {(1, 1, (1, 1), 1, d): F(1),
              (4, 1, (0, 1), 1, d): F(1)}

    def evaluate(v):
        return sum((c*weight.get(k, F(0)) for k, c in v.items()), F(0))

    prior_stage = prior['results'][0]
    decoded = {}
    for row in prior_stage['functional']:
        k = (row['output_bank'], row['input_bank'],
             tuple(row['Q_powers_separated_by_P']), row['source_zeta_power'],
             tuple(row['other_stage_sign_powers']))
        decoded[k] = F(row['coefficient'])
    assert decoded == weight
    columns = ar.columns(source, prefix, suffix, 0, True)
    census = Counter()
    checked = 0
    for desc, vector in columns:
        if desc['operator'] != 'P':
            continue
        assert evaluate(vector) == 0
        checked += 1
        census[desc['kind']] += 1
    assert checked == prior_stage['candidate_scalar_M_ij_controls'] == 14347
    error, event = ar.it.tc.target_error(source, prefix, suffix, 0)
    goal = ar.fc.scale(ar.one_p(error, 0, True), -1)
    evaluation = evaluate(goal)
    assert event == 0 and evaluation == -1
    p5 = -F(int(R[5, 4]*R[5, 5]), 4)
    p8 = -F(int(R[:, 4] @ R[:, 5]), 4)
    assert (p5, p8) == (F(1, 4), -F(1, 2))
    transport = ar.stage0_transport_check(source, prefix, suffix)
    return {
        'changed_stage': 0,
        'all_six_original_banks_remain_independent': True,
        'existing_functional_rechecked_without_new_reachability_search': True,
        'chronological_scalar_control_columns_rebuilt_and_annihilated': checked,
        'control_class_census': dict(sorted(census.items())),
        'functional': prior_stage['functional'],
        'normalized_required_correction_evaluation': str(evaluation),
        'source_R5_P_output4_input5': str(p5),
        'all8_P_output4_input5': str(p8),
        'source_R5_required_correction_evaluation': str(evaluation*p5),
        'all8_required_correction_evaluation': str(evaluation*p8),
        'physical_functional': 'Average over the 512 independently realized signs of zeta D1 D2 (q4 q5 T[bank1,input1] + q5 T[bank4,input1]) at owner pair output4,input5.',
        'new_paid_head_restriction': 'Every same-source J0^+ or J0^- is -P0 on the even common-frequency sector, so its first-order insertion is already a tested scalar control column. Every H0,k-I is zero there.',
        'covered_placements': 'Any earlier actual boundary bank cached to any later boundary bank; every authenticated internal transformed source before its opposite input is consumed; those internal sources cached to every later bank. The unaffected original inputs are not identified or set equal.',
        'consequence': 'Adding up to seven, or any fixed number of, these paid heads supplies no new direction in this first-order correction equation. No linear combination of the declared chronological head effects cancels the nonzero required correction.',
        'stage0_exact_transport_deficit': transport,
        'strict_scope': 'First-order chronological reachability around the unchanged actual p3 caller, for same-source mode heads and the stated ordinary chart coefficients. Essential higher-order interactions of finite controls are not excluded.',
    }


def main():
    begin = time.monotonic()
    paths = {
        'R': ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json',
        'normalizers': ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json',
        'controller': ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json',
        'observer': OTHER/'CROSS-STAGE-RANK1-OBSERVER.json',
        'source_cut': OTHER/'CROSS-STAGE-SOURCE-CUT.json',
        'encoded_head': ROOT/'research/retained_state_next/ENCODED-MODE-HEAD.json',
        'tangent': OTHER/'ARBITRARY-OWNER-TANGENT.json',
        'companion': HERE/'CAUSAL-COMPANION-INDEPENDENT-REVIEW.json',
        'sector_dependency': OTHER/'cross_stage_projector_span.py',
        'tangent_dependency': OTHER/'actual_tangent_reachability.py',
        'script': Path(__file__),
    }
    data = {k: json.loads(p.read_text()) for k, p in paths.items() if p.suffix == '.json'}
    R = np.array(data['R'], dtype=np.int64)
    ports = data['normalizers']['ports']
    assert np.array_equal(R @ R.T, 56*np.eye(8, dtype=np.int64))
    assert [int(np.count_nonzero(r)) for r in R] == [56]*8
    physical = cs.Physical(R.tolist(), ports, [5])
    assert data['observer']['all112_absolute_phase_exit_identities_pass']
    assert data['observer']['all112_cross_stage_tableau_identities_pass']
    assert data['source_cut']['all112_native_Y_outputs_exactly_complete']
    assert data['source_cut']['all112_original_X_unread_unchanged']
    assert data['source_cut']['all408_original_helpers_unread_unchanged']
    assert data['encoded_head']['status'] == 'EXACT_LITERAL_PROGRAMS_PASS'
    assert data['companion']['all_original_endpoints_verified']
    signs = sign_samples(physical, ports)
    balanced = balanced_sector(R, ports)
    companion = companion_range_check(R, ports, physical)
    tangent = tangent_check(R, data['controller']['selected_p3_keep43'], data['tangent'])
    result = {
        'schema': 'source-bound-paid-mode-head-sector-and-companion-range/v1',
        'status': 'PASS_EXACT_SCOPED_LIMITS; POSITIVE_MODE_HEAD_IMPLEMENTATION_RETAINED',
        'pins': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest()
                 for p in paths.values()},
        'source_signed_K_frequency_checks': physical.phase_checks,
        'gaussian_phase_convention': 'C=(1+i)I/2+(1-i)X/2. On two identical Fourier columns the common head eigenvalue is (-1)^w0; w even means +1. Caller Q on owner i instead has sign (-1)^(1+w.q_i), including the actual K_i phase offset.',
        'all_width_mode_algebra': {
            'normalized_maps': 'V_k=diag(K^-1) r_k^T; L_k=r_k diag(K)/56; L_k V_l=delta_kl I.',
            'projector': 'Pi_k=V_k L_k; P_k=-14 Pi_k.',
            'encoded_powers': 'E_k^a=V_k Q_mode^a L_k; E_k^a E_k^b=E_k^(a+b), E_k^0=Pi_k, E_k^4=Pi_k.',
            'paid_foreign_head': 'J_k^a=14 E_k^a. On an already available D_t bank, t different from source stage s, this returns J_k^a D_t y.',
            'partial_head': 'H_k=I-Pi_k+E_k^1; H_k^4=I; H_k^2 is ordinary.',
            'covariance': 'Each H_s,k commutes Q_global D_s and every fresh D_t, t!=s. This covariance does not identify H_s,k with global Q on the mode range.',
            'chronological_value': 'The foreign stage exposes a D_t-transformed native source before its opposite input is read. The mode gather and odd head do not by themselves provide D_t applied to an independently retained earlier mode.',
        },
        'one_mode_physical_head_cost': data['encoded_head']['positive_or_inverse_invoice'],
        'source_cut_event': data['source_cut']['after_event'],
        'even_sector_full_sign_certificate': signs,
        'even_balanced_sector': balanced,
        'p3_first_order_sector_check': tangent,
        'companion_partial_head_range_counterexample': companion,
        'retained_original_inputs': 'All six caller main banks are independent. The standalone H primitive preserves all unrelated original/helper banks, and the authenticated source cut leaves original X and all408 helpers unread. No owned snapshot earns productive credit.',
        'what_is_not_excluded': [
            'New callers using essential finite higher-order feedback.',
            'Intervening ordinary coordinate maps outside the declared source charts.',
            'Changed paid FULL/IDLE jobs or different independent target portfolios.',
            'Other useful applications of the implemented order-four partial-mode head.',
        ],
        'new_native_endpoint_claimed': False,
        'new_kappa_claimed': False,
        'elapsed_seconds': time.monotonic()-begin,
    }
    out = HERE/'FOREIGN-MODE-HEAD-SECTOR.json'
    out.write_text(json.dumps(result, indent=2)+'\n')
    print('PASS', out.relative_to(ROOT))
    print('even balanced minors', [c['exact_integer_minor_determinant']
                                   for c in balanced['independence_certificates']])
    print('tangent columns', tangent['chronological_scalar_control_columns_rebuilt_and_annihilated'],
          'goal', tangent['normalized_required_correction_evaluation'])
    print('companion squared mismatch', [x['upper_output_difference_norm_squared']
                                         for x in companion['results']])
    print('seconds', round(result['elapsed_seconds'], 3))


if __name__ == '__main__':
    main()
