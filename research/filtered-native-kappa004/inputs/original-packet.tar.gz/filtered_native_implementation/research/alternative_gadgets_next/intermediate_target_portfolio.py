#!/usr/bin/env python3
"""Optimize clean intermediate target portfolios of the actual source word.

Each original may be credited once, at an earlier clean physical snapshot.
All original inputs remain independent, including originals not selected as
productive jobs.  A retained-input/owned-SSA implementation restores those
borrowed inputs; no unselected original is treated as an owned zero.
"""
from collections import Counter, defaultdict
from decimal import Decimal as D, localcontext
from fractions import Fraction as Q
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from owned_zero_memoization import load_ce


def add(dst, src, scalar):
    assert dst is not src
    for key, value in src.items():
        result = dst.get(key, Q(0)) + scalar * value
        if result:
            dst[key] = result
        else:
            dst.pop(key, None)


class ForwardOperators:
    def __init__(self, ce, canonical):
        self.ce = ce
        self.ops = [ce.ident(9)]
        self.ids = {self.ops[0].tab: 0}
        self.letters = {}
        self.products = {}
        self.frames = {}
        self.transfers = {}
        self.canonical = canonical
        for warp in canonical['warps']:
            matrix = ce.transpose(tuple(warp['G_columns']), 9)
            inverse = ce.inv(matrix, 9)
            columns = ce.transpose(inverse, 9)
            quadratic = tuple((1 << i) ^ sum(ce.parity(a & b) << j for j, b in enumerate(columns))
                              for i, a in enumerate(columns))
            alpha = tuple((quadratic[i] >> i) & 1 for i in range(9))
            operation = ce.perm(9, matrix).then(ce.diag(9, quadratic, alpha))
            assert operation.zero_state() == self.ops[0].zero_state()
            self.letters[warp['op']] = self.intern(operation)
            self.letters[-warp['op']] = self.intern(operation.adjoint())

    def intern(self, operation):
        if operation.tab not in self.ids:
            self.ids[operation.tab] = len(self.ops)
            self.ops.append(operation)
        return self.ids[operation.tab]

    def product(self, left, right):
        key = left, right
        if key not in self.products:
            self.products[key] = self.intern(self.ops[right].then(self.ops[left]))
        return self.products[key]

    def frame(self, frame):
        if frame not in self.frames:
            self.frames[frame] = self.ce.canonical_frame(9, self.canonical['frames'][frame])
        return self.frames[frame]

    def transfer(self, start, current, logical):
        key = start, current, logical
        if key not in self.transfers:
            operation = self.frame(start).adjoint().then(self.ops[logical]).then(self.frame(current))
            rank = self.ce.rank([x for x, z, phase in operation.tab[9:]])
            self.transfers[key] = operation, rank
        return self.transfers[key]


def compile_source(blob, physical):
    canonical = blob['canonical']
    allowed = set(blob['productive_owners'])
    rows = [{(i, 0): Q(1)} for i in range(632)]
    frames = canonical['start'][:]
    nodes = [{'event': None, 'owner': i, 'deps': [], 'query_rank': 0, 'query_bits': 0}
             for i in range(632)]
    state = list(range(632))
    milestones = []
    maxrank = {owner: 0 for owner in allowed}
    owner_milestones = defaultdict(list)
    query_nodes = []
    clean_snapshots = 0
    monotone_query_inclusions = 0
    maxterms = 1
    for pos, event in enumerate(blob['program']):
        typ = event[0]
        paid = 0
        if typ == 'scalar':
            operation, frame = event[1:]
            assert operation[1][0] == 'L'
            destination = operation[1][1]
            assert frames[destination] == frame
            if operation[0] == 'add':
                assert operation[2][0] == 'L'
                source = operation[2][1]
                assert frames[source] == frame
                add(rows[destination], rows[source], Q(operation[3], operation[4]))
                deps = [state[destination], state[source]]
            else:
                assert operation[0] == 'scale'
                scalar = Q(operation[2], operation[3])
                assert scalar
                rows[destination] = {key: scalar * value for key, value in rows[destination].items()}
                deps = [state[destination]]
        elif typ == 'warp':
            assert event[1][0] == 'L'
            destination = event[1][1]
            assert frames[destination] == event[3]
            changed = {}
            for (owner, operation), value in rows[destination].items():
                product = physical.product(physical.letters[event[2]], operation)
                changed[owner, product] = changed.get((owner, product), Q(0)) + value
            rows[destination] = {key: value for key, value in changed.items() if value}
            frames[destination] = event[4]
            deps = [state[destination]]
        elif typ == 'climb':
            destination = event[2]
            assert frames[destination] == event[3]
            frames[destination] = event[4]
            paid = event[-1]
            deps = [state[destination]]
        else:
            assert typ == 'adapter'
            destination = event[2]
            deps = [state[destination]]
        assert destination in allowed and rows[destination]
        node = len(nodes)
        bits = 0
        for ancestor in deps:
            bits |= nodes[ancestor]['query_bits']
        if paid:
            bits |= 1 << len(query_nodes)
            query_nodes.append(node)
        nodes.append({'event': pos, 'owner': destination, 'deps': deps,
                      'query_rank': paid, 'query_bits': bits})
        state[destination] = node
        maxterms = max(maxterms, len(rows[destination]))
        if len(rows[destination]) != 1:
            continue
        (input_owner, logical), coefficient = next(iter(rows[destination].items()))
        if input_owner != destination:
            continue
        clean_snapshots += 1
        operation, rank = physical.transfer(canonical['start'][destination], frames[destination], logical)
        if rank <= maxrank[destination]:
            continue
        previous = owner_milestones[destination][-1] if owner_milestones[destination] else None
        if previous is not None:
            old_bits = nodes[milestones[previous]['node']]['query_bits']
            assert old_bits & ~bits == 0
            monotone_query_inclusions += 1
        milestone = {'owner': destination, 'node': node, 'event': pos,
                     'original_source_event': blob['original_indices'][pos],
                     'rank': rank, 'previous_rank': maxrank[destination],
                     'previous_milestone': previous,
                     'start_frame': canonical['start'][destination],
                     'snapshot_frame': frames[destination], 'logical_operator_id': logical,
                     'logical_scalar': str(coefficient),
                     'transfer_tableau': [list(row) for row in operation.tab]}
        owner_milestones[destination].append(len(milestones))
        milestones.append(milestone)
        maxrank[destination] = rank
    assert all(row == {(i, 0): Q(1)} for i, row in enumerate(rows))
    assert all(frames[i] == canonical['final'][i] for i in allowed)
    return {'nodes': nodes, 'milestones': milestones, 'state': state,
            'owner_milestones': dict(owner_milestones), 'query_nodes': query_nodes,
            'clean_same_owner_snapshots': clean_snapshots,
            'monotone_query_inclusions_checked': monotone_query_inclusions,
            'max_logical_row_terms': maxterms}


def split(rank, maximum):
    result = Counter()
    if rank:
        copies, tail = divmod(rank, maximum)
        if copies:
            result[maximum] += copies
        if tail:
            result[tail] += 1
    return result


@lru_cache(None)
def exact_power_interval(rank, ctext):
    """Rational enclosure for rank^(1-c), rank<=10, without a float oracle."""
    if rank == 0:
        return Q(0), Q(0)
    c = Q(ctext)
    if c == 0 or rank == 1:
        return Q(rank), Q(rank)
    z = Q(rank - 1, rank + 1)
    zsquare = z * z
    term = z
    log_lower = Q(0)
    terms = 96
    for k in range(terms):
        log_lower += 2 * term / (2 * k + 1)
        term *= zsquare
    # Positive atanh series; every remaining denominator is>=2terms+1.
    log_upper = log_lower + 2 * term / ((2 * terms + 1) * (1 - zsquare))
    def exp_partial_negative(value, degree):
        assert 0 <= value < 1
        total = term = Q(1)
        for j in range(1, degree + 1):
            term *= -value / j
            total += term
        return total
    lower = rank * exp_partial_negative(c * log_upper, 13)
    upper = rank * exp_partial_negative(c * log_lower, 12)
    assert 0 < lower <= upper and upper - lower < Q(1, 10**15)
    return lower, upper


def optimize(data, minimum, ctext, rounding='consistent', scale=100000):
    import numpy as np
    from scipy.sparse import csr_matrix
    from scipy.sparse.csgraph import maximum_flow, breadth_first_order
    nodes, milestones = data['nodes'], data['milestones']
    with localcontext() as context:
        context.prec = 70
        exponent = D(1) - D(ctext)
        tariff = {rank: D(rank)**exponent for rank in range(1, max(10, minimum + 1))}
        tariff[0] = D(0)
        # Padding a clean rank-r target to minimum requires an explicitly
        # paid Gaussian job on fresh disjoint coordinates, on that same
        # independent array. It supplies no extra independent input.
        def credit(rank):
            return tariff[max(rank, minimum)] - tariff[max(0, minimum - rank)] if rank else D(0)
        querycost = {}
        for node in data['query_nodes']:
            querycost[node] = sum(count * tariff[r] for r, count in split(nodes[node]['query_rank'], minimum - 1).items())
        increments = [credit(m['rank']) - credit(m['previous_rank']) for m in milestones]
        assert min(increments) > 0
        if rounding == 'upper':
            intervals = {r: exact_power_interval(r, ctext) for r in tariff}
            def credit_interval(rank):
                if not rank:
                    return Q(0), Q(0)
                target = intervals[max(rank, minimum)]
                complement = intervals[max(0, minimum - rank)]
                return target[0] - complement[1], target[1] - complement[0]
            profits = []
            for milestone in milestones:
                upper_increment = credit_interval(milestone['rank'])[1] - credit_interval(milestone['previous_rank'])[0]
                value = scale * upper_increment
                profits.append(-((-value.numerator) // value.denominator))
            costs = {}
            for node in data['query_nodes']:
                lower_cost = sum(count * intervals[r][0]
                                 for r, count in split(nodes[node]['query_rank'], minimum - 1).items())
                value = scale * lower_cost
                costs[node] = value.numerator // value.denominator
        else:
            inttariff = {r: int((x * scale).to_integral_value(rounding='ROUND_FLOOR')) for r, x in tariff.items()}
            def intcredit(rank):
                return inttariff[max(rank, minimum)] - inttariff[max(0, minimum - rank)] if rank else 0
            profits = [intcredit(m['rank']) - intcredit(m['previous_rank']) for m in milestones]
            costs = {node: sum(count * inttariff[r] for r, count in split(nodes[node]['query_rank'], minimum - 1).items())
                     for node in data['query_nodes']}
        source = 0
        nodeoffset = 1
        milestoneoffset = nodeoffset + len(nodes)
        sink = milestoneoffset + len(milestones)
        infinite = sum(profits) + 1
        assert infinite < 2**31
        edges = []
        for index, profit in enumerate(profits):
            vertex = milestoneoffset + index
            edges.append((source, vertex, profit))
            edges.append((vertex, nodeoffset + milestones[index]['node'], infinite))
            previous = milestones[index]['previous_milestone']
            if previous is not None:
                edges.append((vertex, milestoneoffset + previous, infinite))
        for index, node in enumerate(nodes):
            if index in costs:
                edges.append((nodeoffset + index, sink, costs[index]))
            for predecessor in node['deps']:
                assert predecessor < index
                edges.append((nodeoffset + index, nodeoffset + predecessor, infinite))
        row = np.asarray([x[0] for x in edges], dtype=np.int32)
        col = np.asarray([x[1] for x in edges], dtype=np.int32)
        weights = np.asarray([x[2] for x in edges], dtype=np.int64)
        graph = csr_matrix((weights, (row, col)), shape=(sink + 1, sink + 1))
        flow = maximum_flow(graph, source, sink, method='dinic')
        assert (flow.flow + flow.flow.T).nnz == 0
        balance = np.asarray(flow.flow.sum(axis=1)).ravel()
        assert balance[source] == flow.flow_value and balance[sink] == -flow.flow_value
        assert not np.any(balance[1:sink])
        residual = graph - flow.flow
        assert np.all(residual.data >= 0)
        residual.data = (residual.data > 0).astype(np.int8)
        residual.eliminate_zeros()
        reached = set(map(int, breadth_first_order(residual, source, directed=True, return_predecessors=False)))
        assert sink not in reached
        cut = sum(weight for u, v, weight in edges if u in reached and v not in reached)
        assert cut == flow.flow_value
        selected_indices = [i for i in range(len(milestones)) if milestoneoffset + i in reached]
        chosen = {}
        for i in selected_indices:
            m = milestones[i]
            if m['owner'] not in chosen or m['rank'] > milestones[chosen[m['owner']]]['rank']:
                chosen[m['owner']] = i
        needed = set()
        todo = [milestones[i]['node'] for i in chosen.values()]
        while todo:
            node = todo.pop()
            if node in needed:
                continue
            needed.add(node)
            todo.extend(nodes[node]['deps'])
        paid = Counter()
        for node in needed:
            paid.update(split(nodes[node]['query_rank'], minimum - 1))
        targets = Counter()
        native_snapshot_targets = Counter()
        for owner, i in chosen.items():
            rank = milestones[i]['rank']
            native_snapshot_targets[rank] += 1
            targets[max(rank, minimum)] += 1
            paid.update(split(max(0, minimum - rank), minimum - 1))
        margin = sum(count * tariff[rank] for rank, count in targets.items()) - sum(
            count * tariff[rank] for rank, count in paid.items())
        first = sum(rank * count for rank, count in targets.items()) - sum(rank * count for rank, count in paid.items())
        integer_gain = sum(profits) - int(flow.flow_value)
        proof_upper = D(integer_gain) / scale if rounding == 'upper' else None
        assert not chosen or max(paid) < min(targets)
        exact_milestone_profit = sum(credit(milestones[i]['rank']) for i in chosen.values())
        exact_query_cost = sum(querycost[node] for node in needed if node in querycost)
        assert margin == exact_milestone_profit - exact_query_cost
        witness_name = None
        witness_hash = None
        if rounding == 'upper' and minimum in (6, 9):
            coo = flow.flow.tocoo()
            witness = {'schema': 'intermediate-target-portfolio-flow-witness/v1',
                       'minimum_target_rank': minimum, 'c': ctext, 'integer_scale': scale,
                       'source': source, 'sink': sink, 'nodeoffset': nodeoffset,
                       'milestoneoffset': milestoneoffset,
                       'upper_rounded_milestone_profits': profits,
                       'lower_rounded_query_costs': costs,
                       'tariff_enclosure': 'Exact rational:96 positive atanh log terms plus geometric tail; alternating exp terms through13 for lower and12 for upper; no floating-point tariff assumption.',
                       'capacities': edges,
                       'antisymmetric_flow': [[int(u), int(v), int(w)] for u, v, w in zip(coo.row, coo.col, coo.data) if w],
                       'source_side': sorted(reached), 'flow_value': int(flow.flow_value),
                       'matching_cut_value': int(cut), 'optimistic_upper_bound': str(proof_upper),
                       'nodes': [{key: value for key, value in node.items() if key != 'query_bits'} for node in nodes],
                       'milestone_nodes_ranks_owners': [[m['node'], m['rank'], m['previous_rank'], m['owner'], m['previous_milestone']]
                                                       for m in milestones]}
            witness_name = f'INTERMEDIATE-TARGET-FLOW-MIN{minimum}.json.gz'
            packed = gzip.compress(json.dumps(witness, separators=(',', ':')).encode(), mtime=0)
            (HERE / witness_name).write_bytes(packed)
            witness_hash = sha256(packed).hexdigest()
        return {'minimum_target_rank': minimum, 'c': ctext, 'rounding': rounding,
                'integer_scale': scale, 'integer_optimum': integer_gain,
                'rigorous_optimistic_margin_upper_bound': str(proof_upper) if proof_upper is not None else None,
                'selected_independent_originals': len(chosen),
                'selected_main_X_originals': sum(owner < 112 for owner in chosen),
                'selected_helper_originals': sum(owner >= 224 for owner in chosen),
                'native_snapshot_target_profile': dict(sorted(native_snapshot_targets.items())),
                'padded_productive_target_profile': dict(sorted(targets.items())),
                'complete_paid_profile_including_padding': dict(sorted(paid.items())),
                'first_mass_margin': first, 'actual_moment_margin': str(margin),
                'selected_milestones': [i for owner, i in sorted(chosen.items())],
                'live_SSA_nodes': len(needed), 'flow_value': int(flow.flow_value),
                'flow_capacity_conservation_and_matching_cut_checked': True,
                'flow_witness': witness_name, 'flow_witness_sha256': witness_hash,
                'graph_vertices': sink + 1, 'graph_edges': len(edges)}


def main():
    started = time.monotonic()
    path = ROOT / 'research/retained_state_next/SOURCE-ONLY-WORD.json.gz'
    raw = path.read_bytes()
    blob = json.loads(gzip.decompress(raw))
    ce, cepath = load_ce()
    physical = ForwardOperators(ce, blob['canonical'])
    data = compile_source(blob, physical)
    print('COMPILED', len(data['nodes']), 'nodes', len(data['milestones']), 'milestones',
          data['clean_same_owner_snapshots'], 'clean snapshots', flush=True)
    records = []
    for minimum in (6, 7, 8, 9, 5, 4, 3, 2, 10):
        for ctext, rounding in (('0', 'consistent'), ('0.0030217758', 'consistent'), ('0.0030217758', 'upper')):
            record = optimize(data, minimum, ctext, rounding)
            records.append(record)
            print('PORTFOLIO', minimum, ctext, rounding,
                  record['selected_independent_originals'], record['native_snapshot_target_profile'],
                  'first', record['first_mass_margin'], 'margin', record['actual_moment_margin'],
                  'upper', record['rigorous_optimistic_margin_upper_bound'], flush=True)
    receipt = {'schema': 'actual-clean-intermediate-target-portfolio/v1',
               'status': 'EXACT_SOURCE_SNAPSHOT_CENSUS_AND_PRICED_CLOSURE; EMISSION_PENDING_IF_POSITIVE',
               'source_word_sha256': sha256(raw).hexdigest(),
               'clifford_source_sha256': sha256(cepath.read_bytes()).hexdigest(),
               'original_input_independence': 'All632 originals remain arbitrary. The520 source owners are copied once into owned SSA working storage; all original inputs are retained. At termination one chosen pure-owner snapshot per productive owner is returned, and every unselected original is restored unchanged. All other owned versions are erased. No input is duplicated for productive credit.',
               'physical_rank': 'Every milestone has raw transfer T_snapshot W_logical T_start^-1, including its actual phase-bearing warp. The logical scalar is removed once by an ordinary rational scale. Gaussian rank is computed from its complete phase-aware Clifford tableau.',
               'one_target_per_owner': 'Strictly increasing rank milestones have nested chronological SSA/query ancestry. Incremental target credits telescope to the highest selected milestone. Previous milestones are explicitly required, so no two outputs on one arbitrary original are counted independently.',
               'padding': 'Ranks below the chosen minimum are completed by a paid Gaussian job on fresh disjoint coordinates of the same array. Original paid jobs exceeding minimum−1 are split. All padding and splitting are included before testing strict separation.',
               'optimization': 'Exact integer max-weight closure of the full SSA DAG, with paid-query vertices and incremental milestone credits. Consistent-rounded tariffs identify implementable candidate portfolios; separately rounded-up profits/down costs give favorable upper bounds for the same family.',
               'upper_tariff_proof': 'Exact rational enclosures use log(r)=2 sum z^(2k+1)/(2k+1), z=(r−1)/(r+1),96 terms plus a geometric tail; alternating exp(−c log r) partial sums through13/12 enclose r^(1−c). The full moment interval width is<10^-15 for ranks1…10. Upper profits and lower costs are rounded from these rational enclosures, not Decimal approximations.',
               'SSA_nodes': len(data['nodes']), 'paid_nodes': len(data['query_nodes']),
               'clean_same_owner_snapshots': data['clean_same_owner_snapshots'],
               'strictly_increasing_target_milestones': len(data['milestones']),
               'monotone_query_inclusions_checked': data['monotone_query_inclusions_checked'],
               'phase_exact_logical_operators_seen': len(physical.ops),
               'records': records, 'milestones': data['milestones'],
               'scope': 'One clean same-owner singleton-operator snapshot per original in the literal source-only word, with original input copies and owned SSA storage. Does not cover general clean linear subspaces, changed scalar dependencies, independent coordinate tilings or multi-stage query fusion. A positive portfolio requires literal schedule emission, frame lowerings, cleanup and precision/ordinary billing.',
               'new_kappa_claimed': False, 'elapsed_seconds': time.monotonic() - started}
    (HERE / 'INTERMEDIATE-TARGET-PORTFOLIO.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('DONE', receipt['elapsed_seconds'], flush=True)


if __name__ == '__main__':
    main()
