#!/usr/bin/env python3
"""Literal source-R5 weighted-average provider with query ranks [6,1,1,6].

The exact all-width identity follows from the 56 phase-checked chart
identities. This replay also checks all width-one basis vectors and two
deterministic dense width-two inputs using Gaussian integers only.
"""
from decimal import Decimal as D, localcontext
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import json
import sys
import time

import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'research/tensor_obstruction/inputs'))
import clifford_exact as ce


def gaussian_inverse_num(real,imag,q,m):
    """Numerator of C(X_q)^(-tensor m), with denominator 2^m."""
    index=np.arange(len(real),dtype=np.int64)
    real,imag=real.copy(),imag.copy()
    for c in range(m):
        rr,ii=real[index^(q<<(9*c))],imag[index^(q<<(9*c))]
        real,imag=real+imag+rr-ii,imag-real+ii+rr
    return real,imag


def phase_rotate(real,imag,phase):
    return ((real,imag),(-imag,real),(-real,-imag),(imag,-real))[phase%4]


def permute(real,imag,rows,m):
    local=np.array([ce.mv(rows,x) for x in range(512)],dtype=np.int64)
    index=np.arange(len(real),dtype=np.int64)
    dest=np.zeros(len(real),dtype=np.int64)
    for c in range(m):
        dest|=local[(index>>(9*c))&511]<<(9*c)
    rr,ii=np.empty_like(real),np.empty_like(imag)
    rr[dest],ii[dest]=real,imag
    return rr,ii


def raw_hadamard(real,imag,m):
    real,imag=real.copy(),imag.copy()
    columns=real.shape[1]
    for c in range(m):
        for bit in range(9*c,9*c+6):
            for value in (real,imag):
                view=value.reshape(-1,2,1<<bit,columns)
                a,b=view[:,0].copy(),view[:,1].copy()
                view[:,0],view[:,1]=a+b,a-b
    return real,imag


def chart_raw(real,imag,G,m,inverse=False):
    # ce.hadamard on six bits has phase -i relative to normalized Walsh.
    # The forward and inverse chart phases cancel in this sandwich; raw
    # Walsh butterflies contribute an overall denominator 2^(6m).
    if inverse:
        real,imag=raw_hadamard(real,imag,m)
        return permute(real,imag,G,m)
    real,imag=permute(real,imag,ce.inv(G,9),m)
    return raw_hadamard(real,imag,m)


def conditional_monomial(real,imag,head,z,m):
    index=np.arange(len(real),dtype=np.int64)
    dest=index.copy()
    count=np.zeros(len(real),dtype=np.int8)
    local=np.array([ce.parity(z&x) for x in range(512)],dtype=np.int8)
    for c in range(m):
        control=local[(index>>(9*c))&511]
        dest^=control.astype(np.int64)*(head<<(9*c))
        count+=control
    rr,ii=np.empty_like(real),np.empty_like(imag)
    for phase in range(4):
        selected=(((-count)&3)==phase)
        a,b=phase_rotate(real[selected],imag[selected],phase)
        rr[dest[selected]],ii[dest[selected]]=a,b
    return rr,ii


def finite_check(case,m):
    size=1<<(9*m)
    if m==1:
        real=np.eye(size,dtype=np.int64)
        imag=np.zeros_like(real)
        test_description='all512 standard basis inputs'
    else:
        rng=np.random.default_rng(20261023)
        real=rng.integers(-3,4,size=(size,2),dtype=np.int64)
        imag=rng.integers(-3,4,size=(size,2),dtype=np.int64)
        test_description='two deterministic dense Gaussian-integer inputs'
    direct_r,direct_i=np.zeros_like(real),np.zeros_like(imag)
    for port in case['actual_ports']:
        rr,ii=gaussian_inverse_num(real,imag,port['q'],m)
        direct_r+=rr;direct_i+=ii
    direct_r,direct_i=phase_rotate(direct_r,direct_i,m)
    wr,wi=chart_raw(real,imag,case['G_rows'],m)
    common={h:gaussian_inverse_num(wr,wi,h,m) for h in case['common_heads']}
    total_r,total_i=np.zeros_like(real),np.zeros_like(imag)
    for port in case['actual_ports']:
        rr,ii=conditional_monomial(*common[port['common_head']],
                                   port['common_head'],port['spectator_parity_mask'],m)
        total_r+=rr;total_i+=ii
    total_r,total_i=chart_raw(total_r,total_i,case['G_rows'],m,inverse=True)
    total_r,total_i=phase_rotate(total_r,total_i,m)
    scale=1<<(6*m)
    assert np.array_equal(total_r,direct_r*scale)
    assert np.array_equal(total_i,direct_i*scale)
    return {'width':m,'array_length':size,'tests':test_description,
            'numerator_denominator_before_average':1<<m,
            'raw_chart_extra_denominator':scale,
            'all_entries_equal_over_Gaussian_integers':True,
            'direct_output_sha256':sha256(direct_r.tobytes()+direct_i.tobytes()).hexdigest()}


def main():
    start=time.monotonic()
    source=HERE/'SHARED-SCATTER-CHARTS.json'
    receipt=json.loads(source.read_text())
    assert receipt['source_R5_support_and_all_signs_verified']
    case=next(x for x in receipt['cases'] if x['difference_dimension']==6)
    W=ce.perm(9,ce.inv(case['G_rows'],9)).then(ce.hadamard(9,range(6)))
    operations=[('entry',W),('head128',ce.cgate(9,128,-1)),
                ('head256',ce.cgate(9,256,-1)),('exit',W.adjoint())]
    compiled=[]
    for name,op in operations:
        lowering,program=ce.lower_child(op)
        compiled.append({'name':name,'query_rank':lowering['rank'],
                         'ordinary_wrappers':lowering,'compiled_word':program.circuit,
                         'tableau_and_absolute_phase_verified':True})
    ranks=[x['query_rank'] for x in compiled]
    assert ranks==[6,1,1,6]
    checks=[]
    for m in (1,2):
        check=finite_check(case,m)
        checks.append(check)
        print('EXACT_AVERAGE_WIDTH',m,'PASS',round(time.monotonic()-start,2),flush=True)
    with localcontext() as ctx:
        ctx.prec=65
        exponent=D(1)-D('0.0030217758')
        moment=sum(D(r)**exponent for r in ranks)
        baseline=D(8)**exponent
    result={
        'status':'PASS_SOURCE_R5_SINGLE_OUTPUT_AVERAGE_PROVIDER',
        'chart_source_sha256':sha256(source.read_bytes()).hexdigest(),
        'source_R_sha256':receipt['independent_source_R_sha256'],
        'input_scope':'one arbitrary complex array of length2^(9m); all other live arrays are spectators',
        'target':'T_m=(1/56) sum_{i:sourceR5_i!=0} C(-X_qi)^(tensor m)',
        'exact_identity':'T_m=(i^m/56) W^(-tensor m) [A128_m Q128^(-tensor m)+A256_m Q256^(-tensor m)] W^(tensor m)',
        'ordinary_sums':'Ah_m=sum_{v in K8 edge labels} M_{h,v}^(tensor m), 28 monomials each',
        'conditional_monomial':'M_{h,v}|a>=(-i)^parity(z_v&a)|a xor h*parity(z_v&a)>; multiply these phases across allm columns',
        'required_global_phase':'i^m, not a constant i; 1/56 applied once outside tensor powers',
        'query_ranks':ranks,'rank_mass':sum(ranks),'moment_at_c_0030217758':str(moment),
        'saved_single_rank8_call_moment':str(baseline),
        'moment_excess_over_one_rank8_call':str(moment-baseline),
        'compiled_queries':compiled,
        'ordinary_schedule':[
            'Apply the entry rank6 child with its emitted ordinary wrappers to the one input array.',
            'Preserve the chart input while applying rank1 inverse heads128 and256 to two copies.',
            'Apply and add the56 emitted conditional monomials into one common output array.',
            'Apply the exit rank6 child with its emitted ordinary wrappers once.',
            'Multiply the whole output by i^m/56.'
        ],
        'ordinary_admission':'A fixed56 monomial sum, fixed copies/additions, and fixed source-derived linear/quadratic address functions. The existing whole-width Boolean compiler applies with a constant independent ofm; O(N(1+m^tau)) for the established tau, conditional on its B1 premise.',
        'helper_schedule':'A conservative copy-out implementation uses at most four length-N scratch arrays; these can be reused after the single output returns. This is an upper bound, not a minimized original-owner hosting claim.',
        'finite_exact_checks':checks,
        'all_width_proof':'The phase-checked one-copy conjugation holds separately at every actual port; tensor it overm, then use linearity to group the28 terms sharing each of thetwo heads. The inverse chart is applied after the sum, so it is paid once.',
        'actual_ports':case['actual_ports'],
        'scope':'Exact arbitrary-input provider for the weighted self-average, not a56-output scatter. It reduces56 rank1 calls to[6,1,1,6] but does not beat a rank8 call. No kappa improvement or caller spectral-radius improvement claimed.',
        'elapsed_seconds':time.monotonic()-start}
    target=HERE/'SELF-AVERAGE-PROVIDER.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print('RECEIPT',target,'ranks',ranks,'moment',moment,flush=True)


if __name__=='__main__':main()
