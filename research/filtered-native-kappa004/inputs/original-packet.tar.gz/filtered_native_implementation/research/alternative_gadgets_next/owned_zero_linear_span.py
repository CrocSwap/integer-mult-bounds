#!/usr/bin/env python3
"""Chronological linear-span reuse beyond complete-value memoization.

Every candidate uses previously computed values in the exact same physical
frame.  Dependencies retain their independent arbitrary source owners.  This
is a concrete greedy synthesis census, not a lower bound or admitted supplier.
"""
from collections import Counter, defaultdict
from decimal import Decimal as D, localcontext
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from owned_zero_memoization import PhysicalWords, load_ce


def accumulate(dst, src, scale):
    assert dst is not src
    for key, value in src.items():
        result = dst.get(key, Fr(0)) + scale * value
        if result:
            dst[key] = result
        else:
            dst.pop(key, None)


class Span:
    def __init__(self):
        self.pivots = {}

    def reduce(self, value):
        remaining = dict(value)
        combination = {}
        while remaining:
            pivot = min(remaining)
            if pivot not in self.pivots:
                break
            basisrow, basiscombo = self.pivots[pivot]
            a = remaining[pivot]
            accumulate(remaining, basisrow, -a)
            accumulate(combination, basiscombo, a)
        return remaining, combination

    def insert(self, value, node, remainder, combination):
        assert remainder
        pivot = min(remainder)
        assert pivot not in self.pivots
        a = remainder[pivot]
        basisrow = {key: coefficient / a for key, coefficient in remainder.items()}
        basiscombo = {key: -coefficient / a for key, coefficient in combination.items()}
        assert node not in basiscombo
        basiscombo[node] = 1 / a
        self.pivots[pivot] = basisrow, basiscombo


def execute(blob, chosen, physical, replace_ordinary=False):
    chosen = set(chosen)
    canonical = blob['canonical']
    size = 641
    rows = [{(i, 0): Fr(1)} if 112 <= i < 224 or i in chosen else {} for i in range(size)]
    frames = canonical['start'][:] + [None] * (size - 632)
    nodes = [{'deps': [], 'query': None, 'event': None, 'frame': frames[i],
              'qbits': 0} for i in range(size)]
    state = list(range(size))
    spans = defaultdict(Span)
    queries = []
    score_cache = {0: 0}
    replacements = []
    dependence = Counter()
    max_combination = 0
    max_fraction_bits = 0

    def score(bits):
        if bits not in score_cache:
            value = 0
            left = bits
            while left:
                bit = left & -left
                value += queries[bit.bit_length() - 1]
                left ^= bit
            score_cache[bits] = value
        return score_cache[bits]

    def union_bits(indices):
        result = 0
        for node in indices:
            result |= nodes[node]['qbits']
        return result

    for i, row in enumerate(rows):
        if row:
            remainder, combination = spans[frames[i]].reduce(row)
            assert remainder
            spans[frames[i]].insert(row, i, remainder, combination)

    events = [e for e in blob['programs']['backward'] if e[0] != 'physical_add']
    def ix(ref):
        return ref[1] + (632 if ref[0] == 'C' else 0)

    for pos, event in enumerate(events):
        kind = event[0]
        destination = None
        deps = []
        paid = None
        if kind == 'scalar':
            operation, frame = event[1:]
            opcode, destination = operation[0], ix(operation[1])
            if opcode == 'clear':
                assert destination >= 632
                rows[destination] = {}
                frames[destination] = frame
            else:
                assert frames[destination] == frame
                if opcode in ('copy', 'add'):
                    source = ix(operation[2])
                    assert frames[source] == frame and source != destination
                    if opcode == 'copy':
                        assert destination >= 632
                        rows[destination] = dict(rows[source])
                        deps = [state[source]]
                    else:
                        accumulate(rows[destination], rows[source], Fr(operation[3], operation[4]))
                        deps = [state[destination], state[source]]
                else:
                    assert opcode == 'scale'
                    scalar = Fr(operation[2], operation[3])
                    rows[destination] = {key: scalar * value for key, value in rows[destination].items()
                                         if scalar * value}
                    deps = [state[destination]]
        elif kind == 'warp':
            _, ref, letter, oldframe, newframe = event
            destination = ix(ref)
            assert frames[destination] == oldframe
            replacement = {}
            for (owner, op), value in rows[destination].items():
                product = physical.product(physical.letters[letter], op)
                replacement[owner, product] = replacement.get((owner, product), Fr(0)) + value
            rows[destination] = {key: value for key, value in replacement.items() if value}
            frames[destination] = newframe
            deps = [state[destination]]
        elif kind == 'climb':
            _, _, destination, oldframe, newframe, rank = event
            assert frames[destination] == oldframe
            frames[destination] = newframe
            deps = [state[destination]]
            if rows[destination]:
                paid = rank
        elif kind == 'adapter':
            destination = event[2]
            deps = [state[destination]]
        else:
            assert kind == 'phase'
        if destination is None:
            continue

        row = rows[destination]
        if not row:
            deps = []
            paid = None
        bits = union_bits(deps)
        remainder = combination = None
        reused = False
        original_mass = score(bits) + (paid or 0)
        if row:
            span = spans[frames[destination]]
            remainder, combination = span.reduce(row)
            if not remainder:
                dependence[kind] += 1
                assert combination
                candidate_bits = union_bits(combination)
                candidate_mass = score(candidate_bits)
                permitted = paid is not None or replace_ordinary
                if permitted and (candidate_mass < original_mass or
                                  (paid is not None and candidate_mass == original_mass)):
                    deps = sorted(combination)
                    bits = candidate_bits
                    paid = None
                    reused = True
                    max_combination = max(max_combination, len(combination))
                    max_fraction_bits = max(max_fraction_bits, *(max(abs(a.numerator).bit_length(), a.denominator.bit_length())
                                                                 for a in combination.values()))

        query = None
        if paid:
            query = len(queries)
            queries.append(paid)
            bits |= 1 << query
        node = len(nodes)
        nodes.append({'deps': deps, 'query': query, 'event': pos,
                      'frame': frames[destination], 'qbits': bits})
        state[destination] = node
        if row and remainder:
            span.insert(row, node, remainder, combination)
        if reused:
            replacements.append({'node': node, 'event': pos, 'kind': kind,
                                 'combination': [[j, str(a)] for j, a in sorted(combination.items())],
                                 'original_standalone_mass': original_mass,
                                 'replacement_standalone_mass': score(bits),
                                 'direct_query_removed': event[-1] if kind == 'climb' else 0})

        if pos % 5000 == 0:
            print('SPAN', len(chosen), replace_ordinary, pos,
                  'basis', sum(len(x.pivots) for x in spans.values()),
                  'replacements', len(replacements), flush=True)

    assert frames[:632] == canonical['final']
    assert not any(rows[632:])
    live = set()
    todo = [state[i] for i in list(range(112)) + sorted(chosen)]
    while todo:
        node = todo.pop()
        if node in live:
            continue
        live.add(node)
        todo.extend(nodes[node]['deps'])
    paid_profile = Counter(queries[nodes[j]['query']] for j in live if nodes[j]['query'] is not None)
    targets = Counter({9: 112})
    for helper in chosen:
        targets[len(canonical['frames'][canonical['final'][helper]]) -
                len(canonical['frames'][canonical['start'][helper]])] += 1
    with localcontext() as context:
        context.prec = 60
        exponent = D(1) - D('0.0030217758')
        margin = sum(D(count) * D(rank)**exponent for rank, count in targets.items()) - sum(
            D(count) * D(rank)**exponent for rank, count in paid_profile.items())
    live_replacements = [r for r in replacements if r['node'] in live]
    record = {'helpers': len(chosen), 'replace_ordinary': replace_ordinary,
              'paid_profile': dict(sorted(paid_profile.items())),
              'target_profile': dict(sorted(targets.items())),
              'first_mass_margin': sum(r * k for r, k in targets.items()) - sum(r * k for r, k in paid_profile.items()),
              'moment_margin_at_c0030217758': str(margin),
              'live_SSA_nodes': len(live), 'dependent_rows_by_opcode': dict(dependence),
              'all_replacements': len(replacements), 'live_replacements': len(live_replacements),
              'live_removed_direct_query_mass': sum(r['direct_query_removed'] for r in live_replacements),
              'max_combination_terms': max_combination, 'max_fraction_numerator_or_denominator_bits': max_fraction_bits,
              'sum_frame_basis_dimensions': sum(len(x.pivots) for x in spans.values()),
              'max_frame_basis_dimension': max(len(x.pivots) for x in spans.values()),
              'best_replacement_examples': sorted(live_replacements,
                     key=lambda r: (r['replacement_standalone_mass'] - r['original_standalone_mass'], -r['direct_query_removed']))[:10]}
    return record, rows


def main():
    started = time.monotonic()
    source = ROOT / 'research/retained_state_next/F9-SOURCE-DAG-ALL8-WORD.json.gz'
    raw = source.read_bytes()
    blob = json.loads(gzip.decompress(raw))
    ce, cepath = load_ce()
    physical = PhysicalWords(ce, blob['canonical'])
    records = []
    for helpers in ([], list(range(224, 632))):
        expected = None
        for replace_ordinary in (False, True):
            record, rows = execute(blob, helpers, physical, replace_ordinary)
            if expected is None:
                expected = rows
            else:
                assert rows == expected
            records.append(record)
            print('RESULT', len(helpers), replace_ordinary, record['paid_profile'],
                  record['moment_margin_at_c0030217758'], flush=True)
    receipt = {
        'schema': 'owned-zero-chronological-linear-span/v1',
        'status': 'EXACT_GREEDY_SYNTHESIS_CENSUS; NOT_YET_EMITTED',
        'pins': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in (source, cepath)},
        'records': records,
        'mechanism': 'Cache earlier same-frame full physical values; replace a paid or optionally ordinary row by an exact rational combination of earlier owned caches when its standalone query first mass does not increase. Actual phase-bearing logical warp identities are applied.',
        'scope': 'Chronological rational span census with one earliest echelon basis per frame, two helper policies. Greedy standalone cost can miss globally better sharing. A positive candidate requires emitted operations, ownership/cleanup and precision billing. No new kappa claimed.',
        'elapsed_seconds': time.monotonic() - started
    }
    (HERE / 'OWNED-ZERO-LINEAR-SPAN.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print('DONE', receipt['elapsed_seconds'], flush=True)


if __name__ == '__main__':
    main()
