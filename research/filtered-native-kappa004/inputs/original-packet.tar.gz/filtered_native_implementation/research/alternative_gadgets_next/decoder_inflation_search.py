#!/usr/bin/env python3
"""Structured K3-style point cancellation for 11/12-term root swaps.

Inflate each outside point into one non-point term with an exact elementary
gauge. Unlike a redundant root-swap list, the retained factors must contain
no zero products and no proportional factors on either side.
"""
from collections import Counter
from decimal import Decimal
from fractions import Fraction as F
from hashlib import sha256
import json
import time

import decoder_gauge_search as d
from decoder_receipt_review import reduce_factors,diagnostics


def inflate(P,Q,delta,k,row_side):
    P,Q=[x[:] for x in P],[x[:] for x in Q]
    A,B=(P,Q) if row_side else (Q,P)
    point=next(i for i,x in enumerate(A[delta]) if x)
    assert sum(bool(x) for x in A[delta])==1
    t=-A[k][point]/A[delta][point]
    assert t
    A[k]=[x+t*y for x,y in zip(A[k],A[delta])]
    B[delta]=[x-t*y for x,y in zip(B[delta],B[k])]
    assert A[k][point]==0
    return P,Q,[delta,k,str(t),'row' if row_side else 'column']


def probe(s,t):
    P0,Q0,meta=d.root_swap_seed(s,t)
    names=meta['names']
    operations=[(k,True) for k,n in enumerate(names) if n=='row-swap delta']
    operations += [(k,False) for k,n in enumerate(names) if n=='col-swap delta']
    assert len(operations)==s+t
    finals=[];visited=0;mass_hist=Counter();profile_hist=Counter()
    def rec(P,Q,depth,moves):
        nonlocal visited
        visited+=1
        if depth==len(operations):
            ranks,_,_=d.profiles(P,Q)
            mass_hist[sum(ranks)]+=1
            if sum(ranks)>64:return
            PP,QQ=reduce_factors(P,Q)
            if len(PP)!=len(P):return
            profile_hist[tuple(sorted(ranks))]+=1
            finals.append((sum(d.PRICE[r] for r in ranks),P,Q,moves,ranks))
            return
        delta,row=operations[depth]
        A=P if row else Q
        point=next(i for i,x in enumerate(A[delta]) if x)
        for k in range(len(P)):
            if k==delta or not A[k][point]:continue
            if sum(bool(x) for x in P[k])<=1 or sum(bool(x) for x in Q[k])<=1:continue
            PP,QQ,move=inflate(P,Q,delta,k,row)
            ranks,_,_=d.profiles(PP,QQ)
            # A future point cancellation can remove at most one row/column
            # from its non-point term and at most one point-term rank.
            remaining=len(operations)-depth-1
            if sum(ranks)>64+2*remaining:continue
            rec(PP,QQ,depth+1,moves+[move])
    rec(P0,Q0,0,[])
    finals.sort(key=lambda x:x[0])
    records=[]
    seen=set()
    for price,P,Q,moves,ranks in finals:
        key=tuple(sorted(ranks))
        if key in seen:continue
        seen.add(key)
        rec=d.snapshot(P,Q,{**meta,'point_inflation_moves':moves})
        rec['normalization_diagnostics']=diagnostics(P,Q)
        assert rec['normalization_diagnostics']['normalized_terms']==len(P)
        records.append(rec)
    return {'outside_dimensions':[s,t],'tree_nodes':visited,
            'complete_leaf_mass_histogram':dict(sorted(mass_hist.items())),
            'normalized_rank64_or_lower_attainers':len(finals),
            'normalized_profile_histogram':{' '.join(map(str,k)):v for k,v in profile_hist.items()},
            'best':records[0] if records else None,'one_attainer_per_profile':records}


def main():
    start=time.monotonic();results=[]
    for s,t in [(2,1),(2,2)]:
        result=probe(s,t);results.append(result)
        print('INFLATION',s,t,'nodes',result['tree_nodes'],
              'normalized_mass64',result['normalized_rank64_or_lower_attainers'],
              'profiles',result['normalized_profile_histogram'],flush=True)
    output={'status':'EXACT_STRUCTURED_OUTSIDE_FACTOR_INFLATION_SEARCH',
            'source_sha256':sha256(d.PORTS.read_bytes()).hexdigest(),
            'results':results,'elapsed_seconds':time.monotonic()-start,
            'scope':'Finite K3-style point cancellation on source-bound (2,1)/(2,2) root-swap bases. Each retained factorization is nonzero, has no proportional factors on either side, and is checked on all112^2 entries. No generic floor or physical supplier claim.'}
    target=d.HERE/'DECODER-INFLATION-SEARCH.json'
    target.write_text(json.dumps(output,indent=2)+'\n')
    print('RECEIPT',target,flush=True)


if __name__=='__main__':main()
