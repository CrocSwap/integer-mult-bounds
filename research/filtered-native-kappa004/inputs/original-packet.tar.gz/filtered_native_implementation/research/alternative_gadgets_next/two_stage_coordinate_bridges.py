#!/usr/bin/env python3
"""Move paid address geometry between two physical companion stages.

Enumerates every common coordinate permutation and bit translation in the
source's finite group, independently of the four-role signed permutation.
"""
from collections import Counter
from hashlib import sha256
from itertools import permutations, product
from pathlib import Path
import json
import sys
import time

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import two_stage_companion as core


def main():
    started = time.monotonic()
    n1, n2 = core.stage(1), core.stage(2)
    a1, a2 = core.augmentation(n1), core.augmentation(n2)
    inv1, inv2 = [core.minus([[2 * x for x in row] for row in core.eye(8)], a) for a in (a1, a2)]
    bridges = []
    for roleperm in permutations(range(4)):
        for tail in product((-1, 1), repeat=3):
            signs = (1,) + tail
            bridge = core.bridge(roleperm, signs)
            inverse_aug = core.mm(inv1, [list(row) for row in zip(*bridge)], inv2)
            bridges.append((roleperm, signs, bridge, inverse_aug))

    results = []
    local_results = []
    rejected = Counter()
    tested = 0
    for coordinate_permutation in permutations(range(3)):
        for translations in product((0, 2), repeat=3):
            common = {(translations, coordinate_permutation): 1}
            # Physical chronological word is N2 * (common on every field) * B * N1.
            moved_n1 = [[core.gp(common, entry) for entry in row] for row in n1]
            local_survivors = 0
            local_full_survivors = 0
            for roleperm, signs, bridge, inverse_aug in bridges:
                matrix = core.compose(n2, bridge, moved_n1)
                tested += 1
                pieces = core.grade_components(matrix)
                normalized = [core.mm(piece, inverse_aug) for piece in pieces]
                bad = next((r for r, component in enumerate(normalized)
                            if core.mm(component, component) != component), None)
                if bad is not None:
                    rejected[f'fails_idempotence_grade{bad}'] += 1
                    continue
                assert all(core.zero(core.mm(normalized[r], normalized[s]))
                           for r in range(4) for s in range(4) if r != s)
                multiplicities = [core.rank(component) for component in normalized]
                assert sum(multiplicities) == 8
                local_survivors += 1
                fullgrades = Counter()
                witnesses = []
                for i, j in product(range(8), repeat=2):
                    for (exponents, permutation), coefficient in matrix[i][j].items():
                        grade = sum(x % 2 for x in exponents)
                        fullgrades[grade] += 1
                        if not multiplicities[grade] and len(witnesses) < 3:
                            witnesses.append({'output': i, 'input': j, 'grade': grade,
                                              'word': [exponents, permutation], 'coefficient': coefficient})
                if not witnesses:
                    local_full_survivors += 1
                results.append({'coordinate_permutation': coordinate_permutation,
                                'even_gaussian_exponents': translations,
                                'role_permutation': roleperm, 'role_signs': signs,
                                'target_rank_multiplicities': multiplicities,
                                'target_first_mass': sum(r * k for r, k in enumerate(multiplicities)),
                                'two_stage_paid_geometry_first_mass': 16,
                                'full_nonzero_coefficient_grades': dict(sorted(fullgrades.items())),
                                'absent_target_grade_witnesses': witnesses})
            local_results.append({'coordinate_permutation': coordinate_permutation,
                                  'even_gaussian_exponents': translations,
                                  'augmentation_survivors': local_survivors,
                                  'full_profile_survivors': local_full_survivors})
        print('COORDINATE', coordinate_permutation, 'tested', tested,
              'augmented', len(results), 'full', sum(not r['absent_target_grade_witnesses'] for r in results), flush=True)
    survivors = [r for r in results if not r['absent_target_grade_witnesses']]
    receipt = {
        'schema': 'two-stage-common-coordinate-bridge/v1',
        'status': 'EXACT_ENUMERATED_TOY_SCREEN; NO_SUPPLIER_ADMITTED',
        'source_pin': sha256((HERE / 'two_stage_companion.py').read_bytes()).hexdigest(),
        'physical_network': 'N2 * common_address_monomial * signed_role_permutation * N1',
        'common_address_words': 48,
        'coordinate_permutations': 6,
        'translations_per_permutation': 8,
        'signed_role_bridges_per_word': 192,
        'networks_screened': tested,
        'augmentation_survivor_count': len(results),
        'full_profile_survivor_count': len(survivors),
        'target_rank_profile_census_among_augmentation_survivors': {
            str(profile): count for profile, count in Counter(tuple(r['target_rank_multiplicities']) for r in results).items()},
        'rejections': dict(rejected),
        'common_word_summary': local_results,
        'augmentation_survivors': results,
        'full_profile_survivors': survivors,
        'algebra': 'The exact semidirect product (Z4)^3 semidirect S3 includes Gaussian quarter-turns, coordinate permutations, and even-turn translations. Global phases disappear on widths divisible by four; the finite tensor-power/group-augmentation proof from TWO-STAGE-COMPANION applies unchanged.',
        'ordinary_boundary_scope': 'Invertible owner matrices over finite sums of whole-width lifts of one-column monomial Cliffords. Includes the complete monomial Clifford boundary span, beyond the source subgroup used in enumeration.',
        'limitations': 'Two-active-owner toy specialization, two stages, common address word between them, no extra internal owner shears or source-interior caches. This does not exclude actual112-port-specific constructions, general cross-column ordinary maps, or more stages.',
        'new_kappa_claimed': False,
        'elapsed_seconds': time.monotonic() - started
    }
    (HERE / 'TWO-STAGE-COORDINATE-BRIDGES.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in ('augmentation_survivors', 'common_word_summary')}, indent=2), flush=True)


if __name__ == '__main__':
    main()
