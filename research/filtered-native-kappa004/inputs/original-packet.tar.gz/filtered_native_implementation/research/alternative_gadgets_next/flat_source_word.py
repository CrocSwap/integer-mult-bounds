#!/usr/bin/env python3
"""Exact source flat-word witness for common-basis support pricing."""
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'constructive_observers'))
import cross_column_routes as cc
import check_majorana_admission as ma


def main():
    ce, canonical, normalizers, R, routes = cc.source_data()
    paulis = ma.source_paulis(ce, canonical)
    ports, translations = [], []
    for i, (q, z, p) in enumerate(paulis):
        if ce.rank(translations + [q]) > len(translations):
            ports.append(i)
            translations.append(q)
    assert len(ports) == 9
    matrix_phases = bytearray()
    phase_lookup = {(16, 16): 0, (-16, 16): 1, (-16, -16): 2, (16, -16): 3}
    for source in range(512):
        state = {source: (1, 0)}
        for port in ports:
            q, z, p = paulis[port]
            new = {}
            for x, (a, b) in state.items():
                # Identity coefficient (1+i)/2.
                assert x not in new
                new[x] = (a - b, a + b)
                # Pauli coefficient (1-i)/2, including the actual source phase.
                c, d = ce.mul_i((a, b), p + 2 * ce.parity(z & x))
                assert x ^ q not in new
                new[x ^ q] = (c + d, d - c)
            state = new
        assert len(state) == 512
        assert all(a * a + b * b == 512 for a, b in state.values())
        matrix_phases.extend(phase_lookup[state[x]] for x in range(512))
    result = {
        'status': 'PASS_COMPLETE_EXACT_FLAT_SOURCE_WORD',
        'source_ports_sha256': sha256((HERE / 'SOURCE-PORTS.txt').read_bytes()).hexdigest(),
        'execution_order_ports': ports,
        'independent_head_translations': translations,
        'all_matrix_entries_checked': 512 * 512,
        'matrix_dimension': 512,
        'integer_denominator_before_reduction': 512,
        'squared_gaussian_numerator_for_every_entry': 512,
        'entry_modulus_squared': '1/512',
        'column_major_phase_byte_sha256': sha256(matrix_phases).hexdigest(),
        'all_width_statement': 'W_m=W tensor-power(m) is unitary and every entry has modulus2^(-9m/2).',
        'common_basis_support_bound': 'If B^{-1} U_i^{tensor m} B is monomial for all source ports, max_j |supp(B e_j)| >=2^(9m/2).',
        'route_implementation_bound': 'If every B column is obtained from at most T monomial/Gaussian path words, each using Gaussian ranks summing to at most b, then T*2^b>=2^(9m/2). In particular a fixed-k width-m query route needs T>=2^((9/2-k)m).',
        'scope': 'Support pricing for a common exact basis monomializing all112 native heads. Dense ordinary algorithms, projections, non-common observer alignments, retained caller information, and direct coded consumers are outside this bound.'
    }
    (HERE / 'FLAT-SOURCE-WORD.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
