#!/usr/bin/env python3
"""Schedule the actual source DAG before the centre consumer.

No paid child is duplicated.  Every source value read by the postponed
consumer is explicitly copied into owned storage at its original frame.
This makes clean F9 X available at every centre while preserving every
arbitrary helper.  The output is a helper-clean filtered producer, not a
completed caller or recursive exponent claim.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import copy
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];FSYM=2000009

def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    return m

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--all-modes',action='store_true')
    ap.add_argument('--source-first',action='store_true',help='Retain the stronger late-Y-admission schedule.')
    args=ap.parse_args()
    chosen=set(range(8)) if args.all_modes else {5};tag='ALL8' if args.all_modes else 'MODE5'
    if args.source_first:tag+='-SOURCEFIRST'
    path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw=path.read_bytes();source=json.loads(gzip.decompress(raw));c=source['canonical'];es=source['programs']['forward']
    core=load('source_dag_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    R=[[F(x) for x in row] for row in json.loads(rp.read_text())]
    def idx(ref):return ref[1]+(632 if ref[0]=='C' else 0)
    def ref(i):return ['L',i] if i<632 else ['C',i-632]

    # Bind every actual SSA value to its frame, predecessor values, and
    # original event.  Adapter nodes retain their position on each owner.
    nodes=[{'owner':i,'frame':c['start'][i] if i<632 else None,'deps':[], 'event':None,'index':None} for i in range(633)]
    state=list(range(633));events={};captures={};centermode={};rows=[core.identity(i) for i in range(632)]+[{}]
    cut=-1 if args.source_first else next(k for k,e in enumerate(es) if e==['phase','centers'])
    cutstate=list(range(633)) if cut==-1 else None;count=0
    for k,e in enumerate(es):
        typ=e[0];d=None;deps=[];read=None;frame=None
        if typ=='scalar':
            a,frame=e[1:];d=idx(a[1])
            if a[0]=='clear':rows[d]={}
            elif a[0]=='copy':read=idx(a[2]);deps=[state[read]];rows[d]=dict(rows[read])
            elif a[0]=='add':read=idx(a[2]);deps=[state[d],state[read]];core.add(rows[d],rows[read],F(a[3],a[4]))
            else:deps=[state[d]];rows[d]={j:v*F(a[2],a[3]) for j,v in rows[d].items() if v*a[2]}
        elif typ=='warp':
            d=idx(e[1]);deps=[state[d]];frame=e[4];rows[d]=core.warp(rows[d],e[2],False)
        elif typ=='climb':d=e[2];deps=[state[d]];frame=e[4]
        elif typ=='center':
            d=632+e[1];deps=[state[d]];frame=e[3]
            cap=rows[d];assert all(not w for i,w in cap)
            assert all(cap.get((i,()),F(0))==R[count][i] for i in range(112))
            assert not any(112<=i<224 for i,w in cap)
            hs={i:v for (i,w),v in cap.items() if i>=224}
            assert all(c['start'][i]==0 for i in hs)
            captures[count]=hs;centermode[k]=count;count+=1
        elif typ=='adapter':d=e[2];deps=[state[d]];frame=nodes[state[d]]['frame']
        else:assert typ=='phase'
        if d is not None:
            prev=state[d];j=len(nodes)
            nodes.append({'owner':d,'frame':frame,'deps':deps,'event':copy.deepcopy(e),'index':k,
                          'read_node':state[read] if read is not None else None,'previous_node':prev})
            state[d]=j;events[k]=j
        if k==cut:cutstate=state[:]
    assert count==8 and rows[:632]==[core.expected(i,False) for i in range(632)]
    stack=[state[i] for i in range(112)];anc=set()
    while stack:
        j=stack.pop()
        if j in anc:continue
        anc.add(j);stack.extend(nodes[j]['deps'])
    assert not any(112<=j<224 for j in anc)
    assert not any(nodes[j]['event'] and nodes[j]['event'][0]=='center' for j in anc)
    # Every original owner's ancestor writes form a prefix; otherwise a
    # postponed write would be overwritten before it could consume state.
    lastsource={i:i for i in range(633)}
    boundary=set()
    ignored_copies={k-1 for k,mode in centermode.items() if mode in chosen}
    assert all(es[k][0]=='scalar' and es[k][1][0]=='copy' and es[k][1][1]==['C',0] for k in ignored_copies)
    for k,j in events.items():
        n=nodes[j]
        if j in anc:lastsource[n['owner']]=j
        elif k>cut and k not in ignored_copies:
            rn=n.get('read_node')
            if rn in anc:boundary.add(rn)
    cache={j:1+i for i,j in enumerate(sorted(boundary))}
    hslot={mode:len(cache)+1+i for i,mode in enumerate(sorted(chosen))}
    out=[];origins=[]
    def emit(e,origin):out.append(copy.deepcopy(e));origins.append(origin)
    emit(['phase','retain_ground_helper_modes'],None)
    for mode,slot in hslot.items():
        emit(['scalar',['clear',['C',slot]],0],None)
        for h,a in sorted(captures[mode].items()):emit(['scalar',['add',['C',slot],['L',h],a.numerator,a.denominator],0],None)
    def snapshot(j):
        if j not in cache:return
        n=nodes[j];f=n['frame'];slot=cache[j]
        assert f is not None
        emit(['scalar',['clear',['C',slot]],f],None)
        emit(['scalar',['copy',['C',slot],ref(n['owner'])],f],None)
    emit(['phase','unchanged_native_precenter_prefix'],None)
    for k,e in enumerate(es[:cut+1]):emit(e,k)
    for j in sorted(boundary):
        if nodes[j]['index'] is None or nodes[j]['index']<=cut:
            assert cutstate[nodes[j]['owner']]==j
            snapshot(j)
    emit(['phase','complete_original_X_source_DAG'],None)
    for k,j in events.items():
        if j in anc and k>cut:emit(nodes[j]['event'],k);snapshot(j)
    emit(['phase','consume_retained_source_snapshots'],None)
    for k,j in events.items():
        if j in anc or k<=cut or k in ignored_copies:continue
        n=nodes[j];e=copy.deepcopy(n['event'])
        if e[0]=='center' and centermode[k] in chosen:
            mode=centermode[k]
            emit(['scalar',['clear',['C',0]],0],k)
            for i,a in enumerate(R[mode]):
                if a:emit(['physical_add',['C',0],['L',i],a.numerator,a.denominator,0,1,[]],None)
            emit(['scalar',['add',['C',0],['C',hslot[mode]],1,1],0],None)
            continue
        if e[0]=='scalar' and e[1][0] in ('add','copy') and n['read_node'] in cache:
            e[1][2]=['C',cache[n['read_node']]]
        emit(e,k)
    emit(['phase','release_owned_snapshots'],None)
    for j,slot in cache.items():emit(['scalar',['clear',['C',slot]],nodes[j]['frame']],None)
    for mode,slot in hslot.items():emit(['scalar',['clear',['C',slot]],0],None)
    emit(['phase','done'],None)

    # Literal replay authenticates the schedule and every copied version.
    extra=len(cache)+len(hslot);nr=633+extra
    live=[core.identity(i) for i in range(632)]+[{} for _ in range(nr-632)]
    cur=c['start'][:]+[None for _ in range(nr-632)];paid=Counter();counts=Counter();maxnorm=F(1)
    peak_nonzero_owned=0
    for pos,e in enumerate(out):
        typ=e[0];counts[typ]+=1
        if typ=='scalar':
            a,f=e[1:];d=idx(a[1])
            if a[0]=='clear':assert d>=632;live[d]={};cur[d]=f
            else:
                assert cur[d]==f,(pos,e,cur[d])
                if a[0] in ('copy','add'):
                    s=idx(a[2]);assert cur[s]==f,(pos,e,cur[s])
                    if a[0]=='copy':assert d>=632;live[d]=dict(live[s])
                    else:core.add(live[d],live[s],F(a[3],a[4]))
                else:live[d]={j:v*F(a[2],a[3]) for j,v in live[d].items() if v*a[2]}
                maxnorm=max(maxnorm,sum(map(abs,live[d].values()),F(0)))
        elif typ=='warp':
            d=idx(e[1]);assert cur[d]==e[3];live[d]=core.warp(live[d],e[2],False);cur[d]=e[4]
        elif typ=='climb':
            d=e[2];assert cur[d]==e[3],(pos,e,cur[d]);cur[d]=e[4];paid[e[5]]+=1
        elif typ=='center':
            d=e[1]+632;assert cur[d]==e[2];cur[d]=e[3];paid[e[4]]+=1
        elif typ=='physical_add':
            _,dt,st,a,b,df,sf,word=e;d=idx(dt);s=idx(st)
            assert not word and (df,sf)==(0,1) and d==632
            assert cur[d]==df and cur[s]==sf and live[s]==core.identity(s)
            core.add(live[d],{(o,(FSYM,)+w):v for (o,w),v in live[s].items()},F(a,b))
        else:
            assert typ in ('adapter','phase')
            if e==['phase','consume_retained_source_snapshots']:
                assert all(live[i]==core.identity(i) and cur[i]==1 for i in range(112))
                if cut==-1:assert all(live[i]==core.identity(i) and cur[i]==0 for i in range(112,224))
        peak_nonzero_owned=max(peak_nonzero_owned,sum(bool(z) for z in live[632:]))
    expected=[core.expected(i,False) for i in range(632)]+[{} for _ in range(nr-632)]
    for mode in chosen:
        for i,ri in enumerate(R[mode]):
            if not ri:continue
            for j,rj in enumerate(R[mode]):
                if not rj:continue
                a=ri*rj/4
                core.add(expected[112+i],{(j,(FSYM,)):F(1)},a)
                core.add(expected[112+i],core.identity(j),-a)
    assert live==expected
    assert cur[:632]==c['final'] and all(not z for z in live[632:])
    original_paid=Counter(e[-1] for e in es if e[0] in ('climb','center'))
    want=original_paid.copy();want[8]-=len(chosen)
    assert paid==+want

    # Raw inverse transpose: the retained center-free helper prefix is
    # already helper-clean.  In its conjugated final X frame, a physical
    # identity ADD of original ground Y contributes logical F9*Y.
    back=[];yslot={mode:1+i for i,mode in enumerate(sorted(chosen))}
    for mode,slot in yslot.items():
        back.append(['scalar',['clear',['C',slot]],0])
        for i,a in enumerate(R[mode]):
            if a:back.append(['scalar',['add',['C',slot],['L',112+i],a.numerator,4*a.denominator],0])
        for h,a in sorted(captures[mode].items()):
            back.append(['scalar',['add',['L',h],['C',slot],-a.numerator,a.denominator],0])
    mode=0
    for e in source['programs']['backward']:
        if e[0]=='center':
            if mode in chosen:back.append(['scalar',['clear',['C',e[1]]],e[3]])
            else:back.append(copy.deepcopy(e))
            mode+=1
        else:back.append(copy.deepcopy(e))
    assert mode==8
    for mode,slot in yslot.items():
        for i,a in enumerate(R[mode]):
            if a:back.append(['physical_add',['L',i],['C',slot],-a.numerator,a.denominator,1,0,[]])
        back.append(['scalar',['clear',['C',slot]],0])
    bn=633+len(yslot)
    br=[core.identity(i) for i in range(632)]+[{} for _ in range(bn-632)]
    bf=c['start'][:]+[None for _ in range(bn-632)];bp=Counter();bc=Counter();bmax=F(1)
    for pos,e in enumerate(back):
        typ=e[0];bc[typ]+=1
        if typ=='scalar':
            a,f=e[1:];d=idx(a[1])
            if a[0]=='clear':assert d>=632;br[d]={};bf[d]=f
            else:
                assert bf[d]==f,(pos,e,bf[d])
                if a[0] in ('copy','add'):
                    s=idx(a[2]);assert bf[s]==f
                    if a[0]=='copy':assert d>=632;br[d]=dict(br[s])
                    else:core.add(br[d],br[s],F(a[3],a[4]))
                else:br[d]={j:v*F(a[2],a[3]) for j,v in br[d].items() if v*a[2]}
                bmax=max(bmax,sum(map(abs,br[d].values()),F(0)))
        elif typ=='warp':
            d=idx(e[1]);assert bf[d]==e[3];br[d]=core.warp(br[d],e[2],True);bf[d]=e[4]
        elif typ=='climb':
            d=e[2];assert bf[d]==e[3];bf[d]=e[4];bp[e[5]]+=1
        elif typ=='center':
            d=e[1]+632;assert bf[d]==e[2];bf[d]=e[3];bp[e[4]]+=1
        elif typ=='physical_add':
            _,dt,st,a,b,df,sf,word=e;d=idx(dt);s=idx(st)
            assert not word and (df,sf)==(1,0) and d<112 and s>=633
            assert bf[d]==df and bf[s]==sf
            core.add(br[d],{(o,(FSYM,)+w):v for (o,w),v in br[s].items()},F(a,b))
        else:assert typ in ('adapter','phase')
    bex=[core.expected(i,True) for i in range(632)]+[{} for _ in range(bn-632)]
    for mode in chosen:
        for i,ri in enumerate(R[mode]):
            if not ri:continue
            for j,rj in enumerate(R[mode]):
                if not rj:continue
                a=ri*rj/4
                core.add(bex[i],{(112+j,(FSYM,)):F(1)},-a)
                core.add(bex[i],core.identity(112+j),a)
    assert br==bex and bf[:632]==c['final'] and all(not z for z in br[632:])
    assert bp==paid
    backward_receipt={'all632_original_rows_checked':True,'all_original_final_frames_checked':True,
                      'helpers_autonomous_and_unchanged_logically':True,'all_owned_fields_final_zero':True,
                      'extra_owned_fields':len(yslot),'paid_profile':dict(sorted(bp.items())),
                      'opcode_census':dict(bc),'events':len(back),'max_l1_normalized_row':str(bmax),
                      'physical_frames_conjugated':True,
                      'endpoint':'Y,H unchanged; X -= [I+sum_k(r_k^T r_k/4)(F9^⊗m-I)]^T Y.',
                      'query_free_tail':'Retain ground tY_k=r_k Y/4; append physical X_i-=r_ki tY_k in conjugate(F9) output frame.'}

    blob={'schema':'actual-F9-source-DAG-pair/v2','source_sha256':sha256(raw).hexdigest(),
          'canonical':c,'program':out,'programs':{'forward':out,'backward':back},
          'original_event_origins':origins,'selected_modes':sorted(chosen),
          'owned_extra_slots':extra,'normalized_F9_symbol':FSYM,
          'owned_extra_slots_by_direction':{'forward':extra,'backward':len(yslot)},
          'physical_add_semantics':'Identity on physical data; [dstframe0,srcframe1] has normalized logical F9 effect.',
          'helper_modes':{str(k):[[i,str(a)] for i,a in sorted(v.items())] for k,v in captures.items() if k in chosen},
          'source_ancestor_original_indices':[nodes[j]['index'] for j in sorted(anc) if j>=633],
          'boundary_snapshots':[{'node':j,'owner':nodes[j]['owner'],'frame':nodes[j]['frame'],'source_event':nodes[j]['index'],'slot':slot} for j,slot in cache.items()]}
    payload=json.dumps(blob,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(payload,mtime=0)
    (HERE/f'F9-SOURCE-DAG-{tag}-WORD.json.gz').write_bytes(packed)
    result={'schema':'actual-F9-source-DAG-forward-result/v1','source_sha256':sha256(raw).hexdigest(),
            'R_source_sha256':sha256(rp.read_bytes()).hexdigest(),'word_sha256':sha256(packed).hexdigest(),
            'word_payload_sha256':sha256(payload).hexdigest(),'selected_modes':sorted(chosen),
            'source_ancestor_nodes':len(anc),'source_ancestor_original_events':sum(j>=633 for j in anc),
            'unchanged_prefix_through_original_event':cut,
            'moved_source_original_events':sum(j in anc and k>cut for k,j in events.items()),
            'all_original_Y_untouched_until_full_X_available':cut==-1,
            'source_DAG_contains_no_centers':True,'source_DAG_depends_on_no_original_Y':True,
            'boundary_snapshot_fields':len(cache),'ground_helper_mode_fields':len(hslot),
            'extra_owned_fields':extra,'peak_nonzero_owned_fields_including_original_C0':peak_nonzero_owned,
            'all_original_inputs':632,'all_original_helpers':408,'all_original_endpoints_checked':True,
            'all_original_final_frames_checked':True,'all_owned_fields_final_zero':True,
            'helpers_autonomous_and_unchanged_logically':True,
            'forward_endpoint':'X,H unchanged; Y += [I+sum_k(r_k^T r_k/4)(F9^⊗m-I)] X.',
            'paid_profile':dict(sorted(paid.items())),'events':len(out),'opcode_census':dict(counts),
            'max_l1_normalized_row':str(maxnorm),
            'physical_cache_fact':'All final raw X fields equal F9^⊗m X_i before any center consumer executes.',
            'new_gaussian_queries':0,'duplicated_paid_queries':0,
            'backward':backward_receipt,
            'helper_clean_code':'C_F=A_T+(I-A_T)F9^⊗m, A_T=I-sum_k r_k^T r_k/4; normalized main version is conjugated by actual signed K_i.',
            'conditional_same_input_full_target_decoder':'For z=C_F F9^⊗m v, recover F9^⊗m v=A_T^-1[z-(I-A_T)(F9²)^⊗m v]. This is ordinary but requires this exact z and the same retained v.',
            'status':'PASS_HELPER_CLEAN_FORWARD_AND_RAW_DUAL_FILTERED_PRODUCER; CALLER_PENDING',
            'new_supplier_or_kappa':False}
    (HERE/f'F9-SOURCE-DAG-{tag}.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
