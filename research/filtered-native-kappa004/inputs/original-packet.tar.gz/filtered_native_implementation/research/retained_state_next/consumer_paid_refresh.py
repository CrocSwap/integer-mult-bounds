#!/usr/bin/env python3
"""One paid refresh of the complete retained full-frame snapshot module.

For each native relative logical permutation of a chosen physical Gaussian
rank, test S+L*S.  A positive exact identity has ONE paid query: combine
all L-input terms before applying L, and combine the output with S.
All independent original columns, including helpers, stay in the test.
Modular negative screens are upgraded only when an exact rational dual
annihilator can be reconstructed and directly checked on every candidate.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from math import isqrt
from pathlib import Path
import argparse
import importlib.util
import json
import pickle
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
P=(1<<61)-1


def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m


def mv(cols,x):
    y=0
    while x:
        b=x&-x;y^=cols[b.bit_length()-1];x^=b
    return y


def mul(a,b):return tuple(mv(a,x) for x in b)


def residue(x):return x.numerator*pow(x.denominator,-1,P)%P


def reconstruct(a):
    """Unique rational reconstruction within sqrt(P/2), if it exists."""
    if not a:return F(0)
    bound=isqrt(P//2);r0,r1=P,a;t0,t1=0,1
    while abs(r1)>bound:
        q=r0//r1;r0,r1=r1,r0-q*r1;t0,t1=t1,t0-q*t1
    if not t1 or abs(t1)>bound:return None
    value=F(r1,t1)
    if value.denominator>bound or residue(value)!=a:return None
    return value


class ModularBasis:
    def __init__(self,old=None):self.rows={} if old is None else dict(old.rows)
    def reduce(self,row):
        v=dict(row)
        while v and min(v) in self.rows:
            p=min(v);fac=v[p]
            for k,x in self.rows[p].items():
                z=(v.get(k,0)-fac*x)%P
                if z:v[k]=z
                else:v.pop(k,None)
        return v
    def insert(self,row):
        v=self.reduce(row)
        if not v:return
        p=min(v);inv=pow(v[p],-1,P);self.rows[p]={k:x*inv%P for k,x in v.items()}
    def dual(self,free_coordinate):
        out={free_coordinate:1}
        for pivot in sorted((p for p in self.rows if p<free_coordinate),reverse=True):
            value=-sum(x*out.get(k,0) for k,x in self.rows[pivot].items())%P
            if value:out[pivot]=value
        return out


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--rank',type=int,default=2)
    ap.add_argument('--direction',default='backward',choices=['forward','backward'])
    ap.add_argument('--limit',type=int,default=0);args=ap.parse_args();started=time.monotonic()
    cache=HERE/('CONSUMER-FULL-FRAME-'+args.direction.upper()+'.pickle')
    data=pickle.loads(cache.read_bytes());oldrows=data['snapshot_rows'];maps=data['actual_permutations']
    ce=load('consumer_refresh_ce',ROOT/'upstream/research/coded-native-caller/clifford_exact.py')
    ident=tuple(1<<i for i in range(9));unique=sorted(set(maps.values()))
    inverse=lambda g:ce.transpose(ce.inv(ce.transpose(g,9),9),9)
    invs={g:inverse(g) for g in unique};operators={};census=Counter();pairs=[]
    for i,a in enumerate(unique):
        for b in unique[:i]:
            g=mul(a,invs[b]);git=ce.transpose(inverse(g),9)
            rank=ce.rank([x^y for x,y in zip(g,git)]);census[rank]+=1
            pairs.append({'left':list(a),'right':list(b),'rank':rank})
            if rank==args.rank:
                operators.setdefault(g,(a,b));operators.setdefault(inverse(g),(b,a))
    assert 0 not in census and 1 not in census
    plans=sorted(operators.items())
    if args.limit:plans=plans[:args.limit]
    results=[]
    for number,(g,(a,b)) in enumerate(plans):
        tick=time.monotonic()
        newrows=[{(owner,mul(g,op)):x for (owner,op),x in row.items()} for row in oldrows]
        rows=oldrows+newrows
        # Integer indices make sparse elimination substantially faster.
        labels=sorted({op for row in rows for owner,op in row}|{ident});label={op:i for i,op in enumerate(labels)};n=len(labels)
        keyed=[{owner*n+label[op]:x for (owner,op),x in row.items()} for row in rows]
        modular=[{k:residue(x) for k,x in row.items()} for row in keyed]
        basis=ModularBasis()
        for row in modular:basis.insert(row)
        tests=[];duals=[]
        for bank,offset in [('X',0),('Y',112)]:
            for mode,r in enumerate(data['R']):
                target={(owner+offset)*n+label[ident]:x for owner,x in enumerate(r) if x}
                reduced=basis.reduce({k:residue(x) for k,x in target.items()})
                if not reduced:
                    # A modular hit remains a candidate until rationally lifted.
                    tests.append({'target_bank':bank,'mode':mode,'modular_span_hit':True,
                                  'exact_identity_emitted':False});continue
                witness_mod=basis.dual(min(reduced));witness={k:reconstruct(v) for k,v in witness_mod.items()}
                checked=all(x is not None for x in witness.values())
                if checked:
                    checked=all(sum(v*witness.get(k,F(0)) for k,v in row.items())==0 for row in keyed)
                target_value=sum(v*witness.get(k,F(0)) for k,v in target.items()) if checked else None
                checked=checked and bool(target_value)
                record={'target_bank':bank,'mode':mode,'modular_span_hit':False,
                        'exact_rational_annihilator_verified':checked,'dual_terms':len(witness),
                        'target_pairing':str(target_value) if checked else None}
                if checked:
                    record['dual']=[[k//n,list(labels[k%n]),str(v)] for k,v in sorted(witness.items()) if v]
                    duals.append((bank,mode,witness))
                tests.append(record)
        physical=ce.fourier(9).adjoint().then(ce.perm(9,ce.transpose(g,9))).then(ce.fourier(9))
        assert ce.rank([x for x,z,p in physical.tab[9:]])==args.rank
        # Raw-dual physical implementation is conjugated, without changing
        # Gaussian rank.  The exact compiler recipe is emitted only on hits.
        hit=any(t['modular_span_hit'] for t in tests)
        recipe=None
        if hit:
            compiler,_=ce.lower_child(physical);assert compiler['rank']==args.rank;recipe=compiler
        rec={'operator_index':number,'logical_permutation_columns':list(g),
             'native_relative_columns':[list(a),list(b)],'physical_gaussian_rank':args.rank,
             'candidate_snapshot_rows':len(rows),'operator_labels':len(labels),
             'span_rank_mod_prime':len(basis.rows),'tests':tests,
             'physical_forward_lift_recipe_if_hit':recipe,
             'physical_backward_lift':'complex conjugate of the forward lift',
             'elapsed_seconds':round(time.monotonic()-tick,3)}
        results.append(rec)
        print('PAID_REFRESH',number,'/',len(plans),'rank',args.rank,'basis',len(basis.rows),
              'hits',[(x['target_bank'],x['mode']) for x in tests if x['modular_span_hit']],
              'exact negatives',sum(x.get('exact_rational_annihilator_verified',False) for x in tests),
              'seconds',rec['elapsed_seconds'],flush=True)
        out={'schema':'native-one-paid-full-frame-refresh/v1','direction':args.direction,
             'cache_sha256':sha256(cache.read_bytes()).hexdigest(),'source_sha256':data['source_sha256'],
             'R_sha256':data['R_sha256'],'prime':P,'native_relative_rank_census':dict(sorted(census.items())),
             'tested_rank':args.rank,'distinct_refreshes':len(operators),'results':results,
             'query_contract':'Each identity in S+L*S uses one additional paid rank-r query: first gather the entire L input from retained owned snapshots, then apply L and ordinarily combine with S. No native paid query is removed or duplicated.',
             'all_width_operator_independence':'Distinct binary linear permutations on9 bits have independent tensor powers at width9: apply to the single basis input (e0,e1,...,e8), whose distinct output tuples are their full column matrices. Thus any exact rational annihilator over distinct labels excludes a uniform all-width identity in this fixed finite recoding family.',
             'scope':'One common rank-r relative native transport applied to arbitrary scalar combinations of all native full-frame snapshots. Additional paid queries, different frame births, non-native relative operators, and column-mixing recodings remain open.',
             'new_kappa_claimed':False,'elapsed_seconds':round(time.monotonic()-started,3)}
        dest=HERE/f'CONSUMER-PAID-REFRESH-{args.direction.upper()}-{args.rank}.json'
        dest.write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
