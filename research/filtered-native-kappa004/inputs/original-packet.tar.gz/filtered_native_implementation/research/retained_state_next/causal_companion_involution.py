#!/usr/bin/env python3
"""A literal two-native-word companion involution across opposite roles.

The source/consumer edge is an involution in logical/common-Q coordinates.
It is not declared to be a free physical owner recoding across X/Y roles.
All four main banks and both helper families remain independent originals.
"""
from collections import Counter
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
    spec.loader.exec_module(mod);return mod


def conjugate(ce,op):
    circuit=[]
    for e in op.circuit:
        if e[0]=='D':circuit.append(('D',e[1],tuple((-x)%4 for x in e[2])))
        elif e[0]=='C':circuit.append(('C',e[1],-e[2]))
        elif e[0]=='phase':circuit.append(('phase',(-e[1])%4))
        else:circuit.append(e)
    return ce.Op(op.n,tuple((x,z,(-ph)%4) for x,z,ph in op.tab),circuit)


def main():
    paths=[HERE/'F9-SOURCE-DAG-ALL8-COMPRESSED-WORD.json.gz',HERE/'RAW-DUAL-LATE-X-WORD.json.gz']
    raw=[p.read_bytes() for p in paths];sources=[json.loads(gzip.decompress(x)) for x in raw]
    canonical=sources[0]['canonical'];assert canonical==sources[1]['canonical']
    base=[sources[0]['programs']['forward'],sources[1]['program']]
    # Omitting the F-fed owned-center terms / raw-dual tails gives the
    # helper-clean scalar A producer, preserving the causal schedules.
    words=[[e for e in es if e[0]!='physical_add'] for es in base]
    assert [sum(e[0]=='physical_add' for e in es) for es in base]==[448,448]
    extra=[sources[0]['owned_extra_slots_by_direction']['forward'],sources[1]['owned_extra_slots']]
    core=load('companion_native_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    cp=ROOT/'upstream/research/coded-native-caller/clifford_exact.py'
    ce=load('companion_clifford',cp)
    def equal(x,y):return x.tab==y.tab and x.zero_state()==y.zero_state()
    F=ce.fourier(9);F2=F.then(F);barF=conjugate(ce,F)
    monF2,recipeF2=ce.monomial(F2)
    assert all(e[0] in ('P','D','X','phase') for e in monF2.circuit)
    assert equal(F.then(monF2),barF)
    crosses=[]
    for i in range(112):
        S=ce.canonical_frame(9,canonical['frames'][canonical['final'][112+i]])
        barS=conjugate(ce,S)
        op=barS.adjoint().then(S)
        mon,recipe=ce.monomial(op)
        assert all(e[0] in ('P','D','X','phase') for e in mon.circuit)
        assert equal(barS.then(mon),S)
        crosses.append({'port':i,'word':mon.circuit,'recipe':recipe})
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    R=[[int(x) for x in row] for row in json.loads(rp.read_text())]
    assert len(R)==8 and all(len(r)==112 for r in R)
    assert [[sum(a*b for a,b in zip(r,s)) for s in R] for r in R]==[[56*int(i==j) for j in range(8)] for i in range(8)]
    Q=[[sum(r[i]*r[j] for r in R) for j in range(112)] for i in range(112)]
    assert all(sum(Q[i][k]*Q[k][j] for k in range(112))==56*Q[i][j] for i in range(112) for j in range(112))
    A=[[Fr(i==j)-Fr(Q[i][j],4) for j in range(112)] for i in range(112)]

    cuts=[next(k for k,e in enumerate(words[0]) if e==['phase','consume_retained_source_snapshots']),
          next(k for k,e in enumerate(words[1]) if e==['phase','late_X_input_admission'])]
    out=[['phase','finish_both_independent_source_banks']]
    for copy in range(2):out.extend([['native',copy,e] for e in words[copy][:cuts[copy]+1]])
    out.append(['phase','both_opposite_consumer_inputs_still_unread'])
    for copy in range(2):out.extend([['native',copy,e] for e in words[copy][cuts[copy]+1:]])
    out.append(['phase','ordinary_companion_cross_updates'])
    for item in crosses:
        i=item['port'];out.append(['cross_y_add',i,item['word']])
    for k,row in enumerate(R):
        out.append(['mode_clear',k])
        for i,r in enumerate(row):
            if r:out.append(['mode_add_forward_X',k,i,r])
        for i,r in enumerate(row):
            if r:out.append(['cross_X_mode_add',i,k,-3*r,monF2.circuit])
        out.append(['mode_clear',k])
    out.append(['phase','done'])

    sizes=[633+x for x in extra]
    live=[[core.identity(632*c+i) for i in range(632)]+[{} for _ in range(sizes[c]-632)] for c in range(2)]
    frames=[canonical['start'][:]+[None for _ in range(sizes[c]-632)] for c in range(2)]
    modes=[{} for _ in range(8)];paid=[Counter(),Counter()];counts=Counter();maxnorm=Fr(1)
    def ix(r):return r[1]+(632 if r[0]=='C' else 0)
    source_cut_checked=False
    for pos,e in enumerate(out):
        typ=e[0];counts[typ]+=1
        touched=None
        if typ=='native':
            _,copy,z=e;kind=z[0]
            if kind=='scalar':
                a,f=z[1:];d=ix(a[1]);op=a[0]
                if op=='clear':assert d>=632;live[copy][d]={};frames[copy][d]=f
                else:
                    assert frames[copy][d]==f,(pos,e,frames[copy][d])
                    if op in ('copy','add'):
                        s=ix(a[2]);assert frames[copy][s]==f
                        if op=='copy':assert d>=632;live[copy][d]=dict(live[copy][s])
                        else:core.add(live[copy][d],live[copy][s],Fr(a[3],a[4]))
                    else:assert op=='scale';live[copy][d]={k:v*Fr(a[2],a[3]) for k,v in live[copy][d].items() if v*a[2]}
                touched=live[copy][d]
            elif kind=='warp':
                d=ix(z[1]);assert frames[copy][d]==z[3]
                live[copy][d]=core.warp(live[copy][d],z[2],bool(copy));frames[copy][d]=z[4];touched=live[copy][d]
            elif kind=='climb':
                d=z[2];assert frames[copy][d]==z[3];frames[copy][d]=z[4];paid[copy][z[5]]+=1
            else:assert kind in ('phase','adapter')
        elif typ=='cross_y_add':
            i=e[1];assert frames[0][112+i]==frames[1][112+i]==canonical['final'][112+i]
            assert e[2]==crosses[i]['word'] or json.loads(json.dumps(e[2]))==json.loads(json.dumps(crosses[i]['word']))
            # Exact phase/tableau proof above shows physical W maps bar(S)
            # to S; the induced logical cross-operator is the identity.
            core.add(live[0][112+i],live[1][112+i],Fr(1));touched=live[0][112+i]
        elif typ=='mode_clear':modes[e[1]]={}
        elif typ=='mode_add_forward_X':
            _,k,i,r=e;assert frames[0][i]==1
            core.add(modes[k],live[0][i],Fr(r));touched=modes[k]
        elif typ=='cross_X_mode_add':
            _,i,k,r,word=e;assert frames[1][i]==1
            assert word==monF2.circuit
            # F2 F=bar(F) exactly; physical mode is held in forward F.
            core.add(live[1][i],modes[k],Fr(r));touched=live[1][i]
        else:
            assert typ=='phase'
            if e==['phase','both_opposite_consumer_inputs_still_unread']:
                assert all(live[0][i]==core.identity(i) and frames[0][i]==1 for i in range(112))
                assert all(live[0][i]==core.identity(i) and frames[0][i]==0 for i in range(112,224))
                assert all(live[1][i]==core.identity(632+i) and frames[1][i]==canonical['start'][i] for i in range(112))
                assert all(live[1][i]==core.identity(632+i) and frames[1][i]==canonical['final'][i] for i in range(112,224))
                source_cut_checked=True
        if touched is not None:maxnorm=max(maxnorm,sum(map(abs,touched.values()),Fr(0)))
    expected=[[core.identity(632*c+i) for i in range(632)] for c in range(2)]
    for i in range(112):
        core.add(expected[0][112+i],core.identity(632+112+i),Fr(1))
        for j in range(112):
            if A[i][j]:
                core.add(expected[0][112+i],core.identity(j),A[i][j])
                core.add(expected[1][i],core.identity(632+112+j),-A[i][j])
            if Q[i][j]:core.add(expected[1][i],core.identity(j),Fr(-3*Q[i][j]))
    for c in range(2):
        assert live[c][:632]==expected[c]
        assert frames[c][:632]==canonical['final']
        assert all(not x for x in live[c][632:])
        assert dict(sorted(paid[c].items()))=={1:2201,2:412,3:510,4:127,5:40}
    assert all(not x for x in modes) and source_cut_checked

    gaugepath=ROOT/'upstream/research/coded-native-caller/gauge.py'
    gm=load('companion_gauge',gaugepath);a=gm.Algebra(1)
    one=a.one;q=a.gen(1);qi=a.inv(q);d=a.D(0);c=a.gen(2)
    b=a.add(one,a.neg(a.mul(c,c)))
    physical=[[a.mul(d,c,qi),d],[a.mul(b,d),a.neg(a.mul(q,d,c))]]
    hnormalized=a.mm(a.diag(q,one),physical,a.diag(one,qi))
    companion=[[c,one],[b,a.neg(c)]]
    assert hnormalized==a.mm(companion,a.diag(d,d))
    assert a.mm(companion,companion)==a.diag(one,one)
    physical_source_code=a.mm(a.diag(one,qi),companion,a.diag(one,q))
    assert physical_source_code!=companion
    predecessor=HERE/'CAUSAL-COMPANION-UNCOMPRESSED-WORD.json.gz'
    predecessor_receipt=HERE/'CAUSAL-COMPANION-UNCOMPRESSED-INVOLUTION.json'
    provenance={'uncompressed_pair_word_sha256':sha256(predecessor.read_bytes()).hexdigest(),
                'uncompressed_pair_receipt_sha256':sha256(predecessor_receipt.read_bytes()).hexdigest(),
                'change':'Integrate exact same-frame forward snapshot compression; all backward events, physical cross words and independent endpoints retained.'}
    blob={'schema':'literal-opposite-role-companion-pair/v2','source_word_sha256':[sha256(x).hexdigest() for x in raw],
          'predecessor_provenance':provenance,
          'canonical':canonical,'program':out,'owned_extra_slots_by_copy':extra,
          'shared_cross_mode_fields':8,'copy_directions':['forward','backward'],
          'cross_Y_words':crosses,'cross_X_word':monF2.circuit}
    payload=json.dumps(blob,separators=(',',':')).encode();compressed=gzip.compress(payload,mtime=0)
    (HERE/'CAUSAL-COMPANION-WORD.json.gz').write_bytes(compressed)
    result={'schema':'causal-opposite-role-companion-involution/v2',
      'status':'PASS_LITERAL_PAIR_AND_EXACT_INVOLUTION; CALLER_TARGET_ADMISSION_OPEN',
      'source_word_sha256':[sha256(x).hexdigest() for x in raw],
      'predecessor_provenance':provenance,
      'source_R_sha256':sha256(rp.read_bytes()).hexdigest(),
      'clifford_source_sha256':sha256(cp.read_bytes()).hexdigest(),
      'word_sha256':sha256(compressed).hexdigest(),'word_payload_sha256':sha256(payload).hexdigest(),
      'all1264_original_endpoints_checked':True,'all816_helpers_autonomous':True,
      'all_actual_frames_checked':True,'all_owned_final_zero':True,
      '112_Y_cross_words_phase_exact_and_monomial':True,
      'X_cross_F9_squared_phase_exact_and_monomial':True,
      'both_source_banks_complete_before_other_original_inputs_consumed':True,
      'owned_extra_slots_by_copy':extra,'shared_extra_cross_mode_fields':8,
      'events':len(out),'opcode_census':dict(counts),
      'max_l1_normalized_program_row':str(maxnorm),
      'paid_profile_each':dict(sorted(paid[0].items())),
      'paid_profile_total':dict(sorted((paid[0]+paid[1]).items())),
      'independent_helpers_total':{4:56,7:14,8:94,9:652},
      'main_original_banks':4,'main_original_fields':448,
      'additional_recursive_queries':0,'additional_ordinary_cross_adds':1008,
      'additional_cross_mode_clears':16,
      'logical_endpoint':{
        'X_forward':'x_f',
        'Y_forward':'y_f+A x_f+y_b',
        'X_backward':'x_b+(I-A^2)x_f-A y_b',
        'Y_backward':'y_b',
        'helpers':'All816 original helpers unchanged logically, with their native independent transform targets.'},
      'logical_companion':'M_A=[[A,I],[I-A^2,-A]], M_A^2=I for any A; here I-A^2=-3R^T R.',
      'normalized_companion':'M_C=[[C,I],[I-C^2,-C]], M_C^2=I, [M_C,F]=0.',
      'normalized_source_target_order':{'source':['X_forward','Y_backward'],'consumer':['Y_forward','X_backward']},
      'normalized_role_gauges':'H_source=diag(I,Q); H_consumer=diag(Q,I).',
      'normalized_full_independent_consumer_equation':'H_consumer [Yf_out,Xb_out]^T = diag(D,D) H_consumer [yf_original,xb_original]^T + M_C diag(D,D) H_source [xf_original,yb_original]^T.',
      'physical_cross_updates':['raw Yf_i += W_i raw Yb_i, W_i= S_i conjugate(S_i)^-1, emitted monomial.',
                                'raw Xb += -3 F9^2 R^T R raw Xf; gather all eight modes explicitly, with original Xf preserved.'],
      'all_size_scope':'Exact native free-group identity plus source-bound monomial tableau and absolute-phase identities tensor-lift by column. The scalar owner matrix is evaluated directly, not tensor-powered as a sum.',
      'physical_gauge_control_rejected':True,
      'unresolved':'M_C mixes opposite physical roles. H_source^-1 M_C H_source contains odd Q. Its abstract involution is not a free physical code, and no independent main Gaussian target list or kappa gain is admitted.'}
    (HERE/'CAUSAL-COMPANION-INVOLUTION.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
