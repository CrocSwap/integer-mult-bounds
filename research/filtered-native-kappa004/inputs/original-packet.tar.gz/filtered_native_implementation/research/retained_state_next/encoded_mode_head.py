#!/usr/bin/env python3
"""Literal one-query finite-order head on one actual encoded R mode.

H_k = I - Pi_k + V_k Q L_k, with L_k V_l = delta_kl I.
Every original is arbitrary; only two declared owned fields are copied,
queried and cleared.  K_i are actual phase-correct physical monomials.
"""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip
import json
import time

import consumer_kg_module as kg

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
NP=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
RP=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
T=112;U=113


def add(target,source,coefficient):
    assert target is not source
    for key,value in source.items():
        v=target.get(key,Q(0))+coefficient*value
        if v:target[key]=v
        else:target.pop(key,None)


def actual_K(ce,port):
    return ce.perm(9,tuple(port['G_rows'])).then(
        ce.diag(9,(0,)*9,tuple(2*((port['Z_mask']>>j)&1) for j in range(9))))


def program(row,power):
    assert power in (1,-1,2)
    active=[i for i,r in enumerate(row) if r]
    events=[{'op':'CLEAR','field':T}]
    events.extend({'op':'MAPPED_ADD','destination':T,'source':i,
                   'map':f'K_{i}','coefficient':str(row[i]/56)} for i in active)
    events.append({'op':'COPY','destination':U,'source':T})
    if power==2:
        events.append({'op':'MONOMIAL','field':U,'map':'Q_squared'})
    else:
        events.append({'op':'GAUSSIAN','field':U,'rank':1,'query_word':[['C',1,power]]})
    events.append({'op':'ADD','destination':U,'source':T,'coefficient':'-1'})
    events.extend({'op':'MAPPED_ADD','destination':i,'source':U,
                   'map':f'K_inverse_{i}','coefficient':str(row[i])} for i in active)
    events.extend([{'op':'CLEAR','field':U},{'op':'CLEAR','field':T}])
    return events


def replay(events,initial=None):
    """Exact symbolic replay in authenticated per-owner K coordinates.

    Original physical field i is K_i^-1 z_i; owned fields are in the
    common physical coefficient chart. MAPPED_ADD signatures below are
    accepted only after the emitter authenticates their literal maps.
    A key (owner,p) means Q^p applied to arbitrary z_owner, p modulo4.
    """
    rows=([{(i,0):Q(1)} for i in range(112)]+[{},{}]) if initial is None else [dict(r) for r in initial]
    assert len(rows)==114 and not rows[T] and not rows[U]
    maximum=max(sum(map(abs,row.values()),Q(0)) for row in rows)
    queries=Counter();touched=set()
    for event in events:
        kind=event['op']
        if kind=='CLEAR':
            destination=event['field'];assert destination in (T,U)
            rows[destination]={}
        elif kind=='COPY':
            destination=event['destination'];source=event['source']
            assert destination==U and source==T
            rows[destination]=dict(rows[source])
        elif kind in ('MAPPED_ADD','ADD'):
            destination=event['destination'];source=event['source']
            if kind=='MAPPED_ADD':
                if destination==T:
                    assert source<112 and event['map']==f'K_{source}'
                else:
                    assert destination<112 and source==U
                    assert event['map']==f'K_inverse_{destination}'
            else:assert destination==U and source==T
            add(rows[destination],rows[source],Q(event['coefficient']))
        else:
            destination=event['field'];assert destination==U
            if kind=='GAUSSIAN':
                assert event['rank']==1 and len(event['query_word'])==1
                op,axis,shift=event['query_word'][0]
                assert op=='C' and axis==1 and shift in (-1,1)
                queries[1]+=1
            else:
                assert kind=='MONOMIAL' and event['map']=='Q_squared'
                shift=2
            rows[destination]={(owner,(power+shift)%4):a for (owner,power),a in rows[destination].items()}
        touched.add(destination)
        maximum=max(maximum,sum(map(abs,rows[destination].values()),Q(0)))
    assert not rows[T] and not rows[U]
    return rows,queries,maximum,touched


def expected(rows,k,power):
    answer=[{(i,0):Q(1)} for i in range(112)]+[{},{}]
    for i,ri in enumerate(rows[k]):
        if not ri:continue
        for j,rj in enumerate(rows[k]):
            if rj:
                add(answer[i],{(j,power%4):Q(1),(j,0):Q(-1)},ri*rj/56)
    return answer


def main():
    begin=time.monotonic();ce=kg.load('encoded_mode_head_ce',kg.CLIFFORD)
    ports=json.loads(NP.read_text())['ports'];R=[[Q(a) for a in r] for r in json.loads(RP.read_text())]
    assert len(ports)==112 and len(R)==8
    for k in range(8):
        for l in range(8):assert sum(a*b for a,b in zip(R[k],R[l]))==56*(k==l)
    q=ce.cgate(9,1);q2=q.then(q);q4=q2.then(q2)
    ordinary_square=ce.xgate(9,1)
    assert q2.tab==ordinary_square.tab and q2.zero_state()==ordinary_square.zero_state()
    assert q4.tab==ce.ident(9).tab and q4.zero_state()==ce.ident(9).zero_state()
    maps={};signed_controls=0
    for i,port in enumerate(ports):
        K=actual_K(ce,port);inverse=K.adjoint()
        for tag,op in ((f'K_{i}',K),(f'K_inverse_{i}',inverse)):
            assert ce.rank([x for x,z,p in op.tab[9:]])==0
            compiled,rec=ce.monomial(op)
            assert compiled.tab==op.tab and compiled.zero_state()==op.zero_state()
            # Record all ordinary address and phase data, not merely a
            # tableau whose global phase would be ambiguous.
            maps[tag]={'word':compiled.circuit,'monomial':rec,'tableau':op.tab}
        cancel=K.then(inverse)
        assert cancel.tab==ce.ident(9).tab and cancel.zero_state()==ce.ident(9).zero_state()
        # Every arbitrary normalized z_i corresponds bijectively to an
        # arbitrary original physical x_i=K_i^-1 z_i.
        if port['Z_mask']:
            plain=ce.perm(9,tuple(port['G_rows']))
            assert K.tab!=plain.tab
            signed_controls+=1
    mon,rec=ce.monomial(ordinary_square)
    maps['Q_squared']={'word':mon.circuit,'monomial':rec,'tableau':ordinary_square.tab}
    assert signed_controls==112
    programs={};reviews=[];maximum=Q(0)
    for k,r in enumerate(R):
        assert sum(bool(a) for a in r)==56
        entry={}
        for name,power in [('positive',1),('inverse',-1),('square',2)]:
            events=program(r,power);endpoint,paid,norm,touched=replay(events)
            assert endpoint==expected(R,k,power)
            assert paid==Counter({1:1}) if power!=2 else not paid
            assert touched & set(range(112))=={i for i,a in enumerate(r) if a}
            assert all(endpoint[i]=={(i,0):Q(1)} for i,a in enumerate(r) if not a)
            maximum=max(maximum,norm)
            entry[name]=events
        four=None;fourpaid=Counter()
        for _ in range(4):
            four,paid,norm,_=replay(entry['positive'],four);fourpaid.update(paid)
        identity=[{(i,0):Q(1)} for i in range(112)]+[{},{}]
        assert four==identity and fourpaid==Counter({1:4})
        two,_,_,_=replay(entry['positive']);two,_,_,_=replay(entry['positive'],two)
        ordinary,paid,_,_=replay(entry['square'])
        assert two==ordinary and not paid
        inverse,_,_,_=replay(entry['inverse']);inverse,_,_,_=replay(entry['positive'],inverse)
        assert inverse==identity
        programs[str(k)]=entry
        reviews.append({'mode':k,'events_per_program':len(entry['positive']),
                        'active_originals':56,'arbitrary_originals_checked':112,
                        'one_query_positive_and_inverse':True,'square_query_free':True,
                        'fourth_power_identity':True,'owned_fields_final_zero':True,
                        'max_operator_row_l1':str(max(replay(entry[name])[2] for name in entry))})
    commuting=0
    for k in range(8):
        for l in range(k+1,8):
            left,_,_,_=replay(programs[str(k)]['positive'])
            left,_,_,_=replay(programs[str(l)]['positive'],left)
            right,_,_,_=replay(programs[str(l)]['positive'])
            right,_,_,_=replay(programs[str(k)]['positive'],right)
            assert left==right
            commuting+=1
    artifact={'schema':'literal-encoded-owner-mode-gaussian-head/v1',
              'source_normalizers_sha256':sha256(NP.read_bytes()).hexdigest(),
              'source_R_sha256':sha256(RP.read_bytes()).hexdigest(),
              'clifford_source_sha256':sha256(kg.CLIFFORD.read_bytes()).hexdigest(),
              'base_data_bits':9,'head_axis_mask':1,
              'original_fields':list(range(112)),'owned_fields':[T,U],
              'initial_owned_values':'zero; COPY overwrites only owned U, CLEAR only owned T/U',
              'source_R':[[str(a) for a in r] for r in R],
              'monomial_maps':maps,'programs':programs,
              'opcode_contract':{
                  'MAPPED_ADD':'destination += coefficient * M^tensor_width(source); the map permutes addresses and applies the recorded Z4 phases without modifying source.',
                  'ADD':'destination += coefficient * source in the same physical array coordinates.',
                  'COPY':'overwrite a declared owned destination with a physical identity copy of source.',
                  'CLEAR':'set only a declared owned field to zero.',
                  'GAUSSIAN':'apply the displayed literal C gate tensor-powered across digit columns to the owned field; charge one rank1 query.',
                  'MONOMIAL':'apply the recorded ordinary monomial tensor-powered across digit columns in place.'},
              'tensor_convention':'The9-bit maps, including their absolute phases, are tensor-powered. Rational R/56 and R scalar coefficients multiply the complete array once, outside tensor powers. These maps may be embedded on any ordered9-axis stage with head at its first axis; all other data axes are spectators.',
              'physical_target':'H_k=I−Pi_k+V_k Q L_k, L_k=(1/56)r_k diag(K_i), V_k=diag(K_i^-1)r_k^T, Pi_k=V_k L_k.',
              'scope':'A standalone local112-original linear update with two owned fields. Other original/helper banks are untouched. No unchanged-native center replacement or complete p3 caller repair is claimed.'}
    wp=HERE/'ENCODED-MODE-HEAD-WORD.json.gz'
    wp.write_bytes(gzip.compress(json.dumps(artifact,separators=(',',':')).encode(),mtime=0))
    receipt={'schema':'literal-encoded-owner-mode-gaussian-head-review/v1','status':'EXACT_LITERAL_PROGRAMS_PASS',
             'word_sha256':sha256(wp.read_bytes()).hexdigest(),
             'source_normalizers_sha256':artifact['source_normalizers_sha256'],
             'source_R_sha256':artifact['source_R_sha256'],
             'programs_per_mode':['positive','inverse','square'],'actual_modes':8,
             'all_originals_arbitrary':112,'declared_owned_fields':2,
             'all_other_original_and_helper_banks':'untouched',
             'exact_phase_monomial_maps':225,'omitted_source_sign_negative_controls':signed_controls,
             'mode_orthogonality':'R R^T=56 I8; hence L_k V_l=delta_kl I, Pi_k Pi_l=delta_kl Pi_k.',
             'finite_order':'H_k^a=I−Pi_k+V_k Q^a L_k; H_k^4=I and H_k^-1=H_k^3.',
             'ordinary_square':'Q²=X_head with absolute phase1; H_k²=I−Pi_k+V_k X_head L_k uses no Gaussian query.',
             'cross_mode_commutators_checked':commuting,
             'positive_or_inverse_invoice':{'rank1_queries':1,'owned_fields':2,
                  'mapped_gather_adds':56,'mapped_scatter_adds':56,'ordinary_unmapped_adds':1,
                  'owned_copies':1,'owned_clears':3,'events':118},
             'square_invoice':{'rank1_queries':0,'owned_fields':2,'ordinary_monomial_applications':1,
                  'mapped_gather_adds':56,'mapped_scatter_adds':56,'ordinary_unmapped_adds':1,
                  'owned_copies':1,'owned_clears':3,'events':118},
             'maximum_single_program_operator_row_l1':str(maximum),
             'error_contract':'With exact ordinary instructions, a maximum L2 input error delta per original field and one L2 query error epsilon give all-prefix and final field errors at most3 delta+epsilon. This uses unitary physical K/Q, sum|r|/56=1, and one subtraction; it is not a certificate for rounded ordinary macros or an outer recursive precision budget.',
             'phase_and_tensor_convention':artifact['tensor_convention'],
             'scope':artifact['scope'],'new_kappa_claimed':False,
             'mode_results':reviews,'seconds':time.monotonic()-begin}
    assert all(item['events_per_program']==118 for item in reviews)
    out=HERE/'ENCODED-MODE-HEAD.json';out.write_text(json.dumps(receipt,indent=2)+'\n')
    print('PASS',out,'word',wp,'seconds',receipt['seconds'],flush=True)


if __name__=='__main__':main()
