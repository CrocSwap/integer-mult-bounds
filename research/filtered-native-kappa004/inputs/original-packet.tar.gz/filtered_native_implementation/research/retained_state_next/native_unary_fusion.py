#!/usr/bin/env python3
"""Census maximal unread unary owner paths in the original native word.

The maximal family permits arbitrary unrelated-owner events in between,
all same-owner scalar scales, and native monomial warps.  An ADD involving
the owner in either position is a genuine read barrier; CLEAR/COPY is a
birth/read barrier.  Adapter and phase markers are optionally ignored.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
import json

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SOURCE=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'


def index(ref):return ref[1]+(632 if ref[0]=='C' else 0)


def census(program,adapter_barrier):
    running=[[] for _ in range(633)];finished=[]
    def close(owner,barrier):
        if running[owner]:
            finished.append({'owner':owner,'events':running[owner],
                             'right_barrier':barrier})
            running[owner]=[]
    for pos,e in enumerate(program):
        kind=e[0]
        if kind=='scalar':
            a=e[1]
            if a[0]=='scale':running[index(a[1])].append(pos)
            else:
                assert a[0] in ('add','copy','clear')
                close(index(a[1]),pos)
                if a[0] in ('add','copy'):close(index(a[2]),pos)
        elif kind=='climb':running[e[2]].append(pos)
        elif kind=='center':running[632+e[1]].append(pos)
        elif kind=='warp':running[index(e[1])].append(pos)
        elif kind=='adapter':
            if adapter_barrier:close(e[2],pos)
        else:assert kind=='phase'
    for owner in range(633):close(owner,len(program))
    hist=Counter();candidates=[];paid_covered=[]
    for run in finished:
        events=[program[i] for i in run['events']]
        queries=[i for i in run['events'] if program[i][0] in ('climb','center')]
        warps=[i for i in run['events'] if program[i][0]=='warp']
        hist[len(queries)]+=1;paid_covered.extend(queries)
        if len(queries)>=2 or (queries and warps):
            candidates.append({**run,'queries':queries,'warps':warps})
    expected=[i for i,e in enumerate(program) if e[0] in ('climb','center')]
    assert sorted(paid_covered)==expected
    return {'adapter_markers_are_barriers':adapter_barrier,
            'maximal_unread_owner_runs':len(finished),
            'run_histogram_by_paid_queries':dict(sorted(hist.items())),
            'total_paid_queries_covered':len(expected),
            'multiquery_or_query_warp_runs':candidates}


def main():
    raw=SOURCE.read_bytes();source=json.loads(gzip.decompress(raw))
    outcomes={name:[census(program,barrier) for barrier in (True,False)]
              for name,program in source['programs'].items()}
    assert all(not r['multiquery_or_query_warp_runs'] for a in outcomes.values() for r in a)
    result={'status':'EXACT_MAXIMAL_UNREAD_UNARY_FUSION_FAMILY_HAS_NO_CANDIDATES',
            'source':str(SOURCE.relative_to(ROOT)),'source_sha256':sha256(raw).hexdigest(),
            'all_originals':632,'owned_center_fields':1,'outcomes':outcomes,
            'conclusion':'Every paid query is separated from any other paid query or native monomial warp on that owner by a genuine scalar read/birth contact. The count remains true even when all adapter and phase markers are ignored. Scalar scales commute with the linear query and do not change its Gaussian rank. Therefore no new Clifford compiler call is needed for this family.',
            'prior_scope':'Earlier scalar-refactoring recomposition already fused canonical nested climbs. This census additionally permits fusion across native monomial warps and unary scales, across arbitrary unrelated-owner events, but finds no such paid path.',
            'not_excluded':'Changing an intervening ADD, using a retained copy to avoid a genuine read, joint multi-owner synthesis, or a different circuit/target portfolio.'}
    out=HERE/'NATIVE-UNARY-FUSION.json';out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
