#!/usr/bin/env python3
"""Full-frame and rank8 observations of the actual clean center-free word.

The helper-clean prefix is retained.  Only the filtered physical F9 tails
are omitted, leaving the scalar code A endpoint.  Every original remains
arbitrary, and all eight original rank8 queries are already absent.
"""
from collections import Counter, defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip
import json
import pickle
import time

import consumer_kg_module as kg

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SOURCE=HERE/'F9-SOURCE-DAG-ALL8-WORD.json.gz'
ORIGINAL=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
OBSERVATIONS=ROOT/'research/operator_alignment_next/RANK1-SNAPSHOT-COMPLETION.json'


def main():
    begun=time.monotonic();raw=SOURCE.read_bytes();blob=json.loads(gzip.decompress(raw));c=blob['canonical']
    oraw=ORIGINAL.read_bytes();original=json.loads(gzip.decompress(oraw))
    assert blob['source_sha256']==sha256(oraw).hexdigest()
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    R=[[Q(v) for v in row] for row in json.loads(rp.read_text())]
    program=[e for e in blob['programs']['backward'] if e[0]!='physical_add']
    offset=next(i for i,e in enumerate(program) if e==original['programs']['backward'][0]);assert offset==823
    native=original['programs']['backward']
    for i,e in enumerate(native):
        want=['scalar',['clear',['C',e[1]]],e[3]] if e[0]=='center' else e
        assert program[offset+i]==want
    assert len(program)==offset+len(native)+8
    ce=kg.load('center_free_module_ce',kg.CLIFFORD);group=kg.PhaseGroup(ce,c,True)
    module=kg.UnitModule(group);full_scalar=kg.ScalarSpan();rank8_spans=defaultdict(kg.ScalarSpan)
    rows=[{(i,0):Q(1)} for i in range(632)]+[{} for _ in range(9)];cur=c['start'][:]+[None]*9
    full_seen=0;rank8_seen=0;rank8_rows=[];rank8_descriptions=[];paid=Counter();maxnorm=Q(1)
    oblob=json.loads(OBSERVATIONS.read_text());wanted=defaultdict(list);old_mode_rows=[{} for _ in range(8)]
    for observation in oblob['results']:
        k=int(next(iter(observation['target_modes'])));pre=observation['retained_precenter_input_gather'][0]
        wanted[offset+pre['after_event']].append((k,pre['owner'],Q(pre['coefficient'])))
        for item in next(t for t in observation['targets'] if t['bank']=='Y')['cleanup_recipe']:
            assert item['left_operator']==0
            wanted[offset+item['after_event']].append((k,item['owner'],-Q(item['subtract_coefficient'])))
    for pos,e in enumerate(program):
        typ=e[0];d=None
        if typ=='scalar':
            a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
            if a[0]=='clear':assert d>=632;rows[d]={};cur[d]=f
            else:
                assert cur[d]==f
                if a[0] in ('add','copy'):
                    s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                    if a[0]=='copy':assert d>=632;rows[d]=dict(rows[s])
                    else:kg.add(rows[d],rows[s],Q(a[3],a[4]))
                else:
                    assert a[0]=='scale';rows[d]={k:v*Q(a[2],a[3]) for k,v in rows[d].items() if v*a[2]}
        elif typ=='warp':
            d=e[1][1]+(632 if e[1][0]=='C' else 0);assert cur[d]==e[3]
            rows[d]=group.left(group.letters[e[2]],rows[d]);cur[d]=e[4]
        elif typ=='climb':d=e[2];assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
        else:assert typ in ('phase','adapter')
        if d is not None:
            maxnorm=max(maxnorm,sum(map(abs,rows[d].values()),Q(0)))
            description={'owner':d,'after_event':pos,'frame':cur[d],
                         'original_after_event':pos-offset if offset<=pos<offset+len(native) else None}
            if cur[d]==1:
                full_seen+=1
                if rows[d] and full_scalar.insert(rows[d]):module.insert(rows[d],description)
            if cur[d] is not None and len(c['frames'][cur[d]])==8 and rows[d]:
                rank8_seen+=1
                if rank8_spans[cur[d]].insert(rows[d]):
                    rank8_rows.append(dict(rows[d]));rank8_descriptions.append(description)
        for k,owner,a in wanted.get(pos,[]):kg.add(old_mode_rows[k],rows[owner],a)
        if pos and pos%5000==0:
            print('PROGRESS',pos,'full',full_seen,'pivots',len(module.pivots),'rank8basis',len(rank8_rows),flush=True)
    assert cur[:632]==c['final'] and all(not r for r in rows[632:])
    for i in range(632):
        target={(i,0):Q(1)}
        if i<112:
            target[112+i,0]=Q(-1)
            for r in R:
                if r[i]:kg.add(target,{(112+j,0):v for j,v in enumerate(r) if v},r[i]/4)
        assert rows[i]==target,(i,len(rows[i]),len(target))
    assert all(not r for r in old_mode_rows)
    old_paid=Counter(e[-1] for e in native if e[0] in ('climb','center'));old_paid[8]-=8
    assert paid==+old_paid
    tests=[]
    for bank,off in [('X',0),('Y',112)]:
        for k,r in enumerate(R):
            residual,recipe=module.solve({(off+i,0):v for i,v in enumerate(r) if v})
            tests.append({'bank':bank,'mode':k,'recovered':not residual,'residual_terms':len(residual),
                          'residual':[[i,g,str(a)] for (i,g),a in sorted(residual.items())]})
    pickle_data={'source_sha256':sha256(raw).hexdigest(),'original_source_sha256':sha256(oraw).hexdigest(),
                 'direction':'backward','contract':'helper-clean-scalar-center-free',
                 'program':program,'canonical':c,'source_prefix_offset':offset,
                 'ops':[{'tableau':op.tab,'circuit':op.circuit,'word':word} for op,word in zip(group.ops,group.word)],
                 'letters':group.letters,'snapshots':module.snapshot_rows,'descriptions':module.snapshot_descriptions,
                 'pivots':module.pivots,'pending':module.pending,'R':R,
                 'rank8_rows':rank8_rows,'rank8_descriptions':rank8_descriptions}
    pp=HERE/'CENTER-FREE-SNAPSHOT-MODULE.pickle';pp.write_bytes(pickle.dumps(pickle_data,protocol=5))
    result={'schema':'actual-clean-center-free-snapshot-module/v1','status':'EXACT_PHASE_AWARE_REPLAY_COMPLETE',
            'word_source_sha256':sha256(raw).hexdigest(),'original_source_sha256':sha256(oraw).hexdigest(),
            'observation_source_sha256':sha256(OBSERVATIONS.read_bytes()).hexdigest(),
            'all632_original_rows_checked':True,'all408_helpers_autonomous':True,
            'all_original_final_frames_checked':True,'all_owned_zero':True,
            'endpoint':'X -= A Y, Y,H unchanged, A=I-R^T R/4; physical raw-dual canonical frames.',
            'events':len(program),'helper_clean_prefix_events':offset,'native_paid_profile':dict(sorted(paid.items())),
            'normalized_prefix_l1':str(maxnorm),'full_snapshots':full_seen,
            'scalar_independent_full_snapshots':len(module.snapshot_rows),
            'phase_correct_unit_module_pivots':len(module.pivots),'nonunit_residual_rows':len(module.pending),
            'rank8_snapshots':rank8_seen,'scalar_independent_rank8_snapshots':len(rank8_rows),
            'rank8_frames':len(rank8_spans),'phase_exact_operators':len(group.ops),
            'original_eight_observation_replacement':{
                'all_eight_query_minus_two_cleanup_rows_exactly_zero':True,
                'interpretation':'In the changed center-free word each old pre-center observation is already the sum of its two later full-frame snapshots. The deleted center had supplied the entire RY signal in the original identity. The eight new rank1 lifts therefore add no information to this changed S.',
                'residual_rows':[[] for _ in range(8)]},
            'local_R_mode_tests':tests,'basis_pickle_sha256':sha256(pp.read_bytes()).hexdigest(),
            'scope':'Exact source-bound left module and same-frame rank8 observation inventory. No circuit mutation or additional Gaussian call has been admitted. Other rank8 observations, other frames, changed contacts and targets remain outside the original eight-recipe failure.',
            'seconds':time.monotonic()-begun}
    out=HERE/'CENTER-FREE-SNAPSHOT-MODULE.json';out.write_text(json.dumps(result,indent=2)+'\n')
    print('DONE',out,'pivots',len(module.pivots),'rank8',len(rank8_rows),'seconds',result['seconds'],flush=True)


if __name__=='__main__':main()
