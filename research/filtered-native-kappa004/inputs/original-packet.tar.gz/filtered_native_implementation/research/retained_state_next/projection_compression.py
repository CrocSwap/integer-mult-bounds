#!/usr/bin/env python3
"""Actual two-stage eight-mode compression probe, exact modulo 65537.

Uses 17 address bits: one shared central bit and two fresh eight-bit blocks.
Every R coefficient is used once; the signed normalizers are literal inputs.
NumPy float64 matrix products are exact here because all integer sums remain
below 2**53. Reduction takes place between products.
"""
from pathlib import Path
import argparse, hashlib, json, time
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
P=65537;N=1<<17;INV56=pow(56,-1,P)

def nullvector(columns,p=P):
    a=[list(map(int,r)) for r in zip(*columns)];m=len(a);n=len(columns)
    piv=[];row=0
    for col in range(n):
        k=next((k for k in range(row,m) if a[k][col]%p),None)
        if k is None:continue
        a[row],a[k]=a[k],a[row]
        q=pow(a[row][col]%p,-1,p);a[row]=[(v*q)%p for v in a[row]]
        for k in range(m):
            if k!=row and a[k][col]%p:
                q=a[k][col]%p;a[k]=[(v-q*w)%p for v,w in zip(a[k],a[row])]
        piv.append(col);row+=1
        if row==m:break
    free=[j for j in range(n) if j not in piv]
    if not free:return None
    j=free[-1];v=[0]*n;v[j]=1
    for k,c in reversed(list(enumerate(piv))):v[c]=(-sum(a[k][t]*v[t] for t in free))%p
    return v

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--degree',type=int,default=16);ap.add_argument('--seed',type=int,default=20261023)
    ap.add_argument('--modes',default='0,1,2,3,4,5,6,7')
    ap.add_argument('--source-basis',action='store_true',help='Use actual native R.json row indexes, not NORMALIZERS.mode_columns indexes.')
    args=ap.parse_args();start=time.monotonic()
    path=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json';raw=path.read_bytes();data=json.loads(raw)
    selected=[int(s) for s in args.modes.split(',')]
    rpath=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    mode_data=json.loads(rpath.read_text()) if args.source_basis else data['mode_columns']
    R=np.asarray(mode_data,dtype=np.float64)[selected];ports=data['ports'];k=len(selected)
    assert len(set(selected))==k and np.array_equal(R@R.T,56*np.eye(k))
    base=np.arange(512,dtype=np.uint32)
    fw=[];bw=[];sf=[];sb=[]
    for p in ports:
        rows=p['G_rows'];gt=[sum(((rows[i]>>j)&1)<<i for i in range(9)) for j in range(9)]
        def calc(rr):
            return np.array([sum(((r&int(x)).bit_count()&1)<<j for j,r in enumerate(rr)) for x in base],dtype=np.uint32)
        f,b=calc(rows),calc(gt);z=p['Z_mask']
        fw.append(f);bw.append(b)
        sf.append(np.array([1-2*((z&int(x)).bit_count()&1) for x in f],dtype=np.int8))
        sb.append(np.array([1-2*((z&int(x)).bit_count()&1) for x in base],dtype=np.int8))
    addresses=np.arange(N,dtype=np.uint32)
    def move(i,stage,a,inverse):
        shift=1+8*stage;mask=1|(255<<shift);local=(a&1)|(((a>>shift)&255)<<1)
        table=bw[i] if inverse else fw[i];sg=sb[i] if inverse else sf[i]
        dest=table[local]
        return (a&np.uint32(((1<<17)-1)^mask))|(dest&1)|((dest>>1)<<shift),sg[local]
    perm=[];sign=[]
    for old,new in [(0,1),(1,0)]:
        pp=[];ss=[]
        for i in range(112):
            b,s=move(i,new,addresses,True);c,t=move(i,old,b,False)
            pp.append(c);ss.append(s*t)
        perm.append(np.asarray(pp,dtype=np.uint32));sign.append(np.asarray(ss,dtype=np.int8))
    inverse_checks=0
    for i in range(112):
        assert np.array_equal(perm[1][i][perm[0][i]],addresses)
        assert np.all(sign[0][i]*sign[1][i][perm[0][i]]==1)
        inverse_checks+=N
    def cross(x,direction):
        out=np.zeros((k,N),dtype=np.float64)
        for lo in range(0,112,8):
            hi=lo+8
            z=(R[:,lo:hi].T@x)%P
            z=np.take_along_axis(z,perm[direction][lo:hi].astype(np.int64),axis=1)
            z*=sign[direction][lo:hi]
            out+=R[:,lo:hi]@z
        return ((out%P)*INV56)%P
    def action(x):return cross(cross(x,0),1)
    rng=np.random.default_rng(args.seed)
    initial=rng.integers(0,P,size=(k,N),dtype=np.int64).astype(np.float64)
    sample=rng.choice(k*N,size=512,replace=False)
    current=initial.copy();samples=[];poly=None;sample_rank=[]
    for degree in range(args.degree+1):
        samples.append(current.reshape(-1)[sample].astype(np.int64).tolist())
        poly=nullvector(samples)
        print(json.dumps({'degree':degree,'relation_found':poly is not None,'elapsed':round(time.monotonic()-start,3)}),flush=True)
        if poly is not None:break
        if degree<args.degree:current=action(current)
    verifications=[]
    if poly is not None:
        for trial in range(2):
            x=initial.copy() if trial==0 else rng.integers(0,P,size=(k,N),dtype=np.int64).astype(np.float64)
            current=x.copy();acc=np.zeros_like(x)
            for power,c in enumerate(poly):
                acc=(acc+current*c)%P
                if power+1<len(poly):current=action(current)
            verifications.append({'trial':trial,'all_coordinates':k*N,'nonzero_residual_coordinates':int(np.count_nonzero(acc))})
    out={'schema':'actual-two-stage-projection-compression-probe/v1','prime':P,'address_bits':17,
         'source_sha256':hashlib.sha256(raw).hexdigest(),'operator':'T* T, T=(R K_1 K_0^-1 R^T)/56',
         'mode_dimension':k*N,'selected_modes':selected,'literal_relative_inverse_columns':inverse_checks,
         'mode_basis':'actual native R.json' if args.source_basis else 'NORMALIZERS.mode_columns (different signed row ordering)',
         'mode_basis_sha256':hashlib.sha256(rpath.read_bytes()).hexdigest() if args.source_basis else hashlib.sha256(raw).hexdigest(),
         'max_degree':args.degree,'seed':args.seed,'sample_coordinates':sample.tolist(),
         'krylov_samples':samples,'first_sample_relation_mod_p':poly,'full_vector_checks':verifications,
         'elapsed_seconds':round(time.monotonic()-start,3),
         'scope':'Exact modular full-vector probes on the actual two-stage width-one address space; a discovered annihilator is not an all-input or all-width theorem.'}
    stem=('PROJECTION-COMPRESSION-SOURCE-MODES-'+''.join(map(str,selected)) if args.source_basis
          else ('PROJECTION-COMPRESSION' if k==8 else 'PROJECTION-COMPRESSION-MODES-'+''.join(map(str,selected))))
    (HERE/(stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('sample_coordinates','krylov_samples')}))

if __name__=='__main__':main()
