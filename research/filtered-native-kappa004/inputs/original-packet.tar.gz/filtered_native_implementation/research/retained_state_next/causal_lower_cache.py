#!/usr/bin/env python3
"""Use actual source-phase caches of one filtered FULL in the p3 caller.

All unmodified/corrupted chronological prefixes and the authenticated
internal source cut are retained.  A second screen permits ordinary
feedback from this cut into the still-unread opposite input, plus later
ordinary scatter of the same retained cut values.  Every six-bank input
column is kept.  A failed finite polynomial screen is not a general
impossibility statement about ordinary address circuits.
"""
from collections import defaultdict
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import active_cache as ac


def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--degree',type=int,default=3)
    ap.add_argument('--stages',default='0,1,2,3,4,5,6')
    ap.add_argument('--feedback',action='store_true');ap.add_argument('--central-specialization',action='store_true')
    args=ap.parse_args();started=time.monotonic()
    ff=load('causal_filtered_algebra',ROOT/'research/operator_alignment_next/filtered_full_caller.py')
    if not args.central_specialization:
        def canonical(qword,d,stage):
            q=list(x%4 for x in qword);factor=Fr(1)
            while len(q)>2:
                zero=next((i for i in range(1,len(q)-1) if q[i]==0),None)
                if zero is None:break
                q.pop(zero);factor*=-14
            return (tuple(q),tuple(x%4 for x in d)),factor
        ff.canonical=canonical
    path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    source=json.loads(path.read_text())['selected_p3_keep43']
    matrices,prefix,suffix=ac.source_matrices(source);events=source['physical_events']
    ops=ff.ordinary_words(args.degree);results=[]
    for stage in map(int,args.stages.split(',')):
        start=time.monotonic();changed=next(i for i,e in enumerate(events) if e[0]=='LOCAL' and e[1]==stage)
        event=events[changed];back=event[3];x=2*event[2]
        dst,read=(x,x+1) if back else (x+1,x)
        dl=list(ac.ZERO_D);dl[stage]=1;dl=tuple(dl)
        kwargs=dict(qleft=1 if back else 0,qright=0 if back else -1,dleft=dl,coefficient=-1 if back else 1)
        right=prefix[changed][read]
        fright=[ac.poly_mul(ac.mono(q=1,stages=[stage]),p) for p in right]
        def error_at(left):
            old=ac.p_outer(left,right,stage,**kwargs)
            shifted=ac.p_outer(left,fright,stage,**kwargs)
            return ff.error_rows(ff.add(old,ff.scale(shifted,-1)),stage)
        target=[]
        for i,t in enumerate(source['exact_diagonal_monomials']):
            row=[{} for _ in range(6)];row[i]=ac.mono(q=t[0],stages=[s for s in range(7) if t[s+1]])
            target.append(ff.poly_row(row,stage))
        error=error_at([row[dst] for row in suffix[changed+1]])
        endpoint=[ff.add(t,e) for t,e in zip(target,error)]
        available=[(('actual_final_bank',i),row) for i,row in enumerate(endpoint)]
        for cut in range(changed+1):
            available.extend((('unchanged_prefix',cut,i),ff.poly_row(row,stage)) for i,row in enumerate(prefix[cut]))
        # Retain every actual changed-state prefix.  The transfer from the
        # changed output to each cut is the literal remaining ordinary core.
        middle=ac.identity()
        for cut in range(changed+1,len(events)+1):
            if cut>changed+1:middle=ac.matrix_mul(matrices[cut-1],middle)
            er=error_at([row[dst] for row in middle])
            state=[ff.add(ff.poly_row(row,stage),z) for row,z in zip(prefix[cut],er)]
            available.extend((('actual_changed_prefix',cut,i),row) for i,row in enumerate(state))
            if cut==changed+1:source_after=state[read]
        new_source=ff.act(((0,),dl),ff.poly_row(right,stage),stage)
        assert new_source==source_after
        available.append((('internal_paid_source_cut',changed,read),new_source))
        columns=[({'source':desc,'ordinary_Q_P_word':op[0]},ff.act(op,row,stage))
                 for op in ops for desc,row in available]
        basis=ff.sparse_basis(columns)
        recoveries=[]
        for i,t in enumerate(target):
            recipe,residual=ff.solve(basis,t)
            if not residual:
                reconstructed={}
                for j,c in recipe.items():reconstructed=ff.add(reconstructed,ff.scale(columns[j][1],c))
                assert reconstructed==t
            recoveries.append({'target_bank':i,'recovered':not residual,'residual_terms':len(residual),
                'recipe':[{'coefficient':str(c),**columns[j][0]} for j,c in sorted(recipe.items())] if not residual else None})
        result={'stage':stage,'orientation':'backward' if back else 'forward','changed_event':changed,
            'all_actual_prefix_caches_included':True,'internal_source_cut_equals_immediate_post_FULL_source_bank':True,
            'ordinary_P_degree_bound':args.degree,'candidate_columns':len(columns),'basis_rank':len(basis),
            'recoveries':recoveries,'all_six_targets_recovered':all(r['recovered'] for r in recoveries)}
        if args.feedback:
            early=[(('pre_FULL_original_bank',i),ff.poly_row(row,stage)) for i,row in enumerate(prefix[changed])]
            early.append((('internal_paid_source_cut',read),new_source))
            # Each feedback source is frozen before any controlled input or
            # later state is updated, so the dependence on coefficients is
            # exactly linear, including multiple simultaneous injections.
            positions=[(('opposite_input_before_consumer',dst),
                        [ac.poly_mul(row[dst],ac.mono(stages=[stage])) for row in suffix[changed+1]])]
            for cut in range(changed+1,len(events)+1):
                positions.extend((('post_FULL_or_later_cut',cut,bank),[row[bank] for row in suffix[cut]]) for bank in range(6))
            cbasis={};candidates=[];goal={(i,)+key:-v for i,row in enumerate(error) for key,v in row.items()}
            residual=dict(goal);solution={};tested=0
            def response(left,row):
                z={}
                for i,poly in enumerate(left):
                    rr={}
                    for (q,d),c in poly.items():rr=ff.add(rr,ff.scale(ff.act(((q,),d),row,stage),c))
                    z.update({(i,)+key:v for key,v in rr.items()})
                return z
            done=False
            for position,left in positions:
                if done:break
                for desc,row in early:
                    if done:break
                    for op in ops:
                        candidate=response(left,ff.act(op,row,stage));tested+=1
                        vector=dict(candidate);recipe={len(candidates):Fr(1)}
                        while vector:
                            pivot=min(vector)
                            if pivot not in cbasis:
                                k=vector[pivot];cbasis[pivot]=ff.scale(vector,1/k),ff.scale(recipe,1/k)
                                candidates.append(({'position':position,'source':desc,'ordinary_Q_P_word':op[0]},candidate))
                                break
                            b,r=cbasis[pivot];k=vector[pivot]
                            ac.subtract_scaled(vector,b,k);ac.subtract_scaled(recipe,r,k)
                        if not vector:continue
                        while residual and min(residual) in cbasis:
                            b,r=cbasis[min(residual)];k=residual[min(residual)]
                            ac.subtract_scaled(residual,b,k);solution=ff.add(solution,ff.scale(r,k))
                        if not residual:done=True;break
            if not residual:
                check={}
                for j,c in solution.items():check=ff.add(check,ff.scale(candidates[j][1],c))
                assert check==goal
            result['causal_feedback']={'all_six_independent_columns_checked':True,
                'source_vectors_frozen_before_all_injections':True,
                'sources':'Six pre-FULL banks and actual D_s transformed read bank at the internal source cut.',
                'positions':'Ordinary feedback into the still-unread opposite input; arbitrary later bank scatters.',
                'candidates_tested':tested,'basis_rank':len(cbasis),'whole_endpoint_restored':not residual,
                'residual_terms':len(residual),
                'recipe':[{'coefficient':str(c),**candidates[j][0]} for j,c in sorted(solution.items())] if not residual else None}
        result['elapsed_seconds']=round(time.monotonic()-start,3);results.append(result)
        print('CAUSAL_CACHE',stage,'recoveries',[r['recovered'] for r in recoveries],
              'feedback',result.get('causal_feedback',{}).get('whole_endpoint_restored'),
              'seconds',result['elapsed_seconds'],flush=True)
        out={'schema':'actual-p3-native-causal-cache-screen/v1',
            'source_sha256':sha256(path.read_bytes()).hexdigest(),
            'causal_forward_receipt_sha256':sha256((HERE/'F9-SOURCE-DAG-ALL8-SOURCEFIRST.json').read_bytes()).hexdigest(),
            'causal_backward_receipt_sha256':sha256((HERE/'SYMMETRIC-CAUSAL-PAIR.json').read_bytes()).hexdigest(),
            'central_involutions_specialized':args.central_specialization,
            'algebra':'Q^4=D_t^4=I; D_s P=Q^-1 P Q D_s; [D_t,P]=0 for t!=s; P^2=-14P. No extra actual-K identities assumed.',
            'results':results,'elapsed_seconds':round(time.monotonic()-started,3),
            'scope':'Exact declared finite ordinary P,Q² decoder/feedback family. Additional address monomials, additional changed FULLs, or changed target jobs are not excluded.',
            'new_kappa_claimed':False}
        stem='CAUSAL-LOWER-CACHE'+('-FEEDBACK' if args.feedback else '')+('-SECTOR' if args.central_specialization else '')
        (HERE/(stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
