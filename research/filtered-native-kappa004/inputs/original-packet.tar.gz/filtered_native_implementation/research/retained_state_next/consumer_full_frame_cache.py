#!/usr/bin/env python3
"""Retain every literal full-frame native snapshot and test clean X/Y modes.

This is a post-consumer cache test.  All 632 original columns remain
independent.  It does not zero auxiliary inputs, and a copied snapshot
retains its actual physical frame.  Only scalar combinations after the
unique full frame are admitted; arbitrary further address recodings are
outside this first family.
"""
from collections import Counter, defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import pickle
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
    spec.loader.exec_module(mod);return mod


def add(a,b,c):
    for k,v in b.items():
        z=a.get(k,F(0))+c*v
        if z:a[k]=z
        else:a.pop(k,None)


def modular_rank(rows,keep):
    prime=65521;basis={}
    for row in rows:
        v={k:x.numerator*pow(x.denominator,-1,prime)%prime for k,x in row.items() if keep(k)}
        v={k:x for k,x in v.items() if x}
        while v:
            p=min(v)
            if p not in basis:
                inv=pow(v[p],-1,prime);basis[p]={k:x*inv%prime for k,x in v.items()};break
            b=basis[p];fac=v[p]
            for k,x in b.items():
                z=(v.get(k,0)-fac*x)%prime
                if z:v[k]=z
                else:v.pop(k,None)
    return len(basis)


class Basis:
    def __init__(self):self.rows={};self.snapshots=[];self.original=[]
    def insert(self,row,metadata):
        v=dict(row);index=len(self.snapshots);recipe={index:F(1)}
        while v:
            pivot=min(v)
            if pivot not in self.rows:
                c=v[pivot];self.rows[pivot]=({k:x/c for k,x in v.items()},
                                             {k:x/c for k,x in recipe.items()})
                self.snapshots.append(metadata);self.original.append(dict(row));return True
            b,r=self.rows[pivot];c=v[pivot];add(v,b,-c);add(recipe,r,-c)
        return False
    def solve(self,row):
        v=dict(row);recipe={}
        while v and min(v) in self.rows:
            pivot=min(v);b,r=self.rows[pivot];c=v[pivot]
            add(v,b,-c);add(recipe,r,c)
        if not v:
            check={}
            for j,c in recipe.items():add(check,self.original[j],c)
            assert check==row
        return v,recipe


def main():
    start=time.monotonic()
    path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw=path.read_bytes();source=json.loads(gzip.decompress(raw));c=source['canonical']
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    R=[[F(x) for x in r] for r in json.loads(rp.read_text())]
    core=load('consumer_cache_native_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    ce=load('consumer_cache_clifford',ROOT/'upstream/research/coded-native-caller/clifford_exact.py')
    # Rank is invariant under multiplication on the left by an ordinary
    # monomial.  Thus no frame of rank <9 is ordinarily convertible to F9.
    fullframes=[i for i,b in enumerate(c['frames']) if len(b)==9]
    assert fullframes==[1]
    fmap=ce.canonical_frame(9,c['frames'][1]);assert fmap.tab==ce.fourier(9).tab
    maps={0:tuple(1<<i for i in range(9))}
    maps.update({w['op']:tuple(w['G_columns']) for w in c['warps']})
    invmaps={op:ce.transpose(ce.inv(ce.transpose(cols,9),9),9) for op,cols in maps.items()}
    def mv(cols,x):
        y=0
        while x:
            b=x&-x;y^=cols[b.bit_length()-1];x^=b
        return y
    def compose(a,b):return tuple(mv(a,x) for x in b)
    # The real logical P_G is unchanged by inverse transpose of its unitary
    # physical wrapper.  Backward frames are conjugated, but P_G is real.
    physical_words={():maps[0]}
    def actual_word(word):
        if word in physical_words:return physical_words[word]
        op=word[0];sgn=1 if op>0 else -1;op=abs(op)%1000000
        physical_words[word]=compose(maps[op] if sgn>0 else invmaps[op],actual_word(word[1:]))
        return physical_words[word]
    results=[]
    for direction,back in [('forward',False),('backward',True)]:
        rows=[core.identity(i) for i in range(632)]+[{}]
        cur=c['start'][:]+[None];basis=Basis();seen=0;word_lengths=Counter()
        def observe(owner,event):
            nonlocal seen
            if cur[owner]!=1:return
            seen+=1;row={}
            for (i,w),v in rows[owner].items():
                word_lengths[len(w)]+=1;k=(i,actual_word(w));row[k]=row.get(k,F(0))+v
            row={k:v for k,v in row.items() if v}
            basis.insert(row,{'owner':owner,'after_event':event,'frame':1})
        for i in range(632):observe(i,-1)
        for pos,e in enumerate(source['programs'][direction]):
            typ=e[0];d=None
            if typ=='scalar':
                a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
                if a[0]=='clear':rows[d]={};cur[d]=f
                else:
                    assert cur[d]==f
                    if a[0] in ('add','copy'):
                        s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                        if a[0]=='copy':assert d==632;rows[d]=dict(rows[s])
                        else:core.add(rows[d],rows[s],F(a[3],a[4]))
                    else:assert a[0]=='scale';rows[d]={k:v*F(a[2],a[3]) for k,v in rows[d].items() if v*a[2]}
            elif typ=='warp':
                d=e[1][1]+(632 if e[1][0]=='C' else 0);assert cur[d]==e[3]
                rows[d]=core.warp(rows[d],e[2],back);cur[d]=e[4]
            elif typ=='climb':d=e[2];assert cur[d]==e[3];cur[d]=e[4]
            elif typ=='center':d=632+e[1];assert cur[d]==e[2];cur[d]=e[3]
            else:assert typ in ('phase','adapter','residual_adapter')
            if d is not None:observe(d,pos)
        assert cur[:632]==c['final'] and not rows[632]
        assert rows[:632]==[core.expected(i,back) for i in range(632)]
        tests=[]
        for targetbank in ['X','Y']:
            offset=0 if targetbank=='X' else 112
            for mode,r in enumerate(R):
                target={(i+offset,maps[0]):v for i,v in enumerate(r) if v}
                residual,recipe=basis.solve(target)
                tests.append({'target':targetbank,'mode':mode,'recovered':not residual,
                    'residual_terms':len(residual),
                    'recipe':[{'coefficient':str(v),**basis.snapshots[j]} for j,v in sorted(recipe.items())] if not residual else None,
                    'residual_sha256':sha256(repr(sorted(residual.items())).encode()).hexdigest()})
        unit_success=[]
        for i in range(224):
            residual,_=basis.solve({(i,maps[0]):F(1)})
            if not residual:unit_success.append(i)
        record={'direction':direction,'all_original_owners':632,
            'physical_full_frame':'bar(F9)' if back else 'F9',
            'full_frame_snapshots':seen,'independent_snapshot_rows':len(basis.rows),
            'literal_word_length_counts':dict(word_lengths),
            'all_phase_compatible_full_frames':fullframes,
            'tests':tests,'clean_individual_main_owners':unit_success,
            'retained_basis_snapshots':basis.snapshots}
        record['arbitrary_clean_scalar_main_modes']={}
        for targetbank,lo in [('X',0),('Y',112),('X_and_Y',0)]:
            hi=224 if targetbank=='X_and_Y' else lo+112
            projected_rank=modular_rank(basis.original,lambda k:not(lo<=k[0]<hi and k[1]==maps[0]))
            record['arbitrary_clean_scalar_main_modes'][targetbank]={
                'contamination_projection_rank_mod65521':projected_rank,
                'intersection_dimension_upper_bound':len(basis.rows)-projected_rank,
                'meaning':'Rank over Q is at least this modular projection rank; the upper bound is zero iff no nonzero pure mode exists in this scalar snapshot span.'}
        results.append(record)
        (HERE/('CONSUMER-FULL-FRAME-'+direction.upper()+'.pickle')).write_bytes(pickle.dumps({
            'source_sha256':sha256(raw).hexdigest(),'R_sha256':sha256(rp.read_bytes()).hexdigest(),
            'direction':direction,'snapshot_rows':basis.original,'snapshot_descriptions':basis.snapshots,
            'actual_permutations':maps,'R':R},protocol=5))
        print('FULL_FRAME_CACHE',direction,'snapshots',seen,'rank',len(basis.rows),
              'X modes',[r['mode'] for r in tests if r['target']=='X' and r['recovered']],
              'Y modes',[r['mode'] for r in tests if r['target']=='Y' and r['recovered']],
              'individual',len(unit_success),flush=True)
    # Certify every actual logical permutation label is independent.  If a
    # larger word set is encountered this exact check remains applicable.
    labels=sorted(set(physical_words.values()))
    gram=[[2**(9-ce.rank([x^y for x,y in zip(a,b)])) for b in labels] for a in labels]
    prime=65521;mat=[[x%prime for x in r] for r in gram];rank=0;det=1
    for j in range(len(labels)):
        k=next((i for i in range(rank,len(labels)) if mat[i][j]),None)
        if k is None:continue
        if k!=rank:mat[k],mat[rank]=mat[rank],mat[k];det=-det
        pivot=mat[rank][j];det=det*pivot%prime;inv=pow(pivot,-1,prime)
        mat[rank]=[v*inv%prime for v in mat[rank]]
        for i in range(rank+1,len(labels)):
            fac=mat[i][j]
            if fac:mat[i]=[(x-fac*y)%prime for x,y in zip(mat[i],mat[rank])]
        rank+=1
    out={'schema':'native-full-frame-consumer-cache/v1','source_sha256':sha256(raw).hexdigest(),
        'R_sha256':sha256(rp.read_bytes()).hexdigest(),'results':results,
        'actual_logical_permutation_count':len(labels),'logical_permutation_gram_rank':rank,
        'gram_prime':prime,'gram_determinant_mod_prime':det if rank==len(labels) else 0,
        'all_permutation_labels_independent':rank==len(labels),
        'all_width_argument':'Independent matrix labels have independent positive tensor powers, by tensoring dual coordinate functionals. Scalar identities replay for every width.',
        'scope':'All scalar combinations of all actual snapshots ordinarily convertible to the full physical F9 frame. No extra address monomials on the aligned snapshots and no changed native gate are assumed.',
        'elapsed_seconds':round(time.monotonic()-start,3),'new_kappa_claimed':False}
    (HERE/'CONSUMER-FULL-FRAME-CACHE.json').write_text(json.dumps(out,indent=2)+'\n')
    print('DONE',out['elapsed_seconds'],'operator independence',rank,len(labels),flush=True)


if __name__=='__main__':main()
