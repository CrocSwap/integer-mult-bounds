#!/usr/bin/env python3
"""Exact chronological same-frame span test on the unmodified native supplier.

Every original input, including all 408 helper inputs, is independent.
An output can be memoized only from snapshots actually born earlier in the
same literal frame.  A positive recipe can be implemented by owned copies,
scalar gathering, and an ownership-preserving physical swap.

Scalar same-frame gates cannot enlarge the span of all past same-frame
values, so only initial values and query/warp arrivals need insertion.
"""
from collections import Counter, defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import argparse
import gzip
import importlib.util
import json
import pickle
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
CORE=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py'
CLIFFORD=ROOT/'upstream/research/coded-native-caller/clifford_exact.py'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m
    spec.loader.exec_module(m);return m


def add(a,b,c):
    for k,v in b.items():
        z=a.get(k,Q(0))+c*v
        if z:a[k]=z
        else:a.pop(k,None)


class Basis:
    def __init__(self):
        self.rows={};self.original=[];self.descriptions=[]

    def insert(self,row,description):
        residual=dict(row);idx=len(self.original);recipe={idx:Q(1)}
        while residual:
            pivot=min(residual)
            if pivot not in self.rows:
                a=residual[pivot]
                self.rows[pivot]=({k:v/a for k,v in residual.items()},
                                  {k:v/a for k,v in recipe.items()})
                self.original.append(dict(row));self.descriptions.append(description)
                return True
            basis,word=self.rows[pivot];a=residual[pivot]
            add(residual,basis,-a);add(recipe,word,-a)
        return False

    def solve(self,row):
        residual=dict(row);recipe={}
        while residual:
            pivot=min(residual)
            if pivot not in self.rows:break
            basis,word=self.rows[pivot];a=residual[pivot]
            add(residual,basis,-a);add(recipe,word,a)
        if not residual:
            check={}
            for i,a in recipe.items():add(check,self.original[i],a)
            assert check==row
        return residual,recipe


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--labels',choices=('free','actual'),default='free')
    args=ap.parse_args();started=time.monotonic()
    raw=SOURCE.read_bytes();source=json.loads(gzip.decompress(raw));c=source['canonical']
    core=load('paid_memo_native_core',CORE);ce=load('paid_memo_clifford',CLIFFORD)
    maps={0:tuple(1<<i for i in range(9))}
    maps.update({w['op']:tuple(w['G_columns']) for w in c['warps']})
    invmaps={op:ce.transpose(ce.inv(ce.transpose(cols,9),9),9) for op,cols in maps.items()}
    def mv(cols,x):
        out=0
        while x:
            bit=x&-x;out^=cols[bit.bit_length()-1];x^=bit
        return out
    def compose(a,b):return tuple(mv(a,x) for x in b)
    words={():maps[0]}
    def actual(word):
        if word not in words:
            op=word[0];g=maps[abs(op)%1000000] if op>0 else invmaps[abs(op)%1000000]
            words[word]=compose(g,actual(word[1:]))
        return words[word]
    def labelled(row):
        if args.labels=='free':return row
        out={}
        for (i,w),v in row.items():
            k=i,actual(w);z=out.get(k,Q(0))+v
            if z:out[k]=z
            else:out.pop(k,None)
        return out
    outcomes=[];details={}
    for name,back in [('forward',False),('backward',True)]:
        began=time.monotonic();rows=[core.identity(i) for i in range(632)]+[{}]
        cur=c['start'][:]+[None];spans=defaultdict(Basis);paid=Counter();hits=[]
        arrivals=Counter();paid_tests=[];maxnorm=Q(1)
        def observe(owner,position,kind):
            f=cur[owner];assert f is not None
            row=labelled(rows[owner]);arrivals[kind]+=1
            return spans[f].insert(row,{'owner':owner,'after_event':position,'frame':f,'kind':kind})
        for i in range(632):observe(i,-1,'initial')
        for pos,e in enumerate(source['programs'][name]):
            typ=e[0];d=None
            if typ=='scalar':
                a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
                if a[0]=='clear':
                    assert d==632;rows[d]={};cur[d]=f
                else:
                    assert cur[d]==f
                    if a[0] in ('add','copy'):
                        s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                        if a[0]=='copy':assert d==632;rows[d]=dict(rows[s])
                        else:core.add(rows[d],rows[s],Q(a[3],a[4]))
                    else:
                        assert a[0]=='scale';rows[d]={k:Q(a[2],a[3])*v for k,v in rows[d].items() if a[2]*v}
            elif typ=='warp':
                d=e[1][1]+(632 if e[1][0]=='C' else 0)
                assert cur[d]==e[3];rows[d]=core.warp(rows[d],e[2],back);cur[d]=e[4]
                observe(d,pos,'warp')
            elif typ in ('climb','center'):
                if typ=='climb':d,old,new,rank=e[2:]
                else:d,old,new,rank=e[1:];d+=632
                assert cur[d]==old
                row=labelled(rows[d]);basis=spans[new]
                residual,recipe=basis.solve(row)
                test={'event':pos,'owner':d,'from_frame':old,'to_frame':new,'rank':rank,
                      'prior_same_frame_rank':len(basis.rows),'row_terms':len(row),
                      'residual_terms':len(residual),
                      'residual_sha256':sha256(repr(sorted(residual.items())).encode()).hexdigest()}
                if not residual:
                    record={**test,'recipe':[{'coefficient':str(v),**basis.descriptions[i]}
                                           for i,v in sorted(recipe.items())]}
                    hits.append(record)
                    print('HIT',args.labels,name,pos,'rank',rank,'recipe',len(recipe),flush=True)
                paid_tests.append(test);paid[rank]+=1;cur[d]=new
                observe(d,pos,'paid')
            else:assert typ in ('phase','adapter','residual_adapter')
            if d is not None:maxnorm=max(maxnorm,sum(map(abs,rows[d].values()),Q(0)))
            if pos and pos%5000==0:
                print('PROGRESS',args.labels,name,pos,'hits',len(hits),'seconds',round(time.monotonic()-began,2),flush=True)
        assert cur[:632]==c['final'] and not rows[632]
        assert rows[:632]==[core.expected(i,back) for i in range(632)]
        removed=Counter(h['rank'] for h in hits)
        record={'direction':name,'all_originals':632,'helper_originals':408,
                'paid_profile':dict(sorted(paid.items())),
                'chronological_same_frame_paid_hits':hits,
                'potential_removed_profile':dict(sorted(removed.items())),
                'snapshots_insertions_attempted':dict(arrivals),
                'total_independent_retained_rows':sum(len(b.rows) for b in spans.values()),
                'frames_seen':len(spans),'normalized_prefix_l1':str(maxnorm),
                'seconds':time.monotonic()-began,'paid_tests':paid_tests}
        outcomes.append(record)
        details[name]={'bases':spans,'hits':hits}
        print('DONE',args.labels,name,'hits',len(hits),'removed',dict(removed),'seconds',record['seconds'],flush=True)
    result={'status':'EXACT_CHRONOLOGICAL_SAME_FRAME_SPAN_SCREEN_COMPLETE',
            'source':str(SOURCE.relative_to(ROOT)),'source_sha256':sha256(raw).hexdigest(),
            'core_sha256':sha256(CORE.read_bytes()).hexdigest(),
            'labels':args.labels,'outcomes':outcomes,
            'scope':'Historical snapshots are ordinary scalar combinations only within the identical literal canonical frame. All initial original and helper owners remain independent. Scalar ADD/COPY/SCALE cannot enlarge this history span. Positive hits have exact rational reconstruction recipes; negative residuals are exact over Q in the stated warp-label algebra. No other-frame or additional address-operator combination is excluded.',
            'label_soundness':('Unreduced noncommutative warp words are formal independent symbols.' if args.labels=='free' else 'This is the phase-erased necessary projection of actual K_G words, not a literal identification K_G=P_G. Native K_G words are zero-offset monomials with fourth-root phases. At tensor width36, test the basis tuple (e0 repeated4,...,e8 repeated4): every phase cancels, and distinct binary address matrices give distinct output tuples. Thus any actual scalar recovery at all widths would solve this projected same-frame system at width36. Exact failure of that system excludes the uniform scalar recovery. It does not exclude recoding snapshots by additional operators.'),
            'seconds':time.monotonic()-started}
    output=HERE/('NATIVE-PAID-MEMOIZATION-'+args.labels.upper()+'.json')
    output.write_text(json.dumps(result,indent=2)+'\n')
    if any(r['chronological_same_frame_paid_hits'] for r in outcomes):
        (HERE/('NATIVE-PAID-MEMOIZATION-'+args.labels.upper()+'.pickle')).write_bytes(pickle.dumps(details,protocol=5))
    print('RECEIPT',output,flush=True)


if __name__=='__main__':main()
