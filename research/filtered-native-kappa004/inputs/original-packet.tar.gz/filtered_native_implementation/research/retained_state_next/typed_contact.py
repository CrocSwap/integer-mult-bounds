#!/usr/bin/env python3
"""Literal first coded-child contact and whole-state type propagation.

This is a compositional interface probe, not a recursively closed supplier.
Every semantic field is arbitrary; no borrowed field is used as zero scratch.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def jadd(x, y):
    return x[0] + y[0], x[1] + y[1]


def jmul(x, y):
    return x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0]


def scale(c, z):
    return c * z[0], c * z[1]


def serial(z):
    return [str(z[0]), str(z[1])]


def source_contacts(events):
    """Next literal cross-field scalar contact of each paid query owner."""
    queries = []
    for pos, event in enumerate(events):
        if event[0] == 'climb':
            queries.append((pos, ('L', event[2]), event[-1]))
        elif event[0] == 'center':
            queries.append((pos, ('C', event[1]), event[-1]))
    answer = []
    for pos, owner, rank in queries:
        unary = Counter()
        found = None
        for later in range(pos + 1, len(events)):
            e = events[later]
            if e[0] == 'scalar':
                s = e[1]
                if s[0] in ('add', 'copy') and owner in (tuple(s[1]), tuple(s[2])):
                    found = {'index': later, 'event': e,
                             'query_owner_role': 'destination' if tuple(s[1]) == owner else 'source'}
                    break
                if tuple(s[1]) == owner:
                    unary[s[0]] += 1
                    if s[0] == 'clear':
                        found = {'index': later, 'event': e, 'query_owner_role': 'cleared'}
                        break
            elif e[0] == 'warp' and tuple(e[1]) == owner:
                unary['warp'] += 1
            elif e[0] == 'adapter' and owner == ('L', e[2]):
                unary['adapter'] += 1
            elif e[0] == 'climb' and owner == ('L', e[2]):
                unary['additional_query'] += 1
            elif e[0] == 'center' and owner == ('C', e[1]):
                unary['additional_query'] += 1
        answer.append({'query_index': pos, 'owner': owner, 'rank': rank,
                       'next_contact': found, 'intervening_unary': dict(unary)})
    counts = Counter((a['next_contact']['event'][1][0], a['next_contact']['query_owner_role'])
                     if a['next_contact'] else ('none', 'none') for a in answer)
    return answer, [{'operation': k[0], 'owner_role': k[1], 'queries': v}
                    for k, v in sorted(counts.items())]


def actual_code_witness(norm):
    """Evaluate one actual block of J=Q^-1 B Q on the central input cube.

    B=C2 C1^-1 C0. Every active forward block leaves central bit zero,
    so C2 C1^-1 act as A A^-1=I on this restricted input. This is an
    algebraic restriction in the proof, not an uncharged physical projector.
    """
    R = norm['mode_columns']
    assert len(R) == 8 and all(len(row) == 112 for row in R)
    assert all(sum(R[a][i] * R[b][i] for i in range(112)) == 56 * (a == b)
               for a in range(8) for b in range(8))
    A = [[F(i == j) - F(sum(row[i] * row[j] for row in R), 4)
          for j in range(112)] for i in range(112)]
    ports = norm['ports']
    assert all(A[i][i] == 0 for i in range(112))
    assert all(not A[i][j] or (ports[i]['q'] & ports[j]['q']).bit_count() % 2 == 0
               for i in range(112) for j in range(112))

    def move(i, x, inverse=False):
        p = ports[i]
        rows = p['G_rows']
        if inverse:
            rows = [sum(((rows[j] >> k) & 1) << j for j in range(9)) for k in range(9)]
        y = sum(((r & x).bit_count() % 2) << j for j, r in enumerate(rows))
        sign = 1 - 2 * ((p['Z_mask'] & (x if inverse else y)).bit_count() % 2)
        return y, sign

    # The off-diagonal block owner 1 -> owner 0 is the actual retained marker.
    assert A[0][1] == F(-1, 2)
    y, sy = move(1, 1)
    marker, sx = move(0, y, True)
    assert (marker, sy * sx) == (22, -1)
    Q = {0: (F(1, 2), F(1, 2)), 1: (F(1, 2), F(-1, 2))}
    Qi = {0: (F(1, 2), F(-1, 2)), 1: (F(1, 2), F(1, 2))}
    block = {}
    for input_bit in (0, 1):
        for qflip, qcoef in Q.items():
            address = input_bit ^ qflip
            p, s1 = move(1, address)
            p, s2 = move(0, p, True)
            for outflip, outcoef in Qi.items():
                dest = p ^ outflip
                value = scale(A[0][1] * s1 * s2, jmul(outcoef, qcoef))
                key = dest, input_bit
                block[key] = jadd(block.get(key, (F(0), F(0))), value)
    marker_value = block[marker, 0]
    assert marker_value == (F(0), F(-1, 4))
    # S_c diag(J,I) S_c^-1 has upper-right block c(I-J).
    contact = scale(F(1, 2), marker_value)
    assert contact == (F(0), F(-1, 8))
    return {'input_owner': 1, 'output_owner': 0, 'input_address': 0,
            'output_address': marker, 'J_entry': serial(marker_value),
            'next_contact_upper_right_entry': serial(contact),
            'marker_signed_action': [marker, sy * sx],
            'actual_A01': str(A[0][1]),
            'code_word': 'J=Q^-1 C2 C1^-1 C0 Q',
            'reason_later_stages_cancel': 'On the central input cube all active C0 blocks have zero central bit; the other fresh stages see zero addresses, so their scalar owner matrices multiply to A A^-1=I.'}


def main():
    source = ROOT / 'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    normalizers = ROOT / 'upstream/research/coded-native-caller/NORMALIZERS.json'
    tariff = ROOT / 'research/coded_terminal_p3/PAID-ALTERNATIVE-RESULT.json'
    raw = gzip.decompress(source.read_bytes())
    program = json.loads(raw)
    norm = json.loads(normalizers.read_text())
    contacts = {}
    for orientation in ('forward', 'backward'):
        details, counts = source_contacts(program['programs'][orientation])
        contacts[orientation] = {'queries': len(details), 'contact_census': counts,
                                 'first_query': details[0], 'details': details}
    first = contacts['forward']['first_query']
    assert first['query_index'] == 6276 and first['owner'] == ('L', 126)
    assert first['next_contact']['index'] == 6277
    assert first['next_contact']['event'] == ['scalar', ['add', ['L', 126], ['L', 83], -1, 2], 137]
    witness = actual_code_witness(norm)
    t = json.loads(tariff.read_text())['results'][0]['current_source_packed_separated']
    paid = t['center_free_before_terminal_repair']['paid']
    helpers = t['one_Q_changed_target']['helper_targets']
    ordinary = Counter({int(k): v for k, v in helpers.items()})
    ordinary.update({25: 224, 57: 112})
    out = {'schema': 'first-chronological-coded-child-contact/v1',
           'status': 'EXACT_ONE_CONTACT_TYPE_PROPAGATION_NOT_RECURSIVE_CLOSURE',
           'source_pins': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest()
                           for p in (source, normalizers, tariff)},
           'decompressed_source_sha256': sha256(raw).hexdigest(),
           'contacts': contacts,
           'actual_code_witness': witness,
           'whole_state_transition': {'semantic_contact': 'S_c=[[I,cI],[0,I]], c=-1/2',
                                     'input_type': 'diag(J,I)',
                                     'output_type': '[[J,c(I-J)],[0,I]]',
                                     'next_unary_W_type': '[[W J W^-1,c W(I-J)],[0,I]]',
                                     'extra_queries_for_the_single_ADD': 0,
                                     'extra_scalar_ADDs_for_the_single_ADD': 0,
                                     'per_field_typebook_closed': False,
                                     'independent_source_fields_preserved': True},
           'complete_p3_child_invoice': {'c': t['c'], 'paid': paid,
                                        'ordinary_targets_including_helpers': {str(k): v for k, v in sorted(ordinary.items())},
                                        'coded_negative_target_types': {'25:Q^-1_B3_D': 224, '57:Q^-1_B7_D': 112},
                                        'negative_banks': 3,
                                        'independent_owners_per_negative_bank': 112,
                                        'formal_if_negative_types_were_Gaussians': t['center_free_before_terminal_repair']['formal_target_moment'],
                                        'negative_types_have_not_earned_that_Gaussian_credit': True},
           'finite_alphabet_obligation': 'The literal next ADD already requires a coupled two-field code. Every later child entry must bind its full code, its arbitrary original columns, and its own paid endpoint; no finite recursively closed alphabet is established by this contact.',
           'condition_growth': {'length3_J_operator_norm_upper_bound': 13 ** 2,
                                'length3_J_inverse_operator_norm_upper_bound': 13,
                                'length7_J_operator_norm_upper_bound': 13 ** 4,
                                'length7_J_inverse_operator_norm_upper_bound': 13 ** 3,
                                'height13_bound_length3_J': 1,
                                'height13_bound_length3_J_inverse': 2,
                                'height13_bound_length7_J': 3,
                                'height13_bound_length7_J_inverse': 4,
                                'single_ADD_conjugation_adds_odd_height': 0,
                                'whole_state_add_conjugation_2norm_multiplier_upper_bound': '9/4',
                                'scope': 'Uniform in digit width. These are local bounds only; completed sibling codes do not cancel without actual matching typed transitions.'},
           'no_new_supplier_or_kappa_claim': True}
    (HERE / 'TYPED-CONTACT.json').write_text(json.dumps(out, indent=2) + '\n')
    summary = {k: v for k, v in out.items() if k not in ('contacts', 'source_pins')}
    summary['contacts'] = {k: {a: b for a, b in v.items() if a != 'details'} for k, v in contacts.items()}
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
