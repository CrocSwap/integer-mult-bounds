#!/usr/bin/env python3
"""Independent source-direct fixed-vector kernel of all full-frame snapshots.

This does not read a prior snapshot cache or the parent's kernel solver.
It separately checks the literal native K_G phase function, its inverse
and raw-dual conjugate, and every physical warp frame transport.  It then
propagates 112 independent amplitudes through all source events.
"""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SOURCE=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
CLIFFORD=ROOT/'upstream/research/coded-native-caller/clifford_exact.py'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m


def xor_apply(columns,x):
    answer=0
    for i,v in enumerate(columns):
        if (x>>i)&1:answer^=v
    return answer


def conjugate(ce,operator):
    out=ce.ident(9)
    for gate in operator.circuit:
        kind=gate[0]
        if kind=='P':op=ce.perm(9,gate[1])
        elif kind=='D':op=ce.diag(9,gate[1],tuple(-x%4 for x in gate[2]))
        elif kind=='C':op=ce.cgate(9,gate[1],-gate[2])
        elif kind=='X':op=ce.xgate(9,gate[1])
        else:
            assert kind=='phase';op=ce.Op(9,ce.identity(9),[('phase',-gate[1]%4)])
        out=out.then(op)
    return out


def add(a,b,coefficient):
    for key,value in b.items():
        new=a.get(key,Q(0))+coefficient*value
        if new:a[key]=new
        else:a.pop(key,None)


def main():
    begin=time.monotonic();raw=SOURCE.read_bytes();blob=json.loads(gzip.decompress(raw));c=blob['canonical']
    ce=load('fixed_kernel_independent_ce',CLIFFORD)
    letters={};phasechecks=[]
    for w in c['warps']:
        columns=tuple(w['G_columns']);image=[xor_apply(columns,x) for x in range(512)]
        assert sorted(image)==list(range(512))
        inverse=[0]*512
        for x,y in enumerate(image):inverse[y]=x
        invcols=[inverse[1<<i] for i in range(9)]
        matrix=tuple((1<<i)^sum(((a&b).bit_count()%2)<<j for j,b in enumerate(invcols))
                     for i,a in enumerate(invcols))
        def phase(y):
            value=sum(((matrix[i]>>i)&1)*((y>>i)&1) for i in range(9))
            value+=2*sum(((matrix[i]>>j)&1)*((y>>i)&1)*((y>>j)&1)
                         for i in range(9) for j in range(i+1,9))
            return value%4
        phases=[phase(y) for y in image]
        assert image[0]==0 and phases[0]==0
        G=tuple(sum(((columns[j]>>i)&1)<<j for j in range(9)) for i in range(9))
        alpha=tuple((matrix[i]>>i)&1 for i in range(9))
        actual=ce.perm(9,G).then(ce.diag(9,matrix,alpha))
        # Reconstruct every Pauli image from the independent 512-address
        # phase table and compare the complete phase-sensitive tableau.
        for i,(px,pz,p) in enumerate(actual.tab[:9]):
            assert px==columns[i]
            for x,y in enumerate(image):
                assert (phases[x^(1<<i)]-phases[x]-p-2*((pz&y).bit_count()%2))%4==0
        for i,(px,pz,p) in enumerate(actual.tab[9:]):
            assert px==0 and p==0
            for x,y in enumerate(image):assert ((x>>i)&1)==((pz&y).bit_count()%2)
        for back in (False,True):
            op=conjugate(ce,actual) if back else actual
            assert op.zero_state()==ce.ident(9).zero_state()
            assert op.adjoint().zero_state()==ce.ident(9).zero_state()
            letters[back,w['op']]=op;letters[back,-w['op']]=op.adjoint()
        phasechecks.append({'op':w['op'],'fixes_zero_with_phase_one':True,
                            'addresses_and_all_Pauli_images_checked':512*18})
    frames={};warps={}
    def frame(f,back):
        key=f,back
        if key not in frames:
            op=ce.canonical_frame(9,c['frames'][f]);frames[key]=conjugate(ce,op) if back else op
        return frames[key]
    def apply_monomial(record,state):
        vector,den=state;out=[(0,0)]*512
        for x,value in enumerate(vector):
            y=ce.mv(record['matrix_rows'],x)^record['offset']
            phase=ce.qvalue(record['quadratic_rows'],record['linear_Z4'],x,9)+record['phase']
            out[y]=ce.mul_i(value,phase)
        return out,den
    for name,back in [('forward',False),('backward',True)]:
        for e in blob['programs'][name]:
            if e[0]!='warp':continue
            key=back,e[2],e[3],e[4]
            if key in warps:continue
            start,end=frame(e[3],back),frame(e[4],back)
            op=start.adjoint().then(letters[back,e[2]]).then(end)
            assert ce.rank([x for x,z,p in op.tab[9:]])==0
            compiled,record=ce.monomial(op)
            assert compiled.tab==op.tab and compiled.zero_state()==op.zero_state()
            assert apply_monomial(record,start.zero_state())==end.zero_state()
            warps[key]=record
    print('PHASE_TRANSPORT',len(phasechecks),'native labels',len(warps),'physical warp classes',flush=True)
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    R=[[Q(v) for v in row] for row in json.loads(rp.read_text())]
    outcomes=[]
    for name,back in [('forward',False),('backward',True)]:
        # Backward: X_i=Y_i=a_i|0>, H=0.  Forward: X=H=0,
        # Y_i=a_i|0>.  All a_i are independent, so one replay proves
        # the whole 112-dimensional kernel family.
        rows=[{} for _ in range(633)]
        for i in range(112):
            if back:rows[i]={i:Q(1)}
            rows[112+i]={i:Q(1)}
        cur=c['start'][:]+[None];seen=0;checked=[];paid=Counter()
        for pos,e in enumerate(blob['programs'][name]):
            kind=e[0];d=None
            if kind=='scalar':
                a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
                if a[0]=='clear':assert d==632;rows[d]={};cur[d]=f
                else:
                    assert cur[d]==f
                    if a[0] in ('add','copy'):
                        s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                        if a[0]=='copy':assert d==632;rows[d]=dict(rows[s])
                        else:add(rows[d],rows[s],Q(a[3],a[4]))
                    else:
                        assert a[0]=='scale';rows[d]={k:Q(a[2],a[3])*v for k,v in rows[d].items() if v*a[2]}
            elif kind=='warp':
                d=e[1][1]+(632 if e[1][0]=='C' else 0);assert cur[d]==e[3]
                assert (back,e[2],e[3],e[4]) in warps;cur[d]=e[4]
                # Literal phase transport just proved that a|0> stays
                # a|0> in normalized coordinates, for both orientations.
            elif kind=='climb':
                d=e[2];assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
            elif kind=='center':
                d=632+e[1];assert cur[d]==e[2];cur[d]=e[3];paid[e[4]]+=1
            else:assert kind in ('adapter','phase')
            if d is not None and cur[d]==1:
                seen+=1;assert not rows[d],(name,pos,d,rows[d]);checked.append((pos,d))
        assert cur[:632]==c['final'] and not rows[632]
        for i in range(632):
            expected={i-112:Q(1)} if 112<=i<224 else {}
            assert rows[i]==expected
        witnesses=[]
        for mode,r in enumerate(R):
            i=next(i for i,v in enumerate(r) if v)
            witnesses.append({'mode':mode,'nonzero_initial_logical_owners':([i,112+i] if back else [112+i]),
                              'amplitudes':['1','1'] if back else ['1'],
                              'nonzero_RY_amplitude':str(r[i]),
                              'nonzero_RX_amplitude':str(r[i]) if back else None})
        outcomes.append({'direction':name,'source_events_checked':len(blob['programs'][name]),
                         'independent_amplitudes':112,'full_frame_snapshots_identically_zero':seen,
                         'snapshot_timeline_sha256':sha256(repr(checked).encode()).hexdigest(),
                         'paid_profile':dict(sorted(paid.items())),'witnesses':witnesses})
        print('KERNEL_PASS',name,seen,'snapshots',flush=True)
    result={'schema':'independent-native-KG-fixed-vector-kernel/v1','status':'PASS',
            'source_sha256':sha256(raw).hexdigest(),'R_sha256':sha256(rp.read_bytes()).hexdigest(),
            'clifford_sha256':sha256(CLIFFORD.read_bytes()).hexdigest(),
            'literal_phase_checks':phasechecks,'physical_warp_classes':len(warps),
            'outcomes':outcomes,
            'all_width_proof':'Every actual K_G, inverse, and conjugated raw-dual K_G fixes |0> with phase1. Therefore each tensor power fixes |0>^tensor m. The exact rational 112-amplitude source replay remains valid for every positive m. All full-frame snapshots vanish on the stated input family, while the indicated R-mode targets are nonzero.',
            'physical_inputs':'For each nonzero logical original owner i, set its physical original array to T_start_i|0>^tensor m in the forward orientation, or conjugate(T_start_i)|0>^tensor m in the raw-dual orientation. These are legitimate arbitrary original inputs. Helpers are zero only in this counterexample input, never removed from the source contract.',
            'scope':'No function of only these full-frame snapshots can recover the nonzero target on all arbitrary inputs: zero input and the kernel input give identical snapshots. This excludes any ordinary recoding, any paid processing of only these snapshots, and any retained combination of them. It does not exclude access to original inputs, snapshots at other frames, altered gates, or new observations before/within the source.',
            'seconds':time.monotonic()-begin}
    out=HERE/'KG-FULL-FRAME-KERNEL-INDEPENDENT-REVIEW.json';out.write_text(json.dumps(result,indent=2)+'\n')
    print('DONE',out,'seconds',result['seconds'],flush=True)


if __name__=='__main__':main()
