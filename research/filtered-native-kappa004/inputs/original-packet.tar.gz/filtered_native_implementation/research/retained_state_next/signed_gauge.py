#!/usr/bin/env python3
"""Bind both raw-dual Q^2 conventions and the finite signed-code alphabet.

The nonclosure certificate is in the universal quotient algebra. Actual
native matrix identities beyond its presented relations are not excluded.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import importlib.util
import json

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_cache', HERE / 'cache_probe.py')
cache = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cache)


def main():
    gauge, formal, pins = cache.get_source()
    a = gauge.Algebra(7)
    Q = a.gen(1)
    Qi = a.inv(Q)
    Q2 = a.mul(Q, Q)
    Qm2 = a.inv(Q2)
    C = a.gen(2)
    Cp = a.mul(Q2, C, Qm2)
    D = a.D(0)
    DD = a.diag(D, D)

    def normal(x):
        result = {}
        for (word, d), c in x.items():
            for w, v in cache.expand(word):
                k = w, d
                result[k] = result.get(k, F(0)) + c * v
        return {k: v for k, v in result.items() if v}

    def same(x, y):
        return all(normal(x[i][j]) == normal(y[i][j]) for i in range(2) for j in range(2))

    raw = a.mm(DD, a.U(a.neg(a.mul(Qi, C))))
    bx = a.mm(a.diag(Q2, a.one), raw, a.diag(Qm2, a.one))
    by = a.mm(a.diag(a.one, Q2), raw, a.diag(a.one, Qm2))
    assert same(bx, a.mm(DD, a.U(a.neg(a.mul(Q, C)))))
    assert same(by, a.mm(DD, a.U(a.neg(a.mul(Q, Cp)))))
    assert normal(a.mul(Cp, Q, D)) == normal(a.mul(Q, D, Cp))
    assert normal(a.mul(C, Q)) != normal(a.mul(Q, C))
    assert normal(a.mul(Cp, Q)) != normal(a.mul(Q, Cp))

    signs = {e[1]: (-1 if e[3] else 1) for e in formal['physical_events'] if e[0] == 'LOCAL'}
    certificates = []
    for choices in product((0, 1), repeat=7):
        codes = {s: a.gen(s + 2) if choices[s] == 0 else a.mul(Q2, a.gen(s + 2), Qm2)
                 for s in range(7)}
        for role, target in enumerate(formal['exact_diagonal_monomials'][:3]):
            stages = [s for s in range(7) if target[s + 1]]
            B = a.one
            for s in stages:
                B = a.mul(codes[s] if signs[s] > 0 else a.inv(codes[s]), B)
            decoder = normal(a.mul(Qi, a.inv(B), Q))
            witnesses = []
            for (word, d), coefficient in decoder.items():
                # The unique maximum-stage-support term cannot cancel against
                # terms arising from a scalar part of any inverse code.
                if sum(x != 1 for x in word) == len(stages):
                    assert word[0] == word[-1] == 1
                    assert cache.left_free_class(word) != ()
                    witnesses.append({'word': word, 'coefficient': str(coefficient)})
            assert len(witnesses) == 1
            certificates.append({'signed_stage_choices': choices, 'negative_role': role,
                                 'stages': stages, 'maximal_stage_term': witnesses[0]})
    out = {'schema': 'signed-head-gauge-alphabet-probe/v1',
           'source_pins': pins,
           'raw_after_D_squared': 'diag(D,D) U(-Q^-1 C)',
           'X_Q_squared_convention': 'diag(D,D) U(-Q C)',
           'Y_Q_squared_convention': 'diag(D,D) U(-Q Cprime)',
           'Cprime': 'Q^2 C Q^-2',
           'both_physical_identities_exact': True,
           'Cprime_commutes_QD': True,
           'stage_choices_checked': 128,
           'negative_endpoint_decoders_checked': len(certificates),
           'free_algebra': 'Q-linear combinations of words in C_s and Q^2; inverses reduced with C_s^-1=(C_s+12I)/13.',
           'universal_quotient_nonclosure_certificates': certificates,
           'uniform_choice_actual_source': 'Choosing Cprime at every stage monomially conjugates B and its decoder by Q^2; the actual all-width row-support obstruction is unchanged.',
           'mixed_choice_scope': 'The algebra contains Cprime already and no choice removes the maximal distinct-stage odd-head word. This does not exclude additional identities of the actual 112-owner signed-monomial representation.',
           'new_paid_queries': 0,
           'added_monomial_cost_per_stage_code_prime_upper_bound': 224,
           'no_new_supplier_or_kappa_claim': True}
    (HERE / 'SIGNED-GAUGE.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k not in ('source_pins', 'universal_quotient_nonclosure_certificates')}, indent=2))


if __name__ == '__main__':
    main()
