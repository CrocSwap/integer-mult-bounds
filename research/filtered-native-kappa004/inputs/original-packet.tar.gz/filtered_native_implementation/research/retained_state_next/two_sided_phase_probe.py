#!/usr/bin/env python3
"""A source-specific two-sided input/output basis probe for one mode.

In actual K coordinates P=r^T r/56 is scalar on the owner index,
V_i=K_i Q K_i^-1 is projectively C(X_qi)^-1, and F=F9 commutes
every V_i.  Solve J F R = S F, J=V^-1(I-14P)V, allowing R and S
to contain an arbitrary one-mode gather/scatter conjugated by ordinary
central phase/Pauli maps. This is an input-and-output search, not a
postdecoder search.

We compare projective single-copy Clifford words. Such comparison is
necessary for a uniform identity on all tensor widths divisible by 4;
distinct projective matrices have independent sufficiently high tensor
powers. A modular failure is an exact exclusion for this finite ansatz.
A successful linear solution still needs phase and invertibility checks.
"""
from collections import defaultdict
from functools import lru_cache
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PRIME = 65521


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--paulis', action='store_true')
    ap.add_argument('--pairs', type=int, default=12)
    ap.add_argument('--gamma', default='14')
    ap.add_argument('--control', choices=('identity', 'even'))
    args = ap.parse_args()
    start = time.monotonic()
    ce = load('two_sided_phase_ce', ROOT / 'research/tensor_obstruction/inputs/clifford_exact.py')
    normal_path = ROOT / 'upstream/research/coded-native-caller/NORMALIZERS.json'
    raw = normal_path.read_bytes()
    normal = json.loads(raw)
    rpath = ROOT / 'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    r = [int(v) for v in json.loads(rpath.read_text())[5]]
    assert r == [-int(v) for v in normal['mode_columns'][7]]
    ports = [p for p in normal['ports'] if r[p['port']]]
    assert len(ports) == 56
    qs = [p['q'] for p in ports]
    gamma = Fraction(args.gamma)
    gamma_mod = gamma.numerator * pow(gamma.denominator, -1, PRIME) % PRIME
    if args.control == 'identity':
        gamma_mod = 0
    F = ce.fourier(9).tab
    Fi = ce.inverse(F)
    V = [ce.cgate(9, q, -1).tab for q in qs]
    if args.control == 'even':
        assert args.paulis
        V = [ce.xgate(9, q).tab for q in qs]
    Vi = [ce.inverse(v) for v in V]

    @lru_cache(maxsize=200000)
    def mul(a, b):
        return ce.compose(a, b)

    mono_specs = [(x, s) for x in range(2 if args.paulis else 1) for s in range(4)]
    K = len(mono_specs)
    G = []
    H = []
    for q in qs:
        # K_i Z_e K_i^-1=Z_q, while K_i X_e K_i^-1=-X_q.
        # The latter sign is irrelevant for widths divisible by four.
        zphase = ce.diag(9, tuple(q if q >> j & 1 else 0 for j in range(9)),
                         tuple(1 if q >> j & 1 else 0 for j in range(9)))
        # diag above has i^{linear+2quadratic}, i.e. i^{parity(q.x)}.
        # For weight>=3 the correct Z4 linear coefficients are all 1;
        # the quadratic coefficient is 2 on every pair in q.
        assert all(ce.qvalue(zphase.circuit[0][1], zphase.circuit[0][2], a, 9) == ((q&a).bit_count() & 1)
                   for a in range(512))
        gg = []
        for x, power in mono_specs:
            op = ce.ident(9)
            for _ in range(power):
                op = op.then(zphase)
            if x:
                op = op.then(ce.xgate(9, q))
            gg.append(op.tab)
        G.append(gg)
        H.append([mul(mul(F, g), Fi) for g in gg])
    names = [('diag', a) for a in range(K)] + [('mode', a, b) for a in range(K) for b in range(K)]
    B = len(names)
    nv = 2*B
    pivots = {}
    equations = 0
    known_control = [0]*nv
    if args.control:
        known_control[0] = known_control[B] = 1
        if args.control == 'even':
            known_control[B+K+4*K+4] = -gamma_mod

    def add_equation(row):
        nonlocal equations
        row = {j: v % PRIME for j, v in row.items() if v % PRIME}
        if args.control:
            assert sum(v*known_control[j] for j, v in row.items()) % PRIME == 0
        if not row:
            return
        equations += 1
        while row:
            j = min(row)
            if j not in pivots:
                inv = pow(row[j], -1, PRIME)
                pivots[j] = {k: v*inv % PRIME for k, v in row.items()}
                return
            old = pivots[j]
            c = row[j]
            for k, v in old.items():
                z = (row.get(k, 0)-c*v) % PRIME
                if z:
                    row[k] = z
                elif k in row:
                    del row[k]

    def nullspace():
        free = [j for j in range(nv) if j not in pivots]
        out = []
        for j in free:
            v = [0]*nv
            v[j] = 1
            for p in sorted(pivots, reverse=True):
                v[p] = -sum(c*v[k] for k, c in pivots[p].items() if k != p) % PRIME
            out.append(v)
        return out

    # Distinct actual ports, both diagonal and off diagonal. Pair selection
    # is deterministic and explicit; a failed necessary subsystem suffices.
    pair_list = [(0, 0), (0, 1), (1, 0), (1, 1), (0, 7), (7, 0),
                 (0, 13), (13, 0), (0, 27), (27, 0), (0, 55), (55, 0),
                 (13, 27), (27, 13), (27, 55), (55, 27)]
    progress = []
    for i, j in pair_list[:args.pairs]:
        terms = defaultdict(lambda: defaultdict(int))

        def emit(op, var, coef):
            terms[op][var] += coef

        # Multiply every equation by 56^2/(r_i r_j). On diagonal
        # r_i*r_i=1, so all coefficients below are exact integers.
        for a in range(K):
            if i == j:
                emit(H[i][a], a, 56*56)
            emit(mul(mul(Vi[i], V[j]), H[j][a]), a, -gamma_mod*56)
            if i == j:
                emit(G[i][a], B+a, -56*56)
        for a in range(K):
            for b in range(K):
                col = K + a*K + b
                emit(mul(H[i][a], H[j][b]), col, 56)
                for k in range(56):
                    emit(mul(mul(mul(Vi[i], V[k]), H[k][a]), H[j][b]), col, -gamma_mod)
                emit(mul(G[i][a], G[j][b]), B+col, -56)
        for row in terms.values():
            add_equation(row)
        ns = nullspace()
        diag_support = sorted({a for v in ns for a in range(K) if v[a]})
        rec = {'owner_pair': [ports[i]['port'], ports[j]['port']],
               'rank': len(pivots), 'nullity': nv-len(pivots),
               'possible_R_diagonal_basis_indices': diag_support,
               'elapsed_seconds': round(time.monotonic()-start, 3)}
        progress.append(rec)
        print(json.dumps(rec), flush=True)

    ns = nullspace()
    diag_support = sorted({a for v in ns for a in range(K) if v[a]})
    result = {
        'schema': 'actual-singlemode-two-sided-phase-intertwiner/v1',
        'equation': 'J F R = S F, J=V^-1(I-14P5)V, F=F9',
        'actual_gamma': str(gamma),
        'control': args.control,
        'known_nonzero_control_checked': bool(args.control),
        'prime': PRIME,
        'source_sha256': sha256(raw).hexdigest(),
        'selected_mode': 5,
        'mode_basis': 'actual native R.json row5, equal to negative NORMALIZERS.mode_columns row7',
        'mode_source_sha256': sha256(rpath.read_bytes()).hexdigest(),
        'actual_active_ports': [p['port'] for p in ports],
        'ordinary_monomial_specs': mono_specs,
        'basis': names,
        'basis_size_each_side': B,
        'variables': nv,
        'equations_processed': equations,
        'rank': len(pivots),
        'nullity': nv-len(pivots),
        'nullspace_mod_prime': ns,
        'possible_R_diagonal_basis_indices': diag_support,
        'identity_leading_R_excluded': not any(v[0] for v in ns),
        'all_R_solutions_have_only_mode_factors': not diag_support,
        'mode_factor_rank_upper_bound_in_address_units': K,
        'needed_independent_owner_units': 56,
        'progress': progress,
        'projective_scope': 'Necessary coefficient identity for all tensor widths divisible by4. Scalar phases are retained only projectively, making this a relaxation; no positive all-width factorization is certified.',
        'scope': 'Only the declared finite one-mode phase/Pauli precode and output-code spans. No exclusion for arbitrary ordinary circuits or changed target family.',
        'elapsed_seconds': round(time.monotonic()-start, 3),
    }
    stem = 'TWO-SIDED-PAULI' if args.paulis else 'TWO-SIDED-PHASE'
    if args.control:
        stem += '-CONTROL-'+args.control.upper()
    elif gamma != 14:
        stem += '-INVERSE'
    (HERE/(stem+'.json')).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('basis', 'nullspace_mod_prime', 'progress')}, indent=2))


if __name__ == '__main__':
    main()
