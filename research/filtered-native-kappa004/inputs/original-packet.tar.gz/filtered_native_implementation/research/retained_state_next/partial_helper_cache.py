#!/usr/bin/env python3
"""Literal pre-center G-chart cache span for partial rank-seven repair.

Every cached field is copied from an actual chronological value.  Original
owners remain arbitrary.  A failed span only excludes scalar combinations
of these exact chart-aligned snapshots, not arbitrary monomial reroutings.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    return m

class Basis:
    def __init__(self): self.rows={};self.pivots=[];self.snapshots=[]
    def reduce(self,row):
        row=dict(row)
        while row:
            k=min(row)
            if k not in self.rows: break
            a=row[k]
            for j,v in self.rows[k].items():
                z=row.get(j,F(0))-a*v
                if z:row[j]=z
                else:row.pop(j,None)
        return row
    def add(self,row,record):
        row=self.reduce(row)
        if not row:return
        k=min(row);a=row[k]
        self.rows[k]={j:v/a for j,v in row.items()};self.pivots.append(k)
        self.snapshots.append(record)

def encode(row):
    return [[i,list(w),str(a)] for (i,w),a in sorted(row.items())]

def main():
    path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw=path.read_bytes();source=json.loads(gzip.decompress(raw));c=source['canonical']
    es=source['programs']['forward'];selected=[i for i,e in enumerate(es) if e[0]=='center'][5]
    ce=load('helpercache_ce',ROOT/'research/tensor_obstruction/inputs/clifford_exact.py')
    core=load('helpercache_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    prior=json.loads((HERE/'PARTIAL-CENTER7.json').read_text())
    witness=json.loads((HERE/'CENTER5-SUFFIX.json').read_text())
    qs=prior['eligible_rank7_directions']
    helper={(i,()):F(a) for i,a in witness['capture']['helper_terms']}
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    r=json.loads(rp.read_text())[5]
    mainrow={(i,()):F(a) for i,a in enumerate(r) if F(a)}
    total={**mainrow,**helper}
    # A Gaussian-rank-one G can only be left-monomial equivalent to a
    # rank-one native frame.  Test the complete rank-one native census.
    rankone={i:ce.canonical_frame(9,a) for i,a in enumerate(c['frames']) if len(a)==1}
    matches={};certs=[]
    for q in qs:
        G=ce.cgate(9,q)
        for f,S in rankone.items():
            op=S.adjoint().then(G)
            if ce.rank([x for x,z,p in op.tab[9:]])==0:
                mon,rec=ce.monomial(op)
                assert mon.tab==op.tab and mon.zero_state()==op.zero_state()
                matches.setdefault(f,[]).append(q)
                certs.append({'q':q,'frame':f,'ordinary_wrapper':rec})
    rows=[core.identity(i) for i in range(632)]+[{}]
    cur=c['start'][:]+[None]
    bases={q:Basis() for q in qs};seen=Counter()
    def observe(owner,event):
        for q in matches.get(cur[owner],[]):
            seen[q]+=1
            bases[q].add(rows[owner],{'event':event,'owner':owner,'frame':cur[owner]})
    for i in range(632):observe(i,-1)
    for index,e in enumerate(es[:selected]):
        typ=e[0];changed=None
        if typ=='scalar':
            a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0);changed=d
            if a[0]=='clear':rows[d]={};cur[d]=f
            else:
                assert cur[d]==f
                if a[0] in ('copy','add'):
                    s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                    if a[0]=='copy':rows[d]=dict(rows[s])
                    else:core.add(rows[d],rows[s],F(a[3],a[4]))
                else:
                    assert a[0]=='scale';rows[d]={k:v*F(a[2],a[3]) for k,v in rows[d].items() if v*a[2]}
        elif typ=='warp':
            _,d,op,f,g=e;d=d[1]+(632 if d[0]=='C' else 0);changed=d
            assert cur[d]==f;rows[d]=core.warp(rows[d],op,False);cur[d]=g
        elif typ=='climb':
            _,_,d,f,g,k=e;changed=d;assert cur[d]==f;cur[d]=g
        elif typ=='center':
            _,d,f,g,k=e;d+=632;changed=d;assert cur[d]==f;cur[d]=g
        else:assert typ in ('phase','adapter','residual_adapter')
        if changed is not None:observe(changed,index)
    assert rows[632]==total and cur[632]==280
    records=[]
    for q,b in bases.items():
        hr=b.reduce(helper);xr=b.reduce(mainrow);lr=b.reduce(total)
        records.append({'q':q,'observations':seen[q],'independent_snapshot_rows':len(b.rows),
                        'helper_in_span':not hr,'main_mode_in_span':not xr,'dirty_total_in_span':not lr,
                        'helper_residual_terms':len(hr),'main_mode_residual_terms':len(xr),
                        'dirty_total_residual_terms':len(lr),'retained_basis_snapshots':b.snapshots,
                        'helper_residual':encode(hr)})
    out={'schema':'actual-prefix-partial-G-helper-cache/v1',
         'source_sha256':sha256(raw).hexdigest(),'R_source_sha256':sha256(rp.read_bytes()).hexdigest(),
         'mode':5,'center_event':selected,'eligible_G_count':len(qs),
         'tested_all_native_rankone_frames':len(rankone),'phase_exact_chart_matches':certs,
         'all_original_owners_independent':632,'exact_arithmetic':'fractions.Fraction',
         'helper_source_terms':len(helper),'probes':records,
         'success_count':sum(x['helper_in_span'] for x in records),
         'best_helper_residual_terms':min(x['helper_residual_terms'] for x in records),
         'scope':'Scalar linear span of every actual native prefix value that has an exact ordinary conversion to the requested bare G chart. Copies may be retained from different prior times. Arbitrary further monomial rearrangements of the cached data are outside this finite probe.'}
    (HERE/'PARTIAL-HELPER-CACHE.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('probes','phase_exact_chart_matches')},indent=2))
    print(json.dumps({'rank_census':dict(Counter(x['independent_snapshot_rows'] for x in records)),
                      'residual_census':dict(Counter(x['helper_residual_terms'] for x in records)),
                      'best_q':[x['q'] for x in records if x['helper_residual_terms']==out['best_helper_residual_terms']]},indent=2))

if __name__=='__main__':main()
