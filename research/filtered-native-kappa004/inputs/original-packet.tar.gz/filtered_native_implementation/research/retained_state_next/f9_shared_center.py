#!/usr/bin/env python3
"""Reuse the actual late rank-one L240 query for a full-F9 center residual.

The backward convention uses conjugated physical frames.  Cross-frame
COPY/ADD below are identity maps on physical field data, never implicit
Gaussian transformations.  Their normalized logical effect is F9.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import copy
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
F9SYM=2000009

def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    return m

def main():
    path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw=path.read_bytes();src=json.loads(gzip.decompress(raw));c=src['canonical']
    ce=load('shared_f9_ce',ROOT/'research/tensor_obstruction/inputs/clifford_exact.py')
    core=load('shared_f9_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    prior=json.loads((HERE/'CENTER5-SUFFIX.json').read_text())
    rpath=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    r=[F(x) for x in json.loads(rpath.read_text())[5]]
    hs={i:F(v) for i,v in prior['capture']['helper_terms']}
    l={(i,()):v for i,v in enumerate(r) if v};l.update({(i,()):v for i,v in hs.items()})
    S=ce.canonical_frame(9,c['frames'][280]);G=ce.fourier(9)
    def conjugate(op):
        circ=[]
        for e in op.circuit:
            if e[0]=='C':circ.append(('C',e[1],-e[2]))
            elif e[0]=='D':circ.append(('D',e[1],tuple(-a%4 for a in e[2])))
            elif e[0]=='phase':circ.append(('phase',-e[1]%4))
            else:circ.append(e)
        return ce.Op(9,tuple((x,z,-p%4) for x,z,p in op.tab),circ)
    B=S.adjoint().then(G)
    lowering,compiled=ce.lower_child(B)
    assert lowering['rank']==1 and compiled.tab==B.tab and compiled.zero_state()==B.zero_state()
    dual=conjugate(B.adjoint())
    # The late backward climb is bar(B), not B.  Thus bar(B)*B^T=I
    # for this unitary transfer, including its absolute scalar phase.
    merge=dual.then(conjugate(B))
    assert merge.tab==ce.ident(9).tab and merge.zero_state()==ce.ident(9).zero_state()

    programs={};edits={}
    for direction in ('forward','backward'):
        es=src['programs'][direction]
        assert es[17155]==['climb','scalar_refactor',240,280,1,1]
        # Validate every possible owner-reference spelling in the gap.
        low=11400 if direction=='forward' else 11423
        for e in es[low+1:17155]:
            if e[0]=='scalar':assert ['L',240] not in e[1]
            elif e[0]=='warp':assert e[1]!=['L',240]
            elif e[0]=='climb':assert e[2]!=240
        out=[]
        for i,e in enumerate(es):
            if direction=='forward':
                if i==11399:out.append(['scalar',['clear',['C',0]],0]);continue
                if i==11400:
                    out.append(copy.deepcopy(es[17155]))
                    out.append(['physical_copy',['C',0],['L',240],0,1,[]])
                    continue
                if i in (11401,17155):continue
            else:
                if i==11422:
                    out.extend([['scalar',['clear',['C',1]],0],
                                ['scalar',['copy',['C',1],['C',0]],0]])
                    continue
                if i==11423:continue
                if i==11424:out.append(['scalar',['clear',['C',0]],0]);continue
                if i==17155:
                    out.extend([copy.deepcopy(e),
                                ['physical_add',['L',240],['C',1],-1,1,1,0,[]],
                                ['scalar',['clear',['C',1]],0]])
                    continue
            out.append(copy.deepcopy(e))
        programs[direction]=out
        edits[direction]={'original_center_event':11401 if direction=='forward' else 11422,
                          'shared_paid_event':17155,
                          'extra_owned_fields':0 if direction=='forward' else 1,
                          'events':len(out)}

    def run(es,back):
        rows=[core.identity(i) for i in range(632)]+[{},{}]
        cur=c['start'][:]+[None,None];paid=Counter();counts=Counter();maxnorm=F(1)
        for e in es:
            typ=e[0];counts[typ]+=1
            if typ=='scalar':
                a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
                if a[0]=='clear':assert d>=632;rows[d]={};cur[d]=f
                else:
                    assert cur[d]==f
                    if a[0] in ('copy','add'):
                        s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                        if a[0]=='copy':assert d>=632;rows[d]=dict(rows[s])
                        else:core.add(rows[d],rows[s],F(a[3],a[4]))
                    else:
                        assert a[0]=='scale';rows[d]={k:v*F(a[2],a[3]) for k,v in rows[d].items() if v*a[2]}
                maxnorm=max(maxnorm,sum(map(abs,rows[d].values()),F(0)))
            elif typ=='warp':
                _,d,op,f,g=e;d=d[1]+(632 if d[0]=='C' else 0)
                assert cur[d]==f;rows[d]=core.warp(rows[d],op,back);cur[d]=g
            elif typ=='climb':
                _,_,d,f,g,k=e;assert cur[d]==f;cur[d]=g;paid[k]+=1
            elif typ=='center':
                _,d,f,g,k=e;d+=632;assert cur[d]==f;cur[d]=g;paid[k]+=1
            elif typ=='physical_copy':
                _,dt,st,df,sf,word=e;d=dt[1]+632;s=st[1]
                assert not back and not word and (df,sf)==(0,1)
                assert cur[d]==df and cur[s]==sf
                # Physically COPY F9*l into a ground-tagged owned output.
                assert rows[s]==l
                rows[d]={(o,(F9SYM,)+w):v for (o,w),v in rows[s].items()}
            elif typ=='physical_add':
                _,dt,st,a,b,df,sf,word=e;d=dt[1];s=st[1]+632
                assert back and not word and (df,sf)==(1,0)
                assert cur[d]==df and cur[s]==sf
                # Physical destination frame is bar(F9); identity ADD
                # therefore contributes logical F9 times the ground cache.
                add={(o,(F9SYM,)+w):v for (o,w),v in rows[s].items()}
                core.add(rows[d],add,F(a,b))
            else:assert typ in ('phase','adapter','residual_adapter')
        assert cur[:632]==c['final'] and not rows[632] and not rows[633]
        expected=[core.expected(i,back) for i in range(632)]+[{},{}]
        for i,ri in enumerate(r):
            if not ri:continue
            for (j,w),a in l.items():
                d,s,k=(j,112+i,-ri*a/4) if back else (112+i,j,ri*a/4)
                core.add(expected[d],{(s,(F9SYM,)):F(1)},k)
                core.add(expected[d],core.identity(s),-k)
        assert rows==expected
        return {'all632_original_rows_checked':True,'all_actual_frames_checked':True,
                'arbitrary_helper_response_retained':True,'owned_C0_C1_final_zero':True,
                'paid_profile':dict(sorted(paid.items())),'max_l1_normalized_row':str(maxnorm),
                'opcode_census':dict(counts)}
    outcomes={d:run(es,d=='backward') for d,es in programs.items()}
    blob={'schema':'actual-shared-F9-center-word/v1','source_sha256':sha256(raw).hexdigest(),
          'canonical':c,'programs':programs,'new_owned_slots':{'forward':[],'backward':[1]},
          'physical_frames':'Forward uses S_f; backward uses conjugate(S_f).',
          'new_opcode_spec':{
              'physical_copy':'[opcode,dst,src,dst_frame,src_frame,ordinary_word]; copies actual field data after ordinary_word; only owned destination.',
              'physical_add':'[opcode,dst,src,numerator,denominator,dst_frame,src_frame,ordinary_word]; add transformed actual field data. All emitted words are empty identity.'},
          'normalized_F9_symbol':F9SYM}
    payload=json.dumps(blob,sort_keys=True,separators=(',',':')).encode()
    packed=gzip.compress(payload,mtime=0)
    (HERE/'F9-SHARED-CENTER-WORDS.json.gz').write_bytes(packed)
    out={'schema':'actual-shared-F9-center/v1','source_sha256':sha256(raw).hexdigest(),
         'R_source_sha256':sha256(rpath.read_bytes()).hexdigest(),
         'word_sha256':sha256(packed).hexdigest(),'word_payload_sha256':sha256(payload).hexdigest(),
         'mode':5,'shared_native_owner':240,'original_shared_paid_event':17155,
         'no_intervening_reads_or_writes_of_L240_verified':True,
         'shared_physical_query':'B=F9 S280^-1','shared_query_rank':1,
         'shared_query_lowering':lowering,'shared_query_word':compiled.circuit,
         'raw_dual_physical_frames_conjugated':True,
         'dual_merge_identity':'bar(B) B^T=I, exactly including absolute phase',
         'edits':edits,'replays':outcomes,
         'forward_endpoint':'X,H unchanged; Y_i+=X_i+(r_i/4)(F9^⊗m-I)(rX+SH)',
         'raw_dual_endpoint':'Y unchanged; X_i-=Y_i+(r_i/4)(F9^⊗m-I)rY; H_h-=(S_h/4)(F9^⊗m-I)rY',
         'all_width_logic':'The actual source free-group suffix cancels every native warp around the new F9 symbol. Physical identity cross-frame operations lift at every width. Scalars r_i/4 and S_h remain outside tensor powers.',
         'dirty_helper_correction_not_yet_implemented':True,
         'same_input_clean_target_identity':'If z=(14F9^⊗m-13I)F9^⊗m v is supplied and the same original v retained, then F9^⊗m v=(14(F9²)^⊗m v-z)/13.',
         'target_identity_is_not_yet_bound_to_a_helper_clean_full_caller':True,
         'status':'PASS_ACTUAL_SHARED_QUERY_PRODUCER_BOTH_ORIENTATIONS; DIRTY_HELPER_AND_CALLER_CLOSURE_OPEN',
         'new_supplier_or_kappa':False}
    (HERE/'F9-SHARED-CENTER.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('shared_query_lowering','shared_query_word')},indent=2))

if __name__=='__main__':main()
