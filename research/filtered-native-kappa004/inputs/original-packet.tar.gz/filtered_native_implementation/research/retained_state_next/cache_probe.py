#!/usr/bin/env python3
"""Cache the literal p3 caller's observable main boundaries.

This is an exact universal-algebra discovery probe. It adds C_s^2+12C_s=13I
and Q^4=I to the pinned noncommutative chronology. A negative result is scoped
to this algebra, not every identity of the particular 112-owner realization.
"""
from collections import defaultdict
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import importlib.util
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
UP=ROOT/'upstream'
P=None

def mod(x):
    x=F(x)
    return x

def right_letter(word,g):
    if abs(g)==1:
        k=0
        while k<len(word) and word[-1-k]==1:k+=1
        prefix=word[:-k] if k else word
        return {prefix+(1,)*((k+(1 if g==1 else -1))%4):1}
    if g>0:
        if word and word[-1]==g:
            return {word:F(-12),word[:-1]:F(13)}
        return {word+(g,):1}
    z={word:F(12,13)}
    for w,c in right_letter(word,-g).items():z[w]=z.get(w,0)+c/F(13)
    return {w:c for w,c in z.items() if c}

@lru_cache(None)
def expand(word):
    out={():1}
    for g in word:
        new=defaultdict(int)
        for w,c in out.items():
            for u,d in right_letter(w,g).items():new[u]=new[u]+c*d
        out={w:c for w,c in new.items() if c}
    return tuple(out.items())

def left_free_class(word):
    """Canonical suffix after the first odd Q run; H=<all C_s,Q^2>."""
    i=0
    while i<len(word):
        if word[i]!=1:i+=1;continue
        j=i
        while j<len(word) and word[j]==1:j+=1
        if (j-i)%2:return (1,)+word[j:]
        i=j
    return ()

def get_source():
    fp=UP/'research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    gp=UP/'research/coded-native-caller/gauge.py'
    spec=importlib.util.spec_from_file_location('retained_p3_cache_gauge',gp)
    gauge=importlib.util.module_from_spec(spec);spec.loader.exec_module(gauge)
    formal=json.loads(fp.read_text())['selected_p3_keep43']
    return gauge,formal,{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in (fp,gp)}

def caller_cache():
    gauge,f,pins=get_source();a=gauge.Algebra(7)
    scalar=lambda x:a.term((),(0,)*7,F(x))
    Q=a.gen(1);codes={s:a.gen(s+2) for s in range(7)}
    signs={e[1]:(-1 if e[3] else 1) for e in f['physical_events'] if e[0]=='LOCAL'}
    rows=[[scalar(i==j) for j in range(6)] for i in range(6)]
    caches=[]
    def snap(label):
        for i,row in enumerate(rows):caches.append((label,i,[dict(v) for v in row]))
    snap('original')
    rows=[[scalar(x) for x in r] for r in f['right']];snap('right_boundary')
    def left(i,z):rows[i]=[a.mul(z,v) for v in rows[i]]
    def plus(i,j,z):rows[i]=[a.add(v,a.mul(z,u)) for v,u in zip(rows[i],rows[j])]
    for number,e in enumerate(f['physical_events']):
        label=f'{number}:{e[0]}'
        if e[0]=='LOCAL':
            _,s,pair,back=e;x,y=2*pair,2*pair+1;c=codes[s]
            recode=a.inv(c) if back else c
            left(y,recode);snap(label+':precode')
            plus(x,y,a.neg(a.mul(Q,c))) if back else plus(y,x,a.mul(c,a.inv(Q)))
            left(x,a.D(s));left(y,a.D(s));snap(label+':native_return')
            left(x,recode)
        elif e[0]=='IDLE':
            _,pair,stages=e;b,d=a.one,a.one
            for s in stages:
                b=a.mul(codes[s] if signs[s]>0 else a.inv(codes[s]),b)
                d=a.mul(a.D(s),d)
            left(2*pair+1,b);snap(label+':precode')
            left(2*pair,d);left(2*pair+1,d);snap(label+':paid_return')
            left(2*pair,b)
        elif e[0]=='ADD':plus(e[1],e[2],scalar(e[3]))
        elif e[0]=='SIGNED_SWAP':
            _,x,y=e;rows[x],rows[y]=rows[y],[a.neg(v) for v in rows[x]]
        else:raise ValueError(e)
        snap(label+':complete')
    rows=[[a.add(*(a.mul(scalar(f['left'][i][k]),rows[k][j]) for k in range(6)))
           for j in range(6)] for i in range(6)];snap('left_boundary')
    return a,f,caches,rows,pins

def main():
    a,f,caches,final,pins=caller_cache()
    # Normalize each cached scalar coefficient in the quotient algebra.
    normalized=[];max_terms=0
    for label,bank,row in caches:
        out=defaultdict(int)
        for owner,entry in enumerate(row):
            for (word,d),c in entry.items():
                for w,v in expand(word):out[(owner,d,w)]=out[(owner,d,w)]+mod(c)*v
        out={k:v for k,v in out.items() if v};max_terms=max(max_terms,len(out))
        normalized.append((label,bank,out))
    results=[]
    for owner,target in enumerate(f['exact_diagonal_monomials']):
        d=tuple(target[1:]);required=(1,)
        witnesses=[];same_d=0
        for label,bank,row in normalized:
            for (j,dd,w),c in row.items():
                if j==owner and dd==d:
                    same_d+=1
                    if left_free_class(w)==required:witnesses.append([label,bank,list(w),str(c)])
        results.append({'owner_bank':owner,'head_sign':target[0],
                        'target_D_vector':d,'same_owner_and_D_terms':same_d,
                        'target_free_left_class_occurrences':len(witnesses),
                        'examples':witnesses[:5]})
    out={'schema':'retained-main-boundary-cache-discovery/v1','coefficient_field':'Q',
         'source_pins':pins,'cache_snapshots':len(caches)//6,'cached_bank_rows':len(caches),
         'max_normalized_terms_per_row':max_terms,'results':results,
         'free_left_algebra':'All scalar combinations and words in C_0,...,C_6 and Q^2; inverses included through C^-1=(C+12I)/13.',
         'quotient_relations':['Q^4=I','C_s^2=-12C_s+13I','D_s C_s=Q^-1 C_s Q D_s','[D_s,C_t]=0 for s!=t','[D_s,Q]=[D_s,D_t]=0'],
         'scope':'Exact rational probe of all explicit main-bank caller boundaries; it is not an exclusion using every actual signed-monomial or 112-owner matrix identity, nor a full native-internal cache census.'}
    (HERE/'CACHE-RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('source_pins','results')}))
    for r in results:print(json.dumps(r))

if __name__=='__main__':main()
