#!/usr/bin/env python3
"""Actual standalone source sub-supplier and its true boundary invoice."""
from collections import Counter
from decimal import Decimal as D,getcontext
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    return m

def main():
    path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw=path.read_bytes();s=json.loads(gzip.decompress(raw));c=s['canonical']
    core=load('source_only_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    ce=load('source_only_ce',ROOT/'research/tensor_obstruction/inputs/clifford_exact.py')
    owned=set(range(112))|set(range(224,632))
    def idx(a):return a[1]+(632 if a[0]=='C'else 0)
    out=[];indices=[];rows=[core.identity(i) for i in range(632)];cur=c['start'][:]
    paid=Counter();maxnorm=F(1);counts=Counter()
    for k,e in enumerate(s['programs']['forward']):
        typ=e[0];d=None
        if typ=='scalar':d=idx(e[1][1])
        elif typ=='climb':d=e[2]
        elif typ=='warp':d=idx(e[1])
        elif typ=='adapter':d=e[2]
        if d not in owned:continue
        out.append(e);indices.append(k);counts[typ]+=1
        if typ=='scalar':
            a,f=e[1:];assert cur[d]==f
            assert a[0] not in ('copy','clear')
            if a[0]=='add':
                src=idx(a[2]);assert src in owned and cur[src]==f
                core.add(rows[d],rows[src],F(a[3],a[4]))
            else:assert a[0]=='scale';rows[d]={j:v*F(a[2],a[3]) for j,v in rows[d].items() if v*a[2]}
            maxnorm=max(maxnorm,sum(map(abs,rows[d].values()),F(0)))
        elif typ=='warp':assert cur[d]==e[3];rows[d]=core.warp(rows[d],e[2],False);cur[d]=e[4]
        elif typ=='climb':assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
    assert all(rows[i]==core.identity(i) for i in range(632))
    assert all(cur[i]==c['final'][i] for i in owned)
    assert all(cur[i]==c['start'][i] for i in range(112,224))
    frames={i:ce.canonical_frame(9,a) for i,a in enumerate(c['frames']) if i in set(c['start'])|set(c['final'])}
    target=Counter();helpers=Counter();rank_records=[]
    for i in sorted(owned):
        op=frames[c['start'][i]].adjoint().then(frames[c['final'][i]])
        rank=ce.rank([x for x,z,p in op.tab[9:]])
        target[rank]+=1
        if i>=224:helpers[rank]+=1
        else:assert rank==8
        rank_records.append({'owner':i,'start_frame':c['start'][i],'final_frame':c['final'][i],'actual_transfer_rank':rank})
    assert helpers=={4:28,7:7,8:47,9:326}
    assert sum(k*v for k,v in target.items())==sum(k*v for k,v in paid.items())==4367
    getcontext().prec=60;p=1-D('.0030217758')
    pm=sum(D(v)*D(k)**p for k,v in paid.items());tm=sum(D(v)*D(k)**p for k,v in target.items())
    allpaid=Counter(e[-1] for e in s['programs']['forward'] if e[0] in ('climb','center'))
    consumer=allpaid-paid
    payload=json.dumps({'schema':'standalone-native-source-supplier/v1','source_sha256':sha256(raw).hexdigest(),
                        'canonical':c,'program':out,'original_indices':indices,
                        'productive_owners':sorted(owned),'spectator_Y_identities':list(range(112,224)),
                        'extra_owned_fields':0},sort_keys=True,separators=(',',':')).encode()
    packed=gzip.compress(payload,mtime=0);(HERE/'SOURCE-ONLY-WORD.json.gz').write_bytes(packed)
    result={'schema':'standalone-native-source-invoice/v1','source_sha256':sha256(raw).hexdigest(),
            'word_sha256':sha256(packed).hexdigest(),'word_payload_sha256':sha256(payload).hexdigest(),
            'actual_source_fields':520,'productive_X':112,'productive_helpers':408,
            'all632_logical_rows_checked':True,'all520_actual_transfer_ranks_checked':True,
            'no_Y_dependency':True,'no_center_queries':True,'no_new_owned_fields':True,
            'original_Y_fields_are_unread_unchanged_spectators':True,
            'paid_profile':dict(sorted(paid.items())),'helper_targets':dict(sorted(helpers.items())),
            'all_target_profile':dict(sorted(target.items())),'paid_first_mass':4367,'target_first_mass':4367,
            'benchmark_c':'.0030217758','paid_moment':str(pm),'target_moment':str(tm),'moment_margin':str(tm-pm),
            'rank_certificates':rank_records,
            'warning':'Final frame dimensions alone are not target ranks. The actual start-to-final transfer removes59 units of spurious first mass.',
            'remaining_original_consumer_paid_profile_including_centers':dict(sorted(consumer.items())),
            'events':len(out),'opcode_census':dict(counts),'max_l1_normalized_row':str(maxnorm),
            'status':'PASS_STANDALONE_SOURCE_INTERFACE; NEGATIVE_MOMENT_AT_BENCHMARK',
            'new_supplier_or_kappa':False}
    (HERE/'SOURCE-ONLY-INVOICE.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rank_certificates'},indent=2))

if __name__=='__main__':main()
