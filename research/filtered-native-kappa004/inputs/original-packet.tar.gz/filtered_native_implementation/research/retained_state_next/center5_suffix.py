#!/usr/bin/env python3
"""Exact partial-center producer, retained full-X mode, and real Y exit.

This authenticates a useful active boundary, including all original helper
columns. It deliberately does not claim that the bare-translation scatter
has been implemented with two queries.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def main():
    source = ROOT / 'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    corepath = ROOT / 'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py'
    rpath = ROOT / 'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    ce_path = ROOT / 'research/tensor_obstruction/inputs/clifford_exact.py'
    normpath = ROOT / 'upstream/research/coded-native-caller/NORMALIZERS.json'
    raw = gzip.decompress(source.read_bytes())
    payload = json.loads(raw)
    c = payload['canonical']
    events = payload['programs']['forward']
    core = load('retained_center5_core', corepath)
    ce = load('retained_center5_clifford', ce_path)
    R = [[F(x) for x in row] for row in json.loads(rpath.read_text())]
    norms = json.loads(normpath.read_text())['ports']
    selected = [i for i, e in enumerate(events) if e[0] == 'center'][5]
    assert selected == 11401 and events[selected] == ['center', 0, 280, 0, 8]
    assert events[selected - 1] == ['scalar', ['copy', ['C', 0], ['L', 240]], 280]

    def apply(rows, event):
        if event[0] == 'scalar':
            s = event[1]
            dst = s[1][1] + (632 if s[1][0] == 'C' else 0)
            if s[0] == 'clear':
                rows[dst] = {}
            elif s[0] == 'copy':
                src = s[2][1] + (632 if s[2][0] == 'C' else 0)
                rows[dst] = dict(rows[src])
            elif s[0] == 'scale':
                rows[dst] = {k: v * F(s[2], s[3]) for k, v in rows[dst].items() if v * s[2]}
            elif s[0] == 'add':
                src = s[2][1] + (632 if s[2][0] == 'C' else 0)
                core.add(rows[dst], rows[src], F(s[3], s[4]))
            else:
                raise ValueError(event)
        elif event[0] == 'warp':
            rt = event[1]
            dst = rt[1] + (632 if rt[0] == 'C' else 0)
            rows[dst] = core.warp(rows[dst], event[2], False)
        elif event[0] not in ('phase', 'adapter', 'climb', 'center'):
            raise ValueError(event)

    rows = [core.identity(i) for i in range(632)] + [{}]
    for e in events[:selected]:
        apply(rows, e)
    capture = rows[632]
    assert all(not word for owner, word in capture)
    assert all(capture.get((i, ()), F(0)) == R[5][i] for i in range(112))
    assert all(not capture.get((i, ()), F(0)) for i in range(112, 224))
    helper = {i: value for (i, word), value in capture.items() if i >= 224}
    assert all(c['frames'][c['start'][i]] == [] for i in helper)

    # One abstract incoming centre total, propagated through the entire
    # literal suffix. This includes the scalar Y mixer and native warps.
    impulse = [{} for _ in range(633)]
    impulse[632] = core.identity(0)
    for e in events[selected + 1:]:
        apply(impulse, e)
    response = {}
    for i, row in enumerate(impulse):
        assert all(owner == 0 and not word for owner, word in row)
        if row:
            response[i] = row[0, ()]
    assert set(response) <= set(range(112, 224))
    assert all(response.get(112 + i, F(0)) == R[5][i] / 4 for i in range(112))
    assert len(response) == 56

    def word_op(word):
        out = ce.ident(9)
        for e in word:
            if e[0] == 'P':
                op = ce.perm(9, e[1])
            elif e[0] == 'D':
                op = ce.diag(9, e[1], e[2])
            elif e[0] == 'X':
                op = ce.xgate(9, e[1])
            elif e[0] == 'phase':
                op = ce.Op(9, ce.identity(9), [('phase', e[1])])
            else:
                raise ValueError(e)
            out = out.then(op)
        return out

    F9 = ce.fourier(9)
    port_checks = []
    wrong_gauge_grades = Counter()
    for i in range(112):
        q = c['ports'][i]
        U = ce.canonical_frame(9, c['frames'][c['start'][i]])
        S = ce.canonical_frame(9, c['frames'][c['final'][112 + i]])
        K = word_op(norms[i]['K_word'])
        O = word_op(norms[i]['compiled_wrappers']['output_Y']['word'])
        # K_i X_e K_i^-1=-X_q at every source port.
        assert ce.apply(K.tab, (1, 0, 0)) == (q, 0, 2)
        # S F9^-1 = (-i) O^-1 K^-1 X_q Q_q^-1.
        post = ce.xgate(9, q).then(K.adjoint()).then(O.adjoint()).then(
            ce.Op(9, ce.identity(9), [('phase', 3)]))
        post_word, post_record = ce.monomial(post)
        candidate = ce.cgate(9, q, -1).then(post_word)
        actual = F9.adjoint().then(S)
        assert candidate.tab == actual.tab and candidate.zero_state() == actual.zero_state()
        actual_grade = ce.rank([x for x, z, phase in actual.tab[9:]])
        assert actual_grade == 1
        wrong = F9.adjoint().then(U).then(S)
        wrong_grade = ce.rank([x for x, z, phase in wrong.tab[9:]])
        wrong_gauge_grades[wrong_grade] += 1
        if R[5][i]:
            port_checks.append({'port': i, 'R5': str(R[5][i]), 'q': q,
                                'Y_final_frame': c['final'][112 + i],
                                'Y_final_frame_basis': c['frames'][c['final'][112 + i]],
                                'bare_head_rank': actual_grade,
                                'post_monomial': post_record,
                                'post_monomial_word': post_word.circuit})
    assert wrong_gauge_grades == {2: 112}
    assert all(c['frames'][c['final'][i]] == c['frames'][1] for i in range(112))

    # All newly introduced helper compensation is at the actual ground
    # entrance. The changed word acts identically on logical Y and H, so
    # nilpotence gives the exact all-column corrected endpoint.
    invoice = Counter({int(k): int(v) for k, v in c['local_profile'].items()})
    invoice[8] -= 1
    out = {'schema': 'actual-center5-retained-full-X-suffix/v1',
           'source_pins': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest()
                           for p in (source, corepath, rpath, ce_path, normpath)},
           'decompressed_source_sha256': sha256(raw).hexdigest(),
           'selected_center_event': selected, 'selected_event': events[selected],
           'copy_source_owner': 240, 'R_row': 5,
           'capture': {'formula': 'R5 X + S5 H', 'X_terms': 56,
                       'helper_terms': [[i, str(v)] for i, v in sorted(helper.items())],
                       'all_helper_sources_start_in_ground_chart': True},
           'complete_suffix_impulse': {'all_native_words_empty': True,
                                       'original_input_columns': 632,
                                       'X_and_H_responses_zero': True,
                                       'Y_response': [[i, str(v)] for i, v in sorted(response.items())],
                                       'formula': '(1/4) R5^T times the incoming center total'},
           'partial_center_producer': {'change': 'Replace event11401 by CLEAR(C0) in destination frame0.',
                                      'ground_helper_precompensation': 't_H=sum S5_h H_h; Y_i+=(R5_i/4)t_H; clear owned t_H.',
                                      'ground_helper_precompensation_ADDs': len(helper) + len(response),
                                      'owned_helper_compensation_fields': 1,
                                      'endpoint': 'X unchanged; Y -> Y + (I-R5^T R5/4)X; every H autonomous unchanged logically.',
                                      'paid_profile': dict(sorted(invoice.items())),
                                      'helper_profile_unchanged': {'4': 28, '7': 7, '8': 47, '9': 326},
                                      'mode_Gram': 56,
                                      'code_eigenvalue_on_mode': -13},
           'active_suffix_cache': {'birth': 'After the complete changed native word, all112 raw X outputs are F9 X_i.',
                                   'value': 't_F=sum R5_i raw_X_i = F9 (R5 X)',
                                   'owned_fields': 1, 'scalar_ADDs': 56,
                                   'new_queries_for_cache_birth': 0,
                                   'original_helpers_not_copied_or_erased': True},
           'actual_Y_repair': {'required_output_i': '(R5_i/4) S_i F9^-1 t_F',
                               'factorization': 'S_i F9^-1 = [(-i) O_i^-1 K_i^-1 X_qi] Q_qi^-1, with O_i=D K_i^-1 S_i^-1 monomial.',
                               'all_ports_tableau_and_absolute_phase_checked': 112,
                               'active_ports': port_checks,
                               'uniform_width_phase': '(-i)^m; scalar R5_i/4 is applied once outside tensor powers.',
                               'direct_scatter_rank1_queries': 56,
                               'center_query_saved_rank': 8,
                               'two_head_entrance_formula_admitted_here': False,
                               'entrance_to_exit_wrong_gauge_grade_counts': dict(wrong_gauge_grades)},
           'proof_scope': 'Exact source-specific partial producer and active clean mode; shared-input scatter optimization remains open. No two-query repair, new supplier, or kappa increase is claimed.'}
    (HERE / 'CENTER5-SUFFIX.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps({k: v for k, v in out.items() if k not in ('source_pins', 'actual_Y_repair')}, indent=2))
    print(json.dumps({k: v for k, v in out['actual_Y_repair'].items() if k != 'active_ports'}, indent=2))


if __name__ == '__main__':
    main()
