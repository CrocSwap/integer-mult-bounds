#!/usr/bin/env python3
"""Exact chronological cache-placement synthesis for one deleted FULL code.

All six original banks remain arbitrary. A cache reads P_s times a main row
before the changed FULL and adds it to a later main row. Here P_s=C_s-I;
its factorization uses the literal eight owned mode temporaries. Every
other FULL is the ordinary source. There is no nonlinear approximation:
all cache births precede the sole changed source, and every insertion
follows it. Thus the endpoint correction is exactly linear in P_s.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import json
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
N = 6
ZERO_D = (0,) * 7
ONE = {(0, ZERO_D): F(1)}


def poly_add(*terms):
    z = defaultdict(F)
    for t in terms:
        for k, v in t.items():
            z[k] += v
    return {k: v for k, v in z.items() if v}


def poly_scale(t, c):
    return {k: v * c for k, v in t.items() if v * c}


def poly_mul(a, b):
    z = defaultdict(F)
    for (q, d), v in a.items():
        for (r, e), w in b.items():
            z[((q + r) % 4, tuple((x + y) % 4 for x, y in zip(d, e)))] += v * w
    return {k: v for k, v in z.items() if v}


def scalar(c):
    return {(0, ZERO_D): F(c)} if c else {}


def mono(q=0, stages=(), coefficient=1):
    d = list(ZERO_D)
    for s in stages:
        d[s] += 1
    return {(q % 4, tuple(d)): F(coefficient)}


def identity():
    return [[dict(ONE) if i == j else {} for j in range(N)] for i in range(N)]


def matrix_mul(a, b):
    return [[poly_add(*(poly_mul(a[i][k], b[k][j]) for k in range(N)))
             for j in range(N)] for i in range(N)]


def source_matrices(src):
    matrices = []
    for e in src['physical_events']:
        g = identity()
        if e[0] == 'LOCAL':
            _, stage, pair, back = e
            x, y = 2 * pair, 2 * pair + 1
            g[x][x] = g[y][y] = mono(stages=[stage])
            if back:
                g[x][y] = mono(q=1, stages=[stage], coefficient=-1)
            else:
                g[y][x] = mono(q=-1, stages=[stage])
        elif e[0] == 'IDLE':
            _, pair, stages = e
            g[2 * pair][2 * pair] = g[2 * pair + 1][2 * pair + 1] = mono(stages=stages)
        elif e[0] == 'ADD':
            g[e[1]][e[2]] = scalar(e[3])
        elif e[0] == 'SIGNED_SWAP':
            _, x, y = e
            g[x][x] = g[y][y] = {}
            g[x][y] = dict(ONE)
            g[y][x] = scalar(-1)
        else:
            raise ValueError(e)
        matrices.append(g)
    prefix = [[[scalar(c) for c in row] for row in src['right']]]
    for g in matrices:
        prefix.append(matrix_mul(g, prefix[-1]))
    left = [[scalar(c) for c in row] for row in src['left']]
    suffix = [None] * (len(matrices) + 1)
    suffix[-1] = left
    for i in range(len(matrices) - 1, -1, -1):
        suffix[i] = matrix_mul(suffix[i + 1], matrices[i])
    endpoint = matrix_mul(left, prefix[-1])
    for i, target in enumerate(src['exact_diagonal_monomials']):
        for j in range(N):
            expected = mono(q=target[0], stages=[s for s in range(7) if target[s + 1]]) if i == j else {}
            assert endpoint[i][j] == expected
    return matrices, prefix, suffix


def p_outer(left_column, right_row, stage, qleft=0, qright=0, dleft=ZERO_D, coefficient=1):
    """Canonical Q^a P_s Q^b D^d, using D_s P_s=Q^-1 P_s Q D_s."""
    out = defaultdict(F)
    for i, lpoly in enumerate(left_column):
        for j, rpoly in enumerate(right_row):
            for (ql, dl), cl in lpoly.items():
                dd = tuple((a + b) % 4 for a, b in zip(dl, dleft))
                for (qr, dr), cr in rpoly.items():
                    key = i, j, (ql + qleft - dd[stage]) % 4, (qr + qright + dd[stage]) % 4, tuple((a + b) % 4 for a, b in zip(dd, dr))
                    out[key] += coefficient * cl * cr
    return {k: v for k, v in out.items() if v}


def subtract_scaled(v, w, c):
    for k, z in w.items():
        a = v.get(k, F(0)) - c * z
        if a:
            v[k] = a
        elif k in v:
            del v[k]


def synthesize(stage, events, prefix, suffix, allow_even_heads=True, end_cut=None, central_sector=None):
    changed = next(i for i, e in enumerate(events) if e[0] == 'LOCAL' and e[1] == stage)
    back = events[changed][3]
    x = 2 * events[changed][2]
    dst, src = (x, x + 1) if back else (x + 1, x)
    if end_cut is None:
        active_suffix = suffix
        stop = len(events)
    else:
        stop = end_cut
        active_suffix = [None] * (stop + 1)
        active_suffix[stop] = identity()
        matrices, _, _ = source_matrices(FORMAL)
        for cut in range(stop - 1, -1, -1):
            active_suffix[cut] = matrix_mul(active_suffix[cut + 1], matrices[cut])
    delta_d = list(ZERO_D)
    delta_d[stage] = 1
    def sector_reduce(vector):
        if central_sector is None:
            return vector
        # These seven involutions are central in the one-P_s algebra:
        # T_s=Q^2 D_s^2 and T_t=D_t^2 for t!=s. Their +/- eigenspace
        # projectors are finite scalar/monomial circuits. On T=epsilon,
        # replace D_s^2 by epsilon_s Q^2, always on P_s's right.
        out = defaultdict(F)
        for (i, j, ql, qr, d), c in vector.items():
            factor = 1
            for t, e in enumerate(central_sector):
                factor *= e ** (d[t] // 2)
            key = i, j, ql, (qr + 2 * (d[stage] // 2)) % 4, tuple(v % 2 for v in d)
            out[key] += c * factor
        return {k: v for k, v in out.items() if v}

    error = sector_reduce(p_outer([row[dst] for row in active_suffix[changed + 1]], prefix[changed][src], stage,
                    qleft=1 if back else 0, qright=0 if back else -1,
                    dleft=tuple(delta_d), coefficient=-1 if back else 1))
    goal = {k: -v for k, v in error.items()}
    residual = dict(goal)
    basis = {}
    columns = []
    solution = {}
    tested = 0
    # Later births / earlier insertions reduce owned-cache lifetime.
    for birth in range(changed, -1, -1):
        for injection in range(changed + 1, stop + 1):
            for read_bank in range(N):
                for write_bank in range(N):
                    for lh in ((0, 2) if allow_even_heads else (0,)):
                        for rh in ((0, 2) if allow_even_heads else (0,)):
                            desc = (birth, read_bank, injection, write_bank, lh, rh)
                            candidate = sector_reduce(p_outer([row[write_bank] for row in active_suffix[injection]],
                                                prefix[birth][read_bank], stage, qleft=lh, qright=rh))
                            tested += 1
                            reduced = dict(candidate)
                            combination = {len(columns): F(1)}
                            while reduced:
                                pivot = min(reduced)
                                if pivot not in basis:
                                    c = reduced[pivot]
                                    reduced = {k: v / c for k, v in reduced.items()}
                                    combination = {k: v / c for k, v in combination.items()}
                                    basis[pivot] = reduced, combination
                                    columns.append((desc, candidate))
                                    break
                                vector, recipe = basis[pivot]
                                c = reduced[pivot]
                                subtract_scaled(reduced, vector, c)
                                subtract_scaled(combination, recipe, c)
                            if not reduced:
                                continue
                            # The target can now gain a new pivot only at the
                            # one just introduced, but full reduction is cheap.
                            while residual and min(residual) in basis:
                                pivot = min(residual)
                                vector, recipe = basis[pivot]
                                c = residual[pivot]
                                subtract_scaled(residual, vector, c)
                                for k, v in recipe.items():
                                    z = solution.get(k, F(0)) + c * v
                                    if z:
                                        solution[k] = z
                                    elif k in solution:
                                        del solution[k]
                            if not residual:
                                verify = dict(error)
                                recipe_out = []
                                for k, coef in sorted(solution.items()):
                                    desc, vector = columns[k]
                                    subtract_scaled(verify, vector, -coef)
                                    recipe_out.append({'birth_cut': desc[0], 'read_bank': desc[1],
                                                       'injection_cut': desc[2], 'write_bank': desc[3],
                                                       'left_Q_power': desc[4], 'right_Q_power': desc[5],
                                                       'coefficient': str(coef)})
                                assert not verify
                                return {'stage': stage, 'orientation': 'backward' if back else 'forward',
                                        'changed_event': changed, 'end_cut': stop, 'central_sector': central_sector,
                                        'complete_state_restored': True, 'candidates_tested': tested,
                                        'basis_rank': len(basis), 'recipe': recipe_out,
                                        'owned_cache_groups': len({(r['birth_cut'], r['read_bank'], r['right_Q_power']) for r in recipe_out}),
                                        'additional_paid_queries': 0, 'full_original_columns_checked': N}
    return {'stage': stage, 'orientation': 'backward' if back else 'forward',
            'changed_event': changed, 'end_cut': stop, 'central_sector': central_sector,
            'complete_state_restored': False, 'candidates_tested': tested,
            'basis_rank': len(basis), 'unreduced_target_terms': len(residual),
            'first_unreduced_term': str(min(residual)) if residual else None,
            'scope': 'This exact finite cache-placement family only; not all active caches or source redesigns.'}


def main():
    global FORMAL
    ap = argparse.ArgumentParser()
    ap.add_argument('--stages', default='0,1,2,3,4,5,6')
    ap.add_argument('--window', action='store_true')
    ap.add_argument('--central-sector', type=int)
    args = ap.parse_args()
    source = ROOT / 'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    FORMAL = json.loads(source.read_text())['selected_p3_keep43']
    _, prefix, suffix = source_matrices(FORMAL)
    events = FORMAL['physical_events']
    start = time.monotonic()
    results = []
    for stage in map(int, args.stages.split(',')):
        event = next(i for i, e in enumerate(events) if e[0] == 'LOCAL' and e[1] == stage)
        end_cut = next((i for i in range(event + 1, len(events)) if events[i][0] == 'LOCAL'), len(events)) if args.window else None
        sector = tuple(-1 if args.central_sector >> t & 1 else 1 for t in range(7)) if args.central_sector is not None else None
        result = synthesize(stage, events, prefix, suffix, end_cut=end_cut, central_sector=sector)
        result['elapsed_seconds'] = round(time.monotonic() - start, 3)
        print(json.dumps(result), flush=True)
        results.append(result)
        out = {'schema': 'actual-p3-chronological-active-cache/v1',
               'source_sha256': sha256(source.read_bytes()).hexdigest(),
               'cache': 'Eight owned mode fields implementing P_s=C_s-I=-K_s^-1 R^T R K_s/4; all births precede the changed FULL and all injections follow it.',
               'free_even_head_powers': [0, 2],
               'all_original_main_banks_arbitrary': True,
               'other_FULL_sources': 'Ordinary full source, unchanged helper autonomy and query invoice.',
               'results': results}
        stem = 'ACTIVE-CACHE-WINDOW' if args.window else 'ACTIVE-CACHE-GLOBAL'
        if args.central_sector is not None:
            stem += '-SECTOR-' + str(args.central_sector)
        (HERE / (stem + '.json')).write_text(json.dumps(out, indent=2) + '\n')


if __name__ == '__main__':
    main()
