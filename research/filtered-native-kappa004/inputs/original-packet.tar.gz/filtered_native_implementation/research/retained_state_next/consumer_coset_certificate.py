#!/usr/bin/env python3
"""Lift the actual scalar snapshot invariant to ordinary Clifford recodings.

The canonical full frame is unique.  All actual logical permutation labels
occupy distinct left cosets of F^-1 Mon F.  Consequently a finite bitwise
Clifford recoding cannot use a different permutation label to cancel an
independent helper column.  The scalar snapshot invariant therefore holds
coefficient by coefficient in that larger ordinary-operator family.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]


def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m


def mv(cols,x):
    out=0
    while x:
        b=x&-x;out^=cols[b.bit_length()-1];x^=b
    return out


def mul(a,b):return tuple(mv(a,x) for x in b)


def main():
    cp=HERE/'CONSUMER-FULL-FRAME-CACHE.json';cache=json.loads(cp.read_text())
    sp=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw=sp.read_bytes();source=json.loads(gzip.decompress(raw));c=source['canonical']
    assert sha256(raw).hexdigest()==cache['source_sha256']
    ce=load('consumer_coset_ce',ROOT/'upstream/research/coded-native-caller/clifford_exact.py')
    ident=tuple(1<<i for i in range(9));maps={ident:0}
    maps.update({tuple(x['G_columns']):x['op'] for x in c['warps']})
    labels=sorted(maps);inverse=lambda g:ce.transpose(ce.inv(ce.transpose(g,9),9),9)
    invs={g:inverse(g) for g in labels};F=ce.fourier(9);pairs=[];census=Counter()
    for i,a in enumerate(labels):
        for b in labels[:i]:
            g=mul(a,invs[b]);git=ce.transpose(inverse(g),9)
            bcols=tuple(x^y for x,y in zip(g,git));rank=ce.rank(bcols)
            # Check the physical symplectic expression, not an assumed H/C
            # identification.  F is the source C-Gaussian transform.
            op=F.adjoint().then(ce.perm(9,ce.transpose(g,9))).then(F)
            actual=tuple(x for x,z,p in op.tab[9:])
            assert actual==bcols and rank>0
            census[rank]+=1;pairs.append({'first_label':maps[a],'second_label':maps[b],
                'relative_columns':list(g),'physical_B_columns':list(bcols),'rank':rank})
    for result in cache['results']:
        spaces=result['arbitrary_clean_scalar_main_modes']
        assert spaces['X_and_Y']['intersection_dimension_upper_bound']==112
        assert spaces['Y']['intersection_dimension_upper_bound']==0
        if result['direction']=='backward':assert spaces['X']['intersection_dimension_upper_bound']==0
    out={'schema':'native-full-frame-Clifford-coset-invariant/v1',
      'source_sha256':sha256(raw).hexdigest(),'snapshot_receipt_sha256':sha256(cp.read_bytes()).hexdigest(),
      'actual_distinct_permutations':len(labels),'all_relative_pairs':len(pairs),
      'relative_physical_rank_census':dict(sorted(census.items())),
      'zero_rank_relative_pairs':0,'rank_one_relative_pairs':0,
      'logical_permutation_columns':{str(label):list(g) for g,label in maps.items()},
      'pairwise_exact_symplectic_checks':pairs,
      'coefficient_group':'H=F^-1 Mon F, where Mon is the ordinary Clifford monomial group on the current native axes and any fixed additional stage axes. Conjugate F for the raw-dual orientation.',
      'coset_identity':'H G_i and H G_j intersect iff F G_i G_j^-1 F^-1 is monomial. Its Gaussian B-block is G_i G_j^-1+(G_i G_j^-1)^-T. Every distinct actual pair has positive rank.',
      'additional_axes_argument':'Embedding G_i and F as identity on extra axes preserves this positive B rank; allowing Clifford monomials that mix those extra axes does not change membership of the fixed relative operator in Mon.',
      'tensor_independence_lemma':'For any finite set of distinct projective unitary operators U_i, normalized Hilbert-Schmidt inner products have absolute value below1 off the diagonal. At sufficiently large tensor width, the Gram matrix of their tensor powers is strictly diagonally dominant and therefore invertible. Choose widths divisible by4 to identify harmless global fourth-root phases. The finite bitwise Clifford group gives a common finite set even if the scalar coefficients depend on width.',
      'module_argument':'Expand every ordinary coefficient as a scalar combination of bitwise Clifford monomials. In a vanishing sum of H G_i terms, the distinct cosets prevent any cross-i collision; within each coset each H coefficient separates at a sufficiently large width. For the identity-label target, the same scalar snapshot equations must therefore hold separately for every H coefficient.',
      'clean_main_module':{
        'forward':'Every helper-free main functional is a sum of ordinary operators applied to the112 pure X outputs.',
        'backward':'Every helper-free main functional is a sum of ordinary operators applied to the112 X_i-Y_i outputs. The X and Y coefficient operators are negatives of each other.',
        'pure_backward_X_or_Y':'Only the zero functional is recoverable from these full-frame snapshots in this coefficient family.'},
      'cross_stage_transport_consequence':'P0 D1*x0 is a pure transformed consumer-X functional. Its actual cross-stage K0_i K1_i^-1 wrappers are bitwise ordinary Cliffords, so no combination of only the backward FULL full-frame snapshots supplies it for all widths.',
      'scope':'All actual full-frame snapshots, arbitrary scalar linear combinations of bitwise ordinary Clifford recodings, and any fixed additional stage axes. Does not cover new paid queries, snapshots in different Gaussian frames, changed native gates, column-mixing Bell charts, or arbitrary non-Clifford ordinary address circuits.',
      'new_kappa_claimed':False}
    (HERE/'CONSUMER-COSET-CERTIFICATE.json').write_text(json.dumps(out,indent=2)+'\n')
    print('COSET_CERTIFICATE',len(labels),len(pairs),dict(census),flush=True)


if __name__=='__main__':main()
