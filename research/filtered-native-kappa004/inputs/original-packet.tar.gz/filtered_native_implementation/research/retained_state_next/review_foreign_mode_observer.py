#!/usr/bin/env python3
"""Independent source and phase review of the foreign-mode observer.

No constructor or evaluator from cross_stage_rank1_observer is imported.
K is rebuilt from G_rows/Z_mask; actual input and output wrappers, all
frame phases, emitted ordinary routes, and the noncommuting odd head are
checked separately.  No caller repair or kappa improvement is inferred.
"""
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip
import json
import time

import consumer_kg_module as kg
from review_kg_full_frame_kernel import conjugate

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
RECEIPT=ROOT/'research/operator_alignment_next/CROSS-STAGE-RANK1-OBSERVER.json'
NATIVE=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
NORMAL=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
RP=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'


def read_word(ce,n,word):
    result=ce.ident(n)
    for gate in word:
        if gate[0]=='D':op=ce.diag(n,gate[1],gate[2])
        elif gate[0]=='P':op=ce.perm(n,gate[1])
        elif gate[0]=='X':op=ce.xgate(n,gate[1])
        elif gate[0]=='C':op=ce.cgate(n,gate[1],gate[2])
        else:
            assert gate[0]=='phase'
            op=ce.Op(n,ce.identity(n),[('phase',gate[1])])
        result=result.then(op)
    return result


def embed_tableau(ce,operator,axes,n=17):
    def mask(value):return sum(((value>>i)&1)<<a for i,a in enumerate(axes))
    output=list(ce.identity(n))
    for i,a in enumerate(axes):
        x,z,p=operator.tab[i];output[a]=(mask(x),mask(z),p)
        x,z,p=operator.tab[operator.n+i];output[n+a]=(mask(x),mask(z),p)
    return ce.Op(n,tuple(output),[])


def monomial_address(ce,n,word,address):
    phase=0
    for gate in word:
        if gate[0]=='P':address=ce.mv(gate[1],address)
        elif gate[0]=='D':phase+=ce.qvalue(gate[1],gate[2],address,n)
        elif gate[0]=='X':address^=gate[1]
        else:
            assert gate[0]=='phase'
            phase+=gate[1]
    return address,phase%4


def extract(address,axes):return sum(((address>>a)&1)<<i for i,a in enumerate(axes))


def replace(address,axes,value):
    for i,a in enumerate(axes):
        address=(address&~(1<<a))|(((value>>i)&1)<<a)
    return address


def main():
    begin=time.monotonic();receipt=json.loads(RECEIPT.read_text())
    native=json.loads(gzip.decompress(NATIVE.read_bytes()));c=native['canonical']
    ports=json.loads(NORMAL.read_text())['ports'];R=[[Q(a) for a in r] for r in json.loads(RP.read_text())]
    for field,path in [('source_sha256',NATIVE),('normalizers_sha256',NORMAL),('R_sha256',RP)]:
        assert receipt[field]==sha256(path.read_bytes()).hexdigest()
    ce=kg.load('foreign_independent_review_ce',kg.CLIFFORD)
    old=list(range(9));now=[0]+list(range(9,17));D9=ce.fourier(9,range(1,9))
    D=ce.fourier(17,range(9,17));head=ce.cgate(17,1)
    phase_points=[0]+[1<<i for i in range(17)]+[(1<<i)|(1<<j) for i in range(17) for j in range(i+1,17)]
    assert len(phase_points)==154
    controls=0;route_checks=0;details=[]
    for i,(port,route) in enumerate(zip(ports,receipt['routes'])):
        assert route['port']==i and route['owner']==112+i
        K=ce.perm(9,tuple(port['G_rows'])).then(ce.diag(9,(0,)*9,tuple(2*((port['Z_mask']>>j)&1) for j in range(9))))
        inp=read_word(ce,9,port['compiled_wrappers']['backward_input_Y']['word'])
        out=read_word(ce,9,port['compiled_wrappers']['backward_output_Y']['word'])
        assert inp.tab==K.tab and inp.zero_state()==K.zero_state()
        assert ce.rank([x for x,z,p in out.tab[9:]])==0
        f=c['final'][112+i];partial=conjugate(ce,ce.canonical_frame(9,c['frames'][f]))
        lhs=inp.then(partial).then(out)
        assert lhs.tab==D9.tab and lhs.zero_state()==D9.zero_state()
        # The physical identity with arbitrary native logical input is
        # out * barS = D9 * K^-1, including absolute phase.
        literal=partial.then(out);expected=K.adjoint().then(D9)
        assert literal.tab==expected.tab and literal.zero_state()==expected.zero_state()
        K0=embed_tableau(ce,K,old);K1=embed_tableau(ce,K,now)
        B1=embed_tableau(ce,out,now);S1=embed_tableau(ce,partial,now)
        assert K0.then(D).tab==D.then(K0).tab
        actual_route=read_word(ce,17,route['ordinary_gather_word'])
        assert ce.rank([x for x,z,p in actual_route.tab[17:]])==0
        assert actual_route.tab==B1.then(K0).tab
        target=K1.adjoint().then(K0).then(D)
        assert S1.then(actual_route).tab==target.tab
        for sign in (-1,1):
            H=ce.cgate(17,1,sign)
            assert S1.then(actual_route).then(H).tab==target.then(H).tab
        # Complete affine and Z4 quadratic phase certificate for the
        # emitted ordinary17-axis route.  An affine map is fixed by0 and
        # the basis; a quadratic phase by0, basis and pair sums.
        for address in phase_points:
            local=extract(address,now)
            local,phase=monomial_address(ce,9,out.circuit,local)
            expected_address=replace(address,now,local)
            local=extract(expected_address,old)
            local,phase2=monomial_address(ce,9,K.circuit,local)
            expected_address=replace(expected_address,old,local)
            assert monomial_address(ce,17,route['ordinary_gather_word'],address)==(expected_address,(phase+phase2)%4)
            route_checks+=1
        assert route['mode_coefficients']==[int(r[i]) for r in R]
        plain=ce.perm(9,tuple(port['G_rows']))
        wrong=plain.adjoint().then(D9)
        if literal.tab!=wrong.tab or literal.zero_state()!=wrong.zero_state():controls+=1
        details.append({'port':i,'actual_backward_input_equals_K':True,
                        'input_frame_output_equals_D_exactly':True,
                        'physical_route_phase_basis_checks':len(phase_points)})
    assert len(details)==112 and controls==112
    for k,r in enumerate(R):
        mode=receipt['modes'][k]
        assert mode['active_ports']==[i for i,a in enumerate(r) if a]
        assert len(mode['ordinary_schedule'])==57
        for event in mode['ordinary_schedule'][1:]:
            i=event['ordinary_route_port'];assert event['coefficient']==r[i]
            assert event['source_original_owner']==112+i
        assert sum(a*a for a in r)==56
    diagonal=next(i for i,a in enumerate(R[5]) if a)
    p=ports[diagonal]
    K=ce.perm(9,tuple(p['G_rows'])).then(ce.diag(9,(0,)*9,tuple(2*((p['Z_mask']>>j)&1) for j in range(9))))
    q=ce.cgate(9,1);dressed=K.then(q).then(K.adjoint())
    assert dressed.zero_state()!=q.zero_state()
    result={'schema':'independent-foreign-mode-observer-review/v1','status':'PASS',
            'reviewed_receipt_sha256':sha256(RECEIPT.read_bytes()).hexdigest(),
            'original_source_sha256':sha256(NATIVE.read_bytes()).hexdigest(),
            'normalizers_sha256':sha256(NORMAL.read_bytes()).hexdigest(),
            'all112_actual_backward_input_Y_wrappers_verified':True,
            'all112_literal_exit_tableau_and_absolute_phases_verified':True,
            'all112_17_axis_routes_verified':True,
            'emitted_route_affine_quadratic_phase_points':route_checks,
            'omitted_Z_phase_negative_controls':controls,
            'all8_source_R_mode_gathers_verified':True,
            'odd_head_order_negative_control_port':diagonal,
            'literal_identity':'K0_i BY1_i barS1_i = D1 K0_i K1_i^-1; actual input_Y=K1_i.',
            'normalized_identity':'Gather gives D1 sum_i r_i K0_i y_i. Optional one paid Q_mode or Q_mode^-1 acts on this shared coefficient field. Scatter gives J0^± D1, J0^±=diag(K0^-1) r^T Q_mode^± r diag(K0)/4.',
            'target_limit':'J0^± is not Q^± P0 or P0 Q^±. The no-query gather/scatter is already −P0 D1 on the existing Y output. The paid head produces a different operator but does not establish a caller repair.',
            'all632_originals_retained':'The observer only reads current original Y values into declared owned accumulation fields; it neither resets nor overwrites any native X,Y,H. The base source endpoint remains governed by its own separate replay.',
            'query_invoice_per_mode':{'rank1':1,'owned_accumulators':1,'optional_mapping_scratch':1,'gather_adds':56,'scatter_adds':56},
            'scope':'Independent review of the stated literal observation and normalized J operator only. No new native endpoint, center replacement, recursive target closure or kappa bound is claimed.',
            'ports':details,'seconds':time.monotonic()-begin}
    target_path=HERE/'FOREIGN-MODE-OBSERVER-INDEPENDENT-REVIEW.json'
    target_path.write_text(json.dumps(result,indent=2)+'\n')
    print('PASS',target_path,'seconds',result['seconds'],flush=True)


if __name__=='__main__':main()
