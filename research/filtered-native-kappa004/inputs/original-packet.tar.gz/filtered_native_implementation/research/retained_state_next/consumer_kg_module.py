#!/usr/bin/env python3
"""Constructive full-frame snapshot closure under actual phase-bearing K_G.

Left multiplication by every K_G word is ordinary in the literal full
frame.  Unit (single-monomial) owner pivots perform exact group-ring row
operations and retain an executable sum-of-recodings recovery recipe.
This is deliberately separate from the withdrawn plain-permutation coset
argument.  All 632 original columns remain independent.
"""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import argparse
import gzip
import importlib.util
import json
import pickle
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SOURCE=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
CLIFFORD=ROOT/'upstream/research/coded-native-caller/clifford_exact.py'


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
    spec.loader.exec_module(mod);return mod


def add(a,b,c):
    for k,v in b.items():
        z=a.get(k,Q(0))+c*v
        if z:a[k]=z
        else:a.pop(k,None)


class PhaseGroup:
    def __init__(self,ce,canonical,back):
        self.ce=ce;self.back=back;self.ops=[ce.ident(9)];self.ids={self.ops[0].tab:0}
        self.products={};self.inverses={0:0};self.letters={};self.word=[()]
        self.F=ce.fourier(9).adjoint() if back else ce.fourier(9)
        for w in canonical['warps']:
            G=ce.transpose(tuple(w['G_columns']),9);gi=ce.inv(G,9);cols=ce.transpose(gi,9)
            quadratic=tuple((1<<i)^sum(ce.parity(a&b)<<j for j,b in enumerate(cols))
                            for i,a in enumerate(cols))
            alpha=tuple(((-1 if back else 1)*((quadratic[i]>>i)&1))%4 for i in range(9))
            op=ce.perm(9,G).then(ce.diag(9,quadratic,alpha))
            assert op.zero_state()==self.ops[0].zero_state()
            self.letters[w['op']]=self.intern(op,(w['op'],))
            self.letters[-w['op']]=self.intern(op.adjoint(),(-w['op'],))

    def intern(self,operation,word):
        if operation.tab not in self.ids:
            # All generated operators fix |0> with phase1.  Thus tableau
            # equality also implies absolute-phase equality.
            assert all(x==0 for x,z,p in operation.tab[9:])
            physical=self.F.adjoint().then(operation).then(self.F)
            assert self.ce.rank([x for x,z,p in physical.tab[9:]])==0
            self.ids[operation.tab]=len(self.ops);self.ops.append(operation);self.word.append(word)
        return self.ids[operation.tab]

    def product(self,left,right):
        if not left:return right
        if not right:return left
        key=left,right
        if key not in self.products:
            self.products[key]=self.intern(self.ops[right].then(self.ops[left]),self.word[left]+self.word[right])
        return self.products[key]

    def inverse(self,g):
        if g not in self.inverses:
            value=self.intern(self.ops[g].adjoint(),tuple(-x for x in reversed(self.word[g])))
            self.inverses[g]=value;self.inverses[value]=g
        return self.inverses[g]

    def left(self,g,row):
        if not g:return dict(row)
        out={}
        for (owner,op),a in row.items():
            key=owner,self.product(g,op);v=out.get(key,Q(0))+a
            if v:out[key]=v
            else:out.pop(key,None)
        return out


class UnitModule:
    def __init__(self,group):
        self.group=group;self.pivots=[];self.pivot_owners=set();self.pending=[]
        self.snapshot_rows=[];self.snapshot_descriptions=[];self.zero_relations=0
        self.max_row_terms=0;self.max_recipe_terms=0;self.operations=0

    def reduce(self,row,recipe):
        for owner,basis,expression in self.pivots:
            coefficients=[(g,a) for (i,g),a in row.items() if i==owner]
            for g,a in coefficients:
                add(row,self.group.left(g,basis),-a)
                add(recipe,self.group.left(g,expression),-a)
                self.operations+=1
            assert not any(i==owner for i,g in row)
        return row,recipe

    def accept(self,row,recipe):
        row,recipe=self.reduce(row,recipe)
        if not row:self.zero_relations+=1;return False
        counts=Counter(i for i,g in row)
        candidates=[i for i,n in counts.items() if n==1]
        if not candidates:
            self.pending.append((row,recipe));return False
        # Helpers first generally expose clean main inputs most directly.
        owner=min(candidates,key=lambda i:(i<224,i))
        g,a=next((g,a) for (i,g),a in row.items() if i==owner)
        inv=self.group.inverse(g)
        row={k:v/a for k,v in self.group.left(inv,row).items()}
        recipe={k:v/a for k,v in self.group.left(inv,recipe).items()}
        assert row[owner,0]==1 and sum(i==owner for i,g in row)==1
        assert owner not in self.pivot_owners
        self.pivots.append((owner,row,recipe));self.pivot_owners.add(owner)
        self.max_row_terms=max(self.max_row_terms,len(row));self.max_recipe_terms=max(self.max_recipe_terms,len(recipe))
        return True

    def insert(self,row,description):
        sid=len(self.snapshot_rows);self.snapshot_rows.append(dict(row));self.snapshot_descriptions.append(description)
        new=self.accept(dict(row),{(sid,0):Q(1)})
        while new and self.pending:
            pending=self.pending;self.pending=[];new=False
            for r,e in pending:new=self.accept(r,e) or new

    def solve(self,target):
        residual,neg=self.reduce(dict(target),{})
        recipe={k:-v for k,v in neg.items()}
        if not residual:
            check={}
            for (sid,g),a in recipe.items():add(check,self.group.left(g,self.snapshot_rows[sid]),a)
            assert check==target
        return residual,recipe


class ScalarSpan:
    def __init__(self):self.rows={}
    def insert(self,row):
        v=dict(row)
        while v:
            p=min(v)
            if p not in self.rows:
                a=v[p];self.rows[p]={k:b/a for k,b in v.items()};return True
            add(v,self.rows[p],-v[p])
        return False


def load_completed(path):
    """Restore the exact corrected basis for additional-observation probes."""
    data=pickle.loads(Path(path).read_bytes())
    ce=load('kg_module_restored_ce',CLIFFORD)
    group=PhaseGroup.__new__(PhaseGroup)
    group.ce=ce;group.back=data['direction']=='backward'
    group.F=ce.fourier(9).adjoint() if group.back else ce.fourier(9)
    group.ops=[ce.Op(9,record['tableau'],record['circuit']) for record in data['ops']]
    group.word=[record['word'] for record in data['ops']]
    group.ids={op.tab:i for i,op in enumerate(group.ops)}
    group.products={};group.inverses={0:0};group.letters={}
    # Distinct literal warp labels can have an identical phase-exact
    # tableau.  Their stored representative word need not be that label.
    raw=SOURCE.read_bytes()
    if 'original_source_sha256' in data:
        assert sha256(raw).hexdigest()==data['original_source_sha256']
    else:
        assert sha256(raw).hexdigest()==data['source_sha256']
    canonical=data.get('canonical',json.loads(gzip.decompress(raw))['canonical'])
    native=PhaseGroup(ce,canonical,group.back)
    for letter,i in native.letters.items():
        recovered=group.intern(native.ops[i],native.word[i])
        if 'letters' in data:assert data['letters'][letter]==recovered
        group.letters[letter]=recovered
    module=UnitModule(group)
    module.snapshot_rows=data['snapshots'];module.snapshot_descriptions=data['descriptions']
    module.pivots=data['pivots'];module.pivot_owners={i for i,_,_ in module.pivots}
    module.pending=data['pending']
    return group,module,data


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--direction',choices=('forward','backward'),default='backward')
    args=ap.parse_args();back=args.direction=='backward';began=time.monotonic()
    raw=SOURCE.read_bytes();source=json.loads(gzip.decompress(raw));c=source['canonical']
    ce=load('kg_module_ce',CLIFFORD);group=PhaseGroup(ce,c,back);module=UnitModule(group)
    rows=[{(i,0):Q(1)} for i in range(632)]+[{}];cur=c['start'][:]+[None]
    assert all(f!=1 for f in cur)
    paid=Counter();maxnorm=Q(1);scalar_span=ScalarSpan();raw_snapshots=0
    def observe(owner,pos):
        nonlocal raw_snapshots
        if cur[owner]==1 and rows[owner]:
            raw_snapshots+=1
            if scalar_span.insert(rows[owner]):
                module.insert(rows[owner],{'owner':owner,'after_event':pos,'frame':1})
    for pos,e in enumerate(source['programs'][args.direction]):
        typ=e[0];d=None
        if typ=='scalar':
            a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
            if a[0]=='clear':assert d==632;rows[d]={};cur[d]=f
            else:
                assert cur[d]==f
                if a[0] in ('add','copy'):
                    s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                    if a[0]=='copy':assert d==632;rows[d]=dict(rows[s])
                    else:add(rows[d],rows[s],Q(a[3],a[4]))
                else:
                    assert a[0]=='scale';rows[d]={k:v*Q(a[2],a[3]) for k,v in rows[d].items() if v*a[2]}
        elif typ=='warp':
            d=e[1][1]+(632 if e[1][0]=='C' else 0);assert cur[d]==e[3]
            rows[d]=group.left(group.letters[e[2]],rows[d]);cur[d]=e[4]
        elif typ=='climb':d=e[2];assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
        elif typ=='center':d=632+e[1];assert cur[d]==e[2];cur[d]=e[3];paid[e[4]]+=1
        else:assert typ in ('phase','adapter')
        if d is not None:
            maxnorm=max(maxnorm,sum(map(abs,rows[d].values()),Q(0)));observe(d,pos)
        if pos and pos%1000==0:
            print('PROGRESS',args.direction,pos,'snapshots',len(module.snapshot_rows),'pivots',len(module.pivots),
                  'pending',len(module.pending),'operators',len(group.ops),'seconds',round(time.monotonic()-began,2),flush=True)
    assert cur[:632]==c['final'] and not rows[632]
    for i in range(632):
        expected={(i,0):Q(1)}
        if back and i<112:expected[i+112,0]=Q(-1)
        if not back and 112<=i<224:expected[i-112,0]=Q(1)
        assert rows[i]==expected
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    R=[[Q(x) for x in r] for r in json.loads(rp.read_text())]
    tests=[];recoveries=[]
    for bank,offset in [('X',0),('Y',112)]:
        for k,r in enumerate(R):
            target={(i+offset,0):v for i,v in enumerate(r) if v}
            residual,recipe=module.solve(target)
            record={'bank':bank,'mode':k,'recovered':not residual,'residual_terms':len(residual),
                    'recipe_terms':len(recipe),'residual_sha256':sha256(repr(sorted(residual.items())).encode()).hexdigest()}
            if not residual:
                record['recipe']=[{'coefficient':str(a),'left_operator':g,
                    **module.snapshot_descriptions[sid]} for (sid,g),a in sorted(recipe.items())]
                recoveries.append((record,target,recipe))
            tests.append(record)
            print('TARGET',bank,k,'recovered',not residual,'residual',len(residual),'recipe',len(recipe),flush=True)
    individual=[]
    for i in range(224):
        residual,recipe=module.solve({(i,0):Q(1)})
        if not residual:individual.append(i)
    used=sorted({g for _,_,recipe in recoveries for (sid,g) in recipe})
    physical_words={}
    for g in used:
        operator=group.F.adjoint().then(group.ops[g]).then(group.F)
        lowered,record=ce.monomial(operator)
        assert lowered.tab==operator.tab and lowered.zero_state()==operator.zero_state()
        physical_words[str(g)]={'logical_warp_word':group.word[g],'physical_word':lowered.circuit,
                               'monomial':record,'tableau':operator.tab}
    result={'schema':'actual-KG-full-frame-unit-module/v1','direction':args.direction,
            'source_sha256':sha256(raw).hexdigest(),'R_sha256':sha256(rp.read_bytes()).hexdigest(),
            'clifford_source_sha256':sha256(CLIFFORD.read_bytes()).hexdigest(),
            'all_originals':632,'arbitrary_helpers':408,'native_paid_profile':dict(sorted(paid.items())),
            'native_normalized_prefix_l1':str(maxnorm),'full_frame_snapshots':raw_snapshots,
            'independent_scalar_snapshots':len(module.snapshot_rows),
            'monomial_unit_pivots':len(module.pivots),'pivot_originals':[i for i,_,_ in module.pivots],
            'nonunit_residual_rows':len(module.pending),'zero_relations':module.zero_relations,
            'generated_phase_exact_operators':len(group.ops),'elementary_module_eliminations':module.operations,
            'maximum_pivot_row_terms':module.max_row_terms,'maximum_pivot_recipe_terms':module.max_recipe_terms,
            'mode_tests':tests,'recovered_individual_main_originals':individual,
            'emitted_physical_recodings':physical_words,
            'new_paid_queries_for_recoveries':0,'seconds':time.monotonic()-began,
            'scope':'Constructive exact left-module operations by phase-correct native K_G words in the literal full frame. Every recovery is an exact rational sum of ordinary physical monomial recodings of chronologically retained snapshots; all original/helper columns are separate. No negative completeness claim if nonunit residual rows remain. A positive mode is an available cache, not independent new productive credit.'}
    path=HERE/('CONSUMER-KG-MODULE-'+args.direction.upper()+'.json');path.write_text(json.dumps(result,indent=2)+'\n')
    data={'source_sha256':sha256(raw).hexdigest(),'direction':args.direction,
          'ops':[{'tableau':op.tab,'circuit':op.circuit,'word':word} for op,word in zip(group.ops,group.word)],
          'snapshots':module.snapshot_rows,'descriptions':module.snapshot_descriptions,
          'pivots':module.pivots,'pending':module.pending,'R':R}
    (HERE/('CONSUMER-KG-MODULE-'+args.direction.upper()+'.pickle')).write_bytes(pickle.dumps(data,protocol=5))
    print('DONE',path,'seconds',result['seconds'],flush=True)


if __name__=='__main__':main()
