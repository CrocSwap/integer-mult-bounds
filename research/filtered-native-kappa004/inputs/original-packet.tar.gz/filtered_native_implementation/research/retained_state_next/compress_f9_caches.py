#!/usr/bin/env python3
"""Compress the all-eight-mode causal schedule's same-frame snapshots.

Only rational scalar combinations inside one actual physical frame are
used.  Selected basis snapshots are copied at their original birth, so
this does not invent a cache value or add a Gaussian query.
"""
from collections import Counter,defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    return m

def plus(dst,src,a):
    for k,v in src.items():
        z=dst.get(k,F(0))+a*v
        if z:dst[k]=z
        else:dst.pop(k,None)

class Basis:
    def __init__(self):self.rows={};self.selected=[]
    def add(self,v,slot):
        v=dict(v);used={}
        while v:
            k=min(v)
            if k not in self.rows:break
            a=v[k];row,expr=self.rows[k]
            plus(v,row,-a);plus(used,expr,a)
        if not v:return used
        k=min(v);a=v[k];expr={slot:1/a};plus(expr,used,-1/a)
        self.rows[k]=({j:x/a for j,x in v.items()},expr)
        self.selected.append(slot)
        return {slot:F(1)}

def main():
    original_path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    basepath=HERE/'F9-SOURCE-DAG-ALL8-SOURCEFIRST-WORD.json.gz'
    original_raw=original_path.read_bytes();original=json.loads(gzip.decompress(original_raw))
    base_raw=basepath.read_bytes();base=json.loads(gzip.decompress(base_raw));c=base['canonical'];fsym=base['normalized_F9_symbol']
    core=load('compress_f9_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    def idx(r):return r[1]+(632 if r[0]=='C'else 0)
    snaps=base['boundary_snapshots'];oldcount=len(snaps)
    assert sorted(x['slot'] for x in snaps)==list(range(1,oldcount+1))
    byevent=defaultdict(list)
    for x in snaps:byevent[x['source_event']].append(x)
    values={};rows=[core.identity(i) for i in range(632)]+[{}]
    for x in byevent[None]:values[x['slot']]=dict(rows[x['owner']])
    for k,e in enumerate(original['programs']['forward']):
        t=e[0]
        if t=='scalar':
            a=e[1];d=idx(a[1])
            if a[0]=='clear':rows[d]={}
            elif a[0]=='copy':rows[d]=dict(rows[idx(a[2])])
            elif a[0]=='add':core.add(rows[d],rows[idx(a[2])],F(a[3],a[4]))
            else:rows[d]={j:v*F(a[2],a[3]) for j,v in rows[d].items() if v*a[2]}
        elif t=='warp':d=idx(e[1]);rows[d]=core.warp(rows[d],e[2],False)
        for x in byevent[k]:values[x['slot']]=dict(rows[x['owner']])
    assert len(values)==oldcount
    bases=defaultdict(Basis);reconstruction={};selected=[]
    for x in sorted(snaps,key=lambda z:z['slot']):
        slot=x['slot'];before=len(bases[x['frame']].selected)
        reconstruction[slot]=bases[x['frame']].add(values[slot],slot)
        if len(bases[x['frame']].selected)>before:selected.append(slot)
    # Regenerate every input snapshot as a rational field identity, not a
    # modular rank heuristic or a numerical compression.
    for x in snaps:
        rebuilt={}
        for slot,a in reconstruction[x['slot']].items():plus(rebuilt,values[slot],a)
        assert rebuilt==values[x['slot']]
    mapping={old:1+i for i,old in enumerate(selected)};newcount=len(mapping)
    def mapped(r):
        if r[0]!='C' or r[1]==0:return r[:]
        s=r[1]
        if s<=oldcount:return ['C',mapping[s]]
        return ['C',newcount+s-oldcount]
    out=[];origins=[]
    for e,origin in zip(base['programs']['forward'],base['original_event_origins']):
        if e[0]!='scalar':
            ee=json.loads(json.dumps(e))
            if ee[0]=='physical_add':ee[1]=mapped(ee[1]);ee[2]=mapped(ee[2])
            out.append(ee);origins.append(origin);continue
        a,f=e[1:];dst=a[1]
        if dst[0]=='C' and 1<=dst[1]<=oldcount:
            assert a[0] in ('clear','copy')
            if dst[1] not in mapping:continue
        if a[0] in ('copy','add') and a[2][0]=='C' and 1<=a[2][1]<=oldcount:
            assert a[0]=='add','All eight obsolete center COPYs must be absent.'
            for slot,b in sorted(reconstruction[a[2][1]].items()):
                coef=F(a[3],a[4])*b
                out.append(['scalar',['add',mapped(dst),['C',mapping[slot]],coef.numerator,coef.denominator],f]);origins.append(origin)
            continue
        ee=json.loads(json.dumps(e));ee[1][1]=mapped(dst)
        if a[0] in ('copy','add'):ee[1][2]=mapped(a[2])
        out.append(ee);origins.append(origin)
    extra=newcount+8;nr=633+extra
    live=[core.identity(i) for i in range(632)]+[{} for _ in range(nr-632)]
    cur=c['start'][:]+[None for _ in range(nr-632)];paid=Counter();counts=Counter();scalar_counts=Counter();maxnorm=F(1)
    for pos,e in enumerate(out):
        t=e[0];counts[t]+=1
        if t=='scalar':
            a,f=e[1:];d=idx(a[1]);scalar_counts[a[0]]+=1
            if a[0]=='clear':assert d>=632;live[d]={};cur[d]=f
            else:
                assert cur[d]==f,(pos,e,cur[d])
                if a[0] in ('copy','add'):
                    s=idx(a[2]);assert cur[s]==f,(pos,e,cur[s])
                    if a[0]=='copy':assert d>=632;live[d]=dict(live[s])
                    else:core.add(live[d],live[s],F(a[3],a[4]))
                else:live[d]={j:v*F(a[2],a[3]) for j,v in live[d].items() if v*a[2]}
                maxnorm=max(maxnorm,sum(map(abs,live[d].values()),F(0)))
        elif t=='warp':d=idx(e[1]);assert cur[d]==e[3];live[d]=core.warp(live[d],e[2],False);cur[d]=e[4]
        elif t=='climb':d=e[2];assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
        elif t=='center':raise AssertionError('A removed center returned.')
        elif t=='physical_add':
            _,dt,st,a,b,df,sf,word=e;d=idx(dt);s=idx(st)
            assert not word and (df,sf)==(0,1) and cur[d]==df and cur[s]==sf
            assert live[s]==core.identity(s)
            core.add(live[d],{(o,(fsym,)+w):v for (o,w),v in live[s].items()},F(a,b))
        else:
            assert t in ('phase','adapter')
            if e==['phase','consume_retained_source_snapshots']:
                assert all(live[i]==core.identity(i) and cur[i]==1 for i in range(112))
                assert all(live[i]==core.identity(i) and cur[i]==0 for i in range(112,224))
    R=[[F(v) for v in row] for row in json.loads((ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json').read_text())]
    expected=[core.expected(i,False) for i in range(632)]+[{} for _ in range(nr-632)]
    for row in R:
        for i,ri in enumerate(row):
            if not ri:continue
            for j,rj in enumerate(row):
                if not rj:continue
                a=ri*rj/4;core.add(expected[112+i],{(j,(fsym,)):F(1)},a);core.add(expected[112+i],core.identity(j),-a)
    assert live==expected and cur[:632]==c['final'] and not any(live[632:])
    assert paid=={1:2201,2:412,3:510,4:127,5:40}
    blob={**base,'schema':'compressed-F9-source-DAG-pair/v1','program':out,
          'programs':{'forward':out,'backward':base['programs']['backward']},
          'original_event_origins':origins,'owned_extra_slots':extra,
          'owned_extra_slots_by_direction':{'forward':extra,'backward':8},
          'compression_original_boundary_snapshots':snaps,
          'boundary_snapshots':[{**x,'slot':mapping[x['slot']]} for x in snaps if x['slot'] in mapping],
          'compression_reconstructions':{str(s):[[mapping[j],str(a)] for j,a in sorted(v.items())] for s,v in reconstruction.items()},
          'compression_base_word_sha256':sha256(base_raw).hexdigest()}
    payload=json.dumps(blob,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(payload,mtime=0)
    (HERE/'F9-SOURCE-DAG-ALL8-COMPRESSED-WORD.json.gz').write_bytes(packed)
    l1s=[sum(map(abs,v.values()),F(0)) for v in reconstruction.values()]
    result={'schema':'same-frame-source-cache-compression/v1','base_word_sha256':sha256(base_raw).hexdigest(),
            'word_sha256':sha256(packed).hexdigest(),'word_payload_sha256':sha256(payload).hexdigest(),
            'arithmetic':'exact rational Gaussian elimination; all snapshot rows rebuilt exactly',
            'old_boundary_fields':oldcount,'new_boundary_fields':newcount,'old_total_extra_owned_fields':oldcount+8,
            'new_total_extra_owned_fields':extra,'ground_helper_mode_fields':8,
            'distinct_physical_frames':len(bases),'all_snapshot_reconstructions_checked':oldcount,
            'max_reconstruction_l1':str(max(l1s)),'max_reconstruction_terms':max(map(len,reconstruction.values())),
            'max_l1_normalized_program_row':str(maxnorm),'events':len(out),'opcode_census':dict(counts),
            'scalar_opcode_census':dict(scalar_counts),'paid_profile':dict(sorted(paid.items())),
            'full_late_Y_causal_ABI_retained':True,'all632_original_endpoints_checked':True,
            'all408_helpers_autonomous':True,'all_actual_frames_checked':True,'all_owned_final_zero':True,
            'backward_word_unchanged':True,'new_gaussian_queries':0,
            'status':'PASS_EXACT_SOURCE_CACHE_COMPRESSION; NO_CALLER_OR_KAPPA_CLAIM'}
    (HERE/'F9-SOURCE-DAG-ALL8-COMPRESSED.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
