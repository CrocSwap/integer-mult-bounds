#!/usr/bin/env python3
"""Actual center-free quotient and one-head local monomial alignment.

This is intentionally a one-monomial-per-input factorization screen, not
a lower bound for arbitrary linear combinations of monomial maps or for
multiple added observations.  Unlike the withdrawn plain-G screen, every
operator here contains the native quadratic phases and literal frames.
"""
from collections import Counter, defaultdict
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import json
import time

import consumer_kg_module as kg
from review_kg_full_frame_kernel import conjugate

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'CENTER-FREE-SNAPSHOT-MODULE.pickle'


def binary_basis(vectors):
    pivots={}
    for value in vectors:
        while value:
            p=value.bit_length()-1
            if p in pivots:value^=pivots[p]
            else:
                for j,row in list(pivots.items()):
                    if (row>>p)&1:pivots[j]^=value
                pivots[p]=value
                break
    return tuple(pivots[p] for p in sorted(pivots))


def main():
    begin=time.monotonic();group,module,data=kg.load_completed(SOURCE)
    ce=group.ce;c=data['canonical'];F=group.F
    assert all(i not in module.pivot_owners for i in range(112,224))
    assert not module.pending
    quotients=[];byframe=defaultdict(list)
    for index,(row,desc) in enumerate(zip(data['rank8_rows'],data['rank8_descriptions'])):
        # Unit elimination is an exact universal operator identity.  It
        # gives a legitimate input family with S=0 and all nonpivot
        # original fields independently arbitrary, not a scalar sample.
        residual,recipe=module.reduce(dict(row),{})
        record={'rank8_snapshot_index':index,**desc,
                'residual':[[i,g,str(a)] for (i,g),a in sorted(residual.items())]}
        quotients.append(record);byframe[desc['frame']].append(residual)
    for frame in range(142,254):
        assert len(byframe[frame])==3
        for residual in byframe[frame]:
            assert len(residual)==1
            assert next(iter(residual))==(112+frame-142,0)
    modes=[254,274,279,280,281,619,621,624]
    assert all(not row for frame in modes for row in byframe[frame])
    for frame in [284,285]:
        assert all(i>=224 and g==0 for row in byframe[frame] for i,g in row)
    assert set(byframe)==set(range(142,254))|set(modes)|{284,285}

    heads=[];records=[]
    for i in range(112):
        f=c['final'][112+i];assert f==142+i
        partial=conjugate(ce,ce.canonical_frame(9,c['frames'][f]))
        lift=partial.adjoint().then(F)
        assert ce.rank([x for x,z,p in lift.tab[9:]])==1
        lagrangian=binary_basis(x|(z<<9) for x,z,p in lift.tab[9:])
        heads.append((lift,lagrangian))
        records.append({'port':i,'frame':f,'rank':1,'lift_tableau':lift.tab,
                        'lift_circuit':lift.circuit,
                        'right_monomial_coset_lagrangian':lagrangian})
    assert len({signature for op,signature in heads})==112
    mode_results=[]
    for k,r in enumerate(data['R']):
        support=[i for i,a in enumerate(r) if a]
        assert len(support)==56
        signatures={heads[i][1] for i in support};assert len(signatures)==56
        mode_results.append({'mode':k,'support':support,'distinct_right_monomial_cosets':56,
                             'single_common_head_possible':False})
    # A compact exact control for the selected concrete mode.  Every
    # relative head is rank2; none is physically ordinary.
    s=mode_results[5]['support'];relative=Counter()
    for p,i in enumerate(s):
        for j in s[p+1:]:
            rel=heads[j][0].then(heads[i][0].adjoint())
            relative[ce.rank([x for x,z,phase in rel.tab[9:]])]+=1
    assert relative==Counter({2:1540})

    result={'schema':'center-free-local-one-head-monomial-alignment/v1',
            'status':'NO_SINGLE_COMMON_HEAD_IN_STATED_FAMILY',
            'source_module_sha256':sha256(SOURCE.read_bytes()).hexdigest(),
            'source_word_sha256':data['source_sha256'],
            'all632_original_columns_preserved':True,
            'unit_module_pivots':len(module.pivots),'nonunit_residual_rows':0,
            'arbitrary_free_Y_owners':list(range(112,224)),
            'other_free_originals':[i for i in range(632) if i not in module.pivot_owners and not 112<=i<224],
            'quotient_proof':'Choose all nonpivot originals arbitrarily and solve the 482 unit pivot equations backwards. Every actual full-frame snapshot is then zero. All112 Y fields remain independent arbitrary vectors. On this legitimate input family the336 Y-frame observations are scalar multiples of their own Y_i, the56 mode-frame observations vanish, and the24 other rank8 observations involve only helpers. Setting the38 free helpers tozero isolates all112 independent Y fields.',
            'factorization_proof':'Let T_i be the actual conjugated partial frame and U_i=barF T_i^-1. A single common paid operator H, a common output monomial N, and per-input monomials M_i would require U_i=N H M_i on each independent Y_i. Hence U_i^-1 U_j=M_i^-1 M_j is ordinary. Equivalently all U_i send the computational Z Lagrangian to one common Lagrangian. Their112 exact image Lagrangians are distinct, so no R mode with56 ports has such a factorization. Full-frame snapshots vanish on this input family and cannot alter the necessary equation.',
            'rank8_quotients':quotients,'heads':records,'modes':mode_results,
            'mode5_relative_lift_rank_census':dict(sorted(relative.items())),
            'scope':'Only local pure R_k Y in the full barF chart, the actual ALL8 scalar-center-free word, its full-frame snapshots and rank8 observations, one common query path, and one monomial physical recoding per contributing independent observation. This does not exclude sums of multiple monomial recodings, multiple query paths, other frames, changed native contacts, or cross-stage targets with nonidentity owner-dependent K coefficients.',
            'seconds':time.monotonic()-begin}
    out=HERE/'LOCAL-RANK1-HEAD-ALIGNMENT.json';out.write_text(json.dumps(result,indent=2)+'\n')
    print('DONE',out,'seconds',result['seconds'],flush=True)


if __name__=='__main__':main()
