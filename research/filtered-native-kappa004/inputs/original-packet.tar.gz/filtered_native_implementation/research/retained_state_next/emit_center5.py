#!/usr/bin/env python3
"""Emit and replay a literal one-mode coded source and its actual raw dual.

The current scalar-reduced native word is read-only. Only the fifth indexed
mode (R row 5) is removed. All 632 independent original owners are checked
over Q[free native warp words], including all helper columns.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def scalar_add(dst, src, coef):
    coef = F(coef)
    return ['scalar', ['add', dst, src, coef.numerator, coef.denominator], 0]


def main():
    path = ROOT / 'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw = path.read_bytes()
    source = json.loads(gzip.decompress(raw))
    witness = json.loads((HERE / 'CENTER5-SUFFIX.json').read_text())
    assert witness['source_pins'][str(path.relative_to(ROOT))] == sha256(raw).hexdigest()
    core = load('partial_center5_native_core', ROOT / 'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    ce = load('partial_center5_exact_clifford', ROOT / 'research/tensor_obstruction/inputs/clifford_exact.py')
    norms_path = ROOT / 'upstream/research/coded-native-caller/NORMALIZERS.json'
    norms = json.loads(norms_path.read_text())['ports']
    R = [F(v) for v in json.loads((ROOT / 'upstream/research/involutory-producer-raw-dual/inputs/R/R.json').read_text())[5]]
    S = {i: F(v) for i, v in witness['capture']['helper_terms']}
    A = [[F(i == j) - R[i] * R[j] / 4 for j in range(112)] for i in range(112)]
    assert sum(v * v for v in R) == 56
    artifact = {
        'schema': 'literal-one-center5-coded-native-source/v1',
        'scope': 'Physical forward and true raw-dual one-mode coded ABI. Caller closure and improved kappa not claimed.',
        'canonical': deepcopy(source['canonical']),
        'programs': {},
        'mode': 5,
        'A5': [[str(v) for v in row] for row in A],
        'source_word_sha256': sha256(raw).hexdigest(),
    }
    artifact['canonical']['local_profile']['8'] -= 1
    expected_paid = Counter({int(k): v for k, v in artifact['canonical']['local_profile'].items()})
    results = {}
    for direction, back in [('forward', False), ('backward', True)]:
        old = source['programs'][direction]
        selected = [i for i, e in enumerate(old) if e[0] == 'center'][5]
        changed = deepcopy(old)
        event = changed[selected]
        changed[selected] = ['scalar', ['clear', ['C', 0]], event[3]]
        # Owned C0 already exists and is zero outside each native center.
        # Reuse it at the ground entrance; it is not a new original helper.
        prefix = [['scalar', ['clear', ['C', 0]], 0]]
        if back:
            prefix += [scalar_add(['C', 0], ['L', 112+i], R[i] / 4)
                       for i in range(112) if R[i]]
            prefix += [scalar_add(['L', h], ['C', 0], -coef)
                       for h, coef in sorted(S.items())]
        else:
            prefix += [scalar_add(['C', 0], ['L', h], coef)
                       for h, coef in sorted(S.items())]
            prefix += [scalar_add(['L', 112+i], ['C', 0], R[i] / 4)
                       for i in range(112) if R[i]]
        prefix += [['scalar', ['clear', ['C', 0]], 0]]
        program = prefix + changed
        artifact['programs'][direction] = program
        rows, paid, norm = core.replay(artifact['canonical'], program, back)
        expected = {i: core.identity(i) for i in range(632)}
        expected[632] = {}
        for i in range(112):
            for j, coef in enumerate(A[i]):
                if coef:
                    if back:
                        core.add(expected[j], core.identity(112+i), -coef)
                    else:
                        core.add(expected[112+i], core.identity(j), coef)
        assert rows == expected
        assert paid == expected_paid
        assert all(rows[h] == core.identity(h) for h in range(224, 632))
        assert not rows[632]
        # Deleting the owned center without helper compensation must leave
        # an actual arbitrary-helper dependency, in either raw orientation.
        dirty, dirty_paid, _ = core.replay(artifact['canonical'], changed, back)
        assert dirty != expected and dirty_paid == paid
        assert sum(len(row) for row in dirty.values()) > 632
        results[direction] = {
            'original_event_index': selected,
            'original_event': event,
            'all_original_rows_checked': 632,
            'all_arbitrary_helpers_preserved': 408,
            'owned_C0_final_zero': True,
            'paid_profile': dict(sorted(paid.items())),
            'prefix_ADDs': len(prefix)-2,
            'prefix_CLEARs': 2,
            'events': len(program),
            'normalized_prefix_l1': str(norm),
            'uncompensated_center_deletion_rejected': True,
        }

    # The raw dual uses the actual source backward order, warps and charts.
    # Its all-column endpoint above is exactly inverse-transpose, since
    # the shear block A5 is real symmetric. It is not an invented reversal.
    F9 = ce.fourier(9)
    commutator_checks = 0
    for item in norms:
        K = ce.ident(9)
        for op in item['K_word']:
            if op[0] == 'P': gate = ce.perm(9, op[1])
            elif op[0] == 'D': gate = ce.diag(9, op[1], op[2])
            else: raise ValueError(op)
            K = K.then(gate)
        left, right = K.then(F9), F9.then(K)
        assert left.tab == right.tab and left.zero_state() == right.zero_state()
        commutator_checks += 1
    assert commutator_checks == 112

    data = json.dumps(artifact, sort_keys=True, separators=(',', ':')).encode()
    packed = gzip.compress(data, mtime=0)
    output = HERE / 'CENTER5-CODED-WORDS.json.gz'
    output.write_bytes(packed)
    result = {
        'schema': 'literal-one-center5-coded-native-validation/v1',
        'status': 'PASS_ALL632_BOTH_ACTUAL_ORIENTATIONS',
        'source_sha256': sha256(raw).hexdigest(),
        'emitted_word_sha256': sha256(packed).hexdigest(),
        'emitted_payload_sha256': sha256(data).hexdigest(),
        'checker_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
        'center_mode': 5,
        'forward_endpoint': 'X unchanged; Y += A5 X; all H unchanged logically.',
        'backward_endpoint': 'X -= A5^T Y; Y and all H unchanged logically.',
        'A5': 'I - R5^T R5/4',
        'A5_inverse': 'I - R5^T R5/52',
        'A5_spectrum': {'1': 111, '-13': 1},
        'A5_condition_number_2': 13,
        'helper_profile_unchanged': {'4': 28, '7': 7, '8': 47, '9': 326},
        'new_independent_originals': 0,
        'extra_owned_arrays_for_precompensation': 0,
        'outcomes': results,
        'physical_code': 'C5 = diag(K_i^-1) A5 diag(K_i)',
        'all112_Ki_commute_with_QD_exact_tableau_and_absolute_phase': True,
        'physical_commutation': '[C5,QD]=0 follows for every width because every Ki commutes F9=QD.',
        'all_width_basis': 'Scalar owner operations are tensor-width independent. Every native warp is replayed in a free noncommutative algebra. Each normalizer identity holds as a phase-exact single-copy Clifford equality, hence after arbitrary tensor powers.',
        'new_supplier_or_kappa': False,
    }
    (HERE / 'CENTER5-CODED-RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
