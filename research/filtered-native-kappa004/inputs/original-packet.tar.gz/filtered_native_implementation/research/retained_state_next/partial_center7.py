#!/usr/bin/env python3
"""Actual rank8-to-rank7 center factor and its full dirty endpoint.

This is a priced partial-source interface, not a completed caller repair.
It keeps the helper-dependent operator term explicitly in both orientations.
"""
from collections import Counter
from decimal import Decimal as D, getcontext
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def main():
    source_path = ROOT / 'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    raw = source_path.read_bytes()
    source = json.loads(gzip.decompress(raw))
    c = source['canonical']
    witness = json.loads((HERE/'CENTER5-SUFFIX.json').read_text())
    assert witness['source_pins'][str(source_path.relative_to(ROOT))] == sha256(raw).hexdigest()
    core = load('partial7_core', ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    ce = load('partial7_ce', ROOT/'research/tensor_obstruction/inputs/clifford_exact.py')
    rpath = ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    r = [F(v) for v in json.loads(rpath.read_text())[5]]
    hs = {i:F(v) for i,v in witness['capture']['helper_terms']}
    capture = {i: v for i,v in enumerate(r) if v}
    capture.update(hs)
    S = ce.canonical_frame(9, c['frames'][280])
    full = ce.fourier(9)
    grade = lambda op: ce.rank([x for x,z,p in op.tab[9:]])
    rank_census = Counter()
    eligible = []
    for q in range(1,512):
        rank = grade(S.adjoint().then(ce.cgate(9,q)))
        rank_census[rank] += 1
        if rank == 7:
            eligible.append(q)
    active = [i for i in range(112) if r[i]]
    assert len(eligible) == 128
    assert all(c['ports'][i] in eligible for i in active)
    assert set(eligible) == {h ^ v for h in (128,256) for v in range(128) if v.bit_count()%2 == 0}

    def conjugate(op):
        circ = []
        for e in op.circuit:
            if e[0] == 'C': circ.append(('C',e[1],-e[2]))
            elif e[0] == 'D': circ.append(('D',e[1],tuple(-a%4 for a in e[2])))
            elif e[0] == 'phase': circ.append(('phase',-e[1]%4))
            else: circ.append(e)
        return ce.Op(9,tuple((x,z,-p%4) for x,z,p in op.tab),circ)

    selected = sorted({128,256,c['ports'][active[0]]})
    factors = []
    for q in selected:
        G = ce.cgate(9,q)
        transfer = S.adjoint().then(G)  # Physical G S^-1.
        cert, compiled = ce.lower_child(transfer)
        assert cert['rank'] == 7
        assert compiled.tab == transfer.tab and compiled.zero_state() == transfer.zero_state()
        # The owned transfer in the raw dual is the transpose, not inverse
        # or adjoint. For bare G, G^T=G and it is bar(S) G.
        transpose = conjugate(transfer.adjoint())
        dual_cert, dual_compiled = ce.lower_child(transpose)
        assert dual_cert['rank'] == 7
        assert dual_compiled.tab == transpose.tab and dual_compiled.zero_state() == transpose.zero_state()
        fg, gf = full.then(G), G.then(full)
        assert fg.tab == gf.tab and fg.zero_state() == gf.zero_state()
        factors.append({'q':q, 'G_word':G.circuit,
                        'physical_forward': 'G S280^-1', 'forward_word':compiled.circuit,
                        'forward_lowering':cert,
                        'physical_raw_dual': '(G S280^-1)^T = bar(S280) G',
                        'raw_dual_word':dual_compiled.circuit, 'raw_dual_lowering':dual_cert,
                        'exact_tableau_and_absolute_phase':True,
                        'commutes_F9_exactly':True})

    # Insert one genuinely noncommutative G symbol into the actual source
    # and replay all original columns. It need not commute with native
    # warp symbols; the entire literal suffix itself removes those words.
    GSYM = 2000001
    outcomes = {}
    for direction, back in [('forward',False),('backward',True)]:
        es = source['programs'][direction]
        chosen = [i for i,e in enumerate(es) if e[0]=='center'][5]
        rows = [core.identity(i) for i in range(632)] + [{}]
        paid = Counter()
        for index,e in enumerate(es):
            typ = e[0]
            if typ == 'scalar':
                g = e[1]
                dst = g[1][1] + (632 if g[1][0]=='C' else 0)
                if g[0]=='clear': rows[dst] = {}
                elif g[0]=='copy':
                    src=g[2][1]+(632 if g[2][0]=='C' else 0)
                    rows[dst]=dict(rows[src])
                elif g[0]=='scale': rows[dst]={k:v*F(g[2],g[3]) for k,v in rows[dst].items() if v*g[2]}
                elif g[0]=='add':
                    src=g[2][1]+(632 if g[2][0]=='C' else 0)
                    core.add(rows[dst],rows[src],F(g[3],g[4]))
                else: raise ValueError(g)
            elif typ=='warp':
                rr=e[1][1]+(632 if e[1][0]=='C' else 0)
                rows[rr]=core.warp(rows[rr],e[2],back)
            elif typ=='center':
                if index==chosen:
                    rows[632]={ (owner,(GSYM,)+word):v for (owner,word),v in rows[632].items() }
                    paid[7]+=1
                else: paid[e[4]]+=1
            elif typ=='climb': paid[e[5]]+=1
            else: assert typ in ('phase','adapter','residual_adapter')
        expected=[core.expected(i,back) for i in range(632)]+[{}]
        for i in active:
            u=r[i]/4
            for j,a in capture.items():
                dst,src,coef = (j,112+i,-u*a) if back else (112+i,j,u*a)
                core.add(expected[dst],{(src,(GSYM,)):F(1)},coef)
                core.add(expected[dst],core.identity(src),-coef)
        assert rows==expected
        assert not rows[632]
        outcomes[direction]={
            'actual_selected_event':chosen,
            'all632_original_rows_checked':True,
            'owned_C0_final_zero':True,
            'paid_profile':dict(sorted(paid.items())),
            'helper_dependencies_retained_explicitly':True,
            'final_native_words':sorted({str(w) for row in rows for _,w in row}),
        }

    # The same dirty total stays on L240 until this already-paid rank1
    # contact. Direct matching of its missing head does not give rank7.
    B = S.adjoint().then(full)
    assert grade(B)==1
    contacts = []
    for name,G in [('B_inverse',B.adjoint()),('bare_central_Q',ce.cgate(9,1))]:
        contacts.append({'choice':name,'G_rank':grade(G),
                         'replacement_rank':grade(S.adjoint().then(G)),
                         'B_after_G_rank':grade(G.then(B))})
    assert all(x['replacement_rank']==9 for x in contacts)

    getcontext().prec=60
    cexp=D('.0030217758');p=1-cexp
    saving=D(8)**p-D(7)**p
    prices={str(k):str(D(k+1)**p-D(k)**p) for k in (1,7,8,9,16,24,32,56)}
    output={
        'schema':'actual-native-partial-center7/v1',
        'source_sha256':sha256(raw).hexdigest(),
        'R_source_sha256':sha256(rpath.read_bytes()).hexdigest(),
        'mode':5,'frame':280,'frame_basis':c['frames'][280],
        'rank_census_all511_bare_q':dict(sorted(rank_census.items())),
        'eligible_rank7_directions':eligible,
        'eligible_description':'q=h XOR v, h in{128,256}, v in low7 even-parity subspace',
        'all56_actual_R5_bare_heads_eligible':True,
        'phase_exact_representative_factors':factors,
        'full_dirty_forward_endpoint':'X,H unchanged; Y_i += X_i + (r_i/4)(G^⊗m-I)(rX+SH)',
        'full_dirty_raw_dual_endpoint':'Y unchanged; X_i -= Y_i+(r_i/4)(G^⊗m-I)rY; H_h -= (S_h/4)(G^⊗m-I)rY',
        'literal_symbolic_replays':outcomes,
        'helper_repair':{
            'forward':'t_H=SH; Y_i-=(r_i/4)(G^⊗m-I)t_H before the native word.',
            'raw_dual':'t_Y=rY/4; H_h+=S_h(G^⊗m-I)t_Y before the native word.',
            'new_rank1_queries_if_fresh':1,
            'forward_ADDs':105,'forward_COPYs':1,'forward_CLEARs':4,
            'owned_arrays':2,'all_original_helpers_retained':408,
        },
        'helper_corrected_code':{
            'projector':'P5=r^T r/56',
            'physical':'C_G=diag(K_i^-1)[I-P5+P5(14G^⊗m-13I)]diag(K_i)',
            'exceptional_mode':'14G^⊗m-13I',
            'all_width_eigenvalues':['1','-27','-13+14i','-13-14i'],
            'condition_number_upper_bound':27,
            'exceptional_inverse':'(2197 I+2366 G+2548 G^2+2744 G^3)/9855',
            'fresh_rank1_queries_per_code_or_inverse_evaluation':1,
            'ordinary_free_scalar_code':False,
            'commutes_full_stage_QD':True,
            'retained_input_filter_identity':'p(G)v=14Gv-13v implies Gv=(p(G)v+13v)/14; it requires the same chronological input v.',
        },
        'existing_same_dirty_source_rank1_contact':{
            'event':17155,'owner':240,'from':280,'to':1,
            'source_logical_value_still':'rX+SH',
            'operator':'B=F9 S280^-1','direct_missing_head_tests':contacts,
            'arbitrary_original_owner_may_not_be_queried_as_zero_scratch':True,
        },
        'price_at_c':str(cexp),
        'paid_rank8_to7_saving':str(saving),
        'net_after_one_fresh_rank1_helper_query':str(saving-1),
        'conditional_incremental_price_if_fused_into_existing_rank_k':prices,
        'fusion_warning':'These marginal prices are conditional; no simultaneous independent-input query fusion is supplied.',
        'status':'PASS_EXACT_PARTIAL_SOURCE_AND_DIRTY_ENDPOINT; CALLER_ABSORPTION_OPEN',
        'new_supplier_or_kappa':False,
    }
    (HERE/'PARTIAL-CENTER7.json').write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({k:v for k,v in output.items() if k not in ('eligible_rank7_directions','phase_exact_representative_factors')},indent=2))


if __name__=='__main__':
    main()
