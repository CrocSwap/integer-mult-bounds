#!/usr/bin/env python3
"""Expose the actual raw-dual Y source before any original X is read.

This is a physical SSA reschedule, not an endpoint-only postponement.
Every consumer-visible source version is retained at its actual frame.
All original owners remain arbitrary and independent.  The paired ABI
then exposes forward Dx and backward Dy before their opposite inputs
are consumed, with no duplicated Gaussian child.
"""
from collections import Counter
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import copy
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
FSYM=2000009


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
    spec.loader.exec_module(mod);return mod


def ix(ref):return ref[1]+(632 if ref[0]=='C' else 0)
def ref(i):return ['L',i] if i<632 else ['C',i-632]


def main():
    sourcepath=HERE/'F9-SOURCE-DAG-ALL8-SOURCEFIRST-WORD.json.gz'
    raw=sourcepath.read_bytes();source=json.loads(gzip.decompress(raw))
    canon=source['canonical'];es=source['programs']['backward']
    oldextra=source['owned_extra_slots_by_direction']['backward']
    n=633+oldextra
    core=load('symmetric_causal_core',ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py')
    nodes=[{'owner':i,'frame':canon['start'][i] if i<632 else None,
            'deps':[],'event':None,'index':None,'read_node':None}
           for i in range(n)]
    state=list(range(n));events={}
    for k,e in enumerate(es):
        typ=e[0];d=None;deps=[];read=None;frame=None
        if typ=='scalar':
            a,frame=e[1:];d=ix(a[1])
            if a[0]=='copy':read=ix(a[2]);deps=[state[read]]
            elif a[0]=='add':read=ix(a[2]);deps=[state[d],state[read]]
            elif a[0]=='scale':deps=[state[d]]
            else:assert a[0]=='clear'
        elif typ=='warp':d=ix(e[1]);deps=[state[d]];frame=e[4]
        elif typ in ('climb','adapter'):
            d=e[2];deps=[state[d]]
            frame=e[4] if typ=='climb' else nodes[state[d]]['frame']
        elif typ=='center':d=632+e[1];deps=[state[d]];frame=e[3]
        elif typ=='physical_add':
            d=ix(e[1]);read=ix(e[2]);deps=[state[d],state[read]];frame=e[5]
        else:assert typ=='phase'
        if d is not None:
            j=len(nodes);nodes.append({'owner':d,'frame':frame,'deps':deps,
                'event':copy.deepcopy(e),'index':k,
                'read_node':state[read] if read is not None else None})
            state[d]=j;events[k]=j
    stack=[state[i] for i in range(112,224)];anc=set()
    while stack:
        j=stack.pop()
        if j in anc:continue
        anc.add(j);stack.extend(nodes[j]['deps'])
    assert {i for i in anc if i<n}==set(range(112,224))
    assert all(112<=nodes[j]['owner']<224 for j in anc)
    assert not any(nodes[j]['event'] and nodes[j]['event'][0] in ('center','physical_add') for j in anc)
    boundary={nodes[j]['read_node'] for j in events.values()
              if j not in anc and nodes[j]['read_node'] in anc}
    cache={j:oldextra+1+k for k,j in enumerate(sorted(boundary))}
    out=[];origins=[]
    def emit(e,k=None):out.append(copy.deepcopy(e));origins.append(k)
    def snap(j):
        if j not in cache:return
        f=nodes[j]['frame'];assert f is not None
        emit(['scalar',['clear',['C',cache[j]]],f])
        emit(['scalar',['copy',['C',cache[j]],ref(nodes[j]['owner'])],f])
    emit(['phase','complete_raw_dual_Y_source_DAG'])
    for j in sorted(boundary):
        if nodes[j]['index'] is None:snap(j)
    for k,j in events.items():
        if j in anc:emit(nodes[j]['event'],k);snap(j)
    emit(['phase','late_X_input_admission'])
    for k,e in enumerate(es):
        if k not in events:
            emit(e,k);continue
        j=events[k]
        if j in anc:continue
        e=copy.deepcopy(e);rn=nodes[j]['read_node']
        if rn in cache:
            if e[0]=='scalar':e[1][2]=['C',cache[rn]]
            else:assert e[0]=='physical_add';e[2]=['C',cache[rn]]
        emit(e,k)
    emit(['phase','release_raw_dual_Y_snapshots'])
    for j,slot in cache.items():emit(['scalar',['clear',['C',slot]],nodes[j]['frame']])
    emit(['phase','done'])

    def replay(program,extra,late=False):
        nr=633+extra;live=[core.identity(i) for i in range(632)]+[{} for _ in range(nr-632)]
        frames=canon['start'][:]+[None for _ in range(nr-632)]
        paid=Counter();counts=Counter();maxnorm=Fr(1);admission=None
        for pos,e in enumerate(program):
            typ=e[0];counts[typ]+=1
            if typ=='scalar':
                a,f=e[1:];d=ix(a[1]);op=a[0]
                if op=='clear':assert d>=632;live[d]={};frames[d]=f
                else:
                    assert frames[d]==f,(pos,e,frames[d])
                    if op in ('copy','add'):
                        s=ix(a[2]);assert frames[s]==f,(pos,e,frames[s])
                        if op=='copy':assert d>=632;live[d]=dict(live[s])
                        else:core.add(live[d],live[s],Fr(a[3],a[4]))
                    else:assert op=='scale';live[d]={j:v*Fr(a[2],a[3]) for j,v in live[d].items() if v*a[2]}
            elif typ=='warp':
                d=ix(e[1]);assert frames[d]==e[3]
                live[d]=core.warp(live[d],e[2],True);frames[d]=e[4]
            elif typ=='climb':
                d=e[2];assert frames[d]==e[3],(pos,e,frames[d]);frames[d]=e[4];paid[e[5]]+=1
            elif typ=='center':
                d=632+e[1];assert frames[d]==e[2];frames[d]=e[3];paid[e[4]]+=1
            elif typ=='physical_add':
                _,dr,sr,a,b,df,sf,word=e;d=ix(dr);s=ix(sr)
                assert not word and (df,sf)==(1,0) and d<112
                assert frames[d]==df and frames[s]==sf
                core.add(live[d],{(o,(FSYM,)+w):v for (o,w),v in live[s].items()},Fr(a,b))
            else:
                assert typ in ('phase','adapter')
                if e==['phase','late_X_input_admission']:
                    assert all(live[i]==core.identity(i) and frames[i]==canon['start'][i] for i in range(112))
                    assert all(live[i]==core.identity(i) and frames[i]==canon['final'][i] for i in range(112,224))
                    assert all(live[i]==core.identity(i) and frames[i]==canon['start'][i] for i in range(224,632))
                    admission={'event':pos,'paid_profile_so_far':dict(sorted(paid.items())),
                               'all112_original_X_unread_and_unchanged':True,
                               'all408_original_helpers_unchanged':True,
                               'all112_Y_outputs_complete':True}
            if typ not in ('adapter','phase'):maxnorm=max(maxnorm,sum(map(abs,live[d].values()),Fr(0)))
        assert frames[:632]==canon['final']
        assert all(not r for r in live[632:])
        assert not late or admission is not None
        return live[:632],{'paid_profile':dict(sorted(paid.items())),
            'opcode_census':dict(counts),'max_l1_normalized_program_row':str(maxnorm),
            'late_X_admission':admission}
    expected,basereceipt=replay(es,oldextra)
    actual,receipt=replay(out,oldextra+len(cache),True)
    assert actual==expected
    assert receipt['paid_profile']==basereceipt['paid_profile']
    paid_origins=[origins[k] for k,e in enumerate(out) if e[0] in ('climb','center')]
    base_paid=[k for k,e in enumerate(es) if e[0] in ('climb','center')]
    assert sorted(paid_origins)==base_paid and len(paid_origins)==len(set(paid_origins))
    blob={'schema':'raw-dual-late-X-causal-ABI/v1','source_word_sha256':sha256(raw).hexdigest(),
          'canonical':canon,'program':out,'original_event_origins':origins,
          'owned_extra_slots':oldextra+len(cache),'normalized_F9_symbol':FSYM,
          'physical_frames_conjugated':True,
          'retained_Y_snapshots':[{'node':j,'slot':cache[j],'owner':nodes[j]['owner'],
             'frame':nodes[j]['frame'],'source_event':nodes[j]['index']} for j in sorted(cache)]}
    payload=json.dumps(blob,separators=(',',':')).encode();compressed=gzip.compress(payload,mtime=0)
    path=HERE/'RAW-DUAL-LATE-X-WORD.json.gz';path.write_bytes(compressed)
    result={'schema':'symmetric-causal-pair-ABI/v1','status':'PASS_LITERAL_LATE_X_SCHEDULE; PAIRED_CALLER_PENDING',
      'source_word_sha256':sha256(raw).hexdigest(),'word_sha256':sha256(compressed).hexdigest(),
      'word_payload_sha256':sha256(payload).hexdigest(),
      'backward_Y_source_nodes':len(anc),'retained_Y_snapshots':len(cache),
      'extra_owned_fields':oldextra+len(cache),'ground_Y_mode_fields':oldextra,
      'events':len(out),'receipt':receipt,
      'all632_original_endpoints_checked':True,'all408_helpers_autonomous':True,
      'all_actual_physical_frames_checked':True,'all_owned_final_zero':True,
      'every_paid_origin_used_once':True,'new_gaussian_queries':0,
      'normalized_ABI':{
        'notation':'C=diag(K_i^-1) A diag(K_i); F=QD; B=I-C; all 112 owners independent.',
        'forward_source':'u=D x_f; original y_f untouched until u exists.',
        'backward_source':'v=D y_b; original x_b untouched until v exists.',
        'forward_center_free_consumer':'y_f_out=D y_f+Q^-1 C u.',
        'backward_center_free_consumer':'x_b_out=D x_b-C Q v.',
        'forward_filtered_to_scalar':'After source, y_f-=B u; this is an ordinary owner/address update.',
        'backward_filtered_to_scalar':'After endpoint, x_b_out+=B F^2 y_b; this is ordinary on retained original y_b.',
        'paired_feedback':'Before either consumer: y_f+=N u+M v; x_b+=L u+K v, for actual ordinary N,M,L,K.',
        'paired_consumer_edge':'[[Q^-1 C+D N,D M],[D L,-C Q+D K]] on [u,v], plus D[y_f_original,x_b_original].',
        'independence':'The four original bank vectors are independent; none is silently zeroed or identified.'},
      'limitations':['A source vector transformed by D is not an F-transformed same-input cache.',
                     'The ordinary feedback family does not itself admit independent Gaussian targets.',
                     'No new kappa or complete paired caller is asserted.']}
    (HERE/'SYMMETRIC-CAUSAL-PAIR.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
