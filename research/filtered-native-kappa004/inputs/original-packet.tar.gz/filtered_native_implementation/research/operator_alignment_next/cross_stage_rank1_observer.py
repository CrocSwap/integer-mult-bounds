#!/usr/bin/env python3
"""Phase-exact foreign-stage mode gather from a backward native Y exit.

Native exit wrappers supply D1*y_i. Earlier K0_i commutes with D1, so
all112 differently framed raw Y exits align ordinarily into one D1
coefficient carrier. A single fresh Q head on that gathered field is a
rank1 mode query. Its scatter is J0 D1, not Q P0 D1.
"""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'research/retained_state_next'));import consumer_kg_module as kg
sys.path.insert(0,str(HERE));from rank1_snapshot_completion import conjugate


def operation(ce,n,word):
    out=ce.ident(n)
    for e in word:
        if e[0]=='P':gate=ce.perm(n,tuple(e[1]))
        elif e[0]=='D':gate=ce.diag(n,tuple(e[1]),tuple(e[2]))
        elif e[0]=='C':gate=ce.cgate(n,e[1],e[2])
        elif e[0]=='X':gate=ce.xgate(n,e[1])
        elif e[0]=='phase':gate=ce.Op(n,ce.identity(n),[('phase',e[1])])
        else:raise AssertionError(e)
        out=out.then(gate)
    return out


def embed_word(word,axes,n=17):
    mask=lambda x:sum(((x>>j)&1)<<a for j,a in enumerate(axes))
    result=[]
    for e in word:
        if e[0]=='P':
            rows=[1<<i for i in range(n)]
            for j,a in enumerate(axes):rows[a]=mask(e[1][j])
            result.append(('P',tuple(rows)))
        elif e[0]=='D':
            rows=[0]*n;alpha=[0]*n
            for j,a in enumerate(axes):rows[a]=mask(e[1][j]);alpha[a]=e[2][j]
            result.append(('D',tuple(rows),tuple(alpha)))
        elif e[0] in ('C','X'):result.append((e[0],mask(e[1]),*e[2:]))
        else:assert e[0]=='phase';result.append(tuple(e))
    return result


def main():
    started=time.monotonic();sp=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    np=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    source=json.loads(gzip.decompress(sp.read_bytes()));canonical=source['canonical']
    ports=json.loads(np.read_text())['ports'];R=[[int(a) for a in r] for r in json.loads(rp.read_text())]
    ce=kg.load('foreign_rank1_ce',ROOT/'upstream/research/coded-native-caller/clifford_exact.py')
    old_axes=list(range(9));current_axes=[0]+list(range(9,17));private_axes=list(range(9,17))
    D9=ce.fourier(9,range(1,9));D1=ce.fourier(17,private_axes);Q=ce.cgate(17,1)
    F1=D1.then(Q);routes=[];omitted_phase_rejections=0
    for i,port in enumerate(ports):
        frame=canonical['final'][112+i];S9=ce.canonical_frame(9,canonical['frames'][frame]);barS9=conjugate(ce,S9)
        K9=operation(ce,9,port['K_word']);BY9=operation(ce,9,port['compiled_wrappers']['backward_output_Y']['word'])
        left=barS9.then(BY9);right=K9.adjoint().then(D9)
        assert left.tab==right.tab and left.zero_state()==right.zero_state()
        assert ce.rank([x for x,z,p in BY9.tab[9:]])==0
        K0word=embed_word(K9.circuit,old_axes);K1word=embed_word(K9.circuit,current_axes)
        BYword=embed_word(BY9.circuit,current_axes);Sbarword=embed_word(barS9.circuit,current_axes)
        K0=operation(ce,17,K0word);K1=operation(ce,17,K1word)
        BY=operation(ce,17,BYword);Sbar=operation(ce,17,Sbarword)
        # These commute on disjoint coordinate sets, including the phases:
        # K0 uses only0...8; D1 uses9...16. Tableau equality is an extra check.
        assert K0.then(D1).tab==D1.then(K0).tab
        M=BY.then(K0);T=K1.adjoint().then(K0)
        assert ce.rank([x for x,z,p in M.tab[17:]])==0
        assert Sbar.then(M).tab==T.then(D1).tab
        assert Sbar.then(M).then(Q).tab==T.then(F1).tab
        # Absolute phases follow the independently checked9-axis exit
        # identity plus literal embedding and disjoint-support commutation.
        routes.append({'owner':112+i,'port':i,'native_output_frame':frame,
            'native_physical_frame':'conjugate(S_i)','ordinary_gather_word':M.circuit,
            'logical_target_word':T.circuit,'mode_coefficients':[r[i] for r in R],
            'source_exit_absolute_phase_check':True,'cross_stage17_axis_tableau_check':True})
        if port['Z_mask']:
            wrong=operation(ce,9,[e for e in port['K_word'] if e[0]!='D']).adjoint().then(D9)
            if left.tab!=wrong.tab or left.zero_state()!=wrong.zero_state():omitted_phase_rejections+=1
    assert omitted_phase_rejections
    # A source-bound negative control against moving the odd head outside
    # the K0-normalized mode projector.
    owner=next(i for i,a in enumerate(R[5]) if a)
    K=operation(ce,9,ports[owner]['K_word']);q=ce.cgate(9,1)
    dressed=K.then(q).then(K.adjoint());plain=q
    dv,dd=dressed.zero_state();pv,pd=plain.zero_state();assert (dv,dd)!=(pv,pd)
    def sparse(vec):return {str(i):list(a) for i,a in enumerate(vec) if a!=(0,0)}
    modes=[]
    for k,r in enumerate(R):
        active=[i for i,a in enumerate(r) if a]
        modes.append({'mode':k,'active_ports':active,'owned_accumulator':'O'+str(k),
            'ordinary_schedule':[{'op':'CLEAR','destination':'O'+str(k),'carrier':'D1'}]+[
                {'op':'MAPPED_ADD','destination':'O'+str(k),'source_original_owner':112+i,
                 'ordinary_route_port':i,'coefficient':r[i]} for i in active],
            'zero_query_output':'D1 * sum_i R_ki K0_i K1_i^-1 Ynative_i',
            'optional_plus_head':{'new_query_rank':1,'literal_word':[('C',1,1)],
                'output':'Q_mode D1 * sum_i R_ki K0_i K1_i^-1 Ynative_i'},
            'optional_minus_head':{'new_query_rank':1,'literal_word':[('C',1,-1)],
                'output':'Q_mode^-1 D1 * sum_i R_ki K0_i K1_i^-1 Ynative_i'}})
    out={'schema':'phase-exact-cross-stage-common-carrier-mode-observer/v1',
        'source_sha256':sha256(sp.read_bytes()).hexdigest(),'normalizers_sha256':sha256(np.read_bytes()).hexdigest(),
        'R_sha256':sha256(rp.read_bytes()).hexdigest(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'earlier_stage_axes':old_axes,'current_stage_axes':current_axes,'current_private_D_axes':private_axes,
        'all112_absolute_phase_exit_identities_pass':True,'all112_cross_stage_tableau_identities_pass':True,
        'omitted_source_sign_negative_controls':omitted_phase_rejections,
        'normalized_input':'Ynative_i=K1_i*y_i; actual backward exit adapter BY_i gives D1*y_i.',
        'input_alignment_identity':'(K0_i BY_i) conjugate(S_i)=D1 K0_i K1_i^-1',
        'common_carrier':'V=D1','common_carrier_gaussian_rank':8,
        'minimum_extra_rank_to_F1_carrier':1,'minimum_extra_rank_to_D1_carrier':0,
        'phase_argument':'Each9-axis native exit identity is checked by exact tableau and absolute-phase zero-state replay. Literal embedding preserves that identity; K0 and D1 have disjoint physical support, so commute with phase1.',
        'routes':routes,'modes':modes,
        'ordinary_scatter_normalization':'Scatter diag(K0_i^-1) r_k^T /4; sign may be chosen by caller.',
        'scattered_no_query_operator':'(1/4) diag(K0^-1) r_k^T r_k diag(K0) D1 = -P0,k D1',
        'scattered_plus_head_operator':'J0,k^+ D1, where J0,k^+=(1/4)diag(K0^-1)r_k^T Q_mode r_k diag(K0)',
        'scattered_minus_head_operator':'J0,k^- D1, where J0,k^-=(1/4)diag(K0^-1)r_k^T Q_mode^-1 r_k diag(K0)',
        'inverse_D_variant':'Ordinary D1² changes carrierD1 toD1^-1 before or after the head; it commutes with all earlier-stage K0.',
        'normalized_mode_group':{'definition':'E_a=(1/56)diag(K0^-1)r_k^T Q_mode^a r_k diag(K0)',
            'exact_products':'E_a E_b=E_(a+b mod4); E_0=Pi_k; E_4=Pi_k; differentmode productszero.',
            'ordinary_even_head':'E_2 is ordinary because the whole-width Q_mode² is a monomial.',
            'controlled_bank_map':'H=I-Pi_k+E_1; H⁴=I and H²=I-Pi_k+E_2 isordinary.',
            'one_query_realization':'Gatheru=Lx, retainu, queryv=Q_mode u, scatterV(v-u) into originalbankx; LV=I and VL=Pi_k.',
            'commuting_private_stages':'H commutes every D_t whose privateaxes are disjoint from the earlier stage0 axes.'},
        'odd_head_order_negative_control':{'source_mode':5,'diagonal_owner':owner,'input_basis':0,
            'K0_inverse_Q_K0_denominator_power':dd,'K0_inverse_Q_K0_output':sparse(dv),
            'plain_Q_denominator_power':pd,'plain_Q_output':sparse(pv),
            'unequal':True},
        'cost_one_mode':{'fresh_rank1_queries':1,'ordinary_mapped_gather_adds':56,'ordinary_scatter_adds_if_used':56,
            'owned_accumulator_fields':1,'optional_reusable_map_scratch':1,'all_native_originals_preserved':True},
        'cost_all8_modes':{'fresh_rank1_queries':8,'ordinary_mapped_gather_adds':448,'ordinary_scatter_adds_if_used':448,
            'owned_accumulator_fields':8,'optional_reusable_map_scratch':1},
        'whole_width_rule':'Every literal Clifford word is tensor-powered; R coefficients and1/4 scatter coefficients are outside tensor powers.',
        'scope':'An actual consumer-side cross-stage observation from the current normalized backwardY output. The zero-query form is a projector times an already available bank boundary. The paid head adds a distinct mode operatorJ, not QP. It does not isolate an earlier cached contribution from arbitrary current-stage input or by itself repair a deleted center.',
        'elapsed_seconds':time.monotonic()-started,'new_kappa_claimed':False}
    (HERE/'CROSS-STAGE-RANK1-OBSERVER.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CROSS_STAGE_OBSERVER','ports',len(routes),'phase_mutations',omitted_phase_rejections,'one_mode_queries',1,'seconds',time.monotonic()-started)


if __name__=='__main__':main()
