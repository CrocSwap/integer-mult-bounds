#!/usr/bin/env python3
"""Build and run the exact exhaustive bare-X exit-chart geometry probe."""
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import probe


def main():
    ce,ca,normals,R,routes=probe.cc.source_data()
    q=ca["ports"]
    records=[]
    for k in range(8):
        ports=[i for i in range(112) if R[k][i]]
        qs=[q[i] for i in ports]
        affine_basis=probe.bit_basis(ce,[x^qs[0] for x in qs])
        records.append({"mode":k,"ports":ports,"q_span_dimension":ce.rank(qs),
                        "q_affine_dimension":len(affine_basis),
                        "affine_difference_basis":affine_basis,
                        "orthogonal_normal":list(ce.nullspace(qs,9))})
    path=HERE/"CHART-INPUT.txt"
    path.write_text("".join(f"{q[i]} {sum((bool(R[k][i]))<<k for k in range(8))}\n" for i in range(112)))
    exe=HERE/"chart_frontier.bin"
    subprocess.run(["g++","-std=c++20","-O3",str(HERE/"chart_frontier.cpp"),"-o",str(exe)],check=True)
    raw=subprocess.check_output([str(exe),str(path)],text=True)
    result=json.loads(raw)
    for row in result["frontier"]:
        basis=[r|((r.bit_count()&1)<<8) for r in row["witness_even_basis_low8"]]
        odd=row["witness_odd_coset_low8"]
        if odd>=0:basis.append(odd|((1^(odd.bit_count()&1))<<8))
        row["witness_physical_Fourier_basis"]=basis
        probe.cc.need(ce.rank(basis)==row["Fourier_dimension"],"Wrong lifted chart rank")
        # Independently verify its complete8-mode coset count in physical GF2^9.
        span={0}
        for b in basis:span|={a^b for a in list(span)}
        count=[]
        for k in range(8):
            representatives={min(q[i]^a for a in span) for i in range(112) if R[k][i]}
            representatives.discard(0)
            count.append(len(representatives))
        probe.cc.need(count==row["witness_per_mode_queries"],"Physical quotient replay failed")
    result.update({"status":"EXHAUSTIVE_EXACT_BARE_X_SHARED_CHART_FRONTIER",
                   "source_mode_geometry":records,
                   "scope":"Bare-X_q exit heads, one common partial Walsh chart, one shared rank-one transform per nonzero quotient coset per target mode. Ordinary scalar coefficient and signed monomial phases remain literal.",
                   "entry_exit_cost_note":"Counts exclude creating or removing the output chart. Fresh entry for8 independent target arrays costs8*d rank-one equivalents. A changed caller must supply and price all output chart changes and arbitrary originalY/helper preservation.",
                   "enumeration_completeness":"Every subspace W in GF2^9 is either contained in the even-parity hyperplane E8, or is A plus one odd coset with A=W intersect E8. All417199 subspaces of E8 are enumerated. Because all sourceq are odd, adding an odd coset deletes exactly that coset from paid translations and leaves other equivalence classes unchanged."})
    (HERE/"CHART-FRONTIER.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":result["status"],"enumerated":sum(result["even_subspaces_enumerated_by_dimension"]),
                      "frontier":[{k:r[k] for k in ("Fourier_dimension","minimum_total_queries_for_all8_modes","individual_mode_minima","fresh_common_chart_total_including8_reads")} for r in result["frontier"]]},indent=2))


if __name__=="__main__":main()
