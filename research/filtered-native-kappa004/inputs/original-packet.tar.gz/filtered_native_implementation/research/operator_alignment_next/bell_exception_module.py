#!/usr/bin/env python3
"""Literal full-Bell monomial routes for the finite exception carrier.

All cross-kernel terms have the formK_j Q^a K_s^-1.  Their paired-copy
action is a Pauli-label affine permutation with an exact Z4 phase.
The carrier can therefore retain a common Bell chart, but its real entry
and exit cost is exposed.  This is not a recursive caller admission.
"""
from decimal import Decimal as D,localcontext
from hashlib import sha256
from pathlib import Path
import json
import random
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import probe
from exception_module import embedded_K,power


def need(value,message):
    if not value:raise AssertionError(message)


def bell_route(ce,U,R,address):
    n=U.n;mask=(1<<n)-1
    u,v=address&mask,address>>n
    x,z,p=ce.pmul(ce.apply(U.tab,(v,u,0)),R)
    return z|(x<<n),p


def route_recipe(ce,U,R):
    """Extract the ordinary affine/Z4 word without dense2^(2n) states."""
    n=2*U.n
    offset,phase=bell_route(ce,U,R,0)
    labels=[bell_route(ce,U,R,1<<j) for j in range(n)]
    columns=[x^offset for x,p in labels]
    alpha=[(p-phase)%4 for x,p in labels]
    quadratic=[(alpha[j]%2)<<j for j in range(n)]
    for j in range(n):
        for k in range(j+1,n):
            x,p=bell_route(ce,U,R,(1<<j)|(1<<k))
            need(x==offset^columns[j]^columns[k],'Bell coordinate map is not affine')
            coefficient=(p-phase-alpha[j]-alpha[k])%4
            need(coefficient in (0,2),'Bell phase is not a Z4 quadratic')
            if coefficient:
                quadratic[j]|=1<<k;quadratic[k]|=1<<j
    return {'matrix_rows':ce.transpose(columns,n),'offset':offset,
            'quadratic_rows':quadratic,'linear_Z4':alpha,'phase':phase}


def eval_recipe(ce,recipe,address):
    n=len(recipe['matrix_rows'])
    return (ce.mv(recipe['matrix_rows'],address)^recipe['offset'],
            (ce.qvalue(recipe['quadratic_rows'],recipe['linear_Z4'],address,n)+recipe['phase'])%4)


def closure_witness(ce,ca,normals,active,stages):
    n=1+8*stages
    def mask(q,s):return (q&1)|((q>>1)<<(1+8*s))
    basis=probe.bit_basis(ce,[mask(ca['ports'][i],s) for s in range(stages) for i in active])
    need(len(basis)==8*stages,'Changed source mode5 stage-union rank')
    original=list(basis)
    # The same two-stage witness already completes the one missing axis
    # for every larger union; do not sweep additional subspaces.
    i=4;j=0;s=1
    K_j=embedded_K(ce,normals[i],j,n);K_s=embedded_K(ce,normals[i],s,n)
    even=K_s.adjoint().then(K_j)
    w=259
    need(ce.rank(basis+[w])==len(basis),'Witness input is not in the q-span')
    x,z,p=ce.apply(even.tab,(w,0,0))
    need(z==0 and x==33542,'Cross-word spill witness changed')
    need(ce.rank(basis+[x])==n,'Cross-word did not force the final axis')
    return {'stages':stages,'ambient_axes':n,'bare_q_union_rank':len(original),
            'necessary_common_invariant_axis_dimension':n,
            'even_cross_word':'K_stage0,port4 K_stage1,port4^-1',
            'input_X_vector':w,'output_X_vector':x,
            'source_q_span_normal':ce.nullspace(original,n),
            'scope':'Minimal for partial Bell charts obtained by pairing one fixed physical translation subspaceW and retaining standard computational charts on its complement. Moving or non-Bell charts are not excluded.'}


def main():
    ce,ca,normals,R,routes=probe.cc.source_data()
    active=[i for i in range(112) if R[5][i]]
    n=17;Q=ce.cgate(n,1)
    K=[[embedded_K(ce,item,s,n) for item in normals] for s in range(2)]
    randomizer=random.Random(20261023)
    checks=0;records=[]
    for a in range(4):
        for i in active:
            U=K[1][i].adjoint().then(power(Q,a,ce)).then(K[0][i])
            # Every K is exactly real orthogonal.  Consequently
            # U U^T=K0 Q^(2a) K0^-1, literally, and no dense matrix
            # transpose or global-phase reconstruction is required.
            RR=ce.apply(K[0][i].tab,(1,0,0)) if a%2 else (0,0,0)
            need(RR==(ca['ports'][i],0,2) if a%2 else RR==(0,0,0),
                 'Unexpected U U^T Pauli phase')
            recipe=route_recipe(ce,U,RR)
            # This supplements the exact affine and quadratic coefficient
            # derivation; all route functions are source-fixed Clifford
            # conjugations, so the polynomial degree is proved, not fitted.
            for address in [0]+[randomizer.getrandbits(34) for _ in range(64)]:
                need(eval_recipe(ce,recipe,address)==bell_route(ce,U,RR,address),
                     'Emitted full-Bell monomial route failed')
                checks+=1
            records.append({'output_stage':0,'input_stage':1,'Q_exponent':a,
                            'port':i,'coefficient':'1/56',
                            'U_U_transpose_Pauli':RR,'ordinary_pair_recipe':recipe})
    frontiers=[closure_witness(ce,ca,normals,active,s) for s in (2,3,7)]
    prices=[]
    for stages in (1,2,3,7):
        dim=1+8*stages
        with localcontext() as ctx:
            ctx.prec=65;p=1-D('0.0030217758')
            one=D(dim)/2
            prices.append({'stages':stages,'full_Bell_axes':dim,
                'one_coefficient_field_fresh_boundary_normalized_ranks':[str(one),str(one)],
                'one_field_boundary_first_mass':dim,
                'one_field_boundary_moment':str(2*one**p),
                'max_redundant_coefficient_fields':4*stages,
                'fresh_boundaries_if_all_max_fields_materialized_first_mass':4*stages*dim,
                'scope':'Per-field boundary price only. A source-bound capture/scatter schedule may use fewer fields or share actual operations; none is silently supplied here.'})
    result={
        'status':'PASS_FULL_BELL_EXCEPTION_KERNEL_MONOMIAL_COMPILER',
        'source_R_row':5,'normalizer_mode_row_for_same_projector':7,
        'source_R_sha256':sha256((ROOT/'research/tensor_obstruction/inputs/R.json').read_bytes()).hexdigest(),
        'carrier_reference':'EXCEPTION-MODULE.json',
        'full_Bell_definition':'B_n|u,v>=2^(-n/2) sum_x(-1)^(u dot x)|x,x+v>',
        'general_identity':'B_n^-1(U tensor U)B_n maps Pauli labelP=X_v Z_u to U P U^T=(U P U^-1)(U U^T). For every source Clifford wordU, U U^T is a phase-Pauli, so this is a literal affine label permutation with a quadraticZ4 phase.',
        'specific_phase_formula':'ForU=K_j Q^a K_s^-1, U U^T=I ifa is even and -X_qj ifa is odd. EachK is real orthogonal; Q^2=X_central. ApplyU toP using its signed tableau, then multiply by this exact right-hand Pauli.',
        'all_width_lift':'Pair neighboring digit columns. Tensor the emitted ordinary pair map overthepairs; any odd leftover column ofK_j Q^a K_s^-1 uses at most2 ordinary terms because onlyQ can be nonmonomial. F_t orD_t coefficient transitions similarly expand the fixed leftover column into at most512 or256 monomials.',
        'fixed_stage_coefficient_closure':'All T_js^(a), allC_j andC_j^-1 updates, and coefficientF_t/D_t actions inEXCEPTION-MODULE.json become ordinary on paired Bell coefficient fields. The code state still uses a redundant28-field bound atsevenstages, and no inverse of a compressed T is assumed.',
        'emitted_representative_routes':records,
        'exact_routes':len(records),'additional_exact_address_checks':checks,
        'cross_stage_extension':'The displayed stage0/stage1 routes embed into any distinct pair ofstage blocks by an ordinary coordinate permutation. Self kernels use BELL-SELF-AVERAGE.json or the same full-Bell formula.',
        'common_axis_closure_checks':frontiers,
        'partial_Bell_necessity_proof':'ForU=C(X_q) M_G with real monomialM_G, a partial Bell chart onW can be ordinary only ifG W=W (applyU tensorU to the pairedX stabilizers) andq lies inW (apply it to the unequalZ stabilizers with difference inWperp). The even cross words enforceG-invariance; the source Gaussian heads enforce containment ofthe8S-dimensionalq span. The emitted single spill witness forces its missing central axis.',
        'fresh_boundary_prices':prices,
        'boundary_obligations':'No complete ordinary source capture, output embedding, chronological reuse, recursively closed target alphabet or positive moment matrix is supplied. A commonBell coefficient chart does not put112 arbitrary original owner arrays into that chart for free. Existing F/D charts must be matched as actual operators, not identified only by rank.',
        'kappa_improvement_claimed':False,
    }
    target=HERE/'BELL-EXCEPTION-MODULE.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'routes':len(records),'address_checks':checks,
                      'axis_closure':frontiers,'fresh_prices':prices},indent=2))


if __name__=='__main__':main()
