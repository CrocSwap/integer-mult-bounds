#!/usr/bin/env python3
"""Actual17-axis witness separating8 local mode observations from old-stage R.

All helpers are zero in this one legal witness, not as an algorithmic
premise.  All source observations vanish whereas the explicit cross-chart
R5 target is nonzero, so no decoder of those observations can recover it.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'research/retained_state_next'));import consumer_kg_module as kg


def mv(rows,x):return sum(((r&x).bit_count()%2)<<j for j,r in enumerate(rows))


def main():
    sp=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    np=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    op=HERE/'RANK1-SNAPSHOT-COMPLETION.json'
    source=json.loads(gzip.decompress(sp.read_bytes()));c=source['canonical']
    R=[[F(a) for a in r] for r in json.loads(rp.read_text())]
    ports=json.loads(np.read_text())['ports'];amp={0:F(-1),1:F(1),64:F(-1),70:F(1)}
    assert all(sum((r[i]*a for i,a in amp.items()),F(0))==0 for r in R)
    ce=kg.load('cross_completion_ce',ROOT/'upstream/research/coded-native-caller/clifford_exact.py')
    group=kg.PhaseGroup(ce,c,True)
    for g in set(group.letters.values()):assert group.ops[g].zero_state()==ce.ident(9).zero_state()
    # Current stage1 axes are0,9,...,16; earlier stage0 axes are0,...,8.
    # Basis8 is a spectator of every current-stage K_G and is fixed exactly.
    vector=[amp.get(i,F(0)) for i in range(112)]+[amp.get(i,F(0)) for i in range(112)]+[F(0)]*409
    cur=c['start'][:]+[None];full_count=0;captures={}
    observations=json.loads(op.read_text())['results']
    births={(t['after_event'],t['owner']) for r in observations for t in r['retained_precenter_input_gather']}
    for pos,e in enumerate(source['programs']['backward']):
        typ=e[0];d=None
        if typ=='scalar':
            a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
            if a[0]=='clear':vector[d]=F(0);cur[d]=f
            else:
                assert cur[d]==f
                if a[0] in ('add','copy'):
                    s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                    if a[0]=='copy':vector[d]=vector[s]
                    else:vector[d]+=F(a[3],a[4])*vector[s]
                else:vector[d]*=F(a[2],a[3])
        elif typ=='warp':d=e[1][1]+(632 if e[1][0]=='C' else 0);cur[d]=e[4]
        elif typ=='climb':d=e[2];cur[d]=e[4]
        elif typ=='center':d=632+e[1];cur[d]=e[3]
        else:assert typ in ('phase','adapter')
        if d is not None:
            if cur[d]==1:full_count+=1;assert vector[d]==0
            if (pos,d) in births:captures[pos,d]=vector[d];assert vector[d]==0
    assert len(captures)==8 and full_count==5798
    targets=[]
    for k,r in enumerate(R):
        out=defaultdict(F);terms=[]
        for i,a in amp.items():
            p=ports[i];address=mv(p['G_rows'],8)
            phase=(-1)**((p['Z_mask']&address).bit_count()%2)
            coeff=r[i]*a*phase
            if coeff:out[address]+=coeff
            terms.append({'owner':i,'source_amplitude':str(a),'R_coefficient':str(r[i]),
                          'K0_output_address':address,'K0_phase':phase})
        out={address:a for address,a in out.items() if a}
        targets.append({'source_mode':k,'nonzero':bool(out),
            'output_basis_coefficients':{str(address):str(a) for address,a in sorted(out.items())},'port_terms':terms})
    assert targets[5]['output_basis_coefficients']=={'8':'1','193':'1'}
    out={'schema':'actual-cross-stage-witness-for-local-mode-completion/v1',
        'source_sha256':sha256(sp.read_bytes()).hexdigest(),'R_sha256':sha256(rp.read_bytes()).hexdigest(),
        'normalizers_sha256':sha256(np.read_bytes()).hexdigest(),'local_completion_receipt_sha256':sha256(op.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'width':1,'physical_axes':17,
        'earlier_stage_axes':list(range(9)),'current_stage_axes':[0]+list(range(9,17)),
        'native_logical_initial_X_and_Y_amplitudes':{str(i):str(a) for i,a in amp.items()},
        'common_input_basis_address':8,'helpers':'All408 original helper arrays are zero in this one witness.',
        'all_eight_R_amplitude_sums_zero':True,'all_native_phase_warps_fix_current_local_zero_exactly':True,
        'full_frame_snapshots_vanishing':full_count,'new_precenter_observation_inputs_vanishing':len(captures),
        'target_contract':'T_k=Σ_i R_ki K0_i K1_i^−1 Y_native,i; nativeY=K1 times the normalized caller Y.',
        'cross_stage_targets':targets,
        'conclusion':'All original full-frame snapshots and the8 new local-mode observations have identical zero data, but the cross-stage R5 target is |8>+|193>. No postprocessing of these data recovers that target.',
        'scope':'The specific8 local-mode completion observations, even with all original S and arbitrary postprocessing. Differently designed cross-stage paid observations, additional native contacts, and changed paid jobs remain outside.',
        'new_kappa_claimed':False}
    (HERE/'CROSS-STAGE-COMPLETION-WITNESS.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CROSS_STAGE_WITNESS','snapshots',full_count,'observations',len(captures),'R5',targets[5]['output_basis_coefficients'])


if __name__=='__main__':main()
