#!/usr/bin/env python3
"""Exact tangent insertions on evolving banks of the literal p3 caller.

An insertion G at cut k contributes suffix[k] G prefix[k].  This is only
a first-order control equation; no finite program is claimed without a
separate replay of products and all higher-order terms.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import filtered_full_caller as fc
ac=fc.ac


def target_error(source,prefix,suffix,stage):
    at=next(i for i,e in enumerate(source['physical_events']) if e[0]=='LOCAL' and e[1]==stage)
    _,_,pair,back=source['physical_events'][at];x=2*pair
    dst,src=(x,x+1) if back else (x+1,x)
    delta=list(ac.ZERO_D);delta[stage]=1
    kwargs=dict(qleft=1 if back else 0,qright=0 if back else -1,
                dleft=tuple(delta),coefficient=-1 if back else 1)
    left=[row[dst] for row in suffix[at+1]];right=prefix[at][src]
    old=ac.p_outer(left,right,stage,**kwargs)
    new=ac.p_outer(left,[ac.poly_mul(ac.mono(q=1,stages=[stage]),p) for p in right],stage,**kwargs)
    return fc.add(old,fc.scale(new,-1)),at


def sector(v,stage,enabled):
    if not enabled:return v
    out=defaultdict(F)
    for (i,j,a,b,d),c in v.items():
        key=i,j,a,(b+2*(d[stage]//2))%4,tuple(x%2 for x in d)
        out[key]+=c
    return {k:c for k,c in out.items() if c}


def solve_stage(source,prefix,suffix,stage,use_sector=False):
    error,changed=target_error(source,prefix,suffix,stage)
    error=sector(error,stage,use_sector);goal=fc.scale(error,-1)
    columns=[]
    for cut in range(len(prefix)):
        for write_bank in range(6):
            for read_bank in range(6):
                for a in (0,2):
                    for b in (0,2):
                        op=ac.p_outer([row[write_bank] for row in suffix[cut]],prefix[cut][read_bank],
                                      stage,qleft=a,qright=b)
                        op=sector(op,stage,use_sector)
                        columns.append(({'cut':cut,'write_bank':write_bank,'read_bank':read_bank,
                                         'left_Q_power':a,'right_Q_power':b},op))
    basis=fc.sparse_basis(columns);recipe,residual=fc.solve(basis,goal)
    if not residual:
        check=dict(error)
        for j,c in recipe.items():check=fc.add(check,fc.scale(columns[j][1],c))
        assert not check
    return {'stage':stage,'changed_event':changed,
        'central_involutions_plus_specialization':use_sector,
        'all_six_original_banks_arbitrary':True,
        'candidate_insertions':len(columns),'exact_tangent_span_rank':len(basis),
        'tangent_solution_found':not residual,'residual_terms':len(residual),
        'first_residual':str(min(residual)) if residual else None,
        'solution':[{'coefficient':str(c),**columns[j][0]} for j,c in sorted(recipe.items())] if not residual else [],
        'candidate_physical_scope':'Ordinary Q^(0 or2) P_s Q^(0 or2) between any pair of physical banks at any actual caller cut, including same-bank infinitesimal linear updates. P_s=C5_s-I=-14Pi_s.',
        'no_finite_gate_admission':'The equation is linearized. Any solution must be integrated and replayed with all cross terms; same-bank updates also require a concrete invertible realization or retained input.'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stages',default='0')
    ap.add_argument('--sector',action='store_true');args=ap.parse_args()
    path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    source=json.loads(path.read_text())['selected_p3_keep43'];_,prefix,suffix=ac.source_matrices(source)
    started=time.monotonic();results=[]
    for stage in map(int,args.stages.split(',')):
        result=solve_stage(source,prefix,suffix,stage,args.sector);results.append(result)
        print('TANGENT',stage,'sector',args.sector,'solution',result['tangent_solution_found'],
              'rank',result['exact_tangent_span_rank'],'residual',result['residual_terms'],
              'elapsed',round(time.monotonic()-started,3),flush=True)
    stem='TANGENT-FILTERED-CALLER-SECTOR' if args.sector else 'TANGENT-FILTERED-CALLER'
    (HERE/(stem+'.json')).write_text(json.dumps({'status':'EXACT_TANGENT_CONTROL_SCREEN',
        'source_sha256':sha256(path.read_bytes()).hexdigest(),
        'results':results,'elapsed_seconds':time.monotonic()-started,
        'no_new_kappa_claimed':True},indent=2)+'\n')


if __name__=='__main__':main()
