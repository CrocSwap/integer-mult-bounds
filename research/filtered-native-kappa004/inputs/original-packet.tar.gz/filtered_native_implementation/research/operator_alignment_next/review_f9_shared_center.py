#!/usr/bin/env python3
"""Independent632-owner replay of the actual shared-query F9 centre.

The source interpreter is not imported.  Every new physical cross-frame
copy/add is checked as an identity on physical field data, with its exact
logical F9 effect derived from the forward/conjugated-backward frames.
The dirty helper channel remains explicit; no caller closure is inferred.
"""
from collections import Counter
from decimal import Decimal as D,localcontext
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import probe
from review_center5 import sparse_add,word_op,same


def need(value,message):
    if not value:raise AssertionError(message)


def conjugate(ce,op):
    circ=[]
    for e in op.circuit:
        if e[0]=='C':circ.append(('C',e[1],-e[2]))
        elif e[0]=='D':circ.append(('D',e[1],tuple(-a%4 for a in e[2])))
        elif e[0]=='phase':circ.append(('phase',-e[1]%4))
        else:circ.append(tuple(e))
    return ce.Op(op.n,tuple((x,z,-p%4) for x,z,p in op.tab),circ)


def replay(ce,canonical,program,back,fsym,capture):
    rows=[{(i,()):F(1)} for i in range(632)]+[{},{}]
    frames=canonical['start'][:]+[None,None]
    paid=Counter();counts=Counter();maxnorm=F(1);cross=[];cache_events=[]
    def owner(ref):
        need(ref[0] in ('L','C'),'Unknown owner namespace')
        index=ref[1]+(632 if ref[0]=='C' else 0)
        need(0<=index<634,'Owner beyond two declared owned slots')
        if ref[0]=='L':need(index<632,'Original index outside632')
        return index
    F9=ce.fourier(9)
    def frame_op(f):
        op=ce.canonical_frame(9,canonical['frames'][f])
        return conjugate(ce,op) if back else op
    for index,event in enumerate(program):
        kind=event[0];counts[kind]+=1
        if kind=='scalar':
            op,frame=event[1:];dst=owner(op[1]);name=op[0]
            if dst==633:cache_events.append({'event':index,'operation':name,'frame':frame})
            if name=='clear':
                need(dst>=632,'Erasure of an arbitrary original')
                rows[dst]={};frames[dst]=frame
            else:
                need(frames[dst]==frame,'Scalar destination frame mismatch')
                if name in ('copy','add'):
                    src=owner(op[2]);need(frames[src]==frame,'Scalar source frame mismatch')
                    if name=='copy':
                        need(dst>=632,'Overwrite of an arbitrary original')
                        rows[dst]=dict(rows[src])
                    else:
                        need(src!=dst,'Self ADD outside source grammar')
                        sparse_add(rows[dst],rows[src],F(op[3],op[4]))
                elif name=='scale':
                    factor=F(op[2],op[3]);rows[dst]={key:value*factor for key,value in rows[dst].items() if value*factor}
                else:raise AssertionError('Unknown scalar event')
        elif kind=='warp':
            _,ref,letter,old,new=event;dst=owner(ref)
            need(frames[dst]==old,'Warp source frame mismatch')
            letter=(1 if letter>0 else -1)*(abs(letter)+(1000000 if back else 0))
            changed={}
            for (src,word),value in rows[dst].items():
                word=word[1:] if word and word[0]==-letter else (letter,)+word
                key=(src,word);changed[key]=changed.get(key,F(0))+value
            rows[dst]={key:value for key,value in changed.items() if value};frames[dst]=new
        elif kind=='climb':
            _,_,dst,old,new,rank=event
            need(frames[dst]==old,'Climb source frame mismatch')
            need(rank==len(canonical['frames'][new])-len(canonical['frames'][old]) and rank>0,
                 'Incorrect native climb rank')
            paid[rank]+=1;frames[dst]=new
        elif kind=='center':
            _,owned,old,new,rank=event;dst=632+owned
            need(dst==632 and frames[dst]==old,'Centre frame/owner mismatch')
            need(rank==abs(len(canonical['frames'][new])-len(canonical['frames'][old])),
                 'Incorrect centre rank')
            paid[rank]+=1;frames[dst]=new
        elif kind in ('physical_copy','physical_add'):
            if kind=='physical_copy':
                _,dr,sr,df,sf,ordinary=event;factor=F(1)
            else:
                _,dr,sr,num,den,df,sf,ordinary=event;factor=F(num,den)
            dst,src=owner(dr),owner(sr)
            need(frames[dst]==df and frames[src]==sf,'Cross-frame operation incidence mismatch')
            need(ordinary==[],'New word must be literal identity on physical data')
            logical=frame_op(sf).then(frame_op(df).adjoint())
            need(same(logical,F9),'Physical identity does not have exact logicalF9 effect')
            shifted={(source,(fsym,)+word):value for (source,word),value in rows[src].items()}
            if kind=='physical_copy':
                need(not back and dst==632 and src==240 and (df,sf)==(0,1),
                     'Unexpected physicalCOPY source or owner')
                need(rows[src]==capture,'Moved query no longer sees exact dirty mode')
                rows[dst]=shifted
            else:
                need(back and dst==240 and src==633 and (df,sf)==(1,0) and factor==-1,
                     'Unexpected physicalADD source or owner')
                sparse_add(rows[dst],shifted,factor)
                cache_events.append({'event':index,'operation':'read_for_physical_add','frame':sf})
            cross.append({'event':index,'operation':kind,'source_owner':src,'target_owner':dst,
                          'source_frame':sf,'target_frame':df,
                          'actual_physical_operator':'I','exact_logical_operator':'F9',
                          'tableau_and_absolute_phase_checked':True})
        else:
            need(kind in ('phase','adapter','residual_adapter'),'Unknown source event')
            continue
        if kind in ('scalar','physical_copy','physical_add'):
            maxnorm=max(maxnorm,sum(map(abs,rows[dst].values()),F(0)))
    need(frames[:632]==canonical['final'],'Final original frames differ')
    need(not rows[632] and not rows[633],'Owned data remains live at return')
    return rows,paid,maxnorm,counts,cross,cache_events


def poly_add(dst,src,factor=F(1)):
    for k,v in src.items():
        val=dst.get(k,F(0))+factor*v
        if val:dst[k]=val
        else:dst.pop(k,None)


def polynomial_recovery(r):
    # Verify all112x112 entries of C5^-1 C_F F + (r^Tr/52) F² = F I.
    # F is a commuting address operator; coefficients are owner scalars.
    n=len(r);checks=0
    C0=[[F(i==j)-r[i]*r[j]/52 for j in range(n)] for i in range(n)]
    for i in range(n):
        for j in range(n):
            actual={}
            for k in range(n):
                if not C0[i][k]:continue
                # C_F F=(I-r^Tr/4)F+(r^Tr/4)F².
                first=F(k==j)-r[k]*r[j]/4
                second=r[k]*r[j]/4
                poly_add(actual,{1:first,2:second},C0[i][k])
            poly_add(actual,{2:r[i]*r[j]/52})
            expected={1:F(1)} if i==j else {}
            need(actual==expected,'Full112-owner same-input recovery identity failed')
            checks+=1
    return checks


def main():
    ce,ca,normals,R,routes=probe.cc.source_data()
    old_path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    new_path=ROOT/'research/retained_state_next/F9-SHARED-CENTER-WORDS.json.gz'
    result_path=ROOT/'research/retained_state_next/F9-SHARED-CENTER.json'
    suffix_path=ROOT/'research/retained_state_next/CENTER5-SUFFIX.json'
    old=json.loads(gzip.decompress(old_path.read_bytes()))
    payload=gzip.decompress(new_path.read_bytes());changed=json.loads(payload)
    claimed=json.loads(result_path.read_text());suffix=json.loads(suffix_path.read_text())
    need(changed['canonical']==old['canonical'],'Changed canonical source frames')
    need(sha256(old_path.read_bytes()).hexdigest()==claimed['source_sha256'],'Changed pinned source')
    need(sha256(new_path.read_bytes()).hexdigest()==claimed['word_sha256'],'Packed word hash differs')
    need(sha256(payload).hexdigest()==claimed['word_payload_sha256'],'Payload hash differs')
    r=list(map(F,R[5]));need(sum(x*x for x in r)==56,'Wrong sourceR5 Gram')
    helpers={i:F(value) for i,value in suffix['capture']['helper_terms']}
    capture={(i,()):value for i,value in enumerate(r) if value}
    capture.update({(i,()):value for i,value in helpers.items()})
    fsym=changed['normalized_F9_symbol'];records=[]
    for direction in ('forward','backward'):
        back=direction=='backward'
        prior=old['programs'][direction]
        need(prior[17155]==['climb','scalar_refactor',240,280,1,1],
             'Shared original paid event changed')
        low=11400 if not back else 11423
        for e in prior[low+1:17155]:
            need(not(e[0]=='scalar' and ['L',240] in e[1]),'Intervening scalarL240 use')
            need(not(e[0]=='warp' and e[1]==['L',240]),'Intervening warpL240 use')
            need(not(e[0]=='climb' and e[2]==240),'Intervening climbL240 use')
        rows,paid,norm,counts,cross,cache=replay(ce,changed['canonical'],changed['programs'][direction],back,fsym,capture)
        expected=[{(i,()):F(1)} for i in range(632)]+[{},{}]
        for i in range(112):
            if back:sparse_add(expected[i],{(112+i,()):F(1)},-1)
            else:sparse_add(expected[112+i],{(i,()):F(1)},1)
        for i,ri in enumerate(r):
            if not ri:continue
            for (j,word),a in capture.items():
                dst,src,coef=(j,112+i,-ri*a/4) if back else (112+i,j,ri*a/4)
                sparse_add(expected[dst],{(src,(fsym,)):F(1)},coef)
                sparse_add(expected[dst],{(src,()):F(1)},-coef)
        need(rows==expected,'Independent632-owner dirty endpoint differs')
        need(paid==Counter({int(k):v for k,v in claimed['replays'][direction]['paid_profile'].items()}),
             'Independent paid inventory differs')
        need(norm==F(claimed['replays'][direction]['max_l1_normalized_row']),
             'Independent prefix norm differs')
        source_paid=Counter(e[5] if e[0]=='climb' else e[4] for e in prior if e[0] in ('climb','center'))
        need(source_paid-paid==Counter({8:1}) and not(paid-source_paid),
             'Changed producer did not save exactlyone rank8 query')
        need(paid[1]==source_paid[1],'Moved/shared rank1 query was recounted')
        records.append({'orientation':direction,'all632_original_rows_checked':True,
                        'independent_helper_columns_checked':408,'helper_channel_clean':False,
                        'all_frames_and_owned_lifetimes_checked':True,
                        'paid_profile':dict(sorted(paid.items())),
                        'deleted_paid_profile':{8:1},'extra_owned_slots':int(back),
                        'all_owned_zero_at_return':True,'normalized_prefix_l1':str(norm),
                        'cross_frame_physical_identity_checks':cross,'extra_cache_events':cache,
                        'native_source_event_17155_count':sum(e==prior[17155] for e in changed['programs'][direction])})
    F9=ce.fourier(9);S=ce.canonical_frame(9,ca['frames'][280])
    B=S.adjoint().then(F9);need(ce.rank([x for x,z,p in B.tab[9:]])==1,'Shared query is not rank1')
    transpose=conjugate(ce,B.adjoint());merged=transpose.then(conjugate(ce,B))
    need(same(merged,ce.ident(9)),'Raw-dual merge fails absolutephase identity')
    Fsquare=F9.then(F9);ordinary,recipe=ce.monomial(Fsquare)
    need(recipe['offset']==511 and recipe['phase']==0,'F9² is not the literal allbittranslation')
    kernel_transpose_checks=0
    # The new F9 symbol is symmetric.  Forward error is u(F-I)[r,S];
    # its negative transpose has exactly the replayedX andH destinations.
    for i,ri in enumerate(r):
        for (j,word),a in capture.items():
            if ri:
                need(-(ri*a/4)==-(a*ri/4),'Raw dual coefficient mismatch')
                kernel_transpose_checks+=1
    recovery_checks=polynomial_recovery(r)
    normalizer_checks=0
    for item in normals:
        K=word_op(ce,item['K_word'])
        need(same(K.then(F9),F9.then(K)),'Normalizer does not commute withF9')
        normalizer_checks+=1
    with localcontext() as ctx:
        ctx.prec=65;saved=D(8)**(1-D('0.0030217758'))
    result={
        'status':'PASS_INDEPENDENT_FULL_DIRTY_F9_SHARED_QUERY_REPLAY_AND_CONDITIONAL_112_OWNER_RECOVERY',
        'pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                for p in (old_path,new_path,result_path,suffix_path)},
        'independent_interpreter':'This file does not import or callnative_core. It separately implements all event semantics, source word cancellation, scalar arithmetic, paid inventory, frame incidence and owned lifetimes.',
        'source_R_row':5,'normalizer_mode_row_for_same_projector':7,
        'orientations':records,
        'physical_shared_query':{'source_owner':240,'old_frame':280,'new_frame':1,
            'operator':'B=F9 S280^-1','rank':1,'source_original_paid_event':17155,
            'query_already_present_once':True,'forward_relocation_gap_source_uses':0,
            'forward_identity_COPY':'PhysicalF9 dirtytotal is copied into ownedC0 with ground targetframe; logicaleffectF9 is explicit, not a free Gaussian retagging.',
            'raw_dual_identity_ADD':'Backward physicalframes are conjugated. bar(B)B^T=I, so the sourceground cache may be added after the existingclimb with literal identity. ExtraownedC1 is explicitly retained and cleared.'},
        'dirty_endpoint':{'forward':'X,H unchanged; Y_i+=X_i+(r_i/4)(F9^tensor m-I)(rX+SH).',
            'raw_dual':'Y unchanged; X_i-=Y_i+(r_i/4)(F9^tensor m-I)rY; H_h-=(S_h/4)(F9^tensor m-I)rY.',
            'nonzero_helper_coefficients':len(helpers),'raw_dual_error_transpose_terms_checked':kernel_transpose_checks,
            'helpers_preserved_as_arbitrary_inputs':True,'helpers_returned_to_autonomous_target':False},
        'actual_paid_saving':{'per_orientation':{'8':1},'rank1_difference':0,
            'moment_saved_at_c_0030217758':str(saved),
            'scope':'Producer query inventory only. Helper cleanup, target recovery, additionalowned cache hosting, callerbudgets and recursive child obligations are not paid away by this number.'},
        'conditional_target_recovery':{'all112x112_owner_coefficients_checked':recovery_checks,
            'normalizer_phase_commutators_checked':normalizer_checks,
            'definitions':'P=diagK^-1 r^Tr diagK/56, C_F=I-14P+14PF, C5=I-14P, F=F9^tensor m.',
            'provided_contract':'z=C_F F v with the same chronological originalv retained or its neededr diagK aggregate available.',
            'decoder':'Fv=C5^-1 z+(diagK^-1 r^Tr diagK/52) F²v.',
            'scalar_mode_decoder':'Fv_mode=(14F² v_mode-z_mode)/13.',
            'F9_square_ordinary_recipe':recipe,
            'full_signed_stage_extension':'The same formula holds forz=C_F H v withH=Q^±1D becauseFH ismonomial (Q^(1±1)D²); replaceF²v byFHv.',
            'ordinary_scratch_upper_bound':2,
            'not_yet_supplied':'The normalized native source contract usesdiag(D,D) withaQ^-1-coupled shear. This replay does not substitutea completed C_F F target for that endpoint, does not prove a chronological retainedsameinput reader, and does not repair thedirtyhelper channel.'},
        'scope':'The shared-query source transformation itself is exact and physically priced. It removesone rank8query using an already-paid rank1source contact. A helper-clean supplier and a closed caller have not yet been established; no kappa improvement isclaimed.'}
    target=HERE/'F9-SHARED-CENTER-INDEPENDENT-REVIEW.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('pins','conditional_target_recovery')},indent=2))


if __name__=='__main__':main()
