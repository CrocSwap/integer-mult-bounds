#!/usr/bin/env python3
"""Three finite chronological feedback gates after the changed stage0.

Keep the uniquely observed quadratic escape A at cut1; enumerate later
I/P transvections B,C and solve the exact multilinear inverse equation.
The linear relaxation treats a,b,c,ab,ac,bc,abc independently.  A failure
there excludes that exact three-gate instance without a numerical search.
"""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys
import time
import argparse

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import finite_chronological_loops as fl
ar=fl.ar;ac=fl.ac;fc=fl.fc


def balanced(v):return {k:c for k,c in v.items() if len(k[2])<=2}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--internal-scalarize',action='store_true');args=ap.parse_args()
    started=time.monotonic();path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    source=json.loads(path.read_text())['selected_p3_keep43'];_,prefix,suffix=ac.source_matrices(source)
    targets=source['exact_diagonal_monomials'];err,_=ar.it.tc.target_error(source,prefix,suffix,0)
    E=fl.endpoint_shift(fl.convert(ar.one_p(err,0,True)),targets);goal=fc.scale(E,-1)
    data=fl.classes(source,prefix,suffix,True);first=[e for e in data if e['P_degree']==1][35];A=first['operator']
    internal=None
    if args.internal_scalarize:
        internal=next(e for e in data if e['P_degree']==1 and any(o['kind']=='internal_source_to_opposite_input' and o['source_stage']==0 for o in e['occurrences']))
        H=internal['operator'];assert not fl.mul(H,E) and not fl.mul(E,H)
        E=fc.add(E,H);goal=fc.scale(E,-1)
    old=json.loads((HERE/'ARBITRARY-OWNER-TANGENT.json').read_text())['results'][0]['functional']
    weights={(r['output_bank'],r['input_bank'],tuple(r['Q_powers_separated_by_P']),
        (r['source_zeta_power'],)+tuple(r['other_stage_sign_powers'])):F(r['coefficient']) for r in old}
    def dual(v):return sum((c*weights.get(k,F(0)) for k,c in fl.endpoint_shift(v,targets).items()),F(0))
    assert dual(goal)==-1
    later=[]
    for idx,e in enumerate(data):
        times=[o for o in e['occurrences'] if o['time']>2]
        if times:later.append((idx,e['operator'],times,balanced(fl.mul(e['operator'],A))))
    pairings=0;nonzero=0;candidates=[];best=None
    for ib,B,bt,BA in later:
        for ic,C,ct,CA in later:
            times=next(((b,c) for b in bt for c in ct if b['time']<=c['time']),None)
            if times is None:continue
            pairings+=1;CB=balanced(fl.mul(C,B));CBA=balanced(fl.mul(C,BA))
            nonlinear=[BA,CA,CB,CBA]
            if not any(dual(v) for v in nonlinear):continue
            nonzero+=1
            columns=list(zip(['a','b','c','ab','ac','bc','abc'],[A,B,C,BA,CA,CB,CBA]))
            basis=fc.sparse_basis(columns);recipe,residual=fc.solve(basis,goal)
            if best is None or len(residual)<best['residual_terms']:
                best={'B_class':ib,'C_class':ic,'residual_terms':len(residual),'times':list(times)}
            if residual:continue
            coeff={name:recipe.get(j,F(0)) for j,(name,_) in enumerate(columns)}
            compatible=(coeff['ab']==coeff['a']*coeff['b'] and coeff['ac']==coeff['a']*coeff['c'] and
                        coeff['bc']==coeff['b']*coeff['c'] and coeff['abc']==coeff['a']*coeff['b']*coeff['c'])
            candidates.append({'B_class':ib,'C_class':ic,'times':list(times),'coefficient_solution':{k:str(v) for k,v in coeff.items()},
                               'chosen_solution_multilinear_compatible':compatible,'rank':len(basis),
                               'requires_polynomial_kernel_search':len(basis)<7 and not compatible})
    out={'schema':'finite-three-gate-balanced-sector-feedback/v1','source_sha256':sha256(path.read_bytes()).hexdigest(),
         'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
         'first_gate':first['occurrences'][0],'later_classes':len(later),'chronological_pairings':pairings,
         'initial_internal_scalarizing_feedback':internal['occurrences'] if internal else None,
         'pairings_with_nonzero_higher_order_dual':nonzero,'linear_multilinear_relaxation_candidates':candidates,
         'best_residual':best,'all_six_original_main_banks_arbitrary':True,'all_external_D_characters_retained':True,
         'operator_relations':['Q²=I','P²=-14P','PQP=0 on actual source balanced frequencies'],
         'inverse_equation':'aA+bB+cC+ab BA+ac CA+bc CB+abc CBA=-E; exact finite product',
         'scope':'Three gates with first gate cut1 bank1 += a P0 bank0, then two I/P0 transvections at actual outer/source cuts. This does not cover unrestricted finite feedback or additional gates.',
         'elapsed_seconds':time.monotonic()-started,'new_kappa_claimed':False}
    print('THREE_GATE',pairings,nonzero,'relaxed_candidates',len(candidates),'best',best,'seconds',time.monotonic()-started,flush=True)
    stem='FINITE-SCALARIZED-THREE-GATE-FEEDBACK' if args.internal_scalarize else 'FINITE-THREE-GATE-FEEDBACK'
    (HERE/(stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
