#!/usr/bin/env python3
"""Bind the actual Y exits and replay the common partial-Walsh factorization.

This probe uses actual native final frames, not the entrance head substituted
for an exit head.  The distinction rejects an otherwise attractive two-query
proposal.  Chart-reduced counts are conditional, with both boundaries exposed.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import probe


def grade(ce, op):
    return ce.rank([x for x,z,p in op.tab[9:]])


def eval_monomial(ce, word, address):
    exponent=0
    for e in word:
        if e[0]=="P":address=ce.mv(e[1],address)
        elif e[0]=="D":exponent+=ce.qvalue(e[1],e[2],address,9)
        elif e[0]=="X":address^=e[1]
        elif e[0]=="phase":exponent+=e[1]
        else:raise AssertionError("Nonmonomial route")
    return address,exponent%4


def main():
    ce,ca,normals,R,routes=probe.cc.source_data()
    P=probe.ma.source_paulis(ce,ca)
    F=ce.fourier(9)
    target_records=[]
    wrong_grades=Counter()
    actual_grades=Counter()
    for i,q in enumerate(ca["ports"]):
        U=ce.canonical_frame(9,ca["frames"][ca["start"][i]])
        S=ce.canonical_frame(9,ca["frames"][ca["final"][112+i]])
        # B_i=S_i F9^-1 C(X_qi), so S_i F9^-1=B_i C(X_qi)^*.
        B=ce.cgate(9,q).then(F.adjoint()).then(S)
        actual_grades[grade(ce,B)]+=1
        Bword,Brecipe=ce.monomial(B)
        direct=F.adjoint().then(S)
        factored=ce.cgate(9,q,-1).then(Bword)
        probe.cc.need(direct.tab==factored.tab and direct.zero_state()==factored.zero_state(),
                      "Actual exit factor lost an absolute phase")
        tempting=F.adjoint().then(U).then(S)
        wrong_grades[grade(ce,tempting)]+=1
        target_records.append({"port":i,"bare_head_translation":q,
                               "final_Y_frame_id":ca["final"][112+i],
                               "actual_output_monomial":Bword.circuit,
                               "actual_output_recipe":Brecipe})
    probe.cc.need(actual_grades=={0:112},"Actual exit monomial grade changed")
    probe.cc.need(wrong_grades=={2:112},"Tempting entrance/exit substitution changed")
    mode5=[i for i in range(112) if R[5][i]]
    mode5_counter=Counter()
    paired={}
    for i in mode5:
        q,z,p=P[i]
        h=q^z
        probe.cc.need(h in (128,256) and z<128 and z.bit_count() in (2,6) and p==0,
                      "Changed global mode5 Pauli geometry")
        transformed=ce.apply(F.tab,P[i])
        probe.cc.need(transformed==(h,z,2),"FullGaussian conjugate phase is not -X_h Z_v")
        mode5_counter[(h,z.bit_count())]+=1
        paired[(h,z)]=int(R[5][i])
    probe.cc.need(all(paired[(128,z)]==-paired[(256,z)] for h,z in paired),
                  "Lost paired opposite mode5 signs")
    frontier=json.loads((HERE/"CHART-FRONTIER.json").read_text())
    chart_records=[]
    # Record every Pareto-relevant high-dimensional shared chart, including
    # the actual4-dimensional common chart and the15-query7-dimensional one.
    for d in (4,5,6,7,8):
        row=frontier["frontier"][d]
        W=row["witness_physical_Fourier_basis"]
        coordinate_columns=ce.basis_extend(W,9)
        coordinate_rows=ce.transpose(coordinate_columns,9)
        to_chart=ce.inv(coordinate_rows,9)
        V=ce.perm(9,to_chart).then(ce.hadamard(9,range(d)))
        mask=(1<<d)-1
        recs=[];checked=0
        for i,q in enumerate(ca["ports"]):
            label=ce.mv(to_chart,q)
            z=label&mask;r=label^z
            C=V.adjoint().then(ce.cgate(9,q,-1)).then(V)
            Q=ce.cgate(9,r,-1) if r else ce.ident(9)
            # C=M Q, hence M=C Q^-1.  all represented literally.
            M=Q.adjoint().then(C)
            probe.cc.need(grade(ce,M)==0,"Conditional head coefficient is not monomial")
            Mword,Mrecipe=ce.monomial(M)
            factored=Q.then(Mword)
            probe.cc.need(C.tab==factored.tab and C.zero_state()==factored.zero_state(),
                          "Partial-chart factorization lost a phase")
            for address in range(512):
                delta=probe.parity(z&address)
                expected=(address^(r if delta else 0),(-delta)%4)
                probe.cc.need(eval_monomial(ce,Mword.circuit,address)==expected,
                              "Literal conditional scatter differs from route formula")
                checked+=1
            recs.append({"port":i,"translated_head":r,"control_Z_mask":z,
                         "monomial_recipe":Mrecipe})
        chart_records.append({"Fourier_dimension":d,"physical_basis":W,
                              "coordinate_change_rows":to_chart,
                              "literal_conditional_route_columns_checked":checked,
                              "total_queries_for8_R_modes":row["minimum_total_queries_for_all8_modes"],
                              "ports":recs})
    result={"status":"PASS_ACTUAL_EXIT_BINDING_AND_CONDITIONAL_PARTIAL_CHART_PHASES",
            "source_manifest":"../constructive_observers/SOURCES.json",
            "actual_exit_formula":"S_i F9^-1=B_i C(X_qi)^*; every B_i is literal grade0 Clifford monomial",
            "actual_exit_monomial_grades":dict(actual_grades),
            "rejected_two_head_formula":"S_i U_i F9^-1 has grade2 for ALL112 ports; entrance Pauli diagonalization cannot be reused at this exit for free",
            "rejected_two_head_grades":dict(wrong_grades),
            "mode5_global_entrance_structure":{"ports":mode5,"commuting":True,"Pauli_linear_span":8,
                "formula":"P_i=X_h X_v Z_v=-X_h Y_v, h128/256, wt(v)=2 or6; F9 P_i F9^-1=-X_h Z_v",
                "paired_R5_signs_opposite":True,
                "warning":"This is the entrance Pauli family. Actual exit heads are bareX_q and the matching correction has grade2."},
            "target_equation":"For an already available clean common t_F=F9*t, every required exit contribution r_i*S_i*t equals r_i*B_i*V^-1*M_i*C(X_r)^* V*t_F. Here A q_i=(z,r), V=H_firstd P_A, and M_i|x>=(-i)^{z·x}|x+(z·x)r>.",
            "width_lift":"All operators are actual base Clifford/monomial words tensor-lifted; the conditional route at widthm XORs the active bit-plane words by delta=dot(z,spectator_words), with phase(-i)^wt(delta). Equality at everywidth follows with literal phases.",
            "boundary_obligations":{"input":"t_F must be a complete clean coded input, available at an actual chronological source cut.",
                "output":"The B_i V^-1 embedding is not ordinary for d>0 unless a changed caller supplies that output chart. Arbitrary originalY data must retain its true chart.",
                "helpers":"A deleted native centre may have dirty input R_k x+S_k H. This file repairs only the stated clean R_k x component; all arbitrary helper terms require separate exact cancellation or a dirty coded reader.",
                "owned_workspace":"Shared-input query outputs can be recomputed sequentially with owned CLEAR; no original owner is erased. A full owned/raw-dual program is not asserted for unmatched output charts."},
            "conditional_charts":chart_records,"actual_output_routes":target_records,
            "kappa_improvement_claimed":False}
    (HERE/"EXIT-RESULT.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":result["status"],"actual_exit_grades":dict(actual_grades),
                      "rejected_entry_transfer_grades":dict(wrong_grades),
                      "chart_replays":[{"dimension":r["Fourier_dimension"],"columns":r["literal_conditional_route_columns_checked"],"queries":r["total_queries_for8_R_modes"]} for r in chart_records]},indent=2))


if __name__=="__main__":main()
