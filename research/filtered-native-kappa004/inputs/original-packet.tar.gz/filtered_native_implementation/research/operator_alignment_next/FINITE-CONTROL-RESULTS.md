# Finite chronological feedback: exact constructive search

## What changed in the search

The earlier tangent obstruction does not extend automatically to finite controls. The new probe finds five actual chronological pairs whose quadratic term has nonzero value under that tangent functional. Every pair starts at the same single-use ordinary gate, immediately after the changed stage-zero FULL:

\[
\text{bank}_1\mathrel{+}=aP_0\text{bank}_0.
\]

Thus finite feedback is a real mathematical escape from the linear screen. No complete caller repair has been found in the bounded families below.

The normalized initial defect is

\[
E=(e_4+e_5)(e_1-e_2)^T\otimes(1-\zeta)P_0Q,
\qquad E^2=0.
\]

Here the subscripts denote the six caller banks, all six original input banks remain independent, and the six other stage signs remain independent. The distinguished first gate has dressed generator

\[
A=(e_4+e_5)(e_1-e_2)^T\otimes QP_0Q.
\]

The five later physical gates with nonzero quadratic functional are:

| Later cut | Gate | Normalized quadratic functional |
|---|---|---:|
| 3 | bank2 += b P0 bank1 | −14 |
| 4 or 5 | bank2 += b P0 bank1 | −14 |
| 5, 6 or 7 | bank2 += b P0 bank3 | −14 after the recorded sign normalization |
| 7 or 8 | bank0 += b P0 bank3 | −14 |
| 9 | bank0 += b P0 bank3 | +14 after the recorded sign normalization |

The first gate never recurs later with the same dressed generator. That fact matters: an abstract commutator identity does not license a second access to it.

## Exact search results

| Declared family | Search size | Result |
|---|---:|---|
| Four-cut loop with the same dressed A and B recurring at actual strictly ordered cuts | 7,621 pairings; 2,330 nonzero commutators; 2,085 exact Heisenberg truncations | Every finite coefficient is annihilated by the actual-sector dual |
| Two P0 transvections, before, after, or straddling the changed FULL | 61,543 placements | Five nonzero quadratic directions, no exact two-gate correction |
| Unique cut1 feedback followed by one linear nilpotent cleanup layer of later I/P0 transvections | 556 later classes | The exact required layer is outside the linear span |
| Unique cut1 feedback followed by two later I/P0 transvections | 182,254 placements | No solution even after allowing the seven multilinear coefficients to vary independently |
| Legal internal source feedback, then the previous three gates | 182,254 placements | 48 multilinear-span candidates, all inconsistent after the exact parameter-product constraints |

The last family first applies the authenticated stage-zero internal source gate. Its dressed generator is

\[
H=(e_4+e_5)(e_1-e_2)^T\otimes\zeta P_0Q.
\]

Since EH=HE=0, adding H changes the defect to the scalar-center residual E+H. This produces the48 relaxed candidates; it is a substantive change of the target equation. Their exact inverse equation is

\[
aA+bB+cC+abBA+acCA+bcCB+abcCBA=-(E+H).
\]

Each coefficient matrix has rank6 or7. Rank7 gives a unique incompatible coefficient vector. Rank6 gives one rational free parameter; the four product constraints are univariate polynomials whose exact rational gcd is1. Hence all48 fail even over the complex numbers. No numerical optimizer or small-parameter truncation enters this conclusion.

The chronology permits successive ordinary gates at the same cut. It does not permit returning to an earlier cut or rerunning a paid Gaussian job.

## Why the finite-sector calculation is physically valid

The source normalizers retain their actual linear Z phases. On width-two equal-frequency pairs,

\[
Q_i(w)=(-1)^{1+w\cdot q_i},\qquad D_0=\zeta(w)Q,
\qquad\zeta(w)=(-1)^{\operatorname{wt}(w)}.
\]

There are32 actual source frequencies at which the entire8-by-8 matrix R Q Rᵀ vanishes. Therefore P Q P=0 for source R5 and for the full eight-mode projector. Both values of zeta occur. Exact12-by-12 integer minors establish the independence of

\[
I,Q,P,PQ,QP,QPQ
\]

and their zeta multiples on those actual physical owner spaces. The determinants are16,777,216 for R5 and4,294,967,296 for all8, after the stated common scale4. This justifies discarding higher reduced P words at arbitrary finite word degree on this sector. The six external D signs are independently realized on disjoint stage axes, so the full64-character family remains present.

This certificate is `BALANCED-ACTUAL-SECTOR.json`. It is a necessary physical sector, not a proposed free Fourier adapter or an all-width positive construction.

The recently corrected phase-bearing generic native warp K_G is a different object from the source-K normalizers used here. These finite caller calculations use the latter's actual `G_rows` and `Z_mask`. No plain-permutation assumption about generic native warps is used.

## Interpretation and next constructive requirement

The search demonstrates finite curvature but does not complete its cleanup. The surviving direction appears at a single early occurrence, and the tested later ordinary gates cannot cancel all the accompanying independent-input effects. This supports prioritizing an actual new transport resource: a changed native interior, a usable field at another physical frame, or a mode carried through an already-paid later stage. It does not prove that unrestricted finite feedback is impossible.

The helper-clean source endpoints were independently verified in the existing native-word receipts. The new algebra retains every main-input column; its ordinary gates act only on the six main banks. A future positive still needs complete physical replay with all632 originals, source/helper independence, explicit owned storage, phases, and the query invoice. None of the finite-sector results is credited as a kappa improvement.

## Primary-source design input

Antoine Vinciguerra's [An Operator Approach to Register Programs for Catalytic Computing](https://arxiv.org/html/2609.18692v1), sections4.1–4.3, motivates an exactly closed operator loop whose intermediate output updates retain a useful term while arbitrary work registers are restored. Its polynomial instruction grammar is broader than this project's ordinary Gaussian grammar; no operation is imported as free.

Dinur, Liu and Zhang's [New Codes on High Dimensional Expanders](https://drops.dagstuhl.de/storage/00lipics/lipics-vol339-ccc2025/html/LIPIcs.CCC.2025.27/LIPIcs.CCC.2025.27.html) records the elementary transvection commutator relation. The probe uses its exact nilpotent form and enforces actual chronological recurrence, rather than relying on a formal BCH expansion.

## Reproduction

Run from the repository root:

```bash
python research/operator_alignment_next/balanced_actual_sector.py
python research/operator_alignment_next/finite_chronological_loops.py --include-pp
python research/operator_alignment_next/finite_two_gates.py
python research/operator_alignment_next/finite_preconditioned_cleanup.py
python research/operator_alignment_next/finite_three_gate_feedback.py
python research/operator_alignment_next/finite_three_gate_feedback.py --internal-scalarize
python research/operator_alignment_next/finite_polynomial_replay.py
```

All receipts include source and script hashes. The source-only module uses NumPy; the finite polynomial replay uses exact Python fractions and Euclidean polynomial gcd, with no symbolic-algebra dependency.
