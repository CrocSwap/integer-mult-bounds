#!/usr/bin/env python3
"""Exact phase-aware completion of local R caches by8 pre-center rank1 lifts.

The full native call is unchanged and all its center queries remain paid.
Only retained original-owned pre-center snapshots are lifted; original
rows and arbitrary helper inputs are never overwritten or initialized.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import pickle
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'research/retained_state_next'))
import consumer_kg_module as kg
sys.path.insert(0,str(HERE));import filtered_full_caller as fc


def conjugate(ce,op):
    out=ce.ident(op.n)
    for e in op.circuit:
        if e[0]=='P':gate=ce.perm(op.n,e[1])
        elif e[0]=='D':gate=ce.diag(op.n,e[1],tuple(-a%4 for a in e[2]))
        elif e[0]=='C':gate=ce.cgate(op.n,e[1],-e[2])
        elif e[0]=='X':gate=ce.xgate(op.n,e[1])
        elif e[0]=='phase':gate=ce.Op(op.n,ce.identity(op.n),[('phase',(-e[1])%4)])
        else:raise AssertionError(e)
        out=out.then(gate)
    return out


def main():
    started=time.monotonic();sp=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    bp=ROOT/'research/retained_state_next/CONSUMER-KG-MODULE-BACKWARD.pickle'
    ap=HERE/'AUGMENTED-RANK1-OBSERVERS.json'
    source=json.loads(gzip.decompress(sp.read_bytes()));c=source['canonical']
    group,module,data=kg.load_completed(bp);ce=group.ce
    seed=kg.PhaseGroup(ce,c,True)
    for letter,g in seed.letters.items():
        group.letters[letter]=group.intern(seed.ops[g],(letter,))
    candidates=json.loads(ap.read_text())['candidate_gathers']['no_center_ancestors']
    wanted={(term['after_event'],term['owner']) for row in candidates for term in row['gather']}
    rows=[{(i,0):F(1)} for i in range(632)]+[{}];cur=c['start'][:]+[None]
    captured={};paid=Counter();last=max(t for t,i in wanted)
    for pos,e in enumerate(source['programs']['backward']):
        typ=e[0];d=None
        if typ=='scalar':
            a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
            if a[0]=='clear':rows[d]={};cur[d]=f
            else:
                assert cur[d]==f
                if a[0] in ('add','copy'):
                    s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                    if a[0]=='copy':rows[d]=dict(rows[s])
                    else:rows[d]=fc.add(rows[d],fc.scale(rows[s],F(a[3],a[4])))
                else:rows[d]=fc.scale(rows[d],F(a[2],a[3]))
        elif typ=='warp':
            d=e[1][1]+(632 if e[1][0]=='C' else 0);assert cur[d]==e[3]
            rows[d]=group.left(group.letters[e[2]],rows[d]);cur[d]=e[4]
        elif typ=='climb':d=e[2];assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
        elif typ=='center':d=632+e[1];assert cur[d]==e[2];cur[d]=e[3];paid[e[4]]+=1
        else:assert typ in ('phase','adapter')
        if d is not None and (pos,d) in wanted:captured[pos,d]=dict(rows[d])
        if pos>=last:break
    assert set(captured)==wanted and paid[8]==0
    results=[];all_used=set();Fbar=ce.fourier(9).adjoint()
    for candidate in candidates:
        f=candidate['frame'];observation={}
        for term in candidate['gather']:
            observation=fc.add(observation,fc.scale(captured[term['after_event'],term['owner']],F(term['coefficient'])))
        Sf=conjugate(ce,ce.canonical_frame(9,c['frames'][f]));lift=Sf.adjoint().then(Fbar)
        grade=ce.rank([x for x,z,p in lift.tab[9:]]);assert grade==1
        factor,compiled=ce.lower_child(lift)
        assert factor['rank']==1 and compiled.tab==lift.tab and compiled.zero_state()==lift.zero_state()
        targets=[]
        for bank,offset in [('Y',112),('X',0)]:
            target={}
            for k,a in candidate['target_mode_combination'].items():
                for owner,b in enumerate(data['R'][int(k)]):
                    if b:target[owner+offset,0]=target.get((owner+offset,0),F(0))+F(a)*b
            contamination=fc.add(observation,fc.scale(target,-1))
            residual,recipe=module.solve(contamination)
            if not residual:
                for sid,g in recipe:all_used.add(g)
            targets.append({'bank':bank,'complete_operator_recovery':not residual,
                'residual_terms':len(residual),'cleanup_recipe_terms':len(recipe),
                'residual':[(i,g,str(a)) for (i,g),a in sorted(residual.items())],
                'cleanup_recipe':[{**module.snapshot_descriptions[sid],'snapshot_id':sid,
                    'left_operator':g,'subtract_coefficient':str(a)} for (sid,g),a in sorted(recipe.items())] if not residual else None})
        results.append({'input_frame':f,'target_modes':candidate['target_mode_combination'],
            'retained_precenter_input_gather':candidate['gather'],'new_query_rank':1,
            'physical_input_frame':'conjugate(S_f)','physical_output_frame':'conjugate(F9)',
            'query_factorization':factor,'query_literal_word':compiled.circuit,
            'absolute_phase_verified':True,'all_width_tensor_lift':'Scalar gather coefficients are outside tensor powers; every query/recoding operator is the literal tensor power.',
            'targets':targets})
        print('EXACT_LIFT',f,candidate['target_mode_combination'],[(t['bank'],t['complete_operator_recovery'],t['residual_terms']) for t in targets],flush=True)
    recodings={}
    for g in sorted(all_used):
        physical=Fbar.adjoint().then(group.ops[g]).then(Fbar)
        mon,record=ce.monomial(physical)
        assert mon.tab==physical.tab and mon.zero_state()==physical.zero_state()
        recodings[str(g)]={'logical_word':group.word[g],'literal_physical_word':mon.circuit,'monomial':record}
    out={'schema':'exact-precenter-rank1-plus-full-snapshot-local-mode-completion/v1',
        'source_sha256':sha256(sp.read_bytes()).hexdigest(),'side_module_sha256':sha256(bp.read_bytes()).hexdigest(),
        'augmentation_receipt_sha256':sha256(ap.read_bytes()).hexdigest(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'all632_originals_independent':True,'all408_helper_columns_retained':True,
        'rank8_query_ancestors_of_new_observations':0,'results':results,'ordinary_cleanup_recodings':recodings,
        'all_eight_local_modes_recovered':all(all(t['complete_operator_recovery'] for t in r['targets']) for r in results),
        'new_query_profile':{'1':len(results)},'native_query_profile_unchanged':True,
        'scope':'Constructive local R cache completion in an unchanged backward native call. Original eight rank8 center queries remain paid. No cross-stage R0 transport or center deletion is claimed by this local result.',
        'elapsed_seconds':time.monotonic()-started,'new_kappa_claimed':False}
    (HERE/'RANK1-SNAPSHOT-COMPLETION.json').write_text(json.dumps(out,indent=2)+'\n')
    (HERE/'RANK1-SNAPSHOT-ROWS.pickle').write_bytes(pickle.dumps({'captured':captured,'candidates':candidates},protocol=5))


if __name__=='__main__':main()
