#!/usr/bin/env python3
"""Exact finite first gate plus a subsequent nilpotent cleanup layer.

The first gate is the unique cut1 P-feedback class carrying all five
nonzero quadratic tangent escapes.  The later layer is solved linearly
only after including the exact product with the first gate and defect.
Any candidate is replayed as chronological finite gates; a linear span
solution alone is not a success.
"""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import finite_chronological_loops as fl
ar=fl.ar;ac=fl.ac;fc=fl.fc


def main():
    started=time.monotonic()
    path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    source=json.loads(path.read_text())['selected_p3_keep43']
    _,prefix,suffix=ac.source_matrices(source);targets=source['exact_diagonal_monomials']
    error,_=ar.it.tc.target_error(source,prefix,suffix,0)
    E=fl.endpoint_shift(fl.convert(ar.one_p(error,0,True)),targets)
    goal=fc.scale(E,-1);data=fl.classes(source,prefix,suffix,True)
    pd=[x for x in data if x['P_degree']==1];first=pd[35];A=first['operator']
    assert first['occurrences']==[{'cut':1,'time':2,'kind':'bank_transvection','write_bank':1,'read_bank':0,'ordinary_head':'P','physical_to_normal_scale':'1'}]
    # L(I+aA)(I+E)=I iff L=I-E-aA+aEA, using A²=E²=0.
    first_column=fc.add(A,fc.scale(fl.mul(E,A),-1))
    later=[]
    for idx,e in enumerate(data):
        occ=next((o for o in e['occurrences'] if o['time']>2),None)
        if occ is not None:later.append((dict(occ,global_class=idx),e['operator']))
    results=[]
    for balanced in (False,True):
        project=(lambda v:{k:c for k,c in v.items() if len(k[2])<=2}) if balanced else (lambda v:v)
        columns=[({'kind':'first_parameter'},project(first_column))]+[(d,project(v)) for d,v in later]
        basis=fc.sparse_basis(columns);recipe,residual=fc.solve(basis,project(goal))
        result={'balanced_actual_sector':balanced,'available_later_classes':len(later),'rank':len(basis),
                'linear_layer_solution':not residual,'residual_terms':len(residual)}
        if not residual:
            alpha=recipe.get(0,F(0));gates=[]
            for j,c in recipe.items():
                if j:gates.append((columns[j][0]['time'],j,c))
            gates.sort();state=fc.add({(i,i,(0,),fl.Z):F(1) for i in range(6)},E)
            state=project(fc.add(state,fc.scale(fl.mul(A,state),alpha)))
            for _,j,c in gates:state=project(fc.add(state,fc.scale(fl.mul(columns[j][1],state),c)))
            ident={(i,i,(0,),fl.Z):F(1) for i in range(6)}
            nonzero_products=[]
            for k,(_,j,c) in enumerate(gates):
                for _,h,d in gates[:k]:
                    prod=project(fl.mul(columns[j][1],columns[h][1]))
                    if prod:nonzero_products.append([h,j,len(prod)])
            result.update(first_coefficient=str(alpha),gates=[dict(columns[j][0],coefficient=str(c)) for _,j,c in gates],
                nonzero_layer_products=nonzero_products,exact_finite_endpoint_pass=state==ident,
                finite_residual_terms=len(fc.add(state,fc.scale(ident,-1))))
        results.append(result)
        print('PRECONDITION',balanced,'solution',not residual,'rank',len(basis),'residual',len(residual),flush=True)
    out={'schema':'finite-first-feedback-plus-linear-nilpotent-cleanup/v1','source_sha256':sha256(path.read_bytes()).hexdigest(),
         'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'first_gate':first['occurrences'][0],
         'exact_required_layer':'L=I-E-aA+aEA; no small-parameter truncation',
         'results':results,'all_six_main_originals_arbitrary':True,'all_six_external_D_characters_retained':True,
         'scope':'A single cut1 P0 feedback followed by a cleanup layer whose finite product has no uncompensated higher-order terms. A failed linear-layer relaxation excludes nilpotent one-layer cleanup, not arbitrary multi-layer controls.',
         'new_kappa_claimed':False,'elapsed_seconds':time.monotonic()-started}
    (HERE/'FINITE-PRECONDITIONED-CLEANUP.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
