#!/usr/bin/env python3
"""Exact source-bound probes for operator alignment with physical side information.

This file deliberately writes only to its own new research directory.  All
source data and the native phase compiler are imported read-only from the
previous, pinned experiments.  No rank reduction is counted as a query saving
without an explicit implementation and invoice.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from itertools import product
from math import comb
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "constructive_observers"))
import cross_column_routes as cc
import check_majorana_admission as ma


def parity(x):
    return x.bit_count() & 1


def add(a, b):
    return a[0]+b[0], a[1]+b[1]


def scale(a, n):
    return n*a[0], n*a[1]


def gaussian_power(a, n):
    ans = (1, 0)
    for _ in range(n):
        ans = cc.mul(ans, a)
    return ans


def bit_basis(ce, values):
    answer = []
    for v in values:
        if ce.rank(answer+[v]) > len(answer):
            answer.append(v)
    return answer


def census(ce, R, paulis):
    groups = defaultdict(list)
    for i in range(112):
        groups[tuple(k for k in range(8) if R[k][i])].append(i)
    records = []
    for support, ports in sorted(groups.items()):
        q = [paulis[i][0] for i in ports]
        labels = [paulis[i][0] | (paulis[i][1] << 9) for i in ports]
        anti = sum(parity(paulis[i][0] & paulis[j][1]) ^
                   parity(paulis[j][0] & paulis[i][1])
                   for a, i in enumerate(ports) for j in ports[a+1:])
        records.append({"support": list(support), "ports": ports,
                        "q_affine_rank": ce.rank([x ^ q[0] for x in q]),
                        "Pauli_affine_rank": ce.rank([x ^ labels[0] for x in labels]),
                        "Pauli_linear_rank": ce.rank(labels),
                        "anticommuting_pairs": anti})
    cc.need(len(records) == 14 and all(len(g["ports"]) == 8 for g in records),
            "Changed fourteen support classes")
    cc.need(all(g["q_affine_rank"] == 3 for g in records), "Lost affine3-flats")
    return records


def common_monomial_gauge(ce, paulis, ports):
    """C* P_i C = eps_i X_(1, s_i), literally including absolute phases."""
    first = paulis[ports[0]]
    differences = []
    for i in ports[1:]:
        p = ce.pmul(first, paulis[i])
        if ce.rank([q[0] for q in differences]+[p[0]]) > len(differences):
            differences.append(p)
    cc.need(len(differences) == 3, "Wrong group difference dimension")
    basis = [first]+differences
    cc.need(ce.rank([p[0] for p in basis]) == 4, "Affine flat contains zero")
    extension = ce.basis_extend([p[0] for p in basis], 9)
    products = []
    for mask in range(16):
        p = (0, 0, 0)
        for j in range(4):
            if mask >> j & 1:
                p = ce.pmul(p, basis[j])
        products.append(p)
    labels = []
    for i in ports:
        p = paulis[i]
        mask = next(j for j, q in enumerate(products) if q[:2] == p[:2])
        phase = (p[2]-products[mask][2]) % 4
        cc.need(mask & 1 and phase in (0, 2), "Non-real common-gauge sign")
        labels.append({"port": i, "s": mask >> 1, "epsilon": 1 if phase == 0 else -1})
    cc.need(sorted(r["s"] for r in labels) == list(range(8)), "Group misses an affine label")
    # C|u,c> = product_j P_basis[j]^u_j |anchor(c)>.
    table = []
    for address in range(512):
        anchor = 0
        for j in range(4, 9):
            if address >> j & 1:
                anchor ^= extension[j]
        q, z, p = products[address & 15]
        table.append((anchor ^ q, (p+2*parity(z & anchor)) % 4))
    cc.need(len({x for x, p in table}) == 512, "Gauge is not a permutation")
    checked = 0
    for rec in labels:
        q, z, p = paulis[rec["port"]]
        for address in range(512):
            x, phase0 = table[address]
            lhs = (x ^ q, (phase0+p+2*parity(z & x)) % 4)
            y, phase1 = table[address ^ (1+2*rec["s"])]
            rhs = (y, (phase1+(0 if rec["epsilon"] == 1 else 2)) % 4)
            cc.need(lhs == rhs, "Literal common gauge lost a source phase")
            checked += 1
    return {"basis_paulis": [list(x) for x in basis], "coordinate_basis": list(extension),
            "source_labels": labels, "literal_Pauli_columns_checked": checked,
            "table_sha256": sha256(json.dumps(table).encode()).hexdigest()}


def gaussian_qstar_entry(a, b, width):
    """Numerator, denominator2**width, of C(X)^(-tensor width)."""
    return cc.mul(gaussian_power((1, -1), width-(a ^ b).bit_count()),
                  gaussian_power((1, 1), (a ^ b).bit_count()))


def spectral_group_factorization(group, gauge, R):
    """Complete group identity in the common three-spectator Fourier chart.

    Every active column and every spectator frequency is checked at m=2,3.
    The common gauge is physically monomial; the spectator Fourier chart is
    PAID, and its cost is reported, rather than hidden as a basis change.
    """
    records = []
    for width in (2, 3):
        size = 1 << width
        count = 0
        for freqs in product(range(size), repeat=3):
            for rec in gauge["source_labels"]:
                delta = size-1 if rec["epsilon"] == -1 else 0
                for j in range(3):
                    if rec["s"] >> j & 1:
                        delta ^= freqs[j]
                prefix = cc.phase(-delta.bit_count())
                for b in range(size):
                    for a in range(size):
                        # Source inverse after exact common gauge and H_spect:
                        # each column has bI+a eps*(-1)^<s,xi> X.
                        lhs = (1, 0)
                        for t in range(width):
                            off = (a ^ b) >> t & 1
                            term = (1, 1) if off else (1, -1)
                            if off and (delta >> t & 1):
                                term = scale(term, -1)
                            lhs = cc.mul(lhs, term)
                        rhs = cc.mul(prefix, gaussian_qstar_entry(a, b ^ delta, width))
                        cc.need(lhs == rhs, "Conditional translation inverse phase failed")
                        # All four demanded rows, all source ports, no target replacement.
                        for k in group["support"]:
                            cc.need(scale(lhs, int(R[k][rec["port"]])) ==
                                    scale(rhs, int(R[k][rec["port"]])), "R row changed")
                            count += 1
        records.append({"width": width, "full_nontrivial_group_coordinates": 16**width,
                        "spectator_multiplicity_in_actual_native_space": 32**width,
                        "literal_R_weighted_entries_checked": count})
    return {"status": "EXACT_CONDITIONAL_FOUR_QUERY_GROUP_FACTOR",
            "requires_three_common_spectator_Fourier_charts": True,
            "uniform_formula": "U_i^{-tensor m}=H_spect * Q_a^* * (-i)^wt(delta_i(xi)) X_delta_i(xi) * H_spect",
            "delta": "delta_i(xi)=(epsilon_i<0 ? allones : 0) xor XOR_{j:s_ij=1} xi_j",
            "full_R_rows": group["support"], "ports": group["ports"],
            "finite_replays": records,
            "invoice_rank_one_array_equivalents": {
                "fresh_input_spectator_Fourier": 8*3,
                "four_coded_common_heads": 4,
                "fresh_output_spectator_inverse_Fourier": 4*3,
                "total": 40, "direct_eight_source_heads": 8,
                "if_both_spectator_boundaries_are_already_free": 4},
            "admission": "Common gauge is phase-correct monomial. Conditional translation is a width-dependent linear address map, and its phase is a weight-mod4 scan. Fresh spectral charts cost36 extra query equivalents; no entrance saving."}


def diagonal_side_correction(paulis, R):
    """Verify U_i*^tensor4 w4 and a bounded-norm rank-one bypass of w4.

    This is a genuine whole-width, dense rank-one ordinary side correction,
    not a sum of a fixed number of repeated-base monomials.  A larger 512-
    dimensional equality-support test below prevents mistaking this one-line
    success for full target recovery.
    """
    checked, support_sizes = 0, set()
    targets = []
    for i, (q, z, p) in enumerate(paulis):
        cc.need(p == 0, "This compact coefficient formula uses actual p=0 sources")
        accum = {}
        for anchor in range(512):
            theta = 1-2*parity(z & anchor)
            for mask in range(16):
                dest = tuple(anchor ^ (q if mask >> t & 1 else 0) for t in range(4))
                num = cc.mul(gaussian_power((1, -1), 4-mask.bit_count()),
                             gaussian_power((theta, theta), mask.bit_count()))
                accum[dest] = add(accum.get(dest, (0, 0)), num)
        accum = {key: value for key, value in accum.items() if value != (0, 0)}
        expected = {}
        for anchor in range(512):
            expected[(anchor,)*4] = (-8, 0)
            for subset in (3, 5, 9):
                dest = tuple(anchor ^ (q if subset >> t & 1 else 0) for t in range(4))
                expected[dest] = (8, 0)
        cc.need(accum == expected, "The whole-width rank-one side correction lost a phase")
        support_sizes.add(len(accum))
        checked += 512*16
        k = next(k for k in range(8) if R[k][i])
        targets.append((k, (0, 0, q, q)))
    # Source minor at equality support E4: for each q-orbit {x,x+q},
    # target patterns 0011 and 0001 give 1/4 [[1,1],[-i,i]].
    # It is invertible, determinant i/8. No other q_j contributes.
    pair_minor_numerators = [[(1, 0), (1, 0)], [(0, -1), (0, 1)]]
    determinant = add(cc.mul(pair_minor_numerators[0][0], pair_minor_numerators[1][1]),
                      scale(cc.mul(pair_minor_numerators[0][1], pair_minor_numerators[1][0]), -1))
    cc.need(determinant == (0, 2), "Wrong equality-support pair minor")
    return {"status": "EXACT_WHOLE_WIDTH_RANK_ONE_SIDE_BYPASS_AND_LARGER_RESIDUAL_GATE",
            "literal_source_head_tensor_terms_checked": checked,
            "per_port_output_support_at_width4": list(support_sizes),
            "formula": "w=w4^{tensor t}; v_i=U_i^{-*}w; B_i=v_i w^*/512^t; B_i w=v_i; ||B_i||2=1",
            "gather": "c_i=2^{-9t} sum_{x1,...,xt} X_i[x1,x1,x1,x1,...,xt,xt,xt,xt]",
            "scatter": "For each block, coefficient is -1/2 if all4 addresses agree; +1/2 for two copies each of y,y+q_i; zero otherwise. Multiply block coefficients, then add R_ki*c_i*v_i.",
            "width_lift": "All m=4t, t>=1. Formula factors blockwise with complete source phases verified at t=1.",
            "ordinary_arithmetic": "At most one sequential scan per source gather and one scan per demanded source-output pair; 112 gathers and448 weighted scatters. No recursive query. Address-predicate compiler and scalar-grid cost must be charged.",
            "inverse": "Negate the output addition; physical original X owners remain unchanged.",
            "raw_dual": "Gather v_i^T from each output combination and scatter w/512^t into source i; transpose retains literal Gaussian phase.",
            "old_112_point_minor_after_correction": "identically zero",
            "larger_gate": {
                "subspace": "E4=span{|x,x,x,x>:x in[512]}",
                "dimension_per_source": 512,
                "full_R_target_rank_on_112_E4_sources": 112*512,
                "rank_after_112_rank_one_corrections_at_least": 112*511,
                "observation_rank_each_repeated_base_family_at_m4_at_most": 512,
                "minimum_observations_after_these_corrections": (112*511+511)//512,
                "pair_minor": "(1/4)[[1,1],[-i,i]], determinant i/8; actual z phases only multiply nonzero rows by signs",
                "interpretation": "The new correction kills the old witness exactly but leaves a larger complete-target obstruction. This is not a useful112-to18 construction."}}


def cheap_spectral_baselines():
    answer = []
    for width in range(1, 25):
        counts = [sum(comb(width, j) for j in range(r, width+1, 4)) for r in range(4)]
        residual = min(counts[0], counts[2])+min(counts[1], counts[3])
        answer.append({"width": width, "active_dimension": 2**width,
                       "eigenvalue_residue_multiplicities": counts,
                       "best_residual_rank_for_B=cI+dPglobal": residual,
                       "residual_fraction": str(Fraction(residual, 2**width))})
    return {"status": "EXACT_RANK_COUNTS_ONLY_NOT_QUERY_COUNTS", "rows": answer,
            "formula": "U_i^{-tensor m} eigenvalue=(-i)^j; Pglobal eigenvalue=(-1)^j. Choose one eigenvalue in each parity class.",
            "cost_warning": "B has two ordinary monomial terms but is repeated-base. A cheap factorization of its residual has not been established."}


def main():
    ce, canonical, normals, R, routes = cc.source_data()
    paulis = ma.source_paulis(ce, canonical)
    groups = census(ce, R, paulis)
    commuting = [g for g in groups if g["anticommuting_pairs"] == 0]
    cc.need(len(commuting) == 7, "Changed commuting-group census")
    gauges = []
    for group in commuting:
        gauge = common_monomial_gauge(ce, paulis, group["ports"])
        gauge["support"] = group["support"]
        gauges.append(gauge)
    # One complete8-port group is replayed in detail. The same formula applies
    # to all seven verified common gauges.
    factor = spectral_group_factorization(commuting[0], gauges[0], R)
    result = {"status": "EXACT_SOURCE_GROUP_FACTOR_AND_SIDE_INFORMATION_PROBES_COMPLETE",
              "source_manifest": "../constructive_observers/SOURCES.json",
              "group_census": groups, "common_monomial_gauges": gauges,
              "conditional_group_factor": factor,
              "whole_width_side_correction": diagonal_side_correction(paulis, R),
              "two_term_spectral_baseline": cheap_spectral_baselines(),
              "kappa_improvement_claimed": False}
    (HERE / "RESULT.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"status": result["status"], "commuting_groups": len(gauges),
                      "group_replays": factor["finite_replays"],
                      "group_fresh_query_equivalents": 40,
                      "group_conditional_query_equivalents": 4,
                      "side_correction_old_minor": "zero",
                      "larger_gate_minimum_observations": 112}, indent=2))


if __name__ == "__main__":
    main()
