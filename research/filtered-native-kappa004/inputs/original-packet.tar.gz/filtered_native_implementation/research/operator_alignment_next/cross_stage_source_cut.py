#!/usr/bin/env python3
"""Bind foreign-mode observer to actual early-Y native source chronology."""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'research/retained_state_next'));import consumer_kg_module as kg
sys.path.insert(0,str(HERE));import filtered_full_caller as fc


def main():
    sp=ROOT/'research/retained_state_next/RAW-DUAL-LATE-X-WORD.json.gz'
    rp=ROOT/'research/retained_state_next/SYMMETRIC-CAUSAL-PAIR.json'
    cp=HERE/'CROSS-STAGE-RANK1-OBSERVER.json'
    source=json.loads(gzip.decompress(sp.read_bytes()));receipt=json.loads(rp.read_text())
    c=source['canonical'];extra=source['owned_extra_slots'];cut=receipt['receipt']['late_X_admission']['event']
    ce=kg.load('foreign_cut_ce',ROOT/'upstream/research/coded-native-caller/clifford_exact.py')
    group=kg.PhaseGroup(ce,c,True);rows=[{(i,0):F(1)} for i in range(632)]+[{} for _ in range(1+extra)]
    cur=c['start'][:]+[None]*(1+extra);paid=Counter();read_X=set();read_H=set()
    def ref(x):return x[1]+(632 if x[0]=='C' else 0)
    def read(i):
        if i<112:read_X.add(i)
        if 224<=i<632:read_H.add(i)
    for pos,e in enumerate(source['program'][:cut+1]):
        typ=e[0]
        if typ=='scalar':
            a,f=e[1:];d=ref(a[1])
            if a[0]=='clear':rows[d]={};cur[d]=f
            else:
                assert cur[d]==f
                if a[0] in ('add','copy'):
                    s=ref(a[2]);assert cur[s]==f;read(s)
                    if a[0]=='copy':rows[d]=dict(rows[s])
                    else:read(d);rows[d]=fc.add(rows[d],fc.scale(rows[s],F(a[3],a[4])))
                else:read(d);rows[d]=fc.scale(rows[d],F(a[2],a[3]))
        elif typ=='warp':
            d=ref(e[1]);read(d);assert cur[d]==e[3]
            rows[d]=group.left(group.letters[e[2]],rows[d]);cur[d]=e[4]
        elif typ=='climb':d=e[2];read(d);assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
        elif typ=='center':d=632+e[1];read(d);assert cur[d]==e[2];cur[d]=e[3];paid[e[4]]+=1
        else:assert typ in ('phase','adapter'),e
    assert not read_X and not read_H
    assert all(rows[i]=={(i,0):F(1)} and cur[i]==c['start'][i] for i in list(range(112))+list(range(224,632)))
    assert all(rows[i]=={(i,0):F(1)} and cur[i]==c['final'][i] for i in range(112,224))
    out={'schema':'actual-early-source-binding-for-cross-stage-mode-observer/v1',
        'source_word_sha256':sha256(sp.read_bytes()).hexdigest(),'source_receipt_sha256':sha256(rp.read_bytes()).hexdigest(),
        'observer_receipt_sha256':sha256(cp.read_bytes()).hexdigest(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'after_event':cut,'physical_slots':len(rows),'all112_native_Y_outputs_exactly_complete':True,
        'all112_original_X_unread_unchanged':True,'all408_original_helpers_unread_unchanged':True,
        'all_phase_bearing_native_warps_replayed':True,'paid_profile_before_cut':dict(paid),
        'available_operation':'Execute any chosen foreign R_k gather using the emitted112 ordinary nativeY exit maps; optionally pay one rank1 Q_mode head, then use its result before the originalX consumer.',
        'original_centers':'The current source-first word has scalar-center-free consumers later. Restoring the original center queries after this Y producer does not alter the verified early source cut.',
        'scope':'Chronological availability and exact source-row identity. It does not prove a caller correction, and each mode head remains a fresh paid query.',
        'new_kappa_claimed':False}
    (HERE/'CROSS-STAGE-SOURCE-CUT.json').write_text(json.dumps(out,indent=2)+'\n')
    print('CROSS_STAGE_SOURCE_CUT','event',cut,'allY112','Xunread',not read_X,'Hunread',not read_H,'paid',dict(paid))


if __name__=='__main__':main()
