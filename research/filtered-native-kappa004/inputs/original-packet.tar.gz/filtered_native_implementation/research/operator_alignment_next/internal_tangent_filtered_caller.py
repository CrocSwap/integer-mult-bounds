#!/usr/bin/env python3
"""Source-first internal feedback plus all evolving-bank tangent controls.

The new control is an actual chronological source-to-opposite-input gate:
    opposite_input += Q^a P_s Q^b (D_t source_input), a,b in {0,2}.
It contributes suffix[t+1] D_t Q^a P_s Q^b D_t prefix[t].
No endpoint-only decoding or hypothetical odd-Q gauge is inserted.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import tangent_filtered_caller as tc
fc=tc.fc;ac=tc.ac


def controls(source,prefix,suffix,stage,use_sector=False,internal='changed'):
    columns=[]
    for cut in range(len(prefix)):
        for write_bank in range(6):
            for read_bank in range(6):
                for a in (0,2):
                    for b in (0,2):
                        op=ac.p_outer([row[write_bank] for row in suffix[cut]],
                            prefix[cut][read_bank],stage,qleft=a,qright=b)
                        columns.append(({'kind':'between_events','cut':cut,
                            'write_bank':write_bank,'read_bank':read_bank,
                            'left_Q_power':a,'right_Q_power':b},
                            tc.sector(op,stage,use_sector)))
    for at,event in enumerate(source['physical_events']):
        if event[0]!='LOCAL':continue
        _,t,pair,back=event
        if internal=='changed' and t!=stage:continue
        if internal=='none':continue
        x=2*pair;dst,src=(x,x+1) if back else (x+1,x)
        left=[row[dst] for row in suffix[at+1]]
        right=[ac.poly_mul(ac.mono(stages=[t]),p) for p in prefix[at][src]]
        dl=list(ac.ZERO_D);dl[t]=1
        for a in (0,2):
            for b in (0,2):
                op=ac.p_outer(left,right,stage,qleft=a,qright=b,dleft=tuple(dl))
                columns.append(({'kind':'internal_source_to_opposite_input',
                    'event':at,'source_stage':t,'write_bank':dst,'read_bank':src,
                    'left_Q_power':a,'right_Q_power':b},
                    tc.sector(op,stage,use_sector)))
    return columns


def encode(key):
    i,j,a,b,d=key
    return {'output_bank':i,'input_bank':j,'Q_left':a,'Q_right':b,
            'D_exponents':list(d)}


def annihilator(basis,goal):
    """Exact dual certificate to sparse column-span non-membership."""
    _,residual=fc.solve(basis,goal)
    if not residual:return None
    missing=min(residual);assert missing not in basis
    weight={missing:F(1)}
    for pivot in sorted((p for p in basis if p<missing),reverse=True):
        row,_=basis[pivot]
        value=-sum((c*weight.get(k,F(0)) for k,c in row.items() if k!=pivot),F(0))
        if value:weight[pivot]=value
    assert all(sum((c*weight.get(k,F(0)) for k,c in row.items()),F(0))==0
               for row,_ in basis.values())
    evaluation=sum((c*weight.get(k,F(0)) for k,c in goal.items()),F(0))
    assert evaluation==residual[missing] and evaluation
    return weight,evaluation


def solve_stage(source,prefix,suffix,stage,use_sector=False,internal='changed'):
    error,changed=tc.target_error(source,prefix,suffix,stage)
    error=tc.sector(error,stage,use_sector);goal=fc.scale(error,-1)
    columns=controls(source,prefix,suffix,stage,use_sector,internal)
    basis=fc.sparse_basis(columns);recipe,residual=fc.solve(basis,goal)
    certificate=None
    if not residual:
        check=dict(error)
        for j,c in recipe.items():check=fc.add(check,fc.scale(columns[j][1],c))
        assert not check
    else:
        weight,evaluation=annihilator(basis,goal)
        assert all(sum((c*weight.get(k,F(0)) for k,c in col.items()),F(0))==0
                   for _,col in columns)
        certificate={'control_columns_annihilated':len(columns),
            'goal_evaluation':str(evaluation),'support_size':len(weight),
            'functional':[{'coefficient':str(c),**encode(k)} for k,c in sorted(weight.items())]}
    return {'stage':stage,'changed_event':changed,'internal_controls_at':internal,
        'central_involutions_plus_specialization':use_sector,
        'all_six_original_banks_arbitrary':True,
        'candidate_insertions':len(columns),'exact_tangent_span_rank':len(basis),
        'tangent_solution_found':not residual,'residual_terms':len(residual),
        'solution':[{'coefficient':str(c),**columns[j][0]} for j,c in sorted(recipe.items())] if not residual else [],
        'exact_dual_nonmembership_certificate':certificate,
        'scope':'One-P infinitesimal controls Q^(0 or2) P_s Q^(0 or2), both between every event and at each declared true source-first cut. Universal one-P algebra with F_s P_s=P_s F_s. This is not a complete actual finite-width ordinary-algebra obstruction.',
        'chronology':'The internal source is D_t times the unchanged source input and is produced before the opposite input is consumed. Its feedback enters that opposite input before the same D_t, so its linear response has a D_t on both sides of the ordinary head.',
        'finite_gate_warning':'Only tangent span is tested. A successful tangent recipe would require finite replay including all interactions.'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stages',default='0')
    ap.add_argument('--sector',action='store_true')
    ap.add_argument('--internal',choices=['changed','all','none'],default='changed')
    args=ap.parse_args()
    path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    source=json.loads(path.read_text())['selected_p3_keep43'];_,prefix,suffix=ac.source_matrices(source)
    started=time.monotonic();results=[]
    for stage in map(int,args.stages.split(',')):
        result=solve_stage(source,prefix,suffix,stage,args.sector,args.internal);results.append(result)
        print('INTERNAL_TANGENT',stage,'scope',args.internal,'sector',args.sector,
            'solution',result['tangent_solution_found'],'rank',result['exact_tangent_span_rank'],
            'residual',result['residual_terms'],'elapsed',round(time.monotonic()-started,3),flush=True)
    stem='INTERNAL-TANGENT-'+args.internal.upper()+('-SECTOR' if args.sector else '')
    (HERE/(stem+'.json')).write_text(json.dumps({'status':'EXACT_INTERNAL_SOURCE_FIRST_TANGENT_SCREEN',
        'source_sha256':sha256(path.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'results':results,'elapsed_seconds':time.monotonic()-started,
        'no_new_kappa_claimed':True},indent=2)+'\n')


if __name__=='__main__':main()
