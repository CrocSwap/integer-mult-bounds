#!/usr/bin/env python3
"""Resolve the48 scalarized three-gate multilinear span candidates exactly."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as F
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import finite_chronological_loops as fl
from finite_three_gate_feedback import balanced


def trim(p):
    p=list(p)
    while p and not p[-1]:p.pop()
    return p


def padd(a,b,sign=1):
    return trim([(a[i] if i<len(a) else F(0))+sign*(b[i] if i<len(b) else F(0)) for i in range(max(len(a),len(b)))])


def pmul(a,b):
    if not a or not b:return []
    out=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return trim(out)


def pgcd(a,b):
    a=trim(a);b=trim(b)
    while b:
        r=list(a)
        while len(r)>=len(b):
            scale=r[-1]/b[-1];shift=len(r)-len(b)
            for i,x in enumerate(b):r[i+shift]-=scale*x
            r=trim(r)
        a,b=b,r
    return [x/a[-1] for x in a] if a else []


def main():
    candidate_path=HERE/'FINITE-SCALARIZED-THREE-GATE-FEEDBACK.json'
    source=json.loads((ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json').read_text())['selected_p3_keep43']
    _,prefix,suffix=fl.ac.source_matrices(source);data=fl.classes(source,prefix,suffix,True)
    A=[x for x in data if x['P_degree']==1][35]['operator']
    error,_=fl.ar.it.tc.target_error(source,prefix,suffix,0)
    E=fl.endpoint_shift(fl.convert(fl.ar.one_p(error,0,True)),source['exact_diagonal_monomials'])
    H=next(e['operator'] for e in data if e['P_degree']==1 and any(o['kind']=='internal_source_to_opposite_input' and o['source_stage']==0 for o in e['occurrences']))
    goal=fl.fc.scale(fl.fc.add(E,H),-1)
    results=[]
    for row in json.loads(candidate_path.read_text())['linear_multilinear_relaxation_candidates']:
        B=data[row['B_class']]['operator'];C=data[row['C_class']]['operator']
        BA=balanced(fl.mul(B,A));CA=balanced(fl.mul(C,A));CB=balanced(fl.mul(C,B));CBA=balanced(fl.mul(C,BA))
        vectors=[A,B,C,BA,CA,CB,CBA];columns=list(enumerate(vectors))
        basis=fl.fc.sparse_basis(columns);solution,residual=fl.fc.solve(basis,goal);assert not residual
        kernel=None
        for j,v in enumerate(vectors):
            previous=fl.fc.sparse_basis(columns[:j]);rep,rem=fl.fc.solve(previous,v)
            if not rem:
                assert kernel is None
                kernel={j:F(1)}
                for k,x in rep.items():kernel[k]=-x
        assert (kernel is not None)==(len(basis)==6)
        polys=[[solution.get(j,F(0)),kernel.get(j,F(0)) if kernel else F(0)] for j in range(7)]
        equations=[padd(polys[3],pmul(polys[0],polys[1]),-1),
                   padd(polys[4],pmul(polys[0],polys[2]),-1),
                   padd(polys[5],pmul(polys[1],polys[2]),-1),
                   padd(polys[6],pmul(pmul(polys[0],polys[1]),polys[2]),-1)]
        gcd=[]
        for eq in equations:gcd=pgcd(gcd,eq)
        unit=gcd==[F(1)]
        results.append({'B_class':row['B_class'],'C_class':row['C_class'],
                        'affine_multilinear_solution':[str(solution.get(j,F(0))) for j in range(7)],
                        'affine_null_direction':[str(kernel.get(j,F(0))) for j in range(7)] if kernel else None,
                        'compatibility_polynomials_in_free_parameter':[[str(x) for x in p] for p in equations],
                        'exact_polynomial_gcd':[str(x) for x in gcd],
                        'unit_ideal':unit})
    out={'schema':'finite-scalarized-three-feedback-polynomial-replay/v1',
         'candidate_receipt_sha256':sha256(candidate_path.read_bytes()).hexdigest(),
         'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'candidates':results,
         'all_inconsistent_over_complex_numbers':all(r['unit_ideal'] for r in results),
         'scope':'The48 balanced-sector linear-relaxation candidates from the explicit four-action family: authenticated internal scalarizing feedback, unique cut1 P feedback, and two later I/P transvections.',
         'new_kappa_claimed':False}
    (HERE/'FINITE-SCALARIZED-POLYNOMIAL-REPLAY.json').write_text(json.dumps(out,indent=2)+'\n')
    print('POLYNOMIAL_REPLAY',len(results),'unit_ideals',sum(r['unit_ideal'] for r in results))


if __name__=='__main__':main()
