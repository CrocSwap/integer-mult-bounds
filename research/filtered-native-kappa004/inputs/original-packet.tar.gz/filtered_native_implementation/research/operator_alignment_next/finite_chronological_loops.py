#!/usr/bin/env python3
"""Finite chronological commutator loops in the literal p3 timeline.

All gates are ordinary I/P0 bank transvections at actual event boundaries
or the authenticated internal source-first cut.  Dressed generators must
recur at the actual four cuts: no formal ability to revisit a paid query
is assumed.  The first probe uses the actual equal-width2 frequency sector
but retains all six independent external D signs.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import actual_tangent_reachability as ar
ac=ar.ac;fc=ar.fc
Z=(0,)*7


def canonical(q):
    q=[a%2 for a in q];factor=1
    while len(q)>2:
        k=next((j for j in range(1,len(q)-1) if q[j]==0),None)
        if k is None:break
        q.pop(k);factor*=-14
    return tuple(q),factor


def convert(vector):
    return {(i,j,q,(z,)+other):c for (i,j,q,z,other),c in vector.items()}


def mul(a,b):
    out=defaultdict(F);right=defaultdict(list)
    for (k,j,r,e),v in b.items():right[k].append((j,r,e,v))
    for (i,k,q,d),c in a.items():
        for j,r,e,v in right[k]:
            word,factor=canonical(q[:-1]+(q[-1]+r[0],)+r[1:])
            out[i,j,word,tuple(x^y for x,y in zip(d,e))]+=c*v*factor
    return {k:c for k,c in out.items() if c}


def endpoint_shift(vector,targets):
    out=defaultdict(F)
    for (i,j,q,d),c in vector.items():
        target=targets[i];shift=(target[0]+target[1])%2
        word=(q[0]^shift,)+q[1:]
        exponents=tuple((target[t+1]%2)^d[t] for t in range(7))
        out[i,j,word,exponents]+=c
    return {k:c for k,c in out.items() if c}


def proportional(a,b):
    if not a or set(a)!=set(b):return None
    k=min(a);ratio=a[k]/b[k]
    return ratio if all(a[t]==ratio*b[t] for t in a) else None


def classes(source,prefix,suffix,include_initial=False):
    grouped={};targets=source['exact_diagonal_monomials']
    def append(desc,v):
        if not v:return
        h=endpoint_shift(convert(v),targets);first=h[min(h)]
        normal=fc.scale(h,1/first);key=tuple(sorted(normal.items()))
        if key not in grouped:grouped[key]={'operator':normal,'occurrences':[]}
        grouped[key]['occurrences'].append(dict(desc,physical_to_normal_scale=str(first)))
    for cut in range(0 if include_initial else 1,len(prefix)):
        for write in range(6):
            for read in range(6):
                if write==read:continue
                left=[row[write] for row in suffix[cut]];right=prefix[cut][read]
                for name,v in ar.operators(left,right,0,True):
                    append({'cut':cut,'time':2*cut,'kind':'bank_transvection',
                        'write_bank':write,'read_bank':read,'ordinary_head':name},v)
    for at,event in enumerate(source['physical_events']):
        if event[0]!='LOCAL':continue
        _,t,pair,back=event;x=2*pair;dst,src=(x,x+1) if back else (x+1,x)
        left=[ac.poly_mul(row[dst],ac.mono(stages=[t])) for row in suffix[at+1]]
        right=[ac.poly_mul(ac.mono(stages=[t]),p) for p in prefix[at][src]]
        for name,v in ar.operators(left,right,0,True):
            append({'cut':at,'time':2*at+1,'kind':'internal_source_to_opposite_input',
                'write_bank':dst,'read_bank':src,'source_stage':t,'ordinary_head':name},v)
    out=[]
    for entry in grouped.values():
        entry['occurrences'].sort(key=lambda r:r['time'])
        entry['P_degree']=len(next(iter(entry['operator']))[2])-1
        assert not mul(entry['operator'],entry['operator'])
        out.append(entry)
    return out


def chronology(a,b):
    aa=a['occurrences'];bb=b['occurrences']
    # Strict actual times.  This avoids pretending the earlier dressed
    # generator is available again without a real chronological recurrence.
    for first in aa:
        for second in bb:
            if second['time']<=first['time']:continue
            third=next((r for r in aa if r['time']>second['time']),None)
            if third is None:continue
            fourth=next((r for r in bb if r['time']>third['time']),None)
            if fourth is not None:return [first,second,third,fourth]
    return None


def summarize_operator(v):
    return [{'output_bank':i,'input_bank':j,'Q_powers_separated_by_P':list(q),
             'stage_sign_exponents':list(d),'coefficient':str(c)}
            for (i,j,q,d),c in sorted(v.items())]


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--include-pp',action='store_true');args=ap.parse_args()
    start=time.monotonic();path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    source=json.loads(path.read_text())['selected_p3_keep43'];_,prefix,suffix=ac.source_matrices(source)
    error,_=ar.it.tc.target_error(source,prefix,suffix,0)
    error=endpoint_shift(convert(ar.one_p(error,0,True)),source['exact_diagonal_monomials'])
    assert not mul(error,error);goal=fc.scale(error,-1)
    data=classes(source,prefix,suffix)
    recurrent=[(i,e) for i,e in enumerate(data) if len({r['time'] for r in e['occurrences']})>1]
    old=json.loads((HERE/'ARBITRARY-OWNER-TANGENT.json').read_text())['results'][0]['functional']
    weight={(r['output_bank'],r['input_bank'],tuple(r['Q_powers_separated_by_P']),
             (r['source_zeta_power'],)+tuple(r['other_stage_sign_powers'])):F(r['coefficient']) for r in old}
    def dual(v):
        v=endpoint_shift(v,source['exact_diagonal_monomials'])
        return sum((c*weight.get(k,F(0)) for k,c in v.items()),F(0))
    assert dual(goal)==-1
    tested=0;nonzero=0;nilpotent=0;escapes=[];solutions=[];coefficients=[]
    for ia,a in recurrent:
        for ib,b in recurrent:
            if ia==ib or a['P_degree']+b['P_degree']==0:continue
            if not args.include_pp and a['P_degree']+b['P_degree']>1:continue
            times=chronology(a,b)
            if times is None:continue
            tested+=1;A=a['operator'];B=b['operator'];AB=mul(A,B);BA=mul(B,A)
            comm=fc.add(BA,fc.scale(AB,-1))
            if not comm:continue
            nonzero+=1;ABA=mul(AB,A);BAB=mul(BA,B);BABA=mul(BA,BA)
            heisenberg=not ABA and not BAB
            if heisenberg:nilpotent+=1
            # Exact four-factor product:
            # (I-bB)(I-aA)(I+bB)(I+aA)
            # =I+ab(BA-AB)-a²b ABA+ab² BAB+a²b² BABA.
            for name,v in [('ab',comm),('a2b',fc.scale(ABA,-1)),('ab2',BAB),('a2b2',BABA)]:
                if v:
                    ev=dual(v)
                    coefficients.append(({'class_A':ia,'class_B':ib,'parameter_monomial':name},v))
                    if ev and len(escapes)<20:
                        escapes.append({'class_A':ia,'class_B':ib,'parameter_monomial':name,
                            'old_dual_evaluation':str(ev),'heisenberg_truncation_exact':heisenberg,
                            'chronological_occurrences':times,'coefficient_operator':summarize_operator(v)})
            ratio=proportional(comm,goal) if heisenberg else None
            if ratio is not None:
                # Set a=1,b=1/ratio, then replay the entire finite normalized
                # endpoint including the changed FULL error, not just ab.
                alpha=F(1);beta=1/ratio
                identity={(i,i,(0,),Z):F(1) for i in range(6)}
                endpoint=fc.add(identity,error)
                for h,c in [(A,alpha),(B,beta),(A,-alpha),(B,-beta)]:
                    endpoint=fc.add(endpoint,fc.scale(mul(h,endpoint),c))
                assert endpoint==identity
                gates=[]
                for occurrence,c in zip(times,[alpha,beta,-alpha,-beta]):
                    gates.append(dict(occurrence,coefficient=str(c/F(occurrence['physical_to_normal_scale']))))
                solutions.append({'class_A':ia,'class_B':ib,'gates':gates,
                    'all_six_original_banks_restored_exactly':True,
                    'actual_width2_sector_only':True,'requires_all_width_lift':True})
    print('FINITE_LOOPS','classes',len(data),'recurrent',len(recurrent),'tested',tested,
        'nonzero',nonzero,'heisenberg',nilpotent,'dual_escapes',len(escapes),
        'solutions',len(solutions),'seconds',round(time.monotonic()-start,3),flush=True)
    out={'schema':'actual-timeline-finite-four-transvection-loop/v1',
        'source_sha256':sha256(path.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'changed_stage':0,'all_six_original_banks_arbitrary':True,
        'all_six_external_stage_signs_retained':True,'include_PP_loops':args.include_pp,
        'dressed_generator_classes':len(data),'chronologically_recurrent_classes':len(recurrent),
        'four_cut_pairings_tested':tested,'nonzero_commutators':nonzero,
        'exact_Heisenberg_truncations':nilpotent,'old_dual_escapes':escapes,
        'exact_finite_sector_solutions':solutions,
        'coefficient_count':len(coefficients),
        'all_loop_coefficients_annihilated_by_old_dual':all(dual(v)==0 for _,v in coefficients),
        'ordinary_heads':'I or P0, on off-diagonal bank transvections; P0=-14Pi0. The same dressed generator and its inverse must recur at actual strictly ordered cuts, including authenticated internal source cuts.',
        'operator_relations_used':['Q²=I on actual width2 equal Fourier pairs','P0²=-14P0','All seven stage signs are independent involutions; D0=zeta Q'],
        'actual_arbitrary_degree_validation':{'certificate':'BALANCED-ACTUAL-SECTOR.json',
            'sha256':sha256((HERE/'BALANCED-ACTUAL-SECTOR.json').read_bytes()).hexdigest(),
            'argument':'At32 actual source frequencies, R Q R^T=0 for all8, hence P Q P=0. All higher reducedP words vanish. Exact12-function integer minors prove thatI,Q and thefourone-P words, eachwith1/zeta, are independent. Thus the recordeddual is an actual operatorfunctional for every finitecoefficient above, includingP/P loops.'},
        'chronology_guard':'All gates lie after the changed stage0 event, except its own source-first opposite-input gate. That gate has the same source bank as the filtered defect, so it commutes with the native rank-one defect; explicit replay is still required for a positive.',
        'scope':'This exact recurring-generator four-gate family, not arbitrary finite feedback or nonlinear controls. Any positive sector recipe still needs actual full-operator and source-word lift.',
        'literature_inspiration':[{'title':'An Operator Approach to Register Programs for Catalytic Computing','author':'Antoine Vinciguerra','url':'https://arxiv.org/html/2609.18692v1','section':'4.1–4.3','use':'A closed operator loop may preserve arbitrary work registers while intermediate output updates accumulate a new term. Its polynomial instruction grammar is not imported as a free Gaussian operation.'},
            {'title':'New Codes on High Dimensional Expanders','authors':'Irit Dinur, Siqi Liu, Rachel Yun Zhang','url':'https://drops.dagstuhl.de/storage/00lipics/lipics-vol339-ccc2025/html/LIPIcs.CCC.2025.27/LIPIcs.CCC.2025.27.html','use':'The exact elementary-matrix commutator relation motivates a finite nilpotent two-step loop; every recurrence is checked in our one-pass caller.'}],
        'elapsed_seconds':time.monotonic()-start,'new_kappa_claimed':False}
    stem='FINITE-CHRONOLOGICAL-LOOPS-PP' if args.include_pp else 'FINITE-CHRONOLOGICAL-LOOPS-PI'
    (HERE/(stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
