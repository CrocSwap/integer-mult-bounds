#!/usr/bin/env python3
"""Actual width-two tangent reachability with all chronological prefix caches.

The source-stage equal-frequency sector has Q_i(w)=(-1)^(1+w.q_i),
D_s=zeta(w)Q and P=-R_selected^T R_selected/4.  Every other stage D_t
has an independently chosen sign, realized by equal frequencies on its
eight disjoint coordinates.  Thus every even-head coefficient reduces to
aI+bP, but the six other *unsquared* stage signs remain independent.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import json
import sys
import time

import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import internal_tangent_filtered_caller as it
sys.path.insert(0,str(ROOT/'research/retained_state_next'))
import causal_even_complete as ce
ac=it.ac;fc=it.fc


def one_p(vector,stage,external=True):
    out=defaultdict(F)
    for (i,j,a,b,d),c in vector.items():
        other=tuple(d[t]%2 for t in range(7) if t!=stage) if external else (0,)*6
        key=i,j,(a%2,(b+d[stage])%2),d[stage]%2,other
        out[key]+=c
    return {k:c for k,c in out.items() if c}


def zero_p(left,right,stage,external=True):
    out=defaultdict(F)
    for i,l in enumerate(left):
        for j,r in enumerate(right):
            for (q,d),c in ac.poly_mul(l,r).items():
                other=tuple(d[t]%2 for t in range(7) if t!=stage) if external else (0,)*6
                key=i,j,((q+d[stage])%2,),d[stage]%2,other
                out[key]+=c
    return {k:c for k,c in out.items() if c}


def operators(left,right,stage,external=True):
    yield 'I',zero_p(left,right,stage,external)
    yield 'P',one_p(ac.p_outer(left,right,stage),stage,external)


def columns(source,prefix,suffix,stage,external=True):
    result=[]
    # Store any actual bank at an earlier event boundary; read it at any
    # later boundary, retaining all six independent original input columns.
    for birth in range(len(prefix)):
        for cut in range(birth,len(prefix)):
            for write in range(6):
                left=[row[write] for row in suffix[cut]]
                for read in range(6):
                    for name,v in operators(left,prefix[birth][read],stage,external):
                        result.append(({'kind':'cached_prefix_to_later_bank','birth_cut':birth,
                            'injection_cut':cut,'write_bank':write,'read_bank':read,
                            'operator':name},v))
    # The one new chronological value is the completed transformed source
    # before the opposite input is consumed, at each actual FULL.
    for at,e in enumerate(source['physical_events']):
        if e[0]!='LOCAL':continue
        _,t,pair,back=e;x=2*pair;dst,src=(x,x+1) if back else (x+1,x)
        right=[ac.poly_mul(ac.mono(stages=[t]),p) for p in prefix[at][src]]
        left=[ac.poly_mul(row[dst],ac.mono(stages=[t])) for row in suffix[at+1]]
        for name,v in operators(left,right,stage,external):
            result.append(({'kind':'internal_source_to_opposite_input','event':at,
                'source_stage':t,'write_bank':dst,'read_bank':src,'operator':name},v))
        for cut in range(at+1,len(prefix)):
            for write in range(6):
                left=[row[write] for row in suffix[cut]]
                for name,v in operators(left,right,stage,external):
                    result.append(({'kind':'cached_internal_source_to_later_bank','event':at,
                        'source_stage':t,'injection_cut':cut,'write_bank':write,
                        'read_bank':src,'operator':name},v))
    return result


def encode(key):
    i,j,q,z,d=key
    return {'output_bank':i,'input_bank':j,'Q_powers_separated_by_P':list(q),
        'source_zeta_power':z,'other_stage_sign_powers':list(d)}


def screen(source,prefix,suffix,stage,external=True):
    error,at=it.tc.target_error(source,prefix,suffix,stage)
    error=one_p(error,stage,external);goal=fc.scale(error,-1)
    cs=columns(source,prefix,suffix,stage,external)
    basis=fc.sparse_basis(cs);recipe,residual=fc.solve(basis,goal)
    certificate=None
    if residual:
        weight,evaluation=it.annihilator(basis,goal)
        assert all(sum((c*weight.get(k,F(0)) for k,c in col.items()),F(0))==0 for _,col in cs)
        certificate={'all_control_columns_annihilated':len(cs),
            'required_correction_evaluation':str(evaluation),'support_size':len(weight),
            'functional':[{'coefficient':str(c),**encode(k)} for k,c in sorted(weight.items())]}
    else:
        verify=dict(error)
        for j,c in recipe.items():verify=fc.add(verify,fc.scale(cs[j][1],c))
        assert not verify
    # Supplied true error is an exact positive control for row/sign ordering.
    control=fc.sparse_basis(cs+[({'kind':'supplied_exact_error'},goal)])
    assert not fc.solve(control,goal)[1]
    return {'stage':stage,'changed_event':at,'independent_other_stage_signs':external,
        'all_six_original_banks_arbitrary':True,'candidate_columns':len(cs),
        'exact_span_rank':len(basis),'tangent_solution_found':not residual,
        'unreduced_terms':len(residual),'dual_certificate':certificate,
        'solution':[{'coefficient':str(c),**cs[j][0]} for j,c in sorted(recipe.items())] if not residual else [],
        'supplied_exact_error_positive_control':True}


def stage0_transport_check(source,prefix,suffix):
    error,at=it.tc.target_error(source,prefix,suffix,0);assert at==0
    right=[ac.poly_mul(ac.mono(stages=[0]),p) for p in prefix[0][0]]
    dl=list(ac.ZERO_D);dl[0]=1
    controls=[ac.p_outer([row[1] for row in suffix[1]],right,0,dleft=tuple(dl))]
    for cut,bank,c in [(6,0,1),(13,2,-1),(18,4,1)]:
        controls.append(fc.scale(ac.p_outer([row[bank] for row in suffix[cut]],right,0),c))
    actual=fc.add(error,*controls);expected={}
    for out,positive,negative in [(3,[5,6],[]),(4,[1,2],[]),(5,[1,2,3,4,5,6],[5,6])]:
        for stages,c in [(positive,1),(negative,-1)]:
            left=[{} for _ in range(6)];left[out]=ac.mono(stages=stages,coefficient=c)
            expected=fc.add(expected,ac.p_outer(left,right,0))
    assert actual==expected
    return {'exact_full_operator_replay':True,'residual_terms':len(actual),
        'cache':'t=P0 D0 (x1-x2), from actual right-boundary source bank0',
        'negative_output_errors':[0,0,0],
        'positive_output_errors':{'3':'(D5 D6-I)t','4':'(D1 D2-I)t',
            '5':'D5 D6 (D1 D2 D3 D4-I)t'},
        'all_Q_powers_in_residual_zero':all(a==b==0 for (_,_,a,b,_),c in actual.items()),
        'interpretation':'The missing correction is transport of the one cached mode through later paid transforms, with arbitrary other inputs retained.'}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stages',default='0,1,2,3,4,5,6')
    args=ap.parse_args();start=time.monotonic()
    path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    npth=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    source=json.loads(path.read_text())['selected_p3_keep43'];_,prefix,suffix=ac.source_matrices(source)
    R=np.array(json.loads(rp.read_text()),dtype=np.int64)
    qs=[x['q'] for x in json.loads(npth.read_text())['ports']]
    certs=[ce.actual_independence(R,qs,[5]),ce.actual_independence(R,qs,list(range(8)))]
    results=[]
    for stage in map(int,args.stages.split(',')):
        result=screen(source,prefix,suffix,stage,True);results.append(result)
        print('ACTUAL_TANGENT',stage,'solution',result['tangent_solution_found'],
            'rank',result['exact_span_rank'],'residual',result['unreduced_terms'],
            'elapsed',round(time.monotonic()-start,3),flush=True)
    positive=screen(source,prefix,suffix,0,False)
    assert positive['tangent_solution_found']
    transport=stage0_transport_check(source,prefix,suffix)
    out={'schema':'actual-width2-complete-even-algebra-tangent-reachability/v1',
        'source_sha256':sha256(path.read_bytes()).hexdigest(),
        'actual_R_sha256':sha256(rp.read_bytes()).hexdigest(),
        'normalizers_sha256':sha256(npth.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_operator_independence_certificates':certs,
        'independent_external_characters':{'count':64,'dimension':64,
            'realization':'For each t!=s choose equal width2 Fourier addresses on its eight fresh axes, with total parity0 or1. D_t then acts by+1 or-1, independently of the source-stage address w and all other t.',
            'character_matrix':'The sixfold2x2 Walsh tensor product has determinant magnitude2^192, so its64 characters are independent over Q.',
            'combined_function_independence_dimension':1280},
        'results':results,'stage0_other_stages_identity_positive_control':positive,
        'stage0_exact_transport_deficit':transport,
        'complete_even_head_scope':'Coefficients in the full ordinary algebra generated by the one selected P_s, Q^2, and all squared stage transforms. On this actual sector every coefficient is aI+bP_s with no polynomial-degree limit. This includes the single sourceR5 projector and all8 orthogonal sourceR modes.',
        'chronological_control_scope':'At every actual event boundary, any earlier prefix bank may have been cached and is allowed to update any bank. At each of the7 FULLs, its authenticated transformed source may update the still-unconsumed opposite input and may be retained for any later bank update. This is a first-order control equation around the unchanged caller.',
        'not_excluded':['Finite controls whose essential correction begins at higher order, including multi-P paths that vanish to first order.',
            'Other ordinary address maps outside the declared even-head algebra.',
            'Additional changes to paid FULL/IDLE jobs, distinct independent target populations, or new paid providers.',
            'Other internal source-DAG states or feedback that rewrites already-consumed source contributions.'],
        'elapsed_seconds':time.monotonic()-start,'new_kappa_claimed':False}
    (HERE/'ACTUAL-TANGENT-REACHABILITY.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
