#!/usr/bin/env python3
"""Exact finite two-transvection synthesis around one filtered FULL.

Two gates are not approximated: solve aA+bB+s*a*b*BA=-E, where s=+1
if both gates lie on the same side of the changed call and s=-1 if they
straddle it. Every six-bank operator column and every stage character is
retained. The nonzero dual of BA fixes ab, leaving an exact2x2 solve.
"""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import finite_chronological_loops as fl
ar=fl.ar;ac=fl.ac;fc=fl.fc


def two_coefficients(a,b,v):
    first=next((k for k in sorted(set(a)|set(b)) if a.get(k)),None)
    if first is None:return None
    second=next((k for k in sorted(set(a)|set(b))
        if a.get(first,0)*b.get(k,0)-a.get(k,0)*b.get(first,0)),None)
    if second is None:return None
    aa,ab=a.get(first,F(0)),b.get(first,F(0))
    ba,bb=a.get(second,F(0)),b.get(second,F(0));det=aa*bb-ba*ab
    u,vv=v.get(first,F(0)),v.get(second,F(0))
    alpha=(u*bb-vv*ab)/det;beta=(aa*vv-ba*u)/det
    return (alpha,beta) if fc.add(fc.scale(a,alpha),fc.scale(b,beta))==v else None


def timelines(a,b):
    first=a['occurrences'];second=b['occurrences'];out=[]
    # Both after, or both before, the changed native call.
    for side in ('after','before'):
        allowed=lambda t: t>0 if side=='after' else t==0
        pair=next(((x,y) for x in first for y in second
            if allowed(x['time']) and allowed(y['time']) and x['time']<=y['time']),None)
        if pair:out.append((side,1,pair))
    pair=next(((x,y) for x in first for y in second if x['time']==0 and y['time']>0),None)
    if pair:out.append(('straddling',-1,pair))
    return out


def main():
    start=time.monotonic();path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    source=json.loads(path.read_text())['selected_p3_keep43'];_,prefix,suffix=ac.source_matrices(source)
    target=source['exact_diagonal_monomials'];error,_=ar.it.tc.target_error(source,prefix,suffix,0)
    error=fl.endpoint_shift(fl.convert(ar.one_p(error,0,True)),target);goal=fc.scale(error,-1)
    assert not fl.mul(error,error)
    data=fl.classes(source,prefix,suffix,True)
    data=[e for e in data if e['P_degree']==1]
    weight0=json.loads((HERE/'ARBITRARY-OWNER-TANGENT.json').read_text())['results'][0]['functional']
    weight={(r['output_bank'],r['input_bank'],tuple(r['Q_powers_separated_by_P']),
        (r['source_zeta_power'],)+tuple(r['other_stage_sign_powers'])):F(r['coefficient']) for r in weight0}
    def dual(v):return sum((c*weight.get(k,F(0)) for k,c in fl.endpoint_shift(v,target).items()),F(0))
    assert dual(goal)==-1
    considered=0;curvature=0;bilinear_span=0;balanced_span=0;solutions=[];balanced=[];examples=[]
    for ia,a in enumerate(data):
        A=a['operator']
        for ib,b in enumerate(data):
            schedules=timelines(a,b)
            if not schedules:continue
            B=b['operator'];BA=fl.mul(B,A);evaluation=dual(BA)
            considered+=len(schedules)
            if not evaluation:continue
            curvature+=len(schedules)
            if len(examples)<5:examples.append({'first_class':ia,'second_class':ib,
                'BA_dual':str(evaluation),'example_times':[schedules[0][2][0]['time'],schedules[0][2][1]['time']]})
            for side,sign,pair in schedules:
                product=-1/(sign*evaluation)
                rhs=fc.add(goal,fc.scale(BA,-sign*product))
                values=two_coefficients(A,B,rhs)
                balanced_rhs={k:c for k,c in rhs.items() if len(k[2])<=2}
                bal_values=two_coefficients(A,B,balanced_rhs)
                if bal_values:
                    balanced_span+=1
                    if bal_values[0]*bal_values[1]==product and len(balanced)<20:
                        balanced.append({'first_class':ia,'second_class':ib,'side':side,
                            'alpha':str(bal_values[0]),'beta':str(bal_values[1]),
                            'gates':list(pair),'full_actual_2P_operator_equality':bool(values)})
                if not values:continue
                bilinear_span+=1;alpha,beta=values
                if alpha*beta!=product:continue
                identity={(i,i,(0,),fl.Z):F(1) for i in range(6)}
                sequence=[(A,alpha),(B,beta),(error,1)] if side=='before' else (
                    [(error,1),(A,alpha),(B,beta)] if side=='after' else [(A,alpha),(error,1),(B,beta)])
                state=identity
                for H,c in sequence:state=fc.add(state,fc.scale(fl.mul(H,state),c))
                assert state==identity
                solutions.append({'first_class':ia,'second_class':ib,'side':side,
                    'gates':[dict(p,coefficient=str(c/F(p['physical_to_normal_scale']))) for p,c in zip(pair,[alpha,beta])],
                    'all_six_original_banks_restored':True,'actual_width2_only':True})
    print('FINITE_TWO_GATES','classes',len(data),'timelines',considered,
        'nonzero_quadratic_dual',curvature,'linearized_bilinear_solutions',bilinear_span,
        'balanced_span_solutions',balanced_span,'finite_solutions',len(solutions),
        'balanced_finite_candidates',len(balanced),'seconds',round(time.monotonic()-start,3),flush=True)
    out={'schema':'exact-finite-two-gate-correction-screen/v1',
        'source_sha256':sha256(path.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'projector_transvection_classes':len(data),'chronological_two_gate_pairs':considered,
        'pairs_with_nonzero_second_order_dual':curvature,
        'nonzero_curvature_examples':examples,'bilinear_relaxation_solutions':bilinear_span,
        'balanced_sector_bilinear_relaxation_solutions':balanced_span,
        'exact_finite_actual_sector_solutions':solutions,
        'balanced_sector_finite_candidates':balanced,
        'all_six_arbitrary_original_banks_retained':True,'all_external_stage_characters_retained':True,
        'exact_nonlinear_condition':'The dual fixes a*b, then the entire operator equation solves a,b; the product constraint and the finite endpoint are checked explicitly.',
        'operator_validity':'All terms in the two-gate inverse equation have P-degree at most2. The actual sourceR5 and all8 operator-function independence minors in ACTUAL-TANGENT-REACHABILITY.json certify the required20 functions; no free formal identity is mistaken for an actual obstruction.',
        'scope':'Two off-diagonal bank transvections with a scalar multiple of P0, at arbitrary actual outer cuts or authenticated internal source cuts, before, after, or straddling the one changed stage0 FULL. It does not cover unrestricted finite ordinary matrices, three-or-more non-recurring gates, other internal fields, or a changed paid query.',
        'elapsed_seconds':time.monotonic()-start,'new_kappa_claimed':False}
    (HERE/'FINITE-TWO-GATE-CORRECTION.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
