#!/usr/bin/env python3
"""Cheap exact quotient screen: existing full snapshots +rank1-lifted rank8 contacts.

All native phase-bearing K_G fix |0> with phase1, so augmentation K_G->1
is a necessary source-ground test retaining all632 arbitrary owner amplitudes.
Rank8 contacts are gathered only within the identical actual input frame.
The full native S is allowed as side information; original center queries
are explicitly retained in this preliminary test and are never credited
as deleted by a positive result.
"""
from collections import defaultdict,Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import pickle
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import filtered_full_caller as fc


def augment(row):
    out={}
    for (owner,g),v in row.items():
        x=out.get(owner,F(0))+v
        if x:out[owner]=x
        else:out.pop(owner,None)
    return out


def reduce_with_pivots(row,pivots):
    row=dict(row)
    for owner,basis in pivots:
        a=row.get(owner,F(0))
        if a:fc.ac.subtract_scaled(row,basis,a)
    return row


def intersection(rows,targets):
    columns=[({'kind':'observation','index':j},q) for j,(d,q) in enumerate(rows)]
    initial=len(columns);basis=fc.sparse_basis(columns);rank0=len(basis);out=[]
    for k,t in enumerate(targets):
        recipe,residual=fc.solve(basis,t)
        if not residual:
            target={k:F(1)};observations={}
            for j,a in recipe.items():
                d=columns[j][0]
                if d['kind']=='observation':observations[d['index']]=a
                else:target[d['mode']]=target.get(d['mode'],F(0))-a
            target={k:a for k,a in target.items() if a}
            verify={}
            for j,a in observations.items():verify=fc.add(verify,fc.scale(rows[j][1],a))
            expected={}
            for j,a in target.items():expected=fc.add(expected,fc.scale(targets[j],a))
            assert verify==expected
            out.append((target,observations))
        else:
            columns.append(({'kind':'target','mode':k},t));basis=fc.sparse_basis(columns)
    return rank0,out


def main():
    started=time.monotonic();sourcepath=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    basispath=ROOT/'research/retained_state_next/CONSUMER-KG-MODULE-BACKWARD.pickle'
    source=json.loads(gzip.decompress(sourcepath.read_bytes()));c=source['canonical']
    data=pickle.loads(basispath.read_bytes());pivots=[]
    for owner,row,recipe in data['pivots']:
        ar=augment(row);assert ar[owner]==1;pivots.append((owner,ar))
    assert len(pivots)==482
    targets=[reduce_with_pivots({i+112:a for i,a in enumerate(r) if a},pivots) for r in data['R']]
    assert len(fc.sparse_basis(list(enumerate(targets))))==8
    rows=[{i:F(1)} for i in range(632)]+[{}];cur=c['start'][:]+[None];dependencies=[0]*633
    byframe=defaultdict(list);seen=defaultdict(set);centerno=0;rawcount=Counter()
    def observe(owner,event):
        if cur[owner] is None or len(c['frames'][cur[owner]])!=8 or not rows[owner]:return
        frame=cur[owner];rawcount[frame]+=1
        desc={'owner':owner,'after_event':event,'frame':frame,'center_ancestor_mask':dependencies[owner]}
        q=reduce_with_pivots(rows[owner],pivots);key=tuple(sorted(q.items()))
        if key not in seen[frame]:
            seen[frame].add(key);byframe[frame].append((desc,q))
    for owner in range(632):observe(owner,-1)
    for pos,e in enumerate(source['programs']['backward']):
        typ=e[0];d=None
        if typ=='scalar':
            a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
            if a[0]=='clear':rows[d]={};cur[d]=f;dependencies[d]=0
            else:
                assert cur[d]==f
                if a[0] in ('add','copy'):
                    s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                    if a[0]=='copy':rows[d]=dict(rows[s]);dependencies[d]=dependencies[s]
                    else:rows[d]=fc.add(rows[d],fc.scale(rows[s],F(a[3],a[4])));dependencies[d]|=dependencies[s]
                else:rows[d]=fc.scale(rows[d],F(a[2],a[3]))
        elif typ=='warp':d=e[1][1]+(632 if e[1][0]=='C' else 0);assert cur[d]==e[3];cur[d]=e[4]
        elif typ=='climb':d=e[2];assert cur[d]==e[3];cur[d]=e[4]
        elif typ=='center':
            d=632+e[1];assert cur[d]==e[2];cur[d]=e[3];dependencies[d]|=1<<centerno;centerno+=1
        else:assert typ in ('phase','adapter')
        if d is not None:observe(d,pos)
    assert cur[:632]==c['final'] and not rows[632]
    records=[];selections={}
    for restriction in ('all','original_owned','no_center_ancestors'):
        modes=[];details=[]
        for f,contacts in sorted(byframe.items()):
            used=[(d,q) for d,q in contacts if restriction=='all' or
                  (restriction=='original_owned' and d['owner']<632) or
                  (restriction=='no_center_ancestors' and d['owner']<632 and d['center_ancestor_mask']==0)]
            rank,solutions=intersection(used,targets)
            if not solutions:continue
            for target,recipe in solutions:
                desc={'frame':f,'target_mode_combination':{str(k):str(a) for k,a in target.items()},
                    'gather':[dict(used[j][0],coefficient=str(a)) for j,a in sorted(recipe.items())],
                    'augmented_observation_terms':len(recipe)}
                modes.append((desc,target));details.append(desc)
        rank=len(fc.sparse_basis(modes));selections[restriction]=details
        records.append({'restriction':restriction,'candidate_mode_directions':len(modes),'combined_target_mode_rank':rank,'one_paid_rank1_lift_per_direction':True})
        print('AUGMENTED_OBSERVER',restriction,'directions',len(modes),'mode_rank',rank,flush=True)
    out={'schema':'full-snapshot-plus-rank1-augmentation-screen/v1',
        'source_sha256':sha256(sourcepath.read_bytes()).hexdigest(),'side_module_sha256':sha256(basispath.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'direction':'backward',
        'all632_original_amplitudes_arbitrary':True,'all408_helper_amplitudes_retained':True,
        'full_side_information_unit_pivots':len(pivots),'rank8_contact_frames':len(byframe),
        'raw_rank8_contacts':sum(rawcount.values()),'distinct_rank8_quotient_contacts':sum(map(len,byframe.values())),
        'results':records,'candidate_gathers':selections,
        'query_accounting':'Each emitted same-frame gathered observation needs one fresh rank1 query to the full frame, subject to an exact frame-factor check. All original native centers remain paid in this preliminary screen. No64-to8 saving is inferred.',
        'scope':'Necessary augmentation only: actual phase-bearing K_G->1 on their common fixed |0>. A positive requires complete operator cleanup with S and actual cross-stage target binding. Same-frame scalar input gathers only; no unverified frame alignment.',
        'elapsed_seconds':time.monotonic()-started,'new_kappa_claimed':False}
    (HERE/'AUGMENTED-RANK1-OBSERVERS.json').write_text(json.dumps(out,indent=2)+'\n')
    (HERE/'AUGMENTED-RANK1-CONTACTS.pickle').write_bytes(pickle.dumps({'byframe':dict(byframe),'targets':targets,'pivots':pivots},protocol=5))


if __name__=='__main__':main()
