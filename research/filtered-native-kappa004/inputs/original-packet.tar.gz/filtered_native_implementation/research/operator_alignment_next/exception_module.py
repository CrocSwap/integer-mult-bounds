#!/usr/bin/env python3
"""Exact finite exceptional carrier and source-bound cross-stage kernels.

The carrier is a finite redundant representation for a fixed set of stages.
It is not, by itself, a recursively closed supplier.  The odd transfer
kernels and the actual entrance/return charts are explicitly charged.
"""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import probe
from review_center5 import word_op, same


def need(value,message):
    if not value:raise AssertionError(message)


def embedded_K(ce,item,stage,n=17):
    positions=[0]+list(range(1+8*stage,9+8*stage))
    def mask(x):return sum(((x>>j)&1)<<positions[j] for j in range(9))
    rows=[1<<j for j in range(n)]
    for j,position in enumerate(positions):rows[position]=mask(item['G_rows'][j])
    phase=[0]*n
    for j,position in enumerate(positions):phase[position]=2*((item['Z_mask']>>j)&1)
    return ce.perm(n,rows).then(ce.diag(n,[0]*n,phase))


def power(op,k,ce):
    out=ce.ident(op.n)
    for _ in range(k%4):out=out.then(op)
    return out


def main():
    ce,ca,normals,R,routes=probe.cc.source_data()
    r=list(map(F,R[5]));active=[i for i,x in enumerate(r) if x]
    need(len(active)==56 and all(r[i]*r[i]==1 for i in active),'Changed sourceR5')
    native=json.loads((ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json').read_text())
    need([[F(x) for x in row] for row in native]==R,'Mode labels differ from actual native source')
    normal_modes=json.loads((ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json').read_text())['mode_columns']
    matches=[(j,sgn) for j,row in enumerate(normal_modes) for sgn in (1,-1)
             if all(r[i]==sgn*F(row[i]) for i in range(112))]
    need(matches==[(7,-1)],'SourceR5/normalizer row mapping changed')

    # The literal base commutators include global phases. This supplies the
    # global-phase proof for every embedded identity below without expanding
    # dense17-bit intermediate Fourier states.
    full9=ce.fourier(9);base_checks=0
    for i in active:
        item=normals[i]
        need([e[0] for e in item['K_word']]==['P','D'],'Changed K grammar')
        need(all(x==0 for x in item['K_word'][1][1]),'K has an unexpected quadratic phase')
        K=word_op(ce,item['K_word'])
        need(same(K.then(full9),full9.then(K)),'Literal base commutator failed')
        base_checks+=1
    n=17;Q=ce.cgate(n,1)
    D=[ce.fourier(n,range(1+8*t,9+8*t)) for t in range(2)]
    FF=[Q.then(d) for d in D]
    embedded=[[embedded_K(ce,item,s,n) for item in normals] for s in range(2)]
    cross=[];cross_checks=0;state_checks=0
    for j,s in ((0,1),(1,0)):
        ordinary_terms=[]
        for i in active:
            Kj,Ks=embedded[j][i],embedded[s][i]
            need(Ks.then(D[j]).tab==D[j].then(Ks).tab,'Disjoint fresh-block commutation failed')
            # All monomial routes are literal signed words on the17-bit chart.
            even={a:Ks.adjoint().then(power(Q,a,ce)).then(Kj) for a in (0,2)}
            ordinary_terms.append({'port':i,'weight':'1/56','T0_route':even[0].circuit,
                                   'T2_route':even[2].circuit})
            for a in (1,3):
                lhs=Ks.adjoint().then(power(Q,a,ce)).then(Kj)
                rhs=D[j].adjoint().then(even[a-1]).then(FF[j])
                need(lhs.tab==rhs.tab,'Cross-kernel Clifford identity failed')
                cross_checks+=1
            # The sign3 version can also use inverse full Gaussian, exposing
            # the [8,9] query profile directly in either orientation.
            lhs=Ks.adjoint().then(Q.adjoint()).then(Kj)
            rhs=D[j].then(even[0]).then(FF[j].adjoint())
            need(lhs.tab==rhs.tab,'Inverse cross-kernel identity failed')
        cross.append({'output_stage':j,'input_stage':s,'terms':ordinary_terms})
    for t in range(2):
        for s in range(2):
            for a in range(4):
                for epsilon in (1,-1):
                    target=D[t].then(power(Q,epsilon,ce))
                    new_a=(a+epsilon-(1 if s==t else 0))%4
                    coefficient_job=FF[t] if s==t else D[t]
                    for i in active:
                        K=embedded[s][i]
                        embed=K.adjoint().then(power(Q,a,ce))
                        lhs=embed.then(target)
                        rhs=coefficient_job.then(K.adjoint()).then(power(Q,new_a,ce))
                        need(lhs.tab==rhs.tab,'Exceptional state transition failed')
                        state_checks+=1

    # Algebraic constants are applied once to owner modes, never tensorized.
    alpha=F(14);inverse_alpha=F(14,13)
    need(-alpha-inverse_alpha+alpha*inverse_alpha==0,'Wrong C5 inverse coefficient')
    costs=[]
    for c in (0.0,0.0030217758,0.0041):
        saved=8**(1-c);self_cost=2*6**(1-c)+2;cross_cost=8**(1-c)+9**(1-c)
        costs.append({'c':c,'saved_rank8_cost':saved,
                      'self_kernel_rank_profile_6_1_1_6':self_cost,
                      'cross_kernel_rank_profile_8_9':cross_cost,
                      'self_per_center_ratio':self_cost/saved,
                      'cross_per_center_ratio':cross_cost/saved,
                      'self_kernels_affordable_per_deleted_center_strictly_below':saved/self_cost,
                      'cross_kernels_affordable_per_deleted_center_strictly_below':saved/cross_cost})
    out={
        'status':'PASS_EXACT_FIXED_STAGE_EXCEPTIONAL_CARRIER_AND_CROSS_KERNEL_PROVIDER',
        'source_R_row':5,'normalizer_mode_row_for_same_projector':7,'normalizer_row_sign':-1,
        'source_R_sha256':sha256((ROOT/'research/tensor_obstruction/inputs/R.json').read_bytes()).hexdigest(),
        'active_ports':active,
        'definitions':{
            'V_s':'diag(K_s,i^-1) r5^T',
            'L_s':'r5 diag(K_s,i)/56',
            'P_s':'V_s L_s; L_s V_s=I and P_s^2=P_s',
            'C_s':'I-14 P_s; C_s^-1=I-(14/13)P_s',
            'T_js_a':'L_j Q^a V_s=(1/56) sum_i r5_i^2 K_j,i Q^a K_s,i^-1',
            'carrier':'E=span_{s=1..S,a=0..3} Q^a ran(V_s)',
            'represented_state':'y=sum_{s,a} Q^a V_s f_s,a',
        },
        'fixed_stage_closure':{
            'ambient_field_rank_bound':'dim(E)<=min(112,4S) times the common array dimension',
            'seven_stage_bound':28,
            'Q_action':'f_s,a moves to f_s,(a+1 mod4); Q^4=I at every tensor width.',
            'C_j_action':'f_j,0 -=14 sum_{s,a} T_js^(a) f_s,a; all other coefficient fields are retained.',
            'C_j_inverse_action':'Replace14 by14/13 in the same update.',
            'Q_epsilon_D_t_action':'If s=t: (s,a,f)->(s,a+epsilon-1,F_t f). If s!=t: (s,a,f)->(s,a+epsilon,D_t f), with exponents modulo4.',
            'carrier_is_redundant':True,
            'projection_or_quotient_injectivity_not_assumed':True,
            'width_note':'At width1 the Q orbit has at most2 spectral components; at width2 at most3; the all-width4 bound is used throughout.',
            'coefficient_norms':'Every transfer T_js^(a) has operator2-norm<=1 as an average of56 unitary signed Clifford words.',
        },
        'cross_kernel_provider':{
            'scope':'j and s are distinct stages with disjoint8-bit fresh blocks and one shared central coordinate.',
            'identity':'T_js^(a)=F_j T_js^(a-1) D_j^-1 for a=1,3; a-1 is even and its56-term sum is ordinary.',
            'inverse_form':'T_js^(3)=F_j^-1 T_js^(0) D_j',
            'paid_query_ranks':[8,9],
            'ordinary_route_ADDs':56,
            'scalar_coefficient':'1/56, applied once outside tensor powers',
            'implementation':'On owned scratch compute D_j^-1 f; gather56 signed monomial images into an owned zero aggregate with coefficients1/56; apply F_j. Original f is preserved; CLEAR both disposable owned buffers after the output is consumed.',
            'phase_proof':'All56 source K_j commute literally with F_j, including global phase. D_j acts only on fresh blockj and commutes literally with every K_s for s!=j. These two equalities prove the stated full operators;17-bit tableaus are separately replayed.',
            'local_absolute_phase_commutators':base_checks,
            'cross_tableau_identities':cross_checks,
            'literal_routes_by_stage_pair':cross,
        },
        'state_transition_tableau_checks':state_checks,
        'self_kernel_connection':{
            'identity':'T_ss^(1)=(1/56) sum_{i in supp(sourceR5)} C(-X_qi)^(tensor m)',
            'conditional_6_chart_provider_ranks':[6,1,1,6],
            'scope':'The two head outputs are summed in their common chart before one inverse rank6 chart. This is a single-output averaged kernel, unlike56 separately consumed exit scatters. Its literal provider is being owned by alternative_gadgets_next.',
        },
        'local_provider_prices':costs,
        'recursive_admission':{
            'genuine_moment_matrix_supplied':False,
            'reason':'A finite redundant carrier for one fixed set of stages is not a finite recursive representation alphabet. Arbitrary inputs still need an admitted entrance decomposition/reader, odd-chart returns need physical embeddings, and deeper calls introduce new stage geometries unless an actual closure theorem identifies them.',
            'cost_screen':'One new elementary odd kernel per removed centre already costs more than the saved rank8 query at the benchmark. Shared kernels, state amortization or a cheaper kernel provider are required before constructing a favorable moment matrix.',
            'no_fictitious_spectral_radius':'No spectral radius is quoted because actual child sizes, target multiplicities and every adapter are not yet specified.',
            'prior_positive_vector_theorems':'upstream/research/kappa-action-theory/volumes/04-analytic.md A051/A052/A054/A056; applicability scope in upstream/research/idea-a-spectral-radius-screen/README.md.',
        },
        'new_supplier_or_kappa':False,
    }
    (HERE/'EXCEPTION-MODULE.json').write_text(json.dumps(out,indent=2)+'\n')
    summary={k:v for k,v in out.items() if k not in ('cross_kernel_provider','active_ports')}
    summary['cross_kernel_provider']={k:v for k,v in out['cross_kernel_provider'].items() if k!='literal_routes_by_stage_pair'}
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
