#!/usr/bin/env python3
"""Independent replay of the selective-centre artifact and its chart claims.

This is a separate sparse free-word interpreter, not a call to native_core.
The physical meaning of unchanged native frame transitions remains the pinned
source premise.  Every changed scalar operation, source column, owner frame,
paid event and absolute normalizer phase is checked here.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import probe


def need(value,message):
    if not value:raise AssertionError(message)


def sparse_add(dst,src,scale):
    for key,value in list(src.items()):
        value=dst.get(key,F(0))+scale*value
        if value:dst[key]=value
        else:dst.pop(key,None)


def replay(canonical,program):
    """New evaluator; transpose-word namespace is immaterial within one run."""
    rows=[{(i,()):F(1)} for i in range(632)]+[{}]
    frames=list(canonical['start'])+[None]
    paid=Counter();maxnorm=F(1);changes=Counter()
    def owner(ref):
        need(ref[0] in ('L','C'),'Unknown owner namespace')
        index=ref[1]+(632 if ref[0]=='C' else 0)
        need(0<=index<633,'Owner outside the admitted allocation')
        return index
    for event in program:
        kind=event[0];changes[kind]+=1
        if kind=='scalar':
            op,frame=event[1:];dst=owner(op[1]);name=op[0]
            if name=='clear':
                need(dst==632,'Attempt to erase an arbitrary original')
                rows[dst]={};frames[dst]=frame
            else:
                need(frames[dst]==frame,'Scalar destination chart mismatch')
                if name in ('copy','add'):
                    src=owner(op[2])
                    need(frames[src]==frame,'Scalar source chart mismatch')
                    if name=='copy':
                        need(dst==632,'Attempt to overwrite an original')
                        rows[dst]=dict(rows[src])
                    else:
                        need(src!=dst,'Self-ADD outside source grammar')
                        sparse_add(rows[dst],rows[src],F(op[3],op[4]))
                elif name=='scale':
                    scale=F(op[2],op[3])
                    rows[dst]={key:value*scale for key,value in rows[dst].items() if value*scale}
                else:raise AssertionError('Unrecognized scalar opcode')
                maxnorm=max(maxnorm,sum(map(abs,rows[dst].values()),F(0)))
        elif kind=='warp':
            _,ref,letter,old,new=event;dst=owner(ref)
            need(frames[dst]==old,'Warp source chart mismatch')
            changed={}
            for (src,word),value in rows[dst].items():
                reduced=word[1:] if word and word[0]==-letter else (letter,)+word
                key=(src,reduced);changed[key]=changed.get(key,F(0))+value
            rows[dst]={key:value for key,value in changed.items() if value}
            frames[dst]=new
        elif kind=='climb':
            _,_,dst,old,new,rank=event
            need(frames[dst]==old,'Paid climb source chart mismatch')
            need(rank==len(canonical['frames'][new])-len(canonical['frames'][old]) and rank>0,
                 'Wrong positive climb rank')
            paid[rank]+=1;frames[dst]=new
        elif kind=='center':
            _,owned,old,new,rank=event;dst=632+owned
            need(dst==632 and frames[dst]==old,'Centre ownership/frame mismatch')
            need(rank==abs(len(canonical['frames'][new])-len(canonical['frames'][old])),
                 'Wrong centre rank')
            paid[rank]+=1;frames[dst]=new
        else:need(kind in ('phase','adapter','residual_adapter'),'Unknown native event')
    need(frames[:632]==canonical['final'],'Wrong final original charts')
    need(not rows[632],'Owned register not cleared at return')
    return rows,paid,maxnorm,changes


def word_op(ce,word):
    result=ce.ident(9)
    for e in word:
        if e[0]=='P':op=ce.perm(9,e[1])
        elif e[0]=='D':op=ce.diag(9,e[1],e[2])
        elif e[0]=='X':op=ce.xgate(9,e[1])
        elif e[0]=='phase':op=ce.Op(9,ce.identity(9),[tuple(e)])
        else:raise AssertionError('Nonmonomial normalizer')
        result=result.then(op)
    return result


def same(a,b):return a.tab==b.tab and a.zero_state()==b.zero_state()


def main():
    ce,ca,normals,R,routes=probe.cc.source_data()
    old_path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    new_path=ROOT/'research/retained_state_next/CENTER5-CODED-WORDS.json.gz'
    receipt_path=ROOT/'research/retained_state_next/CENTER5-CODED-RESULT.json'
    suffix_path=ROOT/'research/retained_state_next/CENTER5-SUFFIX.json'
    original=json.loads(gzip.decompress(old_path.read_bytes()))
    new_raw=gzip.decompress(new_path.read_bytes());changed=json.loads(new_raw)
    receipt=json.loads(receipt_path.read_text());suffix=json.loads(suffix_path.read_text())
    need(sha256(old_path.read_bytes()).hexdigest()==receipt['source_sha256'],'Wrong pinned source')
    need(sha256(new_path.read_bytes()).hexdigest()==receipt['emitted_word_sha256'],'Wrong packed artifact')
    need(sha256(new_raw).hexdigest()==receipt['emitted_payload_sha256'],'Wrong decompressed artifact')
    c=changed['canonical'];r=list(map(F,R[5]));gram=sum(x*x for x in r)
    need(gram==56,'Changed mode Gram')
    A=[[F(i==j)-r[i]*r[j]/4 for j in range(112)] for i in range(112)]
    need([[F(x) for x in row] for row in changed['A5']]==A,'Wrong emitted scalar code')
    records=[]
    for direction in ('forward','backward'):
        back=direction=='backward';program=changed['programs'][direction]
        prior=original['programs'][direction]
        index=[i for i,e in enumerate(prior) if e[0]=='center'][5]
        prefix=program[:106];tail=program[106:]
        need(len(tail)==len(prior),'Unexpected source length change')
        differences=[i for i,(a,b) in enumerate(zip(tail,prior)) if a!=b]
        need(differences==[index],'Change extends beyond selected centre')
        need(tail[index]==['scalar',['clear',['C',0]],prior[index][3]],'Wrong centre disposal chart')
        need(Counter(e[1][0] for e in prefix)=={'clear':2,'add':104},'Unexpected prefix grammar')
        rows,paid,norm,counts=replay(c,program)
        expected=[{(i,()):F(1)} for i in range(632)]+[{}]
        for i in range(112):
            for j in range(112):
                if A[i][j]:
                    if back:sparse_add(expected[j],{(112+i,()):F(1)},-A[i][j])
                    else:sparse_add(expected[112+i],{(j,()):F(1)},A[i][j])
        need(rows==expected,'Independent complete-source endpoint failed')
        need(paid==Counter({int(k):v for k,v in receipt['outcomes'][direction]['paid_profile'].items()}),
             'Independent paid inventory differs')
        need(norm==F(receipt['outcomes'][direction]['normalized_prefix_l1']),'Logical prefix envelope differs')
        records.append({'orientation':direction,'original_rows':632,'arbitrary_helpers':408,
                        'owned_zero_at_return':True,'all_scalar_and_paid_frames_checked':True,
                        'source_changes_after_prefix':differences,'prefix_ADDs':104,'prefix_CLEARs':2,
                        'paid_profile':dict(sorted(paid.items())),'normalized_prefix_l1':str(norm)})

    F9=ce.fourier(9);Q=ce.cgate(9,1);P=probe.ma.source_paulis(ce,ca)
    grades=Counter();phase_checks=0;active=[]
    for i,item in enumerate(normals):
        K=word_op(ce,item['K_word']);q=ca['ports'][i]
        need(same(K.then(F9),F9.then(K)),'K failed to commute with full Gaussian')
        bare=K.adjoint().then(Q).then(K) # K Q K^-1
        candidate=ce.cgate(9,q,-1).then(ce.Op(9,ce.identity(9),[('phase',1)]))
        need(same(bare,candidate),'Bare-head conjugation phase differs')
        phase_checks+=1
        if not r[i]:continue
        U=ce.canonical_frame(9,ca['frames'][ca['start'][i]])
        M=Q.then(K).then(U) # M_i=U_i K_i Q
        need(ce.rank([x for x,z,p in M.tab[9:]])==0,'Input wrapper ceased to be monomial')
        transformed=F9.adjoint().then(M).then(F9)
        grades[ce.rank([x for x,z,p in transformed.tab[9:]])]+=1
        need((P[i][0]&1)==(P[i][1]&1),'Shared stage coordinate is not Y/I')
        active.append(i)
    need(grades=={2:56},'Unexpected extra chart cost for entry wrapper')
    helper=[]
    for owner,coefficient in suffix['capture']['helper_terms']:
        need(ca['start'][owner]==0,'Dirty helper does not start ground')
        need(ca['final'][owner]==1,'Dirty helper is not a literal full-frame return')
        need(same(ce.canonical_frame(9,ca['frames'][ca['final'][owner]]),F9),
             'Helper final full frame is not phase-exact F9')
        helper.append({'owner':owner,'coefficient':coefficient,'start_frame':0,'final_frame':1})
    need(len(helper)==48,'Wrong helper capture support')
    # Disjoint-stage P_i commute because their only overlapping coordinate
    # has (X,Z)=(0,0) or (1,1). This is not a claim about the bare terminal heads.
    cross_pairs=sum(1 for i in active for j in active
                    if ((P[i][0]&1)*(P[j][1]&1)+(P[i][1]&1)*(P[j][0]&1))%2==0)
    need(cross_pairs==56*56,'Cross-stage entrance Pauli commutation failed')
    costs=[]
    for exponent in (0.0,0.0030217758,0.0041):
        saved=7*8**(1-exponent);lost=2*25**(1-exponent)+57**(1-exponent)
        costs.append({'c':exponent,'seven_rank8_savings':saved,
                      'optimistic_one_exception_per_negative_bank_cost':lost,'net_extra':lost-saved})
    frontier=json.loads((HERE/'CHART-FRONTIER.json').read_text())
    expected_counts=[1,255,10795,97155,200787,97155,10795,255,1]
    need(frontier['even_subspaces_enumerated_by_dimension']==expected_counts,'Wrong subspace census')
    out={'status':'PASS_INDEPENDENT_632_OWNER_REPLAY_AND_EXACT_TERMINAL_GAUGE',
         'pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                 for p in (old_path,new_path,receipt_path,suffix_path)},
         'independent_interpreter':'This file does not call native_core.replay; it uses a separate sparse free-word interpreter and checks all physical frame incidences of every changed/emitted event.',
         'orientations':records,
         'terminal_gauge':{'all112_literal_bare_head_checks':phase_checks,
                           'formula':'K_i Q K_i^-1=C(-X_qi)=i C(X_qi)^*; at widthm the scalar is i^m.',
                           'J5':'Q^-1 C5^-1 Q=I-(Q^-1 diagK^-1 r5^T)(r5 diagK Q)/52',
                           'ordinary_diagK_chart':'diagK J5 diagK^-1=I-diag(C(-X_q)^*) r5^T r5 diag(C(-X_q))/52',
                           'entry_family_chart_obligation':'M_i=U_i K_i Q is ordinary but F9 M_i F9^-1 has grade2 at all56 active ports.',
                           'entry_family_extra_grades':dict(grades),
                           'common_F9_chart':'J5 commutes with F9, so a uniform F9 return chart leaves J5 unchanged.'},
         'retained_dirty_mode':{'helper_terms':helper,'formula':'sum S5_h raw_helper_h = F9 S5H; sum R5_i raw_X_i = F9 R5X.',
                                'helper_ADDs':48,'clean_X_ADDs':56,'new_queries':0,
                                'scope':'Both are native raw returns. Their existence alone supplies no inverse F9 or free actual Y scatter.'},
         'cross_stage_entrance_Paulis':{'all_pairs_checked':cross_pairs,'shared_axis_local_bit':0,
                                        'reason':'Every local head has Y or I on the shared coordinate; fresh blocks are disjoint.',
                                        'scope':'An exact entrance-family property, not a simplification of the actual bare-X terminal family.'},
         'optimistic_rectangular_population_price':costs,
         'rectangular_price_scope':'The actual three negative terminal jobs have ranks25,25,57. The optimistic111-owner-per-negative-bank architecture discards or independently serves one entire job per bank. A different joint exception supplier or lower-rank helper transfer is outside this price test.',
         'chart_frontier_review':{'RREF_subspace_counts':expected_counts,'total_even_subspaces':sum(expected_counts),
                                  'coverage_argument':'For W outside even parity, A=W intersect E8 leaves all odd-point equivalences unchanged and removes exactly one A-coset from nonzero heads. Empty cosets cannot improve the objective, so the search need only test covered cosets.',
                                  'scope':'Logical review of exhaustive C++ enumeration plus independent physical winning-witness replay in chart_frontier.py and absolute-phase routed-column replay in exit_head_probe.py; not a second full exhaustive implementation.',
                                  'cost_warning':'d+heads and8d+heads are first-rank-mass comparisons. A paid rankd query is priced as d^(1-c), not d distinct unit-query invoices. Output chart costs remain mandatory.'},
         'new_kappa_claim':False}
    (HERE/'CENTER5-INDEPENDENT-REVIEW.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('pins','retained_dirty_mode')},indent=2))


if __name__=='__main__':main()
