#!/usr/bin/env python3
"""Exact paired-digit Bell provider for the source-R5 self-average.

This is a single-output arbitrary-input provider.  Its two chart boundaries
each use8*floor(m/2) Gaussian bits; the normalized rank envelope is[4,4].
The constant odd leftover column is expanded into two ordinary monomials.
All source phases are preserved.  No caller or kappa improvement is claimed.
"""
from decimal import Decimal as D, localcontext
from hashlib import sha256
from pathlib import Path
import json
import sys
import time

import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import probe
sys.path.insert(0,str(ROOT/'research/alternative_gadgets_next'))
from self_average_provider import gaussian_inverse_num,phase_rotate,permute


def need(value,message):
    if not value:raise AssertionError(message)


def phase_op(ce,n,p):
    return ce.Op(n,ce.identity(n),[('phase',p%4)])


def pair_rows(rows):
    return tuple(rows)+tuple(x<<9 for x in rows)


def head_monomial(ce,q):
    """Literal B^-1 (C(-Xq) tensor C(-Xq)) B on two9-bit columns."""
    n=18
    quadratic=tuple(q if j<8 and (q>>j)&1 else 0 for j in range(n))
    linear=tuple(3 if j<8 and (q>>j)&1 else 0 for j in range(n))
    rows=[1<<j for j in range(n)]
    for j in range(8):
        if (q>>j)&1:rows[9+j]^=q
    return ce.diag(n,quadratic,linear).then(ce.perm(n,rows)).then(
        ce.xgate(n,q<<9)).then(phase_op(ce,n,2))


def raw_walsh(real,imag,axes):
    real,imag=real.copy(),imag.copy()
    columns=real.shape[1]
    for bit in axes:
        for value in (real,imag):
            view=value.reshape(-1,2,1<<bit,columns)
            a,b=view[:,0].copy(),view[:,1].copy()
            view[:,0],view[:,1]=a+b,a-b
    return real,imag


def cnot_pairs(real,imag,m):
    index=np.arange(len(real),dtype=np.int64)
    dest=index.copy()
    for pair in range(m//2):
        first=18*pair
        dest^=((index>>first)&255)<<(first+9)
    rr,ii=np.empty_like(real),np.empty_like(imag)
    rr[dest],ii[dest]=real,imag
    return rr,ii


def chart_raw(real,imag,A,m,inverse=False):
    axes=[18*pair+j for pair in range(m//2) for j in range(8)]
    if inverse:
        real,imag=raw_walsh(real,imag,axes)
        real,imag=cnot_pairs(real,imag,m)
        return permute(real,imag,probe_ce.inv(A,9),m)
    real,imag=permute(real,imag,A,m)
    real,imag=cnot_pairs(real,imag,m)
    return raw_walsh(real,imag,axes)


def paired_route(real,imag,q,m):
    index=np.arange(len(real),dtype=np.int64)
    dest=index.copy()
    count=np.zeros(len(real),dtype=np.int8)
    local=np.array([probe_ce.parity(q&x) for x in range(256)],dtype=np.int8)
    for pair in range(m//2):
        first=18*pair
        delta=local[(index>>first)&255]
        dest^=(1-delta).astype(np.int64)*(q<<(first+9))
        count+=2-delta
    rr,ii=np.empty_like(real),np.empty_like(imag)
    for phase in range(4):
        selected=((count&3)==phase)
        a,b=phase_rotate(real[selected],imag[selected],phase)
        rr[dest[selected]],ii[dest[selected]]=a,b
    if m%2:
        # One leftover C(-Xq)=(1+i)I/2-(1-i)Xq/2.  The returned numerator
        # has one additional denominator2, not a Gaussian query.
        shifted=index^(q<<(9*(m-1)))
        r0,i0=rr,ii
        rr=r0-i0-r0[shifted]-i0[shifted]
        ii=r0+i0-i0[shifted]+r0[shifted]
    return rr,ii


def finite_check(A,qs,m):
    size=1<<(9*m)
    if m==1:
        real=np.eye(size,dtype=np.int64);imag=np.zeros_like(real)
        description='all512 standard basis inputs'
    else:
        rng=np.random.default_rng(20261023)
        real=rng.integers(-3,4,size=(size,2),dtype=np.int64)
        imag=rng.integers(-3,4,size=(size,2),dtype=np.int64)
        description='two deterministic dense Gaussian-integer inputs'
    direct_r,direct_i=np.zeros_like(real),np.zeros_like(imag)
    for q in qs:
        rr,ii=gaussian_inverse_num(real,imag,q,m)
        direct_r+=rr;direct_i+=ii
    direct_r,direct_i=phase_rotate(direct_r,direct_i,m)
    wr,wi=chart_raw(real,imag,A,m)
    total_r,total_i=np.zeros_like(real),np.zeros_like(imag)
    for q in qs:
        rr,ii=paired_route(wr,wi,probe_ce.mv(A,q),m)
        total_r+=rr;total_i+=ii
    total_r,total_i=chart_raw(total_r,total_i,A,m,inverse=True)
    # Direct denominator2^m; Bell entry+exit denominator2^(8floor(m/2)),
    # plus denominator2 for the unpaired last column ifm is odd.
    scale=1<<(8*(m//2)+(m%2)-m)
    need(np.array_equal(total_r,direct_r*scale),'Bell average real mismatch')
    need(np.array_equal(total_i,direct_i*scale),'Bell average imaginary mismatch')
    return {'width':m,'array_length':size,'tests':description,
            'direct_denominator_before_average':1<<m,
            'provider_denominator_before_average':1<<(8*(m//2)+(m%2)),
            'all_entries_equal_over_Gaussian_integers':True,
            'direct_output_sha256':sha256(direct_r.tobytes()+direct_i.tobytes()).hexdigest()}


def main():
    global probe_ce
    start=time.monotonic()
    ce,ca,normals,R,routes=probe.cc.source_data();probe_ce=ce
    active=[i for i in range(112) if R[5][i]]
    qs=[ca['ports'][i] for i in active]
    need(len(qs)==56 and len(set(qs))==56,'Changed actual sourceR5 support')
    W=probe.bit_basis(ce,qs)
    need(len(W)==8,'Changed bare-head span')
    basis=ce.basis_extend(W,9)
    A=ce.inv(ce.transpose(basis,9),9)
    need(all(ce.mv(A,q)<256 for q in qs),'Heads escaped Bell coordinates')
    cnot_rows=[1<<j for j in range(18)]
    for j in range(8):cnot_rows[9+j]^=1<<j
    B=ce.hadamard(18,range(8)).then(ce.perm(18,cnot_rows))
    V=ce.perm(18,pair_rows(A)).then(B.adjoint())
    boundary_grades=[ce.rank([x for x,z,p in op.tab[18:]]) for op in (V,V.adjoint())]
    need(boundary_grades==[8,8],'Wrong two-column Gaussian boundary grades')
    records=[];columns=0
    # Full Clifford conjugation, then all2^8 control patterns and two Pauli
    # amplitudes.  The two inactive coordinates are untouched spectators.
    for i,q in zip(active,qs):
        mapped=ce.mv(A,q)
        direct=ce.cgate(18,q,-1).then(ce.cgate(18,q<<9,-1)).then(phase_op(ce,18,2))
        conjugated=V.adjoint().then(direct).then(V)
        M=head_monomial(ce,mapped)
        need(conjugated.tab==M.tab,'Literal Bell conjugation tableau failed')
        for u in range(256):
            delta=ce.parity(u&mapped)
            # C(-Xq)=aI-bXq; 2a²=i,2b²=-i,2ab=1.  On Bell labels,
            # the identity numerator is i(1-(-1)^delta), and the v+q
            # numerator is -(1+(-1)^delta).  These exact numerators
            # compare the two possible destinations and absolute phases.
            identity_num=(0,1-(-1)**delta)
            shifted_num=(-1-(-1)**delta,0)
            expected_identity=(0,2) if delta else (0,0)
            expected_shifted=(0,0) if delta else (-2,0)
            need(identity_num==expected_identity and shifted_num==expected_shifted,
                 'Bell Gaussian integer phase formula failed')
            exponent=(2+ce.qvalue(M.circuit[0][1],M.circuit[0][2],u,18))%4
            need(exponent==(2-delta)%4,'Literal diagonal phase failed')
            columns+=1
        records.append({'port':i,'q':q,'chart_q':mapped,
                        'pair_monomial_word':M.circuit,
                        'pair_formula':'delta=parity(u & chart_q); (u,v)->(u,v xor ((1-delta)*chart_q)); phase=i^(2-delta)'})
    checks=[]
    for m in (1,2):
        check=finite_check(A,qs,m);checks.append(check)
        print('BELL_AVERAGE_WIDTH',m,'PASS',round(time.monotonic()-start,2),flush=True)
    sibling=ROOT/'research/alternative_gadgets_next/SELF-AVERAGE-PROVIDER.json'
    independent=[]
    if sibling.exists():
        previous=json.loads(sibling.read_text())
        for check in checks:
            other=next(x for x in previous['finite_exact_checks'] if x['width']==check['width'])
            need(check['direct_output_sha256']==other['direct_output_sha256'],
                 'Independent provider phase hash mismatch')
            independent.append({'width':check['width'],'same_direct_output_sha256':True})
    prices=[]
    for c_string in ('0','0.0030217758','0.0041'):
        with localcontext() as ctx:
            ctx.prec=65;c=D(c_string);p=1-c
            cost=2*(D(4)**p);baseline=D(8)**p
            prices.append({'c':c_string,'paired_boundary_moment':str(cost),
                           'single_rank8_moment':str(baseline),
                           'moment_excess':str(cost-baseline),
                           'cost_ratio':str(cost/baseline)})
    result={
        'status':'PASS_EXACT_SOURCE_R5_PAIRED_BELL_SELF_AVERAGE_PROVIDER',
        'source_R_row':5,'normalizer_mode_row_for_same_projector':7,
        'source_R_sha256':sha256((ROOT/'research/tensor_obstruction/inputs/R.json').read_bytes()).hexdigest(),
        'target':'T_m=(1/56) sum_{i:sourceR5_i!=0} C(-X_qi)^(tensor m)',
        'input_scope':'one arbitrary complex array on9m bits, with every other live array retained',
        'physical_head_span_basis':W,'head_span_dimension':8,
        'coordinate_change_rows':A,
        'pair_B_definition':'B|u,v>=(1/16) sum_x (-1)^(u dot x)|x,x+v> on the8 active coordinates; both ninth coordinates are spectators',
        'entry_pair_word':V.circuit,'exit_pair_word':V.adjoint().circuit,
        'literal_two_column_query_ranks':boundary_grades,
        'normalized_rank_envelope':[4,4],
        'rank_convention':'Each boundary uses one Gaussian transform on8*floor(m/2) active bits, after a free bit regrouping; this is a rank8 child at widthfloor(m/2), normalized by the original widthm. Its rank is at most4, with10*floor(m/2)+9*(m%2) spectator bits. This is not a base9 rank4 tensor-power word.',
        'pair_identity':'B^-1 [C(-Xq) tensor C(-Xq)] B|u,v> = -|u,v+q> when u dot q=0, and i|u,v> when u dot q=1',
        'all_width_ordinary_routes':'On every paired column apply the emitted affine permutation and i^(2-delta) phase; multiply pair phases. Ifm is even there are56 routes. Ifm is odd, expand the final C(-Xq)=(1+i)I/2-(1-i)Xq/2, giving112 routes. The factor1/56 is applied once after the sum.',
        'ordinary_schedule':[
            'Copy the input into one owned work array; apply its coordinate permutation A to every digit column.',
            'On adjacent digit pairs apply inverse Bell: eight CNOTs, then one shared Gaussian query with diagonal S wrappers on8*floor(m/2) active bits.',
            'Gather the56 paired affine-phase routes, or112 routes for an odd leftover column, into one owned zero aggregate; multiply by1/56.',
            'Apply the inverse boundary once to this one aggregate: one Gaussian query with the matching S wrappers, CNOTs, and A^-1 permutations.',
            'Return the aggregate output and CLEAR only disposable owned work after use.'
        ],
        'scratch_array_upper_bound':3,
        'ordinary_admission':'Fixed signed monomial sums, coordinate XORs, parity phases and adjacent-column regrouping; all functions are source-fixed and whole-width ordinary under the previously declared Boolean compiler premise.',
        'exact_pair_tableau_checks':len(records),
        'exact_control_phase_cases':columns,
        'finite_exact_checks':checks,
        'independent_provider_cross_checks':independent,
        'local_prices':prices,
        'all_width_proof':'The exact pair identity follows by expanding the two Gaussian heads into their4 terms and collecting the two Bell destinations; the literal monomial word has the same tableau and exact phase. Tensor overfloor(m/2) pairs and use the separately checked two-term final-column identity whenm is odd. Summing the56 source terms preserves arbitrary inputs, including the kernel of T_m; no inverse of T_m is used.',
        'ports':records,
        'scope':'A single shared-output kernel provider. Fresh[4,4] boundaries do not beat one rank8 query for0<c<1; their ratio is2^c. Retaining or sharing a genuine boundary could matter, but requires actual chronological entry/exit bindings and caller credit. No new kappa is claimed.',
        'elapsed_seconds':time.monotonic()-start,
    }
    target=HERE/'BELL-SELF-AVERAGE.json'
    target.write_text(json.dumps(result,indent=2)+'\n')
    print('RECEIPT',target,'normalized ranks[4,4]',flush=True)


if __name__=='__main__':main()
