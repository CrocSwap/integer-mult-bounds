#!/usr/bin/env python3
"""Actual scalar-center-free S plus gathered rank8 contacts: augmentation.

This uses the emitted helper-clean word with physical_add tails omitted,
not snapshots borrowed from the original center-retaining native word.
"""
from collections import defaultdict,Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import pickle
import sys
import time
import argparse

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import augmented_rank1_observers as obs
fc=obs.fc


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mode5',action='store_true');args=ap.parse_args()
    started=time.monotonic();stem='MODE5' if args.mode5 else 'ALL8'
    sp=ROOT/('research/retained_state_next/F9-SOURCE-DAG-'+stem+'-WORD.json.gz')
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    raw=sp.read_bytes();source=json.loads(gzip.decompress(raw));c=source['canonical']
    R=[[F(a) for a in r] for r in json.loads(rp.read_text())]
    program=[e for e in source['programs']['backward'] if e[0]!='physical_add']
    extra=source['owned_extra_slots_by_direction']['backward'];owned=1+extra
    selected=[5] if args.mode5 else list(range(8))
    assert sum(e[0]=='center' for e in program)==8-len(selected)
    rows=[{i:F(1)} for i in range(632)]+[{} for _ in range(owned)];cur=c['start'][:]+[None]*owned
    full=[];fullseen=set();frame8=defaultdict(list);frameseen=defaultdict(set);counts=Counter();paid=Counter()
    def observe(owner,event):
        if cur[owner] is None or not rows[owner]:return
        rank=len(c['frames'][cur[owner]])
        if rank not in (8,9):return
        counts[rank]+=1;row=dict(rows[owner]);key=tuple(sorted(row.items()))
        desc={'owner':owner,'after_emitted_event':event,'frame':cur[owner]}
        if rank==9:
            if key not in fullseen:fullseen.add(key);full.append((desc,row))
        elif key not in frameseen[cur[owner]]:
            frameseen[cur[owner]].add(key);frame8[cur[owner]].append((desc,row))
    for owner in range(632):observe(owner,-1)
    for pos,e in enumerate(program):
        typ=e[0];d=None
        if typ=='scalar':
            a,f=e[1:];d=a[1][1]+(632 if a[1][0]=='C' else 0)
            if a[0]=='clear':rows[d]={};cur[d]=f
            else:
                assert cur[d]==f
                if a[0] in ('add','copy'):
                    s=a[2][1]+(632 if a[2][0]=='C' else 0);assert cur[s]==f
                    if a[0]=='copy':rows[d]=dict(rows[s])
                    else:rows[d]=fc.add(rows[d],fc.scale(rows[s],F(a[3],a[4])))
                else:rows[d]=fc.scale(rows[d],F(a[2],a[3]))
        elif typ=='warp':d=e[1][1]+(632 if e[1][0]=='C' else 0);assert cur[d]==e[3];cur[d]=e[4]
        elif typ=='climb':d=e[2];assert cur[d]==e[3];cur[d]=e[4];paid[e[5]]+=1
        elif typ=='center':d=632+e[1];assert cur[d]==e[2];cur[d]=e[3];paid[e[4]]+=1
        else:assert typ in ('phase','adapter')
        if d is not None:observe(d,pos)
    assert cur[:632]==c['final'] and all(not row for row in rows[632:])
    # Exact source endpoint of the helper-clean scalar A producer.
    for i in range(632):
        expected={i:F(1)}
        if i<112:
            expected[i+112]=F(-1)
            for k in selected:
                r=R[k]
                if r[i]:
                    for j,a in enumerate(r):
                        if a:expected[j+112]=expected.get(j+112,F(0))+r[i]*a/4
        expected={k:a for k,a in expected.items() if a}
        assert rows[i]==expected
    sbasis=fc.sparse_basis(full);pivots=[(owner,br[0]) for owner,br in sorted(sbasis.items())]
    targets=[obs.reduce_with_pivots({i+112:a for i,a in enumerate(r) if a},pivots) for r in R]
    print('CENTER_FREE_S','full_snapshots',counts[9],'unique',len(full),'rank',len(sbasis),'rank8',counts[8],flush=True)
    candidate=[];details=[];qcontacts={}
    for f,contacts in sorted(frame8.items()):
        qrows=[];seen=set()
        for d,row in contacts:
            q=obs.reduce_with_pivots(row,pivots);key=tuple(sorted(q.items()))
            if key not in seen:seen.add(key);qrows.append((d,q))
        qcontacts[f]=qrows
        rank,solutions=obs.intersection(qrows,targets)
        details.append({'frame':f,'unique_contacts':len(contacts),'quotient_rank':rank,'R_intersection_dimension':len(solutions)})
        for target,recipe in solutions:
            candidate.append(({'frame':f,'target_modes':{str(k):str(a) for k,a in target.items()},
                'gather':[dict(qrows[j][0],coefficient=str(a)) for j,a in sorted(recipe.items())]},target))
    allq=[(d,q) for rs in qcontacts.values() for d,q in rs]
    globalrank,globalsolutions=obs.intersection(allq,targets)
    out={'schema':'actual-center-free-rank1-snapshot-augmentation/v1','source_sha256':sha256(raw).hexdigest(),
        'R_sha256':sha256(rp.read_bytes()).hexdigest(),'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'all632_originals_arbitrary':True,'all408_helpers_retained':True,'physical_slots':632+owned,
        'deleted_source_modes':selected,
        'complete_augmented_source_endpoint_pass':True,'native_paid_profile':dict(paid),
        'raw_full_snapshots':counts[9],'full_snapshot_augmentation_rank':len(sbasis),
        'raw_rank8_contacts':counts[8],'rank8_frames':len(frame8),'frame_results':details,
        'same_frame_mode_directions':len(candidate),'combined_same_frame_mode_rank':len(fc.sparse_basis(candidate)),
        'candidate_gathers':[d for d,v in candidate],
        'unrestricted_frame_mixing_quotient_rank':globalrank,'unrestricted_frame_mixing_R_intersection_dimension':len(globalsolutions),
        'scope':'Necessary fixed-|0> augmentation of the actual helper-clean scalar-center-free word. Same-frame scalar rank8 input gathers plus all its actual full-frame snapshots. Arbitrary new physical monomial input recodings or changed native contacts are outside this screen; cross-frame mixing is only an uncharged upper-bound control.',
        'elapsed_seconds':time.monotonic()-started,'new_kappa_claimed':False}
    outstem='MODE5-FREE-RANK1' if args.mode5 else 'CENTER-FREE-RANK1'
    (HERE/(outstem+'-AUGMENTATION.json')).write_text(json.dumps(out,indent=2)+'\n')
    (HERE/(outstem+'-CONTACTS.pickle')).write_bytes(pickle.dumps({'full':full,'pivots':pivots,'targets':targets,'byframe':qcontacts},protocol=5))
    print('CENTER_FREE_RESULT','sameframe',len(candidate),'combinedrank',out['combined_same_frame_mode_rank'],'unrestricted',len(globalsolutions),'seconds',time.monotonic()-started,flush=True)


if __name__=='__main__':main()
