#!/usr/bin/env python3
"""Independent replay of helper-clean source DAGs and rational two-copy codes.

Every original column, frame, source lifetime and paid child is checked.
The two-copy program synchronizes both producer DAGs before either consumer;
it never reads a future output or treats an arbitrary original as scratch.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import copy
import gzip
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import probe
from review_center5 import sparse_add,same
from review_f9_shared_center import conjugate


def need(x,msg):
    if not x:raise AssertionError(msg)


def prepend(word,k,g):
    power=k
    while word and word[0]==g:
        power+=1;word=word[1:]
    return (g,)*(power%4)+word


def replay(ce,c,program,back,extra,fsym,copies=1,kind='F'):
    no=632*copies;owned=(1+extra)*copies
    rows=[{(i,()):F(1)} for i in range(no)]+[{} for _ in range(owned)]
    cur=c['start']*copies+[None]*owned
    paid=Counter();maxnorm=F(1);peak=0;live_owned=set();counts=Counter();physical=0
    def index(ref):
        need(ref[0] in ('L','C'),'Unknown owner namespace')
        i=ref[1]+(no if ref[0]=='C' else 0)
        need(0<=i<no+owned,'Owner outside declared allocation')
        if ref[0]=='L':need(i<no,'Original owner out ofrange')
        return i
    for pos,e in enumerate(program):
        typ=e[0];counts[typ]+=1;dst=None
        if typ=='scalar':
            op,f=e[1:];dst=index(op[1]);name=op[0]
            if name=='clear':
                need(dst>=no,'Erasing an arbitrary original')
                rows[dst]={};cur[dst]=f
            else:
                need(cur[dst]==f,('Scalar targetframe',pos,e,cur[dst]))
                if name in ('copy','add'):
                    src=index(op[2]);need(cur[src]==f,('Scalar sourceframe',pos,e,cur[src]))
                    if name=='copy':
                        need(dst>=no,'Overwriting an arbitrary original')
                        rows[dst]=dict(rows[src])
                    else:
                        need(dst!=src,'Self ADD')
                        sparse_add(rows[dst],rows[src],F(op[3],op[4]))
                elif name=='scale':
                    a=F(op[2],op[3]);rows[dst]={key:a*v for key,v in rows[dst].items() if a*v}
                else:raise AssertionError('Badscalar')
        elif typ=='warp':
            _,ref,letter,f,g=e;dst=index(ref);need(cur[dst]==f,'Warp frame')
            letter=(1 if letter>0 else -1)*(abs(letter)+(1000000 if back else 0))
            changed={}
            for (i,w),v in rows[dst].items():
                w=w[1:] if w and w[0]==-letter else (letter,)+w
                key=(i,w);changed[key]=changed.get(key,F(0))+v
            rows[dst]={key:v for key,v in changed.items() if v};cur[dst]=g
        elif typ=='climb':
            _,_,dst,f,g,rank=e
            need(0<=dst<no and cur[dst]==f,'Climb incidence')
            need(rank==len(c['frames'][g])-len(c['frames'][f]) and rank>0,'Climb rank')
            cur[dst]=g;paid[rank]+=1
        elif typ=='center':
            _,slot,f,g,rank=e;dst=no+slot
            need(no<=dst<no+owned and cur[dst]==f,'Center incidence')
            need(rank==abs(len(c['frames'][g])-len(c['frames'][f])),'Center rank')
            cur[dst]=g;paid[rank]+=1
        elif typ=='physical_add':
            _,dr,sr,num,den,df,sf,word=e;dst=index(dr);src=index(sr)
            need(cur[dst]==df and cur[src]==sf,('Physical ADD incidence',pos,e))
            need((df,sf)==((1,0) if back else (0,1)),'Changed physical framepair')
            need(word in ([],[['X',511]]),'Unverified physical monomial')
            if not back:
                need(dst>=no and src<no and src%632<112,'Wrong cleanF9 producer')
                need(rows[src]=={(src,()):F(1)},'SourceX was not complete/clean beforeconsumer')
            else:
                need(dst<no and dst%632<112 and src>=no,'Wrongrawdualcacheuse')
                need(all(112<=i%632<224 and not w for i,w in rows[src]),'Rawdualcache isnot originalgroundY')
            power=3 if word else 1
            value={(i,prepend(w,power,fsym)):v for (i,w),v in rows[src].items()}
            sparse_add(rows[dst],value,F(num,den));physical+=1
        else:
            need(typ in ('phase','adapter','residual_adapter'),'Unknown event')
        if dst is not None:
            if dst>=no:
                if rows[dst]:live_owned.add(dst)
                else:live_owned.discard(dst)
            peak=max(peak,len(live_owned))
            if typ in ('scalar','physical_add'):
                maxnorm=max(maxnorm,sum(map(abs,rows[dst].values()),F(0)))
    need(cur[:no]==c['final']*copies,'Wrong original finalframes')
    need(not live_owned,'Owned arraynotcleared')
    return rows,paid,maxnorm,peak,physical,counts


def expected(R,modes,copies,back,fsym,extra,two_code=False):
    no=632*copies;out=[{(i,()):F(1)} for i in range(no)]+[{} for _ in range((1+extra)*copies)]
    for c in range(copies):
        off=632*c
        for i in range(112):
            d,s=(off+i,off+112+i) if back else (off+112+i,off+i)
            sparse_add(out[d],{(s,()):F(1)},-1 if back else 1)
        for k in modes:
            for i,ri in enumerate(R[k]):
                if not ri:continue
                for j,rj in enumerate(R[k]):
                    if not rj:continue
                    a=ri*rj/4
                    d=off+i if back else off+112+i
                    same_source=off+112+j if back else off+j
                    # Baseline A_T=I-sum r^Tr/4 on eachcopy.
                    sparse_add(out[d],{(same_source,()):F(1)},a if back else -a)
                    if not two_code:
                        sparse_add(out[d],{(same_source,(fsym,)):F(1)},-a if back else a)
                    else:
                        other=632*(1-c)+(112+j if back else j)
                        power=3 if c==0 else 1
                        factor=F(6,7) if c==0 else F(1)
                        # Forward Cplus and rawdual inverse-code Cminus:
                        # both endpoints add +uG; thebase rawdual is-A_T.
                        sparse_add(out[d],{(other,(fsym,)*power):F(1)},a*factor)
    return out


def remap(program,c,extra,back,two_code):
    owned=1+extra;out=[]
    def ref(x,copy_index):return [x[0],x[1]+copy_index*(632 if x[0]=='L' else owned)]
    for event in program:
        e=copy.deepcopy(event);t=e[0]
        if t=='scalar':
            e[1][1]=ref(e[1][1],c)
            if e[1][0] in ('copy','add'):e[1][2]=ref(e[1][2],c)
        elif t=='warp':e[1]=ref(e[1],c)
        elif t in ('climb','adapter'):e[2]+=632*c
        elif t=='center':e[1]+=owned*c
        elif t=='physical_add':
            e[1]=ref(e[1],c);e[2]=ref(e[2],1-c if two_code else c)
            if two_code:
                a=F(e[3],e[4])*(F(6,7) if c==0 else F(1))*(-1 if back else 1)
                e[3],e[4]=a.numerator,a.denominator;e[-1]=[['X',511]] if c==0 else []
        out.append(e)
    return out


def two_copy_program(blob,back):
    direction='backward' if back else 'forward';program=blob['programs'][direction]
    extra=blob['owned_extra_slots_by_direction'][direction]
    if back:
        cut=next(i for i,e in enumerate(program) if e[0]=='physical_add')
    else:
        cut=next(i for i,e in enumerate(program) if e==['phase','consume_retained_source_snapshots'])
    pieces=[remap(program,c,extra,back,True) for c in (0,1)]
    # Both prefixes complete before either crossedconsumer reads.
    if back:
        # Each copy's ground Y cache is read by the opposite copy.  Keep
        # every cache alive until both sets of crossed consumers finish.
        tail=pieces[0][cut:]+pieces[1][cut:]
        need(all(e[0]=='physical_add' or
                 (e[0]=='scalar' and e[1][0]=='clear') for e in tail),
             'Unexpected backward tail event')
        return (pieces[0][:cut]+pieces[1][:cut]+
                [e for e in tail if e[0]=='physical_add']+
                [e for e in tail if e[0]=='scalar'])
    return pieces[0][:cut]+pieces[1][:cut]+pieces[0][cut:]+pieces[1][cut:]


def main():
    started=time.monotonic()
    ce,ca,normals,R,routes=probe.cc.source_data()
    source_path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    source=json.loads(gzip.decompress(source_path.read_bytes()));records=[];blobs={}
    F9=ce.fourier(9);Fsquare=F9.then(F9)
    need(same(Fsquare,ce.xgate(9,511)),'F9square phase differsfromX511')
    need(same(conjugate(ce,F9).adjoint(),F9),'BackwardidentityADD logicalframeeffect differs')
    for tag in ('MODE5','ALL8'):
        path=ROOT/f'research/retained_state_next/F9-SOURCE-DAG-{tag}-WORD.json.gz'
        rpath=ROOT/f'research/retained_state_next/F9-SOURCE-DAG-{tag}.json'
        payload=gzip.decompress(path.read_bytes());blob=json.loads(payload);claim=json.loads(rpath.read_text());blobs[tag]=blob
        need(sha256(path.read_bytes()).hexdigest()==claim['word_sha256'],'SourceDAG gziphash')
        need(sha256(payload).hexdigest()==claim['word_payload_sha256'],'SourceDAG payloadhash')
        need(blob['canonical']==source['canonical'],'Canonicalframeschanged')
        need(blob['source_sha256']==sha256(source_path.read_bytes()).hexdigest(),'Wrongnative source')
        modes=blob['selected_modes'];fsym=blob['normalized_F9_symbol']
        for direction in ('forward','backward'):
            back=direction=='backward';extra=blob['owned_extra_slots_by_direction'][direction]
            program=blob['programs'][direction]
            rows,paid,norm,peak,physical,counts=replay(ce,ca,program,back,extra,fsym)
            want=expected(R,modes,1,back,fsym,extra)
            need(rows==want,'Independenthelper-clean endpointfailed')
            oldpaid=Counter(e[-1] for e in source['programs'][direction] if e[0] in ('climb','center'))
            need(oldpaid-paid==Counter({8:len(modes)}) and not(paid-oldpaid),'Wrongdeletedqueryprofile')
            cc=claim['backward'] if back else claim
            need(norm==F(cc['max_l1_normalized_row']),'Prefixnorm differs')
            need(paid==Counter({int(k):v for k,v in cc['paid_profile'].items()}),'Paidcensus differs')
            if not back:
                need(peak==claim['peak_nonzero_owned_fields_including_original_C0'],'Peakowned countdiffers')
                origins=blob['original_event_origins'];need(len(origins)==len(program),'Originlength')
                paidorigins=[]
                for e,o in zip(program,origins):
                    if e[0] in ('climb','center'):
                        need(o is not None and e==source['programs'][direction][o],'Changed literalpaidchild')
                        paidorigins.append(o)
                need(len(paidorigins)==len(set(paidorigins)),'Duplicated originalpaidchild')
            records.append({'tag':tag,'orientation':direction,'word_sha256':sha256(path.read_bytes()).hexdigest(),
                'all_original_rows':632,'all_arbitrary_helpers':408,'helpers_autonomous':True,
                'paid_profile':dict(sorted(paid.items())),'removed_rank8_queries':len(modes),
                'extra_owned_arrays':extra,'peak_live_owned_including_C0':peak,
                'all_owned_cleared':True,'exact_new_physical_ADDs':physical,
                'max_l1_normalized_row':str(norm)})
            print('CLEAN_DAG_REVIEW',tag,direction,'PASS',round(time.monotonic()-started,2),flush=True)
    # Emit and replaytwoindependentcopies oftheall-eightmodecleanprogram.
    blob=blobs['ALL8'];fsym=blob['normalized_F9_symbol'];two_records=[];programs={}
    for direction in ('forward','backward'):
        back=direction=='backward';extra=blob['owned_extra_slots_by_direction'][direction]
        program=two_copy_program(blob,back);programs[direction]=program
        rows,paid,norm,peak,physical,counts=replay(ce,ca,program,back,extra,fsym,2,'G')
        need(rows==expected(R,blob['selected_modes'],2,back,fsym,extra,True),
             'Two-copyindependent632x2 endpointfailed')
        need(paid==Counter({1:4402,2:824,3:1020,4:254,5:80}),'Two-copyqueryprofile differs')
        two_records.append({'orientation':direction,'all_original_rows':1264,'arbitrary_helper_rows':816,
            'helpers_autonomous':True,'max_l1_normalized_row':str(norm),
            'paid_profile':dict(sorted(paid.items())),'owned_arrays_declared':2*(1+extra),
            'peak_live_owned_arrays':peak,'all_owned_cleared':True,'physical_cross_COPY_ADDs':physical,
            'chronological_producer_before_cross_consumer_verified':True})
        print('TWO_COPY_CLEAN_DAG',direction,'PASS',round(time.monotonic()-started,2),flush=True)
    # Universal projector /inverse-codeproof, with everyRmode's actualsign.
    gram=[[sum(R[k][i]*R[j][i] for i in range(112)) for j in range(8)] for k in range(8)]
    need(gram==[[F(56 if i==j else 0) for j in range(8)] for i in range(8)],'ActualR Gramchanged')
    need(F(14)*F(12)==168 and (-13)**2-168==1,'Inversecodeconstants')
    two_blob={'schema':'independently-replayed-rational-two-copy-clean-DAG/v1',
        'canonical':ca,'programs':programs,'copies':2,'originals_per_copy':632,
        'owned_arrays_per_copy':{d:1+blob['owned_extra_slots_by_direction'][d] for d in programs},
        'source_word_sha256':next(x['word_sha256'] for x in records if x['tag']=='ALL8'),
        'normalized_F9_symbol':fsym,
        'physical_X511_word':'F9^2 exactly, includingphase, tensor-liftedpercolumn',
        'forward_code':'Cplus=A+(I-A)G, G=[[0,(6/7)F^-1],[F,0]]',
        'backward_code':'X-=CminusY withCminus=A-(I-A)G. This is rawdualof thecompanionforwardresidual-G^T, notrawdualofCplus.'}
    twopayload=json.dumps(two_blob,sort_keys=True,separators=(',',':')).encode()
    twopacked=gzip.compress(twopayload,mtime=0)
    (HERE/'TWO-COPY-CLEAN-DAG-WORDS.json.gz').write_bytes(twopacked)
    result={'status':'PASS_INDEPENDENT_HELPER_CLEAN_MODE5_ALL8_AND_RATIONAL_TWO_COPY_SOURCE_DAGS',
        'independent_interpreter':'No importorcall ofnative_core orretainedemitterreplay. All scalar/warp/frame/ownershipsemantics implementedhere; all queriedsourceevents andeveryindependentoriginalcolumn checked.',
        'one_copy_reviews':records,'two_copy_reviews':two_records,
        'two_copy_word_sha256':sha256(twopacked).hexdigest(),
        'two_copy_word_payload_sha256':sha256(twopayload).hexdigest(),
        'two_copy_inverse_codes':{'actual_R_Gram':gram,'P':'sum_k diagK^-1 r_k^T r_k diagK/56, P^2=P',
            'A':'I-14P','G':'[[0,(6/7)F^-1],[F,0]], F=F9^tensor m',
            'G_square':'(6/7)I','Cplus':'I-P+P(-13I+14G)','Cminus':'I-P+P(-13I-14G)',
            'exact_inverse_identity':'Cplus*Cminus=Cminus*Cplus=I; 169-196*(6/7)=1.',
            'coefficients':'Allrational; no square-rootconstant required.',
            'transpose_warning':'G isnot symmetric. The verifiedbackwardcode Cminus is the rawdualof theforwardcompanionwithresidual-G^T.'},
        'caller_warning':'This proves helper-clean filteredsourceprograms and inversecodecouplings, with explicitownedspace. It doesnotprove theactualseven-stagecaller diagonal endpoint, removeitsDinterleaving, oradmitan improvedrecursive moment.',
        'negative_multistage_control':'Although T^-1(C_s D_s)T=diag(I,D_s)A_sdiag(D_s,I) forT=diag(I,Q), copy-mixingA_s doesnotcommutehalf-copyD_t. Aproductofstagesdoesnotcollapse todiag(I,Dword)Aworddiag(Dword,I). ForA=[[-13,12],[14,-13]], d1=1,d2=i, theupperleftdifferencefromthatincorrectformula is168*(1-i).',
        'kappa_improvement_claimed':False,'elapsed_seconds':time.monotonic()-started}
    # FractionsintheactualRGram areintegersexactly.
    result['two_copy_inverse_codes']['actual_R_Gram']=[[int(x) for x in row] for row in gram]
    (HERE/'CLEAN-DAG-INDEPENDENT-REVIEW.json').write_text(json.dumps(result,indent=2)+'\n')
    print('RECEIPT',HERE/'CLEAN-DAG-INDEPENDENT-REVIEW.json',flush=True)


if __name__=='__main__':main()
