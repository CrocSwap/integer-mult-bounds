#!/usr/bin/env python3
"""Actual source-bound balanced sector for arbitrary P-word degree.

Equal Fourier frequency pairs give Q²=I and D0=zeta Q.  At the listed
frequencies R Q R^T=0, so P Q P=0 for sourceR5 and all8 alike.  An exact
12-function minor proves that one-P words and identity words, each with
either zeta power, remain independent on the physical owner space.
"""
from hashlib import sha256
from pathlib import Path
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE));import cross_stage_projector_span as cs


def main():
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    kp=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    R=np.array(json.loads(rp.read_text()),dtype=np.int64)
    qs=[p['q'] for p in json.loads(kp.read_text())['ports']]
    frequencies=[];qvals={}
    for w in range(512):
        q=np.array([(-1)**(1+((w&qi).bit_count()%2)) for qi in qs],dtype=np.int64)
        if not np.any((R*q)@R.T):frequencies.append(w);qvals[w]=q
    assert len(frequencies)==32
    certs=[];prime=65521
    for modes in ([5],list(range(8))):
        rr=R[modes].T@R[modes];basis={};rows=[];samples=[]
        for w in frequencies:
            q=qvals[w];z=(-1)**w.bit_count()
            for i in range(112):
                for j in range(112):
                    vals=[4*int(i==j),4*int(i==j)*q[i]]
                    vals +=[-rr[i,j]*q[i]**a*q[j]**b for a in (0,1) for b in (0,1)]
                    vals=[int(x) for x in vals+[z*x for x in vals]]
                    v=[x%prime for x in vals]
                    for k,b in sorted(basis.items()):
                        c=v[k]
                        if c:v=[(a-c*x)%prime for a,x in zip(v,b)]
                    k=next((k for k,x in enumerate(v) if x),None)
                    if k is not None:
                        inv=pow(v[k],-1,prime);basis[k]=[x*inv%prime for x in v]
                        rows.append(vals);samples.append([w,i,j])
                    if len(rows)==12:break
                if len(rows)==12:break
            if len(rows)==12:break
        assert len(rows)==12;det=cs.determinant(rows);assert det
        certs.append({'source_modes':modes,'function_count':12,'rank':12,
            'functions':'I,Q,P,PQ,QP,QPQ, each times1 andzeta','matrix_scale':4,
            'exact_integer_minor_determinant':str(det),'samples_w_i_j':samples,
            'integer_minor':rows})
    out={'schema':'actual-source-balanced-width2-sector/v1',
        'R_sha256':sha256(rp.read_bytes()).hexdigest(),'normalizers_sha256':sha256(kp.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'balanced_frequencies':frequencies,'balanced_frequency_count':len(frequencies),
        'zeta_values_present':sorted(set((-1)**w.bit_count() for w in frequencies)),
        'all_eight_by_eight_RQR_entries_zero_at_every_frequency':True,
        'identities':['P=-R_selected^T R_selected/4','P²=-14P','PQP=0','Q²=I','D0=zeta Q'],
        'independence_certificates':certs,
        'external_stages':'Every D1,…,D6 sign is independently realized by choosing an equal frequency pair on one of that stage’s eight disjoint axes. Tensoring the Walsh character table preserves these12 function independences.',
        'use':'Any reduced word with at least twoP factors vanishes on this actual sector. Thus a linear functional on the independentone-P coefficients is an actual operator functional at arbitrary finiteworddegree, rather than a formal-algebra projection.',
        'scope':'A necessary actualwidth2 sector, useful for rulingout declared boundedcontrol families. A positive restricted-sector recipe is not anallwidth caller.'}
    (HERE/'BALANCED-ACTUAL-SECTOR.json').write_text(json.dumps(out,indent=2)+'\n')
    print('BALANCED',frequencies,'determinants',[x['exact_integer_minor_determinant'] for x in certs])


if __name__=='__main__':main()
