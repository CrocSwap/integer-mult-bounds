#!/usr/bin/env python3
"""Pointwise actual witness for arbitrary constant owner-map tangent gates.

Ordinary coefficients are diag(K0_i^-1) M diag(K0_i), with an arbitrary
constant112x112 matrix M, and arbitrary even Gaussian heads.  At a fixed
off-diagonal owner pair, the three source signs qi,qj,zeta are independent.
This removes the fixed-R-coefficient premise from the earlier tangent screen.
"""
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import actual_tangent_reachability as ar
import cross_stage_projector_span as cs
ac=ar.ac;fc=ar.fc


def rank2(vectors):
    basis={}
    for x in vectors:
        while x:
            k=x.bit_length()-1
            if k in basis:x^=basis[k]
            else:basis[k]=x;break
    return len(basis)


def solve_stage(source,prefix,suffix,stage):
    error,at=ar.it.tc.target_error(source,prefix,suffix,stage)
    error=ar.one_p(error,stage,True);goal=fc.scale(error,-1)
    # The P tag is now a single matrix unit E_ij, not a projector.  Neither
    # P^2=-14P nor any fixed R coefficient appears in the tangent columns.
    columns=[(dict(desc,operator='arbitrary_M_ij'),v)
             for desc,v in ar.columns(source,prefix,suffix,stage,True)
             if desc['operator']=='P']
    basis=fc.sparse_basis(columns);recipe,residual=fc.solve(basis,goal)
    assert residual
    weight,evaluation=ar.it.annihilator(basis,goal)
    assert all(sum((c*weight.get(k,F(0)) for k,c in v.items()),F(0))==0 for _,v in columns)
    return {'stage':stage,'changed_event':at,'candidate_scalar_M_ij_controls':len(columns),
        'exact_rank':len(basis),'restoration_possible':False,
        'normalized_required_correction_evaluation':str(evaluation),
        'R5_actual_required_correction_evaluation':str(evaluation/F(4)),
        'all8_actual_required_correction_evaluation':str(-evaluation/F(2)),
        'functional':[{'coefficient':str(c),**ar.encode(k)} for k,c in sorted(weight.items())],
        'all_candidates_annihilated_exactly':True,'independent_main_input_bank_columns':6}


def main():
    start=time.monotonic()
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    npth=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    path=ROOT/'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json'
    R=[[int(x) for x in row] for row in json.loads(rp.read_text())]
    ports=json.loads(npth.read_text())['ports']
    physical=cs.Physical(R,ports,[5])
    i,j=4,5;qi,qj=ports[i]['q'],ports[j]['q']
    assert (qi,qj)==(131,259)
    p5=-F(R[5][i]*R[5][j],4);p8=-F(sum(r[i]*r[j] for r in R),4)
    assert (p5,p8)==(F(1,4),-F(1,2))
    assert all(rank2([ports[a]['q'],ports[b]['q'],511])==3
               for a in range(112) for b in range(a+1,112))
    signs={};isolating_counts={}
    for w in range(512):
        bits=((1+((w&qi).bit_count()%2))%2,
              (1+((w&qj).bit_count()%2))%2,w.bit_count()%2)
        if (physical.inverse[i][w]^physical.inverse[j][w])&510:
            signs.setdefault(bits,w)
            isolating_counts[bits]=isolating_counts.get(bits,0)+1
    assert len(signs)==8
    samples=[]
    for bits,w in sorted(signs.items()):
        wi=physical.inverse[i][w];wj=physical.inverse[j][w]
        assert ((wi&1),(wj&1),wi.bit_count()%2)==bits
        assert wj.bit_count()%2==bits[2]
        assert (wi^wj)&510
        samples.append({'sign_bits_Q_output_Q_input_zeta':list(bits),
            'common_source_K_frequency':w,'physical_output_frequency':wi,
            'physical_input_frequency':wj,'different_fresh_source_coordinates':(wi^wj)&510,
            'available_isolating_frequency_count':isolating_counts[bits],
            'column_pairing':'Both digit columns use the listed identical frequency.'})
    # The8 sign patterns give the full3-bit Walsh character matrix.
    walsh=[[(-1)**sum(a*b for a,b in zip(bits,mask))
            for mask in sorted(signs)] for bits in sorted(signs)]
    det=cs.determinant(walsh);assert abs(det)==2**12
    # The six other native charts cannot move any fresh source-stage
    # coordinate.  Replay all512 chosen physical inputs and each competing
    # chart explicitly; stage labels are interchangeable by axis renaming.
    def embedded_map(stage,owner,freq,inverse=False):
        table=physical.inverse if inverse else physical.forward
        shift=8*stage;local=(freq&1)|((freq>>shift)&510)
        value=table[owner][local];mask=1|(510<<shift)
        return (freq&~mask)|(value&1)|((value&510)<<shift)
    graph_checks=0
    for sample in samples:
        for external in range(64):
            tail=sum(((external>>(t-1))&1)<<(1+8*t) for t in range(1,7))
            source=sample['physical_input_frequency']|tail
            target=sample['physical_output_frequency']|tail
            assert embedded_map(0,i,embedded_map(0,j,source),True)==target
            assert source!=target
            for other in range(1,7):
                image=embedded_map(other,i,embedded_map(other,j,source),True)
                assert (image&510)==(source&510) and image!=target
                graph_checks+=1
    source=json.loads(path.read_text())['selected_p3_keep43'];_,prefix,suffix=ac.source_matrices(source)
    results=[]
    for stage in range(7):
        result=solve_stage(source,prefix,suffix,stage);results.append(result)
        print('ARBITRARY_OWNER_TANGENT',stage,'rank',result['exact_rank'],
            'dual_support',len(result['functional']),
            'normalized_goal',result['normalized_required_correction_evaluation'],flush=True)
    out={'schema':'actual-arbitrary-constant-owner-map-tangent-obstruction/v1',
        'source_sha256':sha256(path.read_bytes()).hexdigest(),
        'actual_R_sha256':sha256(rp.read_bytes()).hexdigest(),
        'normalizers_sha256':sha256(npth.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
        'fixed_source_owner_pair':{'output_owner':i,'input_owner':j,'q_output':qi,'q_input':qj,
            'source_R5_P_entry':str(p5),'all8_P_entry':str(p8)},
        'every_distinct_pair_sign_rank3_checked':112*111//2,
        'literal_signed_K_phase_map_checks':physical.phase_checks,
        'actual_source_sign_samples':samples,
        'source_character_matrix_determinant':str(det),
        'other_stage_signs':'The six disjoint8-axis blocks independently realize D_t=+1 or-1 on equal frequency pairs. No such stage is silently specialized to the identity.',
        'full_independent_character_count':512,
        'full_character_matrix_determinant_magnitude':'2^2304',
        'other_native_chart_graph_separation_checks':graph_checks,
        'graph_separation':'Each of the8 source sign representatives changes at least one fresh source-stage frequency coordinate between owners5 and4. A route K_t,4^-1 K_t,5 in another stage t leaves every such coordinate fixed, so its selected matrix element is zero. Gaussian signs before/after do not change that support. Plain physical owner maps also have zero selected entry.',
        'stage0_dual_formula':'For the fixed owner pair(4,5), Lambda(T)=average_{512 sign choices} zeta*D1*D2*(q4*q5*T[bank1,input_bank1]+q5*T[bank4,input_bank1]). Every admitted tangent control has Lambda=0; the required correction has Lambda=-P45.',
        'owner_pair_decoupling':'The unchanged caller is diagonal in owner and in these Fourier frequencies. A single first-order owner-map insertion sends initial owner j to final owner i only through its entry M_ij. Other matrix entries cannot contribute to this same owner pair at first order.',
        'ordinary_coefficient_family':'Sums of arbitrary constant112x112 owner matrices in every one of the7 native K_t charts, plus plain physical owner maps and even Gaussian heads. Arbitrary matrix products within one chart are included. On the actual sector all even heads are identity. Matrix entries may vary independently between every candidate insertion. The six non-source charts vanish on the graph-isolating witness, while the source chart is tested by the exact scalar M_ij reachability solve.',
        'chronology':'All earlier actual event-boundary bank snapshots may be retained and used at every later cut. Each of7 unchanged FULLs may expose its source-first D_t source, feed the opposite input before consumption, and retain that source for every later bank. The changed stage has the exact helper-clean filtered code C_F.',
        'results':results,
        'meaning':'The two-term stage0 invariant and the corresponding small other-stage invariants persist even with independently selected per-owner coefficients from all native charts. This is a first-order chronological reachability obstruction for the stated chart-sum family, not a fixed-projector-coefficient artifact.',
        'not_excluded':['Finite corrections whose essential effect is of higher order in the inserted controls.',
            'Products that visit multiple native charts within one ordinary coefficient, arbitrary deeper cross-stage projector words, and other ordinary coordinate maps.',
            'Changed paid FULL/IDLE jobs, other native internal states, or a changed target family.'],
        'elapsed_seconds':time.monotonic()-start,'new_kappa_claimed':False}
    (HERE/'ARBITRARY-OWNER-TANGENT.json').write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
