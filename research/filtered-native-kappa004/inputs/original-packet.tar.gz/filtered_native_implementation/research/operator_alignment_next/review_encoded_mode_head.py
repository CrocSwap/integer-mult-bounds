#!/usr/bin/env python3
"""Independent physical and symbolic review of the encoded mode head.

This evaluator imports neither the emitter nor the Clifford compiler.  It
authenticates each ordinary map by exhaustive address/phase action, using
raw source G/Z data, then replays the literal field programs.  The formal
Q-power replay is universal in tensor width; sparse physical replays at
widths 1, 2, and 3 separately check tensor placement and scalar placement.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
WORD = ROOT / "research/retained_state_next/ENCODED-MODE-HEAD-WORD.json.gz"
NORMALIZERS = ROOT / "upstream/research/coded-native-caller/NORMALIZERS.json"
R_SOURCE = ROOT / "upstream/research/involutory-producer-raw-dual/inputs/R/R.json"
CLIFFORD_SOURCE = ROOT / "upstream/research/coded-native-caller/clifford_exact.py"
N = 112
T, U = N, N + 1
ZERO = (F(0), F(0))
ONE = (F(1), F(0))


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def parity(value):
    return value.bit_count() & 1


def binary_map(rows, address):
    return sum(parity(row & address) << j for j, row in enumerate(rows))


def diagonal_phase(rows, linear, address):
    phase = sum(a for j, a in enumerate(linear) if address & (1 << j))
    for j, row in enumerate(rows):
        if address & (1 << j):
            phase += 2 * parity(row & address & ~((1 << (j + 1)) - 1))
    return phase % 4


def word_action(word, address):
    phase = 0
    for event in word:
        if event[0] == "P":
            address = binary_map(event[1], address)
        elif event[0] == "D":
            phase += diagonal_phase(event[1], event[2], address)
        elif event[0] == "X":
            address ^= event[1]
        elif event[0] == "phase":
            phase += event[1]
        else:
            raise AssertionError(("nonordinary map opcode", event))
    return address, phase % 4


def record_action(record, address):
    phase = record["phase"] + diagonal_phase(
        record["quadratic_rows"], record["linear_Z4"], address
    )
    return binary_map(record["matrix_rows"], address) ^ record["offset"], phase % 4


def actual_maps(ports):
    result = {}
    for owner, port in enumerate(ports):
        forward = []
        inverse = [None] * 512
        for address in range(512):
            target = binary_map(port["G_rows"], address)
            phase = 2 * parity(port["Z_mask"] & target)
            forward.append((target, phase))
            assert inverse[target] is None
            inverse[target] = (address, (-phase) % 4)
        result[f"K_{owner}"] = forward
        result[f"K_inverse_{owner}"] = inverse
    result["Q_squared"] = [(x ^ 1, 0) for x in range(512)]
    return result


def authenticate_maps(artifact, expected):
    address_checks = tableau_checks = 0
    assert set(artifact["monomial_maps"]) == set(expected)
    for tag, target in expected.items():
        emitted = artifact["monomial_maps"][tag]
        for address, answer in enumerate(target):
            assert word_action(emitted["word"], address) == answer, (tag, address, "word")
            assert record_action(emitted["monomial"], address) == answer, (tag, address, "record")
            address_checks += 1
        # Authenticate the tableau from basis action, including each Pauli phase.
        for generator, (px, pz, pp) in enumerate(emitted["tableau"]):
            assert 0 <= generator < 18
            for address, (mapped, phase) in enumerate(target):
                if generator < 9:
                    left_address, left_phase = target[address ^ (1 << generator)]
                else:
                    left_address = mapped
                    left_phase = phase + 2 * ((address >> (generator - 9)) & 1)
                right_address = mapped ^ px
                right_phase = phase + pp + 2 * parity(pz & mapped)
                assert left_address == right_address and (left_phase - right_phase) % 4 == 0
                tableau_checks += 1
    return address_checks, tableau_checks


def scalar_accumulate(destination, source, scale):
    assert destination is not source
    for key, value in source.items():
        new = destination.get(key, F(0)) + scale * value
        if new:
            destination[key] = new
        else:
            destination.pop(key, None)


def identity_rows():
    return [{(i, 0): F(1)} for i in range(N)] + [{}, {}]


def check_event(event):
    """Check storage ownership and which authenticated chart each ADD uses."""
    op = event["op"]
    if op == "CLEAR":
        assert event["field"] in (T, U)
    elif op == "COPY":
        assert (event["destination"], event["source"]) == (U, T)
    elif op == "ADD":
        assert (event["destination"], event["source"]) == (U, T)
    elif op == "MAPPED_ADD":
        dst, src = event["destination"], event["source"]
        if dst == T:
            assert 0 <= src < N and event["map"] == f"K_{src}"
        else:
            assert 0 <= dst < N and src == U and event["map"] == f"K_inverse_{dst}"
    elif op == "GAUSSIAN":
        assert event["field"] == U and event["rank"] == 1
        assert event["query_word"] in ([["C", 1, 1]], [["C", 1, -1]])
    elif op == "MONOMIAL":
        assert event["field"] == U and event["map"] == "Q_squared"
    else:
        raise AssertionError(("unknown event", event))


def symbolic_replay(events, initial=None):
    """Literal replay in authenticated z_i=K_i x_i coordinates.

    Each coefficient is an exact polynomial in a central formal q with
    q^4=1. No identity specific to width one is used.
    """
    fields = identity_rows() if initial is None else [dict(row) for row in initial]
    assert len(fields) == 114 and not fields[T] and not fields[U]
    invoice = Counter()
    maximum = F(1)
    for event in events:
        check_event(event)
        kind = event["op"]
        invoice[kind] += 1
        if kind == "CLEAR":
            dst = event["field"]
            fields[dst] = {}
        elif kind == "COPY":
            dst = event["destination"]
            fields[dst] = dict(fields[event["source"]])
        elif kind in ("ADD", "MAPPED_ADD"):
            dst, src = event["destination"], event["source"]
            scalar_accumulate(fields[dst], fields[src], F(event["coefficient"]))
        else:
            dst = event["field"]
            power = 2 if kind == "MONOMIAL" else event["query_word"][0][2]
            fields[dst] = {(i, (a + power) % 4): v for (i, a), v in fields[dst].items()}
        maximum = max(maximum, sum(map(abs, fields[dst].values()), F(0)))
    assert not fields[T] and not fields[U], "owned fields must be restored to zero"
    return fields, invoice, maximum


def target_matrix(R, mode, power):
    rows = identity_rows()
    r = R[mode]
    for i in range(N):
        for j in range(N):
            factor = r[i] * r[j] / 56
            if factor:
                scalar_accumulate(rows[i], {(j, power % 4): F(1)}, factor)
                scalar_accumulate(rows[i], {(j, 0): F(1)}, -factor)
    return rows


def pair_add(a, b):
    return a[0] + b[0], a[1] + b[1]


def pair_mul(a, b):
    return a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0]


def phase_mul(pair, exponent):
    a, b = pair
    return ((a, b), (-b, a), (-a, -b), (b, -a))[exponent % 4]


def vector_add(dst, src, coefficient=F(1)):
    assert dst is not src
    for key, (a, b) in src.items():
        old = dst.get(key, ZERO)
        value = old[0] + coefficient * a, old[1] + coefficient * b
        if value != ZERO:
            dst[key] = value
        else:
            dst.pop(key, None)


def apply_map(vector, action, width):
    answer = {}
    for address, value in vector.items():
        target = phase = 0
        for digit in range(width):
            x = (address >> (9 * digit)) & 511
            y, p = action[x]
            target |= y << (9 * digit)
            phase += p
        assert target not in answer
        answer[target] = phase_mul(value, phase)
    return answer


def apply_query(vector, width, sign=1):
    """Exact C=(1+s*i)I/2+(1-s*i)X/2 independently per digit."""
    result = dict(vector)
    stay, flip = (F(1, 2), F(sign, 2)), (F(1, 2), F(-sign, 2))
    for digit in range(width):
        updated = {}
        for address, value in result.items():
            for target, coefficient in ((address, stay), (address ^ (1 << (9 * digit)), flip)):
                new = pair_add(updated.get(target, ZERO), pair_mul(value, coefficient))
                if new != ZERO:
                    updated[target] = new
                else:
                    updated.pop(target, None)
        result = updated
    return result


def physical_replay(events, initial, actions, width):
    fields = [dict(v) for v in initial] + [{}, {}]
    for event in events:
        check_event(event)
        op = event["op"]
        if op == "CLEAR":
            fields[event["field"]] = {}
        elif op == "COPY":
            fields[event["destination"]] = dict(fields[event["source"]])
        elif op in ("ADD", "MAPPED_ADD"):
            src = fields[event["source"]]
            if op == "MAPPED_ADD":
                src = apply_map(src, actions[event["map"]], width)
            vector_add(fields[event["destination"]], src, F(event["coefficient"]))
        elif op == "GAUSSIAN":
            fields[event["field"]] = apply_query(fields[event["field"]], width, event["query_word"][0][2])
        else:
            fields[event["field"]] = apply_map(fields[event["field"]], actions[event["map"]], width)
    assert not fields[T] and not fields[U]
    return fields[:N]


def physical_target(R, mode, power, initial, actions, width, wrong_tensor_scaling=False):
    gathered = {}
    for j, rj in enumerate(R[mode]):
        if rj:
            coeff = (rj / 56) ** width if wrong_tensor_scaling else rj / 56
            vector_add(gathered, apply_map(initial[j], actions[f"K_{j}"], width), coeff)
    shifted = dict(gathered)
    for _ in range(power % 4):
        shifted = apply_query(shifted, width)
    vector_add(shifted, gathered, F(-1))
    answer = [dict(v) for v in initial]
    for i, ri in enumerate(R[mode]):
        if ri:
            vector_add(answer[i], apply_map(shifted, actions[f"K_inverse_{i}"], width), ri)
    return answer


def physical_inputs(width):
    # Every owner has an independent, nonzero labelled probe amplitude;
    # universality over independent inputs is supplied by the formal replay.
    return [{sum(((73 * i + 101 * d + 7) % 512) << (9 * d) for d in range(width)):
             (F(i + 1), F((19 * i) % 23 - 11))} for i in range(N)]


def must_fail(thunk):
    try:
        thunk()
    except AssertionError:
        return True
    raise AssertionError("negative control unexpectedly accepted")


def main():
    begin = time.monotonic()
    initial_word_hash = digest(WORD)
    artifact = json.loads(gzip.decompress(WORD.read_bytes()))
    assert artifact["schema"] == "literal-encoded-owner-mode-gaussian-head/v1"
    assert artifact["base_data_bits"] == 9 and artifact["head_axis_mask"] == 1
    assert artifact["original_fields"] == list(range(N)) and artifact["owned_fields"] == [T, U]
    assert artifact["source_normalizers_sha256"] == digest(NORMALIZERS)
    assert artifact["source_R_sha256"] == digest(R_SOURCE)
    assert artifact["clifford_source_sha256"] == digest(CLIFFORD_SOURCE)
    ports = json.loads(NORMALIZERS.read_text())["ports"]
    R = [[F(a) for a in row] for row in json.loads(R_SOURCE.read_text())]
    assert artifact["source_R"] == [[str(a) for a in row] for row in R]
    assert len(ports) == N and len(R) == 8 and all(len(r) == N for r in R)
    gram = [[sum(a * b for a, b in zip(r, s)) for s in R] for r in R]
    assert gram == [[F(56 * (i == j)) for j in range(8)] for i in range(8)]
    assert all(sum(bool(a) for a in r) == 56 for r in R)
    actions = actual_maps(ports)
    address_count, tableau_count = authenticate_maps(artifact, actions)
    for i in range(N):
        for x, (y, p) in enumerate(actions[f"K_{i}"]):
            z, q = actions[f"K_inverse_{i}"][y]
            assert z == x and (p + q) % 4 == 0
    print(f"PASS physical maps: {address_count} full basis actions; {tableau_count} phase-aware Pauli checks", flush=True)

    # Calibrate the exact query convention on both independent one-bit inputs.
    for x in (0, 1):
        v = {x: ONE}
        qv = apply_query(v, 1)
        assert apply_query(qv, 1, -1) == v
        assert apply_query(v, 1, -1) == apply_map(qv, actions["Q_squared"], 1)
        q2v = apply_query(qv, 1)
        assert q2v == {x ^ 1: ONE}
        assert apply_query(apply_query(q2v, 1), 1) == v

    identity = identity_rows()
    mode_results = []
    maximum = F(0)
    for mode in range(8):
        programs = artifact["programs"][str(mode)]
        assert set(programs) == {"positive", "inverse", "square"}
        invoices = {}
        for name, power in (("positive", 1), ("inverse", -1), ("square", 2)):
            events = programs[name]
            assert len(events) == 118
            rows, invoice, bound = symbolic_replay(events)
            assert rows == target_matrix(R, mode, power)
            assert invoice == Counter({"CLEAR": 3, "MAPPED_ADD": 112, "COPY": 1,
                                       "ADD": 1, "MONOMIAL" if power == 2 else "GAUSSIAN": 1})
            maximum = max(maximum, bound)
            invoices[name] = dict(invoice)
        current = identity
        for _ in range(4):
            current, _, _ = symbolic_replay(programs["positive"], current)
        assert current == identity
        current, _, _ = symbolic_replay(programs["positive"])
        two, _, _ = symbolic_replay(programs["positive"], current)
        square, _, _ = symbolic_replay(programs["square"])
        assert two == square
        assert symbolic_replay(programs["inverse"], current)[0] == identity
        current, _, _ = symbolic_replay(programs["inverse"])
        assert symbolic_replay(programs["positive"], current)[0] == identity
        mode_results.append({"mode": mode, "all_112_original_columns": True,
                             "positive_inverse_square": "PASS", "fourth_power": "IDENTITY",
                             "inverse_both_orders": "PASS", "ordinary_square": "PASS",
                             "invoice": invoices})
    commutators = 0
    for k in range(8):
        for l in range(k + 1, 8):
            a = artifact["programs"][str(k)]["positive"]
            b = artifact["programs"][str(l)]["positive"]
            ab = symbolic_replay(b, symbolic_replay(a)[0])[0]
            ba = symbolic_replay(a, symbolic_replay(b)[0])[0]
            assert ab == ba
            commutators += 1
    print(f"PASS formal all-width replay: 24 programs, 8 order-four identities, {commutators} commutators", flush=True)

    physical_results = []
    for width, modes in ((1, range(8)), (2, range(8)), (3, [5])):
        initial = physical_inputs(width)
        for mode in modes:
            for name, power in (("positive", 1), ("inverse", -1), ("square", 2)):
                output = physical_replay(artifact["programs"][str(mode)][name], initial, actions, width)
                target = physical_target(R, mode, power, initial, actions, width)
                assert output == target, (width, mode, name)
                physical_results.append({"width": width, "mode": mode, "program": name,
                                         "nonzero_output_amplitudes": sum(map(len, output)), "status": "PASS"})
    print(f"PASS physical tensor replays: {len(physical_results)} tests at widths 1, 2, 3", flush=True)

    # Source-phase, query-orientation, scalar-placement, and ownership controls.
    bad_map = deepcopy(artifact["monomial_maps"]["K_4"]["word"])
    bad_map.append(["phase", 1])
    assert any(word_action(bad_map, x) != actions["K_4"][x] for x in range(512))
    omitted_signs = 0
    for i, port in enumerate(ports):
        assert any((binary_map(port["G_rows"], x), 0) != actions[f"K_{i}"][x] for x in range(512))
        omitted_signs += 1
    bad_scatter = deepcopy(artifact["programs"]["5"]["positive"])
    next(e for e in bad_scatter if e["op"] == "MAPPED_ADD" and e["source"] == U)["coefficient"] = "2"
    assert symbolic_replay(bad_scatter)[0] != target_matrix(R, 5, 1)
    bad_query = deepcopy(artifact["programs"]["5"]["positive"])
    next(e for e in bad_query if e["op"] == "GAUSSIAN")["query_word"][0][2] = -1
    assert symbolic_replay(bad_query)[0] != target_matrix(R, 5, 1)
    bad_clear = deepcopy(artifact["programs"]["5"]["positive"])
    bad_clear[0]["field"] = 0
    must_fail(lambda: symbolic_replay(bad_clear))
    must_fail(lambda: symbolic_replay(artifact["programs"]["5"]["positive"][:-2]))
    initial = physical_inputs(2)
    assert physical_target(R, 5, 1, initial, actions, 2, True) != physical_target(R, 5, 1, initial, actions, 2)

    assert maximum == F(83, 28)
    assert digest(WORD) == initial_word_hash, "review must not modify source word"
    receipt = {
        "schema": "independent-literal-encoded-mode-head-review/v1",
        "status": "PASS",
        "word_sha256": initial_word_hash,
        "checker_sha256": digest(Path(__file__)),
        "source_normalizers_sha256": digest(NORMALIZERS),
        "source_R_sha256": digest(R_SOURCE),
        "clifford_source_sha256": digest(CLIFFORD_SOURCE),
        "independence": "Python standard-library evaluator; no emitter or Clifford-compiler import. Raw G/Z source data independently define every physical monomial action. The Clifford source is hash-bound only.",
        "physical_map_count": len(actions),
        "basis_addresses_per_map": 512,
        "exhaustive_address_phase_checks": address_count,
        "exhaustive_tableau_phase_checks": tableau_count,
        "formal_ring": "Q[q]/(q^4-1), independently authenticated by C^2=X and C^4=I; no width-one polynomial identity assumed",
        "inverse_oracle_reduction": "C^-1=X_head C with absolute phase1, checked on both one-bit basis inputs; the inverse program uses one positive rank1 child plus one ordinary X wrapper, not a distinct oracle species.",
        "universal_input_columns": 112,
        "owned_fields": [T, U],
        "owned_initial_and_final": "zero",
        "untouched_other_banks": "No event addresses any other original or helper field.",
        "mode_gram": [[str(a) for a in row] for row in gram],
        "mode_results": mode_results,
        "cross_mode_commutators": commutators,
        "physical_tensor_tests": physical_results,
        "maximum_single_program_operator_row_l1": str(maximum),
        "error_contract_scope": "With exact ordinary arithmetic, the operator row bound is83/28<3, and one rank1 query error enters each active output with coefficient magnitude1. This review does not certify rounded ordinary arithmetic or the outer recursive precision budget.",
        "negative_controls": {
            "altered_absolute_map_phase": "REJECTED",
            "omitted_source_signs": omitted_signs,
            "wrong_scatter_coefficient": "REJECTED",
            "wrong_positive_query_orientation": "REJECTED",
            "clearing_original_field": "REJECTED",
            "missing_owned_clear": "REJECTED",
            "normalization_inside_tensor_power_at_width2": "REJECTED",
        },
        "scope": "Exact standalone finite-order update on one encoded R mode. It is not global Q on Pi, not a native center replacement, and not a complete p3 caller repair.",
        "new_kappa_claimed": False,
        "runtime_dependencies": ["Python3 standard library", str(WORD.relative_to(ROOT)),
                                 str(NORMALIZERS.relative_to(ROOT)), str(R_SOURCE.relative_to(ROOT)),
                                 str(CLIFFORD_SOURCE.relative_to(ROOT))],
        "seconds": time.monotonic() - begin,
    }
    out = HERE / "ENCODED-MODE-HEAD-INDEPENDENT-REVIEW.json"
    out.write_text(json.dumps(receipt, indent=2) + "\n")
    print("PASS", out, "seconds", receipt["seconds"], flush=True)


if __name__ == "__main__":
    main()
