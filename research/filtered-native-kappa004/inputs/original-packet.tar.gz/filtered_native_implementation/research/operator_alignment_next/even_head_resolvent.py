#!/usr/bin/env python3
"""Actual R-weighted even-Q compression and an all-width ordinary inverse.

Unlike odd-head spectra, Q^2 is a uniform signed translation.  Its tensor
power therefore depends only on the XOR of all column frequencies.  The
512 exact 8x8 blocks below certify the same finite polynomial at every
width.  No Fourier change of chart is performed by the compiler.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json
import sys
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE))
import probe
from review_center5 import same,word_op


def need(x,msg):
    if not x:raise AssertionError(msg)


def charpoly(A):
    n=len(A);I=np.eye(n,dtype=object);B=I.copy();coeff=[1]
    for k in range(1,n+1):
        B=A@B;c=-int(np.trace(B));need(c%k==0,'Nonintegral Newton coefficient')
        c//=k;coeff.append(c);B=B+c*I
    return tuple(coeff)


def multiply_polynomials(a,b):
    out=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):out[i+j]+=x*y
    return out


def lagrange(values,value):
    out=[F(1)]
    for other in values:
        if other!=value:out=multiply_polynomials(out,[-other/(value-other),1/(value-other)])
    return out


def inverse_polynomial(values,z):
    out=[F(0)]*len(values)
    for value in values:
        need(1-z*value!=0,'Requested inverse has a zero spectral block')
        for j,c in enumerate(lagrange(values,value)):out[j]+=c/(1-z*value)
    return out


def pseudoinverse_shift_polynomial(values,sign):
    out=[F(0)]*len(values)
    for value in values:
        factor=F(0) if 1+sign*value==0 else 1/(1+sign*value)
        for j,c in enumerate(lagrange(values,value)):out[j]+=c*factor
    return out


def evaluate(poly,x):
    out=F(0)
    for a in reversed(poly):out=out*x+a
    return out


def product_eigenvalues(values):
    poly=[1]
    for value in values:
        new=[0]*(len(poly)+1)
        for i,c in enumerate(poly):new[i]+=c;new[i+1]-=value*c
        poly=new
    return tuple(poly)


def fourier_one_multiplicity(n):
    # Exact cyclic convolution counts the eigenvalues of C(X)^tensor n.
    count=[1,0,0,0]
    for _ in range(n):count=[count[j]+count[(j-1)%4] for j in range(4)]
    return count


def literal_T2_mod(fields,r,q,width,prime):
    """Replay the physical ordinary translation word on one complete orbit.

    A uniform translation q in every digit column acts freely with 512
    points in each orbit.  Every orbit has exactly this same action, so
    this is also the literal width-two diagonal-address orbit (x,x).
    """
    out=np.zeros_like(fields);addresses=np.arange(512)
    for i,qi in enumerate(q):
        gathered=np.sum(r[:,i,None]*fields,axis=0)%prime
        out=(out+r[:,i,None]*gathered[addresses^qi])%prime
    factor=((-1)**width)*pow(56,-1,prime)%prime
    return out*factor%prime


def rational_mod(x,prime):return x.numerator*pow(x.denominator,-1,prime)%prime


def emitted_schedule(r,q,poly):
    # Eight arbitrary input fields, eight result fields, eight next-state
    # fields, and one disposable gather.  Maps are uniform digit translations.
    out=[]
    for k in range(8):
        out.append(['clear',['state',k]])
        out.append(['add',['state',k],['input',k],str(poly[-1]),['identity']])
    for degree in range(len(poly)-2,-1,-1):
        for k in range(8):out.append(['clear',['next',k]])
        for i,qi in enumerate(q):
            out.append(['clear',['gather',0]])
            for k in range(8):
                if r[k,i]:out.append(['add',['gather',0],['state',k],str(int(r[k,i])),['identity']])
            for k in range(8):
                if r[k,i]:out.append(['add',['next',k],['gather',0],str(F(int(r[k,i]),56)),
                                       ['uniform_digit_X',qi,'scalar_phase_(-1)^width']])
            out.append(['clear',['gather',0]])
        for k in range(8):
            out.append(['add',['next',k],['input',k],str(poly[degree]),['identity']])
            out.append(['swap_owned',['state',k],['next',k]])
            out.append(['clear',['next',k]])
    return out


def main():
    ce,ca,normals,R,routes=probe.cc.source_data()
    r=np.array(R,dtype=int);q=[x['q'] for x in normals]
    need((r@r.T).tolist()==(56*np.eye(8,dtype=int)).tolist(),'Actual R Gram')
    Q=ce.cgate(9,1)
    phase_checks=0
    for item in normals:
        K=word_op(ce,item['K_word'])
        actual=K.adjoint().then(Q).then(Q).then(K)
        expected=ce.xgate(9,item['q']).then(ce.Op(9,ce.identity(9),[('phase',2)]))
        need(same(actual,expected),'Conjugated Q square lost a phase')
        phase_checks+=1
    blocks=[];classes=Counter();class_examples={};single=Counter();all_values=set()
    total_intersection=0;total_rank=0
    for w in range(512):
        signs=np.array([(-1)**((w&qi).bit_count()%2) for qi in q],dtype=int)
        numerator=((r*signs)@r.T).astype(object)
        polynomial=charpoly(numerator)
        inferred=[int(round(x)) for x in np.linalg.eigvalsh(np.array(numerator,dtype=float))]
        # Numerical eigenvalues only propose exact integer roots.  Matching
        # the complete integer characteristic polynomial proves them.
        need(product_eigenvalues(inferred)==polynomial,'Inferred eigenvalues not exact')
        all_values.update(F(x,56) for x in inferred)
        key=tuple(sorted(inferred));classes[key]+=1;class_examples.setdefault(key,w)
        single[int(numerator[5,5])]+=1
        total_intersection+=sum(abs(x)==56 for x in inferred)
        total_rank+=sum(x!=0 for x in inferred)
        blocks.append({'xor_frequency':w,'numerator_over_56':[[int(x) for x in row] for row in numerator],
                       'exact_eigenvalue_numerators':inferred})
    values=sorted(all_values)
    need(values==list(map(F,['-1','-6/7','-2/7','-1/7','0','1/7','2/7','6/7','1'])),
         'Unexpected actual all-eight spectrum')
    single_values=sorted(F(x,56) for x in single)
    z=F(14,13);inverse=inverse_polynomial(values,z)
    need(all(evaluate(inverse,x)*(1-z*x)==1 for x in values),'Inverse polynomial certificate')
    for sign in (1,-1):
        pseudoinverse=pseudoinverse_shift_polynomial(values,sign)
        need(all(evaluate(pseudoinverse,x)==(F(0) if 1+sign*x==0 else 1/(1+sign*x))
                 for x in values),'Pseudoinverse polynomial certificate')
    schedule=emitted_schedule(r,q,inverse)
    modular_checks=[];prime=65521
    seed=np.arange(8*512,dtype=np.int64).reshape(8,512)
    fields=(seed*seed+17*seed+31)%prime
    for width in (1,2):
        output=fields*rational_mod(inverse[-1],prime)%prime
        for coefficient in reversed(inverse[:-1]):
            output=(literal_T2_mod(output,r,q,width,prime)+
                    fields*rational_mod(coefficient,prime))%prime
        returned=(output-rational_mod(z,prime)*literal_T2_mod(output,r,q,width,prime))%prime
        need(np.array_equal(returned,fields),'Literal ordinary resolvent replay failed')
        modular_checks.append({'width':width,'prime':prime,'arbitrary_input_entries':4096,
                               'literal_translation_orbit_points':512,
                               'identity':'(I-(14/13)T2) times emitted Horner output equals input',
                               'output_sha256':sha256(output.astype('<i8').tobytes()).hexdigest()})
    # Actual two-column frequency control: a uniform translation's phase
    # depends on XOR, while each source K contributes its -1 per column.
    for a in range(512):
        b=(a*149+73)%512
        for qi in q:
            lhs=(-1)**((a&qi).bit_count()%2)*(-1)**((b&qi).bit_count()%2)
            rhs=(-1)**(((a^b)&qi).bit_count()%2)
            need(lhs==rhs,'Two-column character lift failed')
    defects=[]
    for m in range(1,7):
        counts=fourier_one_multiplicity(9*m);N=2**(9*m)
        defects.append({'width':m,'array_dimension':N,'F9_tensor_eigenvalue_multiplicities':counts,
                        'one_mode_defect_rank':N-counts[0],
                        'all_eight_mode_defect_rank':8*(N-counts[0]),
                        'one_mode_rank_fraction':str(F(N-counts[0],N)),
                        'all_eight_rank_in_array_fields':str(F(8*(N-counts[0]),N))})
    result={'status':'PASS_ACTUAL_ALL_EIGHT_EVEN_HEAD_SPECTRUM_AND_UNIFORM_ORDINARY_RESOLVENT',
        'source_R_sha256':sha256((ROOT/'research/tensor_obstruction/inputs/R.json').read_bytes()).hexdigest(),
        'definitions':{'V':'diag(K_i^-1) R^T, with all eight source-ordered rows',
                       'L':'R diag(K_i)/56, so L V=I_8',
                       'T2':'L Q^2 V=(1/56) sum_i R[:,i] R[:,i]^T (-X_qi)^(tensor m)',
                       'P':'V L, the positive idempotent; the caller probe uses P_old=-14 P'},
        'phase_exact_source_conjugations':phase_checks,
        'all_width_proof':'Each (-X_q)^(tensor m) has Fourier eigenvalue (-1)^m (-1)^(q dot XOR_c frequency_c). Thus every width has exactly the 512 blocks listed, each repeated 2^(9(m-1)) times, with the global factor (-1)^m. The spectral set is symmetric, so the same polynomial annihilates T2 for every m.',
        'actual_all_eight_spectrum':[str(x) for x in values],
        'actual_single_source_R5_spectrum':[str(x) for x in single_values],
        'single_R5_eigenvalue_numerator_census':dict(sorted(single.items())),
        'all_eight_characteristic_polynomial_classes':[
            {'count':count,'example_xor_frequency':class_examples[key],
             'exact_eigenvalue_numerators_over_56':list(key)} for key,count in sorted(classes.items())],
        'uniform_annihilator':'T2 (T2^2-I) (49T2^2-I) (49T2^2-4I) (49T2^2-36I)=0',
        'ordinary_spectral_projectors':[
            {'eigenvalue':str(x),'polynomial_coefficients_ascending':[str(c) for c in lagrange(values,x)]}
            for x in values],
        'ordinary_even_orbit_Gram':{
            'identity':'For B=[V,Q^2 V] and A=[L;L Q^2]=B*/56, A B=[[I,T2],[T2,I]]. Constant sum/difference of the two coefficient banks diagonalizes this normalized Gram to I+T2 and I-T2. No square-root normalization is needed in the physical program.',
            'Moore_Penrose_shifts':[
                {'operator':'(I'+('+' if sign==1 else '-')+'T2)^dagger',
                 'annihilated_T2_eigenvalue':str(-sign),
                 'polynomial_coefficients_ascending':[str(c) for c in pseudoinverse_shift_polynomial(values,sign)],
                 'exact_operator_norm':str(max(abs(1/(1+sign*x)) for x in values if 1+sign*x))}
                for sign in (1,-1)],
            'range_projector':'B (A B)^dagger A is the exact ordinary orthogonal projector onto ran(V)+ran(Q^2V). All factors have finite rational ordinary schedules; no inverse is taken on a zero spectral sector.',
            'Gaussian_queries':0,
            'not_the_odd_Gram':'The four-Q-orbit Gram also contains T1 and T1*, whose opposite spectral splits are not furnished by this ordinary even-head construction.'},
        'uniform_resolvent_example':{'operator':'(I-(14/13)T2)^-1',
            'polynomial_coefficients_ascending':[str(c) for c in inverse],
            'exact_operator_norm':str(max(abs(1/(1-z*x)) for x in values)),
            'Gaussian_queries':0,
            'retained_arbitrary_input_fields':8,'owned_arrays_peak_including_output':17,
            'ordinary_ADD_count':sum(e[0]=='add' for e in schedule),
            'literal_schedule':schedule,'modular_physical_word_checks':modular_checks,
            'implementation':'Horner evaluation on the eight owned mode fields; T2 is the explicit 112-term signed-translation matrix sum above. Every scalar is applied once outside tensor powers. Original inputs may be retained, and each Horner step uses disposable owned fields. No Fourier query or inaccessible spectral chart is assumed.'},
        'even_orbit_carrier':{'rank_of_T2_in_units_of_array_fields':str(F(total_rank,512)),
            'dimension_intersection_ranP_with_Q2ranP_in_array_fields':str(F(total_intersection,512)),
            'dimension_ranP_plus_Q2ranP_in_array_fields':str(F(8192-total_intersection,512)),
            'scope':'Rank/dimension only; no free physical split into that fractional number of fields is claimed.'},
        'filtered_local_defect':{'identity':'C_F-I=14 P (F_s-I)',
            'rank_formula':'For k selected orthogonal source modes and N=2^(9m), rank(C_F-I)=k*(N-multiplicity(F_s=1)). The same rank holds after the invertible actual caller prefix/suffix of one LOCAL substitution.',
            'spectral_multiplicity_formula':'multiplicity(F_s=1)=2^(9m-2)+2^(9m/2-1)*cos(9m*pi/4)',
            'exact_width_census':defects,
            'all_width_asymptotic':'The defect occupies asymptotically 3/4 of each exceptional coefficient field, or six array fields for all eight modes.',
            'invoice_warning':'A constant 3/4 dimension fraction does not reduce the Gaussian rank exponent of a child query. Serving the exceptional output still requires a physical gather/provider/scatter; no kappa credit follows from rank alone.'},
        'exact_blocks':blocks,'new_kappa_claimed':False}
    (HERE/'EVEN-HEAD-RESOLVENT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('exact_blocks','ordinary_spectral_projectors')},indent=2))


if __name__=='__main__':main()
