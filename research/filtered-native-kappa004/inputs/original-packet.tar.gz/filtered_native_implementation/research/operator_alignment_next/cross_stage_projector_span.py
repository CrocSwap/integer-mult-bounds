#!/usr/bin/env python3
"""Actual two-stage projector words in the width-two paired-frequency sector.

The ordinary words are I,P0,P1,P0P1,P1P0,P0P1P0,P1P0P1.
Every head is tested with all left/right characters of Q,D0,D1.
Source-specific small integer minors certify the exact function-space rank;
no dense 112*2^34 matrix and no free physical Fourier adapter is assumed.
"""
from collections import defaultdict
from hashlib import sha256
from itertools import chain
from pathlib import Path
import argparse
import json
import random
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
WORDS=[(),(0,),(1,),(0,1),(1,0),(0,1,0),(1,0,1)]
PRIME=65521
NADDR=1<<17


def mv(rows,x):return sum(((row&x).bit_count()%2)<<j for j,row in enumerate(rows))
def transpose(rows):return [sum(((rows[j]>>i)&1)<<j for j in range(9)) for i in range(9)]


def determinant(a):
    """Exact integer Bareiss determinant, including row swaps."""
    a=[list(row) for row in a];n=len(a);last=1;sign=1
    for k in range(n-1):
        p=next((j for j in range(k,n) if a[j][k]),None)
        if p is None:return 0
        if p!=k:a[k],a[p]=a[p],a[k];sign=-sign
        pivot=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                z=a[i][j]*pivot-a[i][k]*a[k][j]
                assert z%last==0
                a[i][j]=z//last
            a[i][k]=0
        last=pivot
    return sign*a[-1][-1]


class Physical:
    def __init__(self,R,ports,modes):
        self.R=[R[k] for k in modes];self.modes=modes
        self.active=[i for i in range(112) if any(r[i] for r in self.R)]
        self.forward=[];self.inverse=[];self.phase_checks=0
        for port in ports:
            G=port['G_rows'];Gt=transpose(G);z=port['Z_mask']
            assert port['K_word'][0]==['P',G]
            assert port['K_word'][1]==['D',[0]*9,[2*((z>>j)&1) for j in range(9)]]
            fw=[mv(G,w)^z for w in range(512)]
            iv=[mv(Gt,w^z) for w in range(512)]
            for w in range(512):
                assert fw[iv[w]]==w and iv[fw[w]]==w
                assert (fw[w].bit_count()-w.bit_count())%2==0
                # K^-1 |w> has the literal conjugated central Gaussian
                # eigenvalue (-1)^(1+w.q), not the unsigned convention.
                assert (iv[w]&1)==(1+((w&port['q']).bit_count()%2))%2
                self.phase_checks+=1
            self.forward.append(fw);self.inverse.append(iv)

    def map(self,stage,owner,freq,inverse=False):
        table=self.inverse if inverse else self.forward
        if stage==0:return (freq&~511)|table[owner][freq&511]
        assert stage==1
        local=(freq&1)|((freq>>8)&510);value=table[owner][local]
        return (freq&~(1|(255<<9)))|(value&1)|((value&510)<<8)

    def apply_numerator(self,stage,vector):
        # This is -R^T R in the owner-specific K charts, hence4P_s.
        aggregate=[defaultdict(int) for _ in self.R]
        for packed,c in vector.items():
            owner,freq=divmod(packed,NADDR)
            aligned=self.map(stage,owner,freq)
            for k,r in enumerate(self.R):
                if r[owner]:aggregate[k][aligned]+=r[owner]*c
        out=defaultdict(int)
        for k,r in enumerate(self.R):
            for aligned,c in aggregate[k].items():
                if not c:continue
                for owner in self.active:
                    if r[owner]:
                        freq=self.map(stage,owner,aligned,True)
                        out[owner*NADDR+freq]-=r[owner]*c
        return {k:c for k,c in out.items() if c}

    def words(self,owner,freq):
        values={():{owner*NADDR+freq:1}}
        for word in WORDS[1:]:values[word]=self.apply_numerator(word[0],values[word[1:]])
        return [values[word] for word in WORDS]


def signature(freq):
    return (freq&1)|(((freq&510).bit_count()%2)<<1)|((((freq>>9)&255).bit_count()%2)<<2)


def allowed(delta):
    assert delta in (0,3,5,6)
    return [j for j,w in enumerate(WORDS)
            if (not w and delta==0) or
               (w==(0,) and delta in (0,3)) or
               (w==(1,) and delta in (0,5)) or len(w)>=2]


def add_row(block,values,sample):
    v=[x%PRIME for x in values]
    for pivot,b in sorted(block['basis'].items()):
        c=v[pivot]
        if c:v=[(x-c*y)%PRIME for x,y in zip(v,b)]
    pivot=next((j for j,x in enumerate(v) if x),None)
    if pivot is None:return False
    inverse=pow(v[pivot],-1,PRIME)
    block['basis'][pivot]=[x*inverse%PRIME for x in v]
    block['rows'].append(values);block['samples'].append(sample)
    return True


def run(R,ports,modes,max_reps):
    physical=Physical(R,ports,modes);rng=random.Random(79065+sum(modes))
    blocks={(a,a^delta):{'head_indices':allowed(delta),'basis':{},'rows':[],'samples':[]}
            for a in range(8) for delta in (0,3,5,6)}
    start=time.monotonic();inputs=[]
    for rep in range(max_reps):
        for alpha in range(8):
            if all(len(blocks[alpha,alpha^d]['basis'])==len(allowed(d)) for d in (0,3,5,6)):continue
            owner=physical.active[(17*rep+7*alpha)%len(physical.active)]
            freq=rng.randrange(NADDR)
            if (freq&1)!=(alpha&1):freq^=1
            if (freq&510).bit_count()%2 != (alpha>>1)&1:freq^=2
            if ((freq>>9)&255).bit_count()%2 != (alpha>>2)&1:freq^=512
            assert signature(freq)==alpha
            values=physical.words(owner,freq)
            # Source projector normalization and actual phase covariance are
            # controlled separately from the mixed-word rank calculation.
            if rep==0 and alpha==0:
                for stage in (0,1):
                    first=values[1+stage];second=physical.apply_numerator(stage,first)
                    assert second=={k:-56*c for k,c in first.items()}
            seen=set();new_rows=0
            for packed in chain.from_iterable(value for value in values):
                if packed in seen:continue
                seen.add(packed);output_owner,output_freq=divmod(packed,NADDR)
                beta=signature(output_freq);delta=alpha^beta
                assert delta in (0,3,5,6)
                block=blocks[alpha,beta]
                if len(block['basis'])==len(block['head_indices']):continue
                entries=[values[j].get(packed,0)*4**(3-len(WORDS[j])) for j in range(len(WORDS))]
                assert all(entries[j]==0 for j in range(len(WORDS)) if j not in block['head_indices'])
                active=[entries[j] for j in block['head_indices']]
                sample={'input_owner':owner,'input_frequency':freq,
                    'output_owner':output_owner,'output_frequency':output_freq}
                new_rows+=add_row(block,active,sample)
                if all(len(blocks[alpha,alpha^d]['basis'])==len(allowed(d)) for d in (0,3,5,6)):break
            inputs.append({'owner':owner,'frequency':freq,'signature':alpha,
                'head_support_sizes':[len(v) for v in values],'new_independent_rows':new_rows})
            print('CROSS_PROJECTOR','modes',modes,'rep',rep,'signature',alpha,
                'local_ranks',[len(blocks[alpha,alpha^d]['basis']) for d in (0,3,5,6)],
                'expected',[7,5,5,4],'seconds',round(time.monotonic()-start,3),flush=True)
        if all(len(b['basis'])==len(b['head_indices']) for b in blocks.values()):break
    records=[]
    for (alpha,beta),b in sorted(blocks.items()):
        full=len(b['basis'])==len(b['head_indices'])
        det=determinant(b['rows']) if full else None
        if full:assert det and det%PRIME
        records.append({'input_signature':alpha,'output_signature':beta,
            'head_indices':b['head_indices'],'rank':len(b['basis']),
            'maximal_rank':len(b['head_indices']),'maximal':full,
            'evaluation_matrix_scale':64,'integer_minor':b['rows'],
            'integer_determinant':str(det) if full else None,
            'minor_determinant_mod65521':det%PRIME if full else None,
            'matrix_entry_samples':b['samples']})
    rank=sum(r['rank'] for r in records);full=all(r['maximal'] for r in records)
    return {'selected_source_modes':modes,'actual_width':2,
        'physical_equal_pair_sector_dimension':112*(1<<17),
        'literal_K_Fourier_affine_phase_checks':physical.phase_checks,
        'P_squared_equals_minus14P_checked':True,
        'operator_words':[list(w) for w in WORDS],
        'left_right_diagonal_character_group':'All8 characters of (Q,D0,D1) on each side.',
        'maximal_predicted_operator_function_rank':168,
        'exact_certified_operator_function_rank':rank,
        'maximal_direct_sum_proved':full,'block_minors':records,
        'sampled_physical_inputs':inputs,'elapsed_seconds':time.monotonic()-start}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--all-modes',action='store_true')
    ap.add_argument('--reps',type=int,default=4);args=ap.parse_args()
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    npth=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    R=[[int(x) for x in row] for row in json.loads(rp.read_text())]
    ports=json.loads(npth.read_text())['ports']
    result=run(R,ports,list(range(8)) if args.all_modes else [5],args.reps)
    out={'schema':'actual-two-stage-small-projector-word-function-span/v1',
        'actual_R_sha256':sha256(rp.read_bytes()).hexdigest(),
        'normalizers_sha256':sha256(npth.read_bytes()).hexdigest(),
        'script_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),'result':result,
        'phase_convention':'K_i=D(Z_mask) P(G_rows); on one-column Walsh frequency w it is the affine permutation G_rows*w+Z_mask. Applying it to both equal Fourier columns gives exactly the same affine frequency with coefficient1. The signed offset is retained.',
        'ordinary_heads':'P_s=-diag(K_s^-1) R_selected^T R_selected diag(K_s)/4. Scalars are applied once outside tensor powers.',
        'covariance_upper_bound':'I has8 phase-supported functions. P0 and P1 each have16 because they commute with QD_s and the other stage. Each of the four mixed words has at most32 because QD0D1 commutes with both projectors. Thus the total is at most168.',
        'independence_consequence':'If the certified rank is168, these seven head families, with every possible left/right Gaussian sign character, are a direct sum in this actual width2 representation. Additional tangent controls with P1,P0P1,P1P0,P0P1P0,P1P0P1 therefore cannot cancel a nonzero P0-family component. The source-bound one-projector tangent invariant applies after projecting onto that summand. The commutator is included as the difference of P0P1 and P1P0.',
        'scope':'This is the explicitly listed ordinary word family, including all three-letter mixed words. It is not the complete algebra generated by P0,P1 and does not exclude longer alternating products, additional stage projectors, other ordinary address maps, or finite nonlinear control interactions.',
        'new_kappa_claimed':False}
    stem='CROSS-STAGE-PROJECTOR-SPAN-ALL8' if args.all_modes else 'CROSS-STAGE-PROJECTOR-SPAN-R5'
    (HERE/(stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')


if __name__=='__main__':main()
