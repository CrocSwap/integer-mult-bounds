# Operator-alignment continuation: exact source codes and ordinary even-head closure

This directory contains reproducible probes and physical-word reviews.  It does not claim an improved admitted kappa.  The strongest constructive results are the helper-clean paired source programs and the uniform ordinary even-head inverse.  The remaining caller question is chronological integration, including the internal source-first boundaries now owned by `retained_state_next`.

## 1. Independently replayed helper-clean source programs

`review_clean_dag.py` implements its own sparse original-column interpreter.  It does not call the retained emitter's evaluator.  It checks scalar operations, free-word cancellation, source and destination frames, every original column, owned-storage lifetimes, physical cross-frame ADDs, paid ranks, and uniqueness of source paid events.

The frozen MODE5 and ALL8 words from `retained_state_next` pass in both directions.  Each pass includes all 632 arbitrary original inputs and all 408 helper inputs.  The new physical ADD has the actual identity map between a completed F9 source and ground destination, or between a retained ground Y mode and the conjugated-F9 backward destination.  Its logical F9 effect is explicit; no free change of frame is assumed.

The helper-clean logical code is

\[
A_T=I-\frac14\sum_{k\in T}r_k^Tr_k,
\qquad C_F=A_T+(I-A_T)F_9^{\otimes m}.
\]

MODE5 removes one rank-eight center.  ALL8 removes all eight.  Every other paid source event is retained exactly once.  The remaining single-copy profile is

\[
\{1:2201,\;2:412,\;3:510,\;4:127,\;5:40\}.
\]

The forward construction declares 984 additional owned arrays; the backward ALL8 construction declares eight.  These are workspace, not additional credited original targets.  The forward prefix norm is 457; the ALL8 backward norm is 525/2.

Receipt: `CLEAN-DAG-INDEPENDENT-REVIEW.json`.

## 2. Literal rational two-copy inverse codes

Two independent copies of every original input are used.  Write F for the common full Gaussian tensor power and let Pi be the projector onto the selected source modes after the actual ordinary K normalizers.  The phase-exact identity F9 squared = X511 makes

\[
G=\begin{pmatrix}0&(6/7)F^{-1}\\F&0\end{pmatrix}
\]

available from the two already-produced F payloads using cross-copy scalar additions and an ordinary X511 translation.  Since G squared = (6/7)I,

\[
C_\pm=I-\Pi+\Pi(-13I\pm14G),
\qquad C_+C_-=I.
\]

The emitted forward word realizes Cplus.  The emitted backward word realizes `X -= Cminus Y`; it is the raw dual of the companion forward residual minus G transpose.  G is not symmetric, so this distinction is essential.

Both producer prefixes finish before the crossed forward consumers.  Both ground-Y caches remain live until both crossed backward consumers finish.  A naive concatenation of backward tails cleared the first copy's cache too soon; the emitted and verified word postpones all those clears.

All 1264 original columns, including 816 independent helper columns, pass.  The doubled query profile is `{1:4402,2:824,3:1020,4:254,5:80}`, with no rank-eight centers.  Declared owned arrays are 1970 forward and 18 backward, including the two original C0 allocations.  Peak live counts are 1969 and 17.

Artifact: `TWO-COPY-CLEAN-DAG-WORDS.json.gz`.

SHA256: `0175ea33a8bc28aa5c02b27a9c4f0f3b2915e38261765814f860373c9ff0c5f8`.

These are source couplings, not yet a complete replacement caller.  In particular, the interleaved D transforms must still be handled physically.

### Corrected gauge claim

The single-stage identity

\[
T^{-1}(C_sD_s)T
=\operatorname{diag}(I,D_s)A_s\operatorname{diag}(D_s,I)
\]

is valid for the proposed two-copy gauge.  Its products do **not** collapse to a single ordinary A-word between two D-word boundaries.  A mixes the copies and therefore does not commute with a half-copy D.  The review receipt records an explicit two-stage negative control.  No result here uses that discarded product formula.

## 3. Uniform all-eight even-head inverse

Use the actual source ordering of R and define

\[
V=\operatorname{diag}(K_i^{-1})R^T,
\quad L=R\operatorname{diag}(K_i)/56,
\quad T_2=LQ^2V.
\]

All 112 phase-exact source normalizers satisfy

\[
K_iQ^2K_i^{-1}=-X_{q_i}.
\]

Consequently

\[
T_2=\frac1{56}\sum_iR_{:,i}R_{:,i}^T
(-X_{q_i})^{\otimes m}.
\]

In Fourier coordinates, the translation character depends only on the XOR of the m column frequencies.  Thus the complete spectrum at every width is certified by 512 exact 8-by-8 integer matrices.  Numerical eigenvalues only propose roots; matching the full integer characteristic polynomial certifies each result.

For all eight source modes the spectrum is

\[
\{0,\pm1/7,\pm2/7,\pm6/7,\pm1\}.
\]

For source R5 alone it is `{0, ±1/7, ±1}`.  The all-eight polynomial identity is

\[
T_2(T_2^2-I)(49T_2^2-I)(49T_2^2-4I)(49T_2^2-36I)=0.
\]

`even_head_resolvent.py` emits an explicit ordinary Horner program for `(I-(14/13)T2)^-1`.  It uses zero Gaussian queries, 7240 ADDs, and 17 owned fields including its eight outputs, while retaining its eight arbitrary input fields.  All coefficients are rational and are applied outside tensor powers.  Its exact operator norm is 13.  Literal signed-translation replay checks both tensor-width parities.

The same receipt includes ordinary Moore–Penrose polynomials for `(I+T2)^dagger` and `(I-T2)^dagger`, both of norm 7.  The singular eigenvalue is explicitly annihilated.  With B = `[V,Q²V]` and A = `[L;LQ²]` = B*/56, the normalized Gram AB is `[[I,T2],[T2,I]]`.  Therefore `B(AB)^dagger A` is an ordinary orthogonal projector onto the even orbit, with no inversion on a zero sector.

Receipt and complete physical ordinary schedule: `EVEN-HEAD-RESOLVENT.json`.

The odd-head T1 is different.  The four-Q-orbit Gram has blocks T_(b-a); a scalar DFT4 diagonalizes it into `4 L E_r(Q) V`.  Opposite blocks sum to `2(I±T2)`.  T2 supplies those ordinary sums, not the odd spectral split.

## 4. The full ordinary two-projection algebra is finite

Let Pi = VL and S = Q².  The ordinary algebra generated by Pi and S has dimension 32 for all eight modes, and 16 for source R5 alone, at every width.  For all eight modes it is seven full 2-by-2 matrix blocks plus four scalar blocks.  The receipt gives rational matrix units constructed from the spectral projectors of Pi S Pi.  This closes arbitrary polynomial word length; it is not a bounded-degree observation.

Receipt: `FILTERED-FULL-COMPLETE-EVEN-ALGEBRA.json`.

## 5. Actual one-FULL caller substitution and the terminal-only stopping point

`filtered_full_caller.py` reads the unmodified `selected_p3_keep43` source.  It changes exactly one LOCAL and introduces no nonordinary code gauges.  If Pold = C5-I = -14Pi, then

\[
C_F-I=P_{\rm old}(I-F_s).
\]

Its exact terminal error is the previous one-P error minus the same error with its source row multiplied by F_s.  The second term makes the changed D_s exponent even.  This is a real reduction in that term's transform support, but no fresh physical provider is inferred from it.

The initial endpoint and prefix-cache probes retained every corrupted-final-bank term, including higher P powers.  Their receipts are `FILTERED-FULL-CALLER.json` and `FILTERED-FULL-CALLER-PREFIX.json`.

`complete_even_algebra.py` then removes the degree restriction for the terminal family using actual width-two frequency pairs.  On XOR frequency zero, Q² = I.  A positive F_s sample leaves the affected endpoint I.  Two negative F_s samples yield `-I+E_a` and `-I+E_b`, with E_a squared = E_b squared = zero and different exact entries.  A common decoder `W z + V x` using final banks and retained original inputs would require both `W=I+E_a/2` and `W=I+E_b/2`.  This contradiction is checked for all seven LOCAL placements, both for source R5 and the full eight-mode projector.

The result is confined to the complete ordinary algebra generated by Pi, Q² and squared stage transforms.  It does not exclude other ordinary routes, new paid providers, changed target families, or chronological insertion.  In particular, the newly validated internal source-first cuts in `retained_state_next` remain outside this terminal-only statement.

## 6. Residual rank and invoice scope

For k selected modes, array dimension N = 2^(9m), and the actual helper-clean filtered defect,

\[
\operatorname{rank}(C_F-I)
=k\bigl(N-\operatorname{mult}(F_s=1)\bigr).
\]

The multiplicity is computed exactly in `EVEN-HEAD-RESOLVENT.json`.  The defect occupies asymptotically three quarters of each exceptional coefficient field, or six fields for all eight modes.  A constant fraction of array dimension does not lower the Gaussian rank exponent of a child query.  No paid-query or kappa saving is credited from that rank reduction alone.

The actual internal source caches and before-consumer feedback were subsequently tested as described below. The physical paired companion and changes to paid operations remain separate integration opportunities.

## 7. Internal chronological controls and the actual remaining transport

`internal_tangent_filtered_caller.py` first adds the authenticated internal gate

\[
\text{opposite input}\mathrel{+}=G(D_t\text{source input})
\]

to every existing FULL. Its first-order response is
`suffix_after * D_t G D_t * prefix_before`, which the earlier outer-cut search did not contain. Reordering an unchanged FULL to expose this source cut retains its original center queries and paid profile; the source DAG does not depend on those centers.

`actual_tangent_reachability.py` then allows every earlier event-boundary bank snapshot at every later cut, every FULL's internal transformed source at the still-unconsumed opposite input, and every retained internal source at every later bank. There are 28,694 controls per changed stage, with all six original banks independent. The coefficients range over the complete algebra generated by the selected P, Q² and squared stage transforms, with no polynomial-degree cutoff. Every stage still fails the linear reachability equation.

The certificate uses actual width-two equal Fourier pairs. The source-stage operator functions are certified by exact source-dependent integer minors; the six other stage signs remain independent, rather than being set to one. The latter distinction is essential: stage zero passes the weaker sector with all other stages equal to identity.

The source-first stage-zero recipe from `retained_state_next` is independently replayed in `ACTUAL-TANGENT-REACHABILITY.json`. With

\[
t=P_0D_0(x_1-x_2),
\]

it restores all three negative outputs, leaving only

\[
e_3=(D_5D_6-I)t,\qquad
e_4=(D_1D_2-I)t,\qquad
e_5=D_5D_6(D_1D_2D_3D_4-I)t.
\]

There are no odd-Q factors in this remaining defect. The missing resource is transport of the retained mode through the later paid D jobs. Fresh queries for those transports must be charged; this identity does not supply them.

## 8. The invariant is not a fixed-R-coefficient artifact

`arbitrary_owner_tangent.py` enlarges every ordinary gate to an independently chosen arbitrary 112-by-112 owner matrix in the common source-K chart. This includes the full matrix algebra, not only polynomial functions of the selected projector.

It suffices to inspect output owner4 and input owner5. Their source masks are131 and259. The actual filtered-defect entries are `P45=1/4` for source R5 and `P45=-1/2` for all eight modes. The three masks131,259,511 are independent over F2, so the corresponding source signs q4, q5, zeta realize every one of their eight combinations. Together with the six later-stage signs, this gives 512 independent exact characters. The literal signed K maps and the physical frequency representatives are recorded.

For a perturbation T on this owner pair, define

\[
\Lambda(T)=\mathbb E\left[
\zeta D_1D_2\left(q_4q_5T_{1,1}+q_5T_{4,1}\right)
\right],
\]

where the expectation is the average over those512 sign choices and the displayed matrix indices are the six caller banks. Every one of the 14,347 chronological scalar `M45` controls has Lambda zero. The required stage-zero correction has Lambda `-P45`, which is nonzero. Other owner entries cannot affect this pair at first order because the unchanged caller is owner diagonal. The other six changed stages have similarly small exact dual certificates.

Receipt: `ARBITRARY-OWNER-TANGENT.json`. This is a first-order chronological obstruction for constant owner matrices in the stated chart. It does not exclude finite controls whose essential effect begins at higher order, ordinary address maps outside that chart, other native internal states, or changed paid jobs.

## 9. A bounded cross-stage projector enlargement

Other stage projectors are ordinary and are outside the preceding single-chart owner family. `cross_stage_projector_span.py` therefore tests the actual two-stage heads

\[
I,P_0,P_1,P_0P_1,P_1P_0,P_0P_1P_0,P_1P_0P_1
\]

with every possible left/right character of Q,D0,D1. This includes the commutator. The actual width-two equal-pair sector needs17 physical axes; all Gaussian operators are diagonal signs there, and the signed K actions are literal affine frequency permutations.

For both source R5 and all8, the function-space rank is exactly168, the maximal value `8+16+16+4*32`. Thirty-two explicit integer minors prove this, using only eight physical input basis states per source selection. The seven head families therefore form a direct sum even after the Gaussian boundary phases. The added mixed-stage words through length three cannot cancel the nonzero P0-family component of the tangent defect.

Receipts: `CROSS-STAGE-PROJECTOR-SPAN-R5.json` and `CROSS-STAGE-PROJECTOR-SPAN-ALL8.json`. This bounded family is not the complete algebra generated by P0 and P1. No larger ordinary-control impossibility is claimed.

## 10. Finite chronological feedback has curvature, but the bounded cleanup families fail

The nonlinear follow-up finds five actual two-gate paths escaping the earlier tangent functional. All start at the unique cut1 gate `bank1 += a P0 bank0`. This is a real second-order direction, not a formal Lie-bracket claim. The gate does not recur later, so an abstract commutator cannot simply reuse it.

Exact finite checks cover7,621 recurring four-cut loops,61,543 two-gate placements, and182,254 three-gate placements with that first gate. No repair results. Adding the legal internal source-first scalarizing feedback creates48 multilinear-span candidates; all48 fail the actual coefficient-product equations, certified by rational univariate gcd1. A separate nilpotent-layer relaxation with556 later generator classes also fails.

`BALANCED-ACTUAL-SECTOR.json` certifies32 actual source frequencies with `R Q R^T=0` for all8. Thus `P Q P=0`, and exact12-function integer minors justify the finite-word sector screen at arbitrary P degree. All64 external-stage characters remain present. This is a necessary physical sector, not a free chart or a positive all-width construction.

The complete formulas, chronology, limits, primary-source design inputs, and reproduction commands are in `FINITE-CONTROL-RESULTS.md`. No unrestricted finite-feedback lower bound or kappa gain is claimed. A changed native carrier or already-paid later-stage transport remains outside these bounded families.

## 11. A new phase-exact foreign-mode carrier and one-query control

The changed-premise snapshot test first found eight pre-center rank8 contacts whose one-rank1 lifts, together with two full-frame scalar snapshots each, recover all local RY modes in the unchanged backward call. This exact local construction is in `RANK1-SNAPSHOT-COMPLETION.json`. It retains the original center bill. On the actual scalar-center-free word the eight corresponding differences are exactly zero; they cannot be credited as replacement queries. The all8 and mode5-only augmentation receipts use their respective actual emitted words and retain all632 original columns.

A different target does align. Let the current call use stage1 axes `{0,9,...,16}`, with its private D1 axes `{9,...,16}`. Let K0 be the earlier stage's signed normalizer on axes `{0,...,8}`. The literal current backward Y exit is `bar(S1_i) Ynative_i`, with `Ynative_i=K1_i y_i`. Its emitted ordinary exit adapter BY satisfies

\[
BY_i\overline{S_{1,i}}=D_1K_{1,i}^{-1}.
\]

Because K0 and D1 have disjoint support, every one of the112 raw Y exits can be ordinarily recoded into a common D1 mode carrier:

\[
(K_{0,i}BY_i)\overline{S_{1,i}}
=D_1K_{0,i}K_{1,i}^{-1}.
\]

Thus56 ordinary mapped ADDs gather one earlier mode `u=D1 r_k K0 y`. Applying one common rank1 `Q_mode` or its inverse gives `Q_mode^± D1 r_k K0 y`. The source script `cross_stage_rank1_observer.py` checks every9-axis exit identity by tableau and absolute-phase replay, every17-axis carrier identity, and112 negative controls omitting the source Z signs. All pass. It emits every literal ordinary route in `CROSS-STAGE-RANK1-OBSERVER.json`.

After ordinary scatter `K0^-1 r_k^T/4`, the new operator is

\[
J_{0,k}^{\pm}D_1,
\qquad
J_{0,k}^{\pm}=\frac14K_0^{-1}r_k^TQ_{\mathrm{mode}}^{\pm}r_kK_0.
\]

The odd head remains inside the gather/scatter. A source-bound diagonal-block counterexample rejects replacing this by `Q^± P0`. The zero-query carrier itself is only `-P0,k D1`, which was already an available bank-boundary operation.

Normalize `E_a=K0^-1 r_k^T Q_mode^a r_k K0/56`. Then `E_a E_b=E_(a+b mod4)`, `E0=Pi_k`, and `E2` is ordinary. Consequently `H=I-Pi_k+E1` obeys `H^4=I`, with ordinary `H^2`. It costs one paid rank1 mode query. These identities hold for every tensor width, with scalar R coefficients outside tensor powers.

`CROSS-STAGE-SOURCE-CUT.json` independently replays the actual early-Y source-first word through event2618. All112 Y outputs are complete in their final physical frames; all112 X inputs and all408 helpers are unread and unchanged. The new mode-head query can therefore execute at that real internal cut and feed the subsequent X consumer. The independent phase review is `retained_state_next/FOREIGN-MODE-OBSERVER-INDEPENDENT-REVIEW.json`.

This is an admitted new paid primitive and a real chronological placement. It does not isolate an old cached contribution from arbitrary current input, and no caller repair or kappa gain is claimed yet.
