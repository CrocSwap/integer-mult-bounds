// Exact exhaustive quotient geometry for the actual112 bare-X exit directions.
// Input lines: physical q (1..511), nonzero-R-row bitmask (0..255).
// All q have odd parity.  Their low8 bits identify the affine odd hyperplane.
// An even Fourier subspace A uses only even vectors.  An odd-containing W
// has A=W intersect even, and deletes exactly one A coset from the paid heads.
#include <array>
#include <bit>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

struct Witness {
  int sum=9999, max=9999, odd=-1;
  std::vector<int> rows;
  std::array<int,8> counts{};
};

std::vector<std::pair<int,int>> ports;
std::array<Witness,10> best;
std::array<std::array<int,8>,10> individual;
std::array<unsigned long long,9> totals{};
std::vector<int> pivots;

void update(int dim, const std::vector<int>& rows, int odd,
            const std::array<int,8>& counts) {
  int sum=0, maximum=0;
  for(int k=0;k<8;k++) {
    sum+=counts[k]; maximum=std::max(maximum,counts[k]);
    individual[dim][k]=std::min(individual[dim][k],counts[k]);
  }
  if(sum<best[dim].sum || (sum==best[dim].sum && maximum<best[dim].max))
    best[dim]={sum,maximum,odd,rows,counts};
}

void evaluate(const std::vector<int>& rows) {
  int d=rows.size(); totals[d]++;
  std::array<uint8_t,256> coverage{};
  std::array<int,8> counts{};
  for(auto [physical, modes]: ports) {
    int r=physical&255;
    for(int j=0;j<d;j++) if(r&(1<<pivots[j])) r^=rows[j];
    int fresh=modes & ~coverage[r];
    coverage[r]|=modes;
    for(int k=0;k<8;k++) counts[k]+=(fresh>>k)&1;
  }
  update(d,rows,-1,counts);
  if(d<9) {
    // Choosing any affine odd vector in one of these quotient cosets adds
    // one Fourier direction and makes that coset a diagonal, free head.
    for(int r=0;r<256;r++) if(coverage[r]) {
      auto adjusted=counts;
      for(int k=0;k<8;k++) adjusted[k]-=(coverage[r]>>k)&1;
      update(d+1,rows,r,adjusted);
    }
  }
}

void emit_pivots(int d) {
  std::vector<std::pair<int,int>> slots;
  int pivot_mask=0;
  for(int p:pivots) pivot_mask|=1<<p;
  for(int j=0;j<d;j++) for(int col=pivots[j]+1;col<8;col++)
    if(!(pivot_mask&(1<<col))) slots.emplace_back(j,col);
  for(unsigned mask=0;mask<(1u<<slots.size());mask++) {
    std::vector<int> rows;
    for(int p:pivots) rows.push_back(1<<p);
    for(int t=0;t<(int)slots.size();t++) if(mask&(1u<<t))
      rows[slots[t].first]|=1<<slots[t].second;
    evaluate(rows);
  }
}

void choose_pivots(int d,int start=0) {
  if((int)pivots.size()==d) {emit_pivots(d);return;}
  for(int p=start;p<=8-(d-(int)pivots.size());p++) {
    pivots.push_back(p);choose_pivots(d,p+1);pivots.pop_back();
  }
}

void array_out(const std::vector<int>& v) {
  std::cout<<"[";
  for(size_t i=0;i<v.size();i++) {if(i)std::cout<<",";std::cout<<v[i];}
  std::cout<<"]";
}

int main(int argc,char**argv) {
  if(argc!=2) {std::cerr<<"usage: chart_frontier INPUT\n";return 2;}
  std::ifstream input(argv[1]);int q,m;
  while(input>>q>>m) {
    if(std::popcount((unsigned)q)%2!=1) return 3;
    ports.emplace_back(q,m);
  }
  if(ports.size()!=112)return 4;
  for(auto &row:individual)row.fill(9999);
  for(int d=0;d<=8;d++)choose_pivots(d);
  std::cout<<"{\"even_subspaces_enumerated_by_dimension\":";
  std::vector<int> tv;for(auto t:totals)tv.push_back(t);array_out(tv);
  std::cout<<",\"frontier\":[";
  for(int d=0;d<=9;d++) {
    if(d)std::cout<<",";
    auto w=best[d];
    std::cout<<"{\"Fourier_dimension\":"<<d<<",\"minimum_total_queries_for_all8_modes\":"<<w.sum
             <<",\"worst_mode_in_best_sum_witness\":"<<w.max<<",\"witness_even_basis_low8\":";
    array_out(w.rows);
    std::cout<<",\"witness_odd_coset_low8\":"<<w.odd<<",\"witness_per_mode_queries\":";
    array_out(std::vector<int>(w.counts.begin(),w.counts.end()));
    std::cout<<",\"individual_mode_minima\":";
    array_out(std::vector<int>(individual[d].begin(),individual[d].end()));
    std::cout<<",\"fresh_common_chart_total_including8_reads\":"<<(8*d+w.sum)<<"}";
  }
  std::cout<<"]}\n";
}
