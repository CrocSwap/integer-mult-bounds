#!/usr/bin/env python3
"""Exact Majorana alignment identity and source-native Pauli-route admission.

The logical nine-array identity is positive. Its global-Pauli Majorana
realization has exponentially many nonzeros in each native physical block,
so it is not a fixed-term ordinary route at all tensor widths.
"""
from collections import Counter
from pathlib import Path
import json
import time
import cross_column_routes as cc

HERE = Path(__file__).resolve().parent


def plus(out, key, value):
    old = out.get(key, (0, 0))
    value = old[0]+value[0], old[1]+value[1]
    if value == (0, 0):
        out.pop(key, None)
    else:
        out[key] = value


def multiply(A, B):
    out = {}
    for (q, z), a in A.items():
        for (r, s), b in B.items():
            value = cc.mul(a, b)
            if (z & r).bit_count() & 1:
                value = -value[0], -value[1]
            plus(out, (q ^ r, z ^ s), value)
    return out


def add(A, B):
    out = dict(A)
    for key, value in B.items():
        plus(out, key, value)
    return out


def scale(A, n):
    return {key: (n*a, n*b) for key, (a, b) in A.items() if n}


def majoranas(positions):
    result, prefix = [], 0
    for bit in positions:
        result.append({(1 << bit, prefix): (1, 0)})
        result.append({(1 << bit, prefix | (1 << bit)): (0, 1)})
        prefix |= 1 << bit
    for k in range(8):
        for j in range(8):
            anticommutator = add(multiply(result[k], result[j]), multiply(result[j], result[k]))
            cc.need(anticommutator == ({(0, 0): (2, 0)} if j == k else {}),
                    "Majorana Clifford relation failed")
    return result


def source_paulis(ce, canonical):
    result = []
    for i, q in enumerate(canonical["ports"]):
        U = ce.canonical_frame(9, canonical["frames"][canonical["start"][i]])
        P = U.then(U)
        vector, denominator = P.zero_state()
        z = sum((phase//2) << j for j, (x, zz, phase) in enumerate(P.tab[:9]))
        cc.need(denominator == 0 and sum(v != (0, 0) for v in vector) == 1,
                "Actual source square is not the asserted Pauli")
        p = [cc.phase(k) for k in range(4)].index(vector[q])
        cc.need(q not in (0, 1), "Four translated supports are not distinct")
        cc.need((2*p+2*((q & z).bit_count() & 1)) % 4 == 0, "Source Pauli is not Hermitian")
        result.append((q, z, p))
    return result


def head_polynomials(width, q, z, p):
    Q, Ustar = {(0, 0): (1, 0)}, {(0, 0): (1, 0)}
    for j in range(width):
        Q = multiply(Q, {(0, 0): (1, 1), (1 << (9*j), 0): (1, -1)})
        Ustar = multiply(Ustar, {(0, 0): (1, -1),
                               (q << (9*j), z << (9*j)): cc.mul((1, 1), cc.phase(p))})
    return Q, Ustar


def phase_representatives(M):
    """One x for each character of the span of all z labels in M."""
    basis = {}
    for q, z0 in M:
        z = z0
        for pivot in sorted(basis):
            if z >> pivot & 1:
                z ^= basis[pivot]
        if z:
            pivot = (z & -z).bit_length()-1
            for k in list(basis):
                if basis[k] >> pivot & 1:
                    basis[k] ^= z
            basis[pivot] = z
    pivots = sorted(basis)
    cc.need(all(((row >> p) & 1) == (p == pivot)
                for pivot, row in basis.items() for p in pivots), "Character dual basis")
    return [sum(((bits >> k) & 1) << p for k, p in enumerate(pivots))
            for bits in range(1 << len(pivots))]


def column_histogram(M, width):
    reps = phase_representatives(M)
    multiplicity = (1 << (9*width)) // len(reps)
    hist, minimum_norm, maximum_norm = Counter(), None, None
    for x in reps:
        vector = {}
        for (q, z), value in M.items():
            if (z & x).bit_count() & 1:
                value = -value[0], -value[1]
            plus(vector, x ^ q, value)
        norm = sum(a*a+b*b for a, b in vector.values())
        cc.need(norm == 4*(1 << (4*width)), "Literal physical column norm is not2")
        cc.need(len(vector) >= 4**(width-1), "Physical sparsity violates norm/entry bound")
        hist[len(vector)] += multiplicity
        minimum_norm = norm if minimum_norm is None else min(minimum_norm, norm)
        maximum_norm = norm if maximum_norm is None else max(maximum_norm, norm)
    return hist, len(reps)


def run():
    start = time.monotonic()
    ce, canonical, normals, R, routes = cc.source_data()
    paulis = source_paulis(ce, canonical)
    results = []
    for width, positions in ((1, [0, 1, 2, 3]), (2, [0, 9, 1, 10])):
        Gamma = majoranas(positions)
        histogram = Counter()
        per_observer = [Counter() for _ in range(9)]
        per_port, representative_columns = [], 0
        for i, (q, z, p) in enumerate(paulis):
            gamma = {}
            for k in range(8):
                gamma = add(gamma, scale(Gamma[k], int(R[k][i])))
            cc.need(len(gamma) == 4 and multiply(gamma, gamma) == {(0, 0): (4, 0)},
                    "Actual root column is not a four-term norm2 Majorana vector")
            logical = [gamma]
            for k in range(8):
                beta = multiply(gamma, Gamma[k])
                cc.need(add(multiply(Gamma[k], gamma), beta) ==
                        ({(0, 0): (2*int(R[k][i]), 0)} if R[k][i] else {}),
                        "Nine-array exact demanded anticommutator identity")
                logical.append(beta)
            Q, Ustar = head_polynomials(width, q, z, p)
            local = Counter()
            for a, block in enumerate(logical):
                M = multiply(multiply(Q, block), Ustar)
                h, checked = column_histogram(M, width)
                histogram.update(h)
                local.update(h)
                per_observer[a].update(h)
                representative_columns += checked
            per_port.append({"port": i, "q": q, "z": z, "Pauli_phase_exponent": p,
                             "minimum_physical_column_support": min(local),
                             "maximum_physical_column_support": max(local)})
        total = 9*112*(1 << (9*width))
        cc.need(sum(histogram.values()) == total, "Complete phase-class census lost columns")
        results.append({"width": width, "Majorana_qubit_positions": positions,
                        "native_blocks": 9*112,
                        "actual_columns_covered": total,
                        "exact_phase_representative_columns_checked": representative_columns,
                        "column_support_histogram": dict(sorted(histogram.items())),
                        "minimum_support": min(histogram), "maximum_support": max(histogram),
                        "per_observer_minimum_support": [min(h) for h in per_observer],
                        "per_observer_maximum_support": [max(h) for h in per_observer],
                        "per_port": per_port,
                        "matrix_entry_denominator": 1 << (2*width),
                        "physical_column_squared_norm": 4})
    result = {"status": "PASS_NINE_ARRAY_ABSTRACT_IDENTITY_AND_NATIVE_PAULI_MAJORANA_OBSTRUCTION",
              "logical_identity": "Gamma_k A+B_k=2(Rx)_k; A=sum_i gamma_i x_i; B_k=sum_i gamma_i Gamma_k x_i",
              "gamma_i": "sum_k R_ki Gamma_k, four nonzero terms, gamma_i²=4I",
              "native_physical_blocks": "Q_m gamma_i U_i*^tensor(m), Q_m gamma_i Gamma_k U_i*^tensor(m)",
              "finite_exact_censuses": results,
              "all_width_nonzero_entries_per_column_lower_bound": "4^(m-1)",
              "all_width_proof": "For any whole-width Pauli P, Q_m P U_i*^tensor(m) has exactly4^m nonzeros per column, each magnitude2^-m. The four-term sum has entry magnitude<=4*2^-m and column norm2, so support>=4^(m-1).",
              "scope": "Any8 Hermitian anticommuting global Pauli strings, allowed to depend on width and to mix tensor columns, with the actual fixed four-nonzero R columns. Excludes a bounded number of weighted physical monomial terms per block. Does not exclude non-Pauli monomial Majoranas, nonmonomial ordinary algorithms, or a different joint nine/eighteen-observer factorization."}
    (HERE / "MAJORANA-ADMISSION-RESULT.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({"status": result["status"], "seconds": round(time.monotonic()-start, 3),
                      "censuses": [{k: row[k] for k in ("width", "actual_columns_covered",
                        "exact_phase_representative_columns_checked", "column_support_histogram",
                        "minimum_support", "maximum_support")} for row in results]}, indent=2))


if __name__ == "__main__":
    run()
