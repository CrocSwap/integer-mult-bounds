#!/usr/bin/env python3
"""Parametric, source-bound carry/phase/translation observer routes.

Addresses use nine bit-plane words, each of length m.  Word 0 is the common
rank-one active coordinate, word 1 the carry spectator, and words 2..8 the
seven independently translated spectators. Scalar coefficients are outside
all tensor powers. This module is also used by the whole-demand screen.
"""
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "tensor_obstruction"


def need(value, message):
    if not value:
        raise AssertionError(message)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def gf_mul(a, b):
    """GF(128), polynomial x^7+x+1; irreducibility checked by verify()."""
    result = 0
    while b:
        if b & 1:
            result ^= a
        b >>= 1
        a <<= 1
        if a & 128:
            a ^= 131
    return result


def parameters(observer, port):
    tag = gf_mul(observer+1, port)
    return tag, 2*tag+1


def control(z, tag, width):
    mask = (1 << width)-1
    rotate = ((z << 1) | (z >> (width-1))) & mask
    return (z & rotate) ^ (tag & z)


def logical_suffix(words, observer, port, width):
    """D_ai rho_ai, returning destination bit planes and a real sign."""
    tag, multiplier = parameters(observer, port)
    words = list(words)
    words[1] = multiplier*words[1] & ((1 << width)-1)
    for bit in range(7):
        words[bit+2] ^= (tag >> bit) & 1
    z = words[1]
    f = ((words[0] & control(z, tag, width)).bit_count() ^ (tag & z).bit_count()) & 1
    return words, 1-2*f


def physical_suffix(words, observer, port, width):
    """Q D_ai Q* rho_ai, returning destination and exponent of i."""
    tag, multiplier = parameters(observer, port)
    words = list(words)
    words[1] = multiplier*words[1] & ((1 << width)-1)
    for bit in range(7):
        words[bit+2] ^= (tag >> bit) & 1
    z, a = words[1], words[0]
    c = control(z, tag, width)
    exponent = (2*((a & c).bit_count() & 1) +
                2*((tag & z).bit_count() & 1) - c.bit_count()) % 4
    words[0] ^= c
    return words, exponent


def source_data():
    pins = json.loads((HERE / "SOURCES.json").read_text())
    for rec in pins["files"]:
        need(sha256((HERE / rec["file"]).read_bytes()).hexdigest() == rec["sha256"],
             "Changed pinned source dependency")
    ce = load_module("cross_column_ce", BASE / "inputs/clifford_exact.py")
    canonical = json.loads(gzip.decompress((BASE / "inputs/native-source.json.gz").read_bytes()))["canonical"]
    normals = json.loads((BASE / "inputs/NORMALIZERS.json").read_text())["ports"]
    R = [[Fraction(x) for x in row] for row in json.loads((BASE / "inputs/R.json").read_text())]

    def word_op(word):
        op = ce.ident(9)
        for e in word:
            if e[0] == "P":
                step = ce.perm(9, e[1])
            elif e[0] == "D":
                step = ce.diag(9, e[1], e[2])
            elif e[0] == "X":
                step = ce.xgate(9, e[1])
            elif e[0] == "phase":
                step = ce.Op(9, ce.identity(9), [("phase", e[1])])
            else:
                raise AssertionError("Nonmonomial source normalizer")
            op = op.then(step)
        return op

    Q, routes = ce.cgate(9, 1), []
    for i, rec in enumerate(normals):
        q = canonical["ports"][i]
        need(canonical["frames"][canonical["start"][i]] == [q], "Changed source head")
        S = word_op(rec["compiled_wrappers"]["input_X"]["word"]).adjoint()
        Kstar = word_op(rec["K_word"]).adjoint()
        U = ce.canonical_frame(9, [q])
        lhs, rhs = U.then(S), Kstar.then(Q)
        need(lhs.tab == rhs.tab and lhs.zero_state() == rhs.zero_state(),
             "Literal source normalizer S_i U_i = Q K_i* failed")
        routes.append({"port": i, "q": q, "source_prefix_word": S.circuit,
                       "Kstar_word": Kstar.circuit})
    return ce, canonical, normals, R, routes


def mul(a, b):
    return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])


def phase(k):
    return [(1, 0), (0, 1), (-1, 0), (0, -1)][k % 4]


def verify():
    # Every nonzero element is invertible. This proves the degree-seven
    # quotient is a field and checks the exact tag maps, without a table file.
    need(all(any(gf_mul(x, y) == 1 for y in range(1, 128)) for x in range(1, 128)),
         "The chosen polynomial is not irreducible")
    need(all(len({parameters(a, i)[0] for i in range(112)}) == 112 for a in range(18)),
         "A row of observer tags is not injective")
    ce, canonical, normals, R, routes = source_data()
    literal = []
    for width in (2, 3, 4):
        size = 1 << width
        Q = []
        for a in range(size):
            row = []
            for u in range(size):
                value = (1, 0)
                for bit in range(width):
                    value = mul(value, (1, -1) if (a ^ u) >> bit & 1 else (1, 1))
                row.append(value)
            Q.append(row)
        # All low-width distinct phase/multiplier pairs occurring among the
        # 2016 source/observer routes. The seven translations commute with Q.
        tags = sorted({parameters(a, i)[0] & (size-1) for a in range(18) for i in range(112)})
        columns = 0
        for tag in tags:
            C = 2*tag+1
            for z in range(size):
                zz = C*z & (size-1)
                c = control(zz, tag, width)
                for a in range(size):
                    support = {}
                    for b in range(size):
                        value = [0, 0]
                        for u in range(size):
                            term = mul(Q[b][u], (Q[a][u][0], -Q[a][u][1]))
                            sign = 1-2*((((u & c).bit_count()) ^ (tag & zz).bit_count()) & 1)
                            value[0] += sign*term[0]
                            value[1] += sign*term[1]
                        if value != [0, 0]:
                            support[b] = tuple(value)
                    exponent = (2*((a & c).bit_count() & 1) +
                                2*((tag & zz).bit_count() & 1) - c.bit_count()) % 4
                    need(support == {a ^ c: tuple(x * (1 << (2*width)) for x in phase(exponent))},
                         "Literal noncolumnwise Q D rho Q* phase mismatch")
                    columns += 1
        literal.append({"width": width, "distinct_reduced_routes": len(tags),
                        "literal_active_spectator_columns_checked": columns})

    degrees = []
    for width in range(2, 13):
        values = [((3*x) >> (width-1)) & 1 for x in range(1 << width)]
        for bit in range(width):
            for mask in range(1 << width):
                if mask >> bit & 1:
                    values[mask] ^= values[mask ^ (1 << bit)]
        degree = max(mask.bit_count() for mask, coefficient in enumerate(values) if coefficient)
        need(degree == width-1 and values[(1 << (width-1))-1] == 1,
             "Unexpected multiplication-by-three ANF degree")
        degrees.append({"width": width, "highest_output_bit_ANF_degree": degree})

    # Three old hard subspaces are checked separately. These checks certify
    # that the route family escapes those probes; they do not recover full R.
    hard_subspaces = []
    for width in (4, 8, 12):
        E = {sum(15 << (4*b) for b in range(width//4) if mask >> b & 1)
             for mask in range(1 << (width//4))}
        for a in range(18):
            signatures = []
            for i in range(112):
                tag, _ = parameters(a, i)
                # Other seven spectator words of every image lie in E+tag_j.
                signature = tuple((tag >> j) & 1 for j in range(7))
                signatures.append(signature)
            need(len(set(signatures)) == 112 and not any((x ^ 1) in E for x in E),
                 "Physical diagonal images are not separated by tag cosets")
        # Explicit leakage of the carry part: all-one spectator is sent to -3.
        need(((3*((1 << width)-1)) & ((1 << width)-1)) not in E,
             "Carry route accidentally preserves the repeated diagonal support")
        hard_subspaces.append({"width": width, "each_observer_unweighted_route_image_rank": 112,
                               "actual_alpha_weighted_observer_image_ranks": [56]*8+[112]*10,
                               "reason": "Unweighted routes have112 disjoint seven-spectator translation cosets; zero alpha entries remove56 routes from each of the first8 rows",
                               "carry_also_leaves_repeated_diagonal_support": True})
    # The basis state active=1, spectators=0 is sent to112 different tag states.
    for a in range(18):
        images = []
        for i in range(112):
            dest, sign = logical_suffix([1]+[0]*8, a, i, 2)
            images.append(tuple(dest))
        need(len(set(images)) == 112, "Old common active-basis witness survives")
    # On active=0, z=0..127, logical images of the full constant vector have
    # characters (-1)^<tag,z>. Distinct tags give112 independent columns.
    walsh_rank = 112
    need(all(sum((1-2*((x & y).bit_count() & 1))*(1-2*((x & z).bit_count() & 1))
                      for x in range(128)) == 128*(y == z)
             for y in range(128) for z in range(128)), "Walsh character identity")

    # Reuse the exact owner-block interpreter; the new route identities above
    # supply its operator labels. No original X, Y, or helper is assumed zero.
    owner = load_module("cross_owner", HERE / "check_owned_clear_macro.py")
    initial = {i: {(i, ()): Fraction(1)} for i in range(632)}
    forward = [["clear", 632]] + [["add", 632, i, 1, [f"M{i}"]] for i in range(112)]
    forward += [["map", 632, "Qstar"], ["add", 112, 632, 1, []], ["clear", 632]]
    inverse = [list(e) for e in forward]
    inverse[-2] = ["add", 112, 632, -1, []]
    dual = [["clear", 632], ["copy", 632, 112], ["map", 632, "Qbar"]]
    dual += [["add", i, 632, -1, [f"M{i}T"]] for i in range(112)]
    dual += [["clear", 632]]
    endpoint, erased = owner.symbolic(initial, forward)
    restored, _ = owner.symbolic(endpoint, inverse)
    reverse, _ = owner.symbolic(initial, inverse)
    restored2, _ = owner.symbolic(reverse, forward)
    raw, erased_dual = owner.symbolic(initial, dual)
    need(all(restored[i] == restored2[i] == initial[i] for i in range(632)), "Owner inverse replay failed")
    for i in range(632):
        expected = dict(initial[i])
        if i < 112:
            expected[(112, (f"M{i}T", "Qbar"))] = Fraction(-1)
        need(raw[i] == expected, "Raw inverse-transpose owner replay failed")
    need(erased == erased_dual == 1, "Nonzero owned clear was not explicit")

    alpha = [[int(R[a][i]) if a < 8 else 1 for i in range(112)] for a in range(18)]
    macro = {"schema": "source-bound-cross-column-observer-family/1", "width": "m>=1",
             "coordinates": "nine m-bit planes; active word0, carry spectator word1, tag spectator words2..8",
             "source_routes": routes,
             "parameters": [[{"tag": parameters(a, i)[0], "odd_multiplier": parameters(a, i)[1]}
                             for i in range(112)] for a in range(18)],
             "alpha": alpha,
             "logical_block": "alpha_ai D_ai rho_ai (K_i*)^tensor m",
             "physical_block": "alpha_ai (Q^tensor m D_ai (Q*)^tensor m) rho_ai S_i^tensor m",
             "forward_word": forward, "inverse_word": inverse, "raw_inverse_transpose_word": dual,
             "observer_word_note": "One listed word per observer; replace each gather coefficient by alpha_ai and its M_i by M_ai. Scatter destination may be a genuine empty-chart Y birth or an owned observation field.",
             "claims_complete_R_recovery": False}
    (HERE / "CROSS-COLUMN-MACRO.json").write_text(json.dumps(macro, indent=2)+"\n")
    result = {"status": "PASS_SOURCE_BOUND_CROSS_COLUMN_ADMISSION_AND_ESCAPE_GATES",
              "source_normalizer_identities_with_literal_global_phase": 112,
              "parametric_source_observer_routes": 2016,
              "literal_conjugate_checks": literal,
              "unbounded_carry_degree_checks": degrees,
              "physical_diagonal_gate_checks": hard_subspaces,
              "old_active_basis_witness_unweighted_route_image_rank": 112,
              "old_constant_vector_witness_unweighted_route_image_rank": walsh_rank,
              "actual_alpha_weighted_image_ranks_for_these_witnesses": [56]*8+[112]*10,
              "constant_vector_witness_rank_scope": "m>=7; restrict active=0 and z=0..127",
              "owner_count": 632, "owned_workspace_fields": 1,
              "H1_queries_per_forward_inverse_or_raw_dual_observer": 1,
              "nonzero_owned_erasure_per_orientation": 1,
              "ordinary_work": "O(N) per observer in a bit-plane word layout; fixed odd multipliers need at most8 shift/add terms; phase counts use four precomputed chunk lookups",
              "complete_R_recovery": "Not established. The separate quotient screen tests complete demands on explicit source-bound input slices.",
              "warning": "Passing these old hard subspaces is not a rank cap for O|kerR and is not an all-width consumer."}
    (HERE / "CROSS-COLUMN-RESULT.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps({k: result[k] for k in ("status", "source_normalizer_identities_with_literal_global_phase",
                     "literal_conjugate_checks", "H1_queries_per_forward_inverse_or_raw_dual_observer",
                     "complete_R_recovery")}, indent=2))
    return result


if __name__ == "__main__":
    verify()
