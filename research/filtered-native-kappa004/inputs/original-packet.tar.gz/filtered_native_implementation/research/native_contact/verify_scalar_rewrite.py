#!/usr/bin/env python3
"""Read-only verification of the frozen143-ADD native source reduction.

Runtime dependencies: Python standard library and the three pinned files
listed below. Search logs, discovery optimizers and earlier rewrite stages
are not needed to verify the final word.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import argparse
import gzip
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PINS = {
    'upstream/research/general-gaussian-contact-search/inputs/round3-word.json.gz':
        '7679daa4ec6a40f56fc7f0202379a6f454310e94945aba4f48beaaaafb838d05',
    'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz':
        'de4b75c106f8a3ebe1ee68b53fe7e64bd218120526e726d9bdfd4dab711dd4b2',
    'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py':
        '178ff80824a012970fc9435f122152da03c7e6bdc3a7de12136fe03e05cf24fe',
}


def need(ok, message):
    if not ok:
        raise AssertionError(message)


def paths(program):
    out = [[] for _ in range(632)]
    for e in program:
        if e[0] == 'climb':
            out[e[2]].append(tuple(e[3:]))
        elif e[0] == 'warp':
            need(e[1][0] == 'L', 'Every retained warp is on an ordinary owner')
            out[e[1][1]].append(('warp', e[2], e[3], e[4]))
    return out


def scalar_census(program):
    return Counter(e[1][0] for e in program if e[0] == 'scalar')


def add_tariff(program):
    total = 0
    for e in program:
        if e[0] == 'scalar' and e[1][0] == 'add':
            q = F(e[1][3], e[1][4])
            need(q != 0 and q.denominator & (q.denominator-1) == 0, 'Nonzero dyadic ADD')
            total += (3+abs(q.numerator).bit_length()-1
                      +abs(q.numerator).bit_count()+q.denominator.bit_length()-1)
    return total


def run(root):
    for rel, digest in PINS.items():
        need(sha256((root/rel).read_bytes()).hexdigest() == digest, 'Authenticated '+rel)
    source, final, core_path = [root/p for p in PINS]
    source = json.loads(gzip.decompress(source.read_bytes()))
    final = json.loads(gzip.decompress(final.read_bytes()))
    need(source['canonical'] == final['canonical'], 'All canonical frame/warp/source data unchanged')
    spec = importlib.util.spec_from_file_location('scalar_rewrite_frozen_core', core_path)
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    results = {}
    for direction, back in [('forward', False), ('backward', True)]:
        old, new = source['programs'][direction], final['programs'][direction]
        old_rows, old_paid, old_norm = core.replay(source['canonical'], old, back)
        rows, paid, norm = core.replay(final['canonical'], new, back)
        need(rows == old_rows, 'All original arbitrary input rows agree')
        need(all(rows[i] == core.expected(i, back) for i in range(632)),
             'All632 independent owner endpoints')
        need(not rows[632], 'Owned C0 is cleared')
        need(old_paid == paid and paths(old) == paths(new), 'Every paid/query warp path unchanged')
        need([e for e in old if e[0] not in ('scalar','climb')]
             == [e for e in new if e[0] not in ('scalar','climb')],
             'Center calls, warps, adapters and phases literally unchanged')
        oc, nc = scalar_census(old), scalar_census(new)
        need(oc['add']-nc['add'] == 143, 'Exactly143 ADDs removed per orientation')
        need({k:v for k,v in oc.items() if k != 'add'} ==
             {k:v for k,v in nc.items() if k != 'add'}, 'Other scalar inventory unchanged')
        ot, nt = add_tariff(old), add_tariff(new)
        need(ot-nt == 500, 'Exactly500 scalar primitive allowances saved')
        need(old_norm == norm, 'Exact component-l1 prefix bound unchanged')
        results[direction] = {'old_events': len(old), 'new_events': len(new),
                              'old_ADDs': oc['add'], 'new_ADDs': nc['add'],
                              'old_ADD_primitive_allowance': ot,
                              'new_ADD_primitive_allowance': nt,
                              'prefix_l1': str(norm), 'all_originals': 632,
                              'owned_final_zero': True,
                              'paid_profile': {str(k):v for k,v in sorted(paid.items())}}
    c = final['canonical']
    helpers = Counter(len(c['frames'][c['final'][i]])-len(c['frames'][c['start'][i]])
                      for i in range(224,632))
    need(helpers == Counter({4:28,7:7,8:47,9:326}), 'All408 original helper jobs')
    return {'schema': 'frozen-scalar-source-rewrite/v1', 'status': 'PASS',
            'pins': PINS, 'directions': results,
            'helper_profile': {str(k):v for k,v in sorted(helpers.items())},
            'all_width_basis': 'Exact scalar identities over the retained noncommutative '
                               'warp algebra; all canonical frames and each ordered '
                               'query/warp path remain unchanged.',
            'scope': '143 fewer ADDs and500 fewer scalar primitive allowances per orientation. '
                     'No recursive-query saving or improved exponent claimed.'}


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, default=ROOT)
    p.add_argument('--write', action='store_true')
    args = p.parse_args()
    result = run(args.root)
    path = HERE/'SCALAR-REWRITE-VERIFIED.json'
    if args.write:
        path.write_text(json.dumps(result, sort_keys=True, indent=2)+'\n')
    else:
        need(result == json.loads(path.read_text()), 'Frozen verification receipt')
    print(json.dumps(result, sort_keys=True))
