#!/usr/bin/env python3
"""Exact reverse sensitivity of the phase-authenticated causal companion.

Each error site is independent and adversarial.  We combine identical
unitary free words within that site's actual endpoint transfer before
taking absolute values.  This sharpens the forward interval envelope,
without relying on cancellation between different error injections.
"""
from collections import Counter, defaultdict
from fractions import Fraction as Fr
from hashlib import sha256
from pathlib import Path
import gzip
import json
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def add(dst, src, scalar):
    assert dst is not src
    for key, value in src.items():
        value = dst.get(key, Fr(0)) + scalar * value
        if value:
            dst[key] = value
        else:
            dst.pop(key, None)


def power_bound(value):
    if not value:
        return None
    p = value.numerator.bit_length() - value.denominator.bit_length()
    if value > Fr(2) ** p:
        p += 1
    assert Fr(2) ** (p-1) < value <= Fr(2) ** p
    return p


def main():
    started = time.monotonic()
    path = ROOT/'research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz'
    raw = path.read_bytes()
    source = json.loads(gzip.decompress(raw))
    reviewpath = ROOT/'research/alternative_gadgets_next/CAUSAL-COMPANION-INDEPENDENT-REVIEW.json'
    review = json.loads(reviewpath.read_text())
    # The forward review authenticates the frame/unitary semantics used here.
    assert sha256(raw).hexdigest() in json.dumps(review)
    originals = 1264
    owned = [x+1 for x in source['owned_extra_slots_by_copy']]
    offsets = [originals, originals+owned[0]]
    shared = originals+sum(owned)
    n = shared+source['shared_cross_mode_fields']
    adj = [{(i, ()): Fr(1)} for i in range(originals)] + [{} for _ in range(n-originals)]
    ordinary = [Fr(0)]*originals
    paid = [Fr(0)]*originals
    paid_by_rank = defaultdict(lambda: [Fr(0)]*originals)
    sites = Counter()
    max_terms = 1
    witness_sites = []
    transfer_samples = {}

    def index(ref, copy):
        return 632*copy+ref[1] if ref[0] == 'L' else offsets[copy]+ref[1]

    def noise(kind, dst, rank=None, event_index=None):
        budget = ordinary if kind == 'ordinary' else paid
        per_output = defaultdict(Fr)
        for (out, word), coefficient in adj[dst].items():
            per_output[out] += abs(coefficient)
        for out, value in per_output.items():
            budget[out] += value
            if rank is not None:
                paid_by_rank[rank][out] += value
        sites[kind] += 1
        if per_output:
            peak=max(per_output.values())
            witness_sites.append([event_index,kind,rank,dst,str(peak)])
            event=source['program'][event_index]
            if event[0]=='native':
                native=event[2]
                label=f"native{event[1]}."+native[0]
                if native[0]=='scalar':
                    label+='.'+native[1][0]
            else:
                label=event[0]
            if label not in transfer_samples or Fr(transfer_samples[label]['maximum_output_l1'])<peak:
                transfer_samples[label]={
                    'event_index':event_index,'noise_field':dst,
                    'maximum_output_l1':str(peak),
                    'transfer':[[out,list(word),str(a)] for (out,word),a in sorted(adj[dst].items())]}

    for pos in range(len(source['program'])-1, -1, -1):
        event = source['program'][pos]
        typ = event[0]
        if typ == 'phase':
            continue
        if typ == 'native':
            _, copy, e = event
            typ = e[0]
            if typ == 'phase':
                continue
            if typ == 'scalar':
                a = e[1]
                op, d = a[0], index(a[1],copy)
                if op == 'clear':
                    assert d >= originals
                    adj[d] = {}
                    sites['exact_owned_clear'] += 1
                    continue
                noise('ordinary',d,event_index=pos)
                if op in ('copy','add'):
                    s = index(a[2],copy)
                    assert s != d
                    add(adj[s],adj[d],Fr(1) if op == 'copy' else Fr(a[3],a[4]))
                    if op == 'copy':
                        assert d >= originals
                        adj[d] = {}
                    max_terms=max(max_terms,len(adj[s]))
                else:
                    assert op == 'scale'
                    a = Fr(a[2],a[3])
                    adj[d] = {key:a*value for key,value in adj[d].items() if a*value}
            elif typ == 'warp':
                d = index(e[1],copy)
                noise('ordinary',d,event_index=pos)
                letter = (1 if e[2]>0 else -1)*(abs(e[2])+1000000*copy)
                # A forward warp acts on the left of a field; its pullback
                # acts on the right of the endpoint-transfer free word.
                row={}
                for (out,word),a in adj[d].items():
                    w = word[:-1] if word and word[-1] == -letter else word+(letter,)
                    row[out,w] = row.get((out,w),Fr(0))+a
                adj[d] = {key:a for key,a in row.items() if a}
            elif typ == 'climb':
                d=632*copy+e[2]
                noise('paid',d,rank=e[-1],event_index=pos)
            elif typ == 'adapter':
                d=632*copy+e[2]
                noise('ordinary',d,event_index=pos)
            else:
                raise AssertionError(typ)
        elif typ == 'cross_y_add':
            d,s=112+event[1],632+112+event[1]
            noise('ordinary',d,event_index=pos)
            add(adj[s],adj[d],Fr(1))
            max_terms=max(max_terms,len(adj[s]))
        elif typ == 'mode_clear':
            adj[shared+event[1]]={}
            sites['exact_owned_clear']+=1
        elif typ == 'mode_add_forward_X':
            d,s=shared+event[1],event[2]
            noise('ordinary',d,event_index=pos)
            add(adj[s],adj[d],Fr(event[3]))
            max_terms=max(max_terms,len(adj[s]))
        elif typ == 'cross_X_mode_add':
            d,s=632+event[1],shared+event[2]
            noise('ordinary',d,event_index=pos)
            add(adj[s],adj[d],Fr(event[3]))
            max_terms=max(max_terms,len(adj[s]))
        else:
            raise AssertionError(typ)
        if pos%5000==0:
            print('REVERSE',pos,'max_transfer_terms',max_terms,flush=True)

    # Independently construct the full transpose endpoint from its formula.
    R=json.loads((ROOT/'research/tensor_obstruction/inputs/R.json').read_text())
    B=[[sum(Fr(row[i])*Fr(row[j]) for row in R) for j in range(112)] for i in range(112)]
    A=[[Fr(i==j)-B[i][j]/4 for j in range(112)] for i in range(112)]
    expected=[{(i,()):Fr(1)} for i in range(originals)]
    for i in range(112):
        expected[632+112+i][112+i,()]=Fr(1)
        for j in range(112):
            if A[i][j]:
                expected[j][112+i,()]=A[i][j]
                expected[632+112+j][632+i,()]=-A[i][j]
            if B[i][j]:
                expected[j][632+i,()]=-3*B[i][j]
    assert adj[:originals]==expected
    assert all(not row for row in adj[originals:])
    initial=[Fr(0)]*originals
    for row in adj[:originals]:
        for (out,word),a in row.items():
            assert not word
            initial[out]+=abs(a)
    def describe(values):
        m=max(values)
        return {'exact_maximum':str(m),'power_of_two_upper_exponent':power_bound(m),
                'maximizing_output_fields':[i for i,x in enumerate(values) if x==m]}
    out={
        'schema':'causal-companion-exact-adjoint-precision/v1',
        'status':'PASS_EXACT_REVERSE_TRANSFER_AND_ALL1264_ENDPOINT_COLUMNS',
        'word_sha256':sha256(raw).hexdigest(),
        'independent_forward_review_sha256':sha256(reviewpath.read_bytes()).hexdigest(),
        'error_model':'Independent adversarial field errors of norm <=delta initially, <=epsilon_q at each paid child output, <=epsilon_o after each non-clear ordinary macro; Euclidean norm in authenticated unitary frame. Owned CLEAR exact.',
        'method':'Reverse exact rational unitary free-word transfer, combining identical words within each individual noise transfer before triangle bounds. No cancellation between distinct errors is assumed.',
        'all1264_input_transfer_columns_checked':True,
        'all_initial_owned_transfer_columns_zero':True,
        'original_input_error':describe(initial),
        'uniform_paid_child_error':describe(paid),
        'uniform_ordinary_macro_error':describe(ordinary),
        'paid_error_by_rank':{r:describe(v) for r,v in sorted(paid_by_rank.items())},
        'sites':dict(sites),'max_terms_in_one_transfer':max_terms,
        'per_original_output_coefficients':[[str(a),str(b),str(c)] for a,b,c in zip(initial,paid,ordinary)],
        'scope':'Sharper final-output certificate. Prefix/headroom bounds remain those of FILTERED-PRECISION-ENVELOPE.json. Ordinary macros must separately satisfy their local error contract. No outer theorem or kappa gain asserted.',
        'elapsed_seconds':round(time.monotonic()-started,3),
        'new_kappa_claimed':False}
    witness={'schema':'causal-companion-error-site-sensitivity/v1',
             'word_sha256':sha256(raw).hexdigest(),
             'columns':['event','kind','rank_or_null','field','maximum_single_output_transfer_l1'],
             'sites':witness_sites,
             'exact_transfer_samples':transfer_samples}
    witness_path=HERE/'FILTERED-PRECISION-ADJOINT-SITES.json.gz'
    witness_path.write_bytes(gzip.compress(json.dumps(witness,separators=(',',':')).encode(),mtime=0))
    out['site_witness_sha256']=sha256(witness_path.read_bytes()).hexdigest()
    (HERE/'FILTERED-PRECISION-ADJOINT.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='per_original_output_coefficients'},indent=2))


if __name__=='__main__':
    main()
