#!/usr/bin/env python3
"""Bind the self-kernel spectrum census to the actual source R5 row."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import argparse
import gzip
import json
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
RPATH=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--maximum',type=int,default=4)
    args=ap.parse_args()
    source=json.loads(gzip.decompress(SOURCE.read_bytes()))
    R=[[int(x) for x in row] for row in json.loads(RPATH.read_text())]
    ports=source['canonical']['ports']
    qs=[q for i,q in enumerate(ports) if R[5][i]]
    f=[1<<i for i in range(7)]+[127]
    expected=sorted(h^f[a]^f[b] for h in (128,256) for a in range(8) for b in range(a+1,8))
    assert len(qs)==56 and sorted(qs)==expected
    assert sum(x*x for x in R[5])==56
    subprocess.run(['g++','-O3','-std=c++17',str(HERE/'self_kernel_spectrum.cpp'),
                    '-o',str(HERE/'self_kernel_spectrum.bin')],check=True)
    p=subprocess.run([str(HERE/'self_kernel_spectrum.bin'),str(args.maximum)],
                     check=True,text=True,capture_output=True)
    results=[json.loads(line) for line in p.stdout.splitlines()]
    # Independent literal frequency-address census for widths one and two.
    chars=[[((q&y).bit_count()&1) for q in qs] for y in range(512)]
    for row in results[:2]:
        width=row['width']; actual=Counter()
        if width==1:
            for c in chars:
                k=sum(c);actual[(56-k,k)]+=1
        else:
            for a in chars:
                for b in chars:
                    h=Counter(x+y for x,y in zip(a,b))
                    actual[h[0]-h[2],h[1]]+=1
        assert actual==Counter({(re,im):n for re,im,n in row['spectrum']})
        row['independent_literal_address_check']=True
    receipt={
        'schema':'source-bound-compressed-self-kernel-spectrum/v1',
        'status':'PASS_EXACT_MULTIPLICITY_CENSUS',
        'source_pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                       for p in (SOURCE,RPATH,HERE/'self_kernel_spectrum.cpp')},
        'operator':'T_m=(1/56) sum_{q in source R5 support} C(-X_q)^(tensor m)',
        'C_convention':'C(P)=((1+i)I+(1-i)P)/2, exactly the source Clifford convention.',
        'eigenvalue_scale':'The actual eigenvalue is i^m*(re-i*im)/56; the tabulated numerator uses sum i^wt for convenient integer arithmetic.',
        'all_width_finite_spectrum_bound':
            'After removing the common phase, each eigenvalue is the average of56 fourth roots of unity. Thus its numerator is a Gaussian integer with |re|+|im|<=56; the number of possible eigenvalues is bounded independently of m.',
        'enumeration':'Eight vertex words in F2^m with XOR zero; multinomial counts enumerate all7m low-frequency bits. Two independent high words enumerate the remaining2m bits.',
        'results':results,
        'scope':'Exact widths through the requested maximum; finite-spectrum observation is all-width. This supplies no cheap inverse or new recursive target admission.'
    }
    path=HERE/'SELF-KERNEL-SPECTRUM.json'
    path.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'status':receipt['status'],'results':[{k:v for k,v in row.items() if k!='spectrum'} for row in results]},indent=2))


if __name__=='__main__':main()
