#!/usr/bin/env python3
"""Mixed forward/backward, query-free cross updates and an involutive edge.

The involution is in the common Q role chart.  Its cross-role entries are
not silently admitted as ordinary physical recodings.  This is a local
caller design component, not a completed supplier.
"""
from fractions import Fraction as Fr
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod


def main():
    gaugepath=ROOT/'upstream/research/coded-native-caller/gauge.py'
    gm=load('mixed_role_gauge',gaugepath)
    a=gm.Algebra(1)
    q=a.gen(1);qi=a.inv(q);d=a.D(0);c=a.gen(2)
    f=a.mul(q,d);f2=a.mul(f,f)
    scalar=lambda x:a.term((),(0,),Fr(x))
    p=a.mul(scalar(Fr(1,14)),a.add(a.one,a.neg(c)))
    # Source order is (X_forward, Y_backward), target order is
    # (Y_forward, X_backward). H multiplies each physical Y by Q.
    physical=[[a.mul(d,c,qi),a.mul(scalar(12),d,p,f2)],
              [a.neg(a.mul(scalar(14),f2,p,d)),a.neg(a.mul(f,c))]]
    source_H_inverse=a.diag(a.one,qi)
    target_H=a.diag(q,a.one)
    normalized=a.mm(target_H,physical,source_H_inverse)
    abstract_edge=[[c,a.mul(scalar(12),f2,p)],
                   [a.neg(a.mul(scalar(14),f2,p)),a.neg(c)]]
    assert normalized==a.mm(abstract_edge,a.diag(d,d))
    # An ordinary edge in the abstract H chart is not automatically an
    # ordinary recoding after crossing back to the physical source chart.
    source_H=a.diag(a.one,q)
    physical_source_edge=a.mm(source_H_inverse,abstract_edge,source_H)
    assert physical_source_edge!=abstract_edge

    # Separate exact algebra for P^2=P, F^4=I and [P,F]=0.
    def poly(pbit=0,fe=0,value=1): return {(pbit,fe%4):Fr(value)} if value else {}
    def add(*xs):
        out={}
        for x in xs:
            for key,value in x.items():out[key]=out.get(key,Fr(0))+value
        return {k:v for k,v in out.items() if v}
    def mul(x,y):
        out={}
        for (px,fx),vx in x.items():
            for (py,fy),vy in y.items():
                key=(max(px,py),(fx+fy)%4)
                out[key]=out.get(key,Fr(0))+vx*vy
        return {k:v for k,v in out.items() if v}
    one=poly();zero={};cc=add(one,poly(1,0,-14))
    edge=[[cc,poly(1,2,12)],[poly(1,2,-14),{k:-v for k,v in cc.items()}]]
    squared=[[add(*(mul(edge[i][k],edge[k][j]) for k in range(2)))
              for j in range(2)] for i in range(2)]
    assert squared==[[one,zero],[zero,one]]

    rpath=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    r=[[Fr(x) for x in row] for row in json.loads(rpath.read_text())]
    rr=[[sum(x*y for x,y in zip(ri,rj)) for rj in r] for ri in r]
    assert rr==[[56*int(i==j) for j in range(8)] for i in range(8)]
    out={
      'schema':'mixed-role-query-free-involutive-edge/v1',
      'status':'PASS_EXACT_LOCAL_IDENTITIES; CALLER_PENDING',
      'source_pins':{str(x.relative_to(ROOT)):sha256(x.read_bytes()).hexdigest()
                     for x in (rpath,gaugepath)},
      'premise':'One helper-clean center-free forward producer and one helper-clean center-free raw-dual producer, with independent originals in both copies.',
      'logical_projector':'P=R^T R/56, or a selected subset of actual R modes; A=I-14P.',
      'physical_ordinary_updates':{
        'before_forward_Y_is_read':'raw Y_forward +=12 P F9^2 raw Y_backward; retain arbitrary original Y_forward additively.',
        'after_both_native_words':'raw X_backward -=14 P raw X_forward_final; forward final X is F9 times its logical X.',
        'query_count_added':0,
        'original_helpers':'All helpers retain the independent endpoint jobs of the two center-free source words.',
        'ordering':'The source-first forward schedule can delay its Y consumers. The backward X cross-update occurs only after forward final X is available.'},
      'normalized_definitions':'P_s=diag(K_i^-1)P diag(K_i); A_s=I-14P_s; F_s=Q D_s.',
      'role_gauge':'H multiplies each Y bank by Q. Source order(X_forward,Y_backward), target order(Y_forward,X_backward).',
      'H_chart_edge':'M_s=[[A_s,12F_s^2 P_s],[-14F_s^2 P_s,-A_s]]',
      'H_chart_coupling':'targets receive M_s diag(D_s,D_s) times sources; every diagonal main job is still D_s.',
      'involution_identity':'M_s^2=I because A_s^2=I+168P_s, (F_s^2)^2=I and [P_s,F_s]=0.',
      'exact_semidirect_transport_check':True,
      'exact_projector_ring_involution_check':True,
      'source_R_orthogonality_check':True,
      'physical_gauge_control_rejected':True,
      'unresolved':'M_s mixes an X source with a Y source. Conjugating it out of H introduces odd Q factors, so this involution cannot be inserted as a free physical owner code. An actual caller network must use the displayed ordinary cross-updates and retain their chronology.',
      'new_kappa':False}
    (HERE/'MIXED-ROLE-INVOLUTION.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
