// Exact spectra of the source-R5 compressed self kernel.
// Enumerate vertex multiplicities, not all 512^(width) frequency addresses.
// New research by OpenAI; no supplier or exponent claim.
#include <array>
#include <cstdint>
#include <iostream>
#include <map>
#include <utility>
#include <vector>

using U64 = std::uint64_t;
using Pair = std::pair<int,int>;

struct Run {
    int m, n;
    std::vector<int> count, edge, re, im;
    std::map<Pair,U64> spectrum;
    U64 histograms=0, ordered_vertices=0;
    std::array<U64,9> factorial{1,1,2,6,24,120,720,5040,40320};
    Run(int width):m(width),n(1<<m),count(n),edge(n),re(n),im(n){}

    void consume() {
        // Divide by the complete denominator; successive divisions need
        // not be integral in an arbitrary order.
        U64 denominator=1;
        for(int c:count) denominator*=factorial[c];
        U64 multiplicity=factorial[8]/denominator;
        histograms++; ordered_vertices+=multiplicity;
        std::fill(edge.begin(),edge.end(),0);
        for(int a=0;a<n;a++) if(count[a]) {
            edge[0]+=count[a]*(count[a]-1)/2;
            for(int b=a+1;b<n;b++) edge[a^b]+=count[a]*count[b];
        }
        for(int h=0;h<n;h++) {
            re[h]=im[h]=0;
            for(int d=0;d<n;d++) if(edge[d]) {
                switch(__builtin_popcount(unsigned(h^d))&3) {
                    case 0:re[h]+=edge[d];break;
                    case 1:im[h]+=edge[d];break;
                    case 2:re[h]-=edge[d];break;
                    case 3:im[h]-=edge[d];break;
                }
            }
        }
        for(int a=0;a<n;a++) for(int b=0;b<n;b++)
            spectrum[{re[a]+re[b],im[a]+im[b]}]+=multiplicity;
    }

    void visit(int position,int remaining,int parity) {
        if(position==n-1) {
            count[position]=remaining;
            if((parity^((remaining&1)?position:0))==0) consume();
            return;
        }
        for(int c=0;c<=remaining;c++) {
            count[position]=c;
            visit(position+1,remaining-c,parity^((c&1)?position:0));
        }
    }

    void execute() {
        visit(0,8,0);
        U64 total=0,zero=0;
        for(auto [value,c]:spectrum) {total+=c;if(value==Pair{0,0})zero=c;}
        if(ordered_vertices!=(U64(1)<<(7*m)) || total!=(U64(1)<<(9*m)))
            throw std::runtime_error("Multiplicity coverage failure");
        std::cout<<"{\"width\":"<<m<<",\"vertex_histograms\":"<<histograms
                 <<",\"addresses\":"<<total<<",\"zero_eigenvalues\":"<<zero
                 <<",\"distinct_unscaled_eigenvalues\":"<<spectrum.size()
                 <<",\"spectrum\":[";
        bool first=true;
        for(auto [value,c]:spectrum) {
            if(!first)std::cout<<",";first=false;
            std::cout<<"["<<value.first<<","<<value.second<<","<<c<<"]";
        }
        std::cout<<"]}"<<std::endl;
    }
};

int main(int argc,char**argv) {
    int maximum=argc>1?std::stoi(argv[1]):4;
    if(maximum<1 || maximum>5) return 2;
    for(int m=1;m<=maximum;m++) Run(m).execute();
}
