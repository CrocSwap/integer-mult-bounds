#!/usr/bin/env python3
"""Source-bound census of center captures with an untouched later frame move.

This identifies legal physical query-retiming windows; the new center
response is deliberately not identified with the old target endpoint.
"""
from pathlib import Path
from hashlib import sha256
import gzip
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SOURCE=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'


def references(event):
    if event[0]=='scalar':
        return [tuple(a) for a in event[1][1:]
                if isinstance(a,list) and len(a)==2 and a[0] in ('L','C')]
    if event[0]=='warp': return [tuple(event[1])]
    if event[0]=='climb': return [('L',event[2])]
    return []


def run():
    raw=SOURCE.read_bytes()
    source=json.loads(gzip.decompress(raw))
    events=source['programs']['forward']
    results=[]
    for mode,index in enumerate(i for i,e in enumerate(events) if e[0]=='center'):
        center=events[index]
        copy=events[index-1]
        assert copy[0]=='scalar' and copy[1][0]=='copy' and copy[1][1]==['C',0]
        src=tuple(copy[1][2])
        later=[(i,e) for i,e in enumerate(events[index+1:],index+1) if src in references(e)]
        first_i,first=later[0]
        eligible=(first[0]=='climb' and first[3]==center[2] and first[4]==1)
        paired=None
        if mode==7:
            # The sole intervening ADD has an untouched source with the
            # identical later frame move. Move both paid climbs to the copy
            # and perform that ADD in the full frame.
            assert first_i==17143 and first==['scalar',['add',['L',256],['L',288],-1,1],281]
            assert events[17144]==['climb','scalar_refactor',256,281,1,1]
            assert events[17482]==['climb','scalar_refactor',288,281,1,1]
            assert [(i,e) for i,e in enumerate(events[index+1:17482],index+1)
                    if ('L',288) in references(e)]==[(17143,first)]
            paired={'climbs_moved_before_copy':[17144,17482],
                    'owners':[256,288],
                    'retained_ADD_event':17143,'new_ADD_frame':1,
                    'additional_queries':0,
                    'identity':'B(x-y)=Bx-By for B=F9 S281^-1; both original owner values retained.'}
        results.append({'mode':mode,'center_event':index,'center':center,
                        'capture_owner':src[1], 'copy_frame':copy[2],
                        'first_next_contact_event':first_i,'first_next_contact':first,
                        'untouched_forward_full_frame_climb':eligible,
                        'two_owner_retiming':paired,
                        'intervening_events':first_i-index-1,
                        'removed_center_rank_if_retained_full_residual':center[4] if eligible else None,
                        'new_response_if_eligible':'F9 times original dirty capture; unchanged target not asserted' if eligible else None})
    result={'schema':'native-center-query-retiming-census/v1',
            'source_sha256':sha256(raw).hexdigest(),
            'source_payload_sha256':sha256(gzip.decompress(raw)).hexdigest(),
            'forward_centers':results,
            'eligible_modes':[x['mode'] for x in results if x['untouched_forward_full_frame_climb']],
            'eligible_with_two_owner_extension':list(range(8)),
            'scope':'Exact no-contact chronology only. Each retiming changes the center response from its dirty ground logical value to its full-F9 transform. Physical output recovery, helpers, raw dual and recursive admission must be proved separately.',
            'kappa_increase':False}
    (HERE/'CENTER-RETIME-CENSUS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':run()
