#!/usr/bin/env python3
"""Conservative, exact error envelopes for the new literal native programs.

The normalized field norm is Euclidean; every authenticated physical frame,
warp and monomial is unitary.  Each paid child may inject an error of norm
epsilon_q, and each nontrivial ordinary macro may inject epsilon_o.  We
propagate absolute coefficients, including the new retained copies and
cross-copy consumers.  CLEAR is exact and only addresses owned storage.

This is a local perturbation certificate.  It is deliberately not a full
outer precision theorem or a change to the recursive target invoice.
"""
from fractions import Fraction as Fr
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def pow2_ceiling(x):
    if not x:
        return None
    n, d = x.numerator, x.denominator
    b = n.bit_length() - d.bit_length()
    if b >= 0:
        if n > d << b:
            b += 1
    elif n << (-b) > d:
        b += 1
    assert x <= (Fr(2) ** b)
    assert x > (Fr(2) ** (b - 1))
    return b


def short(x):
    if x.numerator.bit_length() < 200 and x.denominator.bit_length() < 200:
        return str(x)
    data = f'{x.numerator:x}/{x.denominator:x}'.encode()
    return {'exact_hex_ratio_sha256': sha256(data).hexdigest(),
            'numerator_bits': x.numerator.bit_length(),
            'denominator_bits': x.denominator.bit_length()}


class Bound:
    def __init__(self, originals, owned):
        self.n = originals
        self.rows = [[Fr(1), Fr(0), Fr(0)] for _ in range(originals)]
        self.rows += [[Fr(0), Fr(0), Fr(0)] for _ in range(owned)]
        self.paid = Counter()
        self.counts = Counter()
        self.maximum = [Fr(1), Fr(0), Fr(0)]

    def observe(self, d):
        self.maximum = [max(a, b) for a, b in zip(self.maximum, self.rows[d])]

    def clear(self, d):
        assert d >= self.n, 'An original input is never erased.'
        self.rows[d] = [Fr(0), Fr(0), Fr(0)]
        self.counts['exact_owned_clear'] += 1

    def add(self, d, s, a):
        assert d != s
        self.rows[d] = [x + abs(a)*y for x, y in zip(self.rows[d], self.rows[s])]
        self.rows[d][2] += 1
        self.counts['ordinary_injection_sites'] += 1
        self.observe(d)

    def native(self, e, original_offset=0, owned_offset=None):
        if owned_offset is None:
            owned_offset = self.n

        def index(ref):
            return original_offset + ref[1] if ref[0] == 'L' else owned_offset + ref[1]

        typ = e[0]
        if typ == 'phase':
            return
        if typ == 'scalar':
            a = e[1]
            op, d = a[0], index(a[1])
            if op == 'clear':
                self.clear(d)
                return
            if op == 'add':
                self.add(d, index(a[2]), Fr(a[3], a[4]))
                return
            if op == 'copy':
                assert d >= self.n
                self.rows[d] = list(self.rows[index(a[2])])
            elif op == 'scale':
                self.rows[d] = [abs(Fr(a[2], a[3]))*x for x in self.rows[d]]
            else:
                raise AssertionError(op)
        elif typ == 'physical_add':
            self.add(index(e[1]), index(e[2]), Fr(e[3], e[4]))
            return
        elif typ in ('climb', 'center'):
            d = original_offset + e[2] if typ == 'climb' else owned_offset + e[1]
            self.paid[e[-1]] += 1
            self.rows[d][1] += 1
            self.observe(d)
            return
        elif typ == 'warp':
            d = index(e[1])
        elif typ == 'adapter':
            d = original_offset + e[2]
        else:
            raise AssertionError(typ)
        self.rows[d][2] += 1
        self.counts['ordinary_injection_sites'] += 1
        self.observe(d)

    def receipt(self):
        final = [max(row[k] for row in self.rows[:self.n]) for k in range(3)]
        assert all(not any(row) for row in self.rows[self.n:])
        keys = ['original_input_perturbation', 'paid_child_uniform_error',
                'ordinary_macro_uniform_error']
        return {
            'original_fields': self.n,
            'owned_fields': len(self.rows)-self.n,
            'all_owned_error_fields_final_zero': True,
            'paid_profile': dict(sorted(self.paid.items())),
            **self.counts,
            'final_original_bounds': {key: {'exact': short(v), 'power_of_two_upper_exponent': pow2_ceiling(v)}
                                      for key, v in zip(keys, final)},
            'all_prefix_bounds': {key: {'exact': short(v), 'power_of_two_upper_exponent': pow2_ceiling(v)}
                                 for key, v in zip(keys, self.maximum)},
        }


def evaluate(path):
    raw = path.read_bytes()
    blob = json.loads(gzip.decompress(raw))
    results = {}
    if blob['schema'].startswith('actual-causal-companion') or 'owned_extra_slots_by_copy' in blob:
        own = [v+1 for v in blob['owned_extra_slots_by_copy']]
        b = Bound(1264, sum(own)+blob['shared_cross_mode_fields'])
        offsets = [1264, 1264+own[0]]
        shared = 1264+sum(own)
        for e in blob['program']:
            if e[0] == 'native':
                b.native(e[2], original_offset=632*e[1], owned_offset=offsets[e[1]])
            elif e[0] == 'phase':
                pass
            elif e[0] == 'cross_y_add':
                b.add(112+e[1], 632+112+e[1], Fr(1))
            elif e[0] == 'mode_clear':
                b.clear(shared+e[1])
            elif e[0] == 'mode_add_forward_X':
                b.add(shared+e[1], e[2], Fr(e[3]))
            elif e[0] == 'cross_X_mode_add':
                b.add(632+e[1], shared+e[2], Fr(e[3]))
            else:
                raise AssertionError(e[0])
        results['paired_program'] = b.receipt()
    else:
        programs = blob.get('programs', {'backward': blob.get('program')})
        for direction, program in programs.items():
            n = 632*blob.get('copies', 1)
            if 'owned_arrays_per_copy' in blob:
                owned = blob['copies']*blob['owned_arrays_per_copy'][direction]
            elif 'owned_extra_slots_by_direction' in blob:
                owned = blob['owned_extra_slots_by_direction'][direction]+1
            else:
                owned = blob['owned_extra_slots']+1
            b = Bound(n, owned)
            for e in program:
                b.native(e)
            results[direction] = b.receipt()
    return {'word': str(path.relative_to(ROOT)), 'sha256': sha256(raw).hexdigest(),
            'directions': results}


def main():
    paths = [
        ROOT/'research/retained_state_next/F9-SOURCE-DAG-ALL8-COMPRESSED-WORD.json.gz',
        ROOT/'research/retained_state_next/RAW-DUAL-LATE-X-WORD.json.gz',
        ROOT/'research/operator_alignment_next/TWO-COPY-CLEAN-DAG-WORDS.json.gz',
        ROOT/'research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz',
    ]
    out = {
        'schema': 'filtered-native-local-precision-envelope/v1',
        'norm': 'Maximum over fields of the Euclidean norm in the authenticated unitary physical frame.',
        'local_error_model': 'At each paid child output, inject any error of norm <=epsilon_q. At each non-clear ordinary event, inject any error of norm <=epsilon_o. Exact owned CLEAR resets that field. Initial original-field error is <=delta.',
        'inequality': 'For each listed endpoint, error <=A*delta+B*epsilon_q+C*epsilon_o, using the three final bounds; the prefix bounds hold at every intermediate state.',
        'method': 'Exact nonnegative rational path propagation. It does not rely on cancellation of errors, signs, a transpose program, or statistical independence.',
        'ordinary_macro_caveat': 'A macro implementation with multiple rounded arithmetic steps must first meet its stated epsilon_o contract. The receipt does not substitute one epsilon_o for an unbounded sequence of primitive errors.',
        'records': [evaluate(p) for p in paths],
        'scope': 'Local perturbation and storage-erasure bounds for authenticated source programs. The complete caller, child headroom, outer precision, and recursive target invoice remain separate.',
        'new_kappa_claimed': False,
    }
    (HERE/'FILTERED-PRECISION-ENVELOPE.json').write_text(json.dumps(out, indent=2)+'\n')
    print(json.dumps({'status': 'PASS_EXACT_LOCAL_ERROR_PROPAGATION',
                      'records': [{ 'word':r['word'], 'directions':{
                          d:{k:v['power_of_two_upper_exponent'] for k,v in x['final_original_bounds'].items()}
                          for d,x in r['directions'].items()}} for r in out['records']]}, indent=2))


if __name__ == '__main__':
    main()
