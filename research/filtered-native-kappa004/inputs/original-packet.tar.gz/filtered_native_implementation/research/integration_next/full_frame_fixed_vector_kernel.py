#!/usr/bin/env python3
"""Phase-correct invisible inputs for the native full-frame snapshot family.

This certificate does not use the withdrawn permutation/coset calculation.
Every actual logical K_G fixes computational |0> exactly. We execute the
literal scalar/frame timeline on all112 independent equal X/Y amplitudes.
If every full-frame snapshot vanishes, no postprocessing of only those
snapshots can recover a nonzero pure X or Y mode, with or without paid queries.
"""
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]

def load_ce():
    p=ROOT/'research/tensor_obstruction/inputs/clifford_exact.py'
    s=importlib.util.spec_from_file_location('fixed_vector_ce',p)
    m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
    return m,p

def add(d,s,c):
    for k,v in list(s.items()):
        z=d.get(k,F(0))+c*v
        if z:d[k]=z
        else:d.pop(k,None)

def main():
    start=time.monotonic();ce,cp=load_ce()
    sourcepath=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    source=json.loads(gzip.decompress(sourcepath.read_bytes()));c=source['canonical']
    rp=ROOT/'research/tensor_obstruction/inputs/R.json';R=json.loads(rp.read_text())
    unit=ce.ident(9).zero_state();warps=[]
    # Explicit source formula, including diagonal Z4 phases and conjugation.
    for w in c['warps']:
        G=ce.transpose(tuple(w['G_columns']),9);gi=ce.inv(G,9);cols=ce.transpose(gi,9)
        Q=tuple((1<<i)^sum(ce.parity(a&b)<<j for j,b in enumerate(cols)) for i,a in enumerate(cols))
        alph=tuple((Q[i]>>i)&1 for i in range(9))
        forward=ce.perm(9,G).then(ce.diag(9,Q,alph))
        backward=ce.perm(9,G).then(ce.diag(9,Q,tuple(-x%4 for x in alph)))
        for op in (forward,forward.adjoint(),backward,backward.adjoint()):
            assert op.zero_state()==unit
        # Same full-frame physical transport is ordinary, contrary to the
        # superseded plain-P_G coset interpretation. Its absolute phase is checked.
        ff=ce.fourier(9)
        transport=ff.adjoint().then(forward).then(ff)
        rank=ce.rank([x for x,z,p in transport.tab[9:]])
        assert rank==0
        mon,recipe=ce.monomial(transport)
        assert mon.tab==transport.tab and mon.zero_state()==transport.zero_state()
        warps.append({'op':w['op'],'G_columns':w['G_columns'],
                      'quadratic_rows':list(Q),'forward_Z4':list(alph),
                      'all_four_signed_conjugate_variants_fix_zero':True,
                      'full_frame_physical_transport_rank':rank,
                      'full_frame_monomial_recipe':recipe})
    assert [i for i,b in enumerate(c['frames']) if len(b)==9]==[1]
    reports=[]
    def idx(ref):return ref[1]+(632 if ref[0]=='C' else 0)
    for direction in ('forward','backward'):
        # All112 amplitudes independent. Backward uses X_i=Y_i=a_i|0>;
        # forward uses X_i=0,Y_i=a_i|0>. All helpers are zero in this witness.
        rows=[{} for _ in range(633)]
        for i in range(112):
            rows[112+i]={i:F(1)}
            if direction=='backward':rows[i]={i:F(1)}
        frames=c['start'][:]+[None];observations=[];counts=Counter()
        def observe(d,event):
            if frames[d]==1:
                assert not rows[d],(direction,event,d,rows[d])
                observations.append([event,d])
        for d in range(632):observe(d,-1)
        for pos,e in enumerate(source['programs'][direction]):
            typ=e[0];counts[typ]+=1;d=None
            if typ=='scalar':
                op,frame=e[1:];kind=op[0];d=idx(op[1])
                if kind=='clear':
                    assert d>=632;rows[d]={};frames[d]=frame
                else:
                    assert frames[d]==frame
                    if kind in ('copy','add'):
                        s=idx(op[2]);assert frames[s]==frame
                        if kind=='copy':assert d>=632;rows[d]=dict(rows[s])
                        else:add(rows[d],rows[s],F(op[3],op[4]))
                    else:
                        assert kind=='scale';q=F(op[2],op[3])
                        rows[d]={k:v*q for k,v in rows[d].items() if v*q}
            elif typ=='warp':
                d=idx(e[1]);assert frames[d]==e[3];frames[d]=e[4]
                # The exact K_G fixed-vector checks above justify no change
                # to any amplitude here, including inverse/conjugate variants.
                assert any(abs(e[2])%1000000==w['op'] for w in c['warps'])
            elif typ=='climb':
                d=e[2];assert frames[d]==e[3];frames[d]=e[4]
            elif typ=='center':
                d=632+e[1];assert frames[d]==e[2];frames[d]=e[3]
            else:assert typ in ('phase','adapter','residual_adapter')
            if d is not None:observe(d,pos)
        assert frames[:632]==c['final']
        assert all(not x for x in rows[:112])
        assert all(rows[112+i]=={i:F(1)} for i in range(112))
        assert all(not x for x in rows[224:])
        mode_witnesses=[]
        for k,r in enumerate(R):
            j=next(i for i,v in enumerate(r) if v)
            inputs=[[112+j,'1']]
            if direction=='backward':inputs.insert(0,[j,'1'])
            mode_witnesses.append({'mode':k,'nonzero_original_amplitudes':inputs,
                                  'Y_target_amplitude':str(r[j]),
                                  'X_target_amplitude':str(r[j]) if direction=='backward' else '0'})
        reports.append({'direction':direction,'all112_amplitudes_independent':True,
          'full_frame_snapshot_count':len(observations),
          'every_snapshot_identically_zero':True,
          'zero_snapshot_locations':observations,
          'mode_witnesses':mode_witnesses,'opcode_census':dict(counts)})
    out={'schema':'phase-correct-native-full-frame-invisible-inputs/v1',
      'status':'PASS_ACTUAL_KG_FIXED_VECTOR_AND_ALL_FULL_FRAME_SNAPSHOTS',
      'source_pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                     for p in (sourcepath,rp,cp)},
      'all_width_fixed_vector':'Each actual forward/backward signed K_G fixes |0> exactly, hence fixes |0>^(tensor m) for every positive m. Scalar field coefficients act once, not tensor-powered.',
      'backward_invisible_family':'For arbitrary112 scalar amplitudes a_i, set logical X_i=Y_i=a_i|0>^(tensor m), all408 helper amplitudes0. Every retained full-frame snapshot is0 throughout the unchanged native backward word, while each nonzero pure X/Y R mode can be nonzero.',
      'forward_invisible_family':'Set X=H=0 and arbitrary Y_i=a_i|0>^(tensor m). Every forward full-frame snapshot is0; pureY modes can be nonzero.',
      'physical_input_legality':'At each original input choose its actual initial frame (conjugated in backward) applied to the stated logical vector. Original arrays are arbitrary; this is one legal counterexample family, not an assumption that all inputs are zero.',
      'conclusion':'Any fixed postprocessing using only these full-frame snapshots receives identical data on this family and the all-zero original input. It cannot output a pure demanded R-mode which differs. This includes arbitrary ordinary left recodings and additional paid linear transforms applied only to combinations of those snapshots.',
      'not_excluded':['Other physical-frame snapshots or retained original inputs supplied to the decoder.',
                      'Changed native gates or new queries on other available data.',
                      'Feedback inserted during the native/caller execution.',
                      'Different callers or productive target families.'],
      'corrected_warp_records':warps,'directions':reports,
      'superseded_claim':'The old plain-P_G physical coset/rank classification remains withdrawn; this is a different physical kernel proof.',
      'new_kappa_claimed':False,'elapsed_seconds':round(time.monotonic()-start,3)}
    dest=HERE/'FULL-FRAME-FIXED-VECTOR-KERNEL.json'
    dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ('corrected_warp_records','directions')},indent=2))
    print('snapshots',[(r['direction'],r['full_frame_snapshot_count']) for r in reports])

if __name__=='__main__':main()
