#!/usr/bin/env python3
"""Build a source-pinned, independently replayable research implementation.

This script packages existing verified work. It never edits the frozen source.
Apache-2.0; substantial OpenAI assistance. No new kappa is claimed.
"""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import argparse
import gzip
import html
import json
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUT = ROOT / 'deliverables'
STAGE = OUT / 'filtered_native_implementation'

FOLDERS = [
    'research/retained_state_next',
    'research/operator_alignment_next',
    'research/alternative_gadgets_next',
    'research/integration_next',
    'research/tensor_obstruction/inputs',
    'research/constructive_observers/inputs',
    'upstream/research/involutory-producer-raw-dual/inputs',
    'upstream/research/coded-native-caller',
]
EXTRA = [
    'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz',
    'research/native_contact/SCALED-GLOBAL-CANCEL-RESULT.json',
    'research/native_contact/verify_scalar_rewrite.py',
    'research/constructive_observers/cross_column_routes.py',
    'research/constructive_observers/check_majorana_admission.py',
    'research/constructive_observers/SOURCES.json',
    'research/coded_terminal_p3/PAID-ALTERNATIVE-RESULT.json',
    'upstream/research/kappa-rebuild/bit/COMPLEX-CONTROLLER-FACTOR.json',
    'upstream/research/complex-cover-lift-audit/native_warps.py',
    'upstream/certificates/selected-result.json',
    'upstream/research/joint-helper-lattice/CONTROLLER.json',
    'upstream/research/query-thinned-controllers/controller.py',
    'upstream/research/query-thinned-controllers/RESULT.json',
    'upstream/docs/research/pr-intake-evidence/pr4470/PROOF-REVIEW.md',
    'upstream/research/higher-moment-strictification/verify.py',
    'upstream/research/pr4359-p7-padding/dependencies/compiler-refill/endpoint.py',
    'upstream/LICENSE',
    'upstream/NOTICE',
]
RECEIPTS = {
    'filtered_source': 'research/retained_state_next/F9-SOURCE-DAG-ALL8.json',
    'compressed_source': 'research/retained_state_next/F9-SOURCE-DAG-ALL8-COMPRESSED.json',
    'source_independent_review': 'research/operator_alignment_next/CLEAN-DAG-INDEPENDENT-REVIEW.json',
    'inverse_codes': 'research/alternative_gadgets_next/PARTIAL-CENTER-INVERSE-CODES.json',
    'companion': 'research/retained_state_next/CAUSAL-COMPANION-INVOLUTION.json',
    'companion_independent_review': 'research/alternative_gadgets_next/CAUSAL-COMPANION-INDEPENDENT-REVIEW.json',
    'ordinary_inverse': 'research/operator_alignment_next/EVEN-HEAD-RESOLVENT.json',
    'ordinary_inverse_independent_review': 'research/integration_next/EVEN-RESOLVENT-INDEPENDENT-REVIEW.json',
    'precision': 'research/integration_next/FILTERED-PRECISION-ADJOINT.json',
    'precision_injection_review': 'research/alternative_gadgets_next/PRECISION-ADJOINT-INDEPENDENT-REVIEW.json',
    'precision_prefix': 'research/integration_next/FILTERED-PRECISION-ENVELOPE.json',
    'arbitrary_owner_tangent': 'research/operator_alignment_next/ARBITRARY-OWNER-TANGENT.json',
    'actual_tangent': 'research/operator_alignment_next/ACTUAL-TANGENT-REACHABILITY.json',
    'even_algebra': 'research/operator_alignment_next/FILTERED-FULL-COMPLETE-EVEN-ALGEBRA.json',
    'consumer_snapshot_closure': 'research/retained_state_next/CONSUMER-FULL-FRAME-CACHE.json',
    'rank2_refresh': 'research/retained_state_next/CONSUMER-PAID-REFRESH-BACKWARD-2.json',
    'rank4_refresh': 'research/retained_state_next/CONSUMER-PAID-REFRESH-BACKWARD-4.json',
    'owned_zero': 'research/integration_next/OWNED-ZERO-ONE-SIDED.json',
    'owned_zero_review': 'research/alternative_gadgets_next/OWNED-ZERO-CLOSURE-INDEPENDENT-REVIEW.json',
    'intermediate_targets': 'research/alternative_gadgets_next/INTERMEDIATE-TARGET-PORTFOLIO.json',
    'native_memoization_free': 'research/retained_state_next/NATIVE-PAID-MEMOIZATION-FREE.json',
    'native_memoization_actual': 'research/retained_state_next/NATIVE-PAID-MEMOIZATION-ACTUAL.json',
    'native_unary_fusion': 'research/retained_state_next/NATIVE-UNARY-FUSION.json',
    'scalar_shear_bridge': 'research/alternative_gadgets_next/TWO-STAGE-SCALAR-SHEAR.json',
    'phase_corrections': 'research/retained_state_next/CORRECTIONS.json',
    'full_frame_kernel': 'research/integration_next/FULL-FRAME-FIXED-VECTOR-KERNEL.json',
    'finite_control_summary': 'research/operator_alignment_next/FINITE-CONTROL-SUMMARY.json',
    'balanced_actual_sector': 'research/operator_alignment_next/BALANCED-ACTUAL-SECTOR.json',
    'finite_two_gate': 'research/operator_alignment_next/FINITE-TWO-GATE-CORRECTION.json',
    'finite_three_gate': 'research/operator_alignment_next/FINITE-THREE-GATE-FEEDBACK.json',
    'subset_Y_portfolio': 'research/alternative_gadgets_next/SUBSET-Y-PORTFOLIO.json',
    'subset_Y_basis': 'research/alternative_gadgets_next/SUBSET-Y-EXACT-BASIS.json',
    'subset_Y_class60': 'research/alternative_gadgets_next/SUBSET-Y-CLASS60-SUBSETS.json',
    'portfolio_flow_review': 'research/integration_next/PORTFOLIO-FLOW-INDEPENDENT-REVIEW.json',
    'full_frame_kernel_review': 'research/retained_state_next/KG-FULL-FRAME-KERNEL-INDEPENDENT-REVIEW.json',
    'corrected_snapshot_module': 'research/retained_state_next/CONSUMER-KG-MODULE-BACKWARD.json',
    'center_free_snapshot_module': 'research/retained_state_next/CENTER-FREE-SNAPSHOT-MODULE.json',
    'original_rank1_completion': 'research/operator_alignment_next/RANK1-SNAPSHOT-COMPLETION.json',
    'center_dependency_review': 'research/integration_next/RANK1-CENTER-DEPENDENCY-INDEPENDENT-REVIEW.json',
    'center_free_rank1_screen': 'research/operator_alignment_next/CENTER-FREE-RANK1-AUGMENTATION.json',
    'one_mode_rank1_screen': 'research/operator_alignment_next/MODE5-FREE-RANK1-AUGMENTATION.json',
    'local_head_alignment': 'research/retained_state_next/LOCAL-RANK1-HEAD-ALIGNMENT.json',
    'cross_stage_local_observation_witness': 'research/operator_alignment_next/CROSS-STAGE-COMPLETION-WITNESS.json',
    'foreign_mode_observer': 'research/operator_alignment_next/CROSS-STAGE-RANK1-OBSERVER.json',
    'foreign_mode_observer_review': 'research/retained_state_next/FOREIGN-MODE-OBSERVER-INDEPENDENT-REVIEW.json',
    'foreign_mode_source_cut': 'research/operator_alignment_next/CROSS-STAGE-SOURCE-CUT.json',
    'conditional_one_center_economics': 'research/alternative_gadgets_next/CONDITIONAL-CENTER-REPLACEMENT-PRICE.json',
    'encoded_mode_head': 'research/retained_state_next/ENCODED-MODE-HEAD.json',
    'encoded_mode_head_independent_review': 'research/operator_alignment_next/ENCODED-MODE-HEAD-INDEPENDENT-REVIEW.json',
    'paid_mode_head_sector_and_range': 'research/alternative_gadgets_next/FOREIGN-MODE-HEAD-SECTOR.json',
}

REPLAY = r'''#!/usr/bin/env python3
"""Verify pinned bytes, then run the small independent implementation reviews.

Run in the extracted package, with Python3, NumPy and SciPy installed.
The checkers write fresh receipts beside their sources. The manifest check is
performed before those intentional writes. No network or git checkout required.
"""
from pathlib import Path
from hashlib import sha256
import json
import argparse
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--supplemental-only',action='store_true',
    help='Verify the manifest and run only the added observer/price/flow reviews.')
args=parser.parse_args()
manifest=json.loads((root/'MANIFEST.json').read_text())
bad=[]
for rec in manifest['files']:
    p=root/rec['path']
    if not p.is_file() or sha256(p.read_bytes()).hexdigest()!=rec['sha256']:
        bad.append(rec['path'])
if bad:
    raise SystemExit('Source manifest mismatch: '+repr(bad))
print('PASS_SOURCE_MANIFEST', len(manifest['files']), flush=True)
commands=[
 ['research/operator_alignment_next/review_clean_dag.py'],
 ['research/alternative_gadgets_next/review_causal_companion.py'],
 ['research/integration_next/review_even_resolvent.py'],
 ['research/alternative_gadgets_next/partial_center_inverse_codes.py'],
 ['research/integration_next/filtered_precision_adjoint.py'],
 ['research/alternative_gadgets_next/review_precision_adjoint.py'],
 ['research/alternative_gadgets_next/review_owned_zero_closure.py'],
 ['research/integration_next/full_frame_fixed_vector_kernel.py'],
]
supplemental=[
 ['research/integration_next/review_portfolio_flow.py'],
 ['research/integration_next/review_rank1_center_dependency.py'],
 ['research/retained_state_next/review_foreign_mode_observer.py'],
 ['research/alternative_gadgets_next/conditional_center_replacement_price.py'],
 ['research/operator_alignment_next/review_encoded_mode_head.py'],
 ['research/alternative_gadgets_next/foreign_mode_head_sector.py'],
]
commands=supplemental if args.supplemental_only else commands+supplemental
records=[]
logs=root/'replay_logs';logs.mkdir(exist_ok=True)
for command in commands:
    before=time.monotonic()
    logfile=logs/(Path(command[0]).stem+'.log')
    with logfile.open('w') as output:
        result=subprocess.run([sys.executable,'-B']+command,cwd=root,
                              stdout=output,stderr=subprocess.STDOUT)
    rec={'command':[sys.executable,'-B']+command,'returncode':result.returncode,
         'elapsed_seconds':round(time.monotonic()-before,3),
         'log':str(logfile.relative_to(root))}
    records.append(rec);print(json.dumps(rec),flush=True)
    if result.returncode:
        print(logfile.read_text()[-10000:])
        raise SystemExit(result.returncode)
status='PASS_PORTABLE_SUPPLEMENTAL_REVIEWS' if args.supplemental_only else 'PASS_PORTABLE_INDEPENDENT_REVIEWS'
receipt={'status':status,'commands':records,
         'new_kappa_claimed':False,
         'scope':'Core literal programs, ordinary inverse and stated precision/closure reviews. Optional searches are included with their own scopes; not every historical search is rerun.'}
name='PORTABLE-SUPPLEMENTAL-REPLAY.json' if args.supplemental_only else 'PORTABLE-REPLAY.json'
(root/name).write_text(json.dumps(receipt,indent=2)+'\n')
print(status,flush=True)
'''

README = '''# Filtered native implementation and caller research

This package contains executable new constructions and exact source-bound probes.
It does **not** establish an improved multiplication exponent. The selected
conditional result at the last source refresh was kappa = 0.00302015.

## Start here

1. Read `REPORT.html` for the mathematical constructions, costs and exact limits.
2. Inspect `RESULTS.json` for the consolidated claim/evidence index.
3. With Python3, NumPy and SciPy installed, run `python3 -B verify_delivery.py`.

The verifier first checks the complete source manifest, then runs the focused
implementation reviews in sequence. Eight core reviews and six supplemental
reviews passed in portable copies, with their runs recorded separately. No clone or network
access is required. Running a checker overwrites its generated receipt, including
timing metadata; use a fresh extraction when rechecking the original manifest.
The package includes optional search scripts. The core replay does not rerun every
historical search or claim universal exclusion from bounded negative probes.

## Concrete implementations

* `research/retained_state_next/F9-SOURCE-DAG-ALL8-COMPRESSED-WORD.json.gz`:
  all-eight filtered source program, with a source-first boundary and compressed
  retained snapshots. Every original/helper input remains arbitrary.
* `research/operator_alignment_next/TWO-COPY-CLEAN-DAG-WORDS.json.gz`:
  rational paired inverse source codes, in both needed orientations.
* `research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz`:
  51,183-event paired physical program, 1,264 independent originals and 816 helper
  columns, explicit cross-frame ordinary instructions, and zero final owned state.
  Its source-to-consumer coupling is an involution; the full four-bank program is
  a shear and is not itself an involution.
* `research/operator_alignment_next/EVEN-HEAD-RESOLVENT.json`:
  an explicit 9,232-event ordinary inverse program, its spectrum and all-width proof.
* `research/operator_alignment_next/CROSS-STAGE-RANK1-OBSERVER.json`:
  an exact foreign-mode gather with an optional rank1 head, actual source-first
  chronology and a separate physical phase review. Its paid operator is J_mode,
  not the global Q head times P. The changed caller remains unresolved.
* `research/retained_state_next/ENCODED-MODE-HEAD-WORD.json.gz`:
  eight 118-event mode controls with 112 arbitrary originals and two owned fields;
  H and its inverse use one rank1 query, H squared is ordinary, and H^4=I.

The uncompressed predecessor words are retained for attribution and comparisons.
Use the compressed companion word above for the current implementation.

## Claim boundaries

Local endpoint identities and word replays are distinct from a complete caller.
The missing step is a physically legal consumer/caller or alternative target
portfolio with a positive complete recursive moment. Odd-Q role changes are not
free. A constant fraction of spectral support is not automatically a cheaper
recursive job. Workspace is never counted as an independent productive input.

The endpoint error certificate assumes unitary field norms and a local error
contract for each ordinary macro. It does not discharge the outer precision,
storage, tape or full integer-multiplication theorem.

Read `research/retained_state_next/CORRECTIONS.json` before using older snapshot
or coset receipts. Five phase-free physical interpretations were withdrawn; their
original bytes are preserved as superseded history. The corrected source-direct
proof is `research/integration_next/FULL-FRAME-FIXED-VECTOR-KERNEL.json`: actual
phase-bearing native warps fix computational zero, producing an invisible family
for all full-frame snapshots. This excludes postprocessing of those snapshots
alone, while leaving other-frame observations and changed native gates open.

The original-word eight rank1 recoveries do not survive deleting the centers:
all eight become exactly zero in the changed word. Their exact independent audit
is `RANK1-CENTER-DEPENDENCY-INDEPENDENT-REVIEW.json`. The conditional one-center
economic study is an unrealized acceptance target, not a kappa claim.

## Sources and attribution

Frozen canonical source: CrocSwap/integer-mult-bounds,
commit `20a1e31bc6009b9b3f4d084bbaadc6350e34fcba`.
The last refreshed main head and byte comparisons are in
`research/integration_next/LATEST-HEAD.json` and `CURRENT-SOURCE.json`.
`upstream/` contains only the frozen dependency subset, not a modified upstream
checkout. Its original notices are retained. New work used substantial OpenAI
assistance; no human peer review or proof-assistant formalization is claimed.
Apache-2.0. See `upstream/LICENSE`, `upstream/NOTICE`, each source package's
provenance, and `MANIFEST.json` for exact bytes.

## Open next questions

1. Find a finite chronological caller correction outside the tested tangent and
   recurrent four-cut families, with all independent inputs retained.
2. Find a different physical source birth or paid provider for the cross-stage
   modes, and charge its entire gather/transport/restoration schedule.
3. Use the paired program in a target portfolio whose actual start-to-output
   Gaussian ranks beat the complete paid bill.
4. Explore shared computation across native words, rather than repeating
   exhausted one-word memoization and unread unary fusion searches.
'''

def read_receipts():
    out={}
    for name,rel in RECEIPTS.items():
        p=ROOT/rel
        if p.exists():
            raw=p.read_bytes()
            out[name]={'path':rel,'sha256':sha256(raw).hexdigest(),
                       'receipt':json.loads(raw)}
    correction=ROOT/'research/retained_state_next/CORRECTIONS.json'
    if correction.exists():
        warnings={x['file']:x['status'] for x in json.loads(correction.read_text())['receipts']}
        for item in out.values():
            if Path(item['path']).name in warnings:
                item['claim_status_override']=warnings[Path(item['path']).name]
                item['use_as_current_physical_evidence']=False
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--stage-only',action='store_true')
    args=ap.parse_args()
    OUT.mkdir(exist_ok=True)
    STAGE.mkdir(exist_ok=True)
    # A rebuild replaces only this script's explicitly scoped staging directory.
    files=[]
    for folder in FOLDERS:
        for p in (ROOT/folder).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.bin'):
                files.append(p)
    files.extend(ROOT/x for x in EXTRA if (ROOT/x).is_file())
    for p in sorted(set(files)):
        rel=p.relative_to(ROOT);dst=STAGE/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dst)
    (STAGE/'verify_delivery.py').write_text(REPLAY)
    (STAGE/'README.md').write_text(README)
    receipts=read_receipts()
    summary={
       'schema':'filtered-native-implementation-delivery/v1',
       'created_utc':datetime.now(timezone.utc).isoformat(),
       'selected_conditional_kappa':'0.00302015',
       'comparison_moment_exponent_c':'0.0030217758',
       'new_kappa_claimed':False,
       'frozen_source_commit':'20a1e31bc6009b9b3f4d084bbaadc6350e34fcba',
       'core_constructions':['all-eight helper-clean filtered source',
          'literal rational paired inverse source codes',
          'compressed causal pair with involutive source-consumer coupling',
          'all-width ordinary even-head resolvent',
          'phase-exact one-query finite-order encoded mode heads'],
       'missing_for_kappa':'Complete physically legal caller or target portfolio, positive fully charged moment, and applicable inherited all-size/precision/hosting closure.',
       'receipts':receipts}
    summarypath=OUT/'integer_mult_filtered_native_results_2026-10-23.json'
    summarypath.write_text(json.dumps(summary,indent=2)+'\n')
    shutil.copyfile(summarypath,STAGE/'RESULTS.json')
    template=HERE/'delivery_report.html'
    if template.exists():
        report=template.read_text()
        extra=HERE/'delivery_latest.html'
        report=report.replace('<!--LATEST_RESULTS-->',extra.read_text() if extra.exists() else '')
        reportpath=OUT/'integer_mult_filtered_native_report_2026-10-23.html'
        reportpath.write_text(report)
        shutil.copyfile(reportpath,STAGE/'REPORT.html')
    word=ROOT/'research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz'
    shutil.copyfile(word,OUT/'integer_mult_causal_companion_word_2026-10-23.json.gz')
    head_word=ROOT/'research/retained_state_next/ENCODED-MODE-HEAD-WORD.json.gz'
    if head_word.exists():
        shutil.copyfile(head_word,OUT/'integer_mult_mode_head_word_2026-10-23.json.gz')
    manifest={'schema':'portable-file-manifest/v1','files':[]}
    for p in sorted(STAGE.rglob('*')):
        if p.is_file() and p.name not in ('MANIFEST.json','PORTABLE-REPLAY.json','PORTABLE-SUPPLEMENTAL-REPLAY.json') and 'replay_logs' not in p.parts and '__pycache__' not in p.parts:
            raw=p.read_bytes();manifest['files'].append({'path':str(p.relative_to(STAGE)),
                 'size_bytes':len(raw),'sha256':sha256(raw).hexdigest()})
    (STAGE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    if not args.stage_only:
        archive=OUT/'integer_mult_filtered_native_implementation_2026-10-23.tar.gz'
        with tarfile.open(archive,'w:gz') as tf:
            tf.add(STAGE,arcname='filtered_native_implementation',
                   filter=lambda i: None if '__pycache__' in Path(i.name).parts else i)
        print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,
                          'sha256':sha256(archive.read_bytes()).hexdigest()}))
    print(json.dumps({'stage':str(STAGE),'manifest_files':len(manifest['files']),
                      'receipt_count':len(receipts)}))

if __name__=='__main__':main()
