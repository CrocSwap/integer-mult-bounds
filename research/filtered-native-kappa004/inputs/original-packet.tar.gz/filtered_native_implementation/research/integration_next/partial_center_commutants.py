#!/usr/bin/env python3
"""Source-labelled Pauli directions compatible with a whole mode's K gauges.

This is a small, exact necessary screen, not a search of all Clifford residuals.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod
    spec.loader.exec_module(mod);return mod


def main():
    ce_path=ROOT/'research/tensor_obstruction/inputs/clifford_exact.py'
    ce=load('partial_center_commutant_clifford',ce_path)
    source_path=ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    rpath=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    npath=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    source=json.loads(gzip.decompress(source_path.read_bytes()))
    R=[[int(x) for x in row] for row in json.loads(rpath.read_text())]
    norms=json.loads(npath.read_text())['ports']
    c=source['canonical']
    centers=[e for e in source['programs']['forward'] if e[0]=='center']
    K=[]
    for p in norms:
        out=ce.ident(9)
        for e in p['K_word']:
            if e[0]=='P':op=ce.perm(9,e[1])
            elif e[0]=='D':op=ce.diag(9,e[1],e[2])
            elif e[0]=='X':op=ce.xgate(9,e[1])
            elif e[0]=='phase':op=ce.Op(9,ce.identity(9),[e])
            else:raise ValueError(e)
            out=out.then(op)
        K.append(out)

    def pturn(pauli):
        tab=[]
        x,z,ph=pauli
        for a in ce.identity(9):
            anti=ce.parity((a[0]&z)^(a[1]&x))
            if anti:
                xx,zz,pp=ce.pmul(pauli,a);tab.append((xx,zz,(pp-1)%4))
            else:tab.append(a)
        return tuple(tab)

    records=[]
    for k,row in enumerate(R):
        active=[i for i,x in enumerate(row) if x]
        S=ce.canonical_frame(9,c['frames'][centers[k][2]])
        record={'source_mode':k,'center_frame':centers[k][2],'directions':{}}
        for direction in ('forward_K','inverse_K'):
            tabs=[(K[i] if direction=='forward_K' else K[i].adjoint()).tab for i in active]
            image_cols=[[x|(z<<9) for x,z,p in tab] for tab in tabs]
            constraints=[]
            ref=image_cols[0]
            for cols in image_cols[1:]:
                constraints.extend(ce.transpose([a^b for a,b in zip(cols,ref)],18))
            ns=ce.nullspace(constraints,18)
            candidates=[0]
            for v in ns:candidates += [x^v for x in candidates]
            accepted=[];grades=Counter();phase_rejected=0
            for v in candidates[1:]:
                x,z=v&511,v>>9
                pauli=(x,z,(x&z).bit_count()%2)
                images=[ce.apply(tab,pauli) for tab in tabs]
                if any(t!=images[0] for t in images[1:]):
                    phase_rejected+=1;continue
                tab=ce.compose(pturn(pauli),S.adjoint().tab)
                grade=ce.rank([a for a,b,p in tab[9:]])
                grades[grade]+=1
                accepted.append({'P':list(pauli),'common_K_image':list(images[0]),
                                 'rank_G_S_inverse':grade})
            record['directions'][direction]={'binary_nullity':len(ns),
                'nonzero_binary_candidates':len(candidates)-1,
                'absolute_Pauli_phase_rejections':phase_rejected,
                'accepted':accepted,'rank_histogram':dict(sorted(grades.items())),
                'rank7_hits':sum(r['rank_G_S_inverse']==7 for r in accepted)}
        records.append(record)
    out={'schema':'source-bound-partial-center-Pauli-commutants/v1',
         'status':'PASS_EXACT_FINITE_PAULI_SCREEN',
         'source_pins':{str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest()
                        for p in (source_path,rpath,npath,ce_path)},
         'records':records,
         'scope':'All Pauli quarter-turn axes whose exact signed image is constant over the56 actual K gauges of each source mode. General noncommuting Pauli omissions and non-Pauli residuals are outside this screen.'}
    (HERE/'PARTIAL-CENTER-COMMUTANTS.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'status':out['status'],'modes':[
        {'mode':r['source_mode'],**{k:{a:v for a,v in d.items() if a!='accepted'}
                                  for k,d in r['directions'].items()}} for r in records]},indent=2))


if __name__=='__main__':main()
