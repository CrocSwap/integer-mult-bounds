#!/usr/bin/env python3
"""Independent integer flow/rounding check for clean-snapshot portfolios.

The native snapshot census itself is not regenerated here. This checker
rebuilds each closure graph from its emitted nodes/milestones, independently
encloses power tariffs with rational arithmetic, and verifies its exact flow.
"""
from collections import defaultdict
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip
import json

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

def powers(r,c):
    if r==0:return F(0),F(0)
    if r==1 or not c:return F(r),F(r)
    t=F(r-1,r+1);u=t*t;term=t;lo=F(0)
    for k in range(128):
        lo+=2*term/(2*k+1);term*=u
    hi=lo+2*term/(257*(1-u))
    def part(x,n):
        assert 0<=x<1
        ans=term=F(1)
        for k in range(1,n+1):term*=-x/k;ans+=term
        return ans
    return r*part(c*hi,17),r*part(c*lo,16)

def ceiling(x):return -((-x.numerator)//x.denominator)
def floor(x):return x.numerator//x.denominator

def review(path):
    raw=path.read_bytes();j=json.loads(gzip.decompress(raw))
    m=j['minimum_target_rank'];scale=j['integer_scale'];c=F(j['c'])
    tariffs={r:powers(r,c)for r in range(11)}
    def credit(r):
        if not r:return F(0),F(0)
        a,b=tariffs[max(r,m)],tariffs[max(0,m-r)]
        return a[0]-b[1],a[1]-b[0]
    profits=[]
    for node,r,old,owner,prev in j['milestone_nodes_ranks_owners']:
        profits.append(ceiling(scale*(credit(r)[1]-credit(old)[0])))
    assert profits==j['upper_rounded_milestone_profits']
    costs={}
    for i,n in enumerate(j['nodes']):
        r=n['query_rank']
        if r:
            q,tail=divmod(r,m-1)
            costs[i]=floor(scale*(q*tariffs[m-1][0]+tariffs[tail][0]))
    assert costs=={int(k):v for k,v in j['lower_rounded_query_costs'].items()}
    source,sink=j['source'],j['sink'];offset=j['nodeoffset'];mo=j['milestoneoffset']
    inf=sum(profits)+1;expected=defaultdict(int)
    for i,(node,r,old,owner,prev)in enumerate(j['milestone_nodes_ranks_owners']):
        expected[source,mo+i]+=profits[i];expected[mo+i,offset+node]+=inf
        if prev is not None:expected[mo+i,mo+prev]+=inf
    for i,n in enumerate(j['nodes']):
        if i in costs:expected[offset+i,sink]+=costs[i]
        for d in n['deps']:
            assert d<i;expected[offset+i,offset+d]+=inf
    caps=defaultdict(int)
    for u,v,w in j['capacities']:
        assert w>=0;caps[u,v]+=w
    assert dict(expected)==dict(caps)
    flow={}
    for u,v,w in j['antisymmetric_flow']:
        assert (u,v)not in flow;flow[u,v]=w
    balance=defaultdict(int)
    for (u,v),w in flow.items():
        assert flow.get((v,u),0)==-w
        assert -caps.get((v,u),0)<=w<=caps.get((u,v),0)
        balance[u]+=w
    value=j['flow_value']
    assert balance[source]==value and balance[sink]==-value
    assert all(x==0 for k,x in balance.items()if k not in (source,sink))
    cut=set(j['source_side']);assert source in cut and sink not in cut
    cutvalue=sum(w for (u,v),w in caps.items()if u in cut and v not in cut)
    assert cutvalue==value==j['matching_cut_value']
    # Feasible flow and equal cut suffice; no trust in the optimizer needed.
    upper=sum(profits)-value;assert upper==0
    return {'path':str(path.relative_to(ROOT)),'sha256':sha256(raw).hexdigest(),
      'minimum_target_rank':m,'capacities_checked':len(caps),
      'antisymmetric_flow_entries_checked':len(flow),
      'nodes_checked':len(j['nodes']),'milestone_tariffs_checked':len(profits),
      'query_tariffs_checked':len(costs),'exact_optimistic_surplus_upper_bound':str(F(upper,scale)),
      'flow_value':value,'cut_value':cutvalue}

def main():
    paths=[ROOT/f'research/alternative_gadgets_next/INTERMEDIATE-TARGET-FLOW-MIN{m}.json.gz'for m in(6,9)]
    records=[review(p)for p in paths]
    out={'schema':'independent-clean-snapshot-closure-flow-review/v1',
      'status':'PASS_EXACT_CAPACITIES_TARIFF_ENCLOSURES_FLOWS_AND_ZERO_UPPER_BOUNDS',
      'records':records,
      'independent_implementation':'No optimizer or portfolio generator imported. Rational128-term log enclosure and16/17-degree alternating exponent enclosure; exact edgewise flow and cut checks.',
      'all_large_thresholds':'For fixed c=0.0030217758 and every native target rank r<=9, f(M)-f(M-r) is nonincreasing for M>=9 by concavity of f(x)=x^(1-c). Native paid ranks<=5 no longer split. Every true portfolio margin at M>=9 is therefore no larger than at9, which the saved favorable flow bounds by0.',
      'scope':'Independently verifies the emitted dependency graphs and their tariffs/flow bounds for minimum6 and9, plus the analytic extension from9. It does not independently regenerate physical snapshot ranks or all2..8 source graphs.',
      'new_kappa_claimed':False}
    (HERE/'PORTFOLIO-FLOW-INDEPENDENT-REVIEW.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
