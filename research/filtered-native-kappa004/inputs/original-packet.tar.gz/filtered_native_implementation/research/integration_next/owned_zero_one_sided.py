#!/usr/bin/env python3
"""Price a changed boundary: owned-zero X, all arbitrary Y and helpers.

The backward scalar center-free producer has X_out=-F^-1 A Y when
X_initial=0.  Since A commutes F and A^-1 is ordinary, those outputs are
112 independent rank9 targets.  This script checks the actual rows and
the exact live SSA query census before a more expensive emitter is built.
"""
from collections import Counter
from decimal import Decimal as D, localcontext
from fractions import Fraction as Fr
from pathlib import Path
from hashlib import sha256
import gzip
import importlib.util
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def load(name,path):
    sp=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m)
    return m


def main():
    path=ROOT/'research/retained_state_next/F9-SOURCE-DAG-ALL8-WORD.json.gz'
    raw=path.read_bytes();p=json.loads(gzip.decompress(raw));c=p['canonical']
    corepath=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/core/native_core.py'
    core=load('zero_one_sided_core',corepath)
    rp=ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json'
    R=[[Fr(v) for v in r] for r in json.loads(rp.read_text())]
    nr=641
    rows=[{} if i<112 or i>=632 else core.identity(i) for i in range(nr)]
    def support(row):
        z=0
        for owner,word in row:
            z|=1<<(owner-112)
        return z
    frames=c['start'][:]+[None]*(nr-632)
    nodes=[{'owner':i,'index':None,'event':None,'deps':[],
            'zero':not bool(rows[i]),'frame':frames[i],
            'support':support(rows[i])} for i in range(nr)]
    state=list(range(nr));original_paid=Counter();zero_paid=Counter();allpaid=Counter()
    es=[e for e in p['programs']['backward'] if e[0]!='physical_add']
    idx=lambda r:r[1]+(632 if r[0]=='C' else 0)
    for k,e in enumerate(es):
        typ=e[0];d=None;deps=[]
        if typ=='scalar':
            a,f=e[1:];op=a[0];d=idx(a[1])
            if op=='clear':rows[d]={};frames[d]=f
            else:
                assert frames[d]==f
                if op in ('copy','add'):
                    s=idx(a[2]);assert frames[s]==f
                    if op=='copy':deps=[state[s]];rows[d]=dict(rows[s])
                    else:deps=[state[d],state[s]];core.add(rows[d],rows[s],Fr(a[3],a[4]))
                else:
                    assert op=='scale';deps=[state[d]]
                    rows[d]={v:coef*Fr(a[2],a[3]) for v,coef in rows[d].items() if coef*a[2]}
        elif typ=='warp':
            d=idx(e[1]);deps=[state[d]];assert frames[d]==e[3]
            rows[d]=core.warp(rows[d],e[2],True);frames[d]=e[4]
        elif typ=='adapter':
            d=e[2];deps=[state[d]]
        elif typ=='climb':
            d=e[2];deps=[state[d]];assert frames[d]==e[3]
            frames[d]=e[4];original_paid[e[-1]]+=1
            if not rows[d]:zero_paid[e[-1]]+=1
        else:
            assert typ=='phase', e
        if d is not None:
            j=len(nodes)
            # A known exact zero is materialized in a fresh owned SSA field.
            # It has no dependency on earlier rounded computations.
            nodes.append({'owner':d,'index':k,'event':e,
                          'deps':deps if rows[d] else [],'zero':not bool(rows[d]),
                          'frame':frames[d],'support':support(rows[d])})
            state[d]=j
    assert frames[:632]==c['final']
    assert all(not row for row in rows[632:])
    for i in range(112):
        want={}
        core.add(want,core.identity(112+i),-1)
        for r in R:
            for j,rj in enumerate(r):
                if r[i] and rj:core.add(want,core.identity(112+j),r[i]*rj/4)
        assert rows[i]==want
    assert all(rows[i]==core.identity(i) for i in range(112,632))
    # Retain exactly the productive X->Y outputs and every arbitrary helper.
    ends=[state[i] for i in list(range(112))+list(range(224,632))]
    live=set();stack=ends[:]
    while stack:
        j=stack.pop()
        if j in live:continue
        live.add(j);stack.extend(nodes[j]['deps'])
    paid=Counter()
    for j in live:
        e=nodes[j]['event']
        if e and e[0]=='climb' and not nodes[j]['zero']:paid[e[-1]]+=1
    helper=Counter(len(c['frames'][c['final'][i]])-len(c['frames'][c['start'][i]])
                   for i in range(224,632))
    targets=helper+Counter({9:112})
    def specialize_helpers(chosen, query_nodes=False):
        mask=(1<<112)-1
        for h in chosen:mask|=1<<(h-112)
        live=set();stack=[state[i] for i in list(range(112))+list(chosen)]
        while stack:
            j=stack.pop()
            if j in live:continue
            live.add(j)
            if nodes[j]['support']&mask:stack.extend(nodes[j]['deps'])
        subpaid=Counter()
        queries=set()
        for j in live:
            e=nodes[j]['event']
            if e and e[0]=='climb' and nodes[j]['support']&mask:
                subpaid[e[-1]]+=1;queries.add(j)
        subtargets=Counter({9:112})
        for h in chosen:
            subtargets[len(c['frames'][c['final'][h]])-len(c['frames'][c['start'][h]])]+=1
        return (subpaid,subtargets,len(live),queries) if query_nodes else (subpaid,subtargets,len(live))
    policies={'no_helpers':[], 'all_helpers':list(range(224,632))}
    for rank in sorted(helper):
        policies[f'only_rank_{rank}']=[h for h in range(224,632)
            if len(c['frames'][c['final'][h]])-len(c['frames'][c['start'][h]])==rank]
    specialized={}
    with localcontext() as ctx:
        ctx.prec=60;ex=D(1)-D('0.0030217758')
        for label,chosen in policies.items():
            pc,tc,ln=specialize_helpers(chosen)
            first=sum(r*v for r,v in tc.items())-sum(r*v for r,v in pc.items())
            margin=sum(D(v)*D(r)**ex for r,v in tc.items())-sum(D(v)*D(r)**ex for r,v in pc.items())
            specialized[label]={'independent_helpers':len(chosen),'paid':dict(sorted(pc.items())),
                               'targets':dict(sorted(tc.items())), 'live_SSA_nodes':ln,
                               'first_mass_margin':first,'moment_margin':str(margin)}
    # Every retained-helper set contains the complete query set required by
    # each of its singleton members: exact supports and SSA reachability are
    # monotone in the retained independent inputs and demanded outputs.
    # Ignoring pair-only extra requirements gives an optimistic weighted
    # closure problem, a rigorous upper bound on every subset in this family.
    import numpy as np
    from scipy.sparse import csr_matrix
    from scipy.sparse.csgraph import maximum_flow, breadth_first_order
    baseq=specialize_helpers([],True)[3]
    triggers={}
    for h in range(224,632):
        qset=specialize_helpers([h],True)[3]
        assert baseq<=qset
        triggers[h]=qset-baseq
    extraq=sorted(set.union(*triggers.values()))
    qindex={q:1+408+i for i,q in enumerate(extraq)}
    # Keep capacities below2^31 as well as int64: the installed SciPy flow
    # implementation uses a narrower internal capacity representation.
    sink=1+408+len(extraq);scale=10**5
    closure_bounds={}
    closure_witnesses={}
    with localcontext() as ctx:
        ctx.prec=70
        for cs in ['0','0.0030217758']:
            ex=D(1)-D(cs)
            credit={h:int((D(len(c['frames'][c['final'][h]])-len(c['frames'][c['start'][h]]))**ex*scale).to_integral_value(rounding='ROUND_CEILING'))
                    for h in range(224,632)}
            cost={q:int((D(nodes[q]['event'][-1])**ex*scale).to_integral_value(rounding='ROUND_FLOOR'))
                  for q in extraq}
            infinite=sum(credit.values())+1
            assert infinite<2**31
            ir=[];ic=[];iv=[]
            def edge(u,v,w):ir.append(u);ic.append(v);iv.append(w)
            for h in range(224,632):
                hi=1+h-224;edge(0,hi,credit[h])
                for q in triggers[h]:edge(hi,qindex[q],infinite)
            for q in extraq:edge(qindex[q],sink,cost[q])
            graph=csr_matrix((np.asarray(iv,dtype=np.int64),(ir,ic)),shape=(sink+1,sink+1))
            flow=maximum_flow(graph,0,sink,method='dinic')
            assert (flow.flow+flow.flow.T).nnz==0
            conservation=np.asarray(flow.flow.sum(axis=1)).ravel()
            assert conservation[0]==flow.flow_value and conservation[sink]==-flow.flow_value
            assert np.all(conservation[1:sink]==0)
            assert np.all((graph-flow.flow).data>=0)
            residual=graph-flow.flow
            residual.data=(residual.data>0).astype(np.int8);residual.eliminate_zeros()
            reachable=set(map(int,breadth_first_order(residual,0,directed=True,return_predecessors=False)))
            chosen=[h for h in range(224,632) if 1+h-224 in reachable]
            qchosen=set.union(*(triggers[h] for h in chosen)) if chosen else set()
            value=sum(credit[h] for h in chosen)-sum(cost[q] for q in qchosen)
            assert value==sum(credit.values())-int(flow.flow_value)
            cut=sum(w for u,v,w in zip(ir,ic,iv) if u in reachable and v not in reachable)
            assert cut==flow.flow_value
            basecredit=int((D(112)*D(9)**ex*scale).to_integral_value(rounding='ROUND_CEILING'))
            basecost=sum(int((D(nodes[q]['event'][-1])**ex*scale).to_integral_value(rounding='ROUND_FLOOR')) for q in baseq)
            upper=D(basecredit-basecost+value)/D(scale)
            actualpaid,actualtargets,actualnodes=specialize_helpers(chosen)
            actualmargin=sum(D(v)*D(r)**ex for r,v in actualtargets.items())-sum(D(v)*D(r)**ex for r,v in actualpaid.items())
            closure_bounds[cs]={'rigorous_optimistic_margin_upper_bound':str(upper),
                               'integer_rounding_scale':scale,'flow_value':int(flow.flow_value),
                               'mincut_value':cut,'exact_flow_capacity_conservation_and_cut_verified':True,
                               'selected_helper_count':len(chosen),'selected_helpers':chosen,
                               'actual_selected_paid':dict(sorted(actualpaid.items())),
                               'actual_selected_margin':str(actualmargin),
                               'all_subsets_rejected_by_upper_bound':upper<0}
            coo=flow.flow.tocoo()
            closure_witnesses[cs]={
                'vertices':sink+1,'source':0,'sink':sink,
                'capacities':sorted([int(u),int(v),int(w)] for u,v,w in zip(ir,ic,iv)),
                'antisymmetric_flow':sorted([int(u),int(v),int(w)] for u,v,w in zip(coo.row,coo.col,coo.data) if w),
                'source_side':sorted(reachable),'flow_value':int(flow.flow_value),
                'base_target_credit_rounded_up':basecredit,
                'base_query_cost_rounded_down':basecost,
                'helper_credits_rounded_up':credit,
                'extra_query_costs_rounded_down':cost,
                'integer_rounding_scale':scale,
                'rigorous_optimistic_margin_upper_bound':str(upper)}
    witness={'schema':'owned-zero-helper-closure-flow-witness/v1',
             'source_word_sha256':sha256(raw).hexdigest(),
             'base_queries':[[j,nodes[j]['index'],nodes[j]['event'][-1]] for j in sorted(baseq)],
             'extra_queries':[[j,qindex[j],nodes[j]['index'],nodes[j]['event'][-1]] for j in extraq],
             'helper_query_triggers':{h:sorted(qs) for h,qs in triggers.items()},
             'helper_rank':{h:len(c['frames'][c['final'][h]])-len(c['frames'][c['start'][h]]) for h in triggers},
             'certificates':closure_witnesses}
    witness_path=HERE/'OWNED-ZERO-CLOSURE-WITNESS.json.gz'
    witness_path.write_bytes(gzip.compress(json.dumps(witness,separators=(',',':')).encode(),mtime=0))
    moments={}
    with localcontext() as ctx:
        ctx.prec=60
        for cs in ['0','0.00302015','0.0030217758','0.0041']:
            ex=D(1)-D(cs)
            cost=sum(D(v)*D(r)**ex for r,v in paid.items())
            credit=sum(D(v)*D(r)**ex for r,v in targets.items())
            moments[cs]={'paid':str(cost),'targets':str(credit),'margin':str(credit-cost)}
    out={
      'schema':'owned-zero-one-sided-native-probe/v1',
      'status':'PASS_EXACT_ENDPOINT_AND_LIVE_SSA_INVOICE',
      'source_word_sha256':sha256(raw).hexdigest(),
      'native_core_sha256':sha256(corepath.read_bytes()).hexdigest(),
      'independent_originals':{'Y':112,'helpers':408,'total':520},
      'changed_premise':'112 original X inputs are replaced by separately owned zeros; their old target credit is removed.',
      'backward_code':'A=I-R^T R/4; all8 centers omitted and all helpers compensated; filtered F tail omitted.',
      'ordinary_decoder':'-A^-1 on the112 common conjugate(F9) X outputs gives F9^-1 Y. A^-1=I-R^T R/52.',
      'all520_required_endpoints_verified':True,
      'all632_intermediate_final_rows_verified':True,
      'original_center_free_paid':dict(sorted(original_paid.items())),
      'queries_on_exact_zero_rows':dict(sorted(zero_paid.items())),
      'live_SSA_paid':dict(sorted(paid.items())),
      'removed_paid':dict(sorted((original_paid-paid).items())),
      'SSA_nodes':len(nodes),'live_SSA_nodes':len(live),
      'live_paid_original_event_indices':[nodes[j]['index'] for j in sorted(live)
                   if nodes[j]['event'] and nodes[j]['event'][0]=='climb' and not nodes[j]['zero']],
      'helper_profile':dict(sorted(helper.items())),
      'productive_targets':dict(sorted(targets.items())),
      'helper_specialization_policies':specialized,
      'all_helper_subsets_optimistic_closure':{
          'helper_subset_count':str(2**408),
          'base_required_queries':len(baseq),'additional_singleton_queries':len(extraq),
          'implication_edges':sum(map(len,triggers.values())),
          'flow_witness_file':witness_path.name,
          'flow_witness_sha256':sha256(witness_path.read_bytes()).hexdigest(),
          'proof':'Within this exact free-warp-letter SSA pruning compiler, for S subset T every active node and live demanded node for S remains active/live for T. Therefore paid(T) contains the union of paid({h}) for h in T plus the no-helper paid set. Max-weight closure optimizes the relaxation dropping only joint extra requirements. Credits are rounded up and query costs down; exact flow feasibility, conservation and matching cut are verified.',
          'scope':'All408 helper-retention choices for this literal specialization and free-letter zero/liveness pruning. Additional identities of physical warp letters, changed scalar circuits, and other one-sided suppliers are not excluded.',
          'bounds':closure_bounds},
      'moments':moments,
      'implementation_status':'Census and all-size normalized endpoint proof only. A positive margin would trigger a literal owned-SSA emitter, physical output swaps, cleanup and precision binding.',
      'new_kappa_claimed':False,
    }
    (HERE/'OWNED-ZERO-ONE-SIDED.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k!='live_paid_original_event_indices'},indent=2))


if __name__=='__main__':main()
