#!/usr/bin/env python3
"""Read-only canonical source refresh; never edits the frozen checkout."""
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import json
import urllib.request

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
COMMIT = 'ff3cc58e370d0f678e529246f8c73e8094e18fcf'
PATHS = ('AGENTS.md', 'autoresearch.md', 'CONTRIBUTING.md',
         'certificates/selected-result.json',
         'docs/research/current-priorities.md',
         'docs/research/research-family-status.md')


def read_one(relative):
    url = f'https://raw.githubusercontent.com/CrocSwap/integer-mult-bounds/{COMMIT}/{relative}'
    request = urllib.request.Request(url, headers={'User-Agent': 'integer-mult-local-research'})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read()
    target = HERE/'current_source'/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    previous = ROOT/'upstream'/relative
    old = previous.read_bytes() if previous.exists() else None
    return {'path': relative, 'url': url, 'bytes': len(data),
            'sha256': sha256(data).hexdigest(),
            'changed_from_frozen_checkout': old != data}


def main():
    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(read_one, PATHS))
    result = {'canonical_commit': COMMIT, 'frozen_scientific_commit':
              '20a1e31bc6009b9b3f4d084bbaadc6350e34fcba', 'files': rows}
    (HERE/'CURRENT-SOURCE.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
