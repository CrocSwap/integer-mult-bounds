#!/usr/bin/env python3
"""Independent free-word audit of the eight proposed center replacements.

No producer, module solver, or native replay code is imported.  In particular,
the changed word's 823 ground-prefix operations are executed before the native
events.  Snapshot event numbers always refer to the frozen native word.
"""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import gzip
import json
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def add(dst, src, factor):
    for key, value in tuple(src.items()):
        result = dst.get(key, Q(0)) + factor * value
        if result:
            dst[key] = result
        else:
            dst.pop(key, None)


def main():
    started = time.monotonic()
    source_path = ROOT/'research/native_contact/SCALED-GLOBAL-CANCEL-WORD.json.gz'
    changed_path = ROOT/'research/retained_state_next/F9-SOURCE-DAG-ALL8-WORD.json.gz'
    candidate_path = ROOT/'research/operator_alignment_next/RANK1-SNAPSHOT-COMPLETION.json'
    source = json.loads(gzip.decompress(source_path.read_bytes()))
    changed = json.loads(gzip.decompress(changed_path.read_bytes()))
    candidates = json.loads(candidate_path.read_text())['results']
    canonical = source['canonical']
    original = source['programs']['backward']
    first_native = changed['programs']['backward'].index(original[0])
    prefix = changed['programs']['backward'][:first_native]
    assert first_native == 823
    R = [[Q(x) for x in row] for row in json.loads((ROOT/'upstream/research/involutory-producer-raw-dual/inputs/R/R.json').read_text())]
    wanted = set()
    for candidate in candidates:
        for t in candidate['retained_precenter_input_gather']:
            wanted.add((t['after_event'], t['owner']))
        recovery = next(t for t in candidate['targets'] if t['bank'] == 'Y')
        assert recovery['complete_operator_recovery']
        for t in recovery['cleanup_recipe']:
            assert t['left_operator'] == 0
            wanted.add((t['after_event'], t['owner']))

    def replay(remove_centers):
        rows = [{(i, ()): Q(1)} for i in range(632)] + [{} for _ in range(9)]
        frames = canonical['start'][:] + [None for _ in range(9)]
        paid = Counter()
        saved = {}

        def index(ref):
            return ref[1] + (632 if ref[0] == 'C' else 0)

        def event(e):
            typ = e[0]
            if typ == 'scalar':
                operation, frame = e[1:]
                dest = index(operation[1])
                if operation[0] == 'clear':
                    assert dest >= 632
                    rows[dest] = {}
                    frames[dest] = frame
                else:
                    assert frames[dest] == frame
                    if operation[0] in ('add', 'copy'):
                        src = index(operation[2])
                        assert frames[src] == frame
                        if operation[0] == 'copy':
                            assert dest >= 632
                            rows[dest] = rows[src].copy()
                        else:
                            add(rows[dest], rows[src], Q(operation[3], operation[4]))
                    else:
                        assert operation[0] == 'scale'
                        factor = Q(operation[2], operation[3])
                        rows[dest] = {k: v*factor for k, v in rows[dest].items() if v*factor}
                return dest
            if typ == 'warp':
                dest = index(e[1])
                assert frames[dest] == e[3]
                letter = e[2]
                result = {}
                for (owner, word), value in rows[dest].items():
                    word = word[1:] if word and word[0] == -letter else (letter,) + word
                    add(result, {(owner, word): value}, Q(1))
                rows[dest] = result
                frames[dest] = e[4]
                return dest
            if typ == 'climb':
                dest = e[2]
                assert frames[dest] == e[3]
                frames[dest] = e[4]
                paid[e[5]] += 1
                return dest
            if typ == 'center':
                dest = 632 + e[1]
                assert frames[dest] == e[2]
                frames[dest] = e[3]
                if remove_centers:
                    rows[dest] = {}
                else:
                    paid[e[4]] += 1
                return dest
            assert typ in ('adapter', 'phase')
            return None

        if remove_centers:
            for e in prefix:
                event(e)
        for pos, e in enumerate(original):
            dest = event(e)
            if (pos, dest) in wanted:
                saved[pos, dest] = rows[dest].copy()
        assert set(saved) == wanted
        assert frames[:632] == canonical['final'] and not rows[632]
        tests = []
        for candidate in candidates:
            mode, coefficient = next(iter(candidate['target_modes'].items()))
            mode = int(mode)
            assert Q(coefficient) == 1
            value = {}
            for term in candidate['retained_precenter_input_gather']:
                add(value, saved[term['after_event'], term['owner']], Q(term['coefficient']))
            recovery = next(t for t in candidate['targets'] if t['bank'] == 'Y')
            for term in recovery['cleanup_recipe']:
                add(value, saved[term['after_event'], term['owner']], -Q(term['subtract_coefficient']))
            expected = {} if remove_centers else {(112+i, ()): x for i, x in enumerate(R[mode]) if x}
            assert value == expected, (mode, remove_centers)
            tests.append({'mode': mode, 'output_terms': len(value), 'expected': 'zero' if remove_centers else 'R_mode_Y', 'exact_match': True})
        return {'paid_profile': dict(sorted(paid.items())), 'tests': tests, 'all632_input_columns_independent': True}

    result = {'status': 'PASS', 'schema': 'independent-eight-rank1-center-dependency/v1',
              'files': {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in (source_path, changed_path, candidate_path)},
              'unchanged_word': replay(False), 'helper_clean_center_free_word': replay(True),
              'ground_prefix_events': len(prefix), 'free_word_identity': True,
              'conclusion': 'The eight original-word recoveries are exact. In the changed word every proposed recovery equals zero, so these observations add no information beyond their two full snapshots. This does not exclude other observations.',
              'seconds': time.monotonic()-started, 'new_kappa_claimed': False}
    (HERE/'RANK1-CENTER-DEPENDENCY-INDEPENDENT-REVIEW.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'status': result['status'], 'original_recoveries': 8, 'changed_zero_relations': 8, 'seconds': result['seconds']}, indent=2))


if __name__ == '__main__':
    main()
