#!/usr/bin/env python3
"""Independent exact replay of the emitted ordinary even-head inverse.

Execute every literal ADD, CLEAR and owned SWAP over all eight independent
input coordinates and all512 translation characters.  Integer arrays and
explicit common denominators avoid numerical eigenvalue or rounding claims.
"""
from collections import Counter
from fractions import Fraction as Fr
from hashlib import sha256
from math import lcm, prod
from pathlib import Path
import importlib.util
import json
import sys
import time

import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def integer_determinant(matrix):
    """Fraction-free Bareiss elimination, with exact division and pivots."""
    a=[[int(x) for x in row] for row in matrix]
    n=len(a);sign=1;previous=1
    for k in range(n-1):
        pivot=next((i for i in range(k,n) if a[i][k]),None)
        if pivot is None:
            return 0
        if pivot!=k:
            a[k],a[pivot]=a[pivot],a[k];sign=-sign
        p=a[k][k]
        for i in range(k+1,n):
            for j in range(k+1,n):
                value=p*a[i][j]-a[i][k]*a[k][j]
                assert value%previous==0
                a[i][j]=value//previous
            a[i][k]=0
        previous=p
    return sign*a[-1][-1]


def main():
    started=time.monotonic()
    path=ROOT/'research/operator_alignment_next/EVEN-HEAD-RESOLVENT.json'
    claim=json.loads(path.read_text())
    rp=ROOT/'research/tensor_obstruction/inputs/R.json'
    npth=ROOT/'upstream/research/coded-native-caller/NORMALIZERS.json'
    R=np.array(json.loads(rp.read_text()),dtype=np.int64)
    normals=json.loads(npth.read_text())['ports']
    qs=[v['q'] for v in normals]
    assert (R@R.T==56*np.eye(8,dtype=np.int64)).all()
    assert claim['source_R_sha256']==sha256(rp.read_bytes()).hexdigest()
    # This interpreter is from a separately authored physical-word review,
    # not the resolvent generator or its source-data loader.
    cp=ROOT/'research/alternative_gadgets_next/review_causal_companion.py'
    spec=importlib.util.spec_from_file_location('independent_cross_review',cp)
    review=importlib.util.module_from_spec(spec);spec.loader.exec_module(review)
    ce,_=review.load_ce()
    Q=ce.cgate(9,1)
    for item in normals:
        K=review.compile_word(ce,9,item['K_word'])
        lhs=K.adjoint().then(Q).then(Q).then(K)
        rhs=ce.xgate(9,item['q']).then(ce.Op(9,ce.identity(9),[('phase',2)]))
        assert review.same(lhs,rhs)
    signs=np.array([[1-2*((w&q).bit_count()%2) for w in range(512)] for q in qs],dtype=np.int64)
    seen={}
    matrices=[]
    for block in claim['exact_blocks']:
        w=block['xor_frequency']
        numerator=(R*signs[:,w])@R.T
        assert numerator.tolist()==block['numerator_over_56']
        key=tuple(map(tuple,numerator.tolist()))
        if key not in seen:
            # Two degree-eight polynomials agreeing at nine integers are
            # identical.  This is independent of the generator's Newton
            # trace recurrence and numerical root proposals.
            for point in range(9):
                actual=integer_determinant(point*np.eye(8,dtype=np.int64)-numerator)
                proposed=prod(point-v for v in block['exact_eigenvalue_numerators'])
                assert actual==proposed
            seen[key]=True
        matrices.append(numerator)
    assert len(matrices)==512
    numerator=np.stack(matrices,axis=2).astype(object)
    schedule=claim['uniform_resolvent_example']['literal_schedule']
    results=[]
    for width in (1,2):
        values={}
        for i in range(8):
            a=np.zeros((8,512),dtype=object)
            a[i,:]=1
            values[('input',i)]=(a,1)
        counts=Counter()
        for e in schedule:
            kind=e[0];counts[kind]+=1
            d=tuple(e[1])
            assert d[0]!='input'
            if kind=='clear':
                values[d]=(np.zeros((8,512),dtype=object),1)
            elif kind=='swap_owned':
                s=tuple(e[2]);assert s[0]!='input'
                values[d],values[s]=values[s],values[d]
            else:
                assert kind=='add'
                s=tuple(e[2]);coefficient=Fr(e[3]);address=e[4]
                dest,dd=values[d];src,ds=values[s]
                if address[0]=='identity':
                    mapped=src
                else:
                    assert address[0]=='uniform_digit_X'
                    assert address[2]=='scalar_phase_(-1)^width'
                    chars=np.array([(-1)**width*(1-2*((w&address[1]).bit_count()%2))
                                    for w in range(512)],dtype=object)
                    mapped=src*chars
                denominator=lcm(dd,ds*coefficient.denominator)
                values[d]=(dest*(denominator//dd)+mapped*(coefficient.numerator*(denominator//(ds*coefficient.denominator))),denominator)
        outputs=[values[('state',i)] for i in range(8)]
        common=lcm(*(den for _,den in outputs))
        z=np.stack([a*(common//den) for a,den in outputs],axis=0)
        # z[output mode,input mode,frequency]; T2 is numerator/56 with
        # the width-parity sign.  Multiply the claimed inverse directly.
        t=np.empty_like(z)
        for i in range(8):
            for j in range(8):
                t[i,j]=sum(numerator[i,k]*z[k,j] for k in range(8))
        reconstructed=52*z-((-1)**width)*t
        expected=np.zeros_like(z)
        for i in range(8):expected[i,i,:]=52*common
        assert np.array_equal(reconstructed,expected)
        assert all(not a.any() for (name,i),(a,den) in values.items() if name in ('next','gather'))
        assert all(values[('input',i)][1]==1 for i in range(8))
        for i in range(8):
            target=np.zeros((8,512),dtype=object);target[i,:]=1
            assert np.array_equal(values[('input',i)][0],target)
        results.append({'width_parity_example':width,
                        'all_independent_input_modes':8,'all_frequency_blocks':512,
                        'exact_inverse_matrix_entries_checked':8*8*512,
                        'literal_event_counts':dict(counts),
                        'common_denominator':str(common),
                        'all_arbitrary_inputs_retained':True,
                        'all_nonoutput_owned_fields_zero':True})
        print('PASS_EXACT_LITERAL_PARITY',width,flush=True)
    out={'schema':'independent-all-width-even-resolvent-review/v1',
         'status':'PASS_EXACT_SOURCE_PHASES_SPECTRUM_AND_LITERAL_INVERSE_PROGRAM',
         'source_receipt_sha256':sha256(path.read_bytes()).hexdigest(),
         'source_R_sha256':sha256(rp.read_bytes()).hexdigest(),
         'source_normalizers_sha256':sha256(npth.read_bytes()).hexdigest(),
         'phase_exact_source_conjugations':112,
         'exact_8_by_8_blocks':512,'distinct_blocks_independent_charpoly_checks':len(seen),
         'literal_replays':results,
         'all_width_reason':'Uniform simultaneous column translations form the512-element XOR group. Every tensor width decomposes into the same512 characters, with multiplicity2^(9(m-1)); (-1)^m is the only extra phase. Both parity families are checked above.',
         'scope':'Eight-mode ordinary resolvent and its spectrum only; no odd-head inverse, complete caller, or kappa gain.',
         'elapsed_seconds':round(time.monotonic()-started,3),'new_kappa_claimed':False}
    (HERE/'EVEN-RESOLVENT-INDEPENDENT-REVIEW.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
