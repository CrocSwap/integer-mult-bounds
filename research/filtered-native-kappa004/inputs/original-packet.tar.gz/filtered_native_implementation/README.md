# Filtered native implementation and caller research

This package contains executable new constructions and exact source-bound probes.
It does **not** establish an improved multiplication exponent. The selected
conditional result at the last source refresh was kappa = 0.00302015.

## Start here

1. Read `REPORT.html` for the mathematical constructions, costs and exact limits.
2. Inspect `RESULTS.json` for the consolidated claim/evidence index.
3. With Python3, NumPy and SciPy installed, run `python3 -B verify_delivery.py`.

The verifier first checks the complete source manifest, then runs the focused
implementation reviews in sequence. Eight core reviews and six supplemental
reviews passed in portable copies, with their runs recorded separately. No clone or network
access is required. Running a checker overwrites its generated receipt, including
timing metadata; use a fresh extraction when rechecking the original manifest.
The package includes optional search scripts. The core replay does not rerun every
historical search or claim universal exclusion from bounded negative probes.

## Concrete implementations

* `research/retained_state_next/F9-SOURCE-DAG-ALL8-COMPRESSED-WORD.json.gz`:
  all-eight filtered source program, with a source-first boundary and compressed
  retained snapshots. Every original/helper input remains arbitrary.
* `research/operator_alignment_next/TWO-COPY-CLEAN-DAG-WORDS.json.gz`:
  rational paired inverse source codes, in both needed orientations.
* `research/retained_state_next/CAUSAL-COMPANION-WORD.json.gz`:
  51,183-event paired physical program, 1,264 independent originals and 816 helper
  columns, explicit cross-frame ordinary instructions, and zero final owned state.
  Its source-to-consumer coupling is an involution; the full four-bank program is
  a shear and is not itself an involution.
* `research/operator_alignment_next/EVEN-HEAD-RESOLVENT.json`:
  an explicit 9,232-event ordinary inverse program, its spectrum and all-width proof.
* `research/operator_alignment_next/CROSS-STAGE-RANK1-OBSERVER.json`:
  an exact foreign-mode gather with an optional rank1 head, actual source-first
  chronology and a separate physical phase review. Its paid operator is J_mode,
  not the global Q head times P. The changed caller remains unresolved.
* `research/retained_state_next/ENCODED-MODE-HEAD-WORD.json.gz`:
  eight 118-event mode controls with 112 arbitrary originals and two owned fields;
  H and its inverse use one rank1 query, H squared is ordinary, and H^4=I.

The uncompressed predecessor words are retained for attribution and comparisons.
Use the compressed companion word above for the current implementation.

## Claim boundaries

Local endpoint identities and word replays are distinct from a complete caller.
The missing step is a physically legal consumer/caller or alternative target
portfolio with a positive complete recursive moment. Odd-Q role changes are not
free. A constant fraction of spectral support is not automatically a cheaper
recursive job. Workspace is never counted as an independent productive input.

The endpoint error certificate assumes unitary field norms and a local error
contract for each ordinary macro. It does not discharge the outer precision,
storage, tape or full integer-multiplication theorem.

Read `research/retained_state_next/CORRECTIONS.json` before using older snapshot
or coset receipts. Five phase-free physical interpretations were withdrawn; their
original bytes are preserved as superseded history. The corrected source-direct
proof is `research/integration_next/FULL-FRAME-FIXED-VECTOR-KERNEL.json`: actual
phase-bearing native warps fix computational zero, producing an invisible family
for all full-frame snapshots. This excludes postprocessing of those snapshots
alone, while leaving other-frame observations and changed native gates open.

The original-word eight rank1 recoveries do not survive deleting the centers:
all eight become exactly zero in the changed word. Their exact independent audit
is `RANK1-CENTER-DEPENDENCY-INDEPENDENT-REVIEW.json`. The conditional one-center
economic study is an unrealized acceptance target, not a kappa claim.

## Sources and attribution

Frozen canonical source: CrocSwap/integer-mult-bounds,
commit `20a1e31bc6009b9b3f4d084bbaadc6350e34fcba`.
The last refreshed main head and byte comparisons are in
`research/integration_next/LATEST-HEAD.json` and `CURRENT-SOURCE.json`.
`upstream/` contains only the frozen dependency subset, not a modified upstream
checkout. Its original notices are retained. New work used substantial OpenAI
assistance; no human peer review or proof-assistant formalization is claimed.
Apache-2.0. See `upstream/LICENSE`, `upstream/NOTICE`, each source package's
provenance, and `MANIFEST.json` for exact bytes.

## Open next questions

1. Find a finite chronological caller correction outside the tested tangent and
   recurrent four-cut families, with all independent inputs retained.
2. Find a different physical source birth or paid provider for the cross-stage
   modes, and charge its entire gather/transport/restoration schedule.
3. Use the paired program in a target portfolio whose actual start-to-output
   Gaussian ranks beat the complete paid bill.
4. Explore shared computation across native words, rather than repeating
   exhausted one-word memoization and unread unary fusion searches.
