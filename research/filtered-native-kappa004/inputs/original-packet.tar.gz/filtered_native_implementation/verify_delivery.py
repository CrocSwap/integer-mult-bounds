#!/usr/bin/env python3
"""Verify pinned bytes, then run the small independent implementation reviews.

Run in the extracted package, with Python3, NumPy and SciPy installed.
The checkers write fresh receipts beside their sources. The manifest check is
performed before those intentional writes. No network or git checkout required.
"""
from pathlib import Path
from hashlib import sha256
import json
import argparse
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--supplemental-only',action='store_true',
    help='Verify the manifest and run only the added observer/price/flow reviews.')
args=parser.parse_args()
manifest=json.loads((root/'MANIFEST.json').read_text())
bad=[]
for rec in manifest['files']:
    p=root/rec['path']
    if not p.is_file() or sha256(p.read_bytes()).hexdigest()!=rec['sha256']:
        bad.append(rec['path'])
if bad:
    raise SystemExit('Source manifest mismatch: '+repr(bad))
print('PASS_SOURCE_MANIFEST', len(manifest['files']), flush=True)
commands=[
 ['research/operator_alignment_next/review_clean_dag.py'],
 ['research/alternative_gadgets_next/review_causal_companion.py'],
 ['research/integration_next/review_even_resolvent.py'],
 ['research/alternative_gadgets_next/partial_center_inverse_codes.py'],
 ['research/integration_next/filtered_precision_adjoint.py'],
 ['research/alternative_gadgets_next/review_precision_adjoint.py'],
 ['research/alternative_gadgets_next/review_owned_zero_closure.py'],
 ['research/integration_next/full_frame_fixed_vector_kernel.py'],
]
supplemental=[
 ['research/integration_next/review_portfolio_flow.py'],
 ['research/integration_next/review_rank1_center_dependency.py'],
 ['research/retained_state_next/review_foreign_mode_observer.py'],
 ['research/alternative_gadgets_next/conditional_center_replacement_price.py'],
 ['research/operator_alignment_next/review_encoded_mode_head.py'],
 ['research/alternative_gadgets_next/foreign_mode_head_sector.py'],
]
commands=supplemental if args.supplemental_only else commands+supplemental
records=[]
logs=root/'replay_logs';logs.mkdir(exist_ok=True)
for command in commands:
    before=time.monotonic()
    logfile=logs/(Path(command[0]).stem+'.log')
    with logfile.open('w') as output:
        result=subprocess.run([sys.executable,'-B']+command,cwd=root,
                              stdout=output,stderr=subprocess.STDOUT)
    rec={'command':[sys.executable,'-B']+command,'returncode':result.returncode,
         'elapsed_seconds':round(time.monotonic()-before,3),
         'log':str(logfile.relative_to(root))}
    records.append(rec);print(json.dumps(rec),flush=True)
    if result.returncode:
        print(logfile.read_text()[-10000:])
        raise SystemExit(result.returncode)
status='PASS_PORTABLE_SUPPLEMENTAL_REVIEWS' if args.supplemental_only else 'PASS_PORTABLE_INDEPENDENT_REVIEWS'
receipt={'status':status,'commands':records,
         'new_kappa_claimed':False,
         'scope':'Core literal programs, ordinary inverse and stated precision/closure reviews. Optional searches are included with their own scopes; not every historical search is rerun.'}
name='PORTABLE-SUPPLEMENTAL-REPLAY.json' if args.supplemental_only else 'PORTABLE-REPLAY.json'
(root/name).write_text(json.dumps(receipt,indent=2)+'\n')
print(status,flush=True)
