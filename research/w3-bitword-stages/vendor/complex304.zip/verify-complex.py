from pathlib import Path
import argparse,hashlib,importlib.util,json,gzip,subprocess,os,sys,time
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--cxx',default='g++');p.add_argument('--boost-include',type=Path);a=p.parse_args();O=a.output.resolve();assert not O.exists() and O!=HERE and HERE not in O.parents;O.mkdir(parents=True);(O/'tmp').mkdir();env=os.environ.copy();env.update(TEMP=str(O/'tmp'),TMP=str(O/'tmp'),PYTHONDONTWRITEBYTECODE='1');t=time.monotonic()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def wr(p,j):p.write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
files=json.loads((HERE/'MANIFEST.json').read_text())['files'];assert set(files)=={p.relative_to(HERE).as_posix()for p in HERE.rglob('*')if p.is_file()and p.name!='MANIFEST.json'}
for n,h in files.items():assert sha(HERE/n)==h,n
z=HERE/'inputs/complex/gcert1-p11-pr304.json.gz';c=json.loads(gzip.decompress(z.read_bytes()));gx=module('admitted_gx',HERE/'code/gx.py');stats={};assert gx.check1(c,scalar=True,stats=stats);wr(O/'GX.json',dict(status='PASS_FRESH_GX_ALL_SOURCE_COLUMNS_AND_PROGRAM_CONTRACT',stats=stats,program_compressed_sha256=sha(z),scope='Source-only scalar replay; arbitrary dirty restoration is supplied by the general invocation theorem.'))
admission=module('admission',HERE/'portable_complex.py').run(HERE,progress=lambda s:print(s,flush=True));wr(O/'ADMISSION.json',admission);exe=O/('complex-price.exe'if os.name=='nt'else'complex-price');cmd=[a.cxx,'-O2','-std=c++17','-I',HERE/'code']
if a.boost_include:cmd+=['-I',a.boost_include.resolve()]
with(O/'compile.log').open('w')as f:r=subprocess.run(list(map(str,cmd+[HERE/'code/complex-price.cpp','-o',exe])),env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
with(O/'native.log').open('w')as f:r=subprocess.run(list(map(str,[exe,O/'ADMISSION.json',O/'NATIVE.json'])),env=env,stdout=f,stderr=subprocess.STDOUT)
assert r.returncode==0
native=json.loads((O/'NATIVE.json').read_text());assert native['program_compressed_sha256']==sha(z)
for n,h in files.items():assert sha(HERE/n)==h,n
wr(O/'CERTIFICATE.json',dict(status='PASS_FRESH_SOURCE_BOUND_STRONGER_COMPLEX_ADMISSION',program_compressed_sha256=sha(z),manifest_sha256=sha(HERE/'MANIFEST.json'),gx_sha256=sha(O/'GX.json'),admission_sha256=sha(O/'ADMISSION.json'),native_sha256=sha(O/'NATIVE.json'),native_executable_sha256=sha(exe),tensor_saving=native['tensor_saving'],fourier_saving=native['fourier_saving'],retained_row_coefficient=native['retained_row_coefficient'],inherited_all_size_interfaces=True,fresh_lean=False,seconds=time.monotonic()-t));print('PASS stronger complex admission',flush=True)
