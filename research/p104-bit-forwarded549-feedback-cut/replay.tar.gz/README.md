# Replay forwarded x549 and bound the nine old feedback directions

Forward x549 through the funded 0→19→182 topology to restore all native chart-268 source rows. Remove the old h contribution from the 421→0 feedback and keep the public endpoints.

The literal control keeps 679 in both orientations and fails 63 forward / one adjoint row. Recoding 2944 restores e17 locally but corrupts its first reader. Separate exact rank arguments reject joint 509/421 recovery of two old rows, and joint recovery of all nine native chart-0 input directions with all historical source rows frozen.

Change an earlier source value or the required output span at chart 0 while securing the full original transfer.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. Both cold packages passed all manifests and code. They reconstruct four literal diagnostics, both full invoices, two-bank and first-reader probes, and chart-421 zero intersection with the rank-nine old feedback demand.
