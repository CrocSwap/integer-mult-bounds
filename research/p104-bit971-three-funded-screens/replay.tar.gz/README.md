# Three timed tests of packet 971 on the signed P104 BIT supplier

These independent offline packages study the projected binary supplier with x341=x340, surrendered target 341 and original transfers 968, 971 and 1564 omitted. They test three different ways of supplying the missing signal. Every tested grammar fails a retained stock or output requirement. The 679 surviving public coordinates and the protected 3553=x411 are part of the contracts. An unconstrained changed word and its complete conditional exponent remain open.

* **Paired receiver exchanges.** Each of 21 unordered pairs drawn from seven named MOVEs was tested at the original senders and clocks. Nineteen fail timed quotient-stock checks. Two yield inconsistent output equations, including a no-op exchange at the common receiver. No pair survived to the optional retiming screen. The results permit no inference for moving the clocks of an already rejected pair.
* **Mixed stock at fixed clocks.** All 512 named mixed second directions in the frozen roster fail. The independent replay validates 489 explicit XOR certificates and resolves 23 cases using exact two-coordinate stock-kernel enumeration. All other paid routes and clocks remain fixed. Mixed directions outside this finite roster and higher-dimensional corrections remain open.
* **A fourth deletion with a purchased delivery.** None of 74 named fourth omissions can finance and implement one new positive-grade nested delivery to chart 178 before packet 1568 under the retained single-x51 perturbation grammar. The new delivery may use any source-stock payload. Its fourth omitted packet still owes its own readers. Grades and outward complete caller prices are included. The prospective margins do not arise from an executable candidate.

The mixed-direction and fourth-omission archives are preserved byte for byte from their owners. The first archive contains its owner's complete manifest closure. Each subarchive retains its original source, notices and independently replayable checks. The combined checksum file covers the subarchives, this note, the recursive member verification inventory and copies of the observed owner logs.

## Reproduce offline

From the unpacked outer directory, verify the combined bytes and prepare three separate working directories.

```sh
sha256sum -c SHA256SUMS
mkdir paired mixed fourth
tar -xzf paired-routes.tar.gz -C paired
tar -xzf mixed-fixed-clock-512.tar.gz -C mixed
tar -xzf funded-fourth-one-pulse.tar.gz -C fourth
```

In `paired`, run `sha256sum -c SHA256SUMS`. In `paired/bundle`, run the following commands.

```sh
sha256sum -c SHA256SUMS
python3 -B verify_word.py
python3 -B paired_gate.py
python3 -B check_paired_certificates.py
python3 -B invoice_controls.py
```

In `mixed`, run `sha256sum -c SHA256SUMS` and `python3 -B verify.py` on one CPU. In `fourth/bundle`, follow the commands in `ROUND5-REPORT.md` and validate both `SHA256SUMS` and `SHA256SUMS-R5`. `README.md` in that particular inner directory is a retained predecessor note. `ROUND5-REPORT.md` is its new result.

## Sources and next question

The surrounding signed supplier is pinned to #7830 at 87fbf4f7b35b0f18ab12b5767775a9a424cf0b15. Its separately retained owner-411-tree native word has compressed SHA-256 d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9 and canonical SHA-256 d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d. The immediate predecessor is #7931 at 91276364ecb92d3182c1d18a80a661b232d7ba0c, which covered single-route relocation and 678 fixed-topology singleton second directions. The current three archives cover different constrained edits. The research context is #7852 at 41beda1d6435760dc99e38bd7e65f36798aad212 and #7869 at 06c207a9feb3994a4b987dc3010657b6e85b7956. The component source manifests and preserved original notices identify the individual predecessors and contributors. Prepared for Clear1nsight with substantial OpenAI Codex assistance.

A bounded continuation can jointly retime two real paid incidences and give both displaced receivers explicit dated replacement stock. It must reprice the entire changed 36-call signed invoice, restore every preserved terminal and establish its independent finite transfer before claiming a conditional exponent.
