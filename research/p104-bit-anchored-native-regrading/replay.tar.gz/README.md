# Anchored native geometry: producer and independent audit

This archive joins the original producer certificate with an independently implemented audit. Both reconstruct the pinned [#7830 native word at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) from its primitive tape. Under the anchored model below, the best complete 36-call **native** signed change is **zero** at `0.003879928046156` and `0.003879929046155`. The incumbent attains equality. This is an obstruction for that model, not a new κ bound or a physical supplier proof.

The original producer is preserved byte for byte as `PRODUCER.tar.gz`, SHA-256 `60bff60b4995e2498b9a2a4f092e186bfa638aa1b65ebe28b2b77c0d7ae068d6`. `independent/audit.py` separately rebuilds its graph, row spaces and price certificate. The root verifier requires the producer and auditor to use **identical word and author-receipt bytes**, replays both in a clean temporary directory, and verifies the original source archive and package inventory. The auditor computes its own rational, directed intervals; it checks that these overlap the producer's separately calculated decimal intervals and that its own upper endpoints are nonpositive.

## Exact scope

Fix the original packet dependencies and 2,874 paid and 458 productive edges, with their original lower-to-upper inclusion directions. The 229 explicitly anchored cochart components include the start and return charts of all 222 main public owners (111 main pairs), owner 411's endpoints and the protected 411 bridge/tree endpoints. For any finite positive integer `m`, take ambient space `Q^8 ⊗ Q^m` and replace each fixed anchor `A` by exactly `A ⊗ Q^m`. Every unanchored component may be **any rational subspace**, including a space which does not split into individual eight-dimensional copies, subject to the anchored inclusions. Coincident charts receive grade zero in this relaxation.

The conclusion compares native edge costs with the uniformly replicated incumbent under the original fixed caller and owner model; unchanged caller and rational terms are not a new supplier qualification. Changed or non-replicated anchors, new main projectors, changed packet graph or edge orientation, different caller incidences, non-rational constructions and physical erasure are outside the claim.

## Independent reconstruction

The auditor parses every INIT, CLEAR, ADD, SWAP and MOVE from the primitive word. It checks live chart tags, produces 2,874 packet rows plus 680 terminal rows, and reconstructs cochart equivalence independently with a union-find. It binds each component back to its source chart, checks original nested orientation and reproduces the full source paid and productive histograms. It obtains 656 components and 229 explicit anchors. Independent exact rational row reduction, sums and intersections then give 606 forced components and 50 free components.

The free graph has eight four-vertex stars and nine two-vertex components. Each star has three leaves with scalar interval dimensions 6 to 7 and a hub with interval dimensions 7 to 8. The auditor verifies all 24 identities `U_leaf ∩ L_hub = L_leaf` and the actual leaf-to-hub orientation. Each pair has zero-to-full interval at both ends and one oriented internal edge. The auditor enumerates nine admissible scalar endpoint states per star and all 45 ordered integer dimension states per pair: 477 in total. Each state's independently directed upper bound is nonpositive at both rates; all states in the nine pairs have bound exactly zero. The original dimension state gives exact zero in every component.

## Why coupled free spaces are covered

Tensoring finite-dimensional vector spaces over `Q` preserves finite sums and intersections. Consequently the propagated hulls are exactly `L_i ⊗ Q^m` and `U_i ⊗ Q^m`, and every checked leaf intersection identity also tensors. For an **arbitrary** admissible leaf `S_i` and hub `S_h`, not necessarily decomposable into layers, the map

`S_i / (L_i ⊗ Q^m) → S_h / (L_h ⊗ Q^m)`

has zero kernel: the leaf lies inside `U_i ⊗ Q^m`, whose intersection with `L_h ⊗ Q^m` is `L_i ⊗ Q^m`. Thus its normalized excess `x_i` cannot exceed the hub's normalized excess `y`. The allowable rank envelope for each star is `0 ≤ x_i ≤ y ≤ 1`. It is the convex hull of the all-zero state and the eight states with `y=1` and binary leaves. For `y>0`, one explicit convex representation gives weight `1−y` to zero and weight `y∏(x_i/y)^{b_i}(1−x_i/y)^{1−b_i}` to leaf bit pattern `b`. The zero case is immediate. A pair obeys `0 ≤ a ≤ b ≤ 8`; weights `1−b/8`, `(b−a)/8` and `a/8` use its three extreme states, which are among the 45 checked states.

For `m=2`, the checker constructs a concrete free leaf containing `v ⊗ (1,1)` while neither `v ⊗ (1,0)` nor `v ⊗ (0,1)` belongs to it. It verifies all 19 edges incident to that star in the replicated ambient space. This is a nondecomposable witness, not an assumption that general spaces split. The checker also exercises 1,970 exact finite-multiplicity convex-weight instances; the algebraic formulas above establish the statement for every finite positive `m`.

## Signed inequality and directed corners

Set `H(g)=g^(1−κ)` and `H(0)=0`. For one grouped edge, let `c` be paid multiplicity minus productive multiplicity, `g>0` its original grade and `h≥0` its normalized candidate grade. Its normalized signed gain is `36c[H(g)−H(h)]`.

- If `c>0`, this expression is convex in `h`, so Jensen bounds it above by the same convex mixture of corner values.
- If `c<0`, concavity gives `H(h)−H(g) ≤ H′(g)(h−g)`. Multiplication by `−c>0` preserves that sign; the resulting tangent term is affine in the same mixture weights.
- If `c=0`, the paid and productive terms cancel before either bound is applied.

The finite corner check therefore bounds every fractional normalized rank vector, including ranks of nondecomposable free spaces. Actual replicated dimensions multiply the result by the positive factor `m^(1−κ)`. The program checks the negative-displacement tangent sign and a strict Jensen sample, then evaluates every corner at both rates using rational outward intervals. It also checks that a removed source bridge, a corrupted star-anchor intersection and impossible rank orders are detected.

## Reproduction and attribution

Run with CPython 3.12 and standard library only:

```sh
python3 -I -B verify.py
```

The root verifier checks `SHA256SUMS`, the exact producer and #7912 archive hashes, source member equality, and the independently pinned author receipt. It then runs the producer and independent checker in a fresh temporary extraction and compares the independent result byte for byte. The producer and copied source retain their original Apache-2.0 license and notices.
