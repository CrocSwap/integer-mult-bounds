#!/usr/bin/env python3
"""Independent primitive-tape rebuild of anchored geometry and Jensen gate."""
from collections import Counter,defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from hashlib import sha256
from itertools import product
from pathlib import Path
import gzip,json,sys
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'inputs'));import price
RATES=('0.003879928046156','0.003879929046155')
PINS={'WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9','AUTHOR-LAYER-JENSEN.json':'f9b3914f4ce03cc665059b446bb6489feb6e2be56268d0d528f6449328112d70','price.py':'d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b','literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c'}
def need(v,msg):
 if not v:raise ValueError(msg)
for n,d in PINS.items():need(sha256((H/'inputs'/n).read_bytes()).hexdigest()==d,'pin '+n)
w=json.loads(gzip.decompress((H/'inputs/WORD.json.gz').read_bytes()));canon=lambda v:sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
need(canon(w)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','canonical source')

def bits(n):
 while n:
  k=n&-n;yield k.bit_length()-1;n^=k

class DSU:
 def __init__(self):self.p={}
 def root(self,x):
  self.p.setdefault(x,x)
  while x!=self.p[x]:self.p[x]=self.p[self.p[x]];x=self.p[x]
  return x
 def join(self,a,b):
  a,b=self.root(a),self.root(b)
  if a!=b:self.p[max(a,b)]=min(a,b)

def build():
 n=w['public'];need(n==680,'680 public')
 bank=[1<<i for i in range(n)]+[0]*w['owned_fields'];tags=w['start'][:]+[None]*w['owned_fields'];routes={};rows={}
 for clock,(op,a,*z) in enumerate(w['program']):
  if op=='INIT':need(tags[a] is None,'INIT');tags[a]=z[0];bank[a]=0
  elif op=='CLEAR':need(tags[a]==z[0],'CLEAR');tags[a]=None;bank[a]=0
  elif op=='ADD':need(tags[a]==tags[z[0]]==z[1] and a!=z[0],'cochart ADD');bank[a]^=bank[z[0]]
  elif op=='SWAP':j=z[0];need(tags[a] is not None and tags[j] is not None,'SWAP');bank[a],bank[j]=bank[j],bank[a];tags[a],tags[j]=tags[j],tags[a]
  elif op=='MOVE':
   need(tags[a]==z[0],'MOVE source chart');k=n+len(routes);routes[k]=tuple(z);rows[k]=bank[a];bank[a]=1<<k;tags[a]=z[1]
  else:raise ValueError('unknown opcode')
 need(tags==w['final']+[None]*w['owned_fields'],'all endpoint tags and retirement')
 rows.update({~j:bank[j] for j in range(n)});need(len(routes)==2874,'primitive route count')
 d=DSU()
 for j in range(n):d.root((j,'in'));d.root((~j,'out'))
 for j in routes:d.root((j,'in'));d.root((j,'out'))
 for child,mask in rows.items():
  for parent in bits(mask):d.join((parent,'in'),(child,'out'))
 roots=sorted({d.root(v) for v in d.p});ids={r:i for i,r in enumerate(roots)}
 def comp(node):return ids[d.root(node)]
 charts={}
 def bind(node,chart):
  i=comp(node);need(charts.setdefault(i,chart)==chart,'component chart mismatch '+str((i,chart)));return i
 ins=[bind((j,'in'),chart) for j,chart in enumerate(w['start'])];outs=[bind((~j,'out'),chart) for j,chart in enumerate(w['final'])]
 frozen={i for j in list(range(222))+[411] for i in (ins[j],outs[j])}
 frame_dim={int(k):v['dim'] for k,v in w['frames'].items()};edges=[];tree={(509,0),(390,509),(517,390)}
 protected=[]
 for k,(a,b) in routes.items():
  x=bind((k,'out'),a);y=bind((k,'in'),b)
  if k==3553 or (a,b) in tree:frozen.update((x,y));protected.append((k,a,b,x,y))
  edges.append((x,y,1,'packet',k))
 for h in range(222,n):
  need(frame_dim[charts[outs[h]]]>frame_dim[charts[ins[h]]],'productive target direction '+str(h))
  edges.append((ins[h],outs[h],-1,'target',h))
 grouped={};neighbors=[set() for _ in roots]
 for i,j,m,typ,label in edges:
  need(i!=j,'self edge');key=tuple(sorted((i,j)));grade=abs(frame_dim[charts[i]]-frame_dim[charts[j]])
  need(grade>0,'positive original contact grade')
  old=grouped.get(key,(0,grade));need(old[1]==grade,'edge grade consistency');grouped[key]=(old[0]+m,grade)
  neighbors[i].add(j);neighbors[j].add(i)
 need((len(roots),len(frozen),len(edges))==(656,229,3332),'component, anchor and edge counts')
 need(all(i in charts for i in range(len(roots))),'component chart coverage')
 dim=[frame_dim[charts[i]] for i in range(len(roots))]
 arcs=[(a,b,m,g) if dim[a]<dim[b] else (b,a,m,g) for (a,b),(m,g) in grouped.items()]
 need(all(dim[a]<dim[b] for a,b,m,g in arcs),'original edge orientation')
 p=Counter(abs(frame_dim[a]-frame_dim[b]) for a,b in routes.values())
 t=Counter(frame_dim[w['final'][h]]-frame_dim[w['start'][h]] for h in range(222,n))
 need(p=={1:1376,2:1281,3:54,4:44,5:17,6:102} and t=={1:8,2:9,4:43,5:8,6:1,8:389},'native paid/productive histogram')
 net=Counter()
 for a,b,m,g in arcs:net[g]+=m
 expected=Counter(p);expected.subtract(t)
 need(all(net[i]==expected[i] for i in set(net)|set(expected)),'signed grouping preserves the full source histogram')
 return roots,charts,dim,frozen,neighbors,arcs,protected,routes,rows

@lru_cache(maxsize=200000)
def rref(rows):
 a=[list(map(Q,row)) for row in rows if any(row)];p=0
 for col in range(8):
  i=next((i for i in range(p,len(a)) if a[i][col]),None)
  if i is None:continue
  a[p],a[i]=a[i],a[p];v=a[p][col];a[p]=[x/v for x in a[p]]
  for j in range(len(a)):
   if j!=p and a[j][col]:
    c=a[j][col];a[j]=[x-c*y for x,y in zip(a[j],a[p],strict=True)]
  p+=1
  if p==len(a):break
 return tuple(tuple(row) for row in a[:p])

@lru_cache(maxsize=200000)
def orth(S):
 if not S:return tuple(tuple(Q(i==j) for j in range(8)) for i in range(8))
 piv=[next(i for i,x in enumerate(row) if x) for row in S];out=[]
 for col in range(8):
  if col in piv:continue
  z=[Q(0)]*8;z[col]=Q(1)
  for row,p in zip(S,piv,strict=True):z[p]=-row[col]
  out.append(tuple(z))
 return rref(tuple(out))
@lru_cache(maxsize=200000)
def join(a,b):return rref(a+b)
@lru_cache(maxsize=200000)
def meet(a,b):return orth(join(orth(a),orth(b)))

def upper(m,g,h,k):
 # Gain = m*(H(g)-H(h)). Positive paid terms use Jensen; negative
 # productive terms use H(h)-H(g) <= H'(g)*(h-g).
 H=lambda v:price.price(v,k) if v else (0,0)
 if not m or h==g:return (0,0)
 if m>0:return price.scale(price.sub(H(g),H(h)),36*m)
 derivative=price.scale(H(g),(1-k)/g)
 return price.scale(derivative,36*(-m)*(h-g))

def rank_arbitrary(rows,width):
 """Independent exact rank for the replicated-anchor, non-layered witness."""
 a=[list(map(Q,row)) for row in rows if any(row)];p=0
 for col in range(width):
  j=next((j for j in range(p,len(a)) if a[j][col]),None)
  if j is None:continue
  a[p],a[j]=a[j],a[p];pivot=a[p][col];a[p]=[v/pivot for v in a[p]]
  for j in range(p+1,len(a)):
   if a[j][col]:
    c=a[j][col];a[j]=[v-c*u for v,u in zip(a[j],a[p],strict=True)]
  p+=1
  if p==len(a):break
 return p

def tensor_basis(rows,m):
 return [tuple((row[i//m] if i%m==j else Q(0)) for i in range(8*m))
         for row in rows for j in range(m)]

def nondecomposable_witness(star,lo,hi,old,arcs,free):
 """Exercise arbitrary subspaces at m=2 without assuming layered inputs."""
 hub=star['hub'];leaf=star['leaves'][0];m=2
 # The injection identity supplies a leaf-upper direction outside hub-lower.
 v=next(row for row in hi[leaf] if len(join(lo[hub],rref((row,))))==8)
 mixed=tuple(v[i//2] for i in range(16))
 lbase=tensor_basis(lo[leaf],m);hbase=tensor_basis(lo[hub],m)
 spaces={i:tensor_basis(lo[i],m) for i in star['component']}
 spaces[leaf]=lbase+[mixed];spaces[hub]=hbase+[mixed]
 need(rank_arbitrary(spaces[leaf],16)==13 and rank_arbitrary(spaces[hub],16)==15,'m2 witness dimensions')
 for copy in (0,1):
  separate=tuple(v[i//2] if i%2==copy else Q(0) for i in range(16))
  need(rank_arbitrary(spaces[leaf]+[separate],16)==14,'mixed leaf is not a sum of the two original layers')
 tested=0
 for a,b,mul,g in arcs:
  if a not in star['component'] and b not in star['component']:continue
  for i in (a,b):need(i in star['component'] or i not in free,'free component separation')
  A=spaces[a] if a in spaces else tensor_basis(old[a],2)
  B=spaces[b] if b in spaces else tensor_basis(old[b],2)
  need(rank_arbitrary(A+B,16)==rank_arbitrary(B,16),'nondecomposable m2 witness violates anchored edge '+str((a,b)))
  tested+=1
 return {'multiplicity':2,'star':star['component'],'leaf':leaf,'hub':hub,
         'leaf_dimension':13,'hub_dimension':15,'mixed_vector':[[str(x) for x in v],[1,1]],
         'both_individual_layer_projections_outside_leaf':True,'all_incident_edges_checked':tested}

def verify_fractional_corner_hulls():
 # Star weights: (1-y) on the bottom and y times a product of three
 # Bernoulli measures, with probabilities x_i/y, on the eight top vertices.
 # Pair weights: 1-b/8, (b-a)/8 and a/8 on (0,0),(0,8),(8,8).
 checked=0
 for multiplicity in (1,2,3,5):
  for yy in range(multiplicity+1):
   y=Q(yy,multiplicity)
   for xx in product(range(yy+1),repeat=3):
    x=tuple(Q(a,multiplicity) for a in xx)
    if not y:need(all(not z for z in x),'zero hub must force leaves zero');checked+=1;continue
    p=tuple(z/y for z in x);weights=[]
    for state in product((0,1),repeat=3):
     z=y
     for a,bit in zip(p,state,strict=True):z*=a if bit else 1-a
     weights.append((state,z))
    need(1-y>=0 and all(z>=0 for state,z in weights) and 1-y+sum(z for state,z in weights)==1,'star corner weights sum')
    need(sum(z for state,z in weights)==y and all(sum(z*state[i] for state,z in weights)==x[i] for i in range(3)),'star corner decomposition')
    checked+=1
  for bb in range(8*multiplicity+1):
   for aa in range(bb+1):
    a,b=Q(aa,multiplicity),Q(bb,multiplicity);ww=(1-b/8,(b-a)/8,a/8)
    need(min(ww)>=0 and sum(ww)==1 and 8*ww[2]==a and 8*(ww[1]+ww[2])==b,'pair corner decomposition')
    checked+=1
 return checked

def main():
 roots,charts,dim,F,nb,arcs,protected,routes,rows=build();n=len(roots)
 spaces={int(c):rref(tuple(tuple(Q(x) for x in row) for row in d['B'])) for c,d in w['frames'].items()}
 need(all(orth(spaces[int(c)])==rref(tuple(tuple(Q(x) for x in row) for row in d['A'])) for c,d in w['frames'].items()),'all orthogonal frame complements')
 old=[spaces[charts[i]] for i in range(n)]
 for a,b,m,g in arcs:need(join(old[a],old[b])==old[b],'source nested route '+str((a,b)))
 zero=();full=orth(zero);lo=[old[i] if i in F else zero for i in range(n)];hi=[old[i] if i in F else full for i in range(n)]
 for a,b,m,g in sorted(arcs,key=lambda e:dim[e[0]]):lo[b]=join(lo[a],lo[b])
 for a,b,m,g in sorted(arcs,key=lambda e:dim[e[0]],reverse=True):hi[a]=meet(hi[a],hi[b])
 need(all(join(lo[i],old[i])==old[i] and join(old[i],hi[i])==hi[i] for i in range(n)),'all original subspaces inside anchor hull')
 need(all(lo[i]==hi[i]==old[i] for i in F),'all 229 anchors retained')
 free={i for i in range(n) if lo[i]!=hi[i]};need(len(free)==50 and n-len(free)==606,'fixed/free hull count')
 todo=set(free);groups=[]
 while todo:
  u=min(todo);todo.remove(u);comp={u};q=[u]
  while q:
   i=q.pop()
   for j in nb[i]&todo:todo.remove(j);comp.add(j);q.append(j)
  groups.append(sorted(comp))
 groups.sort(key=lambda v:(-len(v),v));need(Counter(map(len,groups))=={4:8,2:9},'8 stars and 9 free pairs')
 stars=[];injections=[]
 for v in groups:
  if len(v)!=4:continue
  hh=[i for i in v if len(nb[i]&set(v))==3];need(len(hh)==1,'star hub')
  hub=hh[0];leaves=[i for i in v if i!=hub]
  need((len(lo[hub]),len(hi[hub]))==(7,8),'hub is one-dimensional interval')
  for leaf in leaves:
   need((len(lo[leaf]),len(hi[leaf]))==(6,7),'leaf one-dimensional interval')
   need((leaf,hub) in {(a,b) for a,b,m,g in arcs},'leaf to hub orientation')
   intersection=meet(hi[leaf],lo[hub]);need(intersection==lo[leaf],'leaf quotient injection failure '+str((leaf,hub)))
   injections.append({'leaf':leaf,'hub':hub,'lower_dim':len(lo[leaf]),'upper_dim':len(hi[leaf]),'intersection_dim':len(intersection),'intersection_equals_leaf_lower':True})
  stars.append({'component':v,'hub':hub,'leaves':leaves})
 need(len(injections)==24,'24 leaf injections')
 # Falsification controls: they are injected mutations, not source findings.
 first_star=stars[0];sample_leaf=first_star['leaves'][0];sample_hub=first_star['hub']
 altered_hub=next((rref(lo[sample_hub][:j]+lo[sample_hub][j+1:])
                   for j in range(len(lo[sample_hub]))
                   if meet(hi[sample_leaf],rref(lo[sample_hub][:j]+lo[sample_hub][j+1:]))!=lo[sample_leaf]),None)
 need(altered_hub is not None,'corrupt anchor injection must be detectable')
 need(len(routes)-int(3553 in routes)!=2874,'omitted original bridge must change primitive route count')
 need((Q(1)-Q(2))<0 and (Q(1)-Q(2))/8<0,'invalid star and pair rank weights must be negative')
 # Exact tensoring of a finite-dimensional field-space basis preserves sums
 # and intersections. Thus the scalar injection identities hold after
 # A -> A tensor Q^m, without requiring variable spaces themselves to split.
 witness=nondecomposable_witness(stars[0],lo,hi,old,arcs,free)
 fractional_tests=verify_fractional_corner_hulls()
 # Target tangent and paid Jensen orientation on nondegenerate numerical tests.
 for s in RATES:
  k=Q(s);need(0<k<1,'strict concavity exponent');g=2;h=1
  actual=price.sub(price.price(h,k),price.price(g,k));bound=price.scale(price.price(g,k),(1-k)*Q(h-g,g))
  need(actual[1]<bound[0]<0,'negative productive tangent sign')
  mean=price.scale(price.add(price.price(1,k),price.price(3,k)),Q(1,2));twop=price.price(2,k)
  need(mean[1]<twop[0],'strict concavity Jensen sign')
 author=json.loads((H/'inputs/AUTHOR-LAYER-JENSEN.json').read_bytes());A={tuple(x['component']):x for x in author}
 need(set(A)==set(map(tuple,groups)),'author component id mapping')
 output=[];checked=0;pair_zeros=0;star_zeros=0
 for v in groups:
  edges=[e for e in arcs if e[0] in v or e[1] in v]
  if len(v)==2:
   need(all(not lo[i] and hi[i]==full for i in v),'pair bounds are exactly zero and full')
   need(sum(a in v and b in v for a,b,m,g in edges)==1,'one oriented edge per free pair')
  author_rows={tuple(x['ranks']):x for x in A[tuple(v)]['states']};found={}
  for vals in product(*(range(len(lo[i]),len(hi[i])+1) for i in v)):
   dd=dict(zip(v,vals));grades=[dd.get(b,dim[b])-dd.get(a,dim[a]) for a,b,m,g in edges]
   if min(grades)<0:continue
   if len(v)==4:
    V={i:lo[i] if len(lo[i])==dd[i] else hi[i] for i in v}
    if any(join(V.get(a,old[a]),V.get(b,old[b]))!=V.get(b,old[b]) for a,b,m,g in edges):continue
   rr={}
   for s in RATES:
    k=Q(s);z=(0,0)
    for (a,b,m,g),h in zip(edges,grades,strict=True):z=price.add(z,upper(m,g,h,k))
    need(z[1]<=0,'strict positive corner '+str((v,vals,s,price.decimal_interval(z,30))))
    zz=author_rows.get(vals);need(zz is not None,'author omitted feasible state '+str((v,vals)))
    # Compare independent rational bounds with the author's decimal interval.
    al,au=map(Q,zz['jensen_upper'][s]);il=Q(z[0],price.GRID);iu=Q(z[1],price.GRID)
    need(max(il,al)<=min(iu,au),'author interval disagreement '+str((v,vals,s)))
    rr[s]=price.decimal_interval(z,30)
   found[vals]=rr;checked+=1
  need(set(found)==set(author_rows),'author added or omitted state '+str(v))
  need(len(found)==(9 if len(v)==4 else 45),'state count '+str(v))
  baseline=tuple(dim[i] for i in v)
  need(baseline in found and all(x==['0.000000000000000000000000000000']*2 for x in found[baseline].values()),'original baseline zero attainable')
  if len(v)==2:
   need(all(all(bounds==['0.000000000000000000000000000000']*2 for bounds in val.values()) for val in found.values()),'free pair nonzero')
   pair_zeros+=1
  elif any(all(x==['0.000000000000000000000000000000']*2 for x in val.values()) for val in found.values()):star_zeros+=1
  output.append({'component':v,'states':len(found),'max_upper_by_rate':{s:max(Q(pair[1]) for pair in [val[s] for val in found.values()]).__str__() for s in RATES}})
 need(checked==477 and pair_zeros==9 and star_zeros==8,'all corner cases and attainable zero')
 result={'status':'PASS_INDEPENDENT_ANCHORED_PRIMITIVE_COMPONENTS_JENSEN','source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','word_canonical':canon(w),'primitive_routes':len(routes),'primitive_endpoint_rows':len(rows),'cochart_components':n,'explicit_anchor_components':len(F),'forced_by_anchor_hull':606,'free_components':50,'free_subgraphs':{'four_node_stars':8,'two_node_pairs':9},'star_leaf_quotient_injections':injections,'direct_anchored_tree_edges':protected,'nondecomposable_two_copy_witness':witness,'finite_multiplicity_corner_weight_controls':fractional_tests,'signed_corner_states':checked,'signed_corner_maximum_both_trials':'0 exactly','all_9_free_pairs_every_bound_zero':True,'source_author_states_and_directed_intervals_overlap':True,'directed_formula':'c>0: 36c[H(g)-H(h)]; c<0: 36(-c)H\'(g)(h-g), H(r)=r^(1-kappa). All terms are independently outward-bounded.','injected_corruption_controls':{'omit_original_bridge_changes_route_count':True,'alter_one_star_anchor_breaks_injection':True,'invalid_star_and_pair_rank_orders_have_negative_convex_weights':True,'productive_negative_displacement_and_strict_concavity_jensen':True},'component_maxima':output,'scope':'In ambient Q^8 tensor Q^m for finite positive m, original 229 anchors are exactly A_i tensor Q^m. Remaining chart subspaces may be arbitrary rational subspaces in the replicated lower/upper hull, including nondecomposable ones, and preserve the original lower-to-upper nesting orientation. Original packet graph and signed multiplicities are fixed. This does not cover changed/non-replicated anchors, alternate edge/packet graphs, or altered caller/supplier terms.'}
 print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
