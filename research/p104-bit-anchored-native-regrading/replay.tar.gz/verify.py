#!/usr/bin/env python3
"""Verify both preserved producer and independent audit in a clean extraction."""
from hashlib import sha256
from pathlib import Path
import shutil,subprocess,sys,tarfile,tempfile
H=Path(__file__).resolve().parent

def need(v,msg):
 if not v:raise ValueError(msg)
def pin(path,digest):need(sha256(path.read_bytes()).hexdigest()==digest,'pin '+str(path))
def main():
 for line in (H/'SHA256SUMS').read_text().splitlines():
  value,name=line.split('  ',1);pin(H/name,value)
 pin(H/'PRODUCER.tar.gz','60bff60b4995e2498b9a2a4f092e186bfa638aa1b65ebe28b2b77c0d7ae068d6')
 pin(H/'PR-7912-REPLAY.tar.gz','87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096')
 with tarfile.open(H/'PR-7912-REPLAY.tar.gz','r:gz') as source:
  for name in ('WORD.json.gz','price.py','literal.py'):
   need(source.extractfile('./inputs/'+name).read()==(H/'independent/inputs'/name).read_bytes(),'7912 archived member '+name)
 with tempfile.TemporaryDirectory(prefix='p104-anchor-merged-') as root:
  tmp=Path(root)
  with tarfile.open(H/'PRODUCER.tar.gz','r:gz') as source:source.extractall(tmp,filter='data')
  producer=tmp/'anchored-native-chart-global-bound'
  need((producer/'source/inputs/WORD.json.gz').read_bytes()==(H/'independent/inputs/WORD.json.gz').read_bytes(),'both checkers use same native word')
  need((producer/'LAYER-JENSEN.json').read_bytes()==(H/'independent/inputs/AUTHOR-LAYER-JENSEN.json').read_bytes(),'author receipt exact byte binding')
  p=subprocess.run([sys.executable,'-I','-B',str(producer/'verify.py')],cwd=producer,capture_output=True,text=True,check=True)
  need('PASS 606 fixed' in p.stdout,'producer proof replay result')
  shutil.copytree(H/'independent',tmp/'independent')
  a=subprocess.run([sys.executable,'-I','-B',str(tmp/'independent/audit.py')],cwd=tmp/'independent',capture_output=True,check=True)
  need(a.stdout==(H/'independent/RESULT.json').read_bytes(),'independent reproducibility')
 print('PASS_PRODUCER_AND_INDEPENDENT_REPLICATED_ANCHOR_477_CORNERS_AND_NONDECOMPOSABLE_WITNESS')
if __name__=='__main__':main()
