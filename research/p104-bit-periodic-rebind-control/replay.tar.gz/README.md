# A candidate-bound ternary route for a changed BIT word

This packet binds Ali Romman's ternary, periodic and streamed constructions
to an **actual changed BIT control**. It checks a complete candidate-specific
catalogue, one nontrivial eight-dimensional matcher, a complete small
streamed high fibre, and a real changed rank-five leaf. It also gives
conditional funding and stock arithmetic for 451 factors. It does **not**
construct a complete changed supplier, a seven-stage physical stack, a
precision tape or an integer multiplication application. There is no κ gain.

The changed word is the zero-net routing control in
[#7884 at `4b8ed95c492458d399544b67bf95b86c63a3dc7a`](https://github.com/CrocSwap/integer-mult-bounds/pull/7884).
Its compressed SHA-256 is
`e83abcf1a2bba96681ac14bc6c76eb4ff78db86f7677ea1f19c1b839cdf275a8`,
and its canonical uncompressed SHA-256 is
`98fac9b1c809a3edb41fdaf140cee4656ffa6992e621c78be1ac0b982934f738`.
That packet and its independent replay report that the forward and adjoint
native operators are preserved. This packet independently checks the frame,
catalogue, tag and route properties below; it does not repeat that full
native-operator proof.

The physical algorithms and retained code are from Ali Romman's
[#7868 at `3f7c3c1f2a9a0963736562037e01fe41aec46b8c`](https://github.com/CrocSwap/integer-mult-bounds/pull/7868).
The comparison uses the 451-factor parameters of
[#7863 at `b3e4412fe01f07dc58305616fabf96345f49a781`](https://github.com/CrocSwap/integer-mult-bounds/pull/7863),
and the fixed-profile directed arithmetic of
[#7888 at `939a556aaf9549b3b21458471d9993a9539a10ed`](https://github.com/CrocSwap/integer-mult-bounds/pull/7888).
The #7868 source itself uses 480 binary factors, a different binary carrier
and six ordinary stages. Its statements do not automatically certify this
451-factor, seven-stage combination. See [NOTICE](NOTICE.md), the retained
[original notice](upstream/NOTICE.md), and [source pins](SOURCE-PINS.json).

## What changes and what remains equal

Clocks below are zero-based positions in the **actual changed instruction
array**. Deleting an ADD before the first two new MOVE entries shifts their
physical array indices; 873 and 877 are old-word clocks, not their new
array positions.

| New clock | Owner | Lower chart → upper chart | Difference rank |
| ---: | ---: | --- | ---: |
| 872 | 925 | 45 → 388 | 5 |
| 876 | 926 | 45 → 295 | 3 |
| 880 | 927 | 45 → 322 | 3 |

Each of the 36 LOCAL calls produces these actual ordered tags. The regenerated
paid and productive tables contain 107,460 and 20,706 entries. The rank
histograms equal the original's, but the ordered paid-table SHA-256 changes
from `b25f6531c1106ca2143e494354895e5a3aae00e6ca168e47bc55ea6677aa217d`
to `493abab54bff5e418de99dd9cb3a2a1e1897d1f1af145581ef74fe19d572fe6b`.
In particular the changed word contains a MOVE at clock 872; the old word
contains an ADD there. A consumer that retains the old table misses a real
source location even though the histogram is unchanged. Tags identify actual
locations; they are not evidence of a complete physical compiler.

The candidate has exactly the same 636 eight-coordinate frames and 111
paired joint-port bases. Their determinant absolute values are respectively
`{1:28, 4:326, 16:250, 64:32}` and `{1:8, 4:103}`; all are units at 3.
The code checks each projector over the rationals and all 2,382 distinct
unordered pairs among the candidate's 2,874 MOVE and 458 helper occurrences.
For each pair it checks nesting in both orders, idempotence of the difference,
and its expected rank modulo 3. These pair multiplicities are the same as
the original's. This gives a candidate-bound finite source catalogue; a new
word with new frames or pairs needs its own catalogue.

## A real matcher and an invisible low-trit carry

Let `P` be the rank-three difference for `45 → 295` and `Q` the difference
for `45 → 322`. Using the actual rational source frames, the code constructs
the full matcher `S` satisfying `P S = S Q` and its inverse. The complete
8×8 matrix and its 45 ordered elementary factors are in [EXPECTED.json](EXPECTED.json).
Their coefficient denominators are prime to 3, and every scale numerator is
a 3-adic unit. Across the word and its inverse, the largest absolute
coefficient numerator is 9 and the largest denominator is 16, within the
streamer's 20-run factor alphabet. The code checks the full right action and inverse on 256
deterministically generated invertible 8×8 matrices over `Z/3^w`, for
`w=1,2,3,4`, including the exact low/high carry relation. This is a sample
of eight-dimensional fibres, not their exhaustive physical routing.

One actual factor is `column 4 += 3 * column 7`. It is the identity on low
trits but is generally **not** the identity on high trits. Restrict that
single factor to its two participating coordinates. For every one of the
48 regular 2×2 low matrices over `F_3`, the fixture routes all 81 high
matrices at `w=2`, i.e. 3,888 complete high records. It compares the address
permutation against direct multiplication modulo 9 and also runs #7868's
sequential high router and full padded-cube router. The latter runs both
forward and inverse on arbitrary changed returns; the two directions charge
384 completed preceding-stage cold swaps. Ignoring this factor's carry
misplaces all 3,888 records. The isolated factor fixture does **not** route
the full `3^64` high matrices of an 8×8 fibre.

The true-type sorter is also run on three separate changed-site roles, each
with 48 low types, and two enclosing rows. All returned opaque records are
changed before the inverse, which must restore them to their correct owners.
This is a small shape and ownership control, not the full astronomical stock.

For the rank-five `45 → 388` occurrence, split its actual projector
`5 = 3+2`, then its rank-three part as `3 = 1+2`, using the prescribed
3-adic frames. Across 192 deterministic full-ring cases over `Z/3`, `Z/9`
and `Z/27`, the #7868 weighted reversed-tail leaf matches an independently
calculated column action. There are 108 leading and 84 nonleading pivots;
the latter pay nine full-width child calls. This is a terminal control for
one derived line, not a proof of every generated 451-factor leaf.

The periodic control uses three actual chronological labels around the new
clock-876 MOVE and a deliberately **synthetic** two-factor subrule with ranks
1, 3, 1. At rank 67 it opens 320 raw frames, makes 1,648 leaves, and restores
512 private fields, including 192 nonzero temporary centres. These checks
test ordered cuts, replication and retirement in the source periodic engine.
An out-of-order raw label is rejected at the cut.
The tiny backend is not the real native caller; it cannot validate the full
changed 451-fold chronology or price.

## Conditional 451-factor guards

For this candidate the unchanged rank histogram independently supplies the
labelled product `4^224 * 8^2 * 64^225 = 16^451`. A paid rank-56 tensor
test checks the first two actual slab offsets at `0` and `11^451`. Thus the
intended strict-rule ambient, floor and paid ceiling are respectively
`A=134^451`, `k=16^451` and `r=11^451`, provided the full word and all
private zeros are physically compiled and paid.

Assume a **strict positive** changed 451-factor moment at `C < 97/25000`.
Let `X=4A`, `theta=32/37`, `b0=8192` and `p=71`. The replay checks all of
the following using exact integer powers:

```
r^37 < k^32
2^(5*8192) r^37 <= X^32
X < 2^3394                   2^(3394*97) < 9300^25000
97*(8192+3394) <= 71*25000
16*2*9300*4*32^71 <= 3*15*37^71
```

These are the periodic exit, shifted-base and damping guards for the quoted
compiler induction; the last gives `(16/15)*2*9300*theta^71 <= 3/4`.
They use `F(n) <= n^(1-C)(1+log2(n)/8192)^71` only **conditional on** its
strict moment, boundary, independent-owner and physical-cost hypotheses.
At `H=1202400000000000`, `N=2^H` and uniform loss `e=2.5e-12`, the budget is
`H e=3006` bits. Since `1+H/8192 < 2^38`, `5+71*38=2703 < 3006`;
the five reserved bits can pay the stated terminal multiplier. This is
funding arithmetic, not a completed seven-stage realization.

The finite source condition is **not met by this zero-net control** at the
trial needed for the requested price. #7888's independently directed
receipt bounds its original unstrictified signed moment at
`C=0.003879929048755` between
`-0.000386128646642167090303840263358142709337949` and
`-0.000386128646642167090303840263358142709337948`.
The candidate's equal complete histograms give the same signed moment.
Discarding targets or splitting paid ranks for `0 < 1-C < 1` cannot turn
that deficit into a strictly positive 451-factor certificate. The numerical
interval is authenticated source evidence, not independently recomputed by
this packet. It is not a claim about a different positive candidate.

## Stock, units and precision

Use `e` for ordinary **ternary digits**, not binary bits. The complex scalar
ring, Fourier fine primes and payload XOR do not become ternary. The
following bound assumes exactly seven actual q=3 reserves in the physical
ledger, stage widths at most `e`, a generated productive width `B<=N^105`,
and no other seed or conversion reserve. Any additional reserve must be
included separately. Write `u=log2(e)`, `x=2^(u/250)` and
`T=2414457831325314`. For each reserve, with
`w=ceil(e_i^(1/250))`,
`D=2+ceil(log_N(max(1,ceil(e_i/w))))` and
`W=B |GL_N(F_3)| 3^(N^2(w-1))`, the q-digit depth is bounded by
`D(ceil(log_3 B)+N^2 w)`. The hypotheses give

```
k_total <= 1 + 21 N^2 x (3 + u/H) < e/2        for u >= T.
```

At `T` the checked integer inequality `249T >= 250(2H+12)` gives
`2^(249T/250) >= 4096 N^2` and `3+T/H < 6`. The ratio of the left
exponential to `3+u/H` increases thereafter. The extra `1` pays final
integer rounding. This establishes an eventual **conditional depth bound**,
not the existence, separation, access tariff or restoration of those banks.
It includes all genuine high matrix digits; the streamed low-directory
removal does not make high fibres free.

If the original periodic path bound applies unchanged, its raw-context
number is at most `K=451(H+1)^2`; the replay verifies `856 K < N` by an
integer bit-length check. This numerical inequality does not transfer the
source's 140 fractional-bit and 428 mass-bit debts to the changed word:
the changed open contexts, exact normalizers, common grid, rounding,
full physical erasure, completed stage composition and outer caller still
need a proof. In particular the old qualifier/auditor's hard-coded word and
finite-supplier bindings must be replaced and rerun. A gain requires a
separately positive changed raw moment **and** a fully bound application.

## Replay

The portable package uses the Python 3.10+ standard library and one process.
Assertions are required; optimized Python is rejected. In this directory:

```
python3 -IB verify.py
```

It checks the source inventory, runs the fixture in a temporary directory,
compares the complete receipt with [EXPECTED.json](EXPECTED.json), and runs
fault controls. The 451-factor numerical arithmetic is exact integer
arithmetic; no astronomical supplier or giant stock is allocated. The
committed source files and inputs are preserved byte-for-byte and identified
in [SOURCE-PINS.json](SOURCE-PINS.json).
