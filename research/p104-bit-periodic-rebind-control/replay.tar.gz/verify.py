#!/usr/bin/env python3
"""Authenticate and replay the candidate-bound ternary control offline."""
from hashlib import sha1, sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys
import tempfile

if not __debug__:
    raise SystemExit('Run without -O: this verifier uses assertions.')

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'SOURCE-PINS.json').read_text())
for entry in manifest['files']:
    relative=Path(entry['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    b=(ROOT/relative).read_bytes()
    assert sha256(b).hexdigest()==entry['sha256'], entry['path']
    if 'git_blob' in entry:
        assert sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==entry['git_blob'],entry['path']
print('PASS_SOURCE_INVENTORY',len(manifest['files']),'files',flush=True)

with tempfile.TemporaryDirectory(prefix='bit-ternary-rebind-') as temporary:
    temp=Path(temporary)
    result=temp/'RESULT.json'
    run=subprocess.run([sys.executable,'-I','-B',str(ROOT/'rebind_fixture.py'),'--output',str(result)],
                       capture_output=True,text=True,check=True)
    assert result.read_bytes()==(ROOT/'EXPECTED.json').read_bytes()
    assert 'PASS_CANDIDATE_BOUND_TERNARY_AND_TAGGED_FINITE_CONTROLS' in run.stdout
    print('PASS_REPLAY matches EXPECTED.json',flush=True)

    copy=temp/'mutant'
    shutil.copytree(ROOT,copy,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    changed=copy/'inputs/ZERO-NET-WORD.json.gz'
    blob=bytearray(changed.read_bytes());blob[-1]^=1;changed.write_bytes(blob)
    bad=subprocess.run([sys.executable,'-I','-B',str(copy/'rebind_fixture.py'),
                        '--output',str(temp/'bad.json')],capture_output=True,text=True)
    assert bad.returncode != 0 and 'AssertionError' in bad.stderr and not (temp/'bad.json').exists()
    optimized=subprocess.run([sys.executable,'-I','-O','-B',str(ROOT/'rebind_fixture.py'),
                              '--output',str(temp/'optimized.json')],capture_output=True,text=True)
    assert optimized.returncode != 0 and 'Run without -O' in optimized.stderr
    print('PASS_MUTATED_CANDIDATE_AND_OPTIMIZED_MODE_REJECTIONS',flush=True)

print('NOT REPLAYED: full 451-fold supplier, precision tape, physical stock stack and outer application')
