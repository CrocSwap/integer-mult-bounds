# Source and contributor notice

This packet checks a restricted transfer condition and does not replace the
upstream constructions. New scripts, arithmetic and documentation were
prepared for Clear1nsight with substantial OpenAI Codex assistance and are
offered under Apache-2.0; see `LICENSE`.

The bundled `inputs/` files are byte-for-byte members of the sanitized
[#7863 archive](https://github.com/CrocSwap/integer-mult-bounds/blob/b3e4412fe01f07dc58305616fabf96345f49a781/research/p104-bit-451-factor-schedule/replay.tar.gz),
whose contributor notice credits Clear1nsight with substantial OpenAI Codex
assistance. That 451-factor construction reuses the complete BIT and rational
profiles from [#7830](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier).

The included Apache-2.0 #7830 review code and the older rational selector are
unchanged upstream source. Preserve their notices at
`inputs/source-7830/NOTICE` and `inputs/inputs/cache/parent/NOTICE`. They credit
Clear1nsight, Dugongue, Rohan Arun, Ali Romman, DreamingOfClouds, Jerry Chen,
zxv, SYLforge, Cinna Davis, Douglas Colkitt and the other cited predecessors
for their respective construction, caller, physical, and analytic work.

The [#7852 toolkit](https://github.com/CrocSwap/integer-mult-bounds/tree/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit)
is campaign context, credited to DreamingOfClouds with Claude Opus 5.5 via
Claude Code. No #7852 lower-bound theorem is asserted or used in this packet.
See `SOURCE-PINS.json` for the exact archive paths and hashes.
