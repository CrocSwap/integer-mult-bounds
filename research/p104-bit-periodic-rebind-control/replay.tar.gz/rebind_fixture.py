#!/usr/bin/env python3
"""Hash-bound 3-adic route and periodic controls for the zero-net BIT word.

Finite control only. Does not compile the 451-fold supplier, replay precision
or run an integer multiplication application. One process; no network access.
"""
import argparse
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from io import BytesIO
from itertools import islice, product
from math import lcm
from pathlib import Path
from random import Random
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'upstream'))
from ternary_frames import (covered_factors, frame_at_three, identity, inverse,
                            matcher, multiply, native_factors, projector,
                            residue, split, transpose)
from ternary_leaf import run_leaf, select_pivot
from factored_frames import apply_row, inverse_word, move_cover
from vendor.cover import high_stream, low_action, row_program
from streaming_routes import cold_swap_tape, high_route, right_route, type_route
from powered import Port, PoweredWord
from periodic import Job, make_planner, run
from tagged_sources import binary_ports

BASE = HERE/'inputs/BASELINE-WORD.json.gz'
CANDIDATE = HERE/'inputs/ZERO-NET-WORD.json.gz'
CALLER = HERE/'inputs/EFREE-CALLER.json.gz'
EXPECTED_BASE = 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
EXPECTED_CANDIDATE = 'e83abcf1a2bba96681ac14bc6c76eb4ff78db86f7677ea1f19c1b839cdf275a8'
EXPECTED_CANONICAL = '98fac9b1c809a3edb41fdaf140cee4656ffa6992e621c78be1ac0b982934f738'
EXPECTED_CALLER = '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
TRANSFER_SHA = '53637194798d33dff7bb2368536755875ccc9c61ba6c9385924a4beb747c7842'

def load(path, digest):
    b = path.read_bytes()
    assert sha256(b).hexdigest() == digest, path
    return json.loads(gzip.decompress(b))

def canonical_digest(x):
    return sha256(json.dumps(x, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def digest_rows(x):
    return canonical_digest(x)

def det_int(matrix):
    """Fraction-free determinant for the integral native source bases."""
    a = [list(row) for row in matrix]
    n, sign, previous = len(a), 1, 1
    for j in range(n-1):
        k = next((i for i in range(j, n) if a[i][j]), None)
        if k is None:
            return 0
        if j != k:
            a[j], a[k] = a[k], a[j]
            sign = -sign
        pivot = a[j][j]
        for i in range(j+1, n):
            for k in range(j+1, n):
                q, r = divmod(a[i][k]*pivot - a[i][j]*a[j][k], previous)
                assert r == 0
                a[i][k] = q
            a[i][j] = 0
        previous = pivot
    return sign * a[-1][-1]

def rank3(a):
    a = [[v % 3 for v in row] for row in a]
    n, m, r = len(a), len(a[0]), 0
    for j in range(m):
        k = next((i for i in range(r, n) if a[i][j]), None)
        if k is None:
            continue
        a[r], a[k] = a[k], a[r]
        scale = pow(a[r][j], -1, 3)
        a[r] = [x*scale % 3 for x in a[r]]
        for i in range(r+1, n):
            c = a[i][j]
            if c:
                a[i] = [(x-c*y) % 3 for x,y in zip(a[i],a[r],strict=True)]
        r += 1
        if r == n:
            break
    return r

def scaled(p):
    d = lcm(*(x.denominator for row in p for x in row))
    assert d % 3
    return [[int(d*x) for x in row] for row in p], d

def subtract(a,b):
    return [[x-y for x,y in zip(row,sub,strict=True)] for row,sub in zip(a,b,strict=True)]

def matrix_equal(a, b):
    return all(x == y for ar,br in zip(a,b,strict=True) for x,y in zip(ar,br,strict=True))

def derive_catalogue(old, new, caller):
    assert len(new['frames']) == 636 and old['frames'] == new['frames']
    assert old['start'] == new['start'] and old['final'] == new['final']
    mats, denoms, ranks = {}, {}, {}
    native_det, port_det = Counter(), Counter()
    for key, f in new['frames'].items():
        i = int(key)
        basis = transpose(f['B']+f['A'])
        determinant = det_int(basis)
        assert determinant and determinant % 3
        native_det[abs(determinant)] += 1
        p = projector(basis, f['dim'])
        assert matrix_equal(multiply(p,p),p)
        mats[i], denoms[i] = scaled(p)
        ranks[i] = f['dim']
    for i in range(111):
        left, right = new['start'][i], new['final'][i+111]
        basis = transpose(new['frames'][str(left)]['B'] + new['frames'][str(right)]['B'])
        determinant = det_int(basis)
        assert determinant and determinant % 3
        port_det[abs(determinant)] += 1
        assert ranks[left] == 1 and ranks[right] == 7
        assert matrix_equal(projector(basis,1), [[Fraction(z,denoms[left]) for z in row] for row in mats[left]])

    def pairs(w):
        m = [(row[2],row[3]) for row in w['program'] if row[0] == 'MOVE']
        h = list(zip(w['start'][222:],w['final'][222:],strict=True))
        return m,h
    oldmoves, oldhelp = pairs(old)
    moves, help_ = pairs(new)
    assert len(moves) == 2874 and len(help_) == 458
    assert Counter(tuple(sorted(x)) for x in oldmoves) == Counter(tuple(sorted(x)) for x in moves)
    assert oldhelp == help_
    unique = sorted({tuple(sorted(x)) for x in moves + help_})
    assert len(unique) == 2382
    for a,b in unique:
        if ranks[a] > ranks[b]:
            a,b = b,a
        x,y,dx,dy = mats[a],mats[b],denoms[a],denoms[b]
        assert ranks[a] < ranks[b]
        xy,yx = multiply(x,y),multiply(y,x)
        expected = [[v*dy for v in row] for row in x]
        assert xy == yx == expected
        diff = [[yy*dx-xx*dy for xx,yy in zip(xr,yr,strict=True)] for xr,yr in zip(x,y,strict=True)]
        d = dx*dy
        assert multiply(diff,diff) == [[d*v for v in row] for row in diff]
        assert rank3(diff) == ranks[b]-ranks[a]

    assert native_det == {1:28,4:326,16:250,64:32}
    assert port_det == {1:8,4:103}
    def rational(i):
        return [[Fraction(v,denoms[i]) for v in row] for row in mats[i]]
    actual = []
    for clock,owner,lower,upper in ((872,925,45,388),(876,926,45,295),(880,927,45,322)):
        assert new['program'][clock] == ['MOVE',owner,lower,upper]
        p = subtract(rational(upper),rational(lower))
        frame, rank = frame_at_three(p)
        assert rank == ranks[upper]-ranks[lower]
        assert matrix_equal(projector(frame,rank),p)
        assert det_int([[int(x) for x in row] for row in transpose(new['frames'][str(upper)]['B']+new['frames'][str(upper)]['A'])]) % 3
        actual.append((clock,owner,lower,upper,rank,p))
    return {'frames':636, 'frame_determinants':dict(sorted(native_det.items())),
            'joint_ports':111, 'port_determinants':dict(sorted(port_det.items())),
            'native_moves':len(moves), 'helper_differences':len(help_),
            'distinct_projector_pairs':len(unique), 'same_pair_multisets_as_baseline':True,
            'pairs_digest':digest_rows(unique)}, actual

def actual_tags(old, new, caller, actual):
    b0,b1 = binary_ports(old,caller),binary_ports(new,caller)
    assert (len(b1.targets),len(b1.paid)) == (20706,107460)
    assert Counter(x.rank for x in b0.targets) == Counter(x.rank for x in b1.targets)
    assert Counter(x.rank for x in b0.paid) == Counter(x.rank for x in b1.paid)
    assert len({x.tag for x in b1.targets}) == len(b1.targets)
    assert len({x.tag for x in b1.paid}) == len(b1.paid)
    assert all(1 <= x.rank <= b1.ambient for x in (*b1.targets,*b1.paid))
    clocks = [i for i,event in enumerate(caller['events']) if event[0]=='LOCAL']
    assert len(clocks) == 36
    for native,owner,_,_,rank,_ in actual:
        selected = [p for p in b1.paid if len(p.tag)==4 and p.tag[0]=='move' and p.tag[2]==native and p.tag[3]==owner]
        assert len(selected)==36 and {p.tag[1] for p in selected}==set(clocks)
        assert {p.rank for p in selected} == {rank}
    assert old['program'][872][0] != 'MOVE' and new['program'][872][0] == 'MOVE'
    changed = [(p.tag,p.rank) for p in b1.paid if len(p.tag)==4 and p.tag[2] in (872,876,880)]
    # Exact #7863 floor witness in the changed, regenerated target list.
    words=PoweredWord(134,b1.targets,b1.paid,451,16,10,11)
    ids = {k:next(i for i,p in enumerate(b1.targets) if p.rank == k) for k in (4,8,64)}
    witness=words.target((ids[4],)*224 + (ids[8],)*2 + (ids[64],)*225)
    assert witness.rank==16**451
    j = next(i for i,p in enumerate(b1.paid) if p.rank==56)
    pieces = tuple(islice(words.blocks((j,)*451),2))
    assert len(pieces)==2 and [z.rank for z in pieces] == [11**451]*2
    return b1, {'productive_count':len(b1.targets),'paid_count':len(b1.paid),
                'invoice_unchanged':True,'selected_changed_occurrences':len(changed),
                'changed_site_tags_sample':changed[:3],
                'candidate_paid_order_sha256':digest_rows([(p.tag,p.rank) for p in b1.paid]),
                'baseline_paid_order_sha256':digest_rows([(p.tag,p.rank) for p in b0.paid]),
                '451_floor_witness':'4^224 * 8^2 * 64^225 = 16^451',
                'paid_56_slab_cap':'11^451', 'slab_offsets':'0, 11^451'}

def regular_matrix(rng, n, modulus):
    a = identity(n)
    for _ in range(32):
        i,j=rng.sample(range(n),2)
        c=rng.randrange(modulus)
        a[i]=[(x+c*y)%modulus for x,y in zip(a[i],a[j],strict=True)]
    return a

def full_eight_matcher(actual):
    source,target=actual[1][-1],actual[2][-1]
    s=matcher(source,target)
    assert matrix_equal(multiply(source,s),multiply(s,target))
    inv=inverse(s)
    assert matrix_equal(multiply(s,inv),identity(8))
    word=row_program(s,3)
    # The factor has zero effect on low trits and a nonzero high carry.
    gate=('add',4,7,Fraction(3))
    assert gate in word
    for op in word:
        if op[0] in ('add','scale'):
            c=Fraction(op[-1])
            assert c.denominator % 3
            if op[0]=='scale':
                assert c.numerator % 3
    factors=word+tuple(inverse_word(word))
    coeffs=[Fraction(op[-1]) for op in factors if op[0] in ('add','scale')]
    scales=[Fraction(op[-1]) for op in factors if op[0]=='scale']
    assert max(abs(c.numerator) for c in coeffs)<=20 and max(c.denominator for c in coeffs)<=20
    assert max(abs(c.numerator) for c in scales)<=20 and max(c.denominator for c in scales)<=20
    rng=Random(7868451)
    samples=0
    for digits in (1,2,3,4):
        mod=3**digits
        for _ in range(64):
            g=regular_matrix(rng,8,mod)
            expected=[[residue(y,mod) for y in row] for row in multiply(g,s)]
            assert [apply_row(word,row,mod) for row in g] == expected
            assert [apply_row(tuple(inverse_word(word)),row,mod) for row in expected] == g
            low=[[x%3 for x in row] for row in g]
            h,carry=low_action(low,s,3)
            if digits>1:
                side=3**(digits-1)
                x=[[z//3 for z in row] for row in g]
                recombined=multiply(x,s)
                high=[[residue(recombined[i][j]+carry[i][j],side) for j in range(8)] for i in range(8)]
                assert [[h[i][j]+3*high[i][j] for j in range(8)] for i in range(8)] == expected
            samples+=1
    return s,word,{'source':'45->295','target':'45->322','rank':3,
                   'factor_count':len(word),'factor_sha256':digest_rows([list(map(str,x)) for x in word]),
                   'matrix':[[str(x) for x in row] for row in s],
                   'ordered_factors':[list(map(str,x)) for x in word],
                   'max_abs_numerator_forward_and_inverse':max(abs(c.numerator) for c in coeffs),
                   'max_denominator_forward_and_inverse':max(c.denominator for c in coeffs),
                   'scale_max_abs_numerator_forward_and_inverse':max(abs(c.numerator) for c in scales),
                   'scale_max_denominator_forward_and_inverse':max(c.denominator for c in scales),
                   'eight_dimensional_full_ring_sample_cases':samples,
                   'precise_carry_factor':['add',4,7,'3'],
                   'old_identity_as_matcher_rejected':not matrix_equal(source,target)}

def changed_gate_stream():
    # The exact (4,7) factor of the genuine matcher, restricted to its two
    # participating coordinates: target 0 += 3 * source 1. Exhaust all 2x2
    # regular low matrices and all high matrices for w=2.
    s=[[1,0],[3,1]]
    word=(('add',0,1,Fraction(3)),)
    sinv=inverse(s)
    invword=tuple(inverse_word(word))
    count=records=swap_calls=0
    omitted_carry_mismatches=0
    factored_fibres=[]
    for flat in product(range(3),repeat=4):
        low=[list(flat[:2]),list(flat[2:])]
        if not ((flat[0]*flat[3]-flat[1]*flat[2])%3):
            continue
        out,carry=low_action(low,s,3)
        assert out==low
        before=list(range(3**4))
        fact_low, got = move_cover(before,low,word,2)
        assert fact_low == out and got == high_stream(before,s,3,2,carry)
        assert move_cover(got,out,invword,2)==(low,before)
        # Actual bounded-head upstream tape implementation and preceding-stage
        # cold swaps, charged with their real field/gap/suffix parameters.
        source,dest=BytesIO(bytes(before)),BytesIO()
        calls=[]
        def swap(*args):
            calls.append(tuple(args[2:]))
            return cold_swap_tape(*args)
        high_route(source,dest,low,2,1,word,swap)
        assert list(dest.getvalue())==got
        swap_calls+=len(calls)
        for i,xs in enumerate(product(range(3),repeat=4)):
            g=[[low[r][c]+3*xs[2*r+c] for c in range(2)] for r in range(2)]
            h=[[residue(v,9) for v in row] for row in multiply(g,s)]
            address=0
            for row in h:
                for z in row:
                    address=3*address+z//3
            assert got[address]==i
        omitted_carry_mismatches+=sum(a!=b for a,b in zip(got,before,strict=True))
        factored_fibres.append(got)
        records+=len(before)
        count+=1
    assert count==48 and swap_calls>0 and omitted_carry_mismatches>0
    # Feed all 48 actual low classes and all high records through the complete
    # padded-cube router and then return arbitrary complete child contents.
    data=b''.join(i.to_bytes(2,'little') for i in range(records))
    expected=b''.join((81*low_index + high_index).to_bytes(2,'little')
                      for low_index,fibre in enumerate(factored_fibres) for high_index in fibre)
    full_out=BytesIO()
    full_calls=[]
    def predecessor(*args):
        full_calls.append(tuple(args[2:]))
        return cold_swap_tape(*args)
    right_route(BytesIO(data),full_out,2,2,1,2,word,previous_swap=predecessor)
    assert full_out.getvalue()==expected and len(full_calls)==192
    returned=bytes(x ^ 0xa5 for x in expected)
    full_back=BytesIO()
    right_route(BytesIO(returned),full_back,2,2,1,2,invword,previous_swap=predecessor)
    assert full_back.getvalue()==bytes(x ^ 0xa5 for x in data) and len(full_calls)==384

    # Three distinct changed site roles, 48 true lows each, two enclosing rows.
    # The source's five-spool type sorter must preserve each opaque return.
    types,rows=3*count,2
    split_in=b''.join(i.to_bytes(2,'little') for i in range(types*rows))
    type_out=BytesIO()
    type_route(BytesIO(split_in),type_out,rows,types,2)
    type_expected=b''.join((r*types+t).to_bytes(2,'little') for t in range(types) for r in range(rows))
    assert type_out.getvalue()==type_expected
    changed=bytes(x ^ 0x5a for x in type_expected)
    type_back=BytesIO()
    type_route(BytesIO(changed),type_back,rows,types,2,inverse=True)
    assert type_back.getvalue()==bytes(x ^ 0x5a for x in split_in)
    return {'factor_origin':'actual matcher add column 4 by 3 times column 7',
            'regular_low_matrices':count,'complete_high_records':records,
            'cold_predecessor_swaps':swap_calls,'full_padded_cube_round_trip_predecessor_swaps':len(full_calls),
            'type_split_owners':3,'type_split_lows_per_owner':48,'type_split_rows':rows,
            'missing_carry_record_mismatches':omitted_carry_mismatches,
            'scope':'full two-coordinate fibre for one genuine 8D factor, not the full 8D route'}

def reference_leaf(u,v,weights,head,tail,mod):
    n,width=len(u),len(weights)
    h,t=[r.copy() for r in head],[r.copy() for r in tail]
    for j,a in enumerate(weights):
        x=[pow(a[i],-1,mod)*head[i][j] for i in range(n)]
        y=[tail[n-1-i][width-1-j] for i in range(n)]
        d=sum(c*(r-l) for c,r,l in zip(v,y,x,strict=True))
        for i in range(n):
            h[i][j]=(head[i][j]+a[i]*u[i]*d)%mod
            t[n-1-i][width-1-j]=(y[i]-u[i]*d)%mod
    return h+t

def actual_leaf(actual):
    p=actual[0][-1]
    left,right=split(p,3)
    one,rest=split(left,1)
    assert all(multiply(a,b)==[[0]*8 for _ in range(8)] for a,b in ((left,right),(right,left),(one,rest),(rest,one)))
    assert matrix_equal([[a+b for a,b in zip(x,y,strict=True)] for x,y in zip(left,right,strict=True)],p)
    u0,v0=native_factors(one)
    rng=Random(4517868)
    pivots=Counter()
    cases=0
    for digits in (1,2,3):
        m=3**digits
        units=[i for i in range(m) if i%3]
        for k in range(64):
            g=regular_matrix(rng,8,m)
            u,v=covered_factors((u0,v0),g,digits)
            assert sum(x*y for x,y in zip(u,v,strict=True))%m==1
            width=1+k%4
            weights=[[rng.choice(units) for _ in range(8)] for _ in range(width)]
            head=[[rng.randrange(m) for _ in range(width)] for _ in range(8)]
            tail=[[rng.randrange(m) for _ in range(width)] for _ in range(8)]
            got,child=run_leaf(u,v,weights,head,tail,digits)
            pivot=select_pivot(u,v)
            assert got==reference_leaf(u,v,weights,head,tail,m)
            assert child==(width,)*(1 if pivot==0 else 9)
            pivots['nonleading' if pivot else 'leading']+=1
            cases+=1
    assert pivots['leading'] and pivots['nonleading']
    return {'changed_move_clock':872,'original_rank':5,'splits':'5=3+2; 3=1+2',
            'full_ring_cases':cases,'pivots':dict(pivots),'child_widths':'one or nine equal full-width exchanges'}

class Toy:
    """A tagged subrule control, not an interpreter of the real BIT caller."""
    def __init__(self, world, word):
        self.world,self.word=world,word
        self.data,self.guard={},{}
        self.serial=self.private=self.live_centres=self.raw_frames=self.leaves=0
    def fresh(self,exemplar,rank,tag):
        assert exemplar.owner in self.data and rank <= self.world
        key=self.serial;self.serial+=1;self.private+=1
        self.data[key]=[0]*self.world;self.guard[key]=tag
        return Job(key,tuple(range(rank)))
    def zero(self,exemplar):
        j=self.fresh(exemplar,len(exemplar.axes),('padding',))
        return Job(j.owner,exemplar.axes)
    def retire(self,job):
        assert job.owner in self.guard and not any(self.data.pop(job.owner))
        del self.guard[job.owner]
    retire_zero=retire
    def raw(self,ports,columns):
        ((t0,small),(t1,large))=ports
        assert (t0,t1)==tuple(p.tag for p in self.word.targets)
        assert len(small.axes)==columns and len(large.axes)==4*columns
        assert small.owner != large.owner
        self.raw_frames+=1
        private=self.fresh(large,len(large.axes),('raw-centre',))
        self.data[private.owner],self.data[large.owner]=self.data[large.owner],self.data[private.owner]
        self.live_centres+=int(any(self.data[private.owner]))
        actual=Job(private.owner,large.axes)
        yield self.word.paid[0].tag,small
        yield self.word.paid[1].tag,actual.select(range(3*columns))
        yield self.word.paid[2].tag,actual.select(range(3*columns,4*columns))
        self.data[private.owner],self.data[large.owner]=self.data[large.owner],self.data[private.owner]
        self.retire(private)
    def native(self,fields,columns):
        return self.word.native(fields,columns,self)
    def leaf(self,job):
        self.leaves+=1
        i,=job.axes
        self.data[job.owner][i]= -self.data[job.owner][i]%3

class WrongChronologyToy(Toy):
    def raw(self,ports,columns):
        iterator=super().raw(ports,columns)
        _,job=next(iterator)
        yield self.word.paid[1].tag,job
        yield from iterator

def periodic_control(bit):
    middle=next(i for i,p in enumerate(bit.paid) if len(p.tag)==4 and p.tag[0]=='move' and p.tag[2:]==(876,926))
    first=next(bit.paid[i] for i in reversed(range(middle)) if bit.paid[i].rank==1)
    last=next(p for p in bit.paid[middle+1:] if p.rank==1)
    targets=tuple(next(p for p in bit.targets if p.rank==r) for r in (1,4))
    paid=(first,bit.paid[middle],last)
    word=PoweredWord(4,targets,paid,2,3,2,2)
    rule=word.rule()
    n=67
    planner=make_planner(rule);p=planner(n);machine=Toy(n,word)
    fields=[Job(~i,tuple((j+i)%n for j in range(n))) for i in range(p.width)]
    rng=Random(88404)
    original={f.owner:[rng.randrange(3) for _ in range(n)] for f in fields}
    machine.data.update({o:x.copy() for o,x in original.items()})
    run(rule,n,fields,machine,planner=planner)
    assert machine.leaves==p.leaves and not machine.guard and machine.live_centres>0
    assert machine.data=={o:[-x%3 for x in values] for o,values in original.items()}
    wrong=WrongChronologyToy(n,word)
    wrong.data.update({o:x.copy() for o,x in original.items()})
    try:
        run(rule,n,fields,wrong,planner=planner)
    except ValueError as exc:
        assert 'Wrong chronological raw request or extent' in str(exc)
    else:
        raise AssertionError('A wrong chronological exit label was accepted')
    return {'labels':[list(x.tag) for x in paid], 'ranks':[x.rank for x in paid],
            'test_root_rank':n,'power':2,'finite_rule_targets':len(rule.targets),
            'finite_rule_chronological_exits':len(rule.paid), 'root_width':p.width,
            'raw_frames':machine.raw_frames,'leaf_calls':machine.leaves,
            'private_fields':machine.private,'nonzero_private_centre_visits':machine.live_centres,
            'out_of_order_raw_label_rejected':True,
            'scope':'chosen occurrence labels on a synthetic subrule; not the full native BIT program'}

def funding_guard():
    # Conditional: an actual positive strict 451-factor moment is required.
    # These are the periodic compiler's shifted-log guards for the unchanged
    # ambient, cutoff and floor, independently tested using integer powers.
    v=451
    A=134**v;X=4*A;r=11**v;k=16**v
    assert X < 2**3394 and r**37 < k**32
    assert 2**(5*8192)*r**37 <= X**32
    assert 2**(3394*97) < 9300**25000
    assert 97*(8192+3394) <= 71*25000
    assert 16*2*9300*4*32**71 <= 3*15*37**71
    H=1202400000000000
    assert 8192+H < 8192*2**38
    assert 5+71*38 < 3006
    return {'premise':'a positive strict 451-factor raw moment at C < 97/25000',
            'ambient':'134^451','elementary_below':'4 * 134^451',
            'X_log2_ceiling':X.bit_length(),'rank_ceiling':'11^451','productive_floor':'16^451',
            'theta':'32/37','shift':8192,'log_power':71,'X_to_C_upper':9300,
            'inequalities':'exit guard, base guard, damping and 5+71*38<3006 all exact',
            'loss':'e=2.5e-12 gives H*e=3006 bits at H=1202400000000000',
            'scope':'funding arithmetic only; this control has a negative source moment at the proposed target'}

def stock_guard():
    # Seven explicitly assumed, equal-geometry reserves, in ternary digits.
    # Any additional seed/nested reserve or larger intermediate widths must be
    # added to the ledger. This does not construct such a ledger.
    H=1202400000000000
    T=(250*(2*H+12)+248)//249
    assert 249*T >= 250*(2*H+12)
    assert T < 3*H
    assert (856*451*(H+1)**2).bit_length() < H
    return {'N':'2^1202400000000000','seven_stage_conditional_log2_e':T,
            'units':'e counts ternary digits, not bits or decimal digits',
            'inequality':'k <= 1+21 N^2 2^(u/250)(3+u/H) < e/2 for u=log2(e)>=T',
            'guard_856K_bit_length':(856*451*(H+1)**2).bit_length(),
            'guard_scope':'conditional on seven listed 451-stage reserves, B<=N^105, stage widths <=e, and no extra seed reserve'}

def main():
    if not __debug__:
        raise SystemExit('Run without -O: this verifier uses assertions.')
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=HERE/'RESULT.json')
    output=parser.parse_args().output
    old,new,caller=load(BASE,EXPECTED_BASE),load(CANDIDATE,EXPECTED_CANDIDATE),load(CALLER,EXPECTED_CALLER)
    transfer_raw=(HERE/'inputs/FINITE-TRANSFER-EXPECTED.json').read_bytes()
    assert sha256(transfer_raw).hexdigest()==TRANSFER_SHA
    signed=json.loads(transfer_raw)['old_BIT']['signed_margin']
    assert signed == ['-0.000386128646642167090303840263358142709337949',
                      '-0.000386128646642167090303840263358142709337948']
    assert canonical_digest(new)==EXPECTED_CANONICAL and old!=new
    catalogue,actual=derive_catalogue(old,new,caller)
    bit,tags=actual_tags(old,new,caller,actual)
    s,word,matcher_receipt=full_eight_matcher(actual)
    del s,word
    receipt={'status':'PASS_CANDIDATE_BOUND_TERNARY_AND_TAGGED_FINITE_CONTROLS',
             'candidate_gzip_sha256':EXPECTED_CANDIDATE,'candidate_canonical_sha256':EXPECTED_CANONICAL,
             'baseline_gzip_sha256':EXPECTED_BASE,'caller_gzip_sha256':EXPECTED_CALLER,
             'actual_changed_native_sites':[list(x[:5]) for x in actual],
             'catalogue':catalogue,'source_tags':tags,'matcher':matcher_receipt,
             'unchanged_source_moment_at_0.003879929048755':signed,
             'streamed_factor':changed_gate_stream(),'leaf':actual_leaf(actual),
             'periodic_control':periodic_control(bit),'conditional_funding':funding_guard(),
             'conditional_stock':stock_guard(),
             'not_established':['full changed 451-product execution', 'full-dimensional stock ledger and restoration',
                                'changed-word precision-tape refinement', 'seven completed funded stages',
                                'changed qualifier and auditor', 'outer integer application or new kappa']}
    output.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n')
    print(receipt['status'])
    for k in ('catalogue','source_tags','matcher','streamed_factor','leaf','periodic_control','conditional_funding','conditional_stock'):
        print(k, json.dumps(receipt[k],sort_keys=True))
    print('NOT COMPLETE: precision, full stock, consumer and outer application')

if __name__=='__main__':
    main()
