# Attribution

This control and its new proof text were prepared for Clear1nsight with
substantial OpenAI Codex assistance, under Apache-2.0; see [LICENSE](LICENSE).
They study a zero-gain control and do not replace the upstream construction.

Ali Romman authored the finite-order compiler, ternary native realization,
factored matcher, streamed low machine and physical leaf used here. The
unchanged files under `upstream/` come from his [#7868 pinned head](https://github.com/CrocSwap/integer-mult-bounds/tree/3f7c3c1f2a9a0963736562037e01fe41aec46b8c/research/bounded-general-multiplier),
which includes substantial OpenAI Codex assistance. Preserve its
[original notice](upstream/NOTICE.md), [flow notice](upstream/FLOW-NOTICE.md),
and the [grade-14](upstream/vendor/grade14-NOTICE.md),
[iterated-returns](upstream/vendor/iterated-returns-NOTICE),
[paired caller](upstream/vendor/paired-NOTICE), and
[mixed caller](upstream/vendor/mixed-NOTICE) contributor notices.

Clear1nsight and credited predecessors supplied the original BIT word,
36-call receipt, 451-factor arithmetic and zero-net candidate. Their notices
are retained as [zero-net notice](inputs/NOTICE-ZERO-NET) and
[finite-transfer notice](inputs/NOTICE-FINITE-TRANSFER.md).
Source and artifact byte hashes are listed in [SOURCE-PINS.json](SOURCE-PINS.json).
