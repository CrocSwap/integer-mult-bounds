def replay(mode='F2', direction=1, bits=24, mutation=None):
    major = mode == 'bound'
    binary = mode == 'F2'
    v = W.v
    unit = lambda i: i
    target_frames = [None] * v
    target_paths = [[] for _ in range(v)]
    center_reads = []
    target_hist = Counter()
    aggregation_active = [True] * len(agg)
    aggregation_read = [set() for _ in agg]
    aggregation_restores = []
    aggregation_pivot_reads = 0
    rank_active = set(range(len(rankgroups)))
    rank_seen = [set() for _ in rankgroups]
    rank_restores = []
    rank_skipped = 0
    echelon_active = set(range(len(echelon)))
    echelon_seen = [set() for _ in echelon]
    echelon_restores = []
    echelon_reads = 0

    def target_move(t, f):
        move(v + t, f)
        previous = target_frames[t]
        assert previous is None or C.sub(previous, f), ('actual target chronology', t, previous, f)
        assert all((W.module.dot(C.cov[t], b) == 0 for b in C.B[f])), ('actual target cap', t, f)
        d = C.dimf[f] - (0 if previous is None else C.dimf[previous])
        assert d >= 0
        if d:
            target_hist[d] += 1
        target_frames[t] = f
        target_paths[t].append(f)
    X0 = [unit(i) for i in range(v)]
    Y0 = [unit(v + i) for i in range(v)]
    Z0 = {r: unit(idx[r]) for r in regs}
    x = X0[:]
    y = Y0[:]
    z = Z0.copy()
    top = 1
    done = []

    def track(value):
        nonlocal top
        if major:
            top = max(top, value)
        return value

    def value(s):
        s = W.phys[s]
        return x[borrow[s]] if s in borrow else z[s]

    def assign(s, val):
        s = W.phys[s]
        if s in borrow:
            x[borrow[s]] = track(val)
        else:
            z[s] = track(val)
    source_paths = {role: [W.w['source_frame'][r['source']], r['mix_frame']] for role, r in extra_byrole.items()}
    pair_dirty_paths = {r: [zero] for r in pair_bydirty}

    def source_move(s, f):
        move(physical_id(s), f)
        role = W.phys[s]
        if role in pair_dirty_paths:
            assert C.sub(pair_dirty_paths[role][-1], f), ('paired dirty chronology', role, pair_dirty_paths[role][-1], f)
            pair_dirty_paths[role].append(f)
        if role not in source_paths:
            return
        assert C.sub(source_paths[role][-1], f), ('orderedsource chronology', s, role, source_paths[role][-1], f)
        source_paths[role].append(f)
    responses = W.adjoint() if mutation == 'old_adjoint' else adj

    def aggregate_restore(k, trigger):
        if not aggregation_active[k]:
            return
        group = agg[k]
        pivot = group['pivot']
        assert aggregation_read[k] == set(group['roles']), ('early aggregation inverse', k, trigger, aggregation_read[k])
        for t in group['targets']:
            target_move(t, group['frame'])
        if mutation != 'omit_aggregation_inverse' or k != 39:
            for t in group['targets']:
                if t != pivot:
                    y[t] = track(physical_add(y[t], 1, y[pivot], group['frame'], 'equal_inverse'))
        aggregation_active[k] = False
        aggregation_restores.append(dict(group=k, before_role=trigger, frame=group['frame']))

    def rank_restore(k, trigger):
        group = rankgroups[k]
        assert k in rank_active and rank_seen[k] == group['roles']
        for t in group['targets']:
            target_move(t, group['frame'])
        if mutation != 'omit_rank_inverse' or k != 0:
            for t, cs in group['dependent'].items():
                for p, c in cs.items():
                    y[t] = track(physical_add(y[t], c, y[p], group['frame'], 'rank_inverse'))
        rank_active.remove(k)
        rank_restores.append(dict(group=k, before_role=trigger, frame=group['frame']))

    def echelon_restore(k, trigger):
        group = echelon[k]
        assert echelon_seen[k] == group['roles']
        for t in group['targets']:
            target_move(t, group['frame'])
        if mutation != 'omit_echelon_inverse' or k != 0:
            for t, p, c in reversed(group['moves']):
                y[t] = track(physical_add(y[t], -c, y[p], group['frame'], 'echelon_inverse'))
        echelon_active.remove(k)
        echelon_restores.append(dict(group=k, before_role=trigger, frame=group['frame']))

    def read(s):
        nonlocal aggregation_pivot_reads, rank_skipped, echelon_reads
        if s in pair_byalias:
            if mutation == 'subtract_paired_alias' and s == next(iter(pair_byalias)):
                for t, c in adj[s].items():
                    y[t] = track(physical_add(y[t], -direction * c, value(s), W.gauge[s]['frame'], 'paired_alias_corruption'))
            return
        if s in fresh:
            if mutation == 'omit_transformed_source_read' and s == next(iter(fresh)):
                return
            for t, c in fresh[s]['transformed_response'].items():
                t = int(t)
                source_move(s, W.gauge[s]['frame'])
                target_move(t, W.gauge[s]['frame'])
                y[t] = track(physical_add(y[t], -direction * c, value(s), W.gauge[s]['frame'], 'fresh_source_read'))
            return
        echelon_skip = set()
        if s in W.gauge:
            for k, group in enumerate(echelon):
                if k not in echelon_active:
                    continue
                if s not in group['roles']:
                    if set(responses[s]) & set(group['targets']):
                        echelon_restore(k, s)
                    continue
                echelon_seen[k].add(s)
                echelon_skip.update(group['targets'])
                for t, a in group['response'].items():
                    c = a.get(s, 0)
                    if not c:
                        continue
                    if mutation == 'flip_echelon_sign' and k == 0 and (c < 0):
                        c = -c
                    source_move(s, W.gauge[s]['frame'])
                    target_move(t, W.gauge[s]['frame'])
                    y[t] = track(physical_add(y[t], -direction * c, value(s), W.gauge[s]['frame'], 'echelon_read'))
                    echelon_reads += 1
        if s in W.gauge:
            for k in sorted({rankowner[t] for t in responses[s] if t in rankowner}):
                if k not in rank_active:
                    continue
                if s not in rankgroups[k]['roles']:
                    rank_restore(k, s)
                else:
                    rank_seen[k].add(s)
        if mutation == 'omit_gauge_compensation' and s == new_gauge_selection[-1]['role']:
            return
        if mutation == 'omit_extra_compensation' and s == extra_selection[0]['role']:
            return
        grouped = role_groups.get(s, [])
        for k in sorted({target_group[t] for t in responses[s] if t in target_group}) if s in W.gauge else []:
            if k not in grouped:
                aggregate_restore(k, s)
        skipped = set()
        for k in grouped:
            group = agg[k]
            pivot = group['pivot']
            assert aggregation_active[k]
            assert set(group['targets']) <= set(responses[s]) and len({responses[s][t] for t in group['targets']}) == 1
            c = responses[s][pivot]
            source_move(s, read_frames[s, k])
            target_move(pivot, read_frames[s, k])
            y[pivot] = track(physical_add(y[pivot], -direction * c, value(s), read_frames[s, k], 'equal_read'))
            if mutation == 'repeat_aggregation_read' and k == 39:
                t = next((t for t in group['targets'] if t != pivot))
                target_move(t, read_frames[s, k])
                y[t] = track(physical_add(y[t], -direction * c, value(s), read_frames[s, k], 'equal_corruption'))
            skipped.update(group['targets'])
            aggregation_read[k].add(s)
            aggregation_pivot_reads += 1
        for t, c in responses[s].items():
            if t in skipped or t in echelon_skip:
                continue
            rk = rankowner.get(t)
            if s in W.gauge and rk in rank_active and (t in rankgroups[rk]['dependent']):
                rank_skipped += 1
                if mutation != 'repeat_rank_read' or rk != 0:
                    continue
            if s in W.gauge:
                source_move(s, W.gauge[s]['frame'])
                target_move(t, W.gauge[s]['frame'])
            else:
                assert target_frames[t] is None, 'initial correction leaves target atD0'
            y[t] = track(physical_add(y[t], -direction * c, value(s), W.gauge[s]['frame'] if s in W.gauge else ZERO, 'dirty_read'))

    def gate(i, sign):
        a, b, _ = W.ops[i]
        if sign == 1:
            source_move(a, W.opframe[i])
            source_move(b, W.opframe[i])
        assign(a, physical_add(value(a), sign, value(b), W.opframe[i] if sign == 1 else FULL, 'forward_gate' if sign == 1 else 'cleanup_gate'))
    for s in range(W.R):
        if s not in W.gauge and s not in borrow and (s not in removed):
            read(s)
    for n, s in W.source.items():
        assign(s, physical_add(value(s), 1, x[n], W.w['source_frame'][n], 'inject'))
    for r in gauge_selection:
        if mutation == 'omit_transformed_source_mix' and r is next(iter(fresh.values())):
            continue
        if mutation == 'omit_extra_mix' and r is extra_selection[0]:
            continue
        if mutation != 'omit_gauge_mix' or r is not new_gauge_selection[-1]:
            x[r['partner']] = track(physical_add(x[r['partner']], 1, x[r['source']], kpair[r['source']]['mix_frame'], 'gauge_mix'))

    def forward(i):
        if i not in omitted:
            gate(i, 1)
            done.append(i)
    for k in schedule['center_prefix_events']:
        event = schedule['events'][k]
        i = event['op']
        if event['kind'] == 'early_mix':
            r = early[i]
            a, b = (r['partner'], r['source'])
            if mutation != 'omit_early_mix' or r is not selection[0]:
                x[a] = track(physical_add(x[a], 1, x[b], kpair[b]['mix_frame'], 'partner_mix'))
        else:
            forward(i)
    for j, (r, s) in enumerate(zip(W.g['roots'], W.w['rootroles'])):
        if r['kind'] == 'center':
            center_begin(value(s), W.w['root_frame'][j])
            for t in r['targets']:
                assert all((f is None for f in target_frames)), 'copied centers scatter before any nonzero target movement'
                center_reads.append((s, t))
                y[t] = track(physical_add(y[t], direction, value(s), ZERO, 'center'))
            center_end()
    for k, group in enumerate(echelon):
        assert all((target_frames[t] is None for t in group['targets']))
        if mutation != 'omit_echelon_setup' or k != 0:
            for t, p, c in group['moves']:
                y[t] = track(physical_add(y[t], c, y[p], ZERO, 'echelon_setup'))
    for k, group in enumerate(rankgroups):
        assert all((target_frames[t] is None for t in group['targets']))
        if mutation != 'omit_rank_setup' or k != 0:
            for t, cs in group['dependent'].items():
                for p, c in cs.items():
                    y[t] = track(physical_add(y[t], -c, y[p], ZERO, 'rank_setup'))
    for k, group in enumerate(agg):
        assert all((target_frames[t] is None for t in group['targets'])), 'aggregation setup after all D0 center scatters'
        if mutation != 'omit_aggregation_setup' or k != 39:
            for t in group['targets']:
                if t != group['pivot']:
                    y[t] = track(physical_add(y[t], -1, y[group['pivot']], ZERO, 'equal_setup'))
    for e in terminal:
        assert all((target_frames[t] is None for t in e['targets'])), 'terminal setup afterD0center scatter'
        for t in e['targets']:
            if t != e['pivot']:
                y[t] = track(physical_add(y[t], -1, y[e['pivot']], ZERO, 'terminal_pre'))
    for r in pair_selection:
        b, f = (r['aliased_role'], r['mix_frame'])
        for a, c in r['retained_dirty_coefficients'].items():
            source_move(a, f)
            source_move(b, f)
            if mutation == 'omit_sparse_anchor' and r is pair_selection[14] and (a == next(iter(r['retained_dirty_coefficients']))):
                continue
            if mutation == 'wrong_sparse_sign' and r is pair_selection[14] and (a == next(iter(r['retained_dirty_coefficients']))):
                c = -c
            if mutation != 'omit_pair_initialization' or r is not pair_selection[0]:
                assign(a, physical_add(value(a), c, value(b), f, 'anchor_inject'))
    for j, i in enumerate(W.rest):
        for s in at[j]:
            if mutation != 'late_phase1_gauge' or s not in new_phase_roles:
                read(s)
        if mutation == 'late_phase1_gauge' and j == 168:
            for s in sorted(new_phase_roles):
                read(s)
        if i in bywrite:
            e = bywrite[i]
            a, b, n = W.ops[i]
            source_move(b, W.opframe[i])
            target_move(e['pivot'], W.opframe[i])
            y[e['pivot']] = track(physical_add(y[e['pivot']], direction, value(b), W.opframe[i], 'terminal_write'))
        else:
            forward(i)
        if i in afterwrite:
            e = afterwrite[i]
            for t in e['targets']:
                target_move(t, e['root_frame'])
                if t != e['pivot']:
                    y[t] = track(physical_add(y[t], 1, y[e['pivot']], e['root_frame'], 'terminal_post'))
    for s in at[len(W.rest)]:
        read(s)
    assert not any(aggregation_active), 'all quotient inverses precede original side/K reads'
    assert not rank_active, 'rank quotient inverses precede side/K reads'
    assert not echelon_active, 'echelon inverses precede side/K reads'
    for j, (r, s) in enumerate(zip(W.g['roots'], W.w['rootroles'])):
        if r['kind'] == 'side' and j not in deletedroots:
            for k in sorted({target_group[t] for t in r['targets'] if t in target_group}):
                aggregate_restore(k, ('root', j))
            source_move(s, W.w['root_frame'][j])
            for t in r['targets']:
                target_move(t, W.w['root_frame'][j])
                y[t] = track(physical_add(y[t], direction, value(s), W.w['root_frame'][j], 'side_root'))
        for e in deliveries[j]:
            a, b = (e['carrier'], e['passive'])
            if b not in by_source:
                x[a] = track(physical_add(x[a], 1, x[b], kpair[b]['mix_frame'], 'partner_mix'))
            for k in sorted({target_group[t] for t in e['receivers'] if t in target_group}):
                aggregate_restore(k, ('K', j))
            for t in e['receivers']:
                target_move(t, e['deliver_frame'])
                y[t] = track(physical_add(y[t], direction, x[a], e['deliver_frame'], 'partner_delivery'))
    assert not any(aggregation_active), 'all target inverses completed beforecleanup'
    for e in W.k['entries']:
        if e['passive'] not in by_source:
            x[e['carrier']] = track(physical_add(x[e['carrier']], -1, x[e['passive']], FULL, 'partner_cleanup'))
    if mutation == 'undo_before_restore':
        for e in W.k['entries']:
            if e['passive'] in by_source:
                x[e['carrier']] = track(physical_add(x[e['carrier']], -1, x[e['passive']], FULL, 'partner_cleanup'))
    for role in source_paths:
        source_move(role, W.w['full_frame'])
    for role in pair_dirty_paths:
        source_move(role, W.w['full_frame'])
    for i in reversed(done):
        gate(i, -1)
    for r in reversed(pair_selection):
        b = r['aliased_role']
        for a, c in reversed(list(r['retained_dirty_coefficients'].items())):
            c = -c
            if mutation == 'wrong_pair_restore_sign' and r is pair_selection[0]:
                c = -c
            if mutation != 'omit_pair_restoration' or r is not pair_selection[0]:
                assign(a, physical_add(value(a), c, value(b), FULL, 'anchor_restore'))
    if mutation != 'undo_before_restore':
        for e in W.k['entries']:
            if e['passive'] in by_source:
                x[e['carrier']] = track(physical_add(x[e['carrier']], -1, x[e['passive']], FULL, 'partner_cleanup'))
    for n, s in W.source.items():
        assign(s, physical_add(value(s), -1, x[n], FULL, 'uninject'))
    return dict(center_reads=len(center_reads))
