#!/usr/bin/env python3
"""Exact global event attribution for the #7869 real Q=0 words.

One event has one role across all of its stages; each role/stage cell must be
covered exactly once. For strict attribution both prefix-inverse column v and
prefix row w must have a nonzero entry at that role. The search branches ONLY
on all multi-stage events; once fixed it exhaustively matches singleton events
stage by stage. Input source events are 0-indexed, stages remain 1-indexed.
"""
import argparse, copy, hashlib, importlib.util, itertools, json, os
from fractions import Fraction as F
from pathlib import Path

SRC = Path(os.environ.get('P104_GUIDANCE_SOURCE', str(Path(__file__).resolve().parent / 'source')))
spec = importlib.util.spec_from_file_location('q0check', SRC / 'data/q0_callers/check.py')
q0check = importlib.util.module_from_spec(spec); spec.loader.exec_module(q0check)

def ident(n):
    return [[F(int(i==j)) for j in range(n)] for i in range(n)]

def dot(a,b): return sum((x*y for x,y in zip(a,b)), F(0))

def capture(C):
    n,k=C['roles'],C['stages']
    masks=[frozenset(t+1 for t,v in enumerate(d[2:2+k]) if v) for d in C['diagonal']]
    assert all(len(d)==k+2 and all(v in (0,1) for v in d[2:]) for d in C['diagonal'])
    P=ident(n); inv=ident(n); events=[]
    def add(a,b,c):
        assert a != b
        P[a]=[x+c*y for x,y in zip(P[a],P[b])]
        for row in inv: row[b]-=c*row[a]
    def scale(a,c):
        assert c
        P[a]=[c*x for x in P[a]]
        for row in inv: row[a]/=c
    def inc(j,tag,reg,S):
        S=frozenset(S)
        assert S and S<=set(range(1,k+1))
        # At D=1 the idle event is identity: both sides of this event have
        # exactly the same prefix. For HOST contacts the prefix is post-HOST.
        v=[inv[r][reg] for r in range(n)]; w=P[reg][:]
        assert dot(w,v)==1
        assert all(dot(P[r], [inv[t][col] for t in range(n)]) == int(r==col)
                   for r in range(n) for col in range(n))
        events.append(dict(key=f'{j}:{tag}', source_index=j, kind=tag, register=reg,
                           S=S,v=v,w=w))
    for j,e in enumerate(C['events']):
        op=e[0]
        if op=='ADD': add(e[1],e[2],F(e[3]))
        elif op=='SCALE': scale(e[1],F(e[2]))
        elif op=='LAMBDA': pass # at q=1, its factor is 1
        elif op=='IDLE_ONE':
            assert len(e[2])==len(set(e[2]))
            inc(j,'idle',e[1],e[2])
        elif op=='HOST':
            t,a,b,A,B=e[1],e[2],e[3],F(e[4]),F(e[5])
            assert a!=b and A and B
            pa,pb=P[a][:],P[b][:]
            P[a]=[x+A*y for x,y in zip(pa,pb)]
            P[b]=[B*x+(1+A*B)*y for x,y in zip(pa,pb)]
            for row in inv:
                x,y=row[a],row[b]
                row[a]=(1+A*B)*x-B*y; row[b]=-A*x+y
            inc(j,'host_first',a,[t]); inc(j,'host_second',b,[t])
        else: raise ValueError(op)
    assert P==ident(n) and inv==ident(n)
    # These are word consequences, not assumed constraints of the solver.
    for t in range(1,k+1):
        ids=[i for i,e in enumerate(events) if t in e['S']]
        E=[r for r,M in enumerate(masks) if t in M]
        assert len(ids)==len(E)
        for i in ids:
            assert all((events[i]['v'][r]==0 and events[i]['w'][r]==0) for r in range(n) if r not in E)
            for j in ids:
                assert dot(events[i]['w'],events[j]['v']) == int(i==j)
    return masks,events

def matching(rows, domains):
    # Complete exact DFS matching, no heuristic timeout. Return one or None.
    rows=sorted(rows,key=lambda i:(len(domains[i]),i))
    def go(pos, used, assignment):
        if pos==len(rows): return dict(assignment)
        i=rows[pos]
        for r in domains[i]:
            if r not in used:
                assignment[i]=r; used.add(r)
                ans=go(pos+1,used,assignment)
                if ans is not None: return ans
                used.remove(r); del assignment[i]
        return None
    return go(0,set(),{})

def all_pair_choices(events,masks,strict):
    return [[r for r,M in enumerate(masks) if e['S']<=M and
             (not strict or (e['v'][r]!=0 and e['w'][r]!=0))] for e in events]

def solve(events,masks,k,strict):
    dom=all_pair_choices(events,masks,strict)
    multi=[i for i,e in enumerate(events) if len(e['S'])>1]
    singles={t:[i for i,e in enumerate(events) if e['S']=={t}] for t in range(1,k+1)}
    locals_={}
    for t in range(1,k+1):
        ids=[i for i,e in enumerate(events) if t in e['S']]
        locals_[t]=matching(ids,dom)
    stats={'complete_multi_choices':0,'global_successes':0,'stage_failure_counts':{str(t):0 for t in singles}}
    witness=None
    # Search every multi assignment, including all failed combinations.
    def go(p,assigned,occupied):
        nonlocal witness
        if p<len(multi):
            i=multi[p]
            for r in dom[i]:
                if not (events[i]['S'] & occupied[r]):
                    assigned[i]=r; occupied[r] |= events[i]['S']
                    go(p+1,assigned,occupied)
                    occupied[r] -= events[i]['S']; del assigned[i]
            return
        stats['complete_multi_choices']+=1
        complete=dict(assigned)
        ok=True
        for t,ids in singles.items():
            residual={i:[r for r in dom[i] if t not in occupied[r]] for i in ids}
            mat=matching(ids,residual)
            if mat is None:
                stats['stage_failure_counts'][str(t)]+=1; ok=False
            else: complete.update(mat)
        if ok:
            stats['global_successes']+=1
            if witness is None: witness=complete
    go(0,{},[set() for _ in masks])
    if witness is not None:
        assert len(witness)==len(events)
        for i,r in witness.items(): assert r in dom[i]
        for r,M in enumerate(masks):
            parts=[events[i]['S'] for i,v in witness.items() if v==r]
            assert sum(map(len,parts))==len(set().union(*parts))==len(M) if parts else not M
            assert set().union(*parts)==M if parts else not M
    return dom,multi,locals_,stats,witness

def ser(ev,r):
    return {'event':ev['key'],'source_index':ev['source_index'],'kind':ev['kind'],
            'register':ev['register'],'stages':sorted(ev['S']),'role':r,
            'v':str(ev['v'][r]),'w':str(ev['w'][r])}

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('names',nargs='+'); parser.add_argument('--out',default='RESULT.json'); args=parser.parse_args()
    out={'method':'complete multi-event enumeration plus exact singleton bipartite matching',
         'strict':'mask containment and both v=P^-1 e_reg and w=e_reg^T P nonzero on the assigned role',
         'stage_numbering':'1-based', 'role_and_event_numbering':'0-based','inputs':{}}
    for name in args.names:
        path=SRC/'data/q0_callers'/f'{name}.json'; raw=path.read_bytes(); C=json.loads(raw)
        legal,wf=q0check.legal(C); assert legal and wf
        masks,ev=capture(C); k=C['stages']
        rec={'sha256':hashlib.sha256(raw).hexdigest(),'n':len(masks),'k':k,
             'four_q_symbolic_D_legal':legal,'well_formed_hosts':wf,
             'masks':[sorted(m) for m in masks], 'events':len(ev), 'solutions':{}}
        for strict in (False,True):
            dom,multi,loc,stats,wit=solve(ev,masks,k,strict)
            target={'multi_events':[{'event':ev[i]['key'],'stages':sorted(ev[i]['S']),
                    'candidates':dom[i]} for i in multi],
                    'all_stage_local_matchings_exist':all(x is not None for x in loc.values()),
                    'stats':stats,'global_attribution_exists':wit is not None}
            if wit is not None:
                target['witness']=[ser(e,wit[i]) for i,e in enumerate(ev)]
            rec['solutions']['strict' if strict else 'mask_only']=target
        out['inputs'][name]=rec
        print(name,'n',len(masks),'k',k,'incidences',len(ev),
              'multi',len(multi),'four-q',legal)
        for typ in ('mask_only','strict'):
            x=rec['solutions'][typ]; print(' ',typ,'local',x['all_stage_local_matchings_exist'],
                  'global',x['global_attribution_exists'],'stats',x['stats'])
            print('   multi domains',[(i['event'],i['stages'],i['candidates']) for i in x['multi_events']])
    Path(args.out).write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
if __name__=='__main__': main()
