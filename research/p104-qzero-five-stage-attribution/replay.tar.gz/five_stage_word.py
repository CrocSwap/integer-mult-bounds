#!/usr/bin/env python3
"""Literal two-shared-stage five-stage word, with direct formal replay."""
import copy,json,os,sys
from pathlib import Path
import sympy as sp
HERE=Path(__file__).resolve().parent;os.environ['P104_GUIDANCE_SOURCE']=str(HERE/'source');sys.path.insert(0,str(HERE/'source'))
import attribution as at

def word():
 ops=[(0,1,1),(0,2,1),(1,0,1),(1,2,2),(2,0,1),(2,1,1)]
 fw=[['ADD',a,b,str(c)] for a,b,c in ops];bw=[['ADD',a,b,str(-c)] for a,b,c in reversed(ops)]
 events=[['IDLE_ONE',r,[r+1]] for r in range(3)] + fw + [['IDLE_ONE',r,[4]] for r in range(3)] + bw + fw + [['IDLE_ONE',r,[5]] for r in range(3)] + bw
 return {'schema':'q0-five-stage-two-shared-irreducible-control','roles':3,'stages':5,'events':events,'diagonal':[[0,0,1,0,0,1,1],[0,0,0,1,0,1,1],[0,0,0,0,1,1,1]]}

def formal(c):
 # Entire row-operation source word over Q[D1,...,D5], not point samples.
 d=sp.symbols('D1:6');R=sp.eye(c['roles'])
 for e in c['events']:
  if e[0]=='ADD':R[e[1],:]+=sp.Rational(e[3])*R[e[2],:]
  elif e[0]=='IDLE_ONE':R[e[1],:]*=sp.prod(d[t-1] for t in e[2])
  else:raise ValueError(e)
 target=sp.diag(*[sp.prod(d[t]**dg[t+2] for t in range(5)) for dg in c['diagonal']])
 return all(sp.expand(x)==0 for x in R-target)

def run():
 c=word();assert formal(c);legal,wf=at.q0check.legal(c);assert legal and wf
 masks,events=at.capture(c);assert [sorted(a) for a in masks]==[[1,4,5],[2,4,5],[3,4,5]]
 witness={}
 for strict in (False,True):
  sol=at.solve(events,masks,5,strict)[-1];assert sol is not None
  witness['strict' if strict else 'mask_only']=[{'event':events[i]['key'],'stages':sorted(events[i]['S']),'role':sol[i]} for i in range(len(events))]
 # Three private-stage coordinate projectors and one dense stage-4 projector
 # span the full 3x3 algebra via E_i p E_j, certifying absolute irreducibility.
 p=sp.Matrix(events[3]['v'])*sp.Matrix([events[3]['w']]);assert all(p)
 E=[sp.diag(*[int(i==j) for i in range(3)]) for j in range(3)]
 columns=sp.Matrix.hstack(*[(E[i]*p*E[j]).reshape(9,1) for i in range(3) for j in range(3)])
 assert columns.rank()==9 and columns.det()!=0
 bad=copy.deepcopy(c);where=next(i for i,e in enumerate(bad['events']) if e[0]=='IDLE_ONE' and e[2]==[5]);bad['events'][where][2]=[1,5]
 assert not formal(bad) and not at.q0check.legal(bad)[0]
 rec={'source_word_four_q_symbolic_D_checker':True,'independent_full_formal_D_identity':True,'shared_stages':[4,5],'endpoint_masks':[sorted(a) for a in masks], 'incidence_events':len(events),'strict_witness':witness['strict'],'mask_only_witness':witness['mask_only'], 'full_matrix_algebra_rank':9,'algebra_certificate_determinant':str(columns.det()), 'HOST_count':0,'q_targets_even':True,'roles_plus_two':5,'two_times_stages':10,'mutated_stage_fails_both_full_identity_checks':True}
 (HERE/'WORD-5.json').write_text(json.dumps(c,sort_keys=True,indent=2)+'\n');(HERE/'WORD-5-CONTROL.json').write_text(json.dumps(rec,sort_keys=True,indent=2)+'\n')
 print('PASS five-stage two-shared source identity, irreducible rank 9, strict and mask-only witnesses; mutant rejected')
if __name__=='__main__':run()
