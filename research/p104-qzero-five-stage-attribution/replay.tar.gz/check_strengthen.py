#!/usr/bin/env python3
"""Independent exact rational replay of strengthened obstruction certificates.
No SymPy and no generator code imported. The checker knows only stage sums,
coordinate support, saturated cliques and the rank-one matrix factorization.
"""
import copy,itertools,json
from fractions import Fraction
from pathlib import Path

def check(z):
 try:
  ts=z['targets'];es=z['events'];n=len(es);eq=z['equations'];D=[{r for r,t in enumerate(ts) if e&t==e} for e in es]
  if z['status'] not in ('linear_saturation','linear_plus_rank_one') or len(ts)!=3 or any(not d for d in D):return False
  def vec(u):return [Fraction(int(i in u['events'])) for i in range(n)]+[Fraction(-int(u['roles']>>r&1)) for r in range(3)]
  def weighted(weights,before):
   v=[Fraction(0)]*(n+3)
   for i,x in weights:
    if not isinstance(i,int) or not 0<=i<before:return None
    q=Fraction(x);row=vec(eq[i]);v=[a+q*b for a,b in zip(v,row)]
   return v
  for pos,u in enumerate(eq):
   kind=u['kind'];C=u['events'];R=u['roles']
   if not 1<=R<=7 or len(set(C))!=len(C) or any(not isinstance(i,int) or i<0 or i>=n for i in C):return False
   if kind=='stage':
    s=u['stage']
    if not isinstance(s,int) or not 0<=s<5:return False
    if C!=[i for i,e in enumerate(es) if e>>s&1]:return False
    if R!=sum(1<<r for r,t in enumerate(ts) if t>>s&1):return False
   elif kind=='clique':
    roles={r for r in range(3) if R>>r&1}
    if len(C)!=len(roles) or any(not D[i]<=roles for i in C):return False
    if not all(es[i]&es[j] for i,j in itertools.combinations(C,2)):return False
   elif kind=='rank_one':
    i=u['i'];r=u['r'];comps=u['components']
    if C!=[i] or R!=1<<r or r not in D[i]:return False
    required={(r,r)}|{(a,r) for a in range(3) if a!=r}|{(r,a) for a in range(3) if a!=r}
    if {(q['a'],q['b']) for q in comps}!=required or len(comps)!=5:return False
    for q in comps:
     a=q['a'];b=q['b'];valid={j for j in range(n) if a in D[j] and b in D[j]}
     if q['mode']=='support_zero':
      if i in valid or a==b:return False
     elif q['mode']=='combination':
      v=weighted(q['weights'],pos)
      if v is None:return False
      # Coefficients at absent-support events multiply zeros; compare the rest.
      if any(v[j]!=int(j==i) for j in valid):return False
      # vec stores negative E coefficients, hence negate on a diagonal entry.
      constant= -v[n+a] if a==b else 0
      if constant!=int(a==b):return False
     else:return False
   else:return False
  c=z['clash'];v=weighted(c['combo'],len(eq))
  if v is None:return False
  expected=[Fraction(0)]*(n+3);i=c['i']
  if not isinstance(i,int) or not 0<=i<n:return False
  expected[i]=1
  if c['kind']=='equal':
   j=c['j']
   if not isinstance(j,int) or not 0<=j<n or i==j:return False
   expected[j]-=1
   if c['conflict']=='shared_stage':
    if not es[i]&es[j]:return False
   elif c['conflict']=='disjoint_support':
    if D[i]&D[j]:return False
   else:return False
  elif c['kind']=='outside':
   r=c['r']
   if not 0<=r<3 or r in D[i]:return False
   expected[n+r]-=1
  elif c['kind']!='zero':return False
  return v==expected
 except (KeyError,IndexError,TypeError,ValueError,ZeroDivisionError):return False

def main():
 scan=json.loads(Path('SCAN.json').read_text());x=json.loads(Path('STRENGTHEN.json').read_text());records=x['records']
 unresolved=[(z['targets'],z['events']) for z in scan['necessary_case_orbits'] if 'saturation' in z and z['saturation'] is None]
 assert len(unresolved)==len(records) and len(unresolved)==33
 assert {(tuple(z['targets']),tuple(z['events'])) for z in records}=={(tuple(a),tuple(b)) for a,b in unresolved}
 for z in records:assert check(z),z
 counts={v:sum(z['status']==v for z in records) for v in ('linear_saturation','linear_plus_rank_one','unresolved')}
 weights=[w for z in records for _,w in z['clash']['combo']]
 weights += [w for z in records for e in z['equations'] if e['kind']=='rank_one' for c in e['components'] for _,w in c.get('weights',[])]
 assert all(Fraction(w).denominator==1 for w in weights)
 assert counts==x['counts']=={'linear_saturation':31,'linear_plus_rank_one':2,'unresolved':0}
 # Three specific mutations must fail closed: wrong stage equation, rational
 # certificate weight, and rank-one entrywise deduction.
 m=copy.deepcopy(records[0]);m['equations'][0]['stage']=(m['equations'][0]['stage']+1)%5;assert not check(m)
 m=copy.deepcopy(records[0]);m['clash']['combo'][0][1]=str(Fraction(m['clash']['combo'][0][1])+1);assert not check(m)
 m=copy.deepcopy(next(z for z in records if z['status']=='linear_plus_rank_one'))
 f=next(q for q in m['equations'] if q['kind']=='rank_one');f['components'][0]['weights'][0][1]='0';assert not check(m)
 m=copy.deepcopy(next(z for z in records if z['status']=='linear_plus_rank_one'));f=next(q for q in m['equations'] if q['kind']=='rank_one');r=f['r']
 f['components']=[q for q in f['components'] if not (q['a']==r and q['b']!=r)];assert not check(m)
 # A nonsymmetric rank-one idempotent can have the selected column of E_r
 # without being E_r: a column-only condition must not be accepted.
 P=[[1,1,0],[0,0,0],[0,0,0]]
 assert all(sum(P[i][k]*P[k][j] for k in range(3))==P[i][j] for i in range(3) for j in range(3))
 assert P[0][0]==1 and P[1][0]==P[2][0]==0 and P[0][1]!=0
 out={'all_33_valid':True,'counts':counts,'independent_verifier':'fractions.Fraction; check stage and saturated clique equations, all rank-one component combinations, and each final contradiction','all_certificate_weights_integers':True,'mutations_rejected':{'stage_equation':True,'clash_coefficient':True,'rank_one_component':True,'rank_one_missing_row_entries':True,'nonsymmetric_rank_one_column_only_counterexample_recognized':True}}
 Path('STRENGTHEN-VERIFIED.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
 print('PASS exact certificate replay and 4 rejected mutations; nonsymmetric control checked',counts)
if __name__=='__main__':main()
