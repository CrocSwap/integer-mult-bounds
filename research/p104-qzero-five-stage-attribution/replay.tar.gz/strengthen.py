#!/usr/bin/env python3
"""Derive exact linear saturation certificates for nonpartition survivors."""
import itertools,json
import sympy as sp
from pathlib import Path
S=json.loads(Path('SCAN.json').read_text());bad=[z for z in S['necessary_case_orbits'] if 'saturation' in z and z['saturation'] is None]
def build(z):
 ev=z['events'];ts=z['targets'];n=len(ev);dom=[{r for r,t in enumerate(ts) if e&t==e} for e in ev];eq=[]
 for s in range(5):eq.append({'kind':'stage','stage':s,'events':[i for i,e in enumerate(ev) if e>>s&1],'roles':sum(1<<r for r,t in enumerate(ts) if t>>s&1)})
 for b in range(1,8):
  roles={r for r in range(3) if b>>r&1};inds=[i for i in range(n) if dom[i]<=roles]
  for C in itertools.combinations(inds,len(roles)):
   if all(ev[i]&ev[j] for i,j in itertools.combinations(C,2)):eq.append({'kind':'clique','events':list(C),'roles':b})
 return dom,eq
def fullrow(eq,n):return [int(i in eq['events']) for i in range(n)]+[-int(eq['roles']>>r&1) for r in range(3)]
def combo(rows,goal):
 # Independent original row basis, then solve once. Output exact rational weights.
 M=sp.Matrix(rows);v=sp.Matrix(goal);idx=list(M.T.rref()[1]);basis=M[idx,:]
 try:ans,params=basis.T.gauss_jordan_solve(v)
 except ValueError:return None
 assert not params.rows
 return [[int(idx[j]),str(ans[j])] for j in range(len(idx)) if ans[j]!=0]
def matrix_span(eq,n):
 M=sp.Matrix([fullrow(x,n) for x in eq]);R,pivs=M.rref();b=[R.row(j) for j in range(len(pivs))]
 def holds(v):
  q=sp.Matrix([v])
  for j,p in enumerate(pivs):q-=q[p]*b[j]
  return not any(q)
 return holds

def clash(eq,ev,dom):
 n=len(ev);holds=matrix_span(eq,n);rows=[fullrow(x,n) for x in eq]
 for i in range(n):
  v=[int(h==i) for h in range(n)]+[0]*3
  if holds(v):return {'kind':'zero','i':i,'combo':combo(rows,v)}
  for j in range(i+1,n):
   if ev[i]&ev[j] or not dom[i]&dom[j]:
    q=v.copy();q[j]-=1
    if holds(q):return {'kind':'equal','i':i,'j':j,'conflict':'shared_stage' if ev[i]&ev[j] else 'disjoint_support','combo':combo(rows,q)}
  for r in range(3):
   if r not in dom[i]:
    q=v.copy();q[n+r]-=1
    if holds(q):return {'kind':'outside','i':i,'r':r,'combo':combo(rows,q)}
 return None

def force_candidates(eq,dom):
 n=len(dom)
 def component(i,a,b):
  valid=[j for j in range(n) if a in dom[j] and b in dom[j]]
  if i not in valid:return {'mode':'support_zero','a':a,'b':b} if a!=b else None
  rows=[[int(j in e['events']) for j in valid] for e in eq];goal=[int(j==i) for j in valid];weights=combo(rows,goal)
  if weights is None:return None
  rhs=sum(sp.Rational(w)*(int(a==b and eq[idx]['roles']>>a&1)) for idx,w in weights)
  if rhs!=(1 if a==b else 0):return None
  return {'mode':'combination','a':a,'b':b,'weights':weights}
 for i in range(n):
  for r in sorted(dom[i]):
   diag=component(i,r,r)
   if diag is None:continue
   cross=[component(i,a,r) for a in range(3) if a!=r]+[component(i,r,a) for a in range(3) if a!=r]
   if all(x is not None for x in cross):yield {'kind':'rank_one','events':[i],'roles':1<<r,'i':i,'r':r,'components':[diag]+cross}
def main():
 records=[];counts={'linear_saturation':0,'linear_plus_rank_one':0,'unresolved':0}
 for idx,z in enumerate(bad):
  ev=z['events'];dom,eq=build(z);initial=len(eq);c=clash(eq,ev,dom)
  if c:status='linear_saturation'
  else:
   status='unresolved'
   # Add any rank-one consequences as named, checkable additional equations.
   for f in list(force_candidates(eq,dom)):
    eq.append(f)
   c=clash(eq,ev,dom)
   if c:status='linear_plus_rank_one'
  counts[status]+=1
  records.append({'targets':z['targets'],'events':ev,'status':status,'initial_equations':initial,'equations':eq if c else [],'clash':c})
  print(idx,status,flush=True)
 out={'counts':counts,'records':records,'explanation':'Linear combinations of stage equations and saturated-clique equations; optionally entrywise stage/clique combinations force a rank-one projector to equal a coordinate projector.'}
 Path('STRENGTHEN.json').write_text(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n');print('TOTAL',counts,flush=True)
if __name__=='__main__':main()
