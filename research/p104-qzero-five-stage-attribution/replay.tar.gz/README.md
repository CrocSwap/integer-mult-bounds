# Rank-three mask attribution with five active stages

Research note, 2026-11-21. Follow-up to [PR #7941](https://github.com/CrocSwap/integer-mult-bounds/pull/7941), pinned by the campaign at `322a00cde3f1e15cb04448bba15acc364f97445d`; original Q=0 checker [PR #7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869), pinned at `06c207a9feb3994a4b987dc3010657b6e85b7956`. The exact local Round 5 source snapshot is included as `SOURCE-R5.tar.gz`, SHA-256 `4f5ffe5e66c509e973bce88b93c80c07f6b80828f27a350aed8a81b56e4729ac`. It is the source snapshot used here, not an assertion that this tarball itself is byte-identical to the archive stored in the Git object. The parent snapshot contains the #7918 attribution source and #7869 checker; the parent verifier checks their recorded hashes.

## Result and domain

Let K be a field of characteristic zero or characteristic greater than three. Let `E_0,E_1,E_2` be pairwise annihilating rank-one idempotents adding to the identity. Let each incidence event e have a nonempty squarefree set `S_e` of stage labels and a rank-one idempotent `p_e`. The events have a fixed order and need not commute. Assume the **full formal polynomial matrix identity**

```
product_e ((I - p_e) + (product_{t in S_e} D_t) p_e)
  = sum_{r=0}^2 (product_{t in M_r} D_t) E_r
```

with independent indeterminates, and each endpoint mask `M_r` squarefree. Empty and repeated endpoint masks are allowed. Then **if the union of the endpoint masks contains at most five stages, every event can be assigned to one endpoint role so that its assigned masks are disjoint and union to that role's endpoint mask**. This is a finite, computer-assisted theorem; the script source, all relevant cases, witnesses and obstruction certificates are included.

The new part is exactly five active stages with at least two shared stages (a shared stage occurs in two or three endpoint masks). Simultaneous relabelling can place any two shared stages first. For five stages with at most one shared stage, the parent already proves the statement in every dimension; the parent also verifies all rank-three systems with at most four stages. An inactive stage cannot occur in an event, by equality of determinants. Nothing here establishes the six-or-more-active-stage case.

**Field.** The stage-projector and rank arguments hold over any field. The trace support test uses the fact that the endpoint coefficient multiplicity 1, 2 or 3 cannot vanish, so we assume characteristic zero or greater than three. All supplemental certificate weights are integers, independently checked in `STRENGTHEN-VERIFIED.json`. The positive literal word uses rational coefficients and is checked over Q, independently of the field extension of the finite theorem. The identity is formal, including over finite fields: checking it at selected field elements is not a substitute.

**Strict support.** The theorem concerns mask-only attribution. It does not require the assigned role's entries of the event's column and row to be nonzero, and it does not establish a general strict-attribution theorem. The example below happens to have a strict witness.

**HOST and caller assumptions.** No HOST, odd-target, tightness, RC2, legal-caller, invoice, or κ conclusion is inferred from the mask theorem. The literal control has no HOST, even q targets and `n+2=5` versus `2k=10`; it is not an instance of the tight odd-target HOST branch. Applying the abstract theorem to a caller requires deriving the full displayed identity and its rank-one projectors from that caller's actual source word and hypotheses.

## Why the finite checks suffice

As in the parent, taking determinants gives, for each stage t, exactly `m_t = # {r : t in M_r}` events containing t. Specialize every other indeterminate to 1 and differentiate at `D_t=1`; this gives the exact matrix equation

```
sum_{e: t in S_e} p_e = P_t = sum_{r: t in M_r} E_r.
```

There are precisely `rank(P_t)=m_t` summands. Writing the rank-one idempotents as columns times rows shows that distinct summands annihilate each other in both orders and each is supported inside `P_t`. Thus each event is supported in the intersection of its stage projectors, equivalently in the sum of endpoint roles whose masks contain its entire event mask. That eligible role set is nonempty. Stage events also admit a matching to the corresponding roles: a nonsingular minor of the matrix of their spanning columns has a nonzero permutation term.

Expanding the trace of the formal identity shows a further necessary test: each endpoint mask is the disjoint union of at least one event subset. Its coefficient is the positive endpoint multiplicity 1, 2 or 3, nonzero in the stated characteristics. This subset support and each stage's matching are filters, not a construction of a word. An exact cover search then decides whether all events simultaneously partition among the three roles.

A **saturated clique** is a collection of `|R|` event projectors supported on endpoint-role set R, each pair sharing a stage. The stage lemma makes them pairwise annihilate, so their sum is `P_R`. The original checker detects incompatible projectors by comparing two such sums differing in one term. This excludes 795 of the nonpartitions. For the 33 remaining, `STRENGTHEN.json` records explicit integral linear combinations of stage and saturated-clique equations. Such a combination either forces an event projector to zero, equates it to a coordinate projector outside its support, or equates two nonzero projectors that share a stage or have disjoint support. In two cases the certificate first uses entrywise equations plus support and rank one to show a projector equals a coordinate projector: if `p_rr=1` and all entries in row r and column r outside `(r,r)` vanish, then `p=E_r`. `check_strengthen.py` checks the original equations, separate certificates for the diagonal and both orientations of every off-diagonal row and column entry, and the final contradiction using exact rational arithmetic and no SymPy.

For a concrete version of the last kind, take endpoint masks `1345,2345,12345` and event masks `3,13,4,24,15,25,345`. Let `H=p_345`. Since `p_13+p_15=E_0+E_2` at stage 1 and `{p_13,p_15,H}` is a saturated clique, `H=E_1`. Events `24` and `25` are each supported on roles `{1,2}`. Because they respectively share stages 4 and 5 with H, they annihilate E_1 in both orders and so each equals E_2. They also share stage 2 and must annihilate one another, contradiction. This is an impossible mask pattern, not a word.

## Complete finite census

A stage column is a nonempty subset of the three roles. There are 85 orbits of five columns with at least two shared, after role permutations and permutations of the five stage columns. For each target orbit, `scan.py` enumerates every multiset of allowed nonempty event masks with the exact endpoint multiplicity at each stage, then quotients by that target's stage stabilizer. The cap is intrinsic: an event contains at least one incidence, and there are at most `3*5=15` incidences; there is no additional bound on event count or mask cardinality.

| Test | Cases |
| --- | ---: |
| Endpoint orbits | 85 |
| Compatible event multisets, with the five stage labels fixed for each endpoint representative | 135,226 |
| Combined endpoint/event orbits | 20,232 |
| Pass local matching and trace-subset filters | 13,099 |
| Have an explicit global mask partition | 12,271 |
| Lack a partition | 828 |
| Of these, excluded by direct two-clique cancellation | 795 |
| Further excluded by integral combinations of saturation equations | 31 |
| Further excluded by entrywise rank-one forcing and integral combinations | 2 |
| Remaining | 0 |

These are **orbit counts**, except for the explicitly labelled event-multiset row. Local matching passes 15,149 orbits; trace support passes 13,122; their intersection is 13,099. A representative, and its exact partition or saturation obstruction, is saved for every case passing both filters in `SCAN.json`. `STRENGTHEN.json` has complete certificates for the 33 cases where the original saturation test returned none.

`independent.py` starts instead from endpoint-mask triples, canonicalizes using all 120 stage permutations, and constructs each event multiset one stage at a time. It uses Hall subsets and per-role event-index exact-cover families, verifies every reported partition and direct saturation certificate, and reproduces the entire census. It rejects deliberately damaged partition, saturation-clique and event-degree inputs. `check_strengthen.py` independently checks all 33 supplemental certificates and rejects changed stage equations, weights, rank-one deductions, and a deduction missing the off-diagonal row certificates. The nonsymmetric idempotent `[[1,1,0],[0,0,0],[0,0,0]]` is an explicit control: it has the first coordinate column of `E_0` but is not `E_0`, so the column condition alone is insufficient.

## Literal positive and damaged control

`WORD-5.json` is a three-role, five-stage source word. Its two shared stages are 4 and 5; its endpoint is exactly

```
diag(D1 D4 D5, D2 D4 D5, D3 D4 D5).
```

`five_stage_word.py` regenerates this word, checks the full polynomial identity by a direct SymPy row-operation replay, and checks it independently using the pinned four-q, symbolic-D Q=0 checker. The nine `E_i p E_j` products built from private-stage coordinate projectors and one dense shared-stage projector have full matrix-algebra rank 9, so this example is absolutely irreducible; both mask-only and strict witnesses are saved. Changing a stage-5 event to include stage 1 makes both complete identity checks fail. This is a positive control, not a counterexample. The source checker tests the q-free word against the four q roots; it does not confer the omitted tight HOST conditions.

The included parent verifier also reproduces its one- through four-stage enumeration and independent enumeration, its original irreducible four-stage source word, and the mutated source-word rejection.

## Reproduction

With Python 3 and SymPy installed, from this directory:

```
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B verify.py
```

The verifier hashes the local parent archive, checks copied attribution/checker bytes, regenerates all five-stage outputs in a temporary directory, checks byte equality, replays all certificates and mutations, and reruns the parent verifier. The scripts use only this directory plus their temporary working directory and make no network calls.

## Certificate review revision

An independent reviewer highlighted that checking the selected column alone would not imply a rank-one projector is a coordinate projector. The previous component combinations used full matrix equations and symmetric role support, so the same weights also applied to the transposed entries, but that implication was implicit in the checker. This revision generates and independently checks separate certificates for both row and column entries, and adds the column-only negative control. The prior bundle and checker are retained in the owner directory under `snapshot-pre-review/`; this revision does not claim that the earlier checker explicitly checked both orientations.
