#!/usr/bin/env python3
"""Five-stage rank-3 exact mask screen; canonical endpoint/stage orbits."""
import itertools,json,collections,sys,time
from pathlib import Path
K=5
P3=list(itertools.permutations(range(3)))
P5=list(itertools.permutations(range(5)))
def rolemap(b,p):return sum(1<<p[i] for i in range(3) if b>>i&1)
def stagecols():
 def canon(x):return min(tuple(sorted(rolemap(b,p) for b in x)) for p in P3)
 return sorted({canon(x) for x in itertools.combinations_with_replacement(range(1,8),K) if sum(b.bit_count()>1 for b in x)>=2})
def target_masks(cols):return tuple(sorted(sum(1<<s for s,b in enumerate(cols) if b>>r&1) for r in range(3)))
def stage_map(p):return tuple(sum(1<<p[s] for s in range(K) if e>>s&1) for e in range(1<<K))
def stabilizer(targets):
 maps=[stage_map(p) for p in P5]
 return [mp for mp in maps if tuple(sorted(mp[t] for t in targets))==targets]
def generate(targets):
 allowed=[e for e in range(1,1<<K) if any(e&t==e for t in targets)]
 allowed.sort(key=lambda x:(-x.bit_count(),x));rem=[sum(t>>s&1 for t in targets) for s in range(K)];chosen=[]
 bits=[[s for s in range(K) if e>>s&1] for e in allowed]
 suffix=[set().union(*map(set,bits[j:])) if j<len(bits) else set() for j in range(len(bits)+1)]
 def walk(j):
  if j==len(allowed):
   if not any(rem): yield tuple(sorted(chosen))
   return
  if any(c and s not in suffix[j] for s,c in enumerate(rem)): return
  e=allowed[j];ii=bits[j];cap=min(rem[i] for i in ii)
  for c in range(cap+1):
   for i in ii: rem[i]-=c
   chosen.extend([e]*c)
   yield from walk(j+1)
   if c: del chosen[-c:]
   for i in ii: rem[i]+=c
 yield from walk(0)
def domains(events,targets):return [tuple(r for r,t in enumerate(targets) if e&t==e) for e in events]
def local(events,dom):
 for s in range(K):
  ids=[i for i,e in enumerate(events) if e>>s&1]
  def run(j,used):
   if j==len(ids):return True
   return any(not used>>r&1 and run(j+1,used|1<<r) for r in dom[ids[j]])
  if not run(0,0):return False
 return True
def trace(events,targets):
 for t in targets:
  vals={0}
  for e in events:
   if e&t==e: vals|={x|e for x in tuple(vals) if not x&e}
  if t not in vals:return False
 return True
def partition(events,targets,dom):
 order=sorted(range(len(events)),key=lambda i:(len(dom[i]),-events[i].bit_count(),i));rem=list(targets);out=[None]*len(events)
 def rec(j):
  if j==len(order):return not any(rem)
  i=order[j];e=events[i]
  for r in dom[i]:
   if rem[r]&e==e:
    rem[r]^=e;out[i]=r
    if rec(j+1):return True
    rem[r]^=e
  out[i]=None
  return False
 return out if rec(0) else None
def saturation(events,dom):
 for roles in range(1,8):
  n=roles.bit_count();inds=[i for i,d in enumerate(dom) if all(roles>>r&1 for r in d)]
  cliques=[set(c) for c in itertools.combinations(inds,n) if all(events[i]&events[j] for i,j in itertools.combinations(c,2))]
  for a,b in itertools.combinations(cliques,2):
   da=a-b;db=b-a
   if len(da)!=1 or len(db)!=1:continue
   i=next(iter(da));j=next(iter(db));conflict='shared_stage' if events[i]&events[j] else ('disjoint_support' if not set(dom[i])&set(dom[j]) else None)
   if conflict:return {'roles':roles,'left':sorted(a),'right':sorted(b),'different':[i,j],'conflict':conflict}
 return None
def main():
 total=collections.Counter();by=[];records=[]
 for no,cols in enumerate(stagecols(),1):
  targets=target_masks(cols);maps=stabilizer(targets);seen=set();c=collections.Counter();shared=sum(x.bit_count()>1 for x in cols)
  for ev in generate(targets):
   c['labelled_event_multisets']+=1
   if ev in seen:continue
   orbit={tuple(sorted(mp[e] for e in ev)) for mp in maps};seen.update(orbit)
   # Deterministic representative is independent of generator traversal.
   ev=min(orbit);c['event_orbits']+=1
   dom=domains(ev,targets);loc=local(ev,dom);tr=trace(ev,targets)
   c['local']+=loc;c['trace']+=tr
   if not (loc and tr):continue
   c['necessary']+=1;sol=partition(ev,targets,dom)
   item={'targets':targets,'events':ev}
   if sol is not None:
    c['partition']+=1;item['partition']=sol
   else:
    c['nonpartition']+=1;ob=saturation(ev,dom);item['saturation']=ob
    c['saturated']+=bool(ob);c['unresolved']+=not bool(ob)
   records.append(item)
  assert len(seen)==c['labelled_event_multisets'],(cols,len(seen),c)
  c['endpoint_orbits']=1;total.update(c);by.append({'stage_types':cols,'shared':shared,'target_masks':targets,'stabilizer_size':len(maps),'counts':dict(c)})
  print(f'{no:3} / 85 stages={cols} cases={c["labelled_event_multisets"]} orbits={c["event_orbits"]} necessary={c["necessary"]} blocked={c["saturated"]} unresolved={c["unresolved"]}',flush=True)
 out={'definition':'Exactly five active stage columns, at least two appearing on two or three endpoints, modulo endpoint-role and simultaneous stage permutations. Event masks nonempty and their stage multiplicities equal endpoint degrees. Local matching and characteristic-zero trace support are necessary filters.','role_count':3,'active_stages':5,'at_least_shared':2,'counts':dict(total),'by_target_orbit':by,'necessary_case_orbits':records}
 Path('SCAN.json').write_text(json.dumps(out,sort_keys=True,separators=(',',':'))+'\n')
 print('TOTAL',dict(total),flush=True)
if __name__=='__main__': main()
