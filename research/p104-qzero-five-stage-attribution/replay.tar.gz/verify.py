#!/usr/bin/env python3
"""Cold, offline source and byte-identical regeneration of the R6 result."""
import hashlib,os,shutil,subprocess,sys,tarfile,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd,env):subprocess.run(args,cwd=cwd,env=env,check=True)
def main():
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);assert sha(ROOT/name)==digest,name
 archive=ROOT/'SOURCE-R5.tar.gz';assert sha(archive)=='4f5ffe5e66c509e973bce88b93c80c07f6b80828f27a350aed8a81b56e4729ac'
 with tarfile.open(archive,'r:gz') as tf:
  for p in ('source/attribution.py','source/data/q0_callers/check.py'):
   assert tf.extractfile(p).read()==(ROOT/p).read_bytes(),p
 assert sha(ROOT/'source/data/q0_callers/check.py')=='2233655e29abce6ad1282e6da52ea70a77e7cb2f71b331f78834c165955cd504'
 env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');env.pop('P104_GUIDANCE_SOURCE',None);env.pop('P104_ATTRIBUTION_SOURCE',None)
 with tempfile.TemporaryDirectory(prefix='p104-five-mask-cold-') as raw:
  tmp=Path(raw);work=tmp/'five';work.mkdir()
  scripts=['scan.py','independent.py','strengthen.py','check_strengthen.py','five_stage_word.py']
  outputs=['SCAN.json','INDEPENDENT.json','STRENGTHEN.json','STRENGTHEN-VERIFIED.json','WORD-5.json','WORD-5-CONTROL.json']
  for name in scripts:shutil.copy2(ROOT/name,work/name)
  shutil.copytree(ROOT/'source',work/'source')
  for name in scripts:run([sys.executable,'-B',name],work,env)
  for name in outputs:assert (ROOT/name).read_bytes()==(work/name).read_bytes(),name
  parent=tmp/'parent';parent.mkdir()
  with tarfile.open(archive,'r:gz') as tf:tf.extractall(parent,filter='data')
  run([sys.executable,'-B','verify.py'],parent,env)
 print('PASS five-stage and parent exact regeneration, certificates, controls and mutations')
if __name__=='__main__':main()
