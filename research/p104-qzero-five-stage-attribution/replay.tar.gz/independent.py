#!/usr/bin/env python3
"""Independent active-stage regeneration, exact-cover check, and certificate replay.

Enumerates endpoint triples before stage canonicalization and builds incidence
multisets one stage at a time, unlike scan.py's nonempty-mask multiset DFS.
"""
import collections,itertools,json,sys
from pathlib import Path
K=5
perms=list(itertools.permutations(range(K)))
maps=[tuple(sum(1<<p[t] for t in range(K) if x>>t&1) for x in range(1<<K)) for p in perms]
def target_image(t,mp):return tuple(sorted(mp[a] for a in t))
def key_options(t):
 vals=[target_image(t,mp) for mp in maps];least=min(vals)
 return least,[maps[i] for i,v in enumerate(vals) if v==least]
def pair_key(t,e):
 tt,choices=key_options(t)
 return tt,min(tuple(sorted(mp[x] for x in e)) for mp in choices)
def independent_targets():
 all_t=itertools.combinations_with_replacement(range(32),3);got=set()
 for t in all_t:
  if (t[0]|t[1]|t[2])!=31:continue
  if sum(sum(bool(x>>s&1) for x in t)>1 for s in range(K))<2:continue
  got.add(key_options(t)[0])
 return sorted(got)
def build_events(t):
 states={()}
 for s in range(K):
  degree=sum(bool(x>>s&1) for x in t);nextset=set();bit=1<<s
  for ev in states:
   for reuse in range(min(degree,len(ev))+1):
    for inds in itertools.combinations(range(len(ev)),reuse):
     inds=set(inds);new=tuple(sorted([x|bit if i in inds else x for i,x in enumerate(ev)]+[bit]*(degree-reuse)))
     if all(any(x&a==x for a in t) for x in new):nextset.add(new)
  states=nextset
 return states
def hall(ev,t):
 for s in range(K):
  active=[e for e in ev if e>>s&1]
  domains=[{r for r,a in enumerate(t) if e&a==e} for e in active]
  for bits in range(1,1<<len(active)):
   subset=[domains[j] for j in range(len(active)) if bits>>j&1]
   if len(set().union(*subset))<len(subset):return False
 return True
def covers(ev,target):
 # Choose the lowest uncovered stage and an event containing it. Event-index
 # bitsets give independent exact-cover enumeration for each endpoint role.
 if target==0:return {0}
 bit=target&-target;out=set()
 for i,e in enumerate(ev):
  if e&bit and e&target==e:
   for sub in covers(ev,target^e):out.add(sub|1<<i)
 return out
def is_partition(ev,t,assignment):
 if assignment is None or len(assignment)!=len(ev):return False
 seen=[0,0,0]
 for e,r in zip(ev,assignment):
  if r not in (0,1,2) or seen[r]&e or e&t[r]!=e:return False
  seen[r]|=e
 return tuple(seen)==tuple(t)
def partition_exists(families,n):
 all_e=(1<<n)-1
 for a in families[0]:
  for b in families[1]:
   if a&b:continue
   remaining=all_e^(a|b)
   if remaining in families[2]:return True
 return False
def verify_sat(ev,t,cert):
 if not isinstance(cert,dict):return False
 try:
  R=cert['roles']; A=cert['left'];B=cert['right'];diff=cert['different'];conflict=cert['conflict'];n=len(ev)
  if not 1<=R<=7 or len(A)!=R.bit_count() or len(B)!=R.bit_count():return False
  if len(set(A))!=len(A) or len(set(B))!=len(B) or any(i<0 or i>=n for i in A+B):return False
  domains=[{r for r,a in enumerate(t) if e&a==e} for e in ev];roles={r for r in range(3) if R>>r&1}
  for C in (A,B):
   if not all(domains[i] and domains[i]<=roles for i in C):return False
   if not all(ev[i]&ev[j] for i,j in itertools.combinations(C,2)):return False
  dl=set(A)-set(B);dr=set(B)-set(A)
  if len(dl)!=1 or len(dr)!=1 or diff!=[next(iter(dl)),next(iter(dr))]:return False
  i,j=diff
  return ((conflict=='shared_stage' and bool(ev[i]&ev[j])) or (conflict=='disjoint_support' and not (domains[i]&domains[j])))
 except (KeyError,IndexError,TypeError,ValueError):return False
def main():
 source=json.loads(Path('SCAN.json').read_text());table={}
 for item in source['necessary_case_orbits']:
  key=pair_key(item['targets'],item['events']);assert key not in table;table[key]=item
 counts=collections.Counter();targets=independent_targets();assert len(targets)==85
 visited=set();first_partition=None;first_sat=None
 for no,t in enumerate(targets,1):
  all_events=build_events(t);counts['labelled_event_multisets']+=len(all_events)
  stab=[mp for mp in maps if target_image(t,mp)==t];seen=set();localcounts=collections.Counter()
  for ev in sorted(all_events):
   if ev in seen:continue
   orbit={tuple(sorted(mp[e] for e in ev)) for mp in stab};assert orbit<=all_events;seen.update(orbit)
   ev=min(orbit);counts['event_orbits']+=1
   h=hall(ev,t);family=[covers(ev,a) for a in t];tr=all(family)
   counts['local']+=h;counts['trace']+=tr
   if not(h and tr):continue
   counts['necessary']+=1;key=pair_key(t,ev);assert key in table,(t,ev);item=table[key];visited.add(key)
   exists=partition_exists(family,len(ev));mapped_t=item['targets'];mapped_ev=item['events']
   if exists:
    assert 'partition' in item and is_partition(mapped_ev,mapped_t,item['partition'])
    counts['partition']+=1
    if first_partition is None:first_partition=(mapped_ev,mapped_t,item['partition'])
   else:
    assert 'saturation' in item and 'partition' not in item;counts['nonpartition']+=1
    cert=item['saturation']
    if cert is not None:
     assert verify_sat(mapped_ev,mapped_t,cert),(item,'invalid saturation')
     counts['saturated']+=1
     if first_sat is None:first_sat=(mapped_ev,mapped_t,cert)
    else:counts['unresolved']+=1
  assert len(seen)==len(all_events)
  counts['endpoint_orbits']+=1
  print(f'independent {no}/85 cases={len(all_events)}',flush=True)
 assert len(visited)==len(table)==counts['necessary']
 for field,val in source['counts'].items():assert counts[field]==val,(field,counts[field],val)
 # Negative controls prove certificate checks reject specific malformed input.
 ev,t,assignment=first_partition;bad=list(assignment);bad[0]=3
 assert is_partition(ev,t,assignment) and not is_partition(ev,t,bad)
 ev,t,cert=first_sat;broken=json.loads(json.dumps(cert));broken['left']=broken['left'][:-1]
 assert verify_sat(ev,t,cert) and not verify_sat(ev,t,broken)
 # A changed event membership is caught as a degree mismatch in this local check.
 ev2=list(ev);ev2[0]^=1
 def degrees(a):return tuple(sum(bool(x>>s&1) for x in a) for s in range(5))
 assert degrees(ev)==degrees(t) and degrees(ev2)!=degrees(t)
 result={'independent_method':'endpoint triple orbit enumeration; construct events stage by stage; Hall subsets and per-role event-index exact-cover families; independent saturation-certificate checking','matched':True,'counts':dict(counts),'negative_controls':{'partition_role_out_of_range_rejected':True,'damaged_saturation_clique_rejected':True,'event_membership_degree_mutation_rejected':True}}
 Path('INDEPENDENT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 print('PASS independently regenerated and checked all canonical cases',dict(counts),flush=True)
if __name__=='__main__':main()
