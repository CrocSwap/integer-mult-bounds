#!/usr/bin/env python3
"""Conditional third-donor screen and separate packet-2947 split geometry."""
from pathlib import Path
from collections import Counter,defaultdict
from contextlib import redirect_stdout
import importlib.util,io,json,os
p=Path(__file__).with_name('forward_pairs.py')
spec=importlib.util.spec_from_file_location('forward_pairs',p);P=importlib.util.module_from_spec(spec)
with redirect_stdout(io.StringIO()):spec.loader.exec_module(P)

# Extension justified by the 184 already-protected pairs: one further later
# same-sender packet may contribute a pulse with zero protected support.
# Pairs for which protected parts only cancel jointly across all three donors
# and no protected-preserving two-donor subset exist are outside this screen.
seen=set();best={};patterns=[];histograms=Counter()
for b in P.patterns:
    k=b['retired'];ds=b['donors'];s=P.V[k]^P.V[ds[0]]^P.V[ds[1]]
    for d in P.banks[b['sender_chart']]:
        if d in ds or P.clock[d]<=P.clock[k] or P.V[d]&P.protected:continue
        d3=tuple(sorted((*ds,d),key=P.clock.__getitem__));key=(k,d3)
        if key in seen:continue
        seen.add(key);res=s^P.V[d];hs,zs=P.helper_info(res)
        zs=[z for z in zs if z not in (k,*d3)]
        hist=Counter([P.G[k]]+[P.G[z] for z in zs]);hist.subtract(P.H[h] for h in hs)
        hist=tuple((g,c) for g,c in sorted(hist.items()) if c);histograms[hist]+=1
        row={'retired':k,'donors':d3,'sender_chart':b['sender_chart'],
             'surrendered_helpers':hs,'grant_extra_deletions':zs,'signed_native_histogram':dict(hist)}
        patterns.append(row)
price_table={}
for hist,count in histograms.items():
    gain=dict(hist);pos=Counter({g:c for g,c in gain.items() if c>0});neg=Counter({g:-c for g,c in gain.items() if c<0})
    bounds={t:P.target_exact.signed(neg,pos,t) for t in P.trials}
    assert all(b[1]<0 for b in bounds.values())
    price_table[hist]=bounds
    for t,interval in bounds.items():
        if t not in best or best[t][1]<interval[1]:best[t]=interval
triples={'counts':{'distinct_patterns':len(patterns),'distinct_signed_histograms':len(histograms),
                   'zero_helper_residual':sum(not x['surrendered_helpers'] for x in patterns),
                   'one_helper_residual':sum(len(x['surrendered_helpers'])==1 for x in patterns),
                   'positive':0},
         'scope':'Start from each already protected-preserving chronological pair; add one later same-sender donor with no protected output pulse, remove distinct original non-tree/non-bridge packets whose original output pulses are subsets of the exact helper residual, and bill each helper in that residual. Does not exhaust arbitrary three-donor cancellation.',
         'directed_maximum_native_gain_interval':{t:P.target_exact.interval_output(b) for t,b in best.items()},
         'best_optimistic_complete_36_call_margin_interval':{t:P.target_exact.interval_output((P.full_before[t][0]+36*b[0],P.full_before[t][1]+36*b[1])) for t,b in best.items()},
         'histograms':[{'histogram':dict(h),'count':c,'directed_native_gain_interval':{t:P.target_exact.interval_output(v) for t,v in price_table[h].items()}} for h,c in sorted(histograms.items())],
         'patterns':patterns}
(Path(os.environ.get('P104_OUT',Path(__file__).resolve().parent.parent/'receipts'))/'FORWARD-TRIPLES.json').write_text(json.dumps(triples,indent=2)+'\n')

# Explicit co-location union-find, needed because recoding changes components.
def components(routes,forms):
    nodes={(j,'in'):(j,'in') for j in list(range(P.n))+list(routes)}
    nodes.update({(j,'out'):(j,'out') for j in [~i for i in range(P.n)]+list(routes)})
    def find(k):
        while nodes[k]!=k:nodes[k]=nodes[nodes[k]];k=nodes[k]
        return k
    for k,row in forms.items():
        for j in P.physical.labels(row):nodes[find((j,'in'))]=find((k,'out'))
    groups=defaultdict(list)
    for x in nodes:groups[find(x)].append(x)
    return {x:sorted(a) for a in groups.values() for x in a}
old=components(P.R,P.F)
r2,f2=P.change(2947,(2948,2949));new=components(r2,f2)
assert old[(2669,'in')]==[(2669,'in'),(2674,'in'),(2947,'out'),(2948,'out'),(2949,'out')]
assert new[(2669,'in')]==[(2669,'in'),(2949,'out')]
assert new[(2674,'in')]==[(2674,'in'),(2948,'out')]
assert P.L(f2[2948])==[2674] and P.L(f2[2949])==[2669]

# Move each new source component to its immediate earlier arrival's source
# chart, remove the resulting grade-zero contact, and substitute its row into
# the retained outgoing packet. These substitutions preserve the control's
# complete scalar matrix, so protected output errors remain.
r3=r2.copy();f3=f2.copy()
for arrive,outbound in ((2669,2949),(2674,2948)):
    assert f3[outbound]==1<<arrive
    src,dst=r3[arrive];a,b=r3[outbound];assert dst==a==518
    f3[outbound]=f3[arrive];r3[outbound]=(src,b)
    del r3[arrive];del f3[arrive]
    assert not any((row>>arrive)&1 for row in f3.values())
assert r3[2948]==(420,1) and r3[2949]==(418,1)
import frames
atlas=frames.Atlas(P.word['frames'])
assert all(atlas.grade(*r3[k])==2 for k in (2948,2949))
assert all(atlas.grade(*P.R[k])==1 for k in (2669,2674,2947,2948,2949))
_,previous,fo=P.graph_eval(P.word['start'],P.word['final'],r2,f2)
_,changed,fg=P.graph_eval(P.word['start'],P.word['final'],r3,f3)
assert previous==changed
ar2,af2=P.physical.dual(P.n,r2,f2);_,preva,ao=P.graph_eval(P.word['final'],P.word['start'],ar2,af2)
ar3,af3=P.physical.dual(P.n,r3,f3);_,changeda,ag=P.graph_eval(P.word['final'],P.word['start'],ar3,af3)
assert preva==changeda
assert len([i for i in range(222) if changed[i]!=P.base[i]])==65
# The apparent improvement is intentionally labeled invalid: protected
# output errors preclude its admission to the caller invoice.
hist={1:5,2:-2};pos=Counter({1:5});neg=Counter({2:2})
price={t:P.target_exact.interval_output(P.target_exact.signed(neg,pos,t)) for t in P.trials}
geometry={'retired':2947,'donors':[2948,2949],
 'old_source_component':old[(2669,'in')],
 'rebound_source_components':[new[(2669,'in')],new[(2674,'in')]],
 'rebound_forms':{'2948':P.L(f2[2948]),'2949':P.L(f2[2949])},
 'separately_tested_geometry':{'removed_zero_grade_contacts':[2669,2674],
   'rebound_routes':{'2948':r3[2948],'2949':r3[2949]},
   'rebound_forms':{'2948':P.L(f3[2948]),'2949':P.L(f3[2949])},
   'old_paid_grades':[1,1,1,1,1],'new_paid_grades':[2,2],
   'conditional_apparent_native_savings_if_operator_were_valid':price,
   'forward_all_680_rows_equal_pre_geometry_rebind':'PASS',
   'adjoint_all_680_rows_equal_pre_geometry_rebind':'PASS',
   'chart_validity_and_acyclicity':'PASS',
   'protected_main_rows_in_error':65,
   'admissible':'NO: forward and adjoint protected public maps still fail; graph form only, not a literal physical word'},
 'interpretation':'The two original cochart components and their old coupled span obstruction do not describe the split components after recoding. These transformations produce an invalid operator, so no physical construction or complete caller gain is claimed.'}
(Path(os.environ.get('P104_OUT',Path(__file__).resolve().parent.parent/'receipts'))/'COMBINED-GEOMETRY.json').write_text(json.dumps(geometry,indent=2)+'\n')
print(json.dumps({'triples':triples['counts'],'triple_bounds':triples['directed_maximum_native_gain_interval'],
                  'geometry':geometry['separately_tested_geometry']},indent=2))
