#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""The pinned native BIT word to packet-form extraction and dual graph."""
from collections import defaultdict
from heapq import heapify,heappop,heappush
TREE_WORD="d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d"
TREE_GZIP="d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9"
def need(condition,message):
    if not condition:raise ValueError(message)

def labels(mask):
    while mask:
        low = mask & -mask
        yield low.bit_length()-1
        mask ^= low


def packet_word(word):
    n = word["public"]
    state = [1<<j for j in range(n)] + [0]*word["owned_fields"]
    routes, transfer, clocks = {}, {}, {}
    for ii,(opcode,owner,*tail) in enumerate(word["program"]):
        if opcode == "MOVE":
            packet = n+len(routes)
            routes[packet], transfer[packet], clocks[packet] = tuple(tail),state[owner],ii
            state[owner] = 1<<packet
        elif opcode == "SWAP":
            peer, = tail
            state[owner],state[peer] = state[peer],state[owner]
        elif opcode == "ADD":
            state[owner] ^= state[tail[0]]
        else:
            need(opcode in ("INIT","CLEAR"),"literal packet extraction opcode")
            state[owner] = 0
    transfer.update({~j: state[j] for j in range(n)})
    return routes,transfer,clocks


def dual(n, routes, transfer):
    dual_rows = dict.fromkeys(transfer,0)
    for row, form in transfer.items():
        output = row if row>=0 else ~row
        for j in labels(form):
            dual_rows[~j if j<n else j] ^= 1<<output
    return {k:(b,a) for k,(a,b) in routes.items()},dual_rows


def evaluate(start, final, routes, rows, adjoint):
    arrivals = dict(enumerate(start)) | {k:b for k,(a,b) in routes.items()}
    waits, next_packets = {},defaultdict(list)
    for k,row in rows.items():
        want = routes[k][0] if k>=0 else final[~k]
        parents = list(labels(row))
        need(all(arrivals[p]==want for p in parents),"all chronological packet XOR charts")
        if k>=0:
            pending = [p for p in parents if p in routes]
            waits[k] = len(pending)
            for p in pending:
                next_packets[p].append(k)
    ready = [k for k in waits if not waits[k]]
    heapify(ready)
    order,values = [],{j:1<<j for j in range(len(start))}

    def receive(row):
        result = 0
        for j in labels(row):
            result ^= values[j]
        return result

    while ready:
        head = heappop(ready)
        order.append(head)
        values[head] = receive(rows[head])
        for k in next_packets[head]:
            waits[k] -= 1
            if not waits[k]:
                heappush(ready,k)
    need(len(order)==len(routes),"acyclic restored packet word")
    for j in range(len(start)):
        desired = 1<<j
        if adjoint and j<111:
            desired ^= 1<<(j+111)
        if not adjoint and 111<=j<222:
            desired ^= 1<<(j-111)
        need(receive(rows[~j])==desired,"every exact protected public packet return")
    return order,values


