#!/usr/bin/env python3
"""Pinned forward late-donor-pair pulse screen and exact rebinding control.

For k and d<e later at the same sender chart, delete k, strip k from all
local forms, and XOR k's former sender form into each of d and e. Every
column at protected output positions changes by (v_k^v_d^v_e)*u_k^T.
We also grant deletion of every other packet with original output pulse
supported entirely on the *exact* helper set of that residual, and bill
all of those helpers. This is a screened family, not all retimings or all
possible larger surrender sets.
"""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict, Counter
from bisect import bisect_right
from functools import lru_cache
from itertools import combinations
from heapq import heappush, heappop
import gzip,json,math,os,sys

HERE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(HERE/'source'))
import physical,target_exact
P=HERE/'inputs/WORD.json.gz'
raw=P.read_bytes()
assert sha256(raw).hexdigest()==physical.TREE_GZIP
word=json.loads(gzip.decompress(raw))
assert physical.TREE_WORD==physical.canonical_hash(word) if hasattr(physical,'canonical_hash') else sha256(json.dumps(word,sort_keys=True,separators=(',',':')).encode()).hexdigest()==physical.TREE_WORD
n=word['public']; R,F,clock=physical.packet_word(word)
O,U=physical.evaluate(word['start'],word['final'],R,F,False)
DR,DF=physical.dual(n,R,F)
DO,V=physical.evaluate(word['final'],word['start'],DR,DF,True)
assert len(R)==2874
G={k:abs(word['frames'][str(a)]['dim']-word['frames'][str(b)]['dim']) for k,(a,b) in R.items()}
H={h:word['frames'][str(word['final'][h])]['dim']-word['frames'][str(word['start'][h])]['dim'] for h in range(222,n)}
assert all(1<=g<=8 for g in list(G.values())+list(H.values()))
tree_routes={(517,390),(390,509),(509,0)}
protected_packets={3553}|{k for k in R if R[k] in tree_routes}
assert protected_packets=={2942,2943,2944,3553}
protected=((1<<222)-1)|(1<<411)
L=lambda x:list(physical.labels(x))

def graph_eval(start,end,routes,forms):
    """Evaluate every public column; explicitly validate each local chart and DAG."""
    arrival=dict(enumerate(start))|{k:b for k,(a,b) in routes.items()}
    deps={};children=defaultdict(list)
    for k,expr in forms.items():
        want=routes[k][0] if k>=0 else end[~k]
        for j in physical.labels(expr): assert j in arrival and arrival[j]==want,(k,j,want,arrival.get(j))
        if k>=0:
            refs=[j for j in physical.labels(expr) if j in routes]
            deps[k]=len(refs)
            for j in refs:children[j].append(k)
    heap=[]
    for k,x in deps.items():
        if x==0:heappush(heap,k)
    values={j:1<<j for j in range(n)};order=[]
    def val(mask):
        z=0
        for j in physical.labels(mask):z^=values[j]
        return z
    while heap:
        k=heappop(heap);order.append(k);values[k]=val(forms[k])
        for j in children[k]:
            deps[j]-=1
            if deps[j]==0:heappush(heap,j)
    assert len(order)==len(routes),'noncausal cycle'
    return values,[val(forms[~j]) for j in range(n)],order

def change(k,ds,extra=()):
    """Apply simultaneous deletion and exact source-form transfers."""
    gone={k,*extra};assert not gone.intersection(ds)
    kill=sum(1<<j for j in gone)
    routes={j:r for j,r in R.items() if j not in gone}
    forms={j:(f&~kill) for j,f in F.items() if j not in gone}
    transfer=F[k]&~kill
    for d in ds:forms[d]^=transfer
    return routes,forms

# Inspect the complete 2947 paired geometry and check the algebra by a full
# topological forward and adjoint replay (which correctly rejects the edit).
k=2947;ds=(2948,2949)
assert all(R[d][0]==R[k][0] and clock[d]>clock[k] for d in ds)
res=V[k]^V[ds[0]]^V[ds[1]]
r2,f2=change(k,ds)
_,out,order2=graph_eval(word['start'],word['final'],r2,f2)
base=[1<<i for i in range(n)]
for i in range(111,222):base[i]^=1<<(i-111)
assert all((out[i]^base[i])==(U[k] if res>>i&1 else 0) for i in range(n))
dr2,df2=physical.dual(n,r2,f2)
_,aout,aorder=graph_eval(word['final'],word['start'],dr2,df2)
abase=[1<<i for i in range(n)]
for i in range(111):abase[i]^=1<<(i+111)
assert all((aout[i]^abase[i])==(res if U[k]>>i&1 else 0) for i in range(n))
badforms=f2.copy();badforms[2949]^=1<<2948
try:
    graph_eval(word['start'],word['final'],r2,badforms)
except AssertionError:
    wrong_chart_rejected=True
else:
    raise AssertionError('wrong-chart donor was accepted')
flipped=f2.copy();flipped[2948]^=1<<2674
_,flipped_out,_=graph_eval(word['start'],word['final'],r2,flipped)
assert flipped_out!=out,'erasing an actual donor form must change the operator'
control={'retired':k,'original_clock':clock[k],'route':R[k],'grade':G[k],
         'sender_row':L(F[k]),'sender_row_support_public_inputs':L(U[k]),
         'donors':[{'id':d,'clock':clock[d],'route':R[d],'grade':G[d],'sender_row':L(F[d]),'original_pulse':L(V[d])} for d in ds],
         'residual':L(res),'protected_main_residual':L(res&((1<<222)-1)),
         'helper_residual':L(res&~protected),'owner_411_residual':bool(res&(1<<411)),
         'graph_forward_and_adjoint_topology_and_every_column':'PASS',
         'wrong_chart_donor_rejected':wrong_chart_rejected,
         'flipped_sender_form_changes_operator':flipped_out!=out,
         'expected_outer_product':'PASS','admissible':'NO: protected main outputs change'}

# The signatures capture all 223 protected outputs, including owner 411.
# All candidates are original-clock-ordered (k earlier than d earlier than e).
banks=defaultdict(list)
for k,(src,_) in R.items():
    if k not in protected_packets:banks[src].append(k)
for xs in banks.values():xs.sort(key=clock.__getitem__)
pure=[z for z in R if z not in protected_packets and not (V[z]&protected)]
assert not any(V[z]==0 for z in pure)
@lru_cache(maxsize=200000)
def helper_info(s):
    hs=L(s);eligible=tuple(z for z in pure if not (V[z]&~s))
    return hs,eligible
trials=('0.003879928046156','0.003879929046155')
baseline_path=HERE/'inputs/BASELINE.json'
assert sha256(baseline_path.read_bytes()).hexdigest()=='a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a'
baseline=json.loads(baseline_path.read_bytes())['binary']
assert baseline['native_calls']==36
basepaid=Counter({int(g):c for g,c in baseline['paid'].items()})
basetarget=Counter({int(g):c for g,c in baseline['targets'].items()})
full_before={t:target_exact.signed(basepaid,basetarget,t) for t in trials}
assert all(b[1]<0 for b in full_before.values())
added_paid=basepaid.copy();added_paid[14]+=1
price_controls={t:target_exact.signed(added_paid,basetarget,t) for t in trials}
assert all(price_controls[t][1]<full_before[t][0] for t in trials)
counts=Counter();counts['same_sender_banks']=len(banks);counts['retired_packets']=sum(map(len,banks.values()))
counts['ordered_k_d_e_total']=sum(math.comb(len(x),3) for x in banks.values() if len(x)>=3)
single=[];patterns=[];hists=Counter()
for src,xs in sorted(banks.items()):
    bysig=defaultdict(list)
    for i,j in enumerate(xs):bysig[V[j]&protected].append(i)
    for i,k in enumerate(xs):
        sk=V[k]&protected
        for j in range(i+1,len(xs)):
            d=xs[j]
            sj=(V[d]&protected)^sk
            q=bysig.get(sj,())
            for m in q[bisect_right(q,j):]:
                e=xs[m];s=V[k]^V[d]^V[e]
                assert not s&protected
                counts['protected_preserving_pair_patterns']+=1
                hs,zs=helper_info(s)
                if len(hs)==1:counts['one_helper_residual_patterns']+=1
                if not hs:counts['zero_residual_patterns']+=1
                zs=[z for z in zs if z not in (k,d,e)]
                # This deliberately optimistic bound counts every eligible original
                # pulse as independently removable and freezes the 411 tree.
                gain_hist=Counter([G[k]]+[G[z] for z in zs]);gain_hist.subtract(H[h] for h in hs)
                histkey=tuple((g,c) for g,c in sorted(gain_hist.items()) if c)
                hists[histkey]+=1
                row={'sender_chart':src,'retired':k,'retired_clock':clock[k],
                     'donors':[d,e],'donor_clocks':[clock[d],clock[e]],
                     'surrendered_helpers':hs,'surrendered_grades':[H[h] for h in hs],
                     'grant_extra_deletions':zs,'deleted_grades':[G[k]]+[G[z] for z in zs],
                     'signed_native_histogram':dict(histkey)}
                patterns.append(row)
                if len(hs)==1 and len(single)<20:single.append(row)
directed={};histograms=[];price_by_hist={}
for key,amount in hists.items():
    gain=dict(key)
    positive_hist=Counter({g:c for g,c in gain.items() if c>0})
    negative_hist=Counter({g:-c for g,c in gain.items() if c<0})
    intervals={t:target_exact.signed(negative_hist,positive_hist,t) for t in trials}
    price_by_hist[key]=intervals
    assert all(v[1]<0 for v in intervals.values()),(gain,intervals)
    full={t:(full_before[t][0]+36*v[0],full_before[t][1]+36*v[1]) for t,v in intervals.items()}
    assert all(b[1]<0 for b in full.values())
    histograms.append({'histogram':gain,'count':amount,
                       'exact_gain_interval':{t:target_exact.interval_output(v) for t,v in intervals.items()},
                       'optimistic_complete_36_call_signed_margin':{t:target_exact.interval_output(v) for t,v in full.items()}})
    for t,interval in intervals.items():
        if t not in directed or directed[t][1]<interval[1]:directed[t]=interval
assert sum(hists.values())==counts['protected_preserving_pair_patterns']
def row_intervals(row):return price_by_hist[tuple(sorted(row['signed_native_histogram'].items()))]
for row in patterns:
    row['directed_native_gain_interval']={t:target_exact.interval_output(v) for t,v in row_intervals(row).items()}
best={t:max(patterns,key=lambda row:row_intervals(row)[t][1]) for t in trials}
top=sorted(patterns,key=lambda row:-row_intervals(row)[trials[0]][1])[:20]
positive=[row for row in patterns if any(v[1]>0 for v in row_intervals(row).values())]

# The leading relaxed example also has an actual legal packet-form DAG after
# both the paired rebind and the granted packet deletion. Check each complete
# forward column and each adjoint column after projecting the surrendered roles.
b=best[trials[0]];rr,ff=change(b['retired'],b['donors'],b['grant_extra_deletions'])
_,bo,bord=graph_eval(word['start'],word['final'],rr,ff)
br,bf=physical.dual(n,rr,ff);_,ba,baord=graph_eval(word['final'],word['start'],br,bf)
smask=sum(1<<h for h in b['surrendered_helpers']);cmask=((1<<n)-1)^smask
assert all(bo[i]==base[i] for i in range(n) if i not in b['surrendered_helpers'])
assert all(((ba[i]^abase[i])&cmask)==0 for i in range(n))
best_replay={'retired':b['retired'],'donors':b['donors'],'extra_retired':b['grant_extra_deletions'],
             'surrendered_helpers':b['surrendered_helpers'],'forward_live_packets':len(bord),
             'adjoint_live_packets':len(baord),'forward_all_retained_output_rows':'PASS',
             'adjoint_all_projected_input_columns':'PASS',
             'local_chart_binding_and_acyclic_order':'PASS',
             'limitation':'Packet-form graph replay; this is not a changed literal physical word.'}
receipt={'source_gzip_sha256':physical.TREE_GZIP,'source_canonical_sha256':physical.TREE_WORD,
         'baseline_36_call_invoice_sha256':'a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a',
         'baseline_added_grade_14_paid_control':'rejected by strictly smaller complete signed interval at both trials',
         'protected_tree_and_bridge_packets':sorted(protected_packets),
         'pair_2947_control':control,'counts':dict(counts),'unprotected_original_pulse_packets':len(pure),
         'screen_scope':'All original-clock-later ordered same-sender 2-donor sets, protected mains and owner 411; retire original k, XOR its sender row into both donors, remove every distinct original packet whose pulse lies inside exactly the resulting helper residual, and charge every helper target in that residual. The bridge 3553 and tree packets 2942/2943/2944 are never deleted or donors. Original chart frames and all other paid seats held fixed. No larger helper sets, earlier donors, general retimings or revised nonlinear pulse geometry are exhausted.',
         'maxima':best,'directed_maximum_native_gain_interval':{t:target_exact.interval_output(v) for t,v in directed.items()},
         'best_optimistic_complete_36_call_margin_interval':{t:target_exact.interval_output((full_before[t][0]+36*v[0],full_before[t][1]+36*v[1])) for t,v in directed.items()},
         'distinct_directed_histograms':histograms,'single_helper_patterns':single,
         'all_protected_preserving_patterns':patterns,'best_relaxed_graph_replay':best_replay,
         'positive_granted_seeds':positive,'top':top,
         'pricing':'All protected-preserving signed histograms separately priced by exact rational log bounds and fixed-point directed Taylor enclosure; all upper endpoints are negative.'}
outpath=Path(os.environ.get('P104_OUT',HERE/'receipts'))/'FORWARD-PAIRS.json';outpath.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'counts':dict(counts),'positive':len(positive),'maxima':best,'control_protected':len(control['protected_main_residual'])},indent=2))
