#!/usr/bin/env python3
"""Rational frame and nesting validation, from the independent BIT reviewer."""
from fractions import Fraction
from functools import cache
def require(c,m):
    if not c:raise ValueError(m)

def rational_rank(rows):
    work = [list(row) for row in rows]
    rank = 0
    for column in range(8):
        pivot = next((j for j in range(rank, len(work)) if work[j][column]), None)
        if pivot is None:
            continue
        work[rank], work[pivot] = work[pivot], work[rank]
        for row in work[rank + 1:]:
            factor = row[column] / work[rank][column]
            if factor:
                row[column:] = [x - factor * y for x, y in zip(row[column:], work[rank][column:])]
        rank += 1
    return rank


def annihilates(left, right):
    return all(sum(x * y for x, y in zip(row, dual)) == 0 for row in left for dual in right)


class Atlas:
    def __init__(self, frames):
        self.body = {}
        self.dual = {}
        for label, rows in frames.items():
            chart = int(label)
            body, dual = (tuple(tuple(map(Fraction, row)) for row in rows[k]) for k in ("B", "A"))
            require(len(body) == rows["dim"] and len(body + dual) == 8, f"frame counts at {chart}")
            require(all(len(row) == 8 for row in body + dual), f"frame dimensions at {chart}")
            require(rational_rank(body + dual) == 8 and annihilates(body, dual),
                    f"frame rank and orthogonality at {chart}")
            self.body[chart], self.dual[chart] = body, dual

    @cache
    def grade(self, first, second):
        low, high = sorted((first, second), key=lambda chart: len(self.body[chart]))
        difference = len(self.body[high]) - len(self.body[low])
        return difference if difference > 0 and annihilates(self.body[low], self.dual[high]) else 0

    def main_contacts(self, starts, ends):
        for j in range(111):
            head, body = self.body[starts[j]], self.body[ends[j + 111]]
            require((len(head), len(body), len(self.body[starts[j + 111]]),
                     len(self.body[ends[j]])) == (1, 7, 0, 8), f"contact dimensions at {j}")
            require(annihilates(head, body) and rational_rank(head + body) == 8,
                    f"contact decomposition at {j}")
        return 111

