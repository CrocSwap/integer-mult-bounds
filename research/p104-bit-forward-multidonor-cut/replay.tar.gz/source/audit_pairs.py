#!/usr/bin/env python3
"""Exact independent topological replay of every filtered optimistic pair."""
from pathlib import Path
from collections import Counter
from contextlib import redirect_stdout
from time import process_time
import importlib.util,io,json,os
s=importlib.util.spec_from_file_location('forward_pairs',Path(__file__).with_name('forward_pairs.py'))
p=importlib.util.module_from_spec(s)
with redirect_stdout(io.StringIO()):s.loader.exec_module(p)
counts=Counter();failures=[];checkpoints=[];begin=process_time()
for x in p.patterns:
    k=x['retired'];ds=x['donors'];extra=x['grant_extra_deletions'];H=set(x['surrendered_helpers'])
    res={'retired':k,'donors':ds,'surrendered_helpers':sorted(H)}
    try:
        r,f=p.change(k,ds,extra)
        values,out,_=p.graph_eval(p.word['start'],p.word['final'],r,f)
        mask=sum(1<<h for h in H);keep=((1<<p.n)-1)^mask
        assert all(out[i]==p.base[i] for i in range(p.n) if i not in H), 'forward retained rows'
        ar,af=p.physical.dual(p.n,r,f);_,aout,_=p.graph_eval(p.word['final'],p.word['start'],ar,af)
        assert all(((aout[i]^p.abase[i])&keep)==0 for i in range(p.n)), 'adjoint retained columns'
        counts['all_retained_forward_rows_and_adjoint_columns']+=1
        tree_equal=all(values[t]==p.U[t] for t in p.protected_packets)
        counts['protected_tree_payloads_unchanged' if tree_equal else 'protected_tree_payloads_changed']+=1
        res['protected_tree_payloads_unchanged']=tree_equal
        if len(checkpoints)<3:checkpoints.append(res)
    except Exception as e:
        counts['failures']+=1;res['error']=f'{type(e).__name__}: {e}';failures.append(res)
a={'counts':counts,'failures':failures,'sample':checkpoints,'cpu_seconds':process_time()-begin,
   'scope':'Simultaneous original-coordinate packet-form edit for each of the 184 protected-preserving forward pairs and its granted extra deletions. For all 680 independent public inputs each retained forward output is checked; the transposed adjacency is topologically replayed and every retained input column is checked. Local chart bindings, acyclicity, and exact owner-411 tree payloads are checked. Endpoints, exact helper target losses, price and original packet clock ordering are from FORWARD-PAIRS.json. This is not an INIT/ADD/MOVE/CLEAR literal word, physical erasure proof, or supplier qualification.'}
(Path(os.environ.get('P104_OUT',Path(__file__).resolve().parent.parent/'receipts'))/'FORWARD-PAIR-GRAPH-AUDIT.json').write_text(json.dumps(a,indent=2)+'\n')
print(json.dumps({'counts':counts,'failures':failures[:2],'cpu_seconds':a['cpu_seconds']},indent=2))
