# Provenance and scope

The supplied 680-owner BIT native word and the 36-call invoice are pinned in the README and the executable screen. The packet-form extraction and dualization in `source/physical.py` are adapted from the existing P104 binary physical replay. The rational chart check in `source/frames.py` and the directed arithmetic in `source/target_exact.py` are adapted from the separate P104 independent BIT review. The arithmetic uses rational logarithm bounds with geometric tails and outward fixed-point exponential bounds; it does not certify the physical realizability of a positive invoice.

The two-donor rebind, conditional third-donor extension, component-splitting exercise, controls, and graph replay in this package are this package's work. The graph audit retains exact arbitrary-input coefficients and does not claim that discarding helper targets leaves a qualified physical application.

A separate T02 Codex/assistant investigation examined original adjoint pulses with two retained donors and helper residual support of one to three, including a fixed-point projection with donors explicitly retained. That related screen is distinct from this forward chronological package: it does not establish results for post-recode extra deletions or larger donor sets. Its findings are not inputs to this verifier and are not used in the present price bounds.
