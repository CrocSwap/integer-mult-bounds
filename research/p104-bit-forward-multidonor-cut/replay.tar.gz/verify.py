#!/usr/bin/env python3
"""Reproduce the portable forward multidonor screen in a temporary directory."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json,os,subprocess,sys

root=Path(__file__).resolve().parent
manifest=root/'SHA256SUMS'
for line in manifest.read_text().splitlines():
    digest,rel=line.split('  ',1)
    path=(root/rel).resolve()
    if root not in path.parents or not path.is_file():raise ValueError(f'invalid manifest entry {rel}')
    if sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError(f'SHA-256 mismatch: {rel}')

def read(path):return json.loads(path.read_text())
with TemporaryDirectory(prefix='p104-forward-multidonor-') as d:
    env=os.environ.copy();env['P104_OUT']=d;env['PYTHONDONTWRITEBYTECODE']='1'
    for script in ('followup.py','audit_pairs.py'):
        run=subprocess.run([sys.executable,str(root/'source'/script)],cwd=root,env=env,text=True,capture_output=True)
        if run.returncode:
            print(run.stdout);print(run.stderr,file=sys.stderr)
            raise RuntimeError(f'{script} failed with status {run.returncode}')
        print(f'PASS {script}',flush=True)
    for name in ('FORWARD-PAIRS.json','FORWARD-TRIPLES.json','COMBINED-GEOMETRY.json','FORWARD-PAIR-GRAPH-AUDIT.json'):
        got,expected=read(Path(d)/name),read(root/'receipts'/name)
        if name=='FORWARD-PAIR-GRAPH-AUDIT.json':
            got.pop('cpu_seconds',None);expected.pop('cpu_seconds',None)
        if got!=expected:raise ValueError(f'receipt differs: {name}')
        print(f'PASS {name}',flush=True)
print('PASS_FORWARD_MULTIDONOR_SCREEN')
