# Forward two-donor BIT rebindings: a bounded negative screen

On the pinned 680-owner BIT word, **no pair in the specified forward, chronological, same-sender family yields a positive complete 36-call signed margin** at either `0.003879928046156` or `0.003879929046155`, even after granting all additional packet deletions described below. This is a graph-level price result, not a literal physical-word construction, a universal deletion theorem, a proof of the inherited supplier interfaces, or an improved κ bound.

The census covers **23,849,569** triples `(k,d,e)` in **635** sender-chart banks with original clocks `k < d < e`. The four excluded packets are the owner-411 bridge `3553` and tree packets `2942`, `2943`, and `2944`. Among the 2,870 other packet identities, 184 triples have a combined original output pulse that avoids all 222 protected main outputs and owner 411. Exactly one has a residual supported on just one helper. All 184 were replayed after the proposed changes: each retained forward public output is exact for **every one of the 680 independent original inputs**, the transposed graph passes the corresponding adjoint check, the graph remains acyclic and chart-local, and all four protected packet payloads remain unchanged.

The baseline and each of the 14 distinct signed native histograms are priced with outward rational/fixed-point bounds. The strongest *optimistic* signed native gain is `4^(1-κ) - 6^(1-κ)`, strictly negative at both trials. Adding 36 copies to the pinned full caller invoice yields the following maximum upper bounds over the 184 cases:

| Trial κ | Best native gain per call | Best complete 36-call signed margin |
|---|---:|---:|
| `0.003879928046156` | `< -1.97989039613533238858` | `< -71.27605426163896749` |
| `0.003879929046155` | `< -1.97989039097468987548` | `< -71.27643920240544938` |

These bounds are deliberately favorable to the proposals: for a candidate's exact residual helper set, they count deletion of **every** other non-tree packet whose entire original output pulse is supported in that set, while deducting every surrendered helper target. The retained donors remain paid. The graph audit actually tests all those simultaneous deletions, but the price still does not include costs that a literal physical compilation might add. Full intervals and all cases are in [FORWARD-PAIRS.json](receipts/FORWARD-PAIRS.json); the 184-case graph replay is in [FORWARD-PAIR-GRAPH-AUDIT.json](receipts/FORWARD-PAIR-GRAPH-AUDIT.json).

## What is tested

For a packet `j`, let `u_j` be its exact forward value as a linear form in the 680 public inputs, and `v_j` the original output response to an independent pulse at its arrival. For each eligible packet `k`, take retained, later-clock packets `d,e` sent from the same source chart. Delete `k`, remove all references to its arrival, and XOR the **old sender form** of `k` into the sender forms of `d` and `e`. The added reads remain chart-local; a topological sort checks causality. Before any extra deletion, the resulting public matrix changes by

```
(v_k XOR v_d XOR v_e) · u_k^T.
```

The hash-indexed scan matches all 223 protected bits of this residual, so the count is exhaustive for the original-clock-later two-donor rule just stated. It then charges exactly the residual helper set and grants deletion of every other original packet whose original pulse is contained in it, except the protected tree/bridge and the two retained donors. The graph replay checks the resulting projection for all 680 inputs and both orientations, independently of the price bound. It does not establish a physical erasure procedure or compile a modified `INIT/ADD/MOVE/CLEAR` word.

The only one-helper pair retires packet `868`, retains `1135` and `2320`, and loses helper `663` at grade 4. Its paid saving is grade 1, so the native signed histogram is `+1×grade-1 −1×grade-4`. Its pair is a valid graph-level projection but fails the signed price. The best paid bound instead retires packets `719` and `1564`, retains `968` and `1050`, and surrenders helpers `341` and `664`: saved grades `[1,4]`, lost grades `[6,1]`.

## Packet 2947 and the split geometry

Packet `2947` runs from chart 518 to chart 421 at clock 10388. Its source form is `2669 XOR 2674`; the only other packets at this sender are `2948` and `2949`, at clocks 10391 and 10394. Their combined correction has a residual on **65 protected main outputs and 13 helpers**. Full forward and adjoint graph replay confirms the exact outer-product error, so no choice of helper surrender can make this rebind admissible.

The rebind changes the geometry itself: the old source component `{(2669,in),(2674,in),(2947,out),(2948,out),(2949,out)}` splits into `{(2669,in),(2949,out)}` and `{(2674,in),(2948,out)}`. The two resulting components can separately move to charts 418 and 420; in the graph model, `2669` and `2674` become zero-grade contacts and are spliced away, and `2949` and `2948` become grade-2 contacts. Exact rational frame checks and full forward/adjoint replay verify that this geometry transformation preserves the already **incorrect** rebound matrix. Its apparent `+5×grade-1 −2×grade-2` saving is not admissible because the same 65 protected main rows remain wrong. The earlier fixed-component rank obstruction therefore cannot simply be applied to this changed graph, nor can the geometric saving be booked as a candidate. Details and exact forms are in [COMBINED-GEOMETRY.json](receipts/COMBINED-GEOMETRY.json).

## Restricted triple follow-up

Starting only from the 184 already-protected pairs, append one further later, same-sender donor whose original pulse has no protected support. The resulting 525 distinct triple-donor patterns have no zero- or one-helper residual; all 17 signed histograms have negative directed upper bounds. Their best optimistic complete margins are below `-107.27605426163896749` and `-107.27643920240544938`, respectively. This does **not** enumerate triples whose protected pulse parts cancel only when all three are used. See [FORWARD-TRIPLES.json](receipts/FORWARD-TRIPLES.json).

## Reproduce

Only Python 3 and its standard library are required. From this directory run:

```sh
python3 verify.py
```

The verifier checks the manifest, runs the pair/triple/geometry calculations in a temporary directory, reruns all 184 two-orientation graph audits, compares the generated JSON receipts, and reports `PASS_FORWARD_MULTIDONOR_SCREEN`. Runtime is typically tens of seconds. Negative controls check that a wrong-chart donor is rejected, flipping a sender form changes the operator, and adding a paid grade-14 seat strictly reduces the complete signed interval. Audit runtime is excluded from byte-for-byte receipt comparison.

The original word has gzip SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9` and canonical JSON SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. The independent baseline invoice SHA-256 is `a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a`. The source context is [CrocSwap/integer-mult-bounds #7830 at 87fbf4f7](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15); the enrolled native word here is the separately pinned owner-411-tree word, not an assertion that its gzip bytes are that commit's checkout. [NOTICE.md](NOTICE.md) describes the shared inputs and separate related screen.

The bounds do not cover earlier or retimed donors, sender rewrites beyond this feed transfer, helper sets larger than the exact residual, different individual pulse structure after other recodings, arbitrary three-donor identities, altered charts together with a **valid** repaired operator, or general supplier designs.
