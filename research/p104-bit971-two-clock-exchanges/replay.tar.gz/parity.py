"""Optimistic single-pulse chronological gate for one retained MOVE sender reroute.

The word is projected by x341=x340, paid 968 and 1564 omitted; packet 971
is then omitted from actual stock. Every other carried/terminal scalar is
restricted to its projected two-hole baseline form plus d*x51. If an actual
bank is linearly dependent modulo x51 it is *optimistically* granted any
coefficient d, without verifying it can synthesize x51. Thus an inconsistent
output system excludes the entire stated one-pulse family. This script does
not test unrestricted native recodings nor changing a destination.
"""
import sys,json
from pathlib import Path
from collections import defaultdict,Counter
from context import *
from basis import Basis
from vendor.literal import Charts
U=1<<51; H=341; PAIR={968,1564}; CUT=971

def baseline():
 F={i:1<<(340 if i==H else i) for i in range(n)}
 for k in sorted(moves,key=clocks.get):
  F[k]=0 if k in PAIR else reduce(xor,(F[i] for i in physical.labels(rows[k])),0)
 for o in range(n):
  if o==H:continue
  got=reduce(xor,(F[j] for j in physical.labels(rows[~o])),0)
  want=(1<<o)^((1<<(o-111)) if 111<=o<222 else 0)
  assert got==want,(o,list(physical.labels(got^want)))
 return F
F=baseline()

def gate(override=None, audit=False, use_reach=False, skip_zero=(), movefirst=None, force_loose=(), prepend=()):
 # Override: [packet,new_sender,new_receiver] (or [packet,new_sender]).
 q=defaultdict(Basis); loose={int(c):-2 for c in force_loose}; D={}; active=defaultdict(list); nf=0; eq=[]; notices=[]; reach={w['start'][51],*force_loose}
 def reg(c,v,label,clock):
  if c not in loose and q[c].reduce(v&~U) is not None:loose[c]=clock
  q[c].add(v&~U,1<<label);active[c].append(label)
 def delta(c,v,clock,name):
  nonlocal nf
  m=q[c].reduce(v&~U)
  if m is None:return None
  if use_reach and c not in reach:return int(bool(v&U))
  if c in loose:
   nf+=1;return 1<<nf
  js=tuple(physical.labels(m)); bas=reduce(xor,(F[j] for j in js),0)
  rem=bas^v
  assert rem in (0,U),(name,js,list(physical.labels(rem)))
  return int(rem==U)^reduce(xor,(D[j] for j in js),0)
 for i,c in enumerate(w['start']):
  D[i]=0
  if i!=H:reg(c,F[i],i,-1)
 for ix,k in enumerate(prepend):
  assert k not in PAIR|{CUT,3553}
  phantom=max(moves)+1+ix;F[phantom]=F[k];nf+=1;D[phantom]=1<<nf
  reg(moves[k][1],F[phantom],phantom,-2)
 seq=sorted(moves,key=clocks.get)
 if movefirst is not None:seq.remove(movefirst);seq.insert(0,movefirst)
 for k in seq:
  if k in PAIR: D[k]=0;continue
  if k==CUT:D[k]=1;continue
  if k in prepend:D[k]=0;continue
  if k in skip_zero:
   assert F[k] in (0,U)
   D[k]=int(F[k]==U);continue
  a,b=moves[k]
  if override and k==override[0]:
   a=override[1]
   if len(override)>2:b=override[2]
  d=delta(a,F[k],clocks[k],k)
  if d is None:return {'infeasible_projection_at':k,'sender':a,'prefix_loose':len(loose),'free':nf}
  D[k]=d
  if k==3553:eq.append((n,d))
  reg(b,F[k],k,clocks[k])
  if a in reach and k!=3553:reach.add(b)
 for o,c in enumerate(w['final']):
  if o==H:continue
  target=reduce(xor,(F[j] for j in physical.labels(rows[~o])),0)
  d=delta(c,target,None,~o)
  if d is None:return {'infeasible_projection_at':~o,'sender':c,'prefix_loose':len(loose),'free':nf}
  eq.append((o,d))
 B=Basis()
 for tag,v in eq:B.add(v,1<<tag)
 bad=B.reduce(1)
 return {'override':override,'free':nf,'equation_rank':len(B.r),'contradiction':None if bad is None else list(physical.labels(bad)), 'loose':sorted(loose.items()),'equations_111_162':[str(v) for i,v in eq if i in (111,162)],'desc':'n=680 in contradiction denotes protected 3553 equation'}

if __name__=='__main__':
 out={'control_fixed':gate(), 'reroute_1570_from177_to520':gate([1570,177]), 'reroute_970_from53_to178':gate([970,53,178]), 'reroute_969_from53_to178':gate([969,53,178])}
 print(json.dumps(out,indent=2))
 (ROOT/'receipts/PARITY.json').write_text(json.dumps(out,indent=2)+'\n')
