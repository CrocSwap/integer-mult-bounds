"""Graph controls and hypothetical complete invoices for every legal pair."""
from collections import Counter
from decimal import Decimal
from itertools import combinations
from pathlib import Path
from functools import reduce
from operator import xor
import json

from context import *
from paired_gate import SELECTED, price, signed_bounds, C

def graph(holes):
    values = {i: 1 << (340 if i == 341 else i) for i in range(n)}
    for k in sorted(moves, key=clocks.get):
        values[k] = 0 if k in holes else reduce(
            xor, (values[j] for j in labels(rows[k])), 0)
    errors = []
    for o in range(n):
        if o == 341:
            continue
        actual = reduce(xor, (values[j] for j in labels(rows[~o])), 0)
        expected = (1 << o) ^ ((1 << (o - 111)) if 111 <= o < 222 else 0)
        if actual != expected:
            errors.append({'output': o, 'delta': list(labels(actual ^ expected))})
    return {'holes': sorted(holes), 'checked_outputs': 679, 'wrong_outputs': errors,
            'move_3553': list(labels(values[3553]))}

def histogram_margin(targets, paid, k):
    signed = {g: targets[g] - paid[g] for g in targets.keys() | paid.keys()}
    return signed_bounds(signed, Decimal(k))

def main():
    root = Path(__file__).parent
    bit_raw = (root / 'inputs/BIT.json').read_bytes()
    audit_raw = (root / 'inputs/AUDIT.json').read_bytes()
    assert sha256(bit_raw).hexdigest() == '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'
    assert sha256(audit_raw).hexdigest() == 'a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376'
    bit, rat = json.loads(bit_raw), json.loads(audit_raw)
    def hist(obj):
        return Counter({int(k): int(v) for k, v in obj.items()})
    bt, bp = hist(bit['native']['targets']), hist(bit['native']['paid'])
    rt, rp = hist(rat['signed']['productive']), hist(rat['signed']['paid'])
    assert [grades[k] for k in (968, 971, 1564)] == [1, 1, 4]
    assert C.leg(w['start'][341], w['final'][341]) == 6
    a = graph({968, 1564})
    b = graph({968, 971, 1564})
    assert not a['wrong_outputs'] and len(b['wrong_outputs']) == 60
    assert a['move_3553'] == b['move_3553'] == [411]
    assert all(e['delta'] == [51] for e in b['wrong_outputs'])
    rates = ('0.003879928046156', '0.003879929046155')
    pairs = []
    for pair in combinations(SELECTED, 2):
        p = price(pair)
        if not p['all_routes_legal_positive_nested']:
            pairs.append({'pair': pair, 'status': 'no invoice: illegal edge'})
            continue
        pt, pp = bt.copy(), bp.copy()
        pp[1] -= 72
        pp[4] -= 36
        pt[6] -= 36
        for leg in p['legs']:
            pp[leg['old_grade']] -= 36
            pp[leg['new_grade']] += 36
        assert all(x >= 0 for x in pt.values()) and all(x >= 0 for x in pp.values())
        pairs.append({'pair': pair, 'status': 'hypothetical only: graph excluded',
                      'targets': {str(k): v for k, v in sorted(pt.items()) if v},
                      'paid': {str(k): v for k, v in sorted(pp.items()) if v},
                      'bit_complete_margins': {k: histogram_margin(pt, pp, k) for k in rates},
                      'rational_complete_margins': {k: histogram_margin(rt, rp, k) for k in rates}})
    out = {'scope': 'fixed-clock paired exchanges; signed totals are hypothetical and do not imply a word',
           'two_hole_control': a, 'three_hole_negative_control': b,
           'base_bit_complete_margins': {k: histogram_margin(bt, bp, k) for k in rates},
           'base_rational_complete_margins': {k: histogram_margin(rt, rp, k) for k in rates},
           'pairs': pairs}
    (root / 'receipts/PAIRED-INVOICE-CONTROLS.json').write_text(json.dumps(out, indent=2) + '\n')
    print('PASS 679-output two-hole graph control, 60-error three-hole negative control;')
    print('complete hypothetical 36-call invoices:', sum(x['status'].startswith('hypothetical') for x in pairs), 'legal pairs')

if __name__ == '__main__':
    main()
