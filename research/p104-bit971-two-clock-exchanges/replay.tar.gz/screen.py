#!/usr/bin/env python3
"""Exhaust order-cell necessary conditions for seven paired receivers.

Stock only grows and each received form is its two-hole reference plus an
arbitrary x51 coefficient.  Thus quotient failures are necessary-condition
certificates, not physical sender or word reconstructions.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import reduce
from itertools import combinations, product
from operator import xor
from pathlib import Path
import json, sys
from context import *
from basis import Basis
from parity import F,U,PAIR,CUT
from paired_gate import C, price, separate

ROOT=Path(__file__).resolve().parent
SELECTED=(969,970,1103,1567,1568,1569,1570)
HOLES={968,971,1564}
SEQ=sorted(moves,key=clocks.get)
END=max(clocks.values())+1
LEGAL=[]
for p in combinations(SELECTED,2):
    if price(p)['all_routes_legal_positive_nested']:
        LEGAL.append(p)
assert LEGAL==[(969,970),(969,1567),(970,1567),(1103,1567),
               (1568,1569),(1568,1570),(1569,1570)]
assert all(all(leg['old_grade']==leg['new_grade'] for leg in price(p)['legs']) for p in LEGAL)

def qbasis(stock):
    b=Basis()
    for j in stock:b.add(F[j]&~U,1<<j)
    return b

def init_stock(chart):
    return [i for i,c in enumerate(w['start']) if i!=341 and c==chart]

def fixed_events(pair):
    return [k for k in SEQ if k not in HOLES and k not in pair]

def first_reader(k):
    hits=[j for j in SEQ if j not in HOLES and (rows[j] & (1<<k))]
    assert hits
    return hits[0]

def stock_before(pair,chart,t):
    return init_stock(chart)+[j for j in fixed_events(pair) if moves[j][1]==chart and clocks[j]<t]

def sepcheck(stock,target):
    b=qbasis(stock); assert b.reduce(target&~U) is None
    witness=separate(b,target&~U,stock)
    mask=sum(1<<x for x in witness)
    assert (mask & U)==0
    assert all(not ((F[x]&mask).bit_count() & 1) for x in stock)
    assert ((target&mask).bit_count() & 1)==1
    return {'stock_labels':stock,'stock_rank':len(b.r),'separating_coordinates':witness}

def cell_data(pair,k,reader):
    # Include ALL fixed MOVE events at both source and new receiver, not only
    # incoming arrivals. Their open intervals are the local order cells.
    other=next(j for j in pair if j!=k)
    src=moves[k][0];dst=moves[other][1]
    events=sorted((clocks[j],j) for j in fixed_events(pair)
                  if src in moves[j] or dst in moves[j])
    bounds=[-1]+[t for t,j in events]+[END]
    assert len(bounds)==len(set(bounds))
    oldcell=sum(t<clocks[k] for t,j in events)
    cells=[]
    for ix,(l,r) in enumerate(zip(bounds,bounds[1:])):
        # Rational midpoint avoids simultaneous fixed events.
        t=Fraction(l+r,2)
        source=stock_before(pair,src,t)
        b=qbasis(source);rep=b.reduce(F[k]&~U)
        # This is a necessary test using all prior retained source stock.
        # No post-delivery arrival and no other rerouted arrival is included.
        full=Basis()
        for j in source:full.add(F[j],1<<j)
        exact=full.reduce(F[k])
        cells.append({'interval':[l,r],'at':[t.numerator,t.denominator],
                      'crossed_incident_event':ix!=oldcell,
                      'source_quotient_available':rep is not None,
                      'source_reference_form_available':exact is not None,
                      'arrival_before_old_reader':t<clocks[reader]})
    return {'packet':k,'source':src,'destination':dst,'old_clock':clocks[k],
            'old_cell_index':oldcell,'fixed_incident_events':events,'cells':cells}

def reader_test(pair,lost,reader,arrival_before):
    chart=moves[lost][1]
    assert moves[reader][0]==chart
    stock=stock_before(pair,chart,clocks[reader])
    for j in pair:
        other=next(x for x in pair if x!=j)
        if moves[other][1]==chart and arrival_before[j]:stock.append(j)
    b=qbasis(stock)
    return b.reduce(F[reader]&~U) is not None

def pulse_gate(pair,times):
    # Replay all fixed moves plus both relocated moves by their rational clocks.
    q=defaultdict(Basis); active=defaultdict(list); loose=set(); D={}; eq=[];free=0
    def reg(c,v,label):
        if q[c].reduce(v&~U) is not None:loose.add(c)
        q[c].add(v&~U,1<<label);active[c].append(label)
    def delta(c,v,identity):
        nonlocal free
        m=q[c].reduce(v&~U)
        if m is None:return None
        if c in loose:
            free+=1;return 1<<free
        js=list(labels(m)); diff=reduce(xor,(F[j] for j in js),0)^v
        assert diff in (0,U), (identity,list(labels(diff)))
        return int(diff==U)^reduce(xor,(D[j] for j in js),0)
    for i,c in enumerate(w['start']):
        D[i]=0
        if i!=341:reg(c,F[i],i)
    scheduled=sorted((times.get(k,Fraction(clocks[k])),k) for k in SEQ if k not in HOLES)
    assert len({t for t,k in scheduled})==len(scheduled),'use distinct non-event times'
    swap={pair[0]:moves[pair[1]][1],pair[1]:moves[pair[0]][1]}
    for t,k in scheduled:
        a,b=moves[k]; d=delta(a,F[k],k)
        if d is None:return {'status':'stock_failure','packet':k,'chart':a}
        D[k]=d
        if k==3553:eq.append((680,d))
        reg(swap.get(k,b),F[k],k)
    for o,c in enumerate(w['final']):
        if o==341:continue
        target=reduce(xor,(F[j] for j in labels(rows[~o])),0)
        d=delta(c,target,~o)
        if d is None:return {'status':'output_stock_failure','output':o,'chart':c}
        eq.append((o,d))
    B=Basis()
    for tag,v in eq:B.add(v,1<<tag)
    bad=B.reduce(1); emap=dict(eq)
    assert len(eq)==680 and 680 in emap
    tags=list(labels(bad)) if bad is not None else []
    if bad is not None:assert reduce(xor,(emap[tag] for tag in tags),0)==1
    return {'status':'pulse_contradiction' if bad is not None else 'optimistic_pass',
            'outputs_stock_checked':679,'protected_3553_stock_checked':True,
            'contradiction':tags,'equations':{str(i):str(emap[i]) for i in tags},
            'free_variables':free}

def common_receiver_proof():
    p=(1103,1567);reader=1568;c=178; deadline=clocks[reader]
    assert moves[1103][1]==moves[1567][1]==c
    fixed=fixed_events(p)
    assert not init_stock(c)
    assert not [j for j in fixed if moves[j][1]==c and clocks[j]<deadline]
    assert not [j for j in fixed if moves[j][0]==c and clocks[j]<deadline]
    certs={}
    for missing in p:
        keep=next(j for j in p if j!=missing)
        stock=stock_before(p,c,deadline)+[keep]
        certs[str(missing)]=sepcheck(stock,F[reader])
    # No path, even on free-payload reachability, from x51 to either source
    # or receiver before 1568 when the moved edges are removed. They cannot
    # create such a path when added, since neither source is reachable.
    reach={w['start'][51]}
    for j in fixed:
        if clocks[j]>=deadline:break
        a,b=moves[j]
        if a in reach:reach.add(b)
    assert not {0,73,178}&reach
    assert set(moves[k][0] for k in p)=={0,73}
    assert [(j,clocks[j]) for j in fixed if moves[j][1]==73 and clocks[j]<deadline]==[(1101,1499),(1102,1502)]
    assert not [j for j in fixed if moves[j][1]==0 and clocks[j]<deadline]
    assert moves[1101][0]==moves[1102][0]==0
    # Before first reader the relocated sends cannot alter other stocks:
    # chart 178 has no outgoing. The two source forms contain no x51.
    assert all(not (F[k]&U) for k in p)
    for csrc in (0,73):
        stock=stock_before(p,csrc,deadline)
        assert len(qbasis(stock).r)==len(stock),('source dependent',csrc)
        assert all(not F[j]&U for j in stock)
    examples={
        'original':{1103:Fraction(clocks[1103]),1567:Fraction(clocks[1567])},
        'both_crossed_reverse':{1103:Fraction(3001,2),1567:Fraction(2995,2)},
        'both_crossed_late':{1103:Fraction(6379,2),1567:Fraction(6201,2)},
    }
    checks={}
    for name,times in examples.items():
        result=pulse_gate(p,times)
        assert result['status']=='pulse_contradiction' and result['contradiction']==[111,162], (name,result)
        equations=[int(result['equations'][str(i)]) for i in (111,162)]
        assert equations[0]^equations[1]==1
        assert (equations[0]^1)^equations[1]!=1,'corruption of certificate must fail'
        checks[name]={'times':{str(k):[v.numerator,v.denominator] for k,v in times.items()}, **result}
    return {'deadline':deadline,'receiver':c,'needed_arrivals_certificates':certs,
            'reachable_x51_without_moved_packets':sorted(reach),
            'sources_and_receiver_x51_unreachable':True,
            'source_stock_quotient_independent':True,
            'no_receiver_send_or_fixed_arrival_before_first_reader':True,
            'reason_uniform':'Before reader 1568 both arrivals are required; neither sender is x51 reachable and neither can be affected by receiver 178 before 1568. The unchanged source stocks and the same two arrivals give identical relaxed stock at 1568 regardless of their order. After 1568 all fixed events have the same relative order, so the fixed-clock parity contradiction applies to all such clocks.',
            'sample_sweeps':checks}

def main():
    results=[]
    for pair in LEGAL:
        # Rerouted packets cannot be stock at either relocated sender: this
        # permits independent per-cell sender screens without pair-order ties.
        assert not ({moves[pair[0]][0],moves[pair[1]][0]} & {moves[pair[0]][1],moves[pair[1]][1]})
        readers={k:first_reader(k) for k in pair}
        data={k:cell_data(pair,k,readers[next(x for x in pair if x!=k)]) for k in pair}
        first=[]; universal=[]
        for lost in pair:
            reader=readers[lost];c=moves[lost][1]
            stock=stock_before(pair,c,clocks[reader])
            # Best-case both arrivals granted before all reads, whether or not
            # either sender can generate them; all q values fixed by family.
            stock += [j for j in pair if moves[next(x for x in pair if x!=j)][1]==c]
            b=qbasis(stock)
            info={'lost_packet':lost,'old_receiver':c,'first_surviving_reader':reader,
                  'reader_clock':clocks[reader], 'maximal_stock_sufficient_mod_x51':b.reduce(F[reader]&~U) is not None}
            if b.reduce(F[reader]&~U) is None:
                info['separator']=sepcheck(stock,F[reader]);universal.append(lost)
            first.append(info)
        # Enumerate Cartesian local event cells, including all changed and
        # unchanged cells; common-cell order cannot alter the screen because
        # neither new receiver is a relocated sender.
        counts=Counter(); timing_patterns=Counter(); crossing_counts=Counter()
        for ca,cb in product(data[pair[0]]['cells'],data[pair[1]]['cells']):
            crossed=ca['crossed_incident_event'] or cb['crossed_incident_event']
            crossing_counts[str(int(ca['crossed_incident_event'])+int(cb['crossed_incident_event']))]+=1
            source_ok=ca['source_quotient_available'] and cb['source_quotient_available']
            # Each local cell includes its new receiver's old-reader event.
            arrival={pair[0]:ca['arrival_before_old_reader'],pair[1]:cb['arrival_before_old_reader']}
            r1=reader_test(pair,pair[0],readers[pair[0]],arrival)
            r2=reader_test(pair,pair[1],readers[pair[1]],arrival)
            key=('crossed' if crossed else 'uncrossed')+(' / source-q-pass' if source_ok else ' / source-q-fail')+(' / readers-q-pass' if r1 and r2 else ' / reader-q-fail')
            counts[key]+=1
            timing_patterns[str((arrival[pair[0]],arrival[pair[1]],r1,r2))]+=1
        results.append({'pair':pair,'legs':price(pair)['legs'],'readers':first,
                        'cell_definitions':{str(k):data[k] for k in pair},
                        'cell_pair_count':sum(counts.values()),'cell_counts':dict(counts),
                        'crossing_counts_by_number_of_movers':dict(crossing_counts),
                        'timing_patterns':dict(timing_patterns),'universal_separator_lost_packets':universal})
        print('PAIR',pair,'cells',len(data[pair[0]]['cells']),len(data[pair[1]]['cells']),
              'total',sum(counts.values()),'universal',universal,'counts',dict(counts),flush=True)
    assert sum(bool(x['universal_separator_lost_packets']) for x in results)==6
    out={'scope':'Seven geometry-legal same-grade receiver exchanges; any two distinct times in open cells around fixed MOVE events; omitted 968/971/1564, relation x341=x340; all other forms fixed modulo x51; persistent stock is a free overapproximation.',
         'source_word_canonical_sha256':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d',
         'source_parent_7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
         'parent_7939':'8ec127438a392d06ee1dba5e8a64595f98a1709c (campaign context; this script verifies the separately pinned word, not raw #7939 bytes)',
         'pair_results':results,'common_receiver_proof':common_receiver_proof(),
         'limits':'Source and reader tests are necessary quotient tests on overapproximate retained stock, never proof of a physical sender; fixed packet quotient, fixed other routes and order, plus one x51 pulse only. No physical word or kappa result constructed. Timings at a fixed event are not simultaneous: the two possible strict orders are represented by adjacent open cells.'}
    dest=ROOT/'receipts'/'TWO-CLOCK-CELLS.json'
    payload=json.dumps(out,indent=2,sort_keys=True)+'\n'
    if '--check' in sys.argv:
        assert dest.read_text()==payload, 'recomputed result differs'
        print('PASS deterministic recomputation, six universal separators and common-receiver timed parity')
    else:dest.write_text(payload)
if __name__=='__main__':main()
