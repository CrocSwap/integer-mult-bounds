"""Replay authenticated primitive word and 36-call source invoice."""
from context import *
from vendor import literal

def get(name,digest,packed=False):
 raw=(ROOT/'inputs'/name).read_bytes();assert sha256(raw).hexdigest()==digest
 return json.loads(gzip.decompress(raw) if packed else raw)
caller=get('EFREE-CALLER.json.gz','757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',True)
bit=get('BIT.json','8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d')
rat=get('AUDIT.json','a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376')
charts=literal.Charts(w['frames']);charts.main_contacts(w['start'],w['final'])
fwd,data,_=literal.tape(w,charts);adj,other,_=literal.tape(w,charts,adjoint=True)
assert fwd==literal.expected_rows(n,False) and adj==literal.expected_rows(n,True)
assert data['erase_dirty']==other['erase_dirty']==3554
native_targets=Counter(charts.leg(a,b) for a,b in zip(w['start'][222:],w['final'][222:]))
paid,targets,*_=literal.paired_invoice(caller,data['paid'],native_targets,Counter(e[0] for e in caller['events']))
assert dict(paid)=={int(k):v for k,v in bit['native']['paid'].items()}
assert dict(targets)=={int(k):v for k,v in bit['native']['targets'].items()}
print('PASS literal original 680x680 forward and adjoint, protected tree, and authenticated 36-call invoice; dirty retirements 3554 each')
