#!/usr/bin/env python3
"""Independently check cells, separator certificates, and timed parity samples."""
from collections import Counter,defaultdict
from fractions import Fraction
from functools import reduce
from operator import xor
from itertools import product
from pathlib import Path
import json
from context import *
from vendor.literal import Charts

U=1<<51; HOLES={968,971,1564}; SEQ=sorted(moves,key=clocks.get)
ROOT=Path(__file__).resolve().parent
r=json.loads((ROOT/'receipts/TWO-CLOCK-CELLS.json').read_text())
assert w['start'][340]==w['start'][341]
# Reconstruct references without importing screen/parity/Basis.
f={i:1<<(340 if i==341 else i) for i in range(n)}
for j in SEQ:
    f[j]=0 if j in {968,1564} else reduce(xor,(f[i] for i in labels(rows[j])),0)

def want(o):return (1<<o)^((1<<(o-111)) if 111<=o<222 else 0)
for o in range(n):
    if o==341:continue
    assert reduce(xor,(f[i] for i in labels(rows[~o])),0)==want(o)
assert f[3553]==1<<411 and f[971]==U
neg={i:1<<(340 if i==341 else i) for i in range(n)}
for j in SEQ:neg[j]=0 if j in HOLES else reduce(xor,(neg[i] for i in labels(rows[j])),0)
errors=[]
for o in range(n):
    if o==341:continue
    v=reduce(xor,(neg[i] for i in labels(rows[~o])),0)^want(o)
    if v:errors.append(v)
assert len(errors)==60 and all(v==U for v in errors) and neg[3553]==1<<411

def rank(vectors):
    # Independent low-pivot elimination.
    d={}
    for v in vectors:
        while v:
            p=v&-v
            if p in d:v^=d[p]
            else:d[p]=v;break
    return len(d)

def spans(stock,target,quotient=True):
    mask=~U if quotient else -1
    a=[f[j]&mask for j in stock]
    return rank(a)==rank(a+[target&mask])

def initial(c):return [i for i,v in enumerate(w['start']) if i!=341 and v==c]
def fixed(pair):return [j for j in SEQ if j not in HOLES and j not in pair]
def stock(pair,c,t):return initial(c)+[j for j in fixed(pair) if moves[j][1]==c and clocks[j]<t]
def check_sep(s,target,coordinates):
    z=sum(1<<i for i in coordinates)
    return not(z&U) and all(((f[j]&z).bit_count()&1)==0 for j in s) and ((target&z).bit_count()&1)==1

def independent_pulse(pair,times):
    # Values carried with low-pivot quotient vectors. A dependent bank may
    # emit a fresh independent x51 bit; all stock is kept indefinitely.
    banks=defaultdict(dict); flexible=set(); nv=0; outputs={}; protected=None
    def put(c,v,bit):
        while v:
            p=v&-v
            if p not in banks[c]:banks[c][p]=(v,bit);return
            q,b=banks[c][p];v^=q;bit^=b
        flexible.add(c)
    def send(c,v):
        nonlocal nv
        z=v&~U;bit=0
        while z:
            p=z&-z
            assert p in banks[c],('unavailable',c,list(labels(v)))
            q,b=banks[c][p];z^=q;bit^=b
        if c in flexible:nv+=1;bit^=1<<nv
        return bit
    for i,c in enumerate(w['start']):
        if i!=341:put(c,f[i]&~U,int(bool(f[i]&U)))
    seq=sorted((times.get(j,Fraction(clocks[j])),j) for j in SEQ if j not in HOLES)
    assert len({t for t,j in seq})==len(seq)
    swap={pair[0]:moves[pair[1]][1],pair[1]:moves[pair[0]][1]}
    for t,j in seq:
        a,b=moves[j]; bit=send(a,f[j])
        if j==3553:protected=bit^int(bool(f[j]&U))
        put(swap.get(j,b),f[j]&~U,bit)
    for o,c in enumerate(w['final']):
        if o!=341:outputs[o]=send(c,want(o))^int(bool(want(o)&U))
    assert len(outputs)==679 and protected is not None
    assert outputs[111]^outputs[162]==1
    assert (outputs[111]^1)^outputs[162]!=1 # deliberate certificate corruption
    return outputs[111],outputs[162]

expected_pairs=[(969,970),(969,1567),(970,1567),(1103,1567),
                (1568,1569),(1568,1570),(1569,1570)]
assert [tuple(x['pair']) for x in r['pair_results']]==expected_pairs
charts=Charts(w['frames'])
checks=Counter()
for p in r['pair_results']:
    pair=tuple(p['pair']); fs=fixed(pair); events={}; cells={}; reader={}
    # Independence of the source timing screens and same-grade legality are
    # checked again here rather than imported from the generator.
    assert not ({moves[k][0] for k in pair}&{moves[k][1] for k in pair})
    for k in pair:
        other=next(j for j in pair if j!=k)
        assert charts.leg(moves[k][0],moves[other][1])==grades[k]>0
    checks['same_grade_legal_legs']+=2
    for item in p['readers']:
        k=item['lost_packet']; rd=item['first_surviving_reader'];c=moves[k][1]
        assert item['reader_clock']==clocks[rd] and moves[rd][0]==c
        assert rd==next(j for j in SEQ if j not in HOLES and rows[j]&(1<<k))
        reader[k]=rd
        maximal=stock(pair,c,clocks[rd])+[j for j in pair if moves[next(x for x in pair if x!=j)][1]==c]
        available=spans(maximal,f[rd])
        assert available==item['maximal_stock_sufficient_mod_x51']
        if not available:
            z=item['separator']; assert maximal==z['stock_labels']
            assert check_sep(maximal,f[rd],z['separating_coordinates'])
            assert not check_sep(maximal,f[rd],[]) # corrupted witness rejected
            checks['universal_separators']+=1
    for k in pair:
        d=p['cell_definitions'][str(k)];other=next(j for j in pair if j!=k)
        source=moves[k][0]; dest=moves[other][1]
        ev=sorted((clocks[j],j) for j in fs if source in moves[j] or dest in moves[j])
        assert [list(x) for x in ev]==d['fixed_incident_events']
        bounds=[-1]+[t for t,j in ev]+[max(clocks.values())+1]
        assert len(d['cells'])==len(bounds)-1
        old=sum(t<clocks[k] for t,j in ev)
        assert old==d['old_cell_index']
        cs=[]
        for ix,(a,b) in enumerate(zip(bounds,bounds[1:])):
            t=Fraction(a+b,2); cell=d['cells'][ix];src=stock(pair,source,t)
            assert cell['interval']==[a,b] and cell['at']==[t.numerator,t.denominator]
            assert cell['crossed_incident_event']==(ix!=old)
            assert cell['source_quotient_available']==spans(src,f[k])
            assert cell['source_reference_form_available']==spans(src,f[k],False)
            assert cell['arrival_before_old_reader']==(t<clocks[reader[other]])
            cs.append(cell)
        cells[k]=cs
    total=Counter(); crossed=Counter()
    for a,b in product(cells[pair[0]],cells[pair[1]]):
        time={pair[0]:a['arrival_before_old_reader'],pair[1]:b['arrival_before_old_reader']}
        reader_pass=[]
        for k in pair:
            st=stock(pair,moves[k][1],clocks[reader[k]])
            st += [j for j in pair if moves[next(x for x in pair if x!=j)][1]==moves[k][1] and time[j]]
            reader_pass.append(spans(st,f[reader[k]]))
        change=int(a['crossed_incident_event'])+int(b['crossed_incident_event'])
        crossed[str(change)]+=1
        label=('crossed' if change else 'uncrossed')+(' / source-q-pass' if a['source_quotient_available'] and b['source_quotient_available'] else ' / source-q-fail')+(' / readers-q-pass' if all(reader_pass) else ' / reader-q-fail')
        total[label]+=1
    assert sum(total.values())==p['cell_pair_count']
    assert dict(total)==p['cell_counts'] and dict(crossed)==p['crossing_counts_by_number_of_movers']
    checks['cell_pairs']+=sum(total.values())
    checks['both_clock_cross_fixed_events']+=crossed['2']
    checks['at_least_one_clock_crosses']+=crossed['1']+crossed['2']
# For common destination, both arrivals required, no pre-reader feedback to
# either source, and all source quotients are independent throughout prefix.
pair=(1103,1567);deadline=clocks[1568];c=178
assert not initial(c) and not [j for j in fixed(pair) if c in moves[j] and clocks[j]<deadline]
for missing in pair:
    keep=next(j for j in pair if j!=missing); s=stock(pair,c,deadline)+[keep]
    z=r['common_receiver_proof']['needed_arrivals_certificates'][str(missing)]
    assert z['stock_labels']==s and check_sep(s,f[1568],z['separating_coordinates'])
assert [(j,clocks[j]) for j in fixed(pair) if moves[j][1]==73 and clocks[j]<deadline]==[(1101,1499),(1102,1502)]
assert not [j for j in fixed(pair) if moves[j][1]==0 and clocks[j]<deadline]
assert moves[1101][0]==moves[1102][0]==0
for c in (0,73):
    s=stock(pair,c,deadline)
    assert rank([f[j]&~U for j in s])==len(s)
    assert all(not (f[j]&U) for j in s)
reach={w['start'][51]}
for j in fixed(pair):
    if clocks[j]>=deadline:break
    a,b=moves[j]
    if a in reach:reach.add(b)
assert sorted(reach)==r['common_receiver_proof']['reachable_x51_without_moved_packets']
assert not reach&{0,73,178}
for sample in r['common_receiver_proof']['sample_sweeps'].values():
    times={int(k):Fraction(*v) for k,v in sample['times'].items()}
    for k in pair:
        assert spans(stock(pair,moves[k][0],times[k]),f[k],False)
    bits=independent_pulse(pair,times)
    assert bits[0]^bits[1]==1
    checks['timed_parity_samples']+=1
assert checks['cell_pairs']==16216 and checks['timed_parity_samples']==3
print('PASS independent low-pivot reconstruction, 679 control outputs and 60-corruption negative control,')
print(dict(checks),'with both first readers per pair, sender cells, 3553 and three parity samples (two retimed)')
