# Two-clock receiver exchanges around packet 971

**Result.** All seven geometry-legal, same-grade receiver exchanges from Round 5 stream 01 are excluded for arbitrary pairs of strict delivery orders in the stated one-`x51`-pulse family. Six have a separating quotient functional at at least one displaced first reader even when the replacement arrival is granted free, before all events. The seventh, `(1103,1567)`, has the original output-111/output-162 parity contradiction for every timing that can supply its first reader. No replacement word or κ improvement was constructed.

The reference is the separately pinned 680-owner, owner-411-tree BIT word (canonical SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`), with the [#7830 construction reference](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. Campaign parent [#7939](https://github.com/CrocSwap/integer-mult-bounds/pull/7939), head `8ec127438a392d06ee1dba5e8a64595f98a1709c`, is context supplied to this round; this package does not assert the locally pinned word is that PR's raw word or independently inspect that PR's bytes. See `SOURCES.json` and `parents/R5-01.md`, `parents/R5-02.md`, `parents/R5-10.md`.

## Family and coverage

Identify `x341=x340`, surrender target 341, and remove packets 968, 971 and 1564. Each other packet and retained target must have its own two-hole control form modulo `x51`; senders, the other routes and their relative order are fixed. Exchange the two selected receivers, preserving the two original senders. Both delivery clocks may be independently moved anywhere in the ordering. All 679 retained outputs and packet `3553=x411` remain obligations. Actual stock is overapproximated by keeping all earlier arrivals forever and allowing a free, independent `x51` adjustment at each quotient-dependent bank.

For each relocated packet `screen.py` partitions time at every surviving, fixed **MOVE** incident to either its original sender or new receiver. Thus its open intervals are actual sender/receiver MOVE-order cells, not a separate partition at each primitive `ADD`, `SWAP`, `INIT` or `CLEAR`. The latter do not add received quotient directions to our persistent-stock overapproximation; the impossibility certificates consequently cover their refinements, not a physical schedule compilation. Arrival and reading are strictly ordered. The first and final unbounded order regions are represented by intervals bracketing the first and last fixed MOVE; endpoint output stock is always granted after every MOVE. Because a rerouted destination is never either relocated sender for these seven pairs, any two local cells can be simultaneously realized by distinct rational representatives; the reader tests need only the order of each arrival relative to its first reader. In the common-receiver case, either arrival order is covered by the prefix argument below.

| Exchanged packets | Cell pairs | Universal first-reader separator (lost packet → reader : coordinates) |
|---|---:|---|
| 969, 970 | 72 | `969 → 1560 : 340` |
| 969, 1567 | 4,824 | `969 → 1560 : 340`; `1567 → 1568 : 545` |
| 970, 1567 | 4,815 | `1567 → 1568 : 545` |
| 1103, 1567 | 5,350 | common receiver; see parity argument |
| 1568, 1569 | 225 | `1568 → 2069 : 545`; `1569 → 2219 : 71,545` |
| 1568, 1570 | 465 | `1568 → 2069 : 71` |
| 1569, 1570 | 465 | `1569 → 2219 : 71` |

The total is **16,216** cell pairs: 16,209 cross at least one fixed incident MOVE relative to the original clocks, and 14,450 cross for both moved packets. The table's eight independent certificates annihilate every original incoming form available before the indicated first surviving reader **and** every swapped-in quotient supplied before that reader for free. A separator evaluates to one on the required reader quotient. Both displaced first readers are individually recorded and checked for every pair; for example, removing 970's original first reader 1564 makes 1565 its first surviving reader. A quotient failure is conclusive within the family. A quotient pass is only a necessary test: it does not establish that a literal sender has the exact row, that fields are live, or that a dirty retirement is clean. `TWO-CLOCK-CELLS.json` records each cell's strict-before source test, control-form span diagnostic and arrival flag, together with aggregate counts for the two reader tests; free `x51` corrections and overretained received forms prevent a pass from being interpreted as physical availability.

The sole geometry-legal original parity pair is `(1103,1567)`; `(970,1570)` has an illegal exchanged leg. Both `(1103,1567)` receivers are chart 178, so exchanging them is a route no-op but retiming both is a real order change. Of its 5,350 cell pairs, 1,292 pass both sender-quotient and first-reader quotient tests; these are **not** candidates. Reader 1568 at clock 3192 needs each of the two arrivals: with 1103 absent, coordinate 71 separates, and with 1567 absent, coordinate 545 separates. Before that reader chart 178 has no other arrivals or sends. Sender 0 holds `x545` initially and has no incoming prefix packet; sender 73 holds `x71` initially and receives `x397` at clock 1499 and `x398` at clock 1502, both from sender 0. Their full prefix quotient stocks are independent, and source 0, source 73 and chart 178 are not graph reachable from `x51` before 3192 even with free payload propagation. Therefore the needed payloads have no `x51` part, and the condition at reader 1568 is identical to the original case regardless of their delivery order. From there all remaining fixed events have the same order. The optimistic symbolic sweep checks all 679 output stock requirements and `3553`, and yields equations `1+t=0` at output 111 and `t=0` at output 162. Independent low-pivot replay checks the original and two examples where **both clocks cross** fixed incident events, including reversed delivery order. This is a uniform argument for all admissible clocks, not an inference from those examples alone.

## Caller price and controls

Every legal swap preserves both route grades. Under the favorable hypothetical assumption that the three deletions and surrendered target require no further invoice change, the full 36-call signed delta is `36 · (2 H(1) + H(4) − H(6))` with `H(g)=g^(1−κ)`. `receipts/PAIRED-INVOICE-CONTROLS.json` records all productive and paid grade bins for every legal pair, including both changed routes, and outward-rounded intervals at both trials:

| κ | Prospective complete BIT margin | Complete unchanged rational margin |
|---|---:|---:|
| `0.003879928046156` | `+0.72394573836103250857…` | `+0.21226247016334675537…` |
| `0.003879929046155` | `+0.72356079759455061602…` | `+0.21124392992651434438…` |

These are **hypothetical, unrealized** invoices: no screened case can produce a word. The two-hole graph control checks all 679 expected output forms and `3553=x411`. The no-repair three-hole negative control has 60 wrong retained outputs, all by `x51`, and still `3553=x411`. The independently interpreted original 680-owner word, not a new pair, passes both exact 680×680 orientations and the original 36-call invoice; its interpreter reports 3,554 dirty retirements in each orientation. Round 5 stream 10 separately established a literal two-hole control and its first local erasure obstruction; it is not a three-hole replacement. Finite precision, physical live-field scheduling, clean erasure and the inherited compiler/consumer/analytic interfaces remain separate obligations.

## Replay

Standard-library Python 3.10+; one process at a time:

```sh
sha256sum -c SHA256SUMS
python3 -B verify_word.py
python3 -B screen.py --check
python3 -B verify.py
python3 -B invoice_controls.py
```

`verify.py` independently rebuilds forms, source/receiver events, low-pivot spans, all 16,216 cell counts and both displaced first readers, directly checks the eight universal dual certificates and corruption controls, and replays the three common-receiver parity schedules. `invoice_controls.py` deterministically regenerates the accounting and graph controls. `screen.py --check` deterministically recomputes the full receipt. Inputs and vendor interpreter come from Round 5 stream 01; no network is required.

The conclusion does not cover a different surrendered relation, any additional paid slot, changed sender, changed quotient direction, a second correction direction as in stream 02, changed routes outside the two exchanged receivers, altered relative order of other packets, unrestricted recoding, or extra chart operations that manufacture a quotient direction. It is not a clean reversible supplier or an unqualified κ result.
