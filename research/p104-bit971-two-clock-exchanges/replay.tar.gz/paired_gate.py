"""Bounded fixed-clock receiver exchanges, with optimistic pulse stock.

The 21 unordered pairs of selected MOVE identities retain their original
senders and clocks, but exchange receivers.  Packet 968, 971 and 1564 are
absent; x341=x340, and each remaining packet retains its two-hole control
form modulo x51.  The first necessary-condition gate gives each quotient-
dependent bank an independent, free x51 correction, even if it cannot really
produce x51.  Consequently failure is conclusive inside this family; passage
is only an optimistic result, not an actual-stock or literal-word replay.
"""
from collections import Counter, defaultdict
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from itertools import combinations
from pathlib import Path
from functools import reduce
from operator import xor
import json

from context import *
from basis import Basis
from parity import F, U, PAIR, CUT
from vendor.literal import Charts

SELECTED = (969, 970, 1103, 1567, 1568, 1569, 1570)
C = Charts(w['frames'])
SEQ = sorted(moves, key=clocks.get)

def separate(B, target, available):
    """A dual vector vanishes on stock and evaluates to 1 on target."""
    residual = target
    for p in sorted(B.r, reverse=True):
        if residual & (1 << (p - 1)):
            residual ^= B.r[p][0]
    assert residual
    witness = residual & -residual
    for p in sorted(B.r):
        if (B.r[p][0] & witness).bit_count() & 1:
            witness ^= 1 << (p - 1)
    assert (target & witness).bit_count() & 1
    assert all(not ((F[j] & ~U & witness).bit_count() & 1) for j in available)
    return list(labels(witness))

def gate(pair):
    q = defaultdict(Basis)
    active = defaultdict(list)
    loose = {}
    D = {}
    equations = []
    free = 0
    swap = {pair[0]: moves[pair[1]][1], pair[1]: moves[pair[0]][1]}

    def register(c, value, label, clock):
        if c not in loose and q[c].reduce(value & ~U) is not None:
            loose[c] = clock
        q[c].add(value & ~U, 1 << label)
        active[c].append(label)

    def delta(c, value, clock, identity):
        nonlocal free
        m = q[c].reduce(value & ~U)
        if m is None:
            return None, {
                'identity': identity, 'clock': clock, 'chart': c,
                'required_quotient_coordinates': list(labels(value & ~U)),
                'stock_labels': active[c], 'stock_quotient_rank': len(q[c].r),
                'separator_coordinates': separate(q[c], value & ~U, active[c]),
            }
        if c in loose:
            free += 1
            return 1 << free, None
        js = tuple(labels(m))
        diff = reduce(xor, (F[j] for j in js), 0) ^ value
        assert diff in (0, U)
        return int(diff == U) ^ reduce(xor, (D[j] for j in js), 0), None

    for i, c in enumerate(w['start']):
        D[i] = 0
        if i != 341:
            register(c, F[i], i, -1)
    for k in SEQ:
        if k in PAIR:
            D[k] = 0
            continue
        if k == CUT:
            D[k] = 1
            continue
        a, b = moves[k]
        b = swap.get(k, b)
        d, failure = delta(a, F[k], clocks[k], k)
        if failure:
            return {'status': 'quotient-stock-impossible', 'failure': failure,
                    'free_variables_before_failure': free}
        D[k] = d
        if k == 3553:
            equations.append((680, d))
        register(b, F[k], k, clocks[k])
    for o, c in enumerate(w['final']):
        if o == 341:
            continue
        target = reduce(xor, (F[j] for j in labels(rows[~o])), 0)
        d, failure = delta(c, target, None, ~o)
        if failure:
            failure['output'] = o
            return {'status': 'quotient-stock-impossible', 'failure': failure,
                    'free_variables_before_failure': free}
        equations.append((o, d))
    B = Basis()
    for tag, value in equations:
        B.add(value, 1 << tag)
    contradiction = B.reduce(1)
    if contradiction is not None:
        tags = list(labels(contradiction))
        emap = dict(equations)
        assert reduce(xor, (emap[tag] for tag in tags), 0) == 1
        return {'status': 'pulse-equations-impossible',
                'contradiction_tags': tags,
                'contradiction_equations_decimal': [str(emap[tag]) for tag in tags],
                'tag_680': 'protected MOVE 3553 must equal its old x411 value',
                'free_variables': free, 'equation_rank': len(B.r)}
    return {'status': 'optimistic-pass', 'free_variables': free,
            'equation_rank': len(B.r)}

D = Decimal
LOW = Context(prec=90, rounding=ROUND_FLOOR)
HIGH = Context(prec=90, rounding=ROUND_CEILING)
NEAR = Context(prec=90)

def h(rank, rate):
    if rank == 1:
        return D(1), D(1)
    ln = NEAR.ln(D(rank))
    t = LOW.subtract(D(1), rate)
    assert t == HIGH.subtract(D(1), rate)
    return (NEAR.next_minus(NEAR.exp(LOW.multiply(t, NEAR.next_minus(ln)))),
            NEAR.next_plus(NEAR.exp(HIGH.multiply(t, NEAR.next_plus(ln)))))

def signed_bounds(signed, rate):
    lo = hi = D(0)
    for g, c in signed.items():
        a, b = h(g, rate)
        if c >= 0:
            lo = LOW.add(lo, LOW.multiply(a, c))
            hi = HIGH.add(hi, HIGH.multiply(b, c))
        else:
            lo = LOW.add(lo, LOW.multiply(b, c))
            hi = HIGH.add(hi, HIGH.multiply(a, c))
    return [str(lo), str(hi)]

def price(pair):
    legs = []
    for k, other in (pair, pair[::-1]):
        a = moves[k][0]
        b = moves[other][1]
        try:
            new_grade = C.leg(a, b)
        except ValueError:
            new_grade = None
        legs.append({'move': k, 'old_route': list(moves[k]),
                     'new_route': [a, b], 'old_grade': grades[k],
                     'new_grade': new_grade})
    result = {'legs': legs, 'all_routes_legal_positive_nested':
              all(x['new_grade'] is not None for x in legs)}
    if not result['all_routes_legal_positive_nested']:
        return result
    # 36 native calls, including both exchanged edges, three deletions,
    # and surrendered productive target 341.  No physical implementation
    # or other downstream change is credited.
    s = Counter({1: 72, 4: 36, 6: -36})
    for leg in legs:
        s[leg['old_grade']] += 36
        s[leg['new_grade']] -= 36
    result['signed_grade_changes'] = {str(k): v for k, v in sorted(s.items()) if v}
    result['gain'] = {rate: signed_bounds(s, D(rate)) for rate in
                      ('0.003879928046156', '0.003879929046155')}
    return result

def main():
    results = []
    for pair in combinations(SELECTED, 2):
        r = {'pair': list(pair), 'gate': gate(pair), 'price': price(pair)}
        results.append(r)
        print(*pair, r['gate']['status'],
              r['gate'].get('failure', {}).get('identity', r['gate'].get('contradiction_tags')),
              'legal', r['price']['all_routes_legal_positive_nested'], flush=True)
    out = {'scope': __doc__, 'source_pins': {'7830': '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
            '7852': '41beda1d6435760dc99e38bd7e65f36798aad212'},
            'selected': SELECTED, 'results': results}
    (Path(__file__).parent / 'receipts/PAIRED-GATE.json').write_text(json.dumps(out, indent=2) + '\n')

if __name__ == '__main__':
    main()
