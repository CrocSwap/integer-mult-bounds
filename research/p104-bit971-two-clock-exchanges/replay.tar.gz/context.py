"""Pinned word and lossless packet extraction; extracted from the cited native verifier."""
from pathlib import Path
from collections import Counter,defaultdict
from functools import reduce
from operator import xor
from hashlib import sha256
from types import SimpleNamespace
import gzip,json,sys
ROOT=Path(__file__).resolve().parent
raw=(ROOT/'inputs/WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));n=w['public'];assert n==680
assert sha256(json.dumps(w,separators=(',',':'),sort_keys=True).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
def labels(mask):
 while mask:
  low=mask&-mask;yield low.bit_length()-1;mask^=low
physical=SimpleNamespace(labels=labels)
def packet_word(word):
 state=[1<<j for j in range(n)]+[0]*word['owned_fields'];routes={};transfer={};clocks={}
 for clock,(op,owner,*tail) in enumerate(word['program']):
  if op=='MOVE':
   k=n+len(routes);routes[k]=tuple(tail);transfer[k]=state[owner];clocks[k]=clock;state[owner]=1<<k
  elif op=='SWAP':state[owner],state[tail[0]]=state[tail[0]],state[owner]
  elif op=='ADD':state[owner]^=state[tail[0]]
  else:assert op in ('INIT','CLEAR');state[owner]=0
 transfer.update({~j:state[j] for j in range(n)})
 return routes,transfer,clocks
moves,rows,clocks=packet_word(w)
grades={k:abs(w['frames'][str(a)]['dim']-w['frames'][str(b)]['dim']) for k,(a,b) in moves.items()}
