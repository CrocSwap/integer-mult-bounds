"""GF(2) reduced basis with representation witnesses."""
class Basis:
 def __init__(self):self.r={};self.support=0
 def add(self,x,wt):
  self.support|=x
  while x and x.bit_length() in self.r:
   y,m=self.r[x.bit_length()];x^=y;wt^=m
  if x:self.r[x.bit_length()]=(x,wt)
 def reduce(self,x):
  if x&~self.support:return None
  wt=0
  while x and x.bit_length() in self.r:
   y,m=self.r[x.bit_length()];x^=y;wt^=m
  return None if x else wt
