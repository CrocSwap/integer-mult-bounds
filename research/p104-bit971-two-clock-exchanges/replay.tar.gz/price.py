"""Directed prospective complete invoices; no constructed candidate claimed."""
from decimal import Context,Decimal,ROUND_CEILING,ROUND_FLOOR
from context import *
D=Decimal;LOW=Context(prec=90,rounding=ROUND_FLOOR);HIGH=Context(prec=90,rounding=ROUND_CEILING);NEAR=Context(prec=90)
def bounds(rank,rate):
 if rank==1:return D(1),D(1)
 ln=NEAR.ln(D(rank));t=LOW.subtract(D(1),rate);assert t==HIGH.subtract(D(1),rate)
 return (NEAR.next_minus(NEAR.exp(LOW.multiply(t,NEAR.next_minus(ln)))), NEAR.next_plus(NEAR.exp(HIGH.multiply(t,NEAR.next_plus(ln)))))
def margin(targets,paid,rate):
 val=[]
 for hist in (targets,paid):
  lo=hi=D(0)
  for k,v in hist.items():
   a,b=bounds(int(k),rate);lo=LOW.add(lo,LOW.multiply(a,v));hi=HIGH.add(hi,HIGH.multiply(b,v))
  val.append((lo,hi))
 return LOW.subtract(val[0][0],val[1][1]),HIGH.subtract(val[0][1],val[1][0])
def get(name,digest):
 raw=(ROOT/'inputs'/name).read_bytes();assert sha256(raw).hexdigest()==digest;return json.loads(raw)
bit=get('BIT.json','8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d')
rat=get('AUDIT.json','a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376')
out={}
for k in ('0.003879928046156','0.003879929046155'):
 x=D(k);h4=bounds(4,x);h6=bounds(6,x);h7=bounds(7,x);h8=bounds(8,x)
 credit=(LOW.multiply(D(36),LOW.subtract(LOW.add(D(2),h4[0]),h6[1])),HIGH.multiply(D(36),HIGH.subtract(HIGH.add(D(2),h4[1]),h6[0])))
 penalty=(LOW.multiply(D(36),LOW.subtract(h8[0],h7[1])),HIGH.multiply(D(36),HIGH.subtract(h8[1],h7[0])))
 binary=margin(bit['native']['targets'],bit['native']['paid'],x);rational=margin(rat['signed']['productive'],rat['signed']['paid'],x)
 out[k]={'baseline_bit':list(map(str,binary)),'baseline_rational':list(map(str,rational)),'optimistic_three_omission_gain':list(map(str,credit)), 'hypothetical_binary_with_three_omissions':[str(LOW.add(binary[0],credit[0])),str(HIGH.add(binary[1],credit[1]))], 'min_one_grade_rise_penalty':list(map(str,penalty)), 'hypothetical_binary_after_one_grade_rise':[str(LOW.subtract(LOW.add(binary[0],credit[0]),penalty[1])),str(HIGH.subtract(HIGH.add(binary[1],credit[1]),penalty[0]))]}
print(json.dumps(out,indent=2));(ROOT/'receipts/PRICE.json').write_text(json.dumps(out,indent=2)+'\n')
