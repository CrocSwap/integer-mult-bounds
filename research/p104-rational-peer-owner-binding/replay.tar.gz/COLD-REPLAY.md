# Local replay record

A one-core, offline `python3 -I -B verify.py` run passed the full manifest, fresh temporary-copy construction, changed rational forward and adjoint operators, all 48 owner-labelled native inventories, reconstructed caller, unchanged BIT word and caller, and all three byte-identical expected receipts. It also rejected the distinct-helper owner swap, wrong literal and canonical digests, a missing BIT retirement, an altered BIT paid-rank price, a corrupted rational candidate copy at invoice assembly, and a corrupted source at the manifest gate.

The run took 30.44 seconds wall time with a maximum resident set of 248,860 KiB. These figures describe this local run, not a required performance bound. The mathematical and physical scope remains the one stated in the README.
