# Independent cross-check of a changed rational component

This is a bounded, independent replay of [Ali Romman's public rational component at commit `d018f6ce89ba76b5ac0f56e1e23d73658d7f4681`](https://github.com/aliromman/integer-mult-bounds/tree/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain), paired with the unchanged BIT control from [Clear1nsight's #7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) at commit `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. It does not claim that this pairing has been selected, adopted, or qualified as an application. Current coordination is in [discussion #7111](https://github.com/CrocSwap/integer-mult-bounds/discussions/7111#discussioncomment-19777325).

The changed rational graph passes a separately implemented exact rational forward and adjoint replay: all **1,289 public rows** agree with the declared operator, and all **5,700 paid moves have a first reader**. The independently regenerated 48-call owner binding has **42,672 call-local helper owners**, with 400 main contacts per call. Enumerating the 48 labelled native invoices and adding the separately reconstructed fixed caller gives **282,816 paid and 52,512 productive occurrences**. Every rank bin agrees with the cited component's receipt. This is a raw signed-invoice and owner-binding check.

At the near trial, the changed rational account has positive headroom but the original 36-call BIT account does not:

| κ | Rational productive minus paid | Unchanged BIT productive minus paid |
|---|---:|---:|
| 0.003879929046155 | +3.452573399956609040156437758734… | −0.000385127316613866441054139472… |
| 0.003884928046155 | −1.634903688468347568633537318057… | −1.925615290709237255327353524062… |

The displayed decimals are rounded summaries of directed intervals in [the rational receipt](expected/JOINT-RATIONAL-REPLAY.json) and [the two-invoice assembly](expected/JOINT-TWO-INVOICES.json). The rational invoice changes sign between `0.00388332156403` and `0.00388332156404`, as the public component reports. The first raw trial above the directed BIT crossing, `0.003879928046156`, has BIT balance below `−0.000000000767001502431130261463999524…`. Neither jointly checked trial has two strictly positive balances. These arithmetic results are not a new κ bound.

## Ownership is part of the binding

The public rational word uses helper address 324 for **new owner label 1542**, in place of old label 338, and changes helper input or return charts at addresses 324, 449, 1254, and 1255. All 400 main-port boundaries remain within the pinned contract. The numerical public matrices still have the same hashes as the baseline; this does not make the old and new helper ownership interchangeable. The check requires the exact changed layout, checks that 1542 is fresh relative to the old labels, and gives every helper the key `(call, label)`.

The inherited helper-label digest sorts labels before hashing. A negative control swaps two distinct helper labels at addresses 324 and 449; labels remain unique, and the inherited sorted helper and stage-binding digests remain unchanged. The pinned ordered address-to-label contract rejects the swap, and an independent ordered owner-map digest changes. This demonstrates the scope of that digest, not a claim that every other upstream check accepts a swapped word. Separate wrong literal-SHA and wrong canonical-SHA controls reject before replay. The unchanged BIT replay also checks a missing retirement and an added paid-rank mutation.

The [#7863 consumer receipt](https://github.com/CrocSwap/integer-mult-bounds/blob/b3e4412fe01f07dc58305616fabf96345f49a781/research/p104-bit-451-factor-schedule/CONSUMER.json) explicitly binds the older rational word; the [tagged-source code in #7868](https://github.com/CrocSwap/integer-mult-bounds/blob/3f7c3c1f2a9a0963736562037e01fe41aec46b8c/research/bounded-general-multiplier/tagged_sources.py) pins the older word, layout and caller. A new outer use would need regenerated occurrence and owner tags and a separate requalification of the relevant compiler, supply, erasure, precision, stock and outer interfaces. No physical supply, candidate-specific precision tape, physical erasure, compiler, or outer application replay is supplied here.

## Reproduce

From this directory, using CPython 3.12 and only its standard library:

```sh
python3 -I -B verify.py
```

The verifier checks every file against `SHA256SUMS`, copies the inputs to a fresh temporary directory, independently replays the BIT control and changed rational graph, constructs the two-sided invoice, and compares all three receipts byte for byte with the frozen expected receipts. Each replay is single-process. A representative rational replay used about 250 MiB peak memory and 25 seconds on one core. It does not require network access.

The exact source identities and provenance are in [SOURCE-PINS.md](SOURCE-PINS.md). The cited component's relevant input files and attribution are preserved in `source-ali/`; the predecessor notices and licenses are preserved with their source copies. The independently implemented replay is offered under the accompanying Apache-2.0 license.
