#!/usr/bin/env python3
"""Bind one or both independent replay receipts to the complete two-sided price.

This is arithmetic over independently recounted bins, not a physical or
asymptotic acceptance gate. Each supplied receipt must name the literal SHA
and a still-identical frozen local candidate copy.
"""
import argparse
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import changed_bit_replay as bit
import target_exact as exact


def need(ok, why):
    if not ok:
        raise ValueError(why)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--bit-receipt',type=Path)
    p.add_argument('--bit-sha256')
    p.add_argument('--rational-receipt',type=Path)
    p.add_argument('--rational-sha256')
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    need(a.out.resolve().parent==HERE,'output location')
    need(bool(a.bit_receipt)==bool(a.bit_sha256) and bool(a.rational_receipt)==bool(a.rational_sha256),
         'each receipt requires its supplied literal SHA')
    need(a.bit_receipt or a.rational_receipt,'at least one independently replayed word')
    raw=(HERE/'BASELINE.json').read_bytes()
    need(sha256(raw).hexdigest()==bit.BASE_SHA,'authenticated full baseline')
    baseline=json.loads(raw)
    result={'status':'PASS_FULL_SIGNED_ACCOUNT_ASSEMBLY_ONLY',
            'scope':'Both signed rank invoices under unchanged counterpart assumptions; no physical, finite supplier, precision, compiler or outer qualification.',
            'baseline_sha256':bit.BASE_SHA,'sides':{},'targets':{}}
    sources={}
    for name,receipt,expected in (('binary',a.bit_receipt,a.bit_sha256),('rational',a.rational_receipt,a.rational_sha256)):
        if receipt:
            payload=receipt.read_bytes(); data=json.loads(payload)
            want='PASS_LITERAL_BIT_OPERATOR_AND_COMPLETE_SIGNED_INVOICE' if name=='binary' else 'PASS_LITERAL_RATIONAL_OPERATOR_AND_COMPLETE_SIGNED_INVOICE'
            need(data['status']==want and data['candidate']['sha256']==expected, f'{name} candidate binding')
            path=Path(data['candidate']['clean_copy'])
            need(path.resolve().parent==HERE and sha256(path.read_bytes()).hexdigest()==expected,
                 f'{name} clean byte-pinned copy')
            inventory=data['invoice']
            paid=bit.as_counts(inventory['paid']); productive=bit.as_counts(inventory['productive'])
            need(sum(paid.values())==inventory['paid_count'] and sum(productive.values())==inventory['productive_count'],
                 f'{name} histogram census')
            source={'kind':'changed candidate replay', 'candidate_sha256':expected,
                    'receipt_sha256':sha256(payload).hexdigest(),'receipt':receipt.name}
        else:
            inventory=baseline[name]
            paid=bit.as_counts(inventory['paid']); productive=bit.as_counts(inventory['targets'])
            source={'kind':'unchanged authenticated baseline'}
        need(all(type(k) is int and k>0 and type(v) is int and v>=0
                 for hist in (paid,productive) for k,v in hist.items()), f'{name} valid rank bins')
        sources[name]=(paid,productive)
        result['sides'][name]={'source':source,'paid_count':sum(paid.values()),
                               'productive_count':sum(productive.values())}
    for target in exact.TARGETS:
        record={}
        for name,(paid,productive) in sources.items():
            v=exact.signed(paid,productive,target)
            record[name]={'productive_minus_paid':exact.interval_output(v),'strictly_positive':v[0]>0}
        record['both_strictly_positive'] = all(record[name]['strictly_positive'] for name in sources)
        result['targets'][target]=record
    a.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['status'])
    for target, row in result['targets'].items():
        print(target,'both strictly positive:',row['both_strictly_positive'])


if __name__=='__main__':
    main()
