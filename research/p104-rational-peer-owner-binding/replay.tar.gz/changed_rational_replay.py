#!/usr/bin/env python3
"""Independent literal rational-graph replay with the authenticated caller.

The rational native graph is re-evaluated from exact Fraction coefficients,
including causality, nesting, public endpoints and adjoints. The fixed 48-call
caller is reconstructed by the separately authored, source-locked predecessor
reviewer. This is not a new physical erasure, precision, compiler or outer
application proof. Only candidates preserving the baseline layout/endpoints
and source caller are supported.
"""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
from math import gcd, lcm
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import changed_bit_replay as bit
import target_exact as exact

NATIVE = HERE/'inputs/7830/research/p104-chart306-chain/DOUBLE-CANDIDATE.json.gz'
LAYOUT = HERE/'inputs/7786/research/p104-iterated-returns/continuation/LAYOUT.json.gz'
GRAPH_REVIEWER = HERE/'inputs/cache/parent/complex/independent.py'
GRAPH_REVIEWER_PIN = '0b428bc6fac4dc6ec014114bf4119782553fbb58d92b2a632b51629f4abe563b'


def need(ok, why):
    if not ok:
        raise ValueError(why)


def chart_spans(frames):
    result = []
    for frame in frames:
        span = {0}
        for axis in frame:
            need(type(axis) is int and 0 < axis < 512 and axis not in span, 'independent chart basis')
            span |= {x ^ axis for x in span}
        result.append(frozenset(span))
    return result


def parse(raw):
    n, first, frames = len(raw['initial']), raw['first_output'], raw['frames']
    need(n == len(raw['final']) == 1289 and type(first) is int and first > 0, 'public dimensions')
    def chart(c):
        return type(c) is int and 0 <= c < len(frames)
    need(all(chart(x) for x in raw['initial']+raw['final']), 'public chart ids')
    moves = {}
    for node, src, dst in raw['moves']:
        need(type(node) is int and 0 <= node < first and node not in moves and chart(src) and chart(dst),
             'paid move identity')
        moves[node] = (src, dst)
    forms = {}
    for node, terms in raw['forms']:
        need(type(node) is int and node not in forms and terms, 'form identity')
        entries = {}
        for donor, literal in terms:
            need(type(donor) is int and donor not in entries and type(literal) is str, 'donor identity')
            q = Fraction(literal)
            need(q and str(q) == literal, 'canonical nonzero rational coefficient')
            entries[donor] = q
        forms[node] = entries
    order = raw['schedule']
    need(set(forms) == set(moves) | set(range(first,first+n)), 'complete move and terminal forms')
    need(len(order) == len(forms) and set(order) == set(forms), 'unique complete chronology')
    available = {~i: c for i,c in enumerate(raw['initial'])}
    first_read = {}
    for clock, node in enumerate(order):
        src = moves[node][0] if node in moves else raw['final'][node-first]
        for donor in forms[node]:
            need(donor in available, f'chronology {node} donor {donor}')
            need(available[donor] == src, f'chart binding {node} donor {donor}')
            if donor in moves:
                first_read.setdefault(donor, (clock, node, src))
        if node in moves:
            available[node] = moves[node][1]
    need(set(first_read) <= set(moves), 'reader identity')
    return moves, forms, order, first_read


def expected(raw, layout, spans):
    n = len(raw['initial'])
    need(layout['frames'] == raw['frames'] and layout['public'] == n, 'layout binding')
    labels = layout['source_labels']
    need(len(labels) == len(set(labels)) == n, 'public owner labels')
    host = layout['hosted']
    need(tuple(Fraction(host[k]) for k in ('alpha','beta','alpha2','beta2')) ==
         (-1,Fraction(1,2),-1,0), 'signed port constants')
    secondary = dict(zip(host['Dports'], zip(host['X2'], host['Y2'], strict=True), strict=True))
    need(len(secondary) == 96 and set(secondary) <= set(range(104)), 'secondary ports')
    need(len(layout['live']) == len(layout['ports']) == len(set(layout['ports'])) == 104, 'primary ports')
    out, mains = [{i: Fraction(1)} for i in range(n)], set()
    for p, (x, axis) in enumerate(zip(layout['live'], layout['ports'], strict=True)):
        y = x+112
        group = (x,y) + tuple(secondary.get(p, ()))
        need(all(type(i) is int and 0 <= i < n and i not in mains for i in group), 'disjoint port owners')
        mains.update(group)
        need(raw['frames'][raw['initial'][x]] == [axis] and raw['frames'][raw['initial'][y]] == [],
             f'primary input charts {p}')
        need(spans[raw['final'][x]] == frozenset(range(512)) and
             spans[raw['final'][y]] == frozenset(v for v in range(512) if (v&axis).bit_count()%2 == 0),
             f'primary return charts {p}')
        if p in secondary:
            u,v = secondary[p]
            need(all(seq[a] == seq[b] for seq in (raw['initial'], raw['final']) for a,b in ((u,x),(v,y))),
                 f'secondary charts {p}')
            out[y][x] = Fraction(1)
            out[u][v] = Fraction(-1)
        else:
            out[x][y] = Fraction(-1)
            out[y] = {x: Fraction(1,2), y: Fraction(1,2)}
    need(len(mains) == 400, 'all 400 main owners')
    return out, mains


def combine(terms):
    """Return sparse exact row as (positive common denominator, integer map)."""
    terms = [(den*q.denominator, values, q.numerator) for (den, values), q in terms if values and q]
    denom = lcm(*(d for d,_,_ in terms))
    nums = defaultdict(int)
    for d, row, numerator in terms:
        scalar = numerator*(denom//d)
        for key, val in row.items():
            nums[key] += scalar*val
    nums = {k:v for k,v in nums.items() if v}
    common = gcd(denom, *nums.values())
    return denom//common, {k:v//common for k,v in nums.items()}


def unpack(row):
    denom, nums = row
    return {k: Fraction(v,denom) for k,v in nums.items()}


def forward(n, first, moves, forms, order):
    state = {~i:(1,{i:1}) for i in range(n)}
    out = [None]*n
    for node in order:
        row = combine((state[donor], q) for donor,q in forms[node].items())
        if node in moves:
            state[node] = row
        else:
            out[node-first] = unpack(row)
    return out


def adjoint(n, first, forms, order):
    pending = {first+i:[((1,{i:1}),Fraction(1))] for i in range(n)}
    for node in reversed(order):
        row = combine(pending.pop(node, ()))
        if row[1]:
            for donor,q in forms[node].items():
                pending.setdefault(donor, []).append((row,q))
    return [unpack(combine(pending.pop(~i, ()))) for i in range(n)]


def transpose(rows):
    out = [{} for _ in rows]
    for i,row in enumerate(rows):
        for j,v in row.items():
            out[j][i] = v
    return out


def row_hash(rows):
    return bit.canonical_digest([[[j,str(v)] for j,v in sorted(row.items())] for row in rows])


def native_ranks(raw, spans, moves, mains):
    paid, productive = Counter(), Counter()
    for a,b in moves.values():
        need(spans[a] < spans[b] or spans[b] < spans[a], 'strictly nested paid charts')
        paid[abs(len(raw['frames'][a])-len(raw['frames'][b]))] += 1
    for owner,(a,b) in enumerate(zip(raw['initial'],raw['final'],strict=True)):
        if owner not in mains:
            need(spans[a] < spans[b], 'strictly productive helper endpoint')
            productive[len(raw['frames'][b])-len(raw['frames'][a])] += 1
    return paid, productive


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    need(args.out.resolve().parent == HERE, 'output must be directly in own replay directory')
    need(len(args.sha256) == 64 and all(c in '0123456789abcdef' for c in args.sha256), 'literal lowercase SHA')
    raw = args.candidate.read_bytes()
    need(sha256(raw).hexdigest() == args.sha256, 'candidate SHA mismatch')
    copy = HERE/('RATIONAL-CANDIDATE-'+args.sha256+('.json.gz' if raw.startswith(b'\x1f\x8b') else '.json'))
    if copy.exists():
        need(copy.read_bytes() == raw, 'candidate copy mismatch')
    else:
        copy.write_bytes(raw)
    need(sha256(copy.read_bytes()).hexdigest() == args.sha256, 'clean candidate copy')
    for name, pin in bit.REVIEW_PINS.items():
        a, b = (HERE/name).read_bytes(), (bit.CHECKOUT/'review'/name).read_bytes()
        need(a == b and sha256(a).hexdigest() == pin, f'clean exact-head review source {name}')
    for name, pin in bit.authenticated_review.PRODUCER_SOURCE_PINS.items():
        a, b = (HERE/'comparator'/name).read_bytes(), (bit.CHECKOUT/name).read_bytes()
        need(a == b and sha256(a).hexdigest() == pin, f'clean exact-head producer source {name}')
    need(bit.authenticated_review.authenticate(HERE/'inputs',False) == (20,127), 'inherited source locks')
    need(sha256(GRAPH_REVIEWER.read_bytes()).hexdigest() == GRAPH_REVIEWER_PIN, 'reviewer source pin')
    need(sha256((HERE/'BASELINE.json').read_bytes()).hexdigest() == bit.BASE_SHA, 'recounted baseline')
    base, cand, layout = map(bit.read_json, (NATIVE.read_bytes(), copy.read_bytes(), LAYOUT.read_bytes()))
    need(set(base) == set(cand) and all(base[k] == cand[k] for k in base if k not in ('moves','forms','schedule')),
         'candidate requires unchanged frames, public endpoints and namespace')
    spans = chart_spans(cand['frames'])
    moves, forms, order, first_reads = parse(cand)
    want, mains = expected(cand, layout, spans)
    rows = forward(len(want), cand['first_output'], moves, forms, order)
    need(rows == want, 'complete rational forward operator')
    cols = adjoint(len(want), cand['first_output'], forms, order)
    need(cols == transpose(want), 'complete rational adjoint operator')
    native_paid, native_productive = native_ranks(cand, spans, moves, mains)
    # Authenticate and reconstruct the fixed caller with the separate source
    # reviewer, rather than importing caller counts from a producer receipt.
    reviewer = bit.authenticated_review.load('round2_rational_review', GRAPH_REVIEWER)
    graph = reviewer.Graph.parse(cand)
    caller_paid, caller_productive, binding = reviewer.signed_caller(
        HERE/'inputs/cache/source/research/p104-dual-supplier-lift',graph,layout)
    paid = Counter({k:48*v for k,v in native_paid.items()}); paid.update(caller_paid)
    productive = Counter({k:48*v for k,v in native_productive.items()}); productive.update(caller_productive)
    receipt = json.loads((HERE/'BASELINE.json').read_bytes())['rational']
    oldpaid, oldproductive = bit.as_counts(receipt['paid']), bit.as_counts(receipt['targets'])
    if cand == base:
        need((paid,productive) == (oldpaid,oldproductive), 'independent baseline full signed bins')
    paid_delta = paid.copy(); paid_delta.subtract(oldpaid)
    productive_delta = productive.copy(); productive_delta.subtract(oldproductive)
    prices = {}
    for k in exact.TARGETS:
        old, new = exact.signed(oldpaid,oldproductive,k), exact.signed(paid,productive,k)
        prices[k] = {'old_signed': exact.interval_output(old), 'new_signed': exact.interval_output(new),
                     'signed_improvement': exact.interval_output((new[0]-old[1],new[1]-old[0])),
                     'strictly_positive_candidate_balance': new[0] > 0}
    first_hash = bit.canonical_digest([[node,*first_reads[node]] for node in sorted(first_reads)])
    label_hash = bit.canonical_digest([[call,node,*moves[node]] for call in range(48) for node in sorted(moves)])
    result = {'status':'PASS_LITERAL_RATIONAL_OPERATOR_AND_COMPLETE_SIGNED_INVOICE',
        'scope':'Exact native graph, chronology, first reads, full forward and adjoint, plus fixed caller from the separately authored locked reviewer. Layout and endpoints unchanged. No candidate-specific precision tape, erasure implementation, compiler, or outer application replay.',
        'source':{'construction_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','explicit':20,'inherited':127,
                  'fixed_caller_reviewer_sha256': GRAPH_REVIEWER_PIN, 'baseline_sha256':bit.BASE_SHA},
        'candidate':{'sha256':args.sha256,'clean_copy':str(copy),'same_as_baseline':cand==base},
        'operator':{'public_rows_each':len(want),'forward_sha256':row_hash(rows),'adjoint_sha256':row_hash(cols),
                    'native_moves':len(moves),'scheduled_forms':len(order),'first_reader_count':len(first_reads),
                    'unread_paid_moves':len(moves)-len(first_reads),'first_reader_sha256':first_hash,
                    'native_paid_occurrence_sha256':label_hash},
        'fixed_caller': {'finite_binding':binding['finite_binding'],'readback':binding['readback']},
        'invoice':{'paid':dict(sorted(paid.items())),'productive':dict(sorted(productive.items())),
                   'paid_count':sum(paid.values()),'productive_count':sum(productive.values()),
                   'paid_change_by_rank':{str(k):v for k,v in sorted(paid_delta.items()) if v},
                   'productive_change_by_rank':{str(k):v for k,v in sorted(productive_delta.items()) if v},
                   'prices':prices},
        'precision_tape':'NOT REPLAYED','physical_erasure':'NOT REPLAYED','outer_application':'NOT REPLAYED'}
    args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['status'],args.sha256,'paid',sum(paid.values()),'productive',sum(productive.values()))
    print('native paid rank delta',result['invoice']['paid_change_by_rank'])
    print('precision tape, physical erasure and outer application NOT REPLAYED')


if __name__ == '__main__':
    main()
