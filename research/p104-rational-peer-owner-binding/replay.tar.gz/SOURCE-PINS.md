# Source identities and interpretation

The words and layouts below are source data, not proof that either component is a complete application.

| Item | Identity |
|---|---|
| Changed rational word, literal gzip SHA-256 | `731246c085638706bdb97e7e88618f8923e27ee4ce8eb4869f0847f8f4699f7c` |
| Changed rational word, canonical decoded JSON SHA-256 | `7e74ad15ba7564ad2207acac6c6cafcc57ae3b19386f6d332dd1c0fca968a17e` |
| Changed rational layout, literal gzip SHA-256 | `84cd1d11ff454eecf3504e4b3f26adc371539b17553bfce1bcfda7a331811998` |
| Changed rational layout, canonical decoded JSON SHA-256 | `90929fe1885c0b22004933c22fa57d1bea09f6c1d5955f540e3afb4a8fd0cf42` |
| #7830 parent rational word, literal gzip SHA-256 | `1b1b3294e86979f1f41076fb056f3c0a08ace6df7bf80f2886bc579a22962f4b` |
| #7830 parent rational word, canonical decoded JSON SHA-256 | `7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48` |
| #7786 rational layout, literal gzip SHA-256 | `b0f3ebc5710e469f3e8fc5ce159cbba048b563944182b50993431ef94f4fedbf` |
| #7786 BIT word, literal gzip SHA-256 | `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9` |
| #7786 BIT word, canonical decoded JSON SHA-256 | `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d` |
| Retained independent rational reviewer SHA-256 | `0b428bc6fac4dc6ec014114bf4119782553fbb58d92b2a632b51629f4abe563b` |
| Fixed baseline recount SHA-256 | `a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a` |

The changed word, layout, edit journal and published rational receipt are the files under [`research/p104-live-relative-gain`](https://github.com/aliromman/integer-mult-bounds/tree/d018f6ce89ba76b5ac0f56e1e23d73658d7f4681/research/p104-live-relative-gain) at Ali Romman's `d018f6ce89ba76b5ac0f56e1e23d73658d7f4681`. `joint_replay.py` checks their literal SHA-256 values and public Git blob IDs. The journal binds their canonical digests to the parent source. The retained `source-ali/README.md` states the component's own claims, methods, limitations and predecessor credits.

The parent rational graph is [#7830's `DOUBLE-CANDIDATE.json.gz`](https://github.com/CrocSwap/integer-mult-bounds/blob/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-chart306-chain/DOUBLE-CANDIDATE.json.gz). The unchanged binary word and parent layout are pinned at [#7786 commit `89a67c404226d51028e135de2b9169e9020d57af`](https://github.com/CrocSwap/integer-mult-bounds/tree/89a67c404226d51028e135de2b9169e9020d57af/research/p104-iterated-returns). The review sources and manifest use the exact #7830 head above, which is distinct from the older retained rational-invoice source head `14c74c6a67108f675ac1196a5f2415ead0920e71` recorded in `BASELINE.json`.

The independent parser re-evaluates the actual changed rational graph and independently computes the exact native rank bins. It reconstructs the fixed caller by executing the separately authored, source-locked reviewer. This is independence of the native graph replay and pricing arithmetic, not a new independent proof of the fixed caller, compiler, or inherited premises. A source check verifies **20 explicitly listed plus 127 inherited pins**; the bundled public source licenses and notices remain with their files.

The changed rational per-call records distinguish `(call, native move, source chart, destination chart, grade)` and `(call, helper address, source label, source chart, return chart, grade)`. The fixed caller is counted separately and only once in the total. Equal rank histograms do not by themselves establish owner compatibility.
