#!/usr/bin/env python3
"""Offline isolated replay of the two pinned accounts and negative controls."""
from hashlib import sha256
from pathlib import Path, PurePosixPath
from tempfile import TemporaryDirectory
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BIT = 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
RATIONAL = '731246c085638706bdb97e7e88618f8923e27ee4ce8eb4869f0847f8f4699f7c'
EXPECTED = ('JOINT-BIT-BASELINE.json', 'JOINT-RATIONAL-REPLAY.json', 'JOINT-TWO-INVOICES.json')


def need(value, message):
    if not value:
        raise ValueError(message)


def manifest():
    result = []
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest, path = line.split('  ', 1)
        item = PurePosixPath(path)
        need(len(digest)==64 and all(c in '0123456789abcdef' for c in digest), 'manifest digest')
        need(not item.is_absolute() and '..' not in item.parts and path not in {v[1] for v in result}, 'manifest path')
        result.append((digest,path))
    need(result, 'empty manifest')
    return result


def check_tree(root, entries):
    for digest, name in entries:
        path = root/name
        need(path.is_file() and not path.is_symlink(), 'missing manifest file '+name)
        need(sha256(path.read_bytes()).hexdigest()==digest, 'source hash mismatch '+name)


def invoke(root, arguments, expect=True, error=None):
    completed = subprocess.run([sys.executable,'-I','-B',*arguments], cwd=root, text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    if expect:
        need(completed.returncode==0, 'replay failed: '+completed.stderr[-4000:])
        print(completed.stdout, end='')
    else:
        need(completed.returncode!=0 and error in completed.stderr, 'expected corruption rejection')


def main():
    entries=manifest();check_tree(ROOT,entries)
    with TemporaryDirectory(prefix='joint-component-') as name:
        root=Path(name)
        for _, filename in entries:
            dst=root/filename;dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(ROOT/filename,dst)
        check_tree(root,entries)
        invoke(root,['changed_bit_replay.py','--candidate','inputs/7786/research/p104-iterated-returns/binary/WORD.json.gz',
                     '--sha256',BIT,'--out','JOINT-BIT-BASELINE.json'])
        invoke(root,['joint_replay.py'])
        assembly=['two_invoices.py','--bit-receipt','JOINT-BIT-BASELINE.json','--bit-sha256',BIT,
                  '--rational-receipt','JOINT-RATIONAL-REPLAY.json','--rational-sha256',RATIONAL,
                  '--out','JOINT-TWO-INVOICES.json']
        invoke(root,assembly)
        for filename in EXPECTED:
            need((root/filename).read_bytes()==(root/'expected'/filename).read_bytes(), 'frozen result mismatch '+filename)
        # The receipt cannot be rebound to a changed candidate byte stream.
        copy=root/('RATIONAL-CANDIDATE-'+RATIONAL+'.json.gz')
        copy.write_bytes(copy.read_bytes()+b'\x00')
        invoke(root,assembly,expect=False,error='rational clean byte-pinned copy')
        # A damaged original source must fail the package manifest itself.
        source=root/'source-ali/WORD.json.gz';source.write_bytes(source.read_bytes()+b'\x00')
        try:
            check_tree(root,entries)
        except ValueError as exc:
            need('source hash mismatch source-ali/WORD.json.gz' in str(exc), 'wrong damaged-source rejection')
        else:
            raise ValueError('damaged source passed manifest')
    print('PASS clean offline replay, three exact receipts, owner/digest controls, and two corrupted-byte rejections')


if __name__=='__main__':
    main()
