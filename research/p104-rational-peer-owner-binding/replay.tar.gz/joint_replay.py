#!/usr/bin/env python3
"""Pinned external rational word against the independent #7830 caller.

The previous replayer only accepts unchanged helper boundaries. This wrapper
allows exactly the observed labelled helper substitution and boundary changes.
It reports raw invoices and simulated caller binding, not physical provision,
precision, compiler or outer application qualification.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha1, sha256
from pathlib import Path
import argparse
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import changed_bit_replay as bit
import changed_rational_replay as rat
import target_exact as exact

ALI = HERE/'source-ali'
CHECKOUT = HERE/'source-7830'
PINS = {
    'WORD.json.gz': ('731246c085638706bdb97e7e88618f8923e27ee4ce8eb4869f0847f8f4699f7c', '31786df96c1da3fe7adc42e30839265b29a90964'),
    'LAYOUT.json.gz': ('84cd1d11ff454eecf3504e4b3f26adc371539b17553bfce1bcfda7a331811998', '3ee3637e63e4a2c135b29ae44b39937d6f33ab4b'),
    'EVENTS.json': ('544840ed2aa50dc16788708c6828fedb667e0c129edd3e3aac09652a056e7b6e', '57f3d637077a678a4cf07750b0ddb11792a6494f'),
    'RATIONAL-RECEIPT.json': ('603358c1bc198d689dedb4b591a684170be41ac7b242a50ebd5a12a05ec5c97a', '2687233d8daf63a17355cab2223e0a13b12c5fe6')}
WORD_CANON = '7e74ad15ba7564ad2207acac6c6cafcc57ae3b19386f6d332dd1c0fca968a17e'
LAYOUT_CANON = '90929fe1885c0b22004933c22fa57d1bea09f6c1d5955f540e3afb4a8fd0cf42'
BASE_WORD_CANON = '7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'
BASE_LAYOUT_CANON = 'f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7'
TARGETS = ('0.003879928046156', '0.003879929046155', '0.003884928046155', '0.00391884648', '0.00388332156403', '0.00388332156404')


def need(condition, message):
    if not condition:
        raise ValueError(message)


def check_digest(raw, literal, canonical=None):
    need(sha256(raw).hexdigest() == literal, 'literal digest mismatch')
    if canonical is not None:
        need(bit.canonical_digest(bit.read_json(raw)) == canonical, 'canonical digest mismatch')


def delta(old, new):
    return [[i, a, b] for i, (a, b) in enumerate(zip(old, new, strict=True)) if a != b]


def contract(base, candidate, base_layout, layout):
    need(set(base) == set(candidate) and all(base[k] == candidate[k]
         for k in base if k not in ('initial', 'final', 'moves', 'forms', 'schedule')),
         'non-helper graph boundary or namespace changed')
    need(set(layout) == set(base_layout) and all(layout[k] == base_layout[k]
         for k in layout if k != 'source_labels'), 'caller geometry changed')
    need(delta(base_layout['source_labels'], layout['source_labels']) == [[324,338,1542]],
         'owner label mapping differs from the pinned intended substitution')
    need(1542 not in base_layout['source_labels'] and 338 not in layout['source_labels'],
         'fresh helper label not distinct or removed label reused')
    need(delta(base['initial'], candidate['initial']) == [[324,3,1048],[1254,2,293]],
         'unexpected helper input boundary change')
    need(delta(base['final'], candidate['final']) == [[324,234,127],[449,127,1048],[1255,498,480]],
         'unexpected helper return boundary change')
    spans = rat.chart_spans(candidate['frames'])
    want, mains = rat.expected(candidate, layout, spans)
    changed = {324,449,1254,1255}
    need(not changed & mains, 'main port owner changed')
    need(len(set(layout['source_labels'])) == 1289, 'public label alias')
    return spans, want, mains


def source_authentication():
    for name, pin in bit.REVIEW_PINS.items():
        a, b = (HERE/name).read_bytes(), (bit.CHECKOUT/'review'/name).read_bytes()
        need(a == b and sha256(a).hexdigest() == pin, 'exact-head review file '+name)
    for name, pin in bit.authenticated_review.PRODUCER_SOURCE_PINS.items():
        a, b = (HERE/'comparator'/name).read_bytes(), (bit.CHECKOUT/name).read_bytes()
        need(a == b and sha256(a).hexdigest() == pin, 'exact-head producer file '+name)
    need(bit.authenticated_review.authenticate(HERE/'inputs', False) == (20,127), 'inherited source locks')
    need(sha256(rat.GRAPH_REVIEWER.read_bytes()).hexdigest() == rat.GRAPH_REVIEWER_PIN, 'fixed-caller reviewer pin')
    need(sha256((HERE/'BASELINE.json').read_bytes()).hexdigest() == bit.BASE_SHA, 'baseline pin')
    a = rat.NATIVE.read_bytes(); b = (CHECKOUT/'research/p104-chart306-chain/DOUBLE-CANDIDATE.json.gz').read_bytes()
    need(a == b and sha256(a).hexdigest() == '1b1b3294e86979f1f41076fb056f3c0a08ace6df7bf80f2886bc579a22962f4b', 'actual #7830 rational source')
    return {'construction_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
            'rational_source_sha256':sha256(a).hexdigest(),'explicit_pins':20,'inherited_pins':127,
            'fixed_caller_reviewer_sha256':rat.GRAPH_REVIEWER_PIN, 'baseline_sha256':bit.BASE_SHA}


def load_sources():
    hashes = {}
    for name, (pin, blob) in PINS.items():
        raw = (ALI/name).read_bytes()
        check_digest(raw, pin)
        computed = sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        need(computed == blob, 'public git blob mismatch '+name)
        hashes[name] = {'sha256':pin, 'git_blob_sha1':computed}
    wraw, lraw = (ALI/'WORD.json.gz').read_bytes(), (ALI/'LAYOUT.json.gz').read_bytes()
    check_digest(wraw, PINS['WORD.json.gz'][0], WORD_CANON)
    check_digest(lraw, PINS['LAYOUT.json.gz'][0], LAYOUT_CANON)
    candidate, layout = bit.read_json(wraw), bit.read_json(lraw)
    base, base_layout = bit.read_json(rat.NATIVE.read_bytes()), bit.read_json(rat.LAYOUT.read_bytes())
    need(bit.canonical_digest(base) == BASE_WORD_CANON and bit.canonical_digest(base_layout) == BASE_LAYOUT_CANON,
         'old canonical word/layout pins')
    events = json.loads((ALI/'EVENTS.json').read_bytes())
    need((events['source'],events['layout'],events['canonical_sha256'],events['child_layout_sha256'],events['birth_source_label']) ==
         (BASE_WORD_CANON, BASE_LAYOUT_CANON, WORD_CANON, LAYOUT_CANON, 1542), 'journal parent and child binding')
    return base, candidate, base_layout, layout, hashes


def reject(fn, expected):
    try:
        fn()
    except (ValueError, TypeError, KeyError) as exc:
        need(expected in str(exc), f'wrong control rejection: {exc}')
        return str(exc)
    raise ValueError('negative control unexpectedly accepted')


def controls(base, cand, old_layout, layout):
    modified = deepcopy(layout)
    modified['source_labels'][324],modified['source_labels'][449] = modified['source_labels'][449],modified['source_labels'][324]
    need(len(set(modified['source_labels'])) == 1289, 'swapped owner retains uniqueness')
    _, _, mains = contract(base, cand, old_layout, layout)
    def helper_digest(value):
        helpers = sorted(label for i,label in enumerate(value['source_labels']) if i not in mains)
        return sha256(json.dumps(helpers, separators=(',', ':')).encode()).hexdigest()
    original_helper_digest=helper_digest(layout)
    need(helper_digest(modified)==original_helper_digest, 'swapped helper multiset control')
    original_map=bit.canonical_digest([[i,layout['source_labels'][i]] for i in range(1289) if i not in mains])
    swapped_map=bit.canonical_digest([[i,modified['source_labels'][i]] for i in range(1289) if i not in mains])
    need(original_map != swapped_map, 'ordered owner map digest detects swap')
    swapped = reject(lambda: contract(base,cand,old_layout,modified), 'owner label mapping')
    raw = (ALI/'WORD.json.gz').read_bytes()
    bad_literal = reject(lambda: check_digest(raw, '0'*64, WORD_CANON), 'literal digest mismatch')
    bad_canonical = reject(lambda: check_digest(raw, PINS['WORD.json.gz'][0], '0'*64), 'canonical digest mismatch')
    # A literal terminal coefficient alteration preserves rank inventories but
    # must break both public operators; run the complete operator check only in full mode.
    return {'swapped_distinct_helper_owners': {'addresses':[324,449], 'labels_unique':True,
             'same_sorted_helper_label_digest':True,'sorted_helper_label_digest':original_helper_digest,
             'ordered_owner_map_sha256':original_map,'swapped_owner_map_sha256':swapped_map,'rejection':swapped},
            'wrong_literal_digest':bad_literal, 'wrong_canonical_digest':bad_canonical}


def labelled_inventory(cand, layout, spans, moves, mains):
    labels = layout['source_labels']; calls=[]; all_paid=Counter(); all_targets=Counter()
    for call in range(48):
        paid, productive = Counter(), Counter(); h=sha256(); q=sha256(); owners=set()
        for node,(a,b) in sorted(moves.items()):
            r=abs(len(cand['frames'][a])-len(cand['frames'][b])); paid[r]+=1
            h.update((json.dumps([call,node,a,b,r],separators=(',',':'))+'\n').encode())
        for i,(a,b) in enumerate(zip(cand['initial'],cand['final'],strict=True)):
            if i not in mains:
                owner=(call,labels[i]); need(owner not in owners, 'owner alias within call'); owners.add(owner)
                r=len(cand['frames'][b])-len(cand['frames'][a]); productive[r]+=1
                q.update((json.dumps([call,i,labels[i],a,b,r],separators=(',',':'))+'\n').encode())
        need(len(owners)==889, 'all independent call-local helpers')
        calls.append({'call':call,'paid':dict(sorted(paid.items())),'productive':dict(sorted(productive.items())),
                      'paid_count':sum(paid.values()),'productive_count':sum(productive.values()),
                      'paid_labels_sha256':h.hexdigest(), 'productive_owners_sha256':q.hexdigest()})
        all_paid.update(paid); all_targets.update(productive)
    need(len({x['paid_labels_sha256'] for x in calls})==48 and len({x['productive_owners_sha256'] for x in calls})==48,
         'each occurrence gets an independent call id')
    return calls, all_paid, all_targets


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--quick', action='store_true'); a=ap.parse_args()
    auth=source_authentication(); base,cand,bl,layout,hashes=load_sources()
    spans,want,mains=contract(base,cand,bl,layout); negatives=controls(base,cand,bl,layout)
    moves, forms, order, reads=rat.parse(cand)
    paid1, target1=rat.native_ranks(cand,spans,moves,mains)
    need(len(moves)==5700 and len(reads)==len(moves), 'all paid arrivals have a reader')
    calls, all_paid, all_targets=labelled_inventory(cand,layout,spans,moves,mains)
    need(all_paid == Counter({k:48*v for k,v in paid1.items()}) and all_targets == Counter({k:48*v for k,v in target1.items()}), '48 independently labelled native invoices')
    labels = {'old_helper_label_at_address_324':338,'new_helper_label_at_address_324':1542,
              'changed_initial':delta(base['initial'],cand['initial']), 'changed_final':delta(base['final'],cand['final']),
              'old_and_new_label_unique':True,'old_label_removed':True,'fresh_label_absent_from_old':True,
              'changed_addresses_exclude_400_main_ports':True,'per_call_helper_owners':889,
              'number_distinct_call_helper_labels':48*889}
    result={'status':'PASS_PINNED_QUICK_OWNER_AND_48_NATIVE_CENSUS' if a.quick else 'PENDING',
            'source':auth,'external':{'commit':'d018f6ce89ba76b5ac0f56e1e23d73658d7f4681','files':hashes,
            'word_canonical_sha256':WORD_CANON,'layout_canonical_sha256':LAYOUT_CANON},
            'ownership':labels,'negative_controls':negatives,'native':{'moves':len(moves),
            'first_readers':len(reads),'native_paid':dict(sorted(paid1.items())),
            'native_productive':dict(sorted(target1.items())),'calls':calls}}
    if a.quick:
        path=HERE/'JOINT-QUICK.json';path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print(result['status'], '48 call labels and full native bins checked');return
    rows=rat.forward(len(want),cand['first_output'],moves,forms,order)
    need(rows == want, 'complete rational forward operator')
    adj=rat.adjoint(len(want),cand['first_output'],forms,order)
    need(adj == rat.transpose(want), 'complete rational adjoint operator')
    reviewer=bit.authenticated_review.load('round3_rational_review', rat.GRAPH_REVIEWER)
    graph=reviewer.Graph.parse(cand)
    caller_paid, caller_productive, binding=reviewer.signed_caller(HERE/'inputs/cache/source/research/p104-dual-supplier-lift',graph,layout)
    paid=all_paid.copy();paid.update(caller_paid)
    productive=all_targets.copy();productive.update(caller_productive)
    producer=json.loads((ALI/'RATIONAL-RECEIPT.json').read_bytes())
    need(paid == bit.as_counts(producer['paid']) and productive == bit.as_counts(producer['productive']), 'independent full signed bins differ from public receipt')
    base_receipt=json.loads((HERE/'BASELINE.json').read_bytes()); oldpaid=bit.as_counts(base_receipt['rational']['paid']); oldtargets=bit.as_counts(base_receipt['rational']['targets'])
    bitpaid=bit.as_counts(base_receipt['binary']['paid']); bittargets=bit.as_counts(base_receipt['binary']['targets'])
    pd=paid.copy();pd.subtract(oldpaid); td=productive.copy();td.subtract(oldtargets)
    margins={}
    for t in TARGETS:
        left=exact.signed(bitpaid,bittargets,t);right=exact.signed(paid,productive,t);old=exact.signed(oldpaid,oldtargets,t)
        margins[t]={'binary_baseline':exact.interval_output(left),'rational_changed':exact.interval_output(right),
                    'rational_baseline':exact.interval_output(old),
                    'rational_improvement':exact.interval_output((right[0]-old[1],right[1]-old[0])),
                    'both_strictly_positive':left[0]>0 and right[0]>0}
    need(exact.signed(paid,productive,'0.00388332156403')[0]>0 and exact.signed(paid,productive,'0.00388332156404')[1]<0,
         'public crossing endpoint signs')
    original_binding=base_receipt['rational']['binding']
    new_binding=binding['finite_binding']
    need(new_binding['helper_label_sha256'] != original_binding['helper_label_sha256'] and
         new_binding['stage_binding_sha256'] != original_binding['stage_binding_sha256'], 'helper rebinding must change binding digests')
    need(new_binding['helper_label_sha256'] == negatives['swapped_distinct_helper_owners']['sorted_helper_label_digest'],
         'caller really uses sorted helper-label digest, insensitive to helper swaps')
    # Re-run the inherited binding function itself under a helper-label swap.
    # Its sorted helper digest, and hence stage binding digest, are unchanged;
    # the ordered address->label contract above is a separate guard.
    from closed_caller import templates, placement
    from mixed_caller import layout_bindings
    caller_file=HERE/'inputs/cache/source/research/p104-dual-supplier-lift/complex/retained/data/CALLER.json.gz'
    caller_data=bit.read_json(caller_file.read_bytes())
    swapped_layout=deepcopy(layout)
    swapped_layout['source_labels'][324],swapped_layout['source_labels'][449] = (
        swapped_layout['source_labels'][449],swapped_layout['source_labels'][324])
    _,_,swapped_binding=layout_bindings(templates(caller_data),placement(caller_data),swapped_layout,48)
    need(swapped_binding['helper_label_sha256']==new_binding['helper_label_sha256'] and
         swapped_binding['stage_binding_sha256']==new_binding['stage_binding_sha256'],
         'inherited caller binding should be invariant to the controlled helper swap')
    negatives['swapped_distinct_helper_owners']['same_caller_stage_binding_digest']=True
    need(new_binding['stage_helper_owners']==48*889 and new_binding['native_main_bindings']==48*400,
         'full 48-call owner binding')
    need(binding['readback']['event_stream_sha256'] == base_receipt['rational']['readback']['event_stream_sha256'], 'fixed caller event stream')
    copy=HERE/('RATIONAL-CANDIDATE-'+PINS['WORD.json.gz'][0]+'.json.gz');copy.write_bytes((ALI/'WORD.json.gz').read_bytes())
    check_digest(copy.read_bytes(),PINS['WORD.json.gz'][0],WORD_CANON)
    result.update({'status':'PASS_LITERAL_RATIONAL_OPERATOR_AND_COMPLETE_SIGNED_INVOICE',
        'candidate':{'sha256':PINS['WORD.json.gz'][0],'clean_copy':copy.name,'same_as_baseline':False},
        'operator':{'public_rows_each':len(want),'forward_sha256':rat.row_hash(rows),'adjoint_sha256':rat.row_hash(adj),
                    'native_moves':len(moves),'scheduled_forms':len(order),'first_reader_count':len(reads),
                    'first_reader_sha256':bit.canonical_digest([[k,*reads[k]] for k in sorted(reads)])},
        'fixed_caller':{'finite_binding':new_binding,'old_binding':original_binding,'readback':binding['readback'],
                        'fixed_paid':dict(sorted(caller_paid.items())),'fixed_productive':dict(sorted(caller_productive.items()))},
        'invoice':{'paid':dict(sorted(paid.items())),'productive':dict(sorted(productive.items())),
                   'paid_count':sum(paid.values()),'productive_count':sum(productive.values()),
                   'paid_change_by_rank':{str(k):v for k,v in sorted(pd.items()) if v},
                   'productive_change_by_rank':{str(k):v for k,v in sorted(td.items()) if v},'margins':margins},
        'scope':'Exact native graph and adjoint and regenerated 48-call owner binding, with the unchanged BIT baseline as control. Caller-wide invoice includes fixed caller separately. The regenerated owner label is a fresh independent namespace assumption; no finite supply, physical erasure, precision, compiler or outer application qualification is claimed.'})
    path=HERE/'JOINT-RATIONAL-REPLAY.json';path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['status'], 'moves',len(moves),'helper labels',new_binding['stage_helper_owners'],'paid',sum(paid.values()),'productive',sum(productive.values()))
    for t,v in margins.items():print(t,'BIT',v['binary_baseline'][0],'rational',v['rational_changed'][0],'both',v['both_strictly_positive'])


if __name__=='__main__':main()
