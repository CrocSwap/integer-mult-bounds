#!/usr/bin/env python3
"""Replay CNF fidelity, inherited certificates, branch proof and controls."""
from pathlib import Path
import subprocess,sys
HERE=Path(__file__).resolve().parent
for name in ('audit/verify_fidelity.py','audit/verify_cover_eliminations.py','verify_certificates.py','verify_packing_certificates.py','verify_controls.py','verify_branch.py','verify_branch_controls.py'):
 print('RUN',name,flush=True)
 subprocess.run([sys.executable,'-B',str(HERE/name)],cwd=HERE,check=True)
print('ALL CHECKS PASSED')
