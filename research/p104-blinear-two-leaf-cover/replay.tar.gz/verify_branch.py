#!/usr/bin/env python3
"""Check two complete branch leaves using only finite spans and cover witnesses.

Run via verify_all.py to additionally replay the independent reconstruction of
all price-relevant CNF blocks, the 612/389 partition, and both earlier checks.
"""
from pathlib import Path
from functools import lru_cache
import hashlib,importlib.util,itertools,json,sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;ROOT=HERE/'audit'
PINS={
 'source/drat/gen.py':'2109ace16a7b04aa399ab0a06739afbb6fe378348e06360ce26620b721a08472',
 'source/drat/cubes.txt':'792af281bcb7d5652274ae201624fb69ab49fa99b29fba4522ab295924de3002',
 'source/drat/hashes.tsv':'3cdd8553d2de9c1800daef10f8ea138f6ba3abe27ce8228b9a4ebb3ad678dce7',
 'source/drat/data/e8base.json':'b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41',
 'source/drat/data/perms.json':'1b4e6b64f605f78432d075928ae28696ebf1945679c0818eb319ad61b5e3a3a3',
 'source/drat/data/zclauses.json':'7d586edab8c5527bc47dae89b5e396f69327da7f39707473706bdb7100b05e27',
 'residual-cubes.tsv':'5326f358c5aee7c8849b7cdf7241580721c6f0cfa4d24c0f914357d8f03af2ae',
 'inactive-cover-witnesses.tsv':'88b1681613fda52eff688df9c3a67d9bc7d6b6babd4056ad24b4e32dc8e15d4b',
}
for p,want in PINS.items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==want,p
for p,want in {'certificates.json':'169c798e8561d84ad73c8ae1b05a3e7b93a2a7c81af29e2550e2e4437fc342a8','packing_certificates.json':'ee0c054ad3b4e6a64e68ed46f5f83c8373bda3070e1486ac713c3fc586346851'}.items():assert hashlib.sha256((HERE/p).read_bytes()).hexdigest()==want,p
spec=importlib.util.spec_from_file_location('gen',ROOT/'source/drat/gen.py');gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen);b=gen.Base()
E=json.loads((ROOT/'source/drat/data/e8base.json').read_text())['C'];C=json.loads((ROOT/'source/drat/data/zclauses.json').read_text())
def vec(xs):return 1|sum((int(v)&1)<<(i+1) for i,v in enumerate(xs))
h=list(map(vec,E[:104]));n=list(map(vec,E[104:]));assert len(h)==104 and len(n)==16 and len(set(h))==104 and all(v not in h for v in n)
def rows(path):return [s.split('\t') for s in (ROOT/path).read_text().splitlines() if s and not s.startswith('#')]
r=rows('residual-cubes.tsv');residual={x[0]:int(x[1]) for x in r};old={x[0] for x in rows('inactive-cover-witnesses.tsv')};cubes={x[0]:x for x in rows('source/drat/cubes.txt')};hashes={x[0]:x[1] for x in rows('source/drat/hashes.tsv')}
first={x['id'] for x in json.loads((HERE/'certificates.json').read_text())['certificates']};second={x['id'] for x in json.loads((HERE/'packing_certificates.json').read_text())['certificates']}
assert len(r)==len(residual)==389 and len(old)==612 and len(cubes)==1001
assert len(first)==29 and len(second)==23 and not(first&second)
assert first|second<=residual.keys() and not((first|second)&old)
remaining=set(residual)-(first|second);assert len(remaining)==337 and 'i3' in remaining and 'i719' in remaining
def listing(path):return [x.split('\t') for x in (HERE/path).read_text().splitlines() if x and not x.startswith('#')]
assert listing('remaining-337.tsv')==[x for x in r if x[0] in remaining]
assert listing('remaining-336.tsv')==[x for x in r if x[0] in remaining and x[0]!='i719']
assert [x[0] for x in listing('remaining-337.tsv')[:2]]==['i3','i5']
assert min((c&~3).bit_count() for cs in C for c in cs)==3
assert min((c&~5).bit_count() for cs in C for c in cs)==2
assert sum((c&~5).bit_count()==2 for cs in C for c in cs)==164
cov=set(b.cls[b.n_cov0:b.n_tot0])
def check_clause(t,c):
 assert type(t) is int and 0<=t<104 and type(c) is int and c in C[t],('not source clause',t,c)
 assert tuple(b.m[z,t] for z in range(16) if c>>z&1) in cov,('not generated clause',t,c)
@lru_cache(maxsize=None)
def check_cube(cid,I):
 assert cid in remaining and residual[cid]==I
 row=cubes[cid];assert row[2]=='-' and (sum(1<<int(z) for z in row[1].split(',')) if row[1]!='-' else 0)==I
 units=[x[0] for x in gen.cube_extra(b,cid) if len(x)==1]
 assert len(units)==16 and set(units)=={b.used[z,8] if I>>z&1 else -b.used[z,8] for z in range(16)}
 payload=gen.cube_text(cid,b=b).encode();assert hashlib.sha256(payload).hexdigest()==hashes[cid],cid
@lru_cache(maxsize=None)
def check_branch(cid,t,z,val):
 # Hash the complete regenerated cube with the actual branch unit appended.
 expected={0:'2d0db389149a664f4b4f8361f16ee61ef5035a7d16bf10d2d523fdcc509a8c7b',1:'81792c1db731fcfa91f44c9d472051ccb5cc892b626962793fa818a3ae5efaa4'}
 assert cid=='i719' and (t,z)==(49,5) and val in expected
 lit=b.m[z,t] if val else -b.m[z,t]
 payload=b.text(gen.cube_extra(b,cid)+[[lit]]).encode()
 assert hashlib.sha256(payload).hexdigest()==expected[val],('branch hash',val)

def verify_object(proof,verbose=True):
 assert proof['schema']=='p104-two-choice-branch-v1'
 cases=proof['certificates'];assert len(cases)==1
 records=[];seen_ids=set()
 for case in cases:
  cid,I=case['id'],case['inactive_mask'];assert cid not in seen_ids;seen_ids.add(cid);check_cube(cid,I)
  split=case['split'];t0,z0,c0=split['t'],split['z'],split['clause'];check_clause(t0,c0)
  assert 0<=z0<16 and not(I>>z0&1)
  support=c0&~I;assert support.bit_count()==2 and support&(1<<z0)
  # A Boolean literal and its negation are disjoint and exhaustive. Requiring
  # exactly these two leaf values checks the entire finite partition.
  leaves=case['leaves'];values=[leaf['value'] for leaf in leaves]
  assert all(type(v) is int for v in values) and sorted(values)==[0,1]
  for leaf in leaves:
   val=leaf['value'];check_branch(cid,t0,z0,val);active={z for z in range(16) if not(I>>z&1)}
   forced=leaf['forced_rows'];F={r['z'] for r in forced};U=leaf['other_rows']
   assert len(F)==len(forced) and len(U)==len(set(U)) and F.isdisjoint(U) and F|set(U)==active
   assert all(type(z) is int and 0<=z<16 for z in F|set(U))
   fm=sum(1<<z for z in F);base=0
   for row in forced:
    z=row['z'];span={0,n[z]};seen=set()
    for item in row['ports']:
     t=item['t'];assert type(t) is int and 0<=t<104 and t not in seen;seen.add(t)
     if item['reason']=='branch':
      assert val==1 and z==z0 and t==t0
     else:
      assert item['reason']=='clause';c=item['clause'];check_clause(t,c)
      # All removed entries are inactive, or the tested literal is false.
      removed=I|((1<<z0) if val==0 and t==t0 else 0)
      assert c&~removed==1<<z,('not forced',cid,val,z,t,c)
     assert h[t] not in span,('dependent forced label',cid,val,z,t)
     span|={v^h[t] for v in span};assert len(span)<=512
    base+=len(row['ports'])
   ports=leaf['ports'];ts=[p['t'] for p in ports];assert len(ts)==len(set(ts))
   for z in U:
    span={0,n[z]}
    for t in ts:
     assert type(t) is int and 0<=t<104 and h[t] not in span,('dependent packing label',cid,val,z,t)
     span|={v^h[t] for v in span};assert len(span)<=512
   need=0
   for p in ports:
    t,k=p['t'],p['minimum'];assert type(k) is int and 0<k<=len(U)
    required={sum(1<<z for z in subset) for r in range(k) for subset in itertools.combinations(U,r)}
    supplied={}
    for subset,c in p['subsets']:
     assert type(subset) is int and subset in required and subset not in supplied
     check_clause(t,c);assert not(c&(fm|subset)),('invalid subset witness',cid,val,t,subset,c)
     supplied[subset]=c
    assert set(supplied)==required,('incomplete subset witnesses',cid,val,t)
    need+=k
   assert base+need>55,('insufficient price bound',cid,val,base,need)
   records.append((cid,val,base,need,base+need))
 assert seen_ids=={'i719'}
 if verbose:
  print('PASS original residual 389 minus disjoint 29+23 = 337 IDs')
  print('PASS exact two-choice branch, exhaustive disjoint leaves, and complete cube and branch CNF hashes')
  for cid,val,base,need,total in records:print(f'PASS {cid} m[{z0},{t0}]={val}: forced={base}, packed={need}, total={total} > 55')
 return records
if __name__=='__main__':
 path=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'branch_certificates.json'
 verify_object(json.loads(path.read_text()))
