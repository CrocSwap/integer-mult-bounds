# P104 B-linear: a two-leaf certificate for cube i719

The exact set of **337 cube IDs** left after the earlier solver-free tests is `remaining-337.tsv`: the 389 IDs surviving the original direct-cover test, less the disjoint 29 singleton/rank and 23 packing certificates. This package supplies one further solver-free certificate, for **i719**, leaving **336 IDs** in `remaining-336.tsv`. Together these methods eliminate 665 of the 1,001 cube IDs. IDs count cube boxes, not assignments.

The scope is the specific abstract tight B-linear cover and price-55 CNF in [PR #7852 at `41beda1d6435760dc99e38bd7e65f36798aad212`](https://github.com/CrocSwap/integer-mult-bounds/pull/7852), as explained in `audit/REVIEW.md`. The 612/389 audit is from [PR #7862 at `550a08ab9bf3ee6bb1b310abbfb2874700e7c441`](https://github.com/CrocSwap/integer-mult-bounds/pull/7862), and the prior 52 are inherited from [PR #7872 at `bc8f724ffbf0e38913830a3cfe64ae7b0c3f7423`](https://github.com/CrocSwap/integer-mult-bounds/pull/7872). These sources report broader results using DRAT proofs; this package instead checks the stated 665 cube exclusions by the finite certificates described here and in the inherited audit. It does not re-establish the full UNSAT claim, a general decoder wall, a legal-word result, or a kappa improvement. The other 336 IDs have not been eliminated by these particular checks.

## Reproduce

Using Python 3 and a standard shell, with no solver, network, or third-party Python library:

```sh
sha256sum -c SHA256SUMS
python3 -B verify_all.py
```

This replays the independent reconstruction of the row, membership, positive cover, and totalizer CNF blocks; the 612/389 partition; all 52 inherited certificates and regenerated full cube hashes; the new branch certificate; seven inherited and 11 new semantic corruption controls. The new checker explicitly regenerates the **entire** i719 cube CNF and both full CNFs obtained by adding the respective branch units. The original cube hash is checked against the source's historical `hashes.tsv`; the two new branch hashes are recorded below. The additional lex and normalization clauses are included in those full-file hashes, although the branch lower bound does not need them. The finite executable checker is not a proof-assistant formalization.

The full i719 CNF has SHA-256 `8619b64f916dcc2d71041077a4db769694fa12be537b9919c25f98336f3dfb24`. The actual generator assigns `m[5,49]` DIMACS variable 23187. Appending the positive or negative unit gives:

| Leaf | Full branch CNF SHA-256 |
| --- | --- |
| `m[5,49] = 1` | `81792c1db731fcfa91f44c9d472051ccb5cc892b626962793fa818a3ae5efaa4` |
| `m[5,49] = 0` | `2d0db389149a664f4b4f8361f16ee61ef5035a7d16bf10d2d523fdcc509a8c7b` |

`SHA256SUMS` covers the retained audit inputs and certificates. The upstream generator and geometry are included unchanged with their original license and notice in `audit/source/`. The old certificate files are additionally pinned inside the new checker. The inherited package's `SHA256SUMS` had SHA-256 `4dfd83859e2a23e99cec38ccbbe54085a177c076f84f6ea06d8837512dd5d644`.

## Why both leaves contradict price 55

The actual i719 cube has inactive mask `719`, namely rows `{0,1,2,3,6,7,9}`. The verified row and membership blocks force all their membership flags false. At port 49, generated positive cover clause 1192 has rows `{3,5,7,10}`, so it reduces to `m[5,49] or m[10,49]`. We branch on `m[5,49]`; the two Boolean values are disjoint and exhaustive.

For the positive leaf, `m[5,49]` directly forces label `h_49` into `U_5`. In the negative leaf, generated clause 4775 contains rows `{0,1,2,5,7,9,12}` and reduces to `m[12,49]`, forcing `h_49` into `U_12`. All the other forced labels come from explicit cover-clause witnesses; the checker verifies the exact generated membership variables and clauses, and accepts a negative branch literal only at the branch port.

In each leaf we split the active rows into `F = {5,10,11,12,15}` and `R = {4,8,13,14}`. For a row normal `n_z`, its abstract price satisfies

```text
price_z = dim(U_z) - 1[n_z in U_z] = dim(U_z + span(n_z)) - 1.
```

The stored witnesses give independent labels together with each normal. In order `5,10,11,12,15`, the corresponding F-row lower bounds are `8,7,7,7,8` in the positive leaf and `7,7,7,8,8` in the negative leaf. Both sum to **37**.

For the R rows, grant F free membership in every selected port, a relaxation. Each leaf supplies eight distinct ports, and explicit clauses show that their minimum numbers of R members are `3,3,3,2,2,2,2,2`, totaling **19**. Every subset of R with fewer than the claimed minimum has a stored disjoint clause witness. The eight labels are independently checked, together with each `n_z`, on every R row. Therefore R's total price is at least 19, and F and R together cost at least `37 + 19 = 56`. The audited totalizer requires abstract price at most 55. This contradiction applies to each leaf and hence the whole i719 cube.

The verifier enumerates the F2 spans explicitly; it does not trust the random search, a Gaussian-elimination rank report, a SAT solver, or a DRAT file. It also checks each witness against the generated CNF's actual positive clause block, every required support subset, disjointness of the prior and new ID sets, cube units, and both branch units. Mutations test missing or overlapping leaves, a bad split clause, an already-eliminated ID, invalid branch/cover forcing, a dependent label, an insufficient bound, duplicate packed ports, missing support subsets, and an invalid clause witness.

## Search boundary

The first of the 337 IDs is i3; its smallest cover clauses after inactive rows are removed have **three** choices, so it has no two-choice clause to use for the requested split. The first such case is i5, where a small initial set of three clause pairs did not close under this search; that is a search observation, not a satisfiability verdict. The checked new proof concerns i719. No claim is made about exhaustive search over the remaining cases.
