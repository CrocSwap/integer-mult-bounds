#!/usr/bin/env python3
"""Mutate actual branch witnesses and require semantic rejection."""
import copy,json
from pathlib import Path
import verify_branch as v
base=json.loads((Path(__file__).resolve().parent/'branch_certificates.json').read_text())
v.verify_object(base,verbose=False)
controls=[]
def make(name):
 x=copy.deepcopy(base);controls.append((name,x));return x['certificates'][0]
case=make('missing_leaf');case['leaves'].pop()
case=make('overlapping_leaf');case['leaves'][1]['value']=case['leaves'][0]['value']
case=make('unlisted_split_clause');case['split']['clause']=0
case=make('old_already_excluded_cube');case['id']='i191';case['inactive_mask']=191
case=make('false_branch_used_as_positive');leaf=next(a for a in case['leaves'] if a['value']==0);item=next(i for r in leaf['forced_rows'] for i in r['ports'] if i['t']==49);item.clear();item.update({'t':49,'reason':'branch'})
case=make('non_forcing_source_clause');leaf=next(a for a in case['leaves'] if a['value']==0);row=next(r for r in leaf['forced_rows'] if r['z']==12);item=next(i for i in row['ports'] if i['t']==49);item['clause']=next(c for c in v.C[49] if c&~(719|1<<5)!=1<<12)
case=make('dependent_forced_label');leaf=next(a for a in case['leaves'] if a['value']==1);row=next(r for r in leaf['forced_rows'] if r['z']==5);seen={i['t'] for i in row['ports']};choice=next((t,c) for t in range(104) if t not in seen for c in v.C[t] if c&~719==1<<5);row['ports'].append({'t':choice[0],'reason':'clause','clause':choice[1]})
case=make('insufficient_bound');leaf=next(a for a in case['leaves'] if a['value']==1);row=next(r for r in leaf['forced_rows'] if r['z']==5);row['ports']=[i for i in row['ports'] if i['reason']!='branch']
case=make('duplicate_packed_port');leaf=case['leaves'][0];leaf['ports'][1]['t']=leaf['ports'][0]['t']
case=make('missing_support_subset');leaf=case['leaves'][0];leaf['ports'][0]['subsets'].pop()
case=make('bad_subset_source_clause');leaf=case['leaves'][0];port=leaf['ports'][0];subset=port['subsets'][0][0];fm=sum(1<<r['z'] for r in leaf['forced_rows']);port['subsets'][0][1]=next(c for c in v.C[port['t']] if c&(fm|subset))
for name,obj in controls:
 try:v.verify_object(obj,verbose=False)
 except AssertionError:print('PASS rejected',name)
 else:raise AssertionError('control unexpectedly accepted: '+name)
print('PASS',len(controls),'semantic mutations rejected')
