# Two exact repair exclusions for BIT paid packet 971

The projected control identifies x341 with x340 and omits three old paid movements, 968, 971 and 1564. All other public results and the 411 bridge retain their specified forms. The prospective saving after surrender of the one helper target is about 0.723945925 across 36 calls at κ=0.003879929046155. A legal supplier earning that saving remains open.

1. The single-route screen allows one of seven named retained packets to move to an existing chart at any clock with row variation along x51. The full two 636-receiver sweeps for moves 970 and 1570, the actual stock closure for the 18 optimistic survivors, and the first-reader and early-gate checks for the other five moves all exclude a repair.
2. The two-direction screen fixes routes and clocks. It permits corrections in span{x51, xV} for each of 678 possible surviving unit coordinates V. It independently checks 668 chronological XOR certificates and ten exhaustive finite stock cores. Every case is impossible. Both baseline 679-owner orientations and the protected 3553=x411 constraint are included.

The scopes overlap at their starting operator and omit roster. A mixed nonunit second direction, two changed routes together, a fourth omission or a redesigned physical caller contract remain open.

## Replay

Run `sha256sum -c SHA256SUMS` then extract each named subarchive into its own clean directory. Run the exact one-route README command sequence from the first and `python3 verify.py` from the second. The full cold runs passed, including the two actual-stock methods and the corrupted-control and literal operator evidence detailed in the subarchives. The parent source is PR #7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. See both archived notices for attribution and source paths.
