#!/usr/bin/env python3
"""Held three-group star experiment. Execute only after independent gate/root GO."""
import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "inputs/research/independent-clifford-expansion"
BRIDGE = 172
LEAVES = ((499, 7), (572, 25))
STATES = list(product((0, 1), repeat=3))  # bridge, leaf499, leaf572
CSTAR = Q(15108879, 5000000000)
GRAPH = "f5db08a5814b14b11b93b79207afb1a8d5ec2c5803c1cf6bbc3333cccf0a94af"
PAIR = "d2ea1bd88173a46d8fa59c2958ef234ae9811e44c677aadf012423e77cbf78a9"
PAID = {1: 2201, 2: 412, 3: 510, 4: 127, 5: 40, 8: 8}
HELPERS = {4: 28, 7: 7, 8: 47, 9: 326}
UNION = [130, 131, 1181, 1187, 1193, 1194, 1204, 1212,
         1399, 1405, 1411, 1412, 1422, 1430]


class Deadline(Exception):
    pass


def need(ok, why):
    if not ok:
        raise ValueError(why)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-seconds", type=int, default=58)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    need(1 <= args.max_seconds <= 58, "single authorized cooperative cap")
    started = time.monotonic()
    deadline = started + args.max_seconds

    def check_time():
        if time.monotonic() >= deadline:
            raise Deadline()

    manifest = json.loads((HERE / "AUTH-MANIFEST.json").read_text())
    for name, expected in manifest.items():
        path = HERE / name
        need(path.is_file() and not path.is_symlink(), "regular input " + name)
        need(sha256(path.read_bytes()).hexdigest() == expected, "input hash " + name)
    sys.path.insert(0, str(SOURCE))
    import algebra as A
    import discover as D
    import intervals as I
    need(I.BITS == 128, "exact retained interval precision")
    model = A.build(True)
    need(sha256(D.encoded(model).encode()).hexdigest() == GRAPH, "source graph")
    old, edges = model["charts"], model["contacts"]
    need(len(old) == 1075 and len(edges) == 3938, "graph dimensions")
    selected = [BRIDGE] + [g for g, axis in LEAVES]
    need(all(g not in model["frozen"] for g in selected), "three movable groups")
    union = [i for i, (a, b, op, sign) in enumerate(edges)
             if a in selected or b in selected]
    need(union == UNION and len(union) == len(set(union)), "complete 14-row union")
    need(all(edges[i][2] == 0 and edges[i][3] == 1 for i in union),
         "declared union contains only paid identity incidences")
    internal = [i for i in union if edges[i][0] in selected and edges[i][1] in selected]
    need(internal == [1193, 1411], "two edges of the declared star")
    paid0, helper0 = A.invoice(model, old)
    need(dict(paid0) == PAID and dict(helper0) == HELPERS, "complete baseline")
    need(model["centers"] == {8: 8}, "eight centers stay paid")
    changed_leaves = {g: A.turn(old[g], axis, 9) for g, axis in LEAVES}
    discovery = json.loads((HERE / "retained/DISCOVERY.json").read_text())
    stored_pairs = {(m[1], m[2]) for m in discovery[1]["moves"] if m[0] == 0}
    need(set(LEAVES) <= stored_pairs, "literal retained leaf axes")
    for g, axis in LEAVES:
        need(A.distance(old[g], changed_leaves[g], 9) == 1, "retained nearest leaf")
        assignment = list(old)
        assignment[g] = changed_leaves[g]
        p, h = A.invoice(model, assignment)
        need(p == paid0 and h == helper0, "retained leaf identical full invoice")
    pair_path = HERE / "retained/SEARCH-RESULT.json"
    need(sha256(pair_path.read_bytes()).hexdigest() == PAIR, "accepted pair receipt")
    pair_receipt = json.loads(pair_path.read_text())
    prior = {r["partner_axis"]: r for r in pair_receipt["candidates"]
             if r["partner"] == BRIDGE}
    need(len(prior) == 1022, "complete retained bridge pair projection")
    alternatives = list(A.neighbors(old[BRIDGE], 9))
    need(len(alternatives) == len({c for axis, c in alternatives}) == 1022,
         "exact distinct nearest bridge alphabet")
    need({axis for axis, c in alternatives} == set(prior), "same bridge alphabet")
    records, patterns, full_checks = [], {}, set()
    power_cache = {}

    def powers(c):
        if c not in power_cache:
            power_cache[c] = {r: I.power_bounds(r, c) for r in range(1, 10)}
        return power_cache[c]

    def bounds(delta, a, b, derivative=False):
        pa, pb = powers(a), powers(b)
        lower = upper = 0
        for r in range(1, 10):
            lo, hi, coefficient = pb[r][0], pa[r][1], delta[r]
            if derivative:
                lo = lo * I.LOGS[r][0] // I.SCALE
                hi = I.updiv(hi * I.LOGS[r][1], I.SCALE)
                coefficient = -coefficient
            lower += coefficient * (lo if coefficient >= 0 else hi)
            upper += coefficient * (hi if coefficient >= 0 else lo)
        return lower, upper

    def certify(delta):
        if not any(delta):
            return {"kind": "identically_zero"}
        dominance = I.dominance(delta)
        if min(dominance) >= 0:
            return {"kind": "concave_dominance", "values": dominance}
        mass = sum(r * delta[r] for r in range(1, 10))
        for pieces in (16, 128):
            check_time()
            intervals = [bounds(delta, Q(i, 200 * pieces),
                                Q(i + 1, 200 * pieces), mass == 0)
                         for i in range(pieces)]
            least = min(lo for lo, hi in intervals)
            if least >= 0 and mass >= 0:
                return {"kind": "nonnegative_derivative_from_zero" if mass == 0
                        else "nonnegative_direct_intervals",
                        "subdivisions": pieces, "minimum_scaled_lower": str(least)}
        return {"kind": "unresolved_on_full_domain", "rank_mass": mass}

    def vector_add(*terms):
        return [sum(t[r] for t in terms) for r in range(10)]

    def negate(delta):
        return [-x for x in delta]

    complete = False
    try:
        for ordinal, (axis, bridge_chart) in enumerate(alternatives):
            check_time()
            need(A.distance(old[BRIDGE], bridge_chart, 9) == 1, "nearest bridge")
            previous = prior[axis]
            need(list(bridge_chart) == previous["partner_chart"], "retained bridge chart")
            assignments = []
            for bridge_bit, bit499, bit572 in STATES:
                assignment = list(old)
                if bridge_bit:
                    assignment[BRIDGE] = bridge_chart
                if bit499:
                    assignment[499] = changed_leaves[499]
                if bit572:
                    assignment[572] = changed_leaves[572]
                assignments.append(assignment)
            rank_rows, deltas = [], [[0] * 10 for _ in STATES]
            valid = [True] * 8
            profiles = [[Counter(paid0), Counter(helper0)] for _ in STATES]
            for eid in union:
                a, b, op, sign = edges[eid]
                ranks = []
                for state, assignment in enumerate(assignments):
                    left = assignment[a]
                    if op:
                        left = tuple(A.linear(model["operators"][op], v) for v in left)
                    rank = A.distance(left, assignment[b], 9)
                    need(0 <= rank <= 9, "rank range")
                    ranks.append(rank)
                    if sign < 0 and rank == 0:
                        valid[state] = False
                for state, rank in enumerate(ranks):
                    if ranks[0]:
                        deltas[state][ranks[0]] -= sign
                    if rank:
                        deltas[state][rank] += sign
                    profile = profiles[state][0 if sign > 0 else 1]
                    if ranks[0]:
                        profile[ranks[0]] -= 1
                    if rank:
                        profile[rank] += 1
                rank_rows.append({"id": eid, "a": a, "b": b, "op": op,
                                  "sign": sign, "ranks": ranks})
            need(all(valid), "strict productivity in every state")
            for p, h in profiles:
                need(all(n >= 0 for n in p.values()) and all(n >= 0 for n in h.values()),
                     "nonnegative invoice multiplicities")
                need(sum(h.values()) == 408, "every arbitrary helper exactly once")
            need(all(not any(deltas[s]) for s in range(4)), "all bridge-off states zero")
            for state, old_state in ((0, 0), (2, 1), (4, 2), (6, 3)):
                need(deltas[state] == previous["energy_deltas"][old_state],
                     "accepted prior four-state projection")
            old_rows = {r["id"]: r for r in previous["incidences"]}
            for row in rank_rows:
                if row["id"] in old_rows:
                    need([row["ranks"][s] for s in (0, 2, 4, 6)] ==
                         old_rows[row["id"]]["ranks"], "prior incidence rank projection")
            r499 = vector_add(deltas[6], negate(deltas[4]), negate(deltas[2]), deltas[0])
            r572 = vector_add(deltas[5], negate(deltas[4]), negate(deltas[1]), deltas[0])
            need(r499 == previous["cross_difference"], "retained first interaction")
            need(deltas[7] == vector_add(deltas[4], r499, r572), "exact star factorization")
            active = []
            for state in range(4, 8):
                delta = deltas[state]
                lo, hi = bounds(delta, CSTAR, CSTAR)
                outcome = ("strict_improvement_at_test_C" if hi < 0 else
                           "identically_zero" if not any(delta) else
                           "nonnegative_at_test_C" if lo >= 0 else "unresolved_at_test_C")
                key = tuple(delta)
                if key not in patterns:
                    patterns[key] = {"delta": delta, "count": 0, "first_witness": [axis, state]}
                patterns[key]["count"] += 1
                active.append({"state_index": state, "bits": STATES[state],
                               "point_energy_scaled": [str(lo), str(hi)], "outcome": outcome})
                if key not in full_checks or hi < 0 or ordinal == 1021:
                    p, h = A.invoice(model, assignments[state])
                    need(p == profiles[state][0] and h == profiles[state][1],
                         "complete global invoice matches local union")
                    full_checks.add(key)
            compact_profiles = [{"paid": {r: n for r, n in sorted(p.items()) if n},
                                 "helpers": {r: n for r, n in sorted(h.items()) if n}}
                                for p, h in profiles]
            records.append({"bridge_neighbor_ordinal": ordinal, "bridge_axis": axis,
                            "bridge_chart": bridge_chart, "states": STATES,
                            "valid_states": valid, "incidences": rank_rows,
                            "energy_deltas": deltas, "profiles": compact_profiles,
                            "R499": r499, "R572": r572,
                            "point_R499_scaled": [str(x) for x in bounds(r499, CSTAR, CSTAR)],
                            "point_R572_scaled": [str(x) for x in bounds(r572, CSTAR, CSTAR)],
                            "active_candidates": active})
        complete = len(records) == 1022
        need(complete, "complete declared bridge coverage")
        for row in patterns.values():
            row["domain_certificate"] = certify(row["delta"])
    except Deadline:
        complete = False
    negatives = [[r["bridge_axis"], a["state_index"]] for r in records
                 for a in r["active_candidates"] if a["outcome"] == "strict_improvement_at_test_C"]
    unresolved = sum(a["outcome"] == "unresolved_at_test_C" for r in records
                     for a in r["active_candidates"])
    certified_domain = complete and all(
        p.get("domain_certificate", {}).get("kind") not in (None, "unresolved_on_full_domain")
        for p in patterns.values())
    result = {
        "status": "INCOMPLETE_TIME_CAP" if not complete else
        "EXACT_STAR_IMPROVEMENT_FOUND" if negatives else
        "NO_STAR_IMPROVEMENT_ON_DECLARED_DOMAIN" if certified_domain else
        "NO_STAR_IMPROVEMENT_AT_TEST_C" if not unresolved else "INCONCLUSIVE_EXACT_POINT_SIGN",
        "source_head": "0335701859182b7bdf31706b0d969c72f5de41c7",
        "graph_sha256": GRAPH, "accepted_pair_receipt_sha256": PAIR,
        "bridge_group": BRIDGE, "leaf_group_axes": LEAVES,
        "leaf_baseline_charts": {g: old[g] for g, a in LEAVES},
        "leaf_changed_charts": changed_leaves, "states": STATES,
        "declared_bridge_charts": 1022, "completed_bridge_charts": len(records),
        "declared_active_candidates": 4088, "completed_active_candidates": 4 * len(records),
        "candidate_coverage_complete": len(records) == 1022, "processing_complete": complete,
        "test_C": str(CSTAR), "saving_domain": ["0", "1/200"],
        "domain_nonnegative_certificate_complete": certified_domain,
        "first_certified_negative": negatives[0] if negatives else None,
        "certified_negative_count": len(negatives), "point_unresolved_candidates": unresolved,
        "complete_global_invoice_polynomial_buckets_checked": len(full_checks),
        "baseline_paid": PAID, "baseline_helpers": HELPERS,
        "fixed_point_bits": I.BITS, "scale": str(I.SCALE),
        "patterns": list(patterns.values()), "bridge_records": records,
        "source_input_hashes": manifest, "checker_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "elapsed_seconds": time.monotonic() - started, "requested_cap_seconds": args.max_seconds,
        "mincut_used": False, "native_emitter_executed": False, "compiler_executed": False,
        "new_kappa": None}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    need(not args.output.exists(), "do not overwrite a previous experiment")
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("bridge_records", "patterns", "source_input_hashes")},
                     sort_keys=True))


if __name__ == "__main__":
    main()
