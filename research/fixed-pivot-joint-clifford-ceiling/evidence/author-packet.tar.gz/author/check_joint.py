#!/usr/bin/env python3
"""One fixed-pivot, 3066-candidate joint Clifford experiment.

Design implementation only until root authorizes execution.
Source geometry and integer intervals: Cinna Davis, PR5124.
New bounded joint census: OpenAI Codex assistance; Apache-2.0.
"""
import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "inputs/research/independent-clifford-expansion"
PIVOT, PIVOT_AXIS = 499, 7
PARTNERS = [172, 497, 504]
CSTAR = Q(15108879, 5000000000)
DOMAIN = [Q(0), Q(1, 200)]
GRAPH_HASH = "f5db08a5814b14b11b93b79207afb1a8d5ec2c5803c1cf6bbc3333cccf0a94af"
BASE_PAID = {1: 2201, 2: 412, 3: 510, 4: 127, 5: 40, 8: 8}
BASE_HELPERS = {4: 28, 7: 7, 8: 47, 9: 326}


class Deadline(Exception):
    pass


def need(condition, message):
    if not condition:
        raise ValueError(message)


def authenticate():
    manifest = json.loads((HERE / "AUTH-MANIFEST.json").read_text())
    for name, digest in manifest.items():
        path = HERE / name
        need(not path.is_symlink(), "regular input: " + name)
        need(sha256(path.read_bytes()).hexdigest() == digest,
             "authenticated input: " + name)
    return manifest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-seconds", type=int, default=60)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    need(1 <= args.max_seconds <= 120, "declared wall-clock cap")
    started = time.monotonic()
    deadline = started + args.max_seconds

    def check_time():
        if time.monotonic() >= deadline:
            raise Deadline()

    authenticated = authenticate()
    sys.path.insert(0, str(SOURCE))
    import algebra as A
    import discover as D
    import intervals as I
    need(I.BITS == 128, "retained exact interval precision")
    model = A.build(True)
    need(sha256(D.encoded(model).encode()).hexdigest() == GRAPH_HASH,
         "exact contracted graph")
    need(len(model["charts"]) == 1075 and len(model["contacts"]) == 3938,
         "exact graph dimensions")
    frozen = set(model["frozen"])
    need(len(model["charts"]) - len(frozen) == 800 and PIVOT not in frozen,
         "exact movable domain")
    paid0, helpers0 = A.invoice(model, model["charts"])
    need(dict(paid0) == BASE_PAID and dict(helpers0) == BASE_HELPERS,
         "complete baseline including eight centers and 408 helpers")
    need(model["centers"] == {8: 8}, "all eight centers stay paid")
    old = model["charts"]
    pivot_chart = A.turn(old[PIVOT], PIVOT_AXIS, 9)
    need(A.distance(old[PIVOT], pivot_chart, 9) == 1, "nearest pivot")
    pivot_assignment = list(old)
    pivot_assignment[PIVOT] = pivot_chart
    pivot_paid, pivot_helpers = A.invoice(model, pivot_assignment)
    need(all(pivot_paid[r] - pivot_helpers[r] == paid0[r] - helpers0[r]
             for r in range(1, 10)), "exact zero-polynomial pivot")
    edges = model["contacts"]
    adjacent = sorted({b if a == PIVOT else a
                       for a, b, op, sign in edges
                       if PIVOT in (a, b) and a != b
                       and (b if a == PIVOT else a) not in frozen})
    need(adjacent == PARTNERS, "complete movable adjacent partner set")
    records, patterns, full_checked = [], {}, {}
    power_cache = {}

    def powers(c):
        if c not in power_cache:
            power_cache[c] = {r: I.power_bounds(r, c) for r in range(1, 10)}
        return power_cache[c]

    def polynomial_bounds(delta, a, b, derivative=False):
        pa, pb = powers(a), powers(b)
        lower = upper = 0
        for r in range(1, 10):
            lo, hi = pb[r][0], pa[r][1]
            coefficient = delta[r]
            if derivative:
                lo = lo * I.LOGS[r][0] // I.SCALE
                hi = I.updiv(hi * I.LOGS[r][1], I.SCALE)
                coefficient = -coefficient
            lower += coefficient * (lo if coefficient >= 0 else hi)
            upper += coefficient * (hi if coefficient >= 0 else lo)
        return lower, upper

    def domain_nonnegative_certificate(delta):
        if not any(delta):
            return {"kind": "identically_zero"}
        dominance = I.dominance(delta)
        if min(dominance) >= 0:
            return {"kind": "concave_dominance", "values": dominance}
        mass = sum(r * delta[r] for r in range(1, 10))
        for pieces in (16, 128):
            check_time()
            bounds = [polynomial_bounds(delta, Q(i, 200 * pieces),
                                        Q(i + 1, 200 * pieces), mass == 0)
                      for i in range(pieces)]
            least = min(lo for lo, hi in bounds)
            if least >= 0 and mass >= 0:
                return {"kind": "nonnegative_derivative_from_zero" if mass == 0
                        else "nonnegative_direct_intervals",
                        "subdivisions": pieces,
                        "minimum_scaled_lower": str(least)}
        return {"kind": "unresolved_on_full_domain", "rank_mass": mass}

    def edge_rank(edge, chart_g, chart_h, partner):
        a, b, op, sign = edge
        # Both substitutions matter, including a selfloop.
        left = chart_g if a == PIVOT else chart_h if a == partner else old[a]
        right = chart_g if b == PIVOT else chart_h if b == partner else old[b]
        if op:
            left = tuple(A.linear(model["operators"][op], v) for v in left)
        return A.distance(left, right, 9)

    def changed_profiles(rank_rows, state):
        paid, helper = Counter(paid0), Counter(helpers0)
        for row in rank_rows:
            sign, ranks = row["sign"], row["ranks"]
            target = paid if sign > 0 else helper
            if ranks[0]:
                target[ranks[0]] -= 1
            if ranks[state]:
                target[ranks[state]] += 1
        need(all(n >= 0 for n in paid.values()) and
             all(n >= 0 for n in helper.values()), "nonnegative multiplicities")
        need(sum(helper.values()) == 408, "every independent helper once")
        return ({r: n for r, n in sorted(paid.items()) if n},
                {r: n for r, n in sorted(helper.items()) if n})

    complete = False
    try:
        for partner in PARTNERS:
            check_time()
            need(partner not in frozen and partner != PIVOT, "distinct free groups")
            union = [i for i, (a, b, op, sign) in enumerate(edges)
                     if PIVOT in (a, b) or partner in (a, b)]
            # IDs, not endpoint pairs, are the unit of deduplication.
            need(len(union) == len(set(union)), "each incidence ID once")
            alternatives = list(A.neighbors(old[partner], 9))
            need(len(alternatives) == 1022 and
                 len({chart for axis, chart in alternatives}) == 1022,
                 "complete distinct nearest-chart alphabet")
            for ordinal, (axis, changed_h) in enumerate(alternatives):
                check_time()
                need(A.distance(old[partner], changed_h, 9) == 1,
                     "nearest partner chart")
                rank_rows, deltas = [], [[0] * 10 for _ in range(4)]
                valid = [True] * 4
                for eid in union:
                    a, b, op, sign = edges[eid]
                    ranks = [edge_rank(edges[eid], cg, ch, partner)
                             for cg, ch in ((old[PIVOT], old[partner]),
                                            (pivot_chart, old[partner]),
                                            (old[PIVOT], changed_h),
                                            (pivot_chart, changed_h))]
                    need(all(0 <= r <= 9 for r in ranks), "rank in physical range")
                    for state, rank in enumerate(ranks):
                        if sign < 0 and rank == 0:
                            valid[state] = False
                        if ranks[0]:
                            deltas[state][ranks[0]] -= sign
                        if rank:
                            deltas[state][rank] += sign
                    rank_rows.append({"id": eid, "a": a, "b": b, "op": op,
                                      "sign": sign, "ranks": ranks})
                need(not any(deltas[0]) and not any(deltas[1]),
                     "baseline zero and fixed pivot polynomial")
                need(all(valid[:3]), "source baseline and single states valid")
                record = {"partner": partner, "neighbor_ordinal": ordinal,
                          "partner_axis": axis, "partner_chart": changed_h,
                          "states": ["00", "10", "01", "11"],
                          "valid_states": valid, "incidences": rank_rows,
                          "energy_deltas": deltas}
                if not valid[3]:
                    record["outcome"] = "invalid_joint_helper_productivity"
                    records.append(record)
                    continue
                delta = deltas[3]
                cross = [deltas[3][r] - deltas[1][r] -
                         deltas[2][r] + deltas[0][r] for r in range(10)]
                lo, hi = polynomial_bounds(delta, CSTAR, CSTAR)
                clo, chi = polynomial_bounds(cross, CSTAR, CSTAR)
                paid, helper = changed_profiles(rank_rows, 3)
                record.update(joint_paid=paid, joint_helpers=helper,
                              cross_difference=cross,
                              point_energy_scaled=[str(lo), str(hi)],
                              point_cross_scaled=[str(clo), str(chi)],
                              outcome="strict_improvement_at_test_C" if hi < 0
                              else "identically_zero" if not any(delta)
                              else "nonnegative_at_test_C" if lo >= 0
                              else "unresolved_at_test_C")
                key = tuple(delta)
                if key not in patterns:
                    patterns[key] = {"count": 0, "delta": delta,
                                     "first_witness": [partner, axis]}
                patterns[key]["count"] += 1
                # A complete global invoice checks every polynomial bucket,
                # every favorable candidate, and the last neighbor per partner.
                if key not in full_checked or hi < 0 or ordinal == 1021:
                    assignment = list(old)
                    assignment[PIVOT], assignment[partner] = pivot_chart, changed_h
                    global_paid, global_helper = A.invoice(model, assignment)
                    need(dict(global_paid) == paid and dict(global_helper) == helper,
                         "local union equals complete global invoice")
                    full_checked[key] = True
                records.append(record)
        complete = len(records) == 3066
        need(complete, "declared coverage")
        for row in patterns.values():
            row["domain_certificate"] = domain_nonnegative_certificate(row["delta"])
    except Deadline:
        complete = False

    negatives = [[r["partner"], r["partner_axis"]] for r in records
                 if r["outcome"] == "strict_improvement_at_test_C"]
    unresolved = sum(r["outcome"] == "unresolved_at_test_C" for r in records)
    domain_complete = complete and all(
        row.get("domain_certificate", {}).get("kind") not in
        (None, "unresolved_on_full_domain") for row in patterns.values())
    result = {
        "status": "INCOMPLETE_TIME_CAP" if not complete else
        "EXACT_JOINT_IMPROVEMENT_FOUND" if negatives else
        "NO_IMPROVEMENT_ON_DECLARED_DOMAIN" if domain_complete else
        "NO_IMPROVEMENT_AT_TEST_C" if not unresolved else
        "INCONCLUSIVE_EXACT_POINT_SIGN",
        "source_head": "0335701859182b7bdf31706b0d969c72f5de41c7",
        "graph_sha256": GRAPH_HASH, "pivot": [PIVOT, PIVOT_AXIS],
        "pivot_chart": pivot_chart, "partners": PARTNERS,
        "declared_candidates": 3066, "completed_candidates": len(records),
        "candidate_coverage_complete": len(records) == 3066,
        "processing_complete": complete,
        "test_C": str(CSTAR), "saving_domain": [str(c) for c in DOMAIN],
        "domain_nonnegative_certificate_complete": domain_complete,
        "point_unresolved_candidates": unresolved,
        "first_certified_negative": negatives[0] if negatives else None,
        "certified_negative_count": len(negatives),
        "fixed_point_bits": I.BITS, "scale": str(I.SCALE),
        "baseline_paid": BASE_PAID, "baseline_helpers": BASE_HELPERS,
        "complete_global_invoice_checks": len(full_checked),
        "patterns": list(patterns.values()), "candidates": records,
        "source_input_hashes": authenticated,
        "checker_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "elapsed_seconds": time.monotonic() - started,
        "requested_cap_seconds": args.max_seconds,
        "mincut_used": False, "native_emitter_executed": False,
        "compiler_executed": False, "new_kappa": None}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("candidates", "patterns", "source_input_hashes")},
                     sort_keys=True))


if __name__ == "__main__":
    main()
