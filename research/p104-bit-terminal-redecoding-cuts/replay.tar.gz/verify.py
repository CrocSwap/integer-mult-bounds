from hashlib import sha256
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

HERE = Path(__file__).resolve().parent
for line in (HERE/'SHA256SUMS').read_text().splitlines():
    digest,name = line.split('  ', 1)
    if sha256((HERE/name).read_bytes()).hexdigest()!=digest:
        raise ValueError('Archive or note differs: '+name)
for name in ('producer.tar.gz','independent.tar.gz','early.tar.gz'):
    if not (HERE/name).is_file():
        continue
    with tempfile.TemporaryDirectory(prefix='p104-terminal-review-') as scratch:
        p=Path(scratch)
        with tarfile.open(HERE/name) as f:
            f.extractall(p,filter='data')
        for _ in range(2):
            if (p/'verify.py').is_file() or (p/'verify_raw.py').is_file():break
            children=list(p.iterdir())
            if len(children)!=1 or not children[0].is_dir():
                raise ValueError('Missing nested verify.py: '+name)
            p=children[0]
        if name == 'early.tar.gz':
            subprocess.run(['sha256sum','-c','--quiet','SHA256SUMS'],cwd=p,check=True)
            for script in ('screen.py','verify_raw.py'):
                subprocess.run([sys.executable,'-I','-B',script,'--verify'],cwd=p,check=True)
        else:
            subprocess.run([sys.executable,'-B','verify.py'],cwd=p,check=True)
        print('PASS',name,flush=True)
