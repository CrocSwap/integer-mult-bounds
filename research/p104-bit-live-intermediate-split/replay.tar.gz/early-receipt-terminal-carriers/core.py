"""Portable #7830 packet graph, strict chart geometry and binary elimination."""
from collections import Counter,defaultdict
from fractions import Fraction
from functools import lru_cache,reduce
from math import lcm
from operator import xor
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;SOURCE=HERE/'source'
sys.path.insert(0,str(SOURCE));import physical,common as prices
sys.path.insert(0,str(SOURCE/'vendor'));import binary_operator as op

def labels(a):
 while a:
  bit=a&-a;yield bit.bit_length()-1;a^=bit
def xsum(x):return reduce(xor,x,0)
W=op.load_json(SOURCE/'inputs/WORD.json.gz',op.WORD_GZIP,True);assert op.canonical_hash(W)==op.WORD
R,ROWS,CLOCK=physical.packet_word(W);O,X=physical.evaluate(W['start'],W['final'],R,ROWS,False);O=sorted(R,key=CLOCK.get)
G={k:abs(W['frames'][str(a)]['dim']-W['frames'][str(b)]['dim']) for k,(a,b) in R.items()};DIMS={int(c):v['dim'] for c,v in W['frames'].items()}
PATH={}
for k in O:PATH[k]=(1<<k)^xsum(PATH[j] for j in labels(ROWS[k]) if j in PATH)
M=defaultdict(int)
for i,c in enumerate(W['final']):M[c]|=1<<i
banks=defaultdict(list)
for h,s in enumerate(W['start']):banks[s].append(h)
for p in O:banks[R[p][1]].append(p)
stock=[banks]
class Span:
 def __init__(self):self.rows={};self.union=0
 def add(self,x,label=0):
  self.union|=x
  while x:
   p=x.bit_length()
   if p not in self.rows:self.rows[p]=(x,label);return True
   a,m=self.rows[p];x^=a;label^=m
  return False
 def express(self,x):
  if x&~self.union:return None
  lab=0
  while x:
   pair=self.rows.get(x.bit_length())
   if pair is None:return None
   a,m=pair;x^=a;lab^=m
  return lab
class Reducer:
 def __init__(self,rs):
  self.a=Span()
  for x,y in rs:self.a.add(x,y)
  self.r=sorted(self.a.rows.items(),reverse=True)
 def reduce(self,x):
  m=0
  for p,(v,t) in self.r:
   if x>>(p-1)&1:x^=v;m^=t
  return x,m
def integral(row):
 q=list(map(Fraction,row));m=lcm(*(x.denominator for x in q));return tuple(int(x*m) for x in q)
FRAMES={int(c):(tuple(integral(r) for r in f['B']),tuple(integral(r) for r in f['A'])) for c,f in W['frames'].items()}
@lru_cache(None)
def grade(a,b):
 if a==b:return 0
 l,h=sorted((a,b),key=DIMS.get);d=DIMS[h]-DIMS[l]
 if not d:return None
 if any(sum(u*v for u,v in zip(x,y)) for x in FRAMES[l][0] for y in FRAMES[h][1]):return None
 return d
