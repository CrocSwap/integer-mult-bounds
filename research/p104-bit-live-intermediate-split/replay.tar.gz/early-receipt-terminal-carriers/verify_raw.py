#!/usr/bin/env python3
"""Low-pivot raw-word check of all 129 carrier slots and nine punctured cuts."""
from collections import Counter,defaultdict
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip,json,sys
H=Path(__file__).resolve().parent
raw=(H/'source/inputs/WORD.json.gz').read_bytes();assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
P=w['program'];N=w['public'];frames={int(k):v for k,v in w['frames'].items()};dims={k:v['dim'] for k,v in frames.items()};seeds=json.loads((H/'LATE-PAIR-SEEDS.json').read_bytes());result=json.loads((H/'RESULT.json').read_bytes());assert len(seeds)==129 and not result['hits']

def grade(a,b):
 if a==b:return None
 if dims[a]>dims[b]:a,b=b,a
 d=dims[b]-dims[a]
 if d<=0:return None
 for u in frames[a]['B']:
  for v in frames[b]['A']:
   if sum(Fraction(x)*Fraction(y) for x,y in zip(u,v)):return None
 return d

def add(B,x):
 while x:
  p=(x&-x).bit_length()-1
  if p not in B:B[p]=x;return
  x^=B[p]
def rem(B,x):
 for p in sorted(B):
  if x>>p&1:x^=B[p]
 return x

def run(holes=(),pulse=None):
 cells=[(c,1<<i,0) for i,c in enumerate(w['start'])]+[None]*w['owned_fields'];hist=defaultdict(list);moves={};paths={};outputs=None
 for i,c in enumerate(w['start']):hist[c].append((i,-1,1<<i))
 for t,e in enumerate(P):
  op,a,*rest=e;cell=cells[a]
  if op=='INIT':assert cell is None;cells[a]=(rest[0],0,0)
  elif op=='CLEAR':assert cell is not None and cell[0]==rest[0];cells[a]=None
  elif op=='ADD':
   b,c=rest;other=cells[b];assert cell and other and cell[0]==other[0]==c
   cells[a]=(c,cell[1]^other[1],cell[2]^other[2])
  elif op=='SWAP':
   b,=rest;cells[a],cells[b]=cells[b],cells[a]
  else:
   src,dst=rest;assert op=='MOVE' and cell and cell[0]==src
   moves[a]=(t,src,dst,cell[1]);paths[a]=cell[2]|(1<<a)
   val=0 if a in holes else cell[1]
   tags=0 if a in holes else cell[2]^(1<<a)
   if pulse==a:tags^=1 # a distinguished signal bit, not an owner tag
   cells[a]=(dst,val,tags)
   if a not in holes:hist[dst].append((a,t,val))
 outputs=[x[1] for x in cells[:N]]
 signal=[i for i,x in enumerate(cells[:N]) if x[2]&1]
 return hist,moves,paths,outputs,signal

base,base_moves,paths,base_out,_=run();expected=[(1<<i)^((1<<(i-111)) if 111<=i<222 else 0) for i in range(N)];assert base_out==expected
# Original packet addresses are unique and original public writes occur only at end.
assert len(base_moves)==len([e for e in P if e[0]=='MOVE'])==2874
eligible_by_seed=[]
for k,j,D in seeds:
 cand=[]
 for p,_,_ in base[D]:
  if p<680 or p in (k,j):continue
  if any(z!=p and z not in (k,j) and (paths[z]>>p)&1 for z in paths):continue
  cand.append(p)
 eligible_by_seed.append((k,j,D,cand))
recorded={(r['holes'][0],r['holes'][1],r['deficient_bank']):r['eligible_terminal_only_carriers'] for r in result['seed_census']}
assert all(cand==recorded[k,j,D] for k,j,D,cand in eligible_by_seed)
assert sum(len(x[3]) for x in eligible_by_seed)==9
checks=[];total=0
for k,j,D,cands in eligible_by_seed:
 if not cands:continue
 p,=cands;hist,moves,_,_,signal=run((k,j),pulse=p);clock,src,dest,val=moves[p];assert dest==D
 assert all(w['final'][h]==D for h in signal)
 assert not any(z not in (k,j,p) and (paths[z]>>p)&1 for z in paths)
 other=[x for x in hist[D] if x[0]!=p];B={}
 for _,_,row in other:add(B,row)
 residuals=set()
 for own,c in enumerate(w['final']):
  if c==D:
   q=rem(B,expected[own])
   if q:residuals.add(q)
 assert len(residuals)==1;q=residuals.pop()
 local=[x for x in hist[src] if x[1]<clock];assert all(x[0] not in (k,j) for x in local)
 LS={}
 for _,_,row in local:add(LS,rem(B,row))
 assert rem(LS,q)!=0
 # Punctured carrier's actual row is reconstructible from its saved preclock arrivals.
 whole={}
 for _,_,row in local:add(whole,row)
 assert rem(whole,val)==0
 donors_by_grade=Counter()
 for bank,events in hist.items():
  g=grade(bank,src)
  if g is None or g>6:continue
  donors=[x for x in events if x[1]<clock]
  if not donors:continue
  assert all(x[0] not in (k,j) for x in donors);donors_by_grade[g]+=1
  T=LS.copy()
  for _,_,row in donors:add(T,rem(B,row))
  assert rem(T,q)!=0
 # Supplying the original (unpunctured and omitted) second packet is invalid,
 # but must turn the local cut into a false positive. Also test free target.
 fake=LS.copy();add(fake,rem(B,base_moves[j][3]));assert rem(fake,q)==0
 genie=LS.copy();add(genie,q);assert rem(genie,q)==0
 observed=next(r for r in result['carrier_details'] if r['carrier']==p)
 assert {str(g):n for g,n in donors_by_grade.items()}==observed['tested_donor_banks_by_grade']
 assert observed['allowed_positive_grades']==[1,2,3,4,5,6]
 total+=sum(donors_by_grade.values());checks.append({'holes':[k,j],'carrier':p,'source':src,'destination':D,'clock':clock,'donor_bank_tests':sum(donors_by_grade.values()),'signal_output_owners':signal,'unpunctured_omitted_packet_mutation_rejected':True,'free_target_control_detected':True})
assert total==464 and len(checks)==9
out={'status':'PASS_INDEPENDENT_RAW_PUNCTURED_CONTROL','seed_pairs':129,'eligible_non_descendant_carriers':9,'affordable_nested_donor_banks':total,'survivors':0,'cases':checks,'scope':'Independent low-pivot raw-tape replay of nine actual punctured histories and all 129 non-descendant carrier rosters; free historical retention and only one added receipt are granted.'}
text=json.dumps(out,indent=2,sort_keys=True)+'\n'
if '--verify' in sys.argv:assert (H/'RAW-VERIFY.json').read_text()==text
else:(H/'RAW-VERIFY.json').write_text(text)
print('PASS_RAW_CHECK',len(checks),total)
