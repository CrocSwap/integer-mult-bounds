#!/usr/bin/env python3
"""Punctured early-receipt/non-descendant-carrier gate for 129 seeded pairs.
One scalar is bought before a still-paid terminal-only carrier and locally
recoded into it. Original non-hole paid payloads are otherwise unchanged
except for their actual causal response to the two omissions. Historic scalar
retention and local XOR are granted free; a hit needs literal compilation.
"""
from pathlib import Path
from collections import Counter
from decimal import Decimal
from hashlib import sha256
import json,sys,time,os
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H))
from core import *

try:os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
except (AttributeError,OSError):pass
start=time.monotonic();seeds=json.loads((HERE/'LATE-PAIR-SEEDS.json').read_bytes());assert len(seeds)==129
assert op.WORD=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
price={}
for a in range(1,9):
 for b in range(1,9):
  for g in range(1,9):
   v={str(r):prices.display(prices.scale(prices.minus(prices.plus(prices.power(a,r),prices.power(b,r)),prices.power(g,r)),36)) for r in prices.RATES}
   price[a,b,g]=v

def labels_list(mask):return list(labels(mask))
def positive(a,b,g):return all(Decimal(x[0])>0 for x in price[a,b,g].values())
def punctured(k,j):
 x=X[k];y=X[j]^(x if (PATH[j]>>k)&1 else 0);holes={k,j}
 def value(p):
  if p<680:return 1<<p
  return X[p]^(x if (PATH[p]>>k)&1 else 0)^(y if (PATH[p]>>j)&1 else 0)
 return value,holes

def preclock(c,t,holes):return [p for p in stock[0][c] if p not in holes and (p<680 or CLOCK[p]<t)]

def non_descendant(p,holes):
 return not any(z!=p and z not in holes and ((PATH[z]>>p)&1) for z in O)

def outside_check(holes,D,value):
 # All original outputs outside D have freely granted final-bank history.
 for c,mask in M.items():
  if c==D:continue
  B=Span()
  for p in stock[0][c]:
   if p not in holes:B.add(value(p))
  for h in labels(mask):
   out=(1<<h)^((1<<(h-111)) if 111<=h<222 else 0)
   if B.express(out) is None:return False,{'bank':c,'owner':h}
 return True,None

def compare_samples(tlist,db,q):
 for h in tlist:
  e=(1<<h)^((1<<(h-111)) if 111<=h<222 else 0)
  r,_=db.reduce(e)
  if r not in (0,q):return False
 return True

def run():
 stats=Counter();census=[];hits=[];details=[];grade_cache={};carrier_cache={};lastprint=0
 for i,(k,j,D) in enumerate(seeds):
  assert CLOCK[k]<CLOCK[j] and k!=3553 and j!=3553
  value,holes=punctured(k,j);outowners=list(labels(M[D]));stats['seeds']+=1
  if D not in carrier_cache:carrier_cache[D]=[p for p in stock[0][D] if p>=680]
  eligible=[]
  for p in carrier_cache[D]:
   if p in holes:continue
   if not non_descendant(p,holes):continue
   eligible.append(p)
  stats['non_descendant_carrier_slots']+=len(eligible)
  found=0
  for p in eligible:
   t=CLOCK[p];src=R[p][0]
   other=[z for z in stock[0][D] if z not in holes and z!=p]
   db=Reducer([(value(z),1<<z) for z in other]);res=[]
   for owner in outowners:
    want=(1<<owner)^((1<<(owner-111)) if 111<=owner<222 else 0)
    rem,_=db.reduce(want)
    if rem and rem not in res:res.append(rem)
    if len(res)>1:break
   if not res:stats['no_deficit_without_carrier']+=1;continue
   if len(res)>1:stats['leave_one_out_rank_above_one']+=1;continue
   q=res[0];stats['one_dimensional_carriers']+=1
   local=preclock(src,t,holes);localset=set(local);b=Span()
   actual=Span()
   for z in local:
    assert z not in holes and (z<680 or CLOCK[z]<t)
    b.add(db.reduce(value(z))[0],1<<z);actual.add(value(z),1<<z)
   carrier_original=actual.express(value(p));assert carrier_original is not None
   assert all(z not in holes and z in localset for z in labels(carrier_original))
   m=b.express(q)
   if m is not None:
    express=list(labels(m));assert all(z not in holes and z in localset for z in express)
    rec={'holes':[k,j],'deficient_bank':D,'carrier':p,'carrier_route':list(R[p]),'carrier_clock':t,'source_local_express':express,'donor':None,'new_grade':0,'old_grades':[G[k],G[j]],'gain':'no added paid transfer; original 2 removed','terminal_required_owners':outowners,'history_retention_is_free':True}
    ok,err=outside_check(holes,D,value);rec['outside_original_outputs_restorable']=ok;rec['outside_failure']=err
    if ok:
     hits.append(rec);found+=1;print('HIT',json.dumps(rec),flush=True);(H/'HITS.json').write_text(json.dumps(hits,indent=2)+'\n')
    continue
   assert m is None
   # Negative/positive control: the unpunctured deleted j is forbidden. If it
   # is artificially restored, all nine original cases become solvable.
   bad=Span();bad.rows=b.rows.copy();bad.union=b.union;bad.add(db.reduce(X[j])[0],1<<j)
   phantom=bad.express(q);assert phantom is not None and phantom>>j&1
   genie=Span();genie.rows=b.rows.copy();genie.union=b.union;genie.add(q,1<<j)
   assert genie.express(q) is not None
   outside_ok,outside_error=outside_check(holes,D,value);assert outside_ok, outside_error
   det={'holes':[k,j],'bank':D,'carrier':p,'source_bank':src,'carrier_clock':t,
        'removed_grades':[G[k],G[j]],'source_history_count':len(local),
        'post_puncture_carrier_source_witness':list(labels(carrier_original)),
        'free_local_recoder_restores':False,'synthetic_unpunctured_omitted_packet_control_rejected':True,
        'output_owners':outowners,'quotient_target_sha256':sha256(q.to_bytes(85,'little')).hexdigest(),
        'allowed_positive_grades':[g for g in range(1,9) if positive(G[k],G[j],g)],
        'allowed_grade_gain_36_call':{str(g):price[G[k],G[j],g] for g in range(1,9) if positive(G[k],G[j],g)},
        'tested_donor_banks_by_grade':{},'outside_outputs_redecode':True}
   grade_counts=Counter()
   for gmax in range(1,9):
    if not positive(G[k],G[j],gmax):continue
    # Compute route rank only for candidate sources whose dimension gap is gmax.
    for donor,events in stock[0].items():
     if donor==src or abs(DIMS[donor]-DIMS[src])!=gmax:continue
     key=(donor,src)
     if key not in grade_cache:grade_cache[key]=grade(donor,src)
     if grade_cache[key]!=gmax:continue
     donors=preclock(donor,t,holes)
     if not donors:continue
     assert all(z not in holes and (z<680 or CLOCK[z]<t) for z in donors)
     stats['donor_bank_tests']+=1;grade_counts[gmax]+=1
     tryB=Span();tryB.rows=b.rows.copy();tryB.union=b.union
     for z in donors:tryB.add(db.reduce(value(z))[0],1<<z)
     m=tryB.express(q)
     if m is None:continue
     ss,ds=[z for z in labels(m) if z in localset],[z for z in labels(m) if z not in localset]
     assert ds and set(ds)<=set(donors) and all(z not in holes for z in ss+ds)
     packet_value=xsum(value(z) for z in ss+ds);assert db.reduce(packet_value)[0]==q
     rec={'holes':[k,j],'deficient_bank':D,'carrier':p,'carrier_route':list(R[p]),'carrier_clock':t,'source_local_express':ss,'donor':donor,'donor_express':ds,'donor_latest_original_clock':max((CLOCK[z] if z>=680 else -1) for z in ds),'new_grade':gmax,'old_grades':[G[k],G[j]],'gain_36_call':price[G[k],G[j],gmax],'terminal_required_owners':outowners,'history_retention_is_free':True}
     ok,err=outside_check(holes,D,value);rec['outside_original_outputs_restorable']=ok;rec['outside_failure']=err
     if ok:
      hits.append(rec);found+=1;print('HIT',json.dumps(rec),flush=True);(H/'HITS.json').write_text(json.dumps(hits,indent=2)+'\n')
     # This is the cheapest qualifying source per carrier; enumerate more only after review.
     break
    else:continue
    break
   det['tested_donor_banks_by_grade']=dict(grade_counts);details.append(det)
  census.append({'holes':[k,j],'deficient_bank':D,'eligible_terminal_only_carriers':eligible,'survivors':found})
  if i%10==0:print('progress',i,'seeds',stats['seeds'],'carriers',stats['non_descendant_carrier_slots'],'donor tests',stats['donor_bank_tests'],'hits',len(hits),'seconds',round(time.monotonic()-start,1),flush=True)
 out={'source_word':op.WORD,'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','seed_file_sha256':sha256((HERE/'LATE-PAIR-SEEDS.json').read_bytes()).hexdigest(),'status':'PUNCTURED_HISTORICAL_EARLY_RECEIPT_GATE','stats':dict(stats),'hits':hits,'seed_census':census,'carrier_details':details,'scope':'129 R7 single-deficit terminal seeds; remove both named original packets; an original surviving carrier into the deficient final bank must have no original surviving paid descendants. Re-encode it using strict-preclock punctured source history and at most one paid nested donor scalar of strictly positive 36-call saving at both trial rates; actual final-bank leave-one-row-out target quotient and exterior terminal targets tested. Free retention and arbitrary local XOR are grants; hits are not literal schedules.'}
 text=json.dumps(out,indent=2,sort_keys=True)+'\n'
 if '--verify' in sys.argv:assert (H/'RESULT.json').read_text()==text,'stored result mismatch'
 else:(H/'RESULT.json').write_text(text)
 print('DONE',json.dumps(dict(stats)),len(hits),flush=True)
run()
