# Early receipt into a terminal-only carrier

Across 129 single-deficit terminal-pair seeds, this exact punctured-history screen finds **no saving** using a surviving terminal-only carrier, a free cochart re-encoder, and at most one additional affordable nested transfer into that carrier's source. This is a bounded negative screen, not a new κ bound or a general exclusion of early receipts.

The pinned native word is [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15), canonical SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. [LATE-PAIR-SEEDS.json](LATE-PAIR-SEEDS.json), SHA-256 `f524a141f94f196b6979e6ae2355f69dc3a627a90da42a9f2fd208ab3a678c07`, is the specified R7 architect's 129-seed snapshot.

## Exact screen

For each seed `(k,j,D)`, zero both deleted paid packets and propagate those changes through every later surviving paid equation. The output row of each remaining arrival is its **post-puncture** value. A carrier `p` must be an original still-paid ingress into final chart `D` whose original transitive paid descendants are all deleted or absent. This conservative original-graph condition ensures recoding `p` changes no other surviving paid payload. The screen independently checks that all exterior terminal equations can still be decoded from the post-puncture histories.

For each eligible carrier, build the complete original historical stock at `D`, exclude `k`, `j` and `p`, and project each required final row modulo that leave-one-out span. A single altered carrier can help only when the nonzero required quotient has rank one. Next, at the original carrier clock, grant arbitrary XORs of every original arrival at its source that occurred **strictly earlier**, using its recomputed punctured value and excluding both deleted labels. This tests the free cochart re-encoder. For one paid replacement, grant one arbitrary XOR of the strictly prior punctured history of any one nested donor chart, delivered to the carrier source before its clock. The carrier then carries any XOR of the resulting donor row and the existing source history. All input retention and local arithmetic are free in this necessary-condition screen.

All nine carriers have a rank-one requirement. Their actual post-puncture values are constructible from the allowed source history, but no source-only re-encoding works. Among all nested donor banks with nonempty strict-preclock stock and a strictly positive price change at both requested trials, **464 bank/grade combinations fail** the full target quotient test. Both omitted packet labels are excluded from every tested history.

| Deleted packets | Surviving carrier | Final bank | Carrier source |
| --- | ---: | ---: | ---: |
| 3315, 3316 | 3317 | 528 | 344 |
| 3386, 3387 | 3388 | 586 | 356 |
| 3419, 3420 | 3421 | 534 | 329 |
| 3436, 3437 | 3438 | 547 | 419 |
| 3461, 3462 | 3463 | 571 | 333 |
| 3480, 3481 | 3482 | 585 | 433 |
| 3487, 3488 | 3489 | 591 | 396 |
| 3494, 3495 | 3496 | 597 | 355 |
| 3499, 3500 | 3501 | 599 | 387 |

There are no eligible carriers for the other 120 seeds under this original-descendant rule. [RESULT.json](RESULT.json) includes all 129 carrier rosters, the nine source witnesses, target quotient hashes, per-grade donor counts and outward-directed rate comparisons.

All nine deleted pairs have original grades 4 and 2. At `κ = 0.003879928046156` and `0.003879929046155`, direct outward arithmetic checks that a single new grade 1–6 contact would cost less than those two deleted contacts. A grade-6 candidate would hypothetically gain `+0.530571876369405…` and `+0.530572012380025…` over 36 calls, respectively, if all the other assumptions and obligations were satisfied. The stock test finds no such candidate. These are hypothetical price differences, not an invoice for a legal changed word.

## Independent checks and boundaries

A separate low-pivot checker interprets the original program directly, zeroes each named deleted MOVE at its arrival, and recomputes the complete later word. It reproduces the carrier roster for all 129 seeds and every one of the 464 donor-bank failures for the nine surviving triples. It also verifies the real punctured carrier payload can be reconstructed from prior cochart arrivals and that an injected carrier signal reaches no exterior terminal. The checker does not import the producer's packet-graph or span engine.

In all nine triples, falsely inserting the **original unpunctured value** of the deleted second packet into the carrier-source history makes the free-reencoder cut pass; the real punctured history fails. A free synthetic target-row injection also succeeds as a positive control. This directly tests the omitted-packet and punctured-history conditions.

The screen retains all other original paid routes and grants all prior arrivals for free, even where physical copies or parking would need to be constructed. It covers only these 129 seed pairs and the conservative terminal-only carrier predicate. It does not exclude alternative seed pairs, paid descendants whose effects are jointly repaired, new charts, more than one additional contact, terminal retargeting, caller changes, or a new native construction. No physical erasure, finite supplier or analytic recovery is established.

## Reproduction

CPython 3.12 and the standard library are sufficient. From the extracted directory:

```sh
sha256sum -c SHA256SUMS
python3 -IB screen.py --verify
python3 -IB verify_raw.py --verify
```

The source directory retains the original Apache license, upstream notices, exact word and interpreter dependencies. Both checkers reject a changed frozen result. No external service is needed.
