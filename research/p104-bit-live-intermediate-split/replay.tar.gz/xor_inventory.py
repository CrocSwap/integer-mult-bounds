#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""High-grade MOVE shortening from XORs of actually live intermediate stock."""
from collections import Counter, defaultdict
from pathlib import Path
from hashlib import sha256
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'early-receipt-terminal-carriers'))
from core import *

cells=[(c,1<<i,None) for i,c in enumerate(W['start'])]+[None]*W['owned_fields']
charts=defaultdict(set)
for a,(c,v,p) in enumerate(cells[:680]):charts[c].add(a)
def assign(a,cell):
 if cells[a] is not None:
  c,_,_=cells[a];charts[c].remove(a)
  if not charts[c]:del charts[c]
 cells[a]=cell
 if cell is not None:charts[cell[0]].add(a)

out=[]; counts=Counter(); tested=[];pmoves=0
for t,e in enumerate(W['program']):
 opn,a,*tail=e; old=cells[a]
 if opn=='INIT':assert old is None;assign(a,(tail[0],0,None))
 elif opn=='CLEAR':assert old is not None and old[0]==tail[0];assign(a,None)
 elif opn=='ADD':
  b,c=tail;other=cells[b];assert old and other and old[0]==other[0]==c
  assign(a,(c,old[1]^other[1],old[2] if other[1]==0 else None))
 elif opn=='SWAP':
  b,=tail;other=cells[b];assert old and other
  assign(a,None);assign(b,None);assign(a,other);assign(b,old)
 elif opn=='MOVE':
  A,B=tail;assert old and old[0]==A
  label=680+pmoves;pmoves+=1;assert label==a and R[label]==(A,B) and CLOCK[label]==t
  g=G[label]
  if g>=4 and label!=3553 and old[1]:
   counts['high_grade_nonbridge_moves']+=1
   l,h=sorted((A,B),key=DIMS.get)
   for C in sorted(charts):
    if not DIMS[l]<DIMS[C]<DIMS[h]:continue
    if grade(A,C) is None or grade(C,B) is None:continue
    assert grade(A,C)+grade(C,B)==g
    counts['live_nested_middle_banks']+=1
    bank=Span()
    for b in sorted(charts[C]):bank.add(cells[b][1],1<<b)
    mask=bank.express(old[1]);success=mask is not None
    counts['successful_live_xor']+=success
    if len(tested)<15:
     tested.append(dict(packet=label,clock=t,route=[A,B],old_grade=g,
         middle=C,stock_count=len(charts[C]),stock_rank=len(bank.rows),
         can_reconstruct=success,source_sha256=sha256(old[1].to_bytes(85,'little')).hexdigest()))
    if not success:continue
    fs=list(labels(mask));assert fs
    donated=[dict(field=b,packet=cells[b][2],arrival_clock=CLOCK[cells[b][2]]) for b in fs if cells[b][2] is not None]
    assert all(d['arrival_clock']<t for d in donated)
    counts['live_xor_with_prior_paid_receipt']+=bool(donated)
    out.append(dict(packet=label,clock=t,old_route=[A,B],old_grade=g,
       intermediate_chart=C,used_fields=fs,donors=donated,
       first_grade=grade(A,C),remaining_grade=grade(C,B),
       row_sha256=sha256(old[1].to_bytes(85,'little')).hexdigest()))
  assign(a,(B,old[1],label))
 else:raise ValueError((t,e))
assert pmoves==len(R)==2874
result={'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'word_sha256':op.WORD,'counts':dict(counts),'candidates':out,'first_failed_examples':tested,
 'scope':'Grade 4/5/6 nonbridge forward MOVEs; exact currently live field rows on each strictly intermediate original rational chart. Arbitrary local XOR of all live fields granted; only banks with live fields included. Inputs and earlier surviving packets remain unchanged. No alternate charts or timing.'}
serialized=json.dumps(result,indent=2,sort_keys=True)+'\n'
if '--verify' in sys.argv:assert (ROOT/'XOR-INVENTORY.json').read_text()==serialized
else:(ROOT/'XOR-INVENTORY.json').write_text(serialized)
print('counts',dict(counts),'candidates',len(out))
for r in out[:20]:print(json.dumps(r,sort_keys=True))
