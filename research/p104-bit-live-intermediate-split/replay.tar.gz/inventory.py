#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Find literal live paid receipts for shortening an original paid MOVE."""
from collections import Counter, defaultdict
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'early-receipt-terminal-carriers'))
from core import *

# provenance means this exact nonzero row has remained unchanged since a
# prior paid arrival; it follows a SWAP and is invalidated by a nonzero ADD.
cells=[(c,1<<i,None) for i,c in enumerate(W['start'])]+[None]*W['owned_fields']
live=defaultdict(set)
for a,(c,v,p) in enumerate(cells[:680]):live[c,v].add(a)
byval=defaultdict(set)
for c,v in live:byval[v].add(c)

def remove(a):
 c,v,p=cells[a]; s=live[c,v];s.remove(a)
 if not s:
  del live[c,v];byval[v].remove(c)
  if not byval[v]:del byval[v]

def assign(a,cell):
 if cells[a] is not None:remove(a)
 cells[a]=cell
 if cell is not None:
  c,v,p=cell;live[c,v].add(a);byval[v].add(c)

out=[]; counts=Counter();pmoves=0
for t,e in enumerate(W['program']):
 opn,a,*tail=e; old=cells[a]
 if opn=='INIT':
  assert old is None; assign(a,(tail[0],0,None))
 elif opn=='CLEAR':
  assert old is not None and old[0]==tail[0];assign(a,None)
 elif opn=='ADD':
  b,c=tail;other=cells[b];assert old and other and old[0]==other[0]==c
  assign(a,(c,old[1]^other[1],old[2] if other[1]==0 else None))
 elif opn=='SWAP':
  b,=tail;other=cells[b]; assert old and other
  assign(a,None);assign(b,None);assign(a,other);assign(b,old)
 elif opn=='MOVE':
  A,B=tail;assert old and old[0]==A
  label=680+pmoves;pmoves+=1;assert label==a and R[label]==(A,B) and CLOCK[label]==t
  g=grade(A,B);assert g==G[label]
  if g>=2 and label!=3553 and old[1]:
   counts['high_grade_nonbridge_moves']+=1
   for C in sorted(byval.get(old[1],())):
    if C in (A,B):continue
    d1,d2=grade(A,C),grade(C,B)
    if d1 is None or d2 is None or d1==0 or d2==0 or d1+d2!=g:continue
    counts['live_equal_row_intermediate_slots']+=len(live[C,old[1]])
    for b in sorted(live[C,old[1]]):
     donor=cells[b][2]
     if donor is None or donor==3553:continue
     assert donor<label and CLOCK[donor]<t
     counts['durable_paid_receipts']+=1
     out.append(dict(packet=label,clock=t,old_route=[A,B],old_grade=g,
      intermediate_chart=C,reused_field=b,earlier_packet=donor,
      earlier_packet_clock=CLOCK[donor],earlier_route=list(R[donor]),
      earlier_grade=G[donor],first_grade=d1,remaining_grade=d2,
      row_sha256=__import__('hashlib').sha256(old[1].to_bytes(85,'little')).hexdigest(),
      input_support=list(labels(old[1]))))
  assign(a,(B,old[1],label))
 else:raise ValueError((t,e))
assert pmoves==len(R)==2874
result={'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'word_sha256':op.WORD,'counts':dict(counts),'candidates':out,
 'scope':'Exact original forward tape, old high-grade nonbridge packet, literal unchanged live prior paid arrival with identical nonzero GF(2) value at an intermediate chart on the same strict nested A–B chain. Only arrival whose holder has had no nonzero ADD since is eligible. Does not include cochart linear combinations or altered/prior retimings.'}
serialized=json.dumps(result,indent=2,sort_keys=True)+'\n'
if '--verify' in sys.argv:assert (ROOT/'INVENTORY.json').read_text()==serialized
else:(ROOT/'INVENTORY.json').write_text(serialized)
print('counts',dict(counts),'candidates',len(out))
for r in out[:20]:print(json.dumps(r,sort_keys=True))
