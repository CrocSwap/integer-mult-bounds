#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Literal replay of packet 724 with a paid split and a false free-reuse control."""
from collections import Counter
from copy import deepcopy
from decimal import Decimal
from hashlib import sha256
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'early-receipt-terminal-carriers'))
from core import *

K=Decimal('0.00388')
assert sha256((ROOT/'BIT.json').read_bytes()).hexdigest()=='8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'
bit=json.loads((ROOT/'BIT.json').read_bytes())
caller=op.load_json(ROOT/'EFREE-CALLER.json.gz',op.CALLER,True)
atlas=op.Atlas(W['frames'])
assert CLOCK[724]==157 and W['program'][157]==['MOVE',724,8,328]
assert list(labels(X[724]))==[672]
assert R[685]==(2,270) and CLOCK[685]==20 and list(labels(X[685]))==[0,224]
assert [grade(8,328),grade(8,270),grade(270,328)]==[5,3,2]

# Primitive forward replay up to the real clock, checking that both physical
# fields and their exact rows coexist rather than relying on saved history.
cells=[(c,1<<i) for i,c in enumerate(W['start'])]+[None]*W['owned_fields']
for event in W['program'][:157]:
 opcode,address,*args=event; cell=cells[address]
 if opcode=='INIT':assert cell is None;cells[address]=(args[0],0)
 elif opcode=='CLEAR':assert cell is not None and cell[0]==args[0];cells[address]=None
 elif opcode=='ADD':
  peer,chart=args; other=cells[peer];assert cell and other and cell[0]==other[0]==chart
  cells[address]=(chart,cell[1]^other[1])
 elif opcode=='SWAP':
  peer,=args;assert cell and cells[peer];cells[address],cells[peer]=cells[peer],cell
 elif opcode=='MOVE':
  source,destination=args;assert cell and cell[0]==source;cells[address]=(destination,cell[1])
 else:raise ValueError(opcode)
assert cells[724]==(8,1<<672) and cells[685]==(270,(1<<0)^(1<<224))

def construct_split():
 w=deepcopy(W)
 w['program'][157:158]=[['MOVE',724,8,270],['MOVE',724,270,328]]
 return w

def construct_wrong_free():
 w=deepcopy(W); temp=w['public']+w['owned_fields']; w['owned_fields']+=1
 w['program'][157:158]=[['INIT',temp,270],['ADD',temp,685,270],
                         ['MOVE',temp,270,328],['SWAP',724,temp],['CLEAR',temp,8]]
 return w

def replay(w):
 z=[]
 for reverse in (False,True):
  t=op.run_tape(w,atlas,reverse)
  expected=op.expected_operator(reverse)
  bad=[dict(output=i,changed_inputs=list(labels(actual^want)))
       for i,(actual,want) in enumerate(zip(t.output,expected)) if actual!=want]
  assert t.output[411]==1<<411
  z.append((t,bad))
 return z

base=replay(W); split_word=construct_split();split=replay(split_word);fake_word=construct_wrong_free();fake=replay(fake_word)
assert all(not bad for _,bad in base+split)
assert all(bad for _,bad in fake)
assert all(t.dirty==3554 for t,_ in base+split)
assert [t.dirty for t,_ in fake]==[3555,3554]
assert fake[0][1][0]=={'output':113,'changed_inputs':[0,224,672]}
base_n,base_t,base_paid,base_targets=op.binary_invoice(W,caller,atlas,base[0][0])
new_n,new_t,new_paid,new_targets=op.binary_invoice(split_word,caller,atlas,split[0][0])
assert base_paid==Counter({int(g):v for g,v in bit['native']['paid'].items()})
assert base_targets==Counter({int(g):v for g,v in bit['native']['targets'].items()})
assert new_t==base_t and new_targets==base_targets
assert (base_n-new_n)==Counter({5:1}) and (new_n-base_n)==Counter({2:1,3:1})
assert (base_paid-new_paid)==Counter({5:36}) and (new_paid-base_paid)==Counter({2:36,3:36})
assert Counter(p.grade for p in split[0][0].packets.values())==Counter(p.grade for p in split[1][0].packets.values())
delta=prices.scale(prices.minus(prices.minus(prices.power(5,K),prices.power(3,K)),prices.power(2,K)),36)
unpaid_fantasy=prices.scale(prices.minus(prices.power(5,K),prices.power(2,K)),36)
before=prices.moment(base_paid,base_targets,K);after=prices.moment(new_paid,new_targets,K)
assert prices.minus(after,before)[0]<=delta[1] and delta[0]<=prices.minus(after,before)[1]
assert delta[1]<0 and after[1]<0
out={
 'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'word_sha256':op.WORD,'trial_kappa':str(K),
 'selected_original':{'packet':724,'clock':157,'route':[8,328],'grade':5,'payload_support':[672]},
 'existing_receipt':{'packet':685,'clock':20,'route':[2,270],'grade':G[685],'payload_support':[0,224],
    'still_live_field':685,'identical_to_original_payload':False},
 'fully_paid_control':{'operations':[['MOVE',724,8,270],['MOVE',724,270,328]],
   'ranks_removed':[5],'ranks_added':[3,2],
   'native_word_canonical':op.canonical_hash(split_word),
   'native_paid_before':dict(base_n),'native_paid_after':dict(new_n),
   'caller_paid_before':dict(base_paid),'caller_paid_after':dict(new_paid),
   'caller_productive_before':dict(base_targets),'caller_productive_after':dict(new_targets),
   'forward_damaged_rows':len(split[0][1]),'adjoint_damaged_rows':len(split[1][1]),
   'forward_dirty_retirements':split[0][0].dirty,'adjoint_dirty_retirements':split[1][0].dirty,
   'signed_delta_36_call':prices.display(delta),
   'base_complete_binary_margin':prices.display(before),'changed_complete_binary_margin':prices.display(after)},
 'false_free_control':{'description':'Copy the existing chart-270 receipt into a fresh temporary, send 270→328, swap with field 724 and retire the original at chart 8. This is syntactically valid but changes the original input row.',
   'native_word_canonical':op.canonical_hash(fake_word),
   'forward_damaged_rows':len(fake[0][1]),'adjoint_damaged_rows':len(fake[1][1]),
   'forward_first_10_differences':fake[0][1][:10], 'adjoint_first_10_differences':fake[1][1][:10],
   'forward_dirty_retirements':fake[0][0].dirty,'adjoint_dirty_retirements':fake[1][0].dirty,
   'hypothetical_36_call_grade_gain_if_wrong_free_claim_accepted':prices.display(unpaid_fantasy)},
 'boundary':'The correctly priced 3+2 split preserves both complete native operators and the 36-call productive invoice, but loses by strict subadditivity. Reuse of packet 685 fails exact GF(2) payload and both operators. This is a local literal control; finite and physical transfer are not asserted.'}
serialized=json.dumps(out,indent=2,sort_keys=True)+'\n'
if '--verify' in sys.argv:assert (ROOT/'REPLAY.json').read_text()==serialized
else:(ROOT/'REPLAY.json').write_text(serialized)
print('paid split PASS both; 36-call delta',prices.display(delta),'full margin',prices.display(after))
print('fake reuse FAIL forward',len(fake[0][1]),'adjoint',len(fake[1][1]),'dirty',fake[0][0].dirty,fake[1][0].dirty)
