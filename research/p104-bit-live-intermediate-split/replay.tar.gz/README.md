# A paid telescoping control and a live-receipt inventory

No existing free first leg was found in the tested original native word. A
literal two-leg split of one original high-grade contact is valid in both
native directions but loses on the complete 36-call BIT invoice at
`K = 0.00388`. A proposed free reuse of a nearby previously paid receipt
fails because the live receipt and the original packet carry different rows.
These are local computational results, not a new conditional κ bound.

The native word is #7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`,
canonical SHA-256
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
The frozen #7985 early-receipt archive supplies the source interpreter and
word. The matched #7830 BIT and paired caller files are separately SHA-pinned
in `replay.py`. Original Apache license and notices are retained. See [NOTICE](NOTICE).

## Inventory

The scan walks the literal forward program and maintains the actual chart,
GF(2) input row and live status of every field at each original MOVE. It
examines all **1,497** nonbridge, nonzero original MOVEs of grade at least 2.
None has a single live field with the identical row at a strictly intermediate
original chart nested between its original endpoints. This first test grants
all live fields, including public fields; it does not require the matched
field to be a previously paid receipt.

The stronger local-XOR test examines the **162** nonbridge original MOVEs of
grades 4, 5 and 6. For each at its real clock, it forms the full live-field
row span at each nonempty original intermediate nested chart. All **1,271**
MOVE/chart combinations fail to reconstruct the original payload, even with
free local XOR and access to every currently live row. An existing productive
return or earlier paid receipt whose field is actually live at the required
chart and time is included in this grant. The scan excludes stale historical
stock, hypothetical future returns and changes made before the original clock.

## Concrete literal controls

Original packet 724 at clock 157 sends `x₆₇₂` from chart 8 to chart 328 at
grade 5. Chart 270 is a nested intermediate: `8 → 270` has grade 3 and
`270 → 328` has grade 2. At that same clock, the physical field of prior paid
packet 685 is still live at chart 270. It arrived at clock 20 on a grade-3
MOVE `2 → 270` but holds `x₀ ⊕ x₂₂₄`, not `x₆₇₂`.

Replacing the single original MOVE on field 724 by the two literal MOVEs
`8 → 270` and `270 → 328` preserves every coefficient of all 680 native
output rows in each of forward and adjoint orientations. Both still retire
3,554 dirty private fields. The paired caller's full polynomial operator,
all 36 LOCAL calls, and all productive occurrences are recounted. At each
LOCAL one grade-5 paid occurrence is deleted and one grade-3 plus one
grade-2 occurrence are added. Let `H(g)=g^(1−K)`. Directed arithmetic gives

`36 [H(5) − H(3) − H(2)] = −0.467769001901643579002069…`.

The unchanged complete BIT margin is
`−0.027711360190217590400992…`; the changed margin is
`−0.495480362091861169403061…`. Both are negative. The rational invoice is
not needed to reject this BIT control. At any `0<K<1`, the same general paid
split loses because `H(a+b)<H(a)+H(b)` for positive `a,b`.

For a false-reuse control, the program creates a temporary at chart 270,
copies live field 685, sends the copy to chart 328, swaps it for field 724
and retires the old chart-8 field. All literal chart and liveness checks pass,
but it changes the value delivered at the old packet to `x₀ ⊕ x₂₂₄`. The
full replay finds **64 damaged forward output rows** and **3 damaged adjoint
output rows**; forward output 113 differs on inputs 0, 224 and 672. It
retires 3,555 dirty fields forward and 3,554 in adjoint. Its hypothetical
grade-only saving of `36[H(5)−H(2)] ≈ 107.0728482862` therefore has no
valid word behind it.

## Boundaries and reproduction

These scans do not exclude a newly constructed intermediate chart, a changed
upstream sender or earlier paid packet, a retimed return, extra communications
or altered incidence/ownership. The local-XOR census covers grades 4–6 only;
the single-identical-row census covers all paid grades at least 2. Physical
erasure, ordinary work and finite transfer of a changed candidate would need
separate qualification. No positive candidate was found to enter those gates.

From this directory with CPython 3.12 and the standard library:

```sh
python3 -IB verify_manifest.py
python3 -IB inventory.py --verify
python3 -IB xor_inventory.py --verify
python3 -IB replay.py --verify
```

`INVENTORY.json`, `XOR-INVENTORY.json` and `REPLAY.json` are frozen outputs;
the latter records the full productive and paid bins and exact directed
intervals. For an archive audit, add `--archive /path/to/archive.tar.gz` to
the manifest command. The verifier checks every file and nested source member.
