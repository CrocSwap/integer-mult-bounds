#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Verify the complete extracted inventory and optionally every archive member."""
from hashlib import sha256
from pathlib import Path, PurePosixPath
import sys
import tarfile

ROOT = Path(__file__).resolve().parent


def parse(data):
    result = {}
    for line in data.decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        p = PurePosixPath(name)
        assert len(digest) == 64 and all(c in '0123456789abcdef' for c in digest)
        assert not p.is_absolute() and '..' not in p.parts and name == p.as_posix()
        assert name not in result
        result[name] = digest
    return result


def digest(data):
    return sha256(data).hexdigest()


def verify():
    manifest_bytes = (ROOT/'SHA256SUMS').read_bytes()
    manifest = parse(manifest_bytes)
    actual = set()
    for path in ROOT.rglob('*'):
        assert not path.is_symlink(), f'symlink {path}'
        assert '__pycache__' not in path.parts and path.suffix != '.pyc', f'cache {path}'
        if path.is_file():
            name = path.relative_to(ROOT).as_posix()
            if name != 'SHA256SUMS':
                actual.add(name)
    assert actual == set(manifest), f'inventory mismatch: missing={set(manifest)-actual}, extra={actual-set(manifest)}'
    for name, expected in manifest.items():
        assert digest((ROOT/name).read_bytes()) == expected, name
    nested = ROOT/'early-receipt-terminal-carriers'
    nested_manifest_bytes = (nested/'SHA256SUMS').read_bytes()
    nested_manifest = parse(nested_manifest_bytes)
    nested_actual = {p.relative_to(nested).as_posix() for p in nested.rglob('*') if p.is_file()}
    assert nested_actual == set(nested_manifest) | {'SHA256SUMS'}, 'nested extracted inventory differs'
    for name, expected in nested_manifest.items():
        assert digest((nested/name).read_bytes()) == expected, f'nested {name}'
    with tarfile.open(ROOT/'terminal/early.tar.gz', 'r:gz') as upstream:
        members = upstream.getmembers()
        names = [m.name for m in members]
        prefix = 'early-receipt-terminal-carriers/'
        expected_names = {prefix+n for n in nested_actual}
        assert len(names)==len(set(names)) and set(names)==expected_names, 'nested archive inventory differs'
        assert all(m.isfile() and not m.issym() and not m.islnk() for m in members), 'nested non-file member'
        for member in members:
            name = member.name[len(prefix):]
            data = upstream.extractfile(member).read()
            if name == 'SHA256SUMS':
                assert data == nested_manifest_bytes
            else:
                assert digest(data) == nested_manifest[name], f'nested archive {name}'
    if '--archive' in sys.argv:
        argument = sys.argv[sys.argv.index('--archive')+1]
        with tarfile.open(argument, 'r:gz') as archive:
            members = archive.getmembers()
            names = [m.name for m in members]
            assert len(names) == len(set(names)), 'duplicate archive member'
            assert all(m.isfile() and not m.issym() and not m.islnk() for m in members), 'non-file archive member'
            assert set(names) == set(manifest) | {'SHA256SUMS'}, 'archive inventory differs'
            for member in members:
                data = archive.extractfile(member).read()
                if member.name == 'SHA256SUMS':
                    assert data == manifest_bytes
                else:
                    assert digest(data) == manifest[member.name], member.name
    print('PASS_COMPLETE_INVENTORY', len(actual), 'manifested files plus root manifest',
          'with archive' if '--archive' in sys.argv else '')


if __name__ == '__main__':
    verify()
