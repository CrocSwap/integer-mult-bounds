#!/usr/bin/env python3
"""Replay the literal control in one process and verify its first cleanup cut."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip,json,shutil,subprocess,sys,tarfile
ROOT=Path(__file__).resolve().parent

def need(ok,msg):
 if not ok:raise AssertionError(msg)
def read_json(p):
 b=p.read_bytes();return json.loads(gzip.decompress(b) if str(p).endswith('.gz') else b)
def inventory():
 entries=[]
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);p=Path(name)
  need(not p.is_absolute() and '..' not in p.parts,'unsafe inventory path')
  need(sha256((ROOT/p).read_bytes()).hexdigest()==digest,'inventory '+name);entries.append(name)
 need(set(('compile_control.py','RESULT.json','CONTROL-WORD.json.gz','PRIVATE-LIFETIMES.json.gz','OWNER-CALL-TABLES.json.gz','INVOICE.json')) <= set(entries),'incomplete inventory')
 return entries

def source_authentication():
 p=ROOT/'inputs/REMOTE-7912.tar.gz'
 need(sha256(p.read_bytes()).hexdigest()=='87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096','7912 archive pin')
 with tarfile.open(p,'r:gz') as archive:
  for archived,local in [('WORD.json.gz','WORD.json.gz'),('ZERO-CONTROL-WORD.json.gz','ZERO-CONTROL-WORD.json.gz'),('bit_native.py','bit_native.py'),('literal.py','literal.py'),('EFREE-CALLER.json.gz','EFREE-CALLER.json.gz')]:
   path='./'+archived if archived=='ZERO-CONTROL-WORD.json.gz' else './inputs/'+archived
   member=archive.extractfile(path);need(member is not None and member.read()==(ROOT/'inputs'/local).read_bytes(),'archive member '+path)

def independent_forward_cut():
 # Re-execute the candidate without importing the compiler, stop at the first
 # CLEAR and check the claimed dual separating functional against every bank.
 w=read_json(ROOT/'CONTROL-WORD.json.gz');result=read_json(ROOT/'RESULT.json')
 n=w['public'];bank=[1<<i for i in range(n)]+[0]*w['owned_fields'];tags=list(w['start'])+[None]*w['owned_fields']
 found=False
 for t,(op,r,*args) in enumerate(w['program']):
  if op=='INIT':need(tags[r] is None,'open');tags[r]=args[0];bank[r]=0
  elif op=='ADD':
   src,chart=args;need(tags[r]==tags[src]==chart,'contact');bank[r]^=bank[src]
  elif op=='MOVE':
   a,b=args;need(tags[r]==a,'move');tags[r]=b
  elif op=='SWAP':
   p=args[0];bank[r],bank[p]=bank[p],bank[r];tags[r],tags[p]=tags[p],tags[r]
  elif op=='CLEAR':
   cut=result['forward_lifetimes']['first_dirty_local_unspanned'];c=cut['certificate']
   need((t,r,args[0])==(38712,3551,2)==(cut['clock'],cut['bank'],cut['chart']),'first clear')
   need(tags[r]==2 and bank[r]==1,'retiring original x0')
   stock=[[i,hex(b)] for i,b in enumerate(bank) if i!=r and tags[i]==2 and b]
   need(stock==c['same_chart_nonzero_banks'] and len(stock)==4,'exact same-chart stock')
   owners=list(range(341))+list(range(342,680));functional=(1<<owners.index(0))|(1<<owners.index(627))
   need(functional==int(c['functional_hex'],16),'certificate owner mapping')
   need((functional&bank[r]).bit_count()%2==1,'witness target')
   need(all((functional&int(b,16)).bit_count()%2==0 for _,b in stock),'witness annihilation')
   found=True;break
  else:raise AssertionError('opcode '+op)
 need(found,'first clear missing')

def main():
 entries=inventory();source_authentication();independent_forward_cut()
 # Rebuild in a fresh copy inside the owned folder. Output comparison is on
 # decompressed contents, so an alternative zlib version can still replay it.
 with TemporaryDirectory(prefix='verify-',dir=ROOT) as tmp:
  dest=Path(tmp)
  for name in entries:
   src=ROOT/name;dst=dest/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
  p=subprocess.run([sys.executable,'-I','-B','compile_control.py'],cwd=dest,capture_output=True,text=True)
  need(p.returncode==0,'clean compile failed: '+p.stderr)
  for name in ('CONTROL-WORD.json.gz','PRIVATE-LIFETIMES.json.gz','OWNER-CALL-TABLES.json.gz','INVOICE.json','RESULT.json'):
   need(read_json(dest/name)==read_json(ROOT/name),'rebuild differs: '+name)
  # The source input pin is an executable check, not just metadata.
  source=dest/'inputs/WORD.json.gz';b=bytearray(source.read_bytes());b[len(b)//2]^=1;source.write_bytes(b)
  bad=subprocess.run([sys.executable,'-I','-B','compile_control.py'],cwd=dest,capture_output=True,text=True)
  need(bad.returncode!=0 and 'input hash WORD.json.gz' in bad.stderr,'modified source accepted')
 print('PASS_INVENTORY_ARCHIVE_679_ROWS_TWO_ORIENTATIONS_CHARTS_BINDING_INVOICE_AND_FIRST_CLEAR_WITNESS')
if __name__=='__main__':main()
