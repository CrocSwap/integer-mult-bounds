#!/usr/bin/env python3
"""Compile the x341=x340, two-hole packet control; one process, stdlib only.

This emits a literal symbolic interpreter program, not a clean reversible
implementation. Source packet and helper identities are tracked separately
from the new address namespace. All masks use new public bit positions.
"""
import gzip, json, sys, time
from collections import Counter
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from hashlib import sha256
from pathlib import Path

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'inputs'))
import bit_native as bit
import literal

PINS={
 'WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'ZERO-CONTROL-WORD.json.gz':'f0aa75a63cc9200f627721851bd68c27367ae80e7fca2f0fe6f515fe2bfc9f63',
 'EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
 'AUDIT.json':'a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376'}

def require(x,message):
 if not x: raise AssertionError(message)
def read(name):
 data=(ROOT/'inputs'/name).read_bytes()
 require(sha256(data).hexdigest()==PINS[name],f'input hash {name}')
 return json.loads(gzip.decompress(data) if name.endswith('.gz') else data)
def canonical(x):return sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def save(name,obj):
 data=(json.dumps(obj,sort_keys=True,separators=(',',':'))+'\n').encode()
 if name.endswith('.gz'):
  with (ROOT/name).open('wb') as f:
   with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as z:z.write(data)
 else:(ROOT/name).write_bytes(data)
def sorted_hist(hist):return {str(k):hist[k] for k in sorted(hist) if hist[k]}
def bit_ids(x):return list(bit.indices(x))

def extract(w):
 """Independent opcode extractor with original public and packet labels."""
 n=w['public'];banks=[1<<i for i in range(n)]+[0]*w['owned_fields']
 moves={};rows={};clocks={}
 for t,ins in enumerate(w['program']):
  op,a,*q=ins
  if op=='ADD':banks[a]^=banks[q[0]]
  elif op=='SWAP':banks[a],banks[q[0]]=banks[q[0]],banks[a]
  elif op in ('INIT','CLEAR'):banks[a]=0
  elif op=='MOVE':
   k=n+len(moves);moves[k]=tuple(q);rows[k]=banks[a];clocks[k]=t;banks[a]=1<<k
  else:raise ValueError(op)
 for i in range(n):rows[~i]=banks[i]
 return moves,rows,clocks

def audit_tape(word,adjoint=False):
 """Instrument actual primitive lifetimes, data masks and terminal readouts."""
 n=word['public'];total=n+word['owned_fields'];steps=word['program']
 a=[1<<j if j<n else 0 for j in range(total)]
 chart=list(word['final'] if adjoint else word['start'])+[None]*word['owned_fields']
 active={};life=[];clockseq=range(len(steps)-1,-1,-1) if adjoint else range(len(steps))
 peak=0;paid=Counter();first_dirty_local_unspanned=None
 # Test same-chart XOR span with all current live banks, retaining exact witness
 # absence; adding such a donor changes only the soon-to-be-cleared field.
 def span_test(target,skip,at):
  piv={};stock=[]
  for address,value in enumerate(a):
   if address==skip or chart[address]!=at or value==0:continue
   stock.append((address,value))
   v=value; support=1<<address
   while v:
    b=v.bit_length()-1
    if b not in piv:piv[b]=(v,support);break
    old,which=piv[b];v^=old;support^=which
  v=target;support=0
  while v:
   b=v.bit_length()-1
   if b not in piv:
    # A constructive separating linear functional: it annihilates each
    # presently live stock row and takes value 1 on the retiring row.
    equations={p:(row,0) for p,(row,_) in piv.items()};equations[b]=(v,1)
    functional=0
    for p in sorted(equations):
     row,rhs=equations[p]
     if ((row&functional).bit_count()&1)^rhs:functional|=1<<p
    require((functional&target).bit_count()%2==1,'separating target')
    require(all((functional&row).bit_count()%2==0 for _,row in stock),'separating stock')
    return False,[],len(piv),b,{'functional_hex':hex(functional),
     'functional_positions':bit_ids(functional),
     'same_chart_nonzero_banks':[[address,hex(row)] for address,row in stock]}
   old,which=piv[b];v^=old;support^=which
  return True,bit_ids(support),len(piv),None,None
 for t in clockseq:
  op,r,*args=steps[t]
  if op in ('INIT','CLEAR'):
   opens=(op=='CLEAR') if adjoint else (op=='INIT')
   require(r>=n and str(args[0]) in word['frames'],f'lifetime address {t}')
   if opens:
    require(chart[r] is None and r not in active,f'double open {t}')
    chart[r]=args[0];active[r]={'bank':r,'open_clock':t,'open_chart':args[0],'last_touch_clock':t};peak=max(peak,len(active))
   else:
    require(chart[r]==args[0] and r in active,f'wrong close chart {t}')
    rec=active.pop(r);rec.update(close_clock=t,close_chart=args[0],dirty=bool(a[r]),retire_mask_hex=hex(a[r]))
    # Test the literal unchanged program; no earlier erasure is silently fixed.
    if a[r] and first_dirty_local_unspanned is None:
     can,donors,rank,missing,proof=span_test(a[r],r,args[0])
     if not can:
      first_dirty_local_unspanned={'clock':t,'bank':r,'chart':args[0],
       'retire_mask_hex':hex(a[r]),'new_public_positions':bit_ids(a[r]),
       'same_chart_rank':rank,'separating_pivot':missing,'certificate':proof,
       'explanation':'At this exact unchanged-program clock, other live same-chart fields do not span the retiring value; ADD and SWAP alone at this chart cannot clear it while preserving the other fields.'}
     elif len(life)<3:rec['local_xor_clear_donors']=donors
    life.append(rec);chart[r]=None
   a[r]=0
  elif op=='ADD':
   source,c=args;require(r!=source and chart[r]==chart[source]==c,f'ADD contact {t}')
   if adjoint:a[source]^=a[r]
   else:a[r]^=a[source]
   if r in active:active[r]['last_touch_clock']=t
   if source in active:active[source]['last_touch_clock']=t
  elif op=='SWAP':
   q=args[0];require(r!=q and chart[r] is not None and chart[q] is not None,f'SWAP {t}')
   a[r],a[q]=a[q],a[r];chart[r],chart[q]=chart[q],chart[r]
   if r in active:active[r]['last_touch_clock']=t
   if q in active:active[q]['last_touch_clock']=t
  else:
   require(op=='MOVE' and r>=n,f'opcode {t}')
   b,c=args[::-1] if adjoint else args
   require(chart[r]==b,f'MOVE chronology {t}')
   grade=abs(word['frames'][str(b)]['dim']-word['frames'][str(c)]['dim']);paid[grade]+=1;chart[r]=c
   if r in active:active[r]['last_touch_clock']=t
 require(not active and chart==list(word['start'] if adjoint else word['final'])+[None]*word['owned_fields'],'endpoint and lifetimes')
 require(not any(a[n:]),'private terminal banks reset')
 return a[:n],{'orientation':'adjoint' if adjoint else 'forward','peak':peak,
  'closed':len(life),'dirty':sum(x['dirty'] for x in life),'paid':sorted_hist(paid),
  'first_dirty_local_unspanned':first_dirty_local_unspanned},life

D=Decimal;LOW=Context(prec=90,rounding=ROUND_FLOOR);HIGH=Context(prec=90,rounding=ROUND_CEILING);NEAR=Context(prec=90)
def bounds(g,r):
 if g==1:return D(1),D(1)
 ln=NEAR.ln(D(g));t=LOW.subtract(D(1),r);require(t==HIGH.subtract(D(1),r),'rate rounding')
 return NEAR.next_minus(NEAR.exp(LOW.multiply(t,NEAR.next_minus(ln)))),NEAR.next_plus(NEAR.exp(HIGH.multiply(t,NEAR.next_plus(ln))))
def price(target,paid,r):
 vals=[]
 for hist in (target,paid):
  lo=hi=D(0)
  for k,v in hist.items():
   if v==0:continue
   a,b=bounds(int(k),r);lo=LOW.add(lo,LOW.multiply(a,v));hi=HIGH.add(hi,HIGH.multiply(b,v))
  vals.append((lo,hi))
 return str(LOW.subtract(vals[0][0],vals[1][1])),str(HIGH.subtract(vals[0][1],vals[1][0]))

def main():
 starttime=time.process_time();old=read('WORD.json.gz');other=read('ZERO-CONTROL-WORD.json.gz')
 caller=read('EFREE-CALLER.json.gz');published_bit=read('BIT.json');rat=read('AUDIT.json')
 require(canonical(old)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','old canonical')
 require(canonical(other)=='09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be','7912 canonical')
 require(old['start'][340]==old['start'][341],'alias inputs physically cocharted')
 moves,rows,old_clock=extract(old)
 initial=dict(enumerate(old['start']));final=dict(enumerate(old['final']))
 im,jm,om,orr,oc=bit.extract(old)
 require((initial,final,moves,rows,old_clock)==(im,jm,om,orr,oc),'independent original packet extraction')
 require({k:(old_clock[k],moves[k]) for k in (968,971,1564)}=={968:(1025,(0,53)),971:(1036,(53,178)),1564:(3175,(177,374))},'pinned routes')
 owners=[i for i in range(680) if i!=341];alive={k:v for k,v in moves.items() if k not in (968,1564)}
 init={k:v for k,v in initial.items() if k!=341};fin={k:v for k,v in final.items() if k!=341}
 def transform(mask):
  if mask>>341&1:mask ^= (1<<341)|(1<<340)
  return mask&~((1<<968)|(1<<1564))
 newrows={k:transform(rows[k]) for k in alive}
 newrows.update({~k:transform(rows[~k]) for k in owners})
 order=bit.schedule(init,fin,alive,newrows)
 require(order==[k for k in sorted(moves) if k not in (968,1564)],'source chronology preserved')
 cols=bit.basis(init,alive,newrows,order)
 values={i:1<<i for i in owners}
 for k in order:values[k]=bit.combine(newrows[k],values)
 require(values[3553]==1<<411,'protected packet 3553 remains x411')
 candidate=bit.emit_word(old,init,fin,alive,newrows,order)
 cand_hash=canonical(candidate);require(cand_hash!=canonical(other),'not 7912')
 c_moves,c_rows,c_clocks=extract(candidate)
 require(len(alive)==2872 and len(owners)==679,'candidate counts')
 require(all(c_moves[679+i]==moves[k] for i,k in enumerate(order)),'paid route identity')
 charts=literal.Charts(candidate['frames']);charts.main_contacts(candidate['start'],candidate['final'])
 forward,f,l1=audit_tape(candidate);adjoint,a,l2=audit_tape(candidate,True)
 expectf=literal.expected_rows(679,False);expecta=literal.expected_rows(679,True)
 require(forward==expectf and adjoint==expecta,'all 679 arbitrary inputs and outputs in both orientations')
 f2,lf,_=literal.tape(candidate,charts);a2,la,_=literal.tape(candidate,charts,adjoint=True)
 require(f2==forward and a2==adjoint and lf['erase_dirty']==f['dirty'] and la['erase_dirty']==a['dirty'],'independent primitive replay')
 require(f['paid']==a['paid'],'both native orientations pay the same grades')
 def omit_rejected(clock,adjoint):
  try:literal.tape(candidate,charts,adjoint=adjoint,omit=clock)
  except ValueError:return True
  raise AssertionError('missing private close was accepted')
 retirement_omission_controls={'forward_first_clear_rejected':omit_rejected(f['first_dirty_local_unspanned']['clock'],False),
  'adjoint_selected_init_rejected':omit_rejected(a['first_dirty_local_unspanned']['clock'],True)}
 base_charts=literal.Charts(old['frames']);base_charts.main_contacts(old['start'],old['final'])
 bo,bi,_=literal.tape(old,base_charts);require(bo==literal.expected_rows(680,False),'baseline forward')
 nt=Counter(charts.leg(x,y) for x,y in zip(candidate['start'][222:],candidate['final'][222:]))
 bt=Counter(base_charts.leg(x,y) for x,y in zip(old['start'][222:],old['final'][222:]))
 paid,target,*_=literal.paired_invoice(caller,lf['paid'],nt,Counter(e[0] for e in caller['events']))
 basepaid,basetarget,*_=literal.paired_invoice(caller,bi['paid'],bt,Counter(e[0] for e in caller['events']))
 require(dict(basepaid)=={int(k):v for k,v in published_bit['native']['paid'].items()},'pinned paired paid')
 require(dict(basetarget)=={int(k):v for k,v in published_bit['native']['targets'].items()},'pinned paired targets')
 def hdiff(x,y):return {k:x.get(k,0)-y.get(k,0) for k in sorted(x.keys()|y.keys())}
 dp=hdiff(paid,basepaid);dt=hdiff(target,basetarget)
 require({k:v for k,v in dp.items() if v}=={1:-36,4:-36},'two omissions per each of 36 actual calls')
 require({k:v for k,v in dt.items() if v}=={6:-36},'owner341 opportunity cost per call')
 grades=sorted(paid.keys()|target.keys()|basepaid.keys()|basetarget.keys())
 bins=[{'grade':k,'baseline_paid':basepaid[k],'baseline_targets':basetarget[k],
        'control_paid':paid[k],'control_targets':target[k],
        'delta_paid':dp.get(k,0),'delta_targets':dt.get(k,0),
        'baseline_signed':basetarget[k]-basepaid[k],
        'control_signed':target[k]-paid[k],
        'delta_signed':dt.get(k,0)-dp.get(k,0)} for k in grades]
 prices={}
 for r in ('0.003879928046156','0.003879929046155'):
  x=D(r);p0=price(basetarget,basepaid,x);p1=price(target,paid,x)
  h1=bounds(1,x);h4=bounds(4,x);h6=bounds(6,x)
  gainlo=LOW.multiply(D(36),LOW.subtract(LOW.add(h1[0],h4[0]),h6[1]))
  gainhi=HIGH.multiply(D(36),HIGH.subtract(HIGH.add(h1[1],h4[1]),h6[0]))
  prices[r]={'baseline_bit_margin':p0,'control_symbolic_margin_before_erasure_and_other_costs':p1,
             'delta_with_owner341_target_removed':[str(gainlo),str(gainhi)],
             'baseline_rational_margin':price(Counter({int(k):v for k,v in rat['signed']['productive'].items()}),Counter({int(k):v for k,v in rat['signed']['paid'].items()}),x)}
 # New local addresses identify their original helper and paid source label;
 # caller clock qualifies every use of these identities.
 helpers=[]
 for j in range(222,679):
  r=owners[j];s,e=candidate['start'][j],candidate['final'][j]
  helpers.append([j,r,s,e,charts.leg(s,e)])
 packets=[]
 for j,k in enumerate(order):
  p=679+j;t=c_clocks[p];op,bank,s,e=candidate['program'][t]
  require(op=='MOVE' and bank==p,'new literal address')
  packets.append([t,bank,k,old_clock[k],s,e,charts.leg(s,e)])
 bridge=next(p for p in packets if p[2]==3553)
 owner411=next(h for h in helpers if h[1]==411)
 # Explicitly bind every lifetime to a native purpose and originating owner.
 bank_identity={679+i:{'kind':'paid_scratch','source_packet':k} for i,k in enumerate(order)}
 base=679+len(order)
 for j,r in enumerate(owners):bank_identity[base+j]={'kind':'output_scratch','source_public_owner':r}
 require(len(bank_identity)==candidate['owned_fields'],'every private bank bound')
 for i in (l1,l2):
  for row in i:row.update(bank_identity[row['bank']])
  require(len({row['bank'] for row in i})==candidate['owned_fields'],'unique lifetime')
 for s in (f,a):
  x=s['first_dirty_local_unspanned']
  if x:
   x.update(bank_identity[x['bank']]);x['original_public_owner_support']=[owners[j] for j in x['new_public_positions']]
   x['certificate']['functional_original_owners']=[owners[j] for j in x['certificate']['functional_positions']]
 binding={'forward_lifetime_sha256':canonical(l1),'adjoint_lifetime_sha256':canonical(l2),
          'private_bank_count':len(bank_identity),'forward_dirty':f['dirty'],'adjoint_dirty':a['dirty']}
 tables=[{'candidate':cand_hash,'caller_clock':t,'caller_event':event,'helper':helpers,
          'paid':packets,'erasure_binding':binding}
         for t,event in enumerate(caller['events']) if event[0]=='LOCAL']
 require(len(tables)==36 and all(len(t['helper'])==457 and len(t['paid'])==2872 for t in tables),'complete 36 caller bindings')
 # This bounded binder compares exact identity, call and lifetime tables. It
 # does not claim a physical erasure provider or certify an external consumer.
 def bind(got,expected):
  for key in ('candidate','caller_clock','caller_event','helper','paid','erasure_binding'):
   require(got[key]==expected[key],'binding '+key)
  require(len({r[0] for r in got['helper']})==len(got['helper']),'binding helper duplicate')
  require(len({r[1] for r in got['paid']})==len(got['paid']),'binding paid duplicate')
 def rejects(got,expected,key):
  try:bind(got,expected)
  except AssertionError as ex:require(str(ex)=='binding '+key,'unexpected negative control');return True
  raise AssertionError('malformed binding accepted: '+key)
 for t in tables:bind(t,t)
 t=tables[0];bad=dict(t);bad['candidate']=canonical(other)
 wrong_namespace=rejects(bad,t,'candidate')
 bad=dict(t);bad['caller_clock']=t['caller_clock']+1
 wrong_call=rejects(bad,t,'caller_clock')
 bad=dict(t);bad['erasure_binding']=dict(binding,forward_lifetime_sha256='0'*64)
 wrong_lifetime=rejects(bad,t,'erasure_binding')
 # The #7912 word has owner 341 at address 341; this control's address 341
 # names owner 342. Even a forged candidate hash must not pass the binder.
 bad=dict(t);bad['helper']=[r.copy() for r in helpers];row=bad['helper'][341-222]
 require(row[0:2]==[341,342],'control address/owner mapping')
 row[1]=341;row[2:]=[other['start'][341],other['final'][341],charts.leg(other['start'][341],other['final'][341])]
 forged_7912_owner=rejects(bad,t,'helper')
 pair=next((i,j) for i in range(len(helpers)) for j in range(i+1,len(helpers)) if helpers[i][-1]==helpers[j][-1])
 bad=dict(t);bad['helper']=[r.copy() for r in helpers];i,j=pair
 bad['helper'][i][1],bad['helper'][j][1]=bad['helper'][j][1],bad['helper'][i][1]
 swapped_same_grade_owner=rejects(bad,t,'helper')
 pair=next((i,j) for i in range(len(packets)) for j in range(i+1,len(packets)) if packets[i][-1]==packets[j][-1])
 bad=dict(t);bad['paid']=[r.copy() for r in packets];i,j=pair
 bad['paid'][i][2],bad['paid'][j][2]=bad['paid'][j][2],bad['paid'][i][2]
 swapped_same_grade_packet=rejects(bad,t,'paid')
 negative_controls={'wrong_word_namespace':wrong_namespace,'wrong_call_clock':wrong_call,
  'wrong_lifetime_digest':wrong_lifetime,'forged_7912_owner_mapping':forged_7912_owner,
  'swapped_equal_grade_owners':swapped_same_grade_owner,'swapped_equal_grade_packets':swapped_same_grade_packet}
 save('CONTROL-WORD.json.gz',candidate)
 save('OWNER-CALL-TABLES.json.gz',tables)
 save('PRIVATE-LIFETIMES.json.gz',{'candidate':cand_hash,'owners':owners,'forward':l1,'adjoint':l2,'binding':binding})
 save('INVOICE.json',{'semantics':'full 36 caller paid/targets bins, moment=targets-paid; no cost of physically realizing dirty retirement is included','bins':bins,'prices':prices})
 save('RESULT.json',{'status':'symbolic control only; not cleanly erased','source_prs':{'7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','7912':'83ece5a62d3addbee45bad9594ef4809851b833b'},
  'source_word_canonical':canonical(old),'different_7912_canonical':canonical(other),'control_canonical':cand_hash,
  'scope':{'relation':'x341=x340','surrendered_owner':341,'omitted_original_packets':[968,1564],
           'retained_original_packets':[971,3553],'source_clock_order_preserved':True,'surviving_original_owners':len(owners),
           'programs':'literal destructive INIT/CLEAR interpreter; physical zero retirement is not established'},
  'packets':len(order),'start_terminal_chart_and_rows':'PASS all exact 679 arbitrary-input rows and transpose; source and destination chart at every instruction',
  'protected_original_owner411':owner411,'protected_original_packet3553':bridge,
  'forward_lifetimes':f,'adjoint_lifetimes':a,'native_paid':sorted_hist(lf['paid']),
  'owner_and_erasure_binding':binding,'binding_negative_controls':negative_controls,
  'retirement_omission_controls':retirement_omission_controls,
  'native_targets':sorted_hist(nt),'full_36_call_bins':'INVOICE.json',
  'erasure_status':'dirty CLEAR/INIT operations discard data in symbolic interpreter; no owned-erasure provider constructed'})
 print(json.dumps({'candidate':cand_hash,'forward':f,'adjoint':a,'native_paid':sorted_hist(lf['paid']),'native_targets':sorted_hist(nt),'prices':prices,'cpu_seconds':round(time.process_time()-starttime,3)},indent=2))
if __name__=='__main__':main()
