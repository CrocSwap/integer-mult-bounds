#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Prove two cocharted quotient bounds and rebuild a noncoordinate literal."""
from collections import Counter, defaultdict
from hashlib import sha256
import gzip
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'source'/'vendor'))
sys.path.insert(0, str(ROOT/'source'))
import binary_operator as binary
import bit_native
import common

def check(condition, message):
    if not condition:
        raise ValueError(message)

def bits(value):
    while value:
        first = value & -value
        yield first.bit_length()-1
        value ^= first

class Basis:
    def __init__(self):
        self.pivots = {}
        self.support = 0

    def lookup(self, row):
        if row & ~self.support:
            return None
        coord = 0
        while row:
            previous = self.pivots.get(row.bit_length())
            if previous is None:
                return None
            row ^= previous[0]
            coord ^= previous[1]
        return coord

    def add(self, row, coord=0):
        self.support |= row
        while row:
            pivot = row.bit_length()
            previous = self.pivots.get(pivot)
            if previous is None:
                self.pivots[pivot] = (row,coord)
                return True
            row ^= previous[0]
            coord ^= previous[1]
        return False

def members(rows):
    span = [0]
    for row in rows:
        span += [x ^ row for x in span]
    return span[1:]

def inside(source, rows):
    # Kernel of the projection of the independent bank stock onto all other
    # source charts. The auxiliary coordinate is the original 680-input row.
    outside = Basis()
    result = []
    for _, vector in rows:
        remainder = vector & ~source
        duplicate = outside.lookup(remainder)
        if duplicate is None:
            outside.add(remainder, vector)
        else:
            v = duplicate ^ vector
            check(v and not v & ~source, 'nonzero restricted receiver vector')
            result.append(v)
    return result

def derived(word,atlas,rates,reverse):
    start = word['final' if reverse else 'start']
    end = word['start' if reverse else 'final']
    tape = binary.run_tape(word,atlas,reverse)
    check(tape.output == binary.expected_operator(reverse),'original full operator')
    helpers = {i for i in range(222,word['public']) if i != 411}
    mutable = sum(1<<i for i in helpers)
    by_chart = defaultdict(int)
    grades = {i:atlas.grade(start[i],end[i]) for i in helpers}
    for i,c in enumerate(start):
        if i != 411:
            by_chart[c] |= 1<<i
    eligible = []
    row_bases = defaultdict(Basis)
    equal = Counter()
    for p,packet in tape.packets.items():
        if p == 3553:
            continue
        x = packet.arrival.row
        check(not x & (1<<411), 'protected 411 isolated from other packets')
        pieces = [(c,x&mask) for c,mask in by_chart.items() if x & mask]
        if any(not v & mutable for c,v in pieces):
            continue
        check(len(pieces) == 1,'eligible ones all occupy a single initial chart')
        chart,_ = pieces[0]
        check(row_bases[chart].add(x), 'linearly independent potentially surrendered rows')
        for h in bits(x & mutable):
            check(grades[h] >= packet.grade, 'every available pivot covers the paid price')
            if grades[h] == packet.grade:
                equal[packet.grade] += 1
        eligible.append(p)

    banks = {}
    stocks = {c:[(entry.label,entry.row) for entry in entries] for c,entries in tape.stock.items()}
    for c,stock in stocks.items():
        vec = Basis()
        for p,v in stock:
            check(vec.add(v,1<<p),'full unmodified chart stock independent')
        banks[c] = vec
    small = set()
    large = []
    ranks = Counter()
    for a,source in by_chart.items():
        if not source & mutable:
            continue
        for b,stock in stocks.items():
            if a == b:
                # All source fields at a belong to this bank before any arrival.
                # There is no paid coordinate in their unique representations.
                continue
            basis = inside(source,stock)
            if not any(v & mutable for v in basis):
                continue
            degree = len(basis)
            ranks[degree] += 1
            if degree <= 5:
                small.update(members(basis))
            else:
                support = 0
                for v in basis:
                    support |= v
                ports = sorted(bits(support))
                check(degree == len(ports) == 389 and all(grades.get(i)==8 for i in ports),
                      'large intersection consists precisely of 389 independent grade-eight helpers')
                highest = max((tape.packets[p].grade for p,_ in stock if p in tape.packets and p!=3553), default=0)
                check(highest==4,'maximum individual receipt grade in the large bank')
                large.append(dict(origin=a,receiver=b,dimension=degree,pivot_grade=8,grant_cap=highest))
    check(len(large)==1,'only one unenumerated bank direction family')
    candidates = sorted(r for r in small if r & mutable)
    counts, grades_by_tariff = Counter(), {}
    for relation in candidates:
        debit = min(grades[h] for h in bits(relation & mutable))
        credit = Counter()
        for bank in banks.values():
            coeff = bank.lookup(relation)
            if coeff is None:
                continue
            best = max((tape.packets[p].grade for p in bits(coeff) if p in tape.packets and p!=3553),default=0)
            if best:
                credit[best] += 1
        signature = tuple(sorted(credit.elements())),debit
        counts[signature] += 1
    for (saved,debit),num in sorted(counts.items()):
        signed = Counter(saved)
        signed[debit] -= 1
        credit = {g:n for g,n in signed.items() if n>0}
        cost = {g:-n for g,n in signed.items() if n<0}
        key=','.join(map(str,saved))+' minus '+str(debit)
        results = {}
        for rate in rates:
            gain = common.scale(common.moment(cost,credit,rate),36)
            check(gain[1]<=0,'outward tariff after exact cancellation for '+key)
            results[str(rate)] = common.display(gain)
        grades_by_tariff[key] = dict(relations=num,changes=results)
    return dict(potentially_zero_original_packets=len(eligible),
                source_charts_of_eligible_packets=len(row_bases),matched_tie_edges=dict(equal),
                raw_intersection_dimension_histogram=dict(ranks),small_distinct_vectors=len(small),
                small_vectors_with_optional_pivot=len(candidates),large=large,per_tariff=grades_by_tariff)

def neutral_word(word,atlas,rates):
    # Non-coordinate specialization on three inputs at chart zero. Every
    # coefficient is read from the primitive word before modifying its graph.
    init,final,moves,rows,clocks = bit_native.extract(word)
    pivot = 662
    relation = (1<<645)|(1<<662)|(1<<663)
    check(init[645]==init[662]==init[663], 'one source chart for the public substitution')
    tape = binary.run_tape(word,atlas,False)
    removed = [p for p,visit in tape.packets.items() if visit.arrival.row==relation]
    check(len(removed)==1,'one vanishing triple-input paid payload')
    packet,=removed
    check(atlas.grade(init[pivot],final[pivot])==tape.packets[packet].grade==4, 'tied productive/paid price')
    del init[pivot],final[pivot],moves[packet]
    restricted = {p:((v^relation) if v&(1<<pivot) else v)&~(1<<packet)
                  for p,v in rows.items() if p not in (packet,~pivot)}
    order = bit_native.schedule(init,final,moves,restricted)
    bit_native.basis(init,moves,restricted,order)
    result = bit_native.emit_word(word,init,final,moves,restricted,order)
    asc,desc = [binary.run_tape(result,atlas,r) for r in (False,True)]
    for rev,ta in enumerate((asc,desc)):
        check(ta.output==binary.expected_operator(rev)[:-1], 'all retained literal public components')
        bridge_bit=1<<411
        check(sum(bool(p.arrival.row & bridge_bit) for p in ta.packets.values())==1,
              'bridge column in only the protected paid packet')
    omit=next(i for i,e in enumerate(result['program']) if e[0]=='ADD' and e[2]==411)
    check(all(binary.run_tape(result,atlas,rev,omit=omit).output!=binary.expected_operator(rev)[:-1]
              for rev in (False,True)), 'held-out live ADD damages both operators')
    rejected=False
    try:binary.run_tape(result,atlas,False,omit=asc.last_retirement)
    except ValueError as exc:
        check(str(exc)=='unretired private field','lifetime control');rejected=True
    check(rejected,'omitted retirement accepted')
    word0,caller,_,np,nt,paid,targets,rat = common.baseline()
    newnative=Counter(p.grade for p in asc.packets.values())
    newtargets=Counter(atlas.grade(a,b) for a,b in zip(result['start'][222:],result['final'][222:]))
    check(newnative == +(Counter(np)-Counter({4:1})) and newtargets == +(Counter(nt)-Counter({4:1})), 'paid/productive native price changes')
    events=Counter(e[0] for e in caller['events'])
    newp,newt=common.literal.paired_invoice(caller,newnative,newtargets,events)
    ratp={int(g):n for g,n in rat['signed']['paid'].items()}
    ratt={int(g):n for g,n in rat['signed']['productive'].items()}
    prices={str(k):dict(complete_binary=common.display(common.moment(newp,newt,k)),
                        rational=common.display(common.moment(ratp,ratt,k))) for k in rates}
    return result,dict(relation=list(bits(relation)),surrendered_original=pivot,vanished_original_packet=packet,
                       public=679,owned=result['owned_fields'],dirty=[asc.dirty,desc.dirty],native_paid=newnative,
                       native_productive=newtargets,word_canonical=binary.canonical_hash(result),paid=newp,productive=newt,
                       executable_controls=['source ADD omitted','final private retirement omitted'],prices=prices)

def main():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--write',action='store_true')
    a=ap.parse_args()
    for src in json.loads((ROOT/'SOURCES.json').read_bytes())['files']:
        check(sha256((ROOT/src['local']).read_bytes()).hexdigest()==src['sha256'],src['local'])
    rates=(common.D('0.00388'),common.D('0.0038800000000000083'))
    word = binary.load_json(ROOT/'source/inputs/WORD.json.gz',binary.WORD_GZIP,True)
    atlas = binary.Atlas(word['frames'])
    reports = [derived(word,atlas,rates,q) for q in (False,True)]
    changed,ctl = neutral_word(word,atlas,rates)
    outcome=dict(source=binary.WORD,rates=list(map(str,rates)),directions=reports,neutral=ctl)
    serialized=json.dumps(outcome,indent=2,sort_keys=True)+'\n'
    packed=gzip.compress(json.dumps(changed,sort_keys=True,separators=(',',':')).encode(),mtime=0)
    packed=packed[:9]+bytes([3])+packed[10:]
    if a.write:
        (ROOT/'RESULT.json').write_text(serialized)
        (ROOT/'NEUTRAL-WORD.json.gz').write_bytes(packed)
    else:
        check((ROOT/'RESULT.json').read_text()==serialized,'recomputed complete proof receipt')
        check((ROOT/'NEUTRAL-WORD.json.gz').read_bytes()==packed,'recomputed primitive word')
    print('PASS',[(r['potentially_zero_original_packets'],r['small_distinct_vectors']) for r in reports],ctl['word_canonical'])
if __name__=='__main__': main()
