#!/usr/bin/env python3
"""Replay R6/02 funded literal word using the independent R5 BIT engine."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import importlib.util,gzip,json
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('round5_bit',P/'finite-451'/'replay_bit.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def source(name,pin):
 raw=(P/'inputs'/name).read_bytes();assert sha256(raw).hexdigest()==pin
 return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)
old=source('WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9')
new=source('FUNDED-WORD.json.gz','a823965c2cad60592e0823af23b01cd52811df4e4c4e2e0263758fae152961c5')
caller=source('EFREE-CALLER.json.gz','757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b')
rat=source('R5-RATIONAL-REPLAY.json','2e2ebe8f6f54c6e42c5b79985e6847c96d9085d3c63d3a8af94af081a37a566c')
assert b.canon(new)=='7006953f8d45f310f88825afa5254ea3cc6c46f7848cd229bb4b9e860198bfca'
assert new['public']==680 and new['owned_fields']==3555 and len(new['program'])==42968
result={};invoices={}
for label,w in [('original',old),('funded',new)]:
 f=b.frames(w);fw=b.tape(w,f);ad=b.tape(w,f,True)
 paid,target,calls,paid_native,helpers=b.invoice(w,f,caller)
 assert fw['paid']==ad['paid']==paid_native and len(calls)==36
 result[label]={'native_forward_dirty':fw['dirty_retirements'],'native_adjoint_dirty':ad['dirty_retirements'],
   'paid_native':dict(sorted(paid_native.items())),'productive_native':dict(sorted(helpers.items())),
   'paid_36_call':dict(sorted(paid.items())),'productive_36_call':dict(sorted(target.items())),
   'call_clocks':[x[0] for x in calls]}
 invoices[label]=(paid,target)
assert result['funded']['native_forward_dirty']==result['funded']['native_adjoint_dirty']==3555
p0,t0=invoices['original'];p1,t1=invoices['funded'];dp=p1.copy();dp.subtract(p0);dt=t1.copy();dt.subtract(t0)
assert {k:v for k,v in dp.items() if v}=={1:36,4:-36,5:36}
assert not any(dt.values()) and result['original']['call_clocks']==result['funded']['call_clocks']
# Specific producer changes are located by full primitive instruction identity;
# each mutation must independently fail the full arbitrary-input row check in
# both orientations in the independent R5 literal engine.
mutations={}
for name,event in [('missing_138_repair',['ADD',3692,4234,552]),('missing_sink_xor',['ADD',3295,2562,1])]:
 assert new['program'].count(event)==1
 clock=new['program'].index(event);f=b.frames(new);rejected=[]
 for reverse in (False,True):
  try:b.tape(new,f,reverse,omit=clock)
  except ValueError as ex:assert str(ex)=='all arbitrary public coefficients';rejected.append(True)
  else:raise AssertionError('damaged word accepted')
 mutations[name]={'clock':clock,'forward_and_adjoint_rejected':all(rejected)}
assert rat['actual_caller']['calls']==48
rp=Counter({int(k):v for k,v in rat['complete_paid'].items()});rt=Counter({int(k):v for k,v in rat['complete_productive'].items()})
rates={}
for k in ['0.003879928046156','0.003879929046155']:
 bm=[str(x) for x in b.margin(t1,p1,k)];rm=[str(x) for x in b.margin(rt,rp,k)]
 assert b.D(bm[1])<0 and b.D(rm[0])>0
 assert max(b.D(rm[0]),b.D(rat['directed_margins'][k][0]))<=min(b.D(rm[1]),b.D(rat['directed_margins'][k][1]))
 rates[k]={'bit':bm,'rational':rm}
print(json.dumps({'status':'PASS_INDEPENDENT_R6_FUNDED_NEGATIVE_CONTROL','canonical_word':b.canon(new),
 'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','paired_calls':36,
 'native':result,'signed_paid_delta':{str(k):v for k,v in sorted(dp.items()) if v},
 'signed_productive_delta':{},'mutations':mutations,'trials':rates,
 'scope':'Distinct pre-existing R5 literal engine rechecks both native arbitrary-input orientations, chart contacts and the complete original paired caller bins. Rational prices are recomputed from the pinned R5 48-call receipt, not its underlying word in this run. Literal private CLEAR remains destructive; no physical erasure, changed-word finite compiler/cover/stock/precision/analytic recovery or kappa conclusion is proved.'},indent=2,sort_keys=True))
