#!/usr/bin/env python3
"""Independent integer-vector replay of 33 reduced matrix certificates.

Every stored equation means sum of named p_e minus sum of named E_r is zero.
Tests both orientations before admitting a full p=E_r consequence. No SymPy,
producer checker, or event enumeration is imported.
"""
from pathlib import Path
from itertools import combinations
from fractions import Fraction
from hashlib import sha256
import copy,json
P=Path(__file__).resolve().parent
raw=(P/'REVISED-STRENGTHEN.json').read_bytes();scanraw=(P/'SCAN.json').read_bytes()
assert sha256(raw).hexdigest()=='7e8141bdf7269c99a753e752a44868518140cb2d356a14c591c04a2349ed3321'
assert sha256(scanraw).hexdigest()=='75cc15d129618a92653041cf97396c68d58820ed2e5757c71e12d2e4eea062a0'
x=json.loads(raw);scan=json.loads(scanraw)

def cert(record):
 def req(p):
  if not p:raise ValueError('invalid certificate')
 ts=record['targets'];ev=record['events'];n=len(ev)
 req(len(ts)==3 and all(e>0 for e in ev))
 domains=[{r for r,t in enumerate(ts) if e&t==e} for e in ev]
 req(all(domains))
 equations=[]
 for item in record['equations']:
  kind=item['kind'];ids=item['events'];rolebits=item['roles'];role={r for r in range(3) if rolebits>>r&1}
  req(0<rolebits<8 and len(set(ids))==len(ids) and all(0<=i<n for i in ids))
  def weighted(pairs):
   out=[0]*(n+3)
   for j,q in pairs:
    req(isinstance(j,int) and 0<=j<len(equations))
    val=Fraction(q);req(val.denominator==1);val=int(val)
    for i,co in enumerate(equations[j]):out[i]+=val*co
   return out
  if kind=='stage':
   s=item['stage'];req(0<=s<5)
   req(ids==[i for i,e in enumerate(ev) if e>>s&1])
   req(role=={r for r,t in enumerate(ts) if t>>s&1})
  elif kind=='clique':
   req(len(ids)==len(role) and all(domains[i]<=role for i in ids))
   req(all(ev[i]&ev[j] for i,j in combinations(ids,2)))
  elif kind=='rank_one':
   i=item['i'];r=item['r'];req(ids==[i] and role=={r} and r in domains[i])
   comps=item['components'];required={(r,r)}|{(a,r) for a in range(3) if a!=r}|{(r,a) for a in range(3) if a!=r}
   req(len(comps)==5 and {(c['a'],c['b']) for c in comps}==required)
   for c in comps:
    a,b=c['a'],c['b'];valid={j for j in range(n) if a in domains[j] and b in domains[j]}
    if c['mode']=='support_zero':req(i not in valid and a!=b)
    elif c['mode']=='combination':
     v=weighted(c['weights'])
     req(all(v[j]==int(j==i) for j in valid))
     if a==b:req(v[n+a]==-1)
    else:req(False)
  else:req(False)
  equations.append([int(j in ids) for j in range(n)]+[-int(r in role) for r in range(3)])
 clash=record['clash'];i=clash['i'];req(0<=i<n)
 v=[0]*(n+3)
 for j,q in clash['combo']:
  req(0<=j<len(equations));v0=Fraction(q);req(v0.denominator==1)
  for k,co in enumerate(equations[j]):v[k]+=int(v0)*co
 goal=[0]*(n+3);goal[i]=1
 if clash['kind']=='equal':
  j=clash['j'];req(0<=j<n and i!=j);goal[j]-=1
  if clash['conflict']=='shared_stage':req(bool(ev[i]&ev[j]))
  elif clash['conflict']=='disjoint_support':req(not domains[i]&domains[j])
  else:req(False)
 elif clash['kind']=='outside':
  r=clash['r'];req(0<=r<3 and r not in domains[i]);goal[n+r]=-1
 elif clash['kind']!='zero':req(False)
 req(v==goal)
 return True

def accepted(z):
 try:return cert(z)
 except (ValueError,KeyError,IndexError,TypeError,ZeroDivisionError):return False

records=x['records'];unresolved=[z for z in scan['necessary_case_orbits'] if 'saturation' in z and z['saturation'] is None]
key=lambda z:(tuple(z['targets']),tuple(z['events']))
assert len(records)==len(unresolved)==33 and {key(z) for z in records}=={key(z) for z in unresolved}
assert all(accepted(z) for z in records)
counts={t:sum(z['status']==t for z in records) for t in ('linear_saturation','linear_plus_rank_one')}
assert counts=={'linear_saturation':31,'linear_plus_rank_one':2}
mut=copy.deepcopy(next(z for z in records if z['status']=='linear_plus_rank_one'))
e=next(z for z in mut['equations'] if z['kind']=='rank_one');r=e['r']
e['components']=[c for c in e['components'] if not(c['a']==r and c['b']!=r)]
assert not accepted(mut)
print(json.dumps({'status':'PASS_INDEPENDENT_REVISED_33_CERTIFICATES',
 'counts':counts,'both_row_and_column_explicit':True,'all_weights_integer':True,
 'missing_row_mutation_rejected':True,'scan_sha256':sha256(scanraw).hexdigest(),
 'certificate_sha256':sha256(raw).hexdigest(),
 'scope':'Checks the 33 named certificate records and matches them to SCAN unresolved tuples; assumes stage-sum and saturated-clique lemmas and the scan case enumeration, which are not rerun here. Not a HOST, word-bridge, or kappa claim.'},indent=2,sort_keys=True))
