#!/usr/bin/env python3
"""One isolated #7830 rational compiler/audit replay with a 451 BIT adapter.

Uses the same pinned public consumer and auditor as the producer, but an
independent clean cache and output directory. Checks both result bytes, then
reconstructs rational orientations and independently prices all signed bins.
"""
from hashlib import sha256
from pathlib import Path
import json
import os
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source-7830/review'))
import independent as review

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def need(c,why):
    if not c:
        raise ValueError(why)

def main():
    work=HERE/'inputs'; out=HERE/'clean-replay-output'
    reference=HERE/'consumer-replay'
    bit=HERE/'BIT-451.json'
    need(not out.exists(),'clean output directory must not exist')
    payload=json.loads(bit.read_bytes())
    cap=payload['cover_and_stock']['ordinary_admitted']
    need(payload['status']=='PASS_FIXED_PROFILE_FINITE_BIT_SUPPLIER_REPLAY'
         and payload['source']['head']=='87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'
         and cap=='0.00387992804354799998', 'pinned completed BIT candidate')
    need(digest(HERE/'source-7830/review/independent.py')=='a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
         'independent review script pin')
    count=review.authenticate(work,False)
    need(count==(20,127),'authenticated independent inputs')
    print('Authenticated explicit and inherited inputs',count,flush=True)
    review.ORDINARY=cap
    out.mkdir()
    app,audit=review.replay_application(work,out)
    review.compare_fixed_application(work,app,audit)
    for file in ('APPLICATION.json','AUDIT.json'):
        need((out/file).read_bytes()==(reference/file).read_bytes(), f'{file}: byte-identical producer replay')
    print('PASS byte-identical compiler and expanded audit',flush=True)
    physical=review.rational_orientations(work,app)
    paid,targets,ordinary=review.native_rational(app)
    price=review.directed_invoice(paid,targets,review.RATIONAL_BRACKET,review.TARGET)
    published={'claim':app['application']['claim'],'sharp_outer':audit['outer']['outer_checks']}
    outer=review.rational_outer(app,audit,paid,targets,review.Q(cap),published)
    result={'status':'PASS_ISOLATED_CONSUMER_REPLAY_AND_BYTE_COMPARE',
            'scope':'Fresh replay of the same pinned compiler and separate expanded audit, plus independent exact graph orientations, caller rank invoice and outer arithmetic. Does not materialize the BIT tensor or re-prove its five inherited premises.',
            'construction_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
            'binary_ordinary':cap,'claim':app['application']['claim'],
            'source_counts':count,'binary_receipt_sha256':digest(bit),
            'reference_application_sha256':digest(reference/'APPLICATION.json'),
            'reference_audit_sha256':digest(reference/'AUDIT.json'),
            'clean_application_sha256':digest(out/'APPLICATION.json'),
            'clean_audit_sha256':digest(out/'AUDIT.json'),
            'application_and_audit_byte_equal':True,
            'rational_physical':physical,'rational_directed_crossing':price['raw_crossing'],
            'rational_endpoint_margins':price['endpoint_margins'],
            'outer':outer,'premises':app['premises']}
    (out/'INDEPENDENT.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(result['status'],'claim',result['claim'],flush=True)

if __name__=='__main__':
    main()
