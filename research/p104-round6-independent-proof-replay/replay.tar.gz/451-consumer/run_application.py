#!/usr/bin/env python3
"""Replay the pinned #7830 rational consumer with the 451-factor BIT cap.

The adapter consumes the separately checked BIT receipt; this does not itself
prove the inherited compiler, cover, or analytic-recovery premises.
"""
from fractions import Fraction as Q
from hashlib import sha256
import importlib.util, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
PKG=HERE/'source-7830'; WORK=HERE/'inputs'; OUT=HERE/'consumer-replay'
BIT=HERE/'BIT-451.json'

def need(cond,msg):
    if not cond: raise ValueError(msg)
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

def main():
    summarize = sys.argv[1:] == ['--summarize-existing']
    need(not sys.argv[1:] or summarize, 'usage: run_application.py [--summarize-existing]')
    need(summarize == OUT.exists(), 'existing receipts require --summarize-existing; otherwise use a clean output directory')
    data=json.loads(BIT.read_bytes())
    need(data['status']=='PASS_FIXED_PROFILE_FINITE_BIT_SUPPLIER_REPLAY' and
         data['source']['binary_word']=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d' and
         data['native']['native_calls']==36,'completed component receipt and word')
    cap=data['cover_and_stock']['ordinary_admitted']
    need(Q(cap)==Q('0.00387992804354799998'),'exact BIT ordinary cap')
    program=PKG/'review/independent.py'
    need(sha256(program.read_bytes()).hexdigest()=='a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
         'source review verifier pin')
    review=load('p7830_independent_review',program)
    count=review.authenticate(WORK,False)
    review.ORDINARY=cap
    print('Authenticated independent consumer source pins',count,flush=True)
    if summarize:
        app=json.loads((OUT/'APPLICATION.json').read_bytes())
        audit=json.loads((OUT/'AUDIT.json').read_bytes())
        need(audit['compiler_report_sha256']==sha256((OUT/'APPLICATION.json').read_bytes()).hexdigest(), 'audit binds application bytes')
        stub=json.loads((OUT/'adapter/binary/FINITE.json').read_bytes())
        need(Q(stub['ordinary_admitted'])==Q(cap) and stub['word_sha256']==review.BIT_WORD and stub['native_calls']==36, 'adapter binding')
    else:
        OUT.mkdir()
        app,audit=review.replay_application(WORK,OUT)
    review.compare_fixed_application(WORK,app,audit)
    claim=app['application']['claim']; tested=audit['outer']['finite_compiler']['tested']
    need(Q(claim)==Q('0.00387992804346') and Q(tested)==Q('0.00387992804353'),
         'expected grid claim and tested saving')
    need(Q(app['binary_ordinary'])==Q(cap)==Q(audit['outer']['pinned_binary_cap']),
         'consumer and independent audit bind the exact BIT cap')
    need(audit['outer']['outer_checks']['strict_count']==54 and
         audit['outer']['outer_checks']['functional_count']==4,'outer condition counts')
    report={'status':'PASS_COMPLETE_CONDITIONAL_CONSUMER_REPLAY',
      'scope':'Pinned 48-call rational consumer and separate audit, with BIT cap adapter. Does not materialize BIT tensor or prove the five inherited premises.',
      'bit_receipt_sha256':sha256(BIT.read_bytes()).hexdigest(),'binary_ordinary':cap,
      'claim':claim,'tested':tested,'bit_headroom':str(Q(cap)-Q(tested)),
      'rational_word':review.RATIONAL_WORD,'binary_word':review.BIT_WORD,
      'rational_calls':app['caller_census']['calls'],'source_files':count,
      'unchanged_native_and_caller_checks':'PASS',
      'outer_checks':audit['outer']['outer_checks'],'premises':app['premises']}
    (OUT/'CONSUMER.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(report['status'],claim,flush=True)

if __name__=='__main__':main()
