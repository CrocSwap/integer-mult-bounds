# Fixed cover prime, stock and outer-precision review for the 451-factor candidate

*Workstation paths in this copy are redacted or made package-relative; scientific assertions are unchanged.*

## Finding

No obstruction caused solely by the changed cover-prime lower bound was found. For the [451-factor component receipt](../BIT-451.json) and its inherited delayed-cover inequality, the cover surcharge has a strict rational margin. After a finite, prime-independent catalogue of every fixed nonzero denominator and witness is actually specified, a suitable odd prime exists with an explicit upper bound in terms of that catalogue. The potentially enormous prime and radix-padding factors are fixed before input length varies, so the published fixed-template asymptotic stock and precision *arguments* can be adapted with larger constants. The actual 451-factor catalogue, prime, uniform word, physical row stock, and complete outer composition have not been materialized or independently verified here. In particular, #7846's source-bound six-stage certificate is **not** itself a certificate for the new candidate.

The bounded 451-component input is `BIT-451.json` in the package root (SHA-256 `538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749` at this checkpoint). It pins [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, binary word `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`, and rational word `7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48`. The outer arguments inspected are [#7846](https://github.com/CrocSwap/integer-mult-bounds/pull/7846) at `343f7b1817e26ad3f89d2ddad313b12741d53602` and [#7849](https://github.com/CrocSwap/integer-mult-bounds/pull/7849) at `3615fd982f2f4dc7172bef6f0dc9a4f77d5ab6dd`. Both are submitted research results awaiting scientific review.

## Exact cover and ordinary margins

Put `H=1,202,400,000,000,000`, `N=2^H`, `d=10^-13`, uniform loss `e=1/400000000000`, and raw trial `C=0.003879928046148`. The candidate specifies odd prime `q>2^52 N^5` and cover loss d. The inherited complete surcharge `64 N^5/q` is strictly less than `2^-46=1/70368744177664`. Its budget is `d/4=1/40000000000000`, with exact positive difference

`926780523/85899345920000000000000` ≈ `1.0789145284798e-14`.

The weaker hypothesis `q>2^51 N^5` alone gives the upper bound `2^-45>d/4` and does not certify this particular budget. It does not exclude choosing a larger prime. Also `H d=3006/25=120.24`, so `floor(Hd)=120` and `2^floor(Hd) ≥ 1+d/2`. The source moment argument then has the strict factor at most

`(1+d/4)/(1+d/2) = 40000000000001/40000000000002 < 1`.

This calculation **uses** the [fresh-fibre and fallback inequality](https://github.com/aliromman/integer-mult-bounds/blob/343f7b1817e26ad3f89d2ddad313b12741d53602/research/mixed-rank-uniform-composition/ORDINARY.md) and the 451 finite strict-moment receipt; it does not independently prove either. In particular, real nonunit-pivot classes must follow the charged fallback, and ancestor weights must not depend on fresh child cover rows.

The covered rate is `C−e−d=0.003879928043548`. With `ρ=1/250`, a new cold stage from the elementary interchange can undercut `(1−ρ)(C−e−d)` and still reach the inherited seed `0.00385248` with exact slack `745520710863/62500000000000000` ≈ `0.000011928331373808`. Seven further strict stages in the component receipt reach `0.00387992804354799998`; the checked gaps are recorded in [prime-receipt.json](prime-receipt.json). Thus a newly rebuilt construction can use **eight** nontrivial stages including cold, with an elementary base, rather than the six source-bound stages in #7846. An alternative that reuses a previously completed seed has to charge the nested old stages it actually uses.

Relative to the *unchanged* #7830/#7846 rational trial `0.00387992803563`, the new ordinary rate has headroom `395899999/50000000000000000000` = `0.00000000000791799998`. Its headroom over the old published κ `0.00387992803556` is `0.00000000000798799998`. Those are rate inequalities, not a new rational application or a new κ claim. The old outer exponents and consumer invoice may only be reused after the candidate implements their required complete interfaces.

The productive floor `16^451` is attained, as required when instantiating the source compiler: choose 224 rank-4, two rank-8, and 225 rank-64 target occurrences. There are 451 factors and `2·224+3·2+6·225=4·451`. The component's unchanged histogram has positive counts at all three ranks. This is a floor witness, not a replay of all target labels.

At the same N, replacing exponent 45 by 52 would strengthen the lower bound by a factor 128. Here N itself decreases: the actual old and new lower cutoffs are `2^6,426,000,000,000,045` and `2^6,012,000,000,000,052`. The new **lower cutoff** is 413,999,999,999,993 exponent bits lower. The actual old and new chosen primes cannot be ordered without their distinct catalogue data.

## A usable-prime existence bound

Compile the complete 451-factor rational projectors, selected bases, matchers, their inverses, and the required nonzero rank/determinant/pivot witnesses independently of q. Let M≥2 be the largest absolute nonzero integer appearing as a reduced numerator or denominator in that finite exclusion list. Include every fixed witness required by the concrete implementation, not just the native source list. Set

`T=max(2^(5H+52), M, 2)`.

Bertrand's theorem supplies a prime `T<q<2T`. It is odd, exceeds the surcharge bound, and is larger than every nonzero exclusion integer, so it divides none. If `L=max(5H+52, ceil(log₂ M))`, then the binary bit length of this selected q is at most `L+1`. Trial division and a finite search also give an effective, if impractical, selection algorithm. If the catalogue happens to have M≤2^(5H+52), then this construction selects q with exactly `5H+53` bits. There is no justified numerical upper bound on the real q until M or another bound on the actual 451 catalogue is supplied.

The finite list concerns rational data frozen **before** q. Dynamic cover matrices and low-row pivot choices are not included in a purported pre-q list; q-dependent nonunit cases remain in the paid fallback. The toy exact control chooses q=`131101` above `T=131073` and detects a deliberately forbidden prime 17 for a witness divisible by 17. It is only a check of the construction's arithmetic shape.

#7846's varying fine primes are a separate issue from q: they select the input-dependent geometric axes in [ASSEMBLY.md](https://github.com/aliromman/integer-mult-bounds/blob/343f7b1817e26ad3f89d2ddad313b12741d53602/research/mixed-rank-uniform-composition/ASSEMBLY.md). The fixed cover prime is used for the opaque ordinary permutation. If an implementation additionally requires those axes to avoid this one fixed prime, removing one prime from the interval count is eventually harmless under the submitted count; no such extra coupling is established as necessary here. #7849's outer controller uses pairwise-coprime odd squares rather than a fine-prime search and likewise consumes the fixed complete BIT primitive; it does not make the BIT cover prime vary with input n.

## Stock, width and precision

For one ordinary stage, let B be its fixed productive width, let `w=ceil(E^(1/250))` for input width E in q-adic digits, and put

`W(w)=B |GL_N(F_q)| q^(N²(w−1))`, `D=2+ceil(log_N(max(1,ceil(E/w))))`.

Write `t_B=ceil(log_q B)`. Since `|GL_N(F_q)|≤q^(N²)`, the q-digit depth required to encode one `W(w)^D` row reserve obeys the exact bound

`k=ceil(log_q W(w)^D) ≤ D (t_B+N²w)`.

This is a statement about the reserve's address length, not a claim that all its physical rows have been constructed. Its binary descriptor bound is at most `k ceil(log₂q)` up to fixed delimiter/control overhead. Thus the larger allowed q can make a colossal fixed coefficient but not an input-dependent exponent. #7846's q-ary padding may cost a factor below q² for each full conversion; this is likewise fixed once q is fixed. Its fresh high fibres, complete spectators, restored loaned stock, and auxiliary work still have to be actually provided.

There is even an effective symbolic eventual threshold for **one** stage. Since `w≤2E^(1/250)` and `D≤3+log₂E`, set `A=t_B+2N²`. Then `k≤A(3+log₂E)E^(1/250)`. Let `L_A=ceil(log₂(2A))` and `J=max(8, floor(125 L_A/62)+1)`. For all `E≥2^J`, the elementary bound `3+x≤2^(x/2)` for x≥8 implies `2A(3+log₂E)<E^(249/250)` and hence `k<E/2`. This J is a sufficient symbolic bound in q-digit width; it is not a practical input-size cutoff. Eight fixed nested stages, with all radix conversions, previous-stage stock and the complex stock charged, require a larger fixed constant and threshold. The source's finite-stage `O_fixed(w log E)` induction is the relevant template, but its numerical constants and source-bound code must be refreshed for the new word.

The old complex numerical graph and its Clifford common-grid derivation are unchanged by a binary address permutation. Conditional on the new BIT stage implementing the **exact** complete opaque permutation and restoring its scratch, q-adic control arithmetic introduces no new floating or Gaussian rounding into those payloads. The original source's common-grid bound remains a dependency; additional q-dependent control/storage bits are fixed-template overhead, not free payload bits. The complete [#7846 frame argument](https://github.com/aliromman/integer-mult-bounds/blob/343f7b1817e26ad3f89d2ddad313b12741d53602/research/mixed-rank-uniform-composition/FRAMES.md) still has to be instantiated for the new word and finite stage depth.

In the #7846 and #7849 support-reservoir estimates, a bound of form `C_F[h^(1/250)(log p)^3 + log(h+1)+1]` has a new finite constant `C_F`, potentially huge. A threshold `h≥K_F(1+log p)^5` can still make it at most `h/16`: `5(1−1/250)=4.98>3`. Increase K_F to absorb `C_F` and the logarithmic term, and use the already specified elementary fallback below the new threshold. This preserves the asymptotic argument, not its old implicit numerical threshold. The fixed-q requirement is essential.

## Replay and remaining conditions

From the package root, run `python3 -B prime_scope_check.py` or `python3 -BO prime_scope_check.py`. The matching [normal](prime-receipt.json) and [optimized](prime-receipt-opt.json) outputs independently re-evaluate the rational cover and stage inequalities, the attained floor and 100 tiny one-stage stock instances. Original pre-redaction script SHA-256 `a47673ad76c7ad155a68dcff8fc8b7a38e505ca82adb2bf550793e44280508ba` (the path-adapted copies are listed in the package manifest); receipt SHA-256 `ce6e4027baa051f3c2a2698d7aa57c2180c79c0069296fbe43be8e322ac4274a`. The test reads the component receipt; it does not reproduce its directed moment engines or native graph replay.

To claim a full composition, produce and authenticate the 451-specific finite compiler catalogue and all rank/route witnesses, instantiate a fixed q and the charged fallback and fresh-cylinder schedule, carry actual stock and historical backing through the chosen number of stages, and rerun the complete rational consumer, scalar/common-grid and relevant outer invoices with their strict margins. For #7849 the exact supplied primitive endpoints and its independent outer precision/tape hypotheses also remain required. No new κ or independent human acceptance follows from this note. The base construction and outer proofs are credited to their respective source authors; the 451 component is from the concurrent BIT supplier task, and this note supplies a small independent arithmetic and resource review.
