#!/usr/bin/env python3
"""Directed v=451 component screen, using a separate locked interval engine.

Consumes our independently recounted full BIT bins, not the candidate's bins.
This verifies the stated arithmetic inequalities only; it does not verify the
fresh product implementation, delayed-cover proof, or rational application.
"""
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
EFILE = HERE / 'inputs/cache/source/research/paired-query-only-bit/retained/inputs/inputs/exact_arithmetic.py'
CANDIDATE = HERE / 'carrier_screen.json'
spec = importlib.util.spec_from_file_location('separate_fraction_interval', EFILE)
E = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = E
spec.loader.exec_module(E)

def need(c, message):
    if not c:
        raise ValueError(message)

def ceil(q):
    return -(-q.numerator // q.denominator)

def cap(q, places=22):
    return Q(ceil(q * 10**places), 10**places)

def main():
    data = json.loads((HERE / 'BASELINE.json').read_bytes())
    need(data['pins']['construction_head'] == '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15', 'pinned head')
    source = data['binary']
    p = {int(k): v for k, v in source['paid'].items()}
    t = {int(k): v for k, v in source['targets'].items()}
    need((sum(p.values()), sum(t.values()), sum(k*n for k,n in p.items())) ==
         (107460, 20706, 291360), 'all-call independently recounted inventory')

    c, u, w = Q('0.003879928046148'), Q(13, 50), Q(17, 50)
    e, d, theta, v = Q(1, 400_000_000_000), Q(1, 10**13), Q(13, 15), 451
    moment_t = E.moment(t, 1-c)
    alpha_i = E.divide(E.moment(p, 1-c), moment_t)
    gamma_i = E.divide(E.moment(p, 1-c+u), E.mul(E.power(11,u), moment_t))
    lam_i = E.divide(E.mul(E.power(16,w), E.moment(t,1-c-w)), moment_t)
    alpha, gamma, lam = (cap(x[1]) for x in (alpha_i, gamma_i, lam_i))
    need(all(0 < x < 1 for x in (alpha,gamma,lam)), 'three strict outward caps')

    def surplus(k):
        return 1 - 1/(1+k*(1-alpha)) - 2*gamma**k - lam**k
    slack = surplus(v)
    need(slack > 0, 'strict moment after all paid split and dropped-target charges')
    need(surplus(448) < 0, 'the same sufficient bound fails at 448')

    ambient = E.power(134,v*c)
    eta = E.divide((1-c, 1-c), ambient)
    need(theta**60 < eta[0] <= eta[1] <= theta**59, 'p=60 holds, p=59 fails')
    need(ambient[1] < 2**60 and 11**15 < 16**13 and 4*11**(15*v) <= 134**(13*v),
         'ambient and shifted-log inequalities')
    H, step, j = 1_202_400_000_000_000, e.denominator, 3006
    need(H == step*j and (H+1)**60 < 2**j and (H-step+1)**60 >= 2**(j-1),
         'carrier grid point and previous grid point')
    need((H+1)*e > 120 and Q(H, 1_285_200_000_000_000) < Q(95,100),
         'monotonicity condition and >5% reduction')
    need(Q(64,2**52) < d/4 and Q(64,2**51) > d/4 and 2**int(H*d) >= 1+d/2,
         'separate cover budget and q exponent control')

    covered, rho, prev = c-e-d, Q(1,250), Q('0.00385248')
    stages = []
    for _ in range(7):
        envelope = (1-rho)*covered + rho*prev
        ticks = (envelope*10**20).__floor__()-1
        new = Q(ticks,10**20)
        need(prev < new < envelope < covered and new < rho and new < 1-rho, 'strict stock stage')
        stages.append({'admitted':f'{ticks//10**20}.{ticks%10**20:020d}', 'gap':str(envelope-new)})
        prev = new
    need(prev == Q('0.00387992804354799998') and prev > Q('0.003879928035646'), 'ordinary cap')
    candidate = json.loads(CANDIDATE.read_bytes())
    row = next(z for z in candidate['feasible'] if z['v'] == v)
    need(row['H'] == H and row['log_power'] == 60 and Q(candidate['new_cap']) == prev,
         'candidate values match independent calculation')
    need([s['admitted'] for s in candidate['stages']] == [s['admitted'] for s in stages],
         'all seven stock stages match')
    out = {
        'status': 'PASS_BOUNDED_COMPONENT_ARITHMETIC',
        'scope': 'Independent interval and integer inequalities for fixed BIT invoice only; no full implementation or kappa claim.',
        'candidate_source_sha256': sha256(CANDIDATE.read_bytes()).hexdigest(),
        'independent_interval_source_sha256': sha256(EFILE.read_bytes()).hexdigest(),
        'baseline_sha256': sha256((HERE/'BASELINE.json').read_bytes()).hexdigest(),
        'construction_head': data['pins']['construction_head'], 'trial':str(c), 'factors':v,
        'ratios': {k:E.display(x) for k,x in [('alpha',alpha_i),('gamma',gamma_i),('lambda',lam_i)]},
        'upper_caps': {k:str(x) for k,x in [('alpha',alpha),('gamma',gamma),('lambda',lam)]},
        'normalized_surplus_lower':E.display((slack,slack)),
        'v448_same_sufficient_bound':E.display((surplus(448),surplus(448))),
        'ambient_power':E.display(ambient), 'eta':E.display(eta), 'p':60, 'H':H,
        'H_reduction':str(1-Q(H,1_285_200_000_000_000)),
        'controls':{'p59_fails':True,'previous_H_grid_fails':True,'q_exponent_51_fails_budget':True},
        'covered':str(covered),'seven_stages':stages,'ordinary_cap':str(prev),
    }
    (HERE/'replay').mkdir(exist_ok=True)
    (HERE/'replay/CARRIER-INDEPENDENT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(out['status'], 'surplus',out['normalized_surplus_lower'], 'ordinary_cap',out['ordinary_cap'])

if __name__ == '__main__':
    main()
