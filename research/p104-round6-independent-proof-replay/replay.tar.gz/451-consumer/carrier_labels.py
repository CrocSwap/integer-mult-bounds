#!/usr/bin/env python3
"""Re-enumerate physical paid labels and exercise uniform slab controls.

Finite rank/label screens only. The product construction and wrapper
correctness remain inherited; this is not an executable 451-factor word.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip
import json

HERE = Path(__file__).resolve().parent
WORD = HERE/'inputs/7786/research/p104-iterated-returns/binary/WORD.json.gz'
CALLER = HERE/'inputs/cache/source/research/paired-query-only-bit/EFREE-CALLER.json.gz'

def need(c, message):
    if not c:
        raise ValueError(message)

def check_labels(rows, expected):
    need(len(rows) == len(expected) and dict(rows) == expected, 'incomplete paid label inventory')

def rejects(f):
    try:
        f()
    except ValueError as err:
        need(str(err) == 'incomplete paid label inventory', 'wrong control')
        return True
    raise ValueError('bad label inventory accepted')

def main():
    wraw,craw = WORD.read_bytes(),CALLER.read_bytes()
    need(sha256(wraw).hexdigest() == 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9', 'word bytes')
    need(sha256(craw).hexdigest() == '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b', 'caller bytes')
    w,c = json.loads(gzip.decompress(wraw)),json.loads(gzip.decompress(craw))
    dims = {int(k):value['dim'] for k,value in w['frames'].items()}
    legs = [(i,row[1],abs(dims[row[2]]-dims[row[3]]))
            for i,row in enumerate(w['program']) if row[0]=='MOVE']
    need(all(g > 0 for _,_,g in legs), 'positive native move ranks')
    labels = {}
    for clock,event in enumerate(c['events']):
        if event[0]=='LOCAL':
            for native,bank,grade in legs:
                key=(clock,native,bank)
                need(key not in labels, 'unique native occurrence')
                labels[key]=grade
        elif event[0] in ('QUERY','IDLE_ONE'):
            grade = 1 if event[0]=='QUERY' else 7*len(event[2])
            for port in range(c['ports']):
                key=(clock,-1,port)
                need(key not in labels, 'unique caller occurrence')
                labels[key]=grade
    census=Counter(labels.values())
    expected = json.loads((HERE/'BASELINE.json').read_bytes())['binary']
    need(census == Counter({int(k):v for k,v in expected['paid'].items()}), 'all actual paid grade counts')
    seq=list(labels.items())
    check_labels(seq,labels)
    same_grade=next(row for row in seq[1:] if row[1] == seq[0][1])
    controls={'omitted':rejects(lambda:check_labels(seq[1:],labels)),
              'duplicate':rejects(lambda:check_labels(seq+[seq[0]],labels)),
              'same_grade_substitution':rejects(lambda:check_labels([same_grade]+seq[1:],labels))}

    # Enumerate every rank pair rather than billions of individual occurrence
    # pairs, weighting each pair by the exact independent occurrence counts.
    pair_count=pair_mass=0
    for left,nleft in census.items():
        for right,nright in census.items():
            count,rank=nleft*nright,left*right
            blocks,tail=divmod(rank,11**2)
            pieces=[11**2]*blocks+([tail] if tail else [])
            need(sum(pieces)==rank and all(0<x<=121 for x in pieces), 'disjoint slab rank cover')
            # Verify disjoint ranges and spectator preservation on a signed vector.
            source=[3-2*i for i in range(rank)]+[91,-22]
            actual=source.copy(); start=0
            for size in pieces:
                stop=start+size
                actual[start:stop]=[-x for x in actual[start:stop]]
                start=stop
            need(actual == [-x for x in source[:rank]]+source[rank:], 'slice endpoint and spectators')
            pair_count += count
            pair_mass += count*rank
    p,b,m=sum(census.values()),sum(expected['targets'].values()),sum(k*n for k,n in census.items())
    need((pair_count,pair_mass)==(p*p,m*m), 'all weighted two-factor tuples')

    # Both grades actually occur. Move one factor from 14 to 7 through the
    # 11^451 call boundary, preserving 451 literal factor slots.
    sample={}
    for label,grade in labels.items():
        sample.setdefault(grade,label)
    v=451; ceiling=11**v
    above=next(a for a in range(v+1) if 7**a * 14**(v-a) < ceiling)
    below_rank=7**above * 14**(v-above)
    above_rank=7**(above-1) * 14**(v-above+1)
    need(below_rank < ceiling < above_rank < 2*ceiling and 7 in sample and 14 in sample,
         'actual supported tuple crosses one-call boundary')
    floor=16**v
    need(4**224 * 8**2 * 64**225 == floor and 4**225 * 8 * 64**225 < floor
         and 4**224 * 8 * 15 * 64**225 > floor, 'productive floor exact boundary')
    need(all(str(x) in expected['targets'] for x in (4,8,15,64)), 'floor ranks occur')
    cut_calls=min(m**v,p**v + m**v//ceiling)
    occurrence_count=(p**v-b**v)//(p-b)
    need((p-b)*occurrence_count == p**v-b**v, 'recursive occurrence geometric sum')
    candidate_path=HERE/'BIT-451.json'
    candidate=json.loads(candidate_path.read_bytes())
    need(candidate['partition']['paid_occurrence_count']==len(labels)
         and Counter({int(k):n for k,n in candidate['native']['paid'].items()})==census,
         'candidate full paid census')
    witness=candidate['partition']['witness']
    need(labels[tuple(witness['first_label'])] == 4 and labels[tuple(witness['tail_label'])] == 14,
         'candidate names actual labelled grades')
    rank=4*14**(v-1)
    old_full,old_tail=divmod(rank,10**v)
    new_full,new_tail=divmod(rank,11**v)
    need(str(old_full+bool(old_tail))==witness['baseline_calls']
         and str(new_full+bool(new_tail))==witness['all11_calls'] and new_full+bool(new_tail)<old_full+bool(old_tail)
         and old_tail>0 and new_tail>0, 'candidate literal 451-slot witness')
    product_bit_lengths={'source_occurrences':occurrence_count.bit_length(),
        'raw_paid_tuples':(p**v).bit_length(), 'all_possible_targets':(b**v).bit_length(),
        'raw_record_instances':(occurrence_count*934_182_831_504).bit_length(),
        'raw_owned_instances':(occurrence_count*6_998_544).bit_length(),
        'split_calls_upper':cut_calls.bit_length(), 'added_block_adapter_sides_upper':(2*cut_calls).bit_length(),
        'discarded_target_allocation_and_retirement_pairs_upper':(b**v).bit_length()}
    need(candidate['product']['product_count_bit_lengths']==product_bit_lengths,
         'every candidate product-account bit length')
    out={'status':'PASS_BOUNDED_LABEL_AND_SLAB_CONTROLS',
         'scope':'Full raw paid identity census, all weighted two-factor grade pairs and 451-slot boundary witnesses; no complete constructed product or wrapper replay.',
         'native_word_sha256':sha256(wraw).hexdigest(), 'caller_sha256':sha256(craw).hexdigest(),
         'native_move_sites_per_call':len(legs), 'actual_paid_occurrences':len(labels),
         'grade_histogram':dict(sorted(census.items())), 'label_controls':controls,
         'two_factor':{'grade_pairs':len(census)**2,'weighted_tuple_count':pair_count,
                       'weighted_rank_mass':pair_mass,'slices_include_spectators':True},
         'supported_cutoff_witnesses':{'below':f'7^{above}*14^{v-above}',
                                       'above':f'7^{above-1}*14^{v-above+1}',
                                       'base':f'11^{v}','calls':[1,2],
                                       'actual_first_grade_labels':{'7':sample[7],'14':sample[14]}},
         'candidate_receipt_sha256':sha256(candidate_path.read_bytes()).hexdigest(),
         'candidate_witness_and_all_product_bit_lengths_match':True,
         'target_floor_witnesses':{'equal':'4^224*8^2*64^225',
                                   'below':'4^225*8*64^225','above':'4^224*8*15*64^225'},
         'product_upper_bounds':{'paid_positions':f'{p}^{v}','paid_rank_mass':f'{m}^{v}',
             'productive_targets':f'{b}^{v}','split_calls':f'min({m}^{v},{p}^{v}+floor({m}^{v}/11^{v}))',
             'split_calls_bit_length':cut_calls.bit_length(),'recursive_occurrences':f'({p}^{v}-{b}^{v})/({p}-{b})',
             'occurrence_bit_length':occurrence_count.bit_length()}}
    (HERE/'replay').mkdir(exist_ok=True)
    (HERE/'replay/CARRIER-LABELS.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    print(out['status'], 'paid',len(labels),'grade pairs',len(census)**2,'controls',controls)

if __name__ == '__main__':
    main()
