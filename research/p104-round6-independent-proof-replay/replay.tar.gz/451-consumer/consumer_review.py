#!/usr/bin/env python3
"""Bounded independent arithmetic/binding review of a 451-cap consumer receipt.

This reads producer receipts and authenticates them by scope and recomputation;
it does not execute native operators or supply a full proof of the premises.
"""
import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source-7830/review'))
import independent as review

def need(c,why):
    if not c:
        raise ValueError(why)

def read(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--app',type=Path,default=HERE/'consumer-replay/APPLICATION.json')
    parser.add_argument('--audit',type=Path,default=HERE/'consumer-replay/AUDIT.json')
    parser.add_argument('--bit',type=Path,default=HERE/'BIT-451.json')
    args=parser.parse_args()
    app,audit,bit=map(read,(args.app,args.audit,args.bit))
    base=read(HERE/'BASELINE.json')
    before=read(HERE/'inputs/7830/research/p104-chart306-chain/DOUBLE-APPLICATION.json')
    old_audit=read(HERE/'source-7830/AUDIT.json')
    old_result=read(HERE/'source-7830/RESULT.json')
    newcap=Q(bit['cover_and_stock']['ordinary_admitted'])
    claim=Q(app['application']['claim'])
    tested=Q(audit['outer']['finite_compiler']['tested'])
    gap=Q(1,10**14)
    need(bit['status']=='PASS_FIXED_PROFILE_FINITE_BIT_SUPPLIER_REPLAY'
         and bit['source']['head']==base['pins']['construction_head']
         and bit['source']['binary_word']==base['pins']['binary_word']
         and newcap==Q('0.00387992804354799998'), 'bound BIT supplier and cap')
    need(app['word_sha256']==base['pins']['rational_word']
         and app['layout_sha256']==base['pins']['rational_layout']
         and app['caller']==base['pins']['rational_caller']
         and app['binary_word']==base['pins']['binary_word']
         and Q(app['binary_ordinary'])==newcap
         and Q(audit['outer']['pinned_binary_cap'])==newcap, 'physical source and new cap binding')
    need(app['premises']==audit['premises']==review.PREMISES, 'same five inherited premises')
    for field in ('native','conversion','caller_census','caller_proof'):
        need(app[field]==before[field], f'unchanged rational physical field {field}')
    for field in ('invoice','ordinary','bracket'):
        need(app['application'][field]==before['application'][field], f'unchanged rational field {field}')
    for field in set(audit)-{'outer','compiler_report_sha256'}:
        need(audit[field]==old_audit[field], f'unchanged audit field {field}')
    need(audit['compiler_report_sha256']==digest(args.app), 'audit binds actual compiler receipt bytes')
    p=Counter({int(k):n for k,n in base['rational']['paid'].items()})
    t=Counter({int(k):n for k,n in base['rational']['targets'].items()})
    need(p==review.histogram(app['application']['invoice']['paid'])
         and t==review.histogram(app['application']['invoice']['targets']), 'all recounted signed bins')
    need(claim==Q(audit['outer']['claim']) and tested==claim+7*gap
         and tested+Q(audit['outer']['finite_compiler']['BIT_margin'])==newcap,
         'correct strict consumer headroom')
    published={'claim':str(claim),'sharp_outer':audit['outer']['outer_checks']}
    outer=review.rational_outer(app,audit,p,t,newcap,published)
    # A cap below the effective exponent a=claim+4*gap must fail.
    try:
        review.outer_margins(claim,gap,claim+4*gap-Q(1,10**15))
    except ValueError as exc:
        need(str(exc)=='all strict and functional outer conditions', 'expected cap corruption rejection')
    else:
        raise ValueError('low-cap corruption accepted')
    damaged=p.copy(); damaged[1]+=1
    try:
        review.directed_invoice(damaged,t,review.RATIONAL_BRACKET,review.TARGET)
    except ValueError as exc:
        need(str(exc)=='directed signs at raw crossing endpoints','expected rank corruption rejection')
    else:
        raise ValueError('invoice corruption accepted')
    old=Q(old_result['claim']); upper=Q(review.BIT_BRACKET[1])
    need(old<claim<newcap<upper, 'gain stays below unchanged raw BIT upper')
    out={'status':'PASS_BOUNDED_CONSUMER_BINDING_AND_ARITHMETIC',
         'scope':'Independently checks receipt binding, unchanged physical/invoice fields, inherited outer arithmetic and specified corruption controls. Does not replay consumer construction or prove its premises.',
         'inputs_sha256':{p.name:digest(p) for p in (args.app,args.audit,args.bit)},
         'baseline_sha256':digest(HERE/'BASELINE.json'), 'premises':review.PREMISES,
         'claim':str(claim),'old_claim':str(old),'gain':str(claim-old),
         'binary_ordinary':str(newcap),'tested_rational_exponent':str(tested),
         'cap_headroom':str(newcap-tested),'same_profile_raw_binary_upper':str(upper),
         'gap_to_raw_upper':str(upper-claim),'outer':outer,
         'controls':{'cap_below_effective_rejected':True,'rational_rank_1_added_rejected':True}}
    (HERE/'replay').mkdir(exist_ok=True)
    (HERE/'replay/CONSUMER-REVIEW.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(out['status'],'claim',claim,'gain',claim-old,'gap_to_raw_upper',upper-claim,flush=True)

if __name__=='__main__':
    main()
