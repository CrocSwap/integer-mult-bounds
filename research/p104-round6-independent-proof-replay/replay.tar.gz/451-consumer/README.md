# 451-factor uniform-cutoff BIT supplier

The checked component uses the same #7830 native BIT and 36-call signed invoice, but a 451-factor `11^451` cutoff and separately priced uniform and delayed-cover losses. The directed component arithmetic gives candidate ordinary BIT saving `0.00387992804354799998` and reduces the BIT parameter `log2 N` from `1,285,200,000,000,000` to `1,202,400,000,000,000` (6.442577%). The pinned 48-call rational application and expanded audit accept that cap and yield candidate conditional `κ ≥ 0.00387992804346`, assuming the retained compiler, cover and stock contracts transfer to this 451-factor, seven-stage variant. The six-stage physical-precision proof in #7846 is for 480 factors and has not been re-established for this variant or the nested seed bill. See [PROOF.md](PROOF.md) for the exact inequalities, assumptions, limits and credits.

The package contains pinned public source inputs and uses the Python 3.12 standard library; it does not need network access. `inputs/` includes 21 direct source files and the 127 inherited files authenticated by the copied #7830 source manifests and source lock. `source-7830/` preserves the upstream package, source notices, proof and verifier at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. All archive and proof hashes can be checked using `sha256sum -c SHA256SUMS`.

From this directory, on CPython 3.12, reproduce the BIT word, paired bill and finite schedule, then the separate independently recounted moment and label checks:

```sh
python3.12 -IB replay_451.py
cmp BIT-451.json replay/BIT-451.json
python3.12 -IB carrier_independent.py
cmp CARRIER-INDEPENDENT.json replay/CARRIER-INDEPENDENT.json
python3.12 -IB carrier_labels.py
cmp CARRIER-LABELS.json replay/CARRIER-LABELS.json
```

The portable copies of the independent reviewers differ from the originals only in input/output path selection. They use the independently recounted `BASELINE.json` and its pinned word and caller; they do not rerun the consumer or construct the tensor word. The original reviewer receipts are retained for attribution.

The committed `consumer-replay/` contains the already-generated rational `APPLICATION.json`, expanded `AUDIT.json`, cap adapter and `CONSUMER.json`. Verify their bindings and outer checks without repeating the native compilation:

```sh
python3.12 -IB run_application.py --summarize-existing
python3.12 -IB consumer_review.py
cmp CONSUMER-REVIEW.json replay/CONSUMER-REVIEW.json
```

For a fresh 48-call compiler and audit replay, move `consumer-replay/` to a safe comparison location and run:

```sh
python3.12 -IB run_application.py
```

The fresh run takes materially longer than the bounded component checks. The script's adapter loads only the checked BIT cap, call count and word pin; it relies on the BIT receipt and inherited assumptions. It does not construct an actual cover prime or full uniform circuit. The finite compiler's reported BIT-carrier improvement is not an end-to-end input-size or runtime comparison.

The separate clean reviewer independently regenerated the same compiler and audit bytes, then checked the exact rational graph in both orientations and recomputed the outer conditions. Its receipt and original script are in [independent-review](independent-review/); that pass reused the pinned compiler and auditor. To repeat it in another clean output directory, run `python3.12 -IB clean_replay.py` and compare `clean-replay-output/INDEPENDENT.json` with `independent-review/CLEAN-CONSUMER.json`. The portable script changes the original's paths and omits its optional CPU-affinity setting.

The first producer consumer run completed both scientific checks and wrote both receipts, but its final summary wrapper looked up a nonexistent `application.tested` field and raised `KeyError`; `consumer-run.log` preserves that event. The corrected wrapper reads the audited compiler's tested field and `--summarize-existing` verifies the existing receipt bindings. The later independent clean replay reproduces both receipt files byte for byte.

The separate [prime and stock review](independent-review/PRIME-STOCK-451.md) found no contradiction in the finite-prime budget but did not re-establish the new physical and precision interfaces. Workstation paths in the report and scripts are redacted or made package-relative; their original script hashes are recorded in PROVENANCE. Its path-adjusted arithmetic controls reproduce the retained receipt with:

```sh
python3.12 -IB prime_scope_check.py > replay/prime-receipt.json
cmp independent-review/prime-receipt.json replay/prime-receipt.json
```

This export redacts local workstation paths from the producer log and independent review records. Pinned upstream source bytes remain unchanged; any generic `/tmp` examples inside those source files are part of the authenticated public sources. The original unredacted local evidence is retained separately.
