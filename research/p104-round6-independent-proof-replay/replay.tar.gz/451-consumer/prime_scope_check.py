#!/usr/bin/env python3
"""Small exact controls for the 451-factor cover-prime/stock interface.

This does not construct the astronomical carrier, witness catalogue, prime,
or stock.  The toy checks validate the formulas on small integers only.
"""
from fractions import Fraction as F
import json
from pathlib import Path


def demand(ok, msg):
    if not ok:
        raise ValueError(msg)


def prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    d = 3
    while d*d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def ceil_log(n, base):
    value, out = 1, 0
    while value < n:
        value *= base
        out += 1
    return out


def main():
    source = json.loads((Path(__file__).resolve().parent/'BIT-451.json').read_text())
    old = json.loads((Path(__file__).resolve().parent/'source-7830/RESULT.json').read_text())
    demand(source['source']['head'] == '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15', 'source pin')
    H = 1_202_400_000_000_000
    old_H = 1_285_200_000_000_000
    demand(source['uniform']['H'] == H and old['log2_carrier'] == old_H, 'carrier pins')
    demand(source['partition']['factors'] == 451, 'factor count')
    d = F(source['cover_and_stock']['loss'])
    e = F(source['uniform']['uniform_loss'])
    C = F(source['separation']['trial'])
    covered = F(source['cover_and_stock']['covered'])
    demand((d, e, covered) == (F(1, 10**13), F(1, 400_000_000_000), C-e-d), 'losses')
    surcharge = F(64, 2**52)
    budget = d / 4
    demand(surcharge < budget <= F(64, 2**51), 'prime exponent failure control')
    hd = H*d
    demand(hd == F(3006, 25), 'H times cover loss')
    demand(F(2**(hd.numerator // hd.denominator)) >= 1+d/2, 'covered moment')
    moment_upper = (1+d/4)/(1+d/2)
    demand(moment_upper == F(source['cover_and_stock']['moment_upper']) < 1, 'strict cover margin')

    rho = F(1, 250)
    seed = F(source['cover_and_stock']['seed'])
    cold_envelope = (1-rho)*covered
    demand(seed < cold_envelope, 'cold seed is unfunded')
    prev = seed
    rows = source['cover_and_stock']['stages']
    demand(len(rows) == 7, 'seven post-seed stages')
    gaps = []
    for row in rows:
        envelope = (1-rho)*covered + rho*prev
        claim = F(row['claim'])
        demand(envelope == F(row['envelope_exact']) and prev < claim < envelope, 'bootstrap gap')
        demand(envelope - claim == F(row['strict_gap_exact']), 'recorded gap')
        gaps.append(str(envelope - claim))
        prev = claim
    demand(prev == F(source['cover_and_stock']['ordinary_admitted']), 'final ordinary cap')
    old_trial = F('0.00387992803563')
    old_kappa = F('0.00387992803556')
    demand(prev > old_trial > old_kappa, 'old consumer headroom')

    targets = source['native']['targets']
    demand(all(int(targets[k]) > 0 for k in ('4', '8', '64')), 'floor target labels absent')
    demand(224+2+225 == 451, 'floor tuple count')
    demand(4**224 * 8**2 * 64**225 == 16**451, 'floor not attained')

    # The exponent comparison uses the new and old N, not a fictitious
    # same-N prime comparison. It is a comparison of lower cutoffs only.
    new_power = 52+5*H
    old_power = 45+5*old_H
    demand(old_power-new_power == 413_999_999_999_993, 'cover cutoff comparison')

    # Toy prime control: the admissible search starts past both the lower
    # cutoff and every nonzero integer witness, then ends before 2T. It does
    # not give a numerical upper bound for the real unenumerated catalogue.
    witnesses = (2**17+1, -17, 3, 11)
    M = max(map(abs, witnesses))
    T = max(2**17, M, 2)
    q = T+1
    while not prime(q):
        q += 1
    demand(T < q < 2*T and all(v % q for v in witnesses), 'toy prime selection')
    demand(17 % 17 == 0, 'excluded-prime fault control')
    L = max(17, (M-1).bit_length())
    demand(q.bit_length() <= L+1, 'toy bit-length bound')

    # One-stage stock formula on q=3, N=2. GL_2(F_3) has order 48.
    q0, N0, B0, G0 = 3, 2, 5, 48
    tB = ceil_log(B0, q0)
    stock_cases = 0
    for width in range(1, 101):
        w = 1 if width == 1 else 2  # ceil(width^(1/250)) on this range
        d0 = max(1, (width+w-1)//w)
        D = 2+ceil_log(d0, N0)
        W = B0*G0*q0**(N0*N0*(w-1))
        k = ceil_log(W**D, q0)
        demand(k <= D*(tB+N0*N0*w), 'one-stage stock inequality')
        stock_cases += 1

    result = {
        'status': 'PASS_SCOPED_PRIME_AND_STOCK_ARITHMETIC',
        'source_head': source['source']['head'],
        'new_H': H, 'old_H': old_H,
        'new_log2_prime_cutoff': new_power,
        'old_log2_prime_cutoff': old_power,
        'old_minus_new_cutoff_exponent': old_power-new_power,
        'surcharge_upper': str(surcharge),
        'surcharge_budget': str(budget),
        'surcharge_budget_slack': str(budget-surcharge),
        'one_smaller_q_exponent_rejected': True,
        'H_times_cover_loss': str(hd),
        'good_factor_integer_exponent': hd.numerator // hd.denominator,
        'moment_upper': str(moment_upper),
        'moment_slack': str(1-moment_upper),
        'cold_seed_envelope_slack': str(cold_envelope-seed),
        'nontrivial_stages_including_cold': len(rows)+1,
        'stage_gaps': gaps,
        'final_ordinary_minus_old_rational_trial': str(prev-old_trial),
        'final_ordinary_minus_old_kappa': str(prev-old_kappa),
        'floor_target_tuple': {'4': 224, '8': 2, '64': 225},
        'toy_T': T, 'toy_prime': q, 'toy_exclusion_control': '17 rejects witness 17',
        'toy_one_stage_stock_cases': stock_cases,
        'limitations': ['actual finite exclusion list, q, and stock not materialized',
                        'fresh-fiber, full tape, and precision proofs not independently replayed'],
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
