#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Bounded replay of a single-cutoff BIT schedule on the pinned #7830 word.

This reuses #7830's frozen literal binary verifier, directed arithmetic and
physical stock rules. It does not replay the rational consumer or materialize
the enormous tensor, uniform circuit, prime, or eventual stock.
"""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
from pathlib import Path
import importlib.util, json, sys

HERE=Path(__file__).resolve().parent
PKG=HERE/'source-7830'
WORK=HERE/'inputs'
OUT=HERE/'replay'
OUT.mkdir(exist_ok=True)
PIN='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
V=451; C=Q('0.003879928046148'); CUT=11; FLOOR=16; AMBIENT=134
U=Q(13,50); W=Q(17,50); THETA=Q(13,15); P=60
E=Q(1,400_000_000_000); D=Q(1,10**13); H=1_202_400_000_000_000
QPOWER=52; OLD_H=1_285_200_000_000_000
SEED=Q('0.00385248'); RHO=Q(1,250); GRID=10**22


def need(cond, desc):
    if not cond: raise ValueError(desc)

def pinned(path, pin):
    data=path.read_bytes(); need(sha256(data).hexdigest()==pin, f'pin: {path.name}'); return data

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec); sys.modules[name]=module; spec.loader.exec_module(module)
    return module

def frac(x): return str(x)

def fixed(n,places): return f'{n//10**places}.{n%10**places:0{places}d}'

def read(path): return json.loads(path.read_bytes())

pinned(PKG/'verify.py','5a073a31a4ea63ab5943057db2682029cb5524b8373116f51be580b1a3dde69b')
pinned(PKG/'bit_certificate.py','833bee1b33bb564cd44f3dc80201ab87c88d23db2fd9e2e879b46b1bfbf0b500')
pinned(PKG/'SOURCES.json','357e6fe1a57bcb03be10874ba69ad075729802f15ac9614606856a16dc2c8e4f')
pinned(PKG/'BIT.json','8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d')
pinned(PKG/'review/independent.py','a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca')
sys.path.insert(0,str(PKG))
ver=load('p7830_verify',PKG/'verify.py')
bc=sys.modules['bit_certificate']
ind=load('p7830_interval_review',PKG/'review/independent.py')
print('Authenticating pinned explicit and inherited inputs',flush=True)
explicit=ver.pinned_inputs(WORK,False)
prepare=load('source_preparer', WORK/ver.PRED/'prepare_sources.py')
inherited=prepare.sources(WORK/'cache',False)
need((explicit,inherited)==(21,127),'complete source pin census')
package=WORK/ver.PRED; source=WORK/'cache/source'; parent=WORK/'cache/parent'
binary=ver.load('candidate_finite',package/'binary/finite.py')
for name,pin in binary.SOURCE_PINS.items(): binary.pinned(source/name,pin)
for name,pin in binary.PACKAGE_PINS.items(): binary.pinned(parent/name,pin)
literal=binary.load(parent/'binary/independent/literal.py','literal')
price=binary.load(parent/'binary/independent/price.py','directed_price')
credited=binary.load(source/binary.FINITE,'credited_trim')
exact=credited.E
baseline=literal.candidate_word(parent/'binary/WORD.json.gz')
caller=literal.pinned(source/binary.PAIRED/'EFREE-CALLER.json.gz',literal.CALLER_SHA)
word_path=package/'binary/WORD.json.gz'; word=ver.read(word_path)
print('Replaying both native orientations and the complete 36-call bill',flush=True)
native=binary.candidate_receipt(literal,word_path,PIN,baseline,caller)
archive=read(PKG/'BIT.json')
need(json.loads(json.dumps(native))==archive['native'],'same complete archived binary bill')
paid,targets=native['paid'],native['targets']
predecessor=ver.read(package/'binary/INDEPENDENT.json')
need(paid==Counter({int(k):v for k,v in predecessor['complete_paid'].items()}) and
     targets==Counter({int(k):v for k,v in predecessor['complete_productive'].items()}),
     'complete histograms independently match pinned predecessor')

# All paid labels have the same static assignment. Verify real occurrence ids,
# both coverage and uniqueness, plus mutation controls on same-grade labels.
charts=literal.Charts(word['frames']); occurrences=list(bc.physical_paid_jobs(word,caller,charts))
need(len(occurrences)==sum(paid.values())==107460 and len({id for grade,id in occurrences})==len(occurrences)
     and Counter(g for g,_ in occurrences)==paid,'every real paid label and rank')
rank14=[id for grade,id in occurrences if grade==14][:2]
rank4=[id for grade,id in occurrences if grade==4][:2]
need(len(rank14)==len(rank4)==2,'actual supported repeated grades')
samples=[(4,rank4[0]),(4,rank4[1]),(14,rank14[0]),(14,rank14[1])]
pairs=list(product(samples,repeat=2))
bc.validate_partition(pairs,pairs)
for bad in (pairs[1:],pairs+[pairs[0]],pairs[1:]+[pairs[1]]):
    try: bc.validate_partition(pairs,bad)
    except ValueError: pass
    else: raise ValueError('tuple omission/duplication/substitution control')
R=4*14**(V-1)
old_full,old_tail,old_calls=bc.subdivide(R,10**V)
new_full,new_tail,new_calls=bc.subdivide(R,11**V)
need(new_calls<old_calls and old_full*10**V+old_tail==R and
     new_full*11**V+new_tail==R,'literal slab reduction on real 4,14-labelled tuple')

signed=price.signed_profile(targets,paid)
bracket,signs,derivative=binary.exact_crossing(price,signed)
need(bracket==archive['raw_crossing'] and C<Q(bracket[0]) and price.moment(signed,C)[0]>0,
     'raw signed crossing and strict trial')
# Recompute the single-class strict separation with two independently
# directed source engines; the review implementation supplies a third check.
t=1-C; wanted=price.moment(targets,C); swanted=exact.moment(targets,t)
ratios={
 'alpha':price.divide(price.moment(paid,C),wanted),
 'gamma':price.divide(price.moment(paid,C,U),price.mul(price.exp_log(CUT,U),wanted)),
 'lambda':price.divide(price.mul(price.exp_log(FLOOR,W),price.moment(targets,C,-W)),wanted),
}
sratios={
 'alpha':exact.divide(exact.moment(paid,t),swanted),
 'gamma':exact.divide(exact.moment(paid,t+U),exact.mul(exact.power(CUT,U),swanted)),
 'lambda':exact.divide(exact.mul(exact.power(FLOOR,W),exact.moment(targets,t-W)),swanted),
}
baseline2=ind.moment(targets,t)
iratios={
 'alpha':ind.quotient(ind.moment(paid,t),baseline2),
 'gamma':ind.quotient(ind.moment(paid,t+U),ind.mul(ind.power(CUT,U),baseline2)),
 'lambda':ind.quotient(ind.mul(ind.power(FLOOR,W),ind.moment(targets,t-W)),baseline2),
}
caps={}
for key,interval in ratios.items():
    one=(Q(interval[0],price.GRID),Q(interval[1],price.GRID))
    two=sratios[key]
    three=(Q(iratios[key][0],ind.GRID),Q(iratios[key][1],ind.GRID))
    need(max(one[0],two[0],three[0])<=min(one[1],two[1],three[1]),f'directed agreement {key}')
    upper=max(one[1],two[1],three[1]); rounded=Q(price.ceiling(upper.numerator*GRID,upper.denominator),GRID)
    need(0<upper<=rounded<1,f'strict cap {key}'); caps[key]=rounded
base=1/(1+V*(1-caps['alpha']))
uplift=2*caps['gamma']**V; debit=caps['lambda']**V
surplus=1-base-uplift-debit
need(surplus>Q('0.0000000000005848'),'single-cutoff complete separation')
# Negative control: an attempted 448-factor certificate does not prove separation.
bad_v=448
bad=1-1/(1+bad_v*(1-caps['alpha']))-2*caps['gamma']**bad_v-caps['lambda']**bad_v
need(bad<0,'448-factor moment-bound control')

# Reuse source formula for all complete-product occurrences and slabs.
bc.POWER=V; bc.CLASSES=(('all_paid',CUT,U),); bc.paid_class=lambda grade:'all_paid'
product_account=bc.product_account(native,{'all_paid':paid})
need(product_account['paid_partition']['all_paid']['first_paid_count']==107460,
     'all first labels assigned exactly once')

# Uniform logarithmic majorant, with exact predecessor-grid and p-1 controls.
A1=price.raise_interval(price.exp_log(AMBIENT,C),V)
A2=exact.power(AMBIENT,V*C)
eta1=price.scale(price.invert(A1),1-C)
eta2=exact.scale(exact.power(AMBIENT,-V*C),1-C)
A3=ind.power(AMBIENT,V*C); eta3=ind.quotient(ind.enclose(1-C),A3)
Ahi=max(Q(A1[1],price.GRID),A2[1],Q(A3[1],ind.GRID))
elo=min(Q(eta1[0],price.GRID),eta2[0],Q(eta3[0],ind.GRID))
ehi=max(Q(eta1[1],price.GRID),eta2[1],Q(eta3[1],ind.GRID))
need(THETA**P<elo<=ehi<=THETA**(P-1) and Ahi<2**P,
     'log power 60 succeeds and power 59 fails')
need(CUT**15<FLOOR**13 and 4*CUT**(15*V)<=AMBIENT**(13*V),
     'uniform exit and shifted-log bounds')
j=H*E; need(j.denominator==1 and j==3006,'exact integer horizon')
need((H+1)**P<2**int(j) and (H-E.denominator+1)**P>=2**(int(j)-1),
     'carrier grid point passes and preceding grid point fails')
need((H+1)*E>2*P and Q(H,OLD_H)<=Q(95,100),'monotone uniform tail and >=5% H reduction')

# Delayed cover is separate from uniform loss. Prime is chosen after freezing
# finite exclusions; these comparisons strictly price the entire fallback.
bad_surcharge=Q(64,2**QPOWER)
need(bad_surcharge<D/4 and Q(64,2**(QPOWER-1))>=D/4,
     'q bound suffices; one fewer binary prime bit fails')
need(2**int(H*D)>=1+D/2,'actual N covers the good-class multiplier')
covered=C-E-D; multiplier=(1+D/4)/(1+D/2)
need(multiplier<1 and covered>SEED,'strict covered moment and completed seed')
stages=[]; previous=SEED
for _ in range(7):
    envelope=(1-RHO)*covered+RHO*previous
    scaled=envelope*10**20; tick=scaled.numerator//scaled.denominator-1
    step=fixed(tick,20); accepted=Q(step)
    need(previous<accepted<envelope<covered<RHO<1-envelope,'strict ordinary work exponents')
    stages.append({'previous':str(previous),'claim':step,'envelope_exact':str(envelope),
                   'strict_gap_exact':str(envelope-accepted)})
    previous=accepted
accepted=previous
need(accepted==Q('0.00387992804354799998')>Q(archive['ordinary_admitted']),
     'strictly higher complete ordinary cap')
replayed, _=price.bootstrap(SEED,covered,[row['claim'] for row in stages])
need(replayed==accepted,'source bootstrap independently rechecks strict stages')

out={'status':'PASS_FIXED_PROFILE_FINITE_BIT_SUPPLIER_REPLAY',
     'scope':'451-fold finite construction rule; literal native word replay; uniform/compiler/stock checked by inequalities, not materialized; no rational consumer replay',
     'source':{'pr':7830,'head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','explicit_files':explicit,
               'inherited_files':inherited,'binary_word':PIN,
               'consumer_rational_word':'7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48'},
     'native':native,'raw_crossing':bracket,'raw_crossing_signs':signs,
     'target_0003884928046155_margin':price.decimal_interval(price.moment(signed,Q('0.003884928046155'))),
     'native_derivative_upper':price.decimal_interval((derivative,derivative),12)[1],
     'partition':{'factors':V,'cutoff':f'{CUT}^{V}','productive_floor':f'{FLOOR}^{V}',
        'working_ambient':f'{AMBIENT}^{V}','paid_occurrence_count':len(occurrences),
        'same_grade_omission_duplicate_substitution_controls':'PASS',
        'witness':{'first_grade':4,'first_label':rank4[0],'tail_grade':14,'tail_label':rank14[0],
                   'tail_factors':V-1,'baseline_at_same_v_cutoff':f'10^{V}',
                   'baseline_calls':str(old_calls),'all11_calls':str(new_calls),
                   'old_residual_nonzero':bool(old_tail),'new_residual_nonzero':bool(new_tail)}},
     'separation':{'trial':str(C),'paid_tilt':str(U),'target_tilt':str(W),
        'caps':{k:str(v) for k,v in caps.items()},
        'three_engine_intervals':{'source_1':{k:price.decimal_interval(v) for k,v in ratios.items()},
                                  'source_2':{k:exact.display(v) for k,v in sratios.items()},
                                  'review':{k:ind.report_interval(v) for k,v in iratios.items()}},
        'base_surplus':price.rational_display(1-base,30),
        'paid_uplift_upper':price.rational_display(uplift,30),
        'discarded_target_upper':price.rational_display(debit,30),
        'strict_surplus_lower':price.rational_display(surplus,30),
        '448_factor_bound_control':price.rational_display(bad,30)},
     'product':product_account,
     'uniform':{'theta':str(THETA),'log_power':P,'uniform_loss':str(E),'H':H,
        'N':f'2^{H}','grid_exponent':int(j),'old_H':OLD_H,'H_reduction_exact':str(1-Q(H,OLD_H)),
        'power_59_fails':True,'previous_H_grid_fails':True,'exit_and_shifted_log_pass':True,
        'ambient_power':price.decimal_interval(A1),'eta':price.decimal_interval(eta1)},
     'cover_and_stock':{'loss':str(D),'q_condition':f'odd prime q > 2^{QPOWER}*N^5 avoiding frozen finite catalogue witnesses',
        'bad_surcharge_upper':str(bad_surcharge),'budget':str(D/4),'one_less_q_exponent_fails':True,
        'H_times_loss':str(H*D),'covered':str(covered),'moment_upper':str(multiplier),
        'seed':str(SEED),'rho':str(RHO),'stages':stages,'ordinary_admitted':stages[-1]['claim'],
        'stock_reserve':'W(w)^(2+ceil(log_N(max(1,ceil(e/w))))) * S_old; fixed-template high digits and all auxiliary services retained'},
     'premises':['native_all_columns','owned_erasure','compiler','precision_tape','analytic_recovery'],
     'limitations':['same complete signed histogram and raw crossing as #7830','rational application not rerun',
                    'finite rules and eventual stock not materialized','independent human review open'],
     'credit':['Clear1nsight #7830 mixed schedule and archive','Dugongue #7831 cutoff rebalance',
               'Rohan Arun #7835 grade-14 successor','Ali Romman complete dual-supplier caller',
               'retained source NOTICE and framework contributors']}
(OUT/'BIT-451.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS_FIXED_PROFILE_FINITE_BIT_SUPPLIER_REPLAY',stages[-1]['claim'],flush=True)
