#!/usr/bin/env python3
"""Direct independent named-pulse replay; standard library, no vendor imports.

All rows are original input-coordinate GF(2) bitsets. A pair (base,tag)
represents base + tag[0]*beta_2287 + tag[1]*beta_3387. The cut then
specializes to a common arbitrary beta, and grants a free XOR of every live
receiver field at the first pulse time as the one replacement ingress.
"""
from hashlib import sha256
from pathlib import Path
import gzip,json

root=Path(__file__).resolve().parent
raw=(root/'inputs/WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw))
assert w['public']==680 and w['owned_fields']==3554
assert sum(c==1 for c in w['start'])==0 and sum(c==1 for c in w['final'])==537
assert sum(e[0]=='SWAP' for e in w['program'])>0
point=max(i for i,e in enumerate(w['program']) if e[0]=='SWAP')+1
assert all(e[0]=='CLEAR' for e in w['program'][point:])

# Low-pivot elimination stores full original occurrence coordinates with rows.
def insert(b, row, coordinate):
    while row:
        lsb=row & -row
        i=lsb.bit_length()-1
        if i not in b:
            b[i]=(row,coordinate)
            return True
        v,c=b[i]; row^=v; coordinate^=c
    return False

def solve(b,row):
    coordinate=0
    while row:
        i=(row & -row).bit_length()-1
        if i not in b:
            return None
        v,c=b[i]; row^=v; coordinate^=c
    return coordinate

states=[(chart,1<<i,0) for i,chart in enumerate(w['start'])]+[None]*w['owned_fields']
move_label=w['public']; sink=[]; snap=None; moves={}
for clock,event in enumerate(w['program'][:point]):
    op,a,*rest=event
    if op=='INIT':
        assert states[a] is None
        states[a]=(rest[0],0,0)
    elif op=='CLEAR':
        assert states[a] is not None and states[a][0]==rest[0]
        states[a]=None
    elif op=='ADD':
        b,chart=rest; x,y=states[a],states[b]
        assert a!=b and x is not None and y is not None and x[0]==y[0]==chart
        states[a]=(chart,x[1]^y[1],x[2]^y[2])
    elif op=='SWAP':
        b=rest[0]; assert a!=b and states[a] is not None and states[b] is not None
        states[a],states[b]=states[b],states[a]
    elif op=='MOVE':
        src,dst=rest; x=states[a]
        assert x is not None and x[0]==src and move_label==a
        moves[move_label]=(clock,src,dst)
        if dst==1:
            sink.append((move_label,x[1]))
        if move_label==2287:
            x=(x[0],x[1],x[2]^1)
        elif move_label==3387:
            x=(x[0],x[1],x[2]^2)
        states[a]=(dst,x[1],x[2])
        if move_label==2287:
            snap=[(i,field[1],field[2]) for i,field in enumerate(states) if field is not None and field[0]==dst]
        move_label+=1
    else:
        raise AssertionError(op)
assert moves[2287]==(6983,506,357) and moves[3387]==(18006,506,356)
assert snap is not None and len(sink)==537
assert not any(src==1 for _,src,_ in moves.values()), 'sink has outgoing MOVE'
assert [s[0] for s in states[:680]]==w['final']
assert len({lab for lab,_ in sink})==537
b={}
for i,(label,row) in enumerate(sink):
    assert insert(b,row,1<<i), ('sink stock dependent',label)
assert len(b)==537
# At the correction point every named receipt field is still present and has
# its original row. Tags track all changes under the two symbolic injections.
assert all(states[label] is not None and states[label][0]==1 and states[label][1]==row for label,row in sink)
# The entire terminal public target belongs to the old sink subspace and has
# rank 537, independently of the private arrival rank calculation.
output_rows=[states[i][1] for i,c in enumerate(w['final']) if c==1]
outbasis={}
for row in output_rows:
    assert solve(b,row) is not None
    assert insert(outbasis,row,0)
assert len(outbasis)==537
r=next(i for i,(lab,_) in enumerate(sink) if lab==3266)
q=sum((states[label][2].bit_count()&1)<<i for i,(label,_) in enumerate(sink) if i!=r)
qlabels=[sink[i][0] for i in range(len(sink)) if (q>>i)&1]
assert qlabels==[3122]

# Includes all zero-original fields: any pulse-only zero is a source.
# Here even every nonzero receiver row lies in the old sink space, so every
# XOR combination does too. Linear quantities v_r and lambda+q.v vanish
# individually, so vanish for the full span; this is a universal beta cut.
receiver=[]
for field,row,tag in snap:
    v=solve(b,row)
    assert v is not None, ('outside field requires span-intersection calculation',field)
    lam=tag.bit_count()&1
    vr=(v>>r)&1
    dot=(v&q).bit_count()&1
    assert vr==0 and lam^dot==0, (field,vr,lam,dot)
    if row or tag:
        receiver.append({'field':field,'old_target_coefficient':vr,'pulse_coefficient':lam,'retained_sink_pairing':dot,'determinant_factor':lam^dot})
assert receiver==[
 {'field':2076,'old_target_coefficient':0,'pulse_coefficient':0,'retained_sink_pairing':0,'determinant_factor':0},
 {'field':2112,'old_target_coefficient':0,'pulse_coefficient':0,'retained_sink_pairing':0,'determinant_factor':0},
 {'field':2287,'old_target_coefficient':0,'pulse_coefficient':1,'retained_sink_pairing':1,'determinant_factor':0},
]
# Concrete witness beta=x649 is in the common live stock; as an added
# independent check, directly rank the 537 corrected ingress rows for each of
# the 3 live receiver sources. Their rank must fall below 537.
beta=1<<649
bc=solve(b,beta);assert bc is not None and (bc>>r)&1
ranks=[]
for field,row,tag in snap:
    if not (row or tag): continue
    altered=[]
    for i,(label,base) in enumerate(sink):
        if i==r:
            continue
        altered.append(base^(beta if (q>>i)&1 else 0))
    altered.append(row^(beta if tag.bit_count()&1 else 0))
    p={}
    for item in altered:insert(p,item,0)
    ranks.append({'field':field,'rank':len(p)})
assert all(x['rank']<537 for x in ranks)
# Verify no `ADD` or SWAP reads original target field before its first recorded
# touch; the new ingress is placed before the recorded original use.
touches=[(i,e) for i,e in enumerate(w['program'][moves[3266][0]+1:],moves[3266][0]+1)
         if e[1]==3266 or e[0] in ('ADD','SWAP') and e[2]==3266]
assert touches[0]==(38623,['ADD',4203,3266,1]) and moves[2287][0]<38623
print(json.dumps({
 'status':'PASS_INDEPENDENT_NAMED_ALL_BETA_PULSE_CUT',
 'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'source_gzip_sha256':sha256(raw).hexdigest(),
 'named_case':{'first':2287,'partner':3387,'removed_sink':3266,'first_clock':6983,'partner_clock':18006,'old_first_touch_clock':38623},
 'sink_basis_rank':len(b),'public_sink_output_rank':len(outbasis),'retained_sensitivity_labels':qlabels,
 'receiver_live_field_count_including_zero':len(snap),'nonzero_or_sensitive_fields':receiver,
 'x649_direct_rank_by_replacement_source':ranks,
 'scope':'One arbitrary common-beta injection at two named original MOVE outputs, replacing only sink packet 3266 with one direct ingress from any XOR of live chart-357 fields immediately after 2287. Other paid arrivals fixed; receiver XOR is free. No changed word, new stock, extra ingress, other timing, distinct betas, physical cleanup, or kappa conclusion is covered.'
},indent=2,sort_keys=True))
