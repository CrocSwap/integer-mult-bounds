#!/usr/bin/env python3
"""Independent native-tape replay of 32 named paired-pulse sink cuts.

Each old binary row is a Python bitset; symbolic tags independently track each
named injected arrival. The receiver/T intersection is computed by quotient
elimination on *all* live fields, including original zeros and all XORs of
outside-T rows. No producer algorithm or vendor import is used.
"""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import gzip,json
P=Path(__file__).resolve().parent
raw=(P/'inputs/WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
word=json.loads(gzip.decompress(raw))
source=(P/'inputs/ALL-BETA-CASES.json').read_bytes()
assert sha256(source).hexdigest()=='135a761f88c75e2980b38ea19a02d9042e4c3338fe86e735c7f7943cf70ef44e'
old=json.loads(source)
cases=[(x['first'],x['partner'],x['old_sink']) for x in old['cases']]
assert len(cases)==len(set(cases))==32
firsts={a for a,_,_ in cases}; labels=sorted({v for a,b,_ in cases for v in (a,b)})
tag={a:1<<i for i,a in enumerate(labels)}
N=word['public'];assert N==680 and word['owned_fields']==3554
assert word['start'].count(1)==0 and word['final'].count(1)==537
point=max(i for i,e in enumerate(word['program']) if e[0]=='SWAP')+1
assert all(e[0]=='CLEAR' for e in word['program'][point:])

def add_basis(B,x,rep):
    while x:
        bit=(x&-x).bit_length()-1
        if bit not in B:
            B[bit]=(x,rep);return True
        y,r=B[bit];x^=y;rep^=r
    return False

def reduce_basis(B,x):
    # Preserve irreducible bits while continuing to eliminate higher pivots.
    residual=rep=0
    while x:
        low=x&-x; k=low.bit_length()-1
        if k in B:
            y,r=B[k];x^=y;rep^=r
        else:
            residual^=low;x^=low
    return residual,rep

state=[(c,1<<i,0) for i,c in enumerate(word['start'])]+[None]*word['owned_fields']
move=N; sink=[]; snapshots={}; moves={}
for clock,e in enumerate(word['program'][:point]):
    op,a,*r=e
    if op=='INIT':
        assert state[a] is None;state[a]=(r[0],0,0)
    elif op=='CLEAR':
        assert state[a] is not None and state[a][0]==r[0];state[a]=None
    elif op=='ADD':
        j,c=r;x,y=state[a],state[j]
        assert a!=j and x is not None and y is not None and x[0]==y[0]==c
        state[a]=(c,x[1]^y[1],x[2]^y[2])
    elif op=='SWAP':
        j=r[0];assert a!=j and state[a] is not None and state[j] is not None
        state[a],state[j]=state[j],state[a]
    elif op=='MOVE':
        src,dst=r;x=state[a];assert x is not None and x[0]==src and move==a
        moves[move]=(clock,src,dst)
        if dst==1:sink.append((move,x[1]))
        state[a]=(dst,x[1],x[2]^tag.get(move,0))
        if move in firsts:
            snapshots[move]=[(i,s[1],s[2]) for i,s in enumerate(state) if s is not None and s[0]==dst]
        move+=1
    else:raise AssertionError(op)
assert set(snapshots)==firsts and len(sink)==537
assert not any(s==1 for _,s,_ in moves.values())
assert [s[0] for s in state[:N]]==word['final']
B={}
for i,(label,row) in enumerate(sink):assert add_basis(B,row,1<<i)
assert len(B)==537
assert all(state[l] is not None and state[l][:2]==(1,row) for l,row in sink)
output={}
for i,c in enumerate(word['final']):
    if c==1:
        row=state[i][1];assert reduce_basis(B,row)[0]==0
        assert add_basis(output,row,0)
assert len(output)==537

results=[];tot=Counter()
for a,b,target in cases:
    assert a!=b and moves[a][2]!=1 and moves[b][2]!=1 and moves[target][2]==1
    first_touch=next((i for i,e in enumerate(word['program'][moves[target][0]+1:],moves[target][0]+1)
                      if e[1]==target or e[0] in ('ADD','SWAP') and e[2]==target),None)
    assert first_touch is not None and moves[a][0]<first_touch
    r=next(i for i,(lab,_) in enumerate(sink) if lab==target)
    targetmask=1<<r
    q=0
    for i,(lab,_) in enumerate(sink):
        if i!=r and ((bool(state[lab][2]&tag[a])) != (bool(state[lab][2]&tag[b]))):q|=1<<i
    assert q, ('no retained sensitivity',a,b,target)
    # Quotient by T: eliminate base-row residuals while retaining T coordinates,
    # pulse coefficient and the exact XOR of source field indices. A zero
    # quotient is a complete generator of receiver-span intersection T.
    outB={};intersection={}
    fields=snapshots[a]
    for idx,(field,row,t) in enumerate(fields):
        residual,v=reduce_basis(B,row)
        pulse=int(bool(t&tag[a])!=bool(t&tag[b]));mask=1<<idx
        while residual:
            pivot=(residual&-residual).bit_length()-1
            if pivot not in outB:
                outB[pivot]=(residual,v,pulse,mask);break
            rr,rv,rp,rm=outB[pivot]
            residual^=rr;v^=rv;pulse^=rp;mask^=rm
        else:
            aug=v|(pulse<<537)
            add_basis(intersection,aug,mask)
    seen=[]
    for aug,mask in intersection.values():
        v=aug&((1<<537)-1);pulse=aug>>537
        # Check this generator by reconstructing both the chosen live rows and
        # the occurrence-coordinate representation from scratch.
        base=actualpulse=0;selected=[]
        for idx,(field,row,t) in enumerate(fields):
            if (mask>>idx)&1:
                base^=row;actualpulse^=int(bool(t&tag[a])!=bool(t&tag[b]));selected.append(field)
        representation=0
        for i,(_,row) in enumerate(sink):
            if (v>>i)&1:representation^=row
        assert base==representation and actualpulse==pulse
        oldcoord=int(bool(v&targetmask)); pairing=(v&q).bit_count()&1
        assert oldcoord==0 and pulse^pairing==0,(a,b,target,selected,oldcoord,pulse,pairing)
        seen.append({'source_field_xor':selected,'old_target_coefficient':oldcoord,'pulse_coefficient':pulse,'retained_pairing':pairing,'determinant_factor':pulse^pairing})
    producer=next(x for x in old['cases'] if (x['first'],x['partner'],x['old_sink'])==(a,b,target))
    qlabels=[lab for i,(lab,_) in enumerate(sink) if (q>>i)&1]
    assert qlabels==producer['retained_sink_pulse_receipt_labels']
    tot['cases']+=1;tot['intersection_generators']+=len(seen)
    tot['all_beta_cuts']+=1;tot['live_field_occurrences']+=len(fields)
    tot['original_zero_fields']+=sum(not row for _,row,_ in fields)
    tot['outside_quotient_rank']+=len(outB)
    results.append({'first':a,'partner':b,'target':target,'first_clock':moves[a][0],
      'partner_clock':moves[b][0],'old_first_touch':first_touch,'retained_sensitivity_labels':qlabels,
      'live_field_count':len(fields),'receiver_outside_quotient_rank':len(outB),
      'receiver_sink_intersection_basis':seen})
assert tot['cases']==tot['all_beta_cuts']==32
print(json.dumps({'status':'PASS_INDEPENDENT_ALL_32_NAMED_PULSE_CUTS',
 'source_word_sha256':sha256(raw).hexdigest(),'case_receipt_sha256':sha256(source).hexdigest(),
 'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'sink_input_rank':len(B),'sink_output_rank':len(output),'counts':dict(tot),'cases':results,
 'scope':'The 32 tuples are copied from the producer case list; all native tape states, symbolic tags, sink rank, and receiver-to-sink intersection are recomputed independently. Same arbitrary beta enters both original MOVEs; exactly one named old sink ingress is replaced by one immediate direct ingress from any free XOR of actual receiver stock; all other paid routes and input/output targets fixed. Excludes other pulse timings, distinct betas, additional routes or coordinated word edits. Not a clean physical supplier or kappa result.'},indent=2,sort_keys=True))
