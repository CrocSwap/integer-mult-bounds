#!/usr/bin/env python3
"""Cold replay and independent byte-corruption controls."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import shutil
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def run(root, *args):
    return subprocess.run([sys.executable,*args,str(root/'check.py')],cwd=root,
                          stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)


def main():
    expected=(HERE/'RESULT.json').read_bytes()
    rejected=[]
    with TemporaryDirectory(prefix='p104-r6-19-cold-') as tmp:
        root=Path(tmp)/'packet'
        shutil.copytree(HERE,root,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        for flags in [('-I','-B'),('-I','-B','-O')]:
            p=run(root,*flags)
            if p.returncode or p.stdout!=expected:
                raise ValueError('cold replay or optimized execution differs: '+p.stderr.decode(errors='replace'))
        for relative in ('inputs/WORD.json.gz','inputs/EFREE-CALLER.json.gz','upstream/ternary_leaf.py'):
            path=root/relative
            saved=path.read_bytes()
            damaged=bytearray(saved); damaged[len(damaged)//2]^=1
            path.write_bytes(damaged)
            p=run(root,'-I','-B')
            if not p.returncode or ('source '+relative).encode() not in p.stderr:
                raise ValueError('corrupted input was not source-rejected: '+relative)
            path.write_bytes(saved)
            rejected.append(relative)
    print(json.dumps({'status':'PASS_CLEAN_NORMAL_AND_OPTIMIZED_REPLAY',
                      'source_corruptions_rejected':rejected},indent=2,sort_keys=True))


if __name__=='__main__':
    main()
