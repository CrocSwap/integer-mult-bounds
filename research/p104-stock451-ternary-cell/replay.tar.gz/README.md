# A ternary cell inside one labelled 451-factor paid path

**Result: a real local cell admits the pinned three-local frame and leaf
operations, and the first paid slab has a symbolic partition into copies of
that cell and one singleton.** The checks do not supply the whole 451-factor
physical compiler, cover, stock invoice, erasure, seven-stage recurrence,
precision tape, integer recovery or a new κ. The cell partition is an ordered
coordinate statement; it is not an allocation or an execution of all cells.

The sources are [#7863 at `b3e4412fe01f07dc58305616fabf96345f49a781`](https://github.com/CrocSwap/integer-mult-bounds/pull/7863),
[#7914 at `46783fbbfc219a3faffbea76f60a2810b85ab75a`](https://github.com/CrocSwap/integer-mult-bounds/pull/7914),
and its pinned three-local predecessor [#7868 at `3f7c3c1f2a9a0963736562037e01fe41aec46b8c`](https://github.com/CrocSwap/integer-mult-bounds/pull/7868).
The copied three-local source bytes match #7914's predecessor source manifest.
The results in Round 5 streams 19, 11 and 20 are distinct parent controls:
the interface mismatch, finite zero escrow, and independent arithmetic
replay are not requalified by this local construction.

## The actual labelled path and its ownership

Authenticate the original graph and caller. The source has 107,460 distinct
paid tags. Use the actual tag `(move, 4, 2569, 1402)` as factor 0. Caller
event 4 is `LOCAL` on stage 1, root roles 1 and 0. The literal native word
initializes bank 1402 at chart 136 at clock 2567, adds from bank 775 at
2568, and moves 136 → 399 at 2569. Its rank is 6 − 2 = 4. Its later CLEAR
at 40806 is only a literal source event, not a reversible erasure proof.

Factors 1 through 450 each have the actual tag `(IDLE_ONE, 91, 0)`, which
addresses root 8, port 0 and stages `[8, 9]`. The two stage ranges are
57–63 and 64–70 on the 134-axis caller frame, so its rank is 14. Factor
indices are part of the physical identity: the 450 instances with equal
source labels are on different tensor factors, not aliases. The two
coordinates 57 and 58 selected below are distinct coordinates of **one**
root/port at factor 450, not two separately allocated root owners.

The ordered path has raw rank `4·14^450`. The uniform paid cap is `11^451`;
the retained productive floor is separately `16^451`. In the first paid
slab the selected axes have mixed-radix ordinal `0 ≤ j < 11^451`. Since the
exact integer inequality `11^451 < 14^450` holds, every such ordinal uses the
first of the MOVE's four selected frame lines. Split the 14 last-factor
coordinates into adjacent ordered pairs. As `11^451 ≡ 11 (mod 14)`, the
full slab partitions into `(11^451 − 1)/2` such two-coordinate cells and one
singleton: in the final partial 14-coordinate block it is axis 67. The
earlier 449 idle factors specify the prefix and keep their individual factor
identities. No cell enumeration is required for that integer partition.

The explicit checked cell fixes all 449 preceding idle coordinates to 57,
and uses final-factor coordinates 57 and 58. Its slab ordinals are exactly
0 and 1. The logical partition uses the same identity-frame construction for
the remaining idle coordinate pairs, including pairs spanning the two idle
stages. It does not show that a single global stock route can service them,
nor that independently stocked cell covers would fit the 451 invoice.

## Actual rational projector and local embedding

Construct the exact projectors of charts 136 and 399 from the source bases.
Their determinants are both 16, hence units at 3. They nest in both orders;
their difference is an exact rational idempotent of rank 4 over `F_3`. Its
three-local image/kernel frame `F` has determinant `1/64`. Splitting its first
image line from the other three gives an exact idempotent with entries `1/2`
at `(0,0)`, `(0,6)`, `(6,0)`, `(6,6)` and zero elsewhere. Its rank and the
rank of the remaining image are respectively 1 and 3 over `F_3`; their
products in both orders vanish. All projector, frame, inverse, and elementary
gate denominators are 3-units, as are the numerators of all gate scalings.
The ordered frame has 29 actual elementary gates; both its action and inverse
are checked against dense rational multiplication modulo 3, 9 and 27.

Tensor that first image line with the two selected idle coordinates. In the
explicit 8-by-2 factor slice, these give two orthogonal rank-one summands of
an actual rank-two subspace. The other 14 slice axes form the complete
complement. For every `g ∈ GL₂(F₃)` the checker embeds `g` by conjugating a
two-axis block through `F ⊗ I₂`, verifies both ambient inverse directions,
proves the exterior is fixed, and checks that the two transformed rank-one
idempotents remain disjoint and sum to the same selected cell. The first
factor's other 126 caller coordinates, the other 449 factors and the rest of
the powered ambient are formal exterior coordinates here, not a materialized
full-rank matrix or an executed all-spectator route.

## Complete small ternary cover and returns

There are `|GL₂(F₃)| = 48` regular low matrices. For width `w=2` each low has
`3^(2²) = 81` complete high matrices, giving 3,888 matrices over `Z/9`.
For each, the code independently obtains the two factors of the conjugated
rank-one projector and compares the pinned ternary leaf with its direct
linear formula on all eight basis vectors of two independent width-two
head/tail fields: 31,104 comparisons. It also verifies nonzero input and
changed-return controls. For each actual low type the pivot class is fixed by
the low digits: 28 leading and 20 nonleading types, i.e. 2,268 and 1,620
full-ring matrices. The chosen pinned lowering issues respectively one or
nine complete width-two child calls. One leaf for every matrix would therefore
issue 16,848 such child calls. These are counts for this tiny implementation,
not a lower bound or the total 451 cost. Its head/tail fields are the local
leaf's distinct test roles; the test does not claim that their required full
campaign banks or escrow have been allocated.

The actual 29-gate MOVE frame also contains `column 6 += (3/4)·column 2`.
This is a separate two-coordinate restriction of that real frame gate, not
the same coordinates as the idle cell. Its low action is the identity while
its high action is not. A complete high-fibre check routes all 3,888 records
and restores them after two independent values have changed, retaining both
coordinate labels and an opaque nonzero spectator marker. Discarding the
carry would misplace every record. This is an exhaustive test of the gate's
two-coordinate high fibre, not the complete 8-dimensional frame route.

## What the three-local pivot incidence says

For a uniformly indexed regular low `g ∈ GLₙ(F₃)`, write the conjugated
rank-one projector as `u vᵀ`, with `u = g e₁`, `vᵀ = e₁ᵀ g⁻¹` and
`vᵀu = 1`. A fixed leading pivot is bad exactly when `u₁v₁ = 0`. There are
`(3ⁿ−1)3ⁿ⁻¹` possible `(u,v)` pairs, each occurring equally often in
`GLₙ`. Count bad pairs by `u₁=0` and by `u₁≠0, v₁=0`; for `n ≥ 2` the
fraction is

```
5(3^(n−1) − 1) / (3(3^n − 1)),  which tends to 5/9.
```

The checker independently enumerates all `GL₂` and `GL₃` lows, yielding
`20/48 = 5/12` and `5760/11232 = 20/39` bad respectively. A nonleading
pivot still exists because a rank-one idempotent has trace one. This fixed
leading-pivot incidence cannot be treated as the very small large-prime
surcharge in the #7863 certificate. It is not a proof that the ternary
construction fails: the pinned ternary leaf handles nonleading pivots, and
the actual global incidence, selector, chronological and stock prices must
be proved for the 451 compiler rather than inferred from a local count.

## Reproduction

With Python 3.10+ and the standard library, from this directory:

```
sha256sum -c SHA256SUMS
python3 -I -B check.py > /tmp/p104-r6-19-check.json
cmp RESULT.json /tmp/p104-r6-19-check.json
python3 -I -B verify.py
```

`verify.py` repeats the result in a clean temporary copy, tests optimized
Python, and separately corrupts the graph, caller and local leaf bytes. It
performs no network or IntegerGraph writes. `RESULT.json` records exact
counts and rejected identity, rank/denominator, and owner controls.
