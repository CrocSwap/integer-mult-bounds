#!/usr/bin/env python3
"""A source-bound 451-path cell; not a full 451-factor construction."""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import product
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
PINS = {
    "inputs/WORD.json.gz": "d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9",
    "inputs/EFREE-CALLER.json.gz": "757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b",
    "inputs/BIT-451.json": "538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749",
    "upstream/ternary_frames.py": "ffe3dfc1098fadba9f17ecb4d8338d07d78a73e1bf202def81312780345f3976",
    "upstream/factored_frames.py": "5c43c3f3fb6369cbd5a9010fb5d1729fd01df9f9f7a61702245eebbf5bbec6a8",
    "upstream/ternary_leaf.py": "9c1a6f841d29c32fb75bc243b4e2091a24f55e2fdc3f74ee0caa7a346d72e44b",
    "upstream/vendor/cover.py": "52cfdb73f0289b1d2fd015865104dc66ecb7478eef2dbe3d48325791cea7b786",
}


def need(condition, label):
    if not condition:
        raise ValueError(label)


for filename, digest in PINS.items():
    need(sha256((HERE / filename).read_bytes()).hexdigest() == digest, "source " + filename)
sys.path.insert(0, str(HERE / "upstream"))
from ternary_frames import frame_at_three, identity, inverse, multiply, projector, residue, transpose
from ternary_leaf import run_leaf, select_pivot
from factored_frames import apply_row, inverse_word, move_cover
from vendor.cover import row_program


def canonical(x):
    return sha256(json.dumps(x, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def rank_mod(m, q):
    a = [[residue(v, q) for v in row] for row in m]
    h, w, r = len(a), len(a[0]), 0
    for c in range(w):
        pivot = next((i for i in range(r, h) if a[i][c] % q), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        s = pow(a[r][c], -1, q)
        a[r] = [z * s % q for z in a[r]]
        for i in range(r + 1, h):
            z = a[i][c]
            a[i] = [(x - z * y) % q for x, y in zip(a[i], a[r], strict=True)]
        r += 1
        if r == h:
            break
    return r


def det(m):
    a = [[Fraction(x) for x in row] for row in m]
    d = Fraction(1)
    for j in range(len(a)):
        i = next((i for i in range(j, len(a)) if a[i][j]), None)
        if i is None:
            return Fraction(0)
        if i != j:
            a[i], a[j] = a[j], a[i]
            d = -d
        pivot = a[j][j]
        d *= pivot
        for i in range(j + 1, len(a)):
            fac = a[i][j] / pivot
            for k in range(j + 1, len(a)):
                a[i][k] -= fac * a[j][k]
    return d


def matadd(a, b):
    return [[x + y for x, y in zip(ar, br, strict=True)] for ar, br in zip(a, b, strict=True)]


def matsub(a, b):
    return [[x - y for x, y in zip(ar, br, strict=True)] for ar, br in zip(a, b, strict=True)]


def mm(a, b, q):
    bt = list(zip(*b, strict=True))
    return [[sum(x*y for x, y in zip(ar, bc, strict=True)) % q for bc in bt] for ar in a]


def red(a, q):
    return [[residue(x, q) for x in row] for row in a]


def kron(a, b):
    return [[a[i][j] * b[k][l] for j in range(len(a[0])) for l in range(len(b[0]))]
            for i in range(len(a)) for k in range(len(b))]


def assert_local(f):
    for row in f:
        for x in row:
            need(Fraction(x).denominator % 3 != 0, "non-three-local denominator")


def must_reject(label, f):
    try:
        f()
    except (ValueError, ZeroDivisionError):
        return label
    raise ValueError("failed to reject " + label)


def require_binding(g, c, move_tag, idle_tag, idle_axes):
    need(move_tag == ("move", 4, 2569, 1402), "MOVE owner tag")
    need(idle_tag == ("IDLE_ONE", 91, 0), "IDLE owner tag")
    need(c["events"][4] == ["LOCAL", 1, 1, 0], "actual LOCAL event")
    need(c["events"][91] == ["IDLE_ONE", 8, [8, 9]], "actual IDLE event")
    need(g["program"][2567:2570] == [["INIT", 1402, 136], ["ADD", 1402, 775, 136],
                                     ["MOVE", 1402, 136, 399]], "MOVE chronology")
    need(g["program"][40806] == ["CLEAR", 1402, 399], "MOVE owner lifetime")
    need(all(row[1] != 1402 and not (row[0] == "SWAP" and row[2] == 1402)
             for row in g["program"][2570:40806]), "owner destination reassigned")
    stages = c["events"][91][2]
    axes = tuple(i for stage in stages for i in range(1 + 7 * stage, 1 + 7 * (stage + 1)))
    need(len(set(idle_axes)) == 2, "coordinate alias")
    need(axes == tuple(range(57, 71)) and set(idle_axes) <= set(axes), "idle support")
    need(idle_axes == (57,58), "selected ordered idle coordinates")
    need(c["body_rank"] == 7 and c["stages"] == 18 and c["ports"] == 111, "caller dimensions")
    return axes


def require_factor_owners(owners):
    need(len(owners)==451, "factor count")
    need(len(set(owners))==451, "tensor factor owner alias")
    need(owners[0]==(0,("move",4,2569,1402)), "first tensor owner")
    need(all(owners[j]==(j,("IDLE_ONE",91,0)) for j in range(1,451)), "ordered idle owners")


def reference_leaf(u, v, weights, head, tail, mod):
    n, width = len(u), len(weights)
    h, t = [r.copy() for r in head], [r.copy() for r in tail]
    for j, a in enumerate(weights):
        x = [pow(a[i], -1, mod) * head[i][j] % mod for i in range(n)]
        y = [tail[n - 1 - i][width - 1 - j] for i in range(n)]
        d = sum(c * (r - l) for c, r, l in zip(v, y, x, strict=True)) % mod
        for i in range(n):
            h[i][j] = (head[i][j] + a[i] * u[i] * d) % mod
            t[n - 1 - i][width - 1 - j] = (y[i] - u[i] * d) % mod
    return h + t


def lows2():
    for a, b, c, d in product(range(3), repeat=4):
        if (a*d-b*c) % 3:
            yield [[a,b],[c,d]]


def inv2(g, m):
    a,b = g[0]
    c,d = g[1]
    t = pow((a*d-b*c) % m, -1, m)
    return [[d*t % m, -b*t % m], [-c*t % m, a*t % m]]


def native_source():
    graph = json.loads(gzip.decompress((HERE / "inputs/WORD.json.gz").read_bytes()))
    caller = json.loads(gzip.decompress((HERE / "inputs/EFREE-CALLER.json.gz").read_bytes()))
    receipt = json.loads((HERE / "inputs/BIT-451.json").read_text())
    need(canonical(graph) == "d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d", "canonical word")
    need(receipt["native"]["candidate_canonical_sha256"] == canonical(graph), "451 word binding")
    axes = require_binding(graph, caller, ("move",4,2569,1402), ("IDLE_ONE",91,0), (57,58))
    owners=[(0,("move",4,2569,1402))]+[(j,("IDLE_ONE",91,0)) for j in range(1,451)]
    require_factor_owners(owners)
    dims={int(k):v["dim"] for k,v in graph["frames"].items()}
    moves=[(i,row[1],abs(dims[row[2]]-dims[row[3]])) for i,row in enumerate(graph["program"]) if row[0]=="MOVE"]
    paid=[]
    for clock,event in enumerate(caller["events"]):
        if event[0]=="LOCAL":
            paid.extend((("move",clock,site,bank),rank) for site,bank,rank in moves)
        elif event[0] in ("IDLE_ONE","QUERY"):
            rank=1 if event[0]=="QUERY" else 7*len(event[2])
            paid.extend(((event[0],clock,port),rank) for port in range(caller["ports"]))
    need(len(paid)==107460 and len({tag for tag,_ in paid})==len(paid), "labelled paid census")
    need(dict(paid)[("move",4,2569,1402)]==4 and dict(paid)[("IDLE_ONE",91,0)]==14, "labelled ranks")
    frames = graph["frames"]
    x, y = frames["136"], frames["399"]
    need((x["dim"],y["dim"]) == (2,6), "native dimensions")
    bases = [transpose(f["B"] + f["A"]) for f in (x,y)]
    determinants = [det(b) for b in bases]
    need(all(d.denominator == 1 and d.numerator % 3 for d in determinants), "chart determinant")
    p, q = [projector(b, f["dim"]) for b, f in zip(bases, (x,y), strict=True)]
    need(multiply(p,q)==p and multiply(q,p)==p, "native nesting")
    delta = matsub(q,p)
    need(multiply(delta,delta)==delta and rank_mod(delta,3)==4, "native difference")
    assert_local(p); assert_local(q); assert_local(delta)
    frame, rank = frame_at_three(delta)
    need(rank == 4 and projector(frame,rank)==delta, "split frame rank")
    fi = inverse(frame)
    need(multiply(frame,fi)==identity(8) and multiply(fi,frame)==identity(8), "frame inverse")
    assert_local(frame); assert_local(fi)
    need(residue(det(frame),3) != 0, "frame determinant unit")
    line, rest = projector(frame,1), matsub(delta,projector(frame,1))
    need(multiply(line,line)==line and multiply(rest,rest)==rest, "native line idempotents")
    need(multiply(line,rest)==[[0]*8 for _ in range(8)] and multiply(rest,line)==[[0]*8 for _ in range(8)], "native line disjoint")
    need(rank_mod(line,3)==1 and rank_mod(rest,3)==3, "native split ranks")
    need(delta[0][0] == Fraction(1,2) and line[0][6]==Fraction(1,2), "actual rational line")
    word = row_program(frame,3)
    reverse = tuple(inverse_word(word))
    for op in word + reverse:
        if op[0] in ("add","scale"):
            coeff = Fraction(op[-1]); need(coeff.denominator % 3, "gate denominator")
            if op[0] == "scale": need(coeff.numerator % 3, "scale must be a unit")
    need(("add",6,2,Fraction(3,4)) in word, "source frame carries gate")
    for modulus in (3,9,27):
        for row in identity(8):
            placed=apply_row(word,row,modulus)
            need(len(placed)==8, "frame action shape")
            need(placed == red(multiply([row],frame),modulus)[0], "frame action")
            need(apply_row(reverse,placed,modulus)==row, "frame reverse")
    raw = 4 * 14**450
    cap = 11**451
    nq, nr = divmod(raw,cap)
    need(nq and nr and 1 < cap, "slab boundaries")
    need(str(nq + bool(nr)) == "49155830744717520350444760920956767143210254601", "451 slab count")
    need(16**451 > cap, "productive floor separate from paid cap")
    need(cap < 14**450 and cap % 14 == 11 and cap % 2 == 1, "first slab factor and tail")
    # The slab is the first move-image line with 449 free selected idle prefixes.
    # Even last-axis radix 14 makes every consecutive pair lie in one prefix block.
    # The final 11-axis partial block has five pairs and one unpaired coordinate.
    full14,partial=divmod(cap,14)
    need(full14*7 + partial//2 == (cap-1)//2 and partial==11, "symbolic pair partition")
    for i in (0,2,12,14,cap-3):
        need(i % 2 == 0 and i+1 < cap and i//14==(i+1)//14, "paired cell shape")
    need((cap-1)%14==10, "final singleton idle axis 67")
    # In mixed radix (4,14,...,14), first 450 digits are zero; the last is 0 or 1.
    for last in (0,1):
        offset = 0
        for digit,radix in zip([0]*450+[last], [4]+[14]*450, strict=True):
            need(0 <= digit < radix, "path digit")
            offset = offset*radix + digit
        need(offset == last and offset < cap, "source slab incidence")
    return graph,caller,axes,delta,frame,fi,line,word,determinants,nq+1,owners


def embedding(delta, frame, fi, line):
    t, ti = red(kron(frame,identity(2)),3), red(kron(fi,identity(2)),3)
    eye = identity(16)
    need(mm(t,ti,3)==eye and mm(ti,t,3)==eye, "16-axis basis")
    c0=red(kron(line, [[1,0],[0,0]]),3)
    c1=red(kron(line, [[0,0],[0,1]]),3)
    c=red(matadd(c0,c1),3)
    original=red(kron(delta,identity(2)),3)
    zero=[[0]*16 for _ in range(16)]
    need(mm(original,c,3)==c and mm(c,original,3)==c, "contained in actual MOVE image")
    need(rank_mod(c,3)==2 and rank_mod(c0,3)==rank_mod(c1,3)==1, "actual cell ranks")
    need(mm(c0,c1,3)==zero and mm(c1,c0,3)==zero, "independent cell lines")
    for g in lows2():
        a, ai=identity(16),identity(16)
        gi=inv2(g,3)
        for i in range(2):
            for j in range(2): a[i][j],ai[i][j]=g[i][j],gi[i][j]
        s=mm(mm(t,a,3),ti,3); si=mm(mm(t,ai,3),ti,3)
        need(mm(s,si,3)==eye and mm(si,s,3)==eye, "ambient inverse")
        need(mm(s,c,3)==mm(c,s,3), "cell ownership")
        comp=red(matsub(eye,c),3)
        need(mm(s,comp,3)==comp and mm(comp,s,3)==comp, "untouched exterior")
        p0=mm(mm(s,c0,3),si,3); p1=mm(mm(s,c1,3),si,3)
        need(red(matadd(p0,p1),3)==c, "complete return of cell")
        need(mm(p0,p0,3)==p0 and mm(p1,p1,3)==p1, "covered projectors")
        need(mm(p0,p1,3)==zero and rank_mod(p0,3)==rank_mod(p1,3)==1, "covered rank and disjointness")


def exhaustive_leaf():
    weights=[[1,2],[4,8]]
    counts=Counter()
    # Eight independent input basis vectors span all two-column head/tail inputs.
    for low in lows2():
        for digits in product(range(3), repeat=4):
            g=[[low[i][j]+3*digits[2*i+j] for j in range(2)] for i in range(2)]
            gi=inv2(g,9)
            u=[g[0][0],g[1][0]]; v=gi[0]
            need(sum(x*y for x,y in zip(u,v,strict=True))%9 == 1, "ring incidence")
            proj=[[u[i]*v[j]%9 for j in range(2)] for i in range(2)]
            need(mm(proj,proj,9)==proj and rank_mod(proj,3)==1, "ring projector")
            pivot=select_pivot(u,v)
            need(pivot in (0,1), "live pivot")
            counts["leading" if pivot == 0 else "nonleading"] += 1
            for k in range(8):
                data=[[0,0] for _ in range(4)]
                data[k//2][k%2]=1
                got, calls=run_leaf(u,v,weights,data[:2],data[2:],2)
                need(got==reference_leaf(u,v,weights,data[:2],data[2:],9), "leaf basis action")
                need(calls==(2,)*(1 if pivot==0 else 9), "full-width child accounting")
                counts["basis_vectors"] += 1
            data=[[1,2],[3,4],[5,6],[7,8]]
            got,_=run_leaf(u,v,weights,data[:2],data[2:],2)
            restored,_=run_leaf(u,v,weights,got[:2],got[2:],2)
            need(restored==data, "nonzero independent inputs restore")
            # Two independently changed return coordinates are preserved as inputs to the inverse.
            changed=[r.copy() for r in got]
            changed[0][0]=(changed[0][0]+1)%9
            changed[3][1]=(changed[3][1]+2)%9
            returned,_=run_leaf(u,v,weights,changed[:2],changed[2:],2)
            need(returned==reference_leaf(u,v,weights,changed[:2],changed[2:],9), "changed child return")
    need(counts["leading"]==28*81 and counts["nonleading"]==20*81, "GL2 pivot incidence")
    need(counts["basis_vectors"]==48*81*8, "complete leaf bases")
    return counts


def routed_carry():
    # This gate occurs in the actual eight-axis MOVE frame, with coordinates 2,6.
    w=(("add",1,0,Fraction(3,4)),)
    reverse=tuple(inverse_word(w))
    label=0
    for low in lows2():
        records=[]; direct=[None]*81
        for h in product(range(3),repeat=4):
            idx=((h[0]*3+h[1])*3+h[2])*3+h[3]
            g=[[low[i][j]+3*h[2*i+j] for j in range(2)] for i in range(2)]
            moved=[apply_row(w,row,9) for row in g]
            need([[z%3 for z in row] for row in moved]==low, "zero low action")
            hs=[z//3 for row in moved for z in row]
            dest=((hs[0]*3+hs[1])*3+hs[2])*3+hs[3]
            need(dest != idx and direct[dest] is None, "nonzero carry and one-to-one route")
            record=("factor450/root8/port0/axis57", "factor450/root8/port0/axis58", label, idx,
                    (idx*5+1)%9, (idx*7+2)%9, ("opaque-spectator", label, idx, (idx+label+1)%9))
            records.append(record); direct[dest]=record
        out_low,got=move_cover(records,low,w,2)
        need(out_low==low and got==direct, "complete actual-gate high fibre")
        # Keep opaque owner identities while both independent values change in flight.
        changed=[(x[0],x[1],x[2],x[3],(x[4]+1)%9,(x[5]+2)%9,x[6]) for x in got]
        back_low,back=move_cover(changed,out_low,reverse,2)
        expected=[(x[0],x[1],x[2],x[3],(x[4]+1)%9,(x[5]+2)%9,x[6]) for x in records]
        need(back_low==low and back==expected, "owner-labelled changed return")
        label+=1
    need(label==48, "all low types")
    return 48*81


def incidence3():
    count=Counter()
    for v in product(range(3),repeat=9):
        a,b,c,d,e,f,g,h,i=v
        determinant=(a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g))%3
        if determinant:
            bad=(a*(e*i-f*h))%3==0
            count["nonleading" if bad else "leading"]+=1
    need(count=={"leading":5472,"nonleading":5760}, "GL3 exact incidence")
    return count


def main():
    g,c,axes,delta,frame,fi,line,word,dets,slabs,owners=native_source()
    controls=[
        must_reject("wrong equal-grade MOVE owner",lambda: require_binding(g,c,("move",4,2584,1406),("IDLE_ONE",91,0),(57,58))),
        must_reject("wrong idle port",lambda: require_binding(g,c,("move",4,2569,1402),("IDLE_ONE",91,1),(57,58))),
        must_reject("aliased selected coordinates",lambda: require_binding(g,c,("move",4,2569,1402),("IDLE_ONE",91,0),(57,57))),
        must_reject("outside selected idle axes",lambda: require_binding(g,c,("move",4,2569,1402),("IDLE_ONE",91,0),(57,71))),
        must_reject("aliased tensor factor",lambda: require_factor_owners(owners[:-1]+[owners[-2]])),
        must_reject("non-three-local denominator",lambda: assert_local([[Fraction(1,3)]])),
        must_reject("singular low cover",lambda: inv2([[1,1],[1,1]],3)),
    ]
    embedding(delta,frame,fi,line)
    leaf=exhaustive_leaf()
    routed=routed_carry()
    inc3=incidence3()
    print(json.dumps({
        "status":"PASS_LABELLED_LOCAL_CELL_ONLY",
        "source_word_sha256":canonical(g),
        "labelled_path":{"move":["move",4,2569,1402],"move_charts":[136,399],"move_rank":4,
            "idle":["IDLE_ONE",91,0],"idle_root":8,"idle_stages":[8,9],"idle_rank":14,
            "idle_factors":450,"idle_axes":list(axes),"fixed_idle_coordinates":449,
            "last_cell_axes":[57,58],"first_slab_offsets":[0,1],"cap":"11^451",
            "slabs":str(slabs),"productive_floor":"16^451",
            "first_slab_move_image_line":0,"first_slab_pair_cells":"(11^451 - 1)/2",
            "final_singleton_idle_axis":67,
            "partition_scope":"logical ordered coordinates, no physical stock allocation"},
        "native_frame":{"chart_determinants":[str(x) for x in dets],"frame_determinant":str(det(frame)),
            "difference_rank_mod3":4,"line_rank_mod3":1,"complement_rank_mod3":3,
            "selected_line_nonzero_entries":"1/2 at (0,0), (0,6), (6,0), (6,6)",
            "elementary_gates":len(word),"gate_with_real_carry":"column 6 += (3/4) column 2"},
        "small_cell":{"ambient_raw_axes":16,"selected_cell_rank":2,"split_ranks":[1,1],
            "independent_ambient_spectators":14,"low_matrices":48,"high_matrices_per_low_at_w2":81,
            "full_ring_matrices":48*81,"leading_pivot_at_w2":leaf["leading"],
            "nonleading_pivot_at_w2":leaf["nonleading"],"linear_basis_tests":leaf["basis_vectors"],
            "child_calls_for_one_width_two_job_per_matrix":leaf["leading"]+9*leaf["nonleading"],
            "complete_actual_gate_high_records":routed,
            "scope":"local rank-one split; not all 451 path slabs or stock"},
        "incidence":{"GL2_good_bad":[28,20],"GL3_good_bad":[inc3["leading"],inc3["nonleading"]],
            "bad_fraction_GL2":"5/12","bad_fraction_GL3":"20/39",
            "bad_fraction_general_n_ge_2":"5*(3^(n-1)-1)/(3*(3^n-1))",
            "limit":"5/9","warning":"leading-pivot frequency is not the total 451 recurrence price"},
        "controls_rejected":controls,
        "limitations":["no complete 451 slab traversal or powered chronology", "no full matrix-stock or all-spectator physical route",
                       "no paid-tariff or split overhead proof for the full supplier", "no seven-stage or completed seed construction",
                       "no owned erasure, precision tape, analytic recovery or new kappa"]
    },indent=2,sort_keys=True))


if __name__=="__main__":
    main()
