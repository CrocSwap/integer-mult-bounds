# Replay chart-268 BIT repairs and prove their missing information

Compile two changed old-component words routing owner 679 through 785, 1584 and 1934. The second restores readers 1585 and 1586. Both orientations return the new owner, but the full words still fail 104/29 and 89/29 forward/adjoint outputs, respectively.

The two frozen words need exactly three and two free common binary messages to repair their complete forward outputs, even with nonlinear broadcast. Separately, the exact native-clock 176-slot family leaves owner 221 unknowable in the last two source-space survivors. Its last chart-635 arrival at 19907 precedes the retargeted 3409 arrival at 19913. The remaining funded local C+D and old-donor branch tests also fail.

Change or reroute the independent old 1584 direction in time, or enlarge the productive model. The diagnostic positive tariff does not supply a legal word, physical compiler or qualified outer application.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. Each inner archive passed a cold replay. Both 680-row operators, both complete signed invoices, 131,072 local assignments, 183 relaxed and 34 strict ingress checks, exact broadcast lower/upper controls, and an independent replay of the 176-slot partition passed with source and retiming controls.
