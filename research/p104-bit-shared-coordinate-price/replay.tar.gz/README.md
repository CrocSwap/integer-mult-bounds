# One shared physical body axis in the paired BIT caller

**No gain in this fixed-coordinate family.** Overlapping one physical body
coordinate in stages 9 and 10 changes 222 independent root outputs from
grade 127 to grade 125. It does not change a paid occurrence in this case.
At κ = `0.003879928046156`, the full signed margin changes by
`−434.05562887581880245945`; at κ = `0.003879929046155` it changes by
`−434.05562634086425909208`. This is an exact directed-interval price screen
of the pinned #7830 caller, not a changed supplier, an admitted κ bound, or
an independent proof of the inherited physical and compiler assumptions.

The first condition that defeats the tempting construction is physical:
**the shared selector cancels in the product**. Two seven-dimensional
coordinate bodies with a one-dimensional intersection have a 13-dimensional
union, but their two actual swaps compose to a rank-12 swap. The proof below
also prices the resulting exact outputs. The test then covers all 153 pairs
of the 18 stages under the same single-coordinate overlap rule; all 153 have
strictly negative signed changes at both trial values, with the stage 9/10
change tied for best by 81 pairs. No claim is made about arbitrary oblique
projectors, noncommuting selectors, changed caller forms, or overlapping more
than one coordinate.

## Physical identity and dimensions

Keep the common head coordinate and all other body coordinates fixed. Choose
one physical body coordinate that is shared by the selected two stage
bodies, and take the remaining six coordinates of each to be distinct.
The coordinate projections `P9` and `P10` then commute, and
`P9 P10 = E`, the projection to that one shared coordinate. On the two
complete address chunks, a partial interchange is

```
S(P) = [[I − P, P], [P, I − P]].
```

These matrices act on address coordinates over the retained odd-prime
residue ring; they are not being reduced modulo two. Exact multiplication
gives

```
S(P9) S(P10) = S(P9 + P10 − 2E).
```

The projection on the right selects the **symmetric difference** of the two
bodies: six exclusive axes from each stage, for rank 12. In contrast the
13-axis union projector is `P9 + P10 − E`. Their operators differ by the
nontrivial shared swap `S(E)`. They agree neither as rational address maps nor
on arbitrary complete fields. The 6,561-address ternary fixture in
`check.py` enumerates every address in a smaller model, proves the same
identity, exhibits a failed-union witness, and distinguishes the two
binary-field difference ranks 2916 and 3159. This fixture illustrates the
general coordinate identity; it is not an exhaustive 126-axis replay.

For a residue ring of size `m > 1`, two chunks of `a` address coordinates
contain `m^(2a)` addresses. A rank-r selector fixes `m^(2a−r)` addresses;
its induced binary-field operator has
`rank(I + S) = (m^(2a) − m^(2a−r))/2`. Thus the selector grade r, the
dimension `a` of the address ambient, and the operator's value-space rank
are different quantities. Tensor power preserves the product identity:
`(S(P9) S(P10))^⊗f = S(P9)^⊗f S(P10)^⊗f`.

Each native call still acts on one head plus its own seven body directions,
an 8-dimensional local interface. Both selected bodies remain 7-dimensional
and disjoint from the common head; their other stage's six exclusive axes
are spectators while that call runs. The shared coordinate is active again
at the later call, and is not treated as its spectator. This use on an
already populated coordinate relies on the retained arbitrary-input,
all-column native interface. Each of the four stage-9/10 native calls is
still a complete separate call: they contain 11,496 separately paid native
positions and 1,832 independent helper targets altogether. Their local
embedding is injective, so the original paid and helper grades are unchanged.
Each has its own 3,554 private owned labels; the original 3,554 dirty
retirements per call and direction are not combined or treated as free.

The body union of all 18 stages now has dimension 125; with the head, the
principal ambient has dimension 126 instead of 127. Its two-chunk coordinate
domain has `m^252` rather than `m^254` addresses before other spectators. A
matching conservative working count is `8 + 125 = 133` axes instead of
`8 + 126 = 134`, if the retained eight native working coordinates and the
same embedding contract are used. For 480 chronological factors, that
suggests a cap `133^480`; it is a dimension count, not a recompiled finite
certificate or a claim that the old cutoff and stock proof automatically
work on the changed word. No price credit is taken for the smaller ambient.

## Polynomial identity versus physical selection

The original caller identity is checked in
`F₂[q,D1,…,D18]/(q²−1)`, where the `D` variables are formally free. It
therefore remains valid after substituting commuting physical partial swaps;
it does **not** say that the physical substitutions are algebraically
independent. In the physical image each `D_s² = I`, so the polynomial map is
not injective. No body involution was needed to prove the original identity.

There is a narrower independence statement: because each body still has at
least six private axes, the 18 physical stage selectors together with the
head have rank 19 as vectors over `F₂`. A complete-address orbit with a
nonzero difference on one private axis of each stage and on the head is a
free orbit of these 19 involutions. Thus their square-free group elements
are distinguishable on arbitrary complete fields. That independence does
not turn the overlapping physical axes into 14 separate axes: the shared
axis is switched twice in `D9 D10` and cancels.

The checker independently specializes the 798-event caller into physical
axis masks and checks all 1,444 coefficients both forward and adjoint for
stages 9/10. It also checks the source's forward and reverse formal
polynomial identities separately. These are exact operator and accounting
checks within the retained frame/interface theorem; they are not a new
address-level proof of native all-column realization or owned erasure.

## Caller and complete price

The affected native events are zero-based clocks 100, 101, 394, and 395.
None of the 32 `IDLE_ONE` stage sets includes both 9 and 10. Exactly two
root roles, 0 and 19, use both stages, and each represents 111 independently
owned ports. Their product is the head plus the symmetric difference of all
18 bodies, so its physical grade is `1 + 126 − 2 = 125`. Every other root,
all four QUERYs, the native moves, and the native helper targets retain their
source grade. There are still 107,460 separate paid positions and 20,706
productive fields; rank surplus changes from 1,506 to 1,062.

Let `H(r) = r^(1−κ)`. The complete signed change is

```
222 H(125) − 222 H(127).
```

| κ | Complete old signed margin | Change | Complete new signed margin |
| --- | ---: | ---: | ---: |
| 0.003879928046156 | −0.00000000076700150243 | −434.05562887581880245945 | −434.05562887658580396188 |
| 0.003879929046155 | −0.00038512731661386644 | −434.05562634086425909208 | −434.05601146818087295852 |

Outward intervals and the complete changed bins are in `RESULT.json`.
If each affected output is explicitly corrected with its own paid rank-1
shared-axis swap, that output becomes grade 126, not grade 127. This
particular repair costs 222 grade-1 jobs and changes the complete signed
price by `222 H(126) − 222 H(127) − 222 H(1)`: approximately
`−439.02447292536485` and `−439.02447165704586` at the respective trials.
This is the price of the specified separate-owner repair, not a lower bound
on every possible changed caller or a joint multi-owner construction.

For every other stage pair, the checker rederives the actual selected axes
of every idle as well as every root, uses the entire #7830 source bill, and
prices each changed incidence once. It verifies 153/153 strict losses and
proves by directed interval comparison that the 81 cross-half pairs attain
the same best loss as 9/10. The source caller's formal identity and the
coordinate group law justify substitution for those pairs; a separate
all-address native/adjoint replay is not claimed for them.

## Reproduce and provenance

Run from this directory with CPython 3.12:

```
sha256sum -c SHA256SUMS
python3 -I -B check.py > RESULT.actual.json
cmp RESULT.json RESULT.actual.json
```

`RESULT.actual.json` is a disposable replay output. All required inputs and
engines are included at relative paths; no network access or external workspace
is required. [SOURCES.json](SOURCES.json) records immutable source paths, Git
blobs and SHA-256 hashes.

The checker authenticates its copied inputs and source engines, independently
replays all `680²` native scalar coefficients and the original caller in each
direction, rebuilds the complete paid/target histograms, evaluates the
finite ternary control, and uses outward integer-square-root bounds for both
trial prices. The source is [#7830 at
87fbf4f](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier),
using its pinned native word and
[paired E-free caller](https://github.com/aliromman/integer-mult-bounds/tree/4f7c67ae387cc91580f469aeda4d508b372b9ec1/research/paired-query-only-bit).
The accompanying NOTICE preserves predecessor attribution. This local screen
was prepared with OpenAI Codex assistance; no independent human review or
finite compiler, stock, precision/tape, or application replay is asserted.
