#!/usr/bin/env python3
"""Exact one-common-body-axis screen for the pinned paired BIT caller.

The geometry is a fixed coordinate intersection, with the head and every
other body direction fixed. It is not a search over arbitrary caller words.
"""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import combinations, product
from math import isqrt
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'vendor'))
import binary_operator as native
import paired_check
import paired_audit

PINS = {
    'inputs/WORD.json.gz': 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
    'inputs/EFREE-CALLER.json.gz': '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
    'inputs/BIT.json': '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
    'vendor/paired_check.py': '460ed9a77d66264b00c31d0a7f8dab1db9aab21ec4cc0eaf0452bd4be4ef585e',
    'vendor/paired_audit.py': 'bb6616dbf536acf10163b8fff65ebfa69d01dfdeda3c0ead388c03377361b298',
    'vendor/binary_operator.py': '36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349',
}
SAVINGS = ('0.003879928046156', '0.003879929046155')


def need(ok, why):
    if not ok:
        raise AssertionError(why)


def read(name):
    raw = (HERE / name).read_bytes()
    return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)


def axis_masks(pair=None):
    # Stage s has its own seven coordinate axes, except for one identified
    # axis in exactly the selected pair. Coordinate zero is the fixed head.
    groups = {s: list(range(1 + 7 * (s - 1), 1 + 7 * s)) for s in range(1, 19)}
    if pair:
        a, b = pair
        groups[b][0] = groups[a][0]
    return {s: sum(1 << i for i in axes) for s, axes in groups.items()}


def body_product(stages, masks):
    answer = 0
    for s in stages:
        answer ^= masks[s]
    return answer


def group_rank(masks):
    pivots = {}
    for vector in masks:
        while vector:
            p = vector.bit_length() - 1
            if p in pivots:
                vector ^= pivots[p]
            else:
                pivots[p] = vector
                break
    return len(pivots)


def physical_operator(caller, masks, reverse=False):
    # Group-ring coefficients are bitsets of source roles. A physical stage
    # partial interchange is an involution, so composing selected coordinate
    # sets is XOR, not ordinary set union.
    rows = [{0: 1 << i} for i in range(caller['roles'])]
    def shift(poly, axes):
        return {k ^ axes: v for k, v in poly.items()}
    def add(first, second):
        out = first.copy()
        for key, value in second.items():
            value ^= out.get(key, 0)
            if value:
                out[key] = value
            else:
                out.pop(key, None)
        return out
    events = reversed(caller['events']) if reverse else caller['events']
    for op, *args in events:
        if op in ('ADD', 'QUERY'):
            dst, src = args[::-1] if reverse else args
            rows[dst] = add(rows[dst], shift(rows[src], 1 if op == 'QUERY' else 0))
        elif op == 'SWAP':
            a, b = args
            rows[a], rows[b] = rows[b], rows[a]
        elif op == 'LOCAL':
            stage, src, dst = args
            if reverse:
                src, dst = dst, src
            rows[dst] = shift(add(rows[dst], shift(rows[src], 1)), masks[stage])
            rows[src] = shift(rows[src], masks[stage])
        elif op == 'IDLE_ONE':
            a, stages = args
            rows[a] = shift(rows[a], body_product(stages, masks))
        else:
            raise AssertionError(op)
    return rows


@lru_cache(None)
def power(rank, saving):
    # Outward dyadic interval for rank**(1-saving), from successive roots.
    exponent = 1 - Fraction(saving)
    bits = 204
    scale = 1 << bits
    digits, remainder = divmod(exponent.numerator * scale, exponent.denominator)
    low = high = scale
    lower_root = upper_root = rank * scale
    for bit in range(bits - 1, -1, -1):
        lower_root = isqrt(lower_root * scale)
        square = upper_root * scale
        root = isqrt(square)
        upper_root = root + (root * root < square)
        if digits & (1 << bit):
            low = low * lower_root // scale
            high = (high * upper_root + scale - 1) // scale
    if remainder:
        high = (high * upper_root + scale - 1) // scale
    return Fraction(low, scale), Fraction(high, scale)


def moment(hist, saving):
    low = high = Fraction(0)
    for rank, count in hist.items():
        if count:
            a, b = power(rank, saving)
            low += count * (a if count > 0 else b)
            high += count * (b if count > 0 else a)
    return low, high


def decimal(interval, places=30):
    scale = 10 ** places
    lo, hi = interval
    values = (lo.numerator * scale // lo.denominator,
              -((-hi.numerator * scale) // hi.denominator))
    def one(value):
        sign = '-' if value < 0 else ''
        value = abs(value)
        return f'{sign}{value // scale}.{value % scale:0{places}d}'
    return [one(v) for v in values]


def hist_json(hist):
    return {str(k): v for k, v in sorted(hist.items()) if v}


def grade_mass(hist):
    return sum(rank * count for rank, count in hist.items())


def physical_fixture():
    # Two copies of four ternary coordinates: head, shared, unique9, unique10.
    # Enumerate every address. S(P) swaps the two coordinates selected by P.
    addresses = tuple(product(range(3), repeat=8))
    def swap(x, selected):
        y = list(x)
        for j in selected:
            y[j], y[4 + j] = y[4 + j], y[j]
        return tuple(y)
    h, a, b = {0}, {1, 2}, {1, 3}
    both = a ^ b
    union = a | b
    def changed(selected):
        return sum(x != swap(x, selected) for x in addresses) // 2
    for x in addresses:
        actual = swap(swap(x, a), b)
        need(actual == swap(x, both), 'composition equals symmetric difference')
    witness = next(x for x in addresses if swap(swap(x, a), b) != swap(x, union))
    count = len(addresses)
    need(changed(both) == (count - 3 ** (8 - len(both))) // 2, 'cycle rank')
    need(changed(union) == (count - 3 ** (8 - len(union))) // 2, 'union cycle rank')
    return {'residue': 3, 'two_chunk_coordinates_each': 4, 'addresses': count,
            'head_rank': len(h), 'stage_body_ranks': [len(a), len(b)],
            'shared_rank': len(a & b), 'product_rank': len(both),
            'union_rank': len(union), 'product_change_rank': changed(both),
            'union_change_rank': changed(union), 'failed_union_witness': list(witness)}


def examine(caller, pair, baseline_paid, baseline_targets, check_operator):
    masks = axis_masks(pair)
    a, b = pair
    shared = masks[a] & masks[b]
    need(shared.bit_count() == 1, 'one common body axis')
    need(group_rank([1] + [masks[s] for s in range(1, 19)]) == 19,
         'head and stage generators remain independent mod two')
    need((masks[a] ^ masks[b]).bit_count() == 12, 'real stage product grade')
    need((masks[a] | masks[b]).bit_count() == 13, 'stage body union grade')
    all_axes = 1
    for mask in masks.values():
        all_axes |= mask
    need(all_axes.bit_count() == 126, 'principal ambient rank')
    ports = caller['ports']
    paid, targets = baseline_paid.copy(), baseline_targets.copy()
    changed_idles, changed_targets = [], []
    for clock, e in enumerate(caller['events']):
        if e[0] == 'IDLE_ONE':
            _, role, stages = e
            old = 7 * len(stages)
            new = body_product(stages, masks).bit_count()
            if old != new:
                need(old - new == 2, 'one shared idle selector cancels twice')
                paid[old] -= ports
                paid[new] += ports
                changed_idles.append({'event': clock, 'role': role, 'stages': stages,
                                      'old': old, 'new': new, 'ports': ports})
    expected = []
    for role, entry in enumerate(caller['diagonal']):
        mask = body_product(entry['stages'], masks) ^ (1 if entry['q'] else 0)
        expected.append({mask: 1 << role})
        old = entry['q'] + 7 * len(entry['stages'])
        new = mask.bit_count()
        if old != new:
            need(old - new == 2, 'one shared output selector cancels twice')
            targets[old] -= ports
            targets[new] += ports
            changed_targets.append({'role': role, 'stages': entry['stages'],
                                    'old': old, 'new': new, 'ports': ports})
    need(all(v >= 0 for v in paid.values()) and all(v >= 0 for v in targets.values()), 'positive bills')
    need(sum(paid.values()) == sum(baseline_paid.values()) and
         sum(targets.values()) == sum(baseline_targets.values()), 'no extra field credit')
    if check_operator:
        need(physical_operator(caller, masks) == expected, 'forward physical operator')
        need(physical_operator(caller, masks, True) == expected, 'adjoint physical operator')
        # The formerly tempting union changes the selected operator, even
        # though it can be represented by a different grade-13 target.
        root = changed_targets[0]['role']
        actual = next(iter(expected[root]))
        need((actual & shared) == 0 and (actual ^ shared).bit_count() == actual.bit_count() + 1,
             'a union target needs the missing physical shared swap')
    signed_before = baseline_targets.copy(); signed_before.subtract(baseline_paid)
    signed_after = targets.copy(); signed_after.subtract(paid)
    delta = signed_after.copy(); delta.subtract(signed_before)
    prices = {}
    for k in SAVINGS:
        gain = moment(delta, k)
        need(gain[1] < 0, 'strictly negative complete signed delta')
        prices[k] = {'baseline': decimal(moment(signed_before, k)),
                     'gain': decimal(gain), 'new_margin': decimal(moment(signed_after, k))}
    return {'pair': pair, 'local_event_count': 4,
            'body_intersection': shared.bit_count(), 'body_product_grade': 12,
            'body_union_grade': 13, 'principal_ambient': 126, 'conservative_working_ambient': 133,
            'changed_idle_occurrences': changed_idles, 'changed_root_roles': changed_targets,
            'signed_delta': hist_json(delta), 'paid': hist_json(paid), 'targets': hist_json(targets),
            'mass_change': {'paid': grade_mass(paid) - grade_mass(baseline_paid),
                            'targets': grade_mass(targets) - grade_mass(baseline_targets)},
            'price': prices}


def main():
    for path, digest in PINS.items():
        need(sha256((HERE / path).read_bytes()).hexdigest() == digest, 'pinned bytes: ' + path)
    word, caller, receipt = (read('inputs/WORD.json.gz'), read('inputs/EFREE-CALLER.json.gz'),
                             read('inputs/BIT.json'))
    canonical = sha256(json.dumps(word, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    need(canonical == receipt['native']['candidate_canonical_sha256'], 'pinned canonical native word')
    atlas = native.Atlas(word['frames'])
    need(atlas.main_contacts(word['start'], word['final']) == 111, 'native head/body ports')
    forward, backward, _ = native.native_checks(word, atlas)
    np, nt, paid, targets = native.binary_invoice(word, caller, atlas, forward)
    for actual, name in ((np, 'native_paid'), (nt, 'native_targets'), (paid, 'paid'), (targets, 'targets')):
        need(actual == Counter({int(k): v for k, v in receipt['native'][name].items()}),
             'complete comparator source bill ' + name)
    need(paired_check.forward(caller) == 38 ** 2, 'formal forward polynomial ring')
    need(paired_audit.backward(caller) == 38 ** 2, 'formal reverse polynomial ring')
    ordinary = native.ordinary_boundary(word, caller, paid, targets)
    stage = examine(caller, (9, 10), paid, targets, check_operator=True)
    need(not stage['changed_idle_occurrences'], 'stage 9/10 no changed idles')
    need([x['role'] for x in stage['changed_root_roles']] == [0, 19], 'stage 9/10 full-chain roots')
    need(stage['signed_delta'] == {'125': 222, '127': -222}, 'stage 9/10 bill')
    # Restore the single selector on each affected original independent root.
    # This explicit correction changes grade 125 to 126 and costs one paid
    # grade-1 job per field; 127 cannot fit the changed principal ambient.
    delta_fix = Counter({126: 222, 127: -222, 1: -222})
    stage['explicit_union_restoration'] = {
        'paid_additions': {'1': 222}, 'corrected_productive_grade': 126,
        'original_productive_grade': 127, 'signed_delta': hist_json(delta_fix),
        'gain': {k: decimal(moment(delta_fix, k)) for k in SAVINGS},
        'scope': 'one separate output correction per affected port and role; no merging of owners',
    }
    for k in SAVINGS:
        need(moment(delta_fix, k)[1] < 0, 'explicit restoration debit')
    stage['four_native_occurrences'] = {
        'event_clocks': [i for i, e in enumerate(caller['events'])
                         if e[0] == 'LOCAL' and e[1] in (9, 10)],
        'paid_by_grade': hist_json(Counter({r: 4 * v for r, v in np.items()})),
        'productive_helpers_by_grade': hist_json(Counter({r: 4 * v for r, v in nt.items()})),
        'independent_helpers': 4 * sum(nt.values()),
        'distinct_native_paid_positions': 4 * sum(np.values()),
        'private_owned_labels_per_occurrence': word['owned_fields'],
        'native_paid_and_helper_grades_change': False,
    }
    need(stage['four_native_occurrences']['event_clocks'] == [100, 101, 394, 395], 'actual local clocks')
    all_results = []
    stage_hist = Counter({int(r): v for r, v in stage['signed_delta'].items()})
    ties = 0
    for pair in combinations(range(1, 19), 2):
        result = examine(caller, pair, paid, targets, check_operator=False)
        hist = Counter({int(r): v for r, v in result['signed_delta'].items()})
        if hist == stage_hist:
            ties += 1
        else:
            for k in SAVINGS:
                need(moment(hist, k)[1] < moment(stage_hist, k)[0], 'every other case strictly below stage 9/10')
        all_results.append({'pair': pair, 'changed_idles': len(result['changed_idle_occurrences']),
                            'changed_roots': len(result['changed_root_roles']),
                            'signed_delta': result['signed_delta'], 'price': result['price']})
    need(len(all_results) == 153, 'every stage pair')
    need(ties == 81, 'exact cross-half best-price tie census')
    output = {
        'status': 'PASS_ONE_SHARED_PHYSICAL_BODY_AXIS_NEGATIVE',
        'scope': 'One coordinate shared by exactly one pair of seven-axis bodies; all other body axes and the common head stay distinct; original caller and native forms fixed. Idles are correctly recompiled on their actual symmetric-difference axes.',
        'source': {'pr_7830_head': '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
                   'word_sha256': canonical, 'caller_gzip_sha256': PINS['inputs/EFREE-CALLER.json.gz']},
        'baseline_checks': {'native_coefficients_each_way': 680 ** 2,
                            'formal_caller_coefficients_each_way': 38 ** 2,
                            'paired_caller_independent_source_implementations': 2,
                            'native_dirty_erasures_each_way': [forward.dirty, backward.dirty],
                            'baseline_ordinary': ordinary},
        'stage_9_10': stage, 'finite_swap_fixture': physical_fixture(),
        'pair_census': {'pair_count': len(all_results), 'strictly_negative_at_both': len(all_results),
                        'best_price_ties': ties,
                        'pairs': all_results},
        'caveat': 'A fixed-coordinate algebra and signed-invoice exclusion, not an emitted changed native word, finite compiler/stock/precision replay, new admitted saving, or claim over arbitrary changed callers.',
    }
    print(json.dumps(output, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
