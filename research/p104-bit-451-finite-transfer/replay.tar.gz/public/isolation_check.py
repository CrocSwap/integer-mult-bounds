#!/usr/bin/env python3
"""Replay in-process with network and non-package source reads blocked.

The Python standard library remains readable. Run with -I -B. The guard is a
bounded test for Python audit events, not an operating-system sandbox.
"""
from pathlib import Path
import os
import runpy
import sys
import sysconfig

if not __debug__:
    raise SystemExit('Run without Python optimization: verification uses assertions.')
here=Path(__file__).resolve().parent
out=here/'isolation-replay'
stdlib={Path(sysconfig.get_path(k)).resolve() for k in ('stdlib','platstdlib')}

def under(path,root):
    return path==root or root in path.parents

def audit(event,args):
    if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.exec'}:
        raise PermissionError(f'isolation guard blocked {event}')
    if event=='open' and args and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).resolve()
        if not (under(path,here) or any(under(path,root) for root in stdlib)):
            raise PermissionError('isolation guard blocked a non-package source')

sys.addaudithook(audit)
for script in ('verify.py','stock_transfer.py'):
    sys.argv=[str(here/script),'--output-dir',str(out)]
    runpy.run_path(str(here/script),run_name='__main__')
for result,expected in [('RESULT.json','EXPECTED.json'),('STOCK-TOY.json','EXPECTED-STOCK.json')]:
    if (out/result).read_bytes() != (here/expected).read_bytes():
        raise SystemExit(f'receipt mismatch: {result}')

# Prove the guard itself rejects an out-of-package read and a socket.
try:
    open(here.parent/'guard-negative-control.txt','rb')
except PermissionError:
    pass
else:
    raise SystemExit('non-package read guard did not reject')
import socket
try:
    socket.socket()
except PermissionError:
    pass
else:
    raise SystemExit('socket guard did not reject')
print('PASS_ISOLATED_RECEIPTS_AND_GUARD_CONTROLS',flush=True)
