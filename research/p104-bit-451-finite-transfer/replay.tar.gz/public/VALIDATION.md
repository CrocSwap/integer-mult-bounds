# Validation record

The packet was tested with CPython 3.12.3. A fresh temporary copy passed the
checksum inventory, both offline arithmetic checks, byte comparison with the
two expected receipts, and the Python audit-hook isolation control. A separate
run supplied the exact #7863 archive: its SHA-256 and all ten selected member
hashes matched.

The fresh-copy negative controls rejected a modified baseline input, an altered
expected receipt, an invalid source archive, and optimized Python execution.
A byte scan found no workstation home, scratch, mount, or runtime directory
paths in the packet. `self_test.py` repeats these controls; the optional
archive comparison runs when an archive is supplied.

The pinned #7863 `README.md` and `SOURCES.json` were also read through the
GitHub repository connector. They name the same archive SHA-256 and #7830
head in `SOURCE-PINS.json`. This is source provenance, not a fresh replay of
the native BIT or rational graph. The numerical engine is the retained source
reviewer and the stock examples are finite toy controls; all other limitations
in `README.md` apply.
