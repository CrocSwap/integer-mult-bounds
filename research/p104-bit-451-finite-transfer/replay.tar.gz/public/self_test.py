#!/usr/bin/env python3
"""Test a fresh offline copy, including negative and relocation controls."""
import argparse
from hashlib import sha256
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

if not __debug__:
    raise SystemExit('Run without Python optimization: verification uses assertions.')
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-archive',type=Path,help='optional pinned #7863 source archive')
args=parser.parse_args()
archive=args.source_archive.resolve() if args.source_archive is not None else None

with TemporaryDirectory(prefix='p104-transfer-test-') as temporary:
    root=Path(temporary)/'packet'
    shutil.copytree(HERE,root,ignore=shutil.ignore_patterns('replay','isolation-replay','__pycache__'))
    for line in (root/'SHA256SUMS').read_text().splitlines():
        digest,rel=line.split('  ',1)
        assert sha256((root/rel).read_bytes()).hexdigest()==digest,rel
    for path in root.rglob('*'):
        if path.is_file():
            content=path.read_bytes()
            for component in (b'home',b'tmp',b'mnt',b'run/user'):
                assert b'/'+component+b'/' not in content,path.relative_to(root)

    def run(*arguments,good=True,expected=None):
        process=subprocess.run([sys.executable,*arguments],cwd=root,text=True,
                               stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
        assert (process.returncode==0)==good,(arguments,process.stdout[-600:],process.stderr[-600:])
        if expected is not None:
            assert expected in process.stdout+process.stderr,arguments

    run('-I','-B','replay.py',expected='PASS_BOTH_RECEIPTS_BYTE_EQUAL')
    run('-I','-B','isolation_check.py',expected='PASS_ISOLATED_RECEIPTS_AND_GUARD_CONTROLS')
    if archive is not None:
        run('-I','-B','replay.py','--source-archive',str(archive),expected='PASS_BOTH_RECEIPTS_BYTE_EQUAL')

    baseline=root/'inputs/BASELINE.json'
    old=baseline.read_bytes(); baseline.write_bytes(old+b' ')
    run('-I','-B','replay.py',good=False,expected='BASELINE.json')
    baseline.write_bytes(old)
    receipt=root/'EXPECTED.json'
    old=receipt.read_bytes(); receipt.write_bytes(old+b' ')
    run('-I','-B','replay.py',good=False,expected='receipt mismatch')
    receipt.write_bytes(old)
    bad_archive=root/'bad-archive.tar.gz'; bad_archive.write_bytes(b'not-the-source-archive')
    run('-I','-B','replay.py','--source-archive',str(bad_archive),good=False,expected='source archive hash')
    run('-I','-O','-B','replay.py',good=False,expected='without Python optimization')
    run('-I','-O','-B','verify.py',good=False,expected='without Python optimization')
    print('PASS_PORTABLE_SELF_TEST archive_comparison='+('yes' if archive else 'not_requested'),flush=True)
