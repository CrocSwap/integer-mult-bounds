#!/usr/bin/env python3
"""Exact toy controls for the finite-stage logarithmic stock lemma.

This verifies small inputs and the symbolic threshold shape only. It does not
construct the 451-fold supplier or validate its physical stock composition.
"""
import argparse
import json
from math import prod
from pathlib import Path

if not __debug__:
    raise SystemExit('Run without Python optimization: verification uses assertions.')

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=Path(__file__).resolve().parent/'replay')
OUT=parser.parse_args().output_dir
OUT.mkdir(parents=True,exist_ok=True)

def ceil_log(base, n):
    assert base >= 2 and n >= 1
    k, p = 0, 1
    while p < n:
        p *= base
        k += 1
    return k

def ceil_root(n, k):
    assert n >= 1 and k >= 1
    a,b=1,2
    while b**k < n:
        b *= 2
    while b-a > 1:
        m=(a+b)//2
        if m**k >= n:
            b=m
        else:
            a=m
    return a if a**k >= n else b

# Distinct q and N exercise fixed radix factors, not the enormous real primes.
config = [
    {'N':2,'q':3,'B':5,'c':1},
    {'N':3,'q':5,'B':9,'c':2},
    {'N':2,'q':7,'B':11,'c':1},
    {'N':3,'q':3,'B':8,'c':2},
]*2
K = max(3+ceil_log(2,s['c']) for s in config)
A = sum(ceil_log(2,s['q'])*(ceil_log(s['q'],s['B'])+(s['c']+1)*s['N']**2)
        for s in config)
L = ceil_log(2,2*A)
J = max(8,K,(125*L)//62+1)

def probe(E):
    reserve_product=1
    sum_descriptor=0
    pieces=[]
    for s in config:
        N,q,B,c=(s[x] for x in ('N','q','B','c'))
        width=c*E
        w=ceil_root(width,250)
        d=max(1,(width+w-1)//w)
        D=2+ceil_log(N,d)
        gl=prod(q**N-q**j for j in range(N))
        W=B*gl*q**(N*N*(w-1))
        concrete=W**D
        k=ceil_log(q,concrete)
        rhs=D*(ceil_log(q,B)+N*N*w)
        assert k<=rhs
        assert w <= (c+1)*ceil_root(E,250)
        assert D <= K+ceil_log(2,E)
        bits=ceil_log(2,q)*k
        assert concrete.bit_length()<=bits
        reserve_product*=concrete
        sum_descriptor+=bits
        pieces.append({'width':width,'w':w,'D':D,'q_digits':k,'descriptor_bits':bits})
    assert reserve_product.bit_length()<=sum_descriptor
    return {'E':E,'pieces':pieces,'actual_product_bits':reserve_product.bit_length(),
            'upper_descriptor_bits':sum_descriptor,'below_half_width':2*sum_descriptor < E}

small=probe(32)
large=probe(2**J)
assert not small['below_half_width'] and large['below_half_width']
out={'status':'PASS_TOY_CHECKS_FOR_CONDITIONAL_STOCK_LEMMA',
     'scope':'Eight finite toy reserves with widths at most c_i E and fixed radices; no 451 product, catalogue, precision interface or actual stage composition.',
     'config':config,'A':A,'K':K,'L':L,'sufficient_threshold_log2_E':J,
     'small_negative_control':small,'threshold_control':large}
(OUT/'STOCK-TOY.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(out['status'], 'J',J,'small bits',small['upper_descriptor_bits'],
      'at threshold E',large['E'],'bits',large['upper_descriptor_bits'])
