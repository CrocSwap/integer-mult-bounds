#!/usr/bin/env python3
"""Replay the bounded transfer and toy stock checks against committed receipts."""
import argparse
from pathlib import Path
import subprocess
import sys

if not __debug__:
    raise SystemExit('Run without Python optimization: verification uses assertions.')

here=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=here/'replay',
                    help='directory for regenerated receipts')
parser.add_argument('--source-archive',type=Path,
                    help='optional pinned #7863 replay.tar.gz to check input member bytes')
args=parser.parse_args()
out=args.output_dir.resolve()
out.mkdir(parents=True,exist_ok=True)
cmd=[sys.executable,'-I','-B',str(here/'verify.py'),'--output-dir',str(out)]
if args.source_archive is not None:
    cmd+=['--source-archive',str(args.source_archive.resolve())]
subprocess.run(cmd,check=True)
subprocess.run([sys.executable,'-I','-B',str(here/'stock_transfer.py'),
                '--output-dir',str(out)],check=True)
for result,expected in [('RESULT.json','EXPECTED.json'),('STOCK-TOY.json','EXPECTED-STOCK.json')]:
    if (out/result).read_bytes() != (here/expected).read_bytes():
        raise SystemExit(f'receipt mismatch: {result}')
print('PASS_BOTH_RECEIPTS_BYTE_EQUAL',flush=True)
