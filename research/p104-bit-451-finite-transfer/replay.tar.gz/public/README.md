# P104: bounded 451-factor transfer arithmetic

## Result and limits

This is a numerical and symbolic feasibility check, **not** a new word, a
new supplier, a consumer replay, or a κ improvement. The pinned baseline is
[#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier).
The bundled inputs are exact members of the public sanitized
[#7863 replay archive at `b3e4412fe01f07dc58305616fabf96345f49a781`](https://github.com/CrocSwap/integer-mult-bounds/blob/b3e4412fe01f07dc58305616fabf96345f49a781/research/p104-bit-451-factor-schedule/replay.tar.gz),
whose SHA-256 is `5f9d9c378a1bddccb2e42ac6453716fa950f19bd71f6181a9606f5eb68b022b3`.
The archive pin and #7830 head are recorded by that commit's
[source manifest](https://github.com/CrocSwap/integer-mult-bounds/blob/b3e4412fe01f07dc58305616fabf96345f49a781/research/p104-bit-451-factor-schedule/SOURCES.json).
#7852 at
`41beda1d6435760dc99e38bd7e65f36798aad212` is campaign context; none of its
lower-bound assumptions is used here.

The offline script checks the bundled source-member hashes against its pinned
inventory. Optionally it verifies a supplied archive's SHA-256 and matches
every bundled source member byte-for-byte. The inputs include the exact
component receipt, separately recounted histograms, the #7830 BIT receipt,
the 70-digit directed rational moment engine, and the inherited outer
selector. The BIT invoice is the complete
36-call invoice: 107,460 paid and 20,706 productive positions. It checks the
separately recounted 48-call rational invoice. It does not reproduce either
literal native word or the physical compiler. The source engines and inherited
theorem are reused, not independently reproved.

For target `K=0.003879929046155`, keeping uniform loss `e=2.5e-12` and cover
loss `d=1e-13` requires raw `C>K+e+d=0.003879929048755`, before bootstrap and
outer losses. At that point, with `M=T_(1-C)-P_(1-C)`, directed bounds give

```
M ∈ [-0.000386128646642167090303840263358142709337949,
     -0.000386128646642167090303840263358142709337948].
```

Any changed profile with positive `M` at this same point therefore needs
signed improvement strictly exceeding `0.00038612864664216709030384...`.
The equivalent per-call necessary amount for 36 identical independent changes
is `0.00001072579574006019695...`; this division is invalid for a nonuniform
edit. Removed targets and all added paid jobs count in the same signed
invoice. This check at `C` does not apply at larger raw trials without repricing
or a derivative bound on the **changed** invoice.

The original signed histogram is uniformly decreasing throughout
`0≤C≤0.0040000000026`: its derivative has directed upper bound
`-378607.663700831666954974...`. Thus the original signed profile has
negative `M` for every `C≥0.003879929048755` allowed by the retained condition
`C-e-d<rho=1/250`. This proves an obstruction only for the unchanged signed
profile under these fixed losses and seven-stage parameter conditions.

## Separate moment guards

For a putative changed invoice, define positive `T=T_(1-C)`,
`alpha=P_(1-C)/T`, `gamma=P_(1-C+13/50)/(11^(13/50) T)`, and
`lambda=16^(17/50) T_(1-C-17/50)/T`. Let
`D=2 gamma^451+lambda^451`. The source's 451-factor moment test, using
outward caps, is

```
1/(1+451(1-alpha_cap)) + 2 gamma_cap^451 + lambda_cap^451 < 1.
```

For actual ratios, passing the cap test implies `D<1`, `M>0`, and the
necessary inequality

```
M/T > D / (451*(1-D)).
```

The source rounds the caps upward, so this exact-ratio inequality is necessary
but not by itself sufficient for the source certificate. Alpha measures the
unshifted signed margin; gamma independently prices high-rank paid slabs;
lambda independently prices discarded low-rank targets. A change to any
histogram can change all three ratios.

At the basic adjusted target, the *old* gamma is about
`0.9247497629178406860` and lambda about `0.9428816193932612110`;
`2 gamma^451≈9.5051092901643e-16`, and
`lambda^451≈3.0212280769641e-12`. **Only as an illustration**, if a
proposed profile held `T`, gamma and lambda at exactly these old values, its
extra signed margin above zero would have to exceed
`0.000000001938839410886208679...`, for total improvement over the old
invoice above `0.0003861305854815779765125...`. A real edit can change the
three values, so that figure is not a universal lower bound.

## Seven stages and the inherited outer selector

The copied selector uses grid `g=10^-14`, chooses
`claim=(min(left,floor(BIT_cap/g))-8)g` and tests `claim+7g`, where `left` is
the positive side of the rational crossing bracket. For the unchanged
rational invoice its crossing is far above the rates considered here. The
first grid claim **strictly** above `K` is `0.00387992904616`; the tested
rate is `0.00387992904623`, and the minimum source-selector cap is
`0.00387992904624`. These are properties of that selector, not limits on
other possible consumers or grids.

With the source seed `s=0.00385248` and `rho=1/250`, seven strict stages
obey `a_7 < (1-rho^7)(C-e-d)+rho^7 s`. Consequently reaching that cap
requires the strict bound

```
C > e+d + (0.00387992904624-rho^7 s)/(1-rho^7)
  = 0.00387992904884000000044972517359...
```

This is necessary for the specified stage count and source selector; strict
stage rounding adds a possible further cost. An arithmetic-only example at
raw `0.003879929048842` gives the seven individually strict stage values in
`RESULT.json` and final cap `0.00387992904624199998`. It would yield the
first grid claim if the other inputs existed. However, the old BIT invoice
at this trial is negative by `0.00038616215268542158458818...`; no changed
word is supplied.

At the corresponding rational tested rate, the unchanged rational signed
invoice has margin `+0.21124385353592034954822...`. The inherited rational
alpha/gamma/delta, 1,920-factor separation, log-power 2,381, depth
`15171300000000000000`, and 54 strict plus four functional outer formula
conditions pass arithmetically for the hypothetical minimum cap. The source
input-lift inequalities pass at claim and tested rate, with its derivative
guard checked up to the example cap; the unchanged common-root argument has
14,083 bits, below the rational compiler depth. This does not replay the
changed BIT service or establish that its interface is valid.

The inherited qualifier checks a hard-coded old binary-word SHA against both
the canonical word and its finite receipt; the separate auditor independently
pins the same old word and receipt. The #7863 adapter copies that old word
into its input and rewrites only the cap receipt. A real changed-word consumer
must bind the changed canonical word and its independently authenticated
completed finite supplier throughout the qualifier and auditor, then rerun
both. Changing a cap while leaving the old word installed cannot validate a
new supplier.

## Fixed uniform, cover, and resource guards

On the entire raw interval `[0.003879929048755, 0.00387992905]`, the
unchanged 451-factor arithmetic with ambient `134^451`, cutoff `11^451`,
floor `16^451`, `theta=13/15`, log power 60, `H=1202400000000000`, and
loss `e` passes both shifted-log comparisons and uniform carrier inequalities.
Monotonicity of `(1-C)134^(-451 C)` and `134^(451 C)` justifies checking the
interval endpoints. This does not establish the same ambient, floor or
cutoff for an altered physical word: those must be revalidated. In the old
histogram the floor is attained, for example, by 224 rank-4, two rank-8 and
225 rank-64 targets; a changed histogram needs its own independent labelled
target witness and zero specializations.

For unchanged `H` and `d`, after the full finite candidate catalogue has
been frozen, the source condition `q>2^52 N^5` gives the strict fallback
surcharge `64N^5/q<1/70368744177664<d/4`; the `2^51` exponent alone does
not certify that bound. Also `H d=3006/25` and the source multiplier
`(1+d/4)/(1+d/2)<1`. This is prime-budget arithmetic, not construction of
the actual exclusions, prime, q-dependent cover, fresh-fibre weighting, or
charged nonunit-pivot fallback.

The old one-factor actual ordinary record count is 934,182,831,504 against
the source's `10^12` allowance, leaving 65,817,168,496 nominal positions;
old owned backing is 6,998,544 against the `10^7` guard, leaving 3,001,456
nominal fields. These figures are source-recount headroom, not automatic
permission to add a device: a changed word needs its own ownership,
lifetimes, record/route/auxiliary recount and product-bound rebuild. In
particular the `6,998,544 U+O_aux` and `10^12 U+8R+G_aux` formulas cannot
be reused unmodified if the new bill or occurrence count changes.

## A conditional finite-stage stock-depth transfer

The following improves the single-stage asymptotic bookkeeping to a finite
stack of stages, while leaving the physical interfaces explicit. Suppose
there are `m` actually instantiated reserves in a complete product ledger.
For stage `i`, suppose `q_i` is a fixed odd prime, `N_i≥2`, `B_i≥1` is a
fixed productive width, and its q-adic input width satisfies
`1≤E_i≤c_i E` for a fixed integer `c_i≥1`. Put `rho=1/250`,
`w_i=ceil(E_i^rho)`, and

```
D_i = 2 + ceil(log_(N_i)(max(1, ceil(E_i/w_i))))
W_i = B_i |GL_(N_i)(F_(q_i))| q_i^(N_i^2(w_i-1)).
```

Assume the completed row ledger's combined reserve cardinality is bounded by
`2^h product_i W_i^D_i`, with a fixed `h≥0`; expand any fixed multiplicity
into the index. This is an assumption about the physical ledger, not a
conclusion drawn from matching histograms. Define

```
t_i = ceil(log_(q_i) B_i),  ell_i = ceil(log_2 q_i),
K = max_i (3+ceil(log_2 c_i)),
A = h + sum_i ell_i [t_i+(c_i+1)N_i^2],
L = ceil(log_2(2A)),
J = max(8,K,floor(125 L/62)+1).
```

Assume `m≥1` and `A≥1`. The q-digit depth of reserve `i` is at most
`D_i(t_i+N_i^2 w_i)`, since `|GL_N(F_q)|≤q^(N^2)`. From
`w_i≤(c_i+1)E^rho` and `D_i≤K+log_2 E`, the combined descriptor bit depth is
at most `A(K+log_2 E)E^rho`. For `E≥2^J`, setting `x=log_2 E` gives
`K+x≤2x≤2^(x/2)` and
`log_2(2A)≤L<(62/125)x`. Hence the depth is strictly below `E/2`.
This proves a quantitative eventual **address-depth bound** for this
explicit finite product ledger. It does not establish existence, restoration,
access cost, one-owner separation, or precision of its physical banks, and
does not absorb an unaccounted nested seed reserve. Different fixed radices
are included via `ell_i`; if actual conversion uses additional fixed
multiplicity and bounded intermediate widths, those must be counted in the
ledger and the constants.

`stock_transfer.py` tests the exact cardinalities for eight small heterogeneous
toy reserves. It obtains `J=21`: at `E=2^21`, the calculated upper descriptor
length is 5,096 bits `<E/2`; at `E=32`, 1,710 bits violate the half-width
condition. These are controls of the lemma's arithmetic, not a 451-product
test or a precision-tape proof.

## Reproduction

The package contains its necessary authenticated inputs and runs with the
Python 3.12 standard library. From this directory:

```
python3 -I -B self_test.py
python3 -I -B replay.py
```

Alternatively, `sha256sum -c SHA256SUMS` checks the file inventory where that
utility is installed.

The wrapper runs both bounded checks with one Python process at a time and
requires the generated `replay/RESULT.json` and `replay/STOCK-TOY.json` to
match the committed `EXPECTED.json` and `EXPECTED-STOCK.json` byte for byte.
Use `--output-dir results` to write to a different directory. These programs
use assertions and explicitly reject Python's `-O` optimized mode.

The optional `python3 -I -B isolation_check.py` repeats both calculations in
one process with a Python audit hook blocking socket use and file reads
outside the package and Python standard library. It also checks that attempted
out-of-package access and socket creation are rejected. This audit hook is a
bounded check, not an operating-system sandbox.

`python3 -I -B self_test.py` makes a fresh temporary copy, verifies the
manifest, repeats the offline and isolated replays, scans for workstation
paths, and checks that corrupt input, a changed expected receipt, an invalid
archive and optimized mode are rejected. It deletes its temporary copy when
finished. Supplying `--source-archive ../replay.tar.gz` additionally checks
the archive binding in that fresh copy.

For the optional archive comparison, obtain the pinned #7863 archive from the
link above, place it beside this directory as `replay.tar.gz`, and run:

```
python3 -I -B replay.py --source-archive ../replay.tar.gz
```

The program requires the exact archive hash and compares the selected members
in memory; it does not extract files or access the network. Without that
option, it verifies all bundled member hashes directly. The full archive is
not redistributed in this packet. `SOURCE-PINS.json` records the member paths,
hashes and sources; `NOTICE.md` and the retained notices credit contributors.

Any future candidate
must be fully priced and checked from its own legal occurrence labels,
changed native word in both orientations, target independence and floor,
physical compiler catalogue/cover, stock ledger, all precision and ordinary
stages, and complete 48-call consumer. The five inherited premises remain
`native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and
`analytic_recovery`.
