#!/usr/bin/env python3
"""Pinned bounded 451-factor transfer arithmetic; no candidate construction."""
import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
import json
import sys
import tarfile

if not __debug__:
    raise SystemExit('Run without Python optimization: verification uses assertions.')

HERE = Path(__file__).resolve().parent
P = HERE/'inputs'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir', type=Path, default=HERE/'replay')
parser.add_argument('--source-archive', type=Path,
                    help='optional pinned #7863 replay.tar.gz for exact member comparison')
args=parser.parse_args()
OUT = args.output_dir
OUT.mkdir(parents=True,exist_ok=True)
ARCHIVE_PIN = '5f9d9c378a1bddccb2e42ac6453716fa950f19bd71f6181a9606f5eb68b022b3'
PINS = {
    'source-7830/BIT.json': '8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
    'source-7830/review/independent.py': 'a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
    'BIT-451.json': '538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749',
    'BASELINE.json': 'a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a',
    'inputs/cache/parent/qualify_complex.py': '236988674f4efe96134de83a224f9c5f4508f6049237415bc24a18669cf5ad67',
    'consumer-replay/APPLICATION.json': 'b38b7858943b0dd58617c1a0820105282d80f965c151ea947dac19c7a715bde7',
    'consumer-replay/AUDIT.json': 'd5e4fa9b3824157b10e06f3fdff3946b8ab1faf465a7d7e3ea896234d12c0fea',
}
AUX_PINS = {
    'source-7830/NOTICE':'b213998c8dae6d88e4a1f0fd17c81dd78c31ef35bc9460fa16ca692326f1a02b',
    'source-7830/LICENSE':'c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4',
    'inputs/cache/parent/NOTICE':'5b20e5e7321a62fc765f31114c68aaff3f6c9c8d9f7707ecfe3575ca37aee6b2',
}
for path, digest in {**PINS,**AUX_PINS}.items():
    assert sha256((P/path).read_bytes()).hexdigest() == digest, path
if args.source_archive is not None:
    assert sha256(args.source_archive.read_bytes()).hexdigest() == ARCHIVE_PIN, 'source archive hash'
    with tarfile.open(args.source_archive,'r:gz') as package:
        for path,digest in {**PINS,**AUX_PINS}.items():
            member=package.getmember('package-sanitized/'+path)
            assert member.isfile() and sha256(package.extractfile(member).read()).hexdigest() == digest, path
spec = spec_from_file_location('independent_review', P/'source-7830/review/independent.py')
r = module_from_spec(spec)
sys.modules[spec.name] = r
spec.loader.exec_module(r)

baseline = json.loads((P/'BASELINE.json').read_bytes())
archived = json.loads((P/'source-7830/BIT.json').read_bytes())
component = json.loads((P/'BIT-451.json').read_bytes())
hist = lambda v: Counter({int(k): n for k, n in v.items()})
bp, bt = hist(baseline['binary']['paid']), hist(baseline['binary']['targets'])
rp, rt = hist(baseline['rational']['paid']), hist(baseline['rational']['targets'])
assert bp == hist(archived['native']['paid']) and bt == hist(archived['native']['targets'])
assert sum(bp.values()) == 107460 and sum(bt.values()) == 20706
assert component['source']['head'] == '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'
assert component['source']['binary_word'] == r.BIT_WORD

G = r.GRID
def lo(x): return Q(x[0], G)
def hi(x): return Q(x[1], G)
def ceildiv(x, y): return -(-x // y)
def decimals(x, places=45, up=False):
    n = x.numerator * 10**places
    z = ceildiv(n, x.denominator) if up else n // x.denominator
    sign = '-' if z < 0 else ''
    z = abs(z)
    return f'{sign}{z//10**places}.{z%10**places:0{places}d}'
def interval(a, b, places=45): return [decimals(a, places), decimals(b, places, True)]
def rows(p, t, c):
    time = 1-c
    want = r.moment(t, time)
    paid = r.moment(p, time)
    signed = r.sub(want, paid)
    alpha = r.quotient(paid, want)
    gamma = r.quotient(r.moment(p,time+Q(13,50)), r.mul(r.power(11,Q(13,50)),want))
    lam = r.quotient(r.mul(r.power(16,Q(17,50)),r.moment(t,time-Q(17,50))),want)
    return want, paid, signed, alpha, gamma, lam

target = Q('0.003879929046155')
e, d, rho, seed, v = Q(1,400_000_000_000), Q(1,10**13), Q(1,250), Q('0.00385248'), 451
c0 = target+e+d
tick = 10**14
grid_claim = Q(ceildiv(target.numerator*tick,target.denominator), tick)
cap_min = grid_claim + Q(8,tick)
tested = grid_claim + Q(7,tick)
bootstrap_c = e+d+(cap_min-rho**7*seed)/(1-rho**7)
# An exact rational upper endpoint for the narrow illustrative transfer range.
cmax = Q('0.00387992905')
assert c0 < bootstrap_c < cmax and cmax < Q('0.004')
assert grid_claim > target and tested < cap_min
assert cap_min* tick == int(cap_min*tick)
assert cap_min-Q(1,10**30) < cap_min

want, paid, signed, alpha, gamma, lam = rows(bp, bt, c0)
assert hi(signed) < -Q('0.00038612864664216709')
assert lo(alpha) > 1
gamma_tail = (2*lo(gamma)**v,2*hi(gamma)**v)
lambda_tail = (lo(lam)**v,hi(lam)**v)
tail_lo, tail_hi = gamma_tail[0]+lambda_tail[0], gamma_tail[1]+lambda_tail[1]
assert 0 < tail_lo <= tail_hi < 1
# Purely hypothetical frozen T/gamma/lambda values. A real profile must be
# repriced; changed T, shifted paid and shifted target moments need not agree.
need_lo = lo(want)*tail_lo/(v*(1-tail_lo))
need_hi = hi(want)*tail_hi/(v*(1-tail_hi))
delta_lo = -hi(signed)+need_lo
delta_hi = -lo(signed)+need_hi

# Uniformly negative derivative on the entire 451 bootstrap regime C-e-d <
# rho. The upper bound selects C=rho+e+d for each positive signed bin and
# C=0 for each negative signed bin. This excludes only the identical signed
# histogram, not hypothetical changed profiles.
coeff = bt.copy()
coeff.subtract(bp)
derivative_hi = 0
for rank, count in coeff.items():
    exponent = 1-(rho+e+d) if count > 0 else Q(1)
    derivative_hi += r.scale(r.mul(r.power(rank,exponent),r.log_int(rank)), -count)[1]
assert derivative_hi < 0

# Concrete exponent bookkeeping only. It does not supply the changed paid or
# target word, the finite moment proof, physical compiler, or actual stock.
demo_c = Q('0.003879929048842')
assert bootstrap_c < demo_c < cmax
demo_covered = demo_c-e-d
previous = seed
stages = []
for _ in range(7):
    envelope = (1-rho)*demo_covered+rho*previous
    scale = 10**20
    stage = Q((envelope.numerator*scale)//envelope.denominator-1,scale)
    assert previous < stage < envelope < demo_covered < rho < 1-envelope
    stages.append(stage)
    previous = stage
demo_cap = stages[-1]
assert demo_cap >= cap_min
assert Q((demo_cap*tick).__floor__()-8,tick) == grid_claim
_, _, demo_signed, _, _, _ = rows(bp,bt,demo_c)
assert hi(demo_signed) < 0

# Recheck current 451 uniform-parameter inequalities over [c0,cmax].
# A=134^(451*C) rises and eta=(1-C)/A falls on this interval.
power_lo = r.power(134,v*c0)
power_hi = r.power(134,v*cmax)
eta_lo = r.quotient(r.enclose(1-cmax), power_hi)
eta_hi = r.quotient(r.enclose(1-c0), power_lo)
theta, p, H = Q(13,15), 60, 1_202_400_000_000_000
assert theta**p < lo(eta_lo) <= hi(eta_hi) <= theta**(p-1)
assert hi(power_hi) < 2**p
assert 11**15 < 16**13 and 4*11**(15*v) <= 134**(13*v)
assert H*e == 3006 and (H+1)**p < 2**3006
assert (H+1)*e > 2*p and (H-e.denominator+1)**p >= 2**3005
assert Q(64,2**52) < d/4 <= Q(64,2**51)
assert (1+d/4)/(1+d/2) < 1 and 2**(H*d//1) >= 1+d/2

# Exact outer arithmetic at the first grid claim above target and the
# smallest cap admitted by the pinned price() selector. This is NOT a replay.
outer = r.outer_margins(grid_claim,Q(1,tick),cap_min)
rat_want = r.moment(rt,1-tested)
rat_signed = r.sub(rat_want,r.moment(rp,1-tested))
ra = r.quotient(r.moment(rp,1-tested),rat_want)
rg = r.quotient(r.moment(rp,1-tested+Q(1,7)),r.mul(r.power(11,Q(1,7)),rat_want))
rd = r.quotient(r.enclose(Q(12*sum(rt.values()))),r.mul(r.power(11,tested),rat_want))
reserve, decay, rv = Q(1,10**27), Q(31,32), 1920
assert lo(rat_signed) > 0 and hi(ra) < 1-reserve
assert max(hi(rg),hi(rd)) < decay and 1/(1+rv*reserve)+4*decay**rv < 1
rat_A = r.power(153,rv*tested)
rat_eta = r.quotient(r.enclose(1-tested),rat_A)
assert Q(63,64)**2380 < lo(rat_eta) <= hi(rat_eta) <= Q(63,64)**2379
assert hi(rat_A) < 2**2381
RH = 15_171_300_000_000_000_000
assert RH*Q(1,tick) == 151713 and (RH+1)**2381 < 2**151713
assert (RH+1-tick)**2381 >= 2**151712
app=json.loads((P/'consumer-replay/APPLICATION.json').read_bytes())
assert app['common_root']['context_c']==856
depth_bits=(856*1920*153**1920*(RH+1)**2).bit_length()
assert depth_bits==14083 and depth_bits < RH

# The inherited signed input lift and its curvature-based derivative guard.
positive, negative={7:1,3:1,5:1},{9:1,4:1,1:2}
assert sum(rank*n for rank,n in positive.items()) == sum(rank*n for rank,n in negative.items())
d1, curvature = (0,0),(0,0)
for rank,n in positive.items():
    d1=r.add(d1,r.scale(r.log_int(rank),rank*n))
for rank,n in negative.items():
    lg=r.log_int(rank)
    d1=r.sub(d1,r.scale(lg,rank*n))
    curvature=r.add(curvature,r.scale(r.mul(lg,lg),rank*n))
assert hi(d1)+demo_cap*hi(curvature) < 0
lift={}
for name,k in (('claim',grid_claim),('tested',tested)):
    value=r.sub(r.moment(positive,1-k),r.moment(negative,1-k))
    assert lo(value)>0
    lift[name]=interval(lo(value),hi(value))

ord0 = archived['native']['ordinary']
assert ord0['ordinary_records']==934182831504 and ord0['owned_backing']==6998544
out={
  'status':'PASS_PINNED_ARITHMETIC_CONDITIONAL_NO_CHANGED_WORD',
  'scope':'Fixed-source moment, abstract 451 tail condition, uniform/cover arithmetic and outer formula; no new candidate, compiler or physical replay.',
  'pins':PINS,
  'expected_publication_archive_sha256':ARCHIVE_PIN,
  'source_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
  'trial':str(c0),
  'old_BIT':{'target_moment':interval(lo(want),hi(want)),
      'paid_moment':interval(lo(paid),hi(paid)),
      'signed_margin':interval(lo(signed),hi(signed)),
      'alpha':interval(lo(alpha),hi(alpha)),
      'gamma':interval(lo(gamma),hi(gamma)),
      'lambda':interval(lo(lam),hi(lam)),
      'two_gamma_pow_451':interval(*gamma_tail),
      'lambda_pow_451':interval(*lambda_tail),
      'illustrative_frozen_T_gamma_lambda_extra_margin':interval(need_lo,need_hi),
      'illustrative_frozen_T_gamma_lambda_required_delta':interval(delta_lo,delta_hi),
      'unchanged_signed_derivative_upper_on_full_bootstrap_interval':interval(Q(derivative_hi,G),Q(derivative_hi,G),18)},
  'seven_stage_and_outer':{
      'target':str(target), 'first_claim_grid_above_target':str(grid_claim),
      'tested':str(tested), 'minimum_source_selector_BIT_cap':str(cap_min),
      'minimum_raw_for_cap_strict':str(bootstrap_c),
      'minimum_raw_decimal_bracket':interval(bootstrap_c,bootstrap_c,32),
      'extra_above_target_plus_uniform_cover_decimal_bracket':interval(bootstrap_c-c0,bootstrap_c-c0,32),
      'illustrative_arithmetic_only_raw':decimals(demo_c,18),
      'illustrative_arithmetic_only_seven_stages':[decimals(a,20) for a in stages],
      'illustrative_arithmetic_only_BIT_cap':decimals(demo_cap,20),
      'old_BIT_signed_margin_at_illustrative_raw':interval(lo(demo_signed),hi(demo_signed)),
      'outer_margins':outer,
      'rational_signed_margin_at_tested':interval(lo(rat_signed),hi(rat_signed)),
      'rational_alpha':interval(lo(ra),hi(ra)),
      'rational_gamma':interval(lo(rg),hi(rg)),
      'rational_delta':interval(lo(rd),hi(rd)),
      'rational_H':RH,'written_log_power':2381,
      'common_root_argument_bit_length':depth_bits,
      'input_lift_margins':lift,
      'input_lift_derivative_upper_to_demo_cap':decimals(hi(d1)+demo_cap*hi(curvature),45,True)},
  'fixed_uniform_range':{'low':str(c0),'high':str(cmax),'log_power':p,'H':H,
      'eta_envelope':interval(lo(eta_lo),hi(eta_hi)),
      'power_envelope':interval(lo(power_lo),hi(power_hi)),
      'q_surcharge_bound':str(Q(64,2**52)),'cover_budget':str(d/4)},
  'base_physical':{'records':ord0['ordinary_records'],'record_cap':10**12,
       'nominal_record_room':10**12-ord0['ordinary_records'],
       'owned_backing':ord0['owned_backing'],'owned_cap':10**7,
       'nominal_owned_room':10**7-ord0['owned_backing']},
  'premises':r.PREMISES,
}
(OUT/'RESULT.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(out['status'])
print('BIT old margin',out['old_BIT']['signed_margin'])
print('frozen-tail minimum gain',out['old_BIT']['illustrative_frozen_T_gamma_lambda_required_delta'])
print('raw for source 7-stage/outer',out['seven_stage_and_outer']['minimum_raw_decimal_bracket'])
print('rational margin',out['seven_stage_and_outer']['rational_signed_margin_at_tested'])
