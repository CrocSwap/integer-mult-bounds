#!/usr/bin/env python3
"""Literal #7869 engine word and independent causal receipt for two takers."""
from fractions import Fraction as Q
from pathlib import Path
import json,sys
import screen
sys.path.insert(0,str(Path(__file__).resolve().parent/'parent'))
import relay

L,G,eng=relay.L,relay.Gram,relay.eng

def replay(src,t1,t2,h1,h2,s,chart_kind='baseline',omit=()):
    taks=(t1,t2);hs=(h1,h2)
    assert len({relay.eps[i]['life'] for i in (src,t1,t2)})==3
    ps=[screen.params(src,t,h,s) for t,h in zip(taks,hs)]
    z=screen.prefix_base(src,taks,s)
    b0=screen.eps[src]['b']
    b=(b0 if chart_kind=='baseline' else screen.join(screen.join(z,ps[0]['v']),ps[1]['v']))
    assert z & ~b==0
    predicted,rise,items=screen.price(src,taks,ps,b)
    chart=lambda mask:frozenset(screen.elements(mask))
    B=chart(b)
    R=eng.Run(9,L,eng.Field(0));states=set();phases=[]
    def start(li,a):
        oid=('O',li)
        if li not in states:R.INIT(oid,a);states.add(li)
        else:R.MOVE(oid,a)
        return oid
    def inputs(oid,a,c):
        for v,coef in enumerate(c):
            if coef:
                y=('Y',v);R.MOVE(y,eng.span(list(R.reg[y][0])+list(a)));R.ADD(oid,coef,y)
    def output(oid,w):
        a=R.reg[oid][0];bb=relay.outspace(a,w);R.MOVE(oid,bb)
        for t,v in enumerate(w):
            if v:R.ADD(('X',t),v,oid)
    def normal(row):
        e=relay.eps[row];before=R.cost;oid=start(e['life'],e['a'])
        inputs(oid,e['a'],e['c']);output(oid,e['w'])
        assert R.reg[oid][0]==e['b'];phases.append([row,R.cost-before])
    se=relay.eps[src];ls=se['life'];so=('O',ls)
    for row in relay.chains[ls][:se['pos']+1]:normal(row)
    R.MOVE(so,B)
    # Both previous target histories finish while Y_s is still cold.
    for tak in taks:
        te=relay.eps[tak]
        for row in relay.chains[te['life']][:te['pos']]:normal(row)
    recipients=[]
    # Gather both compensated direct inputs before contaminating Y_s.
    for tak,h,p in zip(taks,hs,ps):
        te=relay.eps[tak];a=chart(b & p['t']);oid=start(te['life'],a)
        inputs(oid,a,p['d']);recipients.append((tak,h,oid,a))
    y=('Y',s)
    for tak,h,oid,a in recipients:
        R.MOVE(y,eng.span(list(R.reg[y][0])+list(a)))
    assert R.reg[y][0]<=B
    R.ADD(y,1,so)                         # one shared hot write
    for tak,h,oid,a in recipients:R.ADD(oid,h,y)
    R.ADD(y,-1,so)                        # cleanup once
    for ix,(tak,h,oid,a) in enumerate(recipients):
        if ix not in omit:R.ADD(oid,-h,y) # each taker must undo token
    assert R.reg[y][1]=={('y',s):Q(1)}
    for tak,h,oid,a in recipients:
        te=relay.eps[tak];before=R.cost;output(oid,te['w']);phases.append([tak,R.cost-before])
        prior=R.reg[oid][0]
        for row in relay.chains[te['life']][te['pos']+1:]:
            e=relay.eps[row];aa=prior & relay.cold(e['c']);before=R.cost
            start(te['life'],aa);inputs(oid,aa,e['c']);output(oid,e['w'])
            prior=R.reg[oid][0];phases.append([row,R.cost-before])
        R.CLEAR(oid)
    for row in relay.chains[ls][se['pos']+1:]:normal(row)
    R.CLEAR(so)
    used={ls,*(relay.eps[t]['life'] for t in taks)}
    for li,ch in enumerate(relay.chains):
        if li in used:continue
        for row in ch:normal(row)
        R.CLEAR(('O',li))
    assert R.cost==predicted and sum(c for _,c in phases)+rise==R.cost and not R.bad and not R.pinned()
    got=R.rec();bad=[(t,u) for t in range(96) for u in range(96) if got[t][u]!=-Q(G[t][u],2)]
    oddbad=[(t,u) for t,u in bad if check_dot(L[t],L[u])]
    replayed=eng.replay(9,L,eng.Field(0),{},R.ops)
    assert replayed.cost==R.cost and not replayed.bad and not replayed.pinned() and replayed.rec()==got
    assert all(got[t][u]+Q(G[t][u],2)==
               (sum(hs[ix]*relay.W[taks[ix]][t] for ix in omit) if u==s else 0)
               for t in range(96) for u in range(96))
    if omit:assert bad
    else:assert not bad

    F={i:relay.eps[i]['c'][:] for i in range(10)}
    for tak,p in zip(taks,ps):F[tak]=p['d'][:]
    edges={i:[] for i in range(10)}
    for ch in relay.chains:
        for a,b1 in zip(ch,ch[1:]):edges[b1].append((a,Q(1)))
    for tak,h in zip(taks,hs):edges[tak].append((src,h))
    def expand(graph):
        power=F;terms=[]
        while any(any(row) for row in power.values()):
            terms.append([[sum(relay.eps[i]['w'][t]*power[i][u] for i in range(10))
                           for u in range(96)] for t in range(96)])
            power={i:[sum(c*power[parent][u] for parent,c in graph[i]) for u in range(96)] for i in range(10)}
            assert len(terms)<=10
        return terms
    terms=expand(edges)
    causal=[[sum(M[t][u] for M in terms) for u in range(96)] for t in range(96)]
    if not omit:assert causal==got
    # The uncancelled public token in a mutation contributes an extra column;
    # it is deliberately absent from the compensated intended DAG.
    else:assert any(causal[t][u]!=got[t][u] for t in range(96) for u in range(96))
    def stats(mat):
        return {'nonzero':sum(bool(x) for row in mat for x in row),
                'odd_nonzero':sum(bool(mat[t][u]) for t in range(96) for u in range(96)
                                  if check_dot(L[t],L[u]))}
    hot=[]
    for tak,h in zip(taks,hs):
        m=[[h*relay.W[tak][t]*relay.eps[src]['u'][u] for u in range(96)] for t in range(96)]
        missing={i:list(es) for i,es in edges.items()};missing[tak].remove((src,h))
        absent=expand(missing)
        # Each edge's total contribution includes all same-lifetime paths on
        # either side of that edge; compare against independently deleting it.
        assert all(causal[t][u]-sum(M[t][u] for M in absent)==m[t][u]
                   for t in range(96) for u in range(96))
        hot.append(stats(m))
    gf_bad=sum(terms[0][t][u]!=-Q(G[t][u],2) for t in range(96) for u in range(96))
    gf_odd_bad=sum(terms[0][t][u]!=-Q(G[t][u],2) for t in range(96) for u in range(96) if check_dot(L[t],L[u]))
    return {'source':src,'takers':list(taks),'h':[str(x) for x in hs],'port':s,
            'chart_kind':chart_kind,'source_extra_rise':rise,'source_chart_dim':screen.dim(b),
            'target_dims_costs_deltas':items,'R':R.cost,'operations':len(R.ops),
            'bad_operations':len(R.bad),'pinning_errors':R.pinned(),
            'full_bad_cells':len(bad),'odd_bad_cells':len(oddbad),
            'token_cancellations_omitted':list(omit),'carrier_restored':True,
            'phase_costs':phases,'GF_alone_bad_cells':gf_bad,'GF_alone_bad_odd_cells':gf_odd_bad,
            'recipient_complete_hot_path_stats':hot,
            'causal_GF_GHF_and_higher_stats':[stats(m) for m in terms],
            'causal_full_equals_engine':not omit,
            'cold_input_rank':relay.check.qrank(list(F.values()))}

def check_dot(a,b):return (a&b).bit_count()%2

def main():
    return {'sharp_R58':replay(2,8,9,Q(-2),Q(-2),24),
            'omit_first_cancel':replay(2,8,9,Q(-2),Q(-2),24,omit=(0,)),
            'omit_second_cancel':replay(2,8,9,Q(-2),Q(-2),24,omit=(1,)),
            'omit_both_cancels':replay(2,8,9,Q(-2),Q(-2),24,omit=(0,1)),
            'one_dimensional_pickup_R59':replay(8,1,2,Q(-1),Q(1),6),
            'six_ascent_shared_enlargement':replay(8,1,2,Q(-1),Q(1),6,chart_kind='optimized'),
            'baseline':relay.full_replay()}

if __name__=='__main__':print(json.dumps(main(),indent=2,sort_keys=True))
