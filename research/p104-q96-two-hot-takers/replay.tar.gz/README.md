# Two recipients sharing one restored Y write in the Q96 R=58 chain

The exact minimum in the insertion family specified below is **R = 58**. A
literal run of the unchanged #7869 rational engine at
`06c207a9feb3994a4b987dc3010657b6e85b7956` achieves it on the #7922
rank-(10,8) Q96 chain at `93b34c8b786229777f1dd5becb0ec3d5f7627f32`.
One owned source writes a public `Y` port once, two other lifetimes read it
hot, the source restores the port once, and both recipients cancel the
port's original token. The engine checks all 9,216 entries of `−G/2`, all odd
cells, and all operation and pinning constraints. This does not establish a
κ gain.

This is a **sharp result for the stated insertion schedule**, not a general
Q96 hosted-rise theorem. The fixed factorization, port labels, signed output
increments, eight-lifetime partition and earlier histories are inherited
from Round 5 stream 18. The source has completed the selected output and
does not change its value before cleanup. The two recipient epochs are in
distinct lifetimes, also distinct from the source lifetime. Both recipient
prefixes and compensated direct intakes are completed before the sole hot
write; the hot reads occur before cleanup. Each recipient may use any legal
pickup subchart, each hot coefficient may be any nonzero rational, and the
source may enlarge its selected output chart by any nested subspace. A
different factorization, changing pre-pickup histories or source output
increments, extra transfers, helpers, or other orderings remain open. The
case analysis also covers nonzero real coefficient **support strata**;
the literal engine runs use rational coefficients. The related Round 5
stream 12 has a separate P104 temporal-network result; its hypotheses and
conclusions are not imported here.

## Schedule and exact price

The fixed chains are `(0,8)`, `(1,9)`, and the six singleton lifetimes
`(2)` through `(7)`. They have baseline phase charges
`7,1,7,1,7,7,7,7,7,7`, totaling 58. For source epoch `i`, let `U_i` be its
accumulated value. For taker `j`, let `c_j` be its original fresh input,
`w_j` its signed output increment, and `L_j` the binary span of labels on
`supp(w_j)`. For taker coefficients `h_1,h_2`, the direct inputs are

```
d_j = c_j − h_j U_i.
```

Gather both `d_j` while `Y_s` still contains its original token, write
`U_i` to `Y_s`, read `h_1 Y_s` and `h_2 Y_s` into the two takers, remove
`U_i` from `Y_s`, and read `−h_1 Y_s` and `−h_2 Y_s` into the respective
takers. Each finishes with its original `c_j`. The source is not altered
while the port is hot. Both compensated direct intakes are accounted for,
including any direct reads of that same port before the write.

Write `B₀` for the baseline source output chart. Let `Z` be the span of
`B₀` and every chart previously built on `Y_s` by the frozen source and
recipient-prefix histories. For taker `j`, let `P_j` be its previous
output chart, or the full space for a first epoch, and set

```
T_j = P_j ∩ cold(d_j) ∩ q_s⊥,     S_j = T_j ∩ L_j.
```

For a nested source enlargement `B ⊇ Z`, the largest legal pickup is
`A_j = B ∩ T_j`. It is optimal for that fixed `B`, and its output ascent is

```
dim(A_j + L_j) − dim(A_j) = dim L_j − dim(B ∩ S_j).
```

If `r_j` is the baseline ascent at each taker epoch, the full price is

```
R(B) = 58 + (dim B − dim B₀)
       + Σ_j [dim L_j − dim(B ∩ S_j) − r_j].
```

The source enlargement is charged **once**, and each taker is charged
separately. The only possible continuations are rows 8 or 9; their
fresh-input cold charts are both zero, so enlarging an earlier chart does
not change their later cost.

For any `B`, adjoining `S_j` increases `dim B` by precisely the increase
in `dim(B ∩ S_j)` and can only help the other recipient. Consequently
adjoining `S_1` and `S_2` cannot increase the price. For any admissible
`B`, the resulting chart contains `B* = Z + S_1 + S_2`; once both `S_j`
are contained, any chart beyond `B*` only increases the source charge.
Thus `B*` is a global minimum over **all nested source enlargements**. This
argument also covers port charts that were incompatible with `B₀`: they
must be added to `Z` and paid for. It does not assume the one-recipient
enlargement bound continues to hold when two recipients share a rise.

## Exhaustive finite census

For each ordered source and two ordered taker epochs in three different
lifetimes, every coefficient where a coordinate of `c_j−h_j U_i` vanishes
is enumerated exactly, along with one nonzero generic representative.
Support, chart and price are constant throughout each generic real stratum.
The table counts ordered recipient pairs, so reversing them is a distinct
case even when the resulting price agrees.

* 624 ordered epoch triples; 7,516 joint coefficient-support strata.
* All 96 named Y ports, hence 721,536 exact cases.
* Optimal chart `B*` prices: R=58 in 4,704 cases, R=59 in 126,264,
  R=60 in 496,572, and R=61 in 93,996.
* At frozen `B₀`, 233,664 cases fail an existing-port chart inclusion;
  the remaining legal prices are R=58 in 4,704, R=59 in 109,464, and
  R=60 in 373,704. These exclusions do not apply to the enlargement
  census, where the mandatory prefix chart is included and charged.

`screen.py` uses 512-bit subspace-membership masks and calculates the
per-case optimum. `independent.py` imports neither the engine nor that
screen: it uses canonical F₂ Gaussian bases and an independently derived
rank expression. It reproduces all histograms, source subtotals, prefix
conflicts and a SHA-256 digest over the ordered per-case records containing
both prices and cochart legality. The digest is a consistency check, not a
publisher signature or a replacement for the stated proof.

## Engine witnesses and mutations

The equality case uses source row 2, takers 8 and 9, coefficients
`h₁=h₂=−2`, and `Y_24` (label 134). The source output chart is unchanged;
both taker pickup charts have dimension zero and each retains its original
one-ascent output charge. Both hot edge values are nonzero, and the carrier
is restored. The engine executes 1,514 operations at R=58 with no bad
operations or pinning errors. Full and odd receipt checks each report zero
bad cells. Re-executing the recorded operations through `eng.replay`
reproduces the same result.

Removing the token-cancellation read for either recipient yields exactly
one wrong cell, and it is odd; removing both yields two wrong odd cells.
These mutations still have legal operations, restored `Y_24`, and no
pinning errors. Thus legality and restoration alone do not prove the
receipt.

The checker forms the actual acyclic epoch graph with both hot edges and
the same-lifetime edges, computes `G(I−H)⁻¹F = GF + GHF + ⋯`, and compares
all 9,216 entries with the engine. In the equality case the full series has
`GF + GHF`; `GF` alone is wrong on 150 cells, including 80 odd cells.
Removing either hot edge from the graph with its compensated cold factor
fixed yields its individual, nonzero path contribution. The first such
contribution has 46 nonzero cells, 25 odd; the second has 46, 24 odd.

A second exact engine word uses source row 8, takers 1 and 2, coefficients
`−1,+1`, and `Y_6`. Its first pickup is one-dimensional. It costs R=59 and
has nonzero terms through `GH³F`; all full and odd cells still match. An
enlarged-chart replay of the same word adds six source ascents, saves six
at the first taker, and still costs R=59 after counting the second taker.
This is a control for the shared-rise accounting, not a κ improvement.

## Reproduction and provenance

`parent/` is the complete Round 5 stream 18 packet including the #7922
replay archive, #7869 engine, license and notices; its own manifest is
unchanged. The archived #7922 replay has SHA-256
`511e8695c085cfeb5f9e3cac2edd6bfe7cd860475558b9ee42fe2c69953fd673`,
and the unchanged #7869 engine has SHA-256
`900b41f42c978e2bca2db001a5dc81dc93953adb5e842a4924d37c860124c2f6`.

Run `python3 -B verify.py` in this directory. It checks the local and
parent manifests and source identities, reconstructs the 721,536-case
census twice, and reruns the engine witnesses, replays, exact full and odd
receipts, the causal expansion, and all token-omission controls. Python
3.10+ and the standard library suffice.
