#!/usr/bin/env python3
"""Independent F2 Gaussian-basis replay of the two-recipient price census.

This module does not import screen.py or eng.py.  Subspaces use canonical
9-bit row-reduced bases rather than 512-bit membership masks.
"""
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'parent'))
import check

L,G,X,C4=check.load();C0=[[Q(x,4) for x in row] for row in C4]
W=[row[:] for row in X]+[[int(t==1) for t in range(96)],[int(t==5) for t in range(96)]]
for i,a,b in ((0,1,1),(1,1,-1)):W[i][1]+=a;W[i][5]+=b
C=C0+[[-a-b for a,b in zip(C0[0],C0[1])],[-a+b for a,b in zip(C0[0],C0[1])]]
chains=[[0,8],[1,9]]+[[i] for i in range(2,8)]

def basis(vectors):
    piv=[0]*9
    for val in vectors:
        v=val
        while v:
            d=v.bit_length()-1
            if piv[d]:v^=piv[d]
            else:piv[d]=v;break
    for lo in range(9):
        if piv[lo]:
            for hi in range(lo+1,9):
                if piv[hi]>>lo & 1:piv[hi]^=piv[lo]
    return tuple(v for v in piv if v)

@lru_cache(maxsize=None)
def add(a,b):return basis(a+b)

def contains(b,v):
    for p in reversed(b):
        if v>>(p.bit_length()-1)&1:v^=p
    return v==0

@lru_cache(maxsize=None)
def elems(b):
    out=[0]
    for v in b:out.extend(x^v for x in out[:])
    return tuple(out)

@lru_cache(maxsize=None)
def meet(a,b):
    if len(a)>len(b):a,b=b,a
    return basis(v for v in elems(a) if contains(b,v))

@lru_cache(maxsize=None)
def perp(support):
    return basis(v for v in range(512) if all(((v&L[i]).bit_count()&1)==0 for i in support))

def support(v):return tuple(i for i,x in enumerate(v) if x)
universe=tuple(1<<i for i in range(9));qperp=[perp((i,)) for i in range(96)]
eps={};control=0
for life,ch in enumerate(chains):
    prev=universe;u=[Q(0)]*96
    for pos,i in enumerate(ch):
        w=[a-b for a,b in zip(W[i],W[ch[pos+1]])] if pos+1<len(ch) else W[i][:]
        a=meet(prev,perp(support(C[i])));o=basis(L[t] for t in support(w));b=add(a,o)
        u=[x+y for x,y in zip(u,C[i])];cost=len(b)-len(a);control+=cost
        eps[i]={'life':life,'pos':pos,'a':a,'b':b,'prev':prev,'c':C[i],
                'w':w,'u':u[:],'out':o,'cost':cost}
        prev=b
assert control==58 and not perp(support(C[8])) and not perp(support(C[9]))

def hs(c,u):
    special={x/y for x,y in zip(c,u) if x and y};gen=Q(1)
    while gen in special:gen+=1
    return sorted(special)+[gen]

def prefix(row,inclusive,s):
    e=eps[row];return [eps[k]['a'] for k in chains[e['life']][:e['pos']+int(inclusive)] if eps[k]['c'][s]]

@lru_cache(maxsize=None)
def triple_rank(z,a,b):return len(add(add(z,a),b))

def run():
    hist=Counter();frozen=Counter();legal=Counter();conflicts=0;strata=0;triples=0;per_source={};digest=hashlib.sha256()
    for src in range(10):
        targets=[i for i in range(10) if eps[i]['life']!=eps[src]['life']]
        ss={};zsource={}
        for s in range(96):
            zsource[s]=eps[src]['b']
            for v in prefix(src,True,s):zsource[s]=add(zsource[s],v)
        for tak in targets:
            for h in hs(eps[tak]['c'],eps[src]['u']):
                d=[x-h*y for x,y in zip(eps[tak]['c'],eps[src]['u'])]
                inner=meet(meet(eps[tak]['prev'],perp(support(d))),eps[tak]['out'])
                ss[tak,h]=[meet(inner,qperp[s]) for s in range(96)]
        ph=Counter()
        for a,b in product(targets,repeat=2):
            if eps[a]['life']==eps[b]['life']:continue
            triples+=1
            for h1,h2 in product(hs(eps[a]['c'],eps[src]['u']),hs(eps[b]['c'],eps[src]['u'])):
                strata+=1
                for s in range(96):
                    z=zsource[s]
                    for t in (a,b):
                        for v in prefix(t,False,s):z=add(z,v)
                    v1,v2=ss[a,h1][s],ss[b,h2][s];base=eps[src]['b']
                    # Independent rank expression for the best enlarged B.
                    constant=(58-len(base)+len(eps[a]['out'])+len(eps[b]['out'])
                              -eps[a]['cost']-eps[b]['cost'])
                    r=constant+triple_rank(z,v1,v2)-len(v1)-len(v2)
                    hist[r]+=1;ph[r]+=1
                    f=(58+len(eps[a]['out'])-len(meet(base,v1))-eps[a]['cost']
                       +len(eps[b]['out'])-len(meet(base,v2))-eps[b]['cost'])
                    frozen[f]+=1
                    if z==base:legal[f]+=1
                    else:conflicts+=1
                    digest.update(f'{src},{a},{b},{h1},{h2},{s},{r},{f},{int(z==base)}\n'.encode())
        per_source[str(src)]={str(k):v for k,v in sorted(ph.items())}
    expected=json.loads((Path(__file__).resolve().parent/'SCREEN.json').read_text())
    stringify=lambda c:{str(k):v for k,v in sorted(c.items())}
    assert (triples,strata)==(expected['ordered_triples'],expected['joint_coefficient_strata'])
    assert stringify(hist)==expected['optimized_enlargement_hist']
    assert stringify(frozen)==expected['frozen_ignore_prefix_hist']
    assert stringify(legal)==expected['frozen_legal_hist']
    assert conflicts==expected['frozen_prefix_conflicts'] and per_source==expected['by_source']
    assert digest.hexdigest()==expected['per_case_sha256']
    return {'ordered_triples':triples,'support_strata':strata,'cases':96*strata,
            'optimal_histogram':stringify(hist),'frozen_legal_histogram':stringify(legal),
            'conflicts':conflicts,'per_source_matches':True,'per_case_sha256':digest.hexdigest()}

if __name__=='__main__':print(json.dumps(run(),indent=2,sort_keys=True))
