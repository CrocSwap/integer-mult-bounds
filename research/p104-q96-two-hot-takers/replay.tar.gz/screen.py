#!/usr/bin/env python3
"""Two compensated hot takers; exact shared-source F2-subspace prices."""
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from pathlib import Path
import hashlib,json,sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'parent'))
import check

L,G,X,C4=check.load(); C0=[[Q(x,4) for x in row] for row in C4]
W=[row[:] for row in X]+[[int(t==1) for t in range(96)],[int(t==5) for t in range(96)]]
for i,a,b in ((0,1,1),(1,1,-1)):
    W[i][1]+=a; W[i][5]+=b
C=C0+[[-a-b for a,b in zip(C0[0],C0[1])],[-a+b for a,b in zip(C0[0],C0[1])]]
chains=[[0,8],[1,9]]+[[i] for i in range(2,8)]
whole=(1<<512)-1; zero=1

def elements(a):
    while a:
        low=a & -a; yield low.bit_length()-1; a^=low

def dim(a):
    n=a.bit_count(); assert n and not n & (n-1)
    return n.bit_length()-1

def plus_vec(a,v):
    return a if a>>v & 1 else a | sum(1<<(x^v) for x in elements(a))

@lru_cache(maxsize=None)
def join(a,b):
    # Iterating a basis is enough; plus_vec ignores dependent elements.
    for v in elements(b): a=plus_vec(a,v)
    return a

def supp(a):return tuple(i for i,x in enumerate(a) if x)

@lru_cache(maxsize=None)
def orth(s):
    return sum(1<<v for v in range(512) if all((v & L[i]).bit_count()%2==0 for i in s))

@lru_cache(maxsize=None)
def out(s):
    r=zero
    for t in s:r=plus_vec(r,L[t])
    return r

qperp=[orth((s,)) for s in range(96)]
eps={};control=0
for li,ch in enumerate(chains):
    prev=whole;u=[Q(0)]*96
    for pos,row in enumerate(ch):
        w=[x-y for x,y in zip(W[row],W[ch[pos+1]])] if pos+1<len(ch) else W[row][:]
        a=prev & orth(supp(C[row])); o=out(supp(w)); b=join(a,o)
        u=[x+y for x,y in zip(u,C[row])]; cost=dim(b)-dim(a);control+=cost
        eps[row]={'life':li,'pos':pos,'prev':prev,'a':a,'b':b,'w':w,'c':C[row],
                  'u':u[:],'cost':cost,'out':o}
        prev=b
assert control==58
assert orth(supp(C[8]))==orth(supp(C[9]))==zero

def hs(c,u):
    ex={x/y for x,y in zip(c,u) if x and y};gen=Q(1)
    while gen in ex:gen+=1
    return sorted(ex)+[gen]

def old_prefix(i,inclusive,s):
    e=eps[i];ch=chains[e['life']]
    return [eps[k]['a'] for k in ch[:e['pos']+int(inclusive)] if eps[k]['c'][s]]

def params(src,tak,h,s):
    p=eps[src];q=eps[tak];d=[x-h*y for x,y in zip(q['c'],p['u'])]
    t=q['prev'] & orth(supp(d)) & qperp[s]
    return {'t':t,'v':t&q['out'],'d':d,'h':h,'tak':tak}

def prefix_base(src,taks,s):
    z=eps[src]['b']
    for r in old_prefix(src,True,s):z=join(z,r)
    for tak in taks:
        for r in old_prefix(tak,False,s):z=join(z,r)
    return z

def price(src, taks, ps, source_chart):
    p=eps[src];rise=dim(source_chart)-dim(p['b']);items=[]
    for tak,q in zip(taks,ps):
        a=source_chart&q['t']; e=eps[tak]
        c=dim(join(a,e['out']))-dim(a)
        items.append((dim(a),c,c-e['cost']))
    return 58+rise+sum(x[2] for x in items),rise,items

def run():
    frozen=Counter();frozen_legal=Counter();optim=Counter();src_hist={};examples={};frozen_examples={}
    conflicts=0;trials=0;strata=0;ordered_triples=set();processed={};digest=hashlib.sha256()
    # Precompute all one-recipient data once. A pair of distinct taker
    # lifetimes is joined only after the actual shared Y_s is fixed.
    for src in range(10):
        prior={}; bytak={}
        targets=[j for j in range(10) if eps[j]['life']!=eps[src]['life']]
        for tak in targets:
            bytak[tak]={}
            for h in hs(eps[tak]['c'],eps[src]['u']):
                bytak[tak][h]=[params(src,tak,h,s) for s in range(96)]
        sh=Counter()
        for t1,t2 in product(targets,repeat=2):
            if eps[t1]['life']==eps[t2]['life']:continue
            ordered_triples.add((src,t1,t2))
            for h1,h2 in product(bytak[t1],bytak[t2]):
                strata+=1
                for s in range(96):
                    trials+=1;ps=(bytak[t1][h1][s],bytak[t2][h2][s]);taks=(t1,t2)
                    b0=eps[src]['b'];z=prefix_base(src,taks,s)
                    r0,_,it0=price(src,taks,ps,b0);frozen[r0]+=1
                    if z==b0:
                        frozen_legal[r0]+=1
                        frozen_examples.setdefault(str(r0),[src,t1,t2,str(h1),str(h2),s,it0])
                    else:conflicts+=1
                    # For any admissible B ⊇ Z, enlarging B by S_i = T_i∩L_i
                    # cannot increase the combined price. Thus Z+S1+S2 is
                    # a global optimum over every nested B, with source rise
                    # counted once and both target costs counted separately.
                    b=join(join(z,ps[0]['v']),ps[1]['v'])
                    r,k,items=price(src,taks,ps,b);optim[r]+=1;sh[r]+=1
                    digest.update(f'{src},{t1},{t2},{h1},{h2},{s},{r},{r0},{int(z==b0)}\n'.encode())
                    ex={'source':src,'takers':[t1,t2],'coefficients':[str(h1),str(h2)],
                        'carrier':s,'carrier_label':L[s],'source_chart_extra_rise':k,
                        'source_chart_dim':dim(b),'source_chart_mask_hex':format(b,'x'),
                        'minimum_required_chart_dim':dim(z),'recipient_dims_costs_deltas':items,
                        'R':r}
                    examples.setdefault(str(r),ex)
        src_hist[str(src)]={str(k):v for k,v in sorted(sh.items())}
        processed[str(src)]={'cases':sum(sh.values()),'minimum':min(sh)}
    return {'ordered_triples':len(ordered_triples),'joint_coefficient_strata':strata,'trials':trials,
            'frozen_ignore_prefix_hist':dict(sorted(frozen.items())),
            'frozen_legal_hist':dict(sorted(frozen_legal.items())), 'frozen_prefix_conflicts':conflicts,
            'frozen_legal_examples':frozen_examples,
            'optimized_enlargement_hist':dict(sorted(optim.items())),'by_source':src_hist,
            'per_case_sha256':digest.hexdigest(),
            'examples':examples,'processed':processed,
            'scope':'source plus two distinct recipient lifetimes; both cold intakes prepared before hot write; source held until cleanup; frozen baseline histories and output factors',
            'coefficient_strata':'all nonzero rational cancellation ratios plus one nonzero generic representative; strata extend to all nonzero real coefficients by identical supports'}

if __name__=='__main__':
    print(json.dumps(run(),indent=2,sort_keys=True))
