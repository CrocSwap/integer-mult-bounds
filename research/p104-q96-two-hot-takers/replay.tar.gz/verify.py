#!/usr/bin/env python3
"""Check source identities, independently rerun the census, and replay words."""
import hashlib,json,subprocess,sys,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(b):return hashlib.sha256(b).hexdigest()

def manifest(root):
    mf=root/'SHA256SUMS';entries={}
    for line in mf.read_text().splitlines():
        h,sep,name=line.partition('  ');p=Path(name)
        if not sep or len(h)!=64 or p.is_absolute() or '..' in p.parts or name in entries:
            raise ValueError('invalid manifest entry')
        entries[name]=h
    files={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p!=mf}
    if files!=set(entries):raise ValueError('file set mismatch in '+str(root))
    for n,h in entries.items():
        f=root/n
        if f.is_symlink() or sha(f.read_bytes())!=h:raise ValueError('hash mismatch: '+str(f))
    return len(entries)

def process(script,saved):
    p=subprocess.run([sys.executable,'-B',str(P/script)],cwd=P,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if p.returncode:raise ValueError(script+' failed: '+p.stderr)
    actual=json.loads(p.stdout);expected=json.loads((P/saved).read_text())
    if actual!=expected:raise ValueError(script+' output differs from '+saved)
    return actual

def main():
    n=manifest(P);parent=manifest(P/'parent')
    arc=P/'parent/source/pr7922-replay.tar.gz'
    if sha(arc.read_bytes())!='511e8695c085cfeb5f9e3cac2edd6bfe7cd860475558b9ee42fe2c69953fd673':
        raise ValueError('wrong #7922 archive')
    engine=P/'parent/source/7869/eng.py'
    if sha(engine.read_bytes())!='900b41f42c978e2bca2db001a5dc81dc93953adb5e842a4924d37c860124c2f6':
        raise ValueError('wrong #7869 engine')
    copies={'check.py':'./check.py','data.json':'./data.json',
            'source/7852/DecoderWall4Data.lean':'./source/7852/DecoderWall4Data.lean',
            'source/7869/eng.py':'./source/7869/eng.py','source/round4-parent-19.md':'./README.md'}
    with tarfile.open(arc,'r:gz') as t:
        for local,archived in copies.items():
            f=t.extractfile(archived)
            if f is None or f.read()!=(P/'parent'/local).read_bytes():raise ValueError('archive mismatch '+local)
    s=process('screen.py','SCREEN.json');i=process('independent.py','INDEPENDENT.json');r=process('replay.py','REPLAY.json')
    assert (s['ordered_triples'],s['joint_coefficient_strata'],s['trials'])==(624,7516,721536)
    assert s['optimized_enlargement_hist']=={'58':4704,'59':126264,'60':496572,'61':93996}
    assert s['per_case_sha256']==i['per_case_sha256']=='c7fff9135aaad786288bcaa10e14fdfe69e782373ae66b9cb88ef4fd8aab6075'
    w=r['sharp_R58'];assert (w['R'],w['operations'],w['full_bad_cells'],w['odd_bad_cells'])==(58,1514,0,0)
    assert not w['bad_operations'] and not w['pinning_errors'] and w['carrier_restored'] and w['causal_full_equals_engine']
    assert (w['GF_alone_bad_cells'],w['GF_alone_bad_odd_cells'])==(150,80)
    for key,n_bad in [('omit_first_cancel',1),('omit_second_cancel',1),('omit_both_cancels',2)]:
        x=r[key];assert (x['full_bad_cells'],x['odd_bad_cells'])==(n_bad,n_bad)
        assert not x['bad_operations'] and not x['pinning_errors'] and x['carrier_restored']
    x=r['one_dimensional_pickup_R59'];assert x['R']==59 and x['target_dims_costs_deltas'][0][0]==1
    assert len(x['causal_GF_GHF_and_higher_stats'])==4 and not x['full_bad_cells'] and not x['odd_bad_cells']
    x=r['six_ascent_shared_enlargement'];assert x['R']==59 and x['source_extra_rise']==6 and x['target_dims_costs_deltas'][0][2]==-6
    print('Verified %d packet files and %d parent files, source archive and pinned engine.'%(n,parent))
    print('Recomputed 721,536 cases twice; independent per-case digest '+s['per_case_sha256'])
    print('Exact enlarged-source minimum R=58, legal R=58 word, two recipient mutation controls and causal expansion all passed.')

if __name__=='__main__':
    try:main()
    except (ValueError,AssertionError,KeyError,OSError,json.JSONDecodeError) as e:
        print('Verification failed: '+str(e),file=sys.stderr);sys.exit(1)
