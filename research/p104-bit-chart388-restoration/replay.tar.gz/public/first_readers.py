#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
# SPDX-License-Identifier: Apache-2.0
"""Recover both public coefficients and the first recipient uses literally."""
from pathlib import Path
from hashlib import sha256
import gzip,json
HERE=Path(__file__).resolve().parent;raw=(HERE/'r1/inputs/WORD.json.gz').read_bytes();assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9';w=json.loads(gzip.decompress(raw));assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
N=w['public'];p=w['program'];values=[1<<i for i in range(N)]+[0]*w['owned_fields'];tags=w['start'][:]+[None]*w['owned_fields'];snap={}
def support(v):return [i for i in range(N) if v>>i&1]
for i,e in enumerate(p[:2927]):
 if i in (2922,2926):snap[i]={str(r):{'tag':tags[r],'support':support(values[r])} for r in (43,405,924,1122,1495,1496,1497,927) if tags[r] is not None}
 op,r,*a=e
 if op=='INIT':assert tags[r] is None;tags[r]=a[0];values[r]=0
 elif op=='CLEAR':assert tags[r]==a[0];tags[r]=None;values[r]=0
 elif op=='SWAP':h=a[0];tags[r],tags[h]=tags[h],tags[r];values[r],values[h]=values[h],values[r]
 elif op=='ADD':h,c=a;assert tags[r]==tags[h]==c;values[r]^=values[h]
 elif op=='MOVE':assert tags[r]==a[0];tags[r]=a[1]
 else:raise ValueError(op)
assert snap[2922]['924']['support']==[43,321] and snap[2922]['1122']['support']==[74,405]
assert snap[2922]['1495']['support']==[527] and snap[2922]['1496']['support']==[43,74,321,405,527]
assert snap[2926]['1497']['support']==[43,74,321,405]
def reads(role,start):
 out=[]
 for i,e in enumerate(p[start+1:],start+1):
  op,r,*a=e
  if op=='ADD' and a[0]==role:out.append([i,e])
  elif op in ('MOVE','SWAP') and (r==role or(op=='SWAP' and a[0]==role)):out.append([i,e])
  elif op=='CLEAR' and r==role:break
 return out
r1496=reads(1496,2922);r1497=reads(1497,2926)
assert [x[0] for x in r1496]==[5191,5197,5218,5225]
assert [x[0] for x in r1497]==[6315,6322,6328,6342,6348]
assert [x[0] for x in reads(924,2922)]==[2924,2928]
assert [x[0] for x in reads(1122,2922)]==[2925]
out={'status':'PASS_OPPOSITE_COEFFICIENT_AND_RECIPIENT_READS','word':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','snapshots':snap,'1496_reads':r1496,'1497_reads':r1497,'924_reads_after_2922':reads(924,2922),'1122_reads_after_2922':reads(1122,2922)}
(HERE/'receipts/FIRST-READERS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'])
