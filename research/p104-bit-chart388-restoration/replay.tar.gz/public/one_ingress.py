#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
"""Optimistic search: change one earlier payload, fixed 388 sender charts.

Every source introduction retains the original literal event/grade; exactly
one earlier MOVE's payload may change by delta. The 14 original source rows
react by the exact linear incidence signature; all histories may be shadowed
for free, and original triangular 388 demands must be recovered. No pricing.
"""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict,Counter
import gzip,json
P=(Path(__file__).resolve().parent/'r1/inputs/WORD.json.gz');raw=P.read_bytes();assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
N=w['public']; prog=w['program']; end=8954; srcs=(560,283,311); omit={880,5207,6326}; high=1<<N

def bits(x):return [i for i in range(N) if (x>>i)&1]
class Basis:
 def __init__(self):self.rows={};self.piv=0
 def reduce(self,x,w=0):
  while z:=x&self.piv:
   r,q=self.rows[z.bit_length()-1];x^=r;w^=q
  return x,w
 def add(self,x,w=0):
  x,w=self.reduce(x,w)
  if x:
   k=x.bit_length()-1;self.rows[k]=(x,w);self.piv|=1<<k
 def clone(self):
  o=Basis();o.rows=self.rows.copy();o.piv=self.piv;return o

# Exact, unchanged forward word; record every source arrival and historical
# sender provenance. Values are bitsets over public coordinates.
values=[1<<i for i in range(N)]+[0]*w['owned_fields'];tags=w['start'][:]+[None]*w['owned_fields'];hist=defaultdict(list);active=defaultdict(dict);entries=[];snap={}; candidates=[]
for r,c in enumerate(w['start']):hist[c].append((-1,r,1<<r));active[c][r]=1<<r
for i,e in enumerate(prog[:end]):
 op,r,*a=e
 if op=='INIT':assert tags[r] is None;tags[r]=a[0];values[r]=0;active[a[0]][r]=0
 elif op=='CLEAR':
  assert tags[r]==a[0];del active[a[0]][r];tags[r]=None;values[r]=0
 elif op=='SWAP':
  p=a[0];ca,cb=tags[r],tags[p];assert ca is not None and cb is not None
  va,vb=values[r],values[p];del active[ca][r];del active[cb][p];active[cb][r]=vb;active[ca][p]=va;tags[r],tags[p]=cb,ca;values[r],values[p]=vb,va
 elif op=='ADD':
  p,c=a;assert tags[r]==tags[p]==c and r!=p;values[r]^=values[p];active[c][r]=values[r]
 elif op=='MOVE':
  s,d=a;assert tags[r]==s
  candidates.append((i,r,s,d,values[r],hist[s][:],dict(active[s])))
  del active[s][r];active[d][r]=values[r];tags[r]=d
  hist[d].append((i,r,values[r]));
  if d in srcs:entries.append((i,r,d,values[r]))
 else:raise ValueError(e)
assert len(entries)==14 and all((v&((1<<43)|(1<<405))).bit_count()%2==0 for _,_,_,v in entries)
assert not [e for e in hist[388] if e[0] not in omit]
u=[values[r] for r in (927,2023,2190)];assert u[0]==1<<43
# Reverse propagate a distinct bit for each of 14 source arrivals.
at={c:j for j,(c,_,_,_) in enumerate(entries)};sig=[0]*len(values);signatures={}
for i in range(end-1,-1,-1):
 op,r,*a=prog[i]
 if i in at:sig[r]^=1<<at[i]
 if op=='ADD':sig[a[0]]^=sig[r]
 elif op=='SWAP':p=a[0];sig[r],sig[p]=sig[p],sig[r]
 elif op in ('INIT','CLEAR'):sig[r]=0
 elif op=='MOVE':signatures[i]=sig[r]
 else:raise ValueError(op)
assert signatures[2922]==1<<at[2922] and signatures[2926]==1<<at[2926]
# For each signature k, U0 is reachable after one change if
# U0 = xor(selected unchanged source rows) xor delta, with selected rows'
# signature parity one and delta lying in old sender's span. An auxiliary
# bit enforces that parity. Grant all source histories for free.
cache={}
def base(signature):
 if signature not in cache:
  b=Basis()
  for j,(_,_,_,v) in enumerate(entries):b.add(v | (high if signature>>j&1 else 0),1<<j)
  cache[signature]=b
 return cache[signature]
def query(signature, available):
 b=base(signature).clone(); shift=len(entries)
 for j,(_,_,v) in enumerate(available):b.add(v,1<<(shift+j))
 rem,form=b.reduce(u[0]|high)
 if rem:return None
 chosen=[j for j in range(len(entries)) if form>>j&1];terms=[available[j] for j in range(len(available)) if form>>(shift+j)&1]
 delta=0
 for _,_,v in terms:delta^=v
 assert (delta & ((1<<43)|(1<<405))).bit_count()%2==1
 return chosen,terms,delta
hits=[];counts=Counter();listed=[]
for i,r,s,d,v,history,live in candidates:
 sig=signatures[i]
 if i in omit or not sig:continue
 counts['influential_other_moves']+=1
 if not any((x&((1<<43)|(1<<405))).bit_count()%2 for _,_,x in history):continue
 counts['pulse_accessible_optimistic']+=1
 h=query(sig,history)
 if h is None:continue
 counts['union_repair_with_free_history']+=1
 live_available=[(-2,role,value) for role,value in sorted(live.items())]
 l=query(sig,live_available)
 if l is not None:counts['union_repair_with_live']+=1
 def serial(x):
  if x is None:return None
  chosen,terms,delta=x
  return {'selected_sender_entries':chosen,'delta':bits(delta),'available_terms':[{'clock':c,'role':r,'support':bits(v)} for c,r,v in terms]}
 hit={'clock':i,'role':r,'source':s,'destination':d,'original':bits(v),'signature':sig,'affected_sender_entries':[j for j in range(len(entries)) if sig>>j&1],'history_witness':serial(h),'live_witness':serial(l)}
 hits.append(hit)
print('counts',dict(counts),'signatures',len(cache),'hits',len(hits))
for x in hits[:40]:print('hit',x['clock'],x['role'],x['source'],x['destination'],'affects',x['affected_sender_entries'],'delta',x['history_witness']['delta'],'live',bool(x['live_witness']))
out={'scope':'one original earlier MOVE payload recoded, arbitrary earlier sender-history span; unchanged old 388 triangular targets; 14 source histories and their exact influence signatures; free shadows; no paid/restore/ownership invoice; excludes MOVE at 880,5207,6326','word':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','sender_entries':[{'index':j,'clock':c,'role':r,'chart':s,'support':bits(v)} for j,(c,r,s,v) in enumerate(entries)],'counts':dict(counts),'signatures':{str(i):s for i,s in signatures.items()},'hits':hits}
(Path(__file__).resolve().parent/'receipts/ONE-INGRESS.json').write_text(json.dumps(out,indent=2)+'\n')
