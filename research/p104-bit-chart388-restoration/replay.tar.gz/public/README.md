# Chart 388: upstream and borrowed-arrival controls

On the pinned binary word from #7830, no tested edit establishes a positive BIT invoice change. The packet contains a complete **zero-net native word** and two bounded screens explaining why the apparent chart-388 saving is difficult to fund. The changed word is a control: it reproduces every native forward and adjoint coefficient and leaves the entire 36-call paid and productive histograms unchanged. It does not establish a new κ bound.

The original fixed-source certificate, its independent pulse checks, source URLs, credits, complete invoice and license are included unchanged in [r1](r1/README.md). It tests the grade-five-to-grade-one ingress proposal with fixed chart 560, 283 and 311 histories and the three original chart-388 reader outputs. Its pulse `{43,405}` separates the original first ingress from all 14 source-history rows. Its scope allows both incumbent rank-two payloads to be recoded, all historical shadows to be free, and late delivery; it does not allow changed earlier data. The present packet tests some specific ways to change that earlier data or borrow an already-paid arrival.

## Source and reconstruction

All clocks below are zero-based in the source word. The upstream scientific head is [#7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830). The canonical original word SHA-256 is `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. The compressed original word, caller, invoice and verifier source pins are in [r1/SOURCES.json](r1/SOURCES.json).

[inputs/ZERO-NET-WORD.json.gz](inputs/ZERO-NET-WORD.json.gz) is an actual `BIT-functional-GL-kernel-native/1` word with 42,958 instructions. Its compressed byte SHA-256 is `e83abcf1a2bba96681ac14bc6c76eb4ff78db86f7677ea1f19c1b839cdf275a8`; its canonical uncompressed SHA-256 is `98fac9b1c809a3edb41fdaf140cee4656ffa6992e621c78be1ac0b982934f738`.

The control cycles three existing routes:

| Clock | Original route and value | Control route and value |
| ---: | --- | --- |
| 873 | 45 → 295, `x43+x322`, grade 3 | 45 → 388, `x43`, grade 5 |
| 877 | 45 → 322, `x43+x323`, grade 3 | 45 → 295, `x43+x322`, grade 3 |
| 880 | 45 → 388, `x43`, grade 5 | 45 → 322, `x43+x323`, grade 3 |

The later receiver-role references are permuted consistently. The script reconstructs this entire word from the pinned source, authenticates the included bytes, then runs the pinned literal checker in both orientations on all 680² native scalar coefficients. The native paid grades, complete 36-call paid and target histograms, ordinary account, instruction counts and owned peaks are identical. Replacing a donor with the wrong one changes 57 public output rows. See [zero-net receipt](receipts/ZERO-NET-CYCLE.json).

This is a **different contract** from the fixed-source proposal: it drops the hypothetical chart-560 send altogether and restores both old receivers by moving their original information around. The paid grades are merely permuted. No finite construction, precision transfer, stock compiler or higher exponent follows from the zero-net native replay.

## One earlier payload

The lost coefficient is not only `x43`. At clock 2922, source chart 160 has role 924 equal to `x43+x321`, role 1122 equal to `x74+x405`, and role 1495 equal to `x527`. Their sum becomes role 1496 at chart 283. At clock 2926, the first two terms become role 1497 at chart 311. The old first receiver reads are clock 5191 for 1496 and 6315 for 1497; their other reads and the donor uses are reproduced in [FIRST-READERS.json](receipts/FIRST-READERS.json). Both initial payloads vanish on `{43,405}` because the `x43` and `x405` coefficients cancel; deleting either term would change the recipient's other coefficient and affect its readers.

The [one-ingress screen](receipts/ONE-INGRESS.json) considers one earlier *existing MOVE* whose source and destination stay fixed, with all other earlier operations fixed. Its payload may be any GF(2) combination of the full earlier history at its sender, with all shadows and the later 388 sender histories free. Among 1,903 earlier MOVE sites, 162 affect at least one of the 14 source introductions and 64 of those can access a pulse-nonzero sender-history row. None can make `u1=x43` belong to the union of the altered 560/283/311 histories. An auxiliary parity bit enforces the exact effect of the single alteration on each of those 14 introductions. The other original 388 reader values remain required.

A separately written forward-lane replay checks all 1,903 reverse influence signatures, including each introduction's own event. [Signature receipt](receipts/SIGNATURE-VALIDATION.json). This is not an impossibility result for changing the earlier MOVE's source or destination, changing two earlier arrivals, adding another paid event, altering a receiver contract, or restoring only final outputs.

## Borrowing a fourth sender

For the three fixed sender banks, the row spaces form a direct sum of dimensions 2, 6 and 6. The second and third old 388 demands lie in the 283 and 311 banks, respectively, while `u1` is outside their union. To recover all three demands from one message per fixed source plus one distinct fourth message, the fourth message must lie among `u1 + b560 + a·u2 + b·u3`, with `b560` any of the four combinations of chart 560's two old rows and `a,b ∈ GF(2)`. The [live fourth-source scan](receipts/FOURTH-SOURCE.json) checks all 16 classes at every eligible old MOVE before clock 8954. It allows free old sender histories, simultaneous late sends and free restoration of the borrowed event's old receiver. Of 1,890 eligible events, four have a live target-class witness before geometry; only clocks **873 and 877** survive the pinned nested-leg and positive-gross screens. Both use the live public role 43 and both leave the old 560/283/311 introduction histories unchanged in the one-event incidence replay.

Redirecting either grade-three event to 388 costs grade five. Together with the hypothetical `5 → 1` target replacement, the optimistic paid gain per native call is `3^(1-C) − 1`, before the old recipient is repaired and before target or ownership changes. It is about `1.98724` at the screen's trial `C=0.003879929048842`; this numerical gross is not a qualified gain. The original recipient of clock 873 needs `x43+x322` at chart 295, first read at 5672. For clock 877 it needs `x43+x323` at chart 322, first read at 6767.

Each old destination originally receives six independent scalar rows and emits six independent protected output rows, with no other introduction through those outputs. Their exact six-by-six reader matrices have rank six over GF(2). Thus five remaining arrivals cannot preserve those six outputs, even if they are arbitrarily recoded or a grade-one transfer is sent to an intermediate chart. [Reader and atlas controls](receipts/RECEIVER-CONTROLS.json) independently replay both ranks; deleting one input direction or duplicating an output reduces the tested rank to five.

Both destinations have rank-four frames. The pinned 636-frame atlas contains no rank-three or rank-five frame, and the remaining rank-four frames are distinct, so it has no distinct grade-zero or grade-one source for either destination. The [grade-two restoration screen](receipts/GRADE2-TRANSVERSAL.json) checks all 11 possible fixed-atlas grade-two source subspaces for each receiver. It even grants the five original senders and the sixth source all of their historical rows for free through the first missing read. The five original source banks each meet the six-dimensional protected target space only in their own singleton input class; none of the 11 possible sixth sources can supply a target class containing the missing input.

Consequently, under this direct sixth-arrival model, a new arrival costs at least grade three. If the redundant hypothetical 560 send is omitted entirely, the optimistic gross before this restore is only `3^(1-C)`, so a grade-three direct restore already consumes the whole gross. If the grade-one 560 send is kept, a grade-two restore would already exceed the gross, since `3^t < 1+2^t` for `0<t<1`. Both statements assume unchanged productive targets and no offset from other paid edits. The screen does not rule out reusing another already-paid incoming event, new frames, changed source histories, multiple coordinated edits, or relaxing intermediate outputs. The included zero-net control demonstrates one such route cycle without claiming a gain.

## Reproduce

The packet uses the Python 3.12 standard library and the included, pinned literal and price checkers. Assertions must remain enabled for the new scripts. From this directory:

```sh
sha256sum -c SHA256SUMS
(cd r1 && sha256sum -c SHA256SUMS && python3 -IB replay.py && python3 -IB pulse.py && python3 -IB independent_pulse.py && python3 -IB fault_controls.py)
python3 -IB first_readers.py
python3 -IB one_ingress.py
python3 -IB validate_signatures.py
python3 -IB fourth_source.py
python3 -IB check_receivers.py
python3 -IB grade2_transversal.py
python3 -IB zero_net_replay.py
python3 -IB fault_controls.py
```

The replay scripts write their receipts under `receipts/` and the original checks write under `r1/`; saved receipts can be compared byte for byte after rerun. The new geometry controls use exact integer arithmetic modulo 65521: higher modular rank certifies noncontainment over the rationals. The grade-two filter deliberately includes every rationally possible grade-two source, possibly more, before the sender-span screen. The zero-net replay uses the pinned literal checker rather than claiming an independent implementation of that native verifier. The new fault-control script rejects changed source and candidate bytes, a changed influence signature, and optimized execution with assertions disabled.

The accessible [coordination discussion #7111](https://github.com/CrocSwap/integer-mult-bounds/discussions/7111), checked on 21 November 2026, contains related causal-history work but did not display a matching chart-388 finding. Loaded replies and external work may not appear in that view; this is a bounded overlap check, not a novelty claim. Refresh coordination before any publication. Credits are retained in [NOTICE](NOTICE) and [r1/NOTICE](r1/NOTICE). No upstream publication is made by this packet.
