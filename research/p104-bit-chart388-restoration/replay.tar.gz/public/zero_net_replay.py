#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
# SPDX-License-Identifier: Apache-2.0
"""Rebuild and check the entire no-gain three-route control in both directions."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
import copy,gzip,json,sys
HERE=Path(__file__).resolve().parent
PINS={
 'r1/inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'r1/inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'r1/vendor/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'inputs/ZERO-NET-WORD.json.gz':'e83abcf1a2bba96681ac14bc6c76eb4ff78db86f7677ea1f19c1b839cdf275a8'}
for path,digest in PINS.items():
 if sha256((HERE/path).read_bytes()).hexdigest()!=digest:raise ValueError('input pin '+path)
sys.path.insert(0,str(HERE/'r1/vendor'));import literal as lit
def load(p):return json.loads(gzip.decompress((HERE/p).read_bytes()))
old=load('r1/inputs/WORD.json.gz');new=load('inputs/ZERO-NET-WORD.json.gz');caller=load('r1/inputs/EFREE-CALLER.json.gz')
assert lit.canonical(old)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
assert lit.canonical(new)=='98fac9b1c809a3edb41fdaf140cee4656ffa6992e621c78be1ac0b982934f738'
assert new['schema']=='BIT-functional-GL-kernel-native/1';p=old['program']
assert p[870:881]==[['INIT',925,45],['ADD',925,43,45],['ADD',925,921,45],['MOVE',925,45,295],['INIT',926,45],['ADD',926,43,45],['ADD',926,922,45],['MOVE',926,45,322],['INIT',927,45],['ADD',927,43,45],['MOVE',927,45,388]]
rebuilt=copy.deepcopy(old);q=[];perm={925:926,926:927,927:925}
for i,event in enumerate(p):
 if i==872:continue
 e=event[:]
 if i==873:e=['MOVE',925,45,388]
 if i==876:e=['ADD',926,921,45]
 if i==877:e=['MOVE',926,45,295]
 if i==880:q.append(['ADD',927,922,45]);e=['MOVE',927,45,322]
 if i>=881:
  e[1]=perm.get(e[1],e[1])
  if e[0] in ('ADD','SWAP'):e[2]=perm.get(e[2],e[2])
 q.append(e)
rebuilt['program']=q;assert rebuilt==new and len(q)==len(p)==42958
charts=lit.Charts(old['frames']);assert charts.main_contacts(old['start'],old['final'])==111
of,ofl,_=lit.tape(old,charts);oa,oal,_=lit.tape(old,charts,adjoint=True)
nf,nfl,_=lit.tape(new,charts);na,nal,_=lit.tape(new,charts,adjoint=True)
assert of==nf==lit.expected_rows(680,False) and oa==na==lit.expected_rows(680,True)
assert ofl['paid']==oal['paid']==nfl['paid']==nal['paid'] and ofl['counts']==nfl['counts']
assert ofl['peak']==nfl['peak'] and oal['peak']==nal['peak']
assert old['frames']==new['frames'] and old['start']==new['start'] and old['final']==new['final']
targets=Counter(charts.leg(a,b) for a,b in zip(new['start'][222:],new['final'][222:]));events=Counter(e[0] for e in caller['events'])
before=lit.paired_invoice(caller,ofl['paid'],targets,events);after=lit.paired_invoice(caller,nfl['paid'],targets,events)
assert before==after and events['LOCAL']==36
assert lit.ordinary(old,caller,events,*before)==lit.ordinary(new,caller,events,*after)
bad=copy.deepcopy(new);j=next(i for i,e in enumerate(bad['program']) if e==['ADD',926,921,45]);bad['program'][j]=['ADD',926,922,45]
badrows,_,_=lit.tape(bad,charts);wrong=[i for i,(a,b) in enumerate(zip(badrows,nf)) if a!=b];assert len(wrong)==57
out={'status':'PASS_ZERO_NET_CYCLE_NATIVE_FORWARD_AND_ADJOINT','word_sha256':lit.canonical(old),'candidate_word_sha256':lit.canonical(new),'candidate_gzip_sha256':PINS['inputs/ZERO-NET-WORD.json.gz'],'old_new_moves':{'old':[[873,925,45,295],[877,926,45,322],[880,927,45,388]],'new':[[873,925,45,388],[877,926,45,295],[880,927,45,322]]},'old_to_new_receiving_role_map':perm,'native_paid':dict(sorted(nfl['paid'].items())),'complete_36_call_paid_equal':True,'complete_36_call_targets_equal':True,'ordinary_account_equal':True,'both_orientations_match_all_680_coefficients':True,'original_peaks':[ofl['peak'],oal['peak']],'new_peaks':[nfl['peak'],nal['peak']],'wrong_donor_public_mismatch_count':len(wrong),'scope':'Exact native three-route control drops the proposed 560 source; no paid/target gain, no changed finite/stock/precision certification or new kappa.'}
(HERE/'receipts/ZERO-NET-CYCLE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'],out['candidate_word_sha256'])
