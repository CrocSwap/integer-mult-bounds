#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
# SPDX-License-Identifier: Apache-2.0
"""Exclude fixed-atlas grade-2 direct restorations of six old receiver rows.

All five old senders and the added sixth source receive unlimited free late
historical shadows. Their outgoing field is restricted only by its source
span. One sender per arrival, all six original receiver outputs required.
"""
from pathlib import Path
from hashlib import sha256
from collections import defaultdict
import gzip,json
HERE=Path(__file__).resolve().parent;raw=(HERE/'r1/inputs/WORD.json.gz').read_bytes();assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9';w=json.loads(gzip.decompress(raw));assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
N=w['public'];p=w['program'];frames={int(k):f for k,f in w['frames'].items()};P=65521
class B:
 def __init__(self):self.rows={};self.piv=0
 def reduce(self,v):
  while h:=v&self.piv:v^=self.rows[h.bit_length()-1]
  return v
 def add(self,v):
  v=self.reduce(v)
  if v:
   k=v.bit_length()-1;self.rows[k]=v;self.piv|=1<<k
 def copy(self):
  z=B();z.rows=self.rows.copy();z.piv=self.piv;return z
def modrank(rows):
 if not rows:return 0
 a=[[int(x)%P for x in row] for row in rows];r=0
 for c in range(len(a[0])):
  pivot=next((j for j in range(r,len(a)) if a[j][c]),None)
  if pivot is None:continue
  a[r],a[pivot]=a[pivot],a[r];q=pow(a[r][c],-1,P);a[r]=[v*q%P for v in a[r]]
  for j in range(r+1,len(a)):
   q=a[j][c]
   if q:a[j]=[(x-q*y)%P for x,y in zip(a[j],a[r])]
  r+=1
  if r==len(a):break
 return r
# Every frame is a full rational orthogonal decomposition; the modular check
# certifies nonzero rational determinants and rank. Grade 2 between commuting
# orthogonal projectors requires dim(intersection)=(dA+dB-2)/2. Modular rank
# can underestimate rational rank, so this candidate selection is a superset.
for f in frames.values():
 Bf,Af=f['B'],f['A'];assert len(Bf)==f['dim'] and len(Bf)+len(Af)==8 and modrank(Bf+Af)==8
 assert all(sum(x*y for x,y in zip(b,a))==0 for b in Bf for a in Af)
cases=[{'event':873,'destination':295,'deadline':5672,'inputs':[873,2359,2502,2577,3012,3312]}, {'event':877,'destination':322,'deadline':6767,'inputs':[877,3361,3616,3766,3991,4411]}]
for c in cases:
 dst=c['destination'];T=frames[dst]['B'];assert len(T)==4;potential=[]
 for s,f in frames.items():
  k=f['dim']
  if s==dst or k not in (2,4,6):continue
  if k+4-modrank(T+f['B']) >= (k+4-2)//2:potential.append(s)
 assert len(potential)==11
 values=[1<<i for i in range(N)]+[0]*w['owned_fields'];tags=w['start'][:]+[None]*w['owned_fields'];hist=defaultdict(list);inputs=[]
 for r,k in enumerate(w['start']):hist[k].append((-1,r,values[r]))
 for i,e in enumerate(p[:c['deadline']]):
  op,r,*a=e
  if op=='INIT':assert tags[r] is None;tags[r]=a[0];values[r]=0
  elif op=='CLEAR':assert tags[r]==a[0];tags[r]=None;values[r]=0
  elif op=='SWAP':h=a[0];tags[r],tags[h]=tags[h],tags[r];values[r],values[h]=values[h],values[r]
  elif op=='ADD':h,k=a;assert tags[r]==tags[h]==k;values[r]^=values[h]
  elif op=='MOVE':
   s,d=a;assert tags[r]==s
   if i in c['inputs']:inputs.append(values[r])
   tags[r]=d;hist[d].append((i,r,values[r]))
  else:raise ValueError(op)
 assert len(inputs)==6;ib=B()
 for v in inputs:ib.add(v)
 assert len(ib.rows)==6
 target=[0]*64
 for m in range(1,64):
  for j,v in enumerate(inputs):
   if m>>j&1:target[m]^=v
 senders=[p[i][2] for i in c['inputs'] if i!=c['event']];classes=[]
 for s in senders:
  bank=B()
  for _,_,v in hist[s]:bank.add(v)
  classes.append([m for m in range(1,64) if not bank.reduce(target[m])])
 assert classes==[[2],[4],[8],[16],[32]]
 passing=[]
 for s in potential:
  bank=B()
  for _,_,v in hist[s]:bank.add(v)
  odd=[m for m in range(1,64,2) if not bank.reduce(target[m])]
  if odd:passing.append({'source':s,'classes':odd})
 assert not passing
 # Mutation control: the withheld first input is sufficient if supplied free.
 positive=B();positive.add(inputs[0]);assert not positive.reduce(target[1])
 c.update({'five_sender_charts':senders,'five_sender_target_classes':classes,'possible_grade2_sources':potential,'possible_grade2_count':len(potential),'grade2_transversal_passes':passing,'freely_supplied_missing_input_control':True})
out={'status':'PASS_FIXED_ATLAS_GRADE2_RESTORATION_CUT','word':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','scope':'Both original six-row receiver outputs retained; original five sender charts and one new direct source given free history through first missing reader. The six messages must span their 6D target space. Fixed 636-frame atlas, unchanged other histories; no extra borrowed event, changed frames, or final-only relaxation.','method':'One message from each of the five old sources has exactly its singleton target class. A sixth grade2 source must supply a target class containing the missing first input; the modular geometry filter includes every possible rational grade2 source, possibly more.','cases':cases}
(HERE/'receipts/GRADE2-TRANSVERSAL.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'],[(x['destination'],x['possible_grade2_count']) for x in cases])
