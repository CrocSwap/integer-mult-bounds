#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
"""Independent forward-lane controls of every reverse MOVE signature."""
from pathlib import Path
from hashlib import sha256
import gzip,json
P=(Path(__file__).resolve().parent/'r1/inputs/WORD.json.gz'); raw=P.read_bytes(); assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'; w=json.loads(gzip.decompress(raw)); assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
record=json.loads((Path(__file__).resolve().parent/'receipts/ONE-INGRESS.json').read_text()); rev={int(k):v for k,v in record['signatures'].items()}; E=record['sender_entries']; entry={e['clock']:e for e in E}; prog=w['program']; clocks=sorted(rev); lane={c:j for j,c in enumerate(clocks)}; val=[0]*(w['public']+w['owned_fields']); obs={}
for i,(op,r,*a) in enumerate(prog[:8954]):
 if op in ('INIT','CLEAR'):val[r]=0
 elif op=='SWAP':p=a[0];val[r],val[p]=val[p],val[r]
 elif op=='ADD':val[r]^=val[a[0]]
 elif op=='MOVE':
  val[r]^=1<<lane[i]
  if i in entry:obs[entry[i]['index']]=val[r]
 else:raise ValueError(op)
assert len(obs)==len(E)==14
mismatches=[]
for c,j in lane.items():
 signature=sum(((obs[k]>>j)&1)<<k for k in range(len(E)))
 if signature!=rev[c]:mismatches.append({'clock':c,'forward':signature,'reverse':rev[c]})
assert not mismatches
assert rev[2922]==1<<next(e['index'] for e in E if e['clock']==2922)
assert rev[2926]==1<<next(e['index'] for e in E if e['clock']==2926)
# Controls: zero output claims and event count would fail if any signature
# were shifted one entry or if the same-event source arrival were omitted.
assert any(s and (s<<1)!=s for s in rev.values())
assert 0!=rev[2922]
out={'status':'PASS_FORWARD_LANE_SIGNATURE_RECONSTRUCTION','word':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','checked_moves':len(clocks),'source_arrivals':len(E),'nonzero_signature_moves':sum(s!=0 for s in rev.values()),'all_equal':not mismatches,'controls':['single-event source arrival 2922','single-event source arrival 2926','zero-signature mutation','shifted-entry mutation']}
(Path(__file__).resolve().parent/'receipts/SIGNATURE-VALIDATION.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
