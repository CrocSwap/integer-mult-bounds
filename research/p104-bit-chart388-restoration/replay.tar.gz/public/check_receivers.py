#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
"""Independent exact reader-rank and fixed-atlas grade-0/1 controls.

No NumPy, supplier source, projector construction, or reverse-tape code. Rank
is computed modulo a fixed prime; a rank > bound modulo p also exceeds that
bound over Q, so it soundly excludes subspace containment over Q.
"""
from hashlib import sha256
from pathlib import Path
from collections import Counter
import gzip,json
P=(Path(__file__).resolve().parent/'r1/inputs/WORD.json.gz');raw=P.read_bytes();assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9';w=json.loads(gzip.decompress(raw)); assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
P=65521
def rank(rows):
 if not rows:return 0
 a=[[int(x)%P for x in row] for row in rows];m=len(a);n=len(a[0]);r=0
 for c in range(n):
  pivot=next((j for j in range(r,m) if a[j][c]),None)
  if pivot is None:continue
  a[r],a[pivot]=a[pivot],a[r];q=pow(a[r][c],-1,P);a[r]=[(v*q)%P for v in a[r]]
  for j in range(r+1,m):
   q=a[j][c]
   if q:a[j]=[(x-q*y)%P for x,y in zip(a[j],a[r])]
  r+=1
  if r==m:break
 return r
def bitrank(rows):
 rows=list(rows);r=0
 for c in range(680):
  k=next((j for j in range(r,len(rows)) if (rows[j]>>c)&1),None)
  if k is not None:
   rows[r],rows[k]=rows[k],rows[r]
   for j in range(r+1,len(rows)):
    if (rows[j]>>c)&1:rows[j]^=rows[r]
   r+=1
 return r
frames={int(k):v for k,v in w['frames'].items()}; assert len(frames)==636
for i,f in frames.items():
 B=f['B'];A=f['A'];assert len(B)==f['dim'] and len(A)==8-f['dim'];assert rank(B)==len(B) and rank(B+A)==8
 assert all(sum(x*y for x,y in zip(b,a))==0 for a in A for b in B)
results=[]
for dst in (295,322):
 B=frames[dst]['B'];assert len(B)==4;counts=Counter();low=[]
 for s,f in frames.items():
  k=f['dim']
  if abs(k-4)>1:continue
  counts[str(k)]+=1;z=rank(B+f['B'])
  if z==max(k,4):low.append(s)
 assert low==[dst]
 # A synthetic co-chart and nested hyperplane must both trigger controls.
 assert rank(B+B)==4 and rank(B+B[:3])==4
 results.append({'destination':dst,'frame_dimensions_checked':dict(counts),'distinct_original_atlas_neighbors_grade_0_or_1':[],'self_grade0_only':True,'controls':['duplicate target subspace detected','synthetic nested rank-three subspace detected']})
cases=[{'dst':295,'inputs':[873,2359,2502,2577,3012,3312],'outputs':[5677,5684,5690,5697,5704,5710]}, {'dst':322,'inputs':[877,3361,3616,3766,3991,4411],'outputs':[6758,6765,6772,6779,6786,6792]}]
for c in cases:
 vals=[1<<i for i in range(w['public'])]+[0]*w['owned_fields'];tags=w['start'][:]+[None]*w['owned_fields'];ins=[];outs=[];introductions=[-1 for t in w['start'] if t==c['dst']];window={};matrix=[];cur=0
 for i,e in enumerate(w['program'][:c['outputs'][-1]+1]):
  op,r,*a=e
  if op=='INIT':assert tags[r] is None;tags[r]=a[0];vals[r]=0
  elif op=='CLEAR':assert tags[r]==a[0];tags[r]=None;vals[r]=0
  elif op=='SWAP':p=a[0];tags[r],tags[p]=tags[p],tags[r];vals[r],vals[p]=vals[p],vals[r]
  elif op=='ADD':p,d=a;assert tags[r]==tags[p]==d;vals[r]^=vals[p]
  elif op=='MOVE':
   s,d=a;assert tags[r]==s
   if d==c['dst']:introductions.append(i)
   if i in c['inputs']:ins.append(vals[r])
   if i in c['outputs']:outs.append(vals[r])
   tags[r]=d
  else:raise ValueError(e)
 assert introductions==c['inputs'] and len(ins)==len(outs)==6 and bitrank(ins)==bitrank(outs)==6
 # Independently reconstruct the 6x6 demand coefficient matrix from the
 # literal peer roles used to initialize the six output fields.
 roles=[w['program'][i][1] for i in c['inputs']]
 start=next(i for i,e in enumerate(w['program']) if e[0]=='INIT' and e[1]==w['program'][c['outputs'][0]][1]);coeff=0
 for i,e in enumerate(w['program'][start:c['outputs'][-1]+1],start):
  if e[0]=='INIT':coeff=0
  elif e[0]=='ADD':assert e[2] in roles;coeff^=1<<roles.index(e[2])
  elif e[0]=='MOVE':matrix.append(coeff)
 assert len(matrix)==6 and bitrank(matrix)==6
 assert bitrank([v & ~1 for v in matrix])==5 and bitrank(matrix[:-1]+matrix[:1])==5
 c.update({'input_rank':bitrank(ins),'output_rank':bitrank(outs),'six_by_six_reader_masks':matrix,'matrix_rank':bitrank(matrix),'drop_one_ingress_control':5,'duplicate_one_output_control':5})
out={'status':'PASS_INDEPENDENT_RECEIVER_RANK_AND_ATLAS','word':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','modulus':P,'method':'Exact modular ranks certify noncontainment over Q; B/A orthogonal full-rank frames make grade 0 equality and grade 1 strict codimension-one containment necessary. Scalar reader ranks replayed independently with GF(2) bitsets.','geometry':results,'readers':cases}
(Path(__file__).resolve().parent/'receipts/RECEIVER-CONTROLS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
