#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
# SPDX-License-Identifier: Apache-2.0
"""Screen one already-paid, distinct, live fourth sender before clock 8954.

The first three source histories are frozen, and the original three 388
reader rows must be reconstructed from four whole-field messages. This grants
free shadows and late sends, and assumes free restoration of the borrowed
old recipient. It is not a candidate word or a complete price.
"""
from pathlib import Path
from hashlib import sha256
from decimal import Decimal,localcontext
from collections import defaultdict,Counter
import gzip,json,sys
HERE=Path(__file__).resolve().parent
assert sha256((HERE/'r1/vendor/literal.py').read_bytes()).hexdigest()=='4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c'
sys.path.insert(0,str(HERE/'r1/vendor'));import literal as lit
raw=(HERE/'r1/inputs/WORD.json.gz').read_bytes();assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9';w=json.loads(gzip.decompress(raw));assert lit.canonical(w)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
N=w['public'];p=w['program'];end=8954
class B:
 def __init__(self):self.rows={};self.piv=0
 def reduce(self,v,mask=0):
  while h:=v&self.piv:
   a,b=self.rows[h.bit_length()-1];v^=a;mask^=b
  return v,mask
 def add(self,v,mask=0):
  v,mask=self.reduce(v,mask)
  if v:
   j=v.bit_length()-1;self.rows[j]=(v,mask);self.piv|=1<<j
 def copy(self):
  z=B();z.rows=self.rows.copy();z.piv=self.piv;return z
def bits(v):return [i for i in range(N) if v>>i&1]
def scan(capture=False):
 values=[1<<i for i in range(N)]+[0]*w['owned_fields'];tags=w['start'][:]+[None]*w['owned_fields'];active=defaultdict(dict);hist=defaultdict(list);events=[]
 for r,c in enumerate(w['start']):active[c][r]=values[r];hist[c].append((-1,r,values[r]))
 for i,e in enumerate(p[:end]):
  op,r,*a=e
  if op=='INIT':assert tags[r] is None;tags[r]=a[0];values[r]=0;active[a[0]][r]=0
  elif op=='CLEAR':assert tags[r]==a[0];del active[a[0]][r];tags[r]=None;values[r]=0
  elif op=='SWAP':
   h=a[0];ca,cb=tags[r],tags[h];va,vb=values[r],values[h];del active[ca][r];del active[cb][h];active[cb][r]=vb;active[ca][h]=va;tags[r],tags[h]=cb,ca;values[r],values[h]=vb,va
  elif op=='ADD':
   h,c=a;assert tags[r]==tags[h]==c and r!=h;values[r]^=values[h];active[c][r]=values[r]
  elif op=='MOVE':
   s,d=a;assert tags[r]==s
   if capture and s not in (388,560,283,311) and d!=388:events.append((i,e,dict(active[s])))
   del active[s][r];active[d][r]=values[r];tags[r]=d;hist[d].append((i,r,values[r]))
  else:raise ValueError(op)
 return hist,values,events
hist,values,events=scan(True);u=[values[r] for r in (927,2023,2190)];assert u[0]==1<<43
sources=(560,283,311);banks={};union=B()
for s in sources:
 b=B()
 for _,_,v in hist[s]:b.add(v);union.add(v)
 banks[s]=b
assert [len(hist[s]) for s in sources]==[2,6,6] and len(union.rows)==14
assert union.reduce(u[0])[0] and not banks[283].reduce(u[1])[0] and not banks[311].reduce(u[2])[0]
assert [len(banks[s].rows) for s in sources]==[2,6,6]
# The three banks form a direct sum. The candidate fourth message must be
# u1 + an arbitrary 560 row + optional u2 and u3, as documented in README.
h560=[v for _,_,v in hist[560]];assert len(h560)==2
choices=[]
for m in (1,3,5,7):
 for bmask in range(4):
  v=0
  for j in range(3):
   if m>>j&1:v^=u[j]
  for j in range(2):
   if bmask>>j&1:v^=h560[j]
  choices.append((m,bmask,v))
assert len(set(v for _,_,v in choices))==16
charts=lit.Charts(w['frames']);hits=[];source_hits=[]
with localcontext() as ctx:
 ctx.prec=70;t=Decimal(1)-Decimal('0.003879929048842')
 def moment(n):return (t*Decimal(n).ln()).exp()
 for clock,event,live in events:
  b=B()
  for role,v in live.items():b.add(v,1<<role)
  for mask,bmask,target in choices:
   residual,form=b.reduce(target)
   if residual:continue
   roles=[r for r in live if form>>r&1];source_hits.append((clock,event[2],mask,bmask))
   try:oldgrade=charts.leg(event[2],event[3]);newgrade=charts.leg(event[2],388)
   except ValueError:continue
   gross=moment(5)-moment(1)+moment(oldgrade)-moment(newgrade)
   # No claim based on rounding near zero; the passing values are order 1.
   if gross<=Decimal('0.0000107267264634839329'):continue
   hits.append({'clock':clock,'event':event,'old_grade':oldgrade,'redirect_grade':newgrade,'target_class_mask':mask,'source560_mask':bmask,'live_sender_roles':roles,'live_sender_supports':{str(r):bits(live[r]) for r in roles},'screen_gross_per_call':str(gross)})
assert [(h['clock'],h['old_grade'],h['redirect_grade'],h['live_sender_roles']) for h in hits]==[(873,3,5,[43]),(877,3,5,[43])]
inf=json.loads((HERE/'receipts/ONE-INGRESS.json').read_text());assert all(inf['signatures'][str(h['clock'])]==0 for h in hits)
def uses(role,clock):
 out=[]
 for i,e in enumerate(p[clock+1:],clock+1):
  if role==e[1] or (e[0] in ('ADD','SWAP') and role==e[2]):
   out.append([i,e])
   if len(out)==4:break
 return out
for h in hits:h['old_recipient_first_uses']=uses(h['event'][1],h['clock'])
assert hits[0]['old_recipient_first_uses'][0][0]==5672 and hits[1]['old_recipient_first_uses'][0][0]==6767
out={'status':'PASS_BOUNDED_FOURTH_SOURCE_SCAN','word':lit.canonical(w),'scope':'One original paid MOVE from a distinct source before 8954, source value formed from live roles, fixed original 560/283/311 histories and three 388 output rows; grant free history/shadow and free recipient restoration. Only nested original-atlas native legs with clearly positive gross are retained. No full paid/target invoice or candidate word.','candidate_event_count':len(events),'live_target_class_hits_before_geometry':len(source_hits),'hits':hits,'source_history_ranks':[2,6,6],'source_union_rank':14,'target_classes_tested':16}
(HERE/'receipts/FOURTH-SOURCE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'],len(events),'live class hits',len(source_hits),'positive',len(hits))
