# A fixed-source joint-ingress cut at BIT chart 388

The proposed grade-five-to-grade-one ingress replacement at chart 388 fails a concrete information cut on the pinned binary word. This remains true when both other incumbent arrivals may carry newly chosen linear combinations, all earlier available source and receiver rows may be kept as free shadows, and all three arrivals may be delayed until the first original reader. The counterexample is the public input difference supported on **coordinates 43 and 405**: it vanishes on every granted source and receiver introduction but changes the first old ingress.

This is a **scoped negative result**, not a changed word or a new κ bound. It preserves the three source charts, all earlier paid data, and three original intermediate outputs. Changing an earlier paid arrival, using other sources or additional paid events, or restoring only final public outputs after a downstream recoding is outside the test.

## Exact local contract

At the original clocks the three paid ingresses into chart 388 are:

| Clock | Owner | Source → destination | Grade |
| ---: | ---: | --- | ---: |
| 880 | 927 | 45 → 388 | 5 |
| 5207 | 2023 | 283 → 388 | 2 |
| 6326 | 2190 | 311 → 388 | 2 |

The attempted replacement uses the existing grade-one geometry `560 → 388` for the first ingress. The other two rank-two ingresses retain their source charts and may be recoded. None of the three transported owners is touched between its arrival and clock 8954. At clocks 8954–8957 the first old receiver computes and exports `u1+u2+u3`; at clocks 8958–8961 the second exports `u2+u3`; at clocks 8962–8964 the third exports `u2`. Thus preserving all three old outputs requires the span of `u1,u2,u3`.

The exact forward trace has no other chart-388 introduction available by the first read after withdrawing these three arrivals. The three proposed sources have, respectively, **2, 6, and 6** earlier introductions, with union rank **14** over GF(2) on the 680 independent public coordinates. Their full union contains `u2` and `u3`, but not `u1`. The pulse `{43,405}` annihilates all 14 source rows and changes the three old ingress values by `[1,0,0]`. A receiver with identical granted stock for the two public inputs cannot reconstruct all three protected old outputs from these fixed sources. This union obstruction is stronger than restricting the replacement to one field per ingress: allowing arbitrarily many linear combinations of the same granted stock cannot supply the missing row.

The record reports all seven nonzero target classes at each source: chart 560 supplies none, chart 283 supplies only `u2`, and chart 311 supplies only `u3`, modulo the granted receiver stock. A positive control grants the missing `u1` direction for free and makes the span obstruction disappear; that grant is not part of the proposed edit. An independently written scalar-opcode probe checks the concrete pulse directly, and rejects each one-coordinate mutation of it.

## Complete price context

The unmodified 36-call BIT caller has 107,460 paid occurrences, 20,706 productive targets, and 291,360 units of paid rank mass. Its ordinary account has 934,182,831,504 records and 6,998,544 owned backing fields. The full signed invoice is `M(C) = Σ targets r^(1-C) − Σ paid r^(1-C)`.

At the near trial **`C = 0.003879929046155`**, exactly `0.000000001` above the fixed BIT raw upper endpoint, directed arithmetic gives

```
M(C) ∈ [−0.000385127316613866441054139472099789196374646204,
        −0.000385127316613866441054139472099789196374646203].
```

Replacing one grade-five paid occurrence with one grade-one occurrence in **each** of the 36 native calls would nominally credit approximately **142.8794912694093** signed units at this trial, before any repair, ordinary cost or change to productive fields. That is only a hypothetical gross credit: this package proves the specified fixed-source, original-reader repair impossible and does not submit the changed invoice. An alternative must price every repair, productive change and actual caller multiplicity and then pass full physical and outer qualification.

For the unchanged invoice, the binary signed crossing lies in `[0.003879928046154, 0.003879928046155]`. This is not a ceiling on a different word or caller. The separately enrolled #7830 target `0.003889928046155` is a different, higher comparison.

## Reproduce

The package is self-contained and uses the CPython 3.12 standard library. From this directory:

```sh
sha256sum -c SHA256SUMS
python3.12 -IB replay.py
python3.12 -IB pulse.py
python3.12 -IB independent_pulse.py
python3.12 -IB fault_controls.py
```

The first checker authenticates all five inputs, reconstructs the 636 rational charts and the source word, checks all `680²` native coefficients and all `38²` paired-caller coefficients in **each** orientation, reconstructs the 36-call paid and productive histograms, and prices the complete signed and ordinary invoice. It independently traces the full forward word to its protected receiver cut and recomputes the source spaces and explicit separator. It checks the source geometry and the added-direction positive control. Results are written to [RESULT.json](RESULT.json).

The second checker has its own scalar tape interpreter and tests zero input, each one-coordinate pulse and the joint `{43,405}` pulse through clock 8953. Its tag and opcode checks, sender-introduction counts, and incumbent ingress bits are in [PULSE.json](PULSE.json). This scalar interpreter is independent of the first checker's row-space implementation. A second reviewer independently replayed the symbolic GF(2) introduction rows and the same pulse, with both one-coordinate controls hitting chart 283 first at clock 2922. Its [receipt](CHART388-INDEPENDENT.json) and path-adjusted [checker](independent_pulse.py) do not independently enumerate all quotient classes. All three computations use the same pinned word and are not an independent human proof. The original reviewer script SHA-256 before changing its input path is `ddbf1e96470f585711d562910a98dfb57e8e39a98d3259a0720961405ce23095`.

The fault-control checker works in disposable copies and rejects changed word, caller, archived invoice and price-source bytes; separate controls reject a changed word in each pulse interpreter. Its results are in [FAULT-CONTROLS.json](FAULT-CONTROLS.json). For byte comparison, save copies of the receipt files before replay and compare them with the regenerated files. The package contains no network fetch or locally generated binary.

## Source, overlap and credit

The pinned construction is [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), scientific head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, which retains the binary word from [#7786](https://github.com/CrocSwap/integer-mult-bounds/pull/7786). The binary canonical SHA-256 is `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`, and the canonical layout SHA-256 is `a0ffffd99fb9b91f0013695877480766319ac51b926ed00dd5f7ec32f2d1e1a6`. Direct source URLs and hashes appear in [SOURCES.json](SOURCES.json).

This check follows an earlier locally recorded single-ingress screen on the same word: that screen kept the other paid payloads fixed, whereas this one releases the two listed payloads together. The accessible text of [coordination discussion #7111](https://github.com/CrocSwap/integer-mult-bounds/discussions/7111), checked on 21 November 2026, did not show an exact match for `chart 388`, `5207`, or `6326`; public search returned no relevant exact match. The discussion page can omit loaded replies, and this bounded search is not proof of novelty or an absence of other ongoing work. The [#7833](https://github.com/CrocSwap/integer-mult-bounds/pull/7833) fixed-observation findings concern different rational-word routes and do not supply this BIT cut. Refresh coordination before any public submission.

The inherited source, compiler and physical credits are in [NOTICE](NOTICE). Clear1nsight supplied the pinned #7830 construction; the source work retains credit to Ali Romman, Dugongue, Rohan Arun and the other predecessor contributors. This separate bounded screen and its replays were prepared with substantial OpenAI Codex assistance. No pull request, discussion message or other publication is made by this package.
