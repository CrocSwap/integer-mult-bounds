#!/usr/bin/env python3
"""Independent scalar-pulse replay of the receiver-388 separating input.

This checks one concrete input difference on the literal tape without the
subspace, projector, or symbolic-row code in chart388_cut.py. It is a bounded
necessary-cut check, not a reconstruction of a complete changed word.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip,json
HERE=Path(__file__).resolve().parent
WORD=HERE/'inputs/WORD.json.gz'
raw=WORD.read_bytes()
if sha256(raw).hexdigest()!='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9':
 raise ValueError('word gzip pin')
w=json.loads(gzip.decompress(raw))
if sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()!='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d':
 raise ValueError('canonical word pin')

SOURCES={560,283,311}; OMIT={880,5207,6326}; DEST=388; DEADLINE=8954

def pulse(active):
 values=[int(i in active) for i in range(w['public'])]+[0]*w['owned_fields']
 tags=w['start'][:]+[None]*w['owned_fields']
 seen=[]; original=[]; counts=Counter()
 def introduction(clock,role,chart):
  if chart in SOURCES or (chart==DEST and clock not in OMIT):
   seen.append((clock,role,chart,values[role]));counts[chart]+=1
 for role,chart in enumerate(w['start']):introduction(-1,role,chart)
 for clock,event in enumerate(w['program'][:DEADLINE]):
  op,role,*args=event;tag=tags[role]
  if op=='INIT':
   if tag is not None:raise ValueError('bad INIT')
   tags[role]=args[0];values[role]=0
  elif op=='CLEAR':
   if tag!=args[0]:raise ValueError('bad CLEAR')
   tags[role]=None;values[role]=0
  elif op=='SWAP':
   peer=args[0]
   if tag is None or tags[peer] is None:raise ValueError('bad SWAP')
   tags[role],tags[peer]=tags[peer],tags[role]
   values[role],values[peer]=values[peer],values[role]
  elif op=='ADD':
   peer,chart=args
   if tag!=chart or tags[peer]!=chart or peer==role:raise ValueError('bad ADD')
   values[role]^=values[peer]
  elif op=='MOVE':
   source,destination=args
   if tag!=source:raise ValueError('bad MOVE')
   if clock in OMIT:original.append((clock,role,destination,values[role]))
   tags[role]=destination;introduction(clock,role,destination)
  else:raise ValueError('unexpected instruction')
 return {'active':active,'source_history_counts':dict(counts),
         'nonzero_granted_introductions':[list(x) for x in seen if x[3]],
         'three_original_ingresses':[list(x) for x in original],
         'first_reader_payloads':[values[i] for i in (927,2023,2190)]}

checks=[pulse([]),pulse([43]),pulse([405]),pulse([43,405])]
witness=checks[-1]
if witness['source_history_counts']!={560:2,283:6,311:6}:
 raise ValueError('sender-history census')
if witness['nonzero_granted_introductions'] or witness['first_reader_payloads']!=[1,0,0]:
 raise ValueError('separating pulse fails')
if [x[0] for x in witness['three_original_ingresses']]!=[880,5207,6326]:
 raise ValueError('three actual events')
if not checks[1]['nonzero_granted_introductions'] or not checks[2]['nonzero_granted_introductions']:
 raise ValueError('single-coordinate mutation controls')
out={'status':'PASS_CONCRETE_388_SEPARATING_PULSE',
     'scope':'literal scalar tape replay through first reader only; unchanged inputs and earlier events; does not exclude changed exterior contract',
     'word':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d',
     'checks':checks}
(HERE/'PULSE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['status'],witness['first_reader_payloads'],witness['source_history_counts'])
