#!/usr/bin/env python3
"""Reject altered immutable source inputs in isolated disposable copies."""
from pathlib import Path
import json,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
CASES=[('binary_word','inputs/WORD.json.gz','input hash inputs/WORD.json.gz'),
       ('paired_caller','inputs/EFREE-CALLER.json.gz','input hash inputs/EFREE-CALLER.json.gz'),
       ('archived_invoice','BIT.json','input hash BIT.json'),
       ('directed_price_source','vendor/price.py','input hash vendor/price.py')]
results={}
with tempfile.TemporaryDirectory(prefix='chart388-control-') as temporary:
 for name,path,expected in CASES:
  root=Path(temporary)/name
  shutil.copytree(HERE,root)
  with (root/path).open('ab') as stream:stream.write(b'\n')
  run=subprocess.run([sys.executable,'-IB','replay.py'],cwd=root,capture_output=True,text=True,timeout=30)
  if run.returncode==0 or expected not in run.stderr:
   raise ValueError(f'{name} corruption was not rejected at its input pin')
  results[name]={'rejected':True,'detected_by':expected}
 # Independently constructed scalar interpreter also checks the word bytes.
 root=Path(temporary)/'scalar_word';shutil.copytree(HERE,root)
 with (root/'inputs/WORD.json.gz').open('ab') as stream:stream.write(b'\n')
 run=subprocess.run([sys.executable,'-IB','pulse.py'],cwd=root,capture_output=True,text=True,timeout=30)
 if run.returncode==0 or 'word gzip pin' not in run.stderr:
  raise ValueError('scalar source corruption accepted')
 results['scalar_word']={'rejected':True,'detected_by':'word gzip pin'}
 root=Path(temporary)/'independent_word';shutil.copytree(HERE,root)
 with (root/'inputs/WORD.json.gz').open('ab') as stream:stream.write(b'\n')
 run=subprocess.run([sys.executable,'-IB','independent_pulse.py'],cwd=root,capture_output=True,text=True,timeout=30)
 if run.returncode==0 or 'word file' not in run.stderr:
  raise ValueError('independent symbolic source corruption accepted')
 results['independent_word']={'rejected':True,'detected_by':'word file'}
out={'status':'PASS_SOURCE_CORRUPTION_CONTROLS','scope':'Source-byte mutation controls; not an independent proof of the framework or changed word.',
     'controls':results}
(HERE/'FAULT-CONTROLS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(out['status'],len(results))
