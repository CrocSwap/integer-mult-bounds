#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Reconstruct the pinned BIT invoice and the chart-388 information cut."""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from itertools import product
from pathlib import Path
import gzip,json,sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
import literal,price

PINS={
 'inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
 'vendor/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'vendor/price.py':'d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b'}
WORD='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
HEAD='87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'
TRIAL=Q('0.003879929046155')

def need(ok,name):
 if not ok:raise ValueError(name)

def read(path):
 raw=path.read_bytes()
 return json.loads(gzip.decompress(raw) if raw[:2]==b'\x1f\x8b' else raw)

def event_roles(e):
 op,r,*args=e
 return (r,args[0]) if op in ('ADD','SWAP') else (r,)

class Basis:
 def __init__(self):self.rows={};self.mask=0
 def reduce(self,v):
  while hit:=v&self.mask:
   v^=self.rows[hit.bit_length()-1]
  return v
 def add(self,v):
  v=self.reduce(v)
  if v:
   k=v.bit_length()-1;self.rows[k]=v;self.mask|=1<<k
 def copy(self):
  b=Basis();b.rows=self.rows.copy();b.mask=self.mask;return b


def trace(w,expected):
 n,owned=w['public'],w['owned_fields'];values=[1<<j for j in range(n)]+[0]*owned
 tags=w['start'][:]+[None]*owned
 history=[(-1,i,chart,values[i]) for i,chart in enumerate(w['start'])]
 snap=None;dirty=0
 for clock,(op,r,*args) in enumerate(w['program']):
  if clock==8954:snap=(history.copy(),[values[i] for i in (927,2023,2190)])
  tag=tags[r]
  if op=='INIT':
   need(r>=n and tag is None,'private INIT');tags[r]=args[0];values[r]=0
  elif op=='CLEAR':
   need(r>=n and tag==args[0],'private CLEAR');dirty+=bool(values[r]);tags[r]=None;values[r]=0
  elif op=='ADD':
   donor,chart=args;need(r!=donor and tag==tags[donor]==chart,'local ADD');values[r]^=values[donor]
  elif op=='SWAP':
   peer=args[0];need(r!=peer and tag is not None and tags[peer] is not None,'local SWAP')
   values[r],values[peer]=values[peer],values[r];tags[r],tags[peer]=tags[peer],tags[r]
  elif op=='MOVE':
   a,b=args;need(r>=n and tag==a,'paid MOVE chronology');tags[r]=b;history.append((clock,r,b,values[r]))
  else:raise ValueError('unknown opcode')
 need(snap is not None and tags==w['final']+[None]*owned and not any(values[n:]), 'final ownership')
 need(values[:n]==expected and dirty==3554,'forward exact 680-row endpoint and dirty retirements')
 return snap

def main():
 for path,expected in PINS.items():
  need(sha256((HERE/path).read_bytes()).hexdigest()==expected,f'input hash {path}')
 w=read(HERE/'inputs/WORD.json.gz');caller=read(HERE/'inputs/EFREE-CALLER.json.gz');old=read(HERE/'BIT.json')
 need(literal.canonical(w)==WORD and w['public']==680,'canonical word')
 layout_pin='a0ffffd99fb9b91f0013695877480766319ac51b926ed00dd5f7ec32f2d1e1a6'
 need(literal.canonical({k:w[k] for k in ('frames','start','final')})==layout_pin,'canonical layout')
 charts=literal.Charts(w['frames'])
 grades={s:charts.leg(s,388) for s in (45,560,283,311)}
 need(grades=={45:5,560:1,283:2,311:2},'exact nested rational geometry')
 expected_moves=[['MOVE',927,45,388],['MOVE',2023,283,388],['MOVE',2190,311,388]]
 need([w['program'][i] for i in (880,5207,6326)]==expected_moves,'pinned ingress clocks')
 need(w['program'][8953:8958]==[['INIT',2583,388],['ADD',2583,927,388],
  ['ADD',2583,2023,388],['ADD',2583,2190,388],['MOVE',2583,388,517]],'first old reader')
 need(w['program'][8958:8965]==[['INIT',2584,388],['ADD',2584,2023,388],
  ['ADD',2584,2190,388],['MOVE',2584,388,560],['INIT',2585,388],
  ['ADD',2585,2023,388],['MOVE',2585,388,1]],'two further old readers')
 for clock,role in ((880,927),(5207,2023),(6326,2190)):
  need(all(role not in event_roles(e) for e in w['program'][clock+1:8954]),'held role unread before cut')
 # Pinned native verifier, on all 680² scalar coefficients in each direction.
 fw,flog,_=literal.tape(w,charts);bw,blog,_=literal.tape(w,charts,adjoint=True)
 need(fw==literal.expected_rows(680,False) and bw==literal.expected_rows(680,True), 'both exact endpoints')
 need(flog['paid']==blog['paid'] and flog['erase_dirty']==blog['erase_dirty']==3554,
      'matching paid ranks and retirement in both directions')
 hist,targets=trace(w,fw)
 cut_indices=[]
 for clock,role in ((880,927),(5207,2023),(6326,2190)):
  found=[i for i,(t,r,c,v) in enumerate(hist) if (t,r,c)==(clock,role,388)]
  need(len(found)==1,'unique old ingress introduction');cut_indices.extend(found)
 need([hist[i][3] for i in cut_indices]==targets,'correct held target expressions')
 rbase=Basis()
 for i,(_,_,chart,row) in enumerate(hist):
  if chart==388 and i not in cut_indices:rbase.add(row)
 need(len(rbase.rows)==0,'no independent other receiver history')
 source_rows={s:[(c,r,v) for c,r,chart,v in hist if chart==s] for s in (560,283,311)}
 need({s:len(z) for s,z in source_rows.items()}=={560:2,283:6,311:6},'all source introductions')
 union=rbase.copy();bases={}
 for s,rows in source_rows.items():
  b=rbase.copy()
  for _,_,v in rows:b.add(v);union.add(v)
  bases[s]=b
 need(len(union.rows)==14 and union.reduce(targets[0])!=0 and
      union.reduce(targets[1])==union.reduce(targets[2])==0,'missing target from all source histories')
 u=rbase.copy()
 for v in targets:u.add(v)
 need(len(u.rows)-len(rbase.rows)==3,'three independent target directions')
 classes={}
 for s,b in bases.items():
  classes[s]=[m for m in range(1,8) if not b.reduce(
      (targets[0] if m&1 else 0)^(targets[1] if m&2 else 0)^(targets[2] if m&4 else 0))]
 need(classes=={560:[],283:[2],311:[4]},'seven target classes for all three senders')
 pulse=(1<<43)|(1<<405)
 need(all((v&pulse).bit_count()%2==0 for b in (rbase,union) for v in b.rows.values())
      and [(v&pulse).bit_count()%2 for v in targets]==[1,0,0],'direct separating input pulse')
 # Positive control: granting the missing old direction to a sender removes
 # the span obstruction. It is not an allowed free candidate edit.
 positive=union.copy();positive.add(targets[0])
 need(positive.reduce(targets[0])==0,'funded missing-direction control')

 native_targets=Counter(charts.leg(w['start'][j],w['final'][j]) for j in range(222,680))
 events=Counter(e[0] for e in caller['events'])
 paid,productive=literal.paired_invoice(caller,flog['paid'],native_targets,events)
 ordinary=literal.ordinary(w,caller,events,paid,productive)
 archive=old['native']
 need(dict(paid)=={int(k):v for k,v in archive['paid'].items()} and
      dict(productive)=={int(k):v for k,v in archive['targets'].items()} and
      ordinary==archive['ordinary'],'complete 36-call signed and ordinary archive')
 need((sum(paid.values()),sum(productive.values()))==(107460,20706),'full caller inventory')
 signed=price.signed_profile(productive,paid)
 at=price.moment(signed,TRIAL)
 gross=price.moment({5:36,1:-36},TRIAL)
 need(at[1]<0 and gross[0]>-at[0],'negative baseline and attractive unimplemented gross')
 need(price.moment(signed,Q('0.003879928046154'))[0]>0 and
      price.moment(signed,Q('0.003879928046155'))[1]<0,'old fixed-profile crossing')

 result={'status':'PASS_FIXED_SOURCE_CHART388_SEPARATING_CUT',
  'scope':'Fixed old word, three source charts and 8954-8963 intermediate outputs, earlier paid data unchanged; free historical shadows and late arrivals granted. Not a changed word or general endpoint impossibility.',
  'head':HEAD,'canonical_binary_word':WORD,'canonical_layout':layout_pin,'word_gzip_sha256':PINS['inputs/WORD.json.gz'],
  'caller_sha256':PINS['inputs/EFREE-CALLER.json.gz'],'native_public':680,'native_calls':36,
  'native_coefficients_each_way':680**2,'caller_coefficients_each_way':38**2,
  'retirements_each_way':3554,'moves':expected_moves,'move_clocks':[880,5207,6326],
  'relative_geometry_grades':grades,'target_quotient_rank':3,'receiver_history_rank':0,
  'source_history_count':{s:len(v) for s,v in source_rows.items()},'source_union_rank':len(union.rows),
  'source_quotient_target_classes':classes,'all_source_union_missing_first_target':True,
  'separating_public_coordinates':[43,405],'pulse_on_three_old_ingresses':[1,0,0],
  'positive_control_missing_direction_granted':True,
  'complete_paid':dict(paid),'complete_productive':dict(productive),'ordinary':ordinary,
  'near_trial':str(TRIAL),'near_trial_decimal':'0.003879929046155',
  'complete_signed_margin':price.decimal_interval(at,48),
  'unrealized_grade5_to_grade1_36_call_gross_credit':price.decimal_interval(gross,48),
  'raw_crossing':['0.003879928046154','0.003879928046155'],
  'other_obligations':'Earlier paid changes, extra senders or events, and release of old intermediate outputs with only public endpoints restored are outside the screen.'}
 (HERE/'RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(result['status'],'margin',result['complete_signed_margin'],flush=True)

if __name__=='__main__':main()
