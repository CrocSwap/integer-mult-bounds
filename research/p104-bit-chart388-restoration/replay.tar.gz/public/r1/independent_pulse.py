#!/usr/bin/env python3
"""Symbolic GF(2) pulse check for the frozen 388 necessary-only cut."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import gzip
import json

HERE=Path(__file__).resolve().parent
WORD=HERE/'inputs/WORD.json.gz'
def need(c,s):
    if not c:
        raise ValueError(s)

def main():
    raw=WORD.read_bytes()
    need(sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9','word file')
    word=json.loads(gzip.decompress(raw))
    canon=json.dumps(word,sort_keys=True,separators=(',',':')).encode()
    need(sha256(canon).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','canonical word')
    program=word['program']; cutoff=8954; old={880,5207,6326}; sources={560,283,311}
    need([program[i] for i in sorted(old)]==[['MOVE',927,45,388],['MOVE',2023,283,388],['MOVE',2190,311,388]],'three old introductions')
    need(program[cutoff:cutoff+3]==[['ADD',2583,927,388],['ADD',2583,2023,388],['ADD',2583,2190,388]],'first readers')
    values=[1<<i for i in range(word['public'])]+[0]*word['owned_fields']
    chart=word['start'][:]+[None]*word['owned_fields']
    intro=[]; incumbent=[]
    for role,c in enumerate(word['start']):
        if c in sources or c==388:
            intro.append((-1,role,c,values[role]))
    for clock,event in enumerate(program[:cutoff]):
        op,role,*a=event
        if op=='INIT':
            need(chart[role] is None and values[role]==0,'open private field')
            chart[role]=a[0]
        elif op=='CLEAR':
            need(chart[role]==a[0],'private clear chart')
            chart[role]=None; values[role]=0
        elif op=='SWAP':
            peer=a[0]; need(chart[role] is not None and chart[peer] is not None,'swap contacts')
            values[role],values[peer]=values[peer],values[role]
            chart[role],chart[peer]=chart[peer],chart[role]
        elif op=='ADD':
            peer,c=a; need(role!=peer and chart[role]==chart[peer]==c,'add contacts')
            values[role] ^= values[peer]
        elif op=='MOVE':
            a0,b0=a; need(chart[role]==a0,'move contact')
            chart[role]=b0
            if clock in old:
                incumbent.append((clock,role,b0,values[role]))
            if b0 in sources or (b0==388 and clock not in old):
                intro.append((clock,role,b0,values[role]))
        else:
            raise ValueError(f'unexpected opcode {op}')
    need([r[0] for r in incumbent]==sorted(old),'incumbent census')
    need([r[3] for r in incumbent]==[values[i] for i in (927,2023,2190)],'incumbent rows still held at deadline')
    census=Counter(r[2] for r in intro)
    need(census==Counter({560:2,283:6,311:6}),'all sender and eligible receiver introductions')
    def parity(row,mask): return (row&mask).bit_count()%2
    mask=(1<<43)|(1<<405)
    need(all(parity(r[3],mask)==0 for r in intro),'two-coordinate pulse annihilates all source/receiver histories')
    need([parity(r[3],mask) for r in incumbent]==[1,0,0],'two-coordinate pulse hits incumbent row one only')
    controls={}
    for position in (43,405):
        hits=[(c,role,ch) for c,role,ch,row in intro if parity(row,1<<position)]
        need(bool(hits),'single-coordinate mutation exposes source history')
        controls[str(position)]={'nonzero_introductions':len(hits),'first':hits[0]}
    out={'status':'PASS_INDEPENDENT_SYMBOLIC_CHART388_PULSE',
         'scope':'Necessary-only frozen-input cut through clock 8954, with unchanged earlier word; does not rule out a changed exterior contract or extra paid information.',
         'word':sha256(canon).hexdigest(),'deadline_clock':cutoff,'public_difference':[43,405],
         'free_sender_and_receiver_introductions':dict(sorted(census.items())),
         'history_rows_all_zero_on_pulse':True,'incumbent_clocks':sorted(old),'incumbent_pulse':[1,0,0],
         'one_coordinate_controls':controls}
    (HERE/'CHART388-INDEPENDENT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(out['status'],'census',dict(census),'pulse',[1,0,0])

if __name__=='__main__':
    main()
