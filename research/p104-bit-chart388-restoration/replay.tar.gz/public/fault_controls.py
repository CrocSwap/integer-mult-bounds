#!/usr/bin/env python3
if not __debug__: raise RuntimeError('assertions must remain enabled')
# SPDX-License-Identifier: Apache-2.0
"""Reject disposable mutations of packet inputs and influence receipts."""
from pathlib import Path
import json,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent;checks=[]
with tempfile.TemporaryDirectory(prefix='chart388-fault-') as temp:
 root=Path(temp)
 def test(name,script,mutate,optimized=False):
  work=root/name;shutil.copytree(HERE,work);mutate(work)
  command=[sys.executable]+(['-O'] if optimized else [])+['-IB',script]
  result=subprocess.run(command,cwd=work,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=30)
  checks.append({'name':name,'rejected':result.returncode!=0})
 def alter(work,path):
  q=work/path;q.write_bytes(q.read_bytes()+b'\n')
 def sig(work):
  q=work/'receipts/ONE-INGRESS.json';z=json.loads(q.read_text());z['signatures']['2922']^=1;q.write_text(json.dumps(z))
 test('original_word','one_ingress.py',lambda p:alter(p,'r1/inputs/WORD.json.gz'))
 test('candidate_word','zero_net_replay.py',lambda p:alter(p,'inputs/ZERO-NET-WORD.json.gz'))
 test('literal_replay','zero_net_replay.py',lambda p:alter(p,'r1/vendor/literal.py'))
 test('literal_fourth','fourth_source.py',lambda p:alter(p,'r1/vendor/literal.py'))
 test('influence_signature','validate_signatures.py',sig)
 test('optimized_execution','zero_net_replay.py',lambda p:None,True)
assert all(x['rejected'] for x in checks)
out={'status':'PASS_NEW_PACKET_FAULT_CONTROLS','checks':checks,'scope':'Six disposable altered-input or optimized-execution controls; not a proof of overall correctness.'}
(HERE/'receipts/FAULT-CONTROLS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(out['status'],len(checks))
