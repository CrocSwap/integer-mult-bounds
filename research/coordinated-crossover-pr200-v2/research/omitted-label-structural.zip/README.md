# Hybrid omitted-port research appendix

This appendix proves finite fresh-decoder and address-frame constructions. It does not claim a completed arbitrary-dirty hybrid supplier, a paid hybrid moment, or a new kappa.

The complete 2,024-source decoder passes every formal source column, with all 264 additional ports, positive cap-compatible query supports, actual good-target read cuts, and 132 new source pairs. Its fused graph has 11,880 new additions, 220 all-eight cube root uses, 3,960 face root uses, 132 fused common new-target roots, and 264 fused singleton roots. The inherited public bit scalar graph and metric are retained.

A direct old-query reuse shortcut fails: all 264 desired old P supports exist, but their original rank21 physical creation frames fail all 792 individual new target-cap tests. The supplied contraction repair changes 2,094 actual inherited operation frames and places all 240 distinct P creation events inside the required new caps. It checks every inherited fixed boundary and role/target path, fresh-source containment, and G-nondegeneracy. Rank mass stays405,456; local entropy rises2,713.6121754377. This entropy is a real charge, not an improvement by itself.

All 1,222 distinct repaired frames have literal basis rank and Gram nonsingularity over every prime greater than2^80. The maximum raw Gram determinant has95bits, but removing integer factors below1000 leaves each residual below2^80. Exact determinant witnesses are supplied.

The remaining physical issue is arbitrary-dirty compensation: copying an old query row also copies its dirt. New response supports cannot be added to inherited global gauge compensation without proving its chronology against every new target chain. The supplied cap/fresh repair does not discharge this issue. The parent campaign's accepted kappa is separate.

## Files

- hybrid-decoder.cpp/json: complete positive fresh decoder and full 2,024-column check.
- target-face-partitions.json: inherited target cuts; 440 faces allow one copy,880 need four singleton copies.
- bad-partners.cpp and bad-partners-residual.cpp: literal132-pair coverage, cap geometry, residuals, and final264-square identity.
- old-query-bindings.cpp/json: exact old node/event/role bindings and rejected original frame shortcut.
- old-query-contraction.cpp/json and old-query-contracted-bases.json: actual repaired inherited frame witness and full path/value checks.
- old-query-prime-admission.cpp/json: independent unbounded integer basis/Gram admission.
- family-prices.cpp/json: discovery-only prices from reported old p11/p12/p13 inventories; these are not constructed current optimized families.
- INHERITED-INPUTS.json: exact hashes of the required inherited raw input files. They are not duplicated here.

## Reproduction

C++20, nlohmann/json (header included), and Boost.Multiprecision headers are required. Never disable assertions. Compile each source with `g++ -std=c++20 -O3 -I. SOURCE.cpp -o PROGRAM`; add the Boost header include directory where needed. The binding and contraction sources use GCC/Clang checked128-bit integers; prime admission uses unbounded cpp_int.

Let INPUT be a directory containing the six matching raw files listed in INHERITED-INPUTS.json. Let OLD_PACKAGE be the pinned inherited PR200 package directory containing selected/bit/graph_p12.json and selected/bit/kchron_p12.json. Run from this appendix directory:

```
./hybrid-decoder OLD_PACKAGE hybrid-decoder-replay.json target-face-partitions.json
./old-query-bindings INPUT hybrid-decoder.json old-query-bindings-replay.json
./old-query-contraction INPUT .
./old-query-prime-admission old-query-contracted-bases.json prime-admission-replay.json
./bad-partners
./bad-partners-residual
./family-prices family-prices-replay.json
```

The binding checker intentionally confirms that original padded old creation frames fail; the contraction receipt is the positive repair. Different newer inherited frames require a fresh combined contraction/path check rather than silently transplanting this witness. No C++ executable is distributed. json.hpp retains its upstream MIT license notice.