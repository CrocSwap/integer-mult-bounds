#!/usr/bin/env python3
"""Recount the actual paired 36-call and pinned rational 48-call profiles."""
import sys,json
from pathlib import Path
from collections import Counter
root=Path(__file__).resolve().parent;sys.path.insert(0,str(root/'source'))
import common
_,_,_,_,_,paid,prod,audit=common.baseline()
k=common.D('0.00388');old=common.moment(paid,prod,k)
newpaid=paid+Counter({8:36});newprod=prod+Counter({8:36});new=common.moment(newpaid,newprod,k)
assert newpaid-paid==Counter({8:36}) and newprod-prod==Counter({8:36})
assert new[0]<=old[1] and old[0]<=new[1]
rat=audit['signed'];rp={int(k):v for k,v in rat['paid'].items()};rt={int(k):v for k,v in rat['productive'].items()};assert rat['native_calls']==48
rmargin=common.moment(rp,rt,k)
out={'rate':str(k),'binary_local_count':36,'binary_baseline_paid':dict(paid),'binary_baseline_productive':dict(prod),'binary_equal_control_paid':dict(newpaid),'binary_equal_control_productive':dict(newprod),'binary_baseline_signed_interval':common.display(old),'binary_equal_control_signed_interval':common.display(new),'binary_change_exact':0,'rational_calls':48,'rational_paid':rp,'rational_productive':rt,'rational_signed_interval':common.display(rmargin),'rational_source':'pinned 7830 AUDIT.json; unchanged profile'}
(root/'BILLS.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({k:out[k] for k in ['rate','binary_baseline_signed_interval','binary_equal_control_signed_interval','binary_change_exact','rational_signed_interval']},sort_keys=True))
