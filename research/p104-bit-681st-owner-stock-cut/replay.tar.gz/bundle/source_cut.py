#!/usr/bin/env python3
"""Exterior-output sensitivity is injective at every original source chart."""
import sys,json
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parent))
from paid_probe import *
from network import ROWS

# Direct backwards sweep from literal terminal/sender packet equations,
# separately from the dual-packet evaluation used to obtain Y.
back={p:0 for p in O}
for i in range(680):
 for p in labels(ROWS[~i]):
  if p in back:back[p]^=1<<i
for p in reversed(O):
 for q in labels(ROWS[p]):
  if q in back:back[q]^=back[p]
assert all(back[p]==Y[p] for p in O)
charts=[];counts=Counter()
for c in sorted(set(W['start'])):
 mask=((1<<680)-1)&~finalmask[c];b=Span()
 for p in outs[c]:b.add(back[p]&mask)
 rec={'chart':c,'source_sends':len(outs[c]),'rank_exterior_output_sensitivity':len(b.rows),'nullity':len(outs[c])-len(b.rows),'initial_inputs':W['start'].count(c),'old_final_outputs':W['final'].count(c)}
 assert rec['nullity']==0
 charts.append(rec);counts['source_charts']+=1;counts['source_sends']+=len(outs[c]);counts['total_rank']+=len(b.rows)
out={'pins':public_source(),'statement':'At each source C, every nonempty selection of its original paid sends changes at least one original terminal output whose fixed final chart differs from C, for a common pulse on those sends.','direct_backward_sweep_verified_packet_columns':len(O),'counts':dict(counts),'send_count_histogram':dict(sorted(Counter(r['source_sends'] for r in charts).items())),'charts':charts}
(Path(__file__).resolve().parent/'SOURCE-CUT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps({'counts':dict(counts),'histogram':out['send_count_histogram']}))
