#!/usr/bin/env python3
"""Exact exhaustive common-stock pulse-sensitivity screen for one final receipt."""
import sys,json,hashlib,time
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parent))
from paid_probe import *

summary={};start=time.monotonic()
for level in (8,7,6,5,4,3,2):
 stats=Counter();pairhash=hashlib.sha256();triplehash=hashlib.sha256()
 pairs=sorted((c,d) for c in set(W['start']) for d in S if c!=d and grade(c,d)==level)
 for ix,(c,d) in enumerate(pairs):
  pairhash.update(f'{c},{d}\n'.encode());stats['productive_legs']+=1
  source_mask=sum(1<<p for p in outs[c]);stats['source_sends']+=len(outs[c])
  for a in sorted(S):
   if a in (c,d):continue
   g=grade(a,d)
   if not g or g>=level:continue
   stats['cheaper_sender_instances']+=1;triplehash.update(f'{c},{d},{a},{g}\n'.encode())
   if any(sens(p)&source_mask for p in S[a]):stats['sender_with_pulse']+=1
   else:stats['sender_without_pulse']+=1
   for sa,sd,diff in intersect(a,d):
    stats['common_stock_basis_vectors']+=1
    affected=diff&source_mask
    if affected:
     stats['nonzero_sensitivity_differences']+=1
     print('POTENTIAL',c,d,a,g,list(labels(affected)),flush=True)
     raise ValueError('nonzero cheaper-send sensitivity difference')
 stats['productive_legs_sha256']=pairhash.hexdigest();stats['sender_instances_sha256']=triplehash.hexdigest()
 summary[str(level)]=dict(stats);print('grade',level,dict(stats),'elapsed',round(time.monotonic()-start,2),flush=True)
out={'word':public_source(),'source_charts':len(set(W['start'])),'charts':len(S),'model':'All original packet rows are fixed except arbitrary z-only changes to any sends from a single initial chart C. One extra, last, nested paid receipt goes to new return chart D. All historical stock may be retained freely. Bridge and all old terminal demands are relaxed in the screen. Old input rows and sender equations otherwise fixed.','reason':'For extraction, the new send old component must lie in the intersection of its sender and receiver old stock spans. All basis vectors of each intersection have identical z sensitivity at both banks under any pulse at C.','direct_source_case':'A new receipt sent directly from C to D has paid grade equal to productive grade.','grade_1':'No positive cheaper paid grade.','per_grade':summary}
(Path(__file__).resolve().parent/'SIGNATURE-SCAN.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
