# New 681st BIT owner: bounded source-pulse cuts

This local receipt uses the pinned #7830 binary word, with gzip SHA-256
`d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`
and canonical SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
The 680 old inputs and outputs remain the reference. The 111 main contacts,
owner 411, and all original paid routes are retained in the tested models.
The candidate new input z is independent of all 680 old inputs, and its source
is one of the 131 actual original input charts. The target rate is 0.00388.
No improved κ, outer theorem, or changed-candidate finite admission is claimed.

Run `python3 -I -B verify.py` from this directory. It verifies the file hashes,
reconstructs both original orientations, regenerates every receipt, enumerates
all named exact GF(2) cases, and checks the compiled positive control. The full
run takes about one minute on the original machine. There is no network access.

## Historical rank and original terminal demands

The old stock at a chart consists optimistically of all its original inputs and
all original paid packets ever received there; we grant their free retention.
In the forward word all 636 bank matrices have full row rank: stock nullity
zero in every bank. The same holds in the adjoint. Every one of the 680 old
terminal demands is in the correct bank in both orientations. Forward demand
is distributed over 138 charts and adjoint demand over 131. `INITIAL-GATE.json`
contains the stock rank, terminal-demand rank and their difference for every
chart. For example, forward chart 8 has old historical rank 7 and retained
demand rank 1, while chart 1 has 537 and 537. Surplus rank over terminal
demand is not a linear dependence among old observations.

The unique forward grade-8 new leg is 0→1. Chart 1 has no original input,
537 original scalar arrivals, and 537 independent old terminal demands.
Returning those demands plus independent z requires 538 bits from only 537
arrivals. Thus, with the original receipt count and fixed timing, even
arbitrary local processing and old-payload recoding cannot realize this leg
without another receipt. In the adjoint, the corresponding unique leg 1→0
has 524 arrivals, 524 old demands, and 525 demands after adding z. This is an
information cut on the two tight destinations, beyond the z-only model.

With original old coefficients fixed, changing received rows only by multiples
of z cannot let a distinct chart extract the pure new z: every old stock
combination with zero old projection is trivial. This assertion does not cover
arbitrary recoding of the old components, which can alter the bank relations.

## A source-side old-form replacement

Choose a source C, any old linear form v, and any subset of original sends from
C. Add the same scalar perturbation v+z to the selected sender rows; all other
sender equations and routes stay fixed. Allow v and all stock retention for
free, allow arbitrary final GF(2) redecoding, and even relax bridge purity.

The exact backward output-sensitivity matrix at C has full column rank after
restricting to old outputs ending outside C. This holds for all 131 source
charts and all 1,191 outgoing send columns. An independent reverse sweep of
all 2,874 raw packet equations reproduces the packet-output columns. Thus any
nonempty selected pulse changes an exterior old terminal demand. In a given
bank, an output containing no z must use a combination whose perturbation
parity is zero; its old projection then has the original unique coordinates.
That output cannot be repaired under these assumptions. The new z is directly
available only in C, and the common-form assumption is essential. This cut
allows any old v, even one that is not actually available at C.

## One additional final paid receipt

Choose C and any positive nested new return chart D. Modify original sends
from C by arbitrary independent z coefficients, leaving their old components
and all other paid sender equations fixed. After all original sends, allow one
new paid packet from an arbitrary old chart A to D, and allow every historic
row at A and D to be kept for free. There is no restriction on old terminal
outputs or the 411 bridge in this test; relaxing them makes failure stronger.

For A different from C, an added row can deliver pure z only if its old part
is in the intersection of the old stock spans at A and D, with different z
sensitivities in their unique stock representations. The exact intersection
basis test examines all 14,452 source/D nested legs of grades 2–8 and 600,832
strictly cheaper positive A→D instances. The 326,178 basis vectors all have
identical pulse sensitivity at A and D; 480,319 sender instances have no pulse
at A and are still checked. A=C would cost the same grade as the productive
C→D leg; grade 1 has no cheaper positive paid leg. Since t^(1−0.00388) is
strictly increasing, none of these cases can improve the signed price. Full
per-grade counts and hashes of the ordered pair and triple enumerations are in
`SIGNATURE-SCAN.json`.

The separate detector control uses an independent augmented-stock span
calculation for 1,744 pulse/sender cases across four actual source/receiver
pairs, including 896 cases where the sender has no pulse. It also includes a
synthetic positive case where a clean sender transmits an old row matching a
z-tagged receiver row. Thus a clean sender is not incorrectly pruned.

## Compiled equal-price control and whole bills

`EQUAL-CONTROL-WORD.json.gz` adds a truly independent 681st owner from chart 0
to chart 1 and a new grade-8 paid packet from chart 0 to chart 1. The generated
primitive word returns all 681 forward and all 681 adjoint rows, keeps the
owner-411 bridge pure, and retires 3,556 dirty private fields in each direction.
Deleting the new sender ADD damages one output row in each orientation. The
old 680 returns and their endpoint chart anchors remain unchanged.

The signed binary 36-LOCAL invoice gains +36 grade-8 productive occurrences
and +36 grade-8 paid occurrences, so its exact price change is zero. The
regenerated complete binary interval at 0.00388 is approximately
−0.02771136019021759040099; the unchanged pinned 48-call rational profile is
approximately +0.13897452233425270897759. Exact bins and directed intervals
are in `BILLS.json`. The positive control demonstrates the scalar construction
and cost; it does not establish the updated finite physical stock, precision,
or outer integer-multiplication theorem.

The negative cuts do not cover multiple new receipts, an additional receipt
early enough to change later original sends, arbitrary old-component recoding
different at each sender, different old terminal anchors, altered rational
frames, or a changed caller. They are not exclusions of those models.

Inputs and source notices are retained in `source/`, `NOTICE`, and `LICENSE`.
This local investigation extends the preceding projected-port helper search;
it does not assert that a previously present dependent or projected direction
is a new 681st input.
