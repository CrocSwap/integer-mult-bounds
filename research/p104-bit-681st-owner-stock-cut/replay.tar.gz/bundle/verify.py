#!/usr/bin/env python3
"""Cold deterministic replay of the 681st-owner bounded evidence."""
import hashlib,json,subprocess,sys
from pathlib import Path
P=Path(__file__).resolve().parent
for line in (P/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);raw=(P/name).read_bytes()
 if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('input hash mismatch '+name)
print('static manifest verified',flush=True)
for script in ['initial_gate.py','tight_destination.py','source_cut.py','detector_control.py','equal_control.py','bills.py','signature_scan.py']:
 subprocess.run([sys.executable,'-I','-B',str(P/script)],cwd=P,check=True)
expected=json.loads((P/'EXPECTED.json').read_text())
for name,digest in expected.items():
 if hashlib.sha256((P/name).read_bytes()).hexdigest()!=digest:raise ValueError('generated result mismatch '+name)
print('all generated receipts and compiled word verified',flush=True)
