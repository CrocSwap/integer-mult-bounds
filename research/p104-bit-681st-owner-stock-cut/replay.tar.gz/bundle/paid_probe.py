#!/usr/bin/env python3
"""Optimistic one-extra-paid-receipt search for a genuinely new helper.

Old packet equations may each acquire a z term at the one designated source.
Historical stocks are freely retained until all old sends finish.  The additional
paid row may use any historical stock at its sender and is the last receipt.
All old targets at their original charts must decode; the source and extra-receipt
chart can remove z locally.  Protected packet purity is optional; by default the
probe grants it free, making a negative result stronger.
"""
import sys,json,time
from collections import Counter,defaultdict
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
HERE=Path(__file__).resolve().parent
from network import W,R,O,X,Y,PATH,DIMS,Span,labels,xsum,public_source
def kernel(rows):
    piv={};out=[]
    for v,m in rows:
        while v and v.bit_length() in piv:
            a,b=piv[v.bit_length()];v^=a;m^=b
        if v:piv[v.bit_length()]=(v,m)
        else:out.append(m)
    return out
from two_hole import grade

S=defaultdict(list); arrivals=defaultdict(list); outs=defaultdict(list); finalmask=defaultdict(int)
for i,c in enumerate(W['start']):S[c].append(i)
for p in O:S[R[p][1]].append(p);outs[R[p][0]].append(p)
for i,c in enumerate(W['final']):finalmask[c] |= 1<<i
obs=lambda p: (1<<p) if p<680 else X[p]
sens=lambda p: 0 if p<680 else PATH[p]

class Reducer:
 def __init__(self,c):
  b=Span()
  for p in S[c]:
   assert b.add(obs(p),1<<p)
  self.rows=sorted(b.rows.items(),reverse=True)
 def red(self,v):
  lab=0
  for pivot,(row,label) in self.rows:
   if v>>(pivot-1)&1:v^=row;lab^=label
  return v,lab
 def exp(self,v):
  rem,lab=self.red(v)
  return None if rem else lab

reductions={c:Reducer(c) for c in S}

def intersect(a,d):
 """Basis of common old vectors, represented by their unique historical rows."""
 D=reductions[d]; piv={}
 for p in S[a]:
  x=obs(p); rem,q=D.red(x); label=1<<p
  while rem and rem.bit_length() in piv:
   r,l=piv[rem.bit_length()];rem^=r;label^=l
  if rem:
   piv[rem.bit_length()]=(rem,label)
  else:
   old=xsum(obs(i) for i in labels(label))
   assert old
   q=D.exp(old);assert q is not None
   diff=xsum(sens(i) for i in labels(label)) ^ xsum(sens(i) for i in labels(q))
   yield (label,q,diff)

