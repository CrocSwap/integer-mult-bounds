#!/usr/bin/env python3
"""Historical bank ranks for full 680-owner #7830 word in both orientations."""
import sys,json,hashlib
from collections import Counter,defaultdict
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from network import W,R,DR,O,X,Y,PATH,DPA,DIMS,Span,labels,public_source
from two_hole import grade

out={'pins':public_source(),'orientations':{}}
for reverse in (False,True):
    s,f,r,o,vals=(W['final'],W['start'],DR,O[::-1],Y) if reverse else (W['start'],W['final'],R,O,X)
    banks=defaultdict(list); targets=defaultdict(list)
    for i,c in enumerate(s):banks[c].append((i,1<<i))
    for p in o:banks[r[p][1]].append((p,vals[p]))
    for i,c in enumerate(f):
        v=(1<<i)
        if not reverse and 111<=i<222:v ^= 1<<(i-111)
        if reverse and i<111:v ^= 1<<(111+i)
        targets[c].append((i,v))
    allcharts=set(banks)|set(targets)
    terminal_chart_count=len(targets)
    records=[]
    for c in sorted(allcharts):
        b=Span()
        for p,v in banks[c]:b.add(v,1<<p)
        t=Span()
        for i,v in targets[c]:t.add(v,1<<i)
        missing=[i for i,v in targets[c] if b.express(v) is None]
        records.append({'chart':c,'dimension':DIMS[c],'stock_count':len(banks[c]),'stock_rank':len(b.rows),'stock_nullity':len(banks[c])-len(b.rows),'demand_count':len(targets[c]),'demand_rank':len(t.rows),'stock_minus_demand_rank':len(b.rows)-len(t.rows),'missing':missing,'initial_count':sum(1 for i,v in banks[c] if i<680)})
    sources=set(s); dst=set(c for c in banks if c not in sources or True)
    pairs=Counter(); bygrade=defaultdict(list)
    for a in sorted(sources):
        for b in sorted(dst):
            if a==b:continue
            g=grade(a,b)
            if g is None or g==0:continue
            pairs[g]+=1
            if len(bygrade[g])<4:bygrade[g].append([a,b])
    name='adjoint' if reverse else 'forward'
    rec={'bank_count':len(banks),'terminal_chart_count':terminal_chart_count,'initial_chart_count':len(sources),'input_count':len(s),'packet_count':len(o),'any_missing':sum(len(x['missing']) for x in records),'total_nullity':sum(x['stock_nullity'] for x in records),'stock_count_range':[min(x['stock_count'] for x in records),max(x['stock_count'] for x in records)],'gap_histogram':dict(sorted(Counter(x['stock_minus_demand_rank'] for x in records).items())),'terminal_gap_histogram':dict(sorted(Counter(x['stock_minus_demand_rank'] for x in records if x['demand_count']).items())),'product_leg_grade_counts':dict(sorted(pairs.items())),'product_leg_examples':dict(sorted(bygrade.items())),'banks':records}
    out['orientations'][name]=rec
    print(name,'banks',rec['bank_count'],'terminal',rec['terminal_chart_count'],'sources',rec['initial_chart_count'],'nullity',rec['total_nullity'],'missing',rec['any_missing'],'grades',rec['product_leg_grade_counts'],flush=True)
assert all(rec['total_nullity']==0 and rec['any_missing']==0 for rec in out['orientations'].values())
(Path(__file__).resolve().parent/'INITIAL-GATE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
