#!/usr/bin/env python3
"""Direct GF(2) stock-span cross-checks of one-receipt detector."""
import sys,json
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parent))
from paid_probe import *

# Negative-to-positive synthetic test: A has clean w, D has w+z. A clean paid
# sender to D enables z. This must remain visible even though A has no pulse.
u,v=9000,9001; t=8999; a,d=-1,-2
S[a]=[u];S[d]=[v];X[u]=X[v]=1;PATH[u]=0;PATH[v]=1<<t
reductions[a]=Reducer(a);reductions[d]=Reducer(d)
toy=list(intersect(a,d));assert len(toy)==1 and toy[0][2]==1<<t
z=1<<680;toybank=Span();toybank.add(1^z);toybank.add(1);assert toybank.express(z) is not None
for m,k in ((S,a),(S,d),(reductions,a),(reductions,d),(X,u),(X,v),(PATH,u),(PATH,v)):del m[k]

# Check actual old-word sender/receiver banks with an independent augmented-
# row span test for every small-source pulse, plus large-source examples.
result=Counter();examples=[]
for c,d in [(2,536),(8,328),(328,1),(0,1)]:
 sends=outs[c];pg=grade(c,d)
 aa=[x for x in sorted(S) if x not in (c,d) and (g:=grade(x,d)) and g<pg]
 # Include charts with and without direct source-pulse influence.
 mask=sum(1<<p for p in sends)
 no=[x for x in aa if not any(sens(p)&mask for p in S[x])]
 yes=[x for x in aa if any(sens(p)&mask for p in S[x])]
 aa=no[:8]+yes[:8]
 if len(sends)<=6:alphas=[sum(1<<p for i,p in enumerate(sends) if n>>i&1) for n in range(1<<len(sends))]
 else:alphas=[0]+[1<<p for p in sends[:12]]+[mask]
 diffs={x:[q[2] for q in intersect(x,d)] for x in aa}
 for alpha in alphas:
  base=Span()
  def value(p):return obs(p) ^ (z if (sens(p)&alpha).bit_count()%2 else 0)
  for p in S[d]:base.add(value(p))
  assert base.express(z) is None
  for x in aa:
   full=Span();full.rows=base.rows.copy();full.union=base.union
   for p in S[x]:full.add(value(p))
   direct=full.express(z) is not None
   predicted=any((q&alpha).bit_count()%2 for q in diffs[x])
   assert direct==predicted
   result['augmented_span_checks']+=1
   result['direct_successes']+=int(direct)
   if not any(sens(p)&mask for p in S[x]):result['no_pulse_sender_checks']+=1
 result['source_destination_pairs']+=1;examples.append({'source':c,'receiver':d,'sender_charts':len(aa),'pulses':len(alphas),'source_outgoing':len(sends)})
out={'toy_clean_sender_z_receipt_detected':True,'scope':'direct augmented old-plus-z GF(2) stock span, not physical schedule','counts':dict(result),'examples':examples}
(Path(__file__).resolve().parent/'DETECTOR-CONTROL.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,sort_keys=True))
