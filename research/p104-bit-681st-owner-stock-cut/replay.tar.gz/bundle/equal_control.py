#!/usr/bin/env python3
"""Positive detection control: a real new owner with one equal-grade receipt."""
import sys,json,gzip,hashlib
from collections import Counter
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))

from network import *
import bit_native as native
from two_hole import grade
Z=4000; P=3554; C=0; D=1
initial=dict(enumerate(W['start']));final=dict(enumerate(W['final']));initial[Z]=C;final[Z]=D
moves=dict(R);moves[P]=(C,D);rows=dict(ROWS);rows[P]=1<<Z;rows[~Z]=1<<P
order=native.schedule(initial,final,moves,rows);native.basis(initial,moves,rows,order)
word=native.emit_word(W,initial,final,moves,rows,order);atlas=op.Atlas(W['frames'])
fwd=op.run_tape(word,atlas,False);adj=op.run_tape(word,atlas,True)
expected=[1<<i for i in range(681)]
for i in range(111,222):expected[i]^=1<<(i-111)
expected_adj=[sum((row>>i&1)<<j for j,row in enumerate(expected)) for i in range(681)]
assert fwd.output==expected and adj.output==expected_adj
scratch=681+order.index(P)
added=[i for i,e in enumerate(word['program']) if e==['ADD',scratch,680,C]]
assert len(added)==1
missing_fwd=op.run_tape(word,atlas,False,omit=added[0]).output
missing_adj=op.run_tape(word,atlas,True,omit=added[0]).output
assert missing_fwd!=expected and missing_adj!=expected_adj
missing_damages=[sum(a!=b for a,b in zip(missing_fwd,expected)),sum(a!=b for a,b in zip(missing_adj,expected_adj))]
oldpaid=Counter(G.values());newpaid=Counter(p.grade for p in fwd.packets.values());assert newpaid==oldpaid+Counter({8:1});assert newpaid==Counter(p.grade for p in adj.packets.values())
for tape in (fwd,adj):
 owner=[p for p in tape.packets.values() if p.arrival.row&(1<<411)]
 assert len(owner)==1 and owner[0].arrival.row==1<<411
packed=gzip.compress(json.dumps(word,sort_keys=True,separators=(',',':')).encode(),compresslevel=9,mtime=0);packed=packed[:9]+bytes([3])+packed[10:]
root=Path(__file__).resolve().parent;(root/'EQUAL-CONTROL-WORD.json.gz').write_bytes(packed)
receipt=dict(public_owners=681,old_public_outputs=680,omit_new_send_add_damaged_rows=missing_damages,canonical_word=op.canonical_hash(word),word_gzip_sha256=hashlib.sha256(packed).hexdigest(),new_input_chart=C,new_output_chart=D,productive_grade=grade(C,D),new_paid_grade=grade(C,D),all_forward_and_transposed_coefficients='passed',protected_owner_411='unique pure paid bridge',dirty_retirements_forward_and_reverse=[fwd.dirty,adj.dirty],new_paid_bin_delta={'8':1},new_productive_bin_delta={'8':1},delta_36_call_signed=0,old_packet_count=len(O),new_packet_count=len(moves),primitive_counts=dict(Counter(i[0] for i in word['program'])))
(root/'EQUAL-CONTROL.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n');print(json.dumps(receipt,sort_keys=True))
