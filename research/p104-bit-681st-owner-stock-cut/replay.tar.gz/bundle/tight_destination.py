#!/usr/bin/env python3
"""Tight grade-eight destination information cuts, independent of recoding."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from network import W,R,DR,O,Span,public_source
from two_hole import grade
out={}
for reverse in (False,True):
 start,final,routes=(W['final'],W['start'],DR) if reverse else (W['start'],W['final'],R)
 c,d=(1,0) if reverse else (0,1)
 arrivals=sum(b==d for a,b in routes.values());initial=start.count(d);b=Span()
 for i,chart in enumerate(final):
  if chart!=d:continue
  row=1<<i
  if not reverse and 111<=i<222:row^=1<<(i-111)
  if reverse and i<111:row^=1<<(111+i)
  assert b.add(row)
 oldrank=len(b.rows);assert b.add(1<<680);extended=len(b.rows)
 high=[(a,z) for a in set(start) for z in set(start)|set(final)|set(v for _,v in routes.values()) if a!=z and grade(a,z)==8]
 assert high==[(c,d)] and grade(c,d)==8 and initial==0 and oldrank==arrivals and extended==arrivals+1
 out['adjoint' if reverse else 'forward']={'unique_grade_8_source':c,'unique_grade_8_destination':d,'old_initial_inputs_at_destination':initial,'original_paid_arrivals':arrivals,'old_retained_output_rank':oldrank,'with_new_independent_output_rank':extended}
result={'pins':public_source(),'model':'Original fixed one-bit route/arrival counts; arbitrary recoding and local processing, but no extra paid receipt or timing side channel. A distinct source supplies z.','cuts':out}
(Path(__file__).resolve().parent/'TIGHT-DESTINATION.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
