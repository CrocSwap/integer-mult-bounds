#!/usr/bin/env python3
"""Search one extra pre-3407 receipt to chart0 in the fixed diagnostic model.
All existing moves/rows up to 3407 fixed as in diagnostic, except retargeted
3409 is any scalar over the actual five early source rows. One new move from
any original-chart sender is allowed to be arbitrarily encoded from its full
actual stock at native cutoff 19903. 3407/3408/terminal221 are freely recoded.
This fixes all other mutable rows; it is not a global no-go theorem.
"""
import sys,json,hashlib
from pathlib import Path
from collections import defaultdict,Counter
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import *
OUT=Path(__file__).resolve().parent


def span_label(rows):
 b=Span()
 for v,tag in rows:b.add(v,tag)
 return b

def setup(side):
 M=dict(R);rows=dict(ROWS);M[3410]=(421,0);rows[3410]=0;del M[3409],rows[3409]
 rows[789]=1<<17;local={785:1<<679,1584:1<<785,1934:1<<1584}
 for p in local:
  for k,r in list(rows.items()):
   if r>>p&1 and k not in local:rows[k]^=1<<p
 rows.update(local);rows[~679]=1<<1934
 if side:
  M[1583]=(19,182);rows[1583]=(1<<17)^(1<<781);rows[1585]=(1<<1583)^(1<<813);rows[1586]=1<<1583
 vals={i:1<<i for i in range(680)};bank=defaultdict(list)
 for i,c in enumerate(W['start']):bank[c].append(i)
 def step(p):
  assert all(j in bank[M[p][0]] for j in labels(rows[p])),(p,M[p])
  vals[p]=xsum(vals[j] for j in labels(rows[p]));bank[M[p][1]].append(p)
 for p in O:
  if p in (3409,3410):continue
  if p==3407:break
  step(p)
  if p==2947:
   assert bank[421]==[264,789,1934,2234,2947]
   step(3410)
 assert vals[3410]==0
 assert len(bank[0])==533 and 3410 in bank[0]
 return M,rows,vals,bank

def test(side):
 M,rows,vals,bank=setup(side)
 b0=[p for p in bank[0] if p!=3410]; src=[264,789,1934,2234,2947]
 fixed=span_label((vals[p],1<<i) for i,p in enumerate(b0))
 source_rows={c:[p for p in bank[c] if p!=3410] for c in ATLAS.body if c and ATLAS.grade(c,0)}
 counts=Counter();bygrade=Counter();results=[]
 for mask in range(32):
  x=xsum(vals[p] for i,p in enumerate(src) if mask>>i&1)
  base=Span();base.rows=fixed.rows.copy();base.add(x,1<<len(b0))
  assert base.express(X[3410]) is None
  # If Y is recovered with one extra scalar, its span together with the
  # existing 0 bank is fixed: B + <x,Y>. Owner221 test can thus be checked
  # independently of which sender supplies this scalar.
  owner=Span();owner.rows=base.rows.copy();owner.add(X[3410])
  for p in bank[107]+bank[635]:owner.add(vals[p])
  if owner.express((1<<221)^(1<<110)) is None:
   counts['masks_owner_infeasible_even_with_old_y']+=1;continue
  counts['masks_owner_feasible_with_old_y']+=1
  for c,ids in source_rows.items():
   g=ATLAS.grade(c,0);counts[f'grade{g}_tested']+=1
   ext=Span();ext.rows=base.rows.copy()
   for i,p in enumerate(ids):ext.add(vals[p],1<<(len(b0)+1+i))
   witness=ext.express(X[3410])
   if witness is None:continue
   pick=[ids[i] for i in range(len(ids)) if witness>>(len(b0)+1+i)&1]
   assert pick
   bygrade[g]+=1
   counts[f'grade{g}_passes']+=1
   if len(results)<10000:
    rec=[b0[i] for i in range(len(b0)) if witness>>i&1]
    results.append(dict(mask=mask,early_donors=[src[i] for i in range(5) if mask>>i&1],chart=c,grade=g,source_donors=pick,
       source_last_donor_clock=max([CLOCK[p] if p>=680 and p!=3410 else -1 for p in pick],default=-1),
       old_y_decoder_b0=rec,old_y_decoder_early=bool(witness>>len(b0)&1)))
 print('side',side,'counts',dict(counts),'passing by grade',dict(bygrade),flush=True)
 return dict(side=side,source_screen='entire actual source bank at original cutoff immediately before packet 3407, arbitrary one-scalar combination from a single chart to 0',num_source_charts=len(source_rows),counts=dict(counts),passing_by_grade=dict(bygrade),passes=results)

x=[test(False),test(True)]
(OUT/'one-extra-repair-search.json').write_text(json.dumps(dict(word_sha256='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',cases=x,scope='Only one new incoming packet from an actual source chart at/before3407, original diagnostic rows otherwise fixed upstream; retargeted early421->0 packet ranges over all32 actual source combinations, and 3407,3408,terminal221 are freely recodable.'),indent=2,sort_keys=True)+'\n')
