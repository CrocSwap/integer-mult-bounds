#!/usr/bin/env python3
"""Independent scalar chronology certificate for two forced 785 branches.

This verifies a necessary obstruction, not a candidate construction. It assumes
785 is either e679 or e679+e17. A separate source-union rank certificate is
needed to establish that those are the only eligible injections in a wider
class. All unspecified sender equations retain their native donor lists.
"""
import argparse
import collections
import gzip
import hashlib
import json
from pathlib import Path

PIN_SHA = 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
DECODED_SHA = '3bf6e12edfc00aa2ec72d65c83c850d09de377c47fe97b9cf8c2b1b4161741f5'


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def extract(word):
    rows = {i: 1 << i for i in range(680)}
    location = dict(enumerate(word['start']))
    stocks = collections.defaultdict(list)
    for i, c in location.items():
        stocks[c].append(i)
    equations = {}
    packets = {}
    for clock, op in enumerate(word['program']):
        kind, i, *args = op
        if kind == 'INIT':
            need(i not in rows, 'duplicate allocation')
            rows[i] = 0
            location[i] = args[0]
            equations[i] = []
        elif kind == 'ADD':
            j, c = args
            need(location[i] == location[j] == c, 'ADD chart mismatch')
            rows[i] ^= rows[j]
            equations[i].append(j)
        elif kind == 'MOVE':
            source, destination = args
            need(location[i] == source, 'MOVE chart mismatch')
            need(all(j in stocks[source] for j in equations[i]), 'noncausal native donor')
            packets[i] = dict(label=i, clock=clock, source=source,
                              destination=destination, donors=equations[i].copy(),
                              original_row=rows[i], stock=stocks[source].copy())
            location[i] = destination
            stocks[destination].append(i)
        elif kind == 'SWAP':
            j, = args
            rows[i], rows[j] = rows[j], rows[i]
            location[i], location[j] = location[j], location[i]
        elif kind == 'CLEAR':
            need(location[i] == args[0], 'CLEAR chart mismatch')
            del rows[i]
            del location[i]
        else:
            raise RuntimeError('unknown operation')
    need(len(packets) == 2874, 'native MOVE count')
    need(set(rows) == set(range(680)), 'native final ownership')
    for i in range(680):
        expected = (1 << i) ^ ((1 << (i - 111)) if 111 <= i < 222 else 0)
        need(rows[i] == expected, 'native target row mismatch')
        need(location[i] == word['final'][i], 'native terminal chart mismatch')
    return packets


def mutable_labels(packets):
    f = set(range(1584, 1587)) | set(range(1931, 1937))
    f |= set(range(2411, 2414)) | set(range(2231, 2237))
    f |= {2947, 2948, 2949, 2677, 2678, 3409, 3547}
    f |= {i for i, p in packets.items() if p['source'] == 0 and p['clock'] > 10378}
    f |= {i for i, p in packets.items()
          if any(j in set(range(1931, 1937)) for j in p['donors'])}
    f |= {i for i, p in packets.items() if p['source'] == 509 and i != 3553}
    # Further harmless releases strengthen the certified family. All eight
    # old receipts at chart0 before the new3409, and all four final chart635
    # arrivals, have all-zero source stock on both probe branches.
    f |= {i for i, p in packets.items() if p['destination'] == 0 and i != 3410}
    f |= {2876, 2882, 2885, 3408}
    need(3553 not in f and 785 not in f and 789 not in f and 3410 not in f,
         'protected or prescribed label accidentally mutable')
    return f


def probe(word, packets, free, alpha):
    support = [17, 106, 108, 109, 110] + ([679] if alpha else [])
    w = sum(1 << i for i in support)
    # State 0/1 is an exact scalar evaluation; state 2 overgrants either bit.
    states = {i: int(bool((w >> i) & 1)) for i in range(680)}
    stock = collections.defaultdict(list)
    for i, c in enumerate(word['start']):
        stock[c].append(i)
    source_zero = None
    source_268 = []
    for i, p in packets.items():
        if i == 3410:
            continue
        source = p['source']
        destination = 0 if i == 3409 else p['destination']
        if i == 785:
            row = (1 << 679) ^ (alpha << 17)
            state = (row & w).bit_count() % 2
            need(state == 0, 'early branch does not annihilate probe')
        elif i == 789:
            state = 1  # The prescribed row e17.
        elif i in free:
            # Any linear combination of all-zero stock is zero. Otherwise
            # permit either bit, independently of all other free choices.
            state = 2 if any(states[j] != 0 for j in stock[source]) else 0
        else:
            ds = [3409 if j == 3410 else j for j in p['donors']]
            need(all(j in stock[source] for j in ds), 'frozen donor unavailable')
            state = 2 if any(states[j] == 2 for j in ds) else sum(states[j] for j in ds) % 2
        if i == 3407:
            need(p['clock'] == 19903, '3407 clock')
            need(len(stock[0]) == 532, 'complete pre-return chart0 stock size')
            need(all(states[j] == 0 for j in stock[0]), 'chart0 is not zero before3407')
            source_zero = dict(clock=19903, stock_count=532,
                               initial_count=sum(c == 0 for c in word['start']),
                               incoming=[j for j in stock[0] if j >= 680],
                               every_scalar_evaluation=0)
        if i in (1931, 1934):
            need(all(states[j] == 0 for j in stock[source]), '268 live stock not annihilated')
            source_268.append(dict(sender=i, clock=p['clock'], stock=stock[source].copy(),
                                   every_scalar_evaluation=0))
        states[i] = state
        stock[destination].append(i)
    terminal_stock = stock[635]
    need(terminal_stock == [2876, 2882, 2885, 3408], 'chart635 terminal stock')
    need(all(states[j] == 0 for j in terminal_stock), 'terminal stock not annihilated')
    need(word['final'][221] == 635, 'owner221 final chart')
    demand = (1 << 221) ^ (1 << 110)
    need((demand & w).bit_count() % 2 == 1, 'owner221 target not separated')
    need((packets[1584]['original_row'] & w).bit_count() % 2 == 1,
         'lost original1584 direction not detected')
    need(all((packets[i]['original_row'] & w).bit_count() % 2 == 0
             for i in [722, 1360, 1464, 1728, 1824]), 'five unchanged268 rows not annihilated')
    return dict(early_785_support=[679] + ([17] if alpha else []), probe_support=support,
                live_268_stock_checks=source_268,
                old_independent_stock=dict(row=1584, probe_evaluation=1,
                                          other_five=[722, 1360, 1464, 1728, 1824],
                                          other_five_evaluations=0),
                chart0_before3407=source_zero,
                terminal=dict(owner=221, chart=635, target_support=[221, 110],
                              target_evaluation=1,
                              stock=[dict(label=j, clock=packets[j]['clock'],
                                          source=packets[j]['source'], evaluation=states[j])
                                     for j in terminal_stock]),
                new3409_arrival_clock=packets[3409]['clock'],
                unknown_packet_count=sum(v == 2 for i, v in states.items() if i >= 680))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('word', type=Path)
    ap.add_argument('--out', type=Path)
    args = ap.parse_args()
    raw = args.word.read_bytes()
    decoded = gzip.decompress(raw)
    need(hashlib.sha256(raw).hexdigest() == PIN_SHA, 'wrong pinned gzip')
    need(hashlib.sha256(decoded).hexdigest() == DECODED_SHA, 'wrong decoded source')
    word = json.loads(decoded)
    packets = extract(word)
    free = mutable_labels(packets)
    branches = [probe(word, packets, free, a) for a in (0, 1)]
    result = dict(schema='P104-paired-repair-two-branch-probe/1',
                  source_gzip_sha256=PIN_SHA, source_json_sha256=DECODED_SHA,
                  mutable_sender_labels=sorted(free), mutable_count=len(free),
                  prescribed={'785': 'One of e679,e679+e17', '789': 'e17',
                              '3409_destination': 0, '3410': 'deleted'},
                  protected={'packet': 3553, 'owner': 411},
                  clocks='Native MOVE clocks only',
                  terminal_decoders='Arbitrary at their own final chart',
                  branches=branches,
                  qualification='Necessary impossibility certificate for the stated two branches; no new word or kappa claim.')
    if args.out:
        args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status='VERIFIED', mutable_count=len(free),
                          terminal_owner=221, probes=[b['probe_support'] for b in branches],
                          last_terminal_arrival=19907, new3409_arrival=19913), indent=2))


if __name__ == '__main__':
    main()
