#!/usr/bin/env python3
"""Exact fixed-payload screens for early retargeted P104 packet 3409.
All native bit rows use the pinned #7830 WORD. This is a local screen, not
a proof for all 176 mutable senders or a successful word.
"""
import sys,json,hashlib
from collections import defaultdict,Counter
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import *

OUT=Path(__file__).resolve().parent
assert hashlib.sha256((HERE9/'source/inputs/WORD.json.gz').read_bytes()).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
assert CLOCK[2947]==10388 and R[2947]==(518,421)
assert (CLOCK[3407],CLOCK[3408],CLOCK[3409],CLOCK[3410])==(19903,19907,19913,19918)
assert list(labels(ROWS[3409]))==[789,1934,2234,2947]
assert list(labels(ROWS[3410]))==[17,679,3409]
assert X[3410]==X[3409]^(1<<17)^(1<<679)
readers=[p for p in O if ROWS[p]>>3410&1]
assert len(readers)==63 and readers[0]==3411 and CLOCK[3411]==20139
assert not [k for k,r in ROWS.items() if k<0 and r>>3410&1]


def span_test(vs,target):
 b=Span()
 for i,v in enumerate(vs): b.add(v,1<<i)
 return b.express(target)

def separator(rows,target):
 # Solve rows dot probe = 0, target dot probe = 1, over GF(2).
 basis={}
 for v,rhs in [(x,0) for x in rows]+[(target,1)]:
  while v:
   k=v.bit_length()-1
   if k in basis:
    w,b=basis[k];v^=w;rhs^=b
   else:
    basis[k]=(v,rhs);break
  if not v: assert rhs==0
 probe=0
 for k in sorted(basis):
  v,rhs=basis[k]
  if rhs^((v&probe).bit_count()&1):probe^=1<<k
 assert all((v&probe).bit_count()%2==0 for v in rows)
 assert (target&probe).bit_count()%2==1
 return probe

def rank(vs):
 b=Span()
 for v in vs:b.add(v)
 return len(b.rows)

def run(side,alpha,mask):
 M=dict(R);rows=dict(ROWS)
 # Keep the original 3410 label as the retargeted one, exactly as #8006
 # construct.py does; original paid 3409 and old 3410 disappear.
 M[3410]=(421,0);rows[3410]=ROWS[3409];del M[3409],rows[3409]
 rows[789]=1<<17
 local={785:(1<<679)^(alpha<<17),1584:1<<785,1934:1<<1584}
 for p in local:
  for k,r in list(rows.items()):
   if r>>p&1 and k not in local:rows[k]^=1<<p
 rows.update(local)
 rows[~679]=(1<<1934)^(alpha<<789)
 if side:
  M[1583]=(19,182);rows[1583]=(1<<17)^(1<<781)
  rows[1585]=(1<<1583)^(1<<813);rows[1586]=1<<1583
 # Test every combination of the five available source rows, including the
 # Pro positive control 3409=789, which is mask 2.
 src=[264,789,1934,2234,2947]
 rows[3410]=sum(1<<p for k,p in enumerate(src) if mask>>k&1)
 vals={i:1<<i for i in range(680)}; bank=defaultdict(list)
 for i,c in enumerate(W['start']): bank[c].append(i)
 checkpoints={}; saved_readers=[]
 def step(p):
  assert all(j in bank[M[p][0]] for j in labels(rows[p])), (p,M[p],list(labels(rows[p])))
  vals[p]=xsum(vals[j] for j in labels(rows[p]));bank[M[p][1]].append(p)
 for p in O:
  if p in (3409,3410):continue
  if p==3407:
   checkpoints['before3407']={c:bank[c].copy() for c in (0,107,635)}
  if p in readers:
   if not saved_readers:
    ids=bank[0].copy(); w=span_test([vals[j] for j in ids],X[3410]); old_y_reader=w is not None
   else:
    assert bank[0]==ids
   saved_readers.append([p,CLOCK[p],old_y_reader])
  step(p)
  if p==2947:
   checkpoints['source421']=bank[421].copy();checkpoints['pre_early_chart0']=bank[0].copy()
   assert bank[421]==src
   step(3410)
 source=checkpoints['source421']
 b0=checkpoints['before3407'][0];b107=checkpoints['before3407'][107];b635=checkpoints['before3407'][635]
 # Any 3407 scalar is allowed from chart0, any 3408 from chart107 plus
 # 3407, and any terminal221 decoder from all chart635 receipts.
 stock221=b0+b107+b635
 target221=(1<<221)^(1<<110)
 witness=span_test([vals[j] for j in stock221],target221)
 recode221=None if witness is None else [stock221[i] for i in labels(witness)]
 optimistic=None
 if mask==0:
  gifted=[j for j in b0 if j!=3410]+source
  vectors=[vals[j] for j in gifted]
  probe=separator(vectors,X[3410])
  optimistic=dict(chart0_before_and_after_early_sources=len(b0)-1,source_chart421=source,
      rank_before=rank([vals[j] for j in b0 if j!=3410]),rank_after_gifting_all_five=rank(vectors),
      rank_after_adding_old_y=rank(vectors+[X[3410]]),probe_support=list(labels(probe)),
      proof='Probe annihilates every fixed pre-reader chart0 stock row and all five possible early 421-source rows; evaluates native old Y3410 to one.')
 final679=span_test([vals[j] for j in bank[421]],1<<679)
 oldY_first=span_test([vals[j] for j in b0],X[3410])
 assert all(not(CLOCK[p]<CLOCK[3407]) for p in readers)
 if oldY_first is not None:
  assert all(k[2] for k in saved_readers)
 return dict(side=side,alpha=alpha,source_ids=source,source_rows={str(p):list(labels(vals[p])) for p in source},mask=mask,
  payload_donors=[src[i] for i in range(5) if mask>>i&1],payload_support=list(labels(vals[3410])),
  chart0_earliest_before_arrival=len(checkpoints['pre_early_chart0']),
  before3407=dict(chart0_count=len(b0),chart107=b107,chart635=b635,old_y_available=oldY_first is not None,
                  old_y_witness=None if oldY_first is None else [b0[i] for i in labels(oldY_first)],
                  owner221_locally_possible=witness is not None,owner221_witness=recode221),
  readers=dict(total=63,old_y_recoverable_count=sum(x[2] for x in saved_readers),rows=saved_readers),
  optimistic_all_five_sources=optimistic,
  owner679_locally_possible=final679 is not None,
  owner679_donors=None if final679 is None else [bank[421][i] for i in labels(final679)])

r={}
for side in (False,True):
 for alpha in (0,1):
  key=f"{'side' if side else 'single'}_alpha{alpha}"
  data=[run(side,alpha,m) for m in range(32)]
  r[key]=data
  print(key,'source421',data[0]['source_ids'],'pre3407 chart0',data[0]['before3407']['chart0_count'],'chart107',data[0]['before3407']['chart107'],'chart635',data[0]['before3407']['chart635'])
  for z in data:
   a=z['before3407'];print(' mask',z['mask'],'donors',z['payload_donors'],'owner221',a['owner221_locally_possible'],'oldY by3407',a['old_y_available'],'oldY reader count',z['readers']['old_y_recoverable_count'],'679',z['owner679_locally_possible'])

result=dict(word_sha256='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',insertion='immediately after 2947@10388',retargeted_old_label='3410; original 3409 removed, 3410 reassigned 421->0',native_feedback_old_y_row=list(labels(X[3410])),native_3409_donors=[789,1934,2234,2947],direct_readers=readers,scopes='Independent diagnostic fixed rows, varied only retargeted payload among 32 five-source combinations; free 3407/3408 and owner221 terminal decoding. alpha=1 is an additional concrete 785=e679+e17 construction, not the full 176-mutable family.',cases=r)
(OUT/'fixed-payload-screen.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
