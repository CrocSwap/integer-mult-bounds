# P104 early retargeted feedback: bounded diagnostics

This is a negative, narrowly scoped research control. It does not prove that every possible earlier feedback construction fails, establish an admissible new word, or claim a κ improvement. The source is the native 680-owner #7830 word with gzip SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`. The input and caller pricing fixtures are pinned in `source/SOURCES.json`; original #7830 notices and license are retained. The 176-label probe helper was copied from the Pro-supplied audited package, which did not contain a separate license.

## Timing and exact feedback row

At chart 421, the full source stock for the old native donor equation is `[264, 789, 1934, 2234, 2947]`. The first is present initially; the other four arrive at clocks `390, 4613, 6619, 10388`. In particular, all five can participate in a retargeted 421→0 scalar immediately after packet 2947 at clock 10388. It then precedes 3407 (0→107) at 19903, and 3408 (107→635) at 19907. A payload with fewer donor dependencies can be sent earlier still. The native feedback identity is

```
X3410 = X3409 + e17 + e679
X3409 = X789 + X1934 + X2234 + X2947
```

The old 3410 scalar is directly read by 63 surviving paid packets, beginning with 3411 at clock 20139; there are no terminal equations that directly read it. Before 3407 the fixed diagnostic has 532 chart-0 stock rows other than the retargeted scalar, and there are no later native chart-0 receipts before any of the 63 readers.

## No-extra-transfer screen

`check.py` replays the single-route and restored-side diagnostics from the #8006 supplement, plus the variants with `785=e679+e17`. For each of these four fixed upstream words it tries **all 32** XOR payloads from the five chart-421 rows at the gap after 2947. The tests allow arbitrary local recoding of 3407, 3408, and the final owner-221 decoding. They also test exact recovery of the native full `X3410` input row at each of the 63 readers. They do not claim arbitrary recoding elsewhere.

Every one of the 128 payload/diagnostic cases leaves `X3410` unavailable to every reader. A single explicit separating input proves a stronger fixed-word fact in all four cases: probe support `{29,58,95,102,106,108}` annihilates all 532 retained chart-0 rows and each of the five chart-421 rows, but pairs with native `X3410` to one. The respective ranks are 532, 537 after all five chart-421 rows are generously given to chart 0, and 538 after `X3410` is appended. The machine receipt contains all 63 reader labels and clocks.

For both single-route variants only payload `789=e17` allows owner 221 to be locally recovered using the actual chart-0, chart-107 and earlier chart-635 stock. For the restored-side variants owner 221 is already locally recoverable for all 32 payloads. The chart-421 stock can locally recover independent owner 679 in all four cases.

The two single-route variants also use only sender changes in the Pro proof's existing 176-label mutable set, apart from the prescribed 785/789 and the changed-clock 3409 itself. They exhibit why Pro's **positive local probe** `3409=789, 3407=3409, 3408=3407` is insufficient: it sends a nonzero value on the chosen probe, while the whole old 3410 row remains unavailable. This is a counterexample to treating that local probe as a full construction; it is **not** an impossibility proof for arbitrary changes across all 176 labels. In fact, `overgrant_probe.py` explicitly shows the six-coordinate separator cannot establish that larger claim: the overgrant permits a nonzero value at 1934 and at chart-0 arrival 3300.

## Minimum one-extra-receipt screen

`repair_search.py` fixes the original `785=e679` single-route or restored-side diagnostic values, with the following limited freedoms:

- the earlier 421→0 scalar is any of all 32 combinations of the actual five source rows;
- one new paid scalar may arrive at chart 0 immediately before 3407 from any of the other 635 actual charts, with any XOR of that chart's full pre-3407 stock;
- 3407, 3408 and owner-221 terminal decoding may be recoded freely;
- the full old `X3410` scalar must be recoverable at chart 0.

For the single-route diagnostic, only the `789` early payload can satisfy the owner-221 test even if `X3410` is granted; the only qualifying extra source is chart 1 at grade 8. For the restored-side diagnostic there is no qualifying grade-1 source in 3,552 tested source/payload combinations and no grade-2 source in 4,896. No grade-3 charts exist in this pinned atlas. The minimum is grade 4: chart 268 can send the XOR `[722,1360,1464,1728,1824]`, which is exactly native `X1934`, and the early 421→0 payload `[789,2234,2947]` then XORs with it to native `X3410`. A second grade-4 encoding also passes; complete counts and witnesses are in `one-extra-repair-search.json`. This is a minimum **within the stated one-new-receipt, fixed-diagnostic model** only; other changed senders, retargeted existing packets, or multi-packet schemes are not excluded.

## Literal compiled control and complete price

`compile_repair.py` builds the minimum-grade restored-side control. It inserts the new 268→0 packet after native 1824@4152 and the retargeted 421→0 packet after native 2947@10388. It adds the new scalar to each of the 63 old direct reader equations and redecodes every final owner where the actual terminal stock allows it. All source and donor choices are checked for causal availability at native chronology.

The old `X3410` row is then available to all 63 direct readers, but only **31 of their complete packet values** match native: other donor values have also changed. The literal word still has **58 of 680 forward output rows wrong and 29 of 680 literal-adjoint output rows wrong**. Owner 221 is exact forward, owner 679 is exact in both orientations, and all 537 chart-1 observations are input-679-free. Owned storage remains dirty (3553 fields in each orientation), and physical erasure is not shown. The compiled gzip SHA-256 is `7deb9939a17ce2a8190f3f1b7ee4e986ea92486768d3eab78f575bb0b6c5705e`.

Its actual paid MOVE histogram for one native call is `{1:1376, 2:1280, 3:54, 4:45, 5:16, 6:103}`, totaling 2874 packets. Using the pinned complete caller and all 36 binary calls, the priced margin at `κ=0.00388` is approximately **-107.0727167934003**. At the campaign target `κ=0.003889928046155` it is approximately **-110.8937626446397**. The unchanged pinned rational 48-call fixture gives approximately **-9.9729391999983** at that target. The exact full charged/productive grade counts and directed-interval margins are in `compiled-repair.json`. These prices apply to an invalid diagnostic and do not establish a finite application.

## Reproduce

Python 3.11 or newer, assertions enabled, with no network or non-standard package:

```sh
sha256sum -c SHA256SUMS
python3 -B check.py > results.log
python3 -B overgrant_probe.py
python3 -B repair_search.py
python3 -B compile_repair.py
sha256sum -c SHA256SUMS
```

The supplied scripts use the bundled pinned fixtures and overwrite only the generated receipts and diagnostic word in this directory. The raw `results.log` enumerates every fixed-payload case; the JSON receipts carry row witnesses, exact reader labels, source selection counts and literal operator failures.
