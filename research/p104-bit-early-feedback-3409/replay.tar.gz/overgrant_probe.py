#!/usr/bin/env python3
"""Check if one exact fixed-diagnostic row witness also spans the 176-slot overgrant."""
import collections,json,gzip,hashlib,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from verify_two_branch_probe import extract,mutable_labels
p=Path(__file__).resolve().parent/'source/inputs/WORD.json.gz';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));pack=extract(w);free=mutable_labels(pack);assert len(free)==176
probe=sum(1<<i for i in [29,58,95,102,106,108]); by=pack

def xor_set(a,b):
 out=0
 for x in range(2):
  for y in range(2):
   if a>>x&1 and b>>y&1:out|=1<<(x^y)
 return out
for alpha in [0,1]:
 st={i:1<<((probe>>i)&1) for i in range(680)};bank=collections.defaultdict(list)
 for i,c in enumerate(w['start']):bank[c].append(i)
 for p,r in pack.items():
  if p==3410:continue
  if p==3409:continue
  if p==785:val=1<<(((probe>>679)^(alpha*(probe>>17)))&1)
  elif p==789:val=1<<((probe>>17)&1)
  elif p in free:val=3 if any(st[j]!=1 for j in bank[r['source']]) else 1
  else:
   val=1
   for j in r['donors']:
    assert j!=3410
    val=xor_set(val,st[j])
  st[p]=val;bank[r['destination']].append(p)
  if p==2947:
   src421=[(j,st[j]) for j in bank[421]]
   assert src421==[(264,1),(789,1),(1934,3),(2234,1),(2947,1)]
   print('alpha',alpha,'earliest source421',src421)
  if p==3407:
   nonzero=[(j,st[j]) for j in bank[0] if st[j]!=1]
   assert nonzero==[(3300,3)]
   print('alpha',alpha,'pre3407 chart0 nonzero/possible',nonzero)
   break
old_y_eval=(by[3410]['original_row']&probe).bit_count()%2
assert old_y_eval==1
print('native oldY probe',old_y_eval)
