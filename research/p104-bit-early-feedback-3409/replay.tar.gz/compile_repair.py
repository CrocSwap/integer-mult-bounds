#!/usr/bin/env python3
"""Compile the minimum-grade one-new-move repaired *diagnostic*, not a bound."""
import sys,json,gzip,hashlib
from pathlib import Path
from collections import Counter,defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import *
import bit_native
OUT=Path(__file__).resolve().parent
M=dict(R);rows=dict(ROWS);M[3410]=(421,0);rows[3410]=ROWS[3409];del M[3409],rows[3409]
rows[789]=1<<17
local={785:1<<679,1584:1<<785,1934:1<<1584}
for p in local:
 for k,r in list(rows.items()):
  if r>>p&1 and k not in local:rows[k]^=1<<p
rows.update(local);rows[~679]=1<<1934
M[1583]=(19,182);rows[1583]=(1<<17)^(1<<781);rows[1585]=(1<<1583)^(1<<813);rows[1586]=1<<1583
assert list(labels(rows[3410]))==[789,2234,2947]
q=max(M)+1;assert q==3554
M[q]=(268,0);rows[q]=sum(1<<p for p in [722,1360,1464,1728,1824])
readers=[p for p in O if ROWS[p]>>3410&1];assert len(readers)==63
for p in readers:
 assert rows[p]>>3410&1
 rows[p]^=1<<q
seq=[]
for p in O:
 if p in (3409,3410):continue
 seq.append(p)
 if p==1824:seq.append(q)
 if p==2947:seq.append(3410)
assert set(seq)==set(M) and len(seq)==2874
vals={i:1<<i for i in range(680)};bank=defaultdict(list)
for i,c in enumerate(W['start']):bank[c].append(i)
for p in seq:
 assert all(j in bank[M[p][0]] for j in labels(rows[p])),(p,list(labels(rows[p])))
 vals[p]=xsum(vals[j] for j in labels(rows[p]));bank[M[p][1]].append(p)
assert vals[q]==X[1934]
assert vals[3410]^vals[q]==X[3410]
assert vals[785]==vals[1584]==vals[1934]==1<<679
assert all(not(vals[p]>>679&1) for p in bank[1])
reader_exact=[p for p in readers if vals[p]==X[p]]
assert vals[1583]==X[785] and vals[1585]==X[1585] and vals[1586]==X[1586]
B={}
for c,ps in bank.items():
 s=Span()
 for p in ps:s.add(vals[p],1<<p)
 B[c]=s
missing=[];recovered=[];targets=op.expected_operator(False)
for i,c in enumerate(W['final']):
 rep=B[c].express(targets[i])
 if rep is None:missing.append(i)
 else:
  if xsum(vals[j] for j in labels(rows[~i]))!=targets[i]:recovered.append(i)
  rows[~i]=rep
word=bit_native.emit_word(W,dict(enumerate(W['start'])),dict(enumerate(W['final'])),M,rows,seq)
traces=[op.run_tape(word,ATLAS,reverse) for reverse in (False,True)]
bad=[[i for i,(x,y) in enumerate(zip(t.output,op.expected_operator(reverse))) if x!=y] for reverse,t in zip((False,True),traces)]
assert bad[0]==missing
assert traces[0].output[679]==1<<679 and traces[0].output[221]==targets[221]
native_hist=Counter(v.grade for v in traces[0].packets.values());assert native_hist==Counter({1:1376,2:1280,3:54,4:45,5:16,6:103})
_,caller,_,_,helpers,_,T,rat=prices.baseline()
paid,targets_price=prices.literal.paired_invoice(caller,native_hist,helpers,Counter(e[0] for e in caller['events']))
assert targets_price==T
rate0=prices.D('0.00388');goal=prices.D('0.003889928046155')
qrat=rat['signed'];rpaid={int(k):v for k,v in qrat['paid'].items()};rtargets={int(k):v for k,v in qrat['productive'].items()}
raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode();zipraw=gzip.compress(raw,mtime=0);(OUT/'REPAIRED-DIAGNOSTIC-WORD.json.gz').write_bytes(zipraw)
res=dict(scope='Invalid restored-side diagnostic plus exactly one additional paid 268->0 grade4 scalar, timed immediately after original 1824@4152; early retargeted 421->0 timed immediately after 2947@10388. Other equations fixed except old-Y direct readers are recoded with the new scalar and arbitrary terminal redecoders.',word_sha256=hashlib.sha256(zipraw).hexdigest(),canonical_json_sha256=hashlib.sha256(raw).hexdigest(),additional_move=dict(label=q,source=268,destination=0,grade=4,donors=[722,1360,1464,1728,1824],after_native_clock=4152),early_retarget=dict(label=3410,source=421,destination=0,donors=[789,2234,2947],after_native_clock=10388),identity='new_268_scalar = native X1934; new_268_scalar XOR retargeted_payload = native X3410',direct_readers_old_y_available=63,direct_readers_outputs_exact_native_count=len(reader_exact),direct_readers_outputs_not_exact_native=[p for p in readers if p not in reader_exact],independent679_transmitted=True,chart1_arrivals=len(bank[1]),chart1_all_679_free=True,owner221_exact_forward=traces[0].output[221]==targets[221],owner679_exact_both=all(t.output[679]==1<<679 for t in traces),full_word_valid=all(not x for x in bad),forward_bad_count=len(bad[0]),forward_bad=bad[0],literal_adjoint_bad_count=len(bad[1]),literal_adjoint_bad=bad[1],dirty_by_orientation=[t.dirty for t in traces],native_paid_grade_histogram=dict(native_hist),per_native_call_paid_total=sum(native_hist.values()),caller_event_counts=dict(Counter(e[0] for e in caller['events'])),complete_binary_36_paid=dict(paid),complete_binary_36_productive=dict(targets_price),complete_binary_36_margin_00388=prices.display(prices.moment(paid,targets_price,rate0)),complete_binary_36_margin_campaign_target=prices.display(prices.moment(paid,targets_price,goal)),unchanged_rational_48_margin_00388=prices.display(prices.moment(rpaid,rtargets,rate0)),unchanged_rational_48_margin_campaign_target=prices.display(prices.moment(rpaid,rtargets,goal)),terminal_outputs_recovered=recovered,qualification='Diagnostic mathematical transfer fails forward and adjoint, binary invoice is negative; no finite application or kappa claim. Dirty owned storage remains and erasure is not established.')
(OUT/'compiled-repair.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print('WORD',res['word_sha256'],'readers exact',len(reader_exact),'forward errors',len(bad[0]),'adjoint errors',len(bad[1]),'binary margin',res['complete_binary_36_margin_00388'],flush=True)
