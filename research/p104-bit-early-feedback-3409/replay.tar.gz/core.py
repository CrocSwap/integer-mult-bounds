# SPDX-License-Identifier: Apache-2.0
from collections import Counter,defaultdict
from functools import reduce
from pathlib import Path
import hashlib
import gzip
import json
import sys
HERE9=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE9/'source'/'vendor'));sys.path.insert(0,str(HERE9/'source'))
import bit_native
import binary_operator as op
import common as prices
W=op.load_json(HERE9/'source/inputs/WORD.json.gz',op.WORD_GZIP,True)
start0,final0,R,ROWS,CLOCK=bit_native.extract(W);O=sorted(R,key=CLOCK.get)
ATLAS=op.Atlas(W['frames']);forward=op.run_tape(W,ATLAS,False);adjoint=op.run_tape(W,ATLAS,True)
assert forward.output==op.expected_operator(False) and adjoint.output==op.expected_operator(True)
X={p:v.arrival.row for p,v in forward.packets.items()}
G={p:v.grade for p,v in forward.packets.items()}
def labels(v):return bit_native.indices(v)
def xsum(seq):
    out=0
    for v in seq:out^=v
    return out
class Span:
    def __init__(self):self.rows={}
    def add(self,x,tag=0):
        while x:
            p=x.bit_length()
            if p not in self.rows:self.rows[p]=(x,tag);return True
            w,c=self.rows[p];x^=w;tag^=c
        return False
    def express(self,x):
        v=0
        while x:
            t=self.rows.get(x.bit_length())
            if t is None:return None
            w,c=t;x^=w;v^=c
        return v
class Direction:
    def __init__(self,r=False):
        assert not r
        self.order=O;self.owners=range(W['public']);self.start=W['start'];self.final=W['final'];self.rank={p:i for i,p in enumerate(O)}
def price(olds,news):
    q=Counter(olds);q.subtract(news)
    return prices.scale(prices.moment({g:-n for g,n in q.items() if n<0},{g:n for g,n in q.items() if n>0},prices.D('0.00388')),36)
def write(name,result):
    canonical=json.dumps(result,sort_keys=True,indent=2)+'\n';p=HERE9/name
    if '--write' in sys.argv:p.write_text(canonical)
    else:assert p.read_text()==canonical,name
