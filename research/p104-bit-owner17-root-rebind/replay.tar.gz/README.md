# P104 owner-17 input rebind: complete logical control

This binary word implements all 680 native output rows and all 680 literal-adjoint rows. It is **not admissible in the pinned paired caller**, and it does not establish a finite application, owned erasure, or a new κ bound. The pinned source word has gzip SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

## Word and native operator

Move public owner 17's input from chart 19 to chart 0 while leaving its output at chart 1. Insert a grade-1 0→19 packet carrying `e17` immediately before native packet 785. Preserve packet 1583's original 0→182 incidence and row `e549`. At chart 19, use the new packet in place of the former local owner 17.

Retarget 3409 from 421→19 to 421→0 and remove its original 789 donor, preserving the independent owner 679 at chart 421. Delete 3410. Each of the 63 surviving native readers of 3410 uses the new 3409 value plus the now-local `e17`. The resulting combined scalar equals native `X3410` exactly. The added packet occurs before native 785; all other retained MOVEs preserve their native relative order. Original native clocks name reference points only: the emitted primitive instruction indices differ after recompilation.

The literal tape returns the exact 680-row native operator and its literal transpose. Every retained old paid packet row other than retargeted 3409 is exact; all 63 former 3410 reader rows are exact. Owner 411, owner 679 and packet 3553 remain exact. The emitted word gzip SHA-256 is `02c0c7c0c0be4875a9e2265ba4c37559648035304f3fe95cb6b9a8932439640b`. Owned retirement is dirty in 3554 fields in each orientation, and physical erasure is not proven.

## Existing-receipt capacity gate

Without the new contact, chart 19 initially retains only `e679`. Its existing prior incoming packets 781–784 are four grade-1 scalar receipts from chart 0, and retargeted 3409 no longer returns to chart 19. Even if all four earlier receipts are arbitrary deterministic functions and all local processing is free, the five inputs to this chart carry at most five bits. Yet the five exact old outgoing packet rows `X785`–`X789` and the required final local owner `e671` are six independent input rows. Thus those fixed five outgoing values and the local owner cannot all be preserved using only the existing four receipts. This counting gate even allows nonlinear encodings; it does not cover changed outgoing values or additional/retargeted incidences.

The sixth obligation matters: packet 784 is unused by paid senders but participates in the final owner-671 decoder. The bound is sharp for the five outgoing rows alone: encode the old `X785`–`X788` directly in 781–784 and retain `X789=e679`; then the independent `e671` direction is unavailable. See `no-extra-gate.json`.

## Native counts and hypothetical price

The native paid grade histogram changes from `{1:1376,2:1281,3:54,4:44,5:17,6:102}` to `{1:1376,2:1281,3:54,4:44,5:16,6:103}`, each with 2874 paid MOVEs. Thus the actual native paid delta is `−H(5)+H(6)`, where `H(g)=g^(1−κ)`. Across all 680 native ownership pairs the productive grade histogram changes from 222 to 221 at grade 7, and from 389 to 390 at grade 8. This is a real **native** grade-7→8 change for owner 17.

If the old 36-call caller were hypothetically credited with that native target-grade change on each call, the formal change from the incumbent 36-call binary margin would be

```
36 * [(H(8)-H(7)) - (H(6)-H(5))].
```

This is strictly negative for `0<κ<1` by concavity. The directed-interval value at κ = 0.00388 is approximately `−0.04293287138074159`, giving a hypothetical binary margin `−0.07064423157095918`. At κ = 0.003889928046155 the corresponding hypothetical margin is approximately `−3.894233311604945`. The unchanged 48-call rational fixture margins are approximately `+0.138974522334253` and `−9.972939199998306` respectively. Exact interval endpoints, complete mechanical paid and old target counts, and other trial rates are in `result.json`.

**This is a hypothetical tariff, not an actual changed-caller invoice.** Owner 17 is one of the 111 paired main ports, not an independent native helper. The pinned 36-call invoice charges native helper targets for owners 222+ and separately charges outer caller targets; it does not count each native main-port grade-7→8 change as an independent productive target. More fundamentally, the paired caller's port-17 head previously started in one-dimensional chart 19 and complemented the seven-dimensional body at owner 128's chart 542. After the rebind the head starts at zero-dimensional chart 0; the pinned `main_contacts` check fails with `contact dimensions at 17`. No replacement outer geometry, product embedding, or complete changed-caller accounting has been constructed. Mechanical repricing against the old caller's target counts is retained only as an arithmetic control.

## Reproduce

Python 3.11 or later, assertions enabled:

```sh
sha256sum -c SHA256SUMS
python3 -I -B build.py
python3 -I -B no_extra_gate.py
sha256sum -c SHA256SUMS
```

The bundled input source and every dependency appear individually in the manifest. The scripts overwrite their local receipts and logical word only.
