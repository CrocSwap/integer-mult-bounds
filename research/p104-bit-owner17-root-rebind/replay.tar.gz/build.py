#!/usr/bin/env python3
"""Logical owner17 initial-chart rebind; caller port is deliberately NOT assumed admissible."""
from pathlib import Path
import sys,json,gzip,hashlib
from collections import Counter,defaultdict
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from core import *
import bit_native

initial=dict(enumerate(W['start']));final=dict(enumerate(W['final']));assert initial[17]==19 and final[17]==1
initial[17]=0
M=dict(R);r=dict(ROWS);q=max(R)+1;assert q==3554
M[q]=(0,19);r[q]=1<<17
M[3409]=(421,0);r[3409]^=1<<789;del M[3410],r[3410]
for k,v in list(r.items()):
 if k in M and M[k][0]==19 and v>>17&1:r[k]^=(1<<17)^(1<<q)
 if v>>3410&1:
  assert k in M and M[k][0]==0
  r[k]^=(1<<3410)^(1<<3409)^(1<<17)
readers=[p for p in O if ROWS[p]>>3410&1];assert len(readers)==63
seq=[]
for p in O:
 if p==3410:continue
 if p==785:seq.append(q)
 seq.append(p)
vals={i:1<<i for i in range(680)};bank=defaultdict(list)
for i,c in initial.items():bank[c].append(i)
for p in seq:
 assert all(j in bank[M[p][0]] for j in labels(r[p])),(p,M[p],list(labels(r[p])))
 vals[p]=xsum(vals[j] for j in labels(r[p]));bank[M[p][1]].append(p)
assert vals[q]==1<<17
assert all(vals[p]==X[p] for p in O if p not in (3409,3410))
assert vals[3409]^(1<<17)==X[3410]
assert M[3553]==R[3553] and r[3553]==ROWS[3553] and vals[3553]==X[3553]
word=bit_native.emit_word(W,initial,final,M,r,seq)
traces=[op.run_tape(word,ATLAS,v) for v in (False,True)]
bad=[[i for i,(a,b) in enumerate(zip(t.output,op.expected_operator(rev))) if a!=b] for rev,t in zip((False,True),traces)]
assert not any(bad)
assert all(t.output[679]==1<<679 and t.output[411]==1<<411 for t in traces)
hist=Counter(v.grade for v in traces[0].packets.values());hist_adj=Counter(v.grade for v in traces[1].packets.values());assert hist==hist_adj
_,caller,_,basehist,helpers,basepaid,baseT,rat=prices.baseline()
assert hist==Counter({1:1376,2:1281,3:54,4:44,5:16,6:103})
assert basehist==Counter({1:1376,2:1281,3:54,4:44,5:17,6:102})
paid,unchangedT=prices.literal.paired_invoice(caller,hist,helpers,Counter(e[0] for e in caller['events']));assert unchangedT==baseT
orig=Counter(ATLAS.grade(W['start'][i],W['final'][i]) for i in range(680))
new=Counter(ATLAS.grade(initial[i],final[i]) for i in range(680))
assert new-orig==Counter({8:1}) and orig-new==Counter({7:1})
try:ATLAS.main_contacts(word['start'],word['final'])
except Exception as e:failure=str(e)
else:raise AssertionError('changed main-port head unexpectedly admissible')
assert ATLAS.main_contacts(W['start'],W['final'])==111
rates=['0.003879928046156','0.00388','0.003889928046155']
# The old paired invoice excludes the main-port targets inside native LOCALs.
# The extra term below is an explicitly hypothetical 36-fold native grade
# 7->8 credit, not a changed-caller target accounting.
mech={};hyp={};deltas={};ratm={};rpaid={int(k):v for k,v in rat['signed']['paid'].items()};rt={int(k):v for k,v in rat['signed']['productive'].items()}
for rate in rates:
 k=prices.D(rate);me=prices.moment(paid,unchangedT,k)
 credit=prices.scale(prices.minus(prices.power(8,k),prices.power(7,k)),36)
 before=prices.moment(basepaid,baseT,k)
 mech[rate]=prices.display(me);hyp[rate]=prices.display(prices.plus(me,credit));deltas[rate]=prices.display(prices.minus(prices.plus(me,credit),before));ratm[rate]=prices.display(prices.moment(rpaid,rt,k))
 assert prices.plus(me,credit)[1]<before[0], 'formal grade-swap change must be negative'
raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode();gz=gzip.compress(raw,mtime=0);(P/'productive17-word.json.gz').write_bytes(gz)
out=dict(source_sha256='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',word_sha256=hashlib.sha256(gz).hexdigest(),initial_chart_change=dict(owner=17,old=19,new=0,final=1),new_receipt=dict(label=q,source=0,destination=19,grade=1,row=[17],order='immediately before native785@374'),retarget_3409=dict(source=421,destination=0,exclude=[789],old3410_removed=True),all_63_paid_reader_rows_restored=all(vals[p]==X[p] for p in readers),all_other_old_packet_rows_exact=True,forward_errors=bad[0],literal_adjoint_errors=bad[1],owner411_exact_both=True,owner679_exact_both=True,packet3553_exact=True,dirty=[t.dirty for t in traces],original_native_paid_histogram=dict(basehist),new_native_paid_histogram=dict(hist),original_all_native_productive_histogram=dict(orig),new_all_native_productive_histogram=dict(new),new_pinned_mechanical_caller_paid=dict(paid),pinned_caller_productive_unchanged=dict(unchangedT),formal_mechanical_margin_without_rebound_outer_targets=mech,formal_optimistic_36fold_grade7_to8_margin=hyp,formal_optimistic_36fold_grade7_to8_change_from_old=deltas,unchanged_rational_48_margin=ratm,caller_admissible=False,caller_rejection=failure,caller_qualification='Owner17 is main port 17, not an independent native helper. Original paired_invoice charges helper targets 222+ and outer caller diagonal targets; it does not charge the 222 main-port targets independently for each native call. start[17]=0 has a zero-dimensional head, violating the pinned main_contacts and no changed-caller composition has been constructed. The 36-fold 7->8 credit is an explicit hypothetical native-price scenario only, not an exact changed-caller invoice.',qualification='Logical binary word fully preserves 680x680 operator and adjoint. Erasure, changed main-port physical/caller embedding and finite application remain open; no new kappa bound.')
(P/'result.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('native_forward_bad',len(bad[0]),'literal_adjoint_bad',len(bad[1]),'paid',dict(hist),'main port failure',repr(failure))
for k in rates:print(k,'mechanical old T',mech[k][0],'formal optimistic grade shift',hyp[k][0],'delta',deltas[k][0],'rational',ratm[k][0])
