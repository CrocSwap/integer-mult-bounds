#!/usr/bin/env python3
"""Information cut for moved owner17 without extra 0->19 receipt."""
from pathlib import Path
import json,sys
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));from core import *
assert W['start'][17]==19 and W['start'][679]==19 and W['start'][671]==0 and W['final'][671]==19
stock_initial=[i for i,c in enumerate(W['start']) if c==19 and i!=17];assert stock_initial==[679]
arr=[p for p in O if R[p][1]==19 and p!=3409];assert arr==[781,782,783,784]
assert all(R[p][0]==0 and G[p]==1 and CLOCK[p]<CLOCK[785] for p in arr)
old_exports=[785,786,787,788,789];demands=[X[p] for p in old_exports]+[1<<671]
b=Span()
for x in demands:b.add(x)
assert len(b.rows)==6
b2=Span()
for x in demands[:-1]:b2.add(x)
assert len(b2.rows)==5 and b2.express(1<<671) is None
assert all(W['start'][i]==0 for i in [265,266,267,671])
# Sharp 5-demand demonstration: replace each of four receipts by these
# four old native outgoing rows, available from original root-zero inputs.
new_receipt_rows={781:[17,266,267],782:[17,265],783:[17,266],784:[17,267]}
for p,sender in zip(arr,old_exports[:4]):assert xsum(1<<i for i in new_receipt_rows[p])==X[sender]
assert X[789]==1<<679
out=dict(initial_chart19_after_move=stock_initial,existing_chart0_to19_receipts=arr,receipt_clocks=[CLOCK[p] for p in arr],input_stock_upper_bound_bits=5,old_export_labels=old_exports,required_local_owner=671,demand_supports=[list(labels(x)) for x in demands],demand_rank=6,receipt_only_export_rank=5,sharp_five_demand_control=new_receipt_rows,qualification='Moved owner17, retargeted3409 no longer enters chart19, four existing scalar receipts only; arbitrary deterministic recoding including nonlinear is allowed, but old 785..789 full values and owner671 must be preserved. No exclusion for altered outgoing values, a new receipt, or other incidences.')
(P/'no-extra-gate.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS 4 old incoming scalar slots + owner679 <=5 bits; five old outgoing rows plus local owner671 rank6; 5-output control realizable')
