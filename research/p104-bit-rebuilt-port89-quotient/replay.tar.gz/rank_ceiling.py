#!/usr/bin/env python3
"""Exact ordered-dimension relaxation for the rebuilt projected quotient."""
from decimal import ROUND_CEILING,ROUND_FLOOR
from itertools import product
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import rebuild as R
import hull as H

SCALE=10**28

def weights(rate):
 low=[];high=[]
 for i in range(128):
  a,b=H.prices.power(i,rate)
  low.append(int(H.prices.LO.multiply(a,SCALE).to_integral_value(rounding=ROUND_FLOOR)))
  high.append(int(H.prices.HI.multiply(b,SCALE).to_integral_value(rounding=ROUND_CEILING)))
 return low,high

def main():
 g=R.Graph();scores={str(k):0 for k in H.prices.RATES};choices={str(k):[] for k in H.prices.RATES}
 ww={str(k):weights(k) for k in H.prices.RATES};tried=valid=0
 for comp in g.free_components:
  s=set(comp);edges=[(a,b,m,g.dim[b]-g.dim[a]) for (a,b),m in g.groups.items() if a in s or b in s]
  # Keep every incidence even if its combined paid/target coefficient is 0.
  assert all(not(a in g.free and b in g.free) or (a in s and b in s) for a,b,m,z in edges)
  best={str(k):None for k in H.prices.RATES};bestv={}
  for values in product(*(range(len(g.lower[i]),len(g.upper[i])+1) for i in comp)):
   tried+=1;d=dict(zip(comp,values));terms=[]
   for a,b,m,old in edges:
    new=d.get(b,g.dim[b])-d.get(a,g.dim[a])
    if new<0:break
    assert new<=8
    terms.append((m,old,new))
   else:
    valid+=1
    for k in H.prices.RATES:
     lo,hi=ww[str(k)]
     z=sum(m*(hi[old]-lo[new] if m>0 else lo[old]-hi[new]) for m,old,new in terms if m)
     if best[str(k)] is None or z>best[str(k)]:best[str(k)]=z;bestv[str(k)]=values
  for k in H.prices.RATES:
   assert best[str(k)] is not None
   scores[str(k)]+=best[str(k)]
   choices[str(k)].append({'components':comp,'ranks':list(bestv[str(k)]),'upper_units':str(best[str(k)])})
 rates={}
 for k in H.prices.RATES:
  lo,hi=ww[str(k)];base=sum(c*(hi[i] if c>0 else lo[i]) for i,c in g.basehist.items())
  geom=36*scores[str(k)];full=base+geom
  rates[str(k)]={'base_upper':str(H.prices.HI.divide(H.prices.D(base),H.prices.D(SCALE))),
   'geometry_upper':str(H.prices.HI.divide(H.prices.D(geom),H.prices.D(SCALE))),
   'complete_upper':str(H.prices.HI.divide(H.prices.D(full),H.prices.D(SCALE))),
   'positive_upper':full>0,'upper_units':str(full),'rank_assignment':choices[str(k)]}
  if full>0:print('POSITIVE_RANK_UPPER',str(k),rates[str(k)]['complete_upper'],file=sys.stderr,flush=True)
 print(json.dumps({'status':'DIMENSION_RELAXATION_ONLY','scope':'Fixed projected 677-owner packet DAG, original surviving paid/target incidence directions and exact retained main/tree anchors. Rank windows are necessary but not sufficient rational geometry.',
  'scale':SCALE,'tested':tried,'order_compatible':valid,'rates':rates},indent=2,sort_keys=True))

if __name__=='__main__':main()
