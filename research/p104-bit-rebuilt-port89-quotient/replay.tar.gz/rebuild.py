#!/usr/bin/env python3
"""Rebuild the 677-owner packet DAG and its cochart graph from live forms."""
from collections import Counter,defaultdict,deque
from hashlib import sha256
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import hull as H
import port_cut as P

PORT=89
GONE={89,200,660}
TREE={(509,0),(390,509),(517,390)}

class Union:
 def __init__(self):self.p={}
 def root(self,x):
  z=self.p.setdefault(x,x)
  if z!=x:self.p[x]=self.root(z)
  return self.p[x]
 def join(self,x,y):
  a,b=self.root(x),self.root(y)
  if a!=b:self.p[max(a,b)]=min(a,b)

def quotient(inputs,routes,forms):
 d=Union()
 for j in inputs:d.root((j,'in'));d.root((~j,'out'))
 for k in routes:d.root((k,'out'));d.root((k,'in'))
 for k,form in forms.items():
  assert k in routes or (k<0 and ~k in inputs)
  for j in P.labels(form):
   assert j in inputs or j in routes,(k,j)
   d.join((j,'in'),(k,'out'))
 roots=sorted({d.root(v) for v in d.p});ids={r:i for i,r in enumerate(roots)}
 return d,roots,{v:ids[d.root(v)] for v in d.p}

def replay(inputs,routes,forms,adjoint=False):
 if adjoint:
  routes,forms=P.physical.dual(680,routes,forms)
  order=[k for k in P.O[::-1] if k in routes]
 else:order=[k for k in P.O if k in routes]
 values={j:1<<j for j in inputs}
 for k in order:
  v=0
  for j in P.labels(forms[k]):
   assert j in values,(adjoint,k,j)
   v^=values[j]
  values[k]=v
 outputs={}
 for j in inputs:
  v=0
  for x in P.labels(forms[~j]):v^=values[x]
  expect=1<<j
  if adjoint and j<111 and j+111 in inputs:expect^=1<<(j+111)
  if not adjoint and 111<=j<222 and j-111 in inputs:expect^=1<<(j-111)
  assert v==expect,(adjoint,j)
  outputs[j]=v
 return outputs,values

class Graph:
 def __init__(self):
  previous=json.loads((ROOT/'PREVIOUS.json').read_text());rec=previous['port89_helper660']
  self.holes=set(rec['projected_zero_paid_packet_ids']);assert self.holes=={1195,1197,1199,1470,1486,3295,3522,3523}
  _,_,_,legacy=P.projection([PORT],[660]);assert self.holes==legacy
  self.inputs=set(range(680))-GONE;self.routes={k:v for k,v in P.R.items() if k not in self.holes}
  removed=sum(1<<j for j in GONE|self.holes)
  self.forms={k:(v&~removed) for k,v in P.ROWS.items() if k in self.routes or (k<0 and ~k in self.inputs)}
  assert len(self.inputs)==677 and len(self.routes)==2866 and len(self.forms)==2866+677
  assert set(previous['protected_tree_packet_ids'])<=set(self.routes)
  f,fvals=replay(self.inputs,self.routes,self.forms)
  a,avals=replay(self.inputs,self.routes,self.forms,True)
  assert all(((f[i]>>j)&1)==((a[j]>>i)&1) for i in self.inputs for j in self.inputs)
  assert all(fvals[k] and avals[k] for k in self.routes if k not in previous['protected_tree_packet_ids'])
  self.FWD=f;self.ADJ=a
  oldd,oldroots,oldmap=quotient(set(range(680)),P.R,P.ROWS)
  assert oldroots==H.nodes
  d,self.nodes,self.map=quotient(self.inputs,self.routes,self.forms)
  self.n=len(self.nodes)
  _,dualforms=P.physical.dual(680,self.routes,self.forms)
  for k,form in dualforms.items():
   target=self.map[(k,'in')] if k>=0 else self.map[(~k,'in')]
   for j in P.labels(form):
    source=self.map[(~j,'out')] if j<680 else self.map[(j,'out')]
    assert source==target,('dual cochart',k,j)
  self.old_of_new={}
  splits=defaultdict(set)
  for v,new in self.map.items():
   old=oldmap[v]
   assert self.old_of_new.setdefault(new,old)==old
   splits[old].add(new)
  self.splits={k:sorted(v) for k,v in splits.items() if len(v)>1}
  self.inowner={j:self.map[(j,'in')] for j in self.inputs}
  self.outowner={j:self.map[(~j,'out')] for j in self.inputs}
  chart={}
  def bind(node,c):
   assert chart.setdefault(node,c)==c,(node,chart[node],c)
  for j in self.inputs:
   bind(self.inowner[j],P.W['start'][j]);bind(self.outowner[j],P.W['final'][j])
  self.paid=[]
  for k,(a,b) in self.routes.items():
   x,y=self.map[(k,'out')],self.map[(k,'in')];bind(x,a);bind(y,b)
   self.paid.append((k,x,y,P.G[k]))
  self.targets=[]
  for j in sorted(self.inputs):
   if j<222:continue
   x,y=self.inowner[j],self.outowner[j];g=P.DIMS[P.W['final'][j]]-P.DIMS[P.W['start'][j]]
   assert g>0
   self.targets.append((j,x,y,g))
  assert len(chart)==self.n and len(self.targets)==457
  self.chart=[chart[i] for i in range(self.n)]
  self.old=[H.frames[c] for c in self.chart];self.dim=list(map(len,self.old))
  self.frozen=set();self.anchors=defaultdict(list)
  for j in (list(range(222))+[411]):
   if j not in self.inputs:continue
   for where,node in (('in',self.inowner[j]),('out',self.outowner[j])):
    self.frozen.add(node);self.anchors[node].append({'owner':j,'side':where})
  for k,(a,b) in self.routes.items():
   if k==3553 or (a,b) in TREE:
    for where,node in (('sender',self.map[(k,'out')]),('arrival',self.map[(k,'in')])):
     self.frozen.add(node);self.anchors[node].append({'packet':k,'route':[a,b],'side':where})
  oldf=set()
  for j in list(range(222))+[411]:
   if j in GONE:continue
   oldf.update((oldmap[(j,'in')],oldmap[(~j,'out')]))
  for k,(a,b) in P.R.items():
   if k==3553 or (a,b) in TREE:oldf.update((oldmap[(k,'out')],oldmap[(k,'in')]))
  self.anchored_splits={old:{'new_components':news,
                            'still_anchored':[n for n in news if n in self.frozen],
                            'released_by_split':[n for n in news if n not in self.frozen]}
                        for old,news in self.splits.items() if old in oldf}
  self.groups=Counter();self.neighbors=[set() for _ in range(self.n)];self.edges=[]
  for sign,ls in ((1,self.paid),(-1,self.targets)):
   for id0,x,y,g in ls:
    assert x!=y and abs(self.dim[x]-self.dim[y])==g
    lo,hi=(x,y) if self.dim[x]<self.dim[y] else (y,x)
    assert H.join(self.old[lo],self.old[hi])==self.old[hi]
    self.groups[(lo,hi)]+=sign;self.neighbors[lo].add(hi);self.neighbors[hi].add(lo)
    self.edges.append((sign,id0,lo,hi,g))
  self.order=sorted(range(self.n),key=self.dim.__getitem__)
  self.lower=[self.old[i] if i in self.frozen else H.zero for i in range(self.n)]
  self.upper=[self.old[i] if i in self.frozen else H.full for i in range(self.n)]
  for i in self.order:
   for j in self.neighbors[i]:
    if self.dim[i]<self.dim[j]:self.lower[j]=H.join(self.lower[j],self.lower[i])
  for i in reversed(self.order):
   for j in self.neighbors[i]:
    if self.dim[j]<self.dim[i]:self.upper[j]=H.meet(self.upper[j],self.upper[i])
  assert all(H.join(self.lower[i],self.old[i])==self.old[i] and H.join(self.old[i],self.upper[i])==self.upper[i] for i in range(self.n))
  self.free={i for i in range(self.n) if self.lower[i]!=self.upper[i]}
  self.free_components=[];todo=set(self.free)
  while todo:
   i=min(todo);todo.remove(i);seen={i};q=deque([i])
   while q:
    for j in self.neighbors[q.popleft()]&todo:
     todo.remove(j);seen.add(j);q.append(j)
   self.free_components.append(sorted(seen))
  self.basehist={int(k):v for k,v in rec['base_signed_grade_histogram'].items()}
  self.prior_frozen_count=len(oldf)

 def record(self):
  from math import prod
  shapes=Counter((len(self.lower[i]),self.dim[i],len(self.upper[i])) for i in range(self.n))
  components=[{'nodes':x,'size':len(x),
      'rank_assignments':prod(len(self.upper[i])-len(self.lower[i])+1 for i in x)} for x in self.free_components]
  components.sort(key=lambda x:(-x['size'],x['nodes']))
  return {'source':{'native_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','main_context':'e54523517d0f03e58352e647c403a5af3e525a57'},
   'gone_owners':sorted(GONE),'removed_zero_packet_ids':sorted(self.holes),
   'surviving_public_owners':len(self.inputs),'surviving_paid_packets':len(self.paid),'surviving_productive_helpers':len(self.targets),
   'forward_adjoint_rows_checked_each':len(self.inputs),'explicit_transpose_coefficients_checked':len(self.inputs)**2,
   'dual_packet_and_terminal_cochart_relations_checked':True,
   'quotient_old_nodes':len(H.nodes),'quotient_new_nodes':self.n,
   'old_nodes_split':len(self.splits),'split_roster':self.splits,
   'formerly_frozen_nodes_split':len(self.anchored_splits),'anchored_split_roster':self.anchored_splits,
   'pre_rebuild_port89_frozen_nodes':self.prior_frozen_count,'post_rebuild_frozen_nodes':len(self.frozen),
   'post_rebuild_free_nodes':len(self.free),'window_dimension_census':{str(k):v for k,v in sorted(shapes.items())},
   'free_components':components,'protected_anchor_nodes':{str(k):v for k,v in sorted(self.anchors.items())},
   'base_projected_signed_grade_histogram':self.basehist}

def main():
 g=Graph();out=g.record();print(json.dumps(out,sort_keys=True,indent=2))

if __name__=='__main__':main()
