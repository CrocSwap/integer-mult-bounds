#!/usr/bin/env python3
"""Check exact rational lattice sections on the rebuilt projected quotient."""
from collections import Counter
from hashlib import sha256
from pathlib import Path
from time import monotonic
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import rebuild as R
import hull as H

def score(g,V):
 for i in g.frozen:assert V[i]==g.old[i]
 for (a,b),_ in g.groups.items():assert H.join(V[a],V[b])==V[b],('nested',a,b)
 h=Counter(g.basehist);zero_paid=[];zero_prod=[]
 for sign,id0,a,b,old in g.edges:
  new=len(V[b])-len(V[a]);assert new>=0
  h[old]+=36*sign;h[new]-=36*sign
  if new==0:(zero_paid if sign>0 else zero_prod).append(id0)
 h={x:y for x,y in sorted(h.items()) if y}
 values={}
 for k in H.prices.RATES:
  interval=H.prices.ZERO
  for grade,c in h.items():interval=H.prices.plus(interval,H.prices.scale(H.prices.power(grade,k),c))
  values[str(k)]=[str(interval[0]),str(interval[1])]
 return {'signed_grade_histogram':h,'full_deltas':values,
         'changed_components':[i for i in range(g.n) if V[i]!=g.old[i]],
         'zero_paid_ids':sorted(zero_paid),'zero_productive_owners':sorted(zero_prod)}

def main():
 g=R.Graph();limit=json.loads((ROOT/'RANK-CEILING.json').read_text());start=monotonic()
 items=[('unchanged',g.old),('lower_corner',g.lower),('upper_corner',g.upper)]
 result=[];digest=sha256()
 def evaluate(label,V):
  r=score(g,V);r['section']=label
  for k in H.prices.RATES:
   assert H.prices.D(r['full_deltas'][str(k)][1])<=H.prices.D(limit['rates'][str(k)]['complete_upper'])
   if H.prices.D(r['full_deltas'][str(k)][0])>0:
    print('POSITIVE_RATIONAL_GEOMETRY',label,k,r['full_deltas'][str(k)],file=sys.stderr,flush=True)
  digest.update(json.dumps(r,sort_keys=True,separators=(',',':')).encode()+b'\n');result.append(r)
 for label,V in items:evaluate(label,V)
 for i,(c,J) in enumerate(sorted(H.frames.items())):
  V=[H.join(g.lower[j],H.meet(g.upper[j],J)) if j in g.free else g.old[j] for j in range(g.n)]
  evaluate('frame:'+str(c),V)
  if i%100==99:print('sections',i+1,'seconds',round(monotonic()-start,2),file=sys.stderr,flush=True)
 rates={}
 for k in H.prices.RATES:
  best=max(result,key=lambda a:H.prices.D(a['full_deltas'][str(k)][1]))
  rates[str(k)]={'best_section':best['section'],'delta':best['full_deltas'][str(k)],
                 'positive':H.prices.D(best['full_deltas'][str(k)][0])>0}
 print(json.dumps({'status':'FINITE_EXACT_RATIONAL_SECTIONS',
  'scope':'Unchanged state, lattice lower/upper corners, and one section per original chart; surviving 677-owner packet graph and original incidence directions fixed.',
  'count':len(result),'digest_sha256':digest.hexdigest(),'rates':rates,'sections':result},sort_keys=True,indent=2))

if __name__=='__main__':main()
