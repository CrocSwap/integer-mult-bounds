#!/usr/bin/env python3
"""Optimize all rational subspaces on the small rebuilt free components.

Every component is either one node, two nodes with one directed edge, or
four nodes each having a one-rank L/U interval.  Single nodes are realized
by basis extension; for two nodes A subset B, the greedy A first maximizes
its intersection with B's required lower subspace.  Four-node ranks force
the unique L or U at each node.  Thus the feasibility test is exhaustive
over rational subspaces, not just the atlas section list.
"""
from collections import Counter
from itertools import product
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import rebuild as R
import rank_ceiling as RC
import corners
import hull as H

def subset(a,b):return H.join(a,b)==b

def extend(base,upper,target,first=()):
 if not subset(base,upper) or not len(base)<=target<=len(upper):return None
 cur=base
 for row in tuple(first)+tuple(upper):
  if len(cur)==target:break
  z=H.join(cur,(row,))
  if len(z)>len(cur):cur=z
 assert len(cur)==target and subset(cur,upper)
 return cur

def realize(g,nodes,ranks):
 d=dict(zip(nodes,ranks))
 if len(nodes)==1:
  i=nodes[0];v=extend(g.lower[i],g.upper[i],d[i]);return None if v is None else {i:v}
 if len(nodes)==2:
  pairs=[(a,b) for a,b in g.groups if a in d and b in d]
  assert len(pairs)==1
  a,b=pairs[0]
  if d[a]>d[b]:return None
  # A must lie in U_A ∩ U_B.  Insert (U_A ∩ U_B) ∩ L_B first;
  # this maximizes dim(A∩L_B), hence minimizes dim(A+L_B).
  domain=H.meet(g.upper[a],g.upper[b])
  prefer=H.meet(domain,g.lower[b])
  A=extend(g.lower[a],domain,d[a],prefer)
  if A is None:return None
  seed=H.join(g.lower[b],A)
  B=extend(seed,g.upper[b],d[b])
  if B is None:return None
  assert subset(A,B)
  return {a:A,b:B}
 assert all(len(g.upper[i])-len(g.lower[i])==1 for i in nodes)
 result={}
 for i in nodes:
  if d[i]==len(g.lower[i]):result[i]=g.lower[i]
  elif d[i]==len(g.upper[i]):result[i]=g.upper[i]
  else:raise AssertionError('one-rank window')
 for (a,b),_ in g.groups.items():
  if a in d and b in d and not subset(result[a],result[b]):return None
 return result

def main():
 g=R.Graph();ww={str(k):RC.weights(k) for k in H.prices.RATES}
 best={str(k):0 for k in H.prices.RATES};selected={str(k):{} for k in H.prices.RATES}
 trials=feasible=0;components=[]
 for comp in g.free_components:
  s=set(comp);inc=[(a,b,m,g.dim[b]-g.dim[a]) for (a,b),m in g.groups.items() if a in s or b in s]
  bestc={str(k):None for k in H.prices.RATES};basis={};nr=nf=0
  for ranks in product(*(range(len(g.lower[i]),len(g.upper[i])+1) for i in comp)):
   nr+=1;trials+=1;assignment=realize(g,comp,ranks)
   if assignment is None:continue
   nf+=1;feasible+=1;d={i:len(v) for i,v in assignment.items()};terms=[]
   for a,b,m,old in inc:
    new=d.get(b,g.dim[b])-d.get(a,g.dim[a]);assert new>=0
    if m:terms.append((m,old,new))
   for k in H.prices.RATES:
    lo,hi=ww[str(k)]
    upper=sum(m*(hi[old]-lo[new] if m>0 else lo[old]-hi[new]) for m,old,new in terms)
    if bestc[str(k)] is None or upper>bestc[str(k)]:bestc[str(k)]=upper;basis[str(k)]=assignment
  assert all(v is not None for v in bestc.values())
  for k in H.prices.RATES:
   best[str(k)]+=bestc[str(k)];selected[str(k)].update(basis[str(k)])
  components.append({'nodes':comp,'rank_assignments':nr,'rationally_feasible_rank_assignments':nf,
                     'best_geometry_units_per_rate':{str(k):str(bestc[str(k)]) for k in H.prices.RATES}})
 rates={};witnesses={}
 for k in H.prices.RATES:
  lo,hi=ww[str(k)];base=sum(c*(hi[i] if c>0 else lo[i]) for i,c in g.basehist.items())
  cap=base+36*best[str(k)]
  V=[selected[str(k)].get(i,g.old[i]) for i in range(g.n)]
  att=corners.score(g,V)
  upper=H.prices.HI.divide(H.prices.D(cap),H.prices.D(RC.SCALE))
  assert H.prices.D(att['full_deltas'][str(k)][1])<=upper
  ranklimit=H.prices.D(json.loads((ROOT/'RANK-CEILING.json').read_text())['rates'][str(k)]['complete_upper'])
  assert upper<=ranklimit
  rates[str(k)]={'complete_upper':str(upper),'attained_delta':att['full_deltas'][str(k)],
                  'positive':H.prices.D(att['full_deltas'][str(k)][0])>0,
                  'upper_units':str(cap),'witness':att}
  witnesses[str(k)]=[{'component':i,'original_chart':g.chart[i],
                       'basis':[list(row) for row in V[i]]}
                      for i in range(g.n) if V[i]!=g.old[i]]
  if rates[str(k)]['positive']:
   print('POSITIVE_EXACT_GEOMETRY',k,rates[str(k)]['attained_delta'],file=sys.stderr,flush=True)
 print(json.dumps({'status':'EXHAUSTIVE_RATIONAL_SUBSPACE_PRICE','scope':'Rebuilt port89/helper660 packet graph; every original surviving packet incidence and nesting direction fixed, exact original remaining main/411/tree anchors, rational subspaces of Q^8, all zero grades priced.',
  'rank_assignments':trials,'rationally_feasible_rank_assignments':feasible,'components':components,
  'rates':rates,'rational_changed_node_bases':witnesses},indent=2,sort_keys=True))

if __name__=='__main__':main()
