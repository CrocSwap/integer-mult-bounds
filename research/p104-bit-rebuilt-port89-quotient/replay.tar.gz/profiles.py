#!/usr/bin/env python3
"""Recount unsigned paid/productive bills for both rational frame witnesses."""
from collections import Counter
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import rebuild as R
import corners
import hull as H

def main():
 g=R.Graph();result=json.loads((ROOT/'EXACT-GEOMETRY.json').read_text())
 _,_,_,_,_,oldP,oldT,rat=H.prices.baseline();out={}
 for k in H.prices.RATES:
  V=list(g.old)
  for row in result['rational_changed_node_bases'][str(k)]:
   V[row['component']]=H.rref(tuple(tuple(x) for x in row['basis']))
  paid=Counter();target=Counter()
  for _,a,b,_ in g.paid:paid[abs(len(V[a])-len(V[b]))]+=1
  for _,a,b,_ in g.targets:target[abs(len(V[a])-len(V[b]))]+=1
  assert sum(paid.values())==2866 and sum(target.values())==457
  pp=Counter({grade:count*36 for grade,count in paid.items()})
  tt=Counter({grade:count*36 for grade,count in target.items()})
  # The retained 110 ports each keep the original 4 queries, 32 idles,
  # and 38 productive root masks. No extra caller substitute is granted.
  pp[1]+=4*110
  for i in range(1,9):pp[7*i]+=4*110
  tt[127]+=2*110
  for i in range(1,10):tt[1+7*i]+=4*110
  delta=Counter()
  for grade,count in tt.items():delta[grade]+=count
  for grade,count in pp.items():delta[grade]-=count
  for grade,count in oldT.items():delta[grade]-=count
  for grade,count in oldP.items():delta[grade]+=count
  delta={grade:count for grade,count in sorted(delta.items()) if count}
  expected={int(grade):count for grade,count in corners.score(g,V)['signed_grade_histogram'].items()}
  assert delta==expected
  bm=H.prices.moment(pp,tt,k);base=H.prices.moment(oldP,oldT,k)
  gain=H.prices.minus(bm,base);previous=result['rates'][str(k)]['attained_delta']
  assert H.prices.D(previous[0])<=gain[1] and gain[0]<=H.prices.D(previous[1])
  out[str(k)]={'native_paid_one_call':dict(sorted(paid.items())),
    'native_productive_one_call':dict(sorted(target.items())),
    'complete_paid_36_calls_110_caller_ports':dict(sorted(pp.items())),
    'complete_productive_36_calls_110_caller_ports':dict(sorted(tt.items())),
    'signed_grade_delta':delta,'bit_margin':H.prices.display(bm),'signed_delta':H.prices.display(gain),
    'fixed_rational_48_call':H.prices.display(H.prices.moment(rat['signed']['paid'],rat['signed']['productive'],k))}
 print(json.dumps({'status':'UNSIGNED_AND_SIGNED_FRAME_PRICE','scope':result['scope'],
   'native_calls':36,'retained_caller_ports':110,'rates':out},indent=2,sort_keys=True))

if __name__=='__main__':main()
