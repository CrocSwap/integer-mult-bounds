# Rebuilt quotient after releasing port 89 and helper 660

Rebuilding the projected packet graph exposes three additional cochart
components, but **no positive rational-geometry profile** in the model
below. The best complete signed change is bounded above by
`−23.0322808346426471951337565666` at κ `0.003879928046156`, and by
`−23.032278030465884383512308756` at `0.003879929046155`. Explicit
rational frame assignments attain values within `5×10⁻²⁵` of those
outward ceilings. No new κ result follows.

The native source is #7830 head
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; canonical main context is
`e54523517d0f03e58352e647c403a5af3e525a57`. The projection is the exact
port-89/helper-660 case in the previous released-port receipt: remove
owners `89, 200, 660`, their terminal equations, and the eight zero
packets `1195, 1197, 1199, 1470, 1486, 3295, 3522, 3523`.

## Rebuild and anchors

`rebuild.py` removes those labels from each surviving packet and terminal
form and constructs new cochart unions from the remaining terms. It does
not carry forward the old disjoint-set unions. The original quotient has
656 nodes; the rebuilt graph has **659**. Exactly two old components split:
old node 58 becomes new nodes 651, 652 and 653; old node 229 becomes 442
and 658. Both old nodes were anchored only by the removed port. No node
anchored by a surviving main port, owner 411 or the retained tree splits.
There are **227** frozen components and **61** nontrivial subspace windows,
versus 58 windows before rebuilding.

The resulting graph has 677 public owners, 2,866 paid packets and 457
productive helpers. Its 677 forward rows and 677 adjoint rows match the
original surviving operator, and all 458,329 transpose coefficients and
the dual cochart relations are checked. The other 110 main ports, owner
411, and the protected tree packet endpoints stay on their original
frames. The exact packet forms and their surviving native routes remain
fixed throughout the subsequent optimization.

## Exhaustive rational subspace screen

For each node, exact rational joins and intersections of the remaining
anchors and surviving nested incidences supply `L ⊆ V ⊆ U`. The free-node
graph has eight four-node components, thirteen two-node components and
three singletons. The four-node components have a one-rank interval at
every node, so each chosen rank forces that node to be exactly `L` or `U`.
For one node any intermediate rational rank is realized by extending a
basis of `L` inside `U`.

For a directed two-node edge `A ⊆ B`, let `W=U_A ∩ U_B` and
`T=W ∩ L_B`. A feasible `A` must lie between `L_A` and `W`. To test
given dimensions `p,q`, extend a basis of `L_A` by vectors of `T` first,
then by vectors of `W`. This maximizes `dim(A ∩ L_B)` and therefore
minimizes `dim(A+L_B)`. A rational `B` of dimension `q` exists exactly
when that minimum union fits inside `U_B` at rank at most `q`. The
independent audit checks this construction against the corresponding
dimension criterion for every pair.

The finite enumeration covers **893** rank assignments, of which **509**
are realizable by rational subspaces. Each component is independent after
the retained anchors are fixed, so summing its individually optimized
signed price gives the global ceiling in this model. `EXACT-GEOMETRY.json`
contains the component receipts and 29 changed rational bases for each
trial. The separate `audit.py` reconstructs the 659-node quotient by graph
search, checks the rational feasibility criterion, independently reprices
paid and productive incidences, and checks 94 exact rational projector
edge relations across the two trial witnesses. It agrees with the bound.

As a simpler control, `corners.py` checks 639 exact rational placements:
the unchanged placement, the lower and upper corners, and one section per
original chart. Their best first-trial change is `−24.2660407911044`,
inferior to the exhaustive rational optimum above. The earlier rank-only
ceiling of `−7.6420789376396` survives the split, but is not attained by
the rational geometry.

## Complete price and limits

The original port projection removes all 38 productive roots, 32 paid
IDLEs and four paid QUERYs for that port, and removes helper 660's grade-4
productive target. Eight zero paid packets receive their actual savings
in each of the **36** native calls. There is no free caller substitute.
The unchanged projected baseline has signed change approximately
`−26.52707431087515`; the best rational rechart repairs roughly `+3.49479`
of that loss.

For the best first-trial frame assignment, the unsigned native one-call
paid bins by grade are `{0:20, 1:1367, 2:1249, 3:70, 4:42, 5:17,
6:100, 7:1}`. The productive helper bins are `{0:9, 1:8, 2:1, 4:41,
5:8, 6:1, 8:389}`. Grade-zero productive returns lose productive credit;
they are not counted as extra paid savings. `PROFILES.json` contains all
36-call and 110-port unsigned bins, signed differences, the unchanged
48-call rational companion, and directed margins at both rates. The
resulting first-trial BIT margin is approximately `−23.03228083540965`;
the rational companion remains approximately `+0.212262470163347`.

The frame witness is a rational-subspace assignment for the fixed packet
graph, not a physically compiled word. The model fixes surviving packet
forms, their paid/target incidences and their original nesting directions.
Changed payloads, routes, additional packet or owner deletions, a different
caller substitution or reversed nesting require new analysis. Physical
field lifetimes, clean erasure, graded operations, finite precision,
stock, compiler and analytic recovery remain open.

## Reproduce

Run CPython with assertions, in this directory:

```sh
(cd source && sha256sum -c SHA256SUMS)
python3 -I -B rebuild.py > GRAPH.check.json
cmp GRAPH.json GRAPH.check.json
python3 -I -B rank_ceiling.py > RANK-CEILING.check.json
cmp RANK-CEILING.json RANK-CEILING.check.json
python3 -I -B corners.py > CORNERS.check.json
cmp CORNERS.json CORNERS.check.json
python3 -I -B geometry_exact.py > EXACT-GEOMETRY.check.json
cmp EXACT-GEOMETRY.json EXACT-GEOMETRY.check.json
python3 -I -B profiles.py > PROFILES.check.json
cmp PROFILES.json PROFILES.check.json
python3 -I -B audit.py > AUDIT.check.json
cmp AUDIT.json AUDIT.check.json
```

The source package retains the Apache license, source pins and prior
notices; the prior ninth-axis notice and license are retained in `vendor/`.
`COLD-REPLAY.json` records a separate-copy replay.
