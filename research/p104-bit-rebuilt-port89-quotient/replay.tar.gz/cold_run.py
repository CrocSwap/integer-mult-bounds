#!/usr/bin/env python3
"""Reproduce the rebuilt graph, exact geometry and audit in a fresh copy."""
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
import json,shutil,subprocess,sys,time
R=Path(__file__).resolve().parent;C=R/'cold'
if C.exists():shutil.rmtree(C)
C.mkdir()
for d in ('source','vendor'):shutil.copytree(R/d,C/d,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for f in ('PREVIOUS.json','rebuild.py','rank_ceiling.py','corners.py','geometry_exact.py','profiles.py','audit.py','RANK-CEILING.json','EXACT-GEOMETRY.json'):
 shutil.copy2(R/f,C/f)
record=[]
def run(cwd,args,expected=None):
 t=time.monotonic();p=subprocess.run(args,cwd=C/cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 if expected:assert p.stdout==(R/expected).read_bytes(),expected
 record.append({'cwd':cwd,'args':args,'seconds':round(time.monotonic()-t,3),
                'stdout_sha256':sha256(p.stdout).hexdigest(),'byte_identical_to':expected,
                'stderr_progress_lines':len(p.stderr.decode().splitlines())})
run('source',['sha256sum','-c','SHA256SUMS'])
for script,expected in [('rebuild.py','GRAPH.json'),('rank_ceiling.py','RANK-CEILING.json'),
 ('corners.py','CORNERS.json'),('geometry_exact.py','EXACT-GEOMETRY.json'),
 ('profiles.py','PROFILES.json'),('audit.py','AUDIT.json')]:
 run('.',[sys.executable,'-I','-B',script],expected)
out={'status':'PASS','completed_utc':datetime.now(timezone.utc).isoformat(),'steps':record}
(R/'COLD-REPLAY.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
