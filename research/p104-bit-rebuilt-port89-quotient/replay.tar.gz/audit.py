#!/usr/bin/env python3
"""Independent BFS quotient, rank feasibility and rational-projector audit."""
from collections import Counter,defaultdict,deque
from decimal import Decimal,localcontext,ROUND_CEILING,ROUND_FLOOR
from fractions import Fraction
from functools import lru_cache
from itertools import product
from pathlib import Path
import json,sys

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'vendor')]
import rebuild as R
import geometry_exact as E
import corners
import hull as H
import port_cut as P

SCALE=10**28

def bfs_partition(g):
 adj=defaultdict(set)
 for j in g.inputs:adj[(j,'in')];adj[(~j,'out')]
 for k in g.routes:adj[(k,'in')];adj[(k,'out')]
 for k,form in g.forms.items():
  for j in P.labels(form):
   a,b=(j,'in'),(k,'out');adj[a].add(b);adj[b].add(a)
 todo=set(adj);out=[]
 while todo:
  z=next(iter(todo));todo.remove(z);group={z};q=deque([z])
  while q:
   for y in adj[q.popleft()]&todo:todo.remove(y);group.add(y);q.append(y)
  out.append(frozenset(group))
 return frozenset(out)

def rank(rows):
 a=[list(map(Fraction,r)) for r in rows];i=0
 for c in range(8):
  j=next((j for j in range(i,len(a)) if a[j][c]),None)
  if j is None:continue
  a[i],a[j]=a[j],a[i];v=a[i][c];a[i]=[x/v for x in a[i]]
  for r in range(i+1,len(a)):
   if a[r][c]:
    q=a[r][c];a[r]=[x-q*y for x,y in zip(a[r],a[i])]
  i+=1
  if i==len(a):break
 return i

@lru_cache(None)
def subset(a,b):return rank(tuple(b)+tuple(a))==len(b)

def criterion(g,nodes,values):
 ds=dict(zip(nodes,values))
 if len(nodes)==1:return True
 if len(nodes)==2:
  pairs=[(a,b) for a,b in g.groups if a in ds and b in ds];assert len(pairs)==1
  a,b=pairs[0];pa,pb=ds[a],ds[b]
  if pa>pb:return False
  w=H.meet(g.upper[a],g.upper[b]);la,lb=g.lower[a],g.lower[b]
  if not subset(la,w) or not len(la)<=pa<=len(w):return False
  p=H.meet(w,lb);d0=len(H.meet(la,lb))
  maximum_overlap=d0+min(pa-len(la),len(p)-d0)
  minimum_union=pa+len(lb)-maximum_overlap
  return minimum_union<=pb<=len(g.upper[b])
 assert all(len(g.upper[i])-len(g.lower[i])==1 for i in nodes)
 basis={i:(g.lower[i] if ds[i]==len(g.lower[i]) else g.upper[i]) for i in nodes}
 return all(subset(basis[a],basis[b]) for a,b in g.groups if a in ds and b in ds)

def inv(m):
 n=len(m);a=[list(map(Fraction,r))+[Fraction(i==j) for j in range(n)] for i,r in enumerate(m)]
 for c in range(n):
  p=next(i for i in range(c,n) if a[i][c]);a[c],a[p]=a[p],a[c]
  v=a[c][c];a[c]=[x/v for x in a[c]]
  for i in range(n):
   if i!=c and a[i][c]:
    v=a[i][c];a[i]=[x-v*y for x,y in zip(a[i],a[c])]
 return [r[n:] for r in a]

@lru_cache(None)
def projector(B):
 if not B:return tuple(tuple(Fraction(0) for _ in range(8)) for _ in range(8))
 b=[list(map(Fraction,r)) for r in B];n=len(b)
 gram=[[sum(b[i][k]*b[j][k] for k in range(8)) for j in range(n)] for i in range(n)]
 G=inv(gram)
 q=tuple(tuple(sum(b[i][r]*G[i][j]*b[j][c] for i in range(n) for j in range(n))
               for c in range(8)) for r in range(8))
 assert all(q[i][j]==q[j][i] for i in range(8) for j in range(8))
 assert all(sum(q[i][k]*q[k][j] for k in range(8))==q[i][j] for i in range(8) for j in range(8))
 return q

@lru_cache(None)
def nested_projector(a,b):
 A,B=projector(a),projector(b)
 return all(sum(A[i][k]*B[k][j] for k in range(8))==A[i][j] for i in range(8) for j in range(8))

def main():
 g=R.Graph();saved=json.loads((ROOT/'EXACT-GEOMETRY.json').read_text())
 groups=defaultdict(set)
 for v,i in g.map.items():groups[i].add(v)
 assert bfs_partition(g)==frozenset(frozenset(x) for x in groups.values())
 assert (g.n,len(g.splits),len(g.anchored_splits),len(g.inputs))==(659,2,0,677)
 _,_,_,oldholes=P.projection([89],[660]);assert oldholes==g.holes
 rates=H.prices.RATES;lohi={}
 for k in rates:
  low=[];high=[]
  for x in range(128):
   a,b=H.prices.power(x,k)
   with localcontext() as ctx:
    ctx.prec=120
    l=int((a*SCALE).to_integral_value(rounding=ROUND_FLOOR));h=int((b*SCALE).to_integral_value(rounding=ROUND_CEILING))
    val=Decimal(x) if x<=1 else ((Decimal(1)-k)*Decimal(x).ln()).exp()
    assert Decimal(l)/SCALE<=val<=Decimal(h)/SCALE
   low.append(l);high.append(h)
  lohi[str(k)]=(low,high)
 # Build per-component raw paid and target incidences independently.
 index={n:i for i,c in enumerate(g.free_components) for n in c}
 raw=[Counter() for _ in g.free_components]
 for sign,id0,a,b,grade in g.edges:
  if a not in index and b not in index:continue
  i=index[a] if a in index else index[b]
  if a in index and b in index:assert index[a]==index[b]
  raw[i][(a,b,grade,sign)]+=1
 totals={str(k):0 for k in rates};checked=feasible=0
 for idx,comp in enumerate(g.free_components):
  best={str(k):None for k in rates}
  for values in product(*(range(len(g.lower[n]),len(g.upper[n])+1) for n in comp)):
   checked+=1;good=criterion(g,comp,values);constructed=E.realize(g,comp,values)
   assert good==(constructed is not None)
   if not good:continue
   feasible+=1;dim=dict(zip(comp,values))
   for k in rates:
    lo,hi=lohi[str(k)];v=0
    for (a,b,old,sign),count in raw[idx].items():
     new=dim.get(b,g.dim[b])-dim.get(a,g.dim[a]);assert 0<=new<=8
     v+=count*((hi[old]-lo[new]) if sign==1 else (hi[new]-lo[old]))
    if best[str(k)] is None or v>best[str(k)]:best[str(k)]=v
  for k in rates:totals[str(k)]+=best[str(k)]
 assert checked==saved['rank_assignments']==893 and feasible==saved['rationally_feasible_rank_assignments']==509
 hist=Counter()
 for k in g.holes:hist[P.G[k]]+=36
 hist[P.DIMS[P.W['final'][660]]-P.DIMS[P.W['start'][660]]]-=36
 hist[1]+=4
 for i in range(1,9):hist[7*i]+=4
 hist[127]-=2
 for i in range(1,10):hist[1+7*i]-=4
 assert {k:v for k,v in hist.items() if v}==g.basehist
 summary={};projector_pairs=0
 for k in rates:
  lo,hi=lohi[str(k)];base=sum(c*(hi[z] if c>0 else lo[z]) for z,c in hist.items())
  upper=base+36*totals[str(k)];producer=int(saved['rates'][str(k)]['upper_units'])
  assert upper>=producer and upper<0
  V=list(g.old)
  for row in saved['rational_changed_node_bases'][str(k)]:
   i=row['component'];V[i]=H.rref(tuple(tuple(x) for x in row['basis']))
   assert subset(g.lower[i],V[i]) and subset(V[i],g.upper[i])
  for i in g.frozen:assert V[i]==g.old[i]
  for (a,b),_ in g.groups.items():
   assert subset(V[a],V[b])
   if V[a]!=g.old[a] or V[b]!=g.old[b]:
    assert nested_projector(V[a],V[b]);projector_pairs+=1
  assert corners.score(g,V)['full_deltas'][str(k)]==saved['rates'][str(k)]['attained_delta']
  for j in list(range(222))+[411]:
   if j not in g.inputs:continue
   assert V[g.inowner[j]]==g.old[g.inowner[j]] and V[g.outowner[j]]==g.old[g.outowner[j]]
  summary[str(k)]={'independent_raw_incidence_upper_units':str(upper),
   'producer_upper_units':str(producer),'extra_outward_slack_units':str(upper-producer),
   'witness_delta':saved['rates'][str(k)]['attained_delta']}
 print(json.dumps({'status':'PASS_REBUILT_EXACT_RATIONAL','scope':saved['scope'],
  'new_cochart_components_BFS_checked':len(groups),'projected_native_rows_each_direction':677,
  'rank_assignments':checked,'rational_feasibility_cases':feasible,
  'projector_edge_checks_across_two_rates':projector_pairs,
  'all_surviving_main_and_owner411_original_anchors':True,
  'tree_endpoint_anchors':True,'price_enclosure_ranks':128,'rates':summary},indent=2,sort_keys=True))

if __name__=='__main__':main()
