# Two overlapping k = 71 local windows

This is a **conditional, finite mask-level relaxation**, not a construction of
a caller word and not a new upper bound. It tests whether two width-8 windows,
their exact ordered CROSS and piece-sensitive cuts, and local pair saturation
alone exclude one named k = 71 type branch from [PR #7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869).
They do not: the explicitly labelled assignment below passes those tests but
violates necessary constraints elsewhere. It neither establishes nor refutes
the existence of a globally valid frame of the same types.

The pinned source for the type model and the caller facts is PR #7869 at
`06c207a9feb3994a4b987dc3010657b6e85b7956`, in
`research/p104-lowerbound-guidance/`. In particular, its `notes/scherk.md`
states CROSS and PIECE-CROSS, `notes/bilinear.md` states closure/effective
masks, and `notes/dyadrelay.md` states PIECE2-CROSS and **SUBDY**, its averaged
local-subset dyadic work. The earlier work already observes that pure and
one-big-piece medium roles survive its type-averaged local constraints. This
receipt investigates an actual placement on two specified overlapping
windows; it does not claim that local subset facts are new. The 357 averaged
rows checked here are exactly the `q0_k71.json` row family; they include the
degree-only global DYADIC rows, not every SUBDY row.

## Reproduce

Run with Python 3, with no third-party modules or solver:

```sh
python3 check_local.py > output.json
```

It regenerates `assignment_saturated_local.json` and `receipt.json` in the
current directory (and also a second, deliberately less constrained local
placement). `independent_q0.py` supplies the exact row functions and the
integer 100th-root power enclosures from the independent [PR #7882](https://github.com/CrocSwap/integer-mult-bounds/pull/7882)
check. `q0_word_check.py`, `caller_C1.json`, and `ml_k9.json` are the
word-checker and words from the pinned #7869 package. A checked-in assignment
is provided so that all 140 labelled masks and their pieces can be inspected.

The script directly exhausts all `3^8 - 2*2^8 + 1 = 6,050` nonempty ordered
disjoint pairs `(X,Y)` in each window `[0,7]` and `[1,8]` in call order. It
checks raw CROSS, post-closure effective-mask CROSS, PIECE-CROSS and
PIECE2-CROSS. Both piece-sensitive rows use the raw masks; closure is empty
on all nine tested stages, so these are also the masks after closure there.
We do **not** assume that inserting effective masks into an arbitrary
piece-sensitive expression is valid when closure is nonempty.

## Explicit branch and exact local result

The assignment realizes this type multiset, quoted from `notes/intcaller.md`
and its `ic4_parity` evidence:

```text
1  x 71:(16,16,1^39), all 39 singleton pieces MAIN
1  x 71:(32,32,1^7),  all 7 singleton pieces MAIN
1  x 32:(8,8,8,6,2)
1  x 32:(16,16)
4  x 16:(2^8)
3  x  8:(2^4)
1  x  6:(2,2,2)
48 x  2:(1,1), both singleton pieces MAIN
80 x  2:(2)
```

There are exactly 140 roles and exactly two MAINs at every stage. Every piece
is contained in its role mask, the pieces partition that mask, and every MAIN
is a singleton piece. With exponent `99/100`, the role-piece invoice lies in
the interval **[129.034865989491791, 129.034865989491792]**, enclosed using
integer roots rather than a floating-point optimizer. This is above 128.891.
It is an invoice for a mask/type relaxation, not a realized caller invoice.

The checker verifies all **357** q0 type rows exactly as rational inequalities,
as well as the INTCALLER averaged TRIPLE, HALL and TURAN type inequalities.
In each window, all 6,050 ordered cuts pass, with minimum slack zero for each
of the four families. For each of the 36 unordered pairs in the union
`[0,8]`, the number of roles that contain both stages in **different** pieces
is exactly two. All nine stages have empty greatest closed sets. Thus the
placement passes the requested local tests even after adding the branch's
necessary pair-saturation equality on the entire nine-stage union.

The raw masks also obey SPARSE, `#{r : M_r subset U} <= 2|U|-2`, for **all**
nonempty stage subsets U, not merely subsets of those windows. The certificate
is the pair of forests and their seven common components in the assignment:
the 128 degree-2 masks form two spanning forests with 64 edges apiece, and
each of the ten medium masks meets at least six components. If U contains a
medium mask, the two induced forests together have at least 12 components,
so their edges plus at most ten medium masks are at most `2|U|-2`. Without a
medium mask, the two forest bound suffices. The two 71-masks can be contained
only in the full set, where the inequality is equality. This is a separate
local-subset fact from the degree-only DYADIC rows.

## Decisive failures outside the windows

The labelled assignment is **not globally feasible**. For example, stages
`(0,9)` have only one distinct-piece separator, contrary to PIECE2-CROSS's
necessary lower bound of two. Of 2,485 unordered stage pairs, 739 have fewer
than two separators and 576 have more than two. All raw pair contributions
sum to exactly 4,970. Stages 55 through 70 also have nonempty closed sets.

At `J=2`, the exact residue-tree count on the raw placed masks is 184, below
the necessary 210, while the **degree-only cap used in the q0 type row** is
210. The corresponding effective-mask count is 143. Similarly `J=1` has raw
130 and effective 96 against required 140, even though the degree-only cap is
164. These differences are why satisfying the 357 averaged rows does not
make this a global mask witness.

Positive controls include the exact Q(i)[D] replay of `caller_C1` and its
explicit labelled frame, and a documented built C33 frame; all their small
ordered cuts pass. The `ml_k9` word also replays exactly and the reconstructed
labelled chain passes both width-8 window families. Its reconstruction is
checked against final mask degrees and the full idle-piece event multiset;
the receipt does not claim a separate provenance proof for every reconstructed
piece. As a negative control, two pure `{0,1}` roles have raw CROSS credit two
but PIECE-CROSS and PIECE2-CROSS credit zero, and closure removes both roles.

## Consequences for every realization of this exact type branch

These are conditional consequences of the pinned frame laws, not a proof
that any realization exists.

1. For a pair `{s,t}`, let its separation count be the number of roles whose
   mask contains both and whose pieces place them in different parts. The
   multiset above fixes the sum of separation counts, regardless of placement:
   `2245 + 1493 + 396 + 256 + 448 + 72 + 12 + 48 = 4970 = 2*C(71,2)`.
   PIECE2-CROSS with singleton X and Y requires each count to be at least two.
   Hence **every** pair must have separation count exactly two. This is a
   placement consequence; an averaged row alone does not place the roles.

2. The degree-only DYADIC caps are equal to their required totals for
   `J=2,3,4,5,6,7`. The actual tree contribution lies between the required
   total and the sum of the caps. Thus every role attains its own cap and
   every node of each such dyadic tree is CROSS-tight. In particular, a degree-2
   role's two stages must have distinct residues mod 8, every degree-8 role
   must use all eight residues mod 8, every degree-16 role has 16 distinct
   residues mod 16, and every degree-32 role has 32 distinct residues mod 32.
   Since PIECE2-CROSS is bounded above by ordinary CROSS and has the same
   lower bound, no piece-trap penalty can occur at any of those tight nodes.

3. The pair condition also forces closure to be empty everywhere. Here is the
   needed effective-pair argument. At stage t, the pieces belonging to the
   greatest closed set `C_t` have x- and y-vectors supported in `C_t` and form
   dual bases there. Every other piece through t has both vectors zero on
   `C_t`, by biorthogonality. For a piece containing t and u whose owner is
   effective at both stages, these vectors therefore vanish on
   `C_t union C_u`; the usual rank-two PIECE2 argument applies to the roles
   effective at both t and u. So the effective distinct-piece separation
   count is also at least two. It is no greater than the raw count, and their
   global raw sum is exactly 4,970; consequently no raw separated pair may
   lose a role through closure. Every role with two or more pieces is
   effective at every stage, by choosing a stage in another piece. Both
   71-stage hub roles have multiple pieces, so they are effective everywhere.
   A pure role's unique piece is contained in both hub masks; if that pure
   role were closed, the closure condition would require both hubs to be
   closed at the same stage, a contradiction. Thus every role is effective at
   all of its stages.

The last item uses the exact biorthogonal-piece and invertible rank-two block
hypotheses in the cited source. It is not asserted for arbitrary labelled
partitions or for callers outside that frame model.
