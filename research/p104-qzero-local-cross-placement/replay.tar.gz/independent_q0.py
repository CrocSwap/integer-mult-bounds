#!/usr/bin/env python3
"""Independent integer-enclosed DP and exact row evaluation for PR7869 Q0."""
import json, math, sys
from fractions import Fraction as F
from pathlib import Path
from functools import lru_cache
HERE=Path(__file__).resolve().parent
PKG=HERE/'source'
SCALE=10**20

def floor_root(n,r):
    a=1 << ((n.bit_length()+r-1)//r)
    while True:
        b=((r-1)*a+n//a**(r-1))//r
        if b>=a: break
        a=b
    while a**r>n:a-=1
    while (a+1)**r<=n:a+=1
    assert a**r<=n<(a+1)**r
    return a

@lru_cache(None)
def power(x):
    lo=floor_root(x**99*SCALE**100,100)
    return lo,lo+1

def rounded(q,up):
    num=q.numerator*SCALE
    return -((-num)//q.denominator) if up else num//q.denominator

def rows(k,J,D,L=None):
    # Each row is (name,rhs,role constant,piece coefficient,no-singleton addition).
    l=L or 0
    out=[('sep',F(k*(k-1)),F(D*D,2),F(-l*l,2),0),('e',2*k-2,-1,int(L is not None),0),('ones',2*k,0,int(l==1),0)]
    for t in range(2,k-1):out.append((f'ell_{t}',k*(k-1),D*(k-D) if t<=D<k else 0,F(l*(D-l),2) if l<t else 0,0))
    for t in range(2,k+1):out.append((f'coord_{t}',0,0,2*l if 2<=l<=t else int(l==1 and D>t),-1))
    out.append(('shal',k,0,2*int(l==2)+int(l==1 and D>=3),0))
    for t in range(1,k):out.append((f'pfix_{t}',-(2*k-2-2*t),-F(math.comb(k-D,t),math.comb(k,t)),-F(math.comb(l,t),math.comb(k,t)) if l>=2 else 0,0))
    for a in range(1,J+1):
        rhs=sum(2*(len(range(j,k,2**b))//2) for b in range(a+1) for j in range(2**b))
        out.append((f'dyadic_{a}',rhs,min(D,2**(a+1))-1,0,0))
    for t in range(3,k+1):out.append((f'RC_{t}',2*k,0 if D>=t else F(D*(D-1),k-1),l if D>=t and l<t else 0,0))
    for t in range(3,k+1):out.append((f'RC2_{t}',2*k,0 if D>=t else F(D*D,k-1),F(l*(k-l),k-1) if D>=t and l<t else (0 if D>=t else -F(l*l,k-1)),0))
    return out

def witness(k,J):
    # Exact role partition of the #7856 event-data witness.
    types=[(2,k,[1]*k),(2*k-4,2,[2])]
    vals=[F(0)]*len(rows(k,J,2))
    for count,D,P in types:
        base=rows(k,J,D)
        for i,(_,rhs,c,_,z) in enumerate(base):
            vals[i]+=count*(c+(z if 1 not in P else 0)+sum(rows(k,J,D,L)[i][3] for L in P))
    return [{'row':r[0],'lhs':str(v),'rhs':str(r[1]),'slack':str(v-r[1])} for v,r in zip(vals,rows(k,J,2)) if v<r[1]]

def decimal_bound(v,up):
    scale=10**15
    n=-((-v.numerator*scale)//v.denominator) if up else v.numerator*scale//v.denominator
    return str(n//scale)+'.'+str(n%scale).zfill(15)

def bound(k):
    c=json.loads((PKG/f'certs/q0_k{k}.json').read_text())
    w=list(map(F,c['dual']));y=F(c['y']);wm=F(c['wm']);J=len(w)-(5*k-5)
    assert all(v>=0 for v in w)
    rd=rows(k,J,2);assert len(w)==len(rd)
    constants=sum(v*r[1] for v,r in zip(w,rd))+2*k*wm
    endpoints=[]
    for up in [False,True]:
        best_global=None
        for D in range(2,k+1):
            rd=rows(k,J,D)
            role=sum(v*r[2] for v,r in zip(w,rd))+y
            zero=sum(v*r[4] for v,r in zip(w,rd))
            gains=[]
            for L in range(1,min(D,k-2)+1):
                piece=sum(v*r[3] for v,r in zip(w,rows(k,J,D,L)))
                gains.append(rounded(piece,up)-power(8*L)[0 if up else 1])
            for mf in [0,1]:
                dp=[[None,None] for _ in range(D+1)];dp[0][0]=0
                for size in range(1,D+1):
                    for L,gain in enumerate(gains[:size],1):
                        for had in [0,1]:
                            prev=dp[size-L][had]
                            if prev is None:continue
                            now=int(had or L==1)
                            candidate=prev+gain+(rounded(wm,up) if mf and L==1 else 0)
                            if dp[size][now] is None or candidate>dp[size][now]:dp[size][now]=candidate
                for has in [0,1]:
                    if mf and not has:continue
                    if dp[D][has] is None:continue
                    score=dp[D][has]+power(8*D+1)[1 if up else 0]+rounded(role,up)+(rounded(zero,up) if not has else 0)
                    if best_global is None or score>best_global:best_global=score
        val=F(104,k)*((2*k-2)*(F(best_global,SCALE)-y)-constants)
        endpoints.append(val)
    lo,hi=endpoints
    assert lo<=hi and hi-lo<F(1,10**14)
    q=lambda v,up: decimal_bound(v,up)
    # Decimal display is auxiliary. Both rational endpoints are retained.
    result={'k':k,'rows':len(w),'J':J,'lower':str(lo),'upper':str(hi),'lower_display':q(lo,False),'upper_display':q(hi,True),'below_bar':hi<F(128891,1000),'witness_violations':witness(k,J),'wm':str(wm)}
    print(k,result['lower_display'],result['upper_display'],result['witness_violations'],flush=True)
    return result

if __name__=='__main__':
    result=[bound(k) for k in (71,72,73)]
    assert [r['below_bar'] for r in result]==[False,True,True]
    (HERE/'INDEPENDENT-Q0.json').write_text(json.dumps(result,indent=2)+'\n')
