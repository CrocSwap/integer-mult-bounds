# Source receipt

The first nine hashes are files in `research/p104-lowerbound-guidance/` at
`CrocSwap/integer-mult-bounds` commit
`06c207a9feb3994a4b987dc3010657b6e85b7956` (PR #7869). The exact source
checkout was at that commit and had no changes in that package at inspection.

```text
d97bde1398505eb230e4264b6db2e86bf0ec181f00c7f824c3ab3847cfdae93c  certs/q0_k71.json
28631389ade47fe54bc311325a453bf5260fe5172f2a459489da5021c515dda8  notes/scherk.md
4143f3e85d4ed76490bf0197567e6d3087fd9af997f15704d9a5c7ba8937545d  notes/bilinear.md
4f8d716a5660cbb060ed385708f548b6134009e6a8dce1d073045fc99c707d0a  notes/dyadrelay.md
13c406129fc4666fff8a192a56a1edd410aa82b9fb1b7b9fd9c57d64b06d4fd9  notes/intcaller.md
9a732a0306a9b518b065721e1370a9edf7b10fc1ffe5b0f055361f44258d1ea1  code/intcaller/evidence/ic4_parity.log.txt
2233655e29abce6ad1282e6da52ea70a77e7cb2f71b331f78834c165955cd504  data/q0_callers/check.py
c708c66aa828bf2a494608555222d9f4d504c220451cd220045471f74ac17a3d  data/q0_callers/caller_C1.json
0d6a0de9e62cb8e7560a70e620a341d188665441e3dcd2a7b0d0e984ff23f14c  data/q0_callers/ml_k9.json
```

The package includes the last three files, with `check.py` named
`q0_word_check.py`. The independent q0 type-row and integer-power routine
from the #7882 follow-up has the following hash:

```text
2b143f6fc089386694660075f0c07dce00d1b18bd388a96ba6b36c0eba70abcd  independent_q0.py
```
