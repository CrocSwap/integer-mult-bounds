#!/usr/bin/env python3
"""Exact finite local-cut checks for the #7869 k=71 type branch.

No optimizer or randomized search.  A labelled type assignment is a relaxation,
not a caller word.  See README.md for hypotheses and mathematical scope.
"""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import json, math, random
import independent_q0 as q0
import q0_word_check as word

HERE = Path(__file__).resolve().parent
def R(parts, main=()):
    parts = tuple(frozenset(p) for p in parts)
    assert all(parts)
    M = frozenset().union(*parts)
    assert sum(map(len, parts)) == len(M)
    assert set(main)<=M and all(any(p==frozenset({t}) for p in parts) for t in main)
    return {'mask': M, 'pieces': parts, 'main': frozenset(main)}

def closure(k, roles):
    """Greatest closed C_t, including every role covering each multi-piece."""
    closed=[]
    for t in range(k):
        at={i for i,r in enumerate(roles) if t in r['mask']}
        pt={i:next(p for p in roles[i]['pieces'] if t in p) for i in at}
        C={i for i in at if len(pt[i])>1}
        while True:
            D={i for i in C if all(not(pt[i] <= roles[j]['mask']) or j in C for j in range(len(roles)))}
            if D == C: break
            C=D
        closed.append(C)
    eff=[frozenset(t for t in r['mask'] if i not in closed[t]) for i,r in enumerate(roles)]
    return closed,eff

def arank(X,Y):
    seq=['X' if t in X else 'Y' for t in sorted(X|Y)]
    def runs(a):return sum(s==a and (i==0 or seq[i-1]!=a) for i,s in enumerate(seq))
    return 2*min(runs('X'),runs('Y'))

def scores(roles, masks, X, Y):
    cross=pc=pc2=0
    for r,M in zip(roles,masks):
        if M&X and M&Y:cross+=1
        if X<=M:
            pc+=not any(len(p)>1 and X<=p for p in r['pieces'])
        elif M&X and M&Y:pc+=1
        if M&X and M&Y and not any(X<=p and p&Y for p in r['pieces']):pc2+=1
    return cross,pc,pc2

def local_checks(roles, eff, windows, require_unclosed=True):
    raw=[r['mask'] for r in roles]
    # PC and PC2 are applied with raw masks.  Simultaneous use with effective
    # masks is valid here only because closure is empty on every window stage.
    assert not require_unclosed or all(all((t in raw[i]) == (t in eff[i]) for i in range(len(roles))) for W in windows for t in W)
    out=[]
    for W in windows:
        mins=[None]*4; arg=[None]*4; count=0
        for labels in product(range(3), repeat=len(W)):
            X=frozenset(t for t,a in zip(W,labels) if a==1)
            Y=frozenset(t for t,a in zip(W,labels) if a==2)
            if not X or not Y:continue
            need=arank(X,Y)
            a,b,c=scores(roles,raw,X,Y)
            ac,_,_=scores(roles,eff,X,Y)
            for j,v in enumerate((a-need,ac-need,b-need,c-need)):
                if mins[j] is None or v<mins[j]:mins[j],arg[j]=v,(sorted(X),sorted(Y))
            count+=1
        assert all(x>=0 for x in mins), (W,mins,arg)
        out.append({'window':list(W),'cuts':count,'min_slack_raw_cross_effective_cross_piece_cross_piece2_cross':mins,'argmins':arg})
    return out

def branch():
    # 7 common connected components, with two spanning forests.  The 48 MAIN
    # chords lie in the first forest and the remaining 80 edges are pure pairs.
    G=[{i} for i in range(7)]
    G[0].add(7);G[1].add(8)
    pos=9
    for i,num in enumerate([5,5,4,4,4,4,4]):
        G[i].update(range(pos,pos+num));pos+=num
    assert pos==39
    for x in range(39,71):G[(x-39)%7].add(x)
    assert set().union(*G)==set(range(71)) and sum(map(len,G))==71
    rng=random.Random(71)
    forest1=[];forest2=[];main_edges=[]
    for g in G:
        ends=sorted(x for x in g if 7<=x<=38)
        internal=sorted(x for x in g if x>=39)
        assert len(ends)%2==0
        paths=[[ends[i],ends[i+1]] for i in range(0,len(ends),2)]
        for i,x in enumerate(internal): paths[i%len(paths)].insert(-1,x)
        seq=[]
        for p in paths:
            main_edges += list(zip(p,p[1:]));seq += p
        seq += sorted(x for x in g if x not in seq)
        forest1 += list(zip(seq,seq[1:]))
        seq2=sorted(g);rng.shuffle(seq2);forest2 += list(zip(seq2,seq2[1:]))
    assert len(forest1)==len(forest2)==64 and len(main_edges)==48
    normal=lambda es:[tuple(sorted(e)) for e in es]
    e1,e2,em=map(normal,(forest1,forest2,main_edges))
    assert len(set(e1))==len(e1) and set(em)<=set(e1)
    pure=[e for e in e1 if e not in set(em)]+e2
    assert len(pure)==80
    roles=[]
    H1=[{t} for t in range(39)]+[set(range(39,55)),set(range(55,71))]
    H2=[{t} for t in range(7)]+[{7}|set(range(9,40)),{8}|set(range(40,71))]
    roles += [R(H1,range(39)), R(H2,range(7))]
    def medium(mask,sizes):
        a=list(mask);rng.shuffle(a);parts=[];p=0
        for size in sizes: parts.append(a[p:p+size]);p+=size
        assert p==len(a)
        return R(parts)
    ext=list(range(9,71))
    roles.append(medium(list(range(9))+ext[:23],[8,8,8,6,2]))
    roles.append(medium(list(range(9))+ext[23:46],[16,16]))
    for i in range(4):roles.append(medium(list(range(9))+ext[7*i:7*i+7],[2]*8))
    for omit in (8,0,1):roles.append(medium([j for j in range(9) if j!=omit],[2]*4))
    roles.append(medium(list(range(6)),[2]*3))
    roles += [R([[a],[b]],[a,b]) for a,b in main_edges]
    roles += [R([[a,b]]) for a,b in pure]
    assert len(roles)==140
    assert all(sum(t in r['main'] for r in roles)==2 for t in range(71))
    for r in roles:
        assert r['main']<=r['mask'] and all(len(p)==1 for p in r['pieces'] if next(iter(p)) in r['main'])
    return roles,G,e1,e2

def branch_locally_saturated():
    # The 9-stage restriction is a two-copy interval binary tree:
    # 0123|45678, then 01|23 and 45|678, then 6|78.  Four leaf pairs
    # are two MAIN chords each; the only unpaired leaf 6 has two chords
    # to stages outside the window.  Pair-separation is exactly two.
    G=[set() for _ in range(7)]
    for i,loc in enumerate(([0,1],[2,3],[4,5],[6,9,10],[7,8])):G[i].update(loc)
    for j in range(22):G[j%7].update([11+2*j,12+2*j])
    for j in range(16):G[j%7].add(55+j)
    assert set().union(*G)==set(range(71)) and sum(map(len,G))==71
    e1=[];e2=[];mains=[]
    def add_main(a,b,which):
        e=tuple(sorted((a,b)));mains.append(e);(e1 if which==1 else e2).append(e)
    for a,b in ((0,1),(2,3),(4,5),(7,8)):
        add_main(a,b,1);add_main(a,b,2)
    add_main(6,9,1);add_main(6,10,2)
    paths=[[11+2*j,12+2*j] for j in range(22)]
    for j,x in enumerate(range(55,71)):paths[j].insert(1,x)
    for p in paths:
        for a,b in zip(p,p[1:]):add_main(a,b,1)
    assert len(mains)==48
    def complete_tree(edges,g,order):
        par={x:x for x in g}
        def find(x):
            while par[x]!=x:par[x]=par[par[x]];x=par[x]
            return x
        def join(a,b):
            a,b=find(a),find(b)
            if a==b:return False
            par[a]=b;return True
        for a,b in edges:
            if a in g and b in g:assert join(a,b)
        for a,b in combinations(order,2):
            if join(a,b):edges.append(tuple(sorted((a,b))))
    for g in G:
        complete_tree(e1,g,sorted(g))
        complete_tree(e2,g,sorted(g,reverse=True))
    assert len(e1)==len(e2)==64
    from collections import Counter as CC
    remaining=CC(e1+e2)-CC(mains)
    pure=list(remaining.elements());assert len(pure)==80
    H1=[{t} for t in range(9,48)]+[set(range(4))|set(range(48,60)),set(range(4,9))|set(range(60,71))]
    H2=[{t} for t in range(48,55)]+[set(range(4))|set(range(9,37)),set(range(4,9))|set(range(37,48))|set(range(55,71))]
    roles=[R(H1,range(9,48)),R(H2,range(48,55))]
    a={4,5}|set(range(60,71))|{11,12,13}
    b={6,7,8,9,14,15,16,17,21,23,26,27,28,29,30,31}
    assert len(a)==len(b)==16 and not a&b
    q={6,7,8,9,14,15,16,17}; small={4,5}
    m={4,5,6,7,8}|set(range(60,71))|{9,11,12,13,14,15,16,17}|set(range(18,26))
    assert len(m)==32 and a<=m and q<=m
    remaining32=sorted(m-q-small)
    roles.append(R([q,remaining32[:8],remaining32[8:16],remaining32[16:],small]))
    roles.append(R([a,b]))
    mask4=set(range(4))|set(range(48,60))
    def pairs_after(first,mask):
        used=set().union(*map(set,first));remain=sorted(mask-used)
        assert len(remain)%2==0
        return list(first)+[remain[i:i+2] for i in range(0,len(remain),2)]
    for _ in range(2):roles.append(R(pairs_after([[0,1],[2,3]],mask4)))
    for _ in range(2):roles.append(R(pairs_after([[6,9],[7,8]],b)))
    # Remaining medium roles avoid the local union and meet >= 6 forest
    # components, as required for the all-subsets SPARSE proof.
    outside=[[x for x in sorted(g) if x>=9] for g in G]
    for shift in range(3):
        mask={outside[i][shift%len(outside[i])] for i in range(7)}
        mask.add(next(x for x in range(9,71) if x not in mask))
        roles.append(R(pairs_after([],mask)))
    mask={outside[i][0] for i in range(6)}
    roles.append(R(pairs_after([],mask)))
    roles += [R([[a],[b]],[a,b]) for a,b in mains]
    roles += [R([[a,b]]) for a,b in pure]
    assert len(roles)==140 and all(sum(t in r['main'] for r in roles)==2 for t in range(71))
    return roles,G,e1,e2

def verify_type_rows(roles):
    k=71; J=7
    ty=Counter((len(r['mask']),tuple(sorted(map(len,r['pieces'])))) for r in roles)
    expected=Counter({(71,tuple([1]*39+[16,16])):1,(71,tuple([1]*7+[32,32])):1,
        (32,(2,6,8,8,8)):1,(32,(16,16)):1,(16,tuple([2]*8)):4,
        (8,tuple([2]*4)):3,(6,(2,2,2)):1,(2,(1,1)):48,(2,(2,)):80})
    assert ty==expected,(ty,expected)
    vals=[F(0)]*len(q0.rows(k,J,2))
    for (D,P),n in ty.items():
        rr=q0.rows(k,J,D); piece={L:q0.rows(k,J,D,L) for L in set(P)}
        for i,(_,_,c,_,z) in enumerate(rr):
            vals[i]+=n*(c+(z if 1 not in P else 0)+sum(piece[L][i][3] for L in P))
    rd=q0.rows(k,J,2)
    bad=[(row[0],str(val-row[1])) for val,row in zip(vals,rd) if val<row[1]]
    assert not bad,bad
    triple=sum(math.comb(D,3)+math.comb(D,2)*(k-D) for r in roles for D in [len(r['mask'])]) - 3*math.comb(k,3)
    hall=[]
    for ell in range(2,k+1):
        v=sum(sum(len(p)*(k-len(p)) for p in r['pieces'] if len(p)<ell)
              -(len(r['mask'])<ell)*len(r['mask'])*(k-len(r['mask'])) for r in roles)-(k-1)*2*k
        hall.append(v)
    ds=sorted([len(r['mask']) for r in roles],reverse=True)
    turan=sum(math.comb(D,2) for D in ds[2:])-(k-1)**2//4
    assert triple>=0 and min(hall)>=0 and turan>=0
    # Exact enclosing integer roots, as in the independent #7882 verifier.
    lo=hi=0
    for (D,P),n in ty.items():
        a,b=q0.power(8*D+1);llo=lhi=0
        for L in P:
            x,y=q0.power(8*L);llo+=x;lhi+=y
        lo+=n*(a-lhi);hi+=n*(b-llo)
    lo=F(104*lo,71*q0.SCALE);hi=F(104*hi,71*q0.SCALE)
    assert lo>F(128891,1000)
    return {'rows':len(rd),'extra_intcaller_triple_slack':triple,'extra_intcaller_min_hall_slack':min(hall),'extra_intcaller_turan_slack':turan,
            'zero_slack':[row[0] for val,row in zip(vals,rd) if val==row[1]],
            'invoice_interval':[str(lo),str(hi)],'invoice_decimal':[q0.decimal_bound(lo,False),q0.decimal_bound(hi,True)]}

def separation_pairs(roles, masks):
    dist=Counter();over=[];under=[]
    for a,b in combinations(range(71),2):
        score=sum(a in M and b in M and not any(a in p and b in p for p in r['pieces']) for r,M in zip(roles,masks))
        dist[score]+=1
        if score<2:under.append((a,b,score))
        if score>2:over.append((a,b,score))
    return {'hist':dict(sorted(dist.items())),'sum':sum(k*v for k,v in dist.items()),'under':len(under),'over':len(over),'first_under':under[:5],'first_over':over[:5]}

def dyadic(roles,masks):
    rows=[]
    for J in range(1,8):
        rhs=sum(2*(len(range(j,71,2**l))//2) for l in range(J+1) for j in range(2**l))
        exact=sum(max(0,len({t%(2**(J+1)) for t in M})-1) for M in masks)
        degree=sum(min(len(r['mask']),2**(J+1))-1 for r in roles)
        rows.append({'J':J,'rhs':rhs,'actual_mask':exact,'degree_only':degree})
    return rows

def k9_control():
    # The extracted role pieces are forced by the nested chain's 2 copies of
    # each IDLE_ONE event; stage i is main for roles starting at i (last pair
    # is main at stages 7 and 8).  Verify multiplicities against the word.
    roles=[]
    for i in range(8):
        if i==7: parts=[{7},{8}];m=[7,8]
        else: parts=[{i},{i+1}]+([set(range(i+2,9))] if i+2<9 else []);m=[i]
        roles += [R(parts,m),R(parts,m)]
    C=json.loads((HERE/'ml_k9.json').read_text())
    assert word.legal(C)==(True,True)
    assert sorted(map(len,[r['mask'] for r in roles]))==sorted(sum(d[2:]) for d in C['diagonal'])
    expected=Counter(tuple(sorted(x-1 for x in e[2])) for e in C['events'] if e[0]=='IDLE_ONE')
    actual=Counter(tuple(sorted(p)) for r in roles for p in r['pieces'] if not (len(p)==1 and next(iter(p)) in r['main']))
    assert expected==actual,(expected,actual)
    closed,eff=closure(9,roles)
    assert all(not c for c in closed)
    return {'name':'ml_k9','legal_exact_Qi_D':True,'all_cuts':local_checks(roles,eff,[range(8),range(1,9)]),
            'closed_count':[len(c) for c in closed]}

def smaller_controls():
    # C1's stage order is 3,1,2 in its word.  Its two degree-2 roles are
    # main at both stages; the full-mask roles are main at 3 and idle at 1,2.
    c1=[R([[1],[2]],[1,2]) for _ in range(2)]+[R([[0],[1],[2]],[0]) for _ in range(2)]
    C=json.loads((HERE/'caller_C1.json').read_text())
    assert word.legal(C)==(True,True)
    closed,eff=closure(3,c1);assert not any(closed)
    c33=[R([[i] for i in range(6)],range(6)) for _ in range(2)]
    c33 += [R([[0],[1,2]]) for _ in range(2)]
    c33 += [R([[1],[2]]) for _ in range(2)]
    c33 += [R([[3,4]]) for _ in range(2)]
    c33 += [R([[3],[4],[5]]) for _ in range(2)]
    closed2,eff2=closure(6,c33);assert not any(closed2)
    return {'C1_exact_word':local_checks(c1,eff,[range(3)]),
            'C33_built_frame':local_checks(c33,eff2,[range(6)])}

def main():
    control=k9_control()
    smaller=smaller_controls()
    roles,G,e1,e2=branch();closed,eff=closure(71,roles)
    assignment={'roles':[{'mask':sorted(r['mask']),'pieces':[sorted(p) for p in r['pieces']],'main':sorted(r['main'])} for r in roles],
                'forest_components':[sorted(g) for g in G], 'forest1':e1,'forest2':e2}
    (HERE/'assignment.json').write_text(json.dumps(assignment,indent=2)+'\n')
    checks=local_checks(roles,eff,[range(8),range(1,9)])
    # All-subsets SPARSE proof: each medium mask meets >=6 of seven common
    # forest components, so for any U containing one, 2 forests have >=12
    # induced components, leaving >=10 edge slots for the ten medium masks.
    medium=roles[2:12]
    component_counts=[sum(bool(r['mask']&g) for g in G) for r in medium]
    assert min(component_counts)>=6
    assert all(len(g)-1==sum(a in g and b in g for a,b in e1)==sum(a in g and b in g for a,b in e2) for g in G)
    local_sparsity=[]
    for W in [range(8),range(1,9),range(9)]:
        m=1000;arg=None
        for bits in product([0,1],repeat=len(W)):
            U={x for x,z in zip(W,bits) if z}
            if not U:continue
            sl=max(0,2*len(U)-2)-sum(r['mask']<=U for r in roles)
            if sl<m:m,arg=sl,sorted(U)
        assert m>=0
        local_sparsity.append({'universe':list(W),'minimum_slack':m,'argmin':arg})
    raw=[r['mask'] for r in roles]
    rawpair=separation_pairs(roles,raw);effpair=separation_pairs(roles,eff)
    assert rawpair['sum']==2*math.comb(71,2)==4970
    assert rawpair['under'] and rawpair['over']
    toy=[R([[0,1]]),R([[0,1]])];tc,te=closure(2,toy)
    assert [len(c) for c in tc]==[2,2]
    assert scores(toy,[r['mask'] for r in toy],frozenset({0}),frozenset({1}))==(2,0,0)
    result={'control_c1_word_exact_Qi_D':True,'smaller_controls':smaller,'control_ml9':control,'q0_type_branch':verify_type_rows(roles),
            'local_checks':checks,'local_sparse':local_sparsity,'all_subsets_sparse_forest_proof':{'component_sizes':list(map(len,G)),'medium_component_counts':component_counts,'two_forest_edges':[len(e1),len(e2)]},
            'closed_counts_by_stage':[len(c) for c in closed],
            'raw_pair_separation':rawpair,'effective_pair_separation':effpair,
            'raw_dyadic':dyadic(roles,raw),'effective_dyadic':dyadic(roles,eff),
            'negative_control':{'two_pure_pairs':{'raw_cross':2,'piece_cross':0,'piece2_cross':0,'closed_roles_each_stage':[2,2]}}}
    sat,SG,SE1,SE2=branch_locally_saturated();sc,se=closure(71,sat)
    sat_assignment={'roles':[{'mask':sorted(r['mask']),'pieces':[sorted(p) for p in r['pieces']],'main':sorted(r['main'])} for r in sat],
                    'forest_components':[sorted(g) for g in SG], 'forest1':SE1,'forest2':SE2}
    (HERE/'assignment_saturated_local.json').write_text(json.dumps(sat_assignment,indent=2)+'\n')
    sm=[sum(bool(r['mask']&g) for g in SG) for r in sat[2:12]]
    assert min(sm)>=6,sm
    assert all(len(g)-1==sum(a in g and b in g for a,b in SE1)==sum(a in g and b in g for a,b in SE2) for g in SG)
    scuts=local_checks(sat,se,[range(8),range(1,9)])
    sr=[r['mask'] for r in sat]
    localpairs=[]
    for a,b in combinations(range(9),2):
        count=sum(a in M and b in M and not any(a in p and b in p for p in r['pieces']) for r,M in zip(sat,sr))
        assert count==2,(a,b,count)
        localpairs.append((a,b,count))
    assert sum(bool(c) for c in sc[:9])==0
    result['saturated_local_assignment']={'local_cuts':scuts,'all_36_union_pairs_exact_separation_two':True,
          'closed_counts_by_stage':[len(c) for c in sc], 'all_subsets_sparse_forest_proof':{'component_sizes':list(map(len,SG)),
          'medium_component_counts':sm,'two_forest_edges':[len(SE1),len(SE2)]},
          'raw_pair_separation':separation_pairs(sat,sr),'effective_pair_separation':separation_pairs(sat,se),
          'raw_dyadic':dyadic(sat,sr),'effective_dyadic':dyadic(sat,se), 'q0_type_branch':verify_type_rows(sat)}
    (HERE/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
