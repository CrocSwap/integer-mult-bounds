# Prove exact P104 BIT receipt prices with free original history

At all 2,874 MOVE clocks, freeze the original scalar and prior tape and allow arbitrary deterministic local functions of free original chart history. No strictly cheaper directly nested donor receipts preserve that scalar.

Two historical-union replays return one exception among 1,498 nontrivial moves. Packet 2944 needs 56 different grade-one donor charts using that grade alone, and all affordable cases fail. Both original signed callers and corrupted candidate controls replay.

Change the older history, scalar, paid geometry or caller. Multi-hop and input-dependent incidence remain outside scope.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. Cold extraction passed 163 hashes, both whole-word historical union checks, direct-sum and triple controls, directed signed pricing and provenance mutation tests.
