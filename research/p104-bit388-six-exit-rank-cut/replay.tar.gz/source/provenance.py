#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,subprocess,sys
from pathlib import Path
H=Path(__file__).resolve().parents[1]
refs={'7924':{'head':'c83039ac63874fa9f9a2fd0bb650469886076dc6','manifest_git_blob':'2f198cae71616c164f4bd5e002a1bd0b5f26463a','archive_sha256':'1b8cf88e86d2b2c82c7c1b796cc93179031da8866e97d61b34d0abc1b5788e0d','path':'research/p104-bit388-paid-relay/SOURCES.json'},
'7923':{'head':'bddc42acae01355aa0e429432f84fac02c271059','manifest_git_blob':'5464cc320884d5666abf93f17021a65d02cb909a','archive_sha256':'c123faccfb2b75de4575844e892c4132446b8ba334e849e20849b0422081ef04','path':'research/p104-bit2947-edge-exchange/SOURCES.json'}}
for pr,x in refs.items():
 data=(H/f'sources/pr{pr}-sources.json').read_bytes()
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert blob==x['manifest_git_blob'],(pr,blob)
 assert json.loads(data)['archive_file_sha256']['replay.tar.gz']==x['archive_sha256']
 assert hashlib.sha256((H/f'sources/pr{pr}-replay.tar.gz').read_bytes()).hexdigest()==x['archive_sha256']
 assert next(v['head'] for v in json.loads(data)['external_sources'] if v['pr']==7830)=='87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'
 for r in json.loads(data)['external_sources']:
  if r['pr']==7830:break
 x['manifest_url']=f"https://github.com/CrocSwap/integer-mult-bounds/blob/{x['head']}/{x['path']}"
 x['manifest_blob_observed_from_github_connector']=blob
p=H/'sources/pr7923'
r=subprocess.run([sys.executable,'-I','-B','exchange.py'],cwd=p,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
assert r.returncode!=0 and "No module named 'binary_operator'" in r.stderr
assert not (p/'source').exists()
(H/'receipts/pr7923-unaugmented.log').write_text('exit_code='+str(r.returncode)+'\n'+r.stderr)
(H/'receipts/provenance.json').write_text(json.dumps({'status':'PIN_AND_ARCHIVE_VERIFIED','references':refs,
 'baseline_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'archive_7923_unaugmented_replay':{'exit_code':r.returncode,'failure':"ModuleNotFoundError: No module named 'binary_operator'",'missing_source_directory':True},
 'archive_7923_augmented_source':'source/ from separately pinned PR 7924 archive',
 'blob_check':'Git blob SHA-1 of local package manifest equals GitHub connector metadata at each exact head, and each archive SHA-256 equals the manifest digest'},indent=2,sort_keys=True)+'\n')
print('PR #7924 and #7923 manifest Git blobs and archive SHA-256 digests match pinned heads')
print('PR #7923 unaugmented extraction reproducibly fails because source/ is absent')
