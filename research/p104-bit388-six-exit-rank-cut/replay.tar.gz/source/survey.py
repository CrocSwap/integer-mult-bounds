#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import gzip,json,sys
from pathlib import Path
from hashlib import sha256
HERE=Path(__file__).resolve().parents[1]
P=HERE/'sources/pr7924'
sys.path.insert(0,str(P/'independent'))
import changed_bit_replay as independent

def load(p):
 b=p.read_bytes()
 return json.loads(gzip.decompress(b) if str(p).endswith('.gz') else b)
def bits(q):return [i for i in range(680) if q>>i&1]
def desc_first(program,origin,first,k):
 x=first[k]; return {'kind':x[0],'changed_clock':x[1],'original_clock':origin[x[1]] if x[1]>=0 else None,'event':program[x[1]] if x[1]>=0 else None,'address':x[2],'arrival_row':bits(x[3])}
w=load(P/'WORD.json.gz'); charts=independent.Charts(w['frames'])
res={'source':{'pr7924_head':'c83039ac63874fa9f9a2fd0bb650469886076dc6','pr7923_head':'bddc42acae01355aa0e429432f84fac02c271059','pr7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','source_word_sha256':sha256((P/'WORD.json.gz').read_bytes()).hexdigest()},'words':{}}
for name in ('direct','two-recodes','baseline'):
 if name=='baseline': q=w; origin=list(range(len(w['program'])))
 else:q=load(P/'words'/f'{name}.json.gz');origin=load(P/'words'/f'{name}.origin.json')
 program=q['program'];fr={};ad={}
 pf,df,of=independent.run_word(q,charts,False,first_use_records=fr)
 pr,dr,orr=independent.run_word(q,charts,True,first_use_records=ad)
 packet_clocks=([k for k,e in enumerate(program) if e[0]=='MOVE' and e[1]==927 and origin[k] is None] if name!='baseline' else [k for k,e in enumerate(program) if e[0]=='MOVE' and e[3]==283 and k<=5191])
 packets=[]
 for k in packet_clocks:
  address,src,dst,g=pf[k]; packets.append({'move_clock':k,'original_clock':origin[k],'event':program[k],'grade':g,'first_forward':desc_first(program,origin,fr,k),'first_adjoint':desc_first(program,origin,ad,k)})
 res['words'][name]={'canonical_sha256':sha256(json.dumps(q,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'forward_and_adjoint_all_680_operators_checked':True,'dirty_forward_adjoint':[df,dr],'packet_count':len(packets),'packets':packets}
 if name=='two-recodes':
  correction,=[k for k,e in enumerate(program) if e==['ADD',1496,927,283]]
  uses=[]
  for k in range(correction+1,len(program)):
   e=program[k]
   if e[1]==1496 or e[0] in ('ADD','SWAP') and e[2]==1496:
    uses.append({'changed_clock':k,'original_clock':origin[k],'event':e})
    if e[0]=='CLEAR':break
  assert [u['original_clock'] for u in uses]==[None,5191,5197,5218,5225,40900]
  res['words'][name]['restored_1496_first_use_and_all_remaining_uses_until_retirement']=uses
out=HERE/'receipts/survey.json';out.write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
for name,data in res['words'].items():
 print('\n',name,data['packet_count'])
 for x in data['packets']:
  print('move',x['move_clock'],x['original_clock'],x['event'],'grade',x['grade'],'forward',x['first_forward']['changed_clock'],x['first_forward']['original_clock'],x['first_forward']['event'],'adjoint',x['first_adjoint']['changed_clock'],x['first_adjoint']['original_clock'],x['first_adjoint']['event'])
