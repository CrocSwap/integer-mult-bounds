#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Optimistic grade gate before checking exterior sender/receiver stock."""
import json,sys
from pathlib import Path
from hashlib import sha256
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from math import isqrt
HERE=Path(__file__).resolve().parents[1]
P=HERE/'sources/pr7924'
sys.path.insert(0,str(P/'independent'))
import target_exact as exact
BASE=P/'source/inputs/BIT.json'
b=json.loads(BASE.read_bytes())['native']
paid0=Counter({int(k):v for k,v in b['paid'].items()})
targets=Counter({int(k):v for k,v in b['targets'].items()})
trials=('0.003879928046156','0.003879929046155')
roster=[{'clock':1095,'role':988,'source_chart':56,'destination_chart':283,'original_grade':3},
 {'clock':1534,'role':1111,'source_chart':74,'destination_chart':283,'original_grade':3},
 {'clock':3327,'role':1604,'source_chart':187,'destination_chart':283,'original_grade':2},
 {'clock':3897,'role':1756,'source_chart':225,'destination_chart':283,'original_grade':2},
 {'clock':4122,'role':1816,'source_chart':240,'destination_chart':283,'original_grade':2}]
@lru_cache(None)
def root_bounds(rank,k):
 exponent=1-F(k);bits=204;S=1<<bits
 digits,rem=divmod(exponent.numerator*S,exponent.denominator)
 lower=upper=S;rl=ru=rank*S
 for shift in range(bits-1,-1,-1):
  rl=isqrt(rl*S);z=ru*S;zroot=isqrt(z);ru=zroot+(zroot*zroot<z)
  if digits&(1<<shift):
   lower=lower*rl//S;upper=(upper*ru+S-1)//S
 if rem:upper=(upper*ru+S-1)//S
 return F(lower,S),F(upper,S)
def root_signed(hist,k):
 lo=hi=F(0)
 for rank,n in hist.items():
  if not n:continue
  a,b=root_bounds(rank,k);lo+=n*(a if n>0 else b);hi+=n*(b if n>0 else a)
 return lo,hi
def hist(paid):
 x=Counter(targets);x.subtract(paid);return {k:v for k,v in x.items() if v}
def check(full,k):
 g=exact.signed(full,targets,k);l,h=root_signed(hist(full),k)
 assert F(g[0],exact.GRID)<=h and l<=F(g[1],exact.GRID)
 return exact.interval_output(g)
base={k:check(paid0,k) for k in trials}
rows=[]
for entry in roster:
 for grade in range(9):
  p=paid0.copy();p[5]-=36;p[3]+=36;p[1]+=36
  p[entry['original_grade']]-=36
  if grade:p[grade]+=36
  assert all(c>=0 for c in p.values())
  scores={k:check(p,k) for k in trials}
  gain={}
  for k in trials:
   candidate=exact.signed(p,targets,k);baseline=exact.signed(paid0,targets,k)
   gain[k]=exact.interval_output((candidate[0]-baseline[1],candidate[1]-baseline[0]))
  signs=[F(exact.signed(p,targets,k)[0],exact.GRID)>0 for k in trials]
  row=dict(entry,new_grade=grade,full_signed=scores,gain_over_baseline=gain,
           survives_both_trials=all(signs),incidence='equal charts optimistically free' if grade==0 else 'one replacement paid incidence')
  assert row['survives_both_trials']==(grade<=entry['original_grade'])
  rows.append(row)
out={'status':'PRICE_GATE_COMPLETE','source_sha256':sha256(BASE.read_bytes()).hexdigest(),
 'source_heads':{'7924':'c83039ac63874fa9f9a2fd0bb650469886076dc6','7923':'bddc42acae01355aa0e429432f84fac02c271059','7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'},
 'scope':'Frozen original six chart-283 arrivals before clock 5191; one of the five roles other than 1496 is replaced by one arbitrary scalar at a tested grade 0 through 8. Begin with the #7924 unrestored 2917/2922 recodes and 283→560 grade 3, 560→388 grade 1 relay, remove 45→388 grade 5. The old selected packet is removed and exactly one replacement is charged. The entire original 36-call paid/productive invoice is otherwise held unchanged. Grade zero treats coincident contact as optimistically free. Ignore all geometry restrictions, local/precision/restoration costs and other changed edges; this is a price upper bound under these frozen other charges, not an emitted word. Exact stock is considered only after this price screen.',
 'baseline_full_signed':base,'trials':trials,'roster':roster,'new_grades_tested':list(range(9)),
 'assignments_checked':len(rows),'assignments_surviving_both_trials':sum(r['survives_both_trials'] for r in rows),'rows':rows,
 'two_directed_engines':'fixed-point atanh/Taylor and independent integer-square-root intervals agree',
 'positive_control':'same-grade replacement gives a strictly positive optimistic complete invoice at both trials',
 'negative_control':'raising any old grade to a strictly larger grade fails the complete invoice at both trials'}
(HERE/'receipts/price-screen.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('roster',len(roster),'grade_assignments',len(rows),'survivors',out['assignments_surviving_both_trials'])
for entry in roster:
 z=[r for r in rows if r['role']==entry['role']]
 print('role',entry['role'],'grade',entry['original_grade'],'surviving grades',[r['new_grade'] for r in z if r['survives_both_trials']])
for grade in (1,2,3):
 r=next(r for r in rows if r['role']==1604 and r['new_grade']==grade)
 print('role 1604 new grade',grade,'near complete',r['full_signed'][trials[1]],'near gain',r['gain_over_baseline'][trials[1]])
