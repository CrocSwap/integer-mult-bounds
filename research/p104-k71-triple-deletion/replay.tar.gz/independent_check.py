#!/usr/bin/env python3
"""Independent raw-node/pair scan and Newton-root enclosure of the fixture."""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json

P=Path(__file__).resolve().parent
r=json.loads((P/'placement.json').read_text())['roles']
bits=[sum(1<<x for x in z['mask']) for z in r]

def total_and_nodes(dele):
    order=[x for x in range(71) if x not in dele]
    total=0; bad=[]; min_slack=None; nodes=0
    for lev in range(5):
        for start in range(2**lev):
            z=order[start::2**lev]
            xb=sum(1<<v for v in z[::2]);yb=sum(1<<v for v in z[1::2])
            if not xb or not yb:continue
            nodes+=1
            score=sum(bool((mask & xb) and (mask & yb)) for mask in bits)
            total+=score
            slack=score-2*min(xb.bit_count(),yb.bit_count())
            if slack<0:bad.append((lev,start,slack))
            min_slack=slack if min_slack is None else min(min_slack,slack)
    return total,nodes,bad,min_slack

def scan(n,demand):
    cases=0; nodes=0; badnodes=0;badcases=0; badtotals=0
    worst_node=None;min_total=None;first_node=None
    for dele in combinations(range(71),n):
        total,n,bad,slack=total_and_nodes(dele)
        cases+=1;nodes+=n;badnodes+=len(bad);badcases+=bool(bad);badtotals+=total<demand
        if bad and first_node is None:first_node={'deleted':dele,'level':bad[0][0],'offset':bad[0][1],'slack':bad[0][2]}
        if worst_node is None or slack<worst_node['slack']:
            worst_node={'deleted':dele,'slack':slack}
        if min_total is None or total<min_total['score']:
            min_total={'deleted':dele,'score':total}
    return {'deletion_sets':cases,'raw_tree_demand':demand,'total_failures':badtotals,
            'minimum_total':min_total,'nodes':nodes,'nodes_failing_raw_cross':badnodes,
            'deletion_sets_with_node_failures':badcases,'minimum_node_slack':worst_node,
            'first_failed_node':first_node}

def integer_nth_root(target,n):
    # Newton decreases from an upper power-of-two bound, then exact comparisons
    # repair any integer termination edge case.
    x=1<<((target.bit_length()+n-1)//n)
    while True:
        nxt=((n-1)*x+target//(x**(n-1)))//n
        if nxt>=x:break
        x=nxt
    while x**n>target:x-=1
    while (x+1)**n<=target:x+=1
    assert x**n<=target<(x+1)**n
    return x

def independent_price():
    scale=10**15; counts=Counter()
    for role in r:
        counts[8*len(role['mask'])+1]+=1
        for piece in role['pieces']:counts[8*len(piece)]-=1
    lo=hi=0
    for base,c in counts.items():
        y=base**99*scale**100
        a=integer_nth_root(y,100)
        b=a if a**100==y else a+1
        lo+=c*(a if c>=0 else b);hi+=c*(b if c>=0 else a)
    lower=F(104*lo,71*scale);upper=F(104*hi,71*scale)
    assert lower>F(128891,1000) and lower<=upper
    return {'scale':scale,'lower_exact':str(lower),'upper_exact':str(upper),
            'strictly_above_bar':True}

def main():
    one=scan(1,334);pair=scan(2,330)
    assert one['deletion_sets']==71 and pair['deletion_sets']==2485
    assert one['total_failures']==pair['total_failures']==0
    assert one['minimum_total']['score']==352 and pair['minimum_total']['score']==337
    assert one['nodes_failing_raw_cross']==230 and pair['nodes_failing_raw_cross']==10942
    assert one['nodes']==2201 and pair['nodes']==77035
    triple,n,bad,slack=total_and_nodes((0,1,2))
    assert triple==324 and triple<328
    result={'one_deletion':one,'two_deletions':pair,
            'triple_0_1_2':{'raw_total':triple,'demand':328,'nodes_failing_raw_cross':len(bad)},
            'newton_root_type_objective':independent_price()}
    (P/'INDEPENDENT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
