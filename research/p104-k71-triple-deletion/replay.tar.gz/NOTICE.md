# Source notice

This packet uses the CrocSwap/integer-mult-bounds Apache-2.0 repository. `LICENSE` is the unchanged license file at both source heads in the README, Git blob `261eeb9e9f8b2b4b0d119366dda99c6fd7d35c64`. Its SHA-256 is in the packet manifest.

The #7943 and #7920 predecessor work is attributed to Clear1nsight and retains the predecessor archive unmodified. The #7869 P104 lower-bound guidance and its original tools are credited to DreamingOfClouds and predecessor authors identified in `source-7943/SOURCES.md` and `source-7943/source/7920/SOURCES.md`. No implication is made that those authors endorse this follow-up.

The added scripts and exposition were prepared with OpenAI Codex assistance. Their exact work scope and numerical limitations are in `README.md`.
