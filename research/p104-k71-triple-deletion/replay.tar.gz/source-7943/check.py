#!/usr/bin/env python3
"""Exact finite controls for paired-deletion capacity; stdlib, one process."""
from __future__ import annotations
import ast
from collections import Counter
import copy
import importlib.util
from fractions import Fraction as F
from itertools import combinations
from math import comb, ceil, log2
from pathlib import Path
import json
import re

HERE=Path(__file__).resolve().parent
K=71
STAGES=set(range(K))

def load_source_functions(path,names,namespace):
    tree=ast.parse(path.read_text())
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
    assert {n.name for n in nodes}==set(names)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
    return namespace

source=load_source_functions(HERE/'source/7869/code/intcaller/ic1.py',{'RJ','rowdefs','turT'},
                            {'Fr':F,'comb':comb,'ceil':ceil,'log2':log2})
coef=load_source_functions(HERE/'source/7869/code/dyadrelay/dr2.py',{'coef'},
                          {'Fr':F,'comb':comb,'_cache':{}})['coef']

def rank(d,J=4):
    return sum(2*(len(range(j,d,2**level))//2)
               for level in range(J+1) for j in range(2**level))

def cap(size,J=4):
    return max(0,min(size,2**(J+1))-1)

def exact_invoice_enclosure(roles,digits=20,display_digits=15):
    """Enclose source type price using only integer 100th-root comparisons."""
    scale=10**digits;counts=Counter()
    for r in roles:
        counts[8*len(r['mask'])+1]+=1
        for p in r['pieces']:counts[8*len(p)]-=1
    def bound(n):
        # x=n**(99/100); x*scale is the root of n**99*scale**100.
        target=n**99*scale**100
        lo,hi=0,(n+1)*scale
        while hi-lo>1:
            mid=(lo+hi)//2
            if mid**100<=target:lo=mid
            else:hi=mid
        assert lo**100<=target<hi**100
        return lo,lo if lo**100==target else hi
    lower=upper=0
    for n,c in counts.items():
        a,b=bound(n)
        lower+=c*(a if c>=0 else b)
        upper+=c*(b if c>=0 else a)
    low=F(104*lower,71*scale); high=F(104*upper,71*scale)
    assert low<=high
    display_scale=10**display_digits
    low_int=low.numerator*display_scale//low.denominator
    high_int=-(-high.numerator*display_scale//high.denominator)
    def fmt(x):return f'{x//display_scale}.{x%display_scale:0{display_digits}d}'
    return {'lower_exact':str(low),'upper_exact':str(high),
            'lower_outward_15':fmt(low_int),'upper_outward_15':fmt(high_int),
            'root_comparison_places':digits,'distinct_root_arguments':len(counts),
            'strictly_below_128_891':high<F(128891,1000)}

def build_separator():
    roles=[]
    # Parts and source's assigned MAIN counts, in its dr4 k=71 exact type.
    types=[([27,2,2],[]),([13]+[2]*8,[]),([14,11,2],[]),
           ([10,2,2,2,1],[1]),([9]+[1]*5,[2,3,4,5,6]),
           ([6,2,2,2,1],[7]),([2]*5+[1],[8]),
           ([11],[]),([11],[]),([2]*5,[]),([2]*4+[1],[9]),([2]*3,[])]
    # Deterministic construction pins the two hubs; MAIN 0 is a singleton.
    def assign_pieces(mask,sizes,main):
        assert len(main)==len(set(main)) and set(main)<=set(mask) and all(sizes.count(1)>=len(main) for _ in [0])
        remaining=sorted(set(mask)-set(main)); out=[]; mains=list(main)
        for size in sizes:
            if size==1 and mains:
                out.append([mains.pop(0)])
            else:
                out.append(remaining[:size]);del remaining[:size]
        assert not remaining and not mains and sum(map(len,out))==len(mask)
        return out
    def add(name,mask,sizes,main):
        mask=sorted(set(mask))
        assert len(mask)==sum(sizes)
        roles.append({'name':name,'mask':mask,'pieces':assign_pieces(mask,sizes,main),'main':sorted(main)})
    add('hub-1',range(K),[17]+[2]*27,[])
    add('hub-2',range(K),[31,29]+[2]*5+[1],[0])
    deg=[0]*K
    for idx,(parts,mains) in enumerate(types):
        chosen=set([0,1]+mains)
        target=sum(parts)
        available=sorted(STAGES-chosen,key=lambda s:(deg[s],s))
        chosen.update(available[:target-len(chosen)])
        for s in chosen:deg[s]+=1
        add('medium-%02d'%idx,chosen,parts,mains)
    # Cycle with 5 disjoint edges removed has remaining degree 1 at 0..9,
    # and 2 elsewhere. Its 66 chords give 132 MAINs, exactly filling all
    # stage-MAIN deficits after the other ten MAINs above.
    cut={(0,1),(2,3),(4,5),(6,7),(8,9)}
    chords=[tuple(sorted((i,(i+1)%K))) for i in range(K)]
    chords=[e for e in chords if e not in cut]
    assert len(chords)==66
    for idx,edge in enumerate(chords):
        add('chord-%02d'%idx,edge,[1,1],edge)
        for s in edge:deg[s]+=1
    # Concentrate six pure pairs at each of the two deleted stages; never
    # use the pair (0,1). Remaining 48 pairs balance the other stages.
    for idx in range(60):
        if idx<12:
            pivot=0 if idx<6 else 1
            other=min(range(2,K),key=lambda s:(deg[s],s))
            edge=(pivot,other)
        else:
            edge=tuple(sorted(range(2,K),key=lambda s:(deg[s],s))[:2])
        assert len(set(edge))==2 and set(edge)!={0,1}
        add('pure-pair-%02d'%idx,edge,[2],[])
        for s in edge:deg[s]+=1
    assert len(roles)==140
    return roles

def crossscore(roles,U):
    ordered=sorted(U);total=0
    for level in range(5):
        for j in range(2**level):
            z=ordered[j::2**level]
            X=set(z[::2]);Y=set(z[1::2])
            total+=sum(bool(set(r['mask'])&X) and bool(set(r['mask'])&Y) for r in roles)
    return total

def data(roles):
    ds=Counter(map(lambda r:len(r['mask']),roles))
    hubs=[r for r in roles if len(r['mask'])==71]
    small=[r for r in roles if len(r['mask'])!=71]
    assert len(hubs)==2 and len(small)==138
    assert all(2<=len(r['mask'])<=32 for r in small)
    T=sum(len(r['mask']) for r in small)
    delta=[sum(s in r['mask'] for r in small) for s in range(K)]
    m2=Counter(tuple(r['mask']) for r in small if len(r['mask'])==2)
    assert sum(delta)==T
    nc=ds[2]
    avg70=F(T-76)-F(T,71)
    avg69=F(T-76)-F(2*T,71)+F(nc,comb(71,2))
    one=[sum(cap(len(set(r['mask'])-{s})) for r in roles) for s in range(K)]
    assert all(one[s]==T-76-delta[s] for s in range(K))
    pairs={}
    for s,t in combinations(range(K),2):
        c=sum(cap(len(set(r['mask'])-{s,t})) for r in roles)
        assert c==T-76-delta[s]-delta[t]+m2.get((s,t),0)
        pairs[(s,t)]=c
    assert F(sum(one),71)==avg70
    assert F(sum(pairs.values()),comb(71,2))==avg69
    assert avg70==sum(n*coef(K,70,4,d) for d,n in ds.items())
    assert avg69==sum(n*coef(K,69,4,d) for d,n in ds.items())
    assert source['RJ'](70,4)==rank(70)==334
    assert source['RJ'](69,4)==rank(69)==330
    return dict(T=T,degree_counts={str(k):v for k,v in sorted(ds.items())},delta=delta,n2=nc,
                mean70=str(avg70),mean69=str(avg69),
                one_deletion_failures=sum(x<334 for x in one),
                pair_deletion_failures=sum(x<330 for x in pairs.values()),
                pair_0_1_cap=pairs[(0,1)], pair_0_1_m2=m2.get((0,1),0),
                pair_0_1_raw_tree_crossscore=crossscore(roles,STAGES-{0,1}),
                one_min=min(one),one_max=max(one),pair_min=min(pairs.values()),pair_max=max(pairs.values()))

def all_averages(roles):
    typed=[]
    mains=[0]*K
    for r in roles:
        mask=set(r['mask']);pieces=[set(p) for p in r['pieces']]
        assert set.union(*pieces)==mask and sum(map(len,pieces))==len(mask)
        assert set(r['main']) <= {next(iter(p)) for p in pieces if len(p)==1}
        for s in r['main']:mains[s]+=1
        typed.append((len(mask),tuple(sorted(map(len,pieces),reverse=True)),len(r['main'])))
    assert mains==[2]*K
    assert all(D%2==0 or any(L%2 for L in P) for D,P,y in typed)
    # Independently compare both multiplicities and total MAINs with the
    # literal k=71 type line in the pinned source, not just its degrees.
    source_lines=(HERE/'source/7869/code/dyadrelay/evidence/dr4_k5_71.log.txt').read_text().splitlines()
    at=next(i for i,line in enumerate(source_lines) if line.startswith('k 71 aggIP '))
    raw=source_lines[at+1].strip()
    assert raw.startswith('design: ')
    reported={}
    for term in raw[len('design: '):].split(' + '):
        match=re.fullmatch(r'(?:(\d+)x )?(\d+):([\d|]+)(?: m(\d+))?',term)
        assert match,term
        n=int(match.group(1) or 1);D=int(match.group(2))
        P=tuple(sorted(map(int,match.group(3).split('|')),reverse=True))
        y=int(match.group(4) or 0)
        assert sum(P)==D and (D,P) not in reported
        reported[(D,P)]=(n,y)
    actual={}
    for D,P,y in typed:
        count,main=actual.get((D,P),(0,0));actual[(D,P)]=(count+1,main+y)
    assert actual==reported
    ty=Counter(typed)
    rows=source['rowdefs'](K);bad=[]
    for name,fun,mc,op,rhs in rows:
        lhs=sum((fun(D,P)+mc*y)*n for (D,P,y),n in ty.items())
        if (op=='>=' and lhs<rhs) or (op=='==' and lhs!=rhs):bad.append((name,str(lhs-rhs)))
    tur=sum(comb(D,2)*n for (D,P,y),n in ty.items())-2*comb(71,2)-source['turT'](K)
    assert tur>=0
    ds=Counter(D for D,P,y in typed)
    rowsn=0; subbad=[]
    for d in range(2,72):
        for J in range((d-1).bit_length()):
            lhs=sum(n*coef(K,d,J,D) for D,n in ds.items())
            rhs=rank(d,J)
            assert rhs==source['RJ'](d,J)
            if lhs<rhs:subbad.append((d,J,str(lhs-rhs)))
            rowsn+=1
    spbad=[]
    for u in range(2,71):
        lhs=sum(n*F(comb(K-D,u-D),comb(K,u)) for D,n in ds.items() if D<=u)
        if lhs>2*u-2:spbad.append((u,str(lhs-(2*u-2))))
    pair_counts=Counter()
    for a,b in combinations(range(K),2):
        c=0
        for r in roles:
            membership=[(a in p,b in p) for p in r['pieces']]
            c+=any(x for x,y in membership) and any(y for x,y in membership) and not any(x and y for x,y in membership)
        pair_counts[c]+=1
    assert not bad and not subbad and not spbad
    return {'matches_pinned_k71_type_and_main_totals':True,
            'main_per_stage':mains, 'base_ic1_rows_checked':len(rows),
            'base_ic1_bad_rows':bad,'parity_ok':True,'turan_slack':tur,
            'averaged_subdy_rows_checked':rowsn,'averaged_subdy_bad_rows':subbad,
            'averaged_sparse_rows_checked':69,'averaged_sparse_bad_rows':spbad,
            'piece_separation_histogram':dict(sorted(pair_counts.items())),
            'pair_separation_fewer_than_two':sum(n for c,n in pair_counts.items() if c<2)}

def build_near(original):
    """Enlarge 27 pure pieces from #7920, leaving all separators unchanged."""
    roles=copy.deepcopy(original); changed=[]
    for target,count in [(0,14),(1,13)]:
        for role in roles:
            if not count:break
            if (len(role['mask'])==2 and len(role['pieces'])==1
                and target not in role['mask'] and role['name'] not in changed):
                assert not role['main']
                role['mask']=sorted(role['mask']+[target])
                role['pieces']=[list(role['mask'])]
                changed.append(role['name']);count-=1
        assert count==0
    assert len(changed)==len(set(changed))==27
    for before,after in zip(original,roles):
        assert before['name']==after['name'] and before['main']==after['main']
        if before['name'] in changed:
            assert len(before['pieces'])==len(after['pieces'])==1
            assert set(before['mask'])<set(after['mask'])
        else:assert before==after
    return roles,changed

def build_combined(original):
    """Grow 17 pure pairs by {0,1}, then one pure pair by {0}."""
    roles=copy.deepcopy(original); changed=[]; left=17
    for role in roles:
        if not left:break
        if len(role['mask'])==2 and len(role['pieces'])==1 and not set(role['mask'])&{0,1}:
            assert not role['main']
            role['mask']=sorted(role['mask']+[0,1]);role['pieces']=[list(role['mask'])]
            changed.append(role['name']);left-=1
    assert left==0
    left=1
    for role in roles:
        if not left:break
        if len(role['mask'])==2 and len(role['pieces'])==1 and 0 not in role['mask']:
            assert not role['main']
            role['mask']=sorted(role['mask']+[0]);role['pieces']=[list(role['mask'])]
            changed.append(role['name']);left-=1
    assert left==0 and len(changed)==len(set(changed))==18
    for before,after in zip(original,roles):
        assert before['name']==after['name'] and before['main']==after['main']
        if before['name'] in changed:
            assert len(before['pieces'])==len(after['pieces'])==1
            assert set(before['mask'])<set(after['mask'])
        else:assert before==after
    return roles,changed

def near_checks(roles,expected_subdy_failures):
    typed=[];mains=[0]*K
    for r in roles:
        mask=set(r['mask']);pieces=[set(p) for p in r['pieces']]
        assert set.union(*pieces)==mask and sum(map(len,pieces))==len(mask)
        assert set(r['main']) <= {next(iter(p)) for p in pieces if len(p)==1}
        for s in r['main']:mains[s]+=1
        typed.append((len(mask),tuple(sorted(map(len,pieces),reverse=True)),len(r['main'])))
    assert mains==[2]*K
    assert all(D%2==0 or any(L%2 for L in P) for D,P,y in typed)
    ty=Counter(typed);ds=Counter(D for D,P,y in typed)
    basebad=[]
    for name,fun,mc,op,rhs in source['rowdefs'](K):
        lhs=sum((fun(D,P)+mc*y)*n for (D,P,y),n in ty.items())
        if (op=='>=' and lhs<rhs) or (op=='==' and lhs!=rhs):basebad.append((name,str(lhs-rhs)))
    tur=sum(comb(D,2)*n for (D,P,y),n in ty.items())-2*comb(71,2)-source['turT'](K)
    subbad=[]
    for d in range(2,72):
        for J in range((d-1).bit_length()):
            lhs=sum(n*coef(K,d,J,D) for D,n in ds.items())
            if lhs<rank(d,J):subbad.append((d,J,str(lhs-rank(d,J))))
    spbad=[]
    for u in range(2,71):
        lhs=sum(n*F(comb(K-D,u-D),comb(K,u)) for D,n in ds.items() if D<=u)
        if lhs>2*u-2:spbad.append((u,str(lhs-(2*u-2))))
    hist=Counter()
    for a,b in combinations(range(K),2):
        separated=sum(a in r['mask'] and b in r['mask'] and
                      not any(a in p and b in p for p in r['pieces']) for r in roles)
        hist[separated]+=1
    assert hist=={2:2485}
    # Execute the exact original min-cut/closure routines on this new mask set.
    spec=importlib.util.spec_from_file_location('pinned_7920',HERE/'source/7920/check_allocation.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    packed=[module.role(r['name'],r['pieces'],r['main']) for r in roles]
    assert module.flow_controls()==25
    sparse=module.sparse_max(packed);closed=module.closure_counts(packed)
    assert max(sparse)==-2 and max(closed)==0
    nodes=[]
    for level in range(7):
        for j in range(2**level):
            X=set(range(j,K,2**(level+1)));Y=set(range(j+2**level,K,2**(level+1)))
            if not X or not Y:continue
            def crosses(r):return bool(r['mask']&X and r['mask']&Y)
            raw=sum(crosses(r) for r in packed)
            f=sum(crosses(r) and not any(X<=p and p&Y for p in r['parts']) for r in packed)
            b=sum(crosses(r) and not any(Y<=p and p&X for p in r['parts']) for r in packed)
            need=2*min(len(X),len(Y))
            nodes.append((raw-need,f-need,b-need))
    assert all(min(a,b,c)>=0 for a,b,c in nodes)
    assert not basebad and tur>=0 and not spbad and len(subbad)==expected_subdy_failures, (basebad,tur,spbad,len(subbad))
    return {'main_per_stage_all_two':True,'base_ic1_rows_checked':len(source['rowdefs'](K)),
            'base_ic1_bad_rows':basebad,'parity_ok':True,'turan_slack':tur,
            'averaged_sparse_bad_rows':spbad,'averaged_subdy_bad_rows_count':len(subbad),
            'averaged_subdy_violations':subbad,
            'pointwise_pair_separation_histogram':dict(hist),'sparse_max_over_all_nonempty_sets':max(sparse),
            'flow_vs_exhaustive_toy_controls':25,'nonempty_combinatorial_closed_stages':sum(bool(x) for x in closed),
            'global_tree_nodes_checked':len(nodes),
            'minimum_global_tree_slack_by_raw_forward_reverse':[min(x[i] for x in nodes) for i in range(3)]}

def main():
    assert [rank(d) for d in [71,70,69,64]]==[338,334,330,320]
    # Correction is indispensable: a 2-role deleted at both stages has
    # capacity 0, while the uncorrected linear expression would be -1.
    toy={'mask':[0,1],'deleted':[0,1],'cap_before':cap(2),
         'uncorrected':cap(2)-2,'correction':1,'cap_after':cap(0)}
    assert toy['uncorrected']+toy['correction']==toy['cap_after']
    original=json.loads((HERE/'source/7920/allocation.json').read_text())['roles']
    baseline=data(original)
    assert baseline['T']==414 and baseline['n2']==128
    assert baseline['mean70']=='23584/71'
    assert F(baseline['mean69'])==F(338)-F(828,71)+F(128,2485)
    # Replace 2 pure 2-roles with 3:3: named neighboring type at T=416.
    basecounts=Counter(len(r['mask']) for r in original)
    basecounts[2]-=2;basecounts[3]+=2
    assert sum(basecounts.values())==140
    assert sum(d*n for d,n in basecounts.items() if d!=71)==416
    named70=sum(n*coef(71,70,4,d) for d,n in basecounts.items())
    named69=sum(n*coef(71,69,4,d) for d,n in basecounts.items())
    assert named70==F(23724,71)>334
    assert named69==F(815906,2485)<330
    # Universal q=2 cap for n2<=138 and q=7 cap for any degree>=2.
    exactlimits={}
    for T in [414,416,417,418,438,439]:
        two=F(T-76)-F(2*T,71)+F(138,2485)
        seven=F(64*T,71)-76+F(414,355)
        exactlimits[T]={'two_deletion_cap_max':str(two),'two_deletion_required':330,
                        'seven_deletion_cap_max':str(seven),'seven_deletion_required':320}
    assert F(exactlimits[417]['two_deletion_cap_max'])<330
    assert F(exactlimits[418]['two_deletion_cap_max'])>=330
    assert F(exactlimits[438]['seven_deletion_cap_max'])==F(113594,355)<320
    assert F(70083,160)>438 and ceil(F(70083,160))==439
    roles=build_separator();fixture=data(roles);avg=all_averages(roles)
    assert fixture['T']==441 and fixture['n2']==126
    assert fixture['one_deletion_failures']==0 and fixture['pair_0_1_cap']<330
    assert fixture['delta'][0]==fixture['delta'][1]==19
    assert fixture['pair_0_1_m2']==0 and fixture['pair_0_1_cap']==327
    near,changes=build_near(original);nd=data(near);nc=near_checks(near,6)
    assert nd['T']==441 and nd['n2']==101
    assert nd['delta'][0]==20 and nd['delta'][1]==17 and nd['pair_0_1_m2']==1
    assert nd['pair_0_1_cap']==329 and nd['pair_0_1_raw_tree_crossscore']==329
    assert nd['one_deletion_failures']==0 and nd['pair_deletion_failures']==1
    combined,combinedchanges=build_combined(original)
    cd=data(combined);cc=near_checks(combined,0)
    assert cd['T']==449 and cd['n2']==110
    assert cd['delta'][0]==24 and cd['delta'][1]==21 and cd['pair_0_1_m2']==1
    assert cd['pair_0_1_cap']==329 and cd['pair_0_1_raw_tree_crossscore']==329
    assert cd['one_deletion_failures']==0 and cd['pair_deletion_failures']==1
    original_invoice=exact_invoice_enclosure(original)
    combined_invoice=exact_invoice_enclosure(combined)
    assert original_invoice['lower_outward_15']=='129.034865989491791'
    assert original_invoice['upper_outward_15']=='129.034865989491792'
    assert combined_invoice['lower_outward_15']=='128.867329776680726'
    assert combined_invoice['upper_outward_15']=='128.867329776680727'
    assert combined_invoice['strictly_below_128_891']
    out={'r4_T414':baseline,'negative_control':toy,
         'neighbor_T416':{'degree_counts':dict(sorted(basecounts.items())),
                          'mean70':str(named70),'gap70':str(named70-334),
                          'mean69':str(named69),'deficit69':str(330-named69)},
         'universal_upper_bounds':exactlimits,'stronger_SUBDY64_T_lower_bound':439,
         'placement_separator':fixture,'placement_source_type_checks':avg,
         'near_pair_saturated_separator':nd,'near_pair_saturated_checks':nc,
         'combined_pair_saturated_separator':cd,'combined_pair_saturated_checks':cc,
         'original_type_invoice':original_invoice,'combined_type_invoice':combined_invoice}
    (HERE/'separator-masks.json').write_text(json.dumps({'roles':roles},indent=2)+'\n')
    (HERE/'near-separator.json').write_text(json.dumps({'changed_roles':changes,'roles':near},indent=2)+'\n')
    (HERE/'combined-separator.json').write_text(json.dumps({'changed_roles':combinedchanges,'roles':combined},indent=2)+'\n')
    (HERE/'result.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
