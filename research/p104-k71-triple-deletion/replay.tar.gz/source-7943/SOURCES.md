# Pinned inputs

- [PR #7920, commit `8b78a7512a46278e37882059c58c2aa0c490213e`](https://github.com/CrocSwap/integer-mult-bounds/tree/8b78a7512a46278e37882059c58c2aa0c490213e/research/p104-k71-hub-cell-capacity). The commit's README gives replay archive SHA-256 `9874201f5cffadca74e09b657080d0bd25be71767fa85b48e103963ec9ad32df`; the identical archive is `source/7920-replay.tar.gz`, with contents under `source/7920/` and its internal `MANIFEST.sha256` verified. Git blob IDs fetched via GitHub's contents API: README `3217f4cbb5d9f813e4f7a8933d4520680d2775d5`, archive `dd5fc9a25c294b56a5948f6a8daec21a2e2c3da0`.
- [PR #7869, commit `06c207a9feb3994a4b987dc3010657b6e85b7956`](https://github.com/CrocSwap/integer-mult-bounds/tree/06c207a9feb3994a4b987dc3010657b6e85b7956/research/p104-lowerbound-guidance). The following files were obtained with `git show 06c207a9...:research/p104-lowerbound-guidance/<path>` from the campaign's existing checkout and copied to `source/7869/`:

```text
4f8d716a5660cbb060ed385708f548b6134009e6a8dce1d073045fc99c707d0a  notes/dyadrelay.md
13c406129fc4666fff8a192a56a1edd410aa82b9fb1b7b9fd9c57d64b06d4fd9  notes/intcaller.md
822a382c5758cb5c36a3ec28183324f14973a14e9a595c7ccaa109a007715b94  code/intcaller/ic1.py
b3e7e89046deff6273fe32fae4179d124f219a5a5a611efe417a8cd2d1a99f0e  code/dyadrelay/dr2.py
6b8515a90b8012a8ac3c7cb2f47d8b9e852b0601276eff62d7b98c760e88e7e3  code/dyadrelay/dr4.py
93c1a453ddd057d2d03f83bc813c3d012fb159ce7cab51eb6aa4f5162a39d3ae  code/dyadrelay/evidence/dr4_k5_71.log.txt
```

`dyadrelay.md` supplies the arbitrary-set local tree and averaged SUBDY claims; `dr2.coef` and `ic1.RJ` are exact independent source controls; `ic1.rowdefs` defines the base type rows; `dr4.py` defines averaged SPARSE; the k=71 line of the log supplies the exact separator type, including pieces and MAIN counts. The source package, along with #7920's internal notices, is research evidence; those works remain credited to their original authors. No public contribution or application write is made by this stream.
