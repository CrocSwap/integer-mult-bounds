# Pinned source receipts

The following files are from `research/p104-lowerbound-guidance/` at
`CrocSwap/integer-mult-bounds` commit `06c207a9feb3994a4b987dc3010657b6e85b7956`
(PR #7869). The checkout and the files were verified unmodified when read.

```text
13c406129fc4666fff8a192a56a1edd410aa82b9fb1b7b9fd9c57d64b06d4fd9  notes/intcaller.md
4f8d716a5660cbb060ed385708f548b6134009e6a8dce1d073045fc99c707d0a  notes/dyadrelay.md
9a732a0306a9b518b065721e1370a9edf7b10fc1ffe5b0f055361f44258d1ea1  code/intcaller/evidence/ic4_parity.log.txt
822a382c5758cb5c36a3ec28183324f14973a14e9a595c7ccaa109a007715b94  code/intcaller/ic1.py
b3e7e89046deff6273fe32fae4179d124f219a5a5a611efe417a8cd2d1a99f0e  code/dyadrelay/dr2.py
```

The #7899 `public/` receipt, at the supplied head
`dc175797eeb89a1551d39f6cd6be149468b55623`, supplies the pair-saturation
consequence used here and explicitly distinguishes its local placement from a
global frame. Relevant supplied artifacts and their SHA-256:

```text
bffe6d4699f87efa37a88835ccb07bd5633ac39554246baa5559cbce478ee240  README.md
bca8a41d4371ebfe5a4c9d743aeacd1bdffb179169d3c37ad94193a9c7ed0167  SOURCES.md
24b69e6cba1238f3687eb56f6f6a42c3db1ff58030dd3c458664abbc08490bf1  check_local.py
```

The original `dr2.py` coefficient and `ic1.RJ` functions were imported with
`highspy` replaced by an empty stub because that optional solver module is not
installed. Those exact arithmetic functions do not use the solver. The
standalone check in `subdy.py` recomputes the coefficients independently.
