#!/usr/bin/env python3
"""Exhaust the 8-vertex scaled rook-graph model. Pure Python, one process."""
from itertools import combinations
from collections import Counter
import json, time
n=8
pairs=list(combinations(range(n),2))
def blocks(max_size):
    return [sum(1<<i for i in c) for m in range(2,max_size+1) for c in combinations(range(n),m)]
def blockpairs(max_size):
    s=blocks(max_size)
    return [(0,0)]+[(0,x) for x in s]+[(x,y) for i,x in enumerate(s) for y in s[i:] if not (x&y)]
def edges(block):
    return sum(1<<i for i,(a,b) in enumerate(pairs) if (block>>a)&(block>>b)&1)
def partition_edges(ps):return sum((edges(x) for x in ps),0)
def matchings(items):
    if not items:
        yield []
        return
    a,*rest=items
    for b in rest:
        for z in matchings([v for v in rest if v!=b]):yield [(a,b)]+z

def qpartitions():
    for singles in combinations(range(n),2):
        rest=[i for i in range(n) if i not in singles]
        for matched in matchings(rest):
            yield [sum(1<<i for i in p) for p in matched]+[1<<i for i in singles]

def run():
    start=time.monotonic()
    As=blockpairs(4); Bs=blockpairs(8)
    assert len(As)==1940 and len(Bs)==2285
    aedges=[partition_edges(a) for a in As]; bedges=[partition_edges(b) for b in Bs]
    allpairs=(1<<len(pairs))-1
    # Q has parts 2,2,2,1,1.  By relabelling it suffices to fix one
    # partition while enumerating all labelled hub partitions.
    Q=[3,12,48,64,128]
    need=allpairs ^ partition_edges(Q)
    pass1=0; noncolumn=0
    for ae in aedges:
        missing=need & ~ae
        for b,be in zip(Bs,bedges):
            if missing & ~be:continue
            pass1+=1
            if 255 not in b:noncolumn+=1
    # A common B block for the 4|4 and 2|2|2|1|1 roles:
    # P- and Q-separated pairs need a second (A) layer.
    P=[15,240]; psep=allpairs ^ partition_edges(P)
    pass2=0; qcount=0
    for q in qpartitions():
        qcount+=1; need2=psep & (allpairs ^ partition_edges(q))
        for ae in aedges:
            if not (need2 & ~ae):pass2+=1
    # Sharpness: 4|4 pieces can live on two hub columns, and can
    # coexist with a 4|4 role on one common column, using two A rows.
    A=[15,240]; B=[51,204]; Qwide=[195,60]
    assert not ((allpairs ^ partition_edges(Qwide)) & ~(partition_edges(A)|partition_edges(B)))
    Bsame=[255]; Pwide=[51,204]
    assert not (((allpairs ^ partition_edges(Qwide)) & (allpairs ^ partition_edges(Pwide))) & ~partition_edges(A))
    assert qcount==420 and noncolumn==0 and pass2==0
    return {'n':n,'A_block_limit':4,'B_block_limit':8,'Q_piece_sizes':[2,2,2,1,1],
            'A_hub_partitions':len(As),'B_hub_partitions':len(Bs),'fixed_Q_pass':pass1,
            'fixed_Q_pass_not_single_B_block':noncolumn,'all_Q_partitions':qcount,
            'same_B_P_Q_pass':pass2,'wide_part_positive_control':True,
            'elapsed_seconds':round(time.monotonic()-start,3)}
if __name__=='__main__':print(json.dumps(run(),indent=2))
