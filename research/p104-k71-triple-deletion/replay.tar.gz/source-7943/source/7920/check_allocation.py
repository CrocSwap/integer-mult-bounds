#!/usr/bin/env python3
"""Check one labelled k=71 necessary-condition allocation; not a caller proof."""
from collections import Counter,deque
from itertools import combinations,product
import json, random, time, sys
from pathlib import Path
K=71
BASE=Path(__file__).resolve().parent

def role(name, parts, main=()):
    parts=tuple(frozenset(p) for p in parts)
    assert all(parts)
    mask=frozenset().union(*parts)
    assert sum(map(len,parts))==len(mask)
    assert set(main)<=mask
    assert all(any(p==frozenset([s]) for p in parts) for s in main)
    return {'name':name,'mask':mask,'parts':parts,'main':frozenset(main)}

def matching_adj(z):
    z=list(z); assert len(z)%2==0
    return [(z[i],z[i+1]) for i in range(0,len(z),2)]
def matching_shift(z):
    z=list(z); assert len(z)%2==0
    return [(z[(i+1)%len(z)],z[(i+2)%len(z)]) for i in range(0,len(z),2)]

def build(pure):
    Qparts=[range(0,8),range(8,16),range(16,24),range(24,30),range(30,32)]
    A1=range(32,48); A2=range(48,64)
    roles=[role('hub-A',[A1,A2]+[[i] for i in list(range(32))+list(range(64,71))],list(range(32))+list(range(64,71))),
           role('hub-B',[range(0,32),range(32,64)]+[[i] for i in range(64,71)],range(64,71)),
           role('Q-32',Qparts),role('P-32',[A1,A2])]
    chord=[]
    for j,A in enumerate([A1,A2]):
        for i,m in enumerate([matching_adj(A),matching_shift(A)]):
            roles.append(role(f'R16-{j}-{i}',m));chord += m
    for i,p in enumerate(Qparts[:3]):
        m=matching_adj(p);roles.append(role(f'R8-{i}',m));chord+=m
    m=matching_adj(Qparts[3]);roles.append(role('R6',m));chord+=m
    chord+=matching_adj(Qparts[4]);assert len(chord)==48
    for i,(a,b) in enumerate(chord):roles.append(role(f'chord-{i}',[[a],[b]],[a,b]))
    assert len(pure)==80
    for i,(a,b) in enumerate(pure):roles.append(role(f'pure-{i}',[[a,b]]))
    return roles

class Dinic:
    def __init__(self,n):self.g=[[] for _ in range(n)]
    def add(self,u,v,c):
        a=[v,c,None];b=[u,0,a];a[2]=b;self.g[u].append(a);self.g[v].append(b)
    def maxflow(self,s,t):
        flow=0;n=len(self.g)
        while True:
            level=[-1]*n;level[s]=0;q=deque([s])
            while q:
                u=q.popleft()
                for v,c,_ in self.g[u]:
                    if c and level[v]<0:level[v]=level[u]+1;q.append(v)
            if level[t]<0:return flow
            it=[0]*n
            def send(u,f):
                if u==t:return f
                while it[u]<len(self.g[u]):
                    e=self.g[u][it[u]];v,c,rev=e
                    if c and level[v]==level[u]+1:
                        z=send(v,min(f,c))
                        if z:e[1]-=z;rev[1]+=z;return z
                    it[u]+=1
                return 0
            while (z:=send(s,10000)):flow+=z

def sparse_max(roles,stop_on_violation=False,anchors=range(K)):
    # max_{U contains root} (number of roles with mask subset U - 2|U|)
    # is a maximum-weight closure, found by an integer min cut.
    # Infinite capacity 10000 > total finite capacity (140+142).
    scores=[]
    for root in anchors:
        s,t=K+len(roles),K+len(roles)+1
        f=Dinic(t+1)
        for a in range(K):f.add(a,t,2)
        f.add(s,root,10000)
        for i,r in enumerate(roles):
            u=K+i;f.add(s,u,1)
            for a in r['mask']:f.add(u,a,10000)
        score=len(roles)-f.maxflow(s,t)
        scores.append(score)
        if stop_on_violation and score>-2:break
    return scores

def flow_controls():
    # Compare the closure reduction + Dinic with direct subset enumeration
    # on 25 deterministic toy instances, including larger hyperedges.
    rng=random.Random(317)
    for case in range(25):
        test=[]
        for i in range(12):
            p=rng.sample(range(6),rng.randrange(2,5))
            test.append(role(f'toy-{i}',[p]))
        expected=max(sum(r['mask']<=set(U) for r in test)-2*len(U)
                     for bits in range(1<<5)
                     for U in [[0]+[i+1 for i in range(5) if (bits>>i)&1]])
        got=sparse_max(test,anchors=[0])[0]
        assert got==expected,(case,got,expected)
    return 25

def closure_counts(roles):
    closed=[]
    for t in range(K):
        at={i for i,r in enumerate(roles) if t in r['mask']}
        pt={i:next(p for p in roles[i]['parts'] if t in p) for i in at}
        C={i for i in at if len(pt[i])>1}
        while True:
            D={i for i in C if all(not (pt[i] <= roles[j]['mask']) or j in C for j in range(len(roles)))}
            if D==C:break
            C=D
        closed.append(C)
    return [len(x) for x in closed]

def types(roles):
    return Counter((len(r['mask']),tuple(sorted(map(len,r['parts']))),len(r['main'])) for r in roles)

def allchecks(roles):
    expected=Counter({(71,tuple([1]*39+[16,16]),39):1,(71,tuple([1]*7+[32,32]),7):1,
      (32,(2,6,8,8,8),0):1,(32,(16,16),0):1,(16,tuple([2]*8),0):4,
      (8,(2,2,2,2),0):3,(6,(2,2,2),0):1,(2,(1,1),2):48,(2,(2,),0):80})
    assert types(roles)==expected
    assert [sum(t in r['main'] for r in roles) for t in range(K)]==[2]*K
    histogram=Counter()
    for a,b in combinations(range(K),2):
        z=sum(a in r['mask'] and b in r['mask'] and not any(a in p and b in p for p in r['parts']) for r in roles)
        histogram[z]+=1
    assert histogram=={2:2485},histogram
    degree_checks=Counter()
    for r in roles:
        d=len(r['mask'])
        mod={2:8,6:8,8:8,16:16,32:32}.get(d)
        if mod:
            assert len({x%mod for x in r['mask']})==d,(r['name'],d,mod)
            degree_checks[(d,mod)]+=1
    tree=[]
    for J in range(1,8):
        nodes=[]
        for l in range(J+1):
            for j in range(2**l):
                X=set(range(j,K,2**(l+1)));Y=set(range(j+2**l,K,2**(l+1)))
                if not X or not Y:continue
                def crosses(r):return bool(r['mask']&X and r['mask']&Y)
                c=sum(crosses(r) for r in roles)
                def piece2(r):
                    return crosses(r) and not any(X<=p and p&Y for p in r['parts'])
                def piece2reverse(r):
                    return crosses(r) and not any(Y<=p and p&X for p in r['parts'])
                p=sum(piece2(r) for r in roles);p2=sum(piece2reverse(r) for r in roles)
                need=2*min(len(X),len(Y))
                nodes.append((c,p,p2,need))
        raw=sum(v[0] for v in nodes); need=sum(v[3] for v in nodes)
        cap=sum(max(min(len(r['mask']),2**(J+1))-1,0) for r in roles)
        tree.append({'J':J,'raw':raw,'piece2_forward':sum(v[1] for v in nodes),
                     'piece2_reverse':sum(v[2] for v in nodes),'required':need,'degree_cap':cap,
                     'nodes':len(nodes),'every_node_tight':all(a==b==c==d for a,b,c,d in nodes)})
        if J>=2:assert raw==need==cap and all(a==b==c==d for a,b,c,d in nodes),tree[-1]
    controls=flow_controls()
    sparse=sparse_max(roles);assert len(sparse)==K and max(sparse)==-2
    closed=closure_counts(roles);assert max(closed)==0
    # Deliberately overpack one pair; SPARSE must reject it.
    negative=sparse_max(build([(0,1)]*80),True);assert negative[0]>-2
    return {'type_counts_ok':True,'mains_at_every_stage':2,'separation_histogram':histogram,
            'mod_transversal_counts':{str(k):v for k,v in degree_checks.items()},
            'global_dyadic_nodes':tree,'sparse_max_score_by_anchor_histogram':dict(Counter(sparse)),
            'flow_matches_exhaustive_toy_instances':controls,
            'overpacked_pair_negative_control_score':negative[0],
            'nonempty_combinatorial_closed_stages':sum(bool(x) for x in closed),
            'sparse_check':'all nonempty U by 71 maximum-weight-closure min cuts'}

def cut_score(roles,X,Y):
    X=frozenset(X);Y=frozenset(Y)
    seq=['X' if t in X else 'Y' for t in sorted(X|Y)]
    runs=lambda a:sum(x==a and (i==0 or seq[i-1]!=a) for i,x in enumerate(seq))
    need=2*min(runs('X'),runs('Y'))
    p=sum(bool(r['mask']&X and r['mask']&Y) and not any(X<=p and p&Y for p in r['parts']) for r in roles)
    return p,need

def deletion_witness(roles):
    incidence=[sum(t in r['mask'] for r in roles[2:]) for t in range(K)]
    assert sum(incidence)==414
    t=max(range(K),key=incidence.__getitem__)
    M=[a for a in range(K) if a!=t]
    raw=required=0;first_bad=None
    for l in range(5):
        for j in range(2**l):
            X=set(M[j::2**(l+1)]);Y=set(M[j+2**l::2**(l+1)])
            if not X or not Y:continue
            v=sum(bool(r['mask']&X and r['mask']&Y) for r in roles)
            q=2*min(len(X),len(Y));raw+=v;required+=q
            if v<q and first_bad is None:first_bad={'level':l,'residue':j,'cross':v,'required':q}
    cap=338-incidence[t]
    assert required==334 and raw<=cap<required and first_bad is not None
    return {'removed_stage':t,'nonhub_incidence':incidence[t],'degree_cap':cap,
            'raw_branch_total':raw,'required':required,'first_failed_node':first_bad}

def find_failure(roles):
    for start in range(64):
        W=range(start,start+8)
        for labels in product(range(3),repeat=8):
            X=[t for t,a in zip(W,labels) if a==1];Y=[t for t,a in zip(W,labels) if a==2]
            if not X or not Y:continue
            p,need=cut_score(roles,X,Y)
            if p<need:return {'X':X,'Y':Y,'piece2':p,'required':need}
    return None

def search():
    # Node quotas make the seven depth-0..2 CROSS rows individually tight.
    # Every pair has distinct residues mod 8, so it branches at exactly one.
    quotas={(0,0):10,(1,0):24,(1,1):22,(2,0):6,(2,1):6,(2,2):7,(2,3):5}
    pools={k:[] for k in quotas}
    for a,b in combinations(range(K),2):
        if a%8==b%8:continue
        l=next(j for j in range(3) if (a-b)%(2**(j+1)))
        pools[(l,a%(2**l))].append((a,b))
    for seed in range(7100,17100):
        rng=random.Random(seed);pure=[]
        for node,num in quotas.items():pure+=rng.sample(pools[node],num)
        roles=build(pure);scores=sparse_max(roles,True)
        if seed<7110 or (seed-7100)%100==0:
            print('try',seed,'tested',len(scores),'max',max(scores),file=sys.stderr,flush=True)
        if len(scores)==K and max(scores)==-2:return seed,pure
    raise RuntimeError('no SPARSE allocation in seed range')

if __name__=='__main__':
    s=time.monotonic();seed,pure=search();roles=build(pure)
    checked=allchecks(roles);failure=find_failure(roles)
    assert failure is not None
    def pack(r):return {'name':r['name'],'mask':sorted(r['mask']),'pieces':[sorted(p) for p in r['parts']],'main':sorted(r['main'])}
    (BASE/'allocation.json').write_text(json.dumps({'seed':seed,'roles':[pack(r) for r in roles]},indent=2)+'\n')
    (BASE/'result.json').write_text(json.dumps({'checks':checked,'explicit_counterexample_to_sufficiency':failure,'single_deletion_witness':deletion_witness(roles),
         'elapsed_seconds':round(time.monotonic()-s,3)},indent=2)+'\n')
    print(json.dumps({'seed':seed,'checks':checked,'explicit_counterexample_to_sufficiency':failure,'single_deletion_witness':deletion_witness(roles),
         'elapsed_seconds':round(time.monotonic()-s,3)},indent=2))
