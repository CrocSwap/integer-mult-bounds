#!/usr/bin/env python3
"""Exact check of already-published SUBDY, and single-deletion simplification."""
from fractions import Fraction as F
from math import comb,ceil,log2
import json
K=71
DEGREES={71:2,32:2,16:4,8:3,6:1,2:128}

def row(d,J):
    cap=2**(J+1);den=comb(K,d)
    required=sum(2*(len(range(j,d,2**l))//2) for l in range(J+1) for j in range(2**l))
    summands={}
    for D,n in DEGREES.items():
        lo=max(0,d-(K-D));hi=min(D,d)
        summands[D]=n*F(sum(comb(D,i)*comb(K-D,d-i)*max(0,min(i,cap)-1)
                            for i in range(lo,hi+1)),den)
    return sum(summands.values()),required,summands

def main():
    full,fullR,_=row(71,4);one,R,contrib=row(70,4)
    incidence=sum(d*n for d,n in DEGREES.items() if d!=71)
    n_nonhub=sum(n for d,n in DEGREES.items() if d!=71)
    assert incidence==414 and n_nonhub==138 and full==fullR==338 and R==334
    assert one==F(23584,71) and R-one==F(130,71)
    assert one==F(71*338-incidence,71)
    # Broader condition with T total incidence on 138 nonhubs:
    # T <= 71*(T-410) => T >= ceil(29110/70) = 416.
    assert (29110+69)//70==416
    allbad=[]
    for d in range(2,72):
        for J in range(ceil(log2(d))):
            cap,req,_=row(d,J)
            if cap<req:allbad.append((d,J,req-cap))
    assert len(allbad)==217
    a,b,_=row(64,4)
    assert b==320 and a==F(30512274633,102299285)
    return {'degrees':DEGREES,'nonhub_roles':n_nonhub,'nonhub_incidence_T':incidence,
            'J4_full_set_degree_cap':str(full),'J4_full_set_required':fullR,
            'J4_70_stage_required':R,'J4_70_stage_average_cap':str(one),
            'J4_70_stage_average_gap':str(R-one),
            'J4_70_stage_per_degree_contributions':{str(d):str(x) for d,x in contrib.items()},
            'broader_two_full_hub_138_nonhub_T_lower_bound':416,
            'J4_64_stage_required':b,'J4_64_stage_average_cap':str(a),
            'J4_64_stage_average_gap':str(b-a),
            'violated_published_subdy_rows':len(allbad),
            'first_violated_subdy_row':{'d':allbad[0][0],'J':allbad[0][1],'gap':str(allbad[0][2])}}
if __name__=='__main__':print(json.dumps(main(),indent=2))
