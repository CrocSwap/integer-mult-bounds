# The named k=71 branch: hub-cell constraints and a published-row contradiction

This checks exactly the `ic4_parity` k=71 multiset in #7869. Under the
#7869 frame laws it has **no global realization**: a short specialization of
#7869's existing SUBDY law gives a contradiction. This is not a new frame
law, an exclusion of the whole `ic4` tie face, a rerun of the SUBDY integer
optimization, or a new upper bound against 128.891.

The hub-cell analysis also gives an explicit labelled mask/piece allocation
that survives exact pair saturation, all global dyadic tree nodes, and all
SPARSE subsets. It is only a countermodel to sufficiency of those tests. It
is **not** a caller: it fails a PIECE2-CROSS cut and the published SUBDY row.

Source: #7869 commit `06c207a9feb3994a4b987dc3010657b6e85b7956`,
`research/p104-lowerbound-guidance/notes/intcaller.md`,
`notes/dyadrelay.md`, `code/intcaller/evidence/ic4_parity.log.txt`, and
`code/dyadrelay/dr2.py`; and the #7899 follow-up at
`dc175797eeb89a1551d39f6cd6be149468b55623`, as supplied in the round-three
receipt. Source hashes are in `SOURCES.md`. The branch is:

```text
1 × 71:(16,16,1^39), 39 MAIN singletons
1 × 71:(32,32,1^7),   7 MAIN singletons
1 × 32:(8,8,8,6,2)
1 × 32:(16,16)
4 × 16:(2^8)
3 ×  8:(2^4)
1 ×  6:(2,2,2)
48 × 2:(1,1), both pieces MAIN
80 × 2:(2)
```

## Contradiction from one-stage deletions

At depth `J=4`, #7869's local rank-ordered dyadic tree has 70-stage lower
bound `R_4(70)=334`, from ordinary CROSS. The universal per-mask upper bound
is `(min(D,32)-1)^+`, applied to the mask *after* deleting a stage. On the
full 71-stage set, these role caps total

```text
2·31 + 2·31 + 4·15 + 3·7 + 5 + 128 = 338.
```

Let `δ(t)` be the number of the 138 nonhub role masks containing stage `t`.
Delete `t`. Each full hub still contributes at most 31; every nonhub mask
containing `t` loses exactly one unit from its degree cap, including a
2-mask shrinking to one stage. Therefore every stage of any realization
must satisfy

```text
334 ≤ 338 − δ(t),  so δ(t) ≤ 4.
```

Summing the left side over 71 stages gives `sum_t δ(t) ≤ 284`. The fixed
degrees instead give

```text
sum_t δ(t) = 2·32 + 4·16 + 3·8 + 6 + 128·2 = 414 > 284.
```

This is a contradiction by 130 incidences. Equivalently, the published
averaged `SUBDY_70_4` cap is `23584/71`, below 334 by `130/71`.
`subdy.py` computes the exact hypergeometric row independently and checks
all published `(d,J)` ranges: this multiset violates 217 of those rows.
Its `SUBDY_64_4` cap is `30512274633/102299285 < 320`. As a separate check,
we invoked the source `dr2.coef` and `ic1.RJ` directly after stubbing the
unavailable, unneeded `highspy` import; they returned `23584/71` and 334.
No solver was invoked in that cross-check.

The same deletion calculation gives a broader **necessary** condition.
With exactly two full 71-stage hubs, 138 other roles of degrees 2..32, and
nonhub total degree `T`, the full degree cap is `T-76`; after deleting `t`
it is `T-76-δ(t)`. The 70-stage bound implies

```text
δ(t) ≤ T-410;    T = sum_t δ(t) ≤ 71(T-410);
therefore T ≥ 416.
```

This applies within those stated structural assumptions. It does not by
itself establish that total degree 416 is achievable or price the effect of
changing role types.

## Hub-cell facts from pair saturation

Let the two 16-pieces of the first hub be rows `A1,A2`, and the two
32-pieces of the second hub be columns `B1,B2`; remaining pieces are
singletons. #7899 establishes that the named branch has exactly two
separators per pair. After subtracting the two hubs, the capacity of a pair
is exactly

```text
[same A piece] + [same B piece].
```

Write `Q` for the 32-role with largest piece 8 and `P` for the 32-role with
two 16-pieces. The following are necessary placement facts for this branch:

1. **Q's mask is B1 or B2.** If a Q stage is a singleton of the B hub, at
   least 24 other Q stages must share its A piece, which has at most 15
   other stages. If a Q stage is an A singleton, all Q stages outside its B
   piece must share its Q piece, so its B piece contains at least 25 stages.
   If there were even one Q stage outside that B piece, at least 18 of those
   25 would have to share that stage's A piece, again impossible. Otherwise,
   if Q is not a whole B piece it lies in A1 ∪ A2 and equals that 32-set.
   In its 2×2 grid, every occupied opposite diagonal pair must belong to one
   Q piece, so each such diagonal has at most 8 stages. If both diagonals
   are occupied the total is at most 16; if one is unoccupied the row sizes
   force Q to be a whole B piece. Thus no other placement exists.

2. **P cannot be the same B piece as Q.** Were both masks that B piece, each
   of their stages would have nonhub separation degree at least `16+24=40`,
   requiring membership in an A piece (otherwise capacity degree is 31).
   The two A rows therefore make up that B piece. For any stage, at least
   eight of the opposite P half differ in Q piece, so those eight must be in
   its A row. Consequently both P halves meet each A row in exactly eight
   stages. Opposite halves in different A rows then total 16 stages which
   must all lie in one Q piece, contradicting Q's maximum piece size 8.

3. **P's remaining possibility is highly restricted.** Each P stage has
   separation degree 16, so it must lie in a B piece: an A-only stage has
   only 15 capacity. If P meets both B pieces, it has no A-singleton stage;
   otherwise its opposite half is contained in one B piece and the A-row
   limit forces all of P into it. Thus P equals A1 ∪ A2. Each of the four
   A/B intersections is nonempty, and the two opposite grid diagonals are
   its two P halves. The four intersection sizes are
   `(x, 16-x; x, 16-x)` after reordering. If Q is B1 then `2x ≤ 8`; if Q is
   B2 then `2(16-x) ≤ 8`: the overlapping stages across opposite P halves
   and different A rows must fit in one Q piece. These conditions remain
   necessary, not sufficient.

These facts use no assumption that a candidate caller exists. The
`control.py` exhaustive scaled 8-stage test fixes Q type `(2,2,2,1,1)`,
checks all 1,940 A partitions and 2,285 B partitions, and finds that every
passing Q equals a B block. It then checks all 420 such Q partitions, every
A partition and P type `(4,4)` on a common B block; none pass. Wider Q pieces
of size 4 give positive controls for both conclusions, so the size bound is
used rather than silently assumed.

The #7899 global dyadic cap and tightness also imply each A or B hub piece
has at most one stage per residue mod 32: otherwise a deepest node would
have a singleton child trapped in that piece. Thus each 32-stage B piece
uses every residue exactly once; the seven B-singletons occupy the third
stage in residues 0..6. The allocation below enforces these exact residue
and node constraints, rather than just the degree-only cap.

## A surviving labelled relaxation and its limits

`allocation.json` contains 140 fully labelled roles with stages 0..70.
Its structural choices are especially simple:

- `B1=0..31`, `B2=32..63`, B-singletons `64..70`;
- `A1=32..47`, `A2=48..63`, A-singletons are the other 39 stages;
- Q occupies B1 with pieces `0..7`, `8..15`, `16..23`, `24..29`, `30..31`;
- P occupies B2 and has pieces A1,A2; two 16-roles occupy each A row,
  with complementary internal pair matchings; the three 8-roles and one
  6-role occupy the first four Q pieces;
- 48 chords fill the omitted pair separations, and 80 pure 2-roles are
  chosen reproducibly by the script.

As an external cross-check, #7899’s exact type verifier accepts all 357 q0
rows and encloses the invoice in `[129.034865989491791, 129.034865989491792]`;
those rows do not include every SUBDY row (`external-source-checks.txt`).

`check_allocation.py` checks exactly:

- the full type and MAIN multiset, and two MAINs per stage;
- separation count exactly 2 for all `C(71,2)=2,485` pairs;
- the degree 2/6/8 masks use distinct residues mod 8, the 16-masks mod 16,
  and the 32-masks mod 32;
- every nonempty node in the original 71-stage dyadic tree is tight for raw
  CROSS and both orientations of PIECE2-CROSS, through J=7;
- combinatorial closure is empty at all stages;
- SPARSE on *every* nonempty stage subset by maximum-weight closure and 71
  exact integer min cuts. The flow routine matches exhaustive subset search
  on 25 small instances and rejects a deliberately overpacked pair.

These checks do not make an algebraic frame. In fact, the explicit cut
`X={3,6}`, `Y={5,7}` has PIECE2 score 3 < 4. Moreover, deleting stage 36
leaves an actual J=4 dyadic-tree total 328, bounded by cap 328, below the
required 334. The universal deletion proof above shows that no alternate
allocation of the same types can repair all subset trees.

## Reproduce

Only Python 3's standard library is needed. In this directory:

```sh
python3 control.py > control-result.json
python3 subdy.py > subdy-result.json
python3 check_allocation.py
```

The last command regenerates `allocation.json` and `result.json`; it runs one
process and searches deterministic seeds beginning at 7100. The checked run
uses seed 7102. `control.py` reports its runtime, so its JSON timestamp-like
runtime field may differ on rerun.
