# Two-stage deletions in the k=71, two-hub branch

## Result and scope

For a 71-stage source frame, assume exactly two roles have full 71-stage masks and exactly 138 other roles have masks of degrees between 2 and 32. Let `T` be the sum of the latter degrees, `δ(s)` their number containing stage `s`, and `m₂(s,t)` the number whose entire mask is `{s,t}`. The existing rank-ordered local-tree CROSS law in #7869 gives, for every distinct `s,t`,

```text
330 = R₄(69) ≤ T − 76 − δ(s) − δ(t) + m₂(s,t).                 (1)
```

This is a pointwise consequence of the existing local-tree law, not a new frame theorem. Averaging (1) is *exactly* the existing `SUBDY_69_4` type row for this degree range:

```text
330 ≤ T − 76 − 2T/71 + N₂/2485,  N₂ = # degree-2 nonhubs.      (2)
```

Because `N₂ ≤ 138`, (2) gives `T ≥ 418`. However `SUBDY_64_4` already implies the **stronger `T ≥ 439`** under these same assumptions. See the derivation below. Neither result excludes arbitrary k=71 types, nor gives an invoice or κ bound. The degree restriction excludes in particular any nonhub of degree 33..70; the exact number and two 71-stage hubs matter.

The pointwise row still rules out a particular *placement* passing all 430 `ic1` type rows, the 370 existing averaged `SUBDY` rows, the 69 averaged `SPARSE` rows, parity, Turán, two MAINs per stage, exact separation of every stage pair, all 71 one-stage `J=4` deletion caps, all global tree nodes through `J=6` in raw and both PIECE2 orientations, and pointwise SPARSE. It is a neighbor of the #7920 allocation, with `T=449`. Deleting stages `0,1`, their nonhub incidences are 24 and 21 and `m₂(0,1)=1`, so the capacity is **329 < 330**. The actual raw tree crossing count is also 329. This literal mask/piece placement is a feasible point of precisely the listed relaxation, not a legal algebraic frame; a different placement of its type remains open.

The source type invoice for this example is rigorously enclosed in `[128.867329776680726, 128.867329776680727]`, below the campaign bar 128.891. It therefore demonstrates a strict placement-level distinction in the listed relaxation, but does not affect the unsolved above-bar k=71 types or prove an achievable κ result.

## Exact derivation

For a chosen stage set `U` with 69 elements, #7869 sums CROSS over the local rank-ordered tree through depth `J=4`. The demand is

```text
R₄(69) = 68 + 68 + 66 + 64 + 64 = 330.
```

For any role with `i` mask stages in `U`, its total tree contribution is at most `f(i) = max(0,min(i,32)−1)`. Each full hub contributes at most 31. On the original stage set, every other role with degree `D∈[2,32]` has cap `D−1`, hence the total is `62+(T−138)=T−76`. Deleting `s,t` reduces that nonhub cap by the number of deleted incidences **except** for a degree-two role whose entire mask is deleted: then subtracting two would give `−1`, while its true cap is `0`. Restoring one for each such role gives (1).

For the original T=414 type, the source allocation independently has `N₂=128`. Its 71 one-stage and 2,485 two-stage caps average exactly `23584/71` and `811078/2485` respectively; 53 one-stage and 2,148 two-stage caps fall below their demands. These are checks on the saved allocation, and the type-averaged equalities do not depend on placement. The one-stage requirement is `R₄(70)=334`, with average cap `23584/71` as in #7920.

As a specific neighboring type, replace two pure `2:(2)` roles in #7920's type by two pure `3:(3)` roles, leaving all other roles and pieces unchanged. This has the prescribed two hubs and 138 nonhubs, `T=416`, `N₂=126`. Its one-deletion averaged cap is `23724/71 = 334 + 10/71` and therefore passes `SUBDY_70_4`; its two-deletion averaged cap is `116558/355 = 330 − 592/355` and therefore violates `SUBDY_69_4`. This defines a degree/piece multiset, not an alleged feasible frame.

The pointwise conditions also exclude `T=416` directly: the one-deletion row forces each `δ≤6`, while their total is 416, so at least 61 stages have `δ=6`. On each of their pairs, (1) requires `m₂(s,t)≥2`, forcing at least `2·C(61,2)=3660` degree-two roles, versus 138 nonhubs. This is a useful local diagnosis but the averaged #7869 rows already rule out the type.

## Existing stronger seven-deletion bound

Choose uniformly a seven-stage deletion set `S`. The 64-stage tree has `R₄(64)=320`. A nonhub degree `D≤32` has remaining cap `D−1−|mask∩S|+1[mask⊆S]`; a full hub still has cap 31. Therefore the mean cap equals

```text
(64/71)T − 76 + Σ_nonhubs C(7,D)/C(71,D).
```

For every `D≥2`, the containment probability is at most `C(7,2)/C(71,2)`. Consequently

```text
320 ≤ (64/71)T − 76 + 138·21/2485
    = (64/71)T − 76 + 414/355,
T ≥ ceil(70083/160) = 439.
```

At `T=438` even this deliberately loose upper cap is `113594/355 = 320−6/355`. This is a specialization of the existing averaged `SUBDY_64_4` row, with the source's local CROSS/frame hypotheses; it is not a newly discovered general law. It supersedes the `T≥418` consequence when reasoning only about total degree.

## Exact pair-saturated local separator and type invoice

`combined-separator.json` starts from #7920's saved labelled allocation. Enlarge the single piece of 17 pure degree-two roles to include both stages `0` and `1`; enlarge the single piece of one additional pure degree-two role to include stage `0`. The 18 modified role names and every resulting mask, partition and MAIN are frozen in the fixture. The nonhub degree counts are `{32:2,16:4,8:3,6:1,4:17,3:1,2:110}` and total `T=449`. Every change expands a single unsplit pure piece, so it creates no additional piece separation, and all 2,485 pairs still have exactly two. MAINs are unchanged and remain two at each stage.

The checker directly evaluates the full set of 430 source `ic1` type rows, 370 averaged SUBDY rows and 69 averaged SPARSE rows, Turán and parity. It also reruns the original #7920 pointwise SPARSE integer min-cut on the modified placement: its maximum score over all nonempty sets is `−2`, which satisfies `#roles inside U≤2|U|−2`. It checks both PIECE2 orientations as well as raw CROSS at all 70 nonempty global tree nodes up through level 6, finds no combinatorially closed stages, and checks all 71 one-stage caps. Exactly one of 2,485 two-stage caps fails, namely deletion `{0,1}`, with raw crossings `329` against required `330`. The 25 toy flow-versus-exhaustive controls supplied by #7920 also pass. These checks establish a separator against the listed combined relaxation; no claim is made about every possible local PIECE2, event-to-role, algebraic-frame, caller or supplier condition.

The pinned `ic1` objective for a labelled type multiset is

```text
(104/71) · Σ_roles [(8D+1)^(99/100) − Σ_pieces (8L)^(99/100)].
```

`check.py` encloses each term by exact integer comparisons: with `Q=10²⁰`, `a=⌊Q·n^(99/100)⌋` is verified by `a¹⁰⁰≤n⁹⁹Q¹⁰⁰<(a+1)¹⁰⁰`. Positive and negative terms are combined with the appropriate outward endpoints as rational numbers. Rounding those rational endpoints out to 15 places proves the interval above; the same routine reproduces #7920's original `[129.034865989491791, 129.034865989491792]`. This is the source's *type* invoice, not a realized full caller tariff.

As a nearer calibration, `near-separator.json` enlarges 27 pure two-stage pieces by one stage each, giving `T=441`. It preserves pair saturation, all listed global tree/PIECE2 checks, pointwise SPARSE and MAINs, and fails the same pair-deletion row. Unlike the `T=449` example it fails six published averaged SUBDY rows, listed exactly in `result.json`.

## Independent winner-type control

`separator-masks.json` is generated deterministically from the exact type listed in #7869 `dr4_k5_71.log.txt` for k=71. Each role includes a mask, partition and marked singleton MAINs. The construction puts stages 0 and 1 in each of the 12 medium roles and adds 12 pure pairs, six incident to each; there is no degree-2 role on `{0,1}`. The 66 chord roles are the 71-cycle after removing five disjoint edges `(0,1),(2,3),...,(8,9)`; together with the other ten MAIN singletons, they give two MAINs at each stage. Remaining pure pairs are distributed deterministically. All main, degree, partition and type claims are checked from the literal file's construction in `check.py`.

The selected type has degree counts `{71:2, 31:1, 29:1, 27:1, 17:1, 14:1, 13:1, 11:3, 10:1, 9:1, 6:1, 2:126}`. The checker matches every degree, piece multiplicity and total MAIN count against the literal k=71 source log. An exact evaluation of the pinned `ic1.rowdefs` gives zero failed rows; the source `dr2.coef` directly evaluates all 370 averaged SUBDY rows, and a separate rational formula evaluates all 69 averaged SPARSE rows. The checker also computes Turán slack 689 and checks parity. Deleting `{0,1}` gives `19+19` nonhub incidences, no degree-two correction, and a cap of `327<330`; its actual raw tree crossing count is 319. This control has 385 pairs with fewer than two piece separations and is not a legal frame.

## Reproduction and provenance

Run `PYTHONDONTWRITEBYTECODE=1 python3 check.py` in this directory. It uses the Python standard library only; it re-derives both deletion caps for every stage/pair of all four placements, independently checks demand ranks, loads the specified exact arithmetic functions from the pinned source AST, reruns #7920's min-cut and closure routines, checks every source type row, certifies the two invoice intervals, and regenerates `result.json`, `separator-masks.json`, `near-separator.json`, and `combined-separator.json`. It needs no solver and no network.

The #7920 head and #7869 head, archive digest, source filenames, source digests and links are in `SOURCES.md`. The #7920 tarball was fetched at the pinned commit, and its internal manifest verified. The #7869 files were read directly from the specified git commit. `MANIFEST.sha256` records the deliverable and frozen inputs.
