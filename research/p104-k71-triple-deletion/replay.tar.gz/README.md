# Three-stage deletion: an above-bar placement separator at k=71

## Result and limits

Assume a 71-stage local-tree CROSS frame with exactly two full-mask roles and 138 nonhubs, each with degree 2–32. For any three deleted stages `{a,b,c}`, the source #7869's depth-four local tree implies

```text
328 = R₄(68) ≤ T − 76 − δ(a) − δ(b) − δ(c)
                 + m₂(a,b) + m₂(a,c) + m₂(b,c) + m₃(a,b,c).    (1)
```

Here `T` is the sum of nonhub degrees, `δ(s)` is their incidence at `s`, `m₂(a,b)` counts nonhubs with entire mask exactly `{a,b}`, and `m₃(a,b,c)` counts nonhubs with entire mask exactly `{a,b,c}`. This is a pointwise consequence of the **existing** local-tree law, not a new frame theorem. Uniformly averaging (1) is exactly the existing `SUBDY_68_4` row. The scope is the stated two-hub degree family, not every k=71 type.

`placement.json` is a literal labelled example that satisfies the listed finite screens below and violates (1), while its #7869 `Q=0` type objective is enclosed above the campaign bar:

```text
T = 447; δ(0), δ(1), δ(2) = 17, 15, 16
m₂(0,1) = 1; m₂(0,2) = m₂(1,2) = m₃(0,1,2) = 0
cap({0,1,2}) = 447 − 76 − 17 − 15 − 16 + 1 = 324 < 328
raw rank-ordered tree CROSS total on the 68 survivors = 324
128.896193445305629 ≤ type objective ≤ 128.896193445305630
128.891 = comparison bar
```

This example is an **infeasible frame placement**, not an attained legal caller or invoice and not a κ result. In particular, it fails other published local CROSS/PIECE2 requirements. A different placement of the same above-bar type may survive; equation (1) does not exclude the type. No strict claim is made against all source pointwise constraints.

## Derivation and averaged comparison

For any role with `i` survivor stages, its total branches in the depth-four rank-ordered tree are at most `f(i)=max(0,min(i,32)-1)`. The two hubs each have 68 survivors and contribute at most 31. For a nonhub of degree `D∈[2,32]`, deleting a triple `S` gives the exact degree-cap identity

```text
f(|M\S|) = D − 1 − |M∩S| + 1[M⊆S].
```

The correction equals one, rather than two or three, whenever the entire mask was swallowed: the uncorrected expression equals −1 while the true cap is zero. Only degree-two and degree-three masks can be swallowed. The three degree-two counts in (1) and the degree-three count enumerate exactly those nonhubs. The checker includes separate degree-two and degree-three swallowed-mask controls and a partially deleted control. Summing `f` gives the displayed bound, since the original two-hub cap is `62+(T−138)=T−76`. The source tree demand is `68+68+64+64+64 = 328`.

Let `N₂` and `N₃` be the numbers of nonhubs of degrees two and three. Over all 57,155 triples, each nonhub incidence is removed with probability `3/71`, every degree-two mask is swallowed by 69 triples, and each degree-three mask by one. Therefore (1) averages to

```text
SUBDY_68_4:  328 ≤ (68/71)T − 76 + (69N₂ + N₃)/57155.          (2)
```

For the example `N₂=117`, `N₃=0`, and the exact average capacity is `875351/2485`, exceeding 328 by `60271/2485`. The checker independently compares the expression to the pinned #7869 `dr2.coef(71,68,4,D)` row. Thus the averaged type row cannot see this placement defect.

The published #7943 `T=449` example is first calibrated from its hash-verified archive. Its `{0,1}` pair cap is 329 < 330, and it has one failed pair-deletion cap. It also has triple cap 324 at `{0,1,2}`. In contrast, the new example below has no failed pair caps, so a triple is genuinely needed **within this specific capacity-screen comparison**.

## Explicit construction and checks

Start with `source-7943/source/7920/allocation.json` and choose the first eleven labelled non-MAIN pure two-stage roles whose masks avoid `{0,1,2}`. Add all three stages to each mask and to its only piece, retaining its name, one-piece partition and empty MAIN set. The changed role names are in `RESULT.json`. Everything else is unchanged. Their degrees change from 2 to 5; the complete nonhub degree counts become

```text
117 × 2, 11 × 5, 1 × 6, 3 × 8, 4 × 16, 2 × 32.
```

This construction only enlarges existing pure pieces, leaving their pair-separation contribution zero. The original pair-separation and MAIN assignments are therefore preserved. The exact checker nevertheless recomputes the following from the literal data, using the cited parent source routines:

- all 430 `ic1` type rows, parity, Turán, 370 averaged SUBDY rows and 69 averaged SPARSE rows pass;
- all 71 stages have two MAINs, all 2,485 stage pairs have exactly two piece separators, and pointwise SPARSE passes for every nonempty set by 71 exact min cuts; the 25 flow-versus-exhaustive toy controls pass;
- all 70 nonempty nodes of the **original global tree**, through level six, meet raw and both oriented PIECE2-CROSS demands;
- all 71 one-stage deletion caps pass and all 2,485 two-stage deletion caps pass, the latter with minimum 338 versus required 330;
- direct mask-by-mask capacities agree with (1) on all 57,155 triples; precisely one fails, `{0,1,2}`.

A separate implementation checks every one- and two-deletion depth-four **raw tree total**, which also passes: minima 352 ≥ 334 and 337 ≥ 330 respectively. This does **not** establish the node-by-node source laws. There are 230 failed raw nodes among the 2,201 nodes in the one-deletion trees, and 10,942 failed nodes among the 77,035 nodes in the two-deletion trees. For example, delete `{0,1}`: the level-one offset-one node has raw CROSS slack −1. The example therefore is a countermodel to sufficiency of the **listed aggregate and global screens**, not to sufficiency of all pointwise local-node laws.

Separately, the explicit source cut `X={3,6}`, `Y={5,7}` has two alternations, so PIECE2-CROSS requires 4, but the example scores 3. This is a concrete algebraic-frame obstruction beyond the triple cap.

## Price and provenance

The exact source type objective is

```text
(104/71) · Σ_roles [(8D+1)^(99/100) − Σ_pieces (8L)^(99/100)].
```

It applies to the source's stated `Q=0` type model. The primary checker bounds each root by 100th-power integer comparisons at scale `10²⁰` and combines endpoints outward; its lower bound exceeds 128.891 by at least `4609182708746328881/887500000000000000000`. A separate checker uses integer Newton roots at scale `10¹⁵` and independently confirms a lower bound above the bar. The type objective is a relaxation score: it does not establish a realizable algebraic frame, word-level correction, attainable caller invoice, supplier or κ.

Pinned inputs:

- [#7943 at `0d4fdd6875211be0beb134957c3f002c360c6c10`](https://github.com/CrocSwap/integer-mult-bounds/tree/0d4fdd6875211be0beb134957c3f002c360c6c10/research/p104-k71-pair-deletion-screen). The published README and SOURCES.json specify archive SHA-256 `4365578692c4cc79f803e945d17098e45e1fb35515c86eb32014cdbef79b5b2c`. `source-7943.tar.gz` matches it; the extracted internal manifest is checked by `check.py`.
- [#7869 at `06c207a9feb3994a4b987dc3010657b6e85b7956`](https://github.com/CrocSwap/integer-mult-bounds/tree/06c207a9feb3994a4b987dc3010657b6e85b7956/research/p104-lowerbound-guidance). `notes/dyadrelay.md` gives the local-tree law and `dr2.coef` its averaged form; source blob identities for it, `ic1.py`, and `dr2.py` are checked against GitHub reads at the pinned head.
- The #7943 archive contains and identifies the #7920 construction and predecessor attribution; `source-7943/SOURCES.md` records all parent source hashes. `LICENSE` reproduces the source repository's Apache-2.0 license, and `NOTICE.md` records attribution.

From this directory, with Python 3 and no solver or network:

```sh
python3 -I -B check.py > check.log
python3 -I -B independent_check.py > independent.log
```

`RESULT.json` and `INDEPENDENT.json` retain the exact finite outcomes. The source law is a mathematical premise; the scripts check the calculations and literal fixture, not the complete correctness of its published proof. An independent review of the cap derivation and numerical attribution is still appropriate.
