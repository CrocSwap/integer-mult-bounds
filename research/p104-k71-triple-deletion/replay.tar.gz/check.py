#!/usr/bin/env python3
"""Exact k=71 three-stage deletion separator; Python standard library only."""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from itertools import combinations
from math import comb
from pathlib import Path
import copy, hashlib, importlib.util, json

HERE=Path(__file__).resolve().parent
SRC=HERE/'source-7943'
K=71
BAR=Fraction(128891,1000)

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git_blob(path):
    contents=path.read_bytes()
    return hashlib.sha1(b'blob '+str(len(contents)).encode()+b'\0'+contents).hexdigest()

def load_parent():
    assert git_blob(HERE/'LICENSE')=='261eeb9e9f8b2b4b0d119366dda99c6fd7d35c64'
    # Published #7943 receipt, whose archive identity is frozen at the head.
    assert sha256(HERE/'source-7943.tar.gz')=='4365578692c4cc79f803e945d17098e45e1fb35515c86eb32014cdbef79b5b2c'
    # Independently observed GitHub blob IDs at #7869 head.
    source=SRC/'source/7869'
    assert git_blob(source/'notes/dyadrelay.md')=='0c83538743549cdb75114ff0413397911700069f'
    assert git_blob(source/'code/intcaller/ic1.py')=='3f9a5c38a88ccd3a08b1d091b29fac4bc4303fa7'
    assert git_blob(source/'code/dyadrelay/dr2.py')=='cda759a485fcdc9bda3cf312d2ceff0cf45db150'
    # Validate extracted parent inputs against the archive's internal manifest.
    for line in (SRC/'MANIFEST.sha256').read_text().splitlines():
        h, name=line.split('  ',1)
        assert sha256(SRC/name)==h, name
    spec=importlib.util.spec_from_file_location('source7943',SRC/'check.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def make_placement():
    roles=json.loads((SRC/'source/7920/allocation.json').read_text())['roles']
    roles=copy.deepcopy(roles);changed=[]
    for r in roles:
        if len(changed)==11: break
        if len(r['mask'])==2 and len(r['pieces'])==1 and not set(r['mask'])&{0,1,2}:
            assert not r['main']
            r['mask']=sorted(r['mask']+[0,1,2]);r['pieces']=[r['mask'][:]]
            changed.append(r['name'])
    assert len(changed)==len(set(changed))==11
    return {'changed_roles':changed,'roles':roles}

def degree_cap(d):
    return max(0,min(d,32)-1)

def triple_stats(roles, source):
    hubs=[r for r in roles if len(r['mask'])==71]
    small=[r for r in roles if len(r['mask'])!=71]
    assert len(hubs)==2 and len(small)==138
    assert all(2<=len(r['mask'])<=32 for r in small)
    T=sum(len(r['mask']) for r in small)
    ds=Counter(map(lambda r:len(r['mask']),small))
    delta=[sum(s in r['mask'] for r in small) for s in range(K)]
    m2=Counter(tuple(r['mask']) for r in small if len(r['mask'])==2)
    m3=Counter(tuple(r['mask']) for r in small if len(r['mask'])==3)
    masks=[sum(1<<x for x in r['mask']) for r in roles]
    hist=Counter();failures=0; total=0; min_item=None
    for a,b,c in combinations(range(K),3):
        correction=m2[a,b]+m2[a,c]+m2[b,c]+m3[a,b,c]
        derived=T-76-delta[a]-delta[b]-delta[c]+correction
        delete=(1<<a)|(1<<b)|(1<<c)
        direct=sum(degree_cap((mask&~delete).bit_count()) for mask in masks)
        assert direct==derived, (a,b,c,direct,derived)
        hist[direct]+=1;total+=direct
        if direct<328: failures+=1
        if min_item is None or direct<min_item[1]:min_item=([a,b,c],direct)
    assert sum(hist.values())==comb(71,3)==57155
    mean=Fraction(total,comb(71,3))
    formula=Fraction(68*T,71)-76+Fraction(69*ds[2]+ds[3],comb(71,3))
    averaged_source=sum(n*source.coef(71,68,4,d) for d,n in ds.items())+2*source.coef(71,68,4,71)
    assert mean==formula==averaged_source
    assert source.rank(68)==source.source['RJ'](68,4)==328
    abc=(0,1,2)
    correction=m2[0,1]+m2[0,2]+m2[1,2]+m3[0,1,2]
    cap=T-76-sum(delta[x] for x in abc)+correction
    return {'T':T,'nonhub_degree_counts':dict(sorted(ds.items())),
            'delta_0_1_2':[delta[x] for x in abc],
            'swallowed_2_by_pair':[m2[0,1],m2[0,2],m2[1,2]],
            'swallowed_3':m3[0,1,2], 'correction':correction,
            'triple_0_1_2_cap':cap,
            'triple_0_1_2_raw_cross':source.crossscore(roles,set(range(K))-set(abc)),
            'triple_demand':328, 'triples_checked_direct_and_formula':sum(hist.values()),
            'triple_failures':failures, 'minimum_triple':min_item,
            'triple_capacity_histogram':dict(sorted(hist.items())),
            'average_cap':str(mean),'averaged_source_SUBDY_68_4':str(averaged_source),
            'average_slack':str(mean-328)}

def swallowed_controls():
    rows=[]
    for mask,deleted in [({0,1},{0,1,2}),({0,1,2},{0,1,2}),({1,2,5},{0,1,2})]:
        base=degree_cap(len(mask));intersection=len(mask&deleted)
        correction=int(mask<=deleted)
        linear=base-intersection
        actual=degree_cap(len(mask-deleted))
        assert linear+correction==actual
        rows.append({'mask':sorted(mask),'deleted':sorted(deleted),'base':base,'linear_after':linear,
                     'correction':correction,'actual_after':actual})
    assert [x['correction'] for x in rows]==[1,1,0]
    return rows

def main():
    source=load_parent()
    result=make_placement()
    roles=result['roles']
    saved=json.loads((HERE/'placement.json').read_text())
    assert saved==result
    parent=json.loads((SRC/'combined-separator.json').read_text())['roles']
    calibration=source.data(parent)
    assert calibration['T']==449 and calibration['pair_0_1_cap']==329
    assert calibration['pair_deletion_failures']==1
    calibration_triples=triple_stats(parent,source)
    ours=source.data(roles)
    assert ours['T']==447 and ours['one_deletion_failures']==0
    assert ours['pair_deletion_failures']==0 and ours['pair_min']==338
    triple=triple_stats(roles,source)
    assert triple['delta_0_1_2']==[17,15,16]
    assert triple['swallowed_2_by_pair']==[1,0,0] and triple['swallowed_3']==0
    assert triple['triple_0_1_2_cap']==triple['triple_0_1_2_raw_cross']==324
    assert triple['average_cap'] and Fraction(triple['average_cap'])>328
    screens=source.near_checks(roles,0)
    assert screens['pointwise_pair_separation_histogram']=={2:2485}
    assert screens['sparse_max_over_all_nonempty_sets']==-2
    price=source.exact_invoice_enclosure(roles)
    assert Fraction(price['lower_exact'])>BAR
    assert price['lower_outward_15']=='128.896193445305629'
    assert price['upper_outward_15']=='128.896193445305630'
    # A source-listed PIECE2 local cut rejects the candidate as a frame.
    X,Y={3,6},{5,7}
    piece2=sum(bool(set(r['mask'])&X and set(r['mask'])&Y) and
               not any(X<=set(p) and set(p)&Y for p in r['pieces']) for r in roles)
    assert piece2==3
    assert sorted([(s,'X' if s in X else 'Y') for s in X|Y])==[(3,'X'),(5,'Y'),(6,'X'),(7,'Y')]
    out={
      'source_pins':{'7943':'0d4fdd6875211be0beb134957c3f002c360c6c10',
                     '7943_archive_sha256':sha256(HERE/'source-7943.tar.gz'),
                     '7869':'06c207a9feb3994a4b987dc3010657b6e85b7956'},
      'roles_expanded':result['changed_roles'], 'swallowed_controls':swallowed_controls(),
      'calibration_7943_T449_pair':{'deletions_checked':2485,'pair_failures':calibration['pair_deletion_failures'],
                                    'cap_0_1':calibration['pair_0_1_cap'],'demand':330},
      'calibration_7943_triples':calibration_triples,
      'challenger_one_pair_deletions':{'one_failures':ours['one_deletion_failures'],
                                      'pair_checked':2485,'pair_failures':ours['pair_deletion_failures'],
                                      'minimum_pair_capacity':ours['pair_min'],'pair_demand':330},
      'challenger_triples':triple,'inherited_screens':screens,
      'type_objective':price,
      'local_piece2_counterexample':{'X':sorted(X),'Y':sorted(Y),'alternations':2,'score':piece2,'demand':4},
      'scope':'A labelled combinatorial relaxation, not an algebraic frame, legal caller, attained invoice, or κ bound.'}
    (HERE/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
