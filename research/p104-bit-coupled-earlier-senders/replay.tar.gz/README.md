# P104: a joint-sender causal cut for the Pro 2418 seed

This is a bounded negative result. In the fixed-route family below, no choice of the five mutable sender equations permits both owner 113 and owner 114 to be decoded. The result holds even when the two changed earlier senders are granted more input information than their actual stocks contain. It does not establish a new κ bound or exclude other rewrites.

## The family

Use the 680-owner binary word whose compressed SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9` and whose canonical JSON SHA-256 is `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. The prior source packet identifies this word with native source `89a67c404226d51028e135de2b9169e9020d57af` and its baseline with #7830 head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; this packet checks the word hashes, not Git provenance.

- Delete paid packet 2418, originally `330 → 510` at clock 8305.
- Freely recode 2421 from its strictly earlier chart-331 stock `[1979,1985,2295]`, and 2921 from the surviving packet 2421 at chart 510.
- Reuse 2922 as `330 → 1` and freely recode it from the strictly earlier chart-330 stock `[1967,1973,2294]`. The existing source prices the new route at grade 2, versus grade 1 for each removed/replaced original packet. No changed physical realization is claimed here.
- In addition, freely recode two **actual** earlier paid senders on their existing routes: packet 1968 (`274 → 348`, clock 4839, grade 2), and one of the 52 other senders listed in `source/roster53.txt` after omitting 1968. Each new payload must be a linear combination of its own strict-preclock same-chart historical stock, including any effect of the earlier recode on the later stock. All other sender equations and routes are retained.
- Grant free retention of historical stock and arbitrary chart-local linear final decoding. The test only asks for the two demanded rows `x113 + x2` at chart 527 and `x114 + x3` at chart 528. Other output obligations are not needed for the rejection.

For every pair there are 8 × 2 × 8 = 128 choices for the three seed sender equations. Their input rows are recomputed symbolically after **both** earlier sender substitutions, so this is not a sum of separate mutation effects.

## A cross-dependent example with two independent effects

Take packet 857 (`0 → 33`, clock 630, grade 1) and packet 1968. The strict source for 1968 is `[1312,1361,1416,1536,1680,1872]`, and its arrival 1872 depends on the new 857 value. The 857 source contains 524 input rows, including inputs 113 and 114 but excluding input 5. The 1968 source has input 5, but the union of the sources cannot see input 3.

The actual final stock labels at charts 527 and 528, in order, are `[2817,2820,2823,3414; 2465,2469,3317]`. With both packets abstracted as independent symbols, their transfer columns for every one of the 128 seed masks are respectively:

```text
857:   0 1 0 1 | 0 0 0
1968:  0 0 0 1 | 0 1 0
```

These are independent columns, while the source of 1968 can still depend on 857. All 16 × 8 final-decoder pairs fail for each of the 128 seed masks. The primitive verifier classifies the 16,384 cases as 10,240 fixed-equation contradictions, 1,920 incompatible paired equations, 4,096 first-source support failures, and 128 combined-source support failures.

## The exact outer cut

The primitive interpreter independently loads the original instruction tape, records each source before its MOVE, replaces the two senders with symbolic values, and extracts actual terminal stocks before final swaps. It computes the coordinate union `C1` of the first sender's strict source. It also computes `C2`, the coordinate union of the non-symbolic parts of the second source after the first sender has been abstracted. If the second source contains the first sender, any legal second payload is still supported in `C1 ∪ C2`.

For each seed mask and each pair of final-decoder subsets, the two decoder equations are reduced over GF(2). The checker grants the first payload **any** vector supported in `C1`, and independently grants the second **any** vector supported in `C1 ∪ C2`. This enlarges both actual source spaces and discards source correlations, including cross-dependencies. A contradiction in this relaxation is therefore a necessary-condition proof against the actual jointly causal recodes. When an equation has no sender symbol or two equations require different right-hand sides, a nonzero input coordinate separates them. When a required sender expression uses an absent coordinate, that coordinate separates it from the enlarged source support.

The 52 cases comprise 6,656 seed-mask branches and 851,968 local-decoder pairs; 14 of the 52 have a formal first-sender dependency in the 1968 source. Every decoder pair is rejected:

| Reason | Decoder pairs |
|---|---:|
| Fixed-equation contradiction | 535,808 |
| Incompatible paired equations | 134,912 |
| First sender lacks a required coordinate | 174,592 |
| Combined source support lacks a required coordinate | 6,656 |

`primitive-cut.json` has the source labels and rejection counts for every pair, with a histogram of separating coordinates. The first solver in the parent scratch directory also used exact source spans and explicit first-to-second dependency branches; this independently implemented primitive verifier proves the stronger coordinate-support relaxation without importing that solver or its packet graph.

## Controls and reproduction

Python 3.11+ and the standard library suffice. From this directory:

```sh
sha256sum -c SHA256SUMS
python3 -B controls.py
python3 -B verify_primitive.py
```

`controls.py` directly replays the unchanged primitive word and checks all 680 demanded output rows and 2,874 paid MOVEs. It checks that the 857/1968 columns above are independent for all 128 masks and that the strict later source really depends on 857. As a positive check on the two-bank equations, it grants the second sender unrestricted input support and constructs a payload satisfying both bank equations; that payload is outside its real source support. `verify_primitive.py` repeats all 851,968 cut cases and checks the totals.

The prior packet's hypothetical caller recount at κ = 0.00388 priced a 36-call paid delta of −72 grade-1 and +36 grade-2 and obtained binary margin approximately +0.165666, assuming unchanged productive bins. That is a tariff calculation for a hypothetical construction, not a complete invoice for this failed family. No finite realization, erasure, adjoint, full caller replay, or new bound follows from the present cut. Other sender pairs, further changed senders, different routes, and different seed rewrites remain open.
