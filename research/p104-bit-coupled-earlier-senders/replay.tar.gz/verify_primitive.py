#!/usr/bin/env python3
"""Conservative coordinate cut, independent primitive instruction interpreter.
Verifies 52 joint-sender models. No producer packet graph, solver, or source
span reduction is imported. Both changed messages get enlarged input supports;
q2 may use any coordinate visible to either source, allowing cross-dependence.
"""
if not __debug__:raise RuntimeError('Run with assertions enabled')
import gzip,hashlib,json,itertools,collections
from pathlib import Path
N=680;LOW=(1<<N)-1;Q1=1<<N;Q2=1<<(N+1);ZZ=[1<<(N+2+i) for i in range(3)]
P=Path(__file__).resolve().parent/'source'
raw=(P/'WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw))
assert hashlib.sha256(json.dumps(w,separators=(',',':'),sort_keys=True).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
roster=list(map(int,(P/'roster53.txt').read_text().split()));roster.remove(1968)

def xor(xs):
 v=0
 for x in xs:v^=x
 return v

def tape(q):
 v=[1<<i for i in range(N)]+[0]*w['owned_fields'];stock=collections.defaultdict(list)
 for i,c in enumerate(w['start']):stock[c].append(i)
 snapshots={};clock={};route={};first=None;bank=None;ix=0
 for t,(op,p,*args) in enumerate(w['program']):
  if op=='INIT' or op=='CLEAR':v[p]=0
  elif op=='ADD':v[p]^=v[args[0]]
  elif op=='SWAP':
   first=t;bank={c:[v[z] for z in stock[c]] for c in (527,528)}
   banklabels={c:stock[c].copy() for c in (527,528)}
   break
  elif op=='MOVE':
   assert p==N+ix;ix+=1
   a,b=args
   if p==2418:v[p]=0;continue
   if p in (q,1968):
    snapshots[p]=[(i,v[i]) for i in stock[a]];clock[p]=t;route[p]=(a,b);v[p]=Q1 if p==q else Q2
   elif p in (2421,2921,2922):v[p]=ZZ[(2421,2921,2922).index(p)]
   stock[b].append(p)
  else:raise AssertionError(op)
 assert ix==2874 and first==38724 and clock[q]<clock[1968]<8305
 assert banklabels=={527:[2817,2820,2823,3414],528:[2465,2469,3317]}
 assert all(v[z]>>(N+2)==0 for z in (1979,1985,2295,1967,1973,2294))
 return snapshots,clock,route,bank,{z:v[z] for z in (1979,1985,2295,1967,1973,2294)}

def choose(rows):
 out=[0]
 for r in rows:out.extend(x^r for x in out[:])
 return out

def branches(banks,source,m):
 z0=xor(source[x] for j,x in enumerate((1979,1985,2295)) if m[0]>>j&1)
 z1=z0 if m[1] else 0
 z2=xor(source[x] for j,x in enumerate((1967,1973,2294)) if m[2]>>j&1)
 for c,target in ((527,(1<<113)^(1<<2)),(528,(1<<114)^(1<<3))):
  rr=[]
  for v in banks[c]:
   vv=v&((1<<(N+2))-1)
   for zz,tag in zip((z0,z1,z2),ZZ):
    if v&tag:vv^=zz
   rr.append(vv)
  yield [((r>>N)&3,(r&LOW)^target) for r in choose(rr)]

def cut(eq1,eq2,cover1,coverU):
 # This is a coordinate-wise OUTER RELAXATION: w1 can be any vector on
 # cover1 and w2 any vector on coverU; no source correlation is imposed.
 # A rejection therefore also rejects actual strict-preclock messages.
 (c,r),(d,s)=eq1,eq2
 if c==0 and r:return 'fixed',r
 if d==0 and s:return 'fixed',s
 if c==0:c,r=d,s
 elif d and c==d:
  if r^s:return 'incompatible',r^s
  d=0
 if c==0:return None,None
 if d==0 or d==c:
  if c==1:outside=r&~cover1
  else:outside=r&~coverU
  return ('source' if outside else None),outside
 # Distinct nonzero GF(2) rows are independent; derive both payloads.
 if c==1:w1=r;w2=s^(r if d==3 else 0)
 elif d==1:w1=s;w2=r^(s if c==3 else 0)
 elif c==2:w2=r;w1=s^r
 elif d==2:w2=s;w1=r^s
 else:raise AssertionError((c,d))
 outside=w1&~cover1
 if outside:return 'source1',outside
 outside=w2&~coverU
 if outside:return 'source2_outer',outside
 return None,None

results=[];totals=collections.Counter()
for q in roster:
 snap,clock,route,banks,source=tape(q)
 A=snap[q];B=snap[1968]
 assert all(r>>N==0 for _,r in A) and all(r>>(N+1)==0 for _,r in B)
 cover1=0;cover2=0
 for _,r in A:cover1|=r&LOW
 for _,r in B:cover2|=r&LOW
 coverU=cover1|cover2
 dep=[i for i,r in B if r&Q1]
 assert not (coverU>>3)&1
 counts=collections.Counter();unresolved=0;separators=collections.Counter()
 for m in itertools.product(range(8),range(2),range(8)):
  aa,bb=branches(banks,source,m)
  for e1,e2 in itertools.product(aa,bb):
   why,sep=cut(e1,e2,cover1,coverU)
   if why is None:unresolved+=1
   else:
    counts[why]+=1
    separators[(sep&-sep).bit_length()-1]+=1
 assert unresolved==0,(q,unresolved)
 assert sum(counts.values())==128*16*8
 totals.update(counts);totals['models']+=1;totals['branches']+=128;totals['decoder_pairs']+=128*16*8;totals['cross_dep_models']+=bool(dep)
 results.append(dict(sender=q,clock=clock[q],route=route[q],source_labels=[i for i,_ in A],source_1968_labels=[i for i,_ in B],source_1968_dep=dep,counts=dict(counts),separators=dict(separators),unresolved=unresolved))
assert dict(totals)=={'fixed':535808,'incompatible':134912,'source':6656,'models':52,'branches':6656,'decoder_pairs':851968,'cross_dep_models':14,'source1':174592},totals
out=dict(scope='source-coordinate relaxation is larger than actual jointly causal senders; all final bank decoders allowed, 2418 deleted and 2421/2921/2922 recoded with retarget 2922 330-to-1',word_gzip_sha256=hashlib.sha256(raw).hexdigest(),totals=dict(totals),results=results)
Path(__file__).with_name('primitive-cut.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print('PASS primitive coordinate outer relaxation',dict(totals))
print('sha256',hashlib.sha256(Path(__file__).with_name('primitive-cut.json').read_bytes()).hexdigest())
