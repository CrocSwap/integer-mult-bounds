#!/usr/bin/env python3
"""Independent replay of original word and permissive-positive gate control."""
import gzip,json,itertools,collections
from pathlib import Path
p=Path(__file__).with_name('verify_primitive.py')
ns={'__file__':str(p)}
exec(p.read_text().split('results=[];totals=collections.Counter()')[0],ns)
w=ns['w'];n=ns['N'];low=ns['LOW']
v=[1<<i for i in range(n)]+[0]*w['owned_fields'];moves=0
for op,a,*args in w['program']:
 if op in ('INIT','CLEAR'):v[a]=0
 elif op=='ADD':v[a]^=v[args[0]]
 elif op=='SWAP':b=args[0];v[a],v[b]=v[b],v[a]
 elif op=='MOVE':moves+=1
 else:raise AssertionError(op)
assert moves==2874
for i in range(n):
 demand=(1<<i)^((1<<(i-111)) if 111<=i<222 else 0)
 assert v[i]==demand,i
print('PASS original tape: all 680 owners, 2874 paid moves')

snap,clock,route,banks,source=ns['tape'](857)
assert [z for z,r in snap[1968] if r&ns['Q1']]==[1872]
cover1=0;cover2=0
for _,r in snap[857]:cover1|=r&low
for _,r in snap[1968]:cover2|=r&low
assert (cover1>>113)&1 and (cover1>>114)&1 and not (cover1>>5)&1
assert (cover2>>5)&1 and not ((cover1|cover2)>>3)&1
for m in itertools.product(range(8),range(2),range(8)):
 a,b=ns['branches'](banks,source,m)
 sig=[a[1<<i][0] for i in range(4)]+[b[1<<i][0] for i in range(3)]
 assert tuple(int(bool(v&1)) for v in sig)==(0,1,0,1,0,0,0)
 assert tuple(int(bool(v&2)) for v in sig)==(0,0,0,1,0,1,0)
print('PASS cross-dependent source and independent 857/1968 columns for all 128 masks')
a,b=ns['branches'](banks,source,(0,0,0))
c1,r1=a[15];c2,r2=b[7]
# Permissively grant q2 its needed target row from the entire input space.
# The two bank equations have the same RHS and both use q2, so w1=0, w2=r1
# is an exact joint witness. This does not satisfy the actual q2 source.
assert c1==c2==2 and r1==r2
w1=0;w2=r1
assert ((w1 if c1&1 else 0)^(w2 if c1&2 else 0))==r1
assert ((w1 if c2&1 else 0)^(w2 if c2&2 else 0))==r2
cover=0
for _,x in snap[1968]:cover|=x&low
assert (w2&~cover)!=0
why,_=ns['cut']((c1,r1),(c2,r2),low,low)
assert why is None
print('PASS positive control: unrestricted second payload solves both bank equations')
