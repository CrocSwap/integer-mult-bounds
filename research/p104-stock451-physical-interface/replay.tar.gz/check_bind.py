#!/usr/bin/env python3
"""Check one labeled powered path and source/stock contracts, without tensor expansion.

This is an interface diagnostic, not a physical implementation or an exponent proof.
"""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha1, sha256
from itertools import chain
from pathlib import Path
import gzip
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "upstream"))
from powered import PoweredWord
from tagged_sources import binary_ports


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(b):
    return sha256(b).hexdigest()


def canonical(obj):
    return digest(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode())


def file(path, expected):
    data = (HERE / path).read_bytes()
    need(digest(data) == expected, "source bytes: " + path)
    return data


def git_blob(path, expected):
    data = (HERE / "peer" / path).read_bytes()
    actual = sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    need(actual == expected, "peer Git blob: " + path)
    return data


def rejects(label, fn):
    try:
        fn()
    except ValueError:
        return label
    raise AssertionError("corruption survived: " + label)


def bind_helper(row, namespace, clock, address, owner, start, end, grade):
    need(namespace == "09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be", "namespace")
    need(row["caller_clock"] == clock == 4, "caller clock")
    found = [r for r in row["helper"] if r[0] == address]
    need(found == [[address, owner, start, end, grade]], "address/owner/chart/grade")


def check_path(actual, expected):
    need(len(actual) == len(expected) == 451, "factor count")
    need(actual == expected, "ordered caller/clock/bank identities")


def shape(word):
    return [word.ambient, word.power, word.floor, word.low_cut, word.high_cut]


def require_451(word):
    need(shape(word) == [134, 451, 16, 11, 11], "451 powered compiler interface")


def recovery_bound(b):
    need(b >= 1 and Fraction(144, 2 ** (2 * b)) < Fraction(1, 2), "outer conservative recovery bound")


def main():
    # Independently authenticate the local predecessor using #7914's own source manifest.
    origin = json.loads(git_blob("inputs_origins.json", "2819bed06729fed3c199dbbbbe282f0e928dd815"))
    for name in ("powered.py", "periodic.py", "tagged_sources.py"):
        pin = origin["members"]["research/bounded-general-multiplier/" + name]["sha256"]
        file("upstream/" + name, pin)
    for name, blob in {
        "compiler_cut.py": "c4c4ef3f5ec8a7dc4a8853110adf445117c77d0c",
        "ordinary.py": "a24d49ec18f76c6a454c79c4d7cb008b0b35f49b",
        "growing_binary.py": "a004121c0914deb8f91766479a2a049937c07fb6",
        "raw_binary.py": "46932a83c41284bb178f17d0250ab6754e01a55b",
        "MODULE-ATOMS.md": "ecf97ce253a2843207ca9565c1ec84d4380fa296",
        "bound.py": "66328e3fd615038d11894e7e7b7c799bdbe0e41d",
    }.items():
        git_blob(name, blob)
    receipt = json.loads(file("inputs/BIT-451.json", "538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749"))
    baseline = json.loads(gzip.decompress(file("inputs/WORD.json.gz", "d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9")))
    changed = json.loads(gzip.decompress(file("inputs/ZERO-CONTROL-WORD.json.gz", "f0aa75a63cc9200f627721851bd68c27367ae80e7fca2f0fe6f515fe2bfc9f63")))
    caller = json.loads(gzip.decompress(file("inputs/EFREE-CALLER.json.gz", "757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b")))
    tables = json.loads(gzip.decompress(file("inputs/TABLES.json.gz", "5358980ce183a7017084af9532077cbc60594d1f2a0cb386c959d1cdf689da69")))
    old_sha, new_sha = canonical(baseline), canonical(changed)
    need(old_sha == receipt["native"]["candidate_canonical_sha256"], "#7863 source word")
    need(new_sha == "09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be", "#7912 source word")
    need(origin["members"]["research/bounded-general-multiplier/vendor/binary.json.gz"]["sha256"] == digest((HERE / "inputs/WORD.json.gz").read_bytes()), "#7914 binary input")
    need(origin["members"]["research/bounded-general-multiplier/vendor/EFREE-CALLER.json.gz"]["sha256"] == digest((HERE / "inputs/EFREE-CALLER.json.gz").read_bytes()), "#7914 caller input")

    source, altered = binary_ports(baseline, caller), binary_ports(changed, caller)
    need((len(source.targets), len(source.paid)) == (20706, 107460), "source occurrence counts")
    need(Counter(x.rank for x in source.paid) == {int(k): v for k, v in receipt["native"]["paid"].items()}, "complete paid histogram")
    need(shape(source) == [134, 480, 16, 10, 11], "actual source compiler shape")
    require_451(PoweredWord(source.ambient, source.targets, source.paid, 451, 16, 11, 11))
    controls = [rejects("unmodified 480 compiler presented as 451", lambda: require_451(source))]

    idx4 = next(i for i, p in enumerate(source.paid) if p.tag == ("move", 4, 2569, 1402))
    idx4_other = next(i for i, p in enumerate(source.paid) if p.tag == ("move", 4, 2584, 1406))
    idx14 = next(i for i, p in enumerate(source.paid) if p.tag == ("IDLE_ONE", 91, 0))
    need(source.paid[idx4].rank == source.paid[idx4_other].rank == 4 and source.paid[idx14].rank == 14, "actual paid witnesses")
    indices = (idx4,) + (idx14,) * 450
    expected = tuple(source.paid[i].tag for i in indices)
    check_path(expected, expected)
    controls.append(rejects("missing factor", lambda: check_path(expected[:-1], expected)))
    mutant = (source.paid[idx4_other].tag,) + expected[1:]
    controls.append(rejects("same-grade different paid bank/clock", lambda: check_path(mutant, expected)))
    raw_rank = 4 * 14**450
    q10, r10 = divmod(raw_rank, 10**451)
    q11, r11 = divmod(raw_rank, 11**451)
    old_calls, new_calls = q10 + bool(r10), q11 + bool(r11)
    candidate = PoweredWord(134, source.targets, source.paid, 451, 16, 11, 11)
    first = next(candidate.blocks(indices))
    need(first.tags == expected and first.first == 0 and first.rank == 11**451, "first modeled 451 slab")
    need(new_calls < old_calls and str(new_calls) == receipt["partition"]["witness"]["all11_calls"], "actual label split counts")

    def position(w, tag):
        return next(i for i, p in enumerate(w.targets) if p.tag == tag)

    paths = []
    for w in (source, altered):
        paths.append(tuple(chain((position(w, ("helper", 4, 649)),),
                                 (position(w, ("helper", 4, 241)),) * 223,
                                 (position(w, ("root", 9, 0)),) * 2,
                                 (position(w, ("root", 1, 0)),) * 225)))
    old_target, changed_target = source.target(paths[0]), altered.target(paths[1])
    need(old_target.rank == 16**451 and changed_target.rank * 2 == old_target.rank, "451 retained/zero boundary")
    call = next(row for row in tables if row["caller_clock"] == 4)
    bind_helper(call, new_sha, 4, 649, 650, 374, 1, 2)
    controls.append(rejects("candidate helper under old namespace", lambda: bind_helper(call, old_sha, 4, 649, 650, 374, 1, 2)))
    controls.append(rejects("old helper owner misbound to new address", lambda: bind_helper(call, new_sha, 4, 649, 649, 374, 1, 2)))
    corrupt = deepcopy(call)
    row = next(x for x in corrupt["helper"] if x[0] == 649)
    row[1] = 649
    controls.append(rejects("corrupted original owner", lambda: bind_helper(corrupt, new_sha, 4, 649, 650, 374, 1, 2)))
    recovery_bound(5)
    controls.append(rejects("outer bound with four radix bits", lambda: recovery_bound(4)))

    spec = importlib.util.spec_from_file_location("peer_bound", HERE / "peer/bound.py")
    bound = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bound)
    h451 = receipt["uniform"]["H"]
    need(h451 == 1202400000000000 and bound.H == 240000000000000, "dimension logs")
    need(receipt["cover_and_stock"]["q_condition"] == "odd prime q > 2^52*N^5 avoiding frozen finite catalogue witnesses", "cover requirement")
    need(3 < 2**52 and h451 > 0, "ternary q cannot meet stated 451 prime lower bound")
    rates = [Fraction(x["claim"]) for x in receipt["cover_and_stock"]["stages"]]
    need(len(rates) == 7 and max(rates) < bound.HIGH, "candidate seven rates fit peer eta only")
    k_candidate = Fraction("0.00387992804346")
    gap = k_candidate - bound.STAGES[-1]
    need(gap > 0, "six-stage rate below candidate consumer")
    cuts = bound.entrance_logs(h451)
    hypothetical = [cuts[0] + j * (12 + 2 * h451) for j in range(8)]
    need(hypothetical[:6] == list(cuts) and hypothetical[6] < 16*h451 < hypothetical[7], "conditional extended entrance arithmetic")

    print(json.dumps({
        "status": "PASS_SCOPED_INTERFACE_MISMATCH_AND_CORRUPTION_CHECKS",
        "source_identity": {"baseline_canonical": old_sha, "changed_canonical": new_sha, "caller_sha256": digest((HERE / "inputs/EFREE-CALLER.json.gz").read_bytes(),), "raw_productive": len(source.targets), "raw_paid": len(source.paid)},
        "actual_receiver_shape_ambient_power_floor_low_high": shape(source),
        "required_451_shape": shape(candidate),
        "actual_451_paid_path": {"first": list(expected[0]), "tail": list(expected[1]), "tail_repeats": 450, "old_10_cut_slab_count": str(old_calls), "new_11_cut_slab_count": str(new_calls), "first_new_slab_starts_at": first.first, "rank": "11^451"},
        "actual_451_target_boundary": {"legacy_tag": ["helper", 4, 649], "baseline_grade": 4, "changed_grade": 2, "baseline_rank": "16^451", "changed_rank": "16^451/2", "changed_owner_row": [649, 650, 374, 1, 2]},
        "stock_contract": {"peer_field": 3, "candidate_required_exponent": 52 + 5*h451, "q3_meets_candidate_prime_lower_bound": False, "actual_candidate_prime_exhibited": False},
        "precision_screen": {"outer_peer_bound_at_b5": str(Fraction(144, 2**10)), "outer_peer_bound_at_b4": str(Fraction(144, 2**8)), "scope": "check of stated conservative outer bound, not changed-word precision certification"},
        "rates": {"peer_sixth_stage": str(bound.STAGES[-1]), "candidate_consumer": str(k_candidate), "difference_exact": str(gap), "candidate_new_stages": len(rates)},
        "threshold_diagnostic_not_a_proof": {"candidate_H": h451, "source_sixth_log2_E": bound.entrance_logs()[-1], "same_formula_candidate_log2_E1_to_E8": hypothetical, "candidate_log2_N16": 16*h451, "caveat": "E7/E8 extend a six-stage formula; no 451, q-prime, eight-stage admission is proved"},
        "controls_rejected": controls,
        "limitations": ["no 451 tensor or complete physical supplier run", "no live q-prime stock or all-spectator inverse", "no rebound precision tape or integer product", "no kappa transfer"]
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
