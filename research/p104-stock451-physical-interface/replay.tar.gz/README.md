# 451-factor supplier versus the live balanced receiver

**Result: the pinned implementations do not yet bind.** The single-call
binary source and paired caller agree, but the first powered compiler has
different factor count and cutoff rules. Its physical stock is ternary while
the particular #7863 cover certificate requires a much larger fixed prime.
The six installed stage rates also stop below the candidate's claimed consumer
rate. This is a precise interface mismatch, not a proof that a modified
451-factor receiver is impossible, and it gives no new κ.

Sources: [#7914](https://github.com/CrocSwap/integer-mult-bounds/pull/7914)
at `46783fbbfc219a3faffbea76f60a2810b85ab75a`;
[#7863](https://github.com/CrocSwap/integer-mult-bounds/pull/7863) at
`b3e4412fe01f07dc58305616fabf96345f49a781`;
[#7912](https://github.com/CrocSwap/integer-mult-bounds/pull/7912) at
`83ece5a62d3addbee45bad9594ef4809851b833b`. Source-specific peer files have
their Git blob identities checked in `check_bind.py`. The original and
changed graphs, caller, #7863 receipt, and Round 4 call-local owner tables
have byte SHA-256 checks. The Round 4 tables are inherited evidence; this
screen does not rerun their full reconstruction or the 13.1-million-product
rational audit. Earlier authors' code and notices are retained under
`upstream/`, `peer/` and `LICENSE`.

## First actual compiler contract

The peer's `compiler_cut.SourceRule` calls `binary_ports` on the authenticated
original graph and paired caller. That produces 20,706 productive and
107,460 paid **raw** occurrences. The old gzip and caller hashes are
`d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`
and `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`;
the original canonical word is
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
These agree with the #7863 finite receipt. Shared raw occurrences do not
imply a shared powered compiler:

| Interface | #7914 installed source | #7863 finite proposal |
| --- | --- | --- |
| Ambient, factors, floor | `134^480`, `16^480` | `134^451`, `16^451` |
| Paid cuts | `10^480` when first grade ≤ 4, otherwise `11^480` | `11^451` for every ordered paid tuple |
| `log2 N` | `240000000000000` | `1202400000000000` |
| Physical cover in source | `GL_N(F_3)` and lifts modulo `3^u` | recorded fixed odd prime `q > 2^52 N^5`, avoiding the 451 catalogue |
| Stages | six specific stages, last `0.003879928035646` | seven new rate stages above a completed `0.00385248` seed |

The #7914 `Weighted` receiver takes its rule and planner from that actual
480-factor source. Its modulus, high radix, and stock are respectively
`3^u`, `3^(u-1)`, and `B |GL_N(F_3)| 3^(N²(u-1))`. `ordinary_swap`
passes the source's H and requests stage six. The #7863 prime condition
requires `q > 2^6012000000000052`, so the installed `q=3` does not satisfy
that particular certificate. A new proof at 3 could potentially replace the
large-prime cover certificate; a new general-q balanced receiver is another
possibility. Neither proof is supplied here, and the numerical size of an
actual #7863 prime is unknown beyond its lower bound.

## An ordered paid path and an owner boundary

One actual #7863 paid path is the original labeled rank-four occurrence
`(move, 4, 2569, 1402)` followed by 450 copies of the rank-fourteen occurrence
`(IDLE_ONE, 91, 0)`, on distinct tensor factors. Its total raw rank is
`4·14^450`. The exact `11^451` split has
`49155830744717520350444760920956767143210254601` slabs. The comparison
`10^451` split has
`228915946207420362589383707993638476952284397287691869463178608738`.
The checker constructs the first candidate block and independently verifies
the exact quotient and remainder; it does **not** enumerate those slabs,
allocate their owners, invoke the live receiver on them, or execute the
451-fold tensor. Changing a first occurrence to another real grade-four
occurrence is rejected despite the unchanged grade histogram.

For a separate productive boundary, use one `(helper,4,649)`, 223 instances
of `(helper,4,241)`, two `(root,9,0)` and 225 `(root,1,0)`, again on separate
factors. In the baseline their grades are 4, 4, 8 and 64; their product is
exactly `16^451`. In #7912 the same text for the first helper names the
different original owner 650, chart 374→1, grade 2. Its syntactically matching
product is `16^451/2` and becomes an independently owned zero in a 451
construction. The old address was original owner 649, chart 506→1, grade 4.
The changed canonical word is
`09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be`.
The table, namespace, caller clock, address, owner, endpoint charts and grade
must all agree. This is a diagnostic for a possible **changed-word** 451
construction; #7863 itself is the original-word construction.

## Rates, thresholds and precision

The peer's final ordinary stage `0.003879928035646` is below #7863's
candidate consumer κ `0.00387992804346` by exactly
`3907/500000000000000 = 0.000000000007814`. The seven #7863 new stage rates
are all strictly below #7914's component-scan exponent `η=97/25000`, but
that simple inequality is not a rebuilt stage or signed-moment proof. The
source's completed seed must itself be included if it is reused; rebuilding
it from an elementary base requires an additional active stage.

The peer's proven six-stage log2 trit-width entrances end at
`2881869654258596` for its own H. Merely applying its displayed arithmetic
formula to `H_451` gives six projected entrances ending at
`14438166967835273`. Extending that formula without a theorem gives
`log2 E7 = 16842966967835285` and
`log2 E8 = 19247766967835297`, while
`log2(N_451^16) = 19238400000000000`. Thus the peer's simple `N^16`
connected-entry expression would not meet that *hypothetical* eighth
entrance. This comparison is arithmetic, not a 451-specific admission or
impossibility theorem; in particular it does not establish a tail threshold
for a different q, compiler, stock history or activation schedule.

For the existing peer's numerical proof, `b ≥ 5`, `B=2^b`, and its
conservative integer-recovery error bound is `144/B²`. At `b=5` that bound
is `9/64 < 1/2`; at `b=4` it is `9/16`, which does not certify rounding.
Failure of this sufficient inequality does not demonstrate an erroneous
four-bit product. The peer uses the common working grid and widened native
operations in its existing source; Round 4 stream 13's separately audited
ten-edit rational word has a different canonical identity and a 105-bit
scalar product grid. The latter is not the complete Gaussian-frame grid,
and neither receipt certifies a 451-specific changed-word precision tape.

## What remains before an actual product binding

The next proof must instantiate the 451-powered chronological target and paid
tables from their true labels, including fresh zero allocations and retirement,
all split slabs, their physical frame matchers, and both inverse directions on
arbitrary independent spectators. It must select and realize either a new
three-local cover proof or the large-q balanced components; then charge the
full low matrix group, each high fibre, every suspended earlier-stage reserve,
conversion, caller bank, scratch lifetime, restored owner and fixed-head tape.
The desired seven-stage/seed construction and its actual tail threshold need
their own recurrence and strict prices.

Only after those interfaces fit can the genuine complex source's selected
window, CRT shuttles, source-gather return, precision grid, three transforms,
rounding, carry and integer output be rebound and requalified. #7914 supplies
these as a written/executable path for its own six-stage source, with finite
controls at smaller dimensions; this screen does not replay that complete
package. No 451 native path reaching an integer product has been shown.

## Reproduce

Python 3.12.3, one process and standard library:

```sh
python3 -I -B check_bind.py > check.json
cmp check.json RESULT.json
python3 -I -B cold_check.py
```

`COLD.json` records fresh-copy and optimized replays plus separate changes to
the peer source and old compressed graph, both rejected by their byte/Git
bindings. The normal check additionally rejects a missing factor, an
equal-grade wrong occurrence, old/new namespace and owner confusion, a
corrupted owner table, an installed 480-as-451 rule and a four-bit use of
the stated sufficient recovery bound. `cold.resources` records the last run:
3.92 seconds elapsed and 116,384 KiB maximum RSS. The result is a finite
source/identity/cut/precision screen, not a complete physical replay.
