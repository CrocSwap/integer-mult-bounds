#!/usr/bin/env python3
"""Replay in a fresh copy and verify that two physical source corruptions fail."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import shutil
import subprocess
import sys

here = Path(__file__).resolve().parent
with TemporaryDirectory(prefix="stock451-cold-", dir=here) as temp:
    root = Path(temp)
    for name in ("peer", "inputs", "upstream"):
        shutil.copytree(here / name, root / name)
    shutil.copy2(here / "check_bind.py", root / "check_bind.py")

    def run(*flags):
        return subprocess.run([sys.executable, "-I", "-B", *flags, "check_bind.py"],
                              cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    normal, optimized = run(), run("-O")
    expected = (here / "RESULT.json").read_bytes()
    if normal.returncode or optimized.returncode or normal.stdout != expected or optimized.stdout != expected:
        raise ValueError("clean copied replay differs or failed")
    source = root / "peer" / "ordinary.py"
    original = source.read_bytes()
    source.write_bytes(original + b"\n# deliberate corruption\n")
    bad_source = run()
    if bad_source.returncode == 0 or b"peer Git blob: ordinary.py" not in bad_source.stderr:
        raise ValueError("changed peer source passed authentication")
    source.write_bytes(original)
    word = root / "inputs" / "WORD.json.gz"
    raw = bytearray(word.read_bytes())
    raw[-1] ^= 1
    word.write_bytes(raw)
    bad_word = run()
    if bad_word.returncode == 0 or b"source bytes: inputs/WORD.json.gz" not in bad_word.stderr:
        raise ValueError("changed word archive passed authentication")
print(json.dumps({"status": "PASS_COLD_AND_OPTIMIZED_REPLAY", "physical_corruptions_rejected": ["peer/ordinary.py", "inputs/WORD.json.gz"]}, indent=2))
