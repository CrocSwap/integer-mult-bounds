#!/usr/bin/env python3
"""Exact four-ingress information cut for the #7925 literal 469 near miss."""
import gzip, hashlib, importlib.util, json, os, sys
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path

if hasattr(os, 'sched_getaffinity'):
    permitted = os.sched_getaffinity(0)
    if permitted: os.sched_setaffinity(0, {min(permitted)})
here = Path(__file__).resolve().parent
sys.path.insert(0, str(here / 'vendor'))
import binary_operator as op
import price

def readpin(path, digest):
    raw=(here/path).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==digest, path
    return raw
word=json.loads(gzip.decompress(readpin('inputs/WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9')))
receipt=json.loads(readpin('inputs/BIT.json','8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'))
assert op.canonical_hash(word)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
assert op.canonical_hash({k:word[k] for k in ('frames','start','final')})==op.LAYOUT
spec=importlib.util.spec_from_file_location('edge',here/'inputs'/'bit_native.py')
e=importlib.util.module_from_spec(spec);sys.modules[spec.name]=e;spec.loader.exec_module(e)
I,T,moves,rows,clocks=e.extract(word);order=e.schedule(I,T,moves,rows)
value={i:1<<i for i in I}
for k in order:value[k]=e.combine(rows[k],value)
N=word['public']; assert N==680
P=word['program']
assert (P[4294],P[6646:6653],P[9627])==(
 ['MOVE',1862,251,447],
 [['INIT',2239,319],['ADD',2239,1441,319],['ADD',2239,1581,319],['ADD',2239,1769,319],['ADD',2239,1817,319],['ADD',2239,1889,319],['MOVE',2239,319,447]],
 ['MOVE',2753,447,1])
assert {k:(moves[k],clocks[k]) for k in (2748,2751,2754,3454)}=={
 2748:((446,564),9607),2751:((447,564),9619),2754:((448,564),9632),3454:((81,564),23547)}
assert [k for k,(a,b) in moves.items() if b==564]==[2748,2751,2754,3454]
assert not [k for k,c in I.items() if c==564]
assert P[10725:10734]==[['INIT',3060,564],['ADD',3060,2748,564],['MOVE',3060,564,1],['INIT',3061,564],['ADD',3061,2751,564],['MOVE',3061,564,1],['INIT',3062,564],['ADD',3062,2754,564],['MOVE',3062,564,1]]
assert P[32742:32747]==[['INIT',3704,564],['ADD',3704,2748,564],['ADD',3704,2751,564],['ADD',3704,2754,564],['ADD',3704,3454,564]]
assert P[39024:39026]==[['SWAP',150,3704],['CLEAR',3704,0]] and word['final'][150]==564
assert [(t,x) for t,x in enumerate(P) if (x[0] in ('ADD','SWAP') and 3704 in x[1:3]) or (x[0] not in ('ADD','SWAP') and x[1]==3704)]==[(t,P[t]) for t in (32742,32743,32744,32745,32746,39024,39025)]
for packet,uses in ((2748,[10726,32743]),(2751,[10729,32744]),(2754,[10732,32745]),(3454,[32746])):
    assert [t for t,x in enumerate(P) if x[0]=='ADD' and x[2]==packet]==uses

# Replay exactly the #7925 test word: inserted z is the real public test input,
# the retained clean copy is a private field, and all old private addresses shift.
Z=680; clean=N+word['owned_fields']+1; total=clean+1
idx=lambda x:x+1 if x>=N else x
program=[];positions={}
for t,(code,r,*args) in enumerate(P):
    positions[t]=len(program); rr=idx(r)
    if t==4294:
        program += [['MOVE',rr,251,524],['INIT',clean,524],['ADD',clean,rr,524],['ADD',rr,Z,524],['MOVE',rr,524,447]]
    elif 6646<=t<=6651: continue
    elif t==6652:
        program += [['INIT',rr,524],['ADD',rr,clean,524],['MOVE',rr,524,447],['CLEAR',clean,524]]
    elif t==9627: program += [['MOVE',rr,447,601],['MOVE',rr,601,1]]
    else:
        if code in ('ADD','SWAP'):args[0]=idx(args[0])
        program.append([code,rr,*args])
assert len(program)==len(P)+2

cuts=[9607,9632,10725,23547,32742]
revpositions={positions[t]:t for t in cuts}
def replay(reverse=False,mutate=False):
    banks=[1<<i for i in range(N+1)]+[0]*(total-N-1)
    tags=list(word['final' if reverse else 'start'])+[524]+[None]*(total-N-1)
    dirty=retire=0; first=second=None; snapshots={}
    iterable=range(len(program)-1,-1,-1) if reverse else range(len(program))
    for step in iterable:
        if not reverse and step in revpositions:
            snapshots[revpositions[step]]=(banks.copy(),tags.copy())
        code,r,*args=program[step]
        if mutate and [code,r,*args]==['ADD',idx(1862),Z,524]:
            continue
        if code in ('INIT','CLEAR'):
            opens=(code=='CLEAR') if reverse else (code=='INIT')
            if opens: assert tags[r] is None;tags[r]=args[0];banks[r]=0
            else: assert tags[r]==args[0];dirty+=bool(banks[r]);retire+=1;tags[r]=None;banks[r]=0
        elif code=='ADD':
            s,c=args;assert tags[r]==tags[s]==c and r!=s
            if reverse:banks[s]^=banks[r]
            else:banks[r]^=banks[s]
        elif code=='SWAP':
            s=args[0];assert tags[r] is not None and tags[s] is not None
            banks[r],banks[s]=banks[s],banks[r];tags[r],tags[s]=tags[s],tags[r]
        elif code=='MOVE':
            c,d=args[::-1] if reverse else args;assert tags[r]==c;tags[r]=d
            if not reverse and r==idx(1862) and (c,d)==(251,524):
                assert tags[idx(1854)]==524;first=banks[idx(1854)]^banks[idx(1862)]
            if not reverse and r==idx(2753) and (c,d)==(447,601):
                assert tags[idx(2752)]==601;second=banks[idx(2752)]^banks[idx(2753)]
        else:raise ValueError(code)
    assert tags==list(word['start' if reverse else 'final'])+[524]+[None]*(total-N-1)
    assert not any(banks[N+1:])
    return banks[:N+1],dirty,retire,first,second,snapshots
f,fd,fr,first,second,snaps=replay();a,ad,ar,_,_,_=replay(True)
assert first==(1<<468)^(1<<469) and second==1<<680
for j in range(N+1):
    assert a[j]==sum(((f[i]>>j)&1)<<i for i in range(N+1))
expected=[(1<<j)^((1<<(j-111)) if 111<=j<222 else 0) for j in range(N)]+[1<<Z]
bad=[i for i in range(N) if f[i]!=expected[i]]
assert bad==[28,37,150,187,255,289,290,308,309,344,469,513,595,625]
assert f[680]==expected[680]
expected_adjoint=[sum(((expected[i]>>j)&1)<<i for i in range(N+1)) for j in range(N+1)]
adjoint_bad=[i for i in range(N+1) if a[i]!=expected_adjoint[i]]
fm,_,_,firstm,secondm,_=replay(mutate=True);am,_,_,_,_,_=replay(True,mutate=True)
for j in range(N+1):assert am[j]==sum(((fm[i]>>j)&1)<<i for i in range(N+1))
assert firstm==first and secondm==0 and fm[255]==expected[255] and fm[469]==expected[469]
assert secondm!=1<<680
D=value[2239]^value[1862]
assert f[150]^expected[150]==D and f[513]^expected[513]==D and f[577]==expected[577]

def rank(xs):
    basis={}
    for x in xs:
        while x:
            b=x.bit_length()-1
            if b in basis:x^=basis[b]
            else:basis[b]=x;break
    return len(basis)
def solve(items,target):
    basis={}
    for i,x in enumerate(items):
        mask=1<<i
        while x:
            b=x.bit_length()-1
            if b in basis:
                v,q=basis[b];x^=v;mask^=q
            else:basis[b]=(x,mask);break
    mask=0;x=target
    while x:
        b=x.bit_length()-1
        if b not in basis:return None
        v,q=basis[b];x^=v;mask^=q
    return [i for i in range(len(items)) if mask>>i&1]
def dual(rows, wanted):
    basis={}
    for row,rhs in zip(rows,wanted):
        while row:
            b=row.bit_length()-1
            if b in basis:
                x,y=basis[b];row^=x;rhs^=y
            else:basis[b]=(row,rhs);break
        else:assert not rhs
    ans=0
    for b,(row,rhs) in sorted(basis.items()):
        if rhs^((row&ans).bit_count()&1):ans|=1<<b
    assert [((x&ans).bit_count()&1) for x in rows]==wanted
    return ans
support=lambda x:list(e.indices(x))
H0,H1,H2,H3=[value[k] for k in (2748,2751,2754,3454)]
Hprime=value[2085]^value[1862]
T150=H0^H1^H2^H3
assert T150==(1<<39)^(1<<150)
assert [rank(x) for x in ([H0,H1,H2],[H0,H1,H2,Hprime],[H0,H1,H2,T150],[H0,H1,H2,T150,Hprime])]==[3,4,4,5]
assert snaps[10725][0][idx(2751)]==Hprime
for key,when in ((2748,9607),(2754,9632),(3454,23547)):
    assert snaps[when][0][idx(key)]==value[key]
assert [(i-1 if i>N else i) for i,c in enumerate(snaps[10725][1]) if c==564]==[2748,2751,2754]
assert [(i-1 if i>N else i) for i,c in enumerate(snaps[32742][1]) if c==564]==[2748,2751,2754,3454]
# Five explicit test pulses map to the identity on the five rows, with z=0.
five=[H0,H1,H2,T150,Hprime]
pulses=[dual(five,[int(i==j) for i in range(5)]) for j in range(5)]
assert all(not ((v>>680)&1) for v in pulses)
assert [[((r&p).bit_count()&1) for p in pulses] for r in five]==[[int(i==j) for j in range(5)] for i in range(5)]
# Mutation: replacing the actually observed Hprime by old H1 destroys the
# rank-five predicate. A bogus assertion of this proof must be rejected.
mutated=[H0,H1,H2,T150,H1]
assert rank(mutated)==4
try:
    assert rank(mutated)==5
except AssertionError:mutation_rejected=True
else:raise AssertionError('rank-five mutation accepted')

# Exact same-grade, original-dispatch sender/stock roster. This is a *subset*
# of the arbitrary sender and payload in the cut, not a witness construction.
atlas=op.Atlas(word['frames'])
for x,y,g in [(251,524,2),(524,447,2),(319,447,2),(447,601,1),(601,1,1),(2748,2748,0)]:
    if x!=2748:assert atlas.grade(x,y)==g
assert [atlas.grade(*moves[k]) for k in (2748,2751,2754,3454)]==[1,1,1,6]
for lo,hi,r in [(9604,9607,2748),(9628,9632,2754),(23544,23547,3454)]:
    assert P[lo]==['INIT',r,moves[r][0]] and all(x[0]=='ADD' and x[1]==r for x in P[lo+1:hi])
all_legal_senders={c:atlas.grade(c,564) for c in atlas.body if atlas.grade(c,564)}
roster={};zero_only_same_grade={}
for k,t,g in [(2748,9607,1),(2754,9632,1),(3454,23547,6)]:
    banks,tags=snaps[t]
    bychart=defaultdict(list)
    for field,c in enumerate(tags):
        if c is None or field==idx(k) or c==564:continue
        if abs(len(atlas.body[c])-len(atlas.body[564]))!=g:continue
        if atlas.grade(c,564)!=g:continue
        label='z' if field==Z else ('clean_1862' if field==clean else (field-1 if field>N else field))
        bychart[c].append((label,banks[field]))
    zero_only_same_grade[str(k)]=[chart for chart,grade in sorted(all_legal_senders.items()) if grade==g and chart not in bychart]
    roster[str(k)]={str(chart):{'field_ids':[label for label,_ in fields],
      'field_supports':[support(row) for _,row in fields],
      'basis_rank':rank([row for _,row in fields]),
      'old_packet_representable':solve([row for _,row in fields],value[k]) is not None,
      'lost_2751_representable':solve([row for _,row in fields],H1) is not None,
      'delta_D_representable':solve([row for _,row in fields],D) is not None}
      for chart,fields in sorted(bychart.items())}

# Source-level witnesses for the narrow output-150-only correction at the
# original dispatch clocks. Other live fields are not transported for free.
# This diagnostic leaves all downstream operations fixed and does not enforce
# the required first-reader restoration.
repair150={};repair150_counts={}
for k,t in [(2748,9607),(2754,9632),(3454,23547)]:
    banks,tags=snaps[t];bychart=defaultdict(list)
    for field,c in enumerate(tags):
        if c is None or field==idx(k) or c==564 or not atlas.grade(c,564):continue
        label='z' if field==Z else ('clean_1862' if field==clean else (field-1 if field>N else field))
        bychart[c].append((label,banks[field]))
    target=value[k]^D; matches=[]
    for chart,fields in sorted(bychart.items()):
        witness=solve([row for _,row in fields],target)
        if witness is not None:
            matches.append({'sender':chart,'grade':atlas.grade(chart,564),
                'donors':[fields[i][0] for i in witness], 'payload_support':support(target)})
    repair150[str(k)]=matches
    repair150_counts[str(k)]={'sender_count':len(bychart),'zero_only_sender_charts':[c for c in sorted(all_legal_senders) if c not in bychart], 'stock_field_count':sum(map(len,bychart.values())),
        'sender_counts_by_grade':dict(sorted(Counter(str(atlas.grade(c,564)) for c in bychart).items()))}
    assert not matches

# Complete caller charge with unchanged productive boundary; separately grant
# the desired split for an optimistic ceiling. Both include all 36 native calls.
T0=Counter({int(k):v for k,v in receipt['native']['targets'].items()})
P0=Counter({int(k):v for k,v in receipt['native']['paid'].items()})
assert receipt['native_calls']==36 and sum(T0.values())==20706 and sum(P0.values())==107460
paid=P0.copy();paid.update({1:72,2:36,4:-36})
assert all(v>=0 for v in paid.values())
ideal=T0.copy();ideal.update({1:36,3:36,4:36,8:-36})
assert all(v>=0 for v in ideal.values())
assert sum(k*v for k,v in paid.items())==sum(k*v for k,v in P0.items())
assert sum(k*v for k,v in ideal.items())==sum(k*v for k,v in T0.items())
def signed(Tx,Px,k):return price.decimal_interval(price.sub(price.moment(Tx,F(k)),price.moment(Px,F(k))),36)
prices={}
for k in ('0.003879928046156','0.003879929046155'):
    d={'original_complete_caller':signed(T0,P0,k),'actual_diagnostic_paid_and_original_productive':signed(T0,paid,k),
       'optimistic_desired_productive_split':signed(ideal,paid,k),'hypothetical_replacement_grade_accounting':{}}
    for old in (1,6):
        d['hypothetical_replacement_grade_accounting'][str(old)]={}
        for new in range(1,8):
            px=paid.copy();px[old]-=36;px[new]+=36
            assert all(v>=0 for v in px.values())
            d['hypothetical_replacement_grade_accounting'][str(old)][str(new)]={
                'original_productive':signed(T0,px,k),'optimistic_productive_split':signed(ideal,px,k)}
    prices[k]=d
previous=json.loads(readpin('LITERAL-NEARMISS.json','06d83f3df1797c034f83b1d5720685a0615c7163b212d1bbfcc9c48912a6fc75'))
envelope=json.loads(readpin('MAXIMAL-ENVELOPE.json','0e618e1aa9f9a28bdb0e759bf8cdda10b30be21a1bae9b234a2c9e7c6ab42240'))
assert envelope['donor_count']==22 and envelope['old_input_pulse_distinguishing_output150']==[150,459]
assert previous['mismatched_original_outputs']==bad and previous['literal_forward_and_adjoint_transpose_all_coefficients']==681**2
out={'scope':{'fixed_2239_route_and_payload':'524→447 carrying pristine original 1862',
 'fixed_other_ingress':'2751 arrives as Hprime = original 2085 XOR original 1862',
 'changed_one_ingress_options':[2748,2754,3454],
 'payloads_and_senders':'arbitrary single-bit payload from any fixed sender at any time; theorem therefore includes all listed same-grade original-dispatch stock XORs and ignores feasibility and cost',
 'decoder':'arbitrary local chart-564 operations and storage; fixed communication topology except the single replacement',
 'required':'preserve actual H0,H1,H2 first-reader values and old output 150 on all 681 inputs, including independent z',
 'excluded':'data-dependent chart/timing side channels, extra incoming communications, replacing 2751 or 2239, changing exterior owner ports, dropping first-reader preservation'},
 'source':{'pr7925_head':'95200cf9df79633f285c37ad20440e74660989ba','pr7830_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'word_gzip_sha256':op.WORD_GZIP,'canonical_word_sha256':op.WORD},
 'actual_ingresses':{str(k):{'route':list(moves[k]),'clock':clocks[k], 'grade':atlas.grade(*moves[k]),
 'original_payload_support':support(value[k])} for k in (2748,2751,2754,3454)},
 'first_readers':{'2748':[10726,3060],'2751':[10729,3061],'2754':[10732,3062],'3454':[32746,3704]},
 'targets':{'names':['H0=old 2748','H1=old 2751','H2=old 2754','T150=old output150','Hprime=old 2085 XOR old 1862'],
 'supports':[support(x) for x in five],'early_target_rank':3,'early_with_Hprime_rank':4,'full_target_rank':4,'full_with_Hprime_rank':5,
 'dual_pulse_supports':[support(x) for x in pulses],'dual_pulses_target_identity':True,
 'stock_mutation_replace_Hprime_by_H1_rank':4,'stock_mutation_rejected':mutation_rejected,
 'stock_counts_at_early_and_late':[3,4], 'information_argument':'four received bits include independent nuisance Hprime; four target bits plus nuisance are independent, so no arbitrary replacement bit can permit all targets to be decoded'},
 'literal_test_681':{'transpose_coefficients_checked':681**2,'mismatched_old_output_count':len(bad),'mismatched_old_outputs':bad,
 'adjoint_mismatched_row_count':len(adjoint_bad),'adjoint_mismatched_rows':adjoint_bad,
 'mutation_delete_z_injection':{'new_observation_support':support(secondm),'observation_contract_rejected':secondm!=1<<680, 'transpose_coefficients_checked':681**2},
 'all_mismatch_delta_supports':{str(j):support(f[j]^expected[j]) for j in bad},
 'first_reader_support':support(first),'second_reader_support':support(second),'test_input_output_preserved':f[680]==expected[680],
 'forward_dirty_and_retirements':[fd,fr],'reverse_dirty_and_retirements':[ad,ar]},
 'same_grade_senders_at_original_dispatch':roster,
 'zero_only_same_grade_senders_at_original_dispatch':zero_only_same_grade,
 'output150_only_witnesses_at_original_dispatch_without_downstream_edits':repair150,
 'output150_only_sender_counts_at_original_dispatch':repair150_counts,
 'pricing_scope':'36-call signed target minus paid. Actual test word has original productive boundary, while the optimistic desired split is not achieved. One replaced ingress at equal grade changes no additional tariff; every other grade is separately repriced without assuming feasibility.',
 'caller_invoices':{'old_productive':dict(sorted(T0.items())), 'old_paid':dict(sorted(P0.items())),
 'diagnostic_paid':dict(sorted(paid.items())), 'ideal_productive':dict(sorted(ideal.items()))},
 'full_caller_prices':prices}
print(json.dumps(out,indent=2,sort_keys=True))
