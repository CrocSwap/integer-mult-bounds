#!/usr/bin/env python3
"""Combine separately best lower/upper search witnesses, simplify upper weights."""
import json,math
from fractions import Fraction
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'inherited/audit/source/drat/data'
E=json.loads((DATA/'e8base.json').read_text())['C']
def vec(xs):return 1|sum((int(v)&1)<<(i+1) for i,v in enumerate(xs))
h=list(map(vec,E[:104]));n=list(map(vec,E[104:]))

def greedy(z,ports,weights):
    span={0,n[z]};chosen=[]
    for t in sorted(ports,key=lambda t:(-weights[t],t)):
        if not weights[t]:break
        if h[t] not in span:
            span|={v^h[t] for v in span};chosen.append(t)
    return sorted(chosen)

for I,N in ((3,12),(3,24),(5,12),(5,24)):
    lo=json.loads((ROOT/f'i{I}-{N}-lower.json').read_text())
    hi=json.loads((ROOT/f'i{I}-{N}-upper.json').read_text())
    assert lo['ports']==hi['ports'] and lo['id']==hi['id']
    distributions=hi['cover_distributions'];origden=hi['denominator'];candidate=[]
    for p in distributions:
        fr=[Fraction(s['weight'],origden).limit_denominator(1000) for s in p['supports']]
        candidate.append(fr)
    D=math.lcm(*(x.denominator for row in candidate for x in row))
    if any(sum(row)!=1 for row in candidate) or D>10**9:
        D=origden
        candidate=[[Fraction(s['weight'],origden) for s in p['supports']] for p in distributions]
    rebuilt=[]
    for p,fr in zip(distributions,candidate):
        entries=[{'mask':s['mask'],'weight':int(x*D)} for s,x in zip(p['supports'],fr) if x]
        assert sum(x['weight'] for x in entries)==D
        rebuilt.append({'t':p['t'],'supports':entries})
    lo['cover_distributions']=rebuilt;lo['upper_denominator']=D
    ports=lo['ports'];active=[z for z in range(16) if not(I>>z&1)];upper=[];total=0
    for z in active:
        weights={p['t']:sum(s['weight'] for s in p['supports'] if s['mask']>>z&1) for p in rebuilt}
        basis=greedy(z,ports,weights);v=sum(weights[t] for t in basis);total+=v
        upper.append({'z':z,'ports':basis,'value':v})
    lo['upper_row_bases']=upper;lo['upper_numerator']=total
    path=ROOT/f'i{I}-{N}.json';path.write_text(json.dumps(lo,indent=2)+'\n')
    print(path.name,'lower',Fraction(lo['lower_numerator'],lo['denominator']),'upper',Fraction(total,D),flush=True)
