#!/usr/bin/env python3
"""Reject semantic corruptions of retained rational witnesses."""
import copy,json
from pathlib import Path
import verify_exact as v
HERE=Path(__file__).resolve().parent
base=json.loads((HERE/'i3-24.json').read_text());v.verify_case(base,verbose=False)
controls=[]
def fresh(name):
    x=copy.deepcopy(base);controls.append((name,x));return x

x=fresh('wrong_cube');x['inactive_mask']=5
x=fresh('duplicate_basis_label');mix=x['row_mixtures'][0]['mixture'][0];mix['ports'].append(mix['ports'][0])
x=fresh('dependent_distinct_label');
for r in x['row_mixtures']:
    for m in r['mixture']:
        span={0,v.n[r['z']]}
        for t in m['ports']:span|={q^v.h[t] for q in span}
        extra=next((t for t in x['ports'] if t not in m['ports'] and v.h[t] in span),None)
        if extra is not None:m['ports'].append(extra);break
    else:continue
    break
else:raise AssertionError('control needs a dependent extension')
x=fresh('row_weights_do_not_sum_to_one');x['row_mixtures'][0]['mixture'][0]['weight']+=1
x=fresh('false_minimum_witness');x['port_minima'][0]['support']=0
x=fresh('overstated_lower_score');x['lower_numerator']+=1
x=fresh('inactive_cover_support');x['cover_distributions'][0]['supports'][0]['mask']|=1
x=fresh('false_cover_support');x['cover_distributions'][0]['supports'][0]['mask']=0
x=fresh('cover_weights_do_not_sum_to_one');x['cover_distributions'][0]['supports'][0]['weight']+=1
x=fresh('wrong_maximum_basis');x['upper_row_bases'][0]['ports'].pop()
x=fresh('understated_upper_score');x['upper_numerator']-=1
for name,obj in controls:
    try:v.verify_case(obj,verbose=False)
    except (AssertionError,KeyError,IndexError):print('PASS rejected',name)
    else:raise AssertionError('control unexpectedly accepted: '+name)
print('PASS',len(controls),'semantic mutations rejected')
