# Branch-free fractional row-basis screens for P104 cubes i3 and i5

**No new cube exclusion was found.** These are four bounded, solver-free
checks of a proposed fractional rank lower bound. They start from the 665 of
1,001 cube IDs excluded in [PR #7893 at
`86366417aa712746545fa3ab9c3f7659cbffe878`](https://github.com/CrocSwap/integer-mult-bounds/pull/7893)
and concern only the stated price-55 tight B-linear covering relaxation of
[PR #7852 at `41beda1d6435760dc99e38bd7e65f36798aad212`](https://github.com/CrocSwap/integer-mult-bounds/pull/7852).
The inherited 665/1,001 baseline remains unchanged; i3 and i5 remain among its
336 unresolved IDs. This is not a conclusion about the satisfiability of
either full cube, the original decoder, or kappa.

For each cube and port set the table gives an **attained lower-bound score**
from a particular rational row mixture and a rigorous rational **ceiling on
the score of every row mixture on that same set of ports**. The two numbers
are close; their slight gap does not certify the exact optimum.

| Cube | Selected ports | Attained score | Rigorous ceiling |
| --- | ---: | ---: | ---: |
| i3 | 12 | 8,834,819 / 250,000 = 35.339276 | 1,979 / 56 = 35.3392857… |
| i3 | 24 | 10,749,991 / 250,000 = 42.999964 | 43 |
| i5 | 12 | 20,999,999 / 500,000 = 41.999998 | 42 |
| i5 | 24 | 42,374,981 / 1,000,000 = 42.374981 | 339 / 8 = 42.375 |

Each 12-port set is a prefix of its 24-port set. Search selected them by
descending minimum cover cardinality after applying the cube's inactive
units, breaking ties by the number of admissible supports and then port ID.
The exact 24-port lists, in selection order, are:

* i3: `93,18,33,39,51,59,92,6,17,27,38,74,85,9,25,56,70,82,96,11,14,19,40,48`.
* i5: `6,22,43,85,28,33,57,59,51,80,42,66,72,86,5,74,89,93,11,25,96,97,34,68`.

The ceiling applies to *all* probability mixtures of row-independent sets on
the listed family, including mixtures not seen by the search. It does **not**
apply to other port families or to bounds using additional cross-port
constraints or branching. In particular, it does not exclude an improved
fractional certificate with more or differently chosen ports.

## Exact argument

The inherited audit defines the 104 port vectors `h_t`, 16 row normals
`n_z`, cover clauses, and `price_z = dim(U_z + span(n_z)) - 1`. A set `B` of
port labels is independent *modulo* `n_z` if `{n_z} union {h_t: t in B}` is
independent over F2. For any row, its price is at least the number of its
actual selected-port membership flags inside `B`. Choose a distribution
`lambda[z,B]` on such independent sets, including the empty set. Define
`a[z,t] = Pr(t in B)`.

For selected port `t`, let `Gamma_t` be **all** membership masks on active
rows that hit every generated positive cover clause at that port. Cube units
force inactive row memberships false. Summing over selected ports gives the
valid lower bound

```text
L(lambda) = sum_t min_(S in Gamma_t) sum_(z in S) a[z,t].
```

Thus `L > 55` would contradict the audited totalizer. The masks need not be
jointly realizable as row subspaces; allowing all of them only weakens the
bound. The checker enumerates the full 16-bit masks satisfying the inactive
units and regenerated clauses and evaluates each minimum with integers.

For the ceiling, supply a probability distribution `pi[t,S]` on `Gamma_t`
for each port. For every row mixture, replacing each minimum by this average
and maximizing a linear function over the independent sets gives

```text
L(lambda) <= sum_z max_(B independent modulo n_z)
                   sum_(t in B) Pr_(S ~ pi[t])(z in S) = U.
```

The checker verifies each support hits the regenerated clauses, each
distribution sums to one, and the exact row maxima by weighted greedy in the
contracted binary vector matroid. Greedy is optimal because its choice forms
a maximum-size independent set in every weight-ordered prefix; a telescoping
sum of weight differences bounds the weight of every other independent set.
Spans are enumerated explicitly; all certificate weights and comparisons use
integers. Because every ceiling here is below 55, none of these four port
families can yield the proposed exclusion, regardless of the floating-point
optimizer used to discover the witnesses.

## Reproduce

Python 3 and a standard shell suffice to check the witnesses and inherited
baseline, with no solver, network, or third-party library:

```sh
sha256sum -c SHA256SUMS
python3 -B inherited/verify_all.py
python3 -B verify_exact.py
python3 -B verify_controls.py
```

The inherited verifier reconstructs the CNF's membership and totalizer
semantics and the 612 + 29 + 23 + 1 exclusions. The new verifier also
regenerates and matches all 17,152 positive cover clauses, verifies each cube's
units and complete generated CNF hash, and checks the rational witnesses.
The source's historical hashes for the full cubes are
`efcac8d4bb92b32e687787ef85a9e940895a97c081b14d88123e59ce2c048702`
for i3 and
`07464a29a4205d503ca221ac98a85608e6a28b927cdd0ed12dcf4851b3c555f8`
for i5. The 11 controls corrupt, among other things, row independence,
mixture totals, a computed minimum, support membership, and a ceiling.

The optional `search.py` uses NumPy and SciPy/HiGHS for bounded cutting-plane
and column generation, with one thread per LP. Its output has no authority
until checked by `verify_exact.py`. To rerun the four searches and reassemble
their best primal and dual witnesses, use:

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python3 search.py 3 12 --rounds 30
python3 search.py 3 24 --rounds 50
python3 search.py 5 12 --rounds 40
python3 search.py 5 24 --rounds 140
python3 assemble.py
python3 -B verify_exact.py
```

`assemble.py` attempts a small rational reconstruction of the dual weights;
exact verification is still required. A different numerical environment can
produce different search witnesses. LP termination or failure does not prove
a cube result.
