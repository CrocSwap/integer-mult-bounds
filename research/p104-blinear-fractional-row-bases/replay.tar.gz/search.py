#!/usr/bin/env python3
"""Bounded column/cut generation for P104 independent-set price certificates.

Search uses floating point LP; verify_exact.py checks retained evidence with
integer arithmetic. Neither an LP result nor a search failure is a proof.
"""
import argparse,collections,hashlib,json,os,random,sys,time
from pathlib import Path

os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'inherited/audit/source/drat/data'
C=json.loads((SOURCE/'zclauses.json').read_text())
E=json.loads((SOURCE/'e8base.json').read_text())['C']
def vec(xs):return 1|sum((int(v)&1)<<(i+1) for i,v in enumerate(xs))
h=list(map(vec,E[:104]));n=list(map(vec,E[104:]));assert len(h)==104 and len(n)==16

def independent_greedy(z,ports,weights):
    b={n[z].bit_length()-1:n[z]};chosen=[]
    for k in sorted(range(len(ports)),key=lambda i:(-weights[i],ports[i])):
        if weights[k]<=1e-12:continue
        v=h[ports[k]]
        while v:
            q=v.bit_length()-1
            if q in b:v^=b[q]
            else:b[q]=v;chosen.append(ports[k]);break
    return tuple(sorted(chosen))

def setup(I):
    active=[z for z in range(16) if not(I>>z&1)]
    masks=np.asarray([s for s in range(65536) if not(s&I)],dtype=np.uint32)
    counts=np.asarray([int(s).bit_count() for s in masks],dtype=np.int16)
    incid=np.asarray([[(s>>z)&1 for z in active] for s in masks],dtype=np.int8)
    good=[]
    for cs in C:
        ok=np.ones(len(masks),dtype=bool)
        for c in cs:ok&=(masks&c)!=0
        g=np.flatnonzero(ok);assert len(g)
        good.append(g)
    return active,masks,counts,incid,good

def rationalize(weights,den=10**6):
    s=sum(weights)
    if s<=0:return [den]+[0]*(len(weights)-1)
    xs=[max(0,w)/s*den for w in weights]
    out=[int(v) for v in xs]
    for i in sorted(range(len(xs)),key=lambda i:xs[i]-out[i],reverse=True)[:den-sum(out)]:out[i]+=1
    assert sum(out)==den and min(out)>=0
    return out

def evidence(cid,I,ports,active,masks,incid,good,bases,cuts,res):
    N=len(ports);Z=len(active);nx=N*Z;nb=sum(map(len,bases));den=10**6
    lam=res.x[nx+N:];offset=0;rows=[];a=np.zeros((Z,N),dtype=np.int64)
    for zi,z in enumerate(active):
        B=bases[zi];w=rationalize(list(lam[offset:offset+len(B)]),den);offset+=len(B)
        items=[]
        for basis,wt in zip(B,w):
            if wt:
                items.append({'ports':list(basis),'weight':wt})
                for t in basis:a[zi,ports.index(t)]+=wt
        rows.append({'z':z,'mixture':items})
    port_records=[];lower=0
    for ti,t in enumerate(ports):
        scores=incid[good[t]].astype(np.int64)@a[:,ti]
        k=int(np.argmin(scores));v=int(scores[k]);lower+=v
        port_records.append({'t':t,'minimum':v,'support':int(masks[good[t][k]])})
    marg=np.maximum(0,-res.ineqlin.marginals)
    distributions=[];wzt=np.zeros((Z,N),dtype=np.int64)
    for ti,t in enumerate(ports):
        ids=[i for i,(j,s) in enumerate(cuts) if j==ti]
        ws=rationalize([float(marg[i]) for i in ids],den)
        entries=[]
        for ci,wt in zip(ids,ws):
            if wt:
                mask=cuts[ci][1];entries.append({'mask':mask,'weight':wt})
                for zi,z in enumerate(active):wzt[zi,ti]+=wt*((mask>>z)&1)
        distributions.append({'t':t,'supports':entries})
    upper=0;upper_basis=[]
    for zi,z in enumerate(active):
        basis=independent_greedy(z,ports,list(wzt[zi]));v=sum(int(wzt[zi,ports.index(t)]) for t in basis)
        upper+=v;upper_basis.append({'z':z,'ports':list(basis),'value':v})
    return {'schema':'p104-fractional-row-bases-v1','id':cid,'inactive_mask':I,'ports':ports,
            'denominator':den,'row_mixtures':rows,'port_minima':port_records,'lower_numerator':lower,
            'cover_distributions':distributions,'upper_row_bases':upper_basis,'upper_numerator':upper}

def solve(I,N,seed,round_limit,lp_seconds):
    t0=time.monotonic();cid='i'+str(I);active,masks,counts,incid,good=setup(I)
    best_by_count=sorted(range(104),key=lambda t:(int(counts[good[t]].min())*-1,len(good[t]),t))
    ports=best_by_count[:N];Z=len(active);rng=random.Random(seed);nx=Z*N
    print('setup',cid,'ports',ports,'mincard',[int(counts[good[t]].min()) for t in ports],flush=True)
    bases=[]
    for z in active:
        s=set()
        for _ in range(8):s.add(independent_greedy(z,ports,[rng.random() for t in ports]))
        bases.append(sorted(s))
    cuts=[];cutset=set()
    for ti,t in enumerate(ports):
        i=good[t][int(np.argmin(counts[good[t]]))];x=(ti,int(masks[i]));cuts.append(x);cutset.add(x)
        x=(ti,sum(1<<z for z in active))
        if x not in cutset:cuts.append(x);cutset.add(x)
    bestlower=None;bestupper=None
    for itr in range(round_limit):
        offsets=[];cur=nx+N
        for B in bases:offsets.append(cur);cur+=len(B)
        nvar=cur;er=[];ec=[];ev=[]
        for zi,z in enumerate(active):
            for ti in range(N):er.append(zi*N+ti);ec.append(zi*N+ti);ev.append(1.)
            for j,B in enumerate(bases[zi]):
                col=offsets[zi]+j
                for t in B:er.append(zi*N+ports.index(t));ec.append(col);ev.append(-1.)
                er.append(nx+zi);ec.append(col);ev.append(1.)
        Aeq=coo_matrix((ev,(er,ec)),shape=(nx+Z,nvar)).tocsr()
        beq=np.r_[np.zeros(nx),np.ones(Z)];ur=[];uc=[];uv=[]
        for i,(ti,mask) in enumerate(cuts):
            ur.append(i);uc.append(nx+ti);uv.append(1.)
            for zi,z in enumerate(active):
                if (mask>>z)&1:ur.append(i);uc.append(zi*N+ti);uv.append(-1.)
        Aub=coo_matrix((uv,(ur,uc)),shape=(len(cuts),nvar)).tocsr()
        obj=np.zeros(nvar);obj[nx:nx+N]=-1.
        res=linprog(obj,A_ub=Aub,b_ub=np.zeros(len(cuts)),A_eq=Aeq,b_eq=beq,
                    bounds=(0,None),method='highs',options={'time_limit':lp_seconds,'threads':1})
        if not res.success:
            print('STOP LP',res.status,res.message,'iteration',itr,flush=True);break
        e=evidence(cid,I,ports,active,masks,incid,good,bases,cuts,res)
        if bestlower is None or e['lower_numerator']>bestlower['lower_numerator']:bestlower=e
        if bestupper is None or e['upper_numerator']<bestupper['upper_numerator']:bestupper=e
        a=res.x[:nx].reshape((Z,N));newcuts=0
        for ti,t in enumerate(ports):
            vals=incid[good[t]]@a[:,ti];order=np.argsort(vals,kind='stable')
            for k in order[:8]:
                if vals[k]>=res.x[nx+ti]-1e-8:break
                x=(ti,int(masks[good[t][k]]))
                if x not in cutset:cuts.append(x);cutset.add(x);newcuts+=1
        y=res.eqlin.marginals[:nx].reshape((Z,N));mu=res.eqlin.marginals[nx:];newbasis=0
        for zi,z in enumerate(active):
            basis=independent_greedy(z,ports,list(-y[zi]))
            if -sum(y[zi,ports.index(t)] for t in basis)>-mu[zi]+1e-8 and basis not in bases[zi]:
                bases[zi].append(basis);newbasis+=1
        print('iter',itr,'LP',round(-res.fun,6),'lower',e['lower_numerator']/1e6,'upper',e['upper_numerator']/1e6,
              'cuts+',newcuts,'bases+',newbasis,'time',round(time.monotonic()-t0,2),flush=True)
        if e['lower_numerator']>55*10**6 or (not newcuts and not newbasis):break
    for kind,e in [('lower',bestlower),('upper',bestupper)]:
        if e:
            path=HERE/f'{cid}-{N}-{kind}.json';path.write_text(json.dumps(e,indent=2)+'\n')
            print('WROTE',path.name,'lower',e['lower_numerator']/1e6,'upper',e['upper_numerator']/1e6,flush=True)
    print('DONE',cid,N,'elapsed',round(time.monotonic()-t0,2),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('I',type=int,choices=[3,5]);p.add_argument('N',type=int,choices=range(12,25));
    p.add_argument('--seed',type=int,default=104);p.add_argument('--rounds',type=int,default=35);p.add_argument('--lp-seconds',type=float,default=4.)
    a=p.parse_args();solve(a.I,a.N,a.seed,a.rounds,a.lp_seconds)
