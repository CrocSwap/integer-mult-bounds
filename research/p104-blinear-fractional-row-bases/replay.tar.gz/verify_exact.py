#!/usr/bin/env python3
"""Replay branch-free row-matroid bounds using only integer arithmetic.

The inherited checker verifies the CNF and 665-ID baseline; this checker
binds each tested cube and cover clause to that generator, exhaustively checks
all admissible selected-port support masks, checks every independent-set
mixture, and checks a cover-distribution upper bound using matroid greedy.
"""
import functools,hashlib,importlib.util,json,sys
from fractions import Fraction
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
INH=HERE/'inherited';ROOT=INH/'audit';DATA=ROOT/'source/drat/data'
PINS={
 'source/drat/gen.py':'2109ace16a7b04aa399ab0a06739afbb6fe378348e06360ce26620b721a08472',
 'source/drat/cubes.txt':'792af281bcb7d5652274ae201624fb69ab49fa99b29fba4522ab295924de3002',
 'source/drat/hashes.tsv':'3cdd8553d2de9c1800daef10f8ea138f6ba3abe27ce8228b9a4ebb3ad678dce7',
 'source/drat/data/e8base.json':'b8c96bb12c628fe152faa150b1ca641709e3556b26d7e5b02af5d661e901bc41',
 'source/drat/data/perms.json':'1b4e6b64f605f78432d075928ae28696ebf1945679c0818eb319ad61b5e3a3a3',
 'source/drat/data/zclauses.json':'7d586edab8c5527bc47dae89b5e396f69327da7f39707473706bdb7100b05e27',
}
for path,want in PINS.items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==want,path
spec=importlib.util.spec_from_file_location('gen',ROOT/'source/drat/gen.py')
gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen);b=gen.Base()
E=json.loads((DATA/'e8base.json').read_text())['C'];C=json.loads((DATA/'zclauses.json').read_text())
def vec(xs):return 1|sum((int(v)&1)<<(i+1) for i,v in enumerate(xs))
h=list(map(vec,E[:104]));n=list(map(vec,E[104:]));assert len(h)==104 and len(n)==16 and len(C)==104
assert len(set(h))==104 and all(x not in h for x in n)
generated=b.cls[b.n_cov0:b.n_tot0]
expected=[tuple(b.m[z,t] for z in range(16) if c>>z&1) for t,cs in enumerate(C) for c in cs]
assert len(generated)==len(expected)==17152 and generated==expected
hashes={p[0]:p[1] for line in (ROOT/'source/drat/hashes.tsv').read_text().splitlines() if line and not line.startswith('#') for p in [line.split('\t')]}
remaining={line.split('\t')[0] for line in (INH/'remaining-336.tsv').read_text().splitlines() if line and not line.startswith('#')}
assert {'i3','i5'}<=remaining and len(remaining)==336

def isint(x):return type(x) is int
@functools.lru_cache(maxsize=None)
def check_cube(cid,I):
    assert cid==f'i{I}' and cid in {'i3','i5'}
    units=[c[0] for c in gen.cube_extra(b,cid) if len(c)==1]
    assert len(units)==16 and set(units)=={b.used[z,8] if I>>z&1 else -b.used[z,8] for z in range(16)}
    assert hashlib.sha256(gen.cube_text(cid,b=b).encode()).hexdigest()==hashes[cid]

@functools.lru_cache(maxsize=None)
def admissible(I,t):
    # Each mask represents precisely the true membership flags for this port.
    # The generated positive clauses are necessary, and inactive flags are 0.
    return tuple(s for s in range(65536) if not(s&I) and all(s&c for c in C[t]))

def independent(z,ports):
    span={0,n[z]}
    for t in ports:
        assert h[t] not in span,('dependent modulo normal',z,t)
        span|={v^h[t] for v in span}
    return True

def max_basis(z,ports,w):
    # Greedy is exact for this contracted binary vector matroid: for each
    # weight-ordered prefix it builds a basis for that prefix. The usual
    # telescoping sum of weight differences proves maximum total weight.
    span={0,n[z]};selected=[]
    for t in sorted(ports,key=lambda t:(-w[t],t)):
        assert isint(w[t]) and w[t]>=0
        if not w[t]:break
        if h[t] not in span:
            span|={v^h[t] for v in span};selected.append(t)
    return sorted(selected)

def verify_case(proof,verbose=True):
    assert proof['schema']=='p104-fractional-row-bases-v1'
    cid,I=proof['id'],proof['inactive_mask'];assert isint(I);check_cube(cid,I)
    active=[z for z in range(16) if not(I>>z&1)];ports=proof['ports'];N=len(ports)
    assert 12<=N<=24 and len(set(ports))==N and all(isint(t) and 0<=t<104 for t in ports)
    den=proof['denominator'];assert isint(den) and den>0
    rows=proof['row_mixtures'];assert [r['z'] for r in rows]==active
    prices={t:{z:0 for z in active} for t in ports}
    for row in rows:
        z=row['z'];mix=row['mixture'];assert mix
        assert sum(x['weight'] for x in mix)==den
        for item in mix:
            wt=item['weight'];B=item['ports']
            assert isint(wt) and wt>0 and len(B)==len(set(B)) and set(B)<=set(ports)
            assert independent(z,B)
            for t in B:prices[t][z]+=wt
    minima=proof['port_minima'];assert [p['t'] for p in minima]==ports
    score=0
    for item in minima:
        t=item['t'];good=admissible(I,t);assert good
        def cost(mask):return sum(prices[t][z] for z in active if mask>>z&1)
        best=min(cost(mask) for mask in good)
        assert item['support'] in good and cost(item['support'])==best and item['minimum']==best
        score+=best
    assert isint(proof['lower_numerator']) and score==proof['lower_numerator']
    upper_den=proof['upper_denominator'];assert isint(upper_den) and upper_den>0
    dists=proof['cover_distributions'];assert [p['t'] for p in dists]==ports
    w={z:{t:0 for t in ports} for z in active}
    for item in dists:
        t=item['t'];supp=item['supports'];assert supp
        assert len({s['mask'] for s in supp})==len(supp)
        assert sum(s['weight'] for s in supp)==upper_den
        for s in supp:
            mask,wt=s['mask'],s['weight']
            assert isint(mask) and 0<=mask<65536 and not(mask&I) and all(mask&c for c in C[t])
            assert isint(wt) and wt>0
            for z in active:
                if mask>>z&1:w[z][t]+=wt
    upper_rows=proof['upper_row_bases'];assert [r['z'] for r in upper_rows]==active
    total=0
    for row in upper_rows:
        z=row['z'];B=max_basis(z,ports,w[z]);assert B==row['ports']
        val=sum(w[z][t] for t in B);assert val==row['value'];total+=val
    assert isint(proof['upper_numerator']) and total==proof['upper_numerator']
    assert score*upper_den<=total*den
    if verbose:
        print(f'PASS {cid} ports={N}: attained={Fraction(score,den)} = {score/den:.6f}; '
              f'exact ceiling={Fraction(total,upper_den)} = {total/upper_den:.6f}')
        print('PASS all selected-port support masks, rational row mixtures, and rational cover distributions')
    return Fraction(score,den),Fraction(total,upper_den)

if __name__=='__main__':
    paths=[Path(x) for x in sys.argv[1:]] or [HERE/f'i{I}-{N}.json' for I,N in ((3,12),(3,24),(5,12),(5,24))]
    for path in paths:verify_case(json.loads(path.read_text()))
    print('PASS regenerated cover block and complete cube hashes')
