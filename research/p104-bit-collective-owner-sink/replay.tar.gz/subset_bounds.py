#!/usr/bin/env python3
"""Ideal paid-free grade bound for every subset of eight grade-7 families."""
import itertools
import json
import sys
from pathlib import Path
from collections import Counter, defaultdict

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from multi_projection import (
    FAMILY, K, R, W, build_projection, kernel, labels, price,
    signed_projection, xsum,
)

def main():
    cases = []
    for size in range(1, len(FAMILY)+1):
        for family in itertools.combinations(FAMILY, size):
            for include_89 in (False, True):
                ports = family + ((89,) if include_89 else ())
                helpers = (660,) if include_89 else ()
                gone = set(helpers) | {i for p in ports for i in (p, p+111)}
                rt, rows, fw, path, adj, target, sens = build_projection(
                    sum(1 << i for i in gone))
                banks, out = defaultdict(list), defaultdict(list)
                for i in target:
                    banks[W['start'][i]].append(i)
                for p, (a, b) in rt.items():
                    banks[b].append(p)
                    out[a].append(p)
                deps = {c: q for c, ps in banks.items()
                        if (q := kernel((fw[p], 1 << p) for p in ps))}
                source0 = sum(1 << p for p in out[0] if p != 3553)
                zero = all(not (source0 & xsum(path[p] for p in labels(r) if p >= 680))
                           for rs in deps.values() for r in rs)
                assert set(deps) == {1} and len(deps[1]) == size and zero
                hist = signed_projection(ports, helpers, set(R)-set(rt))
                hist[7] += 36*size
                bound = price(hist)
                assert float(bound[1]) < 0
                cases.append({
                    'family': list(family), 'ports': list(ports),
                    'helpers': list(helpers), 'removed_owners': sorted(gone),
                    'surviving_owner_count': len(target), 'surviving_packet_count': len(rt),
                    'omitted_packet_ids': sorted(set(R)-set(rt)),
                    'only_sink': 1, 'sink_relations': [list(labels(x)) for x in deps[1]],
                    'rank_chart0_to_sink': 0,
                    'ideal_free_grade7_return_count': size,
                    'complete_change_upper': bound,
                })
        print('completed subset size', size, 'cases', len(cases), flush=True)
    assert len(cases) == 510
    payload = {
        'rate': str(K), 'family': list(FAMILY), 'cases': cases,
        'scope': 'All nonempty subsets of the eight grade-7 contact families, '
                 'without and with port 89 plus helper 660. Free old historical '
                 'stock, arbitrary independent new source-only injections and '
                 'terminal decoding, fixed retained routes and frames. Upper '
                 'bounds grant all available sink dimensions grade 7 for free.',
    }
    (ROOT/'SUBSET-BOUNDS.json').write_text(json.dumps(payload, sort_keys=True, indent=2)+'\n')
    print('PASS 510', flush=True)


if __name__ == '__main__':
    main()
