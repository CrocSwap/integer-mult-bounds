#!/usr/bin/env python3
"""Independently recheck all 510 subset projections and price ceilings."""
import gzip
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
import independent_audit as audit


def main():
    raw = (ROOT/'producer/source/inputs/WORD.json.gz').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
    word = json.loads(gzip.decompress(raw))
    initial, final, routes, rows, clocks = audit.bit_native.extract(word)
    order = sorted(routes, key=clocks.get)
    cases = json.loads((ROOT/'SUBSET-BOUNDS.json').read_text())['cases']
    outputs = []
    for index, c in enumerate(cases):
        case = {
            'ports': c['ports'], 'helpers': c['helpers'],
            'removed_owners': c['removed_owners'],
            'omitted_packet_ids': c['omitted_packet_ids'],
            'retained_owners': c['surviving_owner_count'],
            'retained_packets': c['surviving_packet_count'],
            'bank_dependences': {'1': c['sink_relations']},
            'source0_transfer_rank': c['rank_chart0_to_sink'],
            'grade7_pair_matchings': [],
            'ideal_free_grade7_returns_delta_upper': c['complete_change_upper'],
        }
        outputs.append(audit.calculate(case, initial, final, routes, rows, order, word['frames']))
        if (index+1) % 100 == 0:
            print('audited', index+1, flush=True)
    assert len(outputs) == 510
    payload = {
        'cases': len(outputs),
        'all_projected_operators_both_directions': True,
        'all_bank_relations_and_chart0_zero_blocks': True,
        'all_directed_prices_recomputed_110_digits': True,
        'sink_rank_census': dict(Counter(
            str(c['independent_bank_ranks']) for c in outputs)),
        'cases_by_original_contact_count': dict(Counter(str(len(c['ports'])) for c in outputs)),
    }
    (ROOT/'SUBSET-AUDIT.json').write_text(json.dumps(payload, sort_keys=True, indent=2)+'\n')
    print('PASS', len(outputs), flush=True)


if __name__ == '__main__':
    main()
