# Simultaneous grade-7 helper returns after projecting P104 main ports

**Result.** In the source-only injection model below, no tested release has a
positive complete signed change at `κ = 0.00388`. The result covers every
nonempty subset of the eight grade-7 families
`{6, 11, 17, 56, 57, 67, 68, 69}`, both alone and with release of port 89 and
helper 660: **510 projections**. A size-`m` set has exactly `m` independent
zero-old relations, all at chart 1, and every such relation has zero
sensitivity to every surviving chart-0 send. Even granting all `m` possible
new returns at grade 7 for free, the 36-call complete signed upper change is

`−28.0356508270048417259561298496 * m`.

With port 89 and helper 660 also projected, subtract another
`26.5269371304303352567827584838`. Thus the best upper in the entire census
is below `−28.03565082700484`; the unchanged complete BIT margin at the same
trial is about `−0.0277113601902175904`. This is not a new κ result.
Directed numerical enclosures for every individual case are in
`SUBSET-BOUNDS.json`.

## Pinned sources and released owners

The original native is #7830 at
`87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, canonical main context
`e54523517d0f03e58352e647c403a5af3e525a57`, canonical word hash
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`.
The chosen prior graph is #7983 head
`5f393bfc838276228ff8adfee9c5625d8ce9197f`; the prior independent helper
search is #7985 head `251e15df3e0c058a843e7cb13f5882179a4e3afc`.
`source_check.py` confirms that #7983's port-89/helper-660 zero-packet roster
matches the new projection and that the eight grade-7 families, and the
port-6 and port-11 witness rows, match the #7985 source receipt.

A projected port `p` removes both owners `p` and `p+111`, its terminal
equations, and the corresponding entire paired caller contact. Helper 660,
when specified, is also removed and its grade-4 target is debited. Alternating
forward and adjoint zero-packet pruning preserves protected packet 3553.
All surviving main owners and owner 411 retain their complete original
operator. The released port 89 plus 660 alone has 677 old owners, 2,866
retained sends and no zero-old bank relation. The two-family joint example
below removes owners `{6,11,89,117,122,200,660}`, leaving 673 old owners and
2,862 old sends; its zero packets are
`{1195,1197,1199,1470,1486,3295,3320,3321,3424,3425,3522,3523}`.

## Model and exact independent-owner cut

Frames, retained paid routes, all old packet equations except fresh-owner
source injections, surviving productive endpoints, the paired caller, and the
protected owner-411 bridge are fixed. Each new independent owner may start
at any original chart and be XORed into any retained original sends from
that source chart. Several owners may be injected jointly, with arbitrary
linear choices. Every final chart is granted free access to the complete
history of its surviving old observations and may linearly redecode all its
old and new outputs. No extra paid MOVE is permitted. Releasing a retained
helper first and then reinserting it is included only when that helper is in
the stated projection; there is no free relabel of another retained owner.

Let the old projected rows at a chart be columns of `A`. A combination of
observations that removes all old owners must lie in `ker(A)`. Adding fresh
owners at that chart contributes their direct local axes, and changing their
outgoing source equations maps each column of `ker(A)` into the new-owner
space. Therefore, after quotienting by the axes already sourced locally, at
most `dim ker(A)` independent external owners can be returned at that
chart. This is a joint output-span statement: mixing two owner labels or
changing the basis of the output span cannot enlarge that quotient. Every
fresh owner's genuine original input coordinate must occur in the span of
its actual output chart; a basis change at one chart cannot grant a different
chart's independent input axis for free.

All 510 graphs have only chart 1 relations, of dimension exactly `m`.
Chart 0 and chart 1 are respectively the unique rank-0 and rank-8 frames.
Every chart-1 relation annihilates the full block of chart-0 send injection
coefficients. Hence a new axis sourced at chart 0 is absent from chart 1;
there can be no grade-8 independent return in this model, including in a
joint owner basis. At most `m` positive-grade independent returns are
possible, and each is worth at most grade 7. The upper bound gives each the
full grade-7 target and grants all injection, redecoding and ordinary work
free, so it is optimistic for the stated model.

At rate `κ`, write `H(g)=g^(1−κ)` and

`F = 4 + 4 Σ(i=1..8) H(7i) − 2H(127) − 4 Σ(i=1..9) H(1+7i)`.

The actual complete projection change is `number_of_ports*F`, plus 36
times the grades of all truly zero paid packets, minus 36 times all removed
helper target grades. Adding the ideal `36*m*H(7)` gives the quoted bound.
This counts the original productive roots, QUERYs and IDLEs in the removed
caller port and does not fund an unrecorded substitute.

For the required early gate, releasing ports 6 and 89 plus helper 660 leaves
one chart-1 relation, 521 chart-0 sends whose sensitivity is identically
zero, and the source roster in `MULTI-PROJECTION.json`: four grade-1, seven
grade-2 and one grade-7 source under the output-purity constraints. The
best possible single helper is the chart-8-to-1 return; the full change is
at most `−54.5625879574351769827`. Every pair of grade-7 families was
also explicitly checked: all **56** pair/optional-89 cases have a rank-two
independent grade-7 matching under the old-output and owner-411 constraints.

## Real rank-two and nonscalar basis controls

For ports 6 and 11 together with 89/660, the two retained chart-1 relations
are listed exactly in `MULTI-PROJECTION.json`. The two injected source rows
are packets `[720,721,722,723,3298]` at chart 8 and
`[751,752,753,754,3300]` at chart 13. Their matrix on the two original sink
relations is the identity, and both axes are independently owned. There are
520 surviving chart-0 sends and **all** of their entries in this 2-by-520
block are zero. Before exterior-purity constraints, the nonzero columns at
chart 8 are 720, 721 and 723 with vector `(1,0)`; at chart 13 they are 751,
752 and 753 with vector `(0,1)`.

`JOINT-WORD.json.gz` is an actual compiled control with both new owners,
675 total rows, 108 remaining caller ports and 36 LOCALs. Both the complete
forward operator and its adjoint pass, with 455,625 coefficients each;
owner 411 is isolated. Removing either new output row damages both
orientations. The complete binary margin is
`−82.6259501446302362991`, a change of `−82.5982387844400187087`;
the unchanged 48-call rational margin is `+0.1389745223342527090`.
The signed result equals the optimistic two-return price in this fixed
graph. Its 3,537 dirty retirements in each direction are recorded, not
established as physically erased.

`MIXED-WORD.json.gz` implements a nonscalar common-sink basis: the two
intermediate outputs are `(z6+z11, z11)`, and an actual local ADD at chart 1
decodes to `(z6,z11)`. Both full 675-row operators pass and its complete
paid and productive bins equal the diagonal word. The mixed basis adds no
new independent cross-chart support or price gain.

## Independent checks and limits

`independent_audit.py` extracts packets from the primitive tape with a
separate interpreter, independently recomputes forward/adjoint fixed-point
pruning and the two projected operators, uses the opposite Gaussian-pivot
direction for bank relations, propagates each chart-0 send's distinct taint,
and checks the 56 joint witnesses. `subset_audit.py` does those raw-tape
projection, operator, bank, taint and 110-digit repricing checks on all 510
subsets. Both implementations share the pinned source tape and accounting
inputs. Neither is a cold proof of the native construction or a physical
realization.

The result does **not** rule out changed surviving paid sender equations
away from a new owner's own source, recoding or propagation through a new
interior carrier, new paid contacts, changed frames, changed old surviving
helper endpoints, a different caller, or other contact families. Those are
the next necessary ways out of this particular zero-block cut. Physical
stock, owned erasure, finite precision, compiler guarantees and analytic
recovery remain separate obligations.

## Reproduce

Use CPython 3.11+ in a fresh directory with the included pinned producer and
geometry archives. `producer.tar.gz` is the unmodified producer archive
inside #7985's replay bundle; `geometry-7983.tar.gz` is the #7983 replay.

```sh
mkdir producer
tar -xzf producer.tar.gz -C producer
(cd producer && sha256sum -c SHA256SUMS)
python3 -IB multi_projection.py > MULTI-PROJECTION.log
python3 -IB source_check.py
python3 -IB independent_audit.py > INDEPENDENT-AUDIT.log
python3 -IB joint_control.py > JOINT-CONTROL.log
python3 -IB subset_bounds.py > SUBSET-BOUNDS.log
python3 -IB subset_audit.py > SUBSET-AUDIT.log
```

The archives contain their original Apache-2.0 license, authorship notices,
source pins and input hashes. No upstream or IntegerGraph changes were made.
