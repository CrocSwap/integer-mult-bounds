#!/usr/bin/env python3
"""Bind the prior 89/660 graph and grade-7 roster to the new calculations."""
import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    archive = ROOT/'geometry-7983.tar.gz'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'd1ec2eb1918615632863a104cbd56fb3270d7c5b995635d6ed1cf1c63addf44e'
    with tarfile.open(archive) as tar:
        old = json.load(tar.extractfile('./OPTIMISTIC.json'))
    new = json.loads((ROOT/'MULTI-PROJECTION.json').read_text())
    assert old['source']['word_canonical'] == new['pins']['word_canonical']
    assert old['source']['head'] == new['pins']['head']
    seed = next(c for c in new['cases'] if c['ports'] == [89] and c['helpers'] == [660])
    assert old['port89_helper660']['projected_zero_paid_packet_ids'] == seed['omitted_packet_ids']
    prev = json.loads((ROOT/'producer/NEW-BIRTH-DECODERS.json').read_text())['witnesses']
    expected = {6, 11, 17, 56, 57, 67, 68, 69}
    assert {x['port'] for x in prev if x['grade'] == 7} == expected
    joint = next(c for c in new['cases'] if c['ports'] == [6, 11, 89] and c['helpers'] == [660])
    for p in (6, 11):
        x = next(x for x in prev if x['port'] == p and x['grade'] == 7)
        source = joint['grade7_sources'][str(p)]
        assert x['start'] == source['source_chart']
        assert x['inject'] in source['injection_witnesses']
        assert x['relation'] in joint['bank_dependences']['1']
    print('PASS 7983 89/660 holes; 7985 eight-grade-7 roster and 6/11 witnesses')


if __name__ == '__main__':
    main()
