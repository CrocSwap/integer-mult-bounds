#!/usr/bin/env python3
"""Exact bank-rank gate for projected P104 contacts and jointly injected owners.

The source-only edit family permits arbitrary XOR injection of each fresh,
independent input in every retained send from its own initial chart. Original
terminal equations may be redecoded from historical stock for free. Original
packet routes, frames, and all other sender equations are fixed. The protected
bridge is required to remain pure. No IntegerGraph or upstream writes occur.
"""
import itertools
import json
import sys
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'producer'))
from birth_decoder import *  # noqa: F401,F403; pinned, hash-checked source

K = Decimal('0.00388')
FAMILY = (6, 11, 17, 56, 57, 67, 68, 69)


def image_basis(columns):
    """Eliminate GF(2) values while carrying an actual input combination."""
    s = Span()
    for value, witness in columns:
        s.add(value, witness)
    return list(s.rows.values())


def image_values(basis):
    values = [(0, 0)]
    for v, m in basis:
        values += [(x ^ v, a ^ m) for x, a in values]
    return values


def signed_projection(ports, helpers, holes):
    diff = Counter({1: 4 * len(ports), 127: -2 * len(ports)})
    for i in range(1, 9):
        diff[7*i] += 4 * len(ports)
    for i in range(1, 10):
        diff[1+7*i] -= 4 * len(ports)
    for p in holes:
        diff[G[p]] += 36
    for h in helpers:
        diff[grade(W['start'][h], W['final'][h])] -= 36
    return diff


def price(hist):
    return prices.display(prices.moment({}, hist, K))


def screen(ports, helpers):
    removed = set(helpers) | {i for p in ports for i in (p, p+111)}
    rt, rows, fw, path, adj, target, sens = build_projection(
        sum(1 << i for i in removed)
    )
    banks, out = defaultdict(list), defaultdict(list)
    for i in target:
        banks[W['start'][i]].append(i)
    for p, (a, b) in rt.items():
        banks[b].append(p)
        out[a].append(p)
    relations = {
        c: kernel((fw[p], 1 << p) for p in ps)
        for c, ps in banks.items()
    }
    relations = {c: rs for c, rs in relations.items() if rs}
    rels = relations.get(1, [])
    relation_paths = [xsum(path[p] for p in labels(r) if p >= 680)
                      for r in rels]

    def signature(x):
        return sum(((x & p).bit_count() & 1) << j
                   for j, p in enumerate(relation_paths))

    source0 = [p for p in out[0] if p != 3553]
    source0_sig = [signature(1 << p) for p in source0]
    source0_rank = len(image_basis((s, 1 << p)
                                  for p, s in zip(source0, source0_sig)))
    source_results = {}
    source_bases = {}
    for port in ports:
        if port not in FAMILY:
            continue
        c = W['start'][port]
        assert grade(c, 1) == 7
        local = sum(1 << i for i in target
                    if W['final'][i] in (c, 1) and i != 411)
        columns = [((adj[p] & ~local) |
                    ((1 << 680) if path[3553] >> p & 1 else 0), 1 << p)
                   for p in out[c] if p != 3553]
        free_injections = kernel(columns)
        basis = image_basis((signature(x), x) for x in free_injections)
        source_bases[port] = basis
        source_results[str(port)] = {
            'source_chart': c,
            'source_packets': sorted(out[c]),
            'unconstrained_transfer_rank': len(image_basis(
                (signature(1 << p), 1 << p) for p in out[c] if p != 3553)),
            'permitted_transfer_rank': len(basis),
            'permitted_relation_vectors': [v for v, _ in basis],
            'injection_witnesses': [list(labels(x)) for _, x in basis],
        }

    all_source_roster = None
    if set(ports) == {6, 89} and set(helpers) == {660}:
        all_source_roster = []
        for c, sends in sorted(out.items()):
            g = grade(c, 1)
            if not g:
                continue
            local = sum(1 << i for i in target
                        if W['final'][i] in (c, 1) and i != 411)
            columns = [((adj[p] & ~local) |
                        ((1 << 680) if path[3553] >> p & 1 else 0), 1 << p)
                       for p in sends if p != 3553]
            free = kernel(columns)
            witness = next((x for x in free if signature(x)), None)
            if witness is not None:
                all_source_roster.append({
                    'source_chart': c, 'sink_chart': 1, 'grade': g,
                    'injection': list(labels(witness)),
                    'sink_relation_signature': signature(witness),
                })

    matches = []
    grade7 = sorted(source_bases)
    for a, b in itertools.combinations(grade7, 2):
        witness = None
        for va, xa in image_values(source_bases[a]):
            for vb, xb in image_values(source_bases[b]):
                if va and vb and va != vb:
                    witness = {'vectors': [va, vb],
                               'injections': [list(labels(xa)), list(labels(xb))]}
                    break
            if witness:
                break
        matches.append({'ports': [a, b], 'independent_matching': bool(witness),
                        'witness': witness})

    hist = signed_projection(ports, helpers, set(R) - set(rt))
    ideal = hist.copy()
    # When only chart 1 has r relations, at most r new independent owners can
    # end away from their source. If source0 has zero sensitivity, each of
    # those returns is worth at most grade 7. This grants the r returns free.
    ideal_certified = set(relations) <= {1} and source0_rank == 0
    if ideal_certified:
        ideal[7] += 36 * len(rels)
    return {
        'ports': list(ports), 'helpers': list(helpers),
        'removed_owners': sorted(removed),
        'retained_owners': len(target), 'retained_packets': len(rt),
        'omitted_packet_ids': sorted(set(R) - set(rt)),
        'omitted_grades': dict(sorted(Counter(G[p] for p in set(R) - set(rt)).items())),
        'bank_dependences': {str(c): [list(labels(r)) for r in rs]
                             for c, rs in sorted(relations.items())},
        'source0_packet_count': len(source0),
        'source0_transfer_rank': source0_rank,
        'source0_nonzero_packet_signatures': {str(p): s for p, s in zip(source0, source0_sig) if s},
        'grade7_sources': source_results,
        'single_helper_all_source_roster': all_source_roster,
        'grade7_pair_matchings': matches,
        'projection_signed_bins_36_calls': dict(sorted(hist.items())),
        'projection_delta': price(hist),
        'ideal_free_return_count': len(rels) if ideal_certified else None,
        'ideal_free_grade7_returns_delta_upper': price(ideal) if ideal_certified else None,
    }


def main():
    cases = []
    for ports, helpers in [((89,), (660,)), ((6,), ()), ((6, 89), ()),
                           ((6, 89), (660,))]:
        cases.append(screen(ports, helpers))
    for a, b in itertools.combinations(FAMILY, 2):
        for add89 in (False, True):
            ports = (a, b, 89) if add89 else (a, b)
            helpers = (660,) if add89 else ()
            cases.append(screen(ports, helpers))
            print('checked', ports, helpers, flush=True)
    payload = {
        'pins': public_source(),
        'rate': str(K),
        'grade7_port_family': list(FAMILY),
        'scope': 'Actual projected packets and bank rows; source-only injections, '
                 'free historical stock and arbitrary local terminal redecoding. '
                 'Original frames/routes and protected bridge fixed. Ideal bound '
                 'also grants free independent returns.',
        'cases': cases,
    }
    (ROOT / 'MULTI-PROJECTION.json').write_text(json.dumps(payload, indent=2, sort_keys=True) + '\n')
    print('done', len(cases), flush=True)


if __name__ == '__main__':
    main()
