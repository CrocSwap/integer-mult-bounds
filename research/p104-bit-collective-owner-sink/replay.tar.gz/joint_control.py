#!/usr/bin/env python3
"""Compile and fully price the simultaneous ports-6/11, 89/660 control."""
import gzip
import hashlib
import json
import sys
from collections import Counter
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'producer'))
from new_birth import *  # noqa: F401,F403; pinned, hash-checked source
from late_control import programmer
from whole_prices import complete_caller


def main():
    cases = json.loads((ROOT / 'MULTI-PROJECTION.json').read_text())['cases']
    case = next(c for c in cases if c['ports'] == [6, 11, 89]
                and c['helpers'] == [660])
    match = case['grade7_pair_matchings'][0]['witness']
    assert match['vectors'] == [1, 2]
    gone = set(case['removed_owners'])
    moves, rows, fw, path, adj, target, sens = build_projection(
        sum(1 << i for i in gone))
    initial = {i: W['start'][i] for i in target}
    final = {i: W['final'][i] for i in target}
    axes = (4000, 4001)
    sources = (8, 13)
    rels = [sum(1 << p for p in r) for r in case['bank_dependences']['1']]
    corrections = {}
    for axis, source, injected, rel in zip(axes, sources, match['injections'], rels):
        initial[axis], final[axis] = source, 1
        a = sum(1 << p for p in injected)
        for p in injected:
            assert moves[p][0] == source and p != 3553
            rows[p] ^= 1 << axis
        rows[~axis] = rel
        corrections[axis] = []
        for i in target:
            if (a & sens[i]).bit_count() % 2:
                assert i != 411 and final[i] in (source, 1)
                rows[~i] ^= (1 << axis) if final[i] == source else rel
                corrections[axis].append(i)

    native = programmer()
    order = native.schedule(initial, final, moves, rows)
    word = native.emit_word(W, initial, final, moves, rows, order)
    atlas = op.Atlas(W['frames'])
    old = sorted(initial)
    ix = {a: b for b, a in enumerate(old)}
    expected = [1 << i for i in range(len(old))]
    for p in range(111):
        if p not in gone:
            expected[ix[111+p]] ^= 1 << ix[p]
    transpose = [sum((row >> i & 1) << j for j, row in enumerate(expected))
                 for i in range(len(old))]
    forward, reverse = [op.run_tape(word, atlas, reverse) for reverse in (False, True)]
    assert forward.output == expected and reverse.output == transpose
    assert Counter(p.grade for p in forward.packets.values()) == Counter(G[p] for p in moves)
    assert Counter(p.grade for p in reverse.packets.values()) == Counter(G[p] for p in moves)
    protected = []
    for tape in (forward, reverse):
        b = [k for k, p in tape.packets.items() if p.arrival.row & (1 << ix[411])]
        assert len(b) == 1 and tape.packets[b[0]].arrival.row == 1 << ix[411]
        protected.append(b)

    # Use an explicitly nonscalar sink basis: first return z0+z1 and z1,
    # then perform the actual local decoding ADD at their common chart 1.
    # Both words must implement the same full operator and paid routes.
    mixed_rows = rows.copy()
    mixed_rows[~axes[0]] ^= rels[1]
    mixed_word = native.emit_word(W, initial, final, moves, mixed_rows, order)
    mixed_word['program'].append(['ADD', ix[axes[0]], ix[axes[1]], 1])
    mfwd, madj = [op.run_tape(mixed_word, atlas, reverse) for reverse in (False, True)]
    assert mfwd.output == expected and madj.output == transpose
    assert Counter(p.grade for p in mfwd.packets.values()) == Counter(G[p] for p in moves)
    assert Counter(p.grade for p in madj.packets.values()) == Counter(G[p] for p in moves)

    baseword, caller, _, _, _, paid0, targets0, rat = prices.baseline()
    assert complete_caller(baseword, 111, caller, atlas) == (paid0, targets0)
    paid, targets = complete_caller(word, 108, caller, atlas)
    assert complete_caller(mixed_word, 108, caller, atlas) == (paid, targets)
    rate = Decimal('0.00388')
    binary = prices.moment(paid, targets, rate)
    difference = prices.minus(binary, prices.moment(paid0, targets0, rate))
    assert difference[0] <= Decimal(case['ideal_free_grade7_returns_delta_upper'][1])
    assert Decimal(case['ideal_free_grade7_returns_delta_upper'][0]) <= difference[1]
    ratp = {int(k): v for k, v in rat['signed']['paid'].items()}
    ratt = {int(k): v for k, v in rat['signed']['productive'].items()}

    # Both endpoint decoders are necessary. Recompile with each independently
    # suppressed; this checks that the observed two-axis support is not aliasing.
    corrupted = []
    for z in axes:
        bad = rows.copy()
        bad[~z] = 0
        wbad = native.emit_word(W, initial, final, moves, bad, order)
        aa, bb = [op.run_tape(wbad, atlas, reverse) for reverse in (False, True)]
        damaged = [sum(x != y for x, y in zip(aa.output, expected)),
                   sum(x != y for x, y in zip(bb.output, transpose))]
        assert min(damaged) > 0
        corrupted.append({'removed_output': z, 'damaged_rows_forward_adjoint': damaged})

    raw = gzip.compress(json.dumps(word, sort_keys=True, separators=(',', ':')).encode(),
                        compresslevel=9, mtime=0)
    raw = raw[:9] + bytes([3]) + raw[10:]
    (ROOT / 'JOINT-WORD.json.gz').write_bytes(raw)
    mixed_raw = gzip.compress(json.dumps(mixed_word, sort_keys=True, separators=(',', ':')).encode(),
                              compresslevel=9, mtime=0)
    mixed_raw = mixed_raw[:9] + bytes([3]) + mixed_raw[10:]
    (ROOT / 'MIXED-WORD.json.gz').write_bytes(mixed_raw)
    result = {
        'source': public_source(), 'rate': str(rate),
        'original_port_count': 111, 'new_port_count': 108,
        'projected_original_owners': sorted(gone),
        'new_owner_ids': list(axes), 'new_owner_routes': [[8, 1], [13, 1]],
        'old_relation_vectors_for_new_owners': match['vectors'],
        'injected_packets': match['injections'], 'old_output_corrections': corrections,
        'checked_forward_rows': len(expected), 'checked_adjoint_rows': len(transpose),
        'checked_operator_coefficients_per_direction': len(expected)**2,
        'bridge_packet_ids_per_direction': protected,
        'dirty_retirements_forward_adjoint': [forward.dirty, reverse.dirty],
        'corruption_controls': corrupted,
        'new_native_paid_grade_bins': dict(sorted(Counter(G[p] for p in moves).items())),
        'new_binary_caller_paid_bins': dict(sorted(paid.items())),
        'new_binary_caller_productive_bins': dict(sorted(targets.items())),
        'binary_margin': prices.display(binary), 'binary_change': prices.display(difference),
        'rational_margin_unchanged_48_calls': prices.display(prices.moment(ratp, ratt, rate)),
        'word_canonical_sha256': op.canonical_hash(word),
        'word_gzip_sha256': hashlib.sha256(raw).hexdigest(),
        'primitive_counts': dict(Counter(e[0] for e in word['program'])),
        'nonscalar_sink_basis': {
            'basis_matrix_rows': [[1, 1], [0, 1]],
            'local_decoding_add': [ix[axes[0]], ix[axes[1]], 1],
            'checked_forward_adjoint_rows': [len(mfwd.output), len(madj.output)],
            'dirty_retirements_forward_adjoint': [mfwd.dirty, madj.dirty],
            'same_complete_paid_and_productive_bins': True,
            'word_canonical_sha256': op.canonical_hash(mixed_word),
            'word_gzip_sha256': hashlib.sha256(mixed_raw).hexdigest(),
        },
    }
    (ROOT / 'JOINT-CONTROL.json').write_text(json.dumps(result, sort_keys=True, indent=2)+'\n')
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
