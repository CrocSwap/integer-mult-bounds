#!/usr/bin/env python3
"""Raw-tape second implementation of projection, owner maps and bank cuts."""
import gzip
import hashlib
import json
import sys
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / 'producer/source/vendor'
sys.path.insert(0, str(VENDOR))
import bit_native


def bits(x):
    while x:
        t = x & -x
        yield t.bit_length() - 1
        x ^= t


def combine(form, values):
    result = 0
    for k in bits(form):
        result ^= values.get(k, 0)
    return result


def dual(rows):
    out = {k: 0 for k in rows}
    for k, form in rows.items():
        dest = k if k >= 0 else ~k
        for j in bits(form):
            out[(~j if j < 680 else j)] ^= 1 << dest
    return out


def independently_project(removed, init, routes, rows, order):
    drows = dual(rows)
    holes = set()
    while True:
        old = len(holes)
        for direction, forms, seq in ((0, rows, order), (1, drows, order[::-1])):
            v = {i: (0 if i in removed else 1 << i) for i in init}
            for p in seq:
                v[p] = 0 if p in holes else combine(forms[p], v)
                if not v[p] and p != 3553:
                    holes.add(p)
        if len(holes) == old:
            break
    inputs = set(init) - removed
    live = {p: ab for p, ab in routes.items() if p not in holes}
    erased = sum(1 << j for j in removed | holes)
    projected = {p: form & ~erased for p, form in rows.items()
                 if p in live or (p < 0 and ~p in inputs)}
    return inputs, live, projected, holes


def replay(inputs, routes, rows, order, transpose=False):
    if transpose:
        rows = dual(rows)
        order = order[::-1]
    values = {j: 1 << j for j in inputs}
    for p in order:
        if p in routes:
            values[p] = combine(rows[p], values)
    for i in inputs:
        expected = 1 << i
        if transpose and i < 111 and i+111 in inputs:
            expected ^= 1 << (i+111)
        if not transpose and 111 <= i < 222 and i-111 in inputs:
            expected ^= 1 << (i-111)
        assert combine(rows[~i], values) == expected, (transpose, i)
    return values


def relations(vectors):
    # Pivot in the opposite direction to the producer, carrying original labels.
    pivots, kernel = {}, []
    for label, value in vectors:
        what = 1 << label
        while value:
            pivot = (value & -value).bit_length() - 1
            if pivot not in pivots:
                pivots[pivot] = (value, what)
                break
            v, q = pivots[pivot]
            value ^= v
            what ^= q
        if not value:
            kernel.append(what)
    return kernel


def calculate(case, initial, final, routes, rows, order, frames):
    removed = set(case['removed_owners'])
    inputs, live, projected, holes = independently_project(removed, initial, routes, rows, order)
    assert sorted(holes) == case['omitted_packet_ids']
    assert (len(inputs), len(live)) == (case['retained_owners'], case['retained_packets'])
    fwd = replay(inputs, live, projected, order)
    replay(inputs, live, projected, order, transpose=True)
    banks = defaultdict(list)
    for i in inputs:
        banks[initial[i]].append(i)
    for p, (a, b) in live.items():
        banks[b].append(p)
    dep = {c: relations((p, fwd[p]) for p in ls) for c, ls in banks.items()}
    dep = {c: rs for c, rs in dep.items() if rs}
    assert {str(c): len(rs) for c, rs in dep.items()} == {
        c: len(rs) for c, rs in case['bank_dependences'].items()}
    for c, ls in case['bank_dependences'].items():
        for r in ls:
            assert combine(sum(1 << p for p in r), fwd) == 0

    # Taint each source-0 send independently and propagate through the actual
    # retained sender forms. No terminal-output constraints are used here.
    taint = {i: 0 for i in inputs}
    for p in order:
        if p in live:
            taint[p] = combine(projected[p], taint) ^ ((1 << p) if live[p][0] == 0 else 0)
    leak = [combine(rel, taint) for rel in dep.get(1, [])]
    assert not any(leak)
    assert case['source0_transfer_rank'] == 0

    # Check the recorded two-source matrix against *all* the retained packet
    # forms, not against a list of precomputed taint sensitivities.
    match_count = 0
    for match in case['grade7_pair_matchings']:
        if not match['independent_matching']:
            continue
        witness = match['witness']
        source_rels = [sum(1 << p for p in r) for r in case['bank_dependences']['1']]
        for injection, expected_vector in zip(witness['injections'], witness['vectors']):
            selected = set(injection)
            signal = {i: 0 for i in inputs}
            for p in order:
                if p in live:
                    signal[p] = combine(projected[p], signal) ^ (p in selected)
            vector = sum((combine(r, signal) & 1) << j for j, r in enumerate(source_rels))
            assert vector == expected_vector
        assert witness['vectors'][0] and witness['vectors'][1]
        assert witness['vectors'][0] != witness['vectors'][1]
        match_count += 1

    # Reprice the exact signed bins with a separate high-precision exp/log path.
    with localcontext() as ctx:
        ctx.prec = 110
        rate = Decimal('0.00388')
        def H(g):
            return ((Decimal(1)-rate)*Decimal(g).ln()).exp() if g > 1 else Decimal(g)
        n = len(case['ports'])
        delta = n*(Decimal(4) + 4*sum(H(7*i) for i in range(1,9)) -
                   2*H(127) - 4*sum(H(1+7*i) for i in range(1,10)))
        delta += 36*sum(H(abs(frames[str(routes[p][0])]['dim'] -
                                  frames[str(routes[p][1])]['dim'])) for p in holes)
        delta -= 36*sum(H(abs(frames[str(initial[h])]['dim'] -
                                  frames[str(final[h])]['dim'])) for h in case['helpers'])
        if 'projection_delta' in case:
            xlo, xhi = map(Decimal, case['projection_delta'])
            assert xlo <= delta <= xhi
        if case['ideal_free_grade7_returns_delta_upper']:
            delta += 36*len(dep.get(1, []))*H(7)
            xlo, xhi = map(Decimal, case['ideal_free_grade7_returns_delta_upper'])
            assert xlo <= delta <= xhi

    return {
        'ports': case['ports'], 'helpers': case['helpers'],
        'replayed_owners_per_direction': len(inputs),
        'native_operators_pass': True,
        'retained_packets': len(live),
        'independent_bank_ranks': {str(c): len(rs) for c, rs in dep.items()},
        'independent_chart0_sensitivity': 'identically zero',
        'grade7_witnesses_checked': match_count,
        'independently_repriced': True,
    }


def main():
    raw = (ROOT/'producer/source/inputs/WORD.json.gz').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
    word = json.loads(gzip.decompress(raw))
    initial, final, routes, rows, clocks = bit_native.extract(word)
    order = sorted(routes, key=clocks.get)
    cases = json.loads((ROOT/'MULTI-PROJECTION.json').read_text())['cases']
    result = [calculate(c, initial, final, routes, rows, order, word['frames']) for c in cases]
    payload = {
        'cases': len(result),
        'projection_comparison': 'all exact',
        'both_projected_operators': 'all exact',
        'chart0_sensitivity': 'zero in every case',
        'rank_census': dict(Counter(str(c['independent_bank_ranks']) for c in result)),
        'grade7_pair_witnesses': sum(c['grade7_witnesses_checked'] for c in result),
        'all_signed_price_enclosures_verified': True,
        'case_results': result,
    }
    (ROOT/'INDEPENDENT-AUDIT.json').write_text(json.dumps(payload, sort_keys=True, indent=2)+'\n')
    print('PASS', len(result), payload['rank_census'], payload['grade7_pair_witnesses'])


if __name__ == '__main__':
    main()
