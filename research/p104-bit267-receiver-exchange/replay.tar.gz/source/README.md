# Two adjacent BIT components: rational chart price screen

For the pinned #7830 binary supplier, no joint recharting of any **two paid-adjacent movable cochart components** has positive complete signed gain at κ = `0.003879929046155`, under the fixed-incidence contract below. The screen allows arbitrary rational subspaces of Q⁸, including charts absent from the 636-chart source atlas. It is a finite computation based on exact rational linear algebra and directed price intervals. It constructs no improved word and establishes no new κ bound.

The complete unchanged 36-call signed balance at this trial is

```
[-0.000385127316613866441054139472099789196374646204,
 -0.000385127316613866441054139472099789196374646203].
```

The source packet graph has 656 cochart components, 2,874 paid contacts and 458 independent helper targets. There are 968 distinct paid-adjacent pairs after anchoring the 222 main-port endpoints, owner 411's two endpoints, and the protected owner-411 bridge/tree components. A tested pair may include a movable helper endpoint. All other components and packet forms are fixed. For both changed components, the price includes every affected paid and productive incidence, both at their common contacts and at their fixed exterior neighbors. Every helper remains strictly oriented from its input to output. A paid contact whose two spaces coincide is optimistically treated as a free local operation.

| Rational-space screen | Assignment evaluations |
| --- | ---: |
| Rank pairs compatible with each component's fixed exterior | 12,889 |
| Zero signed histogram | 1,283 |
| Strictly negative signed gain | 11,556 |
| Positive price before testing joint geometry | 50 |
| Positive cases excluded by exact joint geometry | 50 |

Assignment evaluations may recur across different supports. Each of the 50 apparent positive cases has an explicit dimension certificate in [ARBITRARY.json](ARBITRARY.json). Twenty-five fail to fit the required low space inside both upper spaces; the other 25 require a high space of dimension larger than the proposed rank. A constructive exact coupled-space extension check agrees with a separate intersection-dimension test for every positive-price case. A signed histogram is priced as the change in `Σ targets r^(1−κ) − Σ paid r^(1−κ)`, multiplied by all 36 native calls. The unchanged caller terms cancel in the difference, and the full source histogram supplies the baseline above.

An independent fixed-atlas control lets each of the two components choose any of the original 636 charts. It admits 240,365 assignments under an optimistic good-prime geometry filter: 228,299 give an exactly zero histogram and 12,066 give strictly negative gains. Its 202 distinct signed histograms pass directed integer-square-root pricing. The exact rational source frames all retain full rank modulo 65521, so reducing a genuine rational containment cannot eliminate it. Equal-rank modular coincidences are allowed in the filter; hence the filter is a superset even if two different source charts happened to coincide modulo that prime. [RESULT.json](RESULT.json)

This result keeps the original scalar packet dependencies and chronology, all other components and productive identities, and the protected boundary contract. It does **not** cover changing three or more components, nonadjacent pairs, adding or changing packet forms, caller changes, or edits to the protected endpoints/tree. It does not establish a physical implementation of any zero-price assignment or exclude a different paid interface. No changed word, exact candidate replay, finite compiler qualification, ordinary-cost qualification or improved conditional multiplication theorem is claimed.

## Controls

The source's full signed inventory is reconstructed, including 107,460 paid and 20,706 productive positions across the 36-call caller. The pinned original word passes all 462,400 native coefficients and all 1,444 caller polynomial coefficients in **each** orientation, all 3,554 dirty private retirements in each direction, the 111 main contacts, the owner-411 bridge omission control, and the original ordinary/owned-field account. These are **baseline** checks; they are not a replay of a changed recharting.

One retained earlier control moves components `(690, in)` and `(1710, in)` to chart 1. At the trial, complete signed gains are approximately −713.50916249194 for the first alone, −142.31126192744 for the second alone, and −712.73774425682 jointly. The joint amount counts their common paid incidence once; it is not the sum of the singleton bills. Repricing the case at the earlier S8 target reproduces its prior reported joint loss. A separate neutral helper-pair control checks both the paid and productive edge changes. The standalone verifier directly walks all original incidences for these controls.

A representative tempting rank proposal moves components `(-342, out)` and `(741, in)` to ranks 5 and 4. Its provisional 36-call signed gain is about `0.01572932621579`, larger than the unchanged trial deficit. Its required high space has dimension at least 6, however, while the proposed high rank is 5, so that price is not realizable under the frozen exterior contacts. See the exact certificate in [ARBITRARY.json](ARBITRARY.json).

## Why the geometry screen covers the stated family

For a proposed rank d and fixed exterior neighbors, the lower-rank neighbors must lie in the new space and the higher-rank neighbors must contain it. Equal-rank neighbors force equality. Let L be the span of required lower spaces and N the span of normals to required upper spaces. Exact rational RREF checks that `L ⊆ N⊥`, `dim L ≤ d`, and `dim N ≤ 8−d`. Target orientation is checked separately. These are the full exterior constraints for a rational subspace.

For a common paid contact, orient the two proposed spaces U ⊆ V by dimension d ≤ e. Let `L_U` and `L_V` be their lower bounds and `N_U`, `N_V` their upper normals. Put `S = (N_U + N_V)⊥` and `H = L_V`. The smaller U must contain `L_U` and lie in S. Subject to that condition, the minimum possible dimension of `H + U` is

```
dim H + max(dim L_U − dim(L_U ∩ H), d − dim(S ∩ H)).
```

If this minimum exceeds e, no V can satisfy the common contact and its exterior requirements. The second test explicitly constructs a minimal-overlap U and extends `H + U` to a rank-e V when possible. Both calculations use exact rational row reduction. Prices use two directed methods: rational-grid Taylor bounds and integer square-root bounds. All 50 provisional positive intervals have strictly positive lower bounds, so none is a numerical tie.

## Reproduce

Python 3.12; standard library only. From this directory:

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py > /tmp/bit-adjacent-atlas-result.json
cmp RESULT.json /tmp/bit-adjacent-atlas-result.json
python3 -I -B arbitrary.py > /tmp/bit-adjacent-rational-result.json
cmp ARBITRARY.json /tmp/bit-adjacent-rational-result.json
```

Both programs authenticate their relative source inputs. `verify.py` independently rebuilds the packet components and pair roster from the literal word, and reruns the source operator and complete atlas census. `arbitrary.py` rebuilds the same graph, enumerates every rank pair and fixed-exterior rational envelope, reprices the complete affected signed histogram, and checks every positive rank case by both geometry tests. Neither script requires network access or an earlier workspace. The two final measured runs took approximately 4.7 and 8.8 user CPU seconds, respectively, on the development machine; no heavy application qualification was run.

## Sources and credit

The comparator is [PR #7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, binary canonical word `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`, layout `a0ffffd99fb9b91f0013695877480766319ac51b926ed00dd5f7ec32f2d1e1a6`, and caller gzip `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`. The broader task's toolkit context is [PR #7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852), head `41beda1d6435760dc99e38bd7e65f36798aad212`; this screen derives no toolkit wall claim. [SOURCES.json](SOURCES.json) records file hashes, Git blobs and immutable source paths.

The packet and price controls extend prior local S7/S8 BIT chart screens. The source word, paired caller, exact operator checker, pricing routines and framework retain the authors and predecessors named in [NOTICE](NOTICE). The rational envelope and coupled-extension implementation adapts earlier local Apache-2.0 BIT pair geometry; the separate dimension criterion is added here. This screen was prepared for Clear1nsight with OpenAI Codex assistance. No independent human review is asserted.

## Open next questions

Can three or more connected components, altered packet payloads, or a new paid interface give a positive full signed invoice while preserving both orientations, every helper and the original protected outputs? A candidate would require an emitted legal word, all-column forward and adjoint replay, ownership and cleanup, and full supplier and application qualification.
