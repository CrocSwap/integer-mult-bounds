#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Exact fixed-incidence pair screen over arbitrary rational chart subspaces.

The lower/upper envelopes and constructive coupled-space test adapt the earlier
Apache-2.0 binary-whole-bank/pairs.py and binary-charts/whole_screen.py. An
independent intersection-dimension criterion checks every positive-price case.
"""
from collections import Counter,defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path
from hashlib import sha256
from types import SimpleNamespace
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
sys.path.insert(0,str(HERE))
import price
import verify as v
for path,digest in v.PINS.items():v.require(sha256((HERE/path).read_bytes()).hexdigest()==digest,'source lock '+path)
w=v.read('inputs/WORD.json.gz')
v.require(sha256(v.canon(w)).hexdigest()==v.WORD,'canonical word')
chart,raw_edges,frozen,pairs,routes=v.graph(w)
v.require((len(chart),len(raw_edges),len(frozen),len(pairs))==(656,3332,229,968),'graph census')
v.require(sha256(json.dumps(pairs,separators=(',',':')).encode()).hexdigest()==v.PAIR_SHA,'pair roster')
rank={int(k):frame['dim'] for k,frame in w['frames'].items()}
edges=[];incident=defaultdict(list)
for kind,key,a,b in raw_edges:
 edges.append(SimpleNamespace(kind=kind,key=key,source=a,target=b,grade=abs(rank[chart[a]]-rank[chart[b]])))
 incident[a].append(len(edges)-1);incident[b].append(len(edges)-1)
t=SimpleNamespace(word=w,charts=chart,rank=rank,edges=edges,incident=incident)
K=v.K;N=968
def rref(vectors):
 basis={}
 for vec in vectors:
  row=list(vec)
  for p,prior in sorted(basis.items()):
   if row[p]:row=[x-row[p]*y for x,y in zip(row,prior)]
  pivot=next((i for i,x in enumerate(row) if x),None)
  if pivot is None:continue
  row=[x/row[pivot] for x in row]
  for p,old in list(basis.items()):
   if old[pivot]:basis[p]=tuple(x-old[pivot]*y for x,y in zip(old,row))
  basis[pivot]=tuple(row)
 return tuple(basis[k] for k in sorted(basis))

def complement(b):
 pivots=[next(i for i,x in enumerate(row) if x) for row in b];out=[]
 for j in range(8):
  if j in pivots:continue
  row=[F(i==j) for i in range(8)]
  for p,v in zip(pivots,b):row[p]=-v[j]
  out.append(row)
 return rref(out)

def orth(a,b):return all(sum(x*y for x,y in zip(u,v))==0 for u in a for v in b)

B={int(k):rref(tuple(map(F,r)) for r in frame['B']) for k,frame in t.word['frames'].items()}
A={int(k):rref(tuple(map(F,r)) for r in frame['A']) for k,frame in t.word['frames'].items()}
assert all(A[k]==complement(B[k]) and len(B[k])==t.rank[k] for k in B)
@lru_cache(None)
def span(labels,dual):
 f=A if dual else B
 return rref(v for lab in labels for v in f[lab])
@lru_cache(None)
def envelope(neighbors,d):
 low=tuple(z for z in neighbors if t.rank[z]<=d)
 high=tuple(z for z in neighbors if t.rank[z]>=d)
 L,N=span(low,False),span(high,True)
 return (L,N) if len(L)<=d and len(N)<=8-d and orth(L,N) else None

def extend(base,families,target):
 for family in families:
  for row in family:
   if len(base)==target:return base
   base=rref((*base,row))
 return base

def coupled(first,second,d,e):
 assert d<=e
 l,ln=first;h,hn=second
 common=rref((*ln,*hn))
 if len(common)>8-d or not orth(l,common):return None
 hit=complement(rref((*common,*complement(h))))
 low=extend(l,(hit,complement(common)),d)
 if len(low)!=d:return None
 union=rref((*h,*low))
 if len(union)>e:return None
 high=extend(union,(complement(hn),),e)
 if len(high)!=e:return None
 assert orth(low,complement(high)) and orth(low,ln) and orth(high,hn)
 assert len(rref((*low,*l)))==d and len(rref((*high,*h)))==e
 return low,high

def dimension_test(first,second,d,e):
 # Independent dimension-only criterion for L<=U<=S and H<=V<=T, U<=V.
 # Maximize dim(U intersect H) while U contains L and is contained in S∩T.
 L,Ln=first;H,Hn=second
 common=rref((*Ln,*Hn));space=complement(common)
 if len(space)<d or not orth(L,common):
  return False,{'reason':'common-upper-space','common_upper_dim':len(space),'low_dim':d,'low_within_common':orth(L,common)}
 int_lh=len(L)+len(H)-len(rref((*L,*H)))
 int_sh=len(space)+len(H)-len(rref((*space,*H)))
 over=max(len(L)-int_lh,d-int_sh)
 minimum=len(H)+over
 return minimum<=e,{'reason':'coupled-union-rank','minimum_high_dim':minimum,'available_high_dim':e,'required_high_dim':len(H),'low_required_dim':len(L),'low_high_intersection':int_lh,'common_high_intersection':int_sh,'common_upper_dim':len(space)}

W={g:price.price(g,K) for g in range(1,9)}
W2={g:v.power_bounds(g,1-K,204) for g in range(1,9)}
def norm(h):return tuple((g,h[g]) for g in sorted(h) if g and h[g])
def delta(h,kind,old,new):
 s=1 if kind=='targets' else -1
 if old:h[old]-=s
 if new:h[new]+=s

def gain(h):
 lo=hi=0
 for g,c in h:
  a,b=W[g];lo+=36*c*(a if c>0 else b);hi+=36*c*(b if c>0 else a)
 return lo,hi

def gain2(h):
 lo=hi=F(0)
 for g,c in h:
  a,b=W2[g];lo+=36*c*(a if c>0 else b);hi+=36*c*(b if c>0 else a)
 return lo,hi

def fmt(iv):return price.decimal_interval(iv,48)

def ext(node,other):
 ids=[i for i in t.incident[node] if other not in (t.edges[i].source,t.edges[i].target)]
 peers=tuple(sorted({t.charts[t.edges[i].target if t.edges[i].source==node else t.edges[i].source] for i in ids}))
 opts=[]
 for d in range(9):
  bound=envelope(peers,d)
  if bound is None:continue
  h=Counter()
  for i in ids:
   edge=t.edges[i];a=d if edge.source==node else t.rank[t.charts[edge.source]];b=d if edge.target==node else t.rank[t.charts[edge.target]]
   if edge.kind=='targets' and b<=a:break
   delta(h,edge.kind,edge.grade,abs(a-b))
  else:opts.append((d,bound,h))
 return opts

def describe_basis(b):return [[str(x) for x in row] for row in b]

def runpair(pair):
 a,b=pair;inner=[i for i in set(t.incident[a])|set(t.incident[b]) if t.edges[i].source in pair and t.edges[i].target in pair]
 ca=ext(a,b);cb=ext(b,a);out=Counter();positive=[];rejected=[];best=None
 for (d,ea,ha),(e,eb,hb) in product(ca,cb):
  h=ha.copy();h.update(hb)
  for i in inner:
   ed=t.edges[i];r=d if ed.source==a else e;s=d if ed.target==a else e
   if ed.kind=='targets' and s<=r:break
   delta(h,ed.kind,ed.grade,abs(r-s))
  else:
   out['external_feasible_rank_pairs']+=1;hh=norm(h);iv=gain(hh)
   assert gain2(hh)[0]<=F(iv[1],price.GRID) and F(iv[0],price.GRID)<=gain2(hh)[1]
   if not hh:out['zero_hist']+=1;continue
   if iv[1]<0:out['nonpositive_hist']+=1;continue
   v.require(iv[0]>0,'directed price sign undecided')
   out['positive_before_joint_geometry']+=1
   first,second,dd,ee=(ea,eb,d,e) if d<=e else (eb,ea,e,d)
   fit=coupled(first,second,dd,ee)
   feasible,why=dimension_test(first,second,dd,ee)
   assert feasible==(fit is not None)
   if fit is None:
    out['positive_excluded_by_joint_geometry']+=1
    rejected.append({'dimensions':[d,e],'native_signed_hist':dict(hh),'gain':fmt(iv),'dimension_certificate':why})
    continue
   if d>e:fit=fit[::-1]
   out['positive_exact_geometry']+=1
   if best is None or iv[1]>best:best=iv[1]
   positive.append({'dimensions':[d,e],'native_signed_hist':dict(hh),'gain':fmt(iv),'basis':[describe_basis(f) for f in fit]})
 return {'pair':[list(x) for x in pair],'old_charts':[t.charts[x] for x in pair],
  'old_dimensions':[t.rank[t.charts[x]] for x in pair],'dimension_options':[[x[0] for x in ca],[x[0] for x in cb]],
  'joint_edges':[{'kind':t.edges[i].kind,'key':t.edges[i].key,'grade':t.edges[i].grade} for i in inner],
  'counts':dict(out),'positive_witnesses':positive,'rejected_positive':rejected}

out=[]
for i,p in enumerate(pairs[:N],1):
 result=runpair(p);out.append(result)
counts=dict(sum((Counter(x['counts']) for x in out),Counter()))
expected={'external_feasible_rank_pairs':12889,'zero_hist':1283,'nonpositive_hist':11556,
          'positive_before_joint_geometry':50,'positive_excluded_by_joint_geometry':50}
v.require(counts==expected,'arbitrary rational pair census')
rejected=[{'pair':r['pair'],**case} for r in out for case in r['rejected_positive']]
v.require(len(rejected)==50 and not any(r['positive_witnesses'] for r in out),'positive candidates all blocked')
print(json.dumps({'status':'PASS_ARBITRARY_RATIONAL_PAIR_PRICE_EXCLUSION',
 'scope':'Each of two paid-adjacent movable components independently chooses any rational subspace of Q^8. Other components, packet forms, all exterior incidences, helper directions, main endpoints and protected owner-411 bridge/tree fixed. Equal paid contacts inline free.',
 'kappa':'0.003879929046155','supports':len(out),'all_supports':len(pairs),'counts':counts,
 'positive_exclusion_certificates':rejected,'new_word_constructed':False},indent=2,sort_keys=True))
