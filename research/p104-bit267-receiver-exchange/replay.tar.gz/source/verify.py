#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Independent, standard-library replay of the fixed-atlas BIT pair screen.

Packet-component construction and modular subspace tests are implemented here.
The pinned binary operator replay in vendor/ verifies the unchanged native word
and caller. Power enclosures use directed integer square roots.
"""
from collections import Counter, defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from hashlib import sha256
from math import isqrt
from pathlib import Path
import gzip, json, sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'vendor'))
import binary_operator as op

PINS={
 'inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'inputs/BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
 'vendor/binary_operator.py':'36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349',
 'vendor/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'vendor/price.py':'d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b'}
WORD='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
LAYOUT='a0ffffd99fb9b91f0013695877480766319ac51b926ed00dd5f7ec32f2d1e1a6'
PAIR_SHA='161b561ffae3ae8e30f17ca57af6ee933143dcc872f69f2da254c28acad1270d'
K=Q('0.003879929046155');P=65521;CALLS=36

def require(ok,msg):
 if not ok:raise ValueError(msg)
def read(p):
 raw=(HERE/p).read_bytes()
 return json.loads(gzip.decompress(raw) if p.endswith('.gz') else raw)
def canon(o):return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def rows(mask):
 while mask:
  z=mask&-mask;yield z.bit_length()-1;mask^=z

def power_bounds(rank,exponent,bits=204):
 """Directed square-root and multiplication bounds for rank**exponent."""
 require(1<=rank and 0<exponent<1,'positive fractional power')
 S=1<<bits;digits,rem=divmod(exponent.numerator*S,exponent.denominator)
 lower=upper=S;rl=ru=rank*S
 for shift in range(bits-1,-1,-1):
  rl=isqrt(rl*S);z=ru*S;ru=isqrt(z)+(isqrt(z)**2<z)
  if digits & (1<<shift):
   lower=lower*rl//S;upper=(upper*ru+S-1)//S
 if rem:upper=(upper*ru+S-1)//S
 return Q(lower,S),Q(upper,S)
W={r:power_bounds(r,1-K) for r in range(1,135)}
@lru_cache(None)
def signed(hist):
 lo=hi=Q(0)
 for r,n in hist:
  a,b=W[r];lo+=n*(a if n>0 else b);hi+=n*(b if n>0 else a)
 return lo,hi

def hkey(h):return tuple((r,h[r]) for r in sorted(h) if r and h[r])
def decimals(interval,places=48):
 scale=10**places;lo,hi=interval
 a=(lo.numerator*scale)//lo.denominator
 b=-((-hi.numerator*scale)//hi.denominator)
 def fmt(x):
  sign='-' if x<0 else '';x=abs(x);return f'{sign}{x//scale}.{x%scale:0{places}d}'
 return [fmt(a),fmt(b)]

class DSU:
 def __init__(self):self.p={}
 def root(self,v):
  if v not in self.p:self.p[v]=v
  if self.p[v]!=v:self.p[v]=self.root(self.p[v])
  return self.p[v]
 def join(self,a,b):
  a=self.root(a);b=self.root(b)
  if a!=b:self.p[max(a,b)]=min(a,b)

def graph(word):
 n=word['public'];state=[1<<j for j in range(n)]+[0]*word['owned_fields']
 routes={};forms={}
 for clock,event in enumerate(word['program']):
  code,r,*args=event
  if code=='MOVE':
   k=n+len(routes);routes[k]=(args[0],args[1]);forms[k]=state[r];state[r]=1<<k
  elif code=='ADD':state[r]^=state[args[0]]
  elif code=='SWAP':state[r],state[args[0]]=state[args[0]],state[r]
  else:
   require(code in ('INIT','CLEAR'),'packet opcode');state[r]=0
 forms.update({~i:state[i] for i in range(n)})
 # Verify extracted packet forms compose to the native operator on all inputs.
 expanded={i:1<<i for i in range(n)}
 for k in sorted(routes):
  value=0
  for j in rows(forms[k]):
   require(j in expanded,'packet chronological dependency');value^=expanded[j]
  expanded[k]=value
 for i in range(n):
  value=0
  for j in rows(forms[~i]):value^=expanded[j]
  expected=(1<<i)^((1<<(i-111)) if 111<=i<222 else 0)
  require(value==expected,'packet operator')
 d=DSU()
 for i in range(n):d.root((i,'in'));d.root((~i,'out'))
 for k in routes:d.root((k,'in'));d.root((k,'out'))
 for k,mask in forms.items():
  for j in rows(mask):d.join((j,'in'),(k,'out'))
 groups=defaultdict(list)
 for v in list(d.p):groups[d.root(v)].append(v)
 comp={v:min(group) for group in groups.values() for v in group};chart={}
 def bind(v,c):
  root=comp[v];require(chart.setdefault(root,c)==c,'component chart consistency')
 for i in range(n):bind((i,'in'),word['start'][i]);bind((~i,'out'),word['final'][i])
 for k,(a,b) in routes.items():bind((k,'out'),a);bind((k,'in'),b)
 edges=[('paid',k,comp[(k,'out')],comp[(k,'in')]) for k in sorted(routes)]
 edges.extend(('targets',i,comp[(i,'in')],comp[(~i,'out')]) for i in range(222,n))
 frozen={comp[v] for i in range(222) for v in ((i,'in'),(~i,'out'))}
 frozen.update((comp[(411,'in')],comp[(~411,'out')]))
 protected={(509,0),(390,509),(517,390)}
 for kind,k,a,b in edges:
  if kind=='paid' and (k==3553 or (chart[a],chart[b]) in protected):frozen.update((a,b))
 pairs={tuple(sorted((a,b))) for kind,k,a,b in edges if kind=='paid' and a!=b and a not in frozen and b not in frozen}
 return chart,edges,frozen,sorted(pairs),routes

def rankmod(rows_):
 basis={}
 for source in rows_:
  row=[x%P for x in source]
  for k,v in sorted(basis.items()):
   if row[k]:
    factor=row[k];row=[(a-factor*b)%P for a,b in zip(row,v)]
  k=next((i for i,x in enumerate(row) if x),None)
  if k is None:continue
  inv=pow(row[k],-1,P);basis[k]=[(x*inv)%P for x in row]
 return len(basis)

def prepare_frames(word):
 f={int(k):v for k,v in word['frames'].items()};require(sorted(f)==list(range(636)),'chart atlas')
 for k,x in f.items():
  B,A=x['B'],x['A'];d=x['dim']
  require(len(B)==d and len(A)==8-d and rankmod(B)==d and rankmod(A)==8-d and rankmod(B+A)==8,'safe modular frame ranks')
  require(all(sum(a*b for a,b in zip(v,w))%P==0 for v in B for w in A),'modular orthogonality')
 return f

def nested_mod(a,b):
 return all(sum(x*y for x,y in zip(v,w))%P==0 for v in a['B'] for w in b['A'])

def apply_delta(h,kind,old,new):
 weight=1 if kind=='targets' else -1
 if old:h[old]-=weight
 if new:h[new]+=weight

def main():
 for path,digest in PINS.items():require(sha256((HERE/path).read_bytes()).hexdigest()==digest,'source lock '+path)
 w=read('inputs/WORD.json.gz');caller=read('inputs/EFREE-CALLER.json.gz');receipt=read('inputs/BIT.json')
 require(sha256(canon(w)).hexdigest()==WORD and sha256(canon({k:w[k] for k in ('frames','start','final')})).hexdigest()==LAYOUT,'word and layout canonical pins')
 atlas=op.Atlas(w['frames']);require(atlas.main_contacts(w['start'],w['final'])==111,'native main ports')
 forward,backward,omitted=op.native_checks(w,atlas)
 np,nt,full_paid,full_targets=op.binary_invoice(w,caller,atlas,forward)
 for actual,name in ((np,'native_paid'),(nt,'native_targets'),(full_paid,'paid'),(full_targets,'targets')):
  require(actual==Counter({int(k):v for k,v in receipt['native'][name].items()}),'source native/full '+name)
 ordinary=op.ordinary_boundary(w,caller,full_paid,full_targets)
 chart,edges,frozen,pairs,routes=graph(w)
 require((len(chart),len(edges),len(routes),len(frozen),len(pairs))==(656,3332,2874,229,968),'component census')
 require(sha256(json.dumps(pairs,separators=(',',':')).encode()).hexdigest()==PAIR_SHA,'pair census hash')
 frames=prepare_frames(w);dim={k:f['dim'] for k,f in frames.items()}
 @lru_cache(None)
 def legal(a,b):
  da,db=dim[a],dim[b]
  if da==db:
   return 0 if nested_mod(frames[a],frames[b]) and nested_mod(frames[b],frames[a]) else None
  low,high=(a,b) if da<db else (b,a)
  return abs(da-db) if nested_mod(frames[low],frames[high]) else None
 @lru_cache(None)
 def legal_set(a):return frozenset(b for b in frames if legal(a,b) is not None)
 incident=defaultdict(list);native_paid=Counter();native_targets=Counter()
 for i,(kind,k,a,b) in enumerate(edges):
  incident[a].append(i);incident[b].append(i)
  g=legal(chart[a],chart[b]);require(g is not None and g>0,'original incidence geometry')
  if kind=='targets':
   require(dim[chart[b]]>dim[chart[a]],'original helper direction');native_targets[g]+=1
  else:native_paid[g]+=1
 require(native_paid==np and native_targets==nt,'graph-to-receipt native counts')
 def quote(changes):
  h=Counter()
  for kind,k,a,b in edges:
   if a not in changes and b not in changes:continue
   aa=changes.get(a,chart[a]);bb=changes.get(b,chart[b]);da,db=dim[aa],dim[bb]
   if da==db:
    if aa!=bb:return None
    g=0
   else:
    low,high=(aa,bb) if da<db else (bb,aa)
    if not op.annihilates(atlas.body[low],atlas.dual[high]):return None
    g=abs(da-db)
   if kind=='targets' and db<=da:return None
   apply_delta(h,kind,abs(dim[chart[a]]-dim[chart[b]]),g)
  return hkey(h)
 a=(690,'in');b=(1710,'in')
 controls={}
 for name,c,h in (
  ('first',{a:1},((1,2),(2,2),(4,-1),(7,-2),(8,-1))),
  ('second',{b:1},((2,3),(4,-1),(6,-1))),
  ('joint',{a:1,b:1},((1,2),(2,6),(4,-3),(7,-2),(8,-1))),
  ('helper',{(-238,'out'):328,(237,'in'):0},())):
  actual=quote(c);require(actual==h,'direct complete edge walk '+name)
  lo,hi=signed(actual);controls[name]={'native_signed_histogram':dict(actual),'gain_36_calls':decimals((CALLS*lo,CALLS*hi))}
 # Reproduce the earlier S8 reported price with an independent root enclosure.
 earlier=Q('0.003889928046155');prior=quote({a:1,b:1});lo=hi=Q(0)
 for rank,count in prior:
  low,high=power_bounds(rank,1-earlier)
  lo+=CALLS*count*(low if count>0 else high);hi+=CALLS*count*(high if count>0 else low)
 require(Q('-712.71910170800065338517949732464344677546721481545')<=lo<=hi<=Q('-712.71910170800065338517949732464344677546721481535'),'earlier S8 joint price')
 controls['joint']['earlier_target']='0.003889928046155';controls['joint']['earlier_gain_36_calls']=decimals((lo,hi))
 def options(node,peer):
  ids=[i for i in incident[node] if peer not in edges[i][2:]]
  candidates=set(frames)
  for i in ids:
   kind,k,a,b=edges[i];other=b if a==node else a
   candidates.intersection_update(legal_set(chart[other]))
  out={}
  for lab in sorted(candidates):
   h=Counter()
   for i in ids:
    kind,k,a,b=edges[i];aa=lab if a==node else chart[a];bb=lab if b==node else chart[b]
    g=legal(aa,bb)
    if g is None or kind=='targets' and dim[bb]<=dim[aa]:break
    apply_delta(h,kind,abs(dim[chart[a]]-dim[chart[b]]),g)
   else:out[lab]=h
  return out
 stats=Counter();histograms=set()
 for a,b in pairs:
  inner=[i for i in set(incident[a])|set(incident[b]) if edges[i][2] in (a,b) and edges[i][3] in (a,b)]
  A=options(a,b);B=options(b,a)
  for x,ha in A.items():
   for y in legal_set(x).intersection(B):
    stats['modular_pair_candidates']+=1;h=ha.copy();h.update(B[y])
    for i in inner:
     kind,k,u,v=edges[i];aa=x if u==a else y;bb=x if v==a else y;g=legal(aa,bb)
     if g is None or kind=='targets' and dim[bb]<=dim[aa]:break
     apply_delta(h,kind,abs(dim[chart[u]]-dim[chart[v]]),g)
    else:
     stats['directionally_legal']+=1;hh=hkey(h);histograms.add(hh)
     lo,hi=signed(hh)
     if not hh:stats['zero_histogram']+=1
     elif hi<0:stats['negative_histogram']+=1
     elif lo>0:stats['positive_histogram']+=1
     else:stats['unresolved_interval']+=1
 require(stats['positive_histogram']==stats['unresolved_interval']==0,'no positive or undecided relaxed price')
 require((stats['modular_pair_candidates'],stats['directionally_legal'],stats['zero_histogram'],stats['negative_histogram'],len(histograms))==(473429,240365,228299,12066,202),'complete assignment census')
 baseline=full_targets.copy();baseline.subtract(full_paid);interval=signed(hkey(baseline))
 exp_lo=Q('-0.000385127316613866441054139472099789196374646204');exp_hi=Q('-0.000385127316613866441054139472099789196374646203')
 require(exp_lo<=interval[0]<=interval[1]<=exp_hi,'complete near-target signed deficit')
 return {'status':'PASS_ALL_968_ATLAS_PAIR_PRICE_EXCLUSION','kappa':'0.003879929046155','source':{'binary_word':WORD,'layout':LAYOUT,'caller':op.CALLER},
  'scope':'Two paid-adjacent movable cochart components, independently choosing among 636 source frames; all common and exterior paid and helper incidences, protected endpoints and original packet forms. Modular geometry is a relaxation. Equal paid contacts inline free.',
  'source_baseline_signed_margin':decimals(interval),'components':len(chart),'frozen_components':len(frozen),'paid_edges':len(routes),'helper_targets':458,
  'pair_supports':len(pairs),'pair_roster_sha256':PAIR_SHA,'assignments':dict(stats),'distinct_signed_histograms':len(histograms),'maximum_signed_gain':'0',
  'direct_complete_invoice_controls':controls,'baseline_operator':{'native_coefficients_each_direction':680**2,'caller_coefficients_each_direction':38**2,'dirty_retirements_each_direction':[forward.dirty,backward.dirty],'protected_bridge_omission_clock':omitted,'ordinary':ordinary}}

if __name__=='__main__':
 result=main();print(json.dumps(result,indent=2,sort_keys=True))
