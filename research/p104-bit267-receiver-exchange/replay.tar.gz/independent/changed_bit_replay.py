#!/usr/bin/env python3
"""Re-evaluate a hash-pinned changed BIT word against the frozen caller.

This is a separately implemented linear-word, dual-word, chart, ownership
and complete signed caller recount. It accepts only unchanged endpoints,
layout, and caller; it does not validate new physical primitives, compiler,
precision tape, asymptotic supplier construction, rational consumer, or outer
application. The five inherited premises remain assumptions.
"""
import argparse
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
import gzip
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import independent as authenticated_review
import target_exact

WORD_PATH = HERE/'inputs/7786/research/p104-iterated-returns/binary/WORD.json.gz'
CALLER_PATH = HERE/'inputs/cache/source/research/paired-query-only-bit/EFREE-CALLER.json.gz'
CHECKOUT = Path('/tmp/p104-campaign/sources/7830/research/p104-mixed-rank-supplier')
BASE_SHA = 'a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a'
REVIEW_PINS = {'independent.py': 'a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
               'binary_operator.py': '36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349',
               'review_sources.json': 'af24ecde1d2d009ff2e65a889719d7ae33a8958d90026351729f1f9eb7564af2'}


def need(ok, why):
    if not ok:
        raise ValueError(why)


def digest(raw):
    return sha256(raw).hexdigest()


def read_json(raw):
    return json.loads(gzip.decompress(raw) if raw.startswith(b'\x1f\x8b') else raw)


def canonical_digest(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def rank8(rows):
    rows = [[Fraction(v) for v in row] for row in rows]
    rank = 0
    for col in range(8):
        pivot = next((i for i in range(rank, len(rows)) if rows[i][col]), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for i in range(rank+1, len(rows)):
            if rows[i][col]:
                r = rows[i][col] / rows[rank][col]
                for j in range(col, 8):
                    rows[i][j] -= r * rows[rank][j]
        rank += 1
    return rank


def orthogonal(a, b):
    return all(sum(x*y for x, y in zip(u, v)) == 0 for u in a for v in b)


class Charts:
    def __init__(self, frames):
        self.body, self.dual = {}, {}
        for k, value in frames.items():
            chart = int(k)
            body, dual = (tuple(tuple(Fraction(x) for x in row) for row in value[name])
                          for name in ('B', 'A'))
            need(len(body) == value['dim'] and len(body)+len(dual) == 8, f'frame dimension {chart}')
            need(all(len(row) == 8 for row in body+dual), f'frame width {chart}')
            need(rank8(body+dual) == 8 and orthogonal(body, dual), f'frame validity {chart}')
            self.body[chart], self.dual[chart] = body, dual

    @lru_cache(None)
    def grade(self, left, right):
        need(left in self.body and right in self.body, 'unknown chart')
        lower, upper = sorted((left, right), key=lambda x: len(self.body[x]))
        diff = len(self.body[upper]) - len(self.body[lower])
        return diff if diff > 0 and orthogonal(self.body[lower], self.dual[upper]) else 0


def run_word(word, charts, reverse, trace=None, first_use_records=None, check_operator=True):
    public, owned, program = word['public'], word['owned_fields'], word['program']
    initial = word['final'] if reverse else word['start']
    final = word['start'] if reverse else word['final']
    cells = [(chart, 1 << i) for i, chart in enumerate(initial)] + [None]*owned
    packet, dirty = {}, 0
    pending = [None]*len(cells)
    readers = {}

    def first_use(address, op, clock):
        item = pending[address]
        if item is None:
            return
        packet_clock, row = item
        need(cells[address] is not None and cells[address][1] == row,
             f'changed arrival before first use {packet_clock}')
        need(packet_clock not in readers, f'duplicate packet first use {packet_clock}')
        readers[packet_clock] = (op, clock, address, row)
        pending[address] = None
    opening, closing = ('CLEAR', 'INIT') if reverse else ('INIT', 'CLEAR')
    clocks = range(len(program)-1, -1, -1) if reverse else range(len(program))
    for clock in clocks:
        op, address, *args = program[clock]
        need(isinstance(address, int) and 0 <= address < len(cells), f'address {clock}')
        cell = cells[address]
        if op in (opening, closing):
            need(len(args) == 1, f'private arguments {clock}')
            chart, = args
            need(address >= public and chart in charts.body, f'private chart {clock}')
            if op == opening:
                need(cell is None, f'field already owned {clock}')
                cells[address] = (chart, 0)
            else:
                need(cell is not None and cell[0] == chart, f'retirement ownership {clock}')
                first_use(address, 'RETIRE', clock)
                dirty += bool(cell[1])
                cells[address] = None
        elif op == 'ADD':
            need(len(args) == 2, f'add arguments {clock}')
            other, chart = args
            need(isinstance(other, int) and 0 <= other < len(cells) and other != address, f'add address {clock}')
            peer = cells[other]
            need(cell is not None and peer is not None and cell[0] == peer[0] == chart, f'add chart {clock}')
            first_use(address, 'ADD', clock)
            first_use(other, 'ADD', clock)
            cells[other if reverse else address] = (chart, cell[1] ^ peer[1])
        elif op == 'SWAP':
            need(len(args) == 1, f'swap arguments {clock}')
            other, = args
            need(isinstance(other, int) and 0 <= other < len(cells) and other != address
                 and cell is not None and cells[other] is not None, f'swap ownership {clock}')
            cells[address], cells[other] = cells[other], cell
            pending[address], pending[other] = pending[other], pending[address]
        elif op == 'MOVE':
            need(len(args) == 2 and address >= public, f'move arguments {clock}')
            src, dst = args[::-1] if reverse else args
            grade = charts.grade(src, dst)
            need(cell is not None and cell[0] == src and grade > 0, f'move chart {clock}')
            first_use(address, 'MOVE', clock)
            packet[clock] = (address, src, dst, grade)
            cells[address] = (dst, cell[1])
            pending[address] = (clock, cell[1])
        else:
            raise ValueError(f'unknown operation {clock}: {op}')
    need(all(cell is None for cell in cells[public:]), 'unretired private field')
    need(all(cells[i] is not None and cells[i][0] == final[i] for i in range(public)), 'public endpoint chart')
    for address in range(public):
        first_use(address, 'PUBLIC_END', -1 if reverse else len(program))
    need(set(readers) == set(packet), 'every packet has a labeled first use or terminal exit')
    rows = [cell[1] for cell in cells[:public]]
    expected = [1 << i for i in range(public)]
    for i in range(111):
        dest, src = (i, i+111) if reverse else (i+111, i)
        expected[dest] ^= 1 << src
    if check_operator:
        need(rows == expected, 'all-public linear operator')
    if trace is not None:
        trace.update({'count': len(readers), 'kinds': dict(sorted(Counter(v[0] for v in readers.values()).items())),
                      'sha256': canonical_digest([[clock, *readers[clock]] for clock in sorted(readers)])})
    if first_use_records is not None:
        first_use_records.update(readers)
    return packet, dirty, rows


def xor(a, b):
    out = a.copy()
    for key, row in b.items():
        v = out.get(key, 0) ^ row
        if v:
            out[key] = v
        else:
            out.pop(key, None)
    return out


def shift(poly, q, stages):
    stage_set = set(stages)
    return {(key[0] ^ q,) + tuple(key[i+1] + int(i+1 in stage_set) for i in range(18)): row
            for key, row in poly.items()}


def caller_transfer(caller, reverse):
    rows = [{(0,)*19: 1 << i} for i in range(caller['roles'])]
    events = reversed(caller['events']) if reverse else caller['events']
    for op, *args in events:
        if op in ('ADD', 'QUERY'):
            dst, src = args[::-1] if reverse else args
            part = shift(rows[src], 1, ()) if op == 'QUERY' else rows[src]
            rows[dst] = xor(rows[dst], part)
        elif op == 'SWAP':
            a, b = args
            rows[a], rows[b] = rows[b], rows[a]
        elif op == 'LOCAL':
            stage, a, b = args
            if reverse:
                a, b = b, a
            rows[b] = shift(xor(rows[b], shift(rows[a], 1, ())), 0, (stage,))
            rows[a] = shift(rows[a], 0, (stage,))
        elif op == 'IDLE_ONE':
            role, stages = args
            rows[role] = shift(rows[role], 0, stages)
        else:
            raise ValueError(f'unknown caller operation {op}')
    expected = [{(1,) + tuple(int(j in ent['stages']) for j in range(1, 19)): 1 << i}
                for i, ent in enumerate(caller['diagonal'])]
    need(rows == expected, 'all caller polynomial coefficients')
    return canonical_digest([{str(k): v for k, v in sorted(row.items())} for row in rows])


def invoice(word, caller, charts, packets):
    need((caller['roles'], caller['ports'], caller['stages'], caller['native_per_stage'],
          caller['body_rank'], caller['ambient_rank']) == (38, 111, 18, 2, 7, 127), 'caller dimensions')
    native_targets = Counter(charts.grade(a, b) for a, b in zip(word['start'][222:], word['final'][222:]))
    need(not native_targets[0] and sum(native_targets.values()) == 458, 'helper targets')
    paid, targets, labels, local_stages = Counter(), Counter(), {}, []
    for clock, event in enumerate(caller['events']):
        op, *args = event
        if op == 'LOCAL':
            stage, _, _ = args
            local_stages.append(stage)
            targets.update(native_targets)
            for native_clock, (address, _, _, grade) in packets.items():
                identity = (clock, native_clock, address)
                need(identity not in labels, 'duplicate local occurrence')
                labels[identity] = grade
                paid[grade] += 1
        elif op == 'IDLE_ONE':
            _, stages = args
            need(stages and len(stages) == len(set(stages)) and set(stages) <= set(range(1,19)), 'idle stages')
            for port in range(caller['ports']):
                identity = (clock, -1, port)
                need(identity not in labels, 'duplicate idle occurrence')
                grade = 7*len(stages)
                labels[identity] = grade
                paid[grade] += 1
        elif op == 'QUERY':
            for port in range(caller['ports']):
                identity = (clock, -1, port)
                need(identity not in labels, 'duplicate query occurrence')
                labels[identity] = 1
                paid[1] += 1
        else:
            need(op in ('ADD', 'SWAP'), f'caller event {op}')
    need(local_stages == [s for s in range(1,19) for _ in range(2)], '36 actual local calls')
    for ent in caller['diagonal']:
        mask = ent['stages']
        need(ent['q'] == 1 and mask and len(mask) == len(set(mask)) and set(mask) <= set(range(1,19)), 'root mask')
        targets[1+7*len(mask)] += caller['ports']
    need(sum(targets.values()) == 36*458 + 38*111, 'complete productive invoice')
    need(Counter(labels.values()) == paid, 'all paid occurrence identities')
    label_hash = canonical_digest([[*identity, grade] for identity, grade in sorted(labels.items())])
    return paid, targets, label_hash


def ordinary(word, caller, paid, targets):
    events = Counter(event[0] for event in caller['events'])
    calls, queries, idles = events['LOCAL'], events['QUERY'], events['IDLE_ONE']
    ports, roles, owned, public = caller['ports'], caller['roles'], word['owned_fields'], word['public']
    native = calls*16*(owned+public+4)*len(word['program'])
    caller_work = ports*(8*(events['ADD']+3*events['SWAP'])+256*(calls+queries+roles))
    route_groups = 4*(sum(paid.values())+sum(targets.values()))+8*ports*(calls+idles)
    records = native+caller_work+route_groups*80*134*135
    fields = calls*(owned+4)+2*ports*roles*len(caller['events'])+16*ports*(calls+queries+roles)
    need(records < 10**12 and fields < 10**7, 'incumbent ordinary capacity')
    return {'raw_records': records, 'raw_records_limit': 10**12,
            'owned_fields': fields, 'owned_fields_limit': 10**7}


def as_counts(value):
    return Counter({int(k): int(v) for k, v in value.items()})


def recount_from_candidate(word, caller, charts):
    trace_f, trace_r = {}, {}
    forward, dirty_f, rows_f = run_word(word, charts, False, trace_f)
    reverse, dirty_r, rows_r = run_word(word, charts, True, trace_r)
    need(set(forward) == set(reverse), 'forward/adjoint packet clocks')
    for k, (addr, src, dst, grade) in forward.items():
        need(reverse[k] == (addr, dst, src, grade), f'adjoint packet geometry {k}')
    paid, targets, labels = invoice(word, caller, charts, forward)
    return paid, targets, {'native_moves': len(forward), 'dirty_retirements': [dirty_f, dirty_r],
                           'native_forward_sha256': canonical_digest(rows_f),
                           'native_adjoint_sha256': canonical_digest(rows_r),
                           'first_use_forward': trace_f, 'first_use_adjoint': trace_r,
                           'paid_occurrence_sha256': labels, **ordinary(word, caller, paid, targets)}


def fails(action, expected):
    try:
        action()
    except ValueError as exc:
        need(expected in str(exc), f'wrong negative-control rejection: {exc}')
        return str(exc)
    raise ValueError(f'negative control passed: {expected}')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    need(args.out.resolve().parent == HERE, 'output must be directly in own replay directory')
    need(len(args.sha256) == 64 and all(c in '0123456789abcdef' for c in args.sha256), 'literal lowercase sha256')
    raw = args.candidate.read_bytes()
    need(digest(raw) == args.sha256, 'candidate SHA-256 mismatch')
    copy = HERE / ('CANDIDATE-' + args.sha256 + ('.json.gz' if raw.startswith(b'\x1f\x8b') else '.json'))
    if copy.exists():
        need(copy.read_bytes() == raw, 'existing copy differs')
    else:
        copy.write_bytes(raw)
    need(digest(copy.read_bytes()) == args.sha256, 'clean candidate copy')
    for name, pin in REVIEW_PINS.items():
        a, b = (HERE/name).read_bytes(), (CHECKOUT/'review'/name).read_bytes()
        need(a == b and digest(a) == pin, f'clean exact-head review source {name}')
    for name, pin in authenticated_review.PRODUCER_SOURCE_PINS.items():
        a, b = (HERE/'comparator'/name).read_bytes(), (CHECKOUT/name).read_bytes()
        need(a == b and digest(a) == pin, f'clean exact-head producer source {name}')
    need(authenticated_review.authenticate(HERE/'inputs', False) == (20,127), 'full source authentication')
    base_bytes = (HERE/'BASELINE.json').read_bytes()
    need(digest(base_bytes) == BASE_SHA, 'fresh baseline')
    frozen = read_json(WORD_PATH.read_bytes())
    candidate = read_json(copy.read_bytes())
    need(set(candidate) == set(frozen) and all(candidate[k] == frozen[k] for k in frozen if k != 'program'),
         'candidate must preserve full layout, endpoints, frame bytes and other schema fields')
    need(candidate['schema'] == 'BIT-functional-GL-kernel-native/1' and candidate['public'] == 680,
         'native format')
    caller = read_json(CALLER_PATH.read_bytes())
    charts = Charts(frozen['frames'])
    transfer_f = caller_transfer(caller, False)
    transfer_r = caller_transfer(caller, True)
    paid, targets, physical = recount_from_candidate(candidate, caller, charts)
    baseline = json.loads(base_bytes)['binary']
    oldpaid, oldtargets = as_counts(baseline['paid']), as_counts(baseline['targets'])
    need(targets == oldtargets, 'unchanged target census')
    if candidate['program'] == frozen['program']:
        need(paid == oldpaid and physical['raw_records'] == baseline['physical']['raw_records']
             and physical['owned_fields'] == baseline['physical']['owned_fields'], 'baseline independent recount')
    delta = paid.copy(); delta.subtract(oldpaid)
    prices = {}
    for k in target_exact.TARGETS:
        old = target_exact.signed(oldpaid, oldtargets, k)
        new = target_exact.signed(paid, targets, k)
        price_delta = (new[0]-old[1], new[1]-old[0])
        prices[k] = {'old_signed': target_exact.interval_output(old), 'new_signed': target_exact.interval_output(new),
                     'signed_improvement': target_exact.interval_output(price_delta),
                     'strictly_positive_candidate_balance': new[0] > 0}
    # A literal omission of the last clear leaves an owned field live. Check
    # this against the original baseline, independently of candidate details.
    last_clear = max(i for i, event in enumerate(frozen['program']) if event[0] == 'CLEAR')
    dropped = dict(frozen); dropped['program'] = frozen['program'][:last_clear] + frozen['program'][last_clear+1:]
    omitted = fails(lambda: run_word(dropped, charts, False), 'unretired private field')
    altered = oldpaid.copy(); altered[14] += 1
    control = target_exact.signed(altered, oldtargets, target_exact.TARGETS[0])
    old = target_exact.signed(oldpaid, oldtargets, target_exact.TARGETS[0])
    need(control[1] < old[0], 'rank-price mutation rejected')
    receipt = {
        'status': 'PASS_LITERAL_BIT_OPERATOR_AND_COMPLETE_SIGNED_INVOICE',
        'scope': 'Unchanged literal BIT layout/endpoints and unchanged caller. Mathematical word, charts, owned lifetime and signed counts only; not precision tape, erasure implementation, compiler, 451-factor construction, rational consumer or inherited outer theorem.',
        'source_authentication': {'construction_head': '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
                                  'review_pins': REVIEW_PINS, 'explicit': 20, 'inherited': 127,
                                  'baseline_sha256': BASE_SHA},
        'candidate': {'sha256': args.sha256, 'clean_copy': str(copy), 'program_length': len(candidate['program']),
                      'same_as_baseline': candidate['program'] == frozen['program']},
        'forward_and_adjoint': {'public_rows_each': 680, 'caller_polynomial_coefficients_each': 38**2,
                                'caller_forward_sha256': transfer_f, 'caller_adjoint_sha256': transfer_r, **physical},
        'invoice': {'paid': dict(sorted(paid.items())), 'productive': dict(sorted(targets.items())),
                    'paid_count': sum(paid.values()), 'productive_count': sum(targets.values()),
                    'paid_change_by_rank': {str(k): v for k, v in sorted(delta.items()) if v}, 'prices': prices},
        'negative_controls': {'missing_private_retirement_clock': last_clear, 'rejected': omitted,
                              'added_paid_rank_14_receipt_rejected': True},
        'precision_tape': 'NOT REPLAYED', 'outer_application': 'NOT REPLAYED',
    }
    args.out.write_text(json.dumps(receipt, indent=2, sort_keys=True)+'\n')
    print(receipt['status'], args.sha256, 'paid', sum(paid.values()), 'productive', sum(targets.values()))
    print('affected paid ranks', receipt['invoice']['paid_change_by_rank'])
    print('missing retirement and altered-price controls rejected')
    print('precision tape, erasure implementation, compiler and outer application are NOT REPLAYED')


if __name__ == '__main__':
    main()
