#!/usr/bin/env python3
"""Reprice complete frozen invoices with a separate outward integer engine.

The input histogram is produced by baseline_recount.py. Logarithms use exact
rational atanh sums with a geometric remainder; exponentials use a positive
fixed-point Taylor enclosure followed by six outward-rounded squarings.
Nothing here proves that the histogram is physically realizable, nor does a
positive balance establish the inherited theorem's other conditions.
"""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
GRID = 10**65
TARGETS = ('0.003879929046155', '0.003884928046155')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def ceildiv(a, b):
    return -((-a) // b)


def fmt(n):
    sign = '-' if n < 0 else ''
    a, b = divmod(abs(n), GRID)
    return f'{sign}{a}.{b:065d}'


def interval_output(ab):
    return [fmt(ab[0]), fmt(ab[1])]


def atanh_log(z):
    """ln((1+z)/(1-z)), 0 <= z <= 1/3; rigorous exact tail."""
    need(0 <= z <= Fraction(1, 3), 'logarithm range')
    squared, term, total = z*z, z, Fraction(0)
    for k in range(80):
        total += 2 * term / (2*k + 1)
        term *= squared
    return total, total + 2 * term / (161 * (1-squared))


@lru_cache(None)
def log_bounds(rank):
    need(rank >= 1, 'positive rank')
    exp2 = rank.bit_length() - 1
    lower2, upper2 = atanh_log(Fraction(1, 3))
    lower, upper = atanh_log(Fraction(rank-2**exp2, rank+2**exp2))
    return exp2*lower2 + lower, exp2*upper2 + upper


@lru_cache(None)
def rank_power(rank, exponent):
    """Outward fixed-point bounds for rank**exponent, exponent in [0,1]."""
    need(0 <= exponent <= 1, 'exponent range')
    lower, upper = log_bounds(rank)
    lower *= exponent / 64
    upper *= exponent / 64
    ylo = lower.numerator * GRID // lower.denominator
    yhi = ceildiv(upper.numerator * GRID, upper.denominator)
    need(0 <= ylo <= yhi and 8*yhi < GRID, 'exp range')
    lo = hi = termlo = termhi = GRID
    for n in range(1, 65):
        termlo = termlo*ylo // (GRID*n)
        termhi = ceildiv(termhi*yhi, GRID*n)
        lo += termlo
        hi += termhi
    # Each remaining term is at most 1/8 of its predecessor, so twice
    # the first omitted term safely covers the entire nonnegative tail.
    first_omitted = ceildiv(termhi*yhi, GRID*65)
    hi += 2*first_omitted
    for _ in range(6):
        lo, hi = lo*lo // GRID, ceildiv(hi*hi, GRID)
    return lo, hi


def signed(paid, productive, target):
    exponent = 1 - Fraction(target)
    coeff = Counter(productive)
    coeff.subtract(paid)
    lo = hi = 0
    for rank, count in sorted(coeff.items()):
        a, b = rank_power(rank, exponent)
        if count >= 0:
            lo, hi = lo + count*a, hi + count*b
        else:
            lo, hi = lo + count*b, hi + count*a
    return lo, hi


def from_old_engine(paid, productive, target):
    # Cross-check against the authenticated source reviewer's separate grid.
    sys.path.insert(0, str(HERE))
    import independent as upstream
    exponent = 1 - Fraction(target)
    bounds = upstream.sub(upstream.moment(productive, exponent), upstream.moment(paid, exponent))
    return Fraction(bounds[0], upstream.GRID), Fraction(bounds[1], upstream.GRID)


def main():
    base = HERE / 'BASELINE.json'
    need(sha256(base.read_bytes()).hexdigest() == 'a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a',
         'fresh fully recounted baseline receipt identity')
    data = json.loads(base.read_bytes())
    out = {'engine': 'exact rational atanh with fixed-point Taylor and outward squaring',
           'grid': str(GRID), 'baseline_sha256': sha256(base.read_bytes()).hexdigest(), 'targets': {}}
    for target in TARGETS:
        sides = {}
        for side, control_rank in (('binary', 14), ('rational', 1)):
            paid = Counter({int(k): v for k, v in data[side]['paid'].items()})
            productive = Counter({int(k): v for k, v in data[side]['targets'].items()})
            balance = signed(paid, productive, target)
            oldlo, oldhi = from_old_engine(paid, productive, target)
            need(Fraction(balance[0], GRID) <= oldhi and oldlo <= Fraction(balance[1], GRID),
                 f'independent arithmetic engines do not overlap: {side} {target}')
            altered = paid.copy(); altered[control_rank] += 1
            bad = signed(altered, productive, target)
            need(bad[1] < balance[0], f'altered rank-{control_rank} price not detected')
            price = rank_power(control_rank, 1-Fraction(target))
            observed = (balance[0]-bad[1], balance[1]-bad[0])
            need(observed[0] <= price[1] and price[0] <= observed[1], 'price control difference')
            need(balance[0] > 0 or balance[1] < 0, 'balance sign unresolved')
            sides[side] = {'signed_productive_minus_paid': interval_output(balance),
                           'sign': 'surplus' if balance[0] > 0 else 'deficit',
                           'upstream_engine_overlap': True,
                           'altered_paid_control': {'added_rank': control_rank,
                                                    'recomputed_balance': interval_output(bad),
                                                    'unchanged_receipt_rejected': True,
                                                    'price_difference': interval_output(observed)}}
        out['targets'][target] = sides
    path = HERE / 'TARGET-EXACT.json'
    path.write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print('PASS independent directed arithmetic, both full invoices, both targets, four altered-price controls')
    for t, sides in out['targets'].items():
        for side, item in sides.items():
            print(t, side, item['sign'], *item['signed_productive_minus_paid'])


if __name__ == '__main__':
    main()
