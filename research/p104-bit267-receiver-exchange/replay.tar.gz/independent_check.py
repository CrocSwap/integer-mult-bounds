#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Separate packet-first-use interpreter, caller recount and price enclosure."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'independent'))
import changed_bit_replay as replay
import target_exact as price

def need(c,m):
 if not c:raise ValueError(m)
def readgz(path):return json.loads(gzip.decompress(path.read_bytes()))
def counts(d):return Counter({int(k):v for k,v in d.items()})
def intersects(a,b):return Fraction(a[0],price.GRID)<=Fraction(b[1]) and Fraction(b[0])<=Fraction(a[1],price.GRID)
src=HERE/'source'/'inputs';w=readgz(src/'WORD.json.gz');caller=readgz(src/'EFREE-CALLER.json.gz')
need(sha256((src/'WORD.json.gz').read_bytes()).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9','source word pin')
need(sha256((src/'EFREE-CALLER.json.gz').read_bytes()).hexdigest()=='757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b','caller pin')
R=json.loads((HERE/'RESULT.json').read_bytes());charts=replay.Charts(w['frames']);base_paid,base_prod,base_trace=replay.recount_from_candidate(w,caller,charts)
caller_f=replay.caller_transfer(caller,False);caller_a=replay.caller_transfer(caller,True);out={}
for name,expected in sorted(R['controls'].items()):
 path=HERE/'words'/(name+'.json.gz');q=readgz(path);coded=name.startswith('encoded-')
 need(sha256(path.read_bytes()).hexdigest()==expected['gzip_sha256'] and replay.canonical_digest(q)==expected['canonical_word_sha256'],'word hashes '+name)
 need(set(q)==set(w) and all(q[k]==w[k] for k in w if k not in ('program','owned_fields')) and q['owned_fields']==w['owned_fields']+int(coded),'owned layout '+name)
 paid,prod,trace=replay.recount_from_candidate(q,caller,charts)
 need(paid==counts(expected['full_paid']) and prod==counts(expected['full_productive'])==base_prod,'complete signed census '+name)
 need(trace['dirty_retirements']==[3554+int(coded)]*2,'retirements '+name)
 need(trace['raw_records']==expected['ordinary']['records'] and trace['owned_fields']==expected['ordinary']['owned_fields'],'ordinary '+name)
 prices={}
 for rate in R['baseline_margin_at_rates']:
  original=price.signed(base_paid,base_prod,rate);new=price.signed(paid,prod,rate);delta=(new[0]-original[1],new[1]-original[0])
  need(intersects(original,R['baseline_margin_at_rates'][rate]) and intersects(new,expected['complete_margin_at_rates'][rate]) and intersects(delta,expected['gain_at_rates'][rate]),'independent price '+name)
  prices[rate]={'complete_margin':price.interval_output(new),'gain':price.interval_output(delta),'overlaps_primary':True}
 out[name]={'canonical_sha256':expected['canonical_word_sha256'],'physical':trace,'prices':prices}
 if name=='encoded-1926':negative=deepcopy(q)
# Failure of the encoded-payload decode must be caught in each direction.
index,=[i for i,e in enumerate(negative['program']) if e==['ADD',1926,4234,349]]
negative['program'].pop(index);reject=[]
for reverse in (False,True):
 try:replay.run_word(negative,charts,reverse)
 except ValueError as err:
  need(str(err)=='all-public linear operator','expected operator mutation rejection');reject.append(str(err))
 else:raise ValueError('undecoded payload passed')
print(json.dumps({'status':'PASS_SEPARATE_FULL_OPERATOR_INVOICE_PRICE_AND_MUTATION','scope':'Separate whole-field interpreter and first-use tracing, 36-call signed recount and directed price enclosure; no independent human review or compiler/theorem qualification.',
 'caller_forward_sha256':caller_f,'caller_adjoint_sha256':caller_a,'original_physical':base_trace,'negative_control':{'deleted_decode':index,'both_operator_orientations':reject},'cases':out},indent=2,sort_keys=True))
