# Chart-267 receiver histories and exchange controls

For the binary word of [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), pinned at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`, the existing live histories at the receivers of packets 1926 and 1927 do **not** provide either packet for free. Four literal reroutes and exchanges have negative complete 36-call signed gain; they establish no improved κ bound. This examines two different receiver charts while leaving source chart 267 in place, and is distinct from the common-chart temporal split in [#7895](https://github.com/CrocSwap/integer-mult-bounds/pull/7895), head `84110d8b3a23674ab648ea47f361b7c925e53b18`.

## What is live

Clocks are zero-based source-word indices. A cut *before* clock 4553 is immediately after packet 1925 has left. The six live source fields `741,1356,1460,1508,1580,1628` have forward rank six. The original forms of 1926 and 1927 are respectively

```
1926 = x1 + x3 + x4 + x5 + x6   → 349, clock 4559
1927 = x1 + x2 + x4 + x6        → 374, clock 4565
```

Their first reads are `ADD 2471,1926` at clock 8511 and `ADD 2542,1927` at clock 8792. The actual before-instruction active fields, including zero fields and the two target packets when present, are as follows. Their full forward and adjoint rows and additional snapshots appear in [RESULT.json](RESULT.json).

| Before clock | Chart 349 fields (forward rank; adjoint rank) | Chart 374 fields (forward rank; adjoint rank) |
| ---: | --- | --- |
| 4553 | none (0; 0) | 650, 1560, 1564 (3; 3) |
| 4566 | 1926 (1; 1) | 650, 1560, 1564, 1927 (4; 4) |
| 8511 | 1926, 1986, 2282, 2471 (3; 3) | 650, 1560, 1564, 1927, 2207 (5; 5) |
| 8792 | 1926, 1986, 2282 (3; 0) | 650, 1560, 1564, 1927, 2207, 2542 (5; 5) |

The common six-row information deficit is `rank(H + X) − rank(H)`, with X the six current source rows and H the **pooled** rows at both receiver charts. Pooling assumes free receiver communication and is therefore an informational relaxation, not a legal chart operation.

- At clock 4553, H has rank 3, its intersection with X is zero, and the forward deficit is exactly **6**. The source's adjoint rank and deficit are **5** at that same cut.
- Immediately before either first read, the pooled *non-target* receiver stock has forward rank 6 and zero intersection with X, so its six-row deficit remains **6**. Both 1926 and 1927 add independent rows modulo that stock: each has conditional deficit **1**, even when the other is given for free. Including both target packets in H reduces the six-row deficit to **4**.
- At clock 8511 the pooled non-target adjoint stock has rank 6 and both packet adjoint rows are independent modulo it. At clock 8792 its rank is 4; the 1927 adjoint row still adds one, while 1926 has zero adjoint because its last original read was at clock 8520. The six source adjoint rows themselves have become zero by these later cuts: their first-cut rank-five profile must not be confused with a later forward-information deficit.

These are exact F₂ row comparisons for the *original histories*. A modified word can change those histories; the result does not rule out arbitrary multi-component changes, future information transfers, or different retiming. In particular, it does not show that every imaginable scheme needs six new transfers.

## Receiver path and its price

The two receiver spaces are distinct rational rank-six subspaces; their intersection is exactly chart 267 of rank four, and their span is all of Q⁸. A direct 349↔374 MOVE is illegal. The path `349 → 267 → 374`, or its reverse, has grades `(2,2)`.

This is cheapest for carrying **one scalar along a paid nested-space path** at `0 < κ < 1`. Set `α = 1 − κ`. If a path touches rank at most 4, or rank 8, it must make at least two ranks of movement on each side, costing at least `2·2^α` by subadditivity. If it remains in ranks 5, 6 and 7, any grade-two step has separate unit-grade entry and exit; a path of only unit steps needs at least four because no rank-five common subspace or rank-seven common superspace exists. Both alternatives cost at least `2·2^α`. This is a path statement; it does not price arbitrary recoding or changes to other paid edges.

## Four replayed controls

Two direct detours replace a source egress by 267→other receiver→267→original receiver. The two coded controls also use a live independent field at the first receiver: `encoded-1926` uses the pre-existing field 1560, while `encoded-1927` uses the already-arrived 1926. In each coded control the receiver sends the XOR-encoded packet **and** a separate copy of its side information along paid paths, then decodes at the original receiver. A new owned scratch field has one complete lifetime. Thus no side-information transfer is assumed free.

| Control | Native paid histogram change | 36-call gain at first-higher `0.003879928046156` | At near trial `0.003879929046155` |
| --- | --- | ---: | ---: |
| detour 1926 through 374 | +2 grade 2 | −143.613252274482742734 | −143.613252174937721409 |
| detour 1927 through 349 | +2 grade 2 | −143.613252274482742734 | −143.613252174937721409 |
| encoded 1926 using 1560 | +4 grade 2 | −287.226504548965485468 | −287.226504349875442817 |
| encoded 1927 using 1926 | +4 grade 2 | −287.226504548965485468 | −287.226504349875442817 |

Gain is new minus original `Σ productive r^(1−κ) − Σ paid r^(1−κ)` and includes all 36 native calls. The full original margin at first-higher is approximately `−0.0000000007670015024`; each literal control's full signed margin, exact directed interval, unchanged productive and complete paid histograms are in [RESULT.json](RESULT.json). Ordinary records are 934,604,507,280 for each direct control and 935,063,137,488 for each coded control, under the `10¹²` ceiling; the coded controls use 6,998,580 owned fields under the `10⁷` ceiling.

Every changed word checks all 462,400 native coefficients in each orientation, 1,444 caller polynomial coefficients in each orientation, all 111 main contacts, and the full owner-411 bridge/tree routes and payloads in both orientations. The bridge isolation and omission control also pass. The whole state of every original live field, including chart and row, equals the source immediately before the altered packet's first reader in both orientations; the added scratch is already retired. Plain words have 3,554 dirty private retirements in each direction and coded words have 3,555.

A separate interpreter and rational price engine recount every packet's first use, both full operators, unchanged caller, complete invoice and all intervals. A mutation that deletes an encoded word's decode is rejected by both independently implemented operator directions. See [INDEPENDENT.json](INDEPENDENT.json). Computational replay is not independent human review, a compiler or physical-erasure qualification, precision-tape qualification, or an outer-theorem proof.

## Reproduce

Python 3.12, standard library only, offline:

```sh
sha256sum -c SHA256SUMS
python3 -I -B check.py > /tmp/chart267-split-result.json
cmp RESULT.json /tmp/chart267-split-result.json
python3 -I -B independent_check.py > /tmp/chart267-split-independent.json
cmp INDEPENDENT.json /tmp/chart267-split-independent.json
```

The four canonical compressed words under [words/](words/) are reconstructed by `check.py` and verified byte-for-byte after decompression; `--write-words` regenerates them. The source input and verifier are under [source/](source/), and the separately authored engines are under [independent/](independent/). [SOURCES.json](SOURCES.json) lists the pinned source and changed-word hashes. [NOTICE](NOTICE) retains credit. Prepared for Clear1nsight with OpenAI Codex assistance; no independent human review is claimed.
