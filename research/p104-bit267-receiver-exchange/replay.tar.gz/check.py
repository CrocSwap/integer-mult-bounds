#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Frozen-BIT chart-267 receiver stocks and four literal exchange controls."""
from collections import Counter
from copy import deepcopy
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import gzip,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'source'))
import verify as v
op=v.op
R=lambda test,msg: v.require(test,msg)
for path,digest in v.PINS.items():
 R(sha256((HERE/'source'/path).read_bytes()).hexdigest()==digest,'source pin '+path)
w=v.read('inputs/WORD.json.gz'); caller=v.read('inputs/EFREE-CALLER.json.gz'); receipt=v.read('inputs/BIT.json')
R(sha256(v.canon(w)).hexdigest()==v.WORD,'source word'); P=w['program'];N=w['public'];atlas=op.Atlas(w['frames'])
S=[741,1356,1460,1508,1580,1628]; D=[1926,1927]; CH=[349,374]
R(atlas.main_contacts(w['start'],w['final'])==111,'111 unchanged main contacts')
R(P[4552]==['MOVE',1925,267,326] and P[4559]==['MOVE',1926,267,349] and P[4565]==['MOVE',1927,267,374],'pinned exits')
R(P[8511]==['ADD',2471,1926,349] and P[8792]==['ADD',2542,1927,374],'pinned readers')

def rank(rows):
 b={}
 for row in rows:
  while row:
   p=row.bit_length()-1
   if p in b:row^=b[p]
   else:b[p]=row;break
 return len(b)
def support(row):return [i for i in range(row.bit_length()) if row>>i&1]
def rref(rows):
 basis={}
 for vector in rows:
  row=list(map(F,vector))
  for p,b in sorted(basis.items()):
   if row[p]:row=[x-row[p]*y for x,y in zip(row,b)]
  p=next((i for i,x in enumerate(row) if x),None)
  if p is None:continue
  row=[x/row[p] for x in row]
  for k,b in list(basis.items()):
   if b[p]:basis[k]=[x-b[p]*y for x,y in zip(b,row)]
  basis[p]=row
 return tuple(tuple(basis[p]) for p in sorted(basis))
frames=w['frames'];a=rref(frames['349']['A']+frames['374']['A']);s=rref(frames['349']['B']+frames['374']['B'])
R((len(a),len(s))==(4,8) and a==rref(frames['267']['A']),'receiver geometry')
R(atlas.grade(349,374)==0 and atlas.grade(349,267)==atlas.grade(267,374)==2,'receiver transfer')

def capture(word,cuts,reverse=False):
 program=word['program'];cells=[(c,1<<i) for i,c in enumerate(word['final' if reverse else 'start'])]+[None]*word['owned_fields'];out={};cuts=set(cuts)
 for t in (range(len(program)-1,-1,-1) if reverse else range(len(program))):
  cut=t+1 if reverse else t
  if cut in cuts:out[cut]=cells.copy()
  code,addr,*args=program[t]
  if code==('CLEAR' if reverse else 'INIT'):
   R(cells[addr] is None,'capture open');cells[addr]=(args[0],0)
  elif code==('INIT' if reverse else 'CLEAR'):
   R(cells[addr] is not None and cells[addr][0]==args[0],'capture close');cells[addr]=None
  elif code=='MOVE':
   x,y=args[::-1] if reverse else args;R(cells[addr] is not None and cells[addr][0]==x,'capture route');cells[addr]=(y,cells[addr][1])
  elif code=='SWAP':cells[addr],cells[args[0]]=cells[args[0]],cells[addr]
  else:
   R(code=='ADD' and cells[addr][0]==cells[args[0]][0]==args[1],'capture add');d,s=(args[0],addr) if reverse else (addr,args[0]);cells[d]=(args[1],cells[d][1]^cells[s][1])
 R(set(out)==cuts,'all cuts captured')
 return out

cuts=[4553,4559,4565,4566,4587,8511,8792]; forward=capture(w,cuts); adjoint=capture(w,cuts,True)
ref=[forward[4553][i][1] for i in S]; R(rank(ref)==6,'reference six')
# All chart-owned fields count, including zero rows and pending packet fields.
def snapshot(cells):
 out={}
 for chart in CH:
  fields=[(i,x[1]) for i,x in enumerate(cells) if x is not None and x[0]==chart]
  out[chart]=fields
 return out

def profile(cells):
 snap=snapshot(cells); out={}; history=[]
 for z in CH:
  vals=snap[z]; excl=[(i,row) for i,row in vals if i not in D];history+=excl
  out[str(z)]={'live_count':len(vals),'all_live_fields':[{ 'address':i,'support':support(row)} for i,row in vals],
               'live_rank':rank([r for i,r in vals]),'non_target_live_fields':[i for i,r in excl],
               'non_target_rank':rank([r for i,r in excl])}
 h=[r for _,r in history];rows=[cells[i][1] for i in S]
 target=[cells[i][1] for i in D if cells[i] is not None]
 out['pooled_non_target_rank']=rank(h)
 allrows=[r for z in CH for _,r in snap[z]]
 out['pooled_all_live_rank']=rank(allrows)
 out['six_current_field_deficit_over_all_live']=rank(allrows+rows)-rank(allrows)
 out['six_current_field_rank']=rank(rows)
 out['six_current_field_deficit_over_pool']=rank(h+rows)-rank(h)
 out['target_rows_rank_over_pool']=rank(h+target)-rank(h)
 out['target_rank_over_pool_given_other']={str(i):rank(h+[cells[j][1] for j in D if j!=i and cells[j] is not None]+[cells[i][1]])-rank(h+[cells[j][1] for j in D if j!=i and cells[j] is not None]) for i in D if cells[i] is not None}
 return out
profiles={}
for t in cuts:
 R([x[0] if x else None for x in forward[t]]==[x[0] if x else None for x in adjoint[t]],'forward/adjoint charts')
 profiles[str(t)]={'next_instruction':P[t], 'forward':profile(forward[t]),'adjoint':profile(adjoint[t])}
for t in [4553,4559,4565,4566,4587,8511,8792]:
 p=profiles[str(t)]['forward'];R(p['six_current_field_deficit_over_pool']==6,'no six-row information in pooled non-target history '+str(t))
for t in [4565,4566,4587,8511,8792]:
 p=profiles[str(t)]['forward'];R(p['target_rows_rank_over_pool']==2 and all(x==1 for x in p['target_rank_over_pool_given_other'].values()),'independent demanded rows '+str(t))
R(profiles['4553']['adjoint']['six_current_field_rank']==5,'adjoint first-cut rank')

# On a direct-control path, first route the scalar to the other receiver and
# then return through the intersection to its original destination. Coded
# controls add an independent live receiver field h, transport h separately,
# and undo it at the destination. The new scratch has one owned lifetime.
def changed(addr,coded):
 if addr==1926: clock,other,dest,h=4559,374,349,1560
 else: clock,other,dest,h=4565,349,374,1926
 scratch=N+w['owned_fields'];program=[]
 if not coded: edits=[['MOVE',addr,267,other],['MOVE',addr,other,267],['MOVE',addr,267,dest]]
 else: edits=[['MOVE',addr,267,other],['ADD',addr,h,other],['INIT',scratch,other],['ADD',scratch,h,other],
              ['MOVE',addr,other,267],['MOVE',addr,267,dest],['MOVE',scratch,other,267],['MOVE',scratch,267,dest],
              ['ADD',addr,scratch,dest],['CLEAR',scratch,dest]]
 program=P[:clock]+edits+P[clock+1:]
 q=deepcopy(w);q['program']=program;q['owned_fields']+=int(coded)
 return q,edits,clock

f0,b0,_=op.native_checks(w,atlas);np0,nt0,paid0,target0=op.binary_invoice(w,caller,atlas,f0)
for actual,name in [(np0,'native_paid'),(nt0,'native_targets'),(paid0,'paid'),(target0,'targets')]:
 R(actual==Counter({int(k):x for k,x in receipt['native'][name].items()}),'pinned invoice '+name)
def protected(word,tape):
 result={}
 for addr in (2942,2943,2944,3553):
  clock,=[i for i,e in enumerate(word['program']) if e[0]=='MOVE' and e[1]==addr]
  pid=N+sum(e[0]=='MOVE' for e in word['program'][:clock]);p=tape.packets[pid]
  result[str(addr)]={'source':p.source,'receiver':p.receiver,'grade':p.grade,'support':support(p.arrival.row)}
 return result
protected0=[protected(w,f0),protected(w,b0)]
rates=['0.003879928046155','0.003879928046156','0.003879929046155']
weights={k:{r:v.power_bounds(r,1-F(k),204) for r in set(paid0)|set(target0)|set(range(1,9))} for k in rates}
def quote(hist,k):
 lo=hi=F(0)
 for r,n in hist.items():
  if n:
   x,y=weights[k][r];lo+=n*(x if n>0 else y);hi+=n*(y if n>0 else x)
 return v.decimals((lo,hi))
def signed(target,paid):
 out=Counter(target);out.subtract(paid);return out
def normal(c):return {str(k):c[k] for k in sorted(c) if c[k]}
base=signed(target0,paid0)
def ordinary(q,paid,targets):
 e=Counter(x[0] for x in caller['events']);calls=e['LOCAL'];ports=caller['ports'];roles=caller['roles']
 native=calls*16*(q['owned_fields']+N+4)*len(q['program'])
 records=native+ports*(8*(e['ADD']+3*e['SWAP'])+256*(calls+e['QUERY']+roles))+(4*(sum(paid.values())+sum(targets.values()))+8*ports*(calls+e['IDLE_ONE']))*80*134*135
 fields=calls*(q['owned_fields']+4)+2*ports*roles*len(caller['events'])+16*ports*(calls+e['QUERY']+roles)
 R(records<10**12 and fields<10**7,'ordinary budget')
 return {'records':records,'record_limit':10**12,'owned_fields':fields,'owned_limit':10**7}
controls={}
for addr in D:
 for coded in (False,True):
  name=('encoded-' if coded else 'detour-')+str(addr);q,edits,clock=changed(addr,coded)
  ft=op.run_tape(q,atlas,False);bt=op.run_tape(q,atlas,True)
  for rev,tape in ((False,ft),(True,bt)):
   R(tape.output==op.expected_operator(rev),'complete native '+name)
   R(tape.dirty==3554+int(coded),'dirty retirement '+name)
   R(protected(q,tape)==protected0[int(rev)],'protected bridge/tree '+name)
   pk=[p for p in tape.packets.values() if p.arrival.row>>411&1]
   R(len(pk)==1 and (pk[0].source,pk[0].receiver,pk[0].grade)==((*((1,509) if rev else (509,1)),4)),'owner411 isolation '+name)
   deleted,=[i for i,e in enumerate(q['program']) if e==['ADD',3553,411,509]]
   broken=op.run_tape(q,atlas,rev,omit=deleted).output
   R([x^y for x,y in zip(broken,tape.output)]==[(1<<411) if i==411 else 0 for i in range(N)],'owner411 omission '+name)
  np,nt,paid,targets=op.binary_invoice(q,caller,atlas,ft)
  R(nt==nt0 and targets==target0,'productive unchanged '+name)
  delta=signed(targets,paid);delta.subtract(base)
  expected=4 if coded else 2
  R(normal(Counter({k:np[k]-np0[k] for k in set(np)|set(np0)}))=={'2':expected},'all paid transfer charges '+name)
  # The source readers and all live original fields are literally restored.
  reader=[i for i,e in enumerate(q['program']) if e==P[8511 if addr==1926 else 8792]]
  R(len(reader)==1,'first reader lookup');reader=reader[0]
  for reverse,tape in ((False,forward),(True,adjoint)):
   actual=capture(q,[reader],reverse)[reader];reference=tape[8511 if addr==1926 else 8792]
   R(actual[:len(reference)]==reference and all(x is None for x in actual[len(reference):]),'complete actual reader state '+name)
  # Encoded scalar and its side-information are independent at the first receiver.
  coding=None
  if coded:
   temp=N+w['owned_fields'];c=capture(q,[clock+1,clock+2,clock+4,clock+9])[clock+4]
   source=forward[clock][addr][1];h=forward[clock][1560 if addr==1926 else 1926][1]
   R(rank([source,h])==2 and c[addr][1]==source^h and c[temp][1]==h,'coded scalar contents '+name)
   decoded=capture(q,[clock+9])[clock+9];R(decoded[addr][1]==source,'coded destination decode '+name)
   coding={'live_field':1560 if addr==1926 else 1926,'live_history_support':support(h),'source_plus_history_rank':2,'sent_encoded_support':support(source^h),'sent_side_information_support':support(h),'decoded_before_retirement':True}
  raw=v.canon(q);path=HERE/'words'/(name+'.json.gz')
  if '--write-words' in sys.argv:path.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0))
  R(gzip.decompress(path.read_bytes())==raw,'canonical generated word '+name)
  controls[name]={'edits':edits,'native_paid_delta':{'2':expected},'complete_signed_delta_histogram':normal(delta),
   'full_paid':normal(paid),'full_productive':normal(targets),'gain_at_rates':{k:quote(delta,k) for k in rates},
   'complete_margin_at_rates':{k:quote(signed(targets,paid),k) for k in rates},'coding':coding,
   'canonical_word_sha256':sha256(raw).hexdigest(),'gzip_sha256':sha256(path.read_bytes()).hexdigest(),
   'native_coefficients_each_direction':N*N,'caller_coefficients_each_direction':38*38,'owner411_bridge_and_tree_both_directions':True,
   'first_reader_restored_all_original_live_fields_and_rows_in_each_direction':True,
   'dirty_retirements_each_direction':ft.dirty,'ordinary':ordinary(q,paid,targets)}
out={'status':'PASS_SCOPED_RECEIVER_STOCKS_AND_FOUR_LITERAL_EXCHANGE_CONTROLS',
 'scope':'Fixed #7830 word; source chart267 and other five exits unchanged; two receiver charts 349 and 374; no common chart switch. Actual source-cut stocks and fixed-word histories; two plain detours and two explicitly decoded coded detours, not an enumeration of all reroutings or retimings.',
 'source':{'head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','word_sha256':v.WORD,'prior_temporal_head':'84110d8b3a23674ab648ea47f361b7c925e53b18'},
 'six_source_fields':S,'reference_forward_source_rows':[support(r) for r in ref],
 'geometry':{'receiver_ranks':[6,6],'intersection_rank':4,'intersection_is_chart267':True,'span_rank':8,'direct_receiver_move_legal':False,'via_267_grades':[2,2], 'intersection_dual_rref':[[str(x) for x in row] for row in a]},
 'cut_snapshots':profiles,'baseline_margin_at_rates':{k:quote(base,k) for k in rates},
 'single_scalar_receiver_path':{'scope':'Each edge is a paid nested-subspace MOVE, no free side-information coding or other changed paid incidence',
  'minimum_36_call_transfer_cost':{k:quote(Counter({2:72}),k) for k in rates},
  'method':'If a path touches rank <=4 or 8, there is >=2 rank descent/ascent on each side, costing >=2*2^(1-kappa); otherwise it stays at ranks 5,6,7. A grade-two step requires unit-grade entry and exit, while a path of only unit grades requires at least four, since no common rank-5 subspace or rank-7 superspace exists.'},
 'controls':controls}
print(json.dumps(out,indent=2,sort_keys=True))
