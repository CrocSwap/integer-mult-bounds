# Exact price for one f = 22 loose row over the E8 basis

The minimum price is **63** in the finite family stated below.  The eight
original E8 tight rows retain their 56 units and must pay at least four more;
the efficient loose row costs three.  The minimum is attained by an explicit
integer decoder.  This is a fixed-complement result, not a proof of the loose
decoder wall or of the whole inactive-set SAT cube.

## Family

Use the 104 port roots `C`, sixteen tight roots `Z`, Gram matrix `G`, and
binary matrix `Q` from #7852 at commit
[`41beda1d`](https://github.com/CrocSwap/integer-mult-bounds/tree/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit/drat/data).
The only tight rows are the eight indexed
`[4,5,7,8,9,11,12,15]`; the remaining tight rows are inactive, as in the E8
mask 25679.  There is exactly one additional B-linear order-4 row with
`f = B^{-1} ybar = 22`, and its actual output support `D` has homogeneous
port span of dimension three and is efficient: `|D| >= 4`.  There are no
other rows or exemptions.  The tight rows' output coefficients and supports
may otherwise be arbitrary, subject to the decoder equations.  Here a row's
price is `rank_F2 Q[D,S]`, where `D` and `S` are its output and input supports
modulo four.

There are 256 actual lifts of `f` to `Z/4`, or 128 up to sign.  Every one has
input support whose homogeneous labels span `F2^9`, so a loose output with
dimension-three span costs exactly three.  Its efficiency forces exactly four
ports: a three-space contains at most four vectors with first coordinate 1.
There are 17,958 such four-port planes in the pinned data.  This result covers
all the lifts, all these planes, all valid values of the output coefficients,
and either allowed per-port sign in the mod-4 decoder consequence.

## Price proof

Let `A` be the integer 8-by-8 matrix whose columns are the eight active roots.
The replay finds `A` unimodular.  Hence each port `c_t` has a unique tight
coefficient vector `a_t = A^{-1} c_t` modulo four.  It also verifies the
per-port consequence of the **selected decoder equations directly**: for
each port, the kernel of the selected Gram forms on `(Z/4)^8` is exactly
`{0, 2 c_t}`, so the represented target is `+c_t` or `-c_t` modulo four.
There is no need to assume the mod-4 covering characterization in the proof.

In the original eight-row E8 decoder, tight row `i` has 52 output ports and
price seven.  The replay enumerates its 127 nonzero binary column-code words;
the minimum weight is 22 for each row.  Therefore deleting any four ports
leaves each tight row's price seven: a rank drop would require deleting the
support of a nonzero column-code word.  Outside the four ports served by the
loose row, the eight tight coefficients are uniquely fixed up to the per-port
sign, so these seven-dimensional price spaces are forced.

For a port `t`, call a tight row **bad** when the new row vector `Q[t,S_i]`
lies outside that seven-space.  Such a port has `a_t[i] = 0 mod 4`, since a
nonzero original coefficient would have placed it in the original support.
Every lift of `f = 22` has all eight coordinates odd in the `A` basis.  Thus a
nonzero loose coefficient at `t` forces a nonzero tight coefficient in every
bad row, irrespective of that coefficient's value or the target sign.  The
tight row's price becomes eight.  Its full `Q[:,S_i]` has rank eight, so this
is its exact price, not merely a lower bound.

There is also a short lower-bound argument independent of the plane census.
The replay finds a nine-bit normal to each original homogeneous port span
and checks that its value on `h_t` is exactly the corresponding bad bit.
Consequently the bad-set mask is linear in `h_t`.  The 104 bad-set masks are
distinct and each contains at least two tight rows.  The XOR of the four masks
on an affine plane is zero, because the XOR of its four `h_t` is zero.  If
their union had at most three bits, four distinct masks of size at least two
would have to be the three pairs and the triple of those bits; their XOR is
the nonzero triple.  This contradiction proves a surcharge of at least four.
The explicit four-surcharge witness below proves sharpness.

The 17,958 planes give the following distribution of the number of bad tight
rows in their union.  Since the loose row costs three, the total is exactly
`59 + surcharge` throughout this family.

| Surcharge | Planes | Total price |
| ---: | ---: | ---: |
| 4 | 38 | 63 |
| 5 | 624 | 64 |
| 6 | 3,948 | 65 |
| 7 | 7,144 | 66 |
| 8 | 6,204 | 67 |

The 384 supplied mod-2 symmetries fix `f = 22`; 48 stabilize the inactive
set.  The 17,958 planes form 114 orbits under the full group and 483 under
that stabilizer.  The 38 minimum planes form three stabilizer orbits of sizes
6, 8, and 24.  Orbits are used for description; the lower bound enumerates
every plane and does not rely on orbit reduction or a mod-4 lift of a symmetry.

## Exact witness and controls

Use the minimum plane `(0,6,72,77)` and root-coordinate lift
`x = (0,1,1,0,1,0,0,0)`, so `y = Gx mod 4 = (0,1,2,1,1,1,1,1)`.
Let `l = A^{-1}x`, let `a_t` be as above, and set the loose coefficient to 1
on the four plane ports and 0 elsewhere.  The eight tight coefficients for
port `t` are `a_t - loose_coefficient(t) * l`.  With columns
`V[s,i] = <c_s, z_i>` and `V[s,loose] = <c_s,x>`, the replay checks all
10,816 exact integer equalities `W V^T = Gamma`, and independently checks
the `Q`-selected decoder identity.  Loose input values lie in
`{-2,-1,0,1,2}`.  The nine row prices are
`[8,7,7,8,8,7,8,7,3]`, totaling 63.

The unmodified eight-row decoder is separately checked at price 56 with exact
integer Gram product.  A separate F2-REL control appends the four-port
generic availability to the E8 tight spans: all 104 ports still decode in
that relaxation and its price is 59.  Naively appending the active loose
column to the unchanged exact E8 output has nominal price 59 but fails the
selected mod-4 equations.  This illustrates why the F2 shadow control is not
an exact decoder at budget 59.  Removing one loose coefficient from the 63
witness also fails the actual selected equations.

## Replay and provenance

Run `python3 -B verify.py`.  It takes the three pinned text inputs under
`source/`, checks their SHA-256 hashes, and uses only the Python standard
library.  It independently computes the selected-equation kernels, ranks,
code distances, plane census, mod-2 symmetry action and stabilizer, exact
integer witness, and both controls.  `RESULT.json` records one run.  The
author's original loose-row definitions and F2 relaxation are in #7869 at
[`06c207a9`](https://github.com/CrocSwap/integer-mult-bounds/blob/06c207a9feb3994a4b987dc3010657b6e85b7956/research/p104-lowerbound-guidance/notes/loose.md).
The input data and original research are by DreamingOfClouds with Claude Opus
5.5; the finite subcase, witness, and independent replay here were developed
with OpenAI Codex assistance.  The upstream license is `source/LICENSE`.

The 63 result does not cover a different active tight set, additional tight
or order-2 rows, exemptions, more than one loose row, a loose span of dimension
other than three, other generic `f` orbits, nonlinear decoders, a universal
decoder wall, or a kappa claim.  In particular, those possibilities prevent
using this fixed-complement result to close all of cube 25679 at budget 55.
