#!/usr/bin/env python3
"""Finite support-screen for the two hard T<=5 timed-graph cases.

Enumerates every chronologically ordered simple DAG on four/five marked
positive-drop vertices.  The exact path rank test is structural: it searches
for vertex-disjoint path families, not numerically sampled edge weights.  By
the path-determinant identity, absence of such a family makes the determinant
identically zero for ALL rational edge weights, including cancellation.  This
is a finite check of the graph reduction, not a Lean proof of the network
reduction or an enumeration of P104 networks.
"""
from collections import Counter
from fractions import Fraction as Q
from itertools import combinations


def partitions(n, bound=None):
    if n == 0:
        yield ()
        return
    for x in range(min(n, bound or n), 0, -1):
        for rest in partitions(n-x, x):
            yield (x,) + rest


def path_options(src, terminals, adj):
    """All (vertex mask, terminal id) of paths, including length zero."""
    opts = set()
    def dfs(v, seen):
        if v in terminals:
            opts.add((seen, v))
        for w in adj[v]:
            dfs(w, seen | (1 << w))
    dfs(src, 1 << src)
    return sorted(opts)


def three_disjoint(high, low, terminals, adj):
    # Distinct sources, vertex-disjoint and distinct terminal exits.
    options = [path_options(v, terminals, adj) for v in (*high, low)]
    if any(not q for q in options):
        return False
    for m0, e0 in options[0]:
        for m1, e1 in options[1]:
            if m0 & m1 or e0 == e1:
                continue
            for m2, e2 in options[2]:
                if not (m2 & (m0 | m1)) and e2 != e0 and e2 != e1:
                    return True
    return False


def graph_edges(k, mask):
    possible = list(combinations(range(k), 2))
    edges = [edge for bit,edge in enumerate(possible) if mask & (1 << bit)]
    adj = [[] for _ in range(k)]
    for a,b in edges:
        adj[a].append(b)
    return edges, adj


def exact_path_matrix(k, edges):
    """Independent forward evaluation with signed rational edge weights."""
    H = [[Q(0) for _ in range(k)] for _ in range(k)]
    for i,(u,v) in enumerate(edges):
        H[v][u] = Q((-1 if i % 2 else 1)*(i+2), i+3)
    N = [[Q(0) for _ in range(k)] for _ in range(k)]
    for i in range(k):
        for j in range(i+1):
            N[i][j] = Q(i == j) + sum((H[i][p]*N[p][j] for p in range(i)),Q(0))
    return N


def det3(a):
    return (a[0][0]*a[1][1]*a[2][2] + a[0][1]*a[1][2]*a[2][0]
            + a[0][2]*a[1][0]*a[2][1] - a[0][2]*a[1][1]*a[2][0]
            - a[0][1]*a[1][0]*a[2][2] - a[0][0]*a[1][2]*a[2][1])


def chart_classes(terminals, gateways, edges, high_terminal=None):
    """Gateway->7D terminal forces a_terminal=b_gateway (7D)."""
    low = [x for x in terminals if x != high_terminal]
    parent = {x:x for x in low}
    def root(x):
        while parent[x] != x:
            x = parent[x]
        return x
    for z in gateways:
        fed = [v for u,v in edges if u == z and v in parent]
        for v in fed[1:]:
            parent[root(v)] = root(fed[0])
    return {x:root(x) for x in low}


def screen(k):
    totals = Counter()
    negative = None
    for high in combinations(range(k), 2):
        # k=5: both highs are nonterminal one-drop gateways, other 3 terminal.
        # k=4: one high is the double-drop terminal and other the one-drop gateway.
        for high_terminal in ([None] if k == 5 else high):
            gateways = list(high) if high_terminal is None else [x for x in high if x != high_terminal]
            terminals = [x for x in range(k) if x not in gateways]
            assert len(terminals) == 3
            lows = [x for x in terminals if x != high_terminal]
            for mask in range(1 << (k*(k-1)//2)):
                edges,adj = graph_edges(k,mask)
                totals["ordered_graphs"] += 1
                possible = [v for v in lows if three_disjoint(high,v,terminals,adj)]
                N = exact_path_matrix(k,edges)
                for low in lows:
                    d = det3([[N[t][source] for source in (*high,low)] for t in terminals])
                    assert not d or low in possible, (high,high_terminal,edges,low,d)
                    totals["exact_signed_minors"] += 1
                groups = chart_classes(terminals, gateways, edges, high_terminal)
                # Under any assignment of distinct charts, two sources with
                # distinct charts cannot both have a nonzero 3x3 determinant.
                count = len({groups[v] for v in possible})
                totals["graphs_with_a_possible_minor"] += bool(possible)
                totals["violations"] += count >= 2
                if len(possible) >= 2 and negative is None:
                    negative = {"high":high, "high_terminal":high_terminal,
                                "edges":edges,"possible":possible,"forced_classes":groups}
    assert totals["violations"] == 0, totals
    assert negative is not None  # The chart-equality rule is doing real work.
    print(f"k={k}: {dict(totals)}")
    print(f"k={k}: dropping chart-equality permits two nominally distinct low candidates: {negative}")


groups = Counter()
for total in range(1,6):
    for part in partitions(total):
        groups["fewer_than_three_marked" if len(part) < 3 else "at_least_three_marked"] += 1
        if len(part) >= 3:
            print("partition", part, "T=", total)
assert groups == {"fewer_than_three_marked":11, "at_least_three_marked":7}, groups
screen(4)
screen(5)
print("ALL TIMED SUPPORT SCREENS PASSED")
