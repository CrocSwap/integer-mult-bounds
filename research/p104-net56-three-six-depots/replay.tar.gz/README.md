# Three six-dimensional P104 depositor inputs

This is a **paper argument with finite exact controls**, not a Lean theorem,
an exhaustive enumeration of P104 networks, or a general NET-D56 proof. The
original P104 `NetW` model, support rules and rigidity are credited to
DreamingOfClouds with Claude Opus 5.5, pinned at [#7852, head
`41beda1d6435760dc99e38bd7e65f36798aad212`](https://github.com/CrocSwap/integer-mult-bounds/pull/7852).
The first-depositor sink, two-low proof, tools, examples and inherited notices
are from [#7916, head
`8b8965f2bb10f30b24efa15154ad56d71b911211`](https://github.com/CrocSwap/integer-mult-bounds/pull/7916).
Its pinned `SOURCES.json` states archive SHA-256
`0709a966847b52f68bfb813fb1257925b2155fdffd9545485ab8e15473070bb2`;
the locally extracted `prior/` is from exactly that archive and every member
in its manifest passes `sha256sum -c`. All inherited source credits and
Apache-2.0 notices are in `prior/source/NOTICE-P104.md` and
`prior/source/LICENSE-7852`.

## Claim and scope

Suppose a P104 `NetW` has `b_j ⊆ a_j`, exactly nine active gatherers of
dimensions `7,7,≥8,≥8,≥8,≥8,≥8,≥8,≥8`, and exactly eight active depositors,
three with 6D input charts and five with input dimension at least 8. Let

* `T = Σ (dim a_x − dim b_x)` over all nondepositors;
* `E = Σ max(dim a_d − 8,0)` over all depositors; and
* `B` be the number of depositors with `dim b_d=0`.

Then **T ≥ 6 and D = 50 + E + B + T ≥ 56 + E + B**. This permits arbitrary
rational coefficients, path cancellation, zero-dimensional output charts,
and ordered or comparable depositors. A P104 network in the checker
attains E=B=0, T=6, D=56; a second has a real depositor relay and attains
E=1, B=0, T=6, D=57. These are Python-checked finite examples, not Lean
objects or claims that either network is realizable by a legal word. A word
conclusion needs the separate bridge and the asserted induced-network
profile; neither was established here.

## Reduction to a three-row transfer

In the **original** network put `N=(I-H)^−1`, and let S be the nine
gatherers and Dset the eight depositors. The P104 odd-cell condition gives
transfer rank eight. The eight-depositor factorization and P104 eight-row
rigidity, applied before changing the network, give:

1. `C=N[Dset,S]` has row rank 8;
2. the unique relation among its nine columns has nonzero coefficients at
   both 7D gatherers, whose 7D input charts are distinct; and
3. every active depositor has `dim b_d≤1`.

Delete all edges leaving depositors to make an auxiliary sink graph, whose
path matrix is `N0=(I−H0)^−1`. It need not satisfy the P104 transfer
condition. The first-depositor decomposition, including length-zero paths,
is `C=A C0`, where `C0=N0[Dset,S]` and `A=N[Dset,Dset]` is unit lower
triangular. Therefore C0 still has row rank 8 and exactly C's column kernel.
Gatherers that are depositors have no outgoing edges in this auxiliary graph.

Let L be the three 6D depositors and put `P=C0[L,S]`. Its three rows are
independent, so `rank P=3`. Let `P_H` be its seven columns from the ≥8D
gatherers. The preserved relation has two nonzero 7D coefficients and
therefore `rank P ≤ rank P_H + 1`; in particular `rank P_H≥2`.

Let X be all positive-drop nondepositors. Every gather-to-L path meets X:
if it did not, zero-drop chart propagation would place its gatherer's
at-least-7D input chart inside a 6D depositor chart. This also covers a
gatherer in X, as its first-X prefix can have length zero. Define `J[x,g]`
as the path sum from g to x whose only X vertex is x, `K[y,x]` as the path
sum from x to y with no other X vertex, and `U[d,x]` as the path sum from x
to d with no other X vertex. Then K is strictly lower triangular and

```
P = U (I−K)^−1 J,          rank U = 3.
```

All these are exact signed rational sums. Call x **terminal** if its U
column is nonzero, and write `t_x=N0[L,x]` for its complete downstream path
vector, including paths through later X vertices. If x has drop `δ_x`, a
nonzero U column supplies a support path from its output chart to a 6D
depositor through zero-drop nodes, hence `dim a_x≤6+δ_x`. A high gather
can first meet X only at a node whose input has dimension at least 8. A 7D
gather can first meet X at a 7D node only if the two input charts agree.

For any x the path decomposition at the next X vertex gives

```
t_x = U[:,x] + Σ_y K[y,x] t_y.                         (1)
```

Here nonzero `K[y,x]` implies at least one actual zero-drop-segment support
path, so `b_x⊆a_y`; its value may be a sum with cancellation. We never infer
the converse. If a 1-drop node x has input dimension at least 8 and a
successor y is a 1-drop terminal, then `dim b_x≥7` and `dim a_y≤7`.
Consequently both dimensions are 7 and `a_y=b_x`.

## Excluding all drop partitions through five

Suppose T≤5. Since `rank U=3`, there are at least three terminal vertices
and at least three vertices in X. The seven possible drop partitions are

```
T=3: 1+1+1
T=4: 2+1+1, 1+1+1+1
T=5: 3+1+1, 2+2+1, 2+1+1+1, 1+1+1+1+1.
```

In each case all other nodes have zero drop. Treat the nonzero first-X
path sums as arbitrary rationals, and partition each column by its first X
vertex. The high columns are contained in the span of full t vectors at
nodes of input dimension at least 8.

### Three positive-drop nodes

All three are terminal, and therefore each 1-drop node has input dimension
at most 7. At most two nodes can admit a high gather. If fewer than two do,
`rank P_H≥2` is impossible. Otherwise their full t vectors span a space W
of dimension two containing every high column. There is at most one other
node. It has input dimension at most 7 and can be first X contact for at
most one of the two distinct 7D-gather charts. Thus at least one 7D column
lies in W. The preserved relation with both low coefficients nonzero puts
the other 7D column in W as well, contradicting `rank P=3`.

### Four 1-drop nodes

At least three are terminal and cannot admit a high gather. There is at most
one remaining high-entry node, contrary to `rank P_H≥2`.

### Three terminals: a basis observation

The remaining cases each have exactly three terminals Y. Their three U
columns are a basis of `Q³`. The principal Y-by-Y submatrix of `(I−K)^−1`
is unit triangular, so the three **full** vectors `t_y`, y in Y, are also
a basis. This remains true if paths between terminals pass through other
marked vertices, and is why terminal U columns cannot be substituted for
the full vectors in the argument below.

### Partition 2+1+1+1

There must be at least two high-entry vertices. Since at least three
vertices are terminal, the only possibility is: a 2-drop high-entry
terminal x, a 1-drop high-entry nonterminal z, and two 1-drop terminals
y and w. Their high transfer space is `W=span(t_x,t_z)`, of dimension 2.
Equation (1) gives

```
t_z = α t_x + β t_y + γ t_w,
```

where any y or w with a nonzero displayed coefficient has
`a_y=b_z` or `a_w=b_z`, respectively. The y/w part is nonzero, since
`t_z` and `t_x` are independent. If both coefficients are nonzero then
both low-entry terminals have the same 7D chart, so only one distinct 7D
gather chart can use either. If only one coefficient is nonzero, that
terminal's full t vector lies in W; only the other terminal can contribute
outside W. In either case **at most one of the two distinct low gathers can
have a column outside W**. Their relation then puts both in W, a
contradiction.

### Partition 1+1+1+1+1

The three terminal vertices Y cannot admit a high gather. Therefore the
other two vertices z1 and z2 are exactly the high-entry vertices, and
`W=span(t_z1,t_z2)` has dimension 2. Put z1 before z2. In (1), the later
gateway has no gateway successor, while the earlier can next meet z2:

```
t_z2 = Σ_(y∈Y) d_y t_y,
t_z1 = k t_z2 + Σ_(y∈Y) c_y t_y.
```

Both displayed terminal combinations are nonzero; otherwise t_z1 and t_z2
would be dependent. Every terminal appearing in the first sum has the same
7D chart `b_z2`, and every terminal appearing in the second has the same
7D chart `b_z1`. Since the `t_y` form a basis, partition `Q³` as the
direct sum of blocks generated by those basis vectors with equal input
charts. If the two gateway output charts differ, W is the direct sum of one
nonzero line in each of those two blocks. If they coincide, W is a 2D
subspace of that one block. Either way W is a direct sum of subspaces
within chart blocks. Because W has codimension one, **at most one chart
block can have a nonzero image in `Q³/W`**. Any low-gather path first
meeting a terminal can meet only one whose 7D chart equals that gather's
chart; a path first meeting a gateway contributes in W. Hence at most one
of the distinct low-gather columns can lie outside W. The nonzero two-low
relation forces both into W, contradicting `rank P=3`.

This excludes T≤5. The original-network depositor rigidity gives
`Σ_d(dim a_d−dim b_d)=3·6+5·8+E−(8−B)=50+E+B`; adding the other drops
finishes the stated inequality.

## Reproduction and what it checks

From this directory:

```
(cd prior && sha256sum -c SHA256SUMS)
python3 -B check_three_six.py
python3 -B check_timed_graphs.py
python3 -B check_path_control.py
```

`check_three_six.py` first reruns all inherited #7916 examples, including
its sharp T=4 controls. It then retimes three 7D depositor inputs to 6D,
inserting a `(7,6)` nondepositor for each, and exactly checks all P104 odd
and diagonal cells, the complete 104×104 Gram matrix, chart inclusions,
time ordering, counts, D, sink identity, common circuit and path ranks.
It separately constructs the relay control and checks that sinking with the
old G really breaks the transfer. `THREE-SIX-REPLAY.log` is the run output.

`check_timed_graphs.py` lists all seven T≤5 partitions and independently
screens the hard 4- and 5-vertex temporal support cases. It enumerates all
768 and 10,240 chronological marked DAGs, respectively. A nonzero 3×3
path minor requires three vertex-disjoint paths to distinct terminal exits
(the path-determinant identity). The screen checks that any terminal
sources supporting such minors lie in at most one forced 7D chart class.
It permits other graph edges freely, so this is an over-approximation.
Absence of a disjoint path family makes the minor the zero polynomial for
all rational weights, including zero sums and cancellation. A negative
control finds graphs with two candidate terminals if the forced chart
equality is ignored. This finite screen checks the reduced timed-graph
claim; it neither verifies the paper reduction nor quantifies over every
P104 network. As an independent numerical sanity check, it also evaluates
32,256 minors once each using exact signed rational edge weights; those
samples alone do not establish the all-coefficient claim. Output is
`TIMED-SCREEN.log`.

`check_path_control.py` is a separate exact F₂-chart-compatible synthetic
DAG with T=5, two distinct 7D sources, `rank P=3`, `rank P_H=2`, and
cancelled signed bridge paths. Its unique column relation has a zero
coefficient at one 7D source, explicitly showing why the original P104
nonzero-low circuit condition is needed. It is not a P104 counterexample.
Output is `PATH-CONTROL.log`.
