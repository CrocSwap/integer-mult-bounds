#!/usr/bin/env python3
"""Exact synthetic marked-DAG control; it is NOT a P104 network.

It respects nested F2 charts and edge inclusions, has three 6D sinks,
two distinct 7D sources, two 8D sources, T=5, rank P=3 and rank P_H=2.
The column relation has a zero coefficient on one low source, so the
original-network P104 circuit hypothesis is absent. Signed paths cancel.
"""
from fractions import Fraction as Q


def echelon(vecs):
    piv = {}
    for v in vecs:
        while v:
            p = v.bit_length()-1
            if p in piv:
                v ^= piv[p]
            else:
                piv[p] = v
                break
    return list(piv.values())


def contains(a, v):
    return len(echelon(a+[v])) == len(echelon(a))


def rank(m):
    a = [[Q(x) for x in row] for row in m]
    h, w, r = len(a), len(a[0]), 0
    for j in range(w):
        p = next((i for i in range(r,h) if a[i][j]), None)
        if p is None:
            continue
        a[r],a[p] = a[p],a[r]
        q = a[r][j]
        a[r] = [v/q for v in a[r]]
        for i in range(h):
            if i != r:
                q = a[i][j]
                a[i] = [x-q*y for x,y in zip(a[i],a[r])]
        r += 1
        if r == h:
            break
    return r


C = [1 << i for i in range(6)]
A = C + [1 << 6]
B = C + [1 << 7]
AB = C + [1 << 6,1 << 7]
# z0,z1, two zero-drop A bridges, y2,y3,y4, three 6D sinks.
a = [AB,AB,A,A,B,A,A,C,C,C]
b = [A,B,A,A,C,C,C,[],[],[]]
n = len(a)
H = [[Q(0) for _ in range(n)] for _ in range(n)]
for v,u,w in [(2,0,1),(3,0,1),(5,0,2),(5,2,1),(5,3,-1),
              (6,0,-3),(4,1,Q(5,2)),(7,4,1),(8,5,1),(9,6,1)]:
    H[v][u] = Q(w)
assert all(contains(a[i],v) for i in range(n) for v in b[i])
assert all(u < v and all(contains(a[v],x) for x in b[u])
           for v in range(n) for u in range(n) if H[v][u])
assert len(echelon(A)) == len(echelon(B)) == 7 and len(echelon(A+B)) == 8
assert [len(echelon(a[i]))-len(echelon(b[i])) for i in range(7)] == [1,1,0,0,1,1,1]

N = [[Q(0) for _ in range(n)] for _ in range(n)]
for i in range(n):
    for j in range(i+1):
        N[i][j] = Q(i == j) + sum((H[i][k]*N[k][j] for k in range(i)), Q(0))
sources = [0,1,5,4] # 8D, 8D, 7D chart A, 7D chart B
sinks = [7,8,9]
P = [[N[d][g] for g in sources] for d in sinks]
assert P == [[0,Q(5,2),0,1],[2,0,1,0],[-3,0,0,0]]
assert rank(P) == 3 and rank([row[:2] for row in P]) == 2
# Unique relation, normalized here: -(2/5) H2 + L_B = 0;
# its L_A coefficient vanishes and so this is NOT the P104 setting.
relation = [Q(0),Q(-2,5),Q(0),Q(1)]
assert all(sum(x*y for x,y in zip(row,relation)) == 0 for row in P)
assert H[5][2]*H[2][0] + H[5][3]*H[3][0] == 0
print("synthetic only: T=5; distinct 7D sources; rank(P)=3, rank(P_H)=2")
print("exact P =", [[str(x) for x in row] for row in P])
print("unique relation =", [str(x) for x in relation], "; one low coefficient is zero")
print("two signed bridge path contributions cancel exactly")
print("SYNTHETIC CONTROL PASSED; NOT A P104 COUNTEREXAMPLE")
