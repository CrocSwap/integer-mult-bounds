#!/usr/bin/env python3
"""Exact finite controls for the three-six extension; not the paper proof.

Run beside the byte-verified prior/ directory extracted from #7916.
Only Python standard library is used.
"""
from pathlib import Path
import runpy
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
# This executes all inherited sharp-two-six checks before returning functions.
old = runpy.run_path(str(HERE / "prior" / "check_two_six.py"))
r, p, s = old["r"], old["p"], old["s"]


def check(name, net, expected_EBT, expected_comparable):
    M, gat, dep, D, dims = s["verify"](name, net)
    assert M == s["M0"]
    assert len(gat) == 9 and len(dep) == 8
    gdims = sorted(dims[g][0] for g in gat)
    assert gdims in ([7,7,8,8,8,8,8,8,8], [7,7,8,8,8,8,8,8,9])
    lowg = [g for g in gat if dims[g][0] == 7]
    assert len(lowg) == 2
    assert len(s["echelon"](net["a"][lowg[0]] + net["a"][lowg[1]])) == 8
    lows = [d for d in dep if dims[d][0] == 6]
    assert len(lows) == 3 and all(dims[d][0] >= 8 for d in dep if d not in lows)
    assert all(dims[d][1] <= 1 for d in dep)
    E = sum(max(dims[d][0] - 8, 0) for d in dep)
    B = sum(dims[d][1] == 0 for d in dep)
    X = [i for i in range(len(dims)) if i not in dep and dims[i][0] > dims[i][1]]
    T = sum(dims[x][0] - dims[x][1] for x in X)
    assert (E, B, T) == expected_EBT
    assert D == 50 + E + B + T == 56 + E + B
    R = p["c"]["reachability"](net["H"])
    pairs = [(d,e) for d in dep for e in dep if d != e and e in R[d]]
    assert len(pairs) == expected_comparable, pairs

    H0, N, N0, A, C, C0 = r["sink_factor"](net["H"], dep, gat)
    assert r["rank"](C) == r["rank"](C0) == 8
    lam = r["kernel_one"](C0)
    assert lam == r["kernel_one"](C)
    assert all(lam[gat.index(g)] != 0 for g in lowg)
    P,U,Qx,J,V = p["factors"](H0, gat, lows, X)
    assert P == [C0[dep.index(d)] for d in lows]
    assert r["rank"](P) == r["rank"](U) == 3
    high = [j for j,g in enumerate(gat) if dims[g][0] >= 8]
    high_rank = r["rank"]([[row[j] for j in high] for row in P])
    assert high_rank >= 2
    assert all(not v for row in V for v in row)
    assert not p["odd_transfer_errors"](net, net["H"])
    print(f"{name}: dimensions={gdims}; lows={lows}; X={X}")
    print(f"{name}: E={E} B={B} T={T} D={D}; comparable pairs={pairs}")
    print(f"{name}: exact original Gram and P104 cells; rank(C0)=8, rank(P)=rank(U)=3, rank(P_high)={high_rank}")
    print(f"{name}: common C/C0 circuit has two nonzero 7D coefficients; all X-avoiding P paths vanish")
    return H0


# The three-7D fixture is inherited from #7916. Each retiming inserts a
# (7,6) nondepositor before a distinct 7D depositor, preserving transfer.
net = p["net"]
for _ in range(3):
    net = p["retime_depot_7_to_6"](net)
check("three-six equality", net, (0,0,6), 0)

# A real nonzero depositor-to-depositor relay, with a compensating F row,
# preserves the complete Gram transfer and adds one unit E.
relay, u, z, v, coefficient = r["add_relay_preserving_full_transfer"](net)
H0 = check("three-six with relay", relay, (1,0,6), 1)
assert coefficient != 0 and relay["H"][z][u] != 0 and relay["H"][v][z] != 0
errors = p["odd_transfer_errors"](relay, H0)
assert errors and any(i == j for i,j,_ in errors)
print("three-six with relay: sinking without G adjustment breaks", len(errors), "odd/diagonal cells")
print("ALL THREE-SIX AND INHERITED TWO-SIX CONTROLS PASSED")
