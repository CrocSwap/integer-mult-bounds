#!/usr/bin/env python3
"""Find the first admissible boundary-bearing two-node old/fresh exchange.
Read only pinned #7910 archive; search is a finite screen, no physical-word claim.
"""
from itertools import product
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent/'source'))
from mincut import network, patterns
from common import baseline

word,*_=baseline()
nodes, charts, fixed, neighbors, edges=network(word)
dim={int(k):v['dim'] for k,v in word['frames'].items()}
states=tuple(product((0,1), repeat=2))
seen=set()
for number, (axis, pattern) in enumerate(patterns(word['frames'])):
    if number==0 or pattern in seen:
        continue
    seen.add(pattern)
    x=[pattern[c] for c in charts]
    free={i for i,z in enumerate(x) if z!=2 and i not in fixed and all(x[j]!=2 for j in neighbors[i])}
    pairs=sorted((i,j) for i in free for j in neighbors[i] if i<j and j in free and ((neighbors[i]|neighbors[j])-{i,j}))
    for i,j in pairs:
        contacts=[(a,b,edges[tuple(sorted((a,b)))]) for a in (i,j) for b in neighbors[a] if b not in (i,j) or a<b]
        for si,sj in product(states,repeat=2):
            if not (si[1] or sj[1]):
                continue
            changes={i:si,j:sj}
            touched=False
            valid=True
            for a,b,(m,g) in contacts:
                xa,xb=x[a],x[b]
                u=changes.get(a,(xa,0));v=changes.get(b,(xb,0))
                d=g-abs(xa-xb)
                if dim[charts[a]]>dim[charts[b]]:
                    u,v=v,u
                if d:
                    if u[0]>v[0] or u[1]>v[1]:
                        valid=False;break
                elif not ((u[0]<=v[0] and u[1]<=v[1]) or (v[0]<=u[0] and v[1]<=u[1])):
                    valid=False;break
                if abs(u[0]-v[0]) < abs(xa-xb) and abs(u[1]-v[1])>0 and m>0:
                    touched=True
            if valid and touched:
                print('FOUND',number,axis,(i,j),[(charts[n],x[n],changes[n]) for n in (i,j)],'free',len(free),'seen',len(seen),flush=True)
                sys.exit(0)
    if number%300==0:
        print('progress',number,'unique',len(seen),flush=True)
print('NONE all unique',len(seen),flush=True)
