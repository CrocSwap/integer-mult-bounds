#!/usr/bin/env python3
"""Finite, single-CPU scan of pairs of adjacent eligible old/fresh components.

All other components are fixed.  Each tested old direction must reduce each
selected chart and every neighbor, and each affected contact must stay nested.
Integer 1e28 outward enclosures price every affected signed contact.  The scan
stops early on a strictly positive lower endpoint, for exact projector follow-up.
"""
from collections import Counter
from hashlib import sha256
from itertools import product
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'source'))
from common import baseline,RATES,check
from mincut import network,patterns,directed_weights,SCALE
OUT=Path(__file__).resolve().parent
word,*_=baseline()
nodes,charts,fixed,nb,edges=network(word)
dim={int(k):v['dim'] for k,v in word['frames'].items()}
rank=[dim[c] for c in charts]
W=[directed_weights(k) for k in RATES]
S=tuple(product((0,1),repeat=2))
seen=set();digest=sha256();stats=Counter()
maxupper=[None,None]; maxw=[None,None]; firstpositive=None
for num,(axis,pat) in enumerate(patterns(word['frames'])):
    if num==0 or pat in seen:continue
    seen.add(pat); stats['unique_patterns']+=1
    x=[pat[c] for c in charts]
    free={i for i,z in enumerate(x) if z!=2 and i not in fixed and all(x[j]!=2 for j in nb[i])}
    pairs=sorted((i,j) for i in free for j in nb[i] if i<j and j in free)
    if pairs:stats['patterns_with_pairs']+=1
    for i,j in pairs:
        stats['pairs']+=1
        # Encode every paid and helper incidence through its exact signed grouped
        # coefficient.  Zero-coefficient contacts still constrain nestedness.
        adjacent=[(a,b,*edges[tuple(sorted((a,b)))]) for a in (i,j) for b in nb[a] if b not in (i,j) or a<b]
        for ai,aj in product(S,repeat=2):
            stats['assignments']+=1
            # Four-state variable; the rest of each graph is at its old bit and 0 fresh.
            pos={i:ai,j:aj}; hist=Counter(); good=True
            for a,b,m,g in adjacent:
                xa,xb=x[a],x[b];u=pos.get(a,(xa,0));v=pos.get(b,(xb,0))
                d=g-abs(xa-xb)
                if rank[a]>rank[b]:u,v=v,u
                if d:
                    if u[0]>v[0] or u[1]>v[1]:good=False;break
                elif not ((u[0]<=v[0] and u[1]<=v[1]) or (v[0]<=u[0] and v[1]<=u[1])):
                    good=False;break
                new=d+abs(u[0]-v[0])+abs(u[1]-v[1])
                check(0<=new<=9,'new rank bound')
                if m and new!=g:hist[g]+=m;hist[new]-=m
            if not good:continue
            stats['nested']+=1
            hist={g:c for g,c in sorted(hist.items()) if c}
            if not hist:stats['exact_ties']+=1
            highs=[];lows=[]
            for lo,hi in W:
                highs.append(sum(c*(hi[g] if c>0 else lo[g]) for g,c in hist.items()))
                lows.append(sum(c*(lo[g] if c>0 else hi[g]) for g,c in hist.items()))
            row=[num,axis,i,j,ai,aj,hist,lows,highs]
            for z in range(len(RATES)):
                if maxupper[z] is None or highs[z]>maxupper[z]:
                    maxupper[z]=highs[z];maxw[z]=row
                if lows[z]>0:
                    firstpositive=row; break
            digest.update(json.dumps(row,separators=(',',':'),sort_keys=True).encode()+b'\n')
            if firstpositive:break
        if firstpositive:break
    if firstpositive:break
    if num%500==0:
        print('progress',num,'patterns',len(seen),'pairs',stats['pairs'],'nested',stats['nested'],flush=True)
out={'completed_all_directions':firstpositive is None,'direction_patterns':stats['unique_patterns'],
     'scale':SCALE,'statistics':dict(stats),'rates':[str(x) for x in RATES],
     'max_native_signed_gain_upper_units':maxupper,'max_upper_witness':maxw,
     'first_strictly_positive_lower_witness':firstpositive,'digest_of_tested_nested_states':digest.hexdigest()}
check(json.loads(json.dumps(out))==json.loads((OUT/'SCAN.json').read_bytes()),
      'grouped scan matches frozen receipt')
print('PASS_GROUPED_SCAN_RECEIPT',flush=True)
print(json.dumps(out,indent=2,sort_keys=True),flush=True)
