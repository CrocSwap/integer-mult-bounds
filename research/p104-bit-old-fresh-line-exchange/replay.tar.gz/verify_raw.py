#!/usr/bin/env python3
"""Independent arithmetic replay of scan_two: raw route/helper incidences.

Compare quotient-projector ranks, price each primitive incidence first, and
combine only afterwards.  This does not use the grouped signed-cost loop in
scan_two.py and cross-checks its finite census and outward sign conclusions.
"""
from collections import Counter,defaultdict
from itertools import product
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parent/'source'))
from common import baseline,RATES,check
from mincut import network,patterns,directed_weights
from timeline import timeline
w,*_=baseline(); nodes,charts,fixed,nb,_=network(w); trace=timeline(w)
ranks=[w['frames'][str(c)]['dim'] for c in charts]
incident=defaultdict(set)
for k,c in enumerate(trace['contacts']):
    incident[c['i']].add(k);incident[c['j']].add(k)
weights=[directed_weights(k) for k in RATES]
seen=set();counts=Counter();fail=[]
for ax,pat in patterns(w['frames']):
    if not any(ax) or pat in seen:continue
    seen.add(pat);x=[pat[c] for c in charts]
    free={i for i in range(len(nodes)) if x[i]<2 and i not in fixed and all(x[j]<2 for j in nb[i])}
    pairs=[(i,j) for i in sorted(free) for j in sorted(nb[i]) if i<j and j in free]
    counts['pairs']+=len(pairs)
    for a,b in pairs:
        rows=[trace['contacts'][k] for k in sorted(incident[a]|incident[b])]
        for bits in product((0,1),repeat=4):
            counts['assignments']+=1
            state={a:bits[:2],b:bits[2:]}
            score=Counter();ok=True
            for c in rows:
                i,j=c['i'],c['j'];oi=x[i];oj=x[j]
                ui,vi=state.get(i,(oi,0));uj,vj=state.get(j,(oj,0))
                qi=ranks[i]-oi;qj=ranks[j]-oj
                le=ui<=uj and vi<=vj;ge=ui>=uj and vi>=vj
                if (qi<qj and not le) or (qi>qj and not ge) or (qi==qj and not (le or ge)):
                    ok=False;break
                new=abs((qi+ui+vi)-(qj+uj+vj))
                sign=1 if c['kind']=='helper' else -1
                score[new]+=sign;score[c['old_grade']]-=sign
            if not ok:continue
            counts['nested']+=1
            score={g:n for g,n in score.items() if n}
            if not score:
                counts['exact_ties']+=1;continue
            ups=[sum(v*(hi[g] if v>0 else lo[g]) for g,v in score.items()) for lo,hi in weights]
            if all(z<0 for z in ups):counts['strictly_negative_both']+=1
            else:fail.append((ax,a,b,bits,score,ups))
check(not fail,'no nonzero unpriced or nonnegative signed placement')
expected={'pairs':2198,'assignments':35168,'nested':16630,'exact_ties':16534,'strictly_negative_both':96}
check(dict(counts)==expected,'independent finite census')
out={'distinct_old_containment_patterns':len(seen),'raw_paid_incidences':2874,'raw_helper_incidences':458,
     'counts':dict(counts),'all_nonzero_cases_strictly_negative_at_both_rates':True,
     'maximum_signed_gain_upper_both_rates':0}
check(json.loads(json.dumps(out))==json.loads(Path(__file__).with_name('VERIFY-RAW.json').read_bytes()),
      'raw incidence scan matches frozen receipt')
print('PASS_INDEPENDENT_RAW_INCIDENCE_CENSUS',json.dumps(out,sort_keys=True))
