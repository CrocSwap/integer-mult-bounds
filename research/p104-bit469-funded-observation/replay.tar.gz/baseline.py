#!/usr/bin/env python3
"""Pinned complete original operator, paired caller, bridge and invoice baseline."""
import json,os,sys
from collections import Counter
from pathlib import Path
if hasattr(os,'sched_getaffinity'):
 a=os.sched_getaffinity(0)
 if a:os.sched_setaffinity(0,{min(a)})
h=Path(__file__).resolve().parent
sys.path.insert(0,str(h/'vendor'))
import binary_operator as op
word=op.load_json(h/'inputs'/'WORD.json.gz',op.WORD_GZIP,True)
caller=op.load_json(h/'inputs'/'EFREE-CALLER.json.gz',op.CALLER,True)
r=op.load_json(h/'inputs'/'BIT.json','8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d')
assert op.canonical_hash(word)==op.WORD
assert op.canonical_hash({k:word[k] for k in ('frames','start','final')})==op.LAYOUT
atlas=op.Atlas(word['frames']);assert atlas.main_contacts(word['start'],word['final'])==111
assert [atlas.grade(a,b) for a,b in [(251,524),(524,447),(251,447),(447,601),(601,1),(447,1),(319,447),(524,447)]]==[2,2,4,1,1,2,2,2]
forward,reverse,omission=op.native_checks(word,atlas)
np,nt,paid,targets=op.binary_invoice(word,caller,atlas,forward)
for actual,name in ((np,'native_paid'),(nt,'native_targets'),(paid,'paid'),(targets,'targets')):
 assert actual==Counter({int(k):v for k,v in r['native'][name].items()})
ordinary=op.ordinary_boundary(word,caller,paid,targets)
print(json.dumps({'status':'BASELINE_ONLY','native_public_coefficients_each_direction':680**2,'caller_polynomial_coefficients_each_direction':38**2,'main_contacts':111,'main_ports':222,'protected_411_omission_clock':omission,'native_dirty_retirements_each_direction':[forward.dirty,reverse.dirty], 'native_calls':36,'full_paid_jobs':sum(paid.values()),'full_productive_jobs':sum(targets.values()),'ordinary':ordinary,'legal_grades':{'251_to_524':2,'524_to_447':2,'251_to_447_old':4,'447_to_601':1,'601_to_1':1,'447_to_1_old':2,'319_to_447_old':2,'524_to_447_replacement':2}},indent=2,sort_keys=True))
