#!/usr/bin/env python3
from collections import Counter
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
import json, os, sys
if hasattr(os,'sched_getaffinity'):
 a=os.sched_getaffinity(0)
 if a: os.sched_setaffinity(0,{min(a)})
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'vendor'))
import price
j=(p/'inputs'/'BIT.json').read_bytes()
assert sha256(j).hexdigest()=='8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'
s=json.loads(j); assert s['native_calls']==36
T=Counter({int(k):v for k,v in s['native']['targets'].items()});P=Counter({int(k):v for k,v in s['native']['paid'].items()})
assert sum(T.values())==20706 and sum(P.values())==107460
Tnew=T.copy();Pnew=P.copy()
Tnew.update({1:36,3:36,4:36,8:-36});Pnew.update({1:72,2:36,4:-36})
assert all(v>=0 for v in Tnew.values()) and all(v>=0 for v in Pnew.values())
assert sum(k*v for k,v in Tnew.items())==sum(k*v for k,v in T.items())
assert sum(k*v for k,v in Pnew.items())==sum(k*v for k,v in P.items())
out={}
for k in ('0.003879928046156','0.003879929046155'):
 t=F(k)
 m=lambda a,b:price.sub(price.moment(a,t),price.moment(b,t))
 base=m(T,P); split=m(Tnew,Pnew); gain=price.sub(split,base)
 once=price.sub(split,price.point(1)); each=price.sub(split,price.point(36)); grade3=price.sub(split,price.scale(price.price(3,t),36))
 out[k]={x:price.decimal_interval(y,36) for x,y in dict(baseline=base,split_before_observation=split,split_gain=gain,extra_grade1_once_in_entire_caller=once,extra_grade1_per_native=each,extra_grade3_per_native=grade3).items()}
 assert once[1]<0 and each[1]<0 and grade3[1]<0
print(json.dumps(out,indent=2,sort_keys=True))
