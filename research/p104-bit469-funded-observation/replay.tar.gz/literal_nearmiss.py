#!/usr/bin/env python3
"""Replay the explicit paid-ingress reroute as a diagnostic, not a supplier."""
import gzip,hashlib,importlib.util,json,os,sys
from pathlib import Path
if hasattr(os,'sched_getaffinity'):
 a=os.sched_getaffinity(0)
 if a:os.sched_setaffinity(0,{min(a)})
h=Path(__file__).resolve().parent/'inputs';raw=(h/'WORD.json.gz').read_bytes();assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9';w=json.loads(gzip.decompress(raw));N=w['public'];assert N==680
spec=importlib.util.spec_from_file_location('edge',h/'bit_native.py');e=importlib.util.module_from_spec(spec);sys.modules[spec.name]=e;spec.loader.exec_module(e)
I,T,m,rows,clocks=e.extract(w);order=e.schedule(I,T,m,rows);v={i:1<<i for i in I}
for k in order:v[k]=e.combine(rows[k],v)
assert w['program'][4294]==['MOVE',1862,251,447] and w['program'][9627]==['MOVE',2753,447,1]
assert w['program'][6646]==['INIT',2239,319] and w['program'][6652]==['MOVE',2239,319,447]
assert w['program'][6647:6652]==[['ADD',2239,1441,319],['ADD',2239,1581,319],['ADD',2239,1769,319],['ADD',2239,1817,319],['ADD',2239,1889,319]]
# New independent z input is public 680, initially/finally on chart 524. It
# serves only to test the local cut, not as an achieved productive target.
# Shift all old private registers by one; append one private saved-copy field.
Z=680;copy=N+w['owned_fields']+1;total=copy+1;program=[]
def id(x):return x+1 if x>=N else x
def convert(op):
 name,r,*a=op;r=id(r)
 if name in ('ADD','SWAP'):a[0]=id(a[0])
 return [name,r,*a]
for t,op in enumerate(w['program']):
 r=id(op[1])
 if t==4294:
  program += [['MOVE',r,251,524],['INIT',copy,524],['ADD',copy,r,524],['ADD',r,Z,524],['MOVE',r,524,447]]
 elif 6646<=t<=6651:
  continue
 elif t==6652:
  program += [['INIT',r,524],['ADD',r,copy,524],['MOVE',r,524,447],['CLEAR',copy,524]]
 elif t==9627:program += [['MOVE',r,447,601],['MOVE',r,601,1]]
 else:program.append(convert(op))
assert len(program)==len(w["program"])+2
# Exact literal forward and adjoint. CLEAR/INIT are retirement/opening and
# transpose under reversal as in source; both directions must agree entrywise.
def literal(reverse):
 b=[1<<i for i in range(N+1)]+[0]*(total-(N+1)); tags=list(w['final' if reverse else 'start'])+[524]+[None]*(total-(N+1));dirty=0;retire=0;reader=None;first_reader=None
 seq=reversed(program) if reverse else program
 for ix,(op,r,*a) in enumerate(seq):
  if op in ('INIT','CLEAR'):
   opens=(op=='CLEAR') if reverse else (op=='INIT')
   if opens:assert tags[r] is None;tags[r]=a[0];b[r]=0
   else:assert tags[r]==a[0];dirty+=bool(b[r]);retire+=1;tags[r]=None;b[r]=0
  elif op=='ADD':
   s,c=a;assert tags[r]==tags[s]==c and r!=s
   if reverse:b[s]^=b[r]
   else:b[r]^=b[s]
  elif op=='SWAP':
   s=a[0];assert tags[r] is not None and tags[s] is not None;b[r],b[s]=b[s],b[r];tags[r],tags[s]=tags[s],tags[r]
  elif op=='MOVE':
   c,d=a[::-1] if reverse else a;assert tags[r]==c;tags[r]=d
   if not reverse and r==id(1862) and (c,d)==(251,524):
    assert tags[id(1854)]==524;first_reader=b[id(1854)]^b[id(1862)]
   if not reverse and r==id(2753) and (c,d)==(447,601):
    assert tags[id(2752)]==601;reader=b[id(2753)]^b[id(2752)]
  else:raise ValueError(op)
 assert tags==list(w['start' if reverse else 'final'])+[524]+[None]*(total-(N+1))
 assert not any(b[N+1:])
 return b[:N+1],dirty,retire,reader,first_reader
f,fd,fr,reader,first_reader=literal(False);a,ad,ar,_,_=literal(True)
assert reader==1<<Z and first_reader==((1<<468)|(1<<469))
for j in range(N+1):
 transpose=sum(((f[i]>>j)&1)<<i for i in range(N+1))
 assert a[j]==transpose
expected=[((1<<r)^((1<<(r-111)) if 111<=r<222 else 0)) for r in I]+[1<<Z]
bad=[i for i,(x,y) in enumerate(zip(f,expected)) if x!=y]
delta=v[2239]^v[1862]
assert f[150]^expected[150]==delta
assert f[513]^expected[513]==delta and f[577]==expected[577]
assert f[Z]==1<<Z
pulse=(1<<150)|(1<<459)
assert (f[150]&pulse).bit_count()%2==0 and (expected[150]&pulse).bit_count()%2==1
print(json.dumps({'status':'REJECTED_DIAGNOSTIC_NOT_AN_ACHIEVED_SUPPLIER','old_public':N,'additional_test_input':Z,'first_reader_original_1854_xor_1862':'x468 XOR x469','second_reader_2752_xor_2753':'z','literal_forward_and_adjoint_transpose_all_coefficients':(N+1)**2,'mismatched_original_output_count':len([i for i in bad if i<N]),'mismatched_original_outputs':[i for i in bad if i<N], 'output150_difference_old_input_support':list(e.indices(delta)),'output513_equals_same_difference':True,'output577_unchanged':True,'same_local_worlds_old_input_pulse':[150,459],'forward_dirty_retirements':fd,'adjoint_dirty_retirements':ad,'retirement_count_each':[fr,ar],'cost_scope':'unchanged grade for rerouted 2239; two separately paid subdivisions; this diagnostic does not implement the three target boundaries or a complete valid supplier'},indent=2))
