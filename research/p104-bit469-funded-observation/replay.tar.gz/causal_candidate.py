#!/usr/bin/env python3
"""One same-grade reroute to send a useful extra observation; local repair tests."""
import gzip,importlib.util,json,os,sys
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
if hasattr(os,'sched_getaffinity'):
 a=os.sched_getaffinity(0)
 if a:os.sched_setaffinity(0,{min(a)})
h=Path(__file__).resolve().parent/'inputs';w=json.loads(gzip.decompress((h/'WORD.json.gz').read_bytes()));spec=importlib.util.spec_from_file_location('edge',h/'bit_native.py');edge=importlib.util.module_from_spec(spec);sys.modules[spec.name]=edge;spec.loader.exec_module(edge)
I,T,moves,rows,clocks=edge.extract(w);order=edge.schedule(I,T,moves,rows);v={i:1<<i for i in I}
for k in order:v[k]=edge.combine(rows[k],v)
col={k:0 for k in I.keys()|moves.keys()}
for r in I:
 for j in edge.indices(rows[~r]):col[j]^=1<<r
for k in reversed(order):
 for j in edge.indices(rows[k]):col[j]^=col[k]

def inside(c,d):
 x,y=w['frames'][str(c)],w['frames'][str(d)]
 return x['dim']<y['dim'] and all(sum(Fraction(i)*Fraction(j) for i,j in zip(u,z))==0 for u in x['B'] for z in y['A'])
def solve(items,target):
 b={}
 for i,(r,x) in enumerate(items):
  mask=1<<i
  while x:
   p=x.bit_length()-1
   if p not in b:b[p]=(x,mask);break
   y,m=b[p];x^=y;mask^=m
 x=target;mask=0
 while x:
  p=x.bit_length()-1
  if p not in b:return None,len(b)
  y,m=b[p];x^=y;mask^=m
 return [items[i][0] for i in range(len(items)) if mask>>i&1],len(b)
assert moves[2239]==(319,447) and moves[2751]==(447,564)
assert inside(524,447) and w['frames']['524']['dim']==w['frames']['319']['dim']==4
assert w['frames']['447']['dim']==6 and w['frames']['564']['dim']==7
R1862=v[1862];L=v[2085]^v[2239];z=1<<680
c1=sorted([k for k,(a,_) in moves.items() if a==524 and clocks[k]>4294]+[1862],key=clocks.get)
E=[col[k] for k in c1]+[1<<658,1<<659]+[col[k] for k in [3163,3164,3291]]+[1<<187,col[2753]]
assert all(((x>>513)^(x>>577))&1==0 for x in E)
assert ((col[2751]>>513)^(col[2751]>>577))&1==1
charts=[int(c) for c,f in w['frames'].items() if f['dim']==6 and inside(int(c),564)]
banks=[1<<j for j in range(680)]+[0]*w['owned_fields'];tags=list(w['start'])+[None]*w['owned_fields'];snap={};atsecond=None
for t,(op,r,*a) in enumerate(w['program']):
 if t in (9619,10730,23548,31619):
  stocks=defaultdict(list)
  for j,c in enumerate(tags):
   if c in charts or c==564:stocks[c].append((j,banks[j]))
  data={}
  for c in charts+[564]:
   wit,rank=solve(stocks[c],L)
   data[str(c)]={'live':len(stocks[c]),'rank':rank,'contains_original_2751':wit is not None,'witness':wit}
  snap[str(t)]=data
 if t==9627:
  assert banks[2752]^banks[2753]==z
  atsecond={'packet_2752_xor_2753_is_new_signal':True,'packet_2752_old_row_equals_original_2085':banks[2752]^z==v[2085], 'packet_2753_unchanged':banks[2753]==v[2085]}
 if t>31619:break
 if op=='INIT':assert tags[r] is None;tags[r]=a[0];banks[r]=0
 elif op=='CLEAR':assert tags[r]==a[0];tags[r]=None;banks[r]=0
 elif op=='ADD':s,c=a;assert tags[r]==tags[s]==c;banks[r]^=banks[s]
 elif op=='SWAP':s=a[0];banks[r],banks[s]=banks[s],banks[r];tags[r],tags[s]=tags[s],tags[r]
 elif op=='MOVE':
  c,d=a;assert tags[r]==c;tags[r]=d
  if t==4294:banks[r]^=z
  if t==6652:banks[r]=R1862
 else:raise ValueError(op)
print(json.dumps({'candidate':'reroute existing 2239, 319->447 to 524->447, payload pristine pre-injection 1862; use 2752 XOR delayed split 2753','same_grade':2,'causal_reader':atsecond,'required_original_2751':list(edge.indices(L)),'spectator_separator':{'outputs':[513,577],'annihilates_17plus5_controls':True,'dot_original_2751_impulse':1,'forced':'retain old 2751 row when only stated egresses may otherwise change'},'snapshots':snap,'original_3061_first_use':31619,'scope':'Stocks are exact original rows except 1862 gets z and 2239 is replaced by original 1862; 564 decoding is allowed to access all actual live fields. No local chart modifications upstream of these captures or external routes beyond the specified reroute.'},indent=2))
