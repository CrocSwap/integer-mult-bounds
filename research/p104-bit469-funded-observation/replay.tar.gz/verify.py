#!/usr/bin/env python3
"""Read-only serial replay with file and output integrity."""
from hashlib import sha256
from pathlib import Path
import json,os,subprocess,sys
h=Path(__file__).resolve().parent
def manifest():
 for line in (h/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);p=(h/name).resolve()
  assert p.is_relative_to(h) and p.is_file()
  assert sha256(p.read_bytes()).hexdigest()==digest, f'hash: {name}'
manifest()
if hasattr(os,'sched_getaffinity'):
 a=os.sched_getaffinity(0)
 if a:os.sched_setaffinity(0,{min(a)})
env=os.environ.copy();env['PYTHONNOUSERSITE']='1';env.pop('PYTHONPATH',None)
for script,receipt in [('baseline.py','BASELINE.json'),('debit.py','DEBIT.json'),('causal_candidate.py','CAUSAL-CANDIDATE.json'),('maximal_envelope.py','MAXIMAL-ENVELOPE.json'),('literal_nearmiss.py','LITERAL-NEARMISS.json')]:
 p=subprocess.run([sys.executable,'-IB',str(h/script)],cwd=h,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 assert p.returncode==0, f'{script}: {p.stderr}'
 assert json.loads(p.stdout)==json.loads((h/receipt).read_text()), f'receipt {receipt}'
 print('PASS',script)
manifest()
print('PASS_BYTE_PINS_AND_469_PAID_INGRESS_SCOPED_REJECTION')
