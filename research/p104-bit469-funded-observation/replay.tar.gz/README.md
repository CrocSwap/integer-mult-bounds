# BIT 469: a funded observation and the displaced spectator

**Result: scoped negative.** An existing grade-two paid packet can be rerouted so that the new signal is observable at chart 601 by the second split reader. This removes the free-observation assumption in the #7891 control, but the reroute loses data required by spectator output 150. A two-world witness shows that no local decoder at the tested fixed chart-564 exterior can repair that loss, even when supplied with all chart-524 stocks for free. This is not a valid supplier, improved bound, or a global impossibility result.

The source is the #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; the fixed-interface boundary result is #7891 head `1f99c05f16f08a2acdc882d0864b36ac62bed52d`. The earlier seven-stock rank argument applies to its own fixed interface. Here an old paid route and its payload are changed.

## A causal observation without an extra paid MOVE

At original clock 4294, subdivide `1862: 251→447` through chart 524. Its original value is `A = x105 ⊕ x469`. Before injecting the proposed independent chart-524 input `z`, retain `A` in a local private field on 524. Continue packet 1862 to chart 447 with value `A ⊕ z`. The first local reader is `1854 ⊕ A = x468 ⊕ x469`.

At clock 6652 replace packet `2239: 319→447`, originally grade 2, with `524→447`, also grade 2, carrying the retained `A`. Let `B` and `C` denote original packets 2085 and 2239. At chart 447 the three stocks are now `A⊕z`, `B`, `A`. Original packet 2752 at clock 9624 carries their XOR, `B⊕z`. Subdivide packet 2753 at clock 9627 through 601; it carries `B`. Hence the two actual arrivals at 601 XOR to `z`. The rational atlas verifies each stated containment and grade, including both split paths. This is an observation construction; it is not a complete implementation of the three required target boundaries.

## Exact two-world obstruction for this route family

The replacement removes original `C` from chart 447. Packet 2751, which travels from 447 to 564 at clock 9619, originally carries `B⊕C`; after the illustrated reroute it carries `B⊕A`. Chart 564 has no public inputs and receives only packets 2748, 2751, 2754, and 3454. Its original output 150 is `x39⊕x150`.

Compare two old-input assignments differing only in spectators `{150,459}` and hold `z` fixed. Every one of the 16 actual chart-524 stocks at clock 6652, retained `A`, original 2085, and each of the other three chart-564 arrivals 2748, 2754, and 3454 has the same value in both assignments. Original `C` differs, while the required output 150 differs. The two worlds also have the same three owner inputs 255, 468, 469, so the first read `q=x468⊕x469` is unchanged. Granting all of these source values to 564 for free does not help: no local deterministic decoder can distinguish the worlds.

The 22-row GF(2) envelope has rank 22 and does not span the old 2751 row or required output 150. The verifier also tests the positive control of supplying the missing original 2239 row, which breaks the indistinguishability and makes output 150 representable. Thus the obstruction covers **any** replacement payload computed from the stated available 524 stocks, with the other listed original arrival histories fixed, not merely the specific `A` payload. It does not exclude a repair that changes those exterior histories, changes other paid interfaces or recipient routes, or uses additional observations. The boundary certificate's 17+5 first/second egress controls also cannot alone repair 2751: outputs 513 and 577 have identical response to all those controls, while the 2751 impulse reaches 513 and not 577.

The literal diagnostic uses one additional independent public test input, retains the clean copy in one additional private field, and actually performs the reroute and both paid subdivisions. Forward and transposed reverse execution agree on all 681² coefficients; the second read is exactly `z`. The resulting old operator nevertheless has 14 wrong output rows, including main ports 28, 37 and 150, and spectator 513. The new input is a test input, not an implemented three-target boundary. The private copy is explicitly retired; both directions have 3,555 dirty retirements. See [LITERAL-NEARMISS.json](LITERAL-NEARMISS.json). No valid modified word, candidate invoice, or ordinary-cost qualification is claimed.

## Separate extra-MOVE price gate

Granting the entire desired 0→524→601→1 helper split and both original MOVE subdivisions, with every other paid and productive incidence fixed, yields these directed complete 36-call signed margins:

| κ | Ideal split, before repair | Plus one grade-one MOVE once in the entire caller |
| --- | ---: | ---: |
| `0.003879928046156` | `+0.50334585369894364696` | `−0.49665414630105635304` |
| `0.003879929046155` | `+0.50296085573203495409` | `−0.49703914426796504591` |

The upper bounds remain negative even when one grade-one observation is charged only once, rather than once per native call. This arithmetic ceiling says nothing about an edit that also changes other paid or productive incidences. The funded 2239 reroute has no extra observation MOVE and is addressed by the separate two-world obstruction above. [Directed intervals](DEBIT.json)

## Reproduce

Run `python3 -IB verify.py`. It binds the process and children to one allowed CPU where supported; checks every input and receipt hash; replays the original operator, all 680² coefficients in each direction, all paired-caller polynomial coefficients, the 111 main contacts, owner-411 bridge and omission control, original dirty retirements, complete paid/productive bins and ordinary account; then executes the directed debit, actual-stock chronology, 22-row envelope and literal diagnostic. It checks the manifest again afterward. The original ordinary account and protected bridge are **baseline** checks, not qualifications of the rejected diagnostic. No network or external packages are needed.

The source word and pricing lineage retain the authors and credits in [NOTICE-PAIR](NOTICE-PAIR) and [pr7891/NOTICE](pr7891/NOTICE). This diagnostic and its proof use Codex assistance. No independent candidate replay or human review is asserted.
