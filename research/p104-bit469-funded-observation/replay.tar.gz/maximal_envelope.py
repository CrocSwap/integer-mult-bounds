#!/usr/bin/env python3
import gzip,importlib.util,json,os,sys
from pathlib import Path
from hashlib import sha256
if hasattr(os,'sched_getaffinity'):
 a=os.sched_getaffinity(0)
 if a:os.sched_setaffinity(0,{min(a)})
h=Path(__file__).resolve().parent/'inputs';raw=(h/'WORD.json.gz').read_bytes();assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9';w=json.loads(gzip.decompress(raw));spec=importlib.util.spec_from_file_location('edge',h/'bit_native.py');e=importlib.util.module_from_spec(spec);sys.modules[spec.name]=e;spec.loader.exec_module(e)
I,T,m,r,c=e.extract(w);o=e.schedule(I,T,m,r);v={i:1<<i for i in I}
for k in o:v[k]=e.combine(r[k],v)
assert T[150]==564 and not [j for j,c0 in I.items() if c0==564]
assert [k for k,(a,d) in m.items() if d==564]==[2748,2751,2754,3454]
assert not [k for k,(a,d) in m.items() if d==524 and c[k]>6652]
pulse={j:0 for j in I}
for k in o:pulse[k]=e.combine(r[k],pulse)^(k==2239)
assert [pulse[k] for k in (2748,2751,2752,2753,2754,3454)]==[0,1,1,0,0,0]
# All live chart-524 stocks at the dispatch of 2239, with free pristine
# split copy and z; granting all those rows at chart564 is optimistic.
b=[1<<i for i in range(680)]+[0]*w['owned_fields'];tag=list(w['start'])+[None]*w['owned_fields'];z=1<<680
for t,(op,k,*a) in enumerate(w['program']):
 if t==6652:break
 if op=='INIT':tag[k]=a[0];b[k]=0
 elif op=='CLEAR':tag[k]=None;b[k]=0
 elif op=='ADD':b[k]^=b[a[0]]
 elif op=='SWAP':j=a[0];b[k],b[j]=b[j],b[k];tag[k],tag[j]=tag[j],tag[k]
 elif op=='MOVE':tag[k]=a[1]
 else:raise ValueError(op)
stocks=[(j,b[j]) for j,x in enumerate(tag) if x==524]
stocks += [('pristine_1862',v[1862]),('z',z),('stock_2085',v[2085]),('old_2748',v[2748]),('old_2754',v[2754]),('old_3454',v[3454])]
# Source-rank kernel elimination also emits an independently replayable
# distinguishing old input (dual functional); solve target in row span.
def solve(items,target):
 basis={}
 for i,(j,x) in enumerate(items):
  mask=1<<i
  while x:
   p=x.bit_length()-1
   if p not in basis:basis[p]=(x,mask);break
   y,q=basis[p];x^=y;mask^=q
 x=target;mask=0
 while x:
  p=x.bit_length()-1
  if p not in basis:return None,len(basis),x
  y,q=basis[p];x^=y;mask^=q
 return [items[i][0] for i in range(len(items)) if mask>>i&1],len(basis),0
oldout=e.combine(r[~150],v)
assert oldout==(1<<39)^(1<<150)
def dual_witness(rows,target):
 basis={}
 for x,rhs in [(x,0) for x in rows]+[(target,1)]:
  while x:
   p=x.bit_length()-1
   if p not in basis:basis[p]=(x,rhs);break
   y,b=basis[p];x^=y;rhs^=b
  else:assert rhs==0
 solution=0
 for p,(x,rhs) in sorted(basis.items()):
  if rhs^((x&solution).bit_count()&1):solution|=1<<p
 assert all((x&solution).bit_count()%2==0 for x in rows)
 assert (target&solution).bit_count()%2==1
 return solution
res={}
for name,target in [('old_2751',v[2751]),('original_output150',oldout),('old_2239',v[2239])]:
 witness,rank,rem=solve(stocks,target)
 res[name]={'rank':rank,'available':witness is not None,'witness':witness,'remainder_bit_count':rem.bit_count()}
assert not res['original_output150']['available']
sep=dual_witness([x for _,x in stocks],oldout)
assert list(e.indices(sep))==[150,459]
assert not (sep&((1<<255)|(1<<468)|(1<<469)))
assert (v[2239]&sep).bit_count()%2==1
assert solve(stocks+[('old_2239',v[2239])],oldout)[0] is not None
print(json.dumps({'donor_count':len(stocks),'donor_labels':[j for j,_ in stocks], 'envelope_claims':res,'old_input_pulse_distinguishing_output150':list(e.indices(sep)), 'target_output150_support':list(e.indices(oldout)), 'witness_annihilates_all_donors':True,'witness_toggles_target':True,'missing_old_2239_breaks_indistinguishability':True},indent=2))
