#!/usr/bin/env python3
"""Repeat the finite screen from isolated copies and compare saved receipts."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
cold = root / 'cold'
if cold.exists():
    shutil.rmtree(cold)
cold.mkdir()
shutil.copytree(root / 'source', cold / 'source')
shutil.copytree(root / 'independent' / 'inputs', cold / 'independent' / 'inputs')
for p in ('replay_bit.py', 'replay_caller.py', 'replay_rational.py'):
    shutil.copy2(root / 'independent' / p, cold / 'independent' / p)
shutil.copy2(root / 'screen.py', cold / 'screen.py')

records = []
def run(cwd, args, target=None, expected=None):
    start = time.monotonic()
    p = subprocess.run(args, cwd=cold / cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    out = p.stdout
    if target:
        (cold / target).write_bytes(out)
    if expected:
        assert out == (root / expected).read_bytes(), expected
    records.append({'command': args, 'cwd': cwd, 'seconds':round(time.monotonic()-start, 3),
                    'stdout_sha256':sha256(out).hexdigest(), 'byte_identical_to':expected,
                    'stderr':p.stderr.decode()})

run('source', ['sha256sum', '-c', 'SHA256SUMS'], 'source-manifest.log')
run('source', [sys.executable, '-I', '-B', 'verify.py'], 'source-verify.log')
run('independent', [sys.executable, '-I', '-B', 'replay_caller.py'],
    'independent/CALLER-REPLAY.json', 'independent/CALLER-REPLAY.json')
run('independent', [sys.executable, '-I', '-B', 'replay_rational.py'],
    'independent/RATIONAL-REPLAY.json', 'independent/RATIONAL-REPLAY.json')
run('.', [sys.executable, '-I', '-B', 'screen.py'], 'RESULT.json', 'RESULT.json')
receipt={'status':'PASS', 'completed_utc':datetime.now(timezone.utc).isoformat(),
         'steps':records, 'cold_copy':'cold/'}
(root/'COLD-REPLAY.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
