# A 324-event paired binary caller with four QUERYs

A direct characteristic-two construction shortens the paired P104 BIT caller from 798 to **324 macro events**. It reproduces every labelled output of the original caller in both orientations. The established pre-tensor accounting saves **1,067,376 ordinary records** and lowers the owned-backing bound by **3,998,664 units**. The complete paid and productive histograms each agree exactly with the original. The signed gain is zero for every κ. [Pinned construction](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) · [Prior finite result](https://github.com/CrocSwap/integer-mult-bounds/pull/7863)

| Quantity | Original | Changed |
| --- | ---: | ---: |
| ADD | 362 | 252 |
| SWAP | 364 | 0 |
| LOCAL, IDLE_ONE, QUERY | 36, 32, 4 | 36, 32, 4 |
| Ordinary records | 934,182,831,504 | 934,181,764,128 |
| Owned backing bound | 6,998,544 | 2,999,880 |
| Paid positions | 107,460 | 107,460 |
| Productive positions | 20,706 | 20,706 |

`CALLER.json.gz` is the complete executable macro tape. Its canonical SHA-256 is `9de443fa08e766e5b054c6100398ffe11341a8c27dec5c5303573ec6d467cd8b`. The checked construction uses the 680-owner native word at canonical digest `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`. The `CALLER-RESULT.json` receipt lists every old and changed bin, the 48-call rational companion and exact directed bounds. At `0.003879928046156`, the 36-call BIT margin is about `−7.67001502431130e−10` and the companion margin is `+0.212262470163347`. At `0.003879929046155` they are `−0.000385127316613866` and `+0.211243929926514`.

The four QUERYs also attain a lower bound for the stated two-hub, 18-arm-pair grammar. Up to 210 independent rank-two square-zero maps are granted at **each** stage. Dropping selected root-head factors and adding a head to selected funded idles are included. The proof gives a rank-four minor for every variant that could improve the original signed tariff. Different host incidences, idle body masks or other physical actions require their own calculation. [Derivation](PROOF.md)

Run the following commands in the extracted directory with CPython 3.12 and its standard library.

```sh
sha256sum -c SHA256SUMS
python3 -IB verify.py
```

The verifier reconstructs and checks the original and changed caller. It replays `38²` caller coefficients and `680²` native coefficients in each orientation, including all terminal labels. It evaluates the separate complete supplier bills, reproduces both accounting certificates and rejects four event deletions. The unchanged native word retains 3,554 dirty private retirements in each direction. This finite macro-level rewrite changes intermediate states, macro clock labels and the ordinary bank bound. A finite compiler for the literal word would have to bind those new labels. The parent construction's native-all-columns, physical owned-erasure, compiler, precision-tape and analytic-recovery assumptions continue to matter. The reduced resource bound gives no stronger complete conditional exponent. [Source pins and authorship](SOURCES.json) · [Notice](NOTICE)
