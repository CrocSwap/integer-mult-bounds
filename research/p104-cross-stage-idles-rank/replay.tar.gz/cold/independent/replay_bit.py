#!/usr/bin/env python3
"""Independent literal #7830/#7912 owner and complete-caller control.

The CLEAR operation is the literal source's discard semantics; a successful
symbolic replay does not prove a physical erasure implementation.
"""
import copy,gzip,json,hashlib
from collections import Counter
from decimal import Context,Decimal,ROUND_FLOOR,ROUND_CEILING,ROUND_HALF_EVEN
from fractions import Fraction
from functools import lru_cache
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PINS={'WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'ZERO-CONTROL-WORD.json.gz':'f0aa75a63cc9200f627721851bd68c27367ae80e7fca2f0fe6f515fe2bfc9f63',
 'EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'TABLES.json.gz':'5358980ce183a7017084af9532077cbc60594d1f2a0cb386c959d1cdf689da69',
 'BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'}
def need(x,m):
 if not x: raise ValueError(m)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canon(v):return sha(json.dumps(v,sort_keys=True,separators=(',',':')).encode())
def load(n):
 raw=(ROOT/'inputs'/n).read_bytes();need(sha(raw)==PINS[n],'bad input '+n)
 return json.loads(gzip.decompress(raw) if n.endswith('.gz') else raw)

def determinant(matrix):
 a=[row[:] for row in matrix];sign=1;previous=1
 for j in range(len(a)-1):
  p=next((i for i in range(j,len(a)) if a[i][j]),None)
  if p is None:return 0
  if p!=j:a[p],a[j]=a[j],a[p];sign=-sign
  pivot=a[j][j]
  for i in range(j+1,len(a)):
   for k in range(j+1,len(a)):
    x=a[i][k]*pivot-a[i][j]*a[j][k];q,r=divmod(x,previous);need(r==0,'nonintegral determinant');a[i][k]=q
   a[i][j]=0
  previous=pivot
 return sign*a[-1][-1]

def frames(w):
 f={int(k):v for k,v in w['frames'].items()}
 for k,v in f.items():
  b,a=v['B'],v['A'];need(v['dim']==len(b) and len(a)+len(b)==8 and all(len(x)==8 for x in a+b),'chart shape')
  need(all(sum(x*y for x,y in zip(row,col))==0 for row in b for col in a),'chart orthogonality')
  need(determinant(b+a)!=0,'chart basis')
 return f

def leg(f,a,b):
 x,y=sorted((a,b),key=lambda q:f[q]['dim']);lo,hi=f[x],f[y];rank=hi['dim']-lo['dim']
 need(rank>0 and all(sum(u*v for u,v in zip(r,s))==0 for r in lo['B'] for s in hi['A']),'strict nested leg')
 return rank

def tape(w,f,reverse=False,omit=None):
 n=w['public'];bank=[1<<j for j in range(n)]+[0]*w['owned_fields'];tags=list(w['final'] if reverse else w['start'])+[None]*w['owned_fields']
 expected=w['start'] if reverse else w['final']; paid=Counter();counts=Counter();dirty=0;live=0
 sequence=range(len(w['program'])-1,-1,-1) if reverse else range(len(w['program']))
 for t in sequence:
  if t==omit:continue
  op,a,*arg=w['program'][t];need(0<=a<len(bank),'address');counts[op]+=1
  if op in ('INIT','CLEAR'):
   need(a>=n and arg[0] in f,'private lifetime')
   opening=(op=='CLEAR') if reverse else (op=='INIT')
   if opening:need(tags[a] is None,'duplicate activation');tags[a]=arg[0];live+=1
   else:need(tags[a]==arg[0],'erasure chart');dirty+=bool(bank[a]);tags[a]=None;live-=1
   bank[a]=0
  elif op=='ADD':
   b,c=arg;need(a!=b and 0<=b<len(bank) and tags[a]==tags[b]==c and c in f,'add contact')
   if reverse:bank[b]^=bank[a]
   else:bank[a]^=bank[b]
  elif op=='SWAP':
   b,=arg;need(a!=b and 0<=b<len(bank) and tags[a] is not None and tags[b] is not None,'swap contact');bank[a],bank[b]=bank[b],bank[a];tags[a],tags[b]=tags[b],tags[a]
  elif op=='MOVE':
   need(a>=n,'public move');x,y=arg[::-1] if reverse else arg;need(tags[a]==x,'move chronology');paid[leg(f,x,y)]+=1;tags[a]=y
  else:raise ValueError('unknown native op')
 need(tags==list(expected)+[None]*w['owned_fields'] and live==0 and not any(bank[n:]),'terminal retirement')
 expected_rows=[(1<<i)^((1<<(i+111)) if reverse and i<111 else (1<<(i-111)) if not reverse and 111<=i<222 else 0) for i in range(n)]
 need(bank[:n]==expected_rows,'all arbitrary public coefficients')
 return dict(paid=paid,counts=counts,dirty_retirements=dirty,public_rows=n)

def invoice(w,f,c):
 p=Counter();t=Counter();calls=[];local=Counter(leg(f,*row[2:]) for row in w['program'] if row[0]=='MOVE')
 helper=Counter(leg(f,a,b) for a,b in zip(w['start'][222:],w['final'][222:]))
 need(len(w['start'])==len(w['final'])==w['public'],'boundary shape')
 for clock,event in enumerate(c['events']):
  op=event[0]
  if op=='LOCAL':p.update(local);t.update(helper);calls.append([clock,event])
  elif op=='QUERY':p[1]+=c['ports']
  elif op=='IDLE_ONE':p[7*len(event[2])]+=c['ports']
  else:need(op in ('ADD','SWAP'),'unknown caller op')
 for d in c['diagonal']:
  need(len(set(d['stages']))==len(d['stages']) and d['stages'],'target masks')
  t[d['q']+7*len(d['stages'])]+=c['ports']
 return p,t,calls,local,helper

def owners(old,new,caller,tables):
 owners=[i for i in range(old['public']) if i!=649];need(len(owners)==new['public'],'owner count')
 need([old['start'][i] for i in owners]==new['start'] and [old['final'][i] for i in owners]==new['final'],'owner endpoints')
 f=frames(new);helpers=[[i,orig,new['start'][i],new['final'][i],leg(f,new['start'][i],new['final'][i])] for i,orig in enumerate(owners) if i>=222]
 oldmoves=[(t,row[1],row[2],row[3]) for t,row in enumerate(old['program']) if row[0]=='MOVE']
 newmoves=[(t,row[1],row[2],row[3]) for t,row in enumerate(new['program']) if row[0]=='MOVE']
 byid={row[1]:row for row in oldmoves};need(3266 in byid and byid[3266][2:]==(506,1),'deleted original packet')
 kept=[row for row in oldmoves if row[1]!=3266];need(len(kept)==len(newmoves),'packet count')
 paid=[]
 for (ct,cb,ca,cz),(ot,ob,oa,oz) in zip(newmoves,kept,strict=True):
  need((ca,cz)==(oa,oz),'ordered physical chart route');paid.append([ct,cb,ob,ca,cz,leg(f,ca,cz)])
 expected=[dict(caller_clock=i,event=e,helper=helpers,paid_move=paid,word=canon(new)) for i,e in enumerate(caller['events']) if e[0]=='LOCAL']
 def bind(received):
  need(len(received)==len(expected),'call count')
  for rec,want in zip(received,expected,strict=True):
   need(rec['caller_clock']==want['caller_clock'] and rec['event']==want['event'],'caller namespace')
   need(rec['word']==want['word'],'word namespace')
   need(rec['helper']==want['helper'],'helper owner identity')
   need(rec['paid_move']==want['paid_move'],'paid owner and chronology')
 bind(tables)
 # A grade-only check cannot detect exchanging the original owner labels of two same-grade entries.
 bad=copy.deepcopy(tables[:1]);aa,bb=next((i,j) for i in range(len(helpers)) for j in range(i+1,len(helpers)) if helpers[i][-1]==helpers[j][-1] and helpers[i][1]!=helpers[j][1])
 bad[0]['helper'][aa][1],bad[0]['helper'][bb][1]=bad[0]['helper'][bb][1],bad[0]['helper'][aa][1]
 need(Counter(x[-1] for x in bad[0]['helper'])==Counter(x[-1] for x in tables[0]['helper']),'same-grade mutation changed grade invoice')
 # Bind the one-call record directly so the mutation failure is not merely call count.
 mutated=copy.deepcopy(tables);mutated[0]=bad[0]
 try:bind(mutated)
 except ValueError as e:need(str(e)=='helper owner identity','wrong corruption reason')
 else:raise ValueError('same-grade owner swap accepted')
 need(helpers[649-222]==[649,650,374,1,2] and [r for r in paid if r[2]==3267]==[[11347,3265,3267,506,1,4]],'specific relocated owners')
 return dict(equal_grade_swapped_indices=[aa,bb],owners=[helpers[aa][1],helpers[bb][1]],same_grade_swap_rejected=True,all_call_tables_reconstructed=len(expected),helper_649=helpers[649-222],old_removed_paid_packet=3266,moved_packet=next(r for r in paid if r[2]==3267))

N=Context(prec=90,rounding=ROUND_HALF_EVEN);L=Context(prec=90,rounding=ROUND_FLOOR);U=Context(prec=90,rounding=ROUND_CEILING);D=Decimal
def pow_interval(r,e):
 if r==1:return (D(1),D(1))
 x=N.ln(D(r));a=N.next_minus(x);b=N.next_plus(x)
 return (N.next_minus(N.exp(L.multiply(a,e))),N.next_plus(N.exp(U.multiply(b,e))))
def hist(h,e):
 lo=hi=D(0)
 for r,n in h.items():
  a,b=pow_interval(r,e);lo=L.add(lo,L.multiply(a,D(n)));hi=U.add(hi,U.multiply(b,D(n)))
 return lo,hi
def margin(t,p,k):
 a=hist(t,D(1)-D(k));b=hist(p,D(1)-D(k));return L.subtract(a[0],b[1]),U.subtract(a[1],b[0])
def div(a,b):return L.divide(a[0],b[1]),U.divide(a[1],b[0])
def mul(a,b):return L.multiply(a[0],b[0]),U.multiply(a[1],b[1])
def finite(p,t,b):
 src=b['separation'];trial=D('0.003879928046148');power=src['power'];base=hist(t,D(1)-trial)
 caps={name:Fraction(s) for name,s in src['upper_caps'].items()}
 bounds={'alpha':div(hist(p,D(1)-trial),base)}
 for label,cut,tilt,subset in [('grades_1_to_4',10,D('0.22'),Counter({r:n for r,n in p.items() if r<=4})),('grades_above_4',11,D('0.26'),Counter({r:n for r,n in p.items() if r>4}))]:
  denom=mul(pow_interval(cut,tilt),base)
  bounds[label+'_first']=div(hist(subset,D(1)-trial+tilt),denom)
  bounds[label+'_rest']=div(hist(p,D(1)-trial+tilt),denom)
 bounds['discarded_targets']=div(mul(pow_interval(16,D('0.34')),hist(t,D(1)-trial-D('0.34'))),base)
 need(all(Fraction(hi)<=caps[key]<1 for key,(_,hi) in bounds.items()),'directed moment cap')
 volume=1/(1+power*(1-caps['alpha']))+sum(2*caps[name+'_first']*caps[name+'_rest']**(power-1) for name in ('grades_1_to_4','grades_above_4'))+caps['discarded_targets']**power
 need(1-volume>Fraction('0.0000000000012309863319385'),'finite split-and-discard strict margin')
 u=b['uniform'];H=u['H'];need((H+1)**64<2**3213 and (H-400000000000+1)**64>=2**3212,'uniform grid')
 st=b['delayed_cover_and_stock'];prev=Fraction(st['seed']);covered=Fraction(st['covered']);rho=Fraction(st['rho'])
 for row in st['stages']:
  claim=Fraction(row['claim']);need(Fraction(row['previous'])==prev and claim<rho*prev+(1-rho)*covered,'ordinary strict stage');prev=claim
 need(prev==Fraction(st['admitted']) and Fraction(2**45)*Fraction(st['loss'])>256,'admission and cover surcharge')
 return dict(source='#7830 BIT.json, exact 480-factor fixed-incumbent certificate',trial=str(trial),power=power,finite_surplus_gt='0.0000000000012309863319385',actual_product_materialized=False,moment_bounds_checked=list(bounds),uniform_H=H,ordinary_stages=len(st['stages']),ordinary_cap=str(st['admitted']),premises=['native_all_columns','owned_erasure','compiler','precision_tape','analytic_recovery'])

def main():
 old,new,c,tables,source=[load(k) for k in ('WORD.json.gz','ZERO-CONTROL-WORD.json.gz','EFREE-CALLER.json.gz','TABLES.json.gz','BIT.json')]
 need(canon(old)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d' and canon(new)=='09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be','canonical pinned words')
 results={};invoices={}
 for name,w in [('old',old),('new',new)]:
  f=frames(w);forward=tape(w,f);reverse=tape(w,f,True);p,t,calls,np,nt=invoice(w,f,c)
  need(forward['paid']==reverse['paid']==np,'both direction paid')
  clear=next(i for i,e in enumerate(w['program']) if e[0]=='CLEAR')
  try:tape(w,f,omit=clear)
  except ValueError:pass
  else:raise ValueError('omitted clear accepted')
  results[name]=dict(public=w['public'],forward_dirty=forward['dirty_retirements'],adjoint_dirty=reverse['dirty_retirements'],omitted_clear_rejected=True,native_paid=dict(sorted(np.items())),native_helpers=dict(sorted(nt.items())),paid=dict(sorted(p.items())),productive=dict(sorted(t.items())),calls=len(calls),call_clocks=[x[0] for x in calls])
  invoices[name]=p,t
 oldp,oldt=invoices['old'];newp,newt=invoices['new'];dp=Counter(newp);dp.subtract(oldp);dt=Counter(newt);dt.subtract(oldt)
 need({k:v for k,v in dp.items() if v}=={4:-36} and {k:v for k,v in dt.items() if v}=={4:-36},'exact all-caller signed cancellation')
 need(oldp==Counter({int(k):v for k,v in source['native']['paid'].items()}) and oldt==Counter({int(k):v for k,v in source['native']['targets'].items()}),'complete source invoice')
 bind=owners(old,new,c,tables);rates={}
 for k in ['0.003879928046154','0.003879928046155','0.003879928046156','0.003879929046155','0.0038799280461560083000']:
  a=margin(oldt,oldp,k);b=margin(newt,newp,k);need(max(a[0],b[0])<=min(a[1],b[1]),'literal zero-price intervals overlap');rates[k]=[str(max(a[0],b[0])),str(min(a[1],b[1]))]
 need(D(rates['0.003879928046154'][0])>0 and D(rates['0.003879928046155'][1])<0,'directed crossing')
 out={'status':'PASS_LITERAL_INCUMBENT_AND_679_ZERO','source_heads':{'7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15','7863':'b3e4412fe01f07dc58305616fabf96345f49a781','7912':'83ece5a62d3addbee45bad9594ef4809851b833b'},'input_sha256':PINS,'native':results,'owner_binding':bind,'signed_delta_paid':{4:-36},'signed_delta_productive':{4:-36},'total_signed_delta_exact':0,'directed_bit_margins':rates,'incumbent_finite':finite(oldp,oldt,source),'scope':'Literal arbitrary GF(2) rows with discard CLEAR and complete caller invoice; moment and stage arithmetic. Does not prove physical owned erasure, candidate-specific compiler, cover, stock, precision or a new bound.'}
 print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__':main()
