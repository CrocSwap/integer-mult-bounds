#!/usr/bin/env python3
"""Cold replay of a pinned 4-QUERY, 36-native-call BIT caller.

Independent formal operators and exact caller accounting; no physical
all-width or owned-QUERY contract is proved by this finite check.
"""
import copy,gzip,json,hashlib,importlib.util
from collections import Counter
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base',HERE/'replay_bit.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
need=base.need
PIN='f38ad467dc02450f35a57d6e5868bc91e34d356576c926ea839f0a55894bef21'

def shift(row, stages=(), q=False):
 out={}
 for (parity,exps),mask in row.items():
  a=list(exps)
  for s in stages:a[s-1]+=1
  key=(parity^q,tuple(a));out[key]=out.get(key,0)^mask
 return {k:v for k,v in out.items() if v}
def add(a,b):
 out=a.copy()
 for k,v in b.items():
  out[k]=out.get(k,0)^v
  if not out[k]:del out[k]
 return out

def symbolic(w,adjoint=False):
 n=w['roles'];zero=(False,(0,)*w['stages']);rows=[{zero:1<<i} for i in range(n)]
 for e in (reversed(w['events']) if adjoint else w['events']):
  op=e[0]
  if op in ('ADD','QUERY'):
   a,b=e[1:]; a,b=(b,a) if adjoint else (a,b)
   rows[a]=add(rows[a],shift(rows[b],q=op=='QUERY'))
  elif op=='LOCAL':
   s,a,b=e[1:]; a,b=(b,a) if adjoint else (a,b)
   v=add(rows[b],shift(rows[a],q=True));rows[a]=shift(rows[a],[s]);rows[b]=shift(v,[s])
  elif op=='IDLE_ONE':
   a,ss=e[1:];rows[a]=shift(rows[a],ss)
  elif op=='SWAP':
   a,b=e[1:];rows[a],rows[b]=rows[b],rows[a]
  else:raise ValueError('invalid opcode')
 for i,d in enumerate(w['diagonal']):
  need(d['q'] in (0,1) and all(s in range(1,w['stages']+1) for s in d['stages']) and len(set(d['stages']))==len(d['stages']),'bad target')
  exp=tuple(int(s in d['stages']) for s in range(1,w['stages']+1));need(rows[i]=={(bool(d['q']),exp):1<<i},f'wrong row {i}')
 return n*n

def validate_structure(w):
 need((w['roles'],w['stages'],w['ports'],w['native_per_stage'],w['body_rank'],w['ambient_rank'])==(38,18,111,2,7,127),'physical axes and roles')
 stages=[];per={};ops=Counter();calls=[]
 for clock,e in enumerate(w['events']):
  op=e[0];ops[op]+=1
  if op in ('ADD','SWAP','QUERY'):
   a,b=e[1:];need(a!=b and all(type(k)==int and k in range(38) for k in (a,b)),'distinct caller owners')
  elif op=='LOCAL':
   s,a,b=e[1:];need(s in range(1,19) and a!=b and a in range(38) and b in range(38),'invalid native pair')
   used=per.setdefault(s,set());need(not used.intersection((a,b)),'overlapping native main pair');used.update((a,b));stages.append(s)
   calls.append({'clock':clock,'stage':s,'copy':sum(x['stage']==s for x in calls),'source_role':a,'destination_role':b,'main_pairs':111,'body_axes':list(range(1+7*(s-1),1+7*s)),'fresh_helper_owners':458})
  elif op=='IDLE_ONE':
   a,mask=e[1:];need(a in range(38) and mask and len(set(mask))==len(mask) and all(s in range(1,19) for s in mask),'idle owner mask')
  else:raise ValueError('invalid opcode')
 need(stages==[i for i in range(1,19) for _ in range(2)] and len(calls)==36,'actual ordered native schedule')
 need(all(len(v)==4 for v in per.values()),'disjoint physical native pairs')
 return ops,calls

def ordinary(w,native,p,t,ops):
 n=w['ports'];r=w['roles'];N=ops['LOCAL'];q=ops['QUERY'];i=ops['IDLE_ONE']
 banks=native['owned_fields']+native['public']+4
 native_flow=16*banks*len(native['program'])
 caller_flow=n*(8*(ops['ADD']+3*ops['SWAP'])+256*(N+q+r))
 groups=4*(sum(p.values())+sum(t.values()))+8*n*(N+i)
 route=groups*80*(134**2+134);total=N*native_flow+caller_flow+route
 owned=N*(native['owned_fields']+4)+2*n*r*len(w['events'])+16*n*(N+q+r)
 need(total<10**12 and owned<10**7,'source ordinary budgets')
 return dict(native_banks_and_scratch=banks,native_bank_transits_per_call=native_flow,caller_bank_transits=caller_flow,route_groups=groups,route_records=route,ordinary_records=total,owned_backing=owned,raw_ordinary_allowance=10**12,raw_owned_allowance=10**7)

def reject(fn,expected):
 try:fn()
 except (ValueError,KeyError) as e:return str(e)
 raise ValueError('corruption accepted '+expected)

def main():
 raw=(HERE/'inputs/NEW-CALLER.json.gz').read_bytes();need(hashlib.sha256(raw).hexdigest()==PIN,'candidate tape pin');w=json.loads(gzip.decompress(raw))
 old=base.load('EFREE-CALLER.json.gz');native=base.load('WORD.json.gz');f=base.frames(native)
 need(base.canon(w)=='9de443fa08e766e5b054c6100398ffe11341a8c27dec5c5303573ec6d467cd8b','candidate content pin')
 need(w['diagonal']==old['diagonal'],'each original root owner and stage association')
 oldops,oldcalls=validate_structure(old);ops,calls=validate_structure(w)
 fwd=symbolic(w);rev=symbolic(w,True);need(fwd==rev==38**2,'all arbitrary formal rows')
 need(symbolic(old)==symbolic(old,True)==38**2,'pinned old control')
 op0=base.tape(native,f);op1=base.tape(native,f,True)
 need(op0['paid']==op1['paid'],'native paid in both directions')
 p,t,_,_,_=base.invoice(w if False else native,f,w);oldp,oldt,_,_,_=base.invoice(native,f,old)
 need(p==oldp and t==oldt,'complete actual paid and productive caller bins unchanged')
 result={}
 for opcode in ('ADD','LOCAL','QUERY','IDLE_ONE'):
  bad=copy.deepcopy(w);ix=next(i for i,e in enumerate(bad['events']) if e[0]==opcode);del bad['events'][ix]
  result['omit_'+opcode]=reject(lambda:symbolic(bad),opcode)
 bad=copy.deepcopy(w);ix=next(i for i,e in enumerate(bad['events']) if e[0]=='QUERY');bad['events'][ix][0]='ADD'
 result['QUERY_to_ADD']=reject(lambda:symbolic(bad),'QUERY_to_ADD')
 bad=copy.deepcopy(w);bad['diagonal'][0]['q']=0
 result['omit_root_head']=reject(lambda:symbolic(bad),'omit_root_head')
 bad=copy.deepcopy(w);ix=[i for i,e in enumerate(bad['events']) if e[0]=='LOCAL'];bad['events'][ix[1]][2]=bad['events'][ix[0]][2]
 result['overlap_main_owner']=reject(lambda:validate_structure(bad),'overlap_main_owner')
 a=ordinary(old,native,oldp,oldt,oldops);b=ordinary(w,native,p,t,ops)
 rates={k:[str(x) for x in base.margin(t,p,k)] for k in ('0.003879928046156','0.003879929046155')}
 need(b['ordinary_records']<a['ordinary_records'] and b['owned_backing']<a['owned_backing'],'ordinary savings')
 print(json.dumps({'status':'PASS_FORMAL_CALLER_UNCHANGED_SIGNED_INVOICE','source_pins':{'old_native_canonical':base.canon(native),'old_caller_gzip':base.PINS['EFREE-CALLER.json.gz'],'candidate_gzip':PIN,'candidate_canonical':base.canon(w)},'ring':'F2[q,D1,...,D18]/(q^2-1), no specialization or D inverse','forward_coefficients':fwd,'adjoint_coefficients':rev,'native_forward_and_adjoint_public_rows':680,'actual_event_counts':dict(ops),'native_calls':calls,'old_event_counts':dict(oldops),'paid_bins':dict(sorted(p.items())),'productive_bins':dict(sorted(t.items())),'complete_signed_delta_exact':0,'rates':rates,'old_ordinary':a,'new_ordinary':b,'corruptions':result,'physical_limits':'Formal identities hold with arbitrary nonzero root data. The 36 native pairs are disjoint per stage; helper ownership, all-width query/idle embeddings, dirty erasure, off-plane transfer, stock and precision remain inherited or need separate physical verification.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
