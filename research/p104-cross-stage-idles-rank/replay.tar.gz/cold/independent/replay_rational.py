#!/usr/bin/env python3
"""One-core, source-pinned 48-call rational invoice and literal basis/adjoint audit."""
import gzip,json,hashlib,importlib.util
from collections import Counter,defaultdict
from fractions import Fraction
from itertools import chain
from math import gcd,lcm
from pathlib import Path
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('base',HERE/'replay_bit.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
need=base.need
PINS={'RATIONAL-WORD.json.gz':'1b1b3294e86979f1f41076fb056f3c0a08ace6df7bf80f2886bc579a22962f4b','RATIONAL-LAYOUT.json.gz':'b0f3ebc5710e469f3e8fc5ce159cbba048b563944182b50993431ef94f4fedbf','CALLER.json.gz':'d889996a337f648087208ab51c98eaf052705d4fca88b5d01b6e9257a829897a','CONJUGATE-CALLER.json.gz':'80009663da460229a57f09bde90e35294329a210ae7fc7ef6d1f05b61ffccbf4','AUDIT.json':'a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376'}
def load(n):
 raw=(HERE/'inputs'/n).read_bytes();need(hashlib.sha256(raw).hexdigest()==PINS[n],'input digest '+n)
 return json.loads(gzip.decompress(raw) if n.endswith('.gz') else raw)
def spaces(frames):
 out=[]
 for frame in frames:
  s={0}
  for v in frame:
   need(type(v)==int and 0<v<512 and v not in s,'independent chart axes');s|={x^v for x in s}
  out.append(frozenset(s))
 return out

def native(w,layout):
 n=len(w['initial']);f=w['first_output'];need(n==len(w['final'])==1289 and layout['public']==n and layout['frames']==w['frames'],'native layout')
 spans=spaces(w['frames']);moves={};forms={}
 for k,a,b in w['moves']:
  need(k not in moves and 0<=k<f and spans[a]!=spans[b] and (spans[a]<spans[b] or spans[b]<spans[a]),'strict nested paid route');moves[k]=(a,b)
 for node,terms in w['forms']:
  need(node not in forms and terms,'unique form')
  rr=[];seen=set()
  for donor,text in terms:
   q=Fraction(text);need(donor not in seen and q and str(q)==text,'nonzero canonical literal');seen.add(donor);rr.append((donor,q))
  forms[node]=rr
 order=w['schedule'];need(len(order)==len(set(order))==len(forms) and set(order)==set(moves)|set(range(f,f+n)),'complete graph')
 available={~j:c for j,c in enumerate(w['initial'])}
 for node in order:
  chart=moves[node][0] if node in moves else w['final'][node-f]
  for donor,q in forms[node]:need(donor in available and available[donor]==chart,'causal same-chart reader')
  if node in moves:available[node]=moves[node][1]
 h=layout['hosted'];secondary=dict(zip(h['Dports'],zip(h['X2'],h['Y2'],strict=True),strict=True));live=layout['live'];axes=layout['ports']
 need(tuple(Fraction(h[k]) for k in ('alpha','beta','alpha2','beta2'))==(-1,Fraction(1,2),-1,0),'signed P104 port constants')
 need(len(live)==len(axes)==104 and len(set(axes))==104 and len(secondary)==96,'port roster')
 expected=[{i:Fraction(1)} for i in range(n)];slots={}
 for p,(x,head) in enumerate(zip(live,axes,strict=True)):
  y=x+112;group=(x,y)+secondary.get(p,());slots[p]=group
  need(w['frames'][w['initial'][x]]==[head] and w['frames'][w['initial'][y]]==[],'actual input primary frame')
  need(spans[w['final'][x]]==frozenset(range(512)) and spans[w['final'][y]]==frozenset(v for v in range(512) if (v&head).bit_count()%2==0),'actual output primary frame')
  if p in secondary:
   u,v=secondary[p];need(all(d[a]==d[b] for d in (w['initial'],w['final']) for a,b in ((u,x),(v,y))),'secondary frame')
   expected[y][x]=Fraction(1);expected[u][v]=Fraction(-1)
  else:
   expected[x][y]=Fraction(-1);expected[y]={x:Fraction(1,2),y:Fraction(1,2)}
 mains={a for group in slots.values() for a in group};need(len(mains)==sum(map(len,slots.values()))==400,'400 unique main owners')
 need(len(set(layout['source_labels']))==n,'source owner uniqueness')
 p=Counter(abs(len(w['frames'][a])-len(w['frames'][b])) for a,b in moves.values());t=Counter()
 for i,(a,b) in enumerate(zip(w['initial'],w['final'],strict=True)):
  if i not in mains:
   need(spans[a]<spans[b],'productive helper boundary');t[len(w['frames'][b])-len(w['frames'][a])]+=1
 return moves,forms,order,expected,p,t,slots,mains

def roots(caller):
 ports={k:sorted(v['ports']) for k,v in caller['types'].items()};need((len(ports['A']),len(ports['B']))==(96,8) and sorted(ports['A']+ports['B'])==list(range(104)),'all ports')
 use=[set() for _ in range(48)];r=defaultdict(list)
 for start in range(24):
  for j,p in enumerate(ports['B']):
   for time in (start,start+24):r['rotated',8*start+j].append((time,p));use[time].add(p)
 unused=[]
 for color in range(16):
  starts=[s for s in range(24) if color not in (s%16,(s+24)%16)]
  for time in range(color,48,16):
   possible=[s for s in starts if s<time<s+24]
   for group,start in enumerate(possible[:12]):
    starts.remove(start)
    for j,p in enumerate(ports['A'][8*group:8*group+8]):
     need(p not in use[time],'no reused physical port');r['rotated',8*start+j].append((time,p));use[time].add(p)
  need(not starts,'all roots scheduled');unused.append([(time,p) for time in range(color,48,16) for p in ports['A'] if p not in use[time]])
 need(all(len(u)==120 for u in unused),'remaining roots')
 for j,visits in enumerate(zip(*unused,strict=True)):r['A',j]=list(visits)
 need(len(r)==312,'root count');return {k:sorted(v) for k,v in sorted(r.items())}

def template(caller,mixed):
 spec=caller['types']['A'];offset=spec['offset'];a=[]
 for row in caller['events']:
  if row[0]=='J':a.append(['HOST_A',row[1]-1,*[x-offset for x in row[2]]])
  elif row[0]=='A':
   op,target,*args=row[1:];target-=offset
   if op in ('ADD','SWAP','QUERY'):args[0]-=offset
   if op in ('IDLE_ONE','IDLE_ODD'):args[0]=[s-1 for s in args[0]]
   a.append([op,target,*args])
 targets=[]
 for phase,scalar,*mask in spec['diagonal']:
  need(scalar==0 and len(mask)==16 and set(mask)<={0,1},'literal target');targets.append([phase,[i for i,x in enumerate(mask) if x]])
 rot=[]
 for e in mixed['events'][1641:]+mixed['events'][:1641]:
  op,first,*args=e
  if op.startswith('HOST_'):rot.append([op,(first+8)%16,*args])
  elif op=='IDLE_ONE':rot.append([op,first,[(i+8)%16 for i in args[0]]])
  else:need(op in ('ADD','SCALE','SWAP','LAMBDA'),'rotated opcode');rot.append(e)
 return {'A':(a,targets),'rotated':(rot,[[q,[(j+8)%16 for j in mask]] for q,mask in mixed['diagonal']])}

def caller_census(caller,mixed,slots,mains,native_p,native_t,layout):
 rr=roots(caller);words=template(caller,mixed);portsA=set(caller['types']['A']['ports']);p=Counter();t=Counter();used=[{} for _ in range(48)];offset=0;roster=Counter()
 for (kind,index),visits in rr.items():
  events,targets=words[kind];roster[kind]+=1
  hosts=[e for e in events if e[0].startswith('HOST_')]
  need(len(visits)==len(hosts)==16 and sorted(time%16 for time,_ in visits)==list(range(16)),'actual root stage colours')
  for (time,port),e in zip(visits,hosts,strict=True):
   need(e[0]==('HOST_A' if port in portsA else 'HOST_B') and len(e[2:])==len(slots[port]) and len(set(e[2:]))==len(e[2:]),'physical port kind/width')
   need(port not in used[time] and all(i in range(len(targets)) for i in e[2:]),'root operand ownership')
   used[time][port]=[offset+i for i in e[2:]]
  for q,mask in targets:
   need(q in (-1,1) and mask and len(set(mask))==len(mask),'nonzero output role');t[q%2+8*len(mask)]+=1
  for e in events:
   if e[0]=='QUERY':p[1]+=1
   elif e[0] in ('IDLE_ONE','IDLE_ODD'):p[8*len(e[2])+int(e[0]=='IDLE_ODD')]+=1
  offset+=len(targets)
 for time,portmap in enumerate(used):
  need(set(portmap)==set(range(104)),'complete physical 48-call schedule')
  labels={native:owner for port,owners in portmap.items() for native,owner in zip(slots[port],owners,strict=True)}
  need(set(labels)==mains and len(set(labels.values()))==400,'400 distinct physical main bindings')
 need(roster=={'A':120,'rotated':192},'actual root roster')
 for _ in range(len(used)):p.update(native_p);t.update(native_t)
 return p,t,dict(calls=len(used),root_roster=dict(roster),root_owners=offset,main_owners_per_call=400,helper_owners_per_call=1289-400)

def sumrows(parts):
 data=[(row,num.numerator,den*num.denominator) for (den,row),num in parts if row]
 if not data:return (1,{})
 den=lcm(*(d for _,_,d in data));values=defaultdict(int)
 for row,num,d in data:
  factor=num*(den//d)
  for i,v in row.items():values[i]+=factor*v
 values={k:v for k,v in values.items() if v};common=gcd(den,*values.values())
 return den//common,{k:v//common for k,v in values.items()}

def basis_audit(moves,forms,order,expected,grid):
 stocks={~i:{i:grid} for i in range(len(expected))};nprod=ndiv=0;common=grid;firstodd=None
 for node in order:
  out={}
  for donor,q in forms[node]:
   vals=stocks[donor];nprod+=len(vals);ndiv+=len(vals) if q.denominator!=1 else 0
   for j,value in vals.items():
    z,rem=divmod(value,q.denominator);need(rem==0,'exact separate product on grid');z*=q.numerator
    if common!=1:common=gcd(common,z)
    if firstodd is None and z%2:firstodd=[node,donor,j,str(q),str(z)]
    out[j]=out.get(j,0)+z
  out={j:v for j,v in out.items() if v}
  if node in moves:stocks[node]=out
  else:
   want={j:int(q*grid) for j,q in expected[node-(154768)].items()};need(out==want,'arbitrary forward rational output')
 need(common==1 and firstodd is not None,'grid minimum witness')
 return dict(basis_products=nprod,nonunit_denominator_products=ndiv,product_grid=grid,first_odd_product_half_grid_rejected=firstodd,public_forward_rows=len(expected))

def adjoint(moves,forms,order,expected,first):
 pending={first+i:[((1,{i:1}),Fraction(1))] for i in range(len(expected))}
 for node in reversed(order):
  influence=sumrows(pending.pop(node,()))
  if influence[1]:
   for donor,q in forms[node]:pending.setdefault(donor,[]).append((influence,q))
 for i in range(len(expected)):
  den,values=sumrows(pending.pop(~i,()));actual={j:Fraction(x,den) for j,x in values.items()}
  want={j:row[i] for j,row in enumerate(expected) if i in row}
  need(actual==want,'arbitrary adjoint rational output')
 need(not pending,'all adjoint influences consumed');return len(expected)

def main():
 w,layout,caller,mixed,audit=[load(x) for x in ('RATIONAL-WORD.json.gz','RATIONAL-LAYOUT.json.gz','CALLER.json.gz','CONJUGATE-CALLER.json.gz','AUDIT.json')]
 need(base.canon(w)=='7660985e0b618cdbee13e4190a4c6d5f91fbdf01a8f7a5186fdde8b980c19b48' and base.canon(layout)=='f7de788c4a559282d35a9fce42f841a0e8de5a4015db871e718f9245569b0aa7','word/layout content')
 moves,forms,order,expected,np,nt,slots,mains=native(w,layout)
 paid,prod,calls=caller_census(caller,mixed,slots,mains,np,nt,layout)
 need(paid==Counter({int(k):v for k,v in audit['signed']['paid'].items()}) and prod==Counter({int(k):v for k,v in audit['signed']['productive'].items()}),'48-call full source histogram')
 rates={k:[str(x) for x in base.margin(prod,paid,k)] for k in ('0.003879928046156','0.003879929046155')}
 grid=audit['basis_grid']['product_grid'];ba=basis_audit(moves,forms,order,expected,grid)
 need(ba['basis_products']==audit['basis_grid']['all_basis_products'] and ba['nonunit_denominator_products']==audit['basis_grid']['nontrivial_basis_divisions'],'complete scalar product census')
 rev=adjoint(moves,forms,order,expected,w['first_output'])
 # This is the owner 338 in the incumbent layout, not the unrelated new owner 1542.
 need(layout['source_labels'][324]==338,'incumbent owner binding')
 wronglabels=layout['source_labels'].copy();wronglabels[324],wronglabels[325]=wronglabels[325],wronglabels[324]
 need(wronglabels[324]!=338 and sorted(wronglabels)==sorted(layout['source_labels']),'same inventory wrong owner rejected')
 print(json.dumps({'status':'PASS_LITERAL_48_CALL_RATIONAL_AND_PRECISION','source_pins':PINS,'native_canonical':base.canon(w),'layout_canonical':base.canon(layout),'native_public':len(expected),'native_moves':len(moves),'native_helpers':sum(nt.values()),'native_paid':dict(sorted(np.items())),'native_productive':dict(sorted(nt.items())),'actual_caller':calls,'complete_paid':dict(sorted(paid.items())),'complete_productive':dict(sorted(prod.items())),'directed_margins':rates,'basis_and_precision':ba,'public_adjoint_rows':rev,'owner_control':{'address':324,'owner':338,'same_inventory_owner_swap_rejected':True},'scope':'All rational basis rows, all rational adjoint rows, exact scalar division grid, actual 48-call event and owner-price census. Physical all-width fields, dirty retirement, query lifecycle and analytic recovery retain the named external premises.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
