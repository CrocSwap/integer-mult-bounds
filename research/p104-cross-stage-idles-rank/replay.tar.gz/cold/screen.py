#!/usr/bin/env python3
"""Bounded two-IDLE caller screen; all outputs go to stdout.

Two selected original arm registers alone may be transported by ordinary
2x2 invertible matrices between their IDLE slots.  Native and target data,
the body masks, and all unselected IDLEs are fixed.  An optional paid head
on an IDLE is an optimistic formal grant, not a supplied physical opcode.
"""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'source'))
import common as C

N = 38
IDENTITY = tuple(1 << j for j in range(N))


def rank(rows):
    pivots = {}
    for row in rows:
        while row and row.bit_length() in pivots:
            row ^= pivots[row.bit_length()]
        if row:
            pivots[row.bit_length()] = row
    return len(pivots)


def row2mul(a, b):
    return tuple((b[0] if v & 1 else 0) ^ (b[1] if v & 2 else 0) for v in a)


def body_basis_census(equal_masks=False):
    """Check C diag(1,Y) B diag(X,1) A = diag(X,Y)."""
    gl = [m for m in product(range(4), repeat=2) if m[0] and m[1] and m[0] != m[1]]
    e0, e1, z, ident = (1, 0), (0, 2), (0, 0), (1, 2)
    accepted = []
    for a, b, c in product(gl, repeat=3):
        coeff = [row2mul(c, row2mul(p, row2mul(b, row2mul(q, a))))
                 for p in (e0, e1) for q in (e1, e0)]
        if equal_masks:
            ok = (coeff[0] == z and coeff[3] == z and
                  tuple(x ^ y for x, y in zip(coeff[1], coeff[2])) == ident)
        else:
            ok = coeff == [z, e0, e1, z]
        if ok:
            accepted.append([list(a), list(b), list(c)])
    return len(gl) ** 3, accepted


def formal(caller, omit=(), odd=(), adjoint=False):
    """Actual polynomial/q rows; odd marks the hypothetical qD IDLE grant."""
    omit, odd = set(omit), set(odd)
    rows = [{0: 1 << i} for i in range(N)]
    seq = list(enumerate(caller['events']))
    if adjoint:
        seq.reverse()
    for clock, (op, *args) in seq:
        if clock in omit:
            continue
        if op in ('ADD', 'QUERY'):
            a, b = args[::-1] if adjoint else args
            rows[a] = C.literal.add(rows[a], C.literal.shift(rows[b], 0, op == 'QUERY'))
        elif op == 'SWAP':
            a, b = args
            rows[a], rows[b] = rows[b], rows[a]
        elif op == 'LOCAL':
            stage, a, b = args
            if adjoint:
                a, b = b, a
            count = C.literal.caller_monomial([stage])
            rows[a], rows[b] = C.literal.shift(rows[a], count), C.literal.shift(
                C.literal.add(rows[b], C.literal.shift(rows[a], 0, True)), count)
        elif op == 'IDLE_ONE':
            a, mask = args
            rows[a] = C.literal.shift(rows[a], C.literal.caller_monomial(mask), clock in odd)
        else:
            raise ValueError(op)
    return rows


def q1_snapshots(caller):
    """Set q=1, retain all formal body variables and record each actual idle row."""
    rows = [{0: 1 << i} for i in range(N)]
    snapshots = []
    for clock, (op, *args) in enumerate(caller['events']):
        if op in ('ADD', 'QUERY'):
            a, b = args
            rows[a] = C.literal.add(rows[a], rows[b])
        elif op == 'SWAP':
            a, b = args
            rows[a], rows[b] = rows[b], rows[a]
        elif op == 'LOCAL':
            stage, a, b = args
            count = C.literal.caller_monomial([stage])
            rows[a], rows[b] = C.literal.shift(rows[a], count), C.literal.shift(
                C.literal.add(rows[b], rows[a]), count)
        elif op == 'IDLE_ONE':
            a, mask = args
            assert len(rows[a]) == 1
            (before, bits), = rows[a].items()
            assert bits == 1 << a
            hub = 0 if a < 19 else 19
            armstage = a - hub
            if clock < 100:
                prefix = [armstage]
                assert mask == list(range(armstage + 1, 10))
            else:
                prefix = []
                assert mask == list(range(10, armstage))
            assert before == C.literal.caller_monomial(prefix)
            snapshots.append(dict(clock=clock, role=a, hub=hub, stage=armstage,
                                  prefix=prefix, idle_mask=mask, grade=7*len(mask)))
            rows[a] = C.literal.shift(rows[a], C.literal.caller_monomial(mask))
        else:
            raise ValueError(op)
    expected = [{C.literal.caller_monomial(x['stages']): 1 << i}
                for i, x in enumerate(caller['diagonal'])]
    assert rows == expected
    return snapshots


def eps_specialized(caller, omit=(), odd=(), adjoint=False):
    """q=1+eps, eps^2=0, with every D_i=1; return target residual rows."""
    omit, odd = set(omit), set(odd)
    even, epsilon = list(IDENTITY), [0] * N
    seq = list(enumerate(caller['events']))
    if adjoint:
        seq.reverse()
    for clock, (op, *args) in seq:
        if clock in omit:
            continue
        if op in ('ADD', 'QUERY'):
            a, b = args[::-1] if adjoint else args
            epsilon[a] ^= epsilon[b] ^ (even[b] if op == 'QUERY' else 0)
            even[a] ^= even[b]
        elif op == 'LOCAL':
            _, a, b = args
            if adjoint:
                a, b = b, a
            epsilon[b] ^= epsilon[a] ^ even[a]
            even[b] ^= even[a]
        elif op == 'SWAP':
            a, b = args
            even[a], even[b] = even[b], even[a]
            epsilon[a], epsilon[b] = epsilon[b], epsilon[a]
        elif op == 'IDLE_ONE':
            if clock in odd:
                epsilon[args[0]] ^= even[args[0]]
        else:
            raise ValueError(op)
    assert tuple(even) == IDENTITY
    return [x ^ y for x, y in zip(epsilon, IDENTITY)]


def wrong(actual, expected):
    bad_rows, coefficients = 0, 0
    for a, b in zip(actual, expected):
        monomials = set(a) | set(b)
        delta = sum((a.get(k, 0) ^ b.get(k, 0)).bit_count() for k in monomials)
        bad_rows += bool(delta)
        coefficients += delta
    return dict(bad_rows=bad_rows, nonzero_formal_monomial_coefficient_differences=coefficients)


def main():
    raw = gzip.decompress((HERE / 'source' / 'CALLER.json.gz').read_bytes())
    assert sha256(raw).hexdigest() == '9de443fa08e766e5b054c6100398ffe11341a8c27dec5c5303573ec6d467cd8b'
    caller = json.loads(raw)
    word, old, _, native_paid, native_targets, paid, targets, rat = C.baseline()
    ops = Counter(e[0] for e in caller['events'])
    assert ops == {'ADD': 252, 'LOCAL': 36, 'IDLE_ONE': 32, 'QUERY': 4}
    p, t = C.literal.paired_invoice(caller, native_paid, native_targets, ops)
    assert p == paid and t == targets
    expected = [formal(caller, adjoint=rev) for rev in (False, True)]
    assert expected[0] == C.literal.caller_rows(old) == expected[1]
    assert expected[0] == C.literal.caller_rows(caller)
    assert expected[1] == C.literal.caller_rows(caller, True)
    snapshots = q1_snapshots(caller)
    assert len(snapshots) == 32
    distinct, same = [], []
    for a, b in combinations(snapshots, 2):
        (same if a['idle_mask'] == b['idle_mask'] else distinct).append((a, b))
    assert len(distinct) == 480 and len(same) == 16
    assert all(a['stage'] != b['stage'] for a, b in distinct)
    assert all(a['stage'] == b['stage'] for a, b in same)
    for a, b in distinct:
        x = tuple(int(i in a['idle_mask']) for i in range(1, 19))
        y = tuple(int(i in b['idle_mask']) for i in range(1, 19))
        assert len({(0,)*18, x, y, tuple(i+j for i, j in zip(x, y))}) == 4
    all_gl, unique = body_basis_census()
    _, equal_solutions = body_basis_census(equal_masks=True)
    assert all_gl == 216 and unique == [[[1,2],[1,2],[1,2]]]
    assert len(equal_solutions) == 6

    query = [i for i, e in enumerate(caller['events']) if e[0] == 'QUERY']
    assert len(query) == 4
    assert all(caller['events'][i+1] == ['ADD', *caller['events'][i][1:]] for i in query)
    all_removed = {x for i in query for x in (i, i+1)}
    residual = eps_specialized(caller, all_removed)
    explicit = [0] * N
    for h in (0, 19):
        arms = list(range(h+1, h+19))
        explicit[h] = (1 << h) | sum(1 << j for j in arms)
        for j in arms:
            explicit[j] = 1 << h
    assert residual == explicit and rank(residual) == 4
    assert eps_specialized(caller, all_removed, adjoint=True) == explicit

    # A strictly stronger algebraic grant than the body-admissible odd-IDLE
    # projectors: allow every binary 2x2 epsilon matrix on the two chosen arms.
    rank_table = Counter()
    for a, b in distinct:
        roles = (a['role'], b['role'])
        for r0, r1 in product(range(4), repeat=2):
            srank = rank((r0, r1))
            test = residual.copy()
            for row, value in zip(roles, (r0, r1)):
                for j in range(2):
                    if value & (1 << j):
                        test[row] ^= 1 << roles[j]
            rr = rank(test)
            assert rr == 4 + srank
            rank_table[(srank, rr)] += 1
    one_counts, pair_counts = Counter(), Counter()
    for a in snapshots:
        for rev in (False, True):
            one_counts[rank(eps_specialized(caller, all_removed, [a['clock']], rev))] += 1
    for a, b in distinct:
        for rev in (False, True):
            pair_counts[rank(eps_specialized(caller, all_removed, [a['clock'], b['clock']], rev))] += 1
    assert one_counts == {5: 64} and pair_counts == {6: 960}

    trials = []
    for count in (1, 2, 3, 4):
        for selected in combinations(query, count):
            omit = {x for i in selected for x in (i, i+1)}
            rows = [formal(caller, omit, adjoint=rev) for rev in (False, True)]
            mismatch = [wrong(x, y) for x, y in zip(rows, expected)]
            assert all(x['bad_rows'] for x in mismatch)
            qleft = 4-count
            mutops = ops.copy(); mutops['QUERY'] -= count; mutops['ADD'] -= count
            mp = p.copy(); mp[1] -= 111*count
            altered = deepcopy(caller)
            altered['events'] = [e for i, e in enumerate(caller['events']) if i not in omit]
            trials.append(dict(removed_query_clocks=selected, queries_remaining=qleft,
                               mismatches_forward_adjoint=mismatch,
                               specialized_residual_rank=rank(eps_specialized(caller, omit)),
                               ordinary_if_valid=C.literal.ordinary(word, altered, mutops, mp, t)))

    # Aggressive signed-grade temptation: two grade-56 heads and remove two
    # queries, granting the head supplier and all basis work for free.
    selected_idles = [72, 243]
    assert all(next(s for s in snapshots if s['clock'] == x)['grade'] == 56 for x in selected_idles)
    omit = {x for i in query[:2] for x in (i, i+1)}
    cand = [formal(caller, omit, selected_idles, adjoint=rev) for rev in (False, True)]
    mismatch = [wrong(x, y) for x, y in zip(cand, expected)]
    assert all(x['bad_rows'] for x in mismatch)
    pp = p.copy(); pp[1] -= 222; pp[56] -= 222; pp[57] += 222
    mutops = ops.copy(); mutops['QUERY'] -= 2; mutops['ADD'] -= 2
    tmp = deepcopy(caller); tmp['events'] = [e for i, e in enumerate(caller['events']) if i not in omit]
    rates = {}
    restoration = {}
    for k in C.RATES:
        oldbit, newbit = C.moment(p,t,k), C.moment(pp,t,k)
        rates[str(k)] = dict(base_bit=C.display(oldbit), optimistic_changed_bit=C.display(newbit),
                             optimistic_signed_delta=C.display(C.minus(newbit,oldbit)),
                             fixed_rational_48_call=C.display(C.moment(rat['signed']['paid'],
                                                                     rat['signed']['productive'],k)))
        assert rates[str(k)]['optimistic_signed_delta'][0][0] != '-'
        # Any two headed distinct-stage idles need at least six rank-one
        # QUERY corrections.  Sweep all 480 actual grade pairs, charge six
        # rather than four, and grant all basis/physical head work for free.
        pair_upper = []
        for a, b in distinct:
            inc_a = C.minus(C.power(a['grade']+1,k), C.power(a['grade'],k))
            inc_b = C.minus(C.power(b['grade']+1,k), C.power(b['grade'],k))
            penalty = C.plus((C.D(222), C.D(222)), C.scale(C.plus(inc_a,inc_b),111))
            delta = C.minus(C.ZERO, penalty)
            pair_upper.append((delta[1], a['clock'], b['clock'], delta))
        best = max(pair_upper)
        assert best[0] < 0
        restoration[str(k)] = {'best_of_480_idle_pairs': [best[1],best[2]],
                               'minimum_total_queries':6,
                               'signed_delta_upper_interval':C.display(best[3]),
                               'all_ordinary_basis_transport_and_extra_physical_restoration_granted_free':True}
    rational_replay = json.loads((HERE / 'independent' / 'RATIONAL-REPLAY.json').read_text())
    assert rational_replay['actual_caller']['calls'] == 48
    for k in C.RATES:
        independent_interval = rational_replay['directed_margins'][str(k)]
        local_interval = rates[str(k)]['fixed_rational_48_call']
        assert (C.D(independent_interval[0]) <= C.D(local_interval[1]) and
                C.D(local_interval[0]) <= C.D(independent_interval[1]))
        rates[str(k)]['independent_rational_interval'] = independent_interval
    out = dict(
        status='NEGATIVE_BOUNDED_SCREEN',
        source={'pr_7830_head': '87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
                'native_word_canonical': 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d',
                'candidate_canonical': sha256(raw).hexdigest(), 'query_clocks':query},
        scope='Two selected original arm registers only; original masks, native operators and targets fixed. Three q-independent GL(2,2) transport matrices inside the idle-only window. No mixed unselected idle, native-stage changes, additional paid routing, or changed productive targets.',
        actual_idle_rows=snapshots,
        body={'actual_idles':32, 'distinct_stage_pairs':480, 'equal_mask_same_stage_controls':16,
              'constant_gl2_transports_per_pair':all_gl, 'distinct_mask_accepted_per_pair':len(unique),
              'distinct_mask_accepted':unique, 'equal_mask_control_accepted':len(equal_solutions),
              'distinct_pair_monomials_1_X_Y_XY_are_independent':True},
        residual={'ring':'F2[q,D1,..,D18]/(q^2-1), q=1+eps; lower bound specializes all D to 1',
                  'all_query_pairs_removed_base_rank':4,
                  'arbitrary_2x2_epsilon_on_selected_arms_rank_counts':
                    {str(k):v for k,v in sorted(rank_table.items())},
                  'one_odd_head_forward_and_adjoint':dict(one_counts),
                  'two_distinct_stage_heads_forward_and_adjoint':dict(pair_counts),
                  'native_arms_residual_reference_rows': [str(x) for x in residual]},
        actual_deletion_trials=trials,
        optimistic_two_head_two_query_trial={'head_idle_clocks':selected_idles,
             'removed_query_clocks':query[:2], 'query_remaining':2, 'paid_head_is_granted_not_physical_proof':True,
             'all_body_q1_rows_and_original_target_masks_preserved':True,
             'mismatches_forward_adjoint':mismatch,
             'specialized_residual_rank':rank(eps_specialized(caller,omit,selected_idles)),
             'native_call_count':36, 'rational_call_count':48, 'rates':rates,
             'assumed_no_extra_basis_or_head_ordinary_cost':
                C.literal.ordinary(word,tmp,mutops,pp,t),
             'paid_histogram':dict(sorted(pp.items())), 'productive_histogram':dict(sorted(t.items()))},
        two_head_best_case_query_restoration=restoration,
        controls={'full_candidate_38x38_formal_forward_and_adjoint':True,
                  'pinned_native_680x680_forward_and_adjoint':True,
                  'all_36_native_charges_in_each_invoice':True,
                  'independent_rational_48_call_replayed':True,
                  'same_stage_equal_mask_basis_control':True})
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
