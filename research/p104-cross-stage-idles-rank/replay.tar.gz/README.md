# Two paid IDLEs across caller stages: bounded negative screen

The fixed 324-event paired BIT caller admits no improvement in the following
two-register model. Select two existing paid IDLEs on different arm/stage
pairs, keep their original body masks, and transport only those two arm
registers through ordinary `GL(2,F2)` basis changes in the IDLE-only window.
All 30 other IDLEs, all 36 native actions and all productive target roles are
fixed. QUERY corrections may be reselected at the seam. An IDLE that also
supplies the head factor is allowed as an *optimistic formal grant*, priced
at its full new grade, without claiming that physical supplier exists.

There are **480** eligible pairs of the actual 32 IDLEs. Their body masks
are distinct monomials, and exact `q=1` body compatibility allows only the
identity among the **216** triples of 2×2 invertible basis transports for
each pair. The `ε` coefficient still requiring correction has rank four
after specializing every body variable to one. Granting an **arbitrary**
2×2 binary `ε` matrix on the two chosen arms makes its rank
`4 + rank(S)`. Consequently zero, one and two distinct headed IDLEs need at
least four, five and six QUERYs, respectively. A four-QUERY variant with
unchanged paid IDLE grades has exactly the original signed histogram. No
κ improvement follows.

This result is distinct from a fixed-stage square-zero-map proof: the
selected IDLEs may be on separate stages and opposite chains, and the rank
check grants every 2×2 arm correction. It is also deliberately narrower
than arbitrary transport on all 38 registers: a basis change which mixes an
unselected IDLE, changes native action/body masks, or passes through an
altered supply is outside the model.

## Exact body and rank calculations

The source is PR #7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`,
native canonical SHA-256
`d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`,
and the frozen R5 four-QUERY caller canonical SHA-256
`9de443fa08e766e5b054c6100398ffe11341a8c27dec5c5303573ec6d467cd8b`.
`RESULT.json` records every original clock, arm, stage, initial body row,
and idle mask. At a left IDLE, the selected row already has its own stage
factor `D_j`; at a right IDLE it has no body factor yet. After removing
those fixed input/output factors and all untouched diagonal IDLE actions,
put the two selected nonempty idle masks `X` and `Y` into their actual time
order. Body preservation requires

`C diag(1,Y) B diag(X,1) A = diag(X,Y)`.

Here `A,B,C` are 2×2 invertible binary matrices; the same-coordinate
changes occur with their required reversals. The four monomials
`1, X, Y, XY` are linearly independent in the body-polynomial ring, even
for overlapping or nested masks. Coefficient comparison leaves only
`A=B=C=I`. The script independently enumerates all 216 triples. As a
positive control, the 16 same-stage pairs have equal masks and admit six
solutions each; they are excluded from the 480 different-stage pairs.

Write `q=1+ε`, with `ε²=0`. All four compensated QUERY pairs are removed
for the rank measurement. The actual specialized residual on each chain is

`R_h = e_h(e_h+s_h)^T + s_h e_h^T`, with `s_h` the sum of 18 arm vectors.

The direct sum for the two hubs has rank four. The original two selected
arm coordinates meet neither its row space nor its column space, so adding
any matrix supported on their 2×2 block raises rank by exactly the rank of
that block. All 480×16 matrices are checked, as are both orientations for
every one-head and two-head actual IDLE placement. Any actual polynomial
identity would survive setting every `D_j=1`; each QUERY can contribute at
most one rank to the `ε` coefficient there. This is a lower bound, not a
claim that a matching six-QUERY physical implementation exists.

## Failed candidate and complete economics

The explicit optimistic candidate upgrades the grade-56 IDLEs at clocks 72
and 243 to `qD` and removes the compensated QUERYs at clocks 154 and 158.
Its price-only signed change would be `+4.2957707920152856` at
`0.003879928046156` and `+4.2957718888347670` at
`0.003879929046155`. This is **not a construction**: its exact formal
38×38 replay changes 19 forward and 37 adjoint rows, with 114 differing
monomial coefficients in each orientation. The specialized residual after
the two remaining QUERYs has rank four. The body-only `q=1` rows do match,
which shows why the body compatibility test alone is insufficient.

With two headed IDLEs, the minimum is six total QUERYs. Sweeping all 480
actual grade pairs and pricing those six QUERYs gives best-case complete
signed changes bounded above by `−439.7042292079847143` at the first trial
and `−439.7042281111652329` at the near trial. That bound grants all basis
transport and any further physical restoration for free, so no hidden
ordinary or paid charge can improve it under this fixed-productive model.
For comparison, the unchanged caller costs 934,181,764,128 modeled
ordinary records and 2,999,880 backing units. The failed two-QUERY trial's
optimistic modeled values are 932,896,591,920 and 2,962,584, before any
head implementation or repair; these savings are immaterial because its
operator is wrong. `RESULT.json` contains complete paid/productive bins,
all 15 QUERY-subset deletion controls, both exact mismatch counts and
modeled ordinary accounting.

Every invoice contains the original **36** native calls and unchanged
productive roles. The independent R5 check reconstructs the complete
**48**-call rational companion: its margin is approximately
`+0.212262470163347` at the first trial and `+0.211243929926514` at the
near trial. The original BIT margins are approximately
`−0.0000000007670015024` and `−0.000385127316614`, respectively. All
reported interval endpoints are in `RESULT.json`; independent rational
intervals overlap those calculated here.

The base caller and 680-owner native operator replay all forward and
transpose coefficients. Literal `CLEAR` still has discard semantics;
the inherited native-all-columns, owned-erasure, compiler, precision-tape
and analytic-recovery premises remain applicable. No new physical IDLE
supplier, changed caller, complete κ certificate, or maintainer selection
is claimed.

## Reproduce

Run CPython 3.10+ with assertions enabled, in this directory:

```sh
(cd source && sha256sum -c SHA256SUMS && python3 -I -B verify.py)
(cd independent && python3 -I -B replay_caller.py > CALLER-REPLAY.json)
(cd independent && python3 -I -B replay_rational.py > RATIONAL-REPLAY.json)
python3 -I -B screen.py > RESULT.json
```

The separately produced R5 replay scripts and their input pins are retained
under `independent/`; the source construction, licence, and notices are
retained under `source/`. No network or external application writes are
needed. `COLD-REPLAY.json` records a separate-copy rerun.
