# Two retargets after the chart-268 C+D rebind

This is a bounded follow-up to the damaged chart-268 C+D word, whose compressed SHA-256 is `172cb1137452196536f96b422086d99352c493e4761eb13501195412f4995fbc`. The source and the changed word are included. The retained 2678 contact is 182→0. Both 680-owner orientations correctly reproduce owners 221, 411 and 679, but the changed word still has 66 forward and 23 adjoint errors. It is not an admitted supplier and gives no new κ.

We keep all public endpoints and the productive invoice fixed, and replace **two distinct existing paid contacts** with 0→19 and 421→1 in either assignment. These new routes have grades 1 and 2. To increase both the number of sends leaving chart 0 and the number entering chart 1 by one, neither displaced contact may already leave 0 or enter 1. The current 2678 contact is retained. There are 1,813 eligible existing contacts, giving 1,642,578 unordered pairs. Every pair is nominally funded: the least favorable pair removes two grade-one sends, and its complete 36-call binary margin is +0.3481896197840974 at κ = 0.00388. These prices apply to a damaged diagnostic map and do not establish admission.

## Exact incidence cuts

The verifier computes 1,957 exact public-map cut ranks and the capacities of the graph with both prospective routes added, then records a tight separating cut for each of 1,787 individually disallowed contacts. Deleting any such contact, even together with another, violates that cut. Thus **1,642,253 of the 1,642,578 pairs are impossible** regardless of payloads, retiming, interaction or decoder nonlinearity. The 325 survivors are exactly the pairs of 26 listed in `BROAD.json`. `EXCLUSIONS.json` records every individually disallowed contact and the witnessing cut, its required rank and capacity.

A local roster of seven grade-one and fourteen grade-two contacts adjacent to charts 19, 24, 182, 268 or 421 is separately named in `LOCAL-CENSUS.json`. All 98 local pairs fail an exact cut. Notably, all seven that survived a smaller initial cut family fail explicit four-chart cuts with rank 526 and capacity 525.

## Frozen-stock first-reader screen

For each of the 325 incidence-cut survivors, choose the first surviving reader of one displaced contact in the pre-retarget C+D word. At that reader, freely grant every frozen, pre-reader stock value at its chart and at charts 0, 19, 24, 182, 268, 318 and 421, excluding the two displaced packets themselves. Every one of the 325 pre-retarget C+D reader values remains outside the granted span. Some such values already differ from the original #7830 word. Each entry in `COLLISIONS.json` supplies a binary input shift that leaves all granted values unchanged while flipping that reader value. A control restoring the old packet values recovers the target. The verifier also rejects an erased collision shift.

This second result is **not** an unrestricted exclusion of the 325 pairs. It assumes the other historical payload values remain frozen and asks to preserve the stated pre-retarget C+D first-reader value. Coordinated changes to other upstream equations or to reader obligations remain open. Incidences other than the two named replacement routes, altered public endpoints or productive targets, and a different caller are outside the two-cut census.

## Reproduction

Use Python 3.11 or newer; no network or third-party packages are required.

```
sha256sum -c SHA256SUMS
python3 -I -B verify_source.py
python3 -I -B census.py
python3 -I -B exclusions.py
python3 -I -B broad.py
python3 -I -B collisions.py
```

The source verifier independently matches every changed packet's incidence and arrival value to the frozen word, replays both full operators, checks protected owner 411, and reconstructs the directed price floor. The other scripts recompute the cuts and compare their outputs with the frozen receipts; the collision verifier checks the given stock and the positive and corrupted controls. Retained upstream provenance and notices are in `source/`.
