import sys,json
from pathlib import Path
from collections import Counter
from itertools import combinations
sys.path.insert(0,str(Path(__file__).resolve().parent))
from census import *
allc=[p for p,(a,b) in M.items() if p!=2678 and a!=0 and b!=1 and 0<ATLAS.grade(a,b)<=6]
tight=[item for item in values if item[-1]==0]
one=[p for p in allc if all(not crossed(M[p],S) for S,*_ in tight)]
print('eligible',len(allc),dict(Counter(ATLAS.grade(*M[p]) for p in allc)),'individually viable',len(one),[(p,M[p],ATLAS.grade(*M[p])) for p in one],flush=True)
openpairs=[];blocked=Counter()
for p,q in combinations(one,2):
 for S,name,r,n,aug,delta in values:
  if crossed(M[p],S)+crossed(M[q],S)>delta:blocked[name]+=1;break
 else:openpairs.append([p,q])
print('all joint combinations',len(one)*(len(one)-1)//2,'open',len(openpairs),openpairs[:80],flush=True)
out={'new_edges':[[0,19],[421,1]],'eligible_count':len(allc),'eligible_grades':dict(Counter(ATLAS.grade(*M[p]) for p in allc)),'cut_count':len(values),'tight_count':len(tight),'individually_viable':[[p,list(M[p]),ATLAS.grade(*M[p])] for p in one],'joint_survivor_pairs':openpairs,'joint_blocked':dict(blocked),'scope':'Any two distinct eligible original moves retargeted in either assignment to 0->19 and 421->1; unchanged public endpoints/productive invoice; retain 2678 182->0.'}
assert (Path(__file__).resolve().parent/'BROAD.json').read_text()==json.dumps(out,sort_keys=True,indent=2)+'\n'
