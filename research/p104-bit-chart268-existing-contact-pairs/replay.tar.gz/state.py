from pathlib import Path
import sys
from collections import defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parent))

from core import *
from rebind import early_schedule
M=dict(R);rr=dict(ROWS)
M[3410]=(421,0);rr[3410]=rr[3409];del rr[3409],M[3409]
rr[789]=1<<17
for k in [785,1584,1934]:
 for p in list(rr):
  if rr[p]>>k&1:rr[p]^=1<<k
rr.update({785:1<<679,1584:1<<785,1934:1<<1584,~679:1<<1934,1583:(1<<17)^(1<<781),1585:(1<<1583)^(1<<813),1586:1<<1583})
M[1583]=(19,182)
for k in list(rr):rr[k]&=~(1<<2678)
M[2678]=(182,0);rr[2678]=(1<<1583)^(1<<813);rr[1463]=(1<<519)^(1<<549)^(1<<2678)
initial=dict(enumerate(W['start']));final=dict(enumerate(W['final']))
seq=early_schedule(initial,final,M,rr)
vals={i:1<<i for i in initial};stocks=defaultdict(list)
for i,c in initial.items():stocks[c].append(i)
for p in seq:
 vals[p]=xsum(vals[i] for i in labels(rr[p]));stocks[M[p][1]].append(p)
assert vals[1464]==X[1464]^X[1584]
