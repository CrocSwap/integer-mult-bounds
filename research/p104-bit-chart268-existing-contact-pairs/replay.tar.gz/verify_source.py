import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from state import *
import gzip,json,hashlib
from collections import Counter
from pathlib import Path
import bit_native
root=Path(__file__).resolve().parent
raw=(root/'CPLUS-D-WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='172cb1137452196536f96b422086d99352c493e4761eb13501195412f4995fbc'
w=json.loads(gzip.decompress(raw));i,f,m,r,c=bit_native.extract(w);assert i==initial and f==final
trace=[op.run_tape(w,op.Atlas(w['frames']),z) for z in (False,True)]
for j,p in enumerate(seq):
 k=len(initial)+j
 assert m[k]==M[p] and trace[0].packets[k].arrival.row==vals[p]
bad=[[j for j,(x,y) in enumerate(zip(t.output,op.expected_operator(z))) if x!=y] for z,t in zip((False,True),trace)]
assert list(map(len,bad))==[66,23]
assert all(j not in errors for j in [221,411,679] for errors in bad)
assert M[2678]==(182,0) and vals[1464]==X[1464]^X[1584]
assert all(not (x.arrival.row>>679&1) for p,x in trace[0].packets.items() if m[p][1]==1)
_,caller,_,_,helpers,P,T,rat=prices.baseline();gh=Counter(x.grade for x in trace[0].packets.values());paid,prod=prices.literal.paired_invoice(caller,gh,helpers,Counter(e[0] for e in caller['events']));assert prod==T
rate=prices.D('0.00388');margin=prices.moment(paid,prod,rate)
assert prices.D('36.15481217569850')<margin[0] and margin[1]<prices.D('36.15481217569852')
# The minimum old tariff is 1+1, and the replacement pair is 1+2.
for g in range(1,6):assert prices.power(g,rate)[1]<prices.power(g+1,rate)[0]
minimum=prices.plus(margin,prices.scale(prices.minus(prices.power(1,rate),prices.power(2,rate)),36))
assert prices.D('0.34818961978409')<minimum[0] and minimum[1]<prices.D('0.34818961978410')
print('PASS original #7830 control, changed literal byte identity, both operator audits, protected 411, C+D, 221/679 and price floor',prices.display(minimum))
