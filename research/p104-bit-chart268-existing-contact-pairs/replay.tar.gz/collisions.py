import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from state import *
from pathlib import Path
from collections import Counter
import json
idx={p:i for i,p in enumerate(seq)}
grant=[0,19,24,182,268,318,421]
rrr=json.loads((Path(__file__).resolve().parent/'BROAD.json').read_text())
def sep(b,target):
 x=target;free=0
 while x:
  p=x.bit_length();z=b.rows.get(p)
  if z is None:free|=1<<(p-1);x^=1<<(p-1)
  else:x^=z[0]
 assert free
 w=1<<(free.bit_length()-1)
 for i,(v,_) in sorted(b.rows.items()):
  if (v&w).bit_count()%2:w^=1<<(i-1)
 assert (target&w).bit_count()%2 and all((v&w).bit_count()%2==0 for v,_ in b.rows.values())
 return w
def rows_at(p,q,reader):
 c=M[reader][0];cut=idx[reader];ids=[]
 for bank in sorted({c,*grant}):
  for z in stocks[bank]:
   if z in {p,q}:continue
   if z>=680 and idx[z]>=cut:continue
   ids.append(z)
 return ids
out=[];hist=Counter()
for p,q in rrr['joint_survivor_pairs']:
 case=None
 for packet in (p,q):
  uses=[k for k,r in rr.items() if k>=0 and k not in {p,q} and (r>>packet)&1]
  if not uses:continue
  reader=min(uses,key=idx.get);ids=rows_at(p,q,reader);b=Span()
  for i in ids:b.add(vals[i])
  target=vals[reader]
  if b.express(target) is not None:continue
  w=sep(b,target)
  assert all((vals[j]&w).bit_count()%2==0 for j in ids) and (target&w).bit_count()%2==1
  assert not (target&0).bit_count()%2 # deliberately erased separator must fail
  control=Span();control.rows=dict(b.rows)
  for removed in (p,q):
   if idx[removed]<idx[reader]:control.add(vals[removed])
  assert control.express(target) is not None
  case={'p':p,'q':q,'lost_packet':packet,'reader':reader,'receiver':M[reader][0],'reader_position':idx[reader],'granted_charts':sorted(set(grant+[M[reader][0]])),'stock_rows':len(ids),'stock_rank':len(b.rows),'shift_hex':format(w,'x'),'with_old_packets_restored':True}
  break
 assert case is not None
 out.append(case);hist[str(case['reader'])]+=1
print('paired controls and explicit collisions:',len(out),'first reader distribution',dict(hist))
assert (Path(__file__).resolve().parent/'COLLISIONS.json').read_text()==json.dumps({'scope':'frozen other historical stock values, arbitrary computation of pre-retarget C+D first-surviving-reader value; extra stock at listed charts granted free; changed upstream values and changed reader target outside scope','certificates':out},sort_keys=True,indent=2)+'\n'
