import sys,json
from pathlib import Path
from collections import Counter,defaultdict
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import *
M=dict(R);del M[3409];M[3410]=(421,0);M[1583]=(19,182);M[2678]=(182,0)
assert all(ATLAS.grade(*e)>0 for e in M.values())
U=set(ATLAS.body);O0=U-{0};target=op.expected_operator(False);starts=W['start'];ends=W['final']
raw=Counter(M.values());L=[c for c in U if ATLAS.grade(0,c)==1];H=[c for c in U if ATLAS.grade(c,1)==1];K=[c for c in U if ATLAS.grade(c,1)==2]
C={19,24,182,268,421}
ps=[p for p,(a,b) in M.items() if p!=2678 and a!=0 and b!=1 and ({a,b}&C) and ATLAS.grade(a,b)==1]
qs=[p for p,(a,b) in M.items() if p!=2678 and a!=0 and b!=1 and ({a,b}&C) and ATLAS.grade(a,b)==2]
assert len(ps)==7 and len(qs)==14
# Fixed output ranks depend only on the public map, not packet payloads or order.
def rank(S):
 mask=sum(1<<i for i,c in enumerate(starts) if c in S);b=Span()
 for i,c in enumerate(ends):
  if c not in S:b.add(target[i]&mask)
 return len(b.rows)
def crossed(e,S):return int(e[0] in S and e[1] not in S)
def cap(S):return sum(n for e,n in raw.items() if crossed(e,S))
cuts={}
def reg(name,S):cuts.setdefault(frozenset(S),name)
for c in U:
 reg('singleton-'+str(c),{c});reg('co-singleton-'+str(c),U-{c})
for c in L:reg('source-pair-'+str(c),{0,c})
for c in H:reg('sink-pair-'+str(c),U-{1,c})
for c in K:
 neigh={b for (a,b),n in Counter(R.values()).items() if n and a==c and len(ATLAS.body[b])==7}
 neigh.update(a for (a,b),n in Counter(R.values()).items() if n and b==c and len(ATLAS.body[a])==7)
 if len(neigh)==2:reg('sink-four-'+str(c),U-{1,c,*neigh})
# Four-chart cuts around every two-dimensional chart and its native line parents.
for c in U:
 if len(ATLAS.body[c])!=2:continue
 parents={a for (a,b),n in Counter(R.values()).items() if n and b==c and a!=0 and len(ATLAS.body[a])==1}
 if len(parents)==2:reg('source-four-'+str(c),{0,c,*parents})
# Local source/destination adjacency captures each threatened reader cut.
for p,(a,b) in M.items():
 if {a,b}&C:
  for S in ({a,b},{0,a,b},U-{a,b},U-{1,a,b}):reg('local-'+str(p),S)
values=[]
for S,name in cuts.items():
 r=rank(S);n=cap(S);aug=n+crossed((0,19),S)+crossed((421,1),S)
 values.append((S,name,r,n,aug,aug-r))
print('cuts',len(values),'aug violations',sum(delta<0 for *_,delta in values),'tight',sum(delta==0 for *_,delta in values),flush=True)
# Classify the exact local grade-neutral 7 x 14 packet roster.
res=[];separators=Counter()
for p in ps:
 for q in qs:
  if p==q:continue
  for S,name,r,n,aug,delta in values:
   score=aug-crossed(M[p],S)-crossed(M[q],S)
   if score<r:
    side=sorted(S);sidekind='inside'
    if len(side)>len(U)//2:side=sorted(U-set(S));sidekind='outside'
    rec={'p':p,'p_move':M[p],'q':q,'q_move':M[q],'cut':name,'cut_side_kind':sidekind,'cut_charts':side,'required_rank':r,'candidate_capacity':score,'added_graph_capacity':aug,'removed_crossings':[crossed(M[p],S),crossed(M[q],S)]}
    res.append(rec);separators[name]+=1;break
  else:res.append({'p':p,'p_move':M[p],'q':q,'q_move':M[q],'survives':True})
openr=[x for x in res if x.get('survives')]
print('roster p',[(p,M[p]) for p in ps], 'q',[(p,M[p]) for p in qs],flush=True)
print('pairs',len(res),'excluded',len(res)-len(openr),'survive',len(openr),'separators',separators,'open',openr,flush=True)
out={'new_incidences':[[0,19],[421,1]],'kept_rebound_2678':[182,0],'roster_grade1':[{"id":p,"old":M[p]} for p in ps],'roster_grade2':[{"id":q,"old":M[q]} for q in qs],'cuts_examined':len(values),'added_graph_violations':[{"name":name,"rank":r,"capacity":aug} for _,name,r,_,aug,d in values if d<0], 'tested':len(res),'excluded':len(res)-len(openr),'survivors':openr,'results':res,'scope':'One grade-1 and one grade-2 existing contact each incident to 19,24,182,268,421, neither from chart0 nor into chart1; retargeted respectively to 0->19 and 421->1; packet 2678 kept. Public charts and target map fixed. Arbitrary payloads and retiming allowed.'}
assert (Path(__file__).resolve().parent/'LOCAL-CENSUS.json').read_text()==json.dumps(out,sort_keys=True,indent=2)+'\n'
