import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from census import *
from pathlib import Path
import json
allc=[p for p,(a,b) in M.items() if p!=2678 and a!=0 and b!=1 and 0<ATLAS.grade(a,b)<=6]
tight=[item for item in values if item[-1]==0]
records=[];viable=[]
for p in allc:
 for S,name,r,n,aug,d in tight:
  if crossed(M[p],S):
   charts=sorted(S);kind='inside'
   if len(charts)>len(U)//2:kind='outside';charts=sorted(U-set(S))
   records.append({'packet':p,'edge':M[p],'cut':name,'cut_kind':kind,'charts':charts,'required_rank':r,'augmented_capacity':aug,'capacity_after_removal':aug-1})
   break
 else:viable.append(p)
assert len(records)==1787 and len(viable)==26
out={'excluded_count':len(records),'survivor_count':len(viable),'excluded':records,'viable':viable}
assert (Path(__file__).resolve().parent/'EXCLUSIONS.json').read_text()==json.dumps(out,sort_keys=True,indent=2)+'\n'
print('records',len(records),'viable',len(viable))
