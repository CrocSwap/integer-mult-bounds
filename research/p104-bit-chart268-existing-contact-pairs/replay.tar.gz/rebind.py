# Same-grade retiming experiment: this file is not a certified supplier.
import sys, json, gzip, hashlib
from collections import defaultdict,Counter
from pathlib import Path
from heapq import heapify,heappop,heappush
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core import *
import bit_native

def early_schedule(initials,finals,moves,rows):
 # Move 1583 and the re-bound 2678 as soon as their source banks are available;
 # otherwise follow the original input clock. All actual donor edges are honored.
 remaining={}; children=defaultdict(list)
 priority=dict(CLOCK)
 priority[1583]=CLOCK[785]+0.5
 priority[2678]=CLOCK[813]+0.5
 for p in moves:
  parents=[j for j in labels(rows[p]) if j in moves]
  remaining[p]=len(parents)
  for j in parents:children[j].append(p)
 queue=[(priority[p],p) for p in moves if not remaining[p]];heapify(queue);order=[]
 while queue:
  _,p=heappop(queue);order.append(p)
  for q in children[p]:
   remaining[q]-=1
   if not remaining[q]:heappush(queue,(priority[q],q))
 assert len(order)==len(moves)
 return order

def make(corrupt=False):
 M=dict(R); rr=dict(ROWS)
 M[3410]=(421,0); rr[3410]=rr[3409]; del rr[3409],M[3409]
 rr[789]=1<<17
 for k in [785,1584,1934]:
  for p in list(rr):
   if rr[p]>>k&1:rr[p]^=1<<k
 rr.update({785:1<<679,1584:1<<785,1934:1<<1584,~679:1<<1934,1583:(1<<17)^(1<<781),1585:(1<<1583)^(1<<813),1586:1<<1583})
 M[1583]=(19,182)
 # Replace null sink carrier with same-grade early return.
 for k in list(rr):rr[k]&=~(1<<2678)
 M[2678]=(182,0); rr[2678]=(1<<1583)^(1<<813)
 rr[1463]=(1<<519)^(1<<2678)^((0 if corrupt else 1)<<549)
 initials=dict(enumerate(W['start']));finals=dict(enumerate(W['final']))
 bit_native.schedule(initials,finals,M,rr) # local chart and cycle validation
 order=early_schedule(initials,finals,M,rr)
 vals={i:1<<i for i in initials};stocks=defaultdict(list)
 for i,c in initials.items():stocks[c].append(i)
 for p in order:
  vals[p]=xsum(vals[i] for i in labels(rr[p]));stocks[M[p][1]].append(p)
 ss={}
 for c,ids in stocks.items():
  b=Span();[b.add(vals[i],1<<i) for i in ids];ss[c]=b
 targets=op.expected_operator(False);miss=[];fixed=[]
 for i,c in finals.items():
  rep=ss[c].express(targets[i])
  if rep is None:miss.append(i)
  else:
   if xsum(vals[j] for j in labels(rr[~i]))!=targets[i]:fixed.append(i)
   rr[~i]=rep
 word=bit_native.emit_word(W,initials,finals,M,rr,order)
 at=op.Atlas(word['frames']);tr=[op.run_tape(word,at,r) for r in (False,True)]
 bad=[[i for i,(x,y) in enumerate(zip(t.output,op.expected_operator(r))) if x!=y] for r,t in enumerate(tr)]
 assert miss==bad[0]
 _,_,_,_,newclk=bit_native.extract(word)
 clk={p:newclk[len(initials)+i] for i,p in enumerate(order)}
 grade=Counter(v.grade for v in tr[0].packets.values());_,caller,_,_,helpers,P,T,rat=prices.baseline()
 paid,prod=prices.literal.paired_invoice(caller,grade,helpers,Counter(event[0] for event in caller['events']))
 assert prod==T
 result={
  'variant':'without_x549' if corrupt else 'bundle',
  'source_word_gzip_sha256':hashlib.sha256((HERE9/'source/inputs/WORD.json.gz').read_bytes()).hexdigest(),
  'word_canonical_sha256':op.canonical_hash(word),
  'new_route_2678':{'old':list(R[2678]),'new':list(M[2678]),'old_grade':G[2678],'new_grade':ATLAS.grade(*M[2678]),'arrival_row':list(labels(vals[2678])),'intended_A_plus_B':vals[2678]==X[785]^X[813]},
  'packet1464_is_C_plus_D':vals[1464]==X[1464]^X[1584],
  'reader_values_equal_old':{str(p): vals[p]==X[p] for p in [1585,1586,1931,1932,1933,1935,1936]},
  'chart268_new_packet_rows':{str(p):list(labels(vals[p])) for p in [1464,1584,1934]},
  'owner679_both':[t.output[679]==1<<679 for t in tr],
  'owner221_forward':tr[0].output[221]==targets[221],
  'owner221_both':[tr[0].output[221]==op.expected_operator(False)[221],tr[1].output[221]==op.expected_operator(True)[221]],
  'owner411_both':[tr[0].output[411]==op.expected_operator(False)[411],tr[1].output[411]==op.expected_operator(True)[411]],
  'protected_3553_correct':M[3553]==R[3553] and vals[3553]==1<<411,
  'chart1_h_free':all(not(vals[p]>>679&1) for p in stocks[1]),
  'chart1_packet_count':len([p for p in order if M[p][1]==1]),
  'bad':bad,'error_counts':list(map(len,bad)),'corrected_terminal_reads':fixed,
  'clocks':{str(p):clk[p] for p in [781,810,813,1583,2678,1463,1464,1584,1585,1586,1931,1932,1933,1934,1935,1936,3407,3408,3410,3553]},
  'binary_36_margin_at_00388':prices.display(prices.moment(paid,prod,prices.D('0.00388'))),
  'rational_48_margin_at_00388':prices.display(prices.moment({int(k):v for k,v in rat['signed']['paid'].items()},{int(k):v for k,v in rat['signed']['productive'].items()},prices.D('0.00388'))),
  'actual_move_grade_histogram':dict(sorted(grade.items())),
  'dirty':[x.dirty for x in tr],
 }
 if not corrupt:
  assert result['new_route_2678']['old_grade']==result['new_route_2678']['new_grade']==2
  assert result['packet1464_is_C_plus_D'] and all(result['reader_values_equal_old'].values())
  assert all(result['owner679_both']) and all(result['owner221_both']) and all(result['owner411_both'])
  assert result['protected_3553_correct'] and result['chart1_h_free']
  assert clk[813]<clk[2678]<clk[1463]<clk[1464]<clk[1931]
  assert clk[1583]<clk[2678]
  assert len(result['bad'][0]) and len(result['bad'][1])
 else:
  assert not result['packet1464_is_C_plus_D'] and not result['reader_values_equal_old']['1931']
  assert result['protected_3553_correct']
 raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode();gz=gzip.compress(raw,mtime=0)
 dest=Path(__file__).resolve().parent
 if not corrupt:
  saved_gz=(dest/'CPLUS-D-WORD.json.gz').read_bytes()
  assert gzip.decompress(saved_gz)==raw
  result['word_gzip_sha256']=hashlib.sha256(saved_gz).hexdigest()
 return result

if __name__=='__main__':
 out={'bundle':make(),'negative_control':make(True)}
 path=Path(__file__).resolve().parent/'REBIND-RESULT.json';assert path.read_text()==json.dumps(out,sort_keys=True,indent=2)+'\n'
 print(json.dumps({k:{x:v[x] for x in ['word_canonical_sha256','word_gzip_sha256','packet1464_is_C_plus_D','reader_values_equal_old','owner679_both','owner221_forward','owner411_both','protected_3553_correct','chart1_h_free','chart1_packet_count','error_counts','clocks','binary_36_margin_at_00388'] if x in v} for k,v in out.items()},indent=2))
