# Two earlier BIT ingresses into the chart-388 stock

Among the **2,016 ordered pairs** of the 64 originally pulse-accessible, source-influential earlier MOVE sites defined below, no pair permits the proposed three scalar arrivals from charts **560, 283 and 311** to recover all three original chart-388 exit values. The calculation allows arbitrary linear recoding at both chosen MOVE payloads, unchanged MOVE endpoints, free historical shadows, arbitrary linear receiver processing, and late delivery through the first old chart-388 read. It explicitly includes the first payload change's effect on the second sender's history. This is a bounded negative information cut; it produces no legal candidate word, paid saving, or new κ bound.

The ten pairs that pass an optimistic *pooled* single-target test all leave the entire chart-560 stock unchanged. That stock has zero intersection with the space of the three old target values. Since three scalar messages must span that three-dimensional space, each message must lie in the space and be nonzero; chart 560 cannot contribute its required message. This last check applies to **every choice of payloads** at the ten pairs, not just the recorded example payloads.

## Contract and clock boundary

Use the #7830 [scientific head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`](https://github.com/CrocSwap/integer-mult-bounds/pull/7830). The pinned `inputs/WORD.json.gz` has byte SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9` and canonical JSON SHA-256 `d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d`; see [SOURCES.json](SOURCES.json). Clocks are zero-based. The certificate reads no external files and makes no network requests.

The original arrivals into chart 388, before its first read at clock 8954, are precisely:

| Clock | Original MOVE | Grade |
| ---: | --- | ---: |
| 880 | 45 → 388 | 5 |
| 5207 | 283 → 388 | 2 |
| 6326 | 311 → 388 | 2 |

The proposed interface replaces the first with one grade-one scalar arrival from 560 and keeps one scalar arrival from each of 283 and 311. The script checks the rational nested-frame grades `5, 1, 2, 2`. All three old arriving fields are held without use until the first read. The original exits at clocks 8957, 8961 and 8964 are triangular combinations `u1+u2+u3`, `u2+u3`, and `u2`, respectively, where `u1=x43` and all three `u` values are independent. Their exact supports are in [CUT.json](CUT.json). Keeping these three exits means the receiver must recover their full three-dimensional span.

Before clock 8954 the three proposed source stocks have **14 original introductions**, split 2, 6, 6 across 560, 283, 311. The public-coordinate pulse `{43,405}` vanishes on all 14 but changes `u1`. The original word has 1,903 earlier MOVE sites. The ordered-pair roster contains the 64 sites other than 880, 5207, 6326 whose unchanged-word influence reaches at least one of the 14 introductions and whose sender's original history contains a pulse-nonzero row. A changed first payload is permitted to affect both the second owner's original pre-send value and all rows in the second sender's history; 32 of the 2,016 pairs have a changed second-sender history, and in 29 the second moved field itself is affected. These counts refer to a formal unit perturbation, whether or not a particular witness chooses a nonzero delta.

The 64-site screen is **not all possible two-MOVE changes**. In particular, it does not cover a first site with no original source-entry influence that changes a later sender's stock, a site that is pulse-inaccessible in the original history but becomes accessible after the first change, changed MOVE endpoints, new paid arrivals, altered fixed intermediate local operations, changed source charts, more than one scalar per source, or relaxed old chart-388 exit obligations. The sender and receiver histories are granted for free and both later source messages may be sent as late as the first read. These grants make the stated screen more permissive; they do not certify that any witness can be physically built for free.

## Ordered pair calculation

For each candidate first event `i`, a forward unit-impulse interpreter checks all its effects on the 14 original stock introductions against a separately computed reverse sensitivity column. It also records the exact impulse carried by every later incoming row and by each second moved role just before its MOVE. Both of these matter when recoding the second payload.

Write the first additive payload difference as `d`, chosen from the first sender's original history. For an ordered second event `j`, write its original payload as `v_j`. Its currently held unrecoded payload is `v_j + p*d`. Any recoded second payload drawn from the changed sender history has the form `v + t*d`, where the pair `(v,t)` is a linear combination of original history rows augmented by their actual first-edit impulse bits. Thus the second injection relative to the first-edit-only execution is `v + v_j + (t+p)*d`. If `E_k` denotes an original source introduction, `s_i[k]` and `s_j[k]` its two unmodified-word sensitivities, the resulting introduction is

```
E'_k = E_k + s_i[k]*d + s_j[k]*(v + v_j + (t+p)*d).
```

All arithmetic is over GF(2). To test whether `u1` is in the union of the 14 changed source histories, select a combination `z` of their entries. If `z·s_j=0`, the second change vanishes from that combination and the separately checked one-ingress obstruction applies. If `z·s_j=1` but the coefficient of `d` cancels, the same obstruction applies to the second ingress alone. Otherwise the exact necessary and sufficient augmented linear system for this branch is

```
z·E + v + d = u1 + v_j,
z·s_j = 1,
z·s_i + t = 1 + p.
```

The solver grants the first and second sender their entire prior histories, and it grants the receiver the union of all 14 stock rows. It rechecks the one-ingress branches for all 64 sites and independently verifies every site's original moved value and each second owner's augmented pre-send value lie in their respective granted sender spans. Of the 2,016 systems, exactly **10** pass the pooled `u1` condition. The independently written low-pivot [audit.py](audit.py) rebuilds the site roster, forward impulses, and all pair systems directly from the pinned word and reproduces the same ten results.

For each of those ten pairs, both source-introduction sensitivity columns are zero on the two chart-560 entries. Consequently no choice of the two recoded payloads changes that bank under the stated unchanged-upstream-propagation contract. The original rank-two chart-560 bank contains none of the seven nonzero combinations of `u1,u2,u3`. The original baseline and the added-`u1` positive control are checked exactly. Thus the 10 pooled survivors also fail the necessary separate-bank condition. Results and explicit pooled witnesses are in [CUT.json](CUT.json).

## Actual witness replay and restoration screen

The pooled system stores one basis witness for each surviving pair. These are illustrations, not an exhaustive list of that pair's payload choices. [transfer.py](transfer.py) separately runs each witness through the complete 42,958-instruction forward word as a symbolic linear map, using direct scalar overwrites as free oracles. It grants the three original values at the chart-388 arrivals for free, thereby forcing the original three ordered exits, and compares all 680 original and modified public output rows. This reproduces the original 680-row forward operator before comparison.

| Pair of earlier clocks | Public rows still changed after free 388 repair |
| --- | ---: |
| 855, 1572 | 69 |
| 855, 2922 | 69 |
| 855, 2926 | 61 |
| 869, 1572 | 69 |
| 869, 2922 | 69 |
| 869, 2926 | 61 |
| 1561, 1572 | 23 |
| 1572, 2917 | 23 |
| 2917, 2922 | 9 |
| 2917, 2926 | 23 |

At the first original reader of **each** changed ingress in these ten witnesses, its exact original output is absent from the span of all altered recipient-history rows then available, even with free shadows. The exact first-reader clocks, rows, payloads, bank classes and changed public-row indices are in [TRANSFER.json](TRANSFER.json). This is a witness-specific information screen: it does not price or prove the nonexistence of a separate restoration, a different payload choice, or a more general coordinated program rewrite. Direct scalar overwrites are not native word instructions; forward mismatch already prevents these ten oracle illustrations from being accepted as changed native suppliers. No adjoint or lifetime qualification of a candidate is asserted.

## Reproduce

Python 3 with the standard library and assertions enabled:

```sh
sha256sum -c SHA256SUMS
python3 -IB cut.py
python3 -IB audit.py
python3 -IB transfer.py
python3 -IB fault_controls.py
sha256sum -c SHA256SUMS
```

`cut.py` and `transfer.py` deterministically regenerate their checked-in receipts. `audit.py` is a second, low-pivot implementation of the ordered systems and performs an independent direct forward impulse scan to rebuild the 64-site roster. Assertions test source hashes, the 388 chronology, nested grades, single-ingress branches, source-span relations, every forward/reverse source sensitivity, all pooled witnesses, the extra-direction positive control, and original forward public outputs. A source-byte or witness mutation is rejected; see [FAULT-CONTROLS.json](FAULT-CONTROLS.json). No complete paid/productive price, caller replay, finite compiler, or physical qualification is claimed because the optimistic three-source sign check does not pass.

The word and earlier #7830 source retain the contributor credits and license in [NOTICE](NOTICE) and [LICENSE](LICENSE). This two-payload calculation was prepared with substantial OpenAI Codex assistance. It extends the single-earlier-payload scope rather than treating one of its negative screens as a two-payload proof.
