#!/usr/bin/env python3
"""Reject changed source bytes, signatures, witnesses and disabled asserts."""
if not __debug__: raise RuntimeError('assertions must remain enabled')
from pathlib import Path
import json,shutil,subprocess,sys,tempfile
HERE=Path(__file__).resolve().parent
def invoke(root,expected,*args):
    p=subprocess.run([sys.executable,*args],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    return p.returncode != 0 and expected in p.stderr.decode('utf-8',errors='replace')
with tempfile.TemporaryDirectory(prefix='bit388-two-ingress-faults-') as td:
    root=Path(td)
    for name in ('cut.py','audit.py','transfer.py','CUT.json'):
        shutil.copy2(HERE/name,root/name)
    (root/'inputs').mkdir();shutil.copy2(HERE/'inputs/WORD.json.gz',root/'inputs/WORD.json.gz')
    f=root/'inputs/WORD.json.gz';raw=bytearray(f.read_bytes());raw[-1] ^= 1;f.write_bytes(raw)
    source_rejected=invoke(root,'sha256(raw).hexdigest()','-I','-B','cut.py')
    shutil.copy2(HERE/'inputs/WORD.json.gz',f)
    optimized_rejected=invoke(root,'assertions must remain enabled','-O','-I','-B','cut.py')
    receipt=json.loads((root/'CUT.json').read_text());receipt['hits'][0]['first_delta']=[320]
    (root/'CUT.json').write_text(json.dumps(receipt))
    bad_witness_rejected=invoke(root,'chosen==wanted[0]','-I','-B','transfer.py')
    receipt=json.loads((HERE/'CUT.json').read_text());receipt['sites'][0]['signature'] ^= 1<<12
    (root/'CUT.json').write_text(json.dumps(receipt))
    bad_sensitivity_rejected=invoke(root,"affected==inventory[i]['signature']",'-I','-B','audit.py')
    checks={'changed_compressed_word_rejected':source_rejected,'assertions_disabled_rejected':optimized_rejected,
            'changed_first_delta_witness_rejected':bad_witness_rejected,'changed_source_signature_rejected':bad_sensitivity_rejected}
    assert all(checks.values()),checks
    (HERE/'FAULT-CONTROLS.json').write_text(json.dumps(checks,sort_keys=True,indent=2)+'\n')
    print('PASS_FAULT_CONTROLS',len(checks))
