#!/usr/bin/env python3
"""Replay the concrete cut witnesses, and give each an oracle 388 repair.

No legal word is emitted: replacing a MOVE's scalar directly and shadowing
every earlier incoming row are free oracles here.  This deliberately generous
test checks the specific witnesses, not all solutions of each ordered pair.
"""
if not __debug__: raise RuntimeError('assertions must remain enabled')
from collections import defaultdict
from hashlib import sha256
from itertools import product
from pathlib import Path
import gzip, json

HERE=Path(__file__).resolve().parent
raw=(HERE/'inputs/WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw)); p=w['program']; n=w['public']; num=n+w['owned_fields']
cut=json.loads((HERE/'CUT.json').read_text())
assert len(cut['hits'])==10
def value(xs):
    out=0
    for j in xs:out ^= 1<<j
    return out
def bits(x):return [i for i in range(n) if x>>i&1]
class Basis:
    def __init__(self):self.rows={};self.piv=0
    def add(self,x):
        while z:=x&self.piv:x ^= self.rows[z.bit_length()-1]
        if x:self.rows[x.bit_length()-1]=x;self.piv |= 1<<(x.bit_length()-1)
    def has(self,x):
        while z:=x&self.piv:x ^= self.rows[z.bit_length()-1]
        return x==0
def independent3(m):
    b=Basis()
    for x in m:b.add(x)
    return len(b.rows)==3
def first_reader(clock,role):
    for k in range(clock+1,len(p)):
        e=p[k]
        if e[0]=='ADD' and e[2]==role:return k
        # The witnessed roles do not swap, move, or clear before first read.
        assert not (e[0] in ('CLEAR','MOVE') and e[1]==role)
        assert not (e[0]=='SWAP' and role in e[1:3])
    raise ValueError((clock,role))

outs=[]
for hit in cut['hits']:
    first,second=hit['first'],hit['second']; ri=p[first][1];rj=p[second][1]
    reader={first_reader(first,ri):'first',first_reader(second,rj):'second'}
    assert len(reader)==2
    tags=w['start'][:]+[None]*w['owned_fields']
    orig=[1<<k for k in range(n)]+[0]*w['owned_fields']; alt=orig[:]
    hist=defaultdict(list)
    for k,c in enumerate(w['start']):hist[c].append((-1-k,alt[k]))
    first_reads={}; bank_hist=None; wanted=None; old_payload={}; alt_payload={}
    first_delta=value(hit['first_delta']); second_payload=value(hit['second_replacement'])
    oracle={880,5207,6326}; oracle_changes={}; exits={}
    for k,(op,r,*a) in enumerate(p):
        if k==8954:
            wanted=(orig[927],orig[2023],orig[2190]); assert wanted[0]==1<<43
            bank_hist={chart:list(hist[chart]) for chart in (560,283,311)}
        if k in reader:
            label=reader[k]; assert op=='ADD'
            q,c=a; b=Basis()
            for _,v in hist[c]: b.add(v)
            desired=orig[r]^orig[q]
            first_reads[label]={'clock':k,'operation':p[k],
                'original_scalar':bits(orig[q]), 'recoded_scalar':bits(alt[q]),
                'original_output':bits(desired),
                'free_history_contains_original_scalar':b.has(orig[q]),
                'free_history_contains_original_output':b.has(desired),
                'available_history_rank':len(b.rows)}
        if op=='INIT':
            assert tags[r] is None;tags[r]=a[0];orig[r]=alt[r]=0
        elif op=='CLEAR':
            assert tags[r]==a[0];tags[r]=None;orig[r]=alt[r]=0
        elif op=='SWAP':
            q=a[0];tags[r],tags[q]=tags[q],tags[r];orig[r],orig[q]=orig[q],orig[r];alt[r],alt[q]=alt[q],alt[r]
        elif op=='ADD':
            q,c=a;assert tags[r]==tags[q]==c;orig[r]^=orig[q];alt[r]^=alt[q]
        elif op=='MOVE':
            s,d=a;assert tags[r]==s;tags[r]=d
            if k in (first,second):
                old_payload[str(k)]=bits(orig[r])
                if k==first:alt[r]^=first_delta
                else:alt[r]=second_payload
                alt_payload[str(k)]=bits(alt[r])
            if k in oracle:
                # Optimistically grant the exact original value on all three
                # chart-388 deliveries for free. This simultaneously restores
                # the ordered 388 outputs; it is not a realizable price claim.
                oracle_changes[str(k)]=bits(alt[r]^orig[r]);alt[r]=orig[r]
            hist[d].append((k,alt[r]))
            if k in (8957,8961,8964):exits[str(k)]=alt[r]==orig[r]
        else:raise ValueError(op)
    assert bank_hist is not None and all(exits.values())
    assert tags==w['final']+[None]*w['owned_fields']
    expected=[(1<<k) ^ ((1<<(k-111)) if 111<=k<222 else 0) for k in range(n)]
    assert orig[:n]==expected and not any(orig[n:]) and not any(alt[n:])
    classes={}
    for chart,rows in bank_hist.items():
        b=Basis()
        for _,v in rows:b.add(v)
        reachable=[]
        for mask in range(1,8):
            t=0
            for q in range(3):
                if mask>>q&1:t^=wanted[q]
            if b.has(t):reachable.append(mask)
        classes[str(chart)]={'history_count':len(rows),'history_rank':len(b.rows),'nonzero_target_classes':reachable}
    choices=list(product(*(classes[str(c)]['nonzero_target_classes'] for c in (560,283,311))))
    valid=[x for x in choices if independent3(x)]
    allbanks=Basis()
    for rows in bank_hist.values():
        for _,v in rows:allbanks.add(v)
    actual_entries=[]
    for entry in cut['sender_entries']:
        stock={clock:v for clock,v in bank_hist[entry['chart']]}
        actual_entries.append(stock[entry['clock']])
    chosen=0
    for q in hit['source_entry_selection']:chosen ^= actual_entries[q]
    assert chosen==wanted[0]
    mismatch=[k for k in range(n) if orig[k]!=alt[k]]
    assert len(mismatch)>0 and not valid
    assert all(not x['free_history_contains_original_output'] for x in first_reads.values())
    outs.append({'first':first,'second':second,'old_payloads':old_payload,'new_payloads':alt_payload,
        'free_history_388_union_contains_each_old_target':[allbanks.has(v) for v in wanted],
        'per_bank':classes,'one_payload_per_bank_spans_three_targets':bool(valid),
        'one_payload_target_masks_example':list(valid[0]) if valid else None,
        'reader_restoration_screen':first_reads,
        'oracle_repairs_on_388_arrival_delta':oracle_changes,
        'protected_388_exits_equal':exits,'public_row_mismatch_count_after_388_oracle':len(mismatch),
        'public_row_mismatches_after_388_oracle':mismatch})
out={'scope':'Ten cut.py basis witnesses only; direct free payload overwrites and free all-history shadowing; three original 388 arrival values granted for free; exact forward symbolic public endpoints and ordered exits; no physical word or priced restoration',
    'word_gzip_sha256':sha256(raw).hexdigest(),'witnesses':outs}
(HERE/'TRANSFER.json').write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
for a in outs:
    print(a['first'],a['second'],'union',a['free_history_388_union_contains_each_old_target'],
          'bank classes',[a['per_bank'][str(c)]['nonzero_target_classes'] for c in (560,283,311)],
          'bank basis',a['one_payload_per_bank_spans_three_targets'],
          'first reads',[(v['clock'],v['free_history_contains_original_output']) for v in a['reader_restoration_screen'].values()],
          'public mismatches',a['public_row_mismatch_count_after_388_oracle'])
