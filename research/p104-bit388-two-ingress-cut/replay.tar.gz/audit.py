#!/usr/bin/env python3
"""Independent low-pivot verification of the ordered-pair linear systems."""
if not __debug__: raise RuntimeError('assertions must remain enabled')
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import gzip,json
P=Path(__file__).resolve().parent
raw=(P/'inputs/WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw)); prog=w['program']; n=w['public']; end=8954
out=json.loads((P/'CUT.json').read_text()); inventory={s['clock']:s for s in out['sites']}
assert len(inventory)==64
class LowBasis:
    def __init__(self):self.p={}
    def add(self,vector):
        while vector:
            low=vector & -vector
            if low not in self.p:self.p[low]=vector;return
            vector ^= self.p[low]
    def contains(self,vector):
        while vector:
            low=vector & -vector
            if low not in self.p:return False
            vector ^= self.p[low]
        return True

# Rebuild original source histories directly, with a different row reducer.
bank=[1<<i for i in range(n)]+[0]*w['owned_fields']; tags=w['start'][:]+[None]*w['owned_fields']
hist=defaultdict(list); sites={}; entries=[]; possible=[]
for r,c in enumerate(w['start']):hist[c].append((-1-r,bank[r]))
for c,(op,r,*a) in enumerate(prog[:end]):
    if op=='INIT':assert tags[r] is None; tags[r]=a[0];bank[r]=0
    elif op=='CLEAR':assert tags[r]==a[0];tags[r]=None;bank[r]=0
    elif op=='SWAP':q=a[0];tags[r],tags[q]=tags[q],tags[r];bank[r],bank[q]=bank[q],bank[r]
    elif op=='ADD':q,chart=a;assert tags[r]==tags[q]==chart;bank[r]^=bank[q]
    else:
        assert op=='MOVE';s,d=a;assert tags[r]==s
        if c not in (880,5207,6326) and any(((v & ((1<<43)|(1<<405))).bit_count()%2) for _,v in hist[s]):
            possible.append((c,bank[r],tuple(hist[s])))
        if c in inventory:sites[c]=(bank[r],tuple(hist[s]))
        tags[r]=d;hist[d].append((c,bank[r]))
        if d in (560,283,311):entries.append((c,d,bank[r]))
assert len(entries)==14
for chart in (560,283,311):
    assert hist[chart]==[(clock,value) for clock,dest,value in entries if dest==chart]
assert [(x['clock'],x['chart']) for x in out['sender_entries']]==[(c,d) for c,d,_ in entries]
for q,(_,_,v) in enumerate(entries):
    assert out['sender_entries'][q]['support']==[i for i in range(n) if v>>i&1]
targets=(bank[927],bank[2023],bank[2190]);assert targets[0]==1<<43
assert out['target_supports']==[[i for i in range(n) if v>>i&1] for v in targets]
entry_index={c:q for q,(c,_,_) in enumerate(entries)}
actual_hits=[]; stock_effects=role_effects=0; impulses={}
for i,vi,hi in possible:
    # Scalar impulse replay; keep the signal carried by every arrival and by
    # each prospective second owner's role immediately before its MOVE.
    effect=[0]*len(bank); arrivals={}; before={}; affected=0
    for c in range(i,end):
        op,r,*a=prog[c]
        if op=='ADD':effect[r] ^= effect[a[0]]
        elif op=='SWAP':q=a[0];effect[r],effect[q]=effect[q],effect[r]
        elif op in ('INIT','CLEAR'):effect[r]=0
        else:
            assert op=='MOVE'; before[c]=effect[r]
            if c==i:effect[r] ^= 1
            arrivals[c]=effect[r]
            if c in entry_index:affected |= effect[r]<<entry_index[c]
    if affected:
        impulses[i]=(arrivals,before,affected)
assert sorted(impulses)==sorted(inventory)
for i,(_,_,affected) in impulses.items():assert affected==inventory[i]['signature']
clocks=sorted(sites)
for i in clocks:
    # Recheck both the unaltered-stock and every one-ingress branch using a
    # low-pivot solver independent of the primary high-pivot implementation.
    one=LowBasis(); sig=inventory[i]['signature']
    for k,(_,_,row) in enumerate(entries):one.add(row | (((sig>>k)&1)<<n))
    for _,row in sites[i][1]:one.add(row)
    assert not one.contains(targets[0] | (1<<n))
for pos,i in enumerate(clocks):
    arrivals,before,affected=impulses[i]
    vi,hi=sites[i]
    for j in clocks[pos+1:]:
        vj,hj=sites[j];p=before[j]
        stock_effects += bool(any(arrivals.get(c,0) for c,_ in hj if c>=0))
        role_effects += p
        ai=inventory[i]['signature'];aj=inventory[j]['signature']; matrix=LowBasis()
        for k,(_,_,row) in enumerate(entries):matrix.add(row | (((ai>>k)&1)<<n) | (((aj>>k)&1)<<(n+1)))
        for c,row in hj:matrix.add(row | ((arrivals.get(c,0) if c>=0 else 0)<<n))
        for c,row in hi:matrix.add(row)
        rhs=(targets[0]^vj) | ((1^p)<<n) | (1<<(n+1))
        if matrix.contains(rhs):actual_hits.append([i,j])
assert actual_hits==[[h['first'],h['second']] for h in out['hits']]
assert stock_effects==32 and role_effects==29 and len(actual_hits)==10
# Verify the unchanged 560 bank has trivial target intersection, then verify
# that every surviving pair is unable to change either of its two entries.
base=LowBasis(); bank_mask=0
for k,(_,chart,row) in enumerate(entries):
    if chart==560:base.add(row);bank_mask |= 1<<k
assert len(base.p)==2 and bank_mask==out['chart_560_entry_mask']
for m in range(1,8):
    x=0
    for k in range(3):
        if m>>k&1:x ^= targets[k]
    assert not base.contains(x)
for i,j in actual_hits:assert not ((inventory[i]['signature']|inventory[j]['signature']) & bank_mask)
print('PASS_LOW_PIVOT_ALL_2016', 'hits',len(actual_hits),'changed_stocks',stock_effects,'changed_roles',role_effects)
