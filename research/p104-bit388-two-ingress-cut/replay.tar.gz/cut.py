#!/usr/bin/env python3
"""Ordered, two-original-ingress information cut for BIT chart 388.

This is an optimistic test, not a construction: original sender-introduction
rows can be shadowed at zero cost, and the 14 stock rows can be pooled.  The
first edit may change the second sender's stock before the second edit.
"""
if not __debug__:
    raise RuntimeError('assertions must remain enabled')
from collections import Counter, defaultdict
from hashlib import sha256
from pathlib import Path
from fractions import Fraction
import gzip
import json

HERE = Path(__file__).resolve().parent
raw = (HERE/'inputs'/'WORD.json.gz').read_bytes()
assert sha256(raw).hexdigest() == 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w = json.loads(gzip.decompress(raw))
assert sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest() == 'd3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
N = w['public']; program = w['program']; end = 8954
srcs = (560,283,311); omit = {880,5207,6326}; pulse = (1<<43)|(1<<405)
assert N == 680
def rank_rational(rows):
    rows = [[Fraction(x) for x in row] for row in rows]
    i=0
    for col in range(8):
        pivot=next((k for k in range(i,len(rows)) if rows[k][col]),None)
        if pivot is None:continue
        rows[i],rows[pivot]=rows[pivot],rows[i]
        scale=rows[i][col];rows[i]=[x/scale for x in rows[i]]
        for k in range(i+1,len(rows)):
            scale=rows[k][col]
            if scale:rows[k]=[x-scale*y for x,y in zip(rows[k],rows[i])]
        i+=1
        if i==len(rows):break
    return i
def frame(chart):
    x=w['frames'][str(chart)];b=x['B'];a=x['A']
    assert len(b)==x['dim'] and len(b)+len(a)==8 and rank_rational(b+a)==8
    assert all(sum(Fraction(z)*Fraction(y) for z,y in zip(row,normal))==0 for row in b for normal in a)
    return b,a
def grade(c,d):
    bc,ac=frame(c);bd,ad=frame(d)
    if len(bc)>len(bd):bc,bd,ac,ad=bd,bc,ad,ac
    assert all(sum(Fraction(z)*Fraction(y) for z,y in zip(row,normal))==0 for row in bc for normal in ad)
    return len(bd)-len(bc)
assert [grade(a,b) for a,b in ((45,388),(560,388),(283,388),(311,388))]==[5,1,2,2]
def bits(x):
    return [j for j in range(N) if x>>j&1]
class Basis:
    def __init__(self): self.rows = {}; self.piv = 0
    def add(self, x, label):
        while z := x & self.piv:
            row, mask = self.rows[z.bit_length()-1]; x ^= row; label ^= mask
        if x:
            k = x.bit_length()-1; self.rows[k] = (x,label); self.piv |= 1<<k
    def solve(self, x):
        label = 0
        while z := x & self.piv:
            row, mask = self.rows[z.bit_length()-1]; x ^= row; label ^= mask
        return (x,label)

# Independent symbolic forward pass. Each history item is an earlier incoming
# row, indexed by event clock (public roles get unique negative identifiers).
values = [1<<i for i in range(N)] + [0]*w['owned_fields']
tags = w['start'][:] + [None]*w['owned_fields']
history = defaultdict(list); entries = []; moves = []
for r,c in enumerate(w['start']): history[c].append((-1-r,r,1<<r))
for i,(op,r,*a) in enumerate(program[:end]):
    if op == 'INIT': assert tags[r] is None; tags[r] = a[0]; values[r] = 0
    elif op == 'CLEAR': assert tags[r] == a[0]; tags[r] = None; values[r] = 0
    elif op == 'SWAP':
        p = a[0]; assert tags[r] is not None and tags[p] is not None
        tags[r],tags[p] = tags[p],tags[r]; values[r],values[p] = values[p],values[r]
    elif op == 'ADD':
        p,c = a; assert r != p and tags[r] == tags[p] == c; values[r] ^= values[p]
    elif op == 'MOVE':
        s,d = a; assert tags[r] == s
        moves.append((i,r,s,d,values[r],tuple(history[s])))
        tags[r] = d; history[d].append((i,r,values[r]))
        if d in srcs: entries.append((i,r,d,values[r]))
    else: raise ValueError(op)
assert len(entries) == 14 and all((x & pulse).bit_count()%2 == 0 for _,_,_,x in entries)
for chart in srcs:
    assert history[chart] == [(clock,role,value) for clock,role,dest,value in entries if dest==chart]
assert [k for k,_,_ in history[388]] == [880,5207,6326]
for clock,role in ((880,927),(5207,2023),(6326,2190)):
    for e in program[clock+1:end]:
        accessed=e[1:3] if e[0] in ('ADD','SWAP') else e[1:2]
        assert role not in accessed
assert program[8954:8965] == [
    ['ADD',2583,927,388],['ADD',2583,2023,388],['ADD',2583,2190,388],['MOVE',2583,388,517],
    ['INIT',2584,388],['ADD',2584,2023,388],['ADD',2584,2190,388],['MOVE',2584,388,560],
    ['INIT',2585,388],['ADD',2585,2023,388],['MOVE',2585,388,1]]
u = tuple(values[r] for r in (927,2023,2190)); assert u[0] == 1<<43

# Reverse sensitivities from each original source entry to each MOVE. A later
# independent forward impulse will also record the actual second-sender stock.
at = {clock:k for k,(clock,_,_,_) in enumerate(entries)}
lane = [0]*len(values); signature = {}
for i in range(end-1,-1,-1):
    op,r,*a = program[i]
    if i in at: lane[r] ^= 1<<at[i]
    if op == 'ADD': lane[a[0]] ^= lane[r]
    elif op == 'SWAP': p = a[0]; lane[r],lane[p] = lane[p],lane[r]
    elif op in ('INIT','CLEAR'): lane[r] = 0
    elif op == 'MOVE': signature[i] = lane[r]
    else: raise ValueError(op)
sites = [m for m in moves if m[0] not in omit and signature[m[0]] and
         any((v&pulse).bit_count()%2 for _,_,v in m[5])]
assert len(moves) == 1903 and len(sites) == 64

# Independently recheck the one-edit branch, now restricted to these sites.
# If the effective coefficient of the first edit is zero, a two-edit u1
# recovery would also be a one-edit recovery at the second site.
for i,r,s,d,v,h in sites:
    b = Basis()
    sender = Basis()
    for _,_,row in h:sender.add(row,0)
    assert sender.solve(v)[0]==0
    for k,(_,_,_,row) in enumerate(entries):b.add(row | (((signature[i]>>k)&1)<<N),0)
    for _,_,row in h:b.add(row,0)
    assert b.solve(u[0] | (1<<N))[0] != 0

# One scalar per bank spanning a three-dimensional target requires each
# scalar to be a nonzero member of that target space. Authenticate that the
# original chart-560 bank has no such member.
target_basis=Basis()
for row in u:target_basis.add(row,0)
assert len(target_basis.rows)==3
bank_560 = Basis(); bank_560_mask=0
for k,(_,_,chart,row) in enumerate(entries):
    if chart==560:bank_560.add(row,0);bank_560_mask |= 1<<k
assert len(bank_560.rows)==2
for mask in range(1,8):
    row=0
    for k in range(3):
        if mask>>k&1:row ^= u[k]
    assert bank_560.solve(row)[0] != 0
# Positive control: granting u1 to this bank is outside the proposal but must
# make the zero-intersection assertion fail.
positive = Basis()
for _,_,chart,row in entries:
    if chart==560:positive.add(row,0)
positive.add(u[0],0)
assert positive.solve(u[0])[0] == 0

def forward_impulse(first_clock):
    """For a unit additive payload change, return arrival and send signals."""
    signal = [0]*len(values); arrivals = {}; pre = {}; induced = [0]*len(entries)
    for i in range(first_clock,end):
        op,r,*a = program[i]
        if op == 'ADD': signal[r] ^= signal[a[0]]
        elif op == 'SWAP': p = a[0]; signal[r],signal[p] = signal[p],signal[r]
        elif op in ('INIT','CLEAR'): signal[r] = 0
        elif op == 'MOVE':
            pre[i] = signal[r]
            if i == first_clock: signal[r] ^= 1
            arrivals[i] = signal[r]
            if i in at: induced[at[i]] = signal[r]
        else: raise ValueError(op)
    got = sum(x<<j for j,x in enumerate(induced))
    assert got == signature[first_clock], (first_clock,got,signature[first_clock])
    return arrivals,pre

counts = Counter(); hits = []; indirect = 0
for left, first in enumerate(sites):
    i,ri,si,di,vi,hi = first
    arrivals,pre = forward_impulse(i)
    for second in sites[left+1:]:
        j,rj,sj,dj,vj,hj = second
        assert i < j
        counts['ordered_pairs'] += 1
        p = pre[j]
        affected_stock = sum(arrivals.get(k,0) for k,_,_ in hj if k >= 0)
        sender_augmented=Basis()
        for k,r,row in hj:
            sender_augmented.add(row | ((arrivals.get(k,0) if k>=0 else 0)<<N),0)
        assert sender_augmented.solve(vj | (p<<N))[0]==0
        if affected_stock: counts['pairs_with_changed_second_sender_stock'] += 1
        if p: counts['pairs_with_changed_second_moved_role'] += 1
        # The ordinary one-edit cut rules out a zero effective coefficient of
        # delta1. For the remaining branch:
        #  z.E + v + delta1 = u1 + vj,
        #  z.sig_j=1, z.sig_i + t = 1 + p,
        # where (v,t) is a combination of (original second-history row,
        # its actual first-edit impulse). These are necessary and sufficient
        # for recovering u1 from the pooled altered 14 source rows, for this
        # nonzero-first-delta branch. Histories are granted for free.
        b = Basis(); parts = []
        def add(v, kind, data):
            k = len(parts); parts.append((kind,data)); b.add(v,1<<k)
        for k,(_,_,_,v) in enumerate(entries):
            add(v | (((signature[i]>>k)&1)<<N) | (((signature[j]>>k)&1)<<(N+1)), 'entry',k)
        for k,r,v in hj:
            t = arrivals.get(k,0) if k >= 0 else 0
            add(v | (t<<N), 'second_history',(k,r,v,t))
        for k,r,v in hi: add(v,'first_history',(k,r,v))
        target = (u[0]^vj) | ((1^p)<<N) | (1<<(N+1))
        rem, mask = b.solve(target)
        if rem: continue
        counts['pooled_u1_recoverable'] += 1
        chosen = [parts[k] for k in range(len(parts)) if mask>>k&1]
        z = 0; v = 0; t = 0; delta = 0
        for kind, data in chosen:
            if kind == 'entry': z ^= 1<<data
            elif kind == 'second_history': _,_,row,q = data; v ^= row; t ^= q
            else: _,_,row = data; delta ^= row
        assert sum((signature[j]>>k&1) for k in range(14) if z>>k&1)%2 == 1
        assert (sum((signature[i]>>k&1) for k in range(14) if z>>k&1)%2)^t == 1^p
        new_payload_2 = v ^ (delta if t else 0)
        additional_2 = new_payload_2 ^ vj ^ (delta if p else 0)
        actual_entries = [row ^ (delta if signature[i]>>k&1 else 0) ^
                          (additional_2 if signature[j]>>k&1 else 0)
                          for k,(_,_,_,row) in enumerate(entries)]
        actual = 0
        for k in range(14):
            if z>>k&1: actual ^= actual_entries[k]
        assert actual == u[0]
        # This is independent of the chosen witness: neither of the two
        # unmodified-word influence columns touches a 560 stock entry.
        # Hence *every* payload choice for this pair leaves stock 560 fixed.
        assert not (signature[i] & bank_560_mask) and not (signature[j] & bank_560_mask)
        hit = {'first':i,'second':j,'first_move':list(program[i]),'second_move':list(program[j]),
               'first_signature':signature[i],'second_signature':signature[j],
               'first_and_second_560_influence_zero':True,
               'first_delta':bits(delta),'second_replacement':bits(new_payload_2),
               'first_influence_on_second_role':p,'second_history_influenced_rows':affected_stock,
               'source_entry_selection':[k for k in range(14) if z>>k&1],
               'second_history_terms':[{'clock':d[0],'role':d[1],'support':bits(d[2]),'first_impulse':d[3]} for kind,d in chosen if kind=='second_history'],
               'first_history_terms':[{'clock':d[0],'role':d[1],'support':bits(d[2])} for kind,d in chosen if kind=='first_history']}
        hits.append(hit)
assert len(hits)==10
result = {'word_gzip_sha256':sha256(raw).hexdigest(),
          'word_canonical_sha256':'d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d',
          'scope':'64 originally pulse-capable influential earlier MOVE sites; unchanged endpoints; original first-reader demands; free sender histories and pooled 14 source stocks; exact first-edit influence on second sender history; no restoration or pricing',
          'sites':[{'clock':i,'role':r,'source':s,'destination':d,'signature':signature[i]} for i,r,s,d,v,h in sites],
          'sender_entries':[{'index':k,'clock':i,'role':r,'chart':s,'support':bits(v)} for k,(i,r,s,v) in enumerate(entries)],
          'target_supports':[bits(v) for v in u],
          'chart_560_entry_mask':bank_560_mask,'chart_560_original_stock_rank':len(bank_560.rows),
          'three_target_rank':len(target_basis.rows),'chart_560_target_intersection_rank':0,
          'rational_nested_leg_grades':{'45_to_388':5,'560_to_388':1,'283_to_388':2,'311_to_388':2},
          'one_ingress_branch_rechecked_for_all_64':True,'added_u1_positive_control':True,
          'no_three_scalar_reconstruction_for_any_ordered_pair':True,
          'counts':dict(counts),'hits':hits}
(HERE/'CUT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result['counts'],sort_keys=True))
