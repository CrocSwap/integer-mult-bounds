# Same-start 679-owner interface exchange

This finite screen and literal control find **no positive signed change** in the stated one-contact exchange. The least expensive selected exchange adds one grade-2 contact per native call and costs `36 H(2)` over the complete 36-call caller, where `H(r) = r^(1−κ)`. The one-contact literal replay restores all 679 outputs in both directions but discards an additional live scratch value. A separate two-contact construction transports the donor out and back and returns that **additional** scratch to zero in both directions, at twice the contact price. Neither construction proves a physical supplier or a new κ bound.

## Pinned word and pair gate

The starting word is the original-owner-649 specialization in [#7912 at `83ece5a62d3addbee45bad9594ef4809851b833b`](https://github.com/CrocSwap/integer-mult-bounds/tree/83ece5a62d3addbee45bad9594ef4809851b833b/research/p104-bit-adjoint-multidonor-cut). Its canonical SHA-256 is `09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be`. The full #7830 comparator, actual caller, and Round 5 controls 04, 10, and 20 are pinned in `SOURCES.json`. Original 649 is removed, original 650 is now address 649, and original owner 341 remains present; Round 5's owner-341-removed two-hole word is a separate control.

The census excludes original owner 411 from selection. Of 456 remaining helper owners, 85,104 unordered pairs start at the same chart. Of these, 75,499 have identical end-chart tags and are excluded; this prevents counting a same-tag permutation as an interface exchange. A further 9,336 distinct-end pairs touch chart 1. The remaining **269** pairs have distinct nonsink ends, and all start at chart 0. Each consists of independent public input coordinates. Eleven have directly nested end charts: one of grade 2, nine grade 3 and one grade 5.

For each pair, the gate enumerates all five nonidentity elements of `GL(2,F₂)` and both choices of terminal to repair last: 2,690 direction cases. It freezes the original native packet program, all public endpoint tags and order, and the live terminal stock. The stock snapshot is at native clock 40074, after the final public swap and before paid-packet retirement; it includes all 679 public fields and 2,873 packet fields at their actual chart tags. Linear combinations of this stock may be borrowed freely. A new contact may originate at any nested, non-chart-1 stock chart and ends at one of the two nonsink terminal charts. The other terminal must first be repaired by local additive operations; each terminal repair may also borrow its local stock. The gate checks the exact GF(2) witness and excludes the target bank as its own donor.

| Gate outcome | Direction cases |
| --- | ---: |
| Other end cannot be restored by the permitted local additions | 2,152 |
| Other end is repairable, but no eligible paid terminal contact is found | 514 |
| A contact passes the stock gate | 24 |

The 24 gate witnesses have minimum contact grades 2, 3 and 5 in counts 2, 18 and 4 respectively; two grade-5 directions use packet stock rather than a direct leg between the pair's end charts. They are **algebraic stock witnesses**, not 24 independently compiled physical circuits. The included literal word instantiates the least-priced case. Fixed endpoints give exactly unchanged productive grades, so the 24 cases have strictly negative complete signed change if the new contact is charged. `RESULT.json` contains each witness, source and destination banks, and directed intervals at both trial rates.

This gate does not exclude a change to or removal of an original packet, an intermediate recoding, a different timing, non-additive terminal exchange, cross-start action, altered endpoint tags, or a new physical supplier. It is distinct from both the Round 5 second-owner surrender, which removes a productive owner, and the chart-1-only sink-retarget cuts.

## Literal least-price exchange

Original owners **341** and **661** are compiled addresses 341 and 660; they have common start chart 0, end charts 374 and 520, and target grades 6 and 4. The input shear replaces `x661` by `x661 + x341`. The paid terminal contact sends the `x341` value from 374 to 520; adding it there restores the original output label. The endpoints and owner ordering remain exactly those of #7912. Chart 374 is nested with chart 520 and the contact has grade 2; the rational frame and ternary-unit checks pass.

`ONE-CONTACT-WORD.json.gz` executes the shear and one terminal MOVE. It leaves the new transport scratch nonzero at retirement in each orientation. `TWO-CONTACT-WORD.json.gz` instead swaps the donor into the new scratch, sends it to 520, performs the terminal XOR, sends it back to 374, and swaps it home. Its extra scratch closes at zero in both orientations. Both words replay all `679×679` public coefficients forward and transposed, retain every one of the 222 main owners, and preserve original owner 411 and packet 3553. The latter is compiled field 3551, a pure owner-411 sender on forward route `509 → 1`; it retains its original packet order. The 36 reconstructed caller bindings include the exact candidate word hash, all 457 helper identities and every retained and new paid move; their canonical digests are in the receipt.

The baseline word already has 3,552 nonzero private retirements in each orientation. The one-contact word has 3,553 in each; the two-contact word has 3,552 in each. Cleaning the added scratch **does not clean the inherited retirements**. The modeled ordinary and backing counts for both words are below the inherited raw allowances, but do not establish owned erasure, physical routing, or the remaining supplier and consumer premises.

## Full signed price

Each table entry is a directed interval. The control's signed margin already equals the #7830 comparator's because the grade-4 paid and productive deletions cancel.

| κ | One-contact signed change | One-contact full margin | Two-contact signed change | Two-contact full margin |
| --- | --- | --- | --- | --- |
| `0.003879928046156` | [`-71.806626137241371367089356645596`, `-71.806626137241371367089356645595`] | [`-71.806626138008372869520486907060`, `-71.806626138008372869520486907059`] | [`-143.613252274482742734178713291191`, `-143.613252274482742734178713291190`] | [`-143.613252275249744236609843552655`, `-143.613252275249744236609843552654`] |
| `0.003879929046155` | [`-71.806626087468860704348696633262`, `-71.806626087468860704348696633261`] | [`-71.807011214785474570789750772735`, `-71.807011214785474570789750772734`] | [`-143.613252174937721408697393266524`, `-143.613252174937721408697393266523`] | [`-143.613637302254335275138447405997`, `-143.613637302254335275138447405996`] |

The full paid histograms change by `{2:+36}` and `{2:+72}`; neither productive histogram changes. These are finite signed tariffs under the inherited caller and do not establish its full-bound premises.

## Reproduction and corruption controls

Python 3.12 and the standard library:

```sh
python3 -I -B verify.py
```

The verifier checks the complete inventory, rebuilds the census and words in a temporary copy, compares the receipt and canonical word bytes, and independently checks the directed margins using decimal interval arithmetic. The built-in controls reject a stale owner-649 binding, equal-grade owner relabeling, omission of the input shear or terminal XOR, omission of the new scratch retirement, and an invoice that omits the added paid contact. The same-tag pair 222/223 is explicitly rejected by the census. For an optional provenance comparison against the exact upstream archive, use:

```sh
python3 -I -B verify.py --upstream-archive /path/to/7912-replay.tar.gz
```

The pinned source archive, input notices and inherited license are identified in `SOURCES.json` and `inputs/`. No external service is required for the offline replay.
