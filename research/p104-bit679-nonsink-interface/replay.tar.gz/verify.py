#!/usr/bin/env python3
"""Inventory, relocatable rebuild, independent price and optional provenance."""
import argparse,gzip,hashlib,json,shutil,subprocess,sys,tarfile,tempfile
from collections import Counter
from decimal import Decimal
from pathlib import Path
HERE=Path(__file__).resolve().parent

def need(test,message):
 if not test:raise ValueError(message)
def digest(raw):return hashlib.sha256(raw).hexdigest()
def inventory():
 for line in (HERE/'SHA256SUMS').read_text().splitlines():
  sha,name=line.split('  ',1);p=HERE/name
  need(p.is_file() and digest(p.read_bytes())==sha,'inventory '+name)
def upstream(path):
 raw=path.read_bytes();need(digest(raw)=='87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096','upstream archive hash')
 with tarfile.open(path,'r:gz') as t:
  for name in ('WORD.json.gz','EFREE-CALLER.json.gz','BIT.json','LICENSE','NOTICE-7786','NOTICE-7830','NOTICE-PAID-BIRTHS','literal.py','price.py'):
   member=t.extractfile('./inputs/'+name);need(member is not None and member.read()==(HERE/'inputs'/name).read_bytes(),'upstream member '+name)
  member=t.extractfile('./ZERO-CONTROL-WORD.json.gz');need(member is not None and member.read()==(HERE/'inputs/ZERO-CONTROL-WORD.json.gz').read_bytes(),'upstream 679 control')
def margins():
 sys.path.insert(0,str(HERE));import replay_bit as b
 result=json.loads((HERE/'RESULT.json').read_bytes())
 for name,receipt in result['examples'].items():
  paid=Counter({int(k):v for k,v in receipt['full_paid'].items()});targets=Counter({int(k):v for k,v in receipt['full_targets'].items()})
  for rate,prices in result['complete_price'][name]['trials'].items():
   lo,hi=b.margin(targets,paid,rate);a,c=map(Decimal,prices['full_candidate_margin'])
   need(a<=lo<=hi<=c,'independent decimal full signed interval '+name+' '+rate)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--upstream-archive',type=Path);args=parser.parse_args()
 inventory()
 if args.upstream_archive:upstream(args.upstream_archive)
 margins()
 with tempfile.TemporaryDirectory(prefix='p104-679-interface-') as d:
  tmp=Path(d)
  shutil.copytree(HERE/'inputs',tmp/'inputs');shutil.copy2(HERE/'screen.py',tmp/'screen.py');shutil.copy2(HERE/'replay_bit.py',tmp/'replay_bit.py')
  run=subprocess.run([sys.executable,'-I','-B',str(tmp/'screen.py'),'--words',str(tmp)],capture_output=True,check=True)
  need(run.stdout==(HERE/'RESULT.json').read_bytes(),'clean deterministic receipt')
  for name in ('ONE-CONTACT-WORD.json.gz','TWO-CONTACT-WORD.json.gz'):
   need(gzip.decompress((tmp/name).read_bytes())==gzip.decompress((HERE/name).read_bytes()),'clean canonical word '+name)
 print('PASS_679_INTERFACE_CENSUS_BOTH_DIRECTIONS_36_CALLER_PRICES_BINDING_AND_CORRUPTION_CONTROLS')
if __name__=='__main__':main()
