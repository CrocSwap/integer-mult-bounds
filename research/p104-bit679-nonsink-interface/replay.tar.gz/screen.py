#!/usr/bin/env python3
"""679-owner cochart GL(2) terminal-contact census and literal controls.

Scope: unchanged native packet program, fixed public endpoint frames/order,
constant 679-owner input action, frozen end-of-program stock, additive terminal
repair, no changed existing packet, at most one new paid contact to a pair's
nonsink endpoint. Literal CLEAR has discard semantics, not clean uncomputation.
"""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from pathlib import Path
import copy, gzip, json, sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));sys.path.insert(0,str(HERE/'inputs'))
import replay_bit as b
import literal, price
need=b.need
PINS={
 'replay_bit.py':'ffb6351db6d991eae2d9c6f88b6ae82164ecbfc8d28fd4b53f4a013664c06f05',
 'inputs/literal.py':'4021766d87fa791a43a78a6665c9260b7ba3772d8b2db6e9c84b6a3d51a1305c',
 'inputs/price.py':'d720df6f3f7a22554e83d0c29243af3ee04fa036073404926bab7bc2f2687e1b',
 'inputs/R5-04-RESULT.json':'d657c629e74f82128bedb89013aec25f68b598386b6a103ec6ba3bd71aaed5b3',
 'inputs/R5-10-RESULT.json':'94dd86558fdd526455bc50f91761e940b4a05a584e175ab14e91662a491ce5ce',
 'inputs/R5-20-BIT-REPLAY.json':'51cbf251ce2faf17dc7b8d474c2ca289eae32b9f4e6b5ac8b4efb04c9936ef5c'}
for name,digest in PINS.items():need(sha256((HERE/name).read_bytes()).hexdigest()==digest,'source pin '+name)
RATES=('0.003879928046156','0.003879929046155')

def clean(h):return {int(k):v for k,v in sorted(h.items()) if v}
def unpack(path):return json.loads((HERE/'inputs'/path).read_bytes())
def add(p,x,record=0):
 while x:
  k=x.bit_length()-1
  if k not in p:p[k]=(x,record);return True
  y,r=p[k];x^=y;record^=r
 return False

def solve(p,x):
 r=0
 while x:
  k=x.bit_length()-1
  if k not in p:return None
  y,t=p[k];x^=y;r^=t
 return r

def bits(x):
 while x:
  t=x&-x;yield t.bit_length()-1;x^=t

def snapshot(w,stop):
 n=w['public'];bank=[1<<i for i in range(n)]+[0]*w['owned_fields'];tags=w['start'][:]+[None]*w['owned_fields']
 for op,a,*arg in w['program'][:stop]:
  if op=='ADD':need(tags[a]==tags[arg[0]]==arg[1],'snapshot add');bank[a]^=bank[arg[0]]
  elif op=='SWAP':j=arg[0];bank[a],bank[j]=bank[j],bank[a];tags[a],tags[j]=tags[j],tags[a]
  elif op=='INIT':need(tags[a] is None,'snapshot init');bank[a]=0;tags[a]=arg[0]
  elif op=='CLEAR':need(tags[a]==arg[0],'snapshot clear');bank[a]=0;tags[a]=None
  else:need(op=='MOVE' and tags[a]==arg[0],'snapshot move');tags[a]=arg[1]
 return bank,tags

def census(w,f):
 n=w['public'];owners=[i for i in range(680) if i!=649];groups=defaultdict(list)
 for i,o in enumerate(owners):
  if i>=222 and o!=411:groups[w['start'][i]].append((i,o,w['final'][i]))
 allpairs=[(s,a,c) for s,ls in groups.items() for j,a in enumerate(ls) for c in ls[j+1:]]
 distinct=[p for p in allpairs if p[1][2]!=p[2][2]]
 pairs=[p for p in distinct if 1 not in (p[1][2],p[2][2])]
 need((len(owners),sum(map(len,groups.values())),len(allpairs),len(distinct),len(pairs))==(679,456,85104,9605,269),'exact independent pair census')
 need(all(s==0 for s,_,_ in pairs),'nonsink pair common source')
 direct=Counter()
 for _,a,c in pairs:
  try:grade=b.leg(f,a[2],c[2])
  except ValueError:continue
  direct[grade]+=1
 need(direct=={2:1,3:9,5:1},'direct distinct-end census')
 # The old packets remain live at this exact clock, after every public swap
 # and immediately before the first paid-packet CLEAR.
 stop=max(i for i,r in enumerate(w['program']) if r[0]=='SWAP')+2
 need(w['program'][stop][0]=='CLEAR','first packet retirement follows')
 bank,tags=snapshot(w,stop);need(stop==40074 and sum(t is not None for t in tags)==3552,'real terminal stock clock')
 stock=defaultdict(list)
 for i,(chart,v) in enumerate(zip(tags,bank)):
  if chart is not None and v:stock[chart].append((i,v))
 need(len(stock)==636,'terminal nonzero stock charts')
 @lru_cache(None)
 def basis(chart,excluded):
  p={}
  for i,v in stock[chart]:
   if i not in excluded:add(p,v,1<<i)
  return p
 @lru_cache(None)
 def available(chart):return basis(chart,())
 @lru_cache(None)
 def grade(a,z):
  try:return b.leg(f,a,z)
  except ValueError:return None
 @lru_cache(None)
 def source_charts(y):return [(z,g) for z in sorted(stock) if z!=1 and z!=y and (g:=grade(z,y))]
 def apply(v,M):return (M[0] if v&1 else 0)^(M[1] if v&2 else 0)
 matrices=[(a,c) for a in (1,2,3) for c in (1,2,3) if a!=c]
 inverse={M:next(N for N in matrices if all(apply(apply(v,M),N)==v for v in (1,2))) for M in matrices}
 def placed(v,h,k):return ((1<<h) if v&1 else 0)^((1<<k) if v&2 else 0)
 counts=Counter();feasible=[];precomputed=0
 for start,h,k in pairs:
  for M in matrices:
   if M==(1,2):continue
   I=inverse[M]
   for rid in (0,1):
    recipient=(h,k)[rid];other=(k,h)[rid];ro=1-rid
    # Express corrections in the unchanged input-coordinate basis using M^-1.
    dother=placed(apply(M[ro]^(1<<ro),I),h[0],k[0])
    other_basis=basis(other[2],(other[0],))
    repair=solve(other_basis,dother)
    if repair is None:counts['other_endpoint_not_repairable_locally']+=1;continue
    y=recipient[2];target_basis=basis(y,(recipient[0],))
    delta=placed(apply(M[rid]^(1<<rid),I),h[0],k[0])
    local=solve(target_basis,delta)
    if local is not None:counts['both_locally_repairable']+=1;continue
    precomputed+=1;options=[]
    for z,g in source_charts(y):
     combined=target_basis.copy()
     source_basis=basis(z,(other[0],)) if z==other[2] else available(z)
     for x,mask in source_basis.values():add(combined,x,mask)
     if z==other[2]:
      # A locally restored other terminal can itself be borrowed as source.
      add(combined,placed(apply(1<<ro,I),h[0],k[0]),1<<other[0])
     witness=solve(combined,delta)
     if witness is not None:options.append((g,z,witness))
    if not options:counts['no_contact_found']+=1;continue
    counts['one_contact_found']+=1
    grade0,z,wit=min(options)
    source_banks=[i for i in bits(wit) if tags[i]==z]
    target_banks=[i for i in bits(wit) if tags[i]==y]
    need(source_banks and len(source_banks)+len(target_banks)==wit.bit_count(),'source and destination witness decomposition')
    reconstructed=0
    for i in bits(wit):
     reconstructed ^= (placed(apply(1<<ro,I),h[0],k[0])
                       if i==other[0] and z==other[2] else bank[i])
    need(reconstructed==delta,'exact source plus terminal witness')
    repaired=0
    for i in bits(repair):repaired ^= bank[i]
    need(repaired==dother,'exact local other-end witness')
    feasible.append({'owners':[h[1],k[1]],'addresses':[h[0],k[0]],'start':start,'finals':[h[2],k[2]],'matrix_rows':list(M),'recipient_owner':recipient[1],'minimum_contact_grade':grade0,'source_chart':z,'destination_chart':y,'source_banks':source_banks,'destination_banks':target_banks,'other_repair_banks':list(bits(repair)),'qualifying_source_charts':len(options)})
 need(len(matrices)==6 and sum(counts.values())==2690,'GL(2) enumeration count')
 need(counts=={'other_endpoint_not_repairable_locally':2152,'no_contact_found':514,'one_contact_found':24},'terminal contact counts')
 need(Counter(v['minimum_contact_grade'] for v in feasible)=={2:2,3:18,5:4},'minimum contact prices')
 # A known ineligible same-tag transposition must not enter this census.
 same=next(p for p in allpairs if p[1][1:]==(222,1) and p[2][1:]==(223,1))
 need(same not in pairs,'identical-terminal-tag permutation guard')
 # Verify least-cost nontrivial shear and that the missing donor cannot be
 # obtained from the recipient chart without the extra contact.
 h,k=341,660
 need(w['start'][h]==w['start'][k]==0 and (w['final'][h],w['final'][k])==(374,520),'chosen real pair')
 target_no_receiver=basis(520,(k,));need(solve(target_no_receiver,1<<h) is None,'chosen correction cannot be made from terminal stock')
 need(solve(available(374),1<<h) is not None,'chosen cross-contact has donor')
 return {'eligible_helpers':456,'eligible_same_start_unordered_pairs':len(allpairs),'identical_end_chart_pairs_excluded':len(allpairs)-len(distinct),'distinct_end_pairs':len(distinct),'pairs_with_chart_1_excluded':len(distinct)-len(pairs),'nonsink_distinct_end_pairs':len(pairs),'same_start_chart':0,'direct_end_leg_pairs_by_grade':clean(direct),'gl2_matrices_total':len(matrices),'nonidentity_matrices_per_pair':5,'oriented_pair_matrix_cases':2690,'counts':dict(counts),'one_contact_minimum_grades':clean(Counter(v['minimum_contact_grade'] for v in feasible)),'terminal_snapshot_clock':stop,'live_public_and_paid_fields':3552,'nonzero_stock_charts':len(stock),'all_minimum_contact_witnesses':feasible,'stock_sources_include_borrowed_outputs_and_unretired_old_packets':True,'chart_1_source_excluded':True,'identical_tag_guard_example':[222,223,0,1],'chosen_target_donor_in_span_without_crossing':False}

def example(w,clean_scratch=False):
 # Input basis is y_661=x_661+x_341, y_341=x_341. Endpoints
 # remain fixed; add x_341 at chart 520 to recover output x_661.
 out=copy.deepcopy(w);scratch=w['public']+w['owned_fields'];out['owned_fields']+=1
 prefix=[['ADD',660,341,0]]
 if clean_scratch:
  # Transport the donor itself, not a copy.  This makes the full linear
  # operation block diagonal in the auxiliary register, so its transpose
  # also returns the added scratch to zero.
  suffix=[['INIT',scratch,374],['SWAP',341,scratch],['MOVE',scratch,374,520],
          ['ADD',660,scratch,520],['MOVE',scratch,520,374],
          ['SWAP',341,scratch],['CLEAR',scratch,374]]
 else:
  suffix=[['INIT',scratch,374],['ADD',scratch,341,374],
          ['MOVE',scratch,374,520],['ADD',660,scratch,520],['CLEAR',scratch,520]]
 out['program']=prefix+w['program']+suffix
 need((out['frames'],out['start'],out['final'],out['public'])==(w['frames'],w['start'],w['final'],w['public']),'fixed 679 frame and order')
 return out,scratch

def close_value(word,scratch,reverse=False):
 n=word['public'];bank=[1<<i for i in range(n)]+[0]*word['owned_fields']
 it=range(len(word['program'])-1,-1,-1) if reverse else range(len(word['program']))
 for clock in it:
  op,a,*arg=word['program'][clock]
  if a==scratch and ((op=='INIT' and reverse) or (op=='CLEAR' and not reverse)):
   return clock,bank[a]
  if op=='ADD':
   if reverse:bank[arg[0]]^=bank[a]
   else:bank[a]^=bank[arg[0]]
  elif op=='SWAP':j=arg[0];bank[a],bank[j]=bank[j],bank[a]
  elif op in ('INIT','CLEAR'):bank[a]=0
  else:need(op=='MOVE','trace opcode')
 raise ValueError('new scratch closure absent')

def record_3553(word):
 n=word['public'];bank=[1<<i for i in range(n)]+[0]*word['owned_fields'];hits=[]
 for clock,(op,a,*arg) in enumerate(word['program']):
  if op=='ADD':bank[a]^=bank[arg[0]]
  elif op=='SWAP':j=arg[0];bank[a],bank[j]=bank[j],bank[a]
  elif op in ('INIT','CLEAR'):bank[a]=0
  elif op=='MOVE':
   if a==3551:hits.append({'clock':clock,'compiled_bank':a,'route':arg,'forward_sender_support':list(bits(bank[a]))})
  else:raise ValueError('trace opcode')
 need(len(hits)==1 and hits[0]['route']==[509,1] and hits[0]['forward_sender_support']==[411],'protected original packet 3553 / owner 411')
 return hits[0]

def checked(word,charts,caller,events):
 charts.main_contacts(word['start'],word['final'])
 forward,ff,_=literal.tape(word,charts);transpose,rr,_=literal.tape(word,charts,adjoint=True)
 need(forward==literal.expected_rows(word['public'],False),'complete 679 forward public rows')
 need(transpose==literal.expected_rows(word['public'],True),'complete 679 adjoint public rows')
 need(ff['paid']==rr['paid'],'paid movements symmetric')
 native_targets=Counter(charts.leg(a,z) for a,z in zip(word['start'][222:],word['final'][222:],strict=True))
 paid,targets=literal.paired_invoice(caller,ff['paid'],native_targets,events)
 ordinary=literal.ordinary(word,caller,events,paid,targets)
 return {'canonical_sha256':literal.canonical(word),'native_paid':clean(ff['paid']),'native_targets':clean(native_targets),'full_paid':clean(paid),'full_targets':clean(targets),'forward_private_dirty_retirements':ff['erase_dirty'],'adjoint_private_dirty_retirements':rr['erase_dirty'],'counts':dict(sorted(ff['counts'].items())),'ordinary':ordinary,'both_679_by_679_operators_exact':True,'packet_3553':record_3553(word)}

def bind_candidate(old,w,candidate,caller,tables):
 """Bind all 36 call namespaces, all helper identities and all paid rows."""
 owners=[j for j in range(680) if j!=649]
 frames=b.frames(w)
 helper=[[i,original,w['start'][i],w['final'][i],
          b.leg(frames,w['start'][i],w['final'][i])]
         for i,original in enumerate(owners) if i>=222]
 def check_helper(rows):need(rows==helper,'exact 679 helper owner identity')
 for table in tables:check_helper(table['helper'])
 stale=copy.deepcopy(tables[0]['helper']);stale[649-222][1]=649
 try:check_helper(stale)
 except ValueError:pass
 else:raise ValueError('stale original owner 649 accepted')
 need(helper[649-222][1]==650,'old 649 does not alias local 649')
 base=tables[0]['paid_move'];shifted=[]
 for clock,bank,original,a,z,g in base:
  need(candidate['program'][clock+1]==['MOVE',bank,a,z],'retained paid order and identity')
  shifted.append([clock+1,bank,original,a,z,g])
 source3553=[x for x in shifted if x[2]==3553]
 need(len(source3553)==1 and source3553[0][1:]==[3551,3553,509,1,4],
      'protected source packet 3553 retained in original order')
 for clock in range(1+len(w['program']),len(candidate['program'])):
  op,bank,*tail=candidate['program'][clock]
  if op=='MOVE':
   a,z=tail;shifted.append([clock,bank,'new-exchange-'+str(len(shifted)-len(base)+1),
                            a,z,b.leg(frames,a,z)])
 calls=[]
 for table in tables:
  need(table['paid_move']==base,'source 36-call paid order')
  calls.append({'caller_clock':table['caller_clock'],'event':table['event'],
                'word':b.canon(candidate),'helper':helper,'paid_move':shifted})
 need(len(calls)==36 and [x['caller_clock'] for x in calls]==
      [i for i,e in enumerate(caller['events']) if e[0]=='LOCAL'],
      'candidate exact 36 caller clock namespaces')
 return {'candidate_word':b.canon(candidate),'calls':len(calls),
         'helper_rows_per_call':len(helper),'paid_rows_per_call':len(shifted),
         'all_36_call_tables_canonical_sha256':b.canon(calls),
         'original_packet_3553_paid_row':source3553[0],
         'stale_649_identity_corruption_rejected':True}

def price_profiles(control,examples):
 p0=Counter(control['full_paid']);t0=Counter(control['full_targets']);signed0=Counter(t0);signed0.subtract(p0);results={}
 for name,candidate in examples.items():
  p=Counter(candidate['full_paid']);t=Counter(candidate['full_targets']);dp=Counter(p);dp.subtract(p0);dt=Counter(t);dt.subtract(t0);delta=Counter(dt);delta.subtract(dp)
  expected={2:36 if name=='one_contact_discard' else 72}
  def check_price(paid_delta,productive_delta):
   need(clean(paid_delta)==expected and not clean(productive_delta),'whole 36-call contact invoice')
  check_price(dp,dt)
  try:check_price(Counter(),dt)
  except ValueError:pass
  else:raise ValueError('corrupted invoice omitted added contact')
  trials={}
  for rate in RATES:
   k=Fraction(rate);baseline=price.moment(signed0,k);change=price.moment(delta,k);full=price.add(baseline,change)
   want=Counter(t);want.subtract(p);recount=price.moment(want,k)
   need(full[0]<=recount[1] and recount[0]<=full[1] and change[1]<0,'directed signed price')
   trials[rate]={'control_margin':price.decimal_interval(baseline,30),'signed_change':price.decimal_interval(change,30),'full_candidate_margin':price.decimal_interval(recount,30)}
  results[name]={'full_paid_delta':clean(dp),'full_productive_delta':clean(dt),'full_signed_histogram_delta':clean(delta),'trials':trials}
 return results

def main():
 old,w,caller,tables,src=(b.load(k) for k in ('WORD.json.gz','ZERO-CONTROL-WORD.json.gz','EFREE-CALLER.json.gz','TABLES.json.gz','BIT.json'))
 need(b.canon(old)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d' and b.canon(w)=='09452b800860b0323edba227f07c95a14c2f4afa38f332d059e4adb0382d63be','pinned literal words')
 r04,r10,r20=(unpack(k) for k in ('R5-04-RESULT.json','R5-10-RESULT.json','R5-20-BIT-REPLAY.json'))
 need(r04['control_canonical_sha256']==b.canon(w) and r04['control_owner_411_and_packet_3553_retained'],'R5 04 once-specialized control')
 need(r10['different_7912_canonical']==b.canon(w) and r10['control_canonical']!=b.canon(w),'R5 10 is different owner-removal control')
 need(r20['status']=='PASS_LITERAL_INCUMBENT_AND_679_ZERO' and r20['total_signed_delta_exact']==0,'R5 20 independent binding control')
 binding=b.owners(old,w,caller,tables)
 need(binding['all_call_tables_reconstructed']==36 and binding['same_grade_swap_rejected'],'36 source namespaces and corruption')
 need([old['start'][i] for i in range(680) if i!=649]==w['start'] and [old['final'][i] for i in range(680) if i!=649]==w['final'] and old['frames']==w['frames'],'all original owner frame/order')
 f=b.frames(w);gate=census(w,f)
 charts=literal.Charts(w['frames']);need(charts.leg(374,520)==2,'exact rational crossing')
 need(all(x%3 for x in charts.prime_factors),'all native chart determinants are 3-adic units')
 events=Counter(e[0] for e in caller['events']);need(events['LOCAL']==36,'36 native calls')
 control=checked(w,charts,caller,events)
 a,sa=example(w,False);c,sc=example(w,True)
 one=checked(a,charts,caller,events);two=checked(c,charts,caller,events)
 one['owner_call_binding']=bind_candidate(old,w,a,caller,tables)
 two['owner_call_binding']=bind_candidate(old,w,c,caller,tables)
 need(all(x%3 for x in charts.prime_factors),'main quartets remain 3-adic units')
 need(control['forward_private_dirty_retirements']==control['adjoint_private_dirty_retirements']==3552,'known R5 erasure boundary')
 need(one['forward_private_dirty_retirements']==one['adjoint_private_dirty_retirements']==3553,'one crossing extra discarded live copy')
 need(two['forward_private_dirty_retirements']==two['adjoint_private_dirty_retirements']==3552,'two crossings clean only added scratch')
 oneclose=[close_value(a,sa,x) for x in (False,True)];twoclose=[close_value(c,sc,x) for x in (False,True)]
 need(all(v for _,v in oneclose) and all(not v for _,v in twoclose),'new scratch closure controls')
 missing_correction=1+len(w['program'])+3
 wrong,_,_=literal.tape(a,charts,omit=missing_correction);wrongT,_,_=literal.tape(a,charts,adjoint=True,omit=missing_correction)
 badF=literal.different(wrong,literal.expected_rows(679,False));badT=literal.different(wrongT,literal.expected_rows(679,True))
 need(badF[1]==badT[1]==1,'corrupt correction detected in both orientations')
 wrong,_,_=literal.tape(a,charts,omit=0);wrongT,_,_=literal.tape(a,charts,adjoint=True,omit=0)
 need(literal.different(wrong,literal.expected_rows(679,False))[1]==literal.different(wrongT,literal.expected_rows(679,True))[1]==1,'corrupt input shear detected')
 try:literal.tape(c,charts,omit=len(c['program'])-1)
 except ValueError:pass
 else:raise ValueError('omitted scratch retirement accepted')
 prices=price_profiles(control,{'one_contact_discard':one,'two_contacts_clean_new_scratch':two})
 gate['full_36_call_signed_change_by_minimum_grade']={}
 for rate in RATES:
  trial=Fraction(rate)
  intervals={g:price.moment({g:-36},trial) for g in (2,3,5)}
  need(intervals[5][1]<intervals[3][0]<intervals[3][1]<intervals[2][0]<intervals[2][1]<0,
       'every feasible one-contact signed change is negative')
  gate['full_36_call_signed_change_by_minimum_grade'][rate]={
   str(g):price.decimal_interval(intervals[g],30) for g in (2,3,5)}
 # Caller source invoice comparison includes all 36 target/paid bins, not a local proxy.
 oldp,oldt,*_=b.invoice(old,b.frames(old),caller)
 need(oldp==Counter({int(k):v for k,v in src['native']['paid'].items()}) and oldt==Counter({int(k):v for k,v in src['native']['targets'].items()}),'complete 7830 caller binding')
 dp=Counter(control['full_paid']);dp.subtract(oldp);dt=Counter(control['full_targets']);dt.subtract(oldt)
 need(clean(dp)==clean(dt)=={4:-36},'679 control exact signed tie to comparator')
 result={'status':'NO_POSITIVE_679_TWO_OWNER_TERMINAL_EXCHANGE_IN_STATED_SCREEN','pinned_7912_head':'83ece5a62d3addbee45bad9594ef4809851b833b','source_word':b.canon(w),'scope':'All same-start non-411 pairs with different nonsink endpoint tags; input GL2 action; frozen original packet program and fixed 679 output tags/order; additive terminal repair, at most one new paid nested nonsink contact, with frozen terminal stock borrowed freely. Pair endpoints must be repaired individually at their original tags; no new paid contact may alter an existing packet. Discard CLEAR allowed for one-contact literal. Not an exclusion of altered packets, arbitrary nonlinear/cross-start constructions, or globally reversible suppliers.','round5_controls':{'04':'same owner649 control and protected 411/3553','10':'separate owner341-removed word; not substituted','20':'literal independent 679 binding, 36 caller tables, corruption guard'},'exact_pair_and_charge_gate':gate,'selected_pair':{'original_owners':[341,661],'compiled_addresses':[341,660],'common_start_chart':0,'end_charts':[374,520],'target_grades':[6,4],'input_gl2_rows':[1,3],'terminal_contact':[374,520,2],'retained_owner_411':411,'retained_original_packet_3553':'compiled field 3551; forward 509→1; pure owner411'},'control':control,'examples':{'one_contact_discard':one,'two_contacts_clean_new_scratch':two},'complete_price':prices,'corruption_controls':{'identical_tag_permutation_excluded':True,'equal_grade_owner_identity_swap_rejected':binding['same_grade_swap_rejected'],'stale_649_address':'address 649 names original 650; 649 was removed','missing_input_shear_changed_coefficients_both_directions':1,'missing_terminal_add_changed_coefficients_both_directions':badF[1],'omitted_new_clear_rejected':True,'unpaid_added_contact_rejected':True,'new_scratch_discard_close_support_sizes':[v.bit_count() for _,v in oneclose],'new_scratch_reversible_close_support_sizes':[v.bit_count() for _,v in twoclose]},'limitations':['CLEAR in the inherited literal supplier discards nonzero data; the second contact only cleans the additional exchange scratch.','Unchanged helper endpoint tags imply unchanged productive grades; each added paid contact strictly worsens the full signed price.','Physical supply, existing dirty retirements, cover, compiler, precision, and consumer premises remain unproved for the modified words.']}
 if len(sys.argv)==3 and sys.argv[1]=='--words':
  out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
  for name,word in [('ONE-CONTACT-WORD.json.gz',a),('TWO-CONTACT-WORD.json.gz',c)]:
   raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode();(out/name).write_bytes(gzip.compress(raw,mtime=0))
 elif len(sys.argv)!=1:raise ValueError('usage: screen.py [--words directory]')
 print(json.dumps(result,sort_keys=True,indent=2))
if __name__=='__main__':main()
