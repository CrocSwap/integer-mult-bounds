#!/usr/bin/env python3
"""Independent literal GF(2) replay and endpoint block-rank obstruction."""
import gzip, hashlib, json, sys
from collections import Counter, defaultdict
from pathlib import Path
from fractions import Fraction
from decimal import Context, Decimal as D, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN
P=Path(__file__).resolve().parent
O=P
PINS={
 'source/inputs/AUDIT.json':'a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376',
 'source/inputs/WORD.json.gz':'d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
 'source/inputs/EFREE-CALLER.json.gz':'757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
 'EARLY-268-ESCAPE-WORD.json.gz':'9e8e230077c20c6781f3b3092015dc9b2dba991002a558f9d3a0a9b8a1182abf',
 'EARLY-268-RESTORED-SIDE-WORD.json.gz':'84b53c2d8c69c77f9e36b45e238f8be7dae62e6a5ebffeac45c108fe7be0e98a',
}
def load(name):
 raw=(P/name).read_bytes(); h=hashlib.sha256(raw).hexdigest()
 assert h==PINS[name],(name,h);return json.loads(gzip.decompress(raw) if name.endswith('.gz') else raw)
def keys(mask):return [i for i in range(mask.bit_length()) if mask>>i&1]
def rank(rows):
 basis={}
 for v in rows:
  while v:
   q=v.bit_length()-1
   if q not in basis:basis[q]=v;break
   v^=basis[q]
 return len(basis)
def expected(n,reverse):
 return [(1<<i) ^ (1<<(i+111) if reverse and i<111 else 1<<(i-111) if not reverse and 111<=i<222 else 0) for i in range(n)]
def dot(a,b):return sum(Fraction(x)*Fraction(y) for x,y in zip(a,b))
def chart_grade(frames,a,b):
 aa,bb=frames[str(a)],frames[str(b)]
 if aa['dim']>bb['dim']:aa,bb=bb,aa
 diff=bb['dim']-aa['dim']
 assert diff>0 and all(dot(x,y)==0 for x in aa['B'] for y in bb['A']), (a,b)
 return diff
def replay(word,reverse=False,omit=None,marker=411):
 n=word['public'];z=word['owned_fields'];frames=word['frames'];init=word['final'] if reverse else word['start'];end=word['start'] if reverse else word['final']
 val=[1<<i for i in range(n)]+[0]*z; tag=list(init)+[None]*z; grades=Counter(); dirty=0; ops=Counter(); live=peak=0; marked=[]
 for at in (range(len(word['program'])-1,-1,-1) if reverse else range(len(word['program']))):
  if at==omit:continue
  op,a,*xs=word['program'][at];ops[op]+=1;assert 0<=a<len(val)
  if op in ('INIT','CLEAR'):
   c,=xs;assert a>=n and str(c) in frames
   opening=(op=='CLEAR') if reverse else (op=='INIT')
   if opening:assert tag[a] is None;tag[a]=c;live+=1;peak=max(peak,live)
   else:assert tag[a]==c;dirty+=bool(val[a]);tag[a]=None;live-=1
   val[a]=0
  elif op=='ADD':
   b,c=xs;assert 0<=b<len(val) and a!=b and tag[a]==tag[b]==c
   if reverse:val[b]^=val[a]
   else:val[a]^=val[b]
  elif op=='SWAP':
   b,=xs;assert a!=b and tag[a] is not None and tag[b] is not None
   val[a],val[b]=val[b],val[a];tag[a],tag[b]=tag[b],tag[a]
  else:
   assert op=='MOVE' and a>=n
   source,receiver=xs[::-1] if reverse else xs;assert tag[a]==source
   g=chart_grade(frames,source,receiver);grades[g]+=1
   if n>marker and (val[a]>>marker)&1:marked.append({'clock':at,'source':source,'receiver':receiver,'grade':g,'value_support':keys(val[a])})
   tag[a]=receiver
 assert tag==list(end)+[None]*z and not any(val[n:]) and live==0
 out=val[:n];want=expected(n,reverse);bad=[i for i in range(n) if out[i]!=want[i]]
 return dict(rows=out,grades=grades,dirty=dirty,bad=bad,ops=ops,peak_live_private=peak,owner411_packet_support=marked)
def recount(word,local,caller):
 f=word['frames'];helper=Counter(chart_grade(f,a,b) for a,b in zip(word['start'][222:],word['final'][222:]));p=Counter();t=Counter();calls=[];events=Counter()
 for clock,e in enumerate(caller['events']):
  typ=e[0];events[typ]+=1
  if typ=='LOCAL':calls.append(clock);p.update(local);t.update(helper)
  elif typ=='QUERY':p[1]+=caller['ports']
  elif typ=='IDLE_ONE':p[7*len(e[2])]+=caller['ports']
  else:assert typ in ('ADD','SWAP')
 for d in caller['diagonal']:t[d['q']+7*len(d['stages'])]+=caller['ports']
 assert len(calls)==36 and caller['ports']==111 and events['QUERY']==4 and events['IDLE_ONE']==32
 return p,t,helper,events
# Directed enclosures: ln and exp are correctly rounded to nearest under Decimal's
# documented implementation. Adjacent ulps enclose each transcendental; arithmetic
# endpoints are formed under directed contexts. Counts are nonnegative.
L=Context(prec=90,rounding=ROUND_FLOOR); U=Context(prec=90,rounding=ROUND_CEILING); N=Context(prec=90,rounding=ROUND_HALF_EVEN)
def power(g,e):
 if g==1:return D(1),D(1)
 ln=N.ln(D(g));l=N.next_minus(ln);h=N.next_plus(ln)
 return N.next_minus(N.exp(L.multiply(l,e))),N.next_plus(N.exp(U.multiply(h,e)))
def moment(c,e):
 lo=hi=D(0)
 for g,v in c.items():
  a,b=power(int(g),e);lo=L.add(lo,L.multiply(a,D(v)));hi=U.add(hi,U.multiply(b,D(v)))
 return lo,hi
def margin(p,t,s):
 e=L.subtract(D(1),D(s)); assert e==U.subtract(D(1),D(s))
 a=moment(t,e);b=moment(p,e);return [str(L.subtract(a[0],b[1])),str(U.subtract(a[1],b[0]))]
def blocks(word,rows,reverse=False):
 inputs=word['final'] if reverse else word['start'];outputs=word['start'] if reverse else word['final']; byin=defaultdict(list);byout=defaultdict(list)
 for i,c in enumerate(inputs):byin[c].append(i)
 for i,c in enumerate(outputs):byout[c].append(i)
 want=expected(len(inputs),reverse);diff=[]
 for ic,iset in byin.items():
  mask=sum(1<<i for i in iset)
  for oc,oset in byout.items():
   got=[rows[i]&mask for i in oset];exp=[want[i]&mask for i in oset];gr,er=rank(got),rank(exp)
   if gr!=er:diff.append(dict(input_chart=ic,output_chart=oc,input_owners=iset,output_owners=oset,actual_rank=gr,expected_rank=er,actual_rows=[keys(v) for v in got],expected_rows=[keys(v) for v in exp]))
 return sorted(diff,key=lambda x:(len(x['input_owners'])*len(x['output_owners']),x['input_chart'],x['output_chart']))
def main():
 caller=load('source/inputs/EFREE-CALLER.json.gz'); ref=load('source/inputs/WORD.json.gz');rw=replay(ref);rr=replay(ref,True)
 assert rw['bad']==rr['bad']==[] and rw['grades']==rr['grades'] and ref['public']==680
 result={'source_word_gzip_sha256':PINS['source/inputs/WORD.json.gz'],'source_caller_gzip_sha256':PINS['source/inputs/EFREE-CALLER.json.gz'],'baseline':{},'candidates':{}}
 bp,bt,bh,be=recount(ref,rw['grades'],caller)
 audit=load('source/inputs/AUDIT.json')['signed'];assert audit['native_calls']==48
 hist=lambda x:Counter({int(k):v for k,v in x.items()})
 sourcepath=P/'source/BASELINE.json'
 raw=sourcepath.read_bytes();assert hashlib.sha256(raw).hexdigest()=='a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a'
 baseline=json.loads(raw)['rational'];np=hist(baseline['native_paid']);nt=hist(baseline['native_targets']);rp=Counter({k:48*v for k,v in np.items()});rt=Counter({k:48*v for k,v in nt.items()});rp.update(hist(baseline['caller_paid']));rt.update(hist(baseline['caller_targets']))
 assert rp==hist(baseline['paid'])==hist(audit['paid']) and rt==hist(baseline['targets'])==hist(audit['productive']) and sum(rp.values())==283152 and sum(rt.values())==52512
 result['unchanged_rational_invoice']={'baseline_sha256':hashlib.sha256(raw).hexdigest(),'audit_sha256':PINS['source/inputs/AUDIT.json'],'native_calls':48,'recount_scope':'source native histograms times 48 plus source caller histograms, checked against independent pinned audit; no changed-supplier outer application','paid':dict(rp),'productive':dict(rt),'signed_margin_00388':margin(rp,rt,'0.00388'),'signed_margin_raw':margin(rp,rt,'0.0038800000000000083')}
 result['baseline']={'paid':dict(bp),'productive':dict(bt),'margin_00388':margin(bp,bt,'0.00388'),'bad_forward':rw['bad'],'bad_adjoint':rr['bad']}
 for short,path in [('single','EARLY-268-ESCAPE-WORD.json.gz'),('restored_side','EARLY-268-RESTORED-SIDE-WORD.json.gz')]:
  w=load(path);assert w['frames']==ref['frames'] and w['start']==ref['start'] and w['final']==ref['final']
  a,b=replay(w),replay(w,True);assert a['grades']==b['grades'];p,t,h,e=recount(w,a['grades'],caller);assert t==bt and h==bh
  f=blocks(w,a['rows']);r=blocks(w,b['rows'],True)
  wantf=expected(680,False);wantr=expected(680,True)
  target={str(i):{'forward_actual':keys(a['rows'][i]),'forward_expected':keys(wantf[i]),'adjoint_actual':keys(b['rows'][i]),'adjoint_expected':keys(wantr[i])} for i in (221,679)}
  n=w['public'];moves=sum(1 for x in w['program'] if x[0]=='MOVE');scratch=n+moves+221
  omit=next(j for j,x in enumerate(w['program']) if x[0]=='ADD' and x[1]==scratch)
  badf=replay(w,False,omit);badadj=replay(w,True,omit)
  assert badf['rows']!=a['rows'] and badadj['rows']!=b['rows']
  dp=Counter(p);dp.subtract(bp);dt=Counter(t);dt.subtract(bt)
  out={'gzip_sha256':PINS[path],'bad_forward':a['bad'],'bad_adjoint':b['bad'],'targets':target,'dirty_forward':a['dirty'],'dirty_adjoint':b['dirty'],'native_grades':dict(a['grades']),'paid_36':dict(p),'productive_36':dict(t),'paid_delta':{k:v for k,v in dp.items() if v},'productive_delta':{k:v for k,v in dt.items() if v},'binary_margin_00388':margin(p,t,'0.00388'),'binary_margin_raw':margin(p,t,'0.0038800000000000083'),'block_rank_disagreements_forward':len(f),'block_rank_disagreements_adjoint':len(r),'smallest_forward_rank_witnesses':f[:4],'smallest_adjoint_rank_witnesses':r[:4],'owner_221_output_chart_forward_rank_witnesses':[v for v in f if v['output_chart']==w['final'][221]][:4], 'corruption_control':{'omitted_add_clock':omit,'omitted_instruction':w['program'][omit],'forward_changed_output_owners':[i for i in range(680) if badf['rows'][i]!=a['rows'][i]],'adjoint_changed_output_owners':[i for i in range(680) if badadj['rows'][i]!=b['rows'][i]],'corrupted_forward_bad_count':len(badf['bad']),'corrupted_adjoint_bad_count':len(badadj['bad'])}}
  result['candidates'][short]=out
 serialized=json.dumps(result,sort_keys=True,indent=2)+'\n';receipt=O/'REPLAY-BLOCKS.json'
 if '--write' in sys.argv:receipt.write_text(serialized)
 else:assert receipt.read_text()==serialized,'replay receipt mismatch'
 for name,x in result['candidates'].items():
  print(name,'bad forward/adjoint',len(x['bad_forward']),len(x['bad_adjoint']),'owners',x['targets'],'rank disagreements',x['block_rank_disagreements_forward'],x['block_rank_disagreements_adjoint'],'margin',x['binary_margin_00388'])
  print('first witnesses',json.dumps(x['smallest_forward_rank_witnesses'][:1]),json.dumps(x['smallest_adjoint_rank_witnesses'][:1]))
  print('221 output witnesses',json.dumps(x['owner_221_output_chart_forward_rank_witnesses'][:1]))
 print('saved',O/'REPLAY-BLOCKS.json')
if __name__=='__main__':main()
