#!/usr/bin/env python3
"""Summary of two independent fresh diagnostic word replays."""
import gzip,hashlib,importlib.util,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('ireplay',P/'replay_blocks.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
out={'qualification':'Damaged diagnostic words only; no positive kappa or physically valid supplier is established. Invoice uses original 36-call caller; unchanged rational 48-call invoice remains separate.','inputs':{}}
for n in ('CPLUS-D','TRANSFER-719'):
 p=P/('FRESH-'+n+'-WORD.json.gz');w=json.loads(gzip.decompress(p.read_bytes()));a=m.replay(w);b=m.replay(w,True);ef=m.expected(w['public'],False);eb=m.expected(w['public'],True);rec=json.loads((P/('FRESH-'+n+'-ADMISSION.json')).read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['candidate_gzip_sha256'] and w['public']==680 and a['bad']==rec['forward_bad_output_rows'] and b['bad']==rec['adjoint_bad_output_rows']
 rows={str(i):{'forward_actual':m.keys(a['rows'][i]),'forward_expected':m.keys(ef[i]),'adjoint_actual':m.keys(b['rows'][i]),'adjoint_expected':m.keys(eb[i])} for i in (221,679,411)}
 rat=json.loads((P/'REPLAY-BLOCKS.json').read_text())['unchanged_rational_invoice']
 out['inputs'][n]={'word_sha256':rec['candidate_gzip_sha256'],'public':w['public'],'rows':rows,'failures':[len(a['bad']),len(b['bad'])],'all_forward_bad':a['bad'],'all_adjoint_bad':b['bad'],'owner411':rec['owner411'],'native_move_grades':rec['native_move_grades'],'paid_36':rec['all_36_call_paid_grades'],'productive_36':rec['all_36_call_productive_grades'],'paid_grade_delta_vs_source':rec['paid_grade_delta_vs_source'],'productive_grade_delta_vs_source':rec['productive_grade_delta_vs_source'],'binary_margin_00388':rec['binary_margin_00388'],'binary_margin_raw':rec['binary_margin_raw'],'unchanged_rational_paid_48':rat['paid'],'unchanged_rational_productive_48':rat['productive'],'unchanged_rational_margin_00388':rat['signed_margin_00388'],'451':rec['candidate_451'],'input_contract':rec['input_contract'],'stock':rec['word_and_stock_checks'],'rank_witness':rec['fixed_endpoint_first_rank_obstruction']}
serialized=json.dumps(out,indent=2,sort_keys=True)+'\n';receipt=P/'FRESH-REPLAYS.json'
if '--write' in sys.argv:receipt.write_text(serialized)
else:assert receipt.read_text()==serialized,'fresh replay receipt mismatch'
for n,x in out['inputs'].items():print(n,'failures',x['failures'],'rows',x['rows'],'paid_delta',x['paid_grade_delta_vs_source'],'prod_delta',x['productive_grade_delta_vs_source'],'margin',x['binary_margin_00388'],'rational',x['unchanged_rational_margin_00388'],'stock',x['stock'],'rank_witness',x['rank_witness'])
