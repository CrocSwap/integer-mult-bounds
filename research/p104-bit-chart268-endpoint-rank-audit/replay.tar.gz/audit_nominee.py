#!/usr/bin/env python3
"""Independent changed-word arithmetic/operator screen; never certifies kappa.

Read only the word named on the command line. Recount against the pinned old
36-call caller and compare the old endpoint contract. Native CLEAR is modeled
as source discard, not a proof of physical erasure. Owner mapping is a claim.
"""
import argparse, gzip, hashlib, importlib.util, json, sys
from collections import Counter
from decimal import Context, Decimal as D, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction as F
from pathlib import Path
spec=importlib.util.spec_from_file_location('independent_replay',Path(__file__).resolve().parent/'replay_blocks.py')
r=importlib.util.module_from_spec(spec);sys.modules[spec.name]=r;spec.loader.exec_module(r)
R=F(451)
def ratrank(rows):
 if not rows:return 0
 z=[[F(x) for x in a] for a in rows];i=0
 for col in range(len(z[0])):
  pivot=next((j for j in range(i,len(z)) if z[j][col]),None)
  if pivot is None:continue
  z[i],z[pivot]=z[pivot],z[i];q=z[i][col];z[i]=[x/q for x in z[i]]
  for j in range(i+1,len(z)):
   q=z[j][col]
   if q:z[j]=[a-q*b for a,b in zip(z[j],z[i])]
  i+=1
  if i==len(z):break
 return i
def frames(w):
 for c,x in w['frames'].items():
  a,b=x['A'],x['B'];assert x['dim']==len(b) and len(a)+len(b)==8 and all(len(row)==8 for row in a+b),c
  assert all(sum(F(u)*F(v) for u,v in zip(s,t))==0 for s in a for t in b),c
  assert ratrank(a+b)==8,c

def plusprod(a,b):return (r.L.multiply(a[0],b[0]),r.U.multiply(a[1],b[1]))
def ratio(a,b):
 assert a[0]>0 and b[0]>0
 return (r.L.divide(a[0],b[1]),r.U.divide(a[1],b[0]))
def ceilf(x,n=22):
 z=F(x)*10**n;return F(-((-z.numerator)//z.denominator),10**n)
def decimal_fraction(x):
 ctx=Context(prec=70,rounding=ROUND_FLOOR)
 return str(ctx.divide(D(x.numerator),D(x.denominator)))
def finite(p,t):
 raw=D('0.0038800000000000083');e=r.L.subtract(D(1),raw)
 assert e==r.U.subtract(D(1),raw)
 es=r.L.add(e,D('0.26'));et=r.L.subtract(e,D('0.34'))
 assert es==r.U.add(e,D('0.26')) and et==r.U.subtract(e,D('0.34'))
 T=r.moment(t,e);a=ratio(r.moment(p,e),T)
 g=ratio(r.moment(p,es),plusprod(r.power(11,D('0.26')),T))
 lam=ratio(plusprod(r.power(16,D('0.34')),r.moment(t,et)),T)
 ratios={'alpha':a,'gamma':g,'lambda':lam};out={'trial':str(raw),'ratio_bounds':{k:list(map(str,v)) for k,v in ratios.items()}}
 if any(v[0]>=1 for v in ratios.values()):out['status']='FAIL_PROVEN_RATIO_AT_LEAST_ONE';return out
 if any(v[1]>=1 for v in ratios.values()):out['status']='INDETERMINATE_INTERVAL_CROSSES_ONE';return out
 caps={k:ceilf(v[1]) for k,v in ratios.items()};out['outward_upper_caps_22_places']={k:str(v) for k,v in caps.items()}
 if any(v>=1 for v in caps.values()):out['status']='INDETERMINATE_ROUNDED_CAP_AT_LEAST_ONE';return out
 A,G,L=(caps[k] for k in ('alpha','gamma','lambda'))
 surplus=1-(1/(1+R*(1-A))+2*G**451+L**451)
 out['status']='PASS_STRICT_SUFFICIENT_451_ARITHMETIC_ONLY' if surplus>0 else 'NOT_PROVED_AT_22_PLACE_CAPS'
 out['outward_cap_surplus_lower']=decimal_fraction(surplus)
 return out

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--word',type=Path,required=True);ap.add_argument('--expected-sha256');ap.add_argument('--owner-map',type=Path);ap.add_argument('--corrupt-at',type=int);ap.add_argument('--out',type=Path);args=ap.parse_args()
 raw=args.word.read_bytes();sha=hashlib.sha256(raw).hexdigest()
 if args.expected_sha256:assert sha==args.expected_sha256,'expected candidate digest mismatch'
 w=json.loads(gzip.decompress(raw));old=r.load('source/inputs/WORD.json.gz');caller=r.load('source/inputs/EFREE-CALLER.json.gz');frames(w)
 n=w['public'];assert n>=222 and len(w['start'])==len(w['final'])==n
 if args.owner_map:
  owners=json.loads(args.owner_map.read_bytes());assert isinstance(owners,list) and len(owners)==n and len(set(owners))==n and owners[:222]==list(range(222))
  assert all((type(x) is int and 222<=x<680) or (isinstance(x,str) and x.startswith('new:') and len(x)>4) for x in owners[222:])
 else:
  assert n==680,'changed public count needs explicit owner map';owners=list(range(n))
 assert 411 in owners
 addr=owners.index(411);basef=r.replay(old);basep,baset,_,_=r.recount(old,basef['grades'],caller)
 f=r.replay(w,marker=addr);a=r.replay(w,True,marker=addr);assert f['grades']==a['grades']
 p,t,helpers,events=r.recount(w,f['grades'],caller);dp=Counter(p);dp.subtract(basep);dt=Counter(t);dt.subtract(baset)
 same_frames=all(w['frames'].get(key)==frame for key,frame in old['frames'].items())
 maincharts=(w['start'][:222]==old['start'][:222] and w['final'][:222]==old['final'][:222])
 endpoint411=[w['start'][addr],w['final'][addr]]==[old['start'][411],old['final'][411]]
 endpointblocks=r.blocks(w,f['rows']) if n==680 and w['start']==old['start'] and w['final']==old['final'] else []
 corruption=None
 if args.corrupt_at is not None:
  clock=args.corrupt_at;assert 0<=clock<len(w['program']) and w['program'][clock][0]=='ADD'
  cf=r.replay(w,False,clock,addr);ca=r.replay(w,True,clock,addr)
  changedf=[i for i in range(n) if f['rows'][i]!=cf['rows'][i]];changeda=[i for i in range(n) if a['rows'][i]!=ca['rows'][i]]
  assert changedf and changeda,'control ADD did not change both matrices'
  corruption={'omitted_add_clock':clock,'omitted_instruction':w['program'][clock],'changed_forward_rows':changedf,'changed_adjoint_rows':changeda,'candidate_sha_not_reused':True}
 no_bad=not f['bad'] and not a['bad'];invoice_same=t==baset
 x={'candidate_gzip_sha256':sha,'candidate_digest_independently_provided':bool(args.expected_sha256),'candidate_canonical_sha256':hashlib.sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'source_gzip_sha256':r.PINS['source/inputs/WORD.json.gz'],'caller_gzip_sha256':r.PINS['source/inputs/EFREE-CALLER.json.gz'],'owner_map':'self-reported file' if args.owner_map else 'identity assumed','public_owners':n,'owned_fields':w['owned_fields'],'input_contract':{'original_frames_preserved':same_frames,'original_222_main_endpoint_charts_preserved':maincharts,'owner411_index':addr,'owner411_endpoints_preserved':endpoint411,'complete_36_call_productive_bins_preserved':invoice_same},'word_and_stock_checks':{'valid_frames':True,'forward_source_locality_chronology_and_retirement':True,'adjoint_source_locality_chronology_and_retirement':True,'peak_live_private_forward':f['peak_live_private'],'peak_live_private_adjoint':a['peak_live_private'],'dirty_private_retirements_forward':f['dirty'],'dirty_private_retirements_adjoint':a['dirty'],'scope':'symbolic chart-tagged field lifetimes only; no physical erasure or funded stock proof'},'forward_bad_output_rows':f['bad'],'adjoint_bad_output_rows':a['bad'],'owner411':{'forward_row':r.keys(f['rows'][addr]),'adjoint_row':r.keys(a['rows'][addr]),'expected_both':[addr],'exact_rows':f['rows'][addr]==a['rows'][addr]==(1<<addr),'packets_with_mapped_owner_coordinate_forward':f['owner411_packet_support'],'packets_with_mapped_owner_coordinate_adjoint':a['owner411_packet_support'],'packet_scope':'mapped candidate address only; owner identity is self-reported'},'native_move_grades':dict(f['grades']),'all_36_call_paid_grades':dict(p),'all_36_call_productive_grades':dict(t),'paid_grade_delta_vs_source':{k:v for k,v in dp.items() if v},'productive_grade_delta_vs_source':{k:v for k,v in dt.items() if v},'binary_margin_00388':r.margin(p,t,'0.00388'),'binary_margin_raw':r.margin(p,t,'0.0038800000000000083'),'candidate_451':finite(p,t),'fixed_endpoint_block_rank_obstruction_count':len(endpointblocks) if n==680 and w['start']==old['start'] and w['final']==old['final'] else None,'fixed_endpoint_first_rank_obstruction':endpointblocks[0] if endpointblocks else None,'corruption_control':corruption,'screen_status':('PASS_LITERAL_AND_451_ARITHMETIC_ONLY' if finite(p,t)['status']=='PASS_STRICT_SUFFICIENT_451_ARITHMETIC_ONLY' else 'REJECT_OR_INDETERMINATE_451_ARITHMETIC') if (no_bad and same_frames and maincharts and endpoint411 and invoice_same) else 'REJECT_LITERAL_OR_FIXED_CALLER_CONTRACT','not_proved':['owner provenance or changed-caller occurrence ownership','physical erasure, funded stock, temporary work, occurrence identity','third source arithmetic engine and 451 tensor/compiler','finite cover, seed restoration, precision tape, analytic recovery','full 48-call application rebound to candidate and maintainer selection']}
 text=json.dumps(x,indent=2,sort_keys=True)+'\n'
 if args.out:args.out.write_text(text)
 else:print(text,end='')
 print('status',x['screen_status'],'forward/adjoint failures',len(f['bad']),len(a['bad']),'451',x['candidate_451']['status'],'sha',sha)
if __name__=='__main__':main()
