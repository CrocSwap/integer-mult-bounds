#!/usr/bin/env python3
"""Repeat the two newly supplied diagnostic-word checks."""
import json,subprocess,sys,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent
for name,digest in [('CPLUS-D','172cb1137452196536f96b422086d99352c493e4761eb13501195412f4995fbc'),('TRANSFER-719','a2b8143aeee67088df4065525900cb5d923659a1721ff6ed47edc1cf35310889')]:
 with tempfile.TemporaryDirectory(prefix='p104-fresh-') as d:
  out=Path(d)/'result.json'
  subprocess.run([sys.executable,'-I','-B',str(P/'audit_nominee.py'),'--word',str(P/('FRESH-'+name+'-WORD.json.gz')),'--expected-sha256',digest,'--out',str(out)],check=True,capture_output=True,text=True)
  assert out.read_bytes()==(P/('FRESH-'+name+'-ADMISSION.json')).read_bytes()
before=(P/'FRESH-REPLAYS.json').read_bytes();subprocess.run([sys.executable,'-I','-B',str(P/'fresh_summary.py')],check=True,capture_output=True,text=True);assert before==(P/'FRESH-REPLAYS.json').read_bytes()
x=json.loads(before)['inputs'];assert x['CPLUS-D']['failures']==[66,23] and x['TRANSFER-719']['failures']==[90,34]
for z in x.values():
 assert z['rows']['221']=={'forward_actual':[110,221],'forward_expected':[110,221],'adjoint_actual':[221],'adjoint_expected':[221]}
 for i in ('411','679'):
  assert z['rows'][i]=={'forward_actual':[int(i)],'forward_expected':[int(i)],'adjoint_actual':[int(i)],'adjoint_expected':[int(i)]}
 assert z['rank_witness']['actual_rank']==0 and z['rank_witness']['expected_rank']==1
 assert z['451']['status']=='PASS_STRICT_SUFFICIENT_451_ARITHMETIC_ONLY' and len(z['all_forward_bad'])>0
print('PASS: two distinct 680-owner damaged diagnostic words; no gain admitted')
