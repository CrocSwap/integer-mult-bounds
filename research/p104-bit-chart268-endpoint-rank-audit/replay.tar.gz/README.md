# P104 independent public-endpoint admission screen

This is a scoped literal and arithmetic screen, not a new κ result. It takes
both early-chart-268 diagnostic words from the archived predecessor, the
original 680-owner #7830 word and original 36-call paired caller. Exact source
hashes, source attribution and licenses are retained in `source/` and
`LICENSE`. The #7830 word gzip is pinned to
`d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

`replay_blocks.py` independently simulates all public inputs at once over
GF(2), checking source-chart locality, actual field lifetimes and every
strictly nested paid MOVE grade. It reverses the literal sequence and
transposes ADD separately for the adjoint. The stronger restored-side word
returns owners 221 and 679 correctly in both orientations, but has **89
forward and 29 adjoint incorrect public rows**. The single-route word has
104 and 29, respectively; its forward owner 221 is
`x17 + x110 + x221 + x266 + x267` instead of `x110 + x221`.

Even permitting arbitrary input and output linear changes within preserved
public endpoint charts cannot correct either candidate. In the forward
operator, the block from input chart 2 (owner 0 only) to output chart 525
(owner 111 only) is zero, whereas the required block is 1. Multiplication
by arbitrary local basis matrices cannot increase a zero block's rank. The
adjoint has the transposed obstruction from chart 525 to chart 2. The complete
rank-block census and the original owner-221-specific witness for the weaker
word are in `REPLAY-BLOCKS.json`. This statement does not exclude changes to
endpoint charts, moves, intermediate computations or a different caller.

The price recount uses every native MOVE in the old 36-call caller and all
caller queries, idles and productive roots. At κ = 0.00388 the restored-side
word's directed signed margin is +36.1548121756985078045996…; its complete
paid-bin change is 36 fewer grade-2, 36 fewer grade-5, and 36 more grade-6
charges, with the productive bins unchanged. The single-route margin is
+0.3481896197840974…. These are prices of incorrect operators. Separately,
the 48-call rational histogram is reconstructed from 48 native histograms
plus the caller's bins in the independently pinned baseline and matched to
#7830's separate `AUDIT.json`. Its unchanged directed signed margin at
0.00388 is +0.1389745223342527089…. This comparison does not rebind an outer
application to either candidate.

`audit_nominee.py` accepts a gzip candidate and optional owner map, validates
frame geometry and the field-level forward and adjoint chronology, reports
owner 411 and every paid and productive grade, recounts the complete original
caller and computes the candidate-specific 451 arithmetic at the diagnostic
raw `0.0038800000000000083` with outward rounding. It is fail-closed about
invalid words and the old caller interface. Example:

```
python3 -I -B audit_nominee.py --word CANDIDATE.json.gz \
  --expected-sha256 ACTUAL_HEX_DIGEST --owner-map OWNER-MAP.json --out RESULT.json
```

A supplied digest verifies equality to the digest supplied, not independent
provenance; the owner map is a self-commitment. The screen uses the original
111-port caller, and if the public count changes an explicit complete owner
map is required. New owners may be named `new:...`; the first 222 owners must
remain the original main owners. The full historical gate still has distinct
source and caller obligations. An alpha/gamma/lambda result is only the
sufficient numerical part of the source 451 test. The old word passes the
operator and caller-interface checks but provably fails its 451 alpha test;
the restored-side word passes 451 arithmetic and fails the operator checks.
Both statuses are rechecked in `verify.py`.

For a source control, the original owner-411 bridge ADD is removed and the
word is actually recompressed and rehashed: exactly forward row 411 and
adjoint row 411 then fail, although every invoiced grade is unchanged. A
separate rehashed restored-side word omitting its output-221 ADD fails 90
forward and 61 adjoint rows. Both controls, and the fixed endpoint witness,
are reconstructed and checked without overwriting the saved receipts by

```
python3 -I -B verify.py
```

The source's CLEAR semantics are symbolic discard. The screen does not prove
physical erasure, funded stock, earlier owner provenance, paid-occurrence
identity, a changed caller, third-engine full source caps, the 451 tensor
compiler, finite cover, seed restoration, precision tape, analytic recovery,
a changed-supplier 48-call application or maintainer selection.

## Independently replayed Round 10 controls

The exact CPLUS-D word from the chart-268 rebind and TRANSFER-719 word from the chart-635 relay are included with separate full replay receipts. Both preserve public owners 221, 411 and 679 in both orientations. CPLUS-D has 66 forward and 23 adjoint errors, and TRANSFER-719 has 90 and 34. The chart-2 to chart-525 rank-zero block is present in the two words even though the required block has rank one. Consequently changing invertible bases locally at the same endpoints cannot repair either operator.

The unchanged 48-call rational component was independently recounted. Both modified BIT profiles pass the numerical 451 inequality and fail the exact operator. The original erasure, physical stock, compiler, precision and outer application obligations remain. To repeat both fresh checks run `python3 -I -B fresh_verify.py` in this directory. The optional historic-checker comparison appears as a saved receipt, with its separate archive and scope recorded in FRESH-METADATA.json.
