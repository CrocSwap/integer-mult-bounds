#!/usr/bin/env python3
"""Portable independent operator/rank/invoice/corruption replay."""
import gzip,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
P=Path(__file__).resolve().parent
assert __debug__
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def regenerate(src,index,event):
 w=json.loads(gzip.decompress(src.read_bytes()));assert w['program'].pop(index)==event
 return gzip.compress(json.dumps(w,sort_keys=True,separators=(',',':')).encode(),mtime=0)
for old,index,event,new,expect in [
 ('source/inputs/WORD.json.gz',31289,['ADD',3553,411,509],'SOURCE-CORRUPTED-WORD.json.gz','74324556308a66c6659c998e6669be6ad1395c3375dbe2053476d8bbae2fcec2'),
 ('EARLY-268-RESTORED-SIDE-WORD.json.gz',33074,['ADD',3774,2876,635],'RESTORED-CORRUPTED-WORD.json.gz','e7afeea8e83803891ae786d45725b3b19622a4ece796bf2c7ea0e63aa4d754f0')]:
 raw=regenerate(P/old,index,event);assert raw==(P/new).read_bytes() and hashlib.sha256(raw).hexdigest()==expect
before=(P/'REPLAY-BLOCKS.json').read_bytes()
subprocess.run([sys.executable,'-I','-B',str(P/'replay_blocks.py')],check=True,capture_output=True,text=True)
assert before==(P/'REPLAY-BLOCKS.json').read_bytes()
paths=[
 ('source/inputs/WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9','BASELINE-ADMISSION.json',None),
 ('EARLY-268-RESTORED-SIDE-WORD.json.gz','84b53c2d8c69c77f9e36b45e238f8be7dae62e6a5ebffeac45c108fe7be0e98a','RESTORED-ADMISSION.json',33074),
 ('SOURCE-CORRUPTED-WORD.json.gz','74324556308a66c6659c998e6669be6ad1395c3375dbe2053476d8bbae2fcec2','SOURCE-CORRUPTED-ADMISSION.json',None),
 ('RESTORED-CORRUPTED-WORD.json.gz','e7afeea8e83803891ae786d45725b3b19622a4ece796bf2c7ea0e63aa4d754f0','RESTORED-CORRUPTED-ADMISSION.json',None)]
reports={}
with tempfile.TemporaryDirectory(prefix='p104-admission-') as d:
 for word,sha,receipt,omit in paths:
  output=Path(d)/receipt;cmd=[sys.executable,'-I','-B',str(P/'audit_nominee.py'),'--word',str(P/word),'--expected-sha256',sha,'--out',str(output)]
  if omit is not None:cmd+=['--corrupt-at',str(omit)]
  subprocess.run(cmd,check=True,capture_output=True,text=True)
  assert output.read_bytes()==(P/receipt).read_bytes(),receipt
  reports[receipt]=json.loads(output.read_bytes())
b=reports['BASELINE-ADMISSION.json'];s=reports['RESTORED-ADMISSION.json'];bad=reports['SOURCE-CORRUPTED-ADMISSION.json'];sb=reports['RESTORED-CORRUPTED-ADMISSION.json']
assert b['forward_bad_output_rows']==b['adjoint_bad_output_rows']==[] and b['candidate_451']['status']=='FAIL_PROVEN_RATIO_AT_LEAST_ONE'
assert len(s['forward_bad_output_rows'])==89 and len(s['adjoint_bad_output_rows'])==29 and s['candidate_451']['status']=='PASS_STRICT_SUFFICIENT_451_ARITHMETIC_ONLY'
assert s['fixed_endpoint_first_rank_obstruction']['actual_rank']==0 and s['fixed_endpoint_first_rank_obstruction']['expected_rank']==1
assert bad['forward_bad_output_rows']==bad['adjoint_bad_output_rows']==[411] and bad['paid_grade_delta_vs_source']=={}
assert len(sb['forward_bad_output_rows'])==90 and len(sb['adjoint_bad_output_rows'])==61
print('PASS: two independent word replays, endpoint rank witness, full invoice and rehashed corruption controls; no kappa admitted')
