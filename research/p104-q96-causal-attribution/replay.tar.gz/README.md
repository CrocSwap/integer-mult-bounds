# Hosted clique transfer: causal paths versus conservation attribution

This is a finite, reproducible check on the 96 hosted `X2,Y2` pairs in the
P104/#7113 native endpoint. It separates two different matrices that can both
be described informally as transfers through owned storage. The distinction
matters for the `hM` premise of #7852 `CFRelay.rendezvous_lemma_A_run`.

**Result.** In a complete native-valid synthetic word, with the checker’s
entire public input/output matrix correct, all eight hosted clique receipts
travel by public-only causal paths. Its causal public residual is `−I₈` and the
causal owned path sum is `0`. Independently computed FutureAttr-style lifetime
attribution gives owned matrix `−I₈` and public residual `0`, because it
credits the owned cleanup of the helpers. The synthetic word satisfies the
replayed Q96 cold and gather-then-deposit checks. Its `hG` premise is false;
this is not a counterexample to the Lean lemma or to `R ≥ 56`.

The source #7113 supplier word has a nonzero public-only path residual too:
its 8×8 residual has rational rank **2**, with 24 nonzero entries. Its direct
owned and hot-relay contributions have ranks 7 and 4, respectively. Together
with the residual they reproduce the native endpoint `−I₈`. The independent
conservation calculation yields owned attribution `−I₈` and public residual
zero for this particular execution. This exact-source computation does **not**
make it a FutureAttr/CF run: it has 24 selected-intake GTD violations, 60
selected `(intake,label)` cold violations, owned-to-owned gates and SCALEs.

## Inputs and reproduction

Run sequentially on one core with Python 3, standard library only:

```sh
cd /path/to/public
python3 -I -B trace.py
python3 -I -B cf_review.py
```

`trace.py` validates the input hashes, builds the synthetic words locally,
checks their full native endpoints with the unchanged independent verifier,
and independently performs exact rational causal path and conservation
replays. `cf_review.py` adapts the prior 96-port review for public-to-public
ADDs, updating public relay coefficients; it cross-checks cold/support,
chronology, relay inclusion, cost, hF, hG, and the attributed factorization
for the synthetic words. The sole other adaptation sets `H=0` while choosing
the *total effective value* for each node. Both are finite Python checks,
not Lean construction or checking. Inputs are package-relative. The archive
contains the referenced source material, its checker and prior review; see
`MANIFEST.sha256`; machine-generated result files are excluded because their
runtime fields vary. Regenerated JSON files contain exact matrices, source
indices, examples of failed actual-word hypotheses and native results.

Pins:

* #7113 commit `07a76c5e2738882c0cb322278e56f6cae3c9885d`, its original
  `research/signed-caller-8x9/replay/supplier7112/WORD.json.gz`, SHA256
  `fe0b1dc3049a6b72760a705af2e698e0e9998e969e19862a696eba63434eb233`;
  and its `short-caller/independent.py`, SHA256
  `21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874`.
* #7852 commit `41beda1d6435760dc99e38bd7e65f36798aad212`, exact-byte
  `FutureAttr.lean`, `CFChain.lean`, and `CFRelay.lean` in `inputs/rendezvous`.
  The authors credit DreamingOfClouds with Claude Opus 5.5, together with
  earlier P104 lineage. The #7113 supplier credits Rohan Arun with substantial
  OpenAI Codex assistance and its earlier lineage. The synthetic Q96 witness,
  its retiming and this extension were produced with OpenAI Codex. See
  `UPSTREAM-LICENSE` and upstream notices for the original material.

The original 96-port separator and retiming supplied the small synthetic input
`hG_all_retimed.json` (SHA256
`e882fc9b56aa26a987776cccb68264c1a68ad74c365f3a84e29b2b7e62011489`).
The original unmodified peer `review.py` is in `inputs/review`; only the
in-memory adaptations described above are made when it is called.

## Matrices and controls

The D-only clique consists of #7113 port indices
`[0,6,18,24,32,41,52,103]`, with respective labels
`[11,21,161,38,146,140,56,191]`. The replay recomputes all 64 F₂ dot products:
every pair, including each diagonal, is odd. Its inputs are the eight initial
`Y2` symbols and outputs the corresponding final `X2` coefficients.

For the *causal* replay, every chronological owned-to-public read creates a
node. An owned value is decomposed into a direct input row `F_k` and a sum of
prior node rows with coefficients `H[k,j]`; each output is a public-only row
`B` plus node rows with coefficients `G`. All rows are rational. Recursion
recomputes each physical node value independently and checks

```
endpoint = B + G (I + H + H² + ···) F.
```

The finite sum terminates by chronological node order. `causal_direct` in
`*.json` is `GF`; `causal_hot` is `G(H + H² + ···)F`. These read-nodes are
bookkeeping cuts, not claimed CFChain epochs, and causal `G` is **not** the
FutureAttr weight matrix. In particular, neither CF relay geometry nor the
CF lifetime-price accounting is assumed for this causal graph.

| Case | Full native endpoint | Causal `B` on clique | Causal `GF` | Causal hot term | Attributed owned | Public attribution residual | Q96 rise |
|---|---|---|---|---|---|---|---:|
| Retimed cold control | pass | `0` | `−I₈` | `0` | `−I₈` | `0` | 104 |
| One genuine hot relay | pass | `0` | diag `(0,−1,…,−1)` | `−e₁e₁ᵀ` | `−I₈` | `0` | 105 |
| One helper bypass | pass | `−e₁e₁ᵀ` | diag `(0,−1,…,−1)` | `0` | `−I₈` | `0` | 105 |
| Eight helper bypasses | pass | `−I₈` | `0` | `0` | `−I₈` | `0` | 112 |
| #7113 original supplier | pass | rank 2 | rank 7 | rank 4 | `−I₈` | `0` | 56 |

The one-relay word has an actual selected `H[3,2]=1` in the separate 96-port
peer-style replay. It is a genuinely hot path in the final clique transfer;
the added helper and all public inputs are restored. For each eight-bypass
helper, its arbitrary initial value is first copied through owned storage to
cancel the same value at the target; the helper then reads its `Y2`, sends it
directly to `X2`, and is restored by a subsequent owned cleanup. The helper
ends at the full chart. The full 416-input native endpoint passes, including
all helper inputs, rather than only the displayed 16 selected symbols.

`bypass_bad` changes the one-helper public output coefficient from −1 to −2.
The independent native checker reports bad inputs `[104,320]`, and the
clique's first diagonal becomes −2. This negative control is not a valid word.

All four valid synthetic cases have 96-port `hF=true`, `hG=false`, attributed
`rank(G N(H) F)=96`, and no selected GTD or cold violation according to the
adapted finite review. Their extra price, complete caller, ordinary work,
κ, and Lean realizability are not inferred from the displayed native rise.

## Scoped conservation identity

There is a useful **conditional** way to identify `hM` with the native hosted
receipts. It is a specialization of #7852 `FutureAttr.attribution_decoder`,
not a new universal word-to-CF bridge.

Suppose a finite run satisfies FutureAttr’s stated `ARun` hypotheses,
including GTD and cold intakes, public monotone charts, initial owned zeros,
and the actual #7113 endpoint on the selected input symbols. Use the
FutureAttr reference map `Fy = −I` and take one node for each attributed
owned lifetime. Let `G[t,k]` be its FutureAttr weight and let
`V[k,s] = val_k(y_s) + val_k(x_s)` be its total effective value. Include
all closed and final active owned rows. Conservation gives on the eight
clique labels

```
−I₈ = G V + R_public,
R_public[t,s] = Σ_public r W[r,t] (v_final(r)[y_s] + v_final(r)[x_s]).
```

The full native endpoint makes each parenthesized value zero except at the
corresponding unmodified public `Y2_s`, where it is one. Thus
`R_public[t,s] = W[Y2_s,t]`. FutureAttr’s public support invariant forces
`q_t` into `Y2_s`'s final chart `q_s⊥` when this weight is nonzero. Every
clique pair is odd, so the residual vanishes and `GV = −I₈`. This also yields
a rank-at-least-eight submatrix of the full selected matrix. The native
endpoint alone does not establish the FutureAttr run, support invariant or
one-node-per-lifetime representation.

If those rows are also supplied as `CFChain.Life` nodes and the actual CF
premises hold, one may choose `H=0`, `F=V`; any injective node enumeration
satisfies the relay hypotheses, and `G N(H) F = GV` supplies `hM`. This
choice requires **hF for the total effective lifetime values**, not merely
for innovation rows obtained after subtracting relay contributions. It also
requires hG and the corresponding lifecycle/cost construction. Neither
rank premise is automatic: the finite cases above all fail hG. The `H=0`
choice is an algebraic representation; it does not say physical hot relays
are absent. The package checks this particular choice for its examples, but
not for arbitrary words.

More generally, if an attributed relay representation has `V = F + H V`
and H is acyclic, then `N(H) F = V`, so the same clique identity would prove
`hM`. This algebra leaves open the substantive requirement that the chosen
increment rows have the CF cold support and rank dimensions and that the
actual H has the required legality and chronology. The physical-path bypass
above shows why those identifications cannot be replaced by the raw causal
output sensitivities or by assuming a small causal public residual.
