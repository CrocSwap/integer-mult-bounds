#!/usr/bin/env python3
"""Cross-check 96-port CF hypotheses, adapting the peer review to public ADDs.

This is a finite Python check. The upstream theorem takes a Lean Life and a
specific relay matrix; this does not prove an arbitrary word-to-Life bridge.
"""
import hashlib,json,sys,types
from pathlib import Path
OUT=Path(__file__).resolve().parent
R=OUT/'inputs/review'
assert hashlib.sha256((R/'review.py').read_bytes()).hexdigest() == '9b2af96c93c57b6647483663f077256c876b590ecbfb9b1435df091dcb1bdf99'
source=(R/'review.py').read_text()
old="PEER = Path('/tmp/p104-campaign/04-rendezvous')"
new="PEER = Path(__file__).resolve().parents[1] / 'rendezvous'"
assert source.count(old)==1;source=source.replace(old,new)
old="assert (r >= n) != (s >= n), 'this review expects public/owned transfers only'"
new="assert not (r >= n and s >= n), 'this adapted review excludes owned-to-owned transfers'"
assert source.count(old)==1;source=source.replace(old,new)
old="            else:\n                a = live[s]; a['B'] = join(a['B'], fs[c]); a['outputs'].append(tick)"
new="            elif s >= n:\n                a = live[s]; a['B'] = join(a['B'], fs[c]); a['outputs'].append(tick)"
assert source.count(old)==1;source=source.replace(old,new)
old="                carrier[r][a['id']] += coeff\n            tv = {xpos[r]: Q(1)} if r in xpos else {}"
new="""                carrier[r][a['id']] += coeff
            if r < n and s < n:
                for prev, v in list(carrier[s].items()): carrier[r][prev] += coeff*v
            tv = {xpos[r]: Q(1)} if r in xpos else {}"""
assert source.count(old)==1;source=source.replace(old,new)
mod=types.ModuleType('adapted_rendezvous_review');mod.__file__=str(R/'review.py')
exec(compile(source,str(R/'review.py'),'exec'),mod.__dict__)
# Alternative choice: nodes.u is each lifetime's total effective value and
# H=0. This is not an assertion that the physical execution has no relays.
old_H = 'H = {k: v for k, v in H.items() if v}'
assert source.count(old_H)==1
source_zero = source.replace(old_H, 'H = {}')
mod_zero=types.ModuleType('zero_relay_review');mod_zero.__file__=str(R/'review.py')
exec(compile(source_zero,str(R/'review.py'),'exec'),mod_zero.__dict__)
checker=mod.module(mod.PEER/'independent.py'); results={}
for case,p in [('cold',R/'hG_all_retimed.json'),('hot',OUT/'hot-word.json'),('bypass',OUT/'bypass-word.json'),('bypass_all',OUT/'bypass_all-word.json')]:
 w=json.loads(p.read_bytes());native=checker.native(w);assert not native['bad_inputs']
 z=mod.review(w,checker);z_zero=mod_zero.review(w,checker);results[case]={'word_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'review':z,'zero_relay_review':z_zero,'native':native}
 assert z_zero['hF'] and not z_zero['hG'] and z_zero['rank_GNF']==96 and z_zero['relays']==0
 assert z['hF'] and not z['hG'] and z['rank_GNF']==96
 if case=='hot':assert len(z['selected_relevant_relay_edges'])==1
 else:assert not z['selected_relevant_relay_edges']
 assert z['R']=={'cold':104,'hot':105,'bypass':105,'bypass_all':112}[case]
 print(case,'R',z['R'],'hF',z['hF'],'hG',z['hG'],'rank attributed GNF',z['rank_GNF'],'selected relays',z['selected_relevant_relay_edges'])
(OUT/'cf-results.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print('PASS_96_PORT_ATTRIBUTION_AND_CF_HYPOTHESES')
