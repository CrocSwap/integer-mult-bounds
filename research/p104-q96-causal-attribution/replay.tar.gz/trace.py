#!/usr/bin/env python3
"""Exact clique path-sum and conservation replay, one process.

Physical edge-cut decomposition is deliberately separate from FutureAttr's
conservation weights. Node k is each owned-to-public read; it is not a claimed
CF epoch, and H is not assumed to satisfy CF geometry or cost hypotheses.
"""
from fractions import Fraction as Q
from collections import defaultdict, Counter
from pathlib import Path
import copy, gzip, hashlib, importlib.util, json, sys, time

OUT=Path(__file__).resolve().parent
P=OUT/'inputs/rendezvous'
R=OUT/'inputs/review'
SRC=OUT/'inputs/WORD.json.gz'
SP=importlib.util.spec_from_file_location('checker',P/'independent.py'); ck=importlib.util.module_from_spec(SP);SP.loader.exec_module(ck)
CLIQUE=[0,6,18,24,32,41,52,103]
PINS={R/'hG_all_retimed.json':'e882fc9b56aa26a987776cccb68264c1a68ad74c365f3a84e29b2b7e62011489',SRC:'fe0b1dc3049a6b72760a705af2e698e0e9998e969e19862a696eba63434eb233',P/'independent.py':'21f46a8340331abb1486b50bd4e04453f1968b0a5950d86ff7780dd368590874',P/'source/FutureAttr.lean':'96a5bbeae59cf3720f94d6786a5a28e79e5050694f0c9cf3c256534291f30f8b',P/'source/CFChain.lean':'3b8ba0f997377c09c53c39b325edd06e039a5e813569014fc2b6b4b0e8a45991',P/'source/CFRelay.lean':'ca1f04f426fbe47fa60b2fb3a4ddb067f095fde5f4d4a9dfe565cb7d2da62323'}

def add(x,y,c=Q(1)):
 for k,v in y.items():
  z=x.get(k,Q(0))+c*v
  if z:x[k]=z
  else:x.pop(k,None)
def scale(x,c):
 return {k:c*v for k,v in x.items() if c*v}
def serial(M):return [[str(x) for x in row] for row in M]
def rank(A):
 A=[[Q(x) for x in row] for row in A];r=0
 for c in range(len(A[0])):
  k=next((i for i in range(r,len(A)) if A[i][c]),None)
  if k is None:continue
  A[r],A[k]=A[k],A[r];a=A[r][c];A[r]=[x/a for x in A[r]]
  for i in range(r+1,len(A)):
   a=A[i][c]
   if a:A[i]=[x-a*y for x,y in zip(A[i],A[r])]
  r+=1
 return r
def ortho(C,q):return all((a&q).bit_count()%2==0 for a in C)
def join(a,b):return frozenset(x^y for x in a for y in b)
def dim(a):return len(a).bit_length()-1

def trace(w, name):
 start=time.time(); n=w['public']; N=n+w['owned_fields']; m=len(CLIQUE)
 D=w['hosted']['Dports']; selected=[D.index(p) for p in CLIQUE]; xs=[w['hosted']['X2'][j] for j in selected];ys=[w['hosted']['Y2'][j] for j in selected]; labels=[w['ports'][p] for p in CLIQUE]
 assert len(set(xs+ys))==16 and all((a&b).bit_count()%2 for a in labels for b in labels)
 charts=[ck.span(f) for f in w['frames']];pos=list(w['initial'])+[None]*(N-n)
 assert all(labels[j] in charts[pos[xs[j]]] for j in range(m))
 # v represents exact X and Y symbol coefficients; base and carriers are an
 # independently represented cut-circuit over Y symbols plus emission nodes.
 v=[{} for _ in range(N)]; base=[{} for _ in range(N)];carry=[{} for _ in range(N)];weights=[{} for _ in range(N)]
 for j in range(m):v[xs[j]][j]=Q(1);v[ys[j]][m+j]=Q(1);base[ys[j]][j]=Q(1)
 xindex={r:j for j,r in enumerate(xs)};active=set(range(n));live={};closed=[];nodes=[]
 gtd=[];cold=[];copy_drops=[];w_support_fails=[];owned_owned=Counter();checked_intakes=0
 for tick,e in enumerate(w['program']):
  op,r=e[:2]
  if op=='INIT':
   assert r not in active and r>=n
   active.add(r);pos[r]=e[2];v[r]={};base[r]={};carry[r]={};weights[r]={}
   live[r]={'start':tick,'A':frozenset(range(512)),'B':frozenset({0}),'cost':0,'dep':False,'reg':r,'intakes':0,'outputs':0}
  elif op=='CLEAR':
   assert r in live and pos[r]==e[2]; rec=live.pop(r);rec['end']=tick;rec['w']=weights[r].copy();rec['val']=v[r].copy();closed.append(rec)
   active.remove(r);pos[r]=None;v[r]={};base[r]={};carry[r]={};weights[r]={}
  elif op=='MOVE':
   assert r in active and pos[r]==e[2];a,b=charts[e[2]],charts[e[3]]
   assert (a<b) if r<n else (a<b or b<a)
   if r>=n and a<b:live[r]['cost']+=dim(b)-dim(a)
   pos[r]=e[3]
  elif op=='SCALE':
   c=Q(e[2]);assert c and pos[r]==e[-1]
   # The target changes by (c-1)*old value, and its post-scale weight
   # is (W+(c-1)*tv)/c. This reduces to ordinary scaling off target.
   tv={xindex[r]:Q(1)} if r in xindex else {}
   z=weights[r].copy();add(z,tv,c-1);weights[r]=scale(z,1/c)
   v[r]=scale(v[r],c);base[r]=scale(base[r],c);carry[r]=scale(carry[r],c)
  else:
   assert op in ('ADD','COPY');src=e[2];c=Q(e[3]);fr=e[4]
   assert src in active and r in active and src!=r and pos[r]==pos[src]==fr and c
   if op=='COPY':
    # An overwrite invalidates the elementary conservation update unless the
    # old projected content and old ownership weight vanish.
    if v[r] or weights[r] or base[r] or carry[r]:copy_drops.append((tick,r,src))
    assert not (v[r] or weights[r] or base[r] or carry[r]),('nonzero copy dest',tick)
   if r>=n:
    rec=live[r];rec['intakes']+=1;checked_intakes+=1
    if rec['dep']:gtd.append((tick,r,src))
    ef={j:v[src].get(m+j,Q(0))+v[src].get(j,Q(0)) for j in range(m)}
    for j,z in ef.items():
     if z and not ortho(charts[fr],labels[j]):cold.append((tick,r,src,CLIQUE[j]))
    rec['A'] &= charts[fr]
   if r<n and src>=n:
    rec=live[src];rec['dep']=True;rec['outputs']+=1;rec['B']=join(rec['B'],charts[fr]);node=len(nodes)
    assert all(j<node for j in carry[src])
    nodes.append({'tick':tick,'reg':src,'dest':r,'coef':c,'f':base[src].copy(),'h':carry[src].copy(),
                  'actual':{j:v[src].get(m+j,Q(0)) for j in range(m) if v[src].get(m+j,Q(0))}})
    carry[r][node]=carry[r].get(node,Q(0))+c
   else:
    if r>=n and src>=n:owned_owned['gates']+=1
    add(base[r],base[src],c);add(carry[r],carry[src],c)
   tv={xindex[r]:Q(1)} if r in xindex else {}
   z=tv.copy();add(z,weights[r],-1);add(weights[src],z,c)
   add(v[r],v[src],c)
   if src<n:
    for j in weights[src]:
     if labels[j] not in charts[pos[src]]:
      if len(w_support_fails)<20:w_support_fails.append((tick,src,CLIQUE[j]))
 assert not live and active==set(range(n)) and pos[:n]==w['final']
 # Calculate causal node values strictly from f, H; compare independently
 # tracked exact physical rows and then propagate to clique outputs.
 values=[]
 for k,nd in enumerate(nodes):
  acc=nd['f'].copy()
  for j,h in nd['h'].items():add(acc,values[j],h)
  assert acc==nd['actual'],('node path mismatch',name,k,acc,nd['actual'])
  values.append(acc)
 B=[[base[xs[t]].get(s,Q(0)) for s in range(m)] for t in range(m)]
 full=[[v[xs[t]].get(m+s,Q(0)) for s in range(m)] for t in range(m)]
 direct=[[Q(0) for _ in range(m)] for _ in range(m)]
 hot=[[Q(0) for _ in range(m)] for _ in range(m)]
 for t in range(m):
  for k,g in carry[xs[t]].items():
   for s,z in nodes[k]['f'].items():direct[t][s]+=g*z
   acc=values[k].copy();add(acc,nodes[k]['f'],-1)
   for s,z in acc.items():hot[t][s]+=g*z
 assert all(full[t][s]==B[t][s]+direct[t][s]+hot[t][s] for t in range(m) for s in range(m)),('path endpoint mismatch',name)
 # FutureAttr independently accumulated conservation matrix on each closed
 # owned lifetime; all vectors include 8 x-symbols plus 8 y-symbols.
 O=[[Q(0) for _ in range(m)] for _ in range(m)]
 for rec in closed:
  for t,g in rec['w'].items():
   for s in range(m): O[t][s]+=g*(rec['val'].get(m+s,Q(0))+rec['val'].get(s,Q(0)))
 Pm=[[Q(0) for _ in range(m)] for _ in range(m)]
 contributions=[]
 for r in range(n):
  for t,g in weights[r].items():
   for s in range(m):
    a=g*(v[r].get(m+s,Q(0))+v[r].get(s,Q(0)))
    Pm[t][s]+=a
    if a and len(contributions)<30:contributions.append((r,CLIQUE[t],CLIQUE[s],str(a)))
 # End-start target x and y parts, then eliminate x using Fy=-I.
 delta=[[v[xs[t]].get(m+s,Q(0))+(v[xs[t]].get(s,Q(0))-int(t==s)) for s in range(m)] for t in range(m)]
 assert all(delta[t][s]==O[t][s]+Pm[t][s] for t in range(m) for s in range(m)),('attribution mismatch',name)
 expected=[[Q(-int(t==s)) for s in range(m)] for t in range(m)]
 native=ck.native(w)
 errors={'endpoint_bad_inputs':native['bad_inputs'],'full_is_minus_identity':full==expected,'delta_is_minus_identity':delta==expected}
 matching_public_support=sum(len(a) for a in weights[:n]);activepub=[r for r in range(n) if weights[r]]
 return dict(name=name,seconds=round(time.time()-start,3),events=len(w['program']),nodes=len(nodes),node_edges=sum(len(nd['h']) for nd in nodes),
  initial_selected={'indices':CLIQUE,'labels':labels,'xs':xs,'ys':ys},endpoint=serial(full),public_bypass=serial(B),causal_direct=serial(direct),causal_hot=serial(hot),
  attributed_owned=serial(O),attributed_public_residual=serial(Pm),public_residual_terms=contributions,
  public_weight_support_failures=w_support_fails,public_weight_count=matching_public_support,weighted_public_fields=len(activepub),
  intake_count=checked_intakes,gtd_failures=len(gtd),gtd_examples=gtd[:15],cold_failures=len(cold),cold_examples=cold[:15],
  owned_owned_gates=owned_owned['gates'],copy_nonzero_drops=copy_drops,epochs=len(closed),native=native,
  relevant_nodes=[{'id':k,'tick':d['tick'],'src':d['reg'],'dest':d['dest'],'f':{str(j):str(z) for j,z in d['f'].items()},'h':{str(j):str(z) for j,z in d['h'].items()},'g':{str(t):str(carry[xs[t]].get(k)) for t in range(m) if carry[xs[t]].get(k)}} for k,d in enumerate(nodes) if any(carry[xs[t]].get(k) for t in range(m))][:20],errors=errors)

def mutate(w,variant):
 w=copy.deepcopy(w);x=w['hosted']['X2'][0];y=w['hosted']['Y2'][0];h=104;n=w['public'];z=w['initial'][y];line=w['initial'][x]
 assert z==w['initial'][h] and line==w['final'][h]
 i=next(i for i,e in enumerate(w['program']) if e[0]=='COPY' and e[2]==y)
 own=w['program'][i][1]; assert w['program'][i-1:i+4]==[['INIT',own,z],['COPY',own,y,'1',z],['MOVE',own,z,line,True],['ADD',x,own,'-1',line],['CLEAR',own,line]]
 if variant=='hot':
  # Preserve the arbitrary initial helper value h: deliver +h to X before
  # the helper is changed. The hot route later delivers -(h+y).
  p=n+w['owned_fields'];q=p+1;aux=p+2;w['owned_fields']+=3
  body=[['INIT',aux,z],['COPY',aux,h,'1',z],['MOVE',aux,z,line,True],['ADD',x,aux,'1',line],['CLEAR',aux,line],
        ['INIT',p,z],['COPY',p,y,'1',z],['ADD',h,p,'1',z],['CLEAR',p,z],
        ['INIT',own,z],['COPY',own,h,'1',z],['MOVE',own,z,line,True],['ADD',x,own,'-1',line],['CLEAR',own,line],
        ['INIT',q,z],['COPY',q,y,'1',z],['ADD',h,q,'-1',z],['CLEAR',q,z]]
 elif variant=='bypass':
  # +h cancels the helper's independent initial input. The following public
  # gate supplies -y to X; a later owned cleanup restores helper = h.
  # End already has helper z->line, so remove that later duplicate move.
  aux=n+w['owned_fields'];w['owned_fields']+=1
  body=[['INIT',aux,z],['COPY',aux,h,'1',z],['MOVE',aux,z,line,True],['ADD',x,aux,'1',line],['CLEAR',aux,line],
        ['ADD',h,y,'1',z],['MOVE',h,z,line,False],['ADD',x,h,'-1',line],
        ['INIT',own,z],['COPY',own,y,'1',z],['MOVE',own,z,line,True],['ADD',h,own,'-1',line],['CLEAR',own,line]]
  j=next(j for j,e in enumerate(w['program']) if e==['MOVE',h,z,line,False]);assert j>i
  del w['program'][j]
 elif variant=='bypass_bad':
  v=mutate(w,'bypass');p=v['program'];j=next(j for j,e in enumerate(p) if e[0]=='ADD' and e[1]==x and e[2]==h);p[j][3]='-2';return v
 else:raise ValueError(variant)
 w['program'][i-1:i+4]=body
 return w

def bypass_all(word):
 """Use eight disjoint public helpers; preserve each arbitrary input."""
 w=copy.deepcopy(word);n=w['public'];top=w['final'][w['hosted']['X2'][0]];D=w['hosted']['Dports'];replacements=[]
 for j,port in enumerate(CLIQUE):
  k=D.index(port);x=w['hosted']['X2'][k];y=w['hosted']['Y2'][k];h=104+j;z=w['initial'][y];line=w['initial'][x]
  assert w['initial'][h]==z and w['final'][h]==w['initial'][w['hosted']['X2'][0]]
  i=next(i for i,e in enumerate(w['program']) if e[0]=='COPY' and e[2]==y)
  own=w['program'][i][1];assert w['program'][i-1:i+4]==[['INIT',own,z],['COPY',own,y,'1',z],['MOVE',own,z,line,True],['ADD',x,own,'-1',line],['CLEAR',own,line]]
  aux=n+w['owned_fields'];w['owned_fields']+=1
  body=[['INIT',aux,z],['COPY',aux,h,'1',z],['MOVE',aux,z,line,True],['ADD',x,aux,'1',line],['CLEAR',aux,line],
        ['ADD',h,y,'1',z],['MOVE',h,z,line,False],['ADD',x,h,'-1',line],
        ['INIT',own,z],['COPY',own,y,'1',z],['MOVE',own,z,line,True],['ADD',h,own,'-1',line],['CLEAR',own,line]]
  replacements.append((i-1,i+4,body))
  q=next(i for i,e in enumerate(w['program']) if e[0]=='MOVE' and e[1]==h)
  assert q>i and w['program'][q][2]==z and not w['program'][q][4]
  w['program'][q][2:4]=[line,top];w['final'][h]=top
 for lo,hi,body in sorted(replacements,reverse=True):w['program'][lo:hi]=body
 return w

def main():
 for p,pin in PINS.items():assert hashlib.sha256(p.read_bytes()).hexdigest()==pin,p
 source=json.loads(gzip.decompress(SRC.read_bytes())); base=json.loads((R/'hG_all_retimed.json').read_bytes())
 cases=[('cold',base),('hot',mutate(base,'hot')),('bypass',mutate(base,'bypass')),('bypass_bad',mutate(base,'bypass_bad')),('bypass_all',bypass_all(base)),('source7113',source)]
 outputs={}
 for name,w in cases:
  print('starting',name,flush=True)
  if name in ('hot','bypass','bypass_all'):
   (OUT/(name+'-word.json')).write_text(json.dumps(w,sort_keys=True,separators=(',',':'))+'\n')
  z=trace(w,name);outputs[name]=z
  if name=='bypass_bad':
   assert z['errors']['endpoint_bad_inputs']==[104,320] and z['endpoint'][0][0]=='-2'
  else:
   assert not z['errors']['endpoint_bad_inputs'] and z['errors']['full_is_minus_identity']
  if name!='source7113':assert z['gtd_failures']==z['cold_failures']==0
  if name=='source7113':
   assert rank(z['public_bypass'])==2 and rank(z['causal_direct'])==7 and rank(z['causal_hot'])==4
   assert z['gtd_failures']==24 and z['cold_failures']==60
  if name=='hot':
   assert z['causal_direct'][0][0]=='0' and z['causal_hot'][0][0]=='-1'
  if name=='bypass_all':
   neg=[['-1' if i==j else '0' for j in range(8)] for i in range(8)]
   zero=[['0']*8 for i in range(8)]
   assert z['public_bypass']==neg and z['causal_direct']==zero and z['causal_hot']==zero
   assert z['attributed_owned']==neg and z['attributed_public_residual']==zero
  print('finished',name,'seconds',z['seconds'],'nodes/edges',z['nodes'],z['node_edges'],'bad',len(z['errors']['endpoint_bad_inputs']),'gtd/cold',z['gtd_failures'],z['cold_failures'],flush=True)
  (OUT/(name+'.json')).write_text(json.dumps(z,indent=2,sort_keys=True)+'\n')
 (OUT/'results.json').write_text(json.dumps(outputs,indent=2,sort_keys=True)+'\n')
 print('PASS_PATH_SUM_AND_CONSERVATION',flush=True)
if __name__=='__main__':main()
