# Check paid adjoint island retargets and their causal limits

For the {0,137,401} adjoint island, 131 third retargets of existing paid packets cross both deficient cuts and can restore static anonymous capacity. Thirty-one restore fixed-slot capacity and each fails terminal decoding when all direct readers can recode while surrounding equations are fixed.

All 100 deficient fixed-slot cuts, two explicit 680 flows and both boundaries of all 131 timing windows replay. All 131 have some anonymous capacity window. All 15 routes for 3328 fail the actual owner-80 reachability test at every insertion gap. Three 3299 routes cannot include x111, x137 or x191 in their emitter payload, and other paths would need to supply those directions.

Change upstream equations or add an independently funded contact. Use simultaneous decoder tests in the retained windows. This archive uses the corrected directed tariff H(g)=g^(1−κ).

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. Both cold exports passed 38+29 manifest entries, both pinned operator checks, all named static and chronological cut controls, 3,108 pairwise transports, the corrected directed tariff and the emitter analysis.
