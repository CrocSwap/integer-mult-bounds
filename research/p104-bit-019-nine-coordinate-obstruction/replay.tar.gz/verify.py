# SPDX-License-Identifier: Apache-2.0
"""Nine selected input coordinates force a changed paid value on the 0-to-19 topology."""
from collections import Counter,defaultdict
from functools import reduce
from operator import xor
from pathlib import Path
import argparse,gzip,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source'))
import common
import bit_native
import binary_operator as op

ANCHORS=(22,51,77,91,92,96,97,98,100)
SEED=1<<3410
H=679
def require(q,description):
    if not q:raise ValueError(description)
def indices(x):
    while x:
        bit=x&-x
        yield bit.bit_length()-1
        x^=bit
def xors(rows):return reduce(xor,rows,0)
def par(x):return x.bit_count()%2
class Basis:
    def __init__(self):self.rows={}
    def reduce(self,v,tag=0):
        while v:
            t=self.rows.get(v.bit_length()-1)
            if t is None:break
            v^=t[0];tag^=t[1]
        return v,tag
    def add(self,v,tag=0):
        v,tag=self.reduce(v,tag)
        if not v:return False
        self.rows[v.bit_length()-1]=(v,tag);return True
class Equations:
    def __init__(self,copy=None):self.rows={} if copy is None else copy.rows.copy()
    def insert(self,r,b):
        while r:
            key=r.bit_length()-1
            if key not in self.rows:
                self.rows[key]=(r,b);return True
            u,v=self.rows[key];r^=u;b^=v
        return not b
    def solution(self,free=0):
        x=free
        for k,(r,b) in sorted(self.rows.items()):
            if par(r&x)!=b:x^=1<<k
        return x
def build():
    word,caller,_,_,helpers,oldpaid,productive,rat=common.baseline()
    init,final,moves,rr,_=bit_native.extract(word)
    del moves[3409],rr[3409]
    moves[1583]=(19,182);moves[3410]=(421,0);moves[3554]=(0,19)
    rr[3554]=1<<549;rr[1583]=1<<3554
    rr[3410]=(1<<1934)|(1<<2234)|(1<<2947)
    schedule=bit_native.schedule(init,final,moves,rr)
    stock=defaultdict(list);out=defaultdict(list);term=defaultdict(list)
    values={i:1<<i for i in init};tag={};terminal_tag={}
    for i,c in init.items():stock[c].append(i)
    for i,c in final.items():term[c].append(i)
    for j in schedule:
        donors=list(indices(rr[j]))
        # This externally supplied e17 defines a reference transfer only.
        values[j]=xors(values[p] for p in donors)^((1<<17) if j==3410 else 0)
        tag[j]=(1<<j)^xors(tag[p] for p in donors if p in tag)
        a,b=moves[j];stock[b].append(j);out[a].append(j)
    for i in init:
        require(xors(values[p] for p in indices(rr[~i]))==op.expected_operator(False)[i],'reference outputs')
        terminal_tag[i]=xors(tag[p] for p in indices(rr[~i]) if p in tag)
    atlas=op.Atlas(word['frames']);nf=op.run_tape(word,atlas,False)
    require(all(values[p]==row.arrival.row for p,row in nf.packets.items() if p!=3409),'native reference on retained identifiers')
    require(values[3554]==1<<549,'new contact reference')
    return word,caller,init,final,moves,rr,stock,out,term,values,tag,terminal_tag,helpers,productive,rat
def local_generators(stock,values,tags,anchors):
    mask=sum(1<<i for i in anchors)
    allg={}
    for c,ids in stock.items():
        b=Basis();sig=Basis();gen=[]
        for j in ids:
            fixed,rep=b.reduce(values[j]&mask,1<<j)
            if fixed:
                b.add(fixed,rep);continue
            # rep annihilates the fixed projection. Its noncentral two-bit value
            # is the nominal part plus the impulse parity from its packet ancestors.
            v=xors(values[p] for p in indices(rep));t=xors(tags[p] for p in indices(rep) if p in tags)
            m=(v>>17&1)|((v>>H&1)<<1)
            if sig.add((t<<2)|m):gen.append((m,t))
        if gen:allg[c]=gen
    return allg
def possible_axis(axis,gens,out):
    active=set(gens);seed=SEED if axis==0 else 0
    at={c:sum(1<<p for p in out[c]) for c in active}
    while True:
        candidates=0
        for c in active:candidates|=at[c]
        new={c for c in active if any(((m>>axis&1)^par(t&seed)) or t&candidates for m,t in gens[c])}
        if new==active:return candidates,active
        active=new
def helper_assignments(moves,term,nominal,tags,endtags,options,active,S):
    eq=Equations()
    for c,ends in term.items():
        if c not in active:
            for i in ends:require(eq.insert(endtags[i]&options,0),'inactive helper terminal compatible')
    for j,(a,b) in moves.items():
        if a not in S or b not in S:
            require(eq.insert(tags[j]&options,nominal[j]>>H&1),'round-trip source cut compatible')
    free=[k for k in indices(options) if k not in eq.rows]
    require(len(free)<=12,'bounded remaining helper dimension')
    result=[]
    for m in range(1<<len(free)):
        chosen=sum(1<<p for k,p in enumerate(free) if m>>k&1)
        result.append(eq.solution(chosen))
    return result
def solve_old(gens,out,term,endtags,oldopts,helper):
    entries=[];eq=Equations();reason=None
    # Put charts with few nominal generators first to get concrete contradictions early.
    scopes=sorted(set(out)|set(term),key=lambda c:(len(out[c])+len(term[c])>100,len(gens.get(c,[])),c))
    for c in scopes:
        gen=gens.get(c,[]);pivot=None;kernel=[]
        for m,t in gen:
            h=(m>>1&1)^par(t&helper)
            eq17=(t&oldopts,(m&1)^par(t&SEED))
            if not h:kernel.append(eq17)
            elif pivot is None:pivot=eq17
            else:kernel.append((eq17[0]^pivot[0],eq17[1]^pivot[1]))
        kernel=[(v,b) for v,b in kernel if v or b]
        always_free=(0,1) in kernel
        want=[]
        for j in out[c]:want.append((helper>>j&1,(1<<j)&oldopts,0))
        for i in term[c]:
            t=endtags[i];want.append((par(t&helper),t&oldopts,par(t&SEED)))
        missing_low=any(bit and pivot is None for bit,_,_ in want)
        if missing_low:return dict(consistent=False,stage='helper-stock',chart=c,nodes=0)
        if always_free:continue
        constraints=[]
        for bit,r,b in want:
            if bit:r^=pivot[0];b^=pivot[1]
            if r or b:constraints.append((r,b))
        if not constraints:continue
        if not kernel:
            if any(not eq.insert(r,b) for r,b in constraints):
                return dict(consistent=False,stage='forced-linear',chart=c,nodes=0)
        else:entries.append((kernel,constraints))
    nodes=0
    def visit(system,i):
        nonlocal nodes
        nodes+=1
        if i==len(entries):return system.solution()
        kernel,required=entries[i];zero=Equations(system)
        for r,b in kernel:
            nonzero=Equations(zero)
            if nonzero.insert(r,b^1):
                solution=visit(nonzero,i+1)
                if solution is not None:return solution
            if not zero.insert(r,b):return None
        if all(zero.insert(r,b) for r,b in required):return visit(zero,i+1)
        return None
    solution=visit(eq,0)
    return dict(consistent=solution is not None,stage='all-local-stocks',nodes=nodes,conditional_charts=len(entries))
def physical(word,init,final,moves,rows,atlas,anchors):
    order=bit_native.schedule(init,final,moves,rows);changed=bit_native.emit_word(word,init,final,moves,rows,order)
    tapes=[op.run_tape(changed,atlas,r) for r in (False,True)]
    wrong=[[i for i,(x,y) in enumerate(zip(t.output,op.expected_operator(r))) if x!=y] for r,t in zip((False,True),tapes)]
    columns=tuple(anchors)+(17,H);bad_proj=[i for i in columns if i in wrong[1]]
    return dict(canonical_word=op.canonical_hash(changed),full_errors=list(map(len,wrong)),projected_wrong_columns=bad_proj,
                paid_grades=dict(sorted(Counter(p.grade for p in tapes[0].packets.values()).items())),owner411=[411 not in q for q in wrong])
def run():
    word,caller,init,final,moves,rr,stock,out,term,values,tags,endtags,helpers,productive,rat=build()
    atlas=op.Atlas(word['frames'])
    c=json.loads((ROOT/'HELPER-CUT.json').read_text());S=set(c['charts'])
    inside=sum(1<<i for i,c in init.items() if c in S)
    b=Basis()
    for i,c in final.items():
        if c not in S:b.add(op.expected_operator(False)[i]&inside)
    cap=sum(a in S and z not in S for a,z in moves.values())
    require(cap==len(b.rows)==545 and init[H] in S and final[H] in S,'545-row tight owner-679 cut')
    gens=local_generators(stock,values,tags,ANCHORS)
    oldopts,oldactive=possible_axis(0,gens,out);hopts,hactive=possible_axis(1,gens,out)
    choices=helper_assignments(moves,term,values,tags,endtags,hopts,hactive,S)
    results=[]
    for h in choices:
        status=solve_old(gens,out,term,endtags,oldopts,h)
        require(not status['consistent'],'every helper assignment fails even with free historical stock')
        results.append(dict(helper_impulses=list(indices(h)),**status))
    require(len(choices)==8,'complete helper census')
    # Physical positive control pays a separate e17 receipt and reconstructs the whole native transfer.
    positive_moves=dict(moves);positive_rows=dict(rr);positive_moves[3555]=(19,421);positive_rows[3555]=1<<17
    positive_rows[3410]^=1<<3555
    positive=physical(word,init,final,positive_moves,positive_rows,atlas,ANCHORS)
    require(positive['full_errors']==[0,0] and positive['owner411']==[True,True],'paid relaxation is physically complete')
    control=physical(word,init,final,moves,rr,atlas,ANCHORS)
    require(control['projected_wrong_columns']==[17],'only 17 of the eleven retained columns fails the baseline control')
    releases=[]
    # A single actual chart-0 bank XOR, used in every old 3410 reader, can repair selected relaxations.
    for drop in ANCHORS:
        J=tuple(i for i in ANCHORS if i!=drop);mask=sum(1<<i for i in J+(17,H))
        bank=Basis()
        for p in stock[0]:
            v=values[p]^((1<<17) if p==3410 else 0)
            bank.add(v&mask,1<<p)
        residual,donors=bank.reduce(1<<17)
        if residual:
            releases.append(dict(drop=drop,single_chart0_correction=False,projected_bank_rank=len(bank.rows)))
            continue
        rows=dict(rr)
        for j,v in rr.items():
            if v>>3410&1:rows[j]^=donors
        receipt=physical(word,init,final,moves,rows,atlas,J)
        require(not receipt['projected_wrong_columns'] and all(receipt['full_errors']), 'released-column control passes both projected obligations and fails the full map')
        changed_within=[]
        # Independently evaluate each paid row of the physical correction on the eight frozen columns.
        sequence=bit_native.schedule(init,final,moves,rows);v={i:1<<i for i in init}
        for p in sequence:
            v[p]=xors(v[j] for j in indices(rows[p]))
            if (v[p]^values[p])&sum(1<<i for i in J):changed_within.append(p)
        require(not changed_within,'eight frozen components survive on every paid packet')
        releases.append(dict(drop=drop,single_chart0_correction=True,chart0_receipts=list(indices(donors)),**receipt))
    require([r['drop'] for r in releases if r['single_chart0_correction']]==[51,92,100],'three explicit released-input controls')
    profiles={}
    rational=rat['signed'];rp={int(k):v for k,v in rational['paid'].items()};rt={int(k):v for k,v in rational['productive'].items()}
    for name,obj in [('funded',control),('direct_positive',positive)]:
        full,prod=common.literal.paired_invoice(caller,Counter(obj['paid_grades']),helpers,Counter(e[0] for e in caller['events']))
        require(prod==productive,'fixed caller productive ranks')
        profiles[name]=dict(paid=dict(sorted(full.items())),productive=dict(sorted(prod.items())),rates={s:dict(
            binary=common.display(common.moment(full,prod,common.D(s))),rational=common.display(common.moment(rp,rt,common.D(s))))
            for s in ['0.00388','0.0038800000000000083']})
    return dict(native_word=op.WORD,native_gzip=op.WORD_GZIP,frozen_columns=ANCHORS,free_columns=680-len(ANCHORS),
              constraints='Every paid vector agrees on the nine coordinates with the labeled native reference; new 0-to-19 has zero projection there. Every sender including 3553 and all terminal decoders are free otherwise.',
              helper_cut_rank=cap,helper_active_charts=len(hactive),axis17_active_charts=len(oldactive),released_all_senders=True,
              signed_profiles=profiles,helper_assignments=results,funded_diagnostic=control,one_unfunded_grade5_complete=positive,one_release_controls=releases)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--write',action='store_true');args=ap.parse_args()
    receipt=json.dumps(run(),sort_keys=True,indent=2)+'\n'
    if args.write:(ROOT/'RESULT.json').write_text(receipt)
    else:require((ROOT/'RESULT.json').read_text()==receipt,'deterministic receipt')
    print('PASS: all eight helper profiles excluded with nine frozen input columns; three one-column released diagnostic controls and the complete paid relaxation replayed.')
