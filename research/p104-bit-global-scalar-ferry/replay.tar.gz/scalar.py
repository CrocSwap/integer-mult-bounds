# SPDX-License-Identifier: Apache-2.0
"""Arbitrarily many chronological changes modulo the lost packet's binary line."""
from collections import Counter, defaultdict
from functools import lru_cache
from time import monotonic
from network import *

class Direction:
    def __init__(self, reverse=False):
        self.reverse = reverse
        self.order = O[::-1] if reverse else O
        self.rank = {p:i for i,p in enumerate(self.order)}
        self.routes,self.rows,self.value,self.influence,self.paths = (DR,DROWS,Y,X,DPA) if reverse else (R,ROWS,X,Y,PATH)
        self.owners = range(W['public'])
        self.start,self.final = (W['final'],W['start']) if reverse else (W['start'],W['final'])
        self.send = defaultdict(list)
        inputs = defaultdict(list)
        for i,c in enumerate(self.start):
            inputs[c].append((i,1<<i))
        for p in self.order:
            a,b=self.routes[p]
            self.send[a].append(p)
            inputs[b].append((p,self.value[p]))
        self.for_chart = defaultdict(int)
        for i,c in enumerate(self.final):
            self.for_chart[c] |= 1<<i
        self.bank={}
        for c,arrivals in inputs.items():
            bs=Span()
            for label,row in arrivals:
                if not bs.add(row,1<<label):
                    raise ValueError('historical chart stock dependent')
            self.bank[c]=bs

    @lru_cache(None)
    def locations(self,x):
        spots={}
        for c,base in self.bank.items():
            coeff=base.express(x)
            if coeff is None:
                continue
            packets=[p for p in labels(coeff) if p in self.rank]
            first=max((self.rank[p] for p in packets),default=-1)
            sends=tuple(p for p in self.send[c] if self.rank[p]>first)
            spots[c] = (coeff, xsum(self.paths[p] for p in packets), sends)
        return spots

    def solve(self,hole):
        """Branch on actual availability. Fixed row deletion and all other shapes stay fixed."""
        x=self.value[hole]
        allspots = self.locations(x)
        # The original stock is independent and the sole representation at the
        # receiver is the missing label itself. A scalar recode on any number of
        # other arrivals there cannot create x.
        dst=self.routes[hole][1]
        assert dst not in allspots or allspots[dst][0]==1<<hole
        spots={c:s for c,s in allspots.items() if c!=dst}
        path=self.paths[hole]
        iy=self.influence[hole]
        bit=1<<hole
        possible={p:self.influence[p] ^ (iy if (path>>p)&1 else 0)
                  for _,_,sends in spots.values() for p in sends if p!=hole}
        tested=0
        def branch(on, off):
            nonlocal tested
            tested+=1
            active={c:s for c,s in spots.items() if c not in off}
            optional=0
            for c in active:
                optional |= self.for_chart[c]
            outmask=((1<<len(self.owners))-1)^optional
            constraints=tuple((ss[1],1<<(len(self.owners)+i)) for i,c in enumerate(sorted(on)) for ss in (active[c],))
            def tag(p):
                v=0
                for u,b in constraints:
                    if ((u>>p)&1)^(((u&bit)!=0) and ((path>>p)&1) and (p!=hole)):
                        v |= b
                return v
            target=(iy&outmask)|tag(hole)
            columns=Span()
            for c,(_,_,sends) in active.items():
                for p in sends:
                    if p==hole:continue
                    columns.add((possible[p]&outmask)|tag(p),1<<p)
            injection=columns.express(target)
            if injection is None:return None
            fixedpar=(injection&path).bit_count()&1
            all_inj=injection ^ (0 if fixedpar else bit)
            direct_error=iy ^ xsum(possible[p] for p in labels(injection))
            if direct_error&outmask or any((u&all_inj).bit_count()&1 for u,_ in constraints):
                raise ValueError('relaxed linear constraints not met')
            used=set(self.routes[p][0] for p in labels(injection))
            used.update(self.final[i] for i in labels(direct_error))
            bad=sorted(c for c in used if (spots[c][1]&all_inj).bit_count()&1)
            if not bad:
                return (list(labels(injection)),list(labels(direct_error)),sorted(used))
            c=bad[0]
            if c in on or c in off:raise ValueError('invalid branch')
            return branch(on|{c},off) or branch(on,off|{c})
        solution=branch(set(),set())
        return dict(closed=solution is None,linear_tests=tested,original_chart_count=len(allspots),possible_paid_injections=len(possible),solution=solution)

    def build(self, hole, result):
        import bit_native
        if not result['solution']:raise ValueError('missing solution')
        extra,term,used=result['solution']
        S=set(extra);T=set(term)
        allspots=self.locations(self.value[hole])
        initial=dict(enumerate(self.start));final=dict(enumerate(self.final))
        moves={p:ab for p,ab in self.routes.items() if p!=hole}
        rr={}
        for p,row in self.rows.items():
            if p==hole:continue
            if p in S or p<0 and ~p in T:
                c=moves[p][0] if p>=0 else final[~p]
                row ^= allspots[c][0]
            rr[p]=row&~(1<<hole)
        if self.reverse:
            moves,rr=physical.dual(len(self.owners),moves,rr)
            initial,final=final,initial
        order=bit_native.schedule(initial,final,moves,rr)
        bit_native.basis(initial,moves,rr,order)
        w=bit_native.emit_word(W,initial,final,moves,rr,order)
        atlas=op.Atlas(W['frames'])
        both=[op.run_tape(w,atlas,r) for r in [False,True]]
        assert all(t.output==op.expected_operator(i) for i,t in enumerate(both))
        baseline=Counter(G.values());baseline[G[hole]]-=1
        assert all(Counter(p.grade for p in t.packets.values())==+baseline for t in both)
        return w,dict(dirty=[t.dirty for t in both],move_removed_grade=G[hole],events=Counter(p[0] for p in w['program']),word=op.canonical_hash(w))

def run():
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--reverse',action='store_true')
    ap.add_argument('--limit',type=int,default=0)
    a=ap.parse_args()
    d=Direction(a.reverse)
    order=sorted((p for p in O if p!=3553),key=lambda p:(-G[p],p))
    if a.limit:order=order[:a.limit]
    rows=[];hits=[]
    for n,p in enumerate(order):
        r=d.solve(p)
        rows.append(dict(hole=p,**r))
        if not r['closed']:
            word,rep=d.build(p,r)
            h=dict(hole=p,reverse=a.reverse,**rep,**r)
            print('HIT',h,flush=True)
            label=f"SCALAR-{'REV' if a.reverse else 'FWD'}-{p}"
            emit(label+'.json',h)
            (HERE/(label+'-WORD.json.gz')).write_bytes(gzip.compress(json.dumps(word,sort_keys=True,separators=(',',':')).encode(),mtime=0))
            hits.append(h)
        if n%500==0: print('progress',n,len(hits),flush=True)
    obj=dict(pins=public_source(),reverse=a.reverse,examined=len(rows),hits=hits,
             relaxations=Counter(r['linear_tests'] for r in rows),bank_counts=Counter(r['original_chart_count'] for r in rows),rows=rows)
    emit(f"SCALAR-{'REV' if a.reverse else 'FWD'}"+('-partial' if a.limit else '')+'.json',obj)
    print('DONE',len(rows),len(hits),'relaxation nodes',obj['relaxations'],flush=True)

if __name__=='__main__':run()
