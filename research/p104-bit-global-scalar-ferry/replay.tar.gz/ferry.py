# SPDX-License-Identifier: Apache-2.0
"""Rebuild a shared lost scalar at a new receiver and recode the whole surviving graph."""
from fractions import Fraction
from itertools import combinations
from math import lcm
from scalar import *

def integral(row):
    f=tuple(map(Fraction,row))
    d=lcm(*(n.denominator for n in f))
    return tuple(int(n*d) for n in f)

FRAMES={int(c):tuple(tuple(integral(r) for r in f[k]) for k in ('B','A')) for c,f in W['frames'].items()}
@lru_cache(None)
def linked_grade(a,b):
    if DIMS[a]>DIMS[b]:return linked_grade(b,a)
    d=DIMS[b]-DIMS[a]
    if d<=0:return 0
    return 0 if any(sum(x*y for x,y in zip(s,t)) for s in FRAMES[a][0] for t in FRAMES[b][1]) else d

class Puncture:
    def __init__(self,d,holes):
        self.d=d
        holes=sorted(holes,key=d.rank.get)
        self.holes=holes
        self.erased=sum(1<<p for p in holes)
        x=d.value[holes[0]]
        assert all(d.value[p]==x for p in holes)
        self.stock=d.locations(x)
        self.spots={c:q for c,q in self.stock.items() if all(d.routes[p][1]!=c for p in holes)}
        self.early={c:max((d.rank[p] for p in labels(s[0]) if p in d.rank),default=-1) for c,s in self.spots.items()}
        self.Z0=self.shock(0,True)
        self.Y0=xsum(d.influence[p] for p in labels(self.Z0))
        self.effects={}
        self.make_columns={}
        self.local={c:tuple(p for p in q[2] if p not in holes and p!=3553) for c,q in self.spots.items()}

    def shock(self,inj,drop=False):
        mask=inj
        for p in self.holes:
            if ((self.d.paths[p]&mask).bit_count()&1)!=drop:mask ^= 1<<p
        return mask

    def col(self,p):
        if p not in self.effects:
            z=self.shock(1<<p)
            self.effects[p]=z,xsum(self.d.influence[j] for j in labels(z))
        return self.effects[p]

    def solve(self,origin=None,dest=None):
        d=self.d
        forced={} if origin is None else {origin}
        first=-2 if origin is None else self.early[origin]
        allspots=self.spots
        late=() if dest is None else tuple(p for p in d.send[dest] if d.rank[p]>first and p not in self.holes and p!=3553)
        evaluated=0
        def visit(on,off):
            nonlocal evaluated
            evaluated+=1
            live={c:q for c,q in allspots.items() if c not in off}
            terminal=0
            for c in live: terminal |= d.for_chart[c]
            if dest is not None:terminal|=d.for_chart[dest]
            mask=((1<<len(d.owners))-1)^terminal
            conditions=[(live[c][1],1<<(len(d.owners)+j)) for j,c in enumerate(sorted(on))]
            def tag(z):
                return sum(b for u,b in conditions if (u&z).bit_count()&1)
            rhs=(self.Y0&mask)|tag(self.Z0)
            basis=Span()
            sources=set(late)
            for c in live:sources.update(self.local[c])
            for p in sorted(sources):
                z,y=self.col(p)
                basis.add((y&mask)|tag(z),1<<p)
            choice=basis.express(rhs)
            if choice is None:return None
            z=self.Z0;out=self.Y0
            for p in labels(choice):
                e,y=self.col(p);z^=e;out^=y
            assert not (out&mask)
            used=set(d.routes[p][0] for p in labels(choice) if p not in late)
            used.update(d.final[i] for i in labels(out) if d.final[i]!=dest)
            if origin is not None:used.add(origin)
            bad=sorted(c for c in used if (allspots[c][1]&z).bit_count()&1)
            if bad:
                c=bad[0];assert c not in on and c not in off
                return visit(on|{c},off) or visit(on,off|{c})
            return dict(pulses=list(labels(choice)),terminals=list(labels(out)),required_natural_charts=sorted(used),ferry_origin=origin,
                        ferry_dest=dest,ferry_after=first,late_pulses=[p for p in labels(choice) if p in late])
        out=visit(set(forced),set())
        return out,evaluated

    def build(self,sol):
        import bit_native
        d=self.d
        S=set(sol['pulses']);T=set(sol['terminals'])
        late=set(sol['late_pulses']);a,b=sol['ferry_origin'],sol['ferry_dest'];h=3554
        initial=dict(enumerate(d.start));final=dict(enumerate(d.final))
        moves={p:ab for p,ab in d.routes.items() if p not in self.holes}
        rr={}
        for p,row in d.rows.items():
            if p in self.holes:continue
            if p in S or p<0 and ~p in T:
                c=moves[p][0] if p>=0 else final[~p]
                if b is not None and c==b and (p in late or p<0):
                    row ^= 1<<h
                else:
                    row ^= self.spots[c][0]
            rr[p]=row&~self.erased
        if a is not None:
            moves[h]=(a,b);rr[h]=self.spots[a][0]&~self.erased
        if d.reverse:
            moves,rr=physical.dual(len(d.owners),moves,rr)
            initial,final=final,initial
        order=bit_native.schedule(initial,final,moves,rr)
        bit_native.basis(initial,moves,rr,order)
        w=bit_native.emit_word(W,initial,final,moves,rr,order)
        atlas=op.Atlas(W['frames'])
        both=[op.run_tape(w,atlas,r) for r in (False,True)]
        assert all(t.output==op.expected_operator(i) for i,t in enumerate(both))
        baseline=Counter(G.values());baseline.subtract(G[p] for p in self.holes)
        if a is not None:baseline[linked_grade(a,b)]+=1
        assert all(Counter(p.grade for p in t.packets.values())==+baseline for t in both)
        return w,dict(dirty=[t.dirty for t in both],events=Counter(p[0] for p in w['program']),word=op.canonical_hash(w),ferry_compiled_label=len(d.owners)+order.index(h) if a is not None else None)

    def candidates(self,tied=False):
        old=tuple(sorted(G[p] for p in self.holes))
        destinations=sorted(set(self.d.send)|set(self.d.final))
        for a in sorted(self.spots):
            for b in destinations:
                new=linked_grade(a,b)
                if new and affordable(old,new,tied):
                    yield a,b,new

@lru_cache(None)
def affordable(old,new,tied):
    signed=Counter(old)
    signed[new]-=1
    credits={g:n for g,n in signed.items() if n>0}
    debits={g:-n for g,n in signed.items() if n<0}
    if not credits and not debits:return tied
    rates=(prices.D('0.00388'),prices.D('0.0038800000000000083'))
    intervals=[prices.moment(debits,credits,k) for k in rates]
    assert all(l>0 for l,u in intervals) or all(u<0 for l,u in intervals)
    return intervals[0][0]>0

def select(d,n,subset=None):
    groups=defaultdict(list)
    for p in d.order:
        if p!=3553:groups[d.value[p]].append(p)
    allh=[tuple(H) for q in groups.values() for H in combinations(q,n)]
    return sorted(allh,key=lambda H:(-sum(G[p] for p in H),H)) if subset is None else [tuple(subset)]

def run():
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--reverse',action='store_true')
    parser.add_argument('--size',type=int,default=2)
    parser.add_argument('--limit',type=int,default=0)
    parser.add_argument('--holes',type=int,nargs='*')
    parser.add_argument('--noferry',action='store_true')
    parser.add_argument('--tied',action='store_true')
    parser.add_argument('--start',type=int,default=0)
    a=parser.parse_args();d=Direction(a.reverse)
    items=select(d,a.size,a.holes)[a.start:]
    if a.limit:items=items[:a.limit]
    counts=Counter();per=[];samples=[]
    for ix,H in enumerate(items):
        v=Puncture(d,H);c=Counter()
        for origin,dest,gr in [(None,None,0)]+([] if a.noferry else list(v.candidates(a.tied))):
            sol,tests=v.solve(origin,dest)
            c['routes']+=1;c['nodes']+=tests
            if sol is None:continue
            c['funded']+=1
            keep=dict(holes=list(H),old_grades=[G[p] for p in H],ferry_grade=gr,reverse=a.reverse,**sol)
            print('HIT',keep,flush=True)
            if len(samples)<15:
                w,r=v.build(sol);keep.update(r)
                name='FERRY-'+('REV' if a.reverse else 'FWD')+'-'+'-'.join(map(str,H))+'-'+str(origin)+'-'+str(dest)
                emit(name+'.json',keep)
                (HERE/(name+'-WORD.json.gz')).write_bytes(gzip.compress(json.dumps(w,sort_keys=True,separators=(',',':')).encode(),mtime=0))
                samples.append(keep)
        per.append(dict(holes=list(H),**c));counts.update(c)
        if ix%100==0:print('progress',ix,dict(counts),flush=True)
    name='RESULT-FERRY-'+('REV' if a.reverse else 'FWD')+'-'+str(a.size)+('-noferry' if a.noferry else '')+('-tied' if a.tied else '')+(f'-{a.start}-{a.limit}' if a.start or a.limit else '')
    emit(name+'.json',dict(pins=public_source(),items=len(items),counts=counts,samples=samples,per=per))
    print('DONE',name,len(items),dict(counts),flush=True)
if __name__=='__main__':run()
