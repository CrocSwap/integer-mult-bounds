# SPDX-License-Identifier: Apache-2.0
"""Find a real paid ferry repair with globally recoded retained senders."""
from ferry import *

def run(write=False):
    choice=None
    for rev in (False,True):
        d=Direction(rev)
        for hole in sorted(set(O)-{3553}):
            v=Puncture(d,[hole])
            for a in sorted(v.spots):
                b=d.routes[hole][1]
                g=linked_grade(a,b)
                if not g:continue
                sol,count=v.solve(a,b)
                if sol is None:continue
                if len(sol['pulses'])<2 or a==d.routes[hole][0]:continue
                cand=(hole,a,b,g,rev,sol,v)
                if choice is None:choice=cand
                if len(sol['pulses'])<15 and len(sol['terminals'])<70:
                    choice=cand;break
            else:continue
            break
        if choice:break
    if choice is None:raise ValueError('no multi-pulse alternate-source paid canary')
    hole,a,b,g,rev,solution,v=choice
    w,info=v.build(solution)
    atlas=op.Atlas(w['frames'])
    asc,desc=[op.run_tape(w,atlas,b) for b in (False,True)]
    reg=op.expected_operator(False)
    native=Counter(p.grade for p in asc.packets.values())
    base=Counter(G.values());base[G[hole]]-=1;base[g]+=1
    assert native==+base
    # Use the actual paid reevaluation. Reject omitted original bridge ADD and
    # owned CLEAR. Suppressing the new receipt's source reads separately verifies
    # that the reroute itself serves live output.
    marker=(a,b) if not rev else (b,a)
    tree=[i for i,(opname,*args) in enumerate(w['program']) if opname=='MOVE' and args[1:]==list(marker)]
    damages=[]
    for clk in tree:
        if w['program'][clk-1][0]!='ADD':continue
        affected=[sum(x!=z for x,z in zip(op.run_tape(w,atlas,r,omit=clk-1).output,op.expected_operator(r))) for r in (False,True)]
        if all(affected):damages.append([clk,affected])
    ferry_label=info['ferry_compiled_label']
    actual=asc.packets[ferry_label]
    assert (actual.source,actual.receiver)==marker
    bad=dict(w);bad['program']=[e for i,e in enumerate(w['program']) if not (i<actual.clock and e[0]=='ADD' and e[1]==ferry_label)]
    lost_results=[sum(x!=z for x,z in zip(op.run_tape(bad,atlas,r).output,op.expected_operator(r))) for r in (False,True)]
    assert damages and all(lost_results)
    try:op.run_tape(w,atlas,False,omit=asc.last_retirement)
    except ValueError as exc:assert str(exc)=='unretired private field'
    else:raise ValueError('omitted owned CLEAR was accepted')
    # An explicit independent operational negative control drops all ferry-source
    # additions in the retained packet graph, then the full published word fails.
    baseword,caller,_,_,helpers,bp,bt,rat=prices.baseline()
    events=Counter(e[0] for e in caller['events'])
    paid,targ=prices.literal.paired_invoice(caller,native,helpers,events)
    rp={int(k):n for k,n in rat['signed']['paid'].items()};rt={int(k):n for k,n in rat['signed']['productive'].items()}
    rates=(prices.D('0.00388'),prices.D('0.0038800000000000083'))
    receipt=dict(hole=hole,orig=d.routes[hole],new=marker,old_grade=G[hole],new_grade=g,reverse=rev,all_source_and_term_actions=solution,word_sha=op.canonical_hash(w),changed_paid=native,full_binary_paid=paid,productive=targ,**info,active_route_add_corruptions=damages,zero_actual_ferry_input_damaged=lost_results,deletion_clock=asc.last_retirement,signed={str(k):{'bit':prices.display(prices.moment(paid,targ,k)), 'delta':prices.display(prices.scale(prices.moment({g:1},{G[hole]:1},k),36)), 'rational':prices.display(prices.moment(rp,rt,k))} for k in rates})
    encoded=json.dumps(receipt,sort_keys=True,indent=2)+'\n'
    packed=gzip.compress(json.dumps(w,sort_keys=True,separators=(',',':')).encode(),mtime=0);packed=packed[:9]+bytes([3])+packed[10:]
    if write:
        (HERE/'GLOBAL-RECOVERY-CONTROL.json').write_text(encoded)
        (HERE/'GLOBAL-RECOVERY-WORD.json.gz').write_bytes(packed)
    else:
        assert (HERE/'GLOBAL-RECOVERY-CONTROL.json').read_text()==encoded
        assert (HERE/'GLOBAL-RECOVERY-WORD.json.gz').read_bytes()==packed
    print('global control',hole,marker,len(solution['pulses']),len(solution['terminals']),G[hole],g,op.canonical_hash(w),flush=True)
if __name__=='__main__':run('--write' in sys.argv)
