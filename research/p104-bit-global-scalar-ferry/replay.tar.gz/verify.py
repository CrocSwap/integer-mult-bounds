#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Replay every punched roster and actually compile the positive feasibility control."""
import argparse
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sys

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import ferry
import ferry_control

def run_one(reverse,n):
    data=json.loads((ROOT/('RESULT-FERRY-'+('REV' if reverse else 'FWD')+'-'+str(n)+'.json')).read_bytes())
    d=ferry.Direction(reverse)
    roster=ferry.select(d,n)
    assert len(roster)==data['items'] and data['samples']==[]
    total=Counter()
    for h,expected in zip(roster,data['per']):
        assert list(h)==expected['holes']
        cut=ferry.Puncture(d,h);nodes=0;routes=0
        for a,b,g in [(None,None,0),*cut.candidates()]:
            candidate,count=cut.solve(a,b)
            if candidate is not None:
                raise ValueError('funded scalar-ferry repair: '+str((h,a,b)))
            nodes+=count;routes+=1
        assert routes==expected['routes'] and nodes==expected['nodes']
        total.update(dict(routes=routes,nodes=nodes))
    assert total==data['counts']
    print('PASS',reverse,n,len(roster),dict(total),flush=True)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--orientation',choices=('forward','adjoint','both'),default='both')
    ap.add_argument('--size',type=int,choices=(1,2,3))
    ns=ap.parse_args()
    for src in json.loads((ROOT/'SOURCES.json').read_bytes())['files']:
        assert sha256((ROOT/src['local']).read_bytes()).hexdigest()==src['sha256']
    w=ferry.W;atlas=ferry.op.Atlas(w['frames'])
    for reverse in (False,True):
        tape=ferry.op.run_tape(w,atlas,reverse)
        values=ferry.Y if reverse else ferry.X
        assert tape.output==ferry.op.expected_operator(reverse)
        assert all(values[p]==obs.arrival.row and ferry.G[p]==obs.grade for p,obs in tape.packets.items())
    ferry_control.run()
    dirs=(False,True) if ns.orientation=='both' else (ns.orientation=='adjoint',)
    for reverse in dirs:
        for size in (1,2,3) if ns.size is None else (ns.size,):
            run_one(reverse,size)
if __name__=='__main__':main()
