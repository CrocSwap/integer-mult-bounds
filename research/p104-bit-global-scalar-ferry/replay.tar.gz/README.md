# Same-payload relay replacement with global binary recoding

No affordable repair exists in the stated one-dimensional recoding family for the pinned 680-owner #7830 word. Both native orientations were tested. The estimates use the actual nested rational chart grades, and the signed price of every counted route was checked at κ = 0.00388 and at the finite-transfer trial 0.0038800000000000083. The comparison retains all other paid grades and all productive grades, including the 36 binary native uses and the separate 48-call rational caller. [Pinned native word](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) · [Earlier terminal and early-carrier family](https://github.com/CrocSwap/integer-mult-bounds/pull/7985) · [Finite transfer method](https://github.com/CrocSwap/integer-mult-bounds/pull/7975)

| Orientation | Omitted old packets with the same binary payload | Omission sets | Free-deletion or strictly affordable ferry configurations | Feasible |
| --- | ---: | ---: | ---: | ---: |
| Forward | 1 | 2,873 | 183,299 | 0 |
| Adjoint | 1 | 2,873 | 144,790 | 0 |
| Forward | 2 | 681 | 54,284 | 0 |
| Adjoint | 2 | 708 | 47,402 | 0 |
| Forward | 3 | 3 | 974 | 0 |
| Adjoint | 3 | 20 | 7,148 | 0 |

Each row includes one free-deletion test per omission set. A nested ferry can use any atlas chart where the missing binary vector is available, visit any useful different receiver chart and arrive as soon as its source can form the vector. No four old nonbridge packets have the same vector in either orientation. The price test includes all two- or three-to-one equal-total-grade fusions when their directed gain is positive. Full row-by-row counts are in the six RESULT files.

## Permitted changes and the exact search

Fix a binary vector x and remove one, two or three named old packets that carried x. Keep the other paid source/receiver chart pairs, their original order and the 680 public endpoints. Each surviving packet may carry either its old value or that value plus x. This allows simultaneous modifications at arbitrarily many surviving paid senders, including earlier sends and distant descendants. Allow arbitrary local terminal decoding and one additional nested paid transmission carrying x itself. The original bridge 3553 keeps its isolated payload in the chosen search orientation.

The old tracked stock at every chart is independent. At chart c the old vector x therefore has either no expression or a unique one. If its expression uses a missing packet at c, x has no surviving representation there. At a different chart the earliest natural access to x occurs after the last old receive in the unique expression. Under the chosen changes, its expression produces x exactly when the parity of its received perturbations is zero. If the parity is one, the expression produces zero. If x was outside the old stock span, independently perturbing those stocks by multiples of x cannot put x in their span. A fresh ferry creates access at its receiver from the arrival onward, whether or not the old stock had such an expression.

Use one bit per freely injected change to a paid sender row. The baseline change from zeroing the omitted packets and the response to each injected bit are computed by forward substitution in the original triangular dependency graph. At each omitted slot, force its value to zero before continuing downstream. The full-output effects are computed using their transposed influence vectors. All reachable terminal changes are linear in the remaining injection bits.

Initially grant every old natural chart access wherever the old unique expression has arrived. Solve the resulting binary linear system for paid injections, with optional terminal corrections only where access is granted. Require the proposed ferry source's access parity to vanish. Test every natural access actually used by the candidate solution against the corresponding causal stock parity. On a failure at a chart, branch by imposing zero access parity or by disabling all uses of that natural access, including its optional terminal adjustments. Each branch adds one restriction and the disjunction covers every realization. The funded receiver's post-arrival accesses do not need the natural parity. A satisfying assignment produces literal XOR operand rows and a chronological native program. The reported searches found none at a strictly better price.

## Primitive positive feasibility control

Original paid packet 1310 moves from chart 113 to chart 506 at grade 2. An alternate source at chart 7 sends the same missing vector to 506 at grade 3. The constructed word rewrites ten surviving sender rows and two terminal reads, on owners 633 and 634. Its canonical SHA-256 is `7c717c24182141c88f0966283437cfc28f0dd20541850e8d87052ccc9d27e769`. The primitive forward and adjoint interpretations each recover all 680 public rows. Zeroing the actual ferry's compiled source additions damages 61 forward outputs and two adjoint outputs. A missing owned retirement also fails the primitive lifetime check.

With this costlier receipt, the entire binary caller margin is −35.76170609238540358052 at κ = 0.00388. The change is −35.73399473219518599012. The separate rational margin is +0.13897452233425270898. The archive contains the actual primitive tape, the complete paid/productive bins, and both raw trial prices. No finite κ gain follows from the control.

## Reproduction

Run these commands from the extracted archive. Python 3.12 and the standard library suffice. Each optional shard checks the source and control and replays its own roster. The full default replays all six.

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify.py
python3 -I -B verify.py --orientation forward --size 3
```

Two-dimensional global changes, altered old transfer incidences, different new ferry payloads that use receiver side information, and changing the original surviving schedule are outside the finite family.
