# A two-port basis pivot on the compensated caller

**No positive candidate was compiled.** We tested two ports of the exact
rank-four, two-stage re-paired formal caller from the adjacent forest
receipt. A nontrivial, matched `GL(2,F₂)` basis change on selected roles
preserves the complete caller in the identical-port algebra only when the
selected roles are whole connected components of the stage-contact graph.
All such controls keep the original 36 LOCALs, four QUERYs per port, and
signed grades. With independently tagged port bodies or heads, the tested
nontrivial substitutions fail a necessary monomial or ε equation.

The pinned source heads are #7952
`755fcee748d4e90feda281f27d06e7bc66ecf954`, #7964
`1f90b620855e08b6a941a304ed25eda5600c0deb`, and the distinct prior R7
#7977 `92d034719119fcde2f1eeac0a63330d711720e61`. The literal two-stage
caller is the frozen forest witness with canonical SHA-256
`89d5a6ad11f2df0f89012e8401b447c9c0e8275604dd957c0918e443fe972d62`.
Its modified contacts are

```
stage 1:  (0,20)  (19,1)
stage 2:  (0,21)  (19,2)
```

## Formal finite screen

For each of the 5 nonidentity matrices of `GL(2,F₂)`, the same matrix is
applied between the two port copies on each nonempty subset of the roles
in a stage window. Its inverse is placed immediately on the other side.
The rest of the 38-role word and every original output target are fixed.
The three windows are stage 1, stage 2 and the two adjacent stages. Their
active role sets have sizes 4, 4 and 6 respectively. This gives 75, 75 and
315 changes in each variable model. The code first checks the complete
window body orbit at `q=1`, then the remaining formal head coefficient.

| Formal labels | Stage 1 | Stage 2 | Stages 1–2 |
| --- | ---: | ---: | ---: |
| Common head and body tags | 15 exact, 60 head mismatches | 15 exact, 60 head mismatches | 15 exact, 300 head mismatches |
| Common head, separate port body tags | 75 body mismatches | 75 body mismatches | 315 body mismatches |
| Separate port heads, common body tags | 75 head mismatches | 75 head mismatches | 315 head mismatches |
| Separate port heads and body tags | 75 body mismatches | 75 body mismatches | 315 body mismatches |

The 15 shared-tag survivors in each window comprise the five nonidentity
matrices on any nonempty union of the two contact-graph components. All
**15 two-stage survivors** were inserted into the complete two-port caller
and matched every one of **76² formal coefficients**, in both forward and
adjoint orientations. The full unmodified two-port caller was also checked
in each of the four variable models. These survivors do not delete, fuse,
or regrade any paid operation; they add ordinary role mixing and inverse
mixing. Physical co-charting and its cost are not established.

The separate variables are a formal stress test that does **not** assert
that physical maps are algebraically independent. For a shear
`B=[[1,1],[0,1]]`, even a single role with port body maps `D₀,D₁` gives

```
B⁻¹ diag(D₀,D₁) B = [[D₀, D₀+D₁], [0, D₁]].
```

Thus the required off-diagonal vanishing equation is `D₀+D₁=0`. Over the
two-stage window, the analogous diagonal terms are
`D₀,1 D₀,2 + D₁,1 D₁,2`. With shared body tags but separate heads, the
prepared contact's off-diagonal correction requires `q₀+q₁=0`. These are
specific necessary equations for this matched-basis substitution, not a
claim that every conceivable port-routing compiler needs separate formal
indeterminates.

For the common head/body proxy, the uncorrected seam has rank four on one
port and rank eight on their direct sum. Every global `GL(2,F₂)` port basis
conjugation leaves that rank eight. Eight scalar rank-one QUERY occurrences
are therefore necessary for the two ports; seven cannot implement the same
correction. Independently, the verifier deletes each actual QUERY-plus-ADD
pair from only one port, keeping the other port's pair, at each of four
query clocks and in all four formal label models. All **32** deletions
change both forward and adjoint output polynomials. A physical native
LOCAL is not declared deleted merely because one port was relabelled.

## Physical axis and one-channel control

The source native word explicitly identifies ports 0 and 1:

```
port 0: head span(e0), body span(e1,e2,e3,e4,e5,e6,e7)
port 1: head span(e1), body span(e0,e2,e3,e4,e5,e6,e7).
```

Their body spaces have ranks 7 and 7, intersection rank 6 and union rank 8.
For a port body-to-fresh-stage coordinate interchange that fixes the
port's head, port 0 fixes `e0`, while port 1 sends `e0` into the fresh stage
space. Thus the two physical transformations cannot be identified without
an additional port-specific matching or transport. The chosen fresh-axis
matching used by the executable 15-axis one-hot control is illustrative;
the actual changed caller's intermediate physical routes and the emitted
port-specific matching have not been reconstructed. The physical axis
observation alone is not a claim that all possible alternate bindings fail.

Consider the narrower proposed replacement of two distinct paid owner
operations by **one** common physical role channel, surrounded by arbitrary
pointwise GF(2) role mixing. Even granting arbitrary zero scratch and no
scratch restoration, the two owner blocks must have the form

```
Bᵢⱼ I + uᵢ vⱼ K,
```

where `B,u,v` are scalar binary values and `K` is an arbitrary common
physical endomorphism. To obtain `diag(S₀,S₁)` with both `Sᵢ` non-scalar,
both diagonal products `uᵢvᵢ` must be nonzero, making both off-diagonal
products nonzero too; an off-diagonal zero would force `K` to be scalar,
contradiction. The executable checks all 256 scalar choices on an
illustrative one-hot restriction: zero solutions for two different maps,
zero for two copies of one non-scalar map, and two for the one-map control.
The selected restriction has per-port difference ranks 7 and 7 and
combined-image rank 8; these are **one-hot pulse** ranks, not full-array
ranks. The block argument is independent of the illustrative matching.
Role-dependent physical extraction, a real rank-14 direct sum, additional
paid calls and changed interleavings are outside this one-channel model.

## Complete price comparison

At `κ=0.00388`, the pinned 36-native-call BIT margin is
`−0.027711360190217590400992390441...` and the unchanged 48-call rational
margin is `+0.138974522334252708977587373516...`. There are two individual
grade-7 paid occurrences for ports 0 and 1 at formal caller clock 79,
`IDLE_ONE 8 [9]`. Their coincidence is a logical-clock fact; it does not
establish a single simultaneous physical instruction.

If those two paid occurrences could actually be replaced with one grade-14
operation while every other cost and target remained fixed, directed
arithmetic gives

```
2H(7) − H(14)              = +0.037318344937736057592...
full BIT margin             = +0.009606984747518467191...
with one extra grade-1 paid  = −0.990393015252481532808...
```

This is a **hypothetical full invoice**, not a construction or κ bound.
The one-channel control excludes a specific cheap method, while an actual
role-specific rank-14 direct-sum realization, restored ownership and all
associated costs remain open. The changed caller still needs physical
chart and clock binding, query lifecycle and erasure, precision tape,
compiler and analytic-recovery arguments. Arbitrary role-dependent basis
matrices, non-adjacent retiming, more stage changes, altered target masks,
and mixed-port paid primitives are outside this finite screen.

## Reproduce

This companion is self-contained: `inputs/forest-replay-e9d216a6ed61.tar.gz`
is the unchanged licensed forest archive, SHA-256
`e9d216a6ed61f551fe11eb544725d0cb4cd5032fdc01982c90b769b386e816b1`.
It contains the formal caller and all three pinned predecessor source trees.
The temporary replay does not mutate the embedded input or any workspace.

```sh
python3 -I -B verify.py
```

The verifier checks its outer manifest, the exact embedded archive and all
three source manifests, extracts to an isolated temporary directory, runs
the complete pivot, and requires byte-for-byte agreement with RESULT.json.
The pivot uses only Python's standard library. It checks the source caller's
canonical hash, full 76² forward/adjoint operators, all finite basis cases,
32 mutation controls, seam ranks, native port frames, one-channel block
controls, and directed complete-invoice arithmetic.
