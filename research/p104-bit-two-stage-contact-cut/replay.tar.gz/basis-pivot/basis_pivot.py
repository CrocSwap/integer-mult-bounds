#!/usr/bin/env python3
"""Two-port GL(2) insertions over the exact rank-four re-paired caller."""
from collections import Counter
from hashlib import sha256
from itertools import combinations, product
from pathlib import Path
import gzip,json,sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'p7952'))
import common as C
source=json.loads((ROOT/'two-crossings-CALLER.json').read_text())
canonical=json.dumps(source,sort_keys=True,separators=(',',':')).encode()
assert sha256(canonical).hexdigest()=='89d5a6ad11f2df0f89012e8401b447c9c0e8275604dd957c0918e443fe972d62'
assert source['roles']==38 and source['ports']==111
N=38; P=2

def mxmul(a,b):
 return tuple((b[0] if row&1 else 0) ^ (b[1] if row&2 else 0) for row in a)
def tr(m):return tuple(sum(((m[j]>>i)&1)<<j for j in range(2)) for i in range(2))
gl=[m for m in product(range(1,4),repeat=2) if m[0]!=m[1]]
I=(1,2)
inv={m:next(n for n in gl if mxmul(m,n)==I and mxmul(n,m)==I) for m in gl}
assert len(gl)==6

def add(a,b):
 c=a.copy()
 for k,v in b.items():
  z=c.get(k,0)^v
  if z:c[k]=z
  elif k in c:del c[k]
 return c

def sh(a,d=0,q=0):return {(m+d)^q:v for m,v in a.items()}

def run(evs,q_shared,d_shared,adjoint=False):
 rows=[{0:1<<i} for i in range(76)]
 def Q(p):return 1 if q_shared else 1<<p
 def D(p,s):return 1<<(2+5*(s-1+(0 if d_shared else 18*p)))
 for event in (reversed(evs) if adjoint else evs):
  op,*args=event
  if op=='MIX':
   role,a,b=args;m=(a,b);m=tr(m) if adjoint else m
   old=[rows[role],rows[38+role]]
   for p in range(2):
    row={}
    for z in range(2):
     if m[p]>>z&1:row=add(row,old[z])
    rows[p*38+role]=row
  elif op in ('PORT_ADD','PORT_QUERY'):
   p,a,b=args
   if adjoint:a,b=b,a
   x=38*p+a;y=38*p+b
   rows[x]=add(rows[x],sh(rows[y],q=Q(p) if op=='PORT_QUERY' else 0))
  elif op in ('ADD','QUERY'):
   a,b=args[::-1] if adjoint else args
   for p in range(2):
    x=38*p+a;y=38*p+b
    rows[x]=add(rows[x],sh(rows[y],q=Q(p) if op=='QUERY' else 0))
  elif op=='LOCAL':
   s,a,b=args
   if adjoint:a,b=b,a
   for p in range(2):
    x=38*p+a;y=38*p+b
    rows[x],rows[y]=sh(rows[x],d=D(p,s)),sh(add(rows[y],sh(rows[x],q=Q(p))),d=D(p,s))
  elif op=='IDLE_ONE':
   role,stages=args
   for p in range(2):rows[38*p+role]=sh(rows[38*p+role],d=sum(D(p,s) for s in stages))
  elif op=='SWAP':
   a,b=args
   for p in range(2):rows[38*p+a],rows[38*p+b]=rows[38*p+b],rows[38*p+a]
  else:raise ValueError(op)
 return rows

def q1(rows):
 result=[]
 for row in rows:
  out={}
  for m,v in row.items():
   key=m&~3;out[key]=out.get(key,0)^v
   if out[key]==0:del out[key]
  result.append(out)
 return result

def diff(a,b):
 badrows=0; cells=0
 for x,y in zip(a,b):
  changed=sum((x.get(m,0)^y.get(m,0)).bit_count() for m in set(x)|set(y))
  if changed:badrows+=1;cells+=changed
 return {'bad_rows':badrows,'coefficient_mismatches':cells}

def firstdiff(a,b):
 for i,(x,y) in enumerate(zip(a,b)):
  for m in sorted(set(x)|set(y)):
   z=x.get(m,0)^y.get(m,0)
   if z:
    j=(z&-z).bit_length()-1
    return {'out_port':i//38,'out_role':i%38,'in_port':j//38,'in_role':j%38,
            'monomial_encoding':str(m),'q_bits':m&3}
 return None

def wrapped(evs,roles,m):
 pre=[['MIX',r,*m] for r in roles]
 post=[['MIX',r,*inv[m]] for r in reversed(roles)]
 return pre+evs+post

def fullwindow(a,b):
 indices=[i for i,e in enumerate(source['events']) if e[0]=='LOCAL' and e[1] in range(a,b+1)]
 lo=min(indices)-1;hi=max(indices)+3
 for stage in range(a,b+1):
  locs=[e for e in source['events'][lo:hi] if e[0]=='LOCAL' and e[1]==stage]
  assert len(locs)==2
 return lo,hi

modes={'shared_q_shared_body':(True,True), 'shared_q_separate_body':(True,False),
       'separate_q_shared_body':(False,True), 'separate_q_separate_body':(False,False)}
windows=[(1,1),(2,2),(1,2)]
summary={};surviving={}
for a,b in windows:
 lo,hi=fullwindow(a,b);seq=source['events'][lo:hi]
 roles=sorted({i for e in seq if e[0]=='LOCAL' for i in e[2:]})
 expected_components=2
 wkey=f'{a}-{b}'
 for mode,(sq,sd) in modes.items():
  original=run(seq,sq,sd)
  subtotal=Counter();examples={}; survivors=[]
  for num in range(1,len(roles)+1):
   for subset in combinations(roles,num):
    for m in gl:
     if m==I:continue
     changed=run(wrapped(seq,subset,m),sq,sd)
     body=diff(q1(original),q1(changed));full=diff(original,changed)
     state='body_mismatch' if body['bad_rows'] else 'epsilon_or_q_mismatch' if full['bad_rows'] else 'exact'
     subtotal[state]+=1
     if state not in examples:examples[state]={'roles':subset,'matrix':m,'body':body,'full':full,'first':firstdiff(original,changed)}
     if state=='exact':survivors.append((subset,m))
  summary[f'{wkey}:{mode}']={'window_event_range':[lo,hi],'active_roles':roles,'trials':sum(subtotal.values()),'classifications':dict(subtotal),'examples':examples}
  surviving[(wkey,mode)]=survivors
  if not sd: assert subtotal['body_mismatch']==sum(subtotal.values())
  elif not sq:assert subtotal['epsilon_or_q_mismatch']==sum(subtotal.values())
  else:
   # The graph has two star components in these selected windows.
   assert subtotal['exact']==15 and subtotal['epsilon_or_q_mismatch']==sum(subtotal.values())-15

# Full two-port caller has 76 rows, 76 input columns, with either fully shared
# or independently labelled q/body variables. Compare in BOTH orientations.
full={}; sample={}
for mode,(sq,sd) in modes.items():
 basef=run(source['events'],sq,sd); basea=run(source['events'],sq,sd,True)
 def expected():
  out=[]
  for p in range(2):
   for r,x in enumerate(source['diagonal']):
    q=1 if sq else 1<<p
    mask=q+sum(1<<(2+5*(s-1+(0 if sd else 18*p))) for s in x['stages'])
    out.append({mask:1<<(38*p+r)})
  return out
 assert basef==expected()==basea
 full[mode]={'baseline_forward_adjoint_coefficient_slots_each':76**2,'baseline_both_match':True}
 lo,hi=fullwindow(1,2)
 edges=[(subset,m) for subset,m in surviving[('1-2',mode)] if m!=I]
 checked=0
 for roles,m in edges:
  word=source['events'][:lo]+wrapped(source['events'][lo:hi],roles,m)+source['events'][hi:]
  for rev in (False,True):assert run(word,sq,sd,rev)==expected()
  checked+=1
 full[mode]['all_surviving_full_forward_adjoint_checked']=checked
 # Concrete shear on the entire connected component 0-20-21.
 roles=(0,20,21);m=(3,2)
 word=source['events'][:lo]+wrapped(source['events'][lo:hi],roles,m)+source['events'][hi:]
 vf=run(word,sq,sd);va=run(word,sq,sd,True)
 sample[mode]={'roles':roles,'matrix':m,'forward':diff(vf,expected()),'adjoint':diff(va,expected()),
               'first_forward_mismatch':firstdiff(vf,expected())}

# Independently remove one actual QUERY+ADD occurrence in a single port,
# leaving the other port's operation in place. This is not just relabeling.
deletions=[]
qs=[i for i,e in enumerate(source['events']) if e[0]=='QUERY']
assert len(qs)==4
for mode,(sq,sd) in modes.items():
 basef=run(source['events'],sq,sd);basea=run(source['events'],sq,sd,True)
 for clock in qs:
  _,a,b=source['events'][clock]
  assert source['events'][clock+1]==['ADD',a,b]
  for port in (0,1):
   other=1-port
   modified=source['events'][:clock]+[['PORT_QUERY',other,a,b],['PORT_ADD',other,a,b]]+source['events'][clock+2:]
   forward=diff(run(modified,sq,sd),basef)
   adjoint=diff(run(modified,sq,sd,True),basea)
   assert forward['bad_rows'] and adjoint['bad_rows']
   deletions.append({'mode':mode,'query_clock':clock,'omitted_port':port,'forward':forward,'adjoint':adjoint})

# Query rank: take saved exact rank-4 per-port specialized residual from the
# bare compensated caller. Direct sum rank 8 survives any 76x76 invertible
# port-basis conjugation; a rank-one elementary QUERY is needed per term.
sys.path.insert(0,str(ROOT/'p7977'))
import screen as S
bare=S.bare(source);body=S.body_diagonal(bare);cells=S.eps_cells(bare,body,[1]*38)
rows=[0]*38
for (i,j),mm in cells.items():
 if len(mm)%2:rows[i]^=1<<j
assert S.rank(rows)==4
pair=rows+[row<<38 for row in rows]
assert S.rank(pair)==8
for m in gl:
 # Conjugate on every paired role, Q^-1 (R ⊕ R) Q, explicitly.
 def mixvector(x,mat):
  lo=x&((1<<38)-1);hi=x>>38
  return ((lo if mat[0]&1 else 0)^(hi if mat[0]&2 else 0)) | (((lo if mat[1]&1 else 0)^(hi if mat[1]&2 else 0))<<38)
 def apply(mat,v):
  out=0
  for i,row in enumerate(mat):
   if (row&v).bit_count()%2:out|=1<<i
  return out
 images=[mixvector(apply(pair,mixvector(1<<i,m)),inv[m]) for i in range(76)]
 assert S.rank(images)==8

k=C.D('0.00388')
credit=C.minus(C.scale(C.power(7,k),2),C.power(14,k))
_,_,_,_,_,paid,targets,rat=C.baseline()
assert source['events'][79]==['IDLE_ONE',8,[9]] and paid[7]>=2
base=C.moment(paid,targets,k)
ideal=C.plus(base,credit)
loss=C.minus(ideal,(C.D(1),C.D(1)))
physical={}
native=json.loads(gzip.decompress((ROOT/'p7952/inputs/WORD.json.gz').read_bytes()))
for p in (0,1):
 head=native['frames'][str(native['start'][p])]
 body=native['frames'][str(native['final'][111+p])]
 physical[str(p)]={'head_frame':native['start'][p],'body_frame':native['final'][111+p],
                   'head_basis':head['B'],'body_basis':body['B']}
assert physical['0']['head_basis'][0]==[1,0,0,0,0,0,0,0]
assert physical['1']['head_basis'][0]==[0,1,0,0,0,0,0,0]
assert [1,0,0,0,0,0,0,0] not in physical['0']['body_basis']
assert [1,0,0,0,0,0,0,0] in physical['1']['body_basis']
# Exact one-physical-call relaxation from the pinned native port spaces.
# Scalar pre/post role mixing around one common non-scalar K has blocks
# B_ij I + u_i v_j K. Once u,v,B are fixed, each nonzero block forces K.
I15=tuple(1<<i for i in range(15));Z15=(0,)*15
def xorcols(a,b):return tuple(x^y for x,y in zip(a,b))
body_axes=[]
for p in (0,1):
 body_axes.append([row.index(1) for row in physical[str(p)]['body_basis']])
assert body_axes==[[1,2,3,4,5,6,7],[0,2,3,4,5,6,7]]
def selected_delta(axes):
 cols=[0]*15
 for j,old in enumerate(axes):cols[old]=cols[8+j]=(1<<old)|(1<<(8+j))
 return tuple(cols)
d0=selected_delta(body_axes[0]);d1=selected_delta(body_axes[1])
S0=xorcols(I15,d0);S1=xorcols(I15,d1)
def spanrank(cols):
 piv={}
 for v in cols:
  while v and v.bit_length() in piv:v^=piv[v.bit_length()]
  if v:piv[v.bit_length()]=v
 return len(piv)
def solve_one(a,b):
 target=((a,Z15),(Z15,b));count=0
 for u in range(4):
  for v in range(4):
   for m in range(16):
    required=[];ok=True
    for i in range(2):
     for j in range(2):
      want=xorcols(target[i][j],I15 if m>>(2*i+j)&1 else Z15)
      if (u>>i&1) and (v>>j&1):required.append(want)
      elif want!=Z15:ok=False
    if ok and (not required or all(x==required[0] for x in required)):count+=1
 return count
assert (spanrank(d0),spanrank(d1),spanrank(d0+d1))==(7,7,8)
assert S0[0]==1 and S1[0]==1<<8
assert (solve_one(S0,S1),solve_one(S0,S0),solve_one(S0,I15))==(0,0,2)

out={'source_caller_sha256':sha256(canonical).hexdigest(),
     'source_head_7952':'755fcee748d4e90feda281f27d06e7bc66ecf954',
     'source_head_7964':'1f90b620855e08b6a941a304ed25eda5600c0deb',
     'source_head_7977':'92d034719119fcde2f1eeac0a63330d711720e61',
     'query_deletion_controls':deletions,
     'one_common_physical_map_relaxation':{'model':'B_ij I + u_i v_j K; arbitrary common K, arbitrary GF(2) scalar matrices and vectors; scratch unconstrained', 'B_u_v_tuples_tested':256,'two_port_solutions':solve_one(S0,S1),'two_same_nontrivial_map_solutions':solve_one(S0,S0),'one_nontrivial_map_control_solutions':solve_one(S0,I15),'illustrative_one_hot_difference_ranks':[spanrank(d0),spanrank(d1)],'illustrative_common_image_rank':spanrank(d0+d1),'matching_note':'15-axis fresh matching is an illustrative pinned-body model, not the reconstructed compiler route; the 256-case block contradiction holds for any non-scalar physical maps'},
     'stage1_and_2_contacts':[[0,20],[19,1],[0,21],[19,2]],
     'mode_meaning':{'shared_q_shared_body':'abstract identical-port proxy',
       'shared_q_separate_body':'independent formal body-stage variables',
       'separate_q_shared_body':'independent formal head variables',
       'separate_q_separate_body':'independent formal head and body variables'},
     'gl2':gl,'windows':summary,'full_caller':full,'connected_component_shear_control':sample,
     'seam_single_port_rank':4,'two_port_direct_sum_rank':8,
     'conjugated_seam_rank_all_six_GL2':[8]*6,
     'native_ports_0_1':physical,
     'illustrative_port0_vs_port1_e0_image':{'port0_bits':S0[0],'port1_bits':S1[0],'port1_fresh_axis_illustrative':'f0'},
     'hypothetical_two_H7_to_one_H14':{'grade7_pair_credit':C.display(credit),'full_bit_baseline':C.display(base),
       'ideal_full_bit':C.display(ideal),'ideal_less_one_grade1_service':C.display(loss),
       'sample_caller_idle_clock':79,'sample_idle_role':8,'sample_body_stage':9,'sample_ports':[0,1], 'status':'PRICE ONLY: no distinct-coordinate direct-sum operation or restored physical route is constructed'},
     'limits':['cross-port one-hot physical port span mismatch is necessary for raw coordinate swap; no actual emitted per-port fresh matching asserted',
       'formal separated variables represent the necessary no-unexplained-identification control, not a replacement for native physical replay',
       'one identical nontrivial 2x2 matrix applied rolewise to a subset, with inverse across one adjacent stage window; arbitrary role-dependent matrices, intermediate changed staging, target masks, paid primitives and physical rebindings remain open',
       'ordinary physical charts, query lifecycle, dirty erasure, precision, analytic recovery and compiler are not established']}
print(json.dumps(out,indent=2,sort_keys=True))
