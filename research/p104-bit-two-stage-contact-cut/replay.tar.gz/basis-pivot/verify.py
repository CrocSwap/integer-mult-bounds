#!/usr/bin/env python3
"""Cold replay the pivot using the exact embedded forest dependency."""
from hashlib import sha256
from pathlib import Path
import json, shutil, subprocess, sys, tempfile

here=Path(__file__).resolve().parent
subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=here,check=True,stdout=subprocess.PIPE)
manifest=json.loads((here/'DEPENDENCIES.json').read_bytes())
archive=here/manifest['input']
assert sha256(archive.read_bytes()).hexdigest()==manifest['sha256']=='e9d216a6ed61f551fe11eb544725d0cb4cd5032fdc01982c90b769b386e816b1'
with tempfile.TemporaryDirectory(prefix='p104-basis-pivot-') as temp:
    subprocess.run(['tar','-xzf',str(archive),'-C',temp],check=True)
    forest=Path(temp)/'stage-contact-forest'
    for directory in (forest,forest/'p7952',forest/'p7964',forest/'p7977'):
        subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=directory,check=True,stdout=subprocess.PIPE)
    pivot=forest/'basis-pivot';pivot.mkdir()
    shutil.copy2(here/'basis_pivot.py',pivot/'basis_pivot.py')
    got=subprocess.run([sys.executable,'-I','-B','basis_pivot.py'],cwd=pivot,check=True,stdout=subprocess.PIPE).stdout
    assert got==(here/'RESULT.json').read_bytes(),'result differs from saved receipt'
print('PASS: embedded forest checksum, source manifests, complete basis pivot and saved results')
