#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Small formal caller interpreter with independent tuple-exponent encoding.

Coefficients are in F2[q,D1,...,D18]/(q**2-1). Each row maps a monomial to a
38-bit input-support mask. This file does not model the physical implementation.
"""

def shift(row, stages=(), q=0):
    result={}
    for (head, powers), mask in row.items():
        powers=list(powers)
        for stage in stages:
            if not 1 <= stage <= 18:
                raise ValueError('stage outside 1..18')
            powers[stage-1]+=1
        key=(head ^ q, tuple(powers))
        if key in result:
            raise ValueError('shift unexpectedly merged monomials')
        result[key]=mask
    return result


def add(left, right):
    result=left.copy()
    for key, mask in right.items():
        result[key]=result.get(key, 0) ^ mask
        if not result[key]:
            del result[key]
    return result


def rows(caller, reverse=False):
    n=caller['roles']
    state=[{(0,(0,)*18): 1<<j} for j in range(n)]
    events=caller['events'][::-1] if reverse else caller['events']
    for event in events:
        op=event[0]
        if op in ('ADD', 'QUERY'):
            a,b=event[1:]
            if reverse:
                a,b=b,a
            state[a]=add(state[a],shift(state[b],q=(op=='QUERY')))
        elif op=='SWAP':
            a,b=event[1:]
            state[a],state[b]=state[b],state[a]
        elif op=='LOCAL':
            stage,a,b=event[1:]
            if reverse:
                a,b=b,a
            old_a=state[a]
            state[a]=shift(old_a,[stage])
            state[b]=shift(add(state[b],shift(old_a,q=1)),[stage])
        elif op=='IDLE_ONE':
            a,stages=event[1:]
            state[a]=shift(state[a],stages)
        else:
            raise ValueError('unknown caller operation: '+str(op))
    return state


def expected(caller):
    out=[]
    for i,target in enumerate(caller['diagonal']):
        powers=tuple(int(stage in target['stages']) for stage in range(1,19))
        out.append({(target['q'],powers):1<<i})
    return out
