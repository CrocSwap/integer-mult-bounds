# A two-port BIT idle: bounded one-call batch obstruction

At the pinned [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830) caller's zero-based clock 103, ports 0 and 1 both execute `IDLE_ONE` on role 9 for stage 9. Their physical body spaces are different rank-7 subspaces with a rank-6 intersection. For one explicitly chosen stage-coordinate matching, the restrictions of the two desired changes to independent one-hot-address-pulse fields have direct-sum rank 14; combining their difference images in one unchanged 15-axis field has rank 8. This is a finite necessary-condition screen at a **logical caller clock**. The source has not been shown to issue one simultaneous serial-tape instruction for the two occurrences.

The compared occurrences belong to two distinct port groups at the same idle event; no QUERY is changed and no idle is commuted across other caller events. For the defined single-call model below, one common physical operation surrounded by arbitrary pointwise scalar mixing cannot supply both independent outputs, even if any fresh scratch fields may be left dirty. The model includes arbitrary scalar mixtures and an arbitrary common physical endomorphism, but **excludes role-dependent physical matchers or coordinate selectors, multiple paid operations, and changes interleaved with other caller events**. Those are open possibilities, not consequences of this exclusion. There is no modified caller, proved restored physical interface, new κ result, or complete compiler or outer replay here.

## Sources and logical clock

The comparator is #7830 at `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`. Its reported lower endpoint `0.00387992803556` is conditional on `native_all_columns`, `owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery`. Its published review reports the fixed-profile BIT raw crossing in `[0.003879928046154, 0.003879928046155]`. [#7852](https://github.com/CrocSwap/integer-mult-bounds/pull/7852) at `41beda1d6435760dc99e38bd7e65f36798aad212` motivated the broader question; this packet does not apply or replay its theorems. Exact source URLs, Git blob IDs, hashes and notices are in [SOURCES.json](SOURCES.json).

The pinned E-free caller has 111 port groups, 38 roles per group, 18 stages and 798 literal macro events. Clock 103 is `IDLE_ONE 9 [9]` in each group; the next event, clock 104, swaps roles 9 and 8. The formal caller interpreter checks all 38 diagonal endpoint rows in both forward and adjoint orientations. Deleting the idle changes final rows 0 and 8. These checks establish formal sensitivity, not a fresh native replay or physical lifting proof.

## Pinned port spans and the chosen pulse model

In the pinned native word, ports 0 and 1 have head frames 2 and 3 and body frames 525 and 526. The stored body bases in the common old eight-axis space are

```
H0 = span(e1,e2,e3,e4,e5,e6,e7)
H1 = span(e0,e2,e3,e4,e5,e6,e7).
```

Each span has dimension 7, their union has dimension 8, and their intersection has dimension 6. The rank checks are exact for these coordinate bases over either the rationals or GF(2).

The physical source describes exchanging each port's seven basis directions with seven fresh stage directions while fixing its head and spectators. For the finite control here, pair each displayed body basis vector **in its displayed order** with one of seven local fresh axes `f0,...,f6` and swap each pair. This is an explicit choice consistent with that stated interface. We did not reconstruct the actual emitted per-port matching or complete compiler route. In particular, the rank-8 common image and the equal-pulse cancellation below are claims about this chosen matching. An additional abstract-model control fixes port 0 and enumerates all 7! fresh-axis permutations for port 1: the common-image rank ranges from 8 to 14, and 720 of the 5,040 choices have rank 14. It is not a census of physically emitted routes. Thus the pinned body-space intersection alone does not imply the rank-8 image.

Let `pulse(ei)` be the field input supported on the address with the one axis `ei` set, and let `pulse(fi)` have the analogous meaning. Coordinate swaps preserve the 15-dimensional subspace spanned by these one-hot-address pulses. In this subspace, the change from identity has rank 7 on each independent owner and rank 14 on their direct sum. Summing the two changes into one unchanged field gives image rank 8. The two equal inputs `pulse(e2), pulse(e2)` XOR to zero, while the two separate required differences are each `pulse(e2)+pulse(f1)`.

These inputs are covered by an arbitrary-complete-field contract; no general independence or arbitrary-input assumption is weakened. The figure 14 is **not** the rank of the induced operator on the full array. As an independent control, [control.py](control.py) enumerates all `2^15` addresses of the illustrative 15-axis model. For each port its permutation has 256 fixed addresses and 16,256 two-cycles, so the full 15-axis array difference has rank 16,256 over GF(2), and the pair has direct-sum rank 32,512. This finite control is not a rank claim for the complete source's 134-axis array.

## One common physical operation with scalar role mixing

Consider a single paid interface whose departure from the scalar baseline factors into one input role direction, one common physical endomorphism, and one output role direction. This includes one common field operation or one partial-interchange-type role coupling, surrounded by arbitrary pointwise scalar mixing of role fields. Permit any number of fresh zero scratch fields, and drop all requirements that their outputs be restored. Restricted to the two original owners, the resulting two-by-two block operator is contained in the relaxation

```
B_ij I + u_i v_j K,
```

with arbitrary scalar `B,u,v` and arbitrary physical linear map `K`. A real valid implementation must of course restore all owned fields and spectators; permitting dirty scratch only makes the test more favorable.

Let `S0,S1` be the two non-scalar selected coordinate swaps on the pulse subspace. If this relaxed form were `diag(S0,S1)`, the two diagonal equations would force both `u0*v0` and `u1*v1` to be nonzero. All four factors would therefore be nonzero, so either zero off-diagonal block forces `K` to be a scalar multiple of identity. Both diagonal blocks would then be scalar, a contradiction. This proof holds over any field and allows any physical dimension: taking input and output restrictions to the 15 one-hot-pulse coordinates is a necessary condition.

As a concrete binary check, [screen.py](screen.py) enumerates all 256 choices of `B,u,v`, solving for any common `K`. There are zero solutions for `diag(S0,S1)`; `diag(S0,I)` has two. The two-owner same-map control `diag(S0,S0)` also has no solution. These are not a lower bound on all rank-14 physical interfaces: an independently addressable direct sum with role-specific extraction, routing and restoration falls outside the model and requires its own proof and invoice.

## Price of the unconstructed batch

Write `H(r)=r^(1-C)`. At the trial `C=0.003879929046155`, directed rational-grid evaluation of the complete pinned #7830 BIT invoice gives

```
BIT margin:              [-0.000385127316613866441054139472099789196374647,
                          -0.000385127316613866441054139472099789196374646]
unchanged rational:      [ 0.211243929926514344381566367581254905069893951,
                           0.211243929926514344381566367581254905069893952]
```

If two rank-7 paid positions were replaced by one rank-14 position with every productive target and all other paid positions preserved, the idealized credit `2 H(7)-H(14)` would be in

```
[0.037317668564121160335293523335309683070539380,
 0.037317668564121160335293523335309683070539381].
```

The hypothetical full BIT margin would be `+0.03693254124750729389...`. Charging one additional rank-1 paid service once would instead give `−0.96306745875249270610...`. These are actual directed arithmetic evaluations of a **hypothetical invoice**, not a claim that the replacement, free packing, or any particular restoration charge is physically attainable. The decimal control independently checks all five prices numerically at 110 digits; the certificate is the rational-grid arithmetic in [inputs/tariff.py](inputs/tariff.py). Additional route, matcher, temporary, erasure and target changes require explicit pricing.

## Replay and attribution

Use Python 3.10 or later, standard library only:

```sh
python3 -I -B replay.py
```

The replay verifies [SHA256SUMS](SHA256SUMS), the source SHA-256 and Git blob identifiers, regenerates [RESULT.json](RESULT.json) and [CONTROL.json](CONTROL.json), and compares the receipts byte for byte. It needs no network or local workspace paths. It does not replay the native word, compiler, finite supplier, stock, precision or outer theorem. The complete original inputs and notices are retained under [inputs](inputs/).

Credit DreamingOfClouds for the chain-root BIT and E-free roots, CubeJerry for the QUERY-only replacement, zxv and retained authors for integral transfer and the admission framework, and Ali Romman and Cinna Davis for the root/native lineage. Clear1nsight, Dugongue, Rohan Arun and the retained contributors supplied the comparator and supplier. The copied [#7830 notice](inputs/7830-NOTICE) and [BIT caller notice](inputs/BIT-CALLER-NOTICE) retain further attribution. This bounded screen was prepared with OpenAI Codex assistance; its controls are not independent human review.
