#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Bounded two-port caller, invariant pulse, one-call and price screen."""
import copy
from fractions import Fraction
import gzip
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
sys.path.insert(0,str(HERE/'inputs'))
import caller_eval
import tariff


def need(condition, message):
    if not condition:
        raise ValueError(message)


def load_pinned(path, expected):
    raw=(HERE/path).read_bytes()
    need(sha256(raw).hexdigest()==expected, 'source pin '+path)
    return raw


caller_blob=load_pinned('inputs/EFREE-CALLER.json.gz','757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b')
native_blob=load_pinned('inputs/BIT-WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9')
review_blob=load_pinned('inputs/7830-REVIEW.json','077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d')
load_pinned('inputs/tariff.py','f5da41a1fc18d1e8cdf79a7d35454922c6f81ffa1272ee7d7e4f16027a45dfb4')
w=json.loads(gzip.decompress(caller_blob))
native=json.loads(gzip.decompress(native_blob))
review=json.loads(review_blob)
canonical=sha256(json.dumps(native,sort_keys=True,separators=(',',':')).encode()).hexdigest()
need(canonical==review['headline']['binary_word']=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d','canonical native binding')
need(review['binary']['physical']['caller']==sha256(caller_blob).hexdigest(),'caller review binding')
need((w['ports'],w['roles'],w['stages'],len(w['events']))==(111,38,18,798),'caller shape')
need(w['events'][100:105]==[['LOCAL',9,1,0],['LOCAL',9,20,19],['ADD',0,1],['IDLE_ONE',9,[9]],['SWAP',9,8]],'source clocks')

# Sparse binary Gaussian elimination on column bitmasks. The 15-bit masks
# represent coefficients on one-hot ADDRESS PULSES, not the complete array.
def rank(columns):
    pivots={}
    for column in columns:
        while column:
            i=column.bit_length()-1
            if i in pivots:
                column ^= pivots[i]
            else:
                pivots[i]=column
                break
    return len(pivots)


def vector(bits):
    need(all(bit in (0,1) for bit in bits),'first two stored bodies are coordinate bases')
    return sum(bit<<i for i,bit in enumerate(bits))


bodies=[]
for port in (0,1):
    h=native['frames'][str(native['start'][port])]
    b=native['frames'][str(native['final'][111+port])]
    need((h['dim'],b['dim'])==(1,7),'head/body frame ranks')
    need(vector(h['B'][0])==1<<port,'source head basis')
    bodies.append([vector(v) for v in b['B']])
need(bodies==[[1<<i for i in (1,2,3,4,5,6,7)],[1<<i for i in (0,2,3,4,5,6,7)]],'body bases')
need(rank(bodies[0])==rank(bodies[1])==7 and rank(bodies[0]+bodies[1])==8,'physical axis intersection')

# Illustrative, explicitly selected ordered matching of stored body basis
# to seven fresh axes. The particular compiler-emitted route is not pinned.
def diff_columns(j):
    columns=[0]*15
    for i,vector_bits in enumerate(bodies[j]):
        old=vector_bits.bit_length()-1
        fresh=8+i
        columns[old]=columns[fresh]=(1<<old)|(1<<fresh)
    return columns


d0,d1=diff_columns(0),diff_columns(1)
need((rank(d0),rank(d1),rank(d0+d1),rank(d0+[x<<15 for x in d1]))==(7,7,8,14),'one-hot pulse ranks')
need((1<<2) in bodies[0] and (1<<2) in bodies[1],'common e2 axis')
need(d0[2]==d1[2] == (1<<2)|(1<<9),'explicit pulse difference')

I15=tuple(1<<i for i in range(15))
Z15=(0,)*15

def xor(a,b):
    return tuple(x^y for x,y in zip(a,b))


S0=xor(I15,tuple(d0))
S1=xor(I15,tuple(d1))


def relaxed_one_call_solutions(a,b):
    # Desired blocks diag(a,b). Permit any binary scalar baseline B, u, v,
    # and any common physical K. Once B,u,v are fixed, the needed K is
    # determined by every block with u_i*v_j=1.
    target=((a,Z15),(Z15,b))
    count=0
    for u in range(4):
        for v in range(4):
            for B in range(16):
                required=[]
                good=True
                for i in range(2):
                    for j in range(2):
                        scalar=I15 if B>>(2*i+j)&1 else Z15
                        difference=xor(target[i][j],scalar)
                        if (u>>i&1) and (v>>j&1):
                            required.append(difference)
                        elif difference!=Z15:
                            good=False
                if good and (not required or all(k==required[0] for k in required)):
                    count+=1
    return count


solutions=relaxed_one_call_solutions(S0,S1)
one_control=relaxed_one_call_solutions(S0,I15)
same_map_control=relaxed_one_call_solutions(S0,S0)
need(solutions==0 and one_control>0 and same_map_control==0,'one-call screen or control')

# Recheck both directions of the complete formal caller and an omitted-idle
# sensitivity control. The tuple exponent encoding is independent of the
# source's packed-integer monomial encoding.
expected=caller_eval.expected(w)
forward=caller_eval.rows(w)
reverse=caller_eval.rows(w,reverse=True)
need(forward==expected and reverse==expected,'formal caller endpoint, both directions')
bad=copy.deepcopy(w)
del bad['events'][103]
changed=[i for i,(a,b) in enumerate(zip(forward,caller_eval.rows(bad))) if a!=b]
need(changed==[0,8],'omitted idle visible at final formal boundary')

# Price exactly one hypothetical pair on the complete pinned invoice.
trial=Fraction('0.003879929046155')
binv=review['binary']['signed']
paid={int(k):v for k,v in binv['paid'].items()}
productive={int(k):v for k,v in binv['productive'].items()}
need(sum(paid.values())==107460 and sum(productive.values())==20706 and paid[7]>=2,'complete BIT invoice')
baseline=tariff.moment(tariff.signed_profile(productive,paid),trial)
credit=tariff.sub(tariff.scale(tariff.price(7,trial),2),tariff.price(14,trial))
after=tariff.add(baseline,credit)
after_extra1=tariff.sub(after,tariff.price(1,trial))
rinv=review['rational']['signed']
rpaid={int(k):v for k,v in rinv['paid'].items()}
rproductive={int(k):v for k,v in rinv['productive'].items()}
rational=tariff.moment(tariff.signed_profile(rproductive,rpaid),trial)
need(baseline[1]<0 and credit[0]>-baseline[0] and after[0]>0 and after_extra1[1]<0 and rational[0]>0,'directed price comparison')
fmt=lambda value:tariff.decimal_interval(value,45)
result={
 'status':'PASS_BOUNDED_ONE_CLOCK_ONE_HOT_AND_TARIFF_SCREEN',
 'source_commit_7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
 'pinned_caller_sha256':sha256(caller_blob).hexdigest(),
 'pinned_native_canonical_sha256':canonical,
 'pinned_review_sha256':sha256(review_blob).hexdigest(),
 'caller_clock':103,'event':w['events'][103],'next_reader_clock':104,'next_reader':w['events'][104],
 'caller_groups':[0,1],'port_head_frames':[native['start'][j] for j in (0,1)],
 'port_body_frames':[native['final'][111+j] for j in (0,1)],
 'body_axis_bases':[[x.bit_length()-1 for x in b] for b in bodies],
 'body_axis_ranks':[7,7],'body_axis_union_rank':8,'body_axis_intersection_rank':6,
 'illustrative_ordered_stage_matching':{
   'scope':'restriction to invariant 15-dimensional one-hot-address-pulse subspace; not the full array transfer rank',
   'ordered_fresh_axes':'8..14 in the local 15-axis model',
   'restricted_difference_ranks':[rank(d0),rank(d1)],
   'restricted_summed_image_rank':rank(d0+d1),
   'restricted_independent_owner_direct_sum_rank':rank(d0+[x<<15 for x in d1]),
   'same_e2_pulses_naive_packet':0,'each_required_difference_pulse_indices':[2,9]},
 'one_call_scalar_mixing':{
   'output_blocks':'B_ij I + u_i v_j K', 'model':'arbitrary scalar pre/post mixing of full owners, zero fresh scratch, one common physical operation; scratch output unconstrained',
   'candidate_B_u_v':256,'two_owner_solutions':solutions,'single_owner_control_solutions':one_control,
   'same_map_two_owner_control_solutions':same_map_control},
 'formal_caller':{'forward_and_adjoint_rows_each':len(forward),'omitted_idle_changed_final_rows':changed},
 'pricing':{'trial':'0.003879929046155','paid_positions':sum(paid.values()),'productive_positions':sum(productive.values()),
   'full_bit_baseline_margin':fmt(baseline),'ideal_2H7_minus_H14_credit':fmt(credit),
   'ideal_full_bit_margin':fmt(after),'ideal_full_bit_margin_less_one_H1':fmt(after_extra1),
   'unchanged_rational_margin':fmt(rational),'status':'hypothetical pricing only; no replacement constructed'},
 'limitations':['macro-clock coincidence is not a reconstructed physical simultaneous tape instruction',
   'the ordered stage matching is illustrative, not a verified emitted port-specific route',
   'coordinate-dependent encoding, role-specific matchers, multiple paid operations, and interleaved caller edits are not excluded',
   'no restored physical caller, finite supplier, compiler, stock, precision, outer application or new kappa bound is claimed']}
print(json.dumps(result,indent=2,sort_keys=True))
