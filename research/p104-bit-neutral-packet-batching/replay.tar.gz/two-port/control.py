#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Independent address-label orbit and Decimal price controls.

The address control enumerates all 2**15 labels for the stated illustrative
coordinate matching. Decimal is a numerical cross-check, not a directed proof.
"""
from collections import Counter
from decimal import Decimal, localcontext
from itertools import permutations
import gzip
from hashlib import sha256
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def need(condition,message):
    if not condition:
        raise ValueError(message)


def authenticated(name,digest):
    raw=(HERE/'inputs'/name).read_bytes()
    need(sha256(raw).hexdigest()==digest,'pin '+name)
    return raw


native=json.loads(gzip.decompress(authenticated('BIT-WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9')))
review=json.loads(authenticated('7830-REVIEW.json','077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d'))
main=json.loads((HERE/'RESULT.json').read_bytes())


def pairs_for(port):
    body=native['frames'][str(native['final'][111+port])]['B']
    pairs=[]
    for i,row in enumerate(body):
        nz=[j for j,entry in enumerate(row) if entry]
        need(len(nz)==1 and row[nz[0]]==1,'coordinate frame control')
        pairs.append((nz[0],8+i))
    return pairs


def swap_address(address,pairs):
    for x,y in pairs:
        if ((address>>x) ^ (address>>y)) & 1:
            address ^= (1<<x)|(1<<y)
    return address


stats=[]
for port in (0,1):
    pairs=pairs_for(port)
    outputs=[swap_address(i,pairs) for i in range(1<<15)]
    need(len(set(outputs))==1<<15,'full 15-bit mapping bijective')
    need(all(outputs[outputs[i]]==i for i in range(1<<15)),'full mapping involutive')
    fixed=sum(i==j for i,j in enumerate(outputs))
    transpositions=sum(i<j for i,j in enumerate(outputs))
    # A single two-cycle gives a 2x2 permutation minus I of rank one over F2.
    need((fixed,transpositions)==(256,16256),'complete 15-bit cycle count')
    pulse=1<<2
    moved=outputs[pulse]
    need(moved==1<<9,'ordered pulse witness')
    stats.append({'port':port,'fixed_address_labels':fixed,'two_cycles':transpositions,
                  'full_15_bit_array_difference_rank':transpositions,
                  'e2_address_label':pulse,'mapped_address_label':moved})

# The source does not pin which ordered fresh coordinates each body uses.
# Enumerate all 7! permutations for port 1 while keeping port 0 fixed.
# This is a finite model sensitivity control, not a source-route census.
def binary_rank(vectors):
    basis={}
    for v in vectors:
        while v:
            pivot=v.bit_length()-1
            if pivot in basis: v ^= basis[pivot]
            else:
                basis[pivot]=v
                break
    return len(basis)

base0=[(1<<old)|(1<<fresh) for old,fresh in pairs_for(0)]
base1=[old for old,_ in pairs_for(1)]
rank_counts=Counter()
witnesses={}
for order in permutations(range(7)):
    moved=[(1<<old)|(1<<(8+order[j])) for j,old in enumerate(base1)]
    dimension=binary_rank(base0+moved)
    rank_counts[dimension]+=1
    witnesses.setdefault(dimension,list(order))
need(dict(sorted(rank_counts.items()))=={8:1,9:21,10:175,11:735,12:1624,13:1764,14:720},'matching sensitivity')

# Under naive field addition, the two equal input pulses cancel. Their actual
# separate difference fields are nonzero. Sets represent occupied full array
# labels, not coordinate-vector bitmasks.
input0={1<<2}; input1={1<<2}
naive_packet=input0.symmetric_difference(input1)
delta0=input0.symmetric_difference({swap_address(1<<2,pairs_for(0))})
delta1=input1.symmetric_difference({swap_address(1<<2,pairs_for(1))})
need(not naive_packet and delta0==delta1=={1<<2,1<<9},'two-owner pulse cancellation control')
need(bool(delta0) and bool(delta1),'missing-idle mutation must be seen')

# Compare independently evaluated 110-digit Decimal moments to the exact
# rational-grid enclosures. Decimal's transcendental arithmetic is a numerical
# cross-check only; screen.py/tariff.py supply the directed certificates.
intervals=main['pricing']
def within(value,key):
    lo,hi=map(Decimal,intervals[key])
    need(lo<=value<=hi,'Decimal outside directed interval: '+key)

with localcontext() as ctx:
    ctx.prec=110
    trial=Decimal('0.003879929046155')
    exponent=Decimal(1)-trial
    def H(rank):
        return (Decimal(rank).ln()*exponent).exp()
    def moment(invoice):
        p=sum(Decimal(n)*H(int(r)) for r,n in invoice['productive'].items())
        q=sum(Decimal(n)*H(int(r)) for r,n in invoice['paid'].items())
        return p-q
    bit=moment(review['binary']['signed'])
    rational=moment(review['rational']['signed'])
    credit=2*H(7)-H(14)
    within(bit,'full_bit_baseline_margin')
    within(credit,'ideal_2H7_minus_H14_credit')
    within(bit+credit,'ideal_full_bit_margin')
    within(bit+credit-H(1),'ideal_full_bit_margin_less_one_H1')
    within(rational,'unchanged_rational_margin')

result={'status':'PASS_INDEPENDENT_ADDRESS_ORBITS_AND_NUMERIC_PRICE_CONTROL',
        'scope':'exhaustive all 2^15 address labels for the illustrative stage matching only',
        'ports':stats,
        'independent_pair_full_15_bit_array_difference_rank':sum(x['full_15_bit_array_difference_rank'] for x in stats),
        'port1_stage_matching_permutations_tested':sum(rank_counts.values()),
        'summed_one_hot_image_rank_histogram':dict(sorted(rank_counts.items())),
        'one_fresh_order_witness_per_rank':dict(sorted(witnesses.items())),
        'warning':'this 15-bit full-array rank differs from the 15-dimensional one-hot-pulse subspace rank; neither is the source full 134-axis array rank',
        'naive_equal_pulse_packet_occupied_labels':sorted(naive_packet),
        'each_correct_difference_occupied_labels':sorted(delta0),
        'missing_idle_detected':True,
        'decimal_110_digit_values_lie_in_all_five_directed_intervals':True,
        'decimal_status':'independent numerical cross-check, not a directed proof'}
print(json.dumps(result,indent=2,sort_keys=True))
