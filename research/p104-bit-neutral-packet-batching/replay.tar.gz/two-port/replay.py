#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Read-only, offline replay of the source-pinned two-port screen."""
from hashlib import sha1,sha256
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def need(condition,message):
    if not condition:
        raise ValueError(message)


for line in (HERE/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    path=(HERE/name).resolve()
    need(path.is_relative_to(HERE),'manifest path is outside packet')
    need(sha256(path.read_bytes()).hexdigest()==expected,'manifest mismatch: '+name)
print('packet manifest PASS')

source=json.loads((HERE/'SOURCES.json').read_bytes())
for item in source['inputs']:
    path=(HERE/item['path']).resolve()
    need(path.is_relative_to(HERE),'source path is outside packet')
    raw=path.read_bytes()
    need(sha256(raw).hexdigest()==item['sha256'],'source SHA-256: '+item['path'])
    if 'git_blob' in item:
        identifier=sha1(('blob '+str(len(raw))+'\0').encode()+raw).hexdigest()
        need(identifier==item['git_blob'],'source Git blob: '+item['path'])
print('source hashes and recorded Git blobs PASS')

for script,receipt in [('screen.py','RESULT.json'),('control.py','CONTROL.json')]:
    actual=subprocess.check_output([sys.executable,'-I','-B',str(HERE/script)],cwd=HERE)
    need(actual==(HERE/receipt).read_bytes(),'receipt mismatch: '+receipt)
    print(script+': regenerated receipt PASS')
print('PASS: bounded scope only; no physical caller or kappa claim')
