# One-owner physical packet at the BIT 131/196 window

**Local scoped obstruction.** In the literal #7830 BIT caller, a single grade-8 partial interchange on one field cannot, with a neutral no-op wrapper, replace both the stage-9 body idle at clock 131 and the head query at clock 196 while preserving the complete caller transfer. This is a value-level support bound for **independently addressed complete input fields**. It permits arbitrary linear, address-dependent packing and unpacking; it does not require the packet to be rank one in the 38-dimensional role index.

The model requires that setting the one proposed paid interchange to identity leaves exactly the original caller with the 131 idle removed and the 196 query replaced by ordinary ADD. It retains the other caller operations. The proposed job acts on one full field with the same complete address domain as each original field. Embedding the two source fields into a strictly larger, zero-initialized or tagged address domain is outside this rank bound and would need its own full volume, routing, stock and clear bill. A different no-op reference, changed surrounding paid operations, a non-interchange rank-8 map, new productive targets, or a service joint across multiple ports is also outside this proof. This is not a universal BIT barrier, a new lower bound, a changed physical caller, or a proof of the five inherited assumptions.

Pins: #7830 `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; #7852 `41beda1d6435760dc99e38bd7e65f36798aad212` (motivation only); canonical main `e54523517d0f03e58352e647c403a5af3e525a57`. The retained independent #7830 receipt fixes the caller and native hashes, the two complete paid/target histograms, and the raw BIT crossing. [check.py](check.py) authenticates the four directly used source inputs. Their notices are in `inputs/`; the package [LICENSE](LICENSE) is retained at the root. The scientific source URLs, immutable heads, Git blob IDs and file hashes are listed in [SOURCES.json](SOURCES.json).

## Physical factors and their actual order

The first main port of the pinned native word has head frame 2 with `B=(e0)` and body frame 525 with `B=(e1,...,e7)`. In the native eight-coordinate port frame these give rational projectors

```
P_H = diag(1,0,...,0),   P_B = diag(0,1,...,1).
```

The script also checks over the rationals that all 111 actual port pairs have complementary head and body spaces. The framework's prime must avoid the finitely many frame denominators and determinants. Port 0 has the identity basis, so it is good at every prime.

For the two complete address chunks, write `S(P)=[[I-P,P],[P,I-P]]`. The integral identities `P_H²=P_H`, `P_B²=P_B`, `P_H P_B=0`, `P_H+P_B=I` give

```
H = S(P_H),   D = S(P_B),   H D = D H = S(I),   H² = D² = I.
```

The stage-9 body frame is embedded in its fresh seven-dimensional block and fixes the shared head; conjugation by the invertible stage frame preserves these identities. The identity factors one complete interchange on the same owner; it does not by itself expose separately addressable head and body operations on independent owners. The retained whole-job contract completes the child and its adapters before the parent resumes, so a grade-8 call cannot simply be paused to present a body factor at clock 131 and a head factor at clock 196. In the retained reversal convention, conjugate the two-chunk map by `diag(I,C_N)`, where the fixed involution `C_N` acts on the second chunk; this gives the retained reversed partial interchange. These are exact integer/rational identities, hence hold on every allowed `Z/(p^w)` residue, not a claim based on a single random substitution. Untouched address coordinates remain full spectators.

The precise sequence matters. Clock 131 is `IDLE_ONE 28 [9]`. Clock 132 immediately swaps roles 28 and 27, consuming the changed field. Clock 150 adds role 19 into role 27. Propagating the **actual** 64 intervening ADD/SWAP instructions shows that immediately before the clock-196 `QUERY 0 19`, its source role 19 is exactly the pre-131 field in role 0, and the pre-131 role-28 input occurs only in role 27. Thus the idle value was needed before the query, but the query's source is independent of it. The other live role-27 terms are the pre-131 fields 19 and 20.

Compare the actual caller to the fixed reference that replaces only the idle by identity and this QUERY by ADD. Immediately after clock 196 their difference is exactly

```
output role 27:  (D + I) x_28
output role  0:  (H + I) x_0
```

with all other rows zero. Here `x_0` and `x_28` are arbitrary independent full fields at the pre-131 cut, and `+` is XOR. Every old caller operation is invertible at this level, so the common prefix and suffix do not change the rank of this difference. In particular, this is not a claim based only on the two intermediate readers or on freely abstract `q,D` variables. The finite control specializes all other stage body maps to identity; the general argument does not require that specialization.

## Exact support deficit

Let the selected residue ring have size `m=p^w>1`, and let `n` be the number of complete address points in two chunks, including spectators. The physical partial interchange on `r` coordinates fixes a fraction `m^(-r)` of the points and has only 1- and 2-cycles. As a linear map on binary-valued complete fields,

```
rank(I + H)  = n(1-m^-1)/2
rank(I + D)  = n(1-m^-7)/2
rank(I + HD) = n(1-m^-8)/2.
```

The required two-input, two-output difference is a direct sum, so its rank is the first two ranks **added**, strictly more than the third. The deficit is

```
n(1-m^-1)(1-m^-7)/2 > 0.
```

Equivalently, each orbit where both head and body move has four points; the two separate field differences have rank four on that orbit, while the grade-8 interchange's difference has rank two. All other orbit types tie. The same grade-8 bound applies after any allowed invertible change of its physical projector frame on the same full address domain. A larger packet domain has a larger matrix and is not covered by this comparison. For the concrete port-0 residue `m=3` with just its eight selected coordinates and no extra spectators, the two effects require rank 35,862,426, but one grade-8 interchange has rank 21,520,080, a deficit of 14,342,346. Extra untouched spectators multiply all ranks equally.

A limited conclusion is possible for a hypothetical packet of `t` identical full-size fibres on which the same grade-8 swap acts separately: the rank inequality requires

```
t >= ceil((2-m^-1-m^-7)/(1-m^-8)) = 2.
```

This is a necessary support count, not a construction or a bill. It does not establish that a two-fibre packet is a permitted single-owner child or that it costs one grade-8 job.

To see why arbitrary linear packing does not change the result, place any linear preparation before the single proposed physical interchange and any linear unpacking/clears after it, allowing arbitrary role and address mixing. Compare that same full candidate with the same candidate after replacing its interchange by identity. The difference factors as `A (S-I) B` and therefore has rank at most `rank(S-I)`. The specified neutral no-op contract makes this no-op candidate equal to the removed-pair reference, whereas the preceding exact caller calculation needs a strictly larger rank. Zero or dirty owned scratch and linear resets cannot increase the rank bound. The argument also allows the packet at an arbitrary clock, provided the no-op reference condition holds. It does not rule out a replacement whose no-op behavior changes the fixed reference or uses a second paid intervention.

The main computational control constructs a finite `m=3` physical example with one head axis and **one** body axis, executes all 798 caller events with the other body stages set to identity, checks 3,078 exact diagonal entries and retains all 38 independent role inputs. The unchanged caller passes, the two removed jobs produce rank 54, and the single combined swap has rank 36. This illustrates the proof and is deliberately not called a full seven-axis/native replay. The exact seven-axis ranks above use the cycle count, not a 43-million-element enumeration.

## Conditional price and clearing

Let `H_r=r^(1-kappa)`. For this one-port isolated replacement the hoped-for paid delta is `{1:-1, 7:-1, 8:+1}`. The support result rejects that neutral one-job packet. A repair in the same neutral-reference model must contain at least one additional positive paid intervention. Charging the cheapest possible extra job, grade 1, and generously retaining every original productive target yields per port

```
maximum optimistic signed credit = H_7 - H_8 < 0.
```

The 111-fold price below assumes 111 **separately** repaired ports. It makes no claim that a single joint cross-port job is impossible. The source's original realization of the clock-196 queries uses one serial scratch bank: each port copies its independent source, executes the head job, adds its result and clears the dirty scratch before reuse, giving 111 such CLEAR instructions in that realization. No alternative packet or clear schedule exists here to price exactly. For the favorable comparison, grant the repair zero *additional* clear, route, workspace and ordinary cost and no productive debit. Any actual candidate must account for every scratch lifetime and required CLEAR; the permitted lower bound is already unfavorable.

| `kappa` | Complete old BIT margin | Ideal unachievable 111-port credit | Optimistic credit after one extra grade 1 per port | Resulting BIT margin |
| --- | ---: | ---: | ---: | ---: |
| `0.003879928046155` | `-0.000000000381875` | `+1.2913805506523` | `-109.708619449348` | `-109.708619449730` |
| `0.003889928046155` | `-3.851191807064` | `+1.294691567823` | `-109.705308432177` | `-113.556500239240` |

The full unchanged productive and paid histograms and outward interval calculations are in [RESULT.json](RESULT.json). For the optimistic grade-1-extra relaxation the complete paid bins are the old bins with 111 grade-7 jobs replaced by 111 grade-8 jobs; grade-1 stays unchanged. The rational invoice is unchanged and remains separately negative at the enrolled comparison. This is a price relaxation, not a constructed schedule or an unconditional lower bound on other edits.

## Reproduce

Use one standard-library Python process:

```sh
python3 -I -B replay.py
```

A separate control evaluates all four physical orbit types with the actual seven body coordinates and the literal clocks 131–196; see [CONTROL.json](CONTROL.json). It is an automated cross-check by the same research team, not independent human review. The analytic rank argument depends on finite residue cycles and the retained physical meaning of a whole partial interchange; it has not received independent human or formal-kernel review. The changed-caller, 680-column native replay, compiler, provider, precision/tape and outer application have not been rerun.

## Open next questions

The concrete escape route is a non-neutral wrapper or changed intervening word: specify its exact no-op operator, all other paid jobs, any independent target sacrificed or introduced, and the earliest physically correct role-27 read at clock 132. A tagged or otherwise enlarged zero-initialized packet, or a joint multiple-port service, requires a separate support and full-price calculation; this one-port bound cannot simply be multiplied into a global impossibility.

Credit DreamingOfClouds for chain-root BIT and paired E-free caller, CubeJerry for the QUERY-only replacement, zxv and retained authors for integral transfer, Ali Romman and Cinna Davis for the root/native lineage, and Clear1nsight, Dugongue, Rohan Arun and the retained P104 contributors for the comparator and supplier. The included notices preserve further credits and Apache-2.0 terms. OpenAI Codex assisted this local analysis.
