#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Directed signed power prices, adapted from #7830 review/independent.py.

The ancestor's exact-head SHA-256 is
a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca.
"""
from collections import Counter
from fractions import Fraction as Q
from functools import cache

GRID = 10**70

def ceildiv(a, b):
    return -((-a)//b)

def enclose(x):
    x = Q(x)
    p = x.numerator*GRID
    return p//x.denominator, ceildiv(p,x.denominator)

def add(a,b):
    return a[0]+b[0],a[1]+b[1]

def sub(a,b):
    return a[0]-b[1],a[1]-b[0]

def mul(a,b):
    p=[x*y for x in a for y in b]
    return min(p)//GRID,ceildiv(max(p),GRID)

def scale(a,c):
    return mul(a,enclose(c))

def decimal_interval(a,places=48):
    factor=10**places
    def fixed(value):
        head,tail=divmod(abs(value),factor)
        return f"{'-' if value<0 else ''}{head}.{tail:0{places}}"
    return [fixed(a[0]*factor//GRID),fixed(ceildiv(a[1]*factor,GRID))]

def small_log(x):
    z=(x-1)/(x+1)
    square=z*z
    power=z
    partial=Q(0)
    for term in range(80):
        partial+=2*power/(2*term+1)
        power*=square
    tail=2*power/(161*(1-square))
    return enclose(partial)[0],enclose(partial+tail)[1]

@cache
def log_int(r):
    bit=r.bit_length()-1
    return add(scale(small_log(Q(2)),bit),small_log(Q(r,2**bit)))

def exp_closed(x):
    assert x[0]>=0
    squarings,divisor=0,1
    while 8*x[1]>divisor*GRID:
        squarings+=1
        divisor*=2
    y=scale(x,Q(1,divisor))
    term=result=(GRID,GRID)
    for n in range(1,57):
        term=scale(mul(term,y),Q(1,n))
        result=add(result,term)
    next_term=scale(mul(term,y),Q(1,57))
    assert y[1]*7<GRID
    result=result[0],result[1]+2*next_term[1]
    for _ in range(squarings): result=mul(result,result)
    return result

@cache
def price(rank,k):
    assert rank>=1 and 0<=k<=1
    return exp_closed(scale(log_int(rank),1-k))

def moment(hist,k):
    out=(0,0)
    for rank,count in hist.items():
        if count: out=add(out,scale(price(rank,k),count))
    return out

def signed_profile(targets,paid):
    out=Counter(targets)
    out.subtract(paid)
    return out
