#!/usr/bin/env python3
"""Independent four-orbit control of the seven-axis physical interface.

Uses actual 8-coordinate residue pairs, bitsets for field values, and literal
caller instructions.  This is a finite control for the proof, not a full
native, supplier, or all-residue replay.  Apache-2.0.
"""
from hashlib import sha1, sha256
from pathlib import Path
import gzip
import json

ROOT=Path(__file__).resolve().parent
raw=(ROOT/'inputs/EFREE-CALLER.json.gz').read_bytes()
assert sha256(raw).hexdigest()=='757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b'
assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()=='f022272a8d51ede841778dec76e2bfb24b614d04'
caller=json.loads(gzip.decompress(raw)); events=caller['events']
assert len(events)==798 and caller['roles']==38 and caller['ports']==111
assert events[131]==['IDLE_ONE',28,[9]] and events[132]==['SWAP',28,27]
assert events[196]==['QUERY',0,19]

# Points are two 8-coordinate chunks over Z/3.  Axis 0 is the head; axes
# 1..7 are the body.  These are actual representatives of all four orbit
# types, with no collapsed body dimension.
def head(p):
    a,b=p[:8],p[8:]
    return (b[0],)+a[1:]+(a[0],)+b[1:]

def body(p):
    a,b=p[:8],p[8:]
    return (a[0],)+b[1:]+(b[0],)+a[1:]

def field_permute(value, perm):
    return sum(((value>>j)&1)<<i for i,j in enumerate(perm))

def rank(columns):
    basis={}
    for x in columns:
        while x:
            i=x.bit_length()-1
            if i in basis: x ^= basis[i]
            else:
                basis[i]=x
                break
    return len(basis)

def diff_rank(perm):
    return rank([(1<<i)^(1<<j) for i,j in enumerate(perm)])

types=[]
for hh,bb in ((0,0),(1,0),(0,1),(1,1)):
    left=(0,)*8
    right=(hh,)+( (1,2,0,1,2,1,0) if bb else (0,)*7 )
    x=left+right
    orbit=sorted({x,head(x),body(x),head(body(x))})
    assert all(head(head(y))==body(body(y))==y for y in orbit)
    assert all(head(body(y))==body(head(y)) for y in orbit)
    index={y:i for i,y in enumerate(orbit)}
    h=[index[head(y)] for y in orbit]
    b=[index[body(y)] for y in orbit]
    s=[index[head(body(y))] for y in orbit]
    rh,rb,rs=map(diff_rank,(h,b,s))
    expected = {(0,0):(1,0,0,0),(1,0):(2,1,0,1),
                (0,1):(2,0,1,1),(1,1):(4,2,2,2)}[(hh,bb)]
    assert (len(orbit),rh,rb,rs)==expected
    types.append({'head_active':bool(hh),'body_active':bool(bb),'orbit_points':len(orbit),
                  'head_difference_rank':rh,'body_difference_rank':rb,
                  'grade8_difference_rank':rs})
    if hh and bb: physical_h,physical_b=h,b

# Run actual 131..196 with independent arbitrary values on the four active
# points of pre-131 roles 0 and 28.  Bit i is the binary field at orbit point i.
def run(idle,query,role0,role28):
    v=[0]*38
    v[0],v[28]=role0,role28
    watched={}
    for clock in range(131,197):
        op,*z=events[clock]
        if op=='IDLE_ONE':
            assert clock==131
            if idle: v[z[0]]=field_permute(v[z[0]],physical_b)
        elif op=='ADD': v[z[0]] ^= v[z[1]]
        elif op=='SWAP': v[z[0]],v[z[1]]=v[z[1]],v[z[0]]
        elif op=='QUERY':
            assert clock==196
            v[z[0]] ^= field_permute(v[z[1]],physical_h) if query else v[z[1]]
        else: raise AssertionError((clock,events[clock]))
        if clock in (131,132,150,195,196): watched[clock]=tuple(v)
    return watched

def difference(columns,clock):
    return [sum(((ga[clock][r]^gb[clock][r])<<(4*r)) for r in range(38)) for ga,gb in columns]

inputs=[(1<<i,0) for i in range(4)]+[(0,1<<i) for i in range(4)]
def cases(idle,query):
    return [(run(idle,query,x,y),run(False,False,x,y)) for x,y in inputs]

both=cases(True,True)
body_only=cases(True,False)
head_only=cases(False,True)
none=cases(False,False)
checks={'both':rank(difference(both,196)), 'body_only':rank(difference(body_only,196)),
        'head_only':rank(difference(head_only,196)), 'both_removed':rank(difference(none,196))}
assert checks=={'both':4,'body_only':2,'head_only':2,'both_removed':0}
# Check the clock-132 reader actually receives the idle effect, and that the
# later query source is unchanged for every one of the eight independent bits.
for good,base in both:
    assert good[132][27]^base[132][27] == good[131][28]^base[131][28]
    assert good[195][19] == base[195][19]
    assert all(good[196][j]==base[196][j] for j in range(38) if j not in (0,27))

out={'status':'PASS_INDEPENDENT_FOUR_ORBIT_AND_LITERAL_CONTROLS',
     'source_sha256':sha256(raw).hexdigest(), 'residue_ring':'Z/3',
     'physical_head_axes':1,'physical_body_axes':7,'representative_orbits':types,
     'independent_input_bits_at_cut':8, 'reader_132_and_query_source_195_checked':True,
     'event_interval':[131,196], 'literal_reader_difference_ranks_after_196':checks,
     'limitations':['one representative of each orbit type, not all residue addresses',
                    'this finite control does not establish the arbitrary-residue cycle count or replay the native supplier',
                    'same automated research team, not independent human review']}
print(json.dumps(out,indent=2,sort_keys=True))
