#!/usr/bin/env python3
"""Scoped physical-support screen for one #7830 BIT port, clocks 131/196.

This does not produce a changed caller.  The complete source invoice is repriced
only as an optimistic relaxation of the explicitly scoped packet model.
"""
from fractions import Fraction as F
from hashlib import sha256
from itertools import product
from pathlib import Path
import gzip
import json
import sys

HERE = Path(__file__).resolve().parent
PINS = {
    'EFREE-CALLER.json.gz': '757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b',
    'BIT-WORD.json.gz': 'd28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9',
    '7830-REVIEW.json': '077ef3c35f037e67bd8e09dbe0860337a23f0cb17125c9843b818edf9e6e339d',
    'tariff.py': 'f5da41a1fc18d1e8cdf79a7d35454922c6f81ffa1272ee7d7e4f16027a45dfb4',
}
for name, digest in PINS.items():
    assert sha256((HERE/'inputs'/name).read_bytes()).hexdigest() == digest, name
sys.path.insert(0, str(HERE/'inputs'))
import tariff

caller = json.loads(gzip.decompress((HERE/'inputs/EFREE-CALLER.json.gz').read_bytes()))
native = json.loads(gzip.decompress((HERE/'inputs/BIT-WORD.json.gz').read_bytes()))
review = json.loads((HERE/'inputs/7830-REVIEW.json').read_text())
events = caller['events']
assert (caller['roles'], caller['ports'], len(events)) == (38, 111, 798)
assert events[131] == ['IDLE_ONE', 28, [9]]
assert events[132] == ['SWAP', 28, 27]
assert events[150] == ['ADD', 27, 19]
assert events[196] == ['QUERY', 0, 19]
assert sha256(json.dumps(native,sort_keys=True,separators=(',',':')).encode()).hexdigest() == review['headline']['binary_word']

# A real port, not an abstract dimension profile.  At port 0 the input
# head chart and its output complementary body are literally standard axes.
f = native['frames']
hc, bc = native['start'][0], native['final'][111]
assert (hc, bc) == (2,525)
eye8 = [[int(i == j) for j in range(8)] for i in range(8)]
assert f[str(hc)] == {'dim': 1, 'B': eye8[:1], 'A': eye8[1:]}
assert f[str(bc)] == {'dim': 7, 'B': eye8[1:], 'A': eye8[:1]}

# Independently bind the same head/body complement property for the other
# 110 ports, over Q.  Prime selection must avoid all frame denominators and
# determinants; the explicit residue example below uses standard port 0.
def rank_rational(rows):
    a = [[F(x) for x in row] for row in rows]
    k = 0
    for c in range(len(a[0])):
        pivot = next((i for i in range(k,len(a)) if a[i][c]), None)
        if pivot is None: continue
        a[k],a[pivot] = a[pivot],a[k]
        v=a[k][c]
        a[k]=[x/v for x in a[k]]
        for i in range(k+1,len(a)):
            v=a[i][c]
            if v: a[i]=[x-v*y for x,y in zip(a[i],a[k])]
        k+=1
        if k == len(a): break
    return k

def dot(a,b):
    return sum(F(x)*F(y) for x,y in zip(a,b))

for port in range(111):
    head=f[str(native['start'][port])]
    body=f[str(native['final'][111+port])]
    h=head['B'][0]
    assert (head['dim'],body['dim']) == (1,7)
    assert rank_rational(head['B']+head['A']) == rank_rational(body['B']+body['A']) == 8
    assert all(dot(h,a)==0 for a in head['A'])
    assert all(dot(v,body['A'][0])==0 for v in body['B'])
    assert all(dot(h,v)==0 for v in body['B'])
    # Both 7-spaces equal h-perp, and both 1-spaces are the same rational
    # orthogonal complement. Therefore PH+PB=I in every good residue.
    assert rank_rational([h,body['A'][0]]) == 1

def mulmat(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(len(b))) for j in range(len(b[0]))] for i in range(len(a))]

def addmat(a, b):
    return [[x+y for x,y in zip(ra,rb)] for ra,rb in zip(a,b)]

def submat(a, b):
    return [[x-y for x,y in zip(ra,rb)] for ra,rb in zip(a,b)]

def block2(a,b,c,d):
    n=len(a)
    return [a[i]+b[i] for i in range(n)] + [c[i]+d[i] for i in range(n)]

Z = [[0]*8 for _ in range(8)]
PH = [[int(i == j == 0) for j in range(8)] for i in range(8)]
PB = submat(eye8, PH)
P8 = addmat(PH, PB)
SH = block2(submat(eye8,PH), PH, PH, submat(eye8,PH))
SB = block2(submat(eye8,PB), PB, PB, submat(eye8,PB))
S8 = block2(Z, eye8, eye8, Z)
I16 = [[int(i == j) for j in range(16)] for i in range(16)]
assert mulmat(PH,PH) == PH and mulmat(PB,PB) == PB
assert mulmat(PH,PB) == mulmat(PB,PH) == Z and P8 == eye8
assert mulmat(SH,SB) == mulmat(SB,SH) == S8
assert mulmat(SH,SH) == mulmat(SB,SB) == mulmat(S8,S8) == I16
# Retained two-chunk reversal convention: D_P = diag(I,C) S(P) diag(I,C).
C8 = [[int(i+j==7) for j in range(8)] for i in range(8)]
rev = block2(eye8,Z,Z,C8)
assert mulmat(rev,rev) == I16
def reversed_interchange(p):
    return block2(submat(eye8,p),mulmat(p,C8),mulmat(C8,p),
                  submat(eye8,mulmat(mulmat(C8,p),C8)))
DH,DB,DF = [mulmat(mulmat(rev,s),rev) for s in (SH,SB,S8)]
assert DH == reversed_interchange(PH) and DB == reversed_interchange(PB)
assert DF == reversed_interchange(P8)
assert mulmat(DH,DB) == mulmat(DB,DH) == DF

# Trace the 64 intervening literal scalar operations from the moment just
# before the idle.  Rows are XOR forms in the pre-131 role fields.
forms = [1 << i for i in range(38)]
for clock in range(132,196):
    op,*args=events[clock]
    if op == 'ADD': forms[args[0]] ^= forms[args[1]]
    elif op == 'SWAP': forms[args[0]],forms[args[1]]=forms[args[1]],forms[args[0]]
    else: raise AssertionError((clock,events[clock]))
assert forms[19] == 1 << 0
assert forms[27] == (1<<19)^(1<<20)^(1<<28)
assert [i for i,row in enumerate(forms) if row & (1<<28)] == [27]

# Tiny explicit physical-address control: m=3, one head and ONE body axis.
# This is only a finite control for the seven-axis argument below.
m=3
addresses = list(product(range(m), repeat=4))  # headL, bodyL, headR, bodyR
index = {a:i for i,a in enumerate(addresses)}
nh = len(addresses)
hperm = [index[(c,b,a,d)] for a,b,c,d in addresses]
bperm = [index[(a,d,c,b)] for a,b,c,d in addresses]
assert all(hperm[hperm[i]] == bperm[bperm[i]] == i for i in range(nh))
assert all(hperm[bperm[i]] == bperm[hperm[i]] for i in range(nh))
sperm = [hperm[bperm[i]] for i in range(nh)]

def rank(rows):
    pivots={}
    for x in rows:
        while x:
            p=x.bit_length()-1
            if p in pivots: x ^= pivots[p]
            else:
                pivots[p]=x
                break
    return len(pivots)

def perm_rank(perm):
    return rank([(1<<i) ^ (1<<perm[i]) for i in range(len(perm))])

rank_h,rank_b,rank_s=map(perm_rank,(hperm,bperm,sperm))
assert (nh,rank_h,rank_b,rank_s) == (81,27,27,36)

# All 38 independent role inputs, both old maps and the removed-pair
# reference, retaining all four original QUERY occurrences.  The one body
# variable is stage 9; other stage maps are specialized to identity.  This
# is a finite control, not an all-stage full native replay.
def initial():
    return [[1 << (r*nh+a) for a in range(nh)] for r in range(38)]

def apply(st, event, clock, old):
    op,*z=event
    if op in ('ADD','QUERY'):
        dest,src=z
        perm = hperm if op=='QUERY' and (old or clock != 196) else range(nh)
        st[dest] = [x ^ st[src][perm[a]] for a,x in enumerate(st[dest])]
    elif op=='SWAP':
        st[z[0]],st[z[1]]=st[z[1]],st[z[0]]
    elif op=='IDLE_ONE':
        dst,stages=z
        if 9 in stages and (old or clock != 131):
            st[dst] = [st[dst][bperm[a]] for a in range(nh)]
    elif op=='LOCAL':
        stage,src,dst=z
        st[dst] = [x ^ st[src][hperm[a]] for a,x in enumerate(st[dst])]
        if stage == 9:
            st[src] = [st[src][bperm[a]] for a in range(nh)]
            st[dst] = [st[dst][bperm[a]] for a in range(nh)]
    else: raise AssertionError(event)

def active(a,b):
    return [r for r in range(38) if a[r] != b[r]]

good,ref=initial(),initial()
active_at={}
for clock,event in enumerate(events):
    apply(good,event,clock,True)
    apply(ref,event,clock,False)
    if clock in (131,132,150,195,196): active_at[str(clock)]=active(good,ref)
assert active_at == {'131':[28], '132':[27], '150':[27], '195':[27], '196':[0,27]}
for r, d in enumerate(caller['diagonal']):
    for a in range(nh):
        expected = hperm[bperm[a]] if 9 in d['stages'] else hperm[a]
        assert good[r][a] == 1 << (r*nh+expected), (r,a)
diffs=[good[r][a] ^ ref[r][a] for r in range(38) for a in range(nh)]
assert rank(diffs) == rank_h + rank_b == 54

# General exact cycle count on two eight-coordinate chunks.  Any untouched
# spectators multiply each count by their cardinality and do not affect the
# strict inequality.  A rank-r partial swap fixes fraction m^-r, and each
# nontrivial orbit is a two-cycle.
def actual_counts(card):
    n=card**16
    h=(n-n//card)//2
    b=(n-n//card**7)//2
    s=(n-n//card**8)//2
    both_active=(n-n//card-n//card**7+n//card**8)//4
    assert h+b-s == 2*both_active > 0
    return {'residue_cardinality':card,'field_dimension_no_extra_spectators':n,
            'head_difference_rank':h,'body_difference_rank':b,
            'required_independent_rank':h+b,'single_grade8_difference_rank':s,
            'rank_deficit':h+b-s,'head_and_body_active_four_cycles':both_active,
            'minimum_integer_full_field_fibres_by_rank':(h+b+s-1)//s}

residues=[actual_counts(p**w) for p,w in ((3,1),(3,2),(3,3),(5,1),(5,2))]

def prices(ktext):
    k=F(ktext)
    def hist(part):
        signed=review[part]['signed']
        return ({int(r):c for r,c in signed['productive'].items()},
                {int(r):c for r,c in signed['paid'].items()})
    def margin(part):
        t,p=hist(part)
        return tariff.moment(tariff.signed_profile(t,p),k)
    h1,h7,h8=(tariff.price(i,k) for i in (1,7,8))
    ideal=tariff.scale(tariff.sub(tariff.add(h1,h7),h8),111)
    with_extra=tariff.scale(tariff.sub(h7,h8),111)
    return {'kappa':ktext,
            'binary_complete_baseline_margin':tariff.decimal_interval(margin('binary'),36),
            'rational_complete_baseline_margin':tariff.decimal_interval(margin('rational'),36),
            'impossible_ideal_credit':tariff.decimal_interval(ideal,36),
            'optimistic_at_least_one_extra_grade1_credit':tariff.decimal_interval(with_extra,36),
            'binary_margin_after_optimistic_extra':tariff.decimal_interval(tariff.add(margin('binary'),with_extra),36)}

T,P=({int(r):c for r,c in review['binary']['signed'][part].items()} for part in ('productive','paid'))
optimistic_paid=dict(P)
optimistic_paid[7]-=111
optimistic_paid[8]=optimistic_paid.get(8,0)+111
out={
 'status':'SCOPED_ONE_OWNER_NEUTRAL_PACKET_SUPPORT_OBSTRUCTION',
 'pins':{'pr7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
         'pr7852':'41beda1d6435760dc99e38bd7e65f36798aad212',
         'main':'e54523517d0f03e58352e647c403a5af3e525a57','input_sha256':PINS},
 'port':0,'head_frame':hc,'body_frame':bc,'head_dimension':1,'body_dimension':7,
 'port_complements_checked_over_rationals':111,
 'projector_checks':'over Z: PH^2=PH, PB^2=PB, PH*PB=0, PH+PB=I, S(PH)S(PB)=S(I), all involutions; same identities with retained diag(I,C) reversal',
 'intervening_window':{'idle_clock':131,'first_reader_clock':132,'later_destination_clock':150,
    'query_clock':196,'query_pre_source_as_pre131_roles':[0],
    'role_containing_pre131_role28_at_pre196':[27],
    'role27_as_pre131_roles':[19,20,28]},
 'physical_count_proof':{
    'ring':'R=Z/(p^w), m=|R|=p^w>1; two chunks; binary-valued functions on addresses',
    'n':'m^16 times the cardinality of untouched spectators',
    'rank_I_plus_head':'n*(1-m^-1)/2',
    'rank_I_plus_body':'n*(1-m^-7)/2',
    'rank_I_plus_grade8_swap':'n*(1-m^-8)/2',
    'deficit':'n*(1-m^-1)*(1-m^-7)/2 > 0',
    'four_cycle_interpretation':'on each head-and-body-active orbit the two independent effects have rank 4; a single grade-8 effect has rank 2',
    'tagged_fibre_necessary_condition':'for t identical complete fibres, t >= ceil((2-m^-1-m^-7)/(1-m^-8)) = 2; rank only, not a physical tagged implementation or price',
    'arbitrary_linear_pack_and_unpack_allowed':True,
    'residue_examples':residues},
 'finite_control':{'residue_cardinality':3,'head_axes':1,'body_axes':1,'address_count':nh,
    'matrix_ranks':{'head':rank_h,'body':rank_b,'one_combined':rank_s,'complete_38_role_difference':rank(diffs)},
    'unchanged_caller_diagonal_rows_checked':38*nh,'events':len(events),
    'active_difference_roles_after_clock':active_at,
    'scope':'other body stages specialized to identity; 1-axis body control, not full native replay'},
 'optimistic_signed_schedule_111_separate_ports':{
    'complete_baseline_productive':T,'complete_baseline_paid':P,
    'ideal_paid_delta':{'1':-111,'7':-111,'8':111},
    'at_least_one_extra_grade1_each_optimistic_paid_delta':{'7':-111,'8':111},
    'optimistic_complete_paid':optimistic_paid,'productive_delta':{},
    'charges_ordinary_or_extra_clears':'zero, optimistic lower bound only',
    'baseline_clock196_query_scratch_clears':111,
    'prices':[prices(x) for x in ('0.003879928046148','0.003879928046155','0.003889928046155')]},
 'limitations':[
   'one grade-8 partial interchange acts on a single owner field with the same complete address domain as the source fields',
   'embedding source fields into a strictly larger zero-initialized or tagged address domain is outside this bound and requires a separate volume, routing and clear bill',
   'the candidate with this job replaced by identity has the identical full transfer as the literal word with idle 131 deleted and query 196 changed to ADD',
   'all other caller operations and endpoints fixed; neutral wrappers may use arbitrary linear address-dependent pack/unpack and zero or dirty scratch with correctly modeled clears',
   'changed surrounding paid events or non-neutral wrapper, general rank-8 operation beyond a partial interchange, extra productive targets, and joint multi-port service are not excluded',
   'the additional-grade1-per-port bill is an optimistic necessary-price relaxation, not a constructed schedule or upper bound on all possible edits',
   'no independent replay of the full native supplier, compiler, tape, or outer theorem'],
}
print(json.dumps(out,indent=2,sort_keys=True))
