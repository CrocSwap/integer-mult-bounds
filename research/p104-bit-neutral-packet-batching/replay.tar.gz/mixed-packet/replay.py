#!/usr/bin/env python3
"""Verify the portable stream-07 input pins, receipts and orbit control.

Read-only; standard library; no network.  Does not rerun the native supplier.
"""
from hashlib import sha1, sha256
from pathlib import Path
import json
import subprocess
import sys

H=Path(__file__).resolve().parent
entries={}
for line in (H/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    path=(H/name).resolve()
    assert path.is_relative_to(H) and path.is_file() and name not in entries,name
    assert sha256(path.read_bytes()).hexdigest()==expected,name
    entries[name]=expected

sources=json.loads((H/'SOURCES.json').read_text())
for source in sources['inputs']+sources['physical_contract_sources']:
    if 'path' not in source: continue
    name=source['path']
    data=(H/name).read_bytes()
    assert name in entries and sha256(data).hexdigest()==source['sha256'],name
    if 'git_blob' in source:
        got=sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert got==source['git_blob'],name

def run(script,receipt):
    got=subprocess.check_output([sys.executable,'-I','-B',str(H/script)],cwd=H)
    assert got==(H/receipt).read_bytes(),script

run('check.py','RESULT.json')
print('physical projector, reader chronology, finite 798-event control and directed invoice: PASS')
run('control.py','CONTROL.json')
print('seven-body-axis four-orbit and deletion mutation controls: PASS')
print('source hashes, available Git blob pins and package checksums: PASS')
