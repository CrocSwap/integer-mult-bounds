# Conditional k=76 split-caller price screen

For the explicitly restricted signed-Gram/event-partition model in
[PROOF.md](PROOF.md), every `k=76, Q=T=1` type-B case with at least one
split non-hub nonleaf has the corrected invoice bound

`(104/76) repo <= 128.879425704223 < 128.891`.

The rational ceiling and the assumptions matter: two all-stage singleton
hubs; exactly 76 leaves and 73 other nonleaves; a global, bijective
assignment of events to pieces that partition each role mask; nondegenerate
host diagonals; and the signed-frame and event-kernel contracts. The
common-piece rank/fragmentation proof is a paper argument, not a Lean proof.
The result does not establish a general caller ceiling, a legal caller, a
new multiplication bound, or any kappa gain.

[COMPARISON.md](COMPARISON.md) distinguishes this narrower **real-invoice**
result from #7869's modeled `k=76` LP certificate, including the latter's
own rows, bridge limitations, and exact certified endpoint.

## Offline replay

From this directory on Python 3.12 or later, with the standard library only:

```sh
python3 -I -B replay.py
```

It checks the archived source bytes against [SOURCE-MANIFEST.json](SOURCE-MANIFEST.json),
recomputes every case and compares with [expected/RESULT.json](expected/RESULT.json),
then runs the pinned #7869 `k=76` verifier with 152 independent integer-root
checks of its power envelopes. Network access, a Git checkout and Lean are
not used. It does not run the entire #7852, #7858, #7861 or #7869 packages;
the archived Lean snippets are inert references, and their transitive Lean
imports and build environment are deliberately not included.

`sha256sum -c SHA256SUMS` separately checks the packet bytes. The archive's
source paths are relative; its immutable external commit links are provenance
references and are not needed at replay time. Hash equality and finite checks
are separate from validating the mathematical hypotheses or accepting the
paper proof. See [NOTICE.md](NOTICE.md) and each upstream source notice.
