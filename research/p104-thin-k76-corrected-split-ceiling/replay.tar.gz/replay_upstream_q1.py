#!/usr/bin/env python3
"""Replay the pinned #7869 k=76 certificate and audit its power envelopes.

The imported verifier and JSON are unchanged Apache-2.0 upstream snapshots.
The additional integer-root checks certify the verifier's rounded powers;
this is not a proof of the LP row hypotheses or of a legal-word bridge.
"""
from decimal import Decimal
from fractions import Fraction
from hashlib import sha1
import importlib.util
from pathlib import Path

HERE = Path(__file__).resolve().parent
CERT = HERE / 'source' / 'p7869' / 'certs'
EXPECTED_BLOBS = {'verify_q1.py': 'a3500cbbecc38af21f9f07b9bf3425a7e1071b58',
                  'q1_k76.json': 'c80dd74e4be0ebeae7b305ce3727d4055e034360'}


def git_blob(path):
    data = path.read_bytes()
    return sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def root_floor(base, scale):
    # floor(scale * base^(99/100)), checked by integers alone.
    target = base**99 * scale**100
    lo, hi = 0, (base+1)*scale
    while lo+1 < hi:
        mid = (lo+hi)//2
        if mid**100 <= target:
            lo = mid
        else:
            hi = mid
    assert lo**100 <= target < (lo+1)**100
    return lo, lo if lo**100 == target else lo+1


def main():
    for name, digest in EXPECTED_BLOBS.items():
        assert git_blob(CERT / name) == digest, name
    spec = importlib.util.spec_from_file_location('p7869_verify_q1', CERT/'verify_q1.py')
    upstream = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(upstream)
    scale = 1 << 110
    dscale = Decimal(scale)
    for d in range(1,77):
        low, high = root_floor(8*d+1, scale)
        used = int((upstream.pwd(8*d+1)*dscale).to_integral_value(rounding='ROUND_CEILING'))+1
        assert used >= high, ('target upper', d, used, high)
        low, high = root_floor(8*d, scale)
        used = int((upstream.pwd(8*d)*dscale).to_integral_value(rounding='ROUND_FLOOR'))-1
        assert used <= low, ('piece lower', d, used, low)
    value, eps, arg, stored_float, mode = upstream.verify(76)
    expected = Fraction(49715125551675529173873011821938159,
                        385365782469381738054997774434304)
    assert value == expected
    assert eps == 4308439346453729227460408073 and arg == 76 and mode == 'leafshift'
    assert value > Fraction(128891,1000)
    print('PASS: #7869 k=76 source blobs and 152 exact integer-root checks')
    print('Certified modeled upper:', value)
    print('Certified modeled upper, decimal:', Decimal(value.numerator)/Decimal(value.denominator))
    print('Mode:', mode, 'stored float:', stored_float)
    print('Scope: LP conditional on its stated paper/model rows; not a legal caller witness.')


if __name__ == '__main__':
    main()
