# Recorded local verification

On Python 3.12.3, a clean copy of this directory was run with an empty
environment except `PATH` and `LANG`, using `python3 -I -B replay.py`.
It passed the source-identity checks, split-caller finite computations,
expected-data comparison, pinned #7869 verifier and 152 independent power
root checks. The replay used only local packet files and the Python standard
library. No network access or Lean build was used.

Two mutation controls were run in the copied directory and restored: adding
a byte to the #7869 `q1_k76.json` was rejected by `check_sources.py`; changing
the expected combined ceiling was rejected by `verify.py`. The packet itself
was not changed by these controls. `sha256sum -c SHA256SUMS` passed for every
listed file.

The finite replay is distinct from independent mathematical review, a
machine-checked common-piece proof, a legal word, and maintainer acceptance.
Only the #7869 `k=76` certificate was replayed from that upstream package;
its other certificates and full registered-package verifier were not run.
