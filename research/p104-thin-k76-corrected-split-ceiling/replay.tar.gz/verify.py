#!/usr/bin/env python3
"""Exact arithmetic for a scoped k=76 common-piece/price screen.

The rank implication and fragmentation argument are mathematical hypotheses
and proofs, not re-proved by this program. Root intervals, finite monotonicity,
fragmentation cases, an independent relaxed knapsack, and prices are checked.
"""
from collections import Counter
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction as F
from hashlib import sha1
from math import comb
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'source' / 'p7852'
SCALE = 10**14
K = 76
NORM = F(104, K)
BAR = F(128891, 1000)
ROOTS = {}


def check_source():
    expected = {
        'CallerSGram.lean': '6c03a7f3b3c50fe4340cd105378409ca39abc474',
        'CallerRC2.lean': '321ec331931fecddd844f3b12fe0caf27178269c',
        'CallerEv.lean': 'ad5aba9f52bd1d4b60c3023a8325ff68310c5561',
        'SchemaCostB.lean': 'b6a1c4b03a81a99e59c433d110871f605bef9694',
    }
    for name, expected_hash in expected.items():
        data = (SOURCE / name).read_bytes()
        actual = sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual == expected_hash, (name, actual, expected_hash)
    return expected


def root(b):
    if b not in ROOTS:
        target = b**99 * SCALE**100
        lo, hi = 0, (b + 1) * SCALE
        while lo + 1 < hi:
            mid = (lo + hi) // 2
            if mid**100 <= target:
                lo = mid
            else:
                hi = mid
        assert lo**100 <= target < (lo + 1)**100
        ROOTS[b] = (lo, lo if lo**100 == target else lo + 1)
    return ROOTS[b]


def expr(*parts):
    out = Counter()
    for part in parts:
        out.update(part)
    return {b: c for b, c in out.items() if c}


def mul(a, c):
    return {b: x*c for b, x in a.items() if x*c}


def bound_int(a, upper):
    z = 0
    for b, c in a.items():
        lo, hi = root(b)
        z += c * (hi if ((c > 0) == upper) else lo)
    return z


def price_upper(a, loss_lower=0):
    return NORM * F(bound_int(a, True) - loss_lower, SCALE)


def price_lower(a):
    return NORM * F(bound_int(a, False), SCALE)


def decimal_out(x, rounding):
    with localcontext() as ctx:
        ctx.prec = 50
        ctx.rounding = rounding
        return str((Decimal(x.numerator) / Decimal(x.denominator)).quantize(Decimal('0.000000000001')))


def v(d): return expr({8*d + 1: 1}, {8*d: -1})
def loss(d): return expr(v(2), mul(v(d), -1))
def delta(d): return {} if d == 0 else expr({1: 1}, mul(v(d), -1))
def split(d): return expr({8: 1}, {8*(d-1): 1}, {8*d: -1})

BASE = {609: 2, 17: 73, 9: 76, 8: -228, 16: -73, 1: -1}


def cell_min_edges(size):
    return comb(size, 2) - size*size//4


def balanced_edges(size, cells):
    # Optimal when sizes differ by at most 1: the edge function has
    # nondecreasing successive differences, including at size 0 and 1.
    q, r = divmod(size, cells)
    return (cells-r)*cell_min_edges(q) + r*cell_min_edges(q+1)


def fragment_rank_row(split_degree, nlong, loss_lo):
    exceptions = comb(split_degree, 3) if split_degree >= 3 else 0
    pairs = 73 - nlong
    b = [3] * nlong
    constraints = []
    for q in range(1, nlong):
        cells = min(K, 2**min(7, nlong-q))
        allowed = max(size for size in range(K+1)
                      if balanced_edges(size, cells) <= pairs + exceptions)
        need = K - allowed
        degree_min = (need + q - 1)//q
        b[q-1] = max(b[q-1], degree_min)
        constraints.append({'q_smallest': q, 'cells': cells,
                            'max_uncovered_stages': allowed, 'sum_degrees_at_least': need})
    for i in range(1, nlong):
        b[i] = max(b[i], b[i-1])
    # Degree-2 split is outside the long roles; for degree 3/4 allow removal
    # of both it and the one correction-bearing role. Removing the largest
    # lower bounds is the most favorable relaxation.
    remove = 1 if split_degree == 2 else 2
    rank_loss = sum(loss_lo[d] for d in b[:nlong-remove])
    assert all(3 <= d <= K for d in b)
    # Grant actual odd correction to one unsplit role: delta(D)-loss(D)=1-v(2).
    free_odd = expr({1: 1}, mul(v(2), -1))
    real_expr = expr(BASE, mul(split(split_degree), -1),
                     mul(loss(split_degree), -1), free_odd)
    ceiling = price_upper(real_expr, rank_loss)
    return {'nlong': nlong, 'pair_roles': pairs, 'exception_triples': exceptions,
            'sorted_degree_lower_bounds': b, 'paid_loss_lower_scaled': rank_loss,
            'upper_exact': str(ceiling),
            'upper_decimal': decimal_out(ceiling, ROUND_CEILING),
            'constraints': constraints}


def make_dp(loss_lo):
    # For x units still needed, use unlimited long roles and require at least
    # c of them. Repetition/ignoring the 71-role cap only weakens the bound.
    # A degree-76 role has negative surplus and larger loss than degree 3, so
    # replacing it by degree 3 preserves cardinality and can only help.
    target = 33097
    f = lambda d: comb(d, 2) * (76-d)
    options = [(f(d)-74, loss_lo[d], d) for d in range(3, 76) if f(d) > 74]
    dp = [[0]*(target+1) for _ in range(4)]
    prev = [[None]*(target+1) for _ in range(4)]
    for x in range(1, target+1):
        best = min((cost + dp[0][max(0, x-a)], d, a) for a, cost, d in options)
        dp[0][x], prev[0][x] = best[0], best[1:]
    for c in range(1, 4):
        for x in range(target+1):
            best = min((cost + dp[c-1][max(0, x-a)], d, a) for a, cost, d in options)
            dp[c][x], prev[c][x] = best[0], best[1:]
    data = []
    for d in (2, 3, 4):
        exceptions = comb(d, 3) if d >= 3 else 0
        requirement = comb(76, 3) - exceptions - f(d) - 31875 - 71*74
        count = 3 if d == 2 else 2
        x, c, chosen = requirement, count, []
        while x or c:
            degree, surplus = prev[c][x]
            chosen.append(degree)
            x, c = max(0, x-surplus), max(0, c-1)
        free_odd = expr({1: 1}, mul(v(2), -1))
        real_expr = expr(BASE, mul(split(d), -1), mul(loss(d), -1), free_odd)
        ceiling = price_upper(real_expr, dp[count][requirement])
        data.append({'split_degree': d, 'required_surplus': requirement,
                     'minimum_long_roles_after_designating_odd': count,
                     'lower_cost_scaled': dp[count][requirement],
                     'relaxation_witness_degrees': chosen,
                     'upper_exact': str(ceiling),
                     'upper_decimal': decimal_out(ceiling, ROUND_CEILING)})
    return data


def main():
    pins = check_source()
    # Purely finite checks for the relevant discrete range.
    loss_lo = {2: 0}
    for d in range(3, 77):
        loss_lo[d] = bound_int(loss(d), False)
        assert loss_lo[d] > 0
        assert bound_int(expr(v(d-1), mul(v(d), -1)), False) > 0
        assert bound_int(expr(split(d), mul(split(d-1), -1)), False) > 0
    for d in range(1, 76):
        assert bound_int(expr(delta(d+1), mul(delta(d), -1)), False) > 0
    assert all(loss_lo[d] < loss_lo[d+1] for d in range(3, 76))
    f = lambda d: comb(d, 2)*(76-d)
    assert max(f(d) for d in range(2,77)) == f(51) == 31875
    assert f(2) == 74
    increments = [cell_min_edges(i+1)-cell_min_edges(i) for i in range(76)]
    assert increments == sorted(increments)
    assert [balanced_edges(76, 2**L) for L in range(4)] == [1406, 684, 324, 144]
    for d in (2,3,4):
        ex = comb(d,3) if d >= 3 else 0
        for L in range(4):
            assert balanced_edges(76, 2**L) > 73-L+ex
    rows = {str(d): [fragment_rank_row(d,L,loss_lo) for L in range(4,74)]
            for d in (2,3,4)}
    winners = {d: max(vs, key=lambda row: F(row['upper_exact']))
               for d, vs in rows.items()}
    double = price_upper(expr(BASE, mul(split(2), -2), delta(76)))
    d5plus = price_upper(expr(BASE, mul(split(5), -1), mul(loss(5), -1), delta(76)))
    dp = make_dp(loss_lo)
    # Use the best of two separately valid relaxation ceilings, per degree.
    best_singles = {str(d): min(F(winners[str(d)]['upper_exact']), F(dp[d-2]['upper_exact']))
                    for d in (2,3,4)}
    ceiling = max(list(best_singles.values()) + [double,d5plus])
    assert all(x < BAR for x in list(best_singles.values()) + [double,d5plus])
    assert best_singles['2'] == F(winners['2']['upper_exact'])
    assert winners['2']['nlong'] == 9
    control_exprs = {'one_split_d2_query': expr(BASE, mul(split(2), -1)),
                     'one_split_d2_singleton_odd': expr(BASE, mul(split(2), -1), delta(1))}
    assert all(price_lower(a) > BAR for a in control_exprs.values())
    # The triple-capacity DP's degree-2 optimizer cannot be placed: removing
    # its 3- and 7-stage roles leaves >=66 stages in at most four cells, and
    # only 69 degree-2 roles. It needs at least 240 internal pair edges.
    assert dp[0]['relaxation_witness_degrees'] == [3,7,49]
    assert balanced_edges(66,4) == 240 and 240 > 69
    result = {
        'sources_git_blob_sha1': pins,
        'pinned_references': {'7852':'41beda1d6435760dc99e38bd7e65f36798aad212',
                              '7861':'5cbe00f354aae5923205ec68370ddaa5296c2ea7',
                              '7858':'729a0de5c2c1d225085c3b1a7d8b37eb96713138'},
        'power_exponent': '99/100', 'root_scale': SCALE,
        'rank_fragment_winners': winners,
        'rank_fragment_all_rows': {
            d: [{key: row[key] for key in ('nlong', 'pair_roles',
                'sorted_degree_lower_bounds', 'paid_loss_lower_scaled',
                'upper_exact', 'upper_decimal')} for row in vs]
            for d, vs in rows.items()},
        'triple_capacity_knapsack': dp,
        'combined_case_upper': {**{f'one_split_degree_{d}': decimal_out(z, ROUND_CEILING)
                                     for d,z in best_singles.items()},
                                'multiple_split_roles': decimal_out(double, ROUND_CEILING),
                                'one_split_degree_at_least_5': decimal_out(d5plus, ROUND_CEILING)},
        'combined_ceiling_exact': str(ceiling),
        'combined_ceiling_decimal': decimal_out(ceiling, ROUND_CEILING),
        'controls': {k: {'lower': decimal_out(price_lower(a), ROUND_FLOOR),
                         'upper': decimal_out(price_upper(a), ROUND_CEILING)}
                     for k,a in control_exprs.items()},
        'degree_2_dp_relaxation_realizability_obstruction': {
            'long_degrees': [3,7,49,51], 'pair_roles': 69,
            'uncovered_stages_at_least': 66, 'signature_cells_at_most': 4,
            'internal_pair_edges_required': 240},
        'root_certificates': {str(b): {'floor': lo, 'ceiling': hi} for b,(lo,hi) in sorted(ROOTS.items())},
        'scope': 'Conditional partition-matched signed-Gram template, e=0 and at least one nonhub nonleaf split. Paper rank argument; no general caller ceiling, no legal word constructed and no kappa gain.'
    }
    expected_path = HERE / 'expected' / 'RESULT.json'
    assert not sys.argv[1:], 'usage: verify.py'
    assert result == json.loads(expected_path.read_text()), 'expected result mismatch'
    print('PASS source blobs, exact power intervals, fragmentation, knapsack and controls')
    print('Degree-specific and aggregate upper bounds:')
    for name, val in result['combined_case_upper'].items(): print(f'  {name}: {val}')
    print('  all eligible split cases:', result['combined_ceiling_decimal'])
    print('Worst degree-2 fragmentation row:', winners['2']['nlong'], winners['2']['sorted_degree_lower_bounds'])
    print('Expected result: matched')


if __name__ == '__main__':
    main()
