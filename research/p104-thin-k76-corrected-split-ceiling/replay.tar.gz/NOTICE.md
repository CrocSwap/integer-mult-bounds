This package is distributed under Apache License 2.0; see LICENSE. It was
prepared with substantial OpenAI Codex assistance. The new common-piece
triple cut, fragmentation argument, price calculation, and finite replay
extend the pinned predecessor work; they are not represented as the authors'
proofs or as Lean theorems.

The original P104 signed-frame, event and invoice definitions and the #7869
LP certificate are credited to DreamingOfClouds with Claude Opus 5.5 via
Claude Code. The prior #7861 common-kernel/shared-hub rank work and #7858
odd-idle mask-price package were prepared by Clear1nsight with substantial
OpenAI Codex assistance and credit DreamingOfClouds and Rohan Arun for
underlying source material and caller data. See the unmodified notices under
source/ for the relevant upstream attributions and licenses.

Only the selected files listed in SOURCE-MANIFEST.json are redistributed;
they are unmodified source snapshots. The packet's new verification scripts,
expected data, comparison and proof are the present contribution.
