#!/usr/bin/env python3
"""Check byte and Git-blob identities of the pinned source subset offline."""
from hashlib import sha1, sha256
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE/'SOURCE-MANIFEST.json').read_text())
assert manifest['version'] == 1
seen = set()
for entry in manifest['sources']:
    local = Path(entry['local_path'])
    assert not local.is_absolute() and '..' not in local.parts
    assert local.parts[0] == 'source' and entry['modified'] is False
    assert entry['license'] == 'Apache-2.0'
    assert local.as_posix() not in seen
    seen.add(local.as_posix())
    data = (HERE/local).read_bytes()
    assert sha256(data).hexdigest() == entry['sha256'], local
    assert sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest() == entry['git_blob_sha1'], local
actual = {p.relative_to(HERE).as_posix() for p in (HERE/'source').rglob('*') if p.is_file()}
assert seen == actual, ('unlisted or missing source files', seen ^ actual)
print(f'PASS: {len(seen)} relative source paths, SHA-256 and Git-blob identities')
