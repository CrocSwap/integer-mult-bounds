#!/usr/bin/env python3
"""Run the offline source, new-result and pinned #7869 certificate checks."""
from pathlib import Path
import subprocess
import sys

here = Path(__file__).resolve().parent
for script in ('check_sources.py', 'verify.py', 'replay_upstream_q1.py'):
    print('Running:', script, flush=True)
    subprocess.run([sys.executable, '-I', '-B', str(here/script)], cwd=here, check=True)
print('PASS: complete offline replay')
