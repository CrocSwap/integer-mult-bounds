# All-owner closure for fixed original packet pulses

For the pinned [#7830 native word](https://github.com/CrocSwap/integer-mult-bounds/tree/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15), a maximum-closure certificate gives **an exact zero upper bound** on the 36-call signed gain from the fixed-original-support, pure-zero packet-deletion class below. It considers every subset of the 457 optional original helper owners, in the forward and adjoint orientations separately, at `κ = 0.003879928046156` and `κ = 0.003879929046155`. The empty selection attains zero, so the upper bound is sharp. No stronger κ result is claimed.

## Precisely what is specialized

The original word has 680 original public owners: 222 main directions and 458 helpers. Choose any subset `S` of helpers 222–679 other than protected helper 411. In either orientation, set all input coordinates in `S` to zero and discard those same public output coordinates. This is the coordinate restriction of the original linear map; the 222 main directions and owner 411 remain. It is **not** an assertion that a different physical helper interface, an arbitrary quotient, or a changed payload is equivalent.

For each original paid packet `p` in the chosen orientation, let `P(p)` be the exact GF(2) support of its original 680-input pulse. With the original graph and other packet payloads fixed, the specialized pulse is zero if and only if `P(p) ⊆ S`. Removing any collection of such zero packets leaves every remaining packet value and every retained endpoint unchanged. Original bridge packet 3553 is kept.

The price screen grants **every** such zero-packet deletion for free, charges the productive target for every member of `S` in all 36 caller invocations, and grants no additional paid routes. Free deletion and free local repair make this an upper bound for any subset of the allowed zero deletions. It does not bound aliases or routes created after a rewrite, a mixture of forward-zero and adjoint-zero grants, or a pruning cascade: when a packet is deleted, its newly dualized pulse family must be recomputed. The full retained paid and productive caller bins are in [CLOSURE.json](CLOSURE.json).

## Flow proof and independent check

For each orientation, make one positive packet node for each support contained in the 457 optional owners and an owner node for every optional helper. A packet node implies all owners in its support. Its weight is the 36-call paid saving; the owner's negative weight is the 36-call productive debit. These implications give a standard maximum-weight closure/min-cut instance.

Some packets have support exactly `{h}` and the same grade as helper `h`. Their grant occurs exactly when `h` is selected, so one packet credit and that helper debit cancel **symbolically for every selection**. Removing those identical terms before interval arithmetic prevents equal-price cancellation from producing a spurious rounding gain. There are 17 such pairs in the forward graph and 22 in the adjoint graph.

For each trial the remaining packet rewards are rounded upward and owner debits downward using the retained directed interval arithmetic. The certificate routes every packet reward, on edges to owners in that packet's support, into the available owner-debit capacities. An independent verifier checks each flow edge, every packet's saturated reward, every owner's capacity and flow conservation. Thus every possible selected packet reward is covered by selected owner debits, even under these optimistic rounding choices. The source-saturating flow has the same value as the empty-selection cut; the directed upper bound is **exactly zero**, not a near-zero numerical estimate.

| Orientation | All original packets | Optional-support packets | Symbolically canceled | Residual packet nodes | Directed maximum signed change |
| --- | ---: | ---: | ---: | ---: | ---: |
| Forward | 2,874 | 430 | 17 | 413 | `0` |
| Adjoint | 2,874 | 113 | 22 | 91 | `0` |

The proof is separate for each orientation. It does not add the two orientation bounds: the same original packet may occur in both and a first deletion can change the opposite pulse family.

An independent implementation scans the original literal tape in its actual forward and reversed instruction orders to reconstruct the 2,874 packet pulse supports. It does not use the generator's extracted packet DAG or its flow algorithm. It checks the complete closure families, all flow certificates, a deliberately corrupted flow, and all caller bins. Full signed margins under the stated optimistic class are at most the following directed upper endpoints, which are the unchanged #7830 margins:

| κ | Full 36-call signed margin, upper bound |
| --- | --- |
| `0.003879928046156` | `-0.000000000767001502431130261463` |
| `0.003879929046155` | `-0.000385127316613866441054139472` |

The tariff calculation does not independently establish the inherited physical, finite compiler, cover, or stock premises.

## Concrete projections and opposite-direction replay

Three matching-pair selections are compiled as literal control words: all 17 forward-neutral owners, all 22 adjoint-neutral owners, and their 30-owner union. After each first-direction specialization the code recalculates the opposite direction and alternates zero/dead pruning to a fixed point. These controls retain respectively 663, 658 and 650 public owners, remove the same number of paid packets as owners, and have exactly zero full signed histogram change from #7830. Their complete original-owner and packet rosters, rounds and literal hashes are in [PRINCIPAL.json](PRINCIPAL.json).

Each word passes all forward and adjoint literal output rows, rational chart legs and main contacts, complete private retirement, full 36-call repricing, the stated ordinary allowances, and held-out live-ADD and CLEAR controls. In original labels, owner 411 and its pure packet/field 3553 are retained; compiled field addresses are recorded in the receipt.

The 650-owner word gives a concrete next test beyond this zero-pulse theorem. Adding owner 331 removes original grade-2 packet 1332. At that point one grade-1 adjoint pair `950/945` and one grade-1 forward pair `946/945` look separately available. If `950 → 945` is repaired first, terminal 332 is its first repaired reader and the freshly computed forward `945 XOR 946` becomes original owner support `{332,333}`. If `946 → 945` is repaired first, packet 948 is its first repaired reader and the freshly computed adjoint `945 XOR 950` has 65 surviving original directions, including protected mains. No extra zero/dead packet is found after either first edit. Each first-edit word is compiled and replayed in both directions; the full signed change is `36(H1 + H2 − H4)`, approximately `−35.420917118690730571871262720546` at the first trial. See [INTERFERENCE.json](INTERFERENCE.json). This checks these two replacement orders; it does not exclude another donor basis, surrendering further owners, or a funded changed-route construction.

## Relation to prior cuts

[#7912 at `83ece5a`](https://github.com/CrocSwap/integer-mult-bounds/tree/83ece5a62d3addbee45bad9594ef4809851b833b/research/p104-bit-adjoint-multidonor-cut) uses the 649/3266 specialization and a zero-net control. Owner 649 is among the adjoint-neutral selections here. [#7935 at `86203c1`](https://github.com/CrocSwap/integer-mult-bounds/tree/86203c17e5bbecd4085067db1479e5858c896524/research/p104-bit679-second-owner-cut) separately studies two second owners and bounded cocharted omission repairs after that control; its pair rewrites are outside the present fixed-pulse closure. [#7953 at `13a47f6`](https://github.com/CrocSwap/integer-mult-bounds/tree/13a47f662901e894fee93365c7efec89f4f21fae/research/p104-bit-sink-matching) instead proves a direct chart-1 sink matching bound with fixed exterior stock. These are distinct restricted models, not a combined no-go theorem for changed stock or changed interfaces.

A useful next model must charge the full target debit and include changed pulse supports, displaced readers, and fresh opposite-orientation sensitivities. The `{332,333}` residual after the first 331 rewrite supplies a specific starting witness; any additional owner surrender must be priced and all affected readers rebound. Repeating the original-pulse closure alone cannot decide it.

## Reproduction

With Python 3.12 and the standard library:

```sh
python3 -I -B verify.py
```

The verifier checks the manifest, independently derives the pulse census from the raw original tape, checks the generated integer flows and an intentionally broken-flow control, verifies all original rational paid and productive legs, recomputes the full caller invoice, and reruns the closure and all five literal control words in a relocated temporary directory. To additionally check exact #7912 archive bytes and copied members:

```sh
python3 -I -B verify.py --upstream-archive /path/to/7912-replay.tar.gz
```

[SOURCES.json](SOURCES.json), [LICENSE](LICENSE), [NOTICE](NOTICE) and the retained inputs preserve source and attribution information. No independent human review is asserted.
