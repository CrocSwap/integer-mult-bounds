#!/usr/bin/env python3
"""Check owner-331's two opposite-orientation one-bit aliases in both orders."""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import gzip,json,sys
from hashlib import sha256
H=Path(__file__).resolve().parent;sys.path[:0]=[str(H),str(H/'inputs')]
import project as p,bit_native as bit,price,literal

F={237,250,264,351,355,383,387,391,432,672,673,674,675,676,677,678,679}
A={237,250,264,274,351,355,383,387,391,432,648,649,650,662,664,665,666,667,668,669,670,671}
S=F|A|{331};x=p.project(S,max_rounds=100);er=set(p.labels(x['erased']));mask=sum(1<<h for h in S|er)
ai={j:c for j,c in p.initial.items() if j not in S};af={j:c for j,c in p.final.items() if j not in S}
am={k:p.moves[k] for k in x['alive']};ar={k:p.orig[k]&~mask for k in am};ar.update({~j:p.orig[~j]&~mask for j in af})
def need(b,m):
 if not b:raise ValueError(m)
def ids(v):return list(bit.indices(v))
def calc(i,f,m,r,adj):
 order=bit.schedule(i,f,m,r);v={j:1<<j for j in i}
 for k in order:v[k]=bit.combine(r[k],v)
 for j in f:
  t=(1<<j)^((1<<(j+111)) if adj and j<111 else (1<<(j-111)) if not adj and 111<=j<222 else 0)
  need(bit.combine(r[~j],v)==t,'wrong protected endpoint '+str(j))
 return order,v

def rewrite(i,f,m,r,alias,donor,adj):
 _,v=calc(i,f,m,r,adj);need(alias in m and donor in m,'alias and donor retained')
 need(m[alias][1]==m[donor][1] and v[alias]==v[donor],'pair must be cocharted and equal')
 readers=[q for q,row in r.items() if row>>alias&1]
 nm={k:t for k,t in m.items() if k!=alias}
 nr={k:(row ^ ((1<<alias)|(1<<donor)) if row>>alias&1 else row) for k,row in r.items() if k!=alias}
 order,_=calc(i,f,nm,nr,adj);pos={k:n for n,k in enumerate(order)}
 rlist=sorted(({'receiver':q if q>=0 else ~q,'kind':'packet' if q>=0 else 'terminal',
                'new_packet_index':pos[q] if q>=0 else None} for q in readers if q!=alias),
               key=lambda z:(z['new_packet_index'] if z['new_packet_index'] is not None else 10**9,z['receiver']))
 return nm,nr,rlist

def clean_fix(m,r,i,f,adj):
 omitted=set();rounds=[]
 while True:
  _,v=calc(i,f,m,r,adj)
  zero={k for k in m if not v[k] and k!=3553}
  if zero:
   mask=sum(1<<k for k in zero);m={k:q for k,q in m.items() if k not in zero};r={k:q&~mask for k,q in r.items() if k not in zero};omitted|=zero
   rounds.append({'orientation':'adjoint' if adj else 'forward','zero_packets':sorted(zero)})
  dm,dr=p.physical.dual(680,m,r);i,f=f,i;adj=not adj;m,r=dm,dr
  _,v=calc(i,f,m,r,adj)
  z2={k for k in m if not v[k] and k!=3553}
  if not zero and not z2:break
  need(len(rounds)<100,'fixed point terminates')
 # Orient to adjoint for consistent result.
 if not adj:m,r=p.physical.dual(680,m,r)
 return m,r,omitted,rounds

basecalc=Counter(p.grades[k] for k in er);basecalc.subtract(p.hg[h] for h in S)
assert {k:v for k,v in basecalc.items() if v}=={2:1,4:-1}
fm,fr=p.physical.dual(680,am,ar)
_,av=calc(ai,af,am,ar,True);_,fv=calc(af,ai,fm,fr,False)
need(av[945]==av[950] and fv[945]==fv[946],'both tempting aliases exist before editing')
base_paid=literal.histogram(json.loads((H/'inputs/BIT.json').read_text())['native']['paid']);base_target=literal.histogram(json.loads((H/'inputs/BIT.json').read_text())['native']['targets'])
base_signed=Counter(base_target);base_signed.subtract(base_paid)
charts=literal.Charts(p.w['frames'])
caller=literal.pinned(H/'inputs/EFREE-CALLER.json.gz',literal.CALLER_SHA)
events=Counter(e[0] for e in caller['events'])
checks=[]
for first,alias,donor in [('adjoint',950,945),('forward',946,945)]:
 src=(ai,af,am,ar,True) if first=='adjoint' else (af,ai,fm,fr,False)
 nm,nr,readers=rewrite(*src[:4],alias,donor,src[4]);xm,xr,extra,rounds=clean_fix(nm,nr,*src[:2],src[4]);_,av=calc(ai,af,xm,xr,True)
 xf,xfr=p.physical.dual(680,xm,xr);_,fv=calc(af,ai,xf,xfr,False)
 other=(945,946) if first=='adjoint' else (945,950)
 vals=fv if first=='adjoint' else av
 residual=vals[other[0]]^vals[other[1]]
 need(residual!=0,'fresh opposite pair must no longer be equal')
 deleted=er|{alias}|extra;delta=Counter(p.grades[k] for k in deleted);delta.subtract(p.hg[h] for h in S);delta={g:36*c for g,c in delta.items() if c}
 need(delta=={1:36,2:36,4:-36},'complete price includes 331 owner debit')
 signed=Counter(base_signed);signed.update(delta)
 order=bit.schedule(af,ai,xf,xfr);bit.basis(af,xf,xfr,order)
 word=bit.emit_word(p.w,af,ai,xf,xfr,order);n=word['public'];need(n==649,'649 protected owners')
 charts.main_contacts(word['start'],word['final'])
 lforward,fl,_=literal.tape(word,charts);lbackward,bl,_=literal.tape(word,charts,adjoint=True)
 need(lforward==literal.expected_rows(n,False) and lbackward==literal.expected_rows(n,True),'literal forward and adjoint')
 need(fl['paid']==bl['paid'],'literal paid orientation')
 targets=Counter(charts.leg(word['start'][j],word['final'][j]) for j in range(222,n))
 paid,products=literal.paired_invoice(caller,fl['paid'],targets,events)
 literal_signed=Counter(products);literal_signed.subtract(paid)
 need(literal_signed==signed,'literal complete signed price agrees with graph debit')
 ordinary=literal.ordinary(word,caller,events,paid,products)
 paid_banks={event[1] for event in word['program'] if event[0]=='MOVE'}
 held=literal.held_out(word,charts,paid_banks)
 raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(raw,mtime=0)
 word_path=H/('331-'+first.upper()+'-FIRST-WORD.json.gz')
 if '--emit' in sys.argv:word_path.write_bytes(packed)
 else:need(word_path.read_bytes()==packed,'deterministic compiled first-edit word')
 checks.append({'first_edit_orientation':first,'omitted_packet':alias,'replacement_packet':donor,
                'first_repaired_reader':readers[0], 'all_repaired_readers':readers,
                'fresh_opposite_pair':list(other),'fresh_opposite_pair_xor_original_owner_support':ids(residual),
                'fresh_opposite_pair_xor_bit_count':residual.bit_count(),
                'additional_clean_pruned_packets':sorted(extra),'pruning_rounds':rounds,
                'all_649_forward_and_adjoint_output_rows_pass':True,
                'literal_forward_adjoint_chart_and_retirement_pass':True,
                'literal_word_canonical_sha256':sha256(raw).hexdigest(),
                'literal_word_gzip_sha256':sha256(packed).hexdigest(),
                'native_paid':{str(k):v for k,v in sorted(fl['paid'].items()) if v},
                'native_targets':{str(k):v for k,v in sorted(targets.items()) if v},
                'complete_paid':{str(k):v for k,v in sorted(paid.items()) if v},
                'complete_targets':{str(k):v for k,v in sorted(products.items()) if v},
                'ordinary':ordinary,'held_out_control':held,
                'signed_histogram_delta_from_7830':{str(k):v for k,v in sorted(delta.items())},
                'trials':{t:{'signed_margin':price.decimal_interval(price.moment(signed,Fraction(t)),30),
                             'signed_delta':price.decimal_interval(price.moment(delta,Fraction(t)),30)} for t in ('0.003879928046156','0.003879929046155')}})
out={'schema':'p104-owner331-opposite-pair-interference/1','scope':'After the explicit 30-owner zero-net union plus owner 331, remove one named alias with the other as donor. Recompute the exact dual and zero/dead fixed point before testing the specific other original pair; no other multi-donor rewrite or reroute is excluded.',
     'specialized_original_owners':sorted(S),'auto_pruned_before_first_pair':sorted(er),'checks':checks}
text=json.dumps(out,indent=2,sort_keys=True)+'\n'
if '--emit' in sys.argv:(H/'INTERFERENCE.json').write_text(text)
else:need((H/'INTERFERENCE.json').read_text()==text,'deterministic receipt')
for e in checks:print(e['first_edit_orientation'],'first reader',e['first_repaired_reader'],'opposite XOR support',e['fresh_opposite_pair_xor_original_owner_support'],'extra prune',e['additional_clean_pruned_packets'],'price',e['trials']['0.003879928046156']['signed_delta'])
