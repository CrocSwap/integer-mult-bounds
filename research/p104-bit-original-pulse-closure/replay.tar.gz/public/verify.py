#!/usr/bin/env python3
"""Independent raw-tape support and feasible-flow check; replay literal controls."""
from collections import Counter,defaultdict
from decimal import Decimal,localcontext
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip,json,shutil,subprocess,sys,tarfile,argparse
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H/'inputs'))
import literal,price
EXPECTED_WORD='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
UPSTREAM_SHA='87fd65f59b99f1b987d436be202447eec10ebe85857132dca0413fe74d4f6096'
def need(b,m):
 if not b:raise ValueError(m)
def manifest():
 seen=set()
 for line in (H/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1);need(not name.startswith('/') and '..' not in Path(name).parts and name not in seen,'manifest path')
  seen.add(name);need(sha256((H/name).read_bytes()).hexdigest()==expected,'manifest '+name)
 need({'closure.py','CLOSURE.json','principal.py','interference.py','verify.py','README.md','inputs/WORD.json.gz'}<=seen,'manifest members')
def hist(v):return Counter({int(k):int(x) for k,x in v.items() if x})
def clean(v):return {str(k):int(x) for k,x in sorted(v.items()) if x}
def raw_tape(word,adjoint):
 """No packet DAG, schedule, transposition, or closure-generator code used."""
 n=word['public'];fields=[1<<j for j in range(n)]+[0]*word['owned_fields'];labels={};i=0
 for clock,event in enumerate(word['program']):
  if event[0]=='MOVE':labels[clock]=n+i;i+=1
 seq=range(len(word['program'])-1,-1,-1) if adjoint else range(len(word['program']));out={}
 for clock in seq:
  op,r,*args=word['program'][clock]
  if op=='ADD':
   if adjoint:fields[args[0]]^=fields[r]
   else:fields[r]^=fields[args[0]]
  elif op in ('INIT','CLEAR'):fields[r]=0
  elif op=='SWAP':fields[r],fields[args[0]]=fields[args[0]],fields[r]
  else:
   need(op=='MOVE','opcode');out[labels[clock]]=fields[r]
 need(fields[:n]==literal.expected_rows(n,adjoint),'raw public forward/adjoint endpoint')
 need(not any(fields[n:]),'raw private fields retired')
 return out

def validate_flow(case,grade,owner_grade,opts):
 neutral={int(x['owner']):int(x['packet']) for x in case['symbolically_cancelled_pairs']}
 need(len(neutral)==len(case['symbolically_cancelled_pairs']),'unique canceled owners')
 pk={int(x['packet']):x for x in case['eligible_packets']}
 for owner,k in neutral.items():need(k in pk and pk[k]['support']==[owner] and grade[k]==owner_grade[owner],'exact symbolic cancellation')
 remaining={k:item for k,item in pk.items() if k not in set(neutral.values())}
 for trial in case['trials']:
  need(trial['scale']==str(price.GRID) and trial['copies']==36,'directed price grid and multiplicity')
  expected={str(g):[str(a),str(b)] for g,(a,b) in sorted((g,price.price(g,Fraction(trial['trial']))) for g in set(grade.values())|set(owner_grade.values()))}
  need(trial['grade_price_intervals']==expected,'directed price intervals')
  source={k:36*int(expected[str(grade[k])][1]) for k in remaining}
  budget={h:0 if h in neutral else 36*int(expected[str(owner_grade[h])][0]) for h in opts}
  incoming=Counter();outgoing=Counter();seen=set()
  for k,h,amount in trial['packet_to_required_owner_flows']:
   k,h,amount=int(k),int(h),int(amount);need((k,h) not in seen,'duplicate flow edge');seen.add((k,h))
   need(k in remaining and h in remaining[k]['support'] and amount>0,'flow on valid packet-support edge')
   outgoing[k]+=amount;incoming[h]+=amount
  need(all(outgoing[k]==a for k,a in source.items()),'all packet reward arcs saturated')
  need(all(incoming[h]<=budget[h] for h in opts),'required-owner debit capacities')
  total=sum(source.values())
  need(int(trial['source_reward_sum'])==int(trial['max_flow'])==int(trial['min_cut_empty_selection'])==total,'flow equals cut certificate')
  need(trial['directed_upper_bound_signed_delta']=='0','exact zero upper bound')

def decimal_price(histogram,t):
 with localcontext() as ctx:
  ctx.prec=90
  return sum((Decimal(v)*(Decimal(g).ln()*(Decimal(1)-Decimal(t))).exp() for g,v in histogram.items()),Decimal(0))

parser=argparse.ArgumentParser();parser.add_argument('--upstream-archive',type=Path);args=parser.parse_args()
manifest()
raw=gzip.decompress((H/'inputs/WORD.json.gz').read_bytes());word=json.loads(raw)
need(literal.canonical(word)==EXPECTED_WORD and word['public']==680,'pinned original word')
opts=sorted(set(range(222,680))-{411});need(len(opts)==457,'optional owner roster')
doc=json.loads((H/'CLOSURE.json').read_text());need(doc['optional_original_owners']==opts and doc['protected_original_bridge_packet']==3553,'protected roster')
frames=word['frames'];charts=literal.Charts(frames);charts.main_contacts(word['start'],word['final'])
grade={};p=680
for event in word['program']:
 if event[0]=='MOVE':
  _,_,a,b=event;grade[p]=abs(frames[str(a)]['dim']-frames[str(b)]['dim'])
  need(charts.leg(a,b)==grade[p],'original rational paid leg');p+=1
need(len(grade)==2874,'all original paid movements')
owner_grade={j:frames[str(word['final'][j])]['dim']-frames[str(word['start'][j])]['dim'] for j in opts}
for j in range(222,680):need(charts.leg(word['start'][j],word['final'][j])==frames[str(word['final'][j])]['dim']-frames[str(word['start'][j])]['dim'],'original rational productive leg')
for case in doc['orientations']:
 adjoint=case['orientation']=='adjoint';need(case['orientation'] in ('forward','adjoint'),'orientation')
 values=raw_tape(word,adjoint)
 expected=[{'packet':k,'grade':grade[k],'support':[i for i in range(680) if values[k]>>i&1]}
           for k in sorted(grade) if k!=3553 and values[k]&~sum(1<<i for i in opts)==0]
 need(case['eligible_packets']==expected,'independent raw 680-coordinate pulse census')
 need(case['eligible_count']==len(expected) and case['protected_or_ineligible_count']==2874-len(expected),'packet partition')
 validate_flow(case,grade,owner_grade,opts)
 corrupted=json.loads(json.dumps(case));corrupted['trials'][0]['packet_to_required_owner_flows'].pop()
 try:validate_flow(corrupted,grade,owner_grade,opts)
 except ValueError:pass
 else:raise ValueError('dropped flow edge passed')

caller=literal.pinned(H/'inputs/EFREE-CALLER.json.gz',literal.CALLER_SHA);events=Counter(e[0] for e in caller['events'])
all_owner_grades=Counter(frames[str(word['final'][j])]['dim']-frames[str(word['start'][j])]['dim'] for j in range(222,680))
paid,targets=literal.paired_invoice(caller,Counter(grade.values()),all_owner_grades,events)
need(clean(paid)==doc['full_comparator_paid'] and clean(targets)==doc['full_comparator_targets'] and events['LOCAL']==36,'full 36-call raw invoice')
signed=Counter(targets);signed.subtract(paid);need(clean(signed)==doc['full_comparator_signed'],'complete signed inventory')
for t,upper in doc['complete_signed_margin_upper_bounds'].items():need(decimal_price(signed,t)<=Decimal(upper),'independent decimal full-price upper bound')
if args.upstream_archive:
 need(sha256(args.upstream_archive.read_bytes()).hexdigest()==UPSTREAM_SHA,'#7912 source archive pin')
 with tarfile.open(args.upstream_archive,'r:gz') as archive:
  members={m.name.removeprefix('./'):m for m in archive.getmembers() if m.isfile()}
  copied=['ZERO-CONTROL-WORD.json.gz','project.py',*[str(v.relative_to(H)) for v in (H/'inputs').iterdir() if v.is_file()]]
  for name in copied:need(name in members and archive.extractfile(members[name]).read()==(H/name).read_bytes(),'#7912 archive member '+name)
 print('PASS #7912 archive hash and all copied member bytes')
with TemporaryDirectory(prefix='p104-closure-cold-') as tmp:
 dest=Path(tmp)/'package';shutil.copytree(H,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 for script in ('closure.py','principal.py','interference.py'):
  run=subprocess.run([sys.executable,'-I','-B',str(dest/script)],cwd=dest,text=True,capture_output=True)
  need(run.returncode==0,'relocated '+script+': '+run.stderr[-1200:])
manifest()
print('PASS independent raw-tape supports, 457-owner saturated-flow proofs, corrupted-flow rejection, full prices and relocated literal controls')
