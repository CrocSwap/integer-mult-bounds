#!/usr/bin/env python3
"""Compile and replay the principal zero-closure projections in both directions."""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import gzip,json,sys
H=Path(__file__).resolve().parent;sys.path[:0]=[str(H),str(H/'inputs')]
import project as p, bit_native as bit, literal, price

F={237,250,264,351,355,383,387,391,432,672,673,674,675,676,677,678,679}
A={237,250,264,274,351,355,383,387,391,432,648,649,650,662,664,665,666,667,668,669,670,671}
trials=('0.003879928046156','0.003879929046155')
def clean(c):return {str(k):v for k,v in sorted(c.items()) if v}
def assert_(b,m):
 if not b:raise ValueError(m)
charts=literal.Charts(p.w['frames'])
caller=literal.pinned(H/'inputs/EFREE-CALLER.json.gz',literal.CALLER_SHA);events=Counter(e[0] for e in caller['events']);assert_(events['LOCAL']==36,'native calls')
ref=json.loads((H/'inputs/BIT.json').read_text())['native'];baseP=literal.histogram(ref['paid']);baseT=literal.histogram(ref['targets'])
base=Counter(baseT);base.subtract(baseP)
results=[]
for name,S in [('forward',F),('adjoint',A),('union',F|A)]:
 x=p.project(S,max_rounds=100);eliminated=set(p.labels(x['erased']));mask=sum(1<<k for k in S|eliminated)
 ai={j:c for j,c in p.initial.items() if j not in S};af={j:c for j,c in p.final.items() if j not in S}
 am={k:p.moves[k] for k in x['alive']};ar={k:p.orig[k]&~mask for k in am};ar.update({~j:p.orig[~j]&~mask for j in af})
 assert_(411 in ai and 3553 in am and ar[3553]==1<<411 and x['values'][3553]==1<<411,'original 411 bridge intact')
 fm,fr=p.physical.dual(680,am,ar);order=bit.schedule(af,ai,fm,fr);bit.basis(af,fm,fr,order)
 word=bit.emit_word(p.w,af,ai,fm,fr,order);n=word['public'];assert_(n==680-len(S),'projection dimension')
 charts.main_contacts(word['start'],word['final'])
 f,fl,_=literal.tape(word,charts);b,bl,_=literal.tape(word,charts,adjoint=True)
 assert_(f==literal.expected_rows(n,False) and b==literal.expected_rows(n,True),'full scalar word and transpose')
 assert_(fl['paid']==bl['paid'] and sum(fl['paid'].values())==len(am),'paid both directions')
 targets=Counter(charts.leg(word['start'][j],word['final'][j]) for j in range(222,n))
 paid,products=literal.paired_invoice(caller,fl['paid'],targets,events);net=Counter(products);net.subtract(paid)
 delta=Counter(net);delta.subtract(base);assert_(not clean(delta),'zero complete signed histogram difference')
 ordinary=literal.ordinary(word,caller,events,paid,products)
 paid_banks={event[1] for event in word['program'] if event[0]=='MOVE'}
 held=literal.held_out(word,charts,paid_banks)
 raw=json.dumps(word,sort_keys=True,separators=(',',':')).encode();packed=gzip.compress(raw,mtime=0)
 output=H/f'{name.upper()}-WORD.json.gz'
 if '--emit' in sys.argv:output.write_bytes(packed)
 else:assert_(output.read_bytes()==packed,f'deterministic {name} literal word')
 results.append({'principal':name,'surrendered_original_owners':sorted(S),'surviving_original_owners':sorted(ai),
                 'original_packets_deleted':sorted(eliminated),'pruning_rounds':x['steps'],
                 'original_owner_411_and_packet_3553_pure_bridge_retained':True,
                 'compiled_original_bridge_MOVE_field':n+order.index(3553),'compiled_owner_411_field':sorted(ai).index(411),
                 'native_public':n,'native_paid':clean(fl['paid']),'native_targets':clean(targets),
                 'full_paid':clean(paid),'full_targets':clean(products),'full_signed_histogram_delta_from_7830':clean(delta),
                 'trials':{t:price.decimal_interval(price.moment(net,Fraction(t)),30) for t in trials},
                 'ordinary':ordinary,'full_forward_and_adjoint_literal_outputs':True,
                 'private_retirement_and_physical_chart_legs':True,'held_out_control':held,
                 'word_canonical_sha256':sha256(raw).hexdigest(),'word_gzip_sha256':sha256(packed).hexdigest()})
 print(name,'public',n,'packets',len(am),'literal hash',sha256(raw).hexdigest(),'signed delta',clean(delta),flush=True)
text=json.dumps({'schema':'p104-principal-projections/1','results':results},sort_keys=True,indent=2)+'\n'
if '--emit' in sys.argv:(H/'PRINCIPAL.json').write_text(text)
else:assert_((H/'PRINCIPAL.json').read_text()==text,'principal receipt deterministic')
print('PASS compiled principal projections, 36-call prices, physical contacts, full literal forward/adjoint, corrupted live-ADD and CLEAR controls')
