#!/usr/bin/env python3
"""Produce original-pulse 457-owner maximum-closure flow certificates.

Each certificate routes every optimistic packet reward into required owner
charges. Prices are outward-rounded; identical singleton reward/charge terms
are symbolically canceled first, so zero is an exact upper bound.
"""
from collections import Counter,deque
from fractions import Fraction
from pathlib import Path
import json,sys
H=Path(__file__).resolve().parent;sys.path[:0]=[str(H),str(H/'inputs')]
import project as p,price,literal

TRIALS=('0.003879928046156','0.003879929046155');OPT=sorted(set(range(222,680))-{411})
def need(x,m):
 if not x:raise ValueError(m)
def clean(c):return {str(k):int(v) for k,v in sorted(c.items()) if v}
class Flow:
 def __init__(self,n):self.graph=[[] for _ in range(n)]
 def add(self,u,v,capacity):
  a=[v,capacity,None];b=[u,0,a];a[2]=b;self.graph[u].append(a);self.graph[v].append(b);return a
 def run(self,s,t):
  total=0
  while True:
   level=[-1]*len(self.graph);level[s]=0;q=deque([s])
   while q:
    u=q.popleft()
    for v,cap,_ in self.graph[u]:
     if cap and level[v]<0:level[v]=level[u]+1;q.append(v)
   if level[t]<0:break
   at=[0]*len(level)
   def dfs(u,amount):
    if u==t:return amount
    while at[u]<len(self.graph[u]):
     e=self.graph[u][at[u]];v,cap,back=e
     if cap and level[v]==level[u]+1:
      sent=dfs(v,min(amount,cap))
      if sent:e[1]-=sent;back[1]+=sent;return sent
     at[u]+=1
    return 0
   while (x:=dfs(s,10**120)):total+=x
  return total

def certificate(eligible,neutral,t):
 caps={g:price.price(g,Fraction(t)) for g in set(p.grades.values())|set(p.hg.values())}
 packets={k:r for k,r in eligible.items() if k not in neutral.values()}
 reward={k:36*caps[p.grades[k]][1] for k in packets}
 debit={h:(0 if h in neutral else 36*caps[p.hg[h]][0]) for h in OPT}
 oi={h:i+2 for i,h in enumerate(OPT)};pi={k:i+2+len(OPT) for i,k in enumerate(packets)}
 flow=Flow(2+len(OPT)+len(packets));capinf=sum(reward.values())+sum(debit.values())+1;edges={}
 for k,support in packets.items():
  flow.add(0,pi[k],reward[k])
  for h in support:edges[k,h]=flow.add(pi[k],oi[h],capinf)
 for h in OPT:flow.add(oi[h],1,debit[h])
 amount=flow.run(0,1);need(amount==sum(reward.values()),'source rewards saturated')
 routed=[[k,h,str(edge[2][1])] for (k,h),edge in edges.items() if edge[2][1]]
 return {'trial':t,'scale':str(price.GRID),'copies':36,
         'grade_price_intervals':{str(g):[str(a),str(b)] for g,(a,b) in sorted(caps.items())},
         'source_reward_sum':str(sum(reward.values())),'max_flow':str(amount),
         'min_cut_empty_selection':str(sum(reward.values())),
         'directed_upper_bound_signed_delta':'0','packet_to_required_owner_flows':routed}

need(len(OPT)==457,'457 eligible owners')
fm,fr,clocks=p.physical.packet_word(p.w)
need(literal.canonical(p.w)==p.physical.TREE_WORD,'literal #7830 canonical pin')
forw_order,forw=p.physical.evaluate(p.w['start'],p.w['final'],fm,fr,False)
adj_order,adj=p.physical.evaluate(p.w['final'],p.w['start'],p.moves,p.orig,True)
caller=literal.pinned(H/'inputs/EFREE-CALLER.json.gz',literal.CALLER_SHA);events=Counter(e[0] for e in caller['events'])
baseP,baseT=literal.paired_invoice(caller,Counter(p.grades[k] for k in fm),Counter(p.hg.values()),events)
ref=json.loads((H/'inputs/BIT.json').read_text())['native'];need(clean(baseP)==clean(literal.histogram(ref['paid'])) and clean(baseT)==clean(literal.histogram(ref['targets'])),'complete #7830 caller invoice')
signed=Counter(baseT);signed.subtract(baseP)
results=[]
for name,values in [('forward',forw),('adjoint',adj)]:
 eligible={k:list(p.labels(values[k])) for k in sorted(fm) if k!=3553 and set(p.labels(values[k]))<=set(OPT)}
 need(all(s for s in eligible.values()),'no initially zero packet')
 neutral={}
 for k,s in eligible.items():
  if len(s)==1 and p.hg[s[0]]==p.grades[k]:
   need(s[0] not in neutral,'at most one canceled singleton per owner');neutral[s[0]]=k
 expected=(430,17) if name=='forward' else (113,22)
 need((len(eligible),len(neutral))==expected,'complete original support and neutral pair counts')
 results.append({'orientation':name,'eligible_packets':[{'packet':k,'grade':p.grades[k],'support':s} for k,s in eligible.items()],
                 'eligible_count':len(eligible),'protected_or_ineligible_count':len(fm)-len(eligible),
                 'symbolically_cancelled_pairs':[{'owner':h,'packet':k,'grade':p.hg[h]} for h,k in sorted(neutral.items())],
                 'remaining_paid_packet_nodes':len(eligible)-len(neutral),
                 'trials':[certificate(eligible,neutral,t) for t in TRIALS]})
result={'schema':'p104-original-pulse-closure-flow-certificate/1',
        'status':'PASS_BOTH_ORIENTATIONS_EXACT_ZERO_UPPER_BOUND',
        'scope':'For each orientation separately, specialize an arbitrary subset of the 457 original non-411 helper coordinates at both input and output. Grant the deletion of every original paid packet whose original exact input pulse has support wholly inside the selected subset; retain the original chart, packet graph and pulse family. Do not grant retiming, changed payloads, opposite-orientation pruning cascades, pairs, or relays. Target debit includes every selected original helper in all 36 calls. Sum of all such zero-packet grants is an optimistic upper bound for any subset of such omissions; it is not an upper bound for edits outside this class.',
        'comparator_pr':7830,'comparator_head':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15',
        'comparator_word_canonical_sha256':p.physical.TREE_WORD,
        'prior_control_pr':7912,'prior_control_head':'83ece5a62d3addbee45bad9594ef4809851b833b',
        'prior_direct_second_owner_pr':7935,'prior_direct_second_owner_head':'86203c17e5bbecd4085067db1479e5858c896524',
        'fixed_exterior_sink_matching_pr':7953,'fixed_exterior_sink_matching_head':'13a47f662901e894fee93365c7efec89f4f21fae',
        'optional_original_owners':OPT,'protected_main_owners':list(range(222)),
        'protected_helper':411,'protected_original_bridge_packet':3553,'native_calls':events['LOCAL'],
        'full_comparator_paid':clean(baseP),'full_comparator_targets':clean(baseT),'full_comparator_signed':clean(signed),
        'complete_signed_margin_upper_bounds':{t:price.decimal_interval(price.moment(signed,Fraction(t)),30)[1] for t in TRIALS},
        'orientations':results}
text=json.dumps(result,indent=2,sort_keys=True)+'\n'
if '--emit' in sys.argv:(H/'CLOSURE.json').write_text(text)
else:need((H/'CLOSURE.json').read_text()==text,'closure receipt deterministic')
print('PASS all 457 optional owners, separate raw-pulse orientations, exact zero directed maxflow upper bounds and full 36-call baseline')
