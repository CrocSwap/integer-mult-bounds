#!/usr/bin/env python3
"""Independent clean-directory replay and input tamper controls."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parent


def main():
    outputs=['PRICE.json']+[f'RATIONAL-GATE-{k}-m{m}.json'
              for k in ('0.003879928046156','0.003879929046155') for m in (6,7)]
    rejected=[]
    with TemporaryDirectory(prefix='p104-transfer-cold-') as directory:
        tmp=Path(directory)/'packet'
        shutil.copytree(ROOT,tmp,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        def run(*flags):
            return subprocess.run([sys.executable,*flags,str(tmp/'price_transfer.py')],cwd=tmp,
                                  stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
        p=run('-I','-B')
        if p.returncode or p.stdout!=(ROOT/'PRICE.json').read_bytes():
            raise ValueError('cold price mismatch '+p.stderr.decode(errors='replace'))
        for name in outputs[1:]:
            if (tmp/name).read_bytes()!=(ROOT/name).read_bytes():raise ValueError('gate mismatch '+name)
        for name in ('7911/source-7863/BASELINE.json',
                     '7911/source-7863/inputs/cache/source/research/p104-dual-supplier-lift/complex/supplier_gate.py',
                     'inputs/PR-7973-INDEPENDENT.json'):
            path=tmp/name;old=path.read_bytes();bad=bytearray(old);bad[len(bad)//2]^=1;path.write_bytes(bad)
            p=run('-I','-B')
            if p.returncode==0:raise ValueError('source mutation survived: '+name)
            path.write_bytes(old);rejected.append(name)
        p=run('-I','-B','-O')
        if p.returncode==0 or b'use assertions' not in p.stderr:raise ValueError('optimized run survived')
    print(json.dumps({'status':'PASS_COLD_REPLAY_AND_MUTATION_CONTROLS',
                      'byte_equal_outputs':outputs,'rejected_mutations':rejected,
                      'optimized_mode_rejected':True},indent=2,sort_keys=True))


if __name__=='__main__':main()
