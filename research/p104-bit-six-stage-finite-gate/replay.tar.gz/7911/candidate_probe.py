#!/usr/bin/env python3
"""Price an independently replayed candidate BIT receipt, without certifying it."""
import argparse
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from importlib.util import module_from_spec,spec_from_file_location
from pathlib import Path
import gzip,json,re,sys

if not __debug__: raise SystemExit('run without Python optimization')
here=Path(__file__).resolve().parent
review_path=here/'source-7863/source-7830/review/independent.py'
base_path=here/'source-7863/BASELINE.json'
assert sha256(review_path.read_bytes()).hexdigest()=='a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca'
assert sha256(base_path.read_bytes()).hexdigest()=='a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a'
spec=spec_from_file_location('price_review',review_path);r=module_from_spec(spec);sys.modules[spec.name]=r;spec.loader.exec_module(r)

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--receipt',type=Path,required=True,help='independent BIT evaluator receipt')
parser.add_argument('--word',type=Path,required=True,help='exact candidate word gzip bound by receipt')
parser.add_argument('--trial',required=True,help='exact rational or decimal raw exponent')
parser.add_argument('--tensor',type=int,default=451,help='one fixed power, between 1 and 4096')
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args();trial=Q(args.trial);v=args.tensor
assert Q('0.003879928046155') < trial < Q(1,250) and 1<=v<=4096
receipt=json.loads(args.receipt.read_bytes());raw=args.word.read_bytes()
digest=sha256(raw).hexdigest()
assert re.fullmatch('[0-9a-f]{64}',digest) and receipt['candidate']['sha256']==digest,'candidate gzip SHA binding'
word=json.loads(gzip.decompress(raw));canonical=sha256(json.dumps(word,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def hist(obj):
    assert isinstance(obj,dict)
    values={int(k):n for k,n in obj.items()}
    assert all(rank>=1 and isinstance(n,int) and n>=0 for rank,n in values.items())
    return Counter({rank:n for rank,n in values.items() if n})

paid=hist(receipt['invoice']['paid']);targets=hist(receipt['invoice']['productive'])
baseline=json.loads(base_path.read_bytes())['binary']
oldpaid=hist(baseline['paid']);oldtargets=hist(baseline['targets'])
assert paid and targets and sum(paid.values())==receipt['invoice']['paid_count']
assert sum(targets.values())==receipt['invoice']['productive_count']
assert trial<Q(13,50) and Q(17,50)<1-trial

target=r.moment(targets,1-trial);pay=r.moment(paid,1-trial);signed=r.sub(target,pay)
old=r.sub(r.moment(oldtargets,1-trial),r.moment(oldpaid,1-trial))
# Price the net coefficient change directly. Equal bins then give an exact
# zero, instead of interval cancellation between two large invoices.
delta_coeff=targets.copy();delta_coeff.subtract(oldtargets);delta_coeff.subtract(paid);delta_coeff.update(oldpaid)
delta=r.moment(delta_coeff,1-trial)
alpha=r.quotient(pay,target)
gamma=r.quotient(r.moment(paid,1-trial+Q(13,50)),r.mul(r.power(11,Q(13,50)),target))
lam=r.quotient(r.mul(r.power(16,Q(17,50)),r.moment(targets,1-trial-Q(17,50))),target)
G=r.GRID
def cap(interval,places):
    # All source intervals enclose the true values on a 70-place grid.
    n=-(-(interval[1]*10**places)//G)
    return Q(n,10**places)
def dec(x,places=42,up=False):
    n=x.numerator*10**places
    z=-(-n//x.denominator) if up else n//x.denominator
    sign='-' if z<0 else '';z=abs(z)
    return f'{sign}{z//10**places}.{z%10**places:0{places}d}'
def iv(x):return [dec(Q(x[0],G)),dec(Q(x[1],G),up=True)]

ac,gc,lc=(cap(x,40) for x in (alpha,gamma,lam))
a22,g22,l22=(cap(x,22) for x in (alpha,gamma,lam))
state='INDETERMINATE_INTERVAL' if signed[0]<=0<=signed[1] else ('POSITIVE' if signed[0]>0 else 'NEGATIVE')
moment={
  'signed':iv(signed),'unchanged_signed':iv(old),'signed_delta':iv(delta),
  'alpha':iv(alpha),'gamma':iv(gamma),'lambda':iv(lam),'strict_raw_sign':state,
  'caps_40_decimals':{'alpha':dec(ac,40),'gamma':dec(gc,40),'lambda':dec(lc,40)},
  'cap_scope':'single 70-digit source engine; 40-place caps require a refined supplier; archived code uses 22-place caps and three engine upper bounds',
}
if max(ac,gc,lc)<1:
    loss=Q(1,1+v*(1-ac))+2*gc**v+lc**v
    moment['source_sufficient_separation_pass']=loss<1
    moment['one_minus_source_bound_interval']=[dec(1-loss),dec(1-loss,up=True)]
else:
    moment['source_sufficient_separation_pass']=False
    moment['one_minus_source_bound_interval']=None
if max(a22,g22,l22)<1:
    loss22=Q(1,1+v*(1-a22))+2*g22**v+l22**v
    moment['source_22place_one_engine_separation_pass']=loss22<1
else:
    moment['source_22place_one_engine_separation_pass']=False
ordinary=receipt['forward_and_adjoint']
K=Q('0.003879928046156');g=Q(1,10**18);e=Q(1,10**19);d=Q(1,10**20)
rho=Q(1,250);seed=Q('0.00385248')
example_raw_threshold=e+d+(K+8*g-rho**7*seed)/(1-rho**7)
at_target=r.sub(r.moment(targets,1-K),r.moment(paid,1-K))
bridge=None
plan_trial=trial if state=='POSITIVE' and trial>K else None
if plan_trial is None and at_target[0]>0:
    # For C>=K, each r^(1-C) log r decreases. The absolute signed
    # derivative is at most this independently directed finite sum.
    coeff=targets.copy();coeff.subtract(paid)
    derivative_hi=0
    for rank,count in coeff.items():
        term=r.scale(r.mul(r.power(rank,1-K),r.log_int(rank)),abs(count))
        derivative_hi+=term[1]
    positive_margin=Q(at_target[0],G)
    limit=(rho-K)/2
    advance=min(Q(1,10**15),limit,positive_margin/(2*Q(derivative_hi,G))) if derivative_hi else min(Q(1,10**15),limit)
    assert advance>0 and K+advance<rho
    proved_lower=positive_margin-advance*Q(derivative_hi,G)
    assert proved_lower>0
    plan_trial=K+advance
    direct=r.sub(r.moment(targets,1-plan_trial),r.moment(paid,1-plan_trial))
    bridge={'method':'directed signed margin at K and uniform absolute-derivative bound',
            'positive_margin_lower':str(positive_margin),'derivative_absolute_upper':str(Q(derivative_hi,G)),
            'advance':str(advance),'trial':str(plan_trial),'proven_margin_lower':str(proved_lower),
            'direct_reprice_interval':iv(direct),
            'scope':'profile arithmetic only; alpha, gamma, lambda and physical conditions must be rechecked at the bridged trial'}

def rate_plan(raw_trial):
    # Conditional exact-rational loss/selector plan; no physical supplier is
    # created. Precision and the number of completed backends are allowed to
    # grow if the strict raw advantage is very small.
    if raw_trial is None:
        return {'status':'NOT_PROPOSED_NO_STRICT_RAW_ADVANTAGE'}
    advantage=raw_trial-K
    assert advantage>0
    digits=15
    while 64*Q(1,10**digits)>=advantage:
        digits+=1
        if digits>100:
            return {'status':'NOT_PROPOSED_REQUIRES_MORE_THAN_100_DECIMAL_PLACES'}
    step=Q(1,10**digits);uniform=step/100;cover=step/1000
    covered=raw_trial-uniform-cover;desired=K+8*step
    assert seed<desired<covered<rho
    assert desired/step==int(desired/step)
    n=1
    while (1-rho**n)*covered+rho**n*seed<=desired:
        n+=1
        assert n<=128,'more than 128 physical stage interfaces would need consideration'
    ideal=(1-rho**n)*covered+rho**n*seed
    epsilon=(ideal-desired)*(1-rho)/2
    previous=seed;values=[]
    for _ in range(n):
        envelope=(1-rho)*covered+rho*previous
        nxt=envelope-epsilon
        assert previous<nxt<envelope<covered<rho<1-envelope
        values.append(str(nxt));previous=nxt
    assert previous>desired>K+7*step
    return {'status':'CONDITIONAL_RATIONAL_RATE_PLAN_ONLY',
            'raw_trial':str(raw_trial),'decimal_places':digits,'outer_gap':str(step),'uniform_loss':str(uniform),'cover_loss':str(cover),
            'stages_above_seed':n,'stage_values_exact':values,'admitted_stage_exact':str(previous),
            'conservative_adapter_cap':str(desired),'tested':str(K+7*step),
            'source_interval_precision_review_required':digits>65,
            'requires':'reprice all moments at raw_trial; then candidate-specific tensor separation, source selector and complete new finite compiler, cover, seed, stock, precision and outer replay'}
out={'status':'BOUNDED_RECEIPT_PRICE_ONLY',
     'scope':'Receipt and candidate byte binding plus directed profile arithmetic. Does not validate operator replay, occurrence identities, physical stock, supplier, precision, or consumer.',
     'receipt_sha256':sha256(args.receipt.read_bytes()).hexdigest(),'candidate_gzip_sha256':digest,
     'candidate_canonical_json_sha256':canonical,'reported_operator_status':receipt.get('status'),
     'trial':str(trial),'tensor':v,'paid_count':sum(paid.values()),'productive_count':sum(targets.values()),
     'trial_strictly_above_15dp_target':trial>K,
     'target_signed':iv(at_target),'strict_target_positivity':at_target[0]>0,
     'positive_trial_above_target_from_derivative_bound':bridge,
     'passes_example_schedule_raw_necessary_only':trial>example_raw_threshold,
     'uniform_parameters_prepared_only_for_451':v==451,
     'max_paid_grade':max(paid),'max_productive_grade':max(targets),
     'old_ambient_grade_support_only':max(max(paid),max(targets))<=134,
     'target_floor_grade_witness_only':all(targets[k]>0 for k in (4,8,64)) and v==451,
     'reported_ordinary_records':ordinary['raw_records'],'reported_owned_fields':ordinary['owned_fields'],
     'old_template_limits_met_only':ordinary['raw_records']<10**12 and ordinary['owned_fields']<10**7,
     'moment':moment,'adaptive_rate_plan':rate_plan(plan_trial)}
args.out.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print('BOUNDED_RECEIPT_PRICE_ONLY',state,'source_moment_bound',moment['source_sufficient_separation_pass'],flush=True)
