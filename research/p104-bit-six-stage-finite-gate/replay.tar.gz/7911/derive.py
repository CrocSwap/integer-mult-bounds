#!/usr/bin/env python3
"""Conditional 15-decimal target, changed-loss and #7868-stock arithmetic."""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha1,sha256
from importlib.util import module_from_spec,spec_from_file_location
from pathlib import Path
import argparse,json,sys

if not __debug__:
    raise SystemExit('run without Python optimization')
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out',type=Path,default=HERE/'RESULT.json')
args=parser.parse_args()
SRC=HERE/'source-7863'
pins=json.loads((HERE/'SOURCE-7863.json').read_bytes())
assert pins['archive_sha256']=='5f9d9c378a1bddccb2e42ac6453716fa950f19bd71f6181a9606f5eb68b022b3'
assert pins['head']=='b3e4412fe01f07dc58305616fabf96345f49a781'
assert pins['members']=={
  'BASELINE.json':'a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a',
  'BIT-451.json':'538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749',
  'source-7830/BIT.json':'8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d',
  'source-7830/review/independent.py':'a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
  'source-7830/LICENSE':'c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4',
  'source-7830/NOTICE':'b213998c8dae6d88e4a1f0fd17c81dd78c31ef35bc9460fa16ca692326f1a02b',
  'inputs/cache/parent/qualify_complex.py':'236988674f4efe96134de83a224f9c5f4508f6049237415bc24a18669cf5ad67',
  'inputs/cache/parent/NOTICE':'5b20e5e7321a62fc765f31114c68aaff3f6c9c8d9f7707ecfe3575ca37aee6b2',
  'inputs/cache/source/research/p104-dual-supplier-lift/complex/supplier_gate.py':'3796b2e5a27f3caa142d16364154788e60d0099f1e24a8dcd028e4fbd35a84ca',
}
for path,digest in pins['members'].items(): assert sha256((SRC/path).read_bytes()).hexdigest()==digest,path
for path,blob in {
    'CARRIER-PROOF.md':'716ba87353619ac15bbd7652f0b83fb6abb41592',
    'TERNARY-COVER.md':'1ef9dbcc71ad0ba0e040f7aeab6524143135c8ec',
    'FACTORED-ROUTES.md':'2247be52a9bea9c2a99521bc76119a9a6488185e',
    'README.md':'0d1c841f1fb586c7231a99949d0f2cc63a0aa943',
    'NOTICE.md':'1f01fd2ec6946a9034064669d11e392e26bdf469',
    'FLOW-NOTICE.md':'a45751b0e8a6d4fc178cea078a0e2c1a8ad94c85',
    'LICENSE':'261eeb9e9f8b2b4b0d119366dda99c6fd7d35c64',
    'lean/StockThreshold.lean':'e55a106304aeb48f5304062cbcf53714e165f8ce',
    'lean/CarrierGuards.lean':'a8a2340389c281dd7ce9988d32b2eb1f694ef804',
    'lean/ShiftedCarrier.lean':'8e8a3e95c426e1d94657e821a7068439b347f92d',
}.items():
    raw=(HERE/'source-7868'/path).read_bytes()
    assert sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob,path

def load(name,path):
    spec=spec_from_file_location(name,path);m=module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
r=load('r2_review',SRC/'source-7830/review/independent.py')
gate=load('complex_gate',SRC/'inputs/cache/source/research/p104-dual-supplier-lift/complex/supplier_gate.py')
selector=load('complex_selector',SRC/'inputs/cache/parent/qualify_complex.py')
base=json.loads((SRC/'BASELINE.json').read_bytes())
hist=lambda v: Counter({int(k):n for k,n in v.items()})
bp,bt=hist(base['binary']['paid']),hist(base['binary']['targets'])
rp,rt=hist(base['rational']['paid']),hist(base['rational']['targets'])
assert sum(bp.values())==107460 and sum(bt.values())==20706
assert sum(rp.values())==283152 and sum(rt.values())==52512

G=r.GRID
def lo(x):return Q(x[0],G)
def hi(x):return Q(x[1],G)
def cd(a,b):return -(-a//b)
def decimal(x,places=42,upper=False):
    z=cd(x.numerator*10**places,x.denominator) if upper else x.numerator*10**places//x.denominator
    sign='-' if z<0 else '';z=abs(z)
    return f'{sign}{z//10**places}.{z%10**places:0{places}d}'
def interval(a,b,places=42):return [decimal(a,places),decimal(b,places,True)]

K=Q('0.003879928046156'); upper=Q('0.003879928046155')
seed=Q('0.00385248');rho=Q(1,250);v=451
old_e,old_d=Q(1,400_000_000_000),Q(1,10**13)
new_e,new_d=Q(1,10**19),Q(1,10**20)
C=Q('0.0038799280461560083');g=Q(1,10**18)
assert K-upper==Q(1,10**15) and K*10**15==int(K*10**15) and K*10**14!=int(K*10**14)

def row(digits,e,d):
    grid=10**digits;claim=Q(cd(K.numerator*grid,K.denominator),grid);gap=Q(1,grid);cap=claim+8*gap
    # Seven strict source envelopes imply a_7 < this rational supremum.
    threshold=e+d+(cap-rho**7*seed)/(1-rho**7)
    return {'digits':digits,'claim':decimal(claim,20),'tested':decimal(claim+7*gap,20),
            'minimum_cap':decimal(cap,20),'strict_minimum_raw':interval(threshold,threshold,36),
            'minimum_raw_minus_K':interval(threshold-K,threshold-K,36)}
rows={'old_14':row(14,old_e,old_d),'old_15':row(15,old_e,old_d),
      'new_15':row(15,new_e,new_d),'new_18':row(18,new_e,new_d)}

# Seven-step demonstration with the original 20-place stage rounding rule.
covered=C-new_e-new_d;previous=seed;stages=[]
cold_gap=(1-rho)*covered-seed
assert cold_gap>0
for _ in range(7):
    envelope=(1-rho)*covered+rho*previous
    nxt=Q((envelope.numerator*10**20)//envelope.denominator-1,10**20)
    assert previous<nxt<envelope<covered<rho<1-envelope
    stages.append({'claim':decimal(nxt,20),'gap':str(envelope-nxt)})
    previous=nxt
cap=previous;assert cap>=K+8*g and cap>K+7*g

# Prove minimal grid point on the uniform e-grid with a unimodal guard.
# For j>=120, the successive left/right ratios decrease strictly.
den=new_e.denominator
assert 121**60 < 2*120**60
wins=lambda j:(den*j+1)**60<2**j
assert all(not wins(j) for j in range(1,121))
left,right=120,240
while not wins(right):left,right=right,2*right
while right-left>1:
    mid=(left+right)//2
    if wins(mid):right=mid
    else:left=mid
j=right;H=den*j
assert wins(j) and not wins(j-1) and H*new_e==j and (H+1)*new_e>120
assert H==45160000000000000000000

# Check 451 shifted-log guards at C and the alternate cover budget.
theta=Q(13,15);ambient=r.power(134,v*C)
eta=r.quotient(r.enclose(1-C),ambient)
assert theta**60<lo(eta)<=hi(eta)<=theta**59 and hi(ambient)<2**60
assert 11**15<16**13 and 4*11**(15*v)<=134**(13*v)
qbits=1
while Q(64,2**qbits)>=new_d/4:qbits+=1
assert qbits==75 and Q(64,2**qbits)<new_d/4<=Q(64,2**(qbits-1))
assert 2**(H*new_d//1)>=1+new_d/2
# The alternate 9-child ternary rate needs its own moment budget too.
assert 9<2**(H*new_d//1)

def bit_stats(c):
    t=1-c;target=r.moment(bt,t);paid=r.moment(bp,t);signed=r.sub(target,paid)
    gamma=r.quotient(r.moment(bp,t+Q(13,50)),r.mul(r.power(11,Q(13,50)),target))
    lam=r.quotient(r.mul(r.power(16,Q(17,50)),r.moment(bt,t-Q(17,50))),target)
    dl=2*lo(gamma)**v+lo(lam)**v;dh=2*hi(gamma)**v+hi(lam)**v
    # Illustration only: hypothetically hold target, gamma, lambda at baseline.
    extra=(lo(target)*dl/(v*(1-dl)),hi(target)*dh/(v*(1-dh)))
    return {'signed':interval(lo(signed),hi(signed)),
        'gamma':interval(lo(gamma),hi(gamma)),'lambda':interval(lo(lam),hi(lam)),
        'frozen_T_gamma_lambda_extra_margin':interval(*extra),
        'frozen_T_gamma_lambda_required_delta':interval(-hi(signed)+extra[0],-lo(signed)+extra[1])}

# Prove the 54+4 outer rational polynomials are all >= g/10 for the whole
# interval 0<g<=1e-15 at claim K and cap K+8g. Their expressions have degree
# at most 2; interpolate exact coefficients and apply interval bounds.
def outer_list(x):
    b,a,q=(K+n*x for n in (5,4,3));ep,be=1-x,1-3*x;cap0=K+8*x
    sig,tau=1-b,1-a
    internal=tau # sig-tau=-x<=0 for the interval being certified
    leaf=sig+x*(1-sig);ell=1-(q+a)/2;xi=ep*(1+q)-Q(3,32)+x;r0=x/10;key=be+1-ep
    m=[ep*q,a,1-ep+q*be,1-ep+a*be,1-ep+be,Q(3,32)+xi-ep,xi+Q(1,2)-ep,ep,1-(ep+be+48-128+2)]
    strict=[cap0-a,b-a,q,b-q,a-q,x,1-x,(1-x)*b-a,1-internal-q,1-leaf-q,
        ell-tau,ell-sig,ell-internal,1-q-ell,1-q-leaf,ep,1-ep,xi-Q(1,2),ep-xi,be,ep-be,1-be,
        1-(2*xi-2)-r0-be,1-(2*xi-2)-be,1-ep-r0,1-ep,r0,1-key,1-be-2*(1-ep),128-48-be,
        x,ep-a,Q(1,32)-b,2**45-7**16,Q(2),2-xi,Q(5),1-be,1-be,1-ep,m[2]-m[0],x,
        K-Q('.001730970419199163702738'),1-ep,Q(11,2)]+[value-K for value in m]
    functional=[1-be,be*Q(997,1000),128-48-ep-be-1,be*Q(249,250)]
    assert len(strict)==54 and len(functional)==4
    return strict+functional
values=[outer_list(Q(i)) for i in range(4)];gmax=Q(1,10**15)
for z0,z1,z2,z3 in zip(*values):
    c0=z0;c2=(z2-2*z1+z0)/2;c1=z1-c0-c2
    assert z3==c0+3*c1+9*c2 and c0>=0
    if c0==0:
        assert c1-Q(1,10)+min(Q(0),c2*gmax)>=0
    else:
        assert c0+min(Q(0),(c1-Q(1,10))*gmax)+min(Q(0),c2*gmax*gmax)>=0
assert r.outer_margins(K,g,K+8*g)['minimum_margin']==str(g/10)

# Uniform exact enclosures for the unchanged rational profile on the entire
# tested range: numerator evaluated at K, denominator at K+7g_max.
wide_target=r.moment(rt,1-(K+7*gmax))
ra=r.quotient(r.moment(rp,1-K),wide_target)
rg=r.quotient(r.moment(rp,1-K+Q(1,7)),r.mul(r.power(11,Q(1,7)),wide_target))
rd=r.quotient(r.enclose(Q(12*sum(rt.values()))),r.mul(r.power(11,K),wide_target))
reserve,decay=Q(1,10**27),Q(31,32)
assert hi(ra)<1-reserve and max(hi(rg),hi(rd))<decay
assert 1/(1+1920*reserve)+4*decay**1920<1

# Generalize the source selector's decimal tick, its endpoint expressed in
# ticks, and its formatter, retaining the same price() logic. A production
# candidate still needs all word/receipt/auditor pins.
class Reference:
    def dyadic_price(self,weights,trial):
        t=1-Q(trial)
        return r.sub(r.moment(weights['T'],t),r.moment(weights['P'],t))
def refined_price(digits,bit_cap):
    ticks=10**digits
    def tick(n):return f'{n//ticks}.{n%ticks:0{digits}d}'
    def signed(n):return Reference().dyadic_price({'T':rt,'P':rp},tick(n))
    left,right=1,int(Q('0.0069')*ticks)
    assert signed(left)[0]>0 and signed(right)[1]<0
    while right-left>1:
        mid=(left+right)//2;low,high=signed(mid)
        if low>0:left=mid
        else:assert high<0;right=mid
    chosen=min(left,int(bit_cap*ticks))-8
    assert signed(chosen+7)[0]>0 and chosen>0
    return tick(chosen),tick(chosen+7),tick(left),tick(right)
assert refined_price(14,cap)==selector.price(Reference(),{'T':rt,'P':rp},cap)
selected=refined_price(18,cap)
assert Q(selected[0])==K and Q(selected[1])==K+7*g
assert Q('0.00388013644474')<=Q(selected[2])<Q(selected[3])<=Q('0.00388013644475')
assert Q(selected[3])-Q(selected[2])==g
gate.BIT_PIN=str(cap)
consumer=gate.gate({'T':dict(rt),'P':dict(rp)},K,K+7*g,Q(selected[2]),Q(selected[3]),cap)
assert consumer['outer']['strict_count']==54 and consumer['outer']['functional_count']==4
complex_H=int(consumer['H'])
assert complex_H==184014000000000000000000
common_bits=(856*1920*153**1920*(complex_H+1)**2).bit_length()
assert common_bits<complex_H
assert (2*134**451).bit_length()<H
g15=Q(1,10**15);cap15=K+8*g15
gate.BIT_PIN=str(cap15)
consumer15=gate.gate({'T':dict(rt),'P':dict(rp)},K,K+7*g15,Q(selected[2]),Q(selected[3]),cap15)
assert consumer15['outer']['strict_count']==54 and consumer15['outer']['functional_count']==4

# #7868-inspired stock shape: m simultaneous q=3 stage debts, conditional on
# the actual changed compiler proving all stage width/depth/batch hypotheses.
stock=[]
for m in (7,8):
    exponent=(36*m+2).bit_length() # ceil(log2(36m+3))
    assert 2**exponent>=36*m+3 and 2**(exponent-1)<36*m+3
    cut=cd(250*(2*H+exponent),249)
    assert 249*cut>=250*(2*H+exponent) and cut<3*H and H>=4
    necessary=Q(250,249)*(2*H+1)
    stock.append({'stage_debts':m,'power_budget':exponent,'sufficient_log2_E':cut,
                  'necessary_log2_E_strict':interval(necessary,necessary,12),
                  'scope':'conditional on all #7868-style stage shape, ledger and ternary routing hypotheses'})

out={'status':'PASS_CONDITIONAL_NUMERICAL_PREPARATION_NO_CHANGED_WORD',
     'target':str(K),'scope':'arithmetical transfer preparation; no changed word, finite compilation or physical precision transfer',
     'grid_rows':rows,'raw_example':decimal(C,22),'example_uniform_loss':str(new_e),
     'example_cover_loss':str(new_d),'example_outer_gap':str(g),
     'cold_seed_envelope_gap':decimal(cold_gap,30),
     'seven_stages':stages,'ordinary_cap':decimal(cap,20),'tested':decimal(K+7*g,18),
     'cap_above_tested':str(cap-(K+7*g)),'BIT_H':H,'uniform_grid_j':j,
     'cover_q_power':qbits,'q3_nine_child_moment_test':'9 < 2^floor(H*d)',
     'old_BIT_at_target':bit_stats(K),'old_BIT_at_example_raw':bit_stats(C),
     'rational_envelope_upper':{'alpha':decimal(hi(ra),42,True),'gamma':decimal(hi(rg),42,True),
                                'delta':decimal(hi(rd),42,True)},
     'source_18dp_selector':list(selected),
     'source_gate':{'H':consumer['H'],'written_log_power':consumer['written_log_power'],
                    'minimum_log_power':consumer['minimum_log_power'],'outer':consumer['outer'],
                    'common_root_argument_bit_length':common_bits},
     'source_gate_15dp':{'H':consumer15['H'],'written_log_power':consumer15['written_log_power'],
                         'minimum_log_power':consumer15['minimum_log_power'],'outer':consumer15['outer']},
     'outer_polynomial_guard':'54 strict and 4 functional margins >=g/10 for every 0<g<=1e-15',
     'stock_shape':stock,'premises':r.PREMISES}
args.out.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
print(out['status'])
print('source-grid claims',rows['old_14']['claim'],rows['new_15']['claim'])
print('451 example',out['raw_example'],'cap',out['ordinary_cap'],'H',H)
print('source gate H',consumer['H'],'outer',consumer['outer'])
