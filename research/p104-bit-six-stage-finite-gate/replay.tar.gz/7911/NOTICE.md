# Attribution and license

This bounded numerical handoff and its new scripts were prepared for
Clear1nsight with substantial OpenAI Codex assistance and are offered under
Apache-2.0; see `LICENSE`. The results do not replace the cited upstream
constructions and do not assert a new κ.

The pinned #7830 and #7863 source subset retains the original notices in
`source-7863/source-7830/NOTICE` and
`source-7863/inputs/cache/parent/NOTICE`. They credit Clear1nsight, Dugongue,
Rohan Arun, Ali Romman, DreamingOfClouds, Jerry Chen, zxv, SYLforge, Cinna
Davis, Douglas Colkitt and the other named predecessor contributors. The
source files are copied without modification.

The #7868 ternary, periodic compiler and stock work is by Ali Romman with
substantial OpenAI Codex assistance, with further credit in
`source-7868/NOTICE.md` and `source-7868/FLOW-NOTICE.md`. The included exact
source subset is preserved without modification.

The zero-net control word and its independent Round 2 operator receipt were
prepared within this campaign with OpenAI Codex assistance. The bundled
receipt is a smaller path-free extract of that independent receipt, not a
fresh native replay. Its original receipt and gzip hashes are in `README.md`.
The synthetic changed histogram used by `replay.py` is solely an arithmetic
control and does not describe an executed candidate.
