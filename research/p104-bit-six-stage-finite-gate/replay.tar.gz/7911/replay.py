#!/usr/bin/env python3
"""Replay the finite-grid handoff and bounded price controls offline."""
import argparse
from fractions import Fraction as Q
from pathlib import Path
import json,subprocess,sys

if not __debug__:raise SystemExit('run without Python optimization')
here=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output-dir',type=Path,default=here/'replay')
args=parser.parse_args();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
def invoke(script,*items,good=True,expected=None):
    p=subprocess.run([sys.executable,'-I','-B',str(here/script),*map(str,items)],
                     stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=60)
    assert (p.returncode==0)==good,(script,p.stdout,p.stderr)
    if expected is not None:assert expected in p.stdout+p.stderr,(script,p.stdout,p.stderr)
    return p

invoke('derive.py','--out',out/'RESULT.json',expected='PASS_CONDITIONAL_NUMERICAL_PREPARATION_NO_CHANGED_WORD')
assert (out/'RESULT.json').read_bytes()==(here/'EXPECTED.json').read_bytes(),'derived receipt mismatch'
receipt=here/'controls/ZERO-NET-RECEIPT.json';word=here/'controls/ZERO-NET-WORD.json.gz'
trial='0.0038799280461560083';result=out/'ZERO-NET-PRICE.json'
invoke('candidate_probe.py','--receipt',receipt,'--word',word,'--trial',trial,'--out',result,
       expected='NEGATIVE source_moment_bound False')
assert result.read_bytes()==(here/'EXPECTED-CONTROL.json').read_bytes(),'zero-net receipt mismatch'
data=json.loads(result.read_bytes())
assert set(map(Q,data['moment']['signed_delta']))=={Q(0)}
assert data['adaptive_rate_plan']['status']=='NOT_PROPOSED_NO_STRICT_RAW_ADVANTAGE'

# A synthetic histogram deliberately breaks the relation between the source
# word and paid counts. It tests arithmetic only and is never a candidate.
fake=json.loads(receipt.read_bytes());fake['status']='SYNTHETIC_HISTOGRAM_ONLY_NOT_EXECUTED'
fake['invoice']['paid']['1']-=1;fake['invoice']['paid_count']-=1
fake_path=out/'SYNTHETIC-RECEIPT.json';fake_path.write_text(json.dumps(fake,sort_keys=True,indent=2)+'\n')
fake_result=out/'SYNTHETIC-PRICE.json'
invoke('candidate_probe.py','--receipt',fake_path,'--word',word,'--trial','0.003879928046156',
       '--out',fake_result,expected='POSITIVE source_moment_bound True')
data=json.loads(fake_result.read_bytes());assert data['strict_target_positivity']
assert Q(data['positive_trial_above_target_from_derivative_bound']['proven_margin_lower'])>0
assert data['adaptive_rate_plan']['status']=='CONDITIONAL_RATIONAL_RATE_PLAN_ONLY'
assert data['moment']['source_22place_one_engine_separation_pass']
tiny=out/'SYNTHETIC-TINY.json';tiny_trial=str(Q('0.003879928046156')+Q(1,10**60))
invoke('candidate_probe.py','--receipt',fake_path,'--word',word,'--trial',tiny_trial,'--out',tiny,
       expected='POSITIVE source_moment_bound True')
plan=json.loads(tiny.read_bytes())['adaptive_rate_plan'];assert plan['decimal_places']==62 and plan['stages_above_seed']==24
wrong=out/'WRONG-WORD.gz';wrong.write_bytes(word.read_bytes()+b'!')
invoke('candidate_probe.py','--receipt',receipt,'--word',wrong,'--trial',trial,'--out',out/'reject.json',
       good=False,expected='candidate gzip SHA binding')
print('PASS_FINITE_HANDOFF_AND_SCOPED_CONTROLS',flush=True)
