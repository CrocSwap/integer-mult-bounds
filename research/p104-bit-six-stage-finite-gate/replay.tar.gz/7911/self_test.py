#!/usr/bin/env python3
"""Verify a fresh offline copy and reject source/receipt corruption."""
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import gzip,shutil,subprocess,sys

if not __debug__:raise SystemExit('run without Python optimization')
here=Path(__file__).resolve().parent
with TemporaryDirectory(prefix='p104-finite-handoff-') as temp:
    root=Path(temp)/'public'
    shutil.copytree(here,root,ignore=shutil.ignore_patterns('replay','__pycache__'))
    for row in (root/'SHA256SUMS').read_text().splitlines():
        digest,path=row.split('  ',1)
        assert sha256((root/path).read_bytes()).hexdigest()==digest,path
    for path in root.rglob('*'):
        if path.is_file():
            raw=path.read_bytes()
            if path.suffix=='.gz':raw=gzip.decompress(raw)
            for component in (b'home',b'tmp',b'mnt',b'run/user'):
                assert b'/'+component+b'/' not in raw,path.relative_to(root)
    def run(*arguments,good=True,expected=None):
        p=subprocess.run([sys.executable,*arguments],cwd=root,text=True,timeout=60,
                         stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert (p.returncode==0)==good,(arguments,p.stdout[-700:],p.stderr[-700:])
        if expected:assert expected in p.stdout+p.stderr,(arguments,p.stdout,p.stderr)
    run('-I','-B','replay.py',expected='PASS_FINITE_HANDOFF_AND_SCOPED_CONTROLS')
    gate=root/'source-7863/inputs/cache/source/research/p104-dual-supplier-lift/complex/supplier_gate.py'
    old=gate.read_bytes();gate.write_bytes(old+b'\n# mutation\n')
    run('-I','-B','derive.py',good=False,expected='supplier_gate.py');gate.write_bytes(old)
    expected=root/'EXPECTED.json';old=expected.read_bytes();expected.write_bytes(old+b' ')
    run('-I','-B','replay.py',good=False,expected='derived receipt mismatch');expected.write_bytes(old)
    run('-I','-O','-B','derive.py',good=False,expected='without Python optimization')
    print('PASS_FRESH_OFFLINE_COPY_AND_TAMPER_CONTROLS',flush=True)
