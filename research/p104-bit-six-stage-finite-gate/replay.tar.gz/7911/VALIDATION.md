# Verification record

`derive.py` ran with one CPU process and reproduced the strict seven-stage
numerals, the 451 uniform and cover integer guards, the 14-place source
selector control, the revised 18-place bracket, the two retained rational
source-gate evaluations, the 54+4 outer-polynomial interval bounds and the
conditional seven/eight-stage stock thresholds. Its 7863-member SHA-256 and
7868 Git-blob checks pass.

A fresh copied directory reproduced the committed result byte for byte; a
modified source gate, changed expected receipt and Python's optimized mode
were rejected. The standalone replay also rejects a modified control word.

`candidate_probe.py` was tested on the separately replayed Round 2 zero-net
word: its complete signed histogram has exact Δ=0, a negative margin at the
example trial and no 451 separation. A **synthetic** receipt with one fewer
grade-one paid count exercised the positive arithmetic branch; it did not
assert or replay a changed word. Replacing the word bytes was rejected by the
gzip-hash binding.

The same synthetic positive-bin fixture also exercised the adaptive rate
planner with raw trial advantages of approximately `8.3e-18`, `1e-30` and
`1e-60`. It produced strict rational stage plans with 19, 32 and 62 decimal
places respectively. A synthetic positive-at-target control also exercised
the explicit derivative-bound bridge to a larger positive raw trial. These
check arithmetic only; none is an actual changed word or a physical
construction.

These are numerical and bounded code checks. They do not independently
replay a new word, authenticate an owner ledger, establish a 451-specific
physical compiler, prove new stock/precision interfaces, or validate an
end-to-end κ claim.
