# Round 6 independent replay and scoped reviews

No new kappa bound or qualifying positive candidate is established here.
Every replay and review below is bounded by its stated input and cannot
replace the upstream P104/word bridge or the five inherited physical and
analytic premises. No external application or publication was modified.

## Incumbent 451-factor outer consumer

A fresh copy of the pinned 451-cap consumer package passed its complete input
manifest and `clean_replay.py`, using the same #7830 compiler and auditor as
the producer. The newly generated APPLICATION.json and AUDIT.json match the
pinned producer bytes. The independently reconstructed rational orientations,
36-call BIT bindings, signed invoices and outer arithmetic retain the existing
conditional claim `kappa >= 0.00387992804346` under `native_all_columns`,
`owned_erasure`, `compiler`, `precision_tape`, and `analytic_recovery`.
`451-clean.log`, `451-clean.resources`, `451-input-manifest.log`, and
`451-consumer/clean-replay-output/INDEPENDENT.json` are the actual clean-run
records. The separate R5 independent finite-451 arithmetic was rerun from a
fresh copy under `finite-451/`, byte-matching its earlier receipt; it gives a
strict 451-factor surplus and rejects the 448-factor control.

These tests do not construct the full 451-fold word, cover prime, physical
receiver or live stock, and do not prove an adapted precision/activation tape,
physical erasure, or end-to-end integer multiplication. The checked arithmetic
is not a fresh proof of the five inherited premises.

## R6/02 funded literal changed word

`funded_replay.py` applies the separately developed R5 BIT literal interpreter
to the new chart-552 word `FUNDED-WORD.json.gz` (canonical SHA-256
`7006953f8d45f310f88825afa5254ea3cc6c46f7848cd229bb4b9e860198bfca`).
It independently rechecks both 680-row native orientations and complete
36-call caller bins; dropping either the output-138 repair or a required sink
XOR breaks both orientations. Signed paid bins change by `{1:+36,4:-36,5:+36}`
and productive bins do not change. The BIT margins at the requested trials
are approximately -71.651948302139 and -71.652333339349. Repriced from the
pinned R5 48-call rational receipt, the companion margins are approximately
+0.212262470163 and +0.211243929927. The rational receipt's full native
execution is not rerun in this round. Both literal directions discard 3,555
nonzero private values. No physical cleanup, changed stock or precision
tape, or kappa gain is demonstrated.

## R6/01 fixed-packet paired-pulse cuts

`all_pulse_replay.py` directly interprets the pinned original tape without
producer/vendor imports and independently checks all 32 named tuples from
the producer case list. It reconstructs the 537-dimensional sink basis and
537 independent sink target rows; projects every actually live receiver field
(including zeros) into the quotient by the old sink space; and checks all 94
resulting augmented receiver/sink intersection generators. All 32 have the
required zero determinant factor. The 104 total field occurrences include 10
outside-space quotient dimensions. A separate named check in
`pulse_case_replay.py` directly reproduces the 2287/3387 to 3266 obstruction
and rank 536 for input `x649`.

The 32 cases each assume the same arbitrary beta in two named original
arrivals, exactly one immediate direct sink replacement ingress, free XORs of
actual stock, and all other paid paths fixed. Different pulse clocks, distinct
betas, new stock or extra routes are not excluded. No construction or physical
erasure is implied.

## R6/12 four-depositor paper review and witness

`INDEPENDENT-R4-REVIEW.md` records the scope and proof snapshot. The reduced
structural checker `structural_r4.py` enumerates the r=4 equality-case chart
patterns: 759 patterns, 151 structurally capable of full high rank, and 662
pairwise distinct-chart extension checks, all passing. A mutation dropping the
single-chart gateway condition gives a countermodel. This is not an exhaustive
search of P104 networks or a word-bridge proof.

`independent_witness.py` independently validates the producer's exported
18-node four-low network. It checks the two #7852 Lean blob identities and
extracts their pinned labels and root codes; verifies all GF(2) chart, F/G/H
support, chronology, all 10,816 exact rational Gram entries and 5,824 odd
entries; and obtains T=8, E=B=0, D=56, sink rank 8, low rank 4, high-gather
rank 3 and terminal rank 4. Deleting the indicated relay breaks 1,462 odd
cells. This is one network; the constructor, relay variant, r=5..8 examples,
and Lean theorem were not independently replayed by this checker.

## R6/14 revised supplemental certificates

A concern was raised that a rank-one idempotent's column alone does not force
it to equal a coordinate projector; full matrix equations also imply the
transpose entries, and the producer revised its certificates to check both
orientations explicitly. `qzero-review/independent_certificates.py` independently
checks all 33 revised named certificates with integer arithmetic, including all
five required entries and a missing-row mutation. It confirms 31 linear and two
rank-one contradictions. `qzero-review/strengthen.py` is a local amended copy
of the producer's generator; its regenerated result byte-matches the revised
certificate. The checker assumes the stage-sum/clique lemmas and the SCAN case
census; those are not independently regenerated here. The result is mask-only,
not a HOST, caller, word-bridge, or kappa claim.

## Portable checks

CPython 3.12, standard library, unless the optional local certificate
regenerator `qzero-review/strengthen.py` is run (SymPy required):

```
sha256sum -c SHA256SUMS
python3 -IB funded_replay.py | cmp - funded-replay-result.json
python3 -IB pulse_case_replay.py | cmp - pulse-case-result.json
python3 -IB all_pulse_replay.py | cmp - all-pulse-result.json
python3 -IB structural_r4.py | cmp - structural-r4-result.json
python3 -IB independent_witness.py | cmp - independent-witness-result.json
python3 -IB qzero-review/independent_certificates.py | cmp - qzero-review/independent-certificates-result.json
python3 -IB finite-451/replay_451.py | cmp - finite-451/FRESH.json
```

The full outer consumer replay is intentionally preserved with its generated
output; to repeat it, make a temporary copy of `451-consumer`, remove that
copy's `clean-replay-output` directory, and run `python3 -IB clean_replay.py`
inside the copy. The source package carries its own notice and manifest. The
four-depositor proof snapshot and source fixtures retain the upstream P104
notices in `inputs/NOTICE-P104.md` and `inputs/LICENSE-7852`.
