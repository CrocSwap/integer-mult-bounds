# Finite transfer conditions for a higher P104 rate

**This is a numerical and algebraic handoff, not a qualified higher κ.** No
positive changed BIT word or new physical supplier is supplied. The 451-fold
compiler, owned erasure, cover, stock, precision and analytic-recovery
premises remain to be bound to any future candidate. The rational gate below
is freshly evaluated on the pinned existing 48-call histogram with
hypothetical binary caps; a complete application must be rerun with an
authenticated, completed changed supplier.

The inputs are [#7863 at `b3e4412fe01f07dc58305616fabf96345f49a781`](https://github.com/CrocSwap/integer-mult-bounds/pull/7863),
[#7911 at `4afc1ffbcde45da360e631a8634b1c86261ddc09`](https://github.com/CrocSwap/integer-mult-bounds/pull/7911),
and [#7973 at `ac3df5d5c8889f464f575e32dfea43714abf08ca`](https://github.com/CrocSwap/integer-mult-bounds/pull/7973).
The published #7973 archive SHA-256 is
`bffb02e833d8253c693ea3e679fdc1a737a5a45f81089255848d9ee9a7d3487d`;
the extracted receipt reproduces only the unchanged conditional value
`0.00387992804346`. The #7911 archive and its complete original manifest are
retained in `7911/`. Its baseline and source engine, and the extracted #7973
receipts, are authenticated by `price_transfer.py`.

## Exact separation test for an actual candidate

For raw trial C, let `t=1-C`, candidate target moment `T=T_t>0`, paid
moment `P=P_t`, and

```
gamma  = P_(t+13/50) / (11^(13/50) T)
lambda = 16^(17/50) T_(t-17/50) / T
D_v    = 2 gamma^v + lambda^v.
```

If `D_v<1`, the #7863 sufficient tensor test, with the candidate's actual
ratios, is equivalent to

```
M_new(C) = T-P > T D_v / (v (1-D_v)).                 (1)
```

The strict inequality also implies `P/T<1`. Equivalently, using the signed
change from the old complete profile,

```
Delta(C) > -M_old(C) + T_new D_new / (v (1-D_new)).   (2)
```

Use outward bounds: a lower bound for the left side and upper bounds for the
right. All `T_new`, `gamma_new`, `lambda_new`, changed productive bins and
changed paid bins must come from the actual full owner-qualified candidate.
The bound is a sufficient certificate for the named source moment test, not
for physical realization. A merely positive unshifted signed moment does not
by itself establish (1).

At the following raw examples the old complete signed balance is negative:

| Raw C | Old `M(C)` | Δ for (1) **if old T, gamma and lambda are hypothetically frozen** |
| --- | ---: | ---: |
| `0.0038799280461560083` | `−0.000000000770198055995903…` | `> 0.000000002709037162111599…` |
| `0.0038799290461550083` | `−0.00038512731981041999…` | `> 0.00038512925864983009…` |

The frozen values are not universal thresholds: changing the word may
change all three ratios. Exact directed intervals, including both target
rates themselves, are in [PRICE.json](PRICE.json). The old rational margins
remain separate; they cannot cancel a binary deficit.

## The decimal selector and a sufficient rate buffer

Let `K` be the desired exactly representable claim and let `g` be the
decimal selector tick. The source selector tests `K+7g` and needs an admitted
ordinary cap of at least `K+8g`. With seed `s=0.00385248`, `rho=1/250`,
uniform loss `e`, cover loss `d`, and `m` strict ordinary stages, put
`B=C−e−d`. The source envelopes imply

```
a_m < (1−rho^m) B + rho^m s.
C > e+d + (K+8g−rho^m s)/(1−rho^m)                  (3)
```

is necessary for this selector and count. The checked construction rounds
each stage to `floor(envelope/h)h−h`, with `h=10^-20`; each such rounding
loses less than `2h`. Summing the geometric losses gives a conservative
**sufficient rate-only** condition

```
C > e+d + (K+8g−rho^m s)/(1−rho^m) + 2h/(1−rho).   (4)
```

It assumes these are admissible ordinary stages; their physical
implementations, true moments and stock are still separate obligations.
The script independently verifies all actual strict stage inequalities for
the examples, so (4) is not used as a stand-in for them.

For `g=10^-18`, `e=10^-19`, `d=10^-20`, the relevant thresholds are:

| Claim | Stages above seed | Necessary C, strictly above | Conservative rounded-rate sufficient C, strictly above |
| --- | ---: | --- | --- |
| `0.003879928046156` | 6 | `0.003879928046156008222427197055009228…` | `0.003879928046156008242507518340149790…` |
| `0.003879928046156` | 7 | `0.003879928046156008110449708788220035…` | `0.003879928046156008130530030073360597…` |
| `0.003879929046155` | 6 | `0.003879929046155008222431293050913228…` | `0.003879929046155008242511614336053790…` |
| `0.003879929046155` | 7 | `0.003879929046155008110449725172203651…` | `0.003879929046155008130530046457344213…` |

The `K+8.3e-18` raw examples in the first table pass the six-stage rate
bound as well as the seven-stage bound. Their actual sixth admitted rates
are respectively `0.00387992804615600806` and
`0.00387992904615500806`, while stage five is below each target. This is six
stages **above the completed seed**; building the seed from a cold elementary
backend needs an additional funded stage. The preceding #7911 seven-stage
example remains valid. Other grid/loss combinations, including the original
larger losses, are compared in `PRICE.json`; a finer selector or different
loss must actually be implemented and checked.

## A bounded factor-count sensitivity, not a construction

At K, suppose only for algebraic sensitivity that the old `T`, `gamma` and
`lambda` are held fixed while a new positive signed margin `M` is postulated.
The directed source intervals give these minimal powers for the source
inequality; the immediately preceding power is checked to fail:

| Postulated `M` | Least power under frozen moments |
| ---: | ---: |
| `10^-12` | 576 |
| `10^-10` | 500 |
| `10^-9` | 462 |
| `10^-8` | 425 |
| `10^-6` | 350 |

This is a mathematical parameter interpolation. It does not assert that a
word with those independent quantities exists, that a fractional or free
edit is legal, or that any power other than 451 has the required new H,
target floor, chronology, stock or compiler. The unchanged word itself has
negative `M` at both targets; increasing v does not turn its `P/T>1` into a
valid certificate.

## Cover, seed and rational gate boundaries

For the new losses at the 451 source power, the checked uniform parameter is
`H=45160000000000000000000` with log power 60. The inherited large-prime
sufficient budget uses a newly frozen finite exclusion list and
`q > 2^75 N^5`. The alternative q=3 numerical test `9 < 2^floor(Hd)` also
passes, but it requires a new all-owner three-local route and its complete
nine-child charges. Neither test creates a prime or stock.

Under #7911's **conditional** m-stage stock-shape assumptions, six or seven
simultaneous debts give `log2 E ≥ 90682730923694779116474`; eight give
`log2 E ≥ 90682730923694779116475`. These are sufficient stock-size shapes,
not a proof that the new ledger obeys those hypotheses. An old seed's
nested reserve, or an actual cold seed, must be charged.

At each target, the program reprices the actual pinned rational histogram,
input lift, selector and 54 strict plus four functional source-gate
conditions for both the six- and seven-stage *hypothetical* caps. At the
six-stage cap, the rational signed margins at the tested rates are
`+0.212262470156216966…` and `+0.211243929919384555…`; both gates pass.
The source rational compiler parameter is
`H=184014000000000000000000`, with written log power 2381. The four exact
source-gate receipts are linked from `PRICE.json`. They are not a full
48-call application replay against a newly completed BIT supplier.

Upon a candidate, authenticate its word and owner namespace; independently
replay both orientations and the complete 36-call invoice; price its signed
change and all three candidate moment ratios; then establish target-floor,
slab, compiler, cover, stock, restoration, precision, erasure and consumer
contracts. Until then the first missing premise is an actual positive,
correctly charged BIT word and independently checked occurrence inventory.

## Reproduce

Python 3.10+ and the standard library, from this directory:

```
(cd 7911 && sha256sum -c SHA256SUMS)
python3 -I -B price_transfer.py > /tmp/p104-finite-price.json
cmp PRICE.json /tmp/p104-finite-price.json
python3 -I -B verify.py
```

The isolated replay regenerates the four gate receipts, compares them with
the saved bytes and rejects tampering with the pinned baseline, rational gate
and #7973 receipt. No network or application writes are performed.
