#!/usr/bin/env python3
"""Directed profile and conditional finite-transfer diagnostics, not a supplier proof."""
from collections import Counter
from fractions import Fraction as Q
from hashlib import sha256
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
import json
import sys

if not __debug__:
    raise SystemExit('use assertions: source gate requires them')
HERE=Path(__file__).resolve().parent
SRC=HERE/'7911/source-7863'
PINS={
    '7911/EXPECTED.json':'b99810b63ecce725db18c8bf3205a3e18b2262c036da03919a6c2659856e0053',
    '7911/source-7863/BASELINE.json':'a411390c2e21b289825a433f83a4903c75f64d102ff4cd2051b87e476c49e92a',
    '7911/source-7863/BIT-451.json':'538b785f93517b41229186e9070281d240f5d506f80a7e1ed705dd91c68f8749',
    '7911/source-7863/source-7830/review/independent.py':'a2366b60cb4cd535fbcbce2a834cdf2ed4b9daba3e7025c7403e6abcd598a7ca',
    '7911/source-7863/inputs/cache/source/research/p104-dual-supplier-lift/complex/supplier_gate.py':'3796b2e5a27f3caa142d16364154788e60d0099f1e24a8dcd028e4fbd35a84ca',
    'inputs/PR-7973-INDEPENDENT.json':'ba826926d913ba7826679332e650d23b7d0c7272a5503e8e7d65a55f00e3bcbe',
    'inputs/PR-7973-APPLICATION.json':'b38b7858943b0dd58617c1a0820105282d80f965c151ea947dac19c7a715bde7',
    'inputs/PR-7973-README.md':'b0bc0d83e3b460a1d7c3dfc2de56aafe8c6a51298efcf45343c74af35d6a9371',
}


def load(name,path):
    spec=spec_from_file_location(name,path);m=module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m


def decimal(x,n=42,upper=False):
    z=Q(x)*10**n
    v=-((-z.numerator)//z.denominator) if upper else z.numerator//z.denominator
    return ('-' if v<0 else '')+str(abs(v)//10**n)+'.'+str(abs(v)%10**n).zfill(n)


def interval(a,b,n=42):return [decimal(a,n),decimal(b,n,True)]
def cd(a,b):return -(-a//b)


for path,digest in PINS.items():
    if digest is not None:
        assert sha256((HERE/path).read_bytes()).hexdigest()==digest,path
prior=json.loads((HERE/'inputs/PR-7973-INDEPENDENT.json').read_bytes())
assert prior['status']=='PASS_ISOLATED_CONSUMER_REPLAY_AND_BYTE_COMPARE'
assert prior['claim']=='0.00387992804346' and prior['binary_receipt_sha256']==PINS['7911/source-7863/BIT-451.json']
assert prior['clean_application_sha256']==PINS['inputs/PR-7973-APPLICATION.json']
old=json.loads((SRC/'BASELINE.json').read_bytes())
hist=lambda obj:Counter({int(k):n for k,n in obj.items()})
bp,bt=hist(old['binary']['paid']),hist(old['binary']['targets'])
rp,rt=hist(old['rational']['paid']),hist(old['rational']['targets'])
assert (sum(bp.values()),sum(bt.values()),sum(rp.values()),sum(rt.values()))==(107460,20706,283152,52512)
r=load('p104_directed',SRC/'source-7830/review/independent.py')
gate=load('p104_gate',SRC/'inputs/cache/source/research/p104-dual-supplier-lift/complex/supplier_gate.py')
G=r.GRID
lower=lambda a:Q(a[0],G)
upper=lambda a:Q(a[1],G)
seed=Q('0.00385248');rho=Q(1,250);v=451
e,d,g=Q(1,10**19),Q(1,10**20),Q(1,10**18)


def bit_stats(c):
    t=1-c;target=r.moment(bt,t);paid=r.moment(bp,t);signed=r.sub(target,paid)
    gamma=r.quotient(r.moment(bp,t+Q(13,50)),r.mul(r.power(11,Q(13,50)),target))
    lam=r.quotient(r.mul(r.power(16,Q(17,50)),r.moment(bt,t-Q(17,50))),target)
    dl=2*lower(gamma)**v+lower(lam)**v
    dh=2*upper(gamma)**v+upper(lam)**v
    assert 0<dl<=dh<1 and lower(target)>0
    # Conditional diagnostic only, with T, gamma, lambda frozen at old values.
    extra_lo=lower(target)*dl/(v*(1-dl));extra_hi=upper(target)*dh/(v*(1-dh))
    return {'signed':interval(lower(signed),upper(signed)),
            'raw_positive_required_delta':interval(-upper(signed),-lower(signed)),
            'frozen_extra_required_signed_margin':interval(extra_lo,extra_hi),
            'frozen_required_delta':interval(-upper(signed)+extra_lo,-lower(signed)+extra_hi),
            'target_moment':interval(lower(target),upper(target)),
            'gamma':interval(lower(gamma),upper(gamma)),
            'lambda':interval(lower(lam),upper(lam))},target,gamma,lam


def threshold(target,digits,uniform,cover,stages=7):
    tick=Q(1,10**digits)
    claim=cd(target.numerator*tick.denominator,target.denominator)*tick
    cap=claim+8*tick
    raw=uniform+cover+(cap-rho**stages*seed)/(1-rho**stages)
    # Each stage is floor(envelope/h)*h-h, so its strict rounding loss is
    # less than 2h. Sum the seven (or m) geometric losses exactly.
    h=Q(1,10**20)
    safe=raw+2*h/(1-rho)
    return {'claim':decimal(claim,20),'minimum_cap':decimal(cap,20),
            'necessary_raw_interval':interval(raw,raw,42),'necessary_raw_minus_target':interval(raw-target,raw-target,42),
            'strict_rounded_rate_sufficient_raw':interval(safe,safe,42),'stages_above_seed':stages,
            'scope':'necessary ideal envelope and conservative sufficient rounded rate; physical supplier remains unproved'}


def stage_example(target):
    raw=target+Q(83,10**19);covered=raw-e-d;previous=seed;rows=[];rates=[]
    cold_envelope=(1-rho)*covered
    cold=Q((cold_envelope.numerator*10**20)//cold_envelope.denominator-1,10**20)
    assert seed<cold<cold_envelope
    for _ in range(7):
        envelope=(1-rho)*covered+rho*previous
        next_=Q((envelope.numerator*10**20)//envelope.denominator-1,10**20)
        assert previous<next_<envelope<covered<rho<1-envelope
        rows.append({'rate':decimal(next_,20),'strict_gap':str(envelope-next_)})
        rates.append(next_)
        previous=next_
    assert rates[4]<target and rates[5]>=target+8*g and rates[6]>=target+8*g
    # The stated geometric rounding bound is sufficient for six and seven
    # steps here; all actual stage monotonicity and strict gaps are tested above.
    for m in (6,7):
        safe=e+d+(target+8*g-rho**m*seed)/(1-rho**m)+2*Q(1,10**20)/(1-rho)
        assert raw>safe and rates[m-1]>target+8*g
    ambient=r.power(134,v*raw);eta=r.quotient(r.enclose(1-raw),ambient)
    assert Q(13,15)**60<lower(eta)<=upper(eta)<=Q(13,15)**59 and upper(ambient)<2**60
    H=45160000000000000000000
    assert (H+1)**60<2**(H*e//1) and 64*4*10**20<2**75
    assert Q(64,2**75)<d/4<=Q(64,2**74)
    assert 9<2**(H*d//1)
    # Evaluate the pinned source rational gate, with the finer selector and a
    # hypothetical admitted binary cap. This is not a full changed application.
    lo,hi=Q('0.003880136444745846'),Q('0.003880136444745847')
    gate_results={}
    for m in (6,7):
        cap=rates[m-1]
        claim_tick=Q((cap*10**18).numerator//(cap*10**18).denominator-8,10**18)
        assert claim_tick==target
        gate.BIT_PIN=str(cap)
        result=gate.gate({'T':dict(rt),'P':dict(rp)},target,target+7*g,lo,hi,cap)
        assert result['outer']['strict_count']==54 and result['outer']['functional_count']==4
        gatepath=HERE/('RATIONAL-GATE-'+decimal(target,15)+'-m'+str(m)+'.json')
        gatepath.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        h=int(result['H']);common_bits=(856*1920*153**1920*(h+1)**2).bit_length()
        assert common_bits<h
        gate_results[str(m)]={'cap':decimal(cap,20),'cap_headroom':str(cap-(target+7*g)),
            'outer':result['outer'],'H':result['H'],'minimum_log_power':result['minimum_log_power'],
            'written_log_power':result['written_log_power'],'common_root_argument_bits':common_bits,
            'full_receipt':gatepath.name}
    rational_at_k=r.sub(r.moment(rt,1-target),r.moment(rp,1-target))
    rational_at_test=r.sub(r.moment(rt,1-(target+7*g)),r.moment(rp,1-(target+7*g)))
    assert lower(rational_at_k)>0 and lower(rational_at_test)>0
    # Inherited ternary stock-shape paper bound only; the physical ledger must prove its hypotheses.
    stock={}
    for m in (6,7,8):
        B=(36*m+2).bit_length()
        threshold=cd(250*(2*H+B),249)
        stock[str(m)]={'power_budget':B,'conditional_log2_E':str(threshold)}
    return {'raw':decimal(raw,22),'covered':decimal(covered,22),
            'seed':str(seed),'rho':str(rho),'uniform_loss':str(e),'cover_loss':str(d),'outer_grid':str(g),
            'cold_seed_arithmetic_only':{'cold_stage_rate':decimal(cold,20),
               'strictly_above_reused_seed':str(cold-seed),
               'scope':'one hypothetical stage from zero, prior to six stages; physical implementation and full ledger unproved'},
            'stages':rows,'minimum_stages_above_seed_for_this_example':6,
            'selected_claim':decimal(target,18),'tested':decimal(target+7*g,18),
            'uniform_H':H,'uniform_grid_j':int(H*e),'uniform_log_power':60,
            'large_q_sufficient_lower_bound':'q > 2^75 N^5 after finite exclusions',
            'ternary_nine_child_arithmetic_only':'9 < 2^floor(H*d)',
            'stock_shape_conditional':stock,
            'rational_gate':{'scope':'pinned source finite gate with hypothetical BIT cap; not rebound full application',
               'tested_rational_margin':interval(lower(rational_at_test),upper(rational_at_test)),
               'claim_rational_margin':interval(lower(rational_at_k),upper(rational_at_k)),
               'stage_options':gate_results}}


def pow_bound(value,n,up):
    out=G
    while n:
        if n&1:out=cd(out*value,G) if up else out*value//G
        n//=2
        if n:value=cd(value*value,G) if up else value*value//G
    return out


def finite_factor_tradeoff(target_moment,gamma,lam):
    # Controlled hypothetical only: fix the old T/gamma/lambda and postulate
    # a new positive signed margin. This does not claim realizable histograms.
    assert 0<gamma[0]<=gamma[1]<G and 0<lam[0]<=lam[1]<G
    samples=[]
    for exponent in (12,10,9,8,6):
        margin=Q(1,10**exponent)
        min_mu=margin/upper(target_moment)
        max_mu=margin/lower(target_moment)
        def pass_upper(n):
            D=2*pow_bound(gamma[1],n,True)+pow_bound(lam[1],n,True)
            return D<G and n*min_mu>Q(D,G-D)
        def fail_lower(n):
            D=2*pow_bound(gamma[0],n,False)+pow_bound(lam[0],n,False)
            return D>=G or n*max_mu<=Q(D,G-D)
        lo,hi=0,1
        while not pass_upper(hi):lo,hi=hi,2*hi
        assert hi<=4096
        while hi-lo>1:
            mid=(lo+hi)//2
            if pass_upper(mid):hi=mid
            else:lo=mid
        assert pass_upper(hi) and fail_lower(hi-1)
        samples.append({'assumed_new_signed_margin':str(margin),'minimum_factor_count_for_frozen_moments':hi,
                        'preceding_factor_proven_fails':hi-1})
    return samples


def main():
    cases={}
    for name,target in [('K',Q('0.003879928046156')),('near',Q('0.003879929046155'))]:
        raw=target+Q(83,10**19)
        at_target,t,gam,lam=bit_stats(target)
        at_raw,_,_,_=bit_stats(raw)
        old_uniform,old_cover=Q(1,400000000000),Q(1,10**13)
        table={f'{digits}_{kind}':threshold(target,digits,ue,ud)
               for kind,ue,ud in [('old',old_uniform,old_cover),('new',e,d)] for digits in (14,15,18,19,20)}
        table['18_new_six_stages']=threshold(target,18,e,d,6)
        ex=stage_example(target)
        strict_threshold=e+d+(target+8*g-rho**7*seed)/(1-rho**7)
        assert raw>strict_threshold
        cases[name]={'target':decimal(target,15),'unchanged_at_target':at_target,
                     'unchanged_at_example_raw':at_raw,'rate_thresholds':table,
                     'finite_example':ex,
                     'frozen_moment_factor_tradeoffs':finite_factor_tradeoff(t,gam,lam)}
    out={'status':'PASS_CONDITIONAL_FINITE_ARITHMETIC_NO_POSITIVE_WORD',
         'pinned_sources':{'7863':'b3e4412fe01f07dc58305616fabf96345f49a781',
                           '7911':'4afc1ffbcde45da360e631a8634b1c86261ddc09',
                           '7973':'ac3df5d5c8889f464f575e32dfea43714abf08ca'},
         'formula':'D=2*gamma^v+lambda^v, 0<=D<1: (T-P)>T*D/(v*(1-D)); use candidate values',
         'frozen_tradeoff_scope':'hypothetical independent changes of signed margin while baseline T/gamma/lambda are held; no realizable word implied',
         'prior_7973_claim':prior['claim'],'cases':cases,
         'limitations':['no positive changed word or paid occurrence','no candidate physical supplier or complete 451 tensor',
                        'q-prime or ternary all-owner cover and staged stock not instantiated',
                        'fine-selector gate is not full changed 48-call application',
                        'no new qualified kappa']}
    print(json.dumps(out,sort_keys=True,indent=2))


if __name__=='__main__':main()
