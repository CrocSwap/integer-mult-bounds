# Source, license, and reproducibility

The four files under `source/data/q0_callers/` are byte-for-byte copies from [CrocSwap/integer-mult-bounds pull request #7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869), commit `06c207a9feb3994a4b987dc3010657b6e85b7956`, directory `research/p104-lowerbound-guidance/data/q0_callers/`. The upstream archive and the repository use Apache-2.0; the license and upstream notice are preserved as `LICENSE` and `UPSTREAM-NOTICE.md`. New research scripts, words, and notes are offered under the same Apache-2.0 license for the requested upstream contribution. No upstream file in `source/` was edited.

Source file pins:

| File | SHA-256 |
|---|---|
| `source/data/q0_callers/check.py` | `2233655e29abce6ad1282e6da52ea70a77e7cb2f71b331f78834c165955cd504` |
| `source/data/q0_callers/caller_C1.json` | `c708c66aa828bf2a494608555222d9f4d504c220451cd220045471f74ac17a3d` |
| `source/data/q0_callers/ml_k4.json` | `9ee9f80a381f1bf1a90810c307908feb766d700132e0035392b112a34d0cda6e` |
| `source/data/q0_callers/ml_k5.json` | `12d69d15e3228550a96c68bd0619f1afa1d5f3359236fe71eed33d915b495ffc` |

All bundle files except `MANIFEST.sha256` itself are covered by `MANIFEST.sha256`. `separator_word.json` and `separator_jb_word.json` are new generated words; their event programs contain unmodified C1 subsequences plus the listed gadget and stage relabeling. The C1 subsequences are not represented as independent new proofs of the C1 result. `independent_verify.py` and `independent_support.py` are separate SymPy implementations and do not import the upstream checker or the matching implementation. The former tests polynomial endpoints at all four q values; the latter reconstructs exact prefixes and checks the strict obstruction. The original #7869 checker is also run, so the endpoints are tested twice by different implementations. Four distinct roots are sufficient because `q^4-1` splits into distinct factors over Q(i).

The reproducible controls and separator are finite evidence. The scope theorem is an on-paper argument in `README.md`; it is not presented as a Lean result. The separator refutes a strong strict-support global attribution claim in a non-tight legal caller and does not refute the original mask-only conjecture or the tight RC2 case.
