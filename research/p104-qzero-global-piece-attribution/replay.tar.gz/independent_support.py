#!/usr/bin/env python3
"""Independent SymPy prefix/support replay and global strict impossibility."""
import itertools,json
from pathlib import Path
import sympy as s
C=json.loads(Path('separator_jb_word.json').read_text()); n=C['roles']; k=C['stages']
mask=[{t+1 for t,b in enumerate(d[2:]) if b} for d in C['diagonal']]
P=s.eye(n); events=[]; hostdet=[]
def inc(j,tag,reg,S):
    I=P.inv(); v=I[:,reg]; w=P[reg,:].T
    assert (w.T*v)[0]==1
    events.append({'key':f'{j}:{tag}','S':set(S),'v':v,'w':w,
                   'domain':{r for r in range(n) if set(S)<=mask[r] and v[r]!=0 and w[r]!=0}})
for j,e in enumerate(C['events']):
    op=e[0]; H=s.eye(n)
    if op=='ADD': H[e[1],e[2]]=s.Rational(e[3])
    elif op=='SCALE': H[e[1],e[1]]=s.Rational(e[2])
    elif op in ('IDLE_ONE','LAMBDA'): pass
    elif op=='HOST':
        t,x,y,a,b=e[1],e[2],e[3],s.Rational(e[4]),s.Rational(e[5])
        H[x,x]=1; H[x,y]=a; H[y,x]=b; H[y,y]=1+a*b
        before=P; P=H*P; afterinv=P.inv()
        A=s.Matrix.hstack((-2*a)*afterinv[:,x],(-2*b)*afterinv[:,y])
        B=s.Matrix.hstack(before[y,:].T,before[x,:].T)
        hostdet.append(s.det(2*s.eye(2)+B.T*A))
        inc(j,'host_first',x,{t}); inc(j,'host_second',y,{t}); continue
    else: raise ValueError(op)
    P=H*P
    if op=='IDLE_ONE': inc(j,'idle',e[1],set(e[2]))
assert P==s.eye(n)
assert hostdet==list(map(s.Rational,[2,-4,-5,2,-4,-5]))
for t in range(1,k+1):
    ids=[i for i,e in enumerate(events) if t in e['S']]; roles=[r for r in range(n) if t in mask[r]]
    assert len(ids)==len(roles)
    for i in ids:
        assert all(events[i]['v'][r]==events[i]['w'][r]==0 for r in range(n) if r not in roles)
        for j in ids: assert (events[i]['w'].T*events[j]['v'])[0]==int(i==j)

def match(ids,used):
    ids=sorted(ids,key=lambda i:len(events[i]['domain']-used))
    def run(p,occupied):
        if p==len(ids): return True
        for r in sorted(events[ids[p]]['domain']-occupied):
            if run(p+1,occupied|{r}): return True
        return False
    return run(0,set(used))
for t in range(1,k+1): assert match([i for i,e in enumerate(events) if t in e['S']],set())
multi=[i for i,e in enumerate(events) if len(e['S'])>1]; assert len(multi)==2
poss=[]
for r1,r2 in itertools.product(*(sorted(events[i]['domain']) for i in multi)):
    if r1==r2:continue
    ok=[]
    for t in range(4,7):
        singles=[i for i,e in enumerate(events) if e['S']=={t}]
        ok.append(match(singles,{r1,r2}))
    assert not all(ok)
    poss.append(((r1,r2),ok))
assert len(poss)==5
print('PASS independent exact supports, all 6 stage local strict matchings, and K-block determinants',hostdet)
print('PASS independent global strict separator: all 5 allowed multi-role pairs fail:',poss)
