#!/usr/bin/env python3
"""Search rational rank-one decompositions for a true global strict separator."""
import itertools, json, random
from pathlib import Path
import sympy as sp

rng=random.Random(786915)
# Two columns of an SL(2) change of singleton basis. Duplicates collapse.
Ts=[v for v in itertools.product(range(-2,3),repeat=4) if v[0]*v[3]-v[1]*v[2]]
pairs=list(itertools.combinations(range(4),2))

for iteration in range(30000):
    A=sp.Matrix(4,4,[rng.choice((-2,-1,0,0,1,2)) for _ in range(16)])
    det=int(A.det())
    if not det: continue
    W=A.adjugate().T
    a=[[int(A[r,c]) for c in range(4)] for r in range(4)]
    w=[[int(W[r,c]) for c in range(4)] for r in range(4)]
    m1={r for r in range(4) if a[r][0]*w[r][0]}
    m2={r for r in range(4) if a[r][1]*w[r][1]}
    allowed={i for i,(x,y) in enumerate(pairs) if (x in m1 and y in m2) or (y in m1 and x in m2)}
    if len(allowed)<2: continue
    patterns={}
    for b,c,d,e in Ts: # T=[[b,c],[d,e]]
        d1=set(); d2=set()
        for r in range(4):
            if (b*a[r][2]+d*a[r][3])*(e*w[r][2]-c*w[r][3]): d1.add(r)
            if (c*a[r][2]+e*a[r][3])*(-d*w[r][2]+b*w[r][3]): d2.add(r)
        valid=set()
        for i in allowed:
            left=set(range(4))-set(pairs[i]); x,y=tuple(left)
            if (x in d1 and y in d2) or (y in d1 and x in d2): valid.add(i)
        if valid: patterns.setdefault(frozenset(valid), (b,c,d,e))
    pats=list(patterns)
    for pp in itertools.combinations(pats,3):
        if not (pp[0]&pp[1]&pp[2]):
            out={'found':True,'iterations':iteration+1,'A':a,'det':det,
                 'multi_domains':[sorted(m1),sorted(m2)],'possible_pairs':[list(p) for p in pairs],
                 'stage_bases':[list(patterns[p]) for p in pp],
                 'stage_feasible_multi_role_pairs':[[list(pairs[i]) for i in sorted(p)] for p in pp]}
            Path('GADGET_FOUND.json').write_text(json.dumps(out,indent=2)+'\n')
            print(json.dumps(out,indent=2),flush=True); quit()
    if iteration%1000==0: print('tested',iteration,'patterns',len(pats),flush=True)
print('none')
