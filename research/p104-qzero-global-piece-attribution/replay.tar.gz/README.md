# Q0 caller attribution: global controls, a scoped theorem, and a strict separator

Research record, 2026-11-21. Source: #7869, commit `06c207a9feb3994a4b987dc3010657b6e85b7956`, `research/p104-lowerbound-guidance`. #7879's event-indexed/per-stage normalization does not itself establish a globally consistent event-to-role attribution. This record does not prove or refute the general **mask-only** attribution conjecture and does not change any claimed bound.

## Precise question and exact reduction

An incidence event `e` has a nonempty set of stages `S_e`. A target role `r` has a squarefree D-mask `M_r`. A global mask-only attribution assigns **one role to each event**, with `S_e ⊆ M_r`, and the sets assigned to each role partition its mask. A **strict** attribution additionally requires both `v_e(r)` and `w_e(r)` to be nonzero at the same role, where at q=1, D=1, `v_e=P_e^{-1} e_reg` and `w_e^T=e_reg^T P_e`. Host contacts are the two singleton idle events immediately after the host, and P is the exact base prefix at that point. Strict support is an extra property; the event-indexed RC2 use and the original mask-only attribution do not require it.

For either choice of domains, an exact reduction holds: enumerate one candidate role for each multi-stage event, requiring events placed on one role to have disjoint stage sets. For each such choice and every stage t, build the bipartite graph between singleton t-events and the still-free t-slots of roles, using the same domains. A global attribution exists **if and only if** one multi-event assignment leaves a perfect matching at every stage. Necessity restricts a global assignment. Sufficiency joins the per-stage singleton matchings because singleton events occur at exactly one stage. `attribution.py` carries out the full finite enumeration and exact matching without a time limit; it does not confuse separate stage matchings with a global solution.

## Real #7869 controls

Both control words pass four-root replay at q=1,-1,i,-i with symbolic D, exact rational prefix/inverse reconstruction, every stage's incidence cardinality, support outside the mask being zero, and `w_e^T v_f=δ_ef` for events sharing a stage. Every returned global witness is checked event-by-event and role-by-role.

| Word | Multi-stage events | Mask-only complete choices, completable | Strict complete choices, completable |
|---|---|---:|---:|
| `ml_k4` | two `{3,4}` | 30/30 | 7/7 |
| `ml_k5` | two `{3,4,5}` and two `{4,5}` | 900/900 | 49/49 |

All possible multi-event role assignments satisfying their own eligibility and mutual non-overlap are included in these denominators; residual singleton matchings are then tested jointly. Thus k5 includes genuinely intersecting, unequal multi-stage masks. `RESULT.json` records source SHA-256, exact support values, and one full witness for each case. Stages are 1-indexed; roles and JSON source-event positions are 0-indexed.

## Sufficient central-projector theorem for mask-only attribution

**Theorem.** Take a legal caller word with squarefree target masks. At q=1,D=1 let each nonempty incidence event have the rank-one idempotent `p_e=v_e w_e^T`. If every multi-stage event projector commutes with **every** incidence-event projector, then the word has a globally consistent mask-only attribution.

**Proof.** Move the base q=1,D=1 prefix matrices through the word. The endpoint at q=1 is the diagonal polynomial matrix

`F(D) = product_e [I + (D^{S_e}-1) p_e] = diag(D^{M_r})`.

The factors retain their event order; no global commutativity is assumed. Fix a multi-stage projector p. By hypothesis p commutes with every factor and therefore with F. Since the diagonal monomials are independent, p has no entries between roles of distinct masks. As p is rank one, all its support is in one equal-mask block, say M.

Two commuting rank-one idempotents are either identical or have zero products both ways: if their product is nonzero their images coincide, and commutativity then forces equality. Thus, on the image of p, every factor whose projector differs from p acts as the identity, and every factor with projector p acts by `D^{S_e}`. Since F acts there as `D^M`, squarefreeness implies that the masks of **all** events with projector p are pairwise disjoint and partition M.

Distinct multi-stage projectors commute and have mutually independent images. For a fixed M, there are at most as many such distinct projectors as roles with mask M. Assign each such projector to a distinct role in that mask block, and assign **all** events having that projector to that role. Each selected role's entire mask is now partitioned. Every unassigned event is a singleton. Equating the powers of each D_t in `det F(D)` gives equal counts of t-events and roles containing t; after removing the assigned full partitions, the remaining singleton t-events and remaining t-role slots still have equal counts. Match them arbitrarily stage by stage. This gives the required global attribution. □

This is a sufficient condition, not a general proof. It does not require all singleton projectors to commute. `verify_central.py` checks a non-vacuous q-free legal gadget: its two multi-event projectors commute with all eight event projectors, while 12 unordered singleton pairs do not commute. The theorem predicts its mask-only global attribution. The gadget has even q-targets and no HOST; it illustrates the theorem rather than the tight odd-target caller branch. The real `ml_k4` and `ml_k5` controls are not covered: their respective multi-projectors fail to commute with 6, or with 6/10, other exact incidence projectors.

## Legal strict separator, including six genuine HOSTs

`separator_jb_word.json` is generated from the rational gadget and two copies of the #7869 `caller_C1` word, with stage labels reordered to actual host time order. It has n=8 roles, k=6 stages, one type-B host per stage, odd q-targets, Q=0, and degree at least 2 for every role. At the six hosts the exact 2-by-2 K-block determinants are `2,-4,-5,2,-4,-5` in order; for host coefficients a,b this determinant is `4(1+ab)`. Full four-q symbolic-D replay passes both #7869's checker and the independent SymPy event replay in `independent_verify.py`. `independent_support.py` independently reconstructs every prefix with SymPy, checks the six K-block determinants and local matchings, and verifies that all five global strict choices fail. The construction respects q, D, role, and event semantics; it is not a matrix-support toy masquerading as a caller.

It has two events with the same multi-mask `{4,5,6}`. Exact strict eligible-role sets for the important eight gadget incidences are:

| Source event | Stage set | Roles with both v and w nonzero |
|---|---|---|
| 14 | {4,5,6} | {0,1,3} |
| 43 | {4,5,6} | {0,2} |
| 70 | {5} | {0,1,2,3} |
| 97 | {5} | {0,1} |
| 125 | {6} | {0,1,2,3} |
| 153 | {6} | {0,2} |
| 180 | {4} | {1,2,3} |
| 209 | {4} | {3} |

The other four roles have zero strict support for these eight events. For the first two events, the only possible ordered role pairs and their extension outcomes are:

| Roles for 14,43 | Stage 4 | Stage 5 | Stage 6 |
|---|---|---|---|
| (0,2) | yes | yes | **no** |
| (1,0) | yes | **no** | yes |
| (1,2) | **no** | yes | yes |
| (3,0) | **no** | yes | yes |
| (3,2) | **no** | yes | yes |

Stage 4 forces event 209 onto role 3; its other singleton event then blocks the last three pairs. Stage 5 blocks (1,0) through event 97, and stage 6 blocks (0,2) through event 153. Therefore no pair completes globally, although **every stage separately has a strict matching**. A global mask-only attribution does exist; the complete witness is in `SEPARATOR_JB.json`. This is a real separator of stagewise strict matching from global strict matching, **not** a counterexample to global mask-only attribution.

**Boundary.** The word is not tight: `n+2=10 < 2k=12`. It therefore does not settle whether strict or mask-only attribution exists under the tight RC2 hypothesis, even though it has ordered type-B hosts, odd targets, Q=0, degree≥2, and nonzero host K-blocks. The general mask-only bridge and the tight branch remain open.

## Reproduction

Run from this directory with Python 3; `independent_verify.py` additionally needs SymPy. The four required upstream files are bundled under `source/`; `P104_GUIDANCE_SOURCE` can instead point to another copy of the #7869 `research/p104-lowerbound-guidance` directory. Run `python3 verify.py` for the manifest check and complete replay in a temporary directory, or run the commands below from this directory.

```sh
python3 attribution.py ml_k4 ml_k5 --out RESULT.json
python3 make_separator.py
python3 make_jb_separator.py
python3 verify_central.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 independent_verify.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 independent_support.py
```

Input SHA-256: `check.py` `2233655e29abce6ad1282e6da52ea70a77e7cb2f71b331f78834c165955cd504`; `caller_C1.json` `c708c66aa828bf2a494608555222d9f4d504c220451cd220045471f74ac17a3d`; `ml_k4.json` `9ee9f80a381f1bf1a90810c307908feb766d700132e0035392b112a34d0cda6e`; `ml_k5.json` `12d69d15e3228550a96c68bd0619f1afa1d5f3359236fe71eed33d915b495ffc`. Generated `separator_jb_word.json` SHA-256: `b905400179a5d4a6b1864e81d641e05c3eebca8a9369abc4f21bee577bddf3d5`.
