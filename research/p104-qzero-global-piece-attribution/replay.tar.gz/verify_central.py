#!/usr/bin/env python3
"""Verify the central-multi-projector theorem on the rational gadget."""
import json
from pathlib import Path
import attribution as at
original=json.loads(Path('separator_word.json').read_text())
gadget=[]
for e in original['events'][:226]:
    f=e[:]
    if f[0]=='IDLE_ONE': f[2]=[x-3 for x in f[2]]
    gadget.append(f)
C={'schema':'central-projector q-free gadget','roles':4,'stages':3,
   'events':gadget,'diagonal':[[0,0,1,1,1] for _ in range(4)]}
assert at.q0check.legal(C)==(True,True)
masks,ev=at.capture(C)
def same(a,b):
    return all(a['v'][i]*a['w'][j]==b['v'][i]*b['w'][j] for i in range(4) for j in range(4))
def commute(a,b):
    ab=at.dot(a['w'],b['v']); ba=at.dot(b['w'],a['v'])
    return all(a['v'][i]*ab*b['w'][j]==b['v'][i]*ba*a['w'][j]
               for i in range(4) for j in range(4))
multi=[e for e in ev if len(e['S'])>1]
assert all(commute(x,y) for x in multi for y in ev)
noncomm=sum(not commute(ev[i],ev[j]) for i in range(len(ev)) for j in range(i+1,len(ev)))
assert noncomm>0 # the theorem is broader than pairwise commuting ALL projectors
for strict in (False,True):
    dom,mi,local,stats,wit=at.solve(ev,masks,3,strict)
    assert all(x is not None for x in local.values())
    assert (wit is not None)==(not strict)
    print('strict' if strict else 'mask-only', 'local=yes',
          'global=',wit is not None,'stats=',stats)
print('central multi projectors:',len(multi),'all commute with all',len(ev),'incidences;',
      'but',noncomm,'unordered singleton pairs do not commute')
Path('central_gadget_word.json').write_text(json.dumps(C,indent=2)+'\n')
