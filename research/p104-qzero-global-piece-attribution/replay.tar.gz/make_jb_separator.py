#!/usr/bin/env python3
"""Strengthen the legal strict separator with a type-B HOST at every stage.

Direct-sum C1 (on four fresh roles) into stages 4--6 of separator_word.
The original rational gadget uses only roles 0--3, while the extra C1 HOST
contacts use roles 4--7, so the strict obstruction remains. This is still
non-tight: n=8, k=6 and n+2<2k. All computations use exact rationals.
"""
import hashlib, json
from fractions import Fraction as F
from pathlib import Path
import attribution as at
base=json.loads(Path('separator_word.json').read_text())
c1_path=at.SRC/'data/q0_callers/caller_C1.json'; c1=json.loads(c1_path.read_text())
def shift(e):
    f=e[:]; op=f[0]
    if op=='ADD': f[1]+=4; f[2]+=4
    elif op in ('SCALE','LAMBDA'): f[1]+=4
    elif op=='IDLE_ONE': f[1]+=4; f[2]=[t+3 for t in f[2]]
    elif op=='HOST': f[1]+=3; f[2]+=4; f[3]+=4
    else: raise ValueError(op)
    return f
C=base; C['roles']=8
C['events'] += [shift(e) for e in c1['events']]
C['diagonal'] += [dg[:2]+[0,0,0]+dg[2:] for dg in c1['diagonal']]
# Relabel stage symbols by actual HOST time order, preserving all words.
stage_map={3:1, 1:2, 2:3, 6:4, 4:5, 5:6}
for e in C['events']:
    if e[0]=='HOST': e[1]=stage_map[e[1]]
    elif e[0]=='IDLE_ONE': e[2]=[stage_map[t] for t in e[2]]
for dg in C['diagonal']:
    before=dg[2:]; after=[0]*6
    for old,new in stage_map.items(): after[new-1]=before[old-1]
    dg[2:]=after
C['schema']='JB Q0 strict attribution separator: rational gadget and two C1 blocks'
path=Path('separator_jb_word.json'); path.write_text(json.dumps(C,indent=2)+'\n')
legal,wf=at.q0check.legal(C); assert legal and wf
masks,ev=at.capture(C)
hosts=[(j,e) for j,e in enumerate(C['events']) if e[0]=='HOST']
assert [e[1] for _,e in hosts]==[1,2,3,4,5,6]
# For HOST(s,t,a,b) the two-column K block has det 4(1+ab).
host_dets=[str(4*(1+F(e[4])*F(e[5]))) for _,e in hosts]
assert all(F(d) for d in host_dets)
assert all(sum(d[2:])>=2 and d[0]%2==1 for d in C['diagonal'])
result={'word_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'n':8,'k':6,
        'legal_4q_symbolic_D':legal,'well_formed_hosts':wf,
        'source_C1_sha256':hashlib.sha256(c1_path.read_bytes()).hexdigest(),
        'Q_odd_thin_events':0,'host_count':len(hosts),
        'host_stages':[e[1] for _,e in hosts], 'K_block_determinants':host_dets,
        'event_count':len(C['events']),'incidences':len(ev),
        'masks':[sorted(m) for m in masks],
        'qualifications':'All 6 stage HOSTs type B with nonzero K-block determinants; n+2=10 < 2k=12, outside tight RC2 branch.',
        'solutions':{}}
for strict in (False,True):
    dom,multi,loc,stats,wit=at.solve(ev,masks,6,strict)
    target={'all_stage_local_matchings_exist':all(x is not None for x in loc.values()),
            'local_matchings':{str(t):[at.ser(ev[i],r) for i,r in m.items()] if m is not None else None
                               for t,m in loc.items()},
            'multi_events':[{'event':ev[i]['key'],'stages':sorted(ev[i]['S']),'domain':dom[i]} for i in multi],
            'stats':stats,'global_attribution_exists':wit is not None}
    if wit is not None: target['global_witness']=[at.ser(e,wit[i]) for i,e in enumerate(ev)]
    result['solutions']['strict' if strict else 'mask_only']=target
assert result['solutions']['strict']['all_stage_local_matchings_exist']
assert not result['solutions']['strict']['global_attribution_exists']
assert result['solutions']['mask_only']['global_attribution_exists']
Path('SEPARATOR_JB.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='solutions'},indent=2))
for typ in ('mask_only','strict'):
    x=result['solutions'][typ]; print(typ,'local',x['all_stage_local_matchings_exist'],
          'global',x['global_attribution_exists'],'multis',x['multi_events'],'stats',x['stats'])
