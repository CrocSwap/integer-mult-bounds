#!/usr/bin/env python3
"""Verify the frozen manifest and regenerate every result in a temporary directory."""
import hashlib, os, subprocess, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parent

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest={}
for line in (root/'MANIFEST.sha256').read_text().splitlines():
    sha,name=line.split('  ',1); assert name and not name.startswith('/')
    assert name not in manifest
    manifest[name]=sha
actual={p.relative_to(root).as_posix() for p in root.rglob('*')
        if p.is_file() and p.name!='MANIFEST.sha256' and '__pycache__' not in p.parts}
assert actual==set(manifest), ('manifest file list mismatch',sorted(actual^set(manifest)))
for name,sha in manifest.items(): assert digest(root/name)==sha,('checksum mismatch',name)
print('PASS frozen manifest:',len(manifest),'files',flush=True)
try:
    import sympy
except ImportError:
    raise SystemExit('The independent replay requires SymPy; install requirements.txt.')
print('Python',sys.version.split()[0],'; SymPy',sympy.__version__,flush=True)
env=os.environ.copy(); env['P104_GUIDANCE_SOURCE']=str(root/'source')
env['PYTHONDONTWRITEBYTECODE']='1'; env['OPENBLAS_NUM_THREADS']='1'; env['OMP_NUM_THREADS']='1'
with tempfile.TemporaryDirectory(prefix='q0-attribution-verify-') as td:
    work=Path(td)
    def run(script,*args):
        print('\nRUN',script,*args,flush=True)
        subprocess.run([sys.executable,str(root/script),*args],cwd=work,env=env,check=True)
    def compare(*names):
        for name in names:
            assert digest(work/name)==digest(root/name),('regeneration mismatch',name)
            print('PASS exact regeneration:',name,flush=True)
    run('attribution.py','ml_k4','ml_k5','--out','RESULT.json'); compare('RESULT.json')
    run('make_separator.py'); compare('separator_word.json','SEPARATOR.json')
    run('make_jb_separator.py'); compare('separator_jb_word.json','SEPARATOR_JB.json')
    run('verify_central.py'); compare('central_gadget_word.json')
    run('independent_verify.py')
    run('independent_support.py')
print('\nPASS all frozen evidence and independent checks',flush=True)
