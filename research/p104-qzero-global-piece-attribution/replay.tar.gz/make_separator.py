#!/usr/bin/env python3
"""Construct and exactly verify a 4-q legal Q=0 strict-attribution separator.

The gadget's first two projectors have S={4,5,6}; for each of stages 4,5,6
its other two projectors complete the same rank-2 complementary space. Their
scalar product is D4 D5 D6 I. Append the legal 3-stage C1 word unchanged.
"""
import copy, hashlib, itertools, json
from fractions import Fraction as F
from pathlib import Path
import attribution as at

A=[[F(x) for x in row] for row in [[2,-1,0,1],[1,0,1,0],[0,1,-1,2],[2,0,2,1]]]
Ts=[[[-2,-2],[-2,-1]],[[-2,0],[-2,-2]],[[-2,0],[0,-2]]]

def invmat(a):
    n=len(a); m=[row[:] + [F(i==j) for j in range(n)] for i,row in enumerate(a)]
    for j in range(n):
        q=next(i for i in range(j,n) if m[i][j]); m[j],m[q]=m[q],m[j]
        z=m[j][j]; m[j]=[x/z for x in m[j]]
        for i in range(n):
            if i!=j:
                z=m[i][j]; m[i]=[x-z*y for x,y in zip(m[i],m[j])]
    return [row[n:] for row in m]

def inverse_op(e):
    if e[0]=='ADD': return ['ADD',e[1],e[2],str(-F(e[3]))]
    if e[0]=='SCALE': return ['SCALE',e[1],str(1/F(e[2]))]
    raise ValueError(e)

def compile_matrix(G):
    # Reduce G to I by row additions/scales. The reverse inverse ops build G.
    m=copy.deepcopy(G); n=len(m); red=[]
    def add(i,j,c):
        m[i]=[x+c*y for x,y in zip(m[i],m[j])]
        red.append(['ADD',i,j,str(c)])
    def scale(i,c):
        m[i]=[c*x for x in m[i]]; red.append(['SCALE',i,str(c)])
    for j in range(n):
        p=next(i for i in range(j,n) if m[i][j])
        if p!=j: # row swap expressed in ADD/SCALE, all invertible
            add(j,p,F(1)); add(p,j,F(-1)); add(j,p,F(1)); scale(p,F(-1))
        scale(j,1/m[j][j])
        for i in range(n):
            if i!=j and m[i][j]: add(i,j,-m[i][j])
    assert m==at.ident(n)
    return [inverse_op(e) for e in reversed(red)]

def apply_ops(ops):
    R=at.ident(4)
    for e in ops:
        if e[0]=='ADD':
            r,s,c=e[1],e[2],F(e[3]); R[r]=[x+c*y for x,y in zip(R[r],R[s])]
        else:
            r,c=e[1],F(e[2]); R[r]=[c*x for x in R[r]]
    return R

def basis(stage):
    T=Ts[stage]
    B=copy.deepcopy(A)
    for r in range(4):
        B[r][2]=A[r][2]*T[0][0]+A[r][3]*T[1][0]
        B[r][3]=A[r][2]*T[0][1]+A[r][3]*T[1][1]
    return B

def factor(B,j,S):
    # G=B_j^-1, with the desired B column moved to index 0. The idle event
    # contributes G^-1 E_00 G = v w^T at the D=1 prefix.
    order=[j]+[i for i in range(4) if i!=j]
    Bj=[[row[i] for i in order] for row in B]
    G=invmat(Bj); ops=compile_matrix(G)
    assert apply_ops(ops)==G
    return ops+[['IDLE_ONE',0,S]]+[inverse_op(e) for e in reversed(ops)]

C=json.loads((at.SRC/'data/q0_callers/caller_C1.json').read_text())
assert C['roles']==4 and C['stages']==3
prefix=factor(A,0,[4,5,6])+factor(A,1,[4,5,6])
for t in range(3):
    for j in (2,3): prefix+=factor(basis(t),j,[t+4])
C['events']=prefix+C['events']
C['stages']=6
C['diagonal']=[d+[1,1,1] for d in C['diagonal']]
C['schema']='Q0 strict attribution separator: scalar projector gadget times C1'
path=Path('separator_word.json'); path.write_text(json.dumps(C,indent=2)+'\n')
legal,wf=at.q0check.legal(C); assert legal and wf
masks,ev=at.capture(C)
result={'word_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'n':4,'k':6,
        'legal_4q_symbolic_D':legal,'well_formed_hosts':wf,
        'source_C1_sha256':hashlib.sha256((at.SRC/'data/q0_callers/caller_C1.json').read_bytes()).hexdigest(),
        'Q_odd_thin_events':0,'host_count':sum(e[0]=='HOST' for e in C['events']),
        'event_count':len(C['events']),'gadget_event_count':len(prefix),'incidences':len(ev),
        'masks':[sorted(m) for m in masks],
        'qualifications':'Stages 4,5,6 have no HOST; n+2=6 < 2k=12. Legal Q=0 word, outside tight JB and K-block branches.',
        'solutions':{}}
for strict in (False,True):
    dom,multi,loc,stats,wit=at.solve(ev,masks,6,strict)
    target={'all_stage_local_matchings_exist':all(x is not None for x in loc.values()),
            'local_matchings':{str(t):[at.ser(ev[i],r) for i,r in m.items()] if m is not None else None
                               for t,m in loc.items()},
            'multi_events':[{'event':ev[i]['key'],'stages':sorted(ev[i]['S']),'domain':dom[i]} for i in multi],
            'stats':stats,'global_attribution_exists':wit is not None}
    if wit is not None: target['global_witness']=[at.ser(e,wit[i]) for i,e in enumerate(ev)]
    result['solutions']['strict' if strict else 'mask_only']=target
assert result['solutions']['strict']['all_stage_local_matchings_exist']
assert not result['solutions']['strict']['global_attribution_exists']
assert result['solutions']['mask_only']['global_attribution_exists']
Path('SEPARATOR.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='solutions'},indent=2))
for typ in ('mask_only','strict'):
    x=result['solutions'][typ]; print(typ,'local',x['all_stage_local_matchings_exist'],
          'global',x['global_attribution_exists'],'multis',x['multi_events'],'stats',x['stats'])
