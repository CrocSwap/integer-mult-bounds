#!/usr/bin/env python3
"""Independent symbolic SymPy replay of the separator at all four q roots."""
import json, time
from pathlib import Path
import sympy as s
C=json.loads(Path('separator_jb_word.json').read_text()); n=C['roles']; k=C['stages']
D=s.symbols('D1:'+str(k+1))
for q in (s.Integer(1),s.Integer(-1),s.I,-s.I):
    tic=time.monotonic(); R=s.eye(n).tolist()
    for e in C['events']:
        op=e[0]
        if op=='ADD':
            r,t,c=e[1],e[2],s.Rational(e[3]); R[r]=[s.expand(x+c*y) for x,y in zip(R[r],R[t])]
        elif op=='SCALE':
            r,c=e[1],s.Rational(e[2]); R[r]=[s.expand(c*x) for x in R[r]]
        elif op=='LAMBDA':
            r,z=e[1],e[2]; c=((1+s.I*z)+(1-s.I*z)*q*q)/2
            R[r]=[s.expand(c*x) for x in R[r]]
        elif op=='IDLE_ONE':
            c=s.prod(D[t-1] for t in e[2]); r=e[1]; R[r]=[s.expand(c*x) for x in R[r]]
        elif op=='HOST':
            t,r,z,a,b=e[1],e[2],e[3],s.Rational(e[4]),s.Rational(e[5])
            oldr,oldz=R[r][:],R[z][:]
            R[r]=[s.expand(D[t-1]*(x+a*q*y)) for x,y in zip(oldr,oldz)]
            R[z]=[s.expand(D[t-1]*(b*q**3*x+(1+a*b)*y)) for x,y in zip(oldr,oldz)]
        else: raise ValueError(op)
    for r,dg in enumerate(C['diagonal']):
        expected=q**dg[0]*s.prod(D[t]**dg[t+2] for t in range(k))
        for j in range(n):
            assert s.expand(R[r][j]-(expected if j==r else 0))==0,(q,r,j)
    print('PASS exact SymPy independent replay q=',q,'seconds=',round(time.monotonic()-tic,3),flush=True)
