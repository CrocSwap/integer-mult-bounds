# Replay the packet-3410 bypass and bound funded owner restoration

Packet 3410 is the sole original deletion outside the whole-word cut proof. A literal bypass deletes it, sends 3409 directly from 421 to 0, and preserves 679 of 680 original outputs. It loses independent owner 679; the actual 679-owner projection passes both directions but its full BIT margin is about −178.5312812223383 at 0.00388.

Four fixed-time chart-421 ingresses cannot restore the owner from chart 0 under new-axis-only pulses. On the projected word, arbitrary helpers and funded extra receipts fail if retained forward old packet components are fixed: 28,101 one-receipt choices and 26,640 two-receipt topologies fail, and three receipts exceed budget. Independent Pro-based certificates with their separate hypotheses exclude the 11-fixed-equation family at original clocks and all perturbations confined to the x17/x679 plane even with retiming. The four-ingress proof has 524 input collisions and the Pro audit adds a fixed-three exact cut at the 1931/1934 opening.

Change old components or incidences outside these scopes. For the old 785-to-1934 route at native clocks, the other path through 1932 and 2470 into chart 1 must also be accounted for. A local coefficient escape still requires all old outputs, exact literal adjoint, caller and outer strictification.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. All four inner cold replays passed. They check both literal orientations, protected 411, complete prices, the damaged operator, the actual projection and physical costlier restore, 524 independent collision/mutation controls, the one/two-receipt censuses, and a separate raw Pro-certificate implementation with 4,096 joint masks.
