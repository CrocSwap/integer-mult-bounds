#!/usr/bin/env python3
"""Independent literal chronology and dual-pulse verification of TIMELINE.json.

Uses only the frozen word and the output certificate. It does not import the
primary screen, its rank solver, its atlas, or its packet extractor.
"""
import gzip, hashlib, json, os
from pathlib import Path
from collections import defaultdict

if hasattr(os,'sched_getaffinity'):
    a=os.sched_getaffinity(0)
    if a:os.sched_setaffinity(0,{min(a)})
here=Path(__file__).resolve().parent
raw=(here/'inputs/WORD.json.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9'
w=json.loads(gzip.decompress(raw));P=w['program']; n=w['public']; assert n==680
assert hashlib.sha256(json.dumps(w,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
cert=json.loads((here/'TIMELINE.json').read_text())
# Independent frame-containment computation (integer dot products).
def legal_grade(x,y):
    a,b=w['frames'][str(x)],w['frames'][str(y)]
    lo,hi=(a,b) if a['dim']<b['dim'] else (b,a)
    d=hi['dim']-lo['dim']
    if d<=0:return 0
    if any(sum(u*v for u,v in zip(row,ann))!=0 for row in lo['B'] for ann in hi['A']):return 0
    return d
legal={int(c):legal_grade(int(c),564) for c in w['frames'] if int(c)!=564 and legal_grade(int(c),564)}
assert len(legal)==104 and set(map(str,legal))==set(cert['senders'])

# Symbolic primitive interpreter, distinct implementation from primary.
def state(extra=False):
    size=n+w['owned_fields']+(2 if extra else 0)
    rows=[0]*size; tags=[None]*size
    for i,c in enumerate(w['start']): rows[i]=1<<i;tags[i]=c
    if extra:rows[n]=1<<n;tags[n]=524
    return rows,tags

def apply(rows,tags,ins):
    op,r,*a=ins
    if op=='INIT':
        assert tags[r] is None;tags[r]=a[0];rows[r]=0;return [r]
    if op=='CLEAR':
        assert tags[r]==a[0];tags[r]=None;rows[r]=0;return []
    if op=='ADD':
        s,c=a;assert tags[r]==tags[s]==c and r!=s;rows[r]^=rows[s];return [r]
    if op=='MOVE':
        c,d=a;assert tags[r]==c;tags[r]=d;return [r]
    if op=='SWAP':
        s=a[0];assert tags[r] is not None and tags[s] is not None
        rows[r],rows[s]=rows[s],rows[r];tags[r],tags[s]=tags[s],tags[r];return [r,s]
    raise ValueError(ins)
rows,tags=state();old={};bridge=None
for t,ins in enumerate(P):
    if ins[0]=='MOVE' and ins[1] in (2748,2751,2754,3454) and ins[3]==564:old[ins[1]]=rows[ins[1]]
    if ins[0]=='MOVE' and ins[1]==3553:bridge=rows[3553]
    apply(rows,tags,ins)
assert len(old)==4 and tags[:n]==w['final'] and not any(tags[n:])
assert 564 not in w['start']
assert bridge==1<<411
assert rows[:n]==[(1<<j)^((1<<(j-111)) if 111<=j<222 else 0) for j in range(n)]
H0,H1,H2,H3=[old[x] for x in (2748,2751,2754,3454)]
T=rows[150]; assert T==H0^H1^H2^H3==(1<<39)^(1<<150)
for j,p in enumerate((1<<645,(1<<469)^(1<<622),1<<613,1<<150)):
    assert [((p & h).bit_count()&1) for h in (H0,H1,H2,T)]==[int(j==i) for i in range(4)]
assert [t for t,x in enumerate(P) if x[0]=='MOVE' and x[2]==564 and t<23547]==[10727,10730,10733]
assert [(t,x[1]) for t,x in enumerate(P) if x[0]=='MOVE' and x[3]==564]==[(9607,2748),(9619,2751),(9632,2754),(23547,3454)]

# Rebuild the funded diagnostic from original instructions, retaining every
# local row that ever appears through the instant before original clock 10729.
idx=lambda j:j+1 if j>=n else j
clean=n+w['owned_fields']+1
rows,tags=state(True);hist=defaultdict(set)
def record(changed):
    for j in changed:
        c=tags[j]
        if c in legal and rows[j]:hist[c].add(rows[j])
record(range(n+1))
for t,ins in enumerate(P):
    if t==10729:break
    code,r,*a=ins;rr=idx(r)
    if t==4294:
        ops=[['MOVE',rr,251,524],['INIT',clean,524],['ADD',clean,rr,524],['ADD',rr,n,524],['MOVE',rr,524,447]]
    elif 6646<=t<=6651:ops=[]
    elif t==6652:
        ops=[['INIT',rr,524],['ADD',rr,clean,524],['MOVE',rr,524,447],['CLEAR',clean,524]]
    elif t==9627:
        assert tags[idx(2752)]==601 and tags[rr]==447
        assert rows[idx(2752)]^rows[rr]==1<<n
        ops=[['MOVE',rr,447,601],['MOVE',rr,601,1]]
    else:
        if code in ('ADD','SWAP'):a[0]=idx(a[0])
        ops=[[code,rr,*a]]
    for op in ops:record(apply(rows,tags,op))
# Rank by low-bit pivots, unlike the main check's high-bit elimination.
def rank(xs):
    piv={}
    for v in xs:
        while v:
            p=(v&-v).bit_length()-1
            if p not in piv:piv[p]=v;break
            v^=piv[p]
    return len(piv)
def verify_pulse(p,ss,extra):
    return p>>n==0 and all(((p&q).bit_count()&1)==0 for q in list(ss)+extra) and ((p&H1).bit_count()&1)==1
count=0
for c,g in legal.items():
    rec=cert['senders'][str(c)];ss=hist[c]
    assert rec['grade']==g and rec['history_row_count']==len(ss) and rec['history_rank']==rank(ss)
    for key,extras in [('early_U',[H0,H2]),('full_W',[H0,H2,T])]:
        row=rec[key];assert row['available'] is False
        p=sum(1<<x for x in row['dual_pulse_support'])
        assert row['annihilated_history_rows']==len(ss)
        assert verify_pulse(p,ss,extras)
        # Positive control: globally granting H1 breaks every separator.
        assert not verify_pulse(p,list(ss)+[H1],extras)
        # Mutation control: toggle an H1-supported coordinate, invalidating the
        # required odd parity on H1.
        b=(H1&-H1).bit_length()-1
        assert not verify_pulse(p^(1<<b),ss,extras)
        count+=1
assert count==208
print(json.dumps({'result':'PASS','original_word_sha256':hashlib.sha256(raw).hexdigest(),
 'old_outputs_replayed_and_compared':680,'original_owner_411_bridge':True,'rank4_pulse_identity':True,'independent_601_observation':'z',
 'legal_sender_charts':len(legal),'verified_dual_pulses':count,'oracle_H1_control_rejected':208,
 'corrupted_pulse_rejected':208,'cutoff_original_clock':10729},indent=2,sort_keys=True))
