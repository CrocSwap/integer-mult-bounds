#!/usr/bin/env python3
"""Exact four-ingress information cut for the #7925 literal 469 near miss."""
import gzip, hashlib, importlib.util, json, os, sys
from collections import Counter, defaultdict
from fractions import Fraction as F
from pathlib import Path

if hasattr(os, 'sched_getaffinity'):
    permitted = os.sched_getaffinity(0)
    if permitted: os.sched_setaffinity(0, {min(permitted)})
here = Path(__file__).resolve().parent
sys.path.insert(0, str(here / 'vendor'))
import binary_operator as op
import price

def readpin(path, digest):
    raw=(here/path).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==digest, path
    return raw
word=json.loads(gzip.decompress(readpin('inputs/WORD.json.gz','d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9')))
receipt=json.loads(readpin('inputs/BIT.json','8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'))
assert op.canonical_hash(word)=='d3aa4426fa8fe7dc167270d01f2515184f2bff6a82744a14e941c5dd3afca27d'
assert op.canonical_hash({k:word[k] for k in ('frames','start','final')})==op.LAYOUT
spec=importlib.util.spec_from_file_location('edge',here/'inputs'/'bit_native.py')
e=importlib.util.module_from_spec(spec);sys.modules[spec.name]=e;spec.loader.exec_module(e)
I,T,moves,rows,clocks=e.extract(word);order=e.schedule(I,T,moves,rows)
value={i:1<<i for i in I}
for k in order:value[k]=e.combine(rows[k],value)
N=word['public']; assert N==680
P=word['program']
assert (P[4294],P[6646:6653],P[9627])==(
 ['MOVE',1862,251,447],
 [['INIT',2239,319],['ADD',2239,1441,319],['ADD',2239,1581,319],['ADD',2239,1769,319],['ADD',2239,1817,319],['ADD',2239,1889,319],['MOVE',2239,319,447]],
 ['MOVE',2753,447,1])
assert {k:(moves[k],clocks[k]) for k in (2748,2751,2754,3454)}=={
 2748:((446,564),9607),2751:((447,564),9619),2754:((448,564),9632),3454:((81,564),23547)}
assert [k for k,(a,b) in moves.items() if b==564]==[2748,2751,2754,3454]
assert not [k for k,c in I.items() if c==564]
assert P[10725:10734]==[['INIT',3060,564],['ADD',3060,2748,564],['MOVE',3060,564,1],['INIT',3061,564],['ADD',3061,2751,564],['MOVE',3061,564,1],['INIT',3062,564],['ADD',3062,2754,564],['MOVE',3062,564,1]]
assert P[32742:32747]==[['INIT',3704,564],['ADD',3704,2748,564],['ADD',3704,2751,564],['ADD',3704,2754,564],['ADD',3704,3454,564]]
assert P[39024:39026]==[['SWAP',150,3704],['CLEAR',3704,0]] and word['final'][150]==564
assert [(t,x) for t,x in enumerate(P) if (x[0] in ('ADD','SWAP') and 3704 in x[1:3]) or (x[0] not in ('ADD','SWAP') and x[1]==3704)]==[(t,P[t]) for t in (32742,32743,32744,32745,32746,39024,39025)]
for packet,uses in ((2748,[10726,32743]),(2751,[10729,32744]),(2754,[10732,32745]),(3454,[32746])):
    assert [t for t,x in enumerate(P) if x[0]=='ADD' and x[2]==packet]==uses

# Replay exactly the #7925 test word: inserted z is the real public test input,
# the retained clean copy is a private field, and all old private addresses shift.
Z=680; clean=N+word['owned_fields']+1; total=clean+1
idx=lambda x:x+1 if x>=N else x
program=[];positions={}
for t,(code,r,*args) in enumerate(P):
    positions[t]=len(program); rr=idx(r)
    if t==4294:
        program += [['MOVE',rr,251,524],['INIT',clean,524],['ADD',clean,rr,524],['ADD',rr,Z,524],['MOVE',rr,524,447]]
    elif 6646<=t<=6651: continue
    elif t==6652:
        program += [['INIT',rr,524],['ADD',rr,clean,524],['MOVE',rr,524,447],['CLEAR',clean,524]]
    elif t==9627: program += [['MOVE',rr,447,601],['MOVE',rr,601,1]]
    else:
        if code in ('ADD','SWAP'):args[0]=idx(args[0])
        program.append([code,rr,*args])
assert len(program)==len(P)+2

cuts=[9607,9619,9632,10725,23547,32742]
revpositions={positions[t]:t for t in cuts}
def replay(reverse=False,mutate=False):
    banks=[1<<i for i in range(N+1)]+[0]*(total-N-1)
    tags=list(word['final' if reverse else 'start'])+[524]+[None]*(total-N-1)
    dirty=retire=0; first=second=None; snapshots={}
    iterable=range(len(program)-1,-1,-1) if reverse else range(len(program))
    for step in iterable:
        if not reverse and step in revpositions:
            snapshots[revpositions[step]]=(banks.copy(),tags.copy())
        code,r,*args=program[step]
        if mutate and [code,r,*args]==['ADD',idx(1862),Z,524]:
            continue
        if code in ('INIT','CLEAR'):
            opens=(code=='CLEAR') if reverse else (code=='INIT')
            if opens: assert tags[r] is None;tags[r]=args[0];banks[r]=0
            else: assert tags[r]==args[0];dirty+=bool(banks[r]);retire+=1;tags[r]=None;banks[r]=0
        elif code=='ADD':
            s,c=args;assert tags[r]==tags[s]==c and r!=s
            if reverse:banks[s]^=banks[r]
            else:banks[r]^=banks[s]
        elif code=='SWAP':
            s=args[0];assert tags[r] is not None and tags[s] is not None
            banks[r],banks[s]=banks[s],banks[r];tags[r],tags[s]=tags[s],tags[r]
        elif code=='MOVE':
            c,d=args[::-1] if reverse else args;assert tags[r]==c;tags[r]=d
            if not reverse and r==idx(1862) and (c,d)==(251,524):
                assert tags[idx(1854)]==524;first=banks[idx(1854)]^banks[idx(1862)]
            if not reverse and r==idx(2753) and (c,d)==(447,601):
                assert tags[idx(2752)]==601;second=banks[idx(2752)]^banks[idx(2753)]
        else:raise ValueError(code)
    assert tags==list(word['start' if reverse else 'final'])+[524]+[None]*(total-N-1)
    assert not any(banks[N+1:])
    return banks[:N+1],dirty,retire,first,second,snapshots
f,fd,fr,first,second,snaps=replay();a,ad,ar,_,_,_=replay(True)
assert first==(1<<468)^(1<<469) and second==1<<680
for j in range(N+1):
    assert a[j]==sum(((f[i]>>j)&1)<<i for i in range(N+1))
expected=[(1<<j)^((1<<(j-111)) if 111<=j<222 else 0) for j in range(N)]+[1<<Z]
bad=[i for i in range(N) if f[i]!=expected[i]]
assert bad==[28,37,150,187,255,289,290,308,309,344,469,513,595,625]
assert f[680]==expected[680]
expected_adjoint=[sum(((expected[i]>>j)&1)<<i for i in range(N+1)) for j in range(N+1)]
adjoint_bad=[i for i in range(N+1) if a[i]!=expected_adjoint[i]]
fm,_,_,firstm,secondm,_=replay(mutate=True);am,_,_,_,_,_=replay(True,mutate=True)
for j in range(N+1):assert am[j]==sum(((fm[i]>>j)&1)<<i for i in range(N+1))
assert firstm==first and secondm==0 and fm[255]==expected[255] and fm[469]==expected[469]
assert secondm!=1<<680
D=value[2239]^value[1862]
assert f[150]^expected[150]==D and f[513]^expected[513]==D and f[577]==expected[577]

def rank(xs):
    basis={}
    for x in xs:
        while x:
            b=x.bit_length()-1
            if b in basis:x^=basis[b]
            else:basis[b]=x;break
    return len(basis)
def solve(items,target):
    basis={}
    for i,x in enumerate(items):
        mask=1<<i
        while x:
            b=x.bit_length()-1
            if b in basis:
                v,q=basis[b];x^=v;mask^=q
            else:basis[b]=(x,mask);break
    mask=0;x=target
    while x:
        b=x.bit_length()-1
        if b not in basis:return None
        v,q=basis[b];x^=v;mask^=q
    return [i for i in range(len(items)) if mask>>i&1]
def dual(rows, wanted):
    basis={}
    for row,rhs in zip(rows,wanted):
        while row:
            b=row.bit_length()-1
            if b in basis:
                x,y=basis[b];row^=x;rhs^=y
            else:basis[b]=(row,rhs);break
        else:assert not rhs
    ans=0
    for b,(row,rhs) in sorted(basis.items()):
        if rhs^((row&ans).bit_count()&1):ans|=1<<b
    assert [((x&ans).bit_count()&1) for x in rows]==wanted
    return ans
support=lambda x:list(e.indices(x))
H0,H1,H2,H3=[value[k] for k in (2748,2751,2754,3454)]
Hprime=value[2085]^value[1862]
T150=H0^H1^H2^H3
assert T150==(1<<39)^(1<<150)
assert [rank(x) for x in ([H0,H1,H2],[H0,H1,H2,Hprime],[H0,H1,H2,T150],[H0,H1,H2,T150,Hprime])]==[3,4,4,5]
assert snaps[10725][0][idx(2751)]==Hprime
for key,when in ((2748,9607),(2754,9632),(3454,23547)):
    assert snaps[when][0][idx(key)]==value[key]
assert [(i-1 if i>N else i) for i,c in enumerate(snaps[10725][1]) if c==564]==[2748,2751,2754]
assert [(i-1 if i>N else i) for i,c in enumerate(snaps[32742][1]) if c==564]==[2748,2751,2754,3454]
# Five explicit test pulses map to the identity on the five rows, with z=0.
five=[H0,H1,H2,T150,Hprime]
pulses=[dual(five,[int(i==j) for i in range(5)]) for j in range(5)]
assert all(not ((v>>680)&1) for v in pulses)
assert [[((r&p).bit_count()&1) for p in pulses] for r in five]==[[int(i==j) for j in range(5)] for i in range(5)]
# Mutation: replacing the actually observed Hprime by old H1 destroys the
# rank-five predicate. A bogus assertion of this proof must be rejected.
mutated=[H0,H1,H2,T150,H1]
assert rank(mutated)==4
try:
    assert rank(mutated)==5
except AssertionError:mutation_rejected=True
else:raise AssertionError('rank-five mutation accepted')



# Oracle control: overwrite the 2751 row at its original dispatch with H1.
# This is a free impossible nonlocal operation, not a primitive construction.
# The rest of the 681-input diagnostic is run literally and its complete output
# rows are compared against the original 680-owner contract plus identity z.
def oracle_run(corrupt=False):
    banks=[1<<i for i in range(N+1)]+[0]*(total-N-1)
    tags=list(word['start'])+[524]+[None]*(total-N-1)
    observations={}; reader={}
    for step,(code,r,*args) in enumerate(program):
        if step==positions[9619]:
            assert (code,r,args)==('MOVE',idx(2751),[447,564])
            banks[r]=H1^((1<<680) if corrupt else 0)
        if code in ('INIT','CLEAR'):
            if code=='INIT': assert tags[r] is None;tags[r]=args[0];banks[r]=0
            else: assert tags[r]==args[0];tags[r]=None;banks[r]=0
        elif code=='ADD':
            s,c=args;assert tags[r]==tags[s]==c and r!=s;banks[r]^=banks[s]
            if r in [idx(x) for x in (3060,3061,3062,3704)]:
                reader[str(r-1)]=banks[r]
        elif code=='SWAP':
            s=args[0];assert tags[r] is not None and tags[s] is not None
            banks[r],banks[s]=banks[s],banks[r];tags[r],tags[s]=tags[s],tags[r]
        elif code=='MOVE':
            c,d=args;assert tags[r]==c;tags[r]=d
            if r==idx(1862) and (c,d)==(251,524):observations['first']=banks[idx(1854)]^banks[r]
            if r==idx(2753) and (c,d)==(447,601):observations['second']=banks[idx(2752)]^banks[r]
        else:raise ValueError(code)
    assert tags==list(word['final'])+[524]+[None]*(total-N-1) and not any(banks[N+1:])
    return banks[:N+1],reader,observations
of,rr,obs=oracle_run(); mf,mr,mo=oracle_run(True)
assert [rr[str(i)] for i in (3060,3061,3062,3704)]==[H0,H1,H2,T150]
assert obs['second']==1<<680 and obs['first']==(1<<468)^(1<<469)
wrong=[i for i in range(N+1) if of[i]!=expected[i]]
assert 150 not in wrong and 513 not in wrong
assert mr['3061']!=H1 and mf!=of
out={'scope':'Oracle injects unavailable old H1 into packet 2751. This is not a realizable word, reverse primitive, repair of exteriors, or physical supplier.',
 'comparison':'all 681 diagnostic outputs against the 680-owner original contract and z identity',
 'outputs_checked':N+1,'diagnostic_wrong_outputs':bad,'oracle_wrong_outputs':wrong,
 'oracle_mismatch_delta_supports':{str(i):support(of[i]^expected[i]) for i in wrong},
 'first_reader_rows_recovered':[3060,3061,3062,3704],
 'second_chart601_observation_z':True,'corruption_of_H1_detected':True}
print(json.dumps(out,indent=2,sort_keys=True))
