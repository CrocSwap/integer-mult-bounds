#!/usr/bin/env python3
"""Create deterministic, offline-replayable artifact from the manifest."""
import gzip,hashlib,io,tarfile
from pathlib import Path
here=Path(__file__).resolve().parent
lines=(here/'SHA256SUMS').read_text().splitlines()
files=[]
for line in lines:
    digest,name=line.split('  ',1)
    assert name.startswith('./') and '..' not in Path(name).parts
    p=here/name; assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
    files.append(name)
files.append('./SHA256SUMS')
out=here/'p104-bit469-two-ingress.tar.gz'
with out.open('wb') as fd, gzip.GzipFile(fileobj=fd,mode='wb',mtime=0,filename='') as gz, tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
    for name in sorted(files):
        data=(here/name).read_bytes(); i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;i.mtime=0;i.uid=i.gid=0;i.uname=i.gname=''
        tar.addfile(i,io.BytesIO(data))
print(hashlib.sha256(out.read_bytes()).hexdigest(),out.name)
