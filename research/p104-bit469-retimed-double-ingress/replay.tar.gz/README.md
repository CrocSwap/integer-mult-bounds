# Two changed ingresses for the BIT 469 spectator

**Result: a scoped timing and information exclusion, with no new supplier or κ bound.** Keep the #7925 observation construction at 524 and 601, in particular replace original 2239 by `524→447` carrying pristine old 1862. Change 2751 and exactly one of 2748, 2754, 3454; retain every other exterior communication and require the old first-reader values at 3060, 3061 and 3062 and old output 150. The changed arrivals may come from any legal sender chart at any fixed input-independent time, can use arbitrary nonlinear functions of that sender's freely retained local history, and may use free local memory and computation. Under those hypotheses the four-bit interface at chart 564 cannot meet the required reader and output contract.

This extends the #7934 one-ingress rank-five cut by actually allowing 2751 itself to change and by allowing the second changed arrival to be retimed. It does **not** exclude different exterior communications, data-dependent transport or timing, extra receptions, changed first-reader obligations, altered observation mechanics, or a different target boundary. Sender histories are those of the pinned #7925 diagnostic, except that all candidate packets' own source operations can be omitted or freely retained; the only early 564 egress, 3060, is required to carry its original value. Recipient-side operations may be arbitrary. Other donors, routes and independent chart-601 observation are fixed. Source choices, timing, arrival identities and local execution do not encode data through side channels.

## Frozen records and chronology

- [#7934](https://github.com/CrocSwap/integer-mult-bounds/pull/7934), head `1e9508114eb3d030046b687881c0d304ebcc018f`, archive SHA-256 `af6b4326698eed0e866d06a721dcf3a2b9c8d6c1457ef2e8232d53d89ee4e86e`.
- [#7925](https://github.com/CrocSwap/integer-mult-bounds/pull/7925), head `95200cf9df79633f285c37ad20440e74660989ba`, archive SHA-256 `ca697380f9cb220a07dd834ccab7c5d9a521c83ced99fa620a290749ff5a7a8b`.
- [#7830](https://github.com/CrocSwap/integer-mult-bounds/pull/7830), head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15`; exact original word gzip SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`. The pinned 48-call rational audit is `a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376`.

The two retrieved parent archives agree byte-for-byte with all six copied input and vendor files; `verify_sources.py` checks these matches, both archive hashes, the retained receipts, the adapted parent-code prefixes, and the #7830 audit. See [SOURCE-CHECK.json](SOURCE-CHECK.json).

Let `H0,H1,H2,H3` be the **original** values of packets 2748, 2751, 2754, 3454. Their original arrivals to 564 occur at clocks 9607, 9619, 9632, 23547, and have grades 1, 1, 1, 6. The first old readers of the first three are `3060←2748` at 10726, `3061←2751` at 10729 and `3062←2754` at 10732. The late value of old output 150 is `T = H0 ⊕ H1 ⊕ H2 ⊕ H3 = x39 ⊕ x150`. The original word has no initial public input at 564 and exactly these four incoming MOVEs. In the uncorrected diagnostic, 2751 is `H′ = old 2085 ⊕ old 1862`; the four old targets have rank 4, and adding `H′` raises that rank to 5. The independent verifier checks four explicit input pulses giving the identity on `H0,H1,H2,T`.

## A timed dual certificate

For each of all **104** charts allowed to send directly to 564, accumulate every symbolic linear field value ever present there from the initial state through just before the original 10729 read. Grant a free permanent copy of every one of those values and even grant the independent diagnostic input `z` globally. The changed packet constructions and shipments do not write their donor fields; granting the original packet values seen in this baseline is an overestimate. Before 10729, the only output from 564 to the exterior is 3060 at 10727, and the required value `H0` equals the diagnostic's value. All other outside histories are fixed by the stated contract.

For every sender `s`, [TIMELINE.json](TIMELINE.json) supplies two explicit old-input pulses. One annihilates every row in the entire enlarged local history, `H0`, and `H2`, but toggles `H1`. The second also annihilates `T`. Both hold `z` fixed at zero. Thus no (even nonlinear) function of that local history can distinguish the pulse pair; any such function that is separately a function of `(H0,H1,H2)` cannot depend on `H1`, and the same is true for any function of `(H0,H1,H2,T)`. The second assertion is what permits an early retiming of 3454. An independently written literal interpreter rebuilds the histories and atlas roster and checks all 208 pulses, the old 680 output rows, the owner-411 bridge, and `2752⊕2753=z` at 601. It rejects adding `H1` for free to a sender's history and rejects a damaged pulse. See [INDEPENDENT.json](INDEPENDENT.json).

For the information step, if `m` independent target bits are decoded from exactly `m` received one-bit messages, every message must be a function of those target bits: the decoding maps all `2^m` received codes bijectively to the `2^m` target values. This holds for arbitrary deterministic nonlinear messages and decoders.

1. If the second changed ingress is 2748 or 2754, unchanged 3454 arrives after the three early readers. If all three earlier arrivals are present before the 10729 H1 read, those three bits must eventually recover the three independent values `H0,H1,H2`; the bijection makes each a function of that triple, and the pulses show that none can carry its H1 direction. If fewer than three arrivals are present, the already required independent outputs `H0,H1` must be recoverable from at most two bits; the same bijection and early pulses give the contradiction.
2. If the second changed ingress is 3454, the unchanged H0 and H2 have already arrived. With at most one of the two changed arrivals before the H1 read, the early pulse for its sender leaves its entire local history and H0/H2 unchanged while toggling H1. If both arrive before that read, all four arrivals must eventually recover the four independent values `H0,H1,H2,T`; the bijection makes each changed bit a function of those four targets, and the second set of pulses shows neither contains the H1 direction. The unchanged two bits also omit it.

The proof assumes all the stated old readers and output are recoverable at their original clocks, and that no changed communication elsewhere imports new information. It is not a theorem about a changed reader contract or a fifth reception. The exact original-dispatch linear screen in [RESULT.json](RESULT.json) additionally enumerates 24, 24, and 32 abstract rank-feasible payload pairs for second packet 2748, 2754, and 3454 respectively. Across all grades and all 104 actual sender charts, it finds zero source-feasible pairs. It grants free XOR/scratch and corrects the late 3061 stock to H1 in its late 3454 snapshot. The broader dual proof above covers arbitrary nonlinear local functions through the stated early timing.

## Complete operator control and separate fifth-arrival price

The primary replay reproduces the #7925 diagnostic's full **681×681** forward/adjoint transpose comparison, its independent z observation, and its 14 old-output differences. A separate *oracle* control substitutes the unavailable old H1 row into 2751 for free and leaves the other diagnostic primitives fixed. The three early first readers and T are then restored, and chart 601 still observes z; all 681 forward rows are compared with the original 680-owner operator plus z identity. The remaining differences are rows **187, 255, and 469**, all with the same recorded delta in [ORACLE.json](ORACLE.json). The intended three-target wrapper is not implemented, so those differences are not classified as an admissible target change. The oracle assignment is not a realizable primitive or a changed adjoint word; corrupting the oracle is detected. No successful changed candidate exists to bind or physically compile.

A genuinely fifth funded arrival is outside the four-arrival exclusion. As a separate price screen, retain all other paid incidences and their grades, charge both #7925 subdivisions, and optimistically grant the entire unimplemented productive split. Price the complete 36-call BIT and 48-call unchanged rational histograms with directed intervals; `H(g)=g^(1−κ)`. A grade-one MOVE charged **once in the entire caller** is a lower debit than an additional positive-grade MOVE per native call:

| κ | Optimistic BIT before extra | Extra grade-1 once per caller | Extra grade-1 per each of 36 calls | Unchanged rational margin |
| --- | ---: | ---: | ---: | ---: |
| `0.003879928046156` | `+0.50334585369894364696…` | `−0.49665414630105635303…` | `−35.496654146301056353…` | `+0.21226247016334675536…` |
| `0.003879929046155` | `+0.50296085573203495409…` | `−0.49703914426796504590…` | `−35.497039144267965045…` | `+0.21124392992651434438…` |

These are pre-physical raw signed margins and the positive productive split is unimplemented. They do not rule out a separately justified saving elsewhere, changed grades, a changed target, or a different caller. See [PRICE.json](PRICE.json) for every original and optimistic histogram bin and directed endpoints. No finite transfer, tensor cover, clean erasure, precision tape, ordinary-cost or outer-consumer qualification is claimed.

## Reproduce

Python 3 and the standard library are sufficient; the checks restrict affinity to one available CPU where supported. From this directory:

```sh
sha256sum -c SHA256SUMS
python3 -I -B verify_sources.py | cmp - SOURCE-CHECK.json
python3 -I -B screen.py | cmp - RESULT.json
python3 -I -B timeline.py | cmp - TIMELINE.json
python3 -I -B independent.py | cmp - INDEPENDENT.json
python3 -I -B oracle.py | cmp - ORACLE.json
python3 -I -B price_gate.py | cmp - PRICE.json
```

The parent verifier code is Apache-2.0; original notices and the #7830 notice are retained. This screen was prepared with Codex assistance. No independent human review is asserted.
