#!/usr/bin/env python3
"""Conservative full-caller tariff ceiling for one added grade-one ingress."""
import hashlib,json,sys
from pathlib import Path
from fractions import Fraction
from collections import Counter
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'vendor'))
import price
raw=(here/'inputs/BIT.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='8744587b49787bd9bfaed28a2595069d91afa45274284049bbba9764bc704a7d'
b=json.loads(raw)
assert b['native_calls']==36
T0=Counter({int(k):v for k,v in b['native']['targets'].items()})
P0=Counter({int(k):v for k,v in b['native']['paid'].items()})
assert (sum(T0.values()),sum(P0.values()))==(20706,107460)
T=T0.copy();T.update({1:36,3:36,4:36,8:-36})
P=P0.copy();P.update({1:72,2:36,4:-36})
assert all(v>=0 for v in T.values()) and all(v>=0 for v in P.values())
assert sum(g*v for g,v in T.items())==sum(g*v for g,v in T0.items())
assert sum(g*v for g,v in P.items())==sum(g*v for g,v in P0.items())
def bill(T,P,k):return price.decimal_interval(price.sub(price.moment(T,Fraction(k)),price.moment(P,Fraction(k))),36)
audit_raw=(here/'inputs/AUDIT.json').read_bytes()
assert hashlib.sha256(audit_raw).hexdigest()=='a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376'
audit=json.loads(audit_raw)['signed'];assert audit['native_calls']==48
RT=Counter({int(k):v for k,v in audit['productive'].items()})
RP=Counter({int(k):v for k,v in audit['paid'].items()})
prices={}
for k in ['0.003879928046156','0.003879929046155']:
    one=P.copy();one[1]+=1
    each=P.copy();each[1]+=36
    prices[k]={'rational_companion_unchanged':bill(RT,RP,k),'old_caller':bill(T0,P0,k),'optimistic_unimplemented_split_no_extra':bill(T,P,k),
       'plus_one_grade1_once_entire_caller':bill(T,one,k),'plus_one_grade1_each_of_36_calls':bill(T,each,k)}
    assert Fraction(prices[k]['plus_one_grade1_once_entire_caller'][1])<0
    assert Fraction(prices[k]['plus_one_grade1_each_of_36_calls'][1])<0
out={'scope':'Full 36-call signed productive minus paid. #7925 two real subdivisions and same-grade 2239 exchange are charged. Hypothetical full productive split granted; added ingress charged once or 36 times. No other movement changes are credited. One separate grade-one movement per caller is an optimistic lower debit for any extra positive-grade movement.',
 'target_bins_original':dict(sorted(T0.items())),'paid_bins_original':dict(sorted(P0.items())),
 'target_bins_optimistic':dict(sorted(T.items())),'paid_bins_before_extra':dict(sorted(P.items())),
 'rational_target_bins':dict(sorted(RT.items())),'rational_paid_bins':dict(sorted(RP.items())),
 'rational_source_sha256':'a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376',
 'intervals':prices}
print(json.dumps(out,indent=2,sort_keys=True))
