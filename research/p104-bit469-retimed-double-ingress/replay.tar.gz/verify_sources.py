#!/usr/bin/env python3
import hashlib,json,tarfile
from pathlib import Path
here=Path(__file__).resolve().parent
pins={'PARENT-7934.tar.gz':'af6b4326698eed0e866d06a721dcf3a2b9c8d6c1457ef2e8232d53d89ee4e86e',
'PARENT-7925.tar.gz':'ca697380f9cb220a07dd834ccab7c5d9a521c83ced99fa620a290749ff5a7a8b'}
shared=['inputs/WORD.json.gz','inputs/BIT.json','inputs/bit_native.py','vendor/binary_operator.py','vendor/literal.py','vendor/price.py']
sha=lambda b:hashlib.sha256(b).hexdigest()
checks={}
assert sha((here/'inputs/AUDIT.json').read_bytes())=='a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376'
assert sha((here/'inputs/7830-NOTICE').read_bytes())=='b213998c8dae6d88e4a1f0fd17c81dd78c31ef35bc9460fa16ca692326f1a02b'
checks['7830_AUDIT_json']='a4f318b83a810758bc9dc80eec15326e2794441f36d872aa24811b61c5d9f376'
for archive,digest in pins.items():
    p=here/'inputs'/archive;assert sha(p.read_bytes())==digest
    with tarfile.open(p,'r:gz') as t:
        for name in shared:
            b=t.extractfile('./'+name).read()
            assert b==(here/name).read_bytes(),(archive,name)
        checks[archive]={'sha256':digest,'matched_working_inputs':{name:sha((here/name).read_bytes()) for name in shared}}
with tarfile.open(here/'inputs/PARENT-7934.tar.gz','r:gz') as t:
    source=t.extractfile('./check.py').read().decode()
    prefix=source.split('# Exact same-grade, original-dispatch sender/stock roster.')[0]
    prefix=prefix.replace('cuts=[9607,9632,10725,23547,32742]', 'cuts=[9607,9619,9632,10725,23547,32742]')
    for name,separator in [('screen.py','# A necessary exact four-bit rank gate'),('timeline.py','# Enlarge each legal sender'),('oracle.py','# Oracle control')]:
        adapted=(here/name).read_text().split(separator)[0]
        assert adapted.rstrip()==prefix.rstrip(),name
    checks['parent_check_sha256']=sha(source.encode())
with tarfile.open(here/'inputs/PARENT-7934.tar.gz','r:gz') as a, tarfile.open(here/'inputs/PARENT-7925.tar.gz','r:gz') as b:
    for name in ['LITERAL-NEARMISS.json','MAXIMAL-ENVELOPE.json']:
        x=a.extractfile('./'+name).read();y=b.extractfile('./'+name).read();assert x==y
        checks['matching_'+name]=sha(x)
print(json.dumps({'status':'PASS','pinned_pr_heads':{'7934':'1e9508114eb3d030046b687881c0d304ebcc018f',
 '7925':'95200cf9df79633f285c37ad20440e74660989ba','7830':'87fbf4f7b35b0f18ab12b5767775a9a424cf0b15'},'checks':checks},indent=2,sort_keys=True))
