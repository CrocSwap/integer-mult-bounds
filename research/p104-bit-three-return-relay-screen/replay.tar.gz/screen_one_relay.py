#!/usr/bin/env python3
"""Bounded one-new-field, existing-atlas relay screen for the rank-21 triple.

Each tested replacement sends one arbitrary live binary combination from the
original grade-7 sender at its old first clock to a proper, nested atlas chart,
then sends one combination from that relay to the empty chart at the old final
clock.  Free local data at the latter deadline must be live then and unaffected
by any of this return's three old receipts.  Other returns stay intact. No
conclusions are made for another timetable or path architecture.
"""
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction
import gzip, json, hashlib
from pathlib import Path
import verify_decoder_triples as v
w=json.load(gzip.open('BIT-WORD.json.gz','rt')); F={int(k):x for k,x in w['frames'].items()}
s=v.run_tape(w,False); a=v.run_tape(w,True); targets, unused=v.collect(w,F,s,a)
returns=[t for t,(_,b,_) in s.items() if b==0]
groups=[[t for t in sorted(s) if a[t][2]==a[returns[g]][2]] for g in range(9)]
tri=(2,6,7); marks={t:3*j+k for j,g in enumerate(tri) for k,t in enumerate(groups[g])}
watch_first={groups[g][0]:g for g in tri}; watch_last={groups[g][2]:g for g in tri}
watch_mid={groups[g][1]:g for g in tri}
chart=list(w['start'])+[None]*w['owned_fields']; row=[1<<i for i in range(w['public'])]+[0]*w['owned_fields']
first={};first_all={};mid={};last={};last_all={}; MASK=(1<<680)-1
for t,(op,adr,*args) in enumerate(w['program']):
 if t in watch_first:
  g=watch_first[t]; src=s[t][0]; first[g]=[(i,x&MASK) for i,(c,x) in enumerate(zip(chart,row)) if c==src and x&MASK]
  first_all[g]=[(i,x&MASK) for i,(c,x) in enumerate(zip(chart,row)) if c==src and x&MASK and not (x>>680)]
 if t in watch_mid:
  g=watch_mid[t]; src=s[t][0]
  mid[g]=[(i,x&MASK) for i,(c,x) in enumerate(zip(chart,row)) if c==src and x&MASK]
 if t in watch_last:
  g=watch_last[t]; st=defaultdict(list); bad=0; mask=7<<(680+3*tri.index(g))
  for i,(c,x) in enumerate(zip(chart,row)):
   if c is None or not (x&MASK):continue
   if x&mask:bad+=1;continue
   st[c].append((i,x&MASK))
  last[g]=(st,row[adr]&MASK,bad)
  joint=defaultdict(list)
  for i,(c,x) in enumerate(zip(chart,row)):
   if c is not None and x&MASK and not (x>>680):joint[c].append((i,x&MASK))
  last_all[g]=joint
 if op=='INIT':chart[adr]=args[0];row[adr]=0
 elif op=='CLEAR':chart[adr]=None;row[adr]=0
 elif op=='ADD':row[adr]^=row[args[0]]
 elif op=='SWAP':
  other=args[0];row[adr],row[other]=row[other],row[adr];chart[adr],chart[other]=chart[other],chart[adr]
 elif op=='MOVE':
  chart[adr]=args[1]
  if t in marks:row[adr]^=1<<(680+marks[t])
 else:raise Exception(op)

def nested(c,d):
 return all(sum(Fraction(x)*Fraction(y) for x,y in zip(u,z))==0 for u in F[c]['B'] for z in F[d]['A'])

def contains(target,rows):return v.reduce_binary(target,v.binary_basis(rows))==0

def separate(target,rows):
    """An arbitrary public input invisible to every row, visible to target."""
    basis=v.binary_basis(rows)
    remainder=v.reduce_binary(target,basis)
    assert remainder
    free=remainder.bit_length()-1
    assert free not in basis
    witness=1<<free
    for pivot in sorted(basis):
        if (basis[pivot]&witness).bit_count()&1:
            witness^=1<<pivot
    assert all((x&witness).bit_count()%2==0 for x in rows)
    assert (target&witness).bit_count()%2==1
    return witness

def tariff(k,r):return (Decimal(r).ln()*(Decimal(1)-k)).exp() if r>1 else Decimal(r)
trials=['0.003879928046156','0.003879929046155']
result={'description':__doc__,'word_sha256':hashlib.sha256(Path('BIT-WORD.json.gz').read_bytes()).hexdigest(), 'triple_zero_based':tri,'records':[],'trials':trials}
assert result['word_sha256']==v.WORD_SHA
for j,g in enumerate(tri):
 t1,t2,t3=groups[g]; src=s[t1][0]; old1=s[t1][2]; old2=s[t2][2]; old3=s[t3][2]; st,target,bad=last[g]
 assert old3==target
 srcrows=[x for _,x in first[g]]; root=F[src]['dim']; assert root==7
 empty=[x for _,x in st.get(0,[])]
 candidates=[c for c in sorted(F) if 0<F[c]['dim']<7 and nested(c,src)]
 second_aux=[x for owner,x in mid[g] if owner not in (w['program'][t1][1],w['program'][t2][1])]
 final_aux=[x for owner,x in st[s[t3][0]]]
 # The incumbent's nested relay chain is a positive control. Its intermediate
 # auxiliary banks are present independently of the three old receipts.
 assert contains(old1,srcrows)
 assert contains(old2^old1,second_aux)
 assert contains(old3^old2,final_aux)
 rec={'return_index':g,'clocks':[t1,t2,t3],'source_chart':src,'old_route':[{'source':s[t][0],'destination':s[t][1],'grade':F[s[t][0]]['dim']-F[s[t][1]]['dim']} for t in (t1,t2,t3)],'first_sender_live_fields':len(srcrows),'first_sender_rank':len(v.binary_basis(srcrows)),'deadline_untouched_empty_fields':len(empty),'deadline_excluded_tainted_fields':bad,'old_route_positive_control':{'first_leg':True,'second_leg_local_correction':True,'final_leg_local_correction':True},'candidate_charts':len(candidates),'by_relay_dimension':{},'feasible':[],'separating_inputs':[]}
 for c in candidates:
  dim=F[c]['dim']; k=str(dim); item=rec['by_relay_dimension'].setdefault(k,{'nested_atlas_charts':0,'with_live_untouched_stock':0,'span_feasible':0});item['nested_atlas_charts']+=1
  aux=[x for _,x in st.get(c,[])];item['with_live_untouched_stock']+=bool(aux)
  assert contains(srcrows[0],srcrows+aux+empty), 'known-sender-form positive control'
  if contains(target,srcrows+aux+empty):
   item['span_feasible']+=1;rec['feasible'].append({'chart':c,'dim':dim,'relay_untouched_fields':len(aux),'grades':[7-dim,dim]})
  else:
   witness=separate(target,srcrows+aux+empty)
   rec['separating_inputs'].append({'chart':c,'owner_support':list(v.indices(witness))})
 with localcontext() as ctx:
  ctx.prec=60
  for d in rec['by_relay_dimension']:
   r=int(d);rec['by_relay_dimension'][d]['price_diagnostics']={}
   for k in trials:
    old=sum(tariff(Decimal(k),q) for q in [1,5,1]);new=sum(tariff(Decimal(k),q) for q in [7-r,r])
    rec['by_relay_dimension'][d]['price_diagnostics'][k]={'all_three_old_native_returns':str(3*old),'all_three_after_one_hypothetical_replacement':str(2*old+new),'hypothetical_saving_per_native_call':str(old-new),'hypothetical_saving_across_36_calls':str(36*(old-new))}
 result['records'].append(rec)
all_sources=[x for g in tri for _,x in first_all[g]]
joint_candidates=[c for c in sorted(F) if 0<F[c]['dim']<7 and all(nested(c,s[groups[g][0]][0]) for g in tri)]
joint={'description':'All three changed at once, each sends one arbitrary form from its grade-7 sender at its original first clock to a single common existing atlas relay. Each return sends once from that relay to empty at its original deadline. We grant the combined source spans independently to each output, any jointly untainted relay/empty stock, and earlier completed return forms at empty. This is an optimistic necessary span screen; it still excludes modified descendants and alternative timetables.',
       'common_nested_charts':len(joint_candidates),'by_relay_dimension':{},'feasible':[],'rejected':[]}
for c in joint_candidates:
 dim=F[c]['dim']; by=joint['by_relay_dimension'].setdefault(str(dim),{'candidates':0,'all_deadlines_pass_optimistic_spans':0});by['candidates']+=1
 done=[]; failures=[]
 for g in tri:
  st=last_all[g]; rows=all_sources+[x for _,x in st.get(c,[])]+[x for _,x in st.get(0,[])]+done
  target=s[groups[g][2]][2]
  if not contains(target,rows):
   z=separate(target,rows);failures.append({'return_index':g,'owner_support':list(v.indices(z))})
  done.append(target)
 if failures:joint['rejected'].append({'chart':c,'dim':dim,'separating_inputs':failures})
 else:by['all_deadlines_pass_optimistic_spans']+=1;joint['feasible'].append(c)
with localcontext() as ctx:
 ctx.prec=60
 for d in joint['by_relay_dimension']:
  r=int(d);joint['by_relay_dimension'][d]['price_diagnostics']={}
  for k in trials:
   old=sum(tariff(Decimal(k),q) for q in [1,5,1]);new=sum(tariff(Decimal(k),q) for q in [7-r,r])
   joint['by_relay_dimension'][d]['price_diagnostics'][k]={'all_three_old_native_returns':str(3*old),'all_three_hypothetical_common_relay':str(3*new),'hypothetical_saving_per_native_call':str(3*(old-new)),'hypothetical_saving_across_36_calls':str(108*(old-new))}
result['joint_common_relay']=joint
# A genuinely fresh chart has no incumbent local data and no old move lands
# there. The same generous test therefore holds independent of its exact nested
# rational subspace. Include one explicit fresh one-dimensional example.
fresh={'description':'Fresh common relay with no incumbent local stock and no other new movements, with the same original sender/deadline times and grants as the joint screen. No target becomes available even before choosing a new nested chart.',
       'example_basis_vector':[0,0,0,0,0,1,2,0], 'example_dimension':1,
       'example_nested_in_senders':[], 'example_existing_line_match':[], 'separating_inputs':[]}
z=fresh['example_basis_vector']
for g in tri:
 source=s[groups[g][0]][0]
 assert all(sum(Fraction(x)*Fraction(y) for x,y in zip(z,a))==0 for a in F[source]['A'])
 fresh['example_nested_in_senders'].append(source)
for c in F:
 if F[c]['dim']==1:
  b=F[c]['B'][0]
  if all(Fraction(z[i])*Fraction(b[j])==Fraction(z[j])*Fraction(b[i]) for i in range(8) for j in range(8)):fresh['example_existing_line_match'].append(c)
assert not fresh['example_existing_line_match']
done=[]
for g in tri:
 st=last_all[g];rows=all_sources+[x for _,x in st.get(0,[])]+done;target=s[groups[g][2]][2]
 assert not contains(target,rows)
 fresh['separating_inputs'].append({'return_index':g,'owner_support':list(v.indices(separate(target,rows)))})
 done.append(target)
result['fresh_empty_relay']=fresh
Path('ONE-RELAY-SCREEN.json').write_text(json.dumps(result,indent=2)+'\n')
for rec in result['records']:
 print('return',rec['return_index'],'source',rec['source_chart'],'clocks',rec['clocks'],'sender fields/rank',rec['first_sender_live_fields'],rec['first_sender_rank'],'zero fields',rec['deadline_untouched_empty_fields'],'tainted excluded',rec['deadline_excluded_tainted_fields'])
 print(json.dumps(rec['by_relay_dimension'],indent=2));print('FEASIBLE',rec['feasible'])
print('JOINT COMMON RELAY:',len(joint_candidates),'charts, by dimension',joint['by_relay_dimension'],'survivors',joint['feasible'])
