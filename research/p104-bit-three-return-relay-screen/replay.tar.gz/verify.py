#!/usr/bin/env python3
"""Portable serial replay and controlled corruption of the relay screen."""
from decimal import Decimal
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
FILES=['BIT-WORD.json.gz','EFREE-CALLER.json.gz','verify_decoder_triples.py',
       'binary_operator.py','baseline_check.py','inspect_triple.py',
       'screen_one_relay.py','independent_separators.py']
GENERATED=['TRIPLE.json','BASELINE-CHECK.json','ONE-RELAY-SCREEN.json','SEPARATOR-RECHECK.json']

def require(test,description):
    if not test:raise ValueError(description)

def check_manifest():
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        digest,name=line.split('  ',1)
        p=ROOT/name
        require(p.is_file() and sha256(p.read_bytes()).hexdigest()==digest,'manifest mismatch: '+name)

def compare(a,b,prices=False):
    if isinstance(a,dict):
        require(isinstance(b,dict) and set(a)==set(b),'record keys')
        for k in a:compare(a[k],b[k],prices or k=='price_diagnostics')
    elif isinstance(a,list):
        require(isinstance(b,list) and len(a)==len(b),'record list length')
        for u,v in zip(a,b):compare(u,v,prices)
    elif prices:
        require(abs(Decimal(a)-Decimal(b))<Decimal('1e-45'),'price diagnostic differs')
    else:require(a==b,'exact record mismatch')

def run(script,directory,expected_success=True):
    p=subprocess.run([sys.executable,'-B',script],cwd=directory,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if expected_success:
        require(p.returncode==0,script+' failed: '+p.stderr[-3000:])
    else:
        require(p.returncode!=0 and 'AssertionError' in p.stderr and 'check(' in p.stderr,
                'witness corruption did not fail at parity check: '+p.stderr[-3000:])
    return p

def main():
    check_manifest()
    with tempfile.TemporaryDirectory(prefix='three-return-replay-') as td:
        temp=Path(td)
        for name in FILES:shutil.copyfile(ROOT/name,temp/name)
        for script in ('verify_decoder_triples.py','inspect_triple.py','baseline_check.py','screen_one_relay.py','independent_separators.py'):
            run(script,temp)
            print('PASS',script,flush=True)
        for name in GENERATED:
            actual=json.loads((temp/name).read_text())
            expected=json.loads((ROOT/'expected'/name).read_text())
            compare(actual,expected)
        print('PASS saved exact records and bounded price diagnostics',flush=True)
        result_file=temp/'ONE-RELAY-SCREEN.json'; original=result_file.read_text();bad=json.loads(original)
        bad['records'][0]['separating_inputs'][0]['owner_support']=[]
        result_file.write_text(json.dumps(bad)+'\n')
        run('independent_separators.py',temp,False)
        result_file.write_text(original)
        print('PASS corrupted-separator rejection',flush=True)
    print('PASS 318 individual charts, 46 shared charts, 459 separating assignments',flush=True)

if __name__=='__main__':main()
