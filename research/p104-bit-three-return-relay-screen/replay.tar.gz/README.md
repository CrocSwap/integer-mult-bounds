# Three BIT returns: one-relay tariff screen

This is a bounded negative search, not a new supplier, a κ improvement, or a
claim to have discovered Ali Romman's movement bound. His public
[`BINARY-DECODER.md`](https://github.com/CrocSwap/integer-mult-bounds/blob/e33edecdd7fe17bec0247201306fc603f561eac9/research/p104-live-relative-gain/BINARY-DECODER.md)
proves the stated rank lower bounds and describes its 788,035-subspace check.
We use his exact triple verifier and word to locate its single rank-21 triple
among the 84 triples of the nine frozen returns. We have **not** independently
replayed his full 788,035-subspace computation. The distinct question here is
whether the **price** of this triple can be improved by a small, named family
of changed actual relay paths while keeping independent owner values.

## Scope and outcome

The nine return indices are zero-based in the order of arrival at chart 0 in
Ali's verifier; the triple is `(2, 6, 7)`. Each old return follows three
nested moves of grades `1, 5, 1`, so their combined movement rank is 21.
These are not unchanged packets passed through identical forms. The three
ordered paths, with program clocks and original field addresses, are:

| Return | First movement | Second movement | Final movement |
| --- | --- | --- | --- |
| 2 | `10302: 2924, 511(7) → 346(6)` | `11483: 3299, 346(6) → 13(1)` | `11488: 3300, 13(1) → 0(0)` |
| 6 | `10342: 2936, 515(7) → 350(6)` | `13060: 3328, 350(6) → 71(1)` | `13065: 3329, 71(1) → 0(0)` |
| 7 | `10352: 2939, 516(7) → 359(6)` | `15592: 3360, 359(6) → 70(1)` | `15597: 3361, 70(1) → 0(0)` |

The number in parentheses is the rational chart dimension. The final
corrections in the **full 680-owner rows** are, respectively,
`owner11 ⊕ owner673`, `owner69 ⊕ owner677`, and `owner68 ⊕ owner678`.
The middle corrections involve further independent owners. `TRIPLE.json`
records the complete 680-bit rows, the original 111-input projections, and
live field information at all nine moves. The screen checks the original
three-leg construction as a positive control, including its middle and final
local corrections.

The first library changes one return at a time. It sends one arbitrary local
linear combination from its original grade-7 sender at its original first
clock into a fresh relay field at a proper nested **existing atlas chart**,
and sends one arbitrary combination from that relay to chart 0 at the old
final clock. We grant every simultaneously live, 680-coordinate stock row at
that relay and the empty chart that is independent of the three old receipts.
The other two returns remain fixed. The potential new grades are
`(7 − d, d)`, so the return still has total rank 7.

The 636-frame atlas yields **108, 104, and 106** nested choices for the three
returns, or **318** cases. No case spans its old final outgoing row, even
when all granted local rows may be combined freely. A separately replayed
680-bit input assignment annihilates all available rows and makes the target
row one for every one of the 318 cases.

The second library changes all three returns at once and shares one relay
chart. All three old first clocks precede the first old deadline. At the three
old first clocks it may send one chosen form from each grade-7 sender into the
common relay; at each original deadline it may send a form from that relay to
chart 0. The screen is optimistic: it grants the full combined source span
independently to *each* deadline, the simultaneously live rows at the relay
and chart 0 unaffected by **any** of the nine replaced receipts, and the
already completed return forms at chart 0. It therefore ignores the extra
coupling imposed by sending only one chosen form per sender. All 46 common
nested atlas charts fail **every** target's necessary span condition: 33 have
dimension 1, 12 have dimension 2, and one has dimension 4. The archive has
138 checked separating assignments, one for each chart and deadline.

A third version uses a fresh rational chart that starts empty, with no other
new movement into it. The same necessary span fails for each output,
independent of the choice of nested chart. An explicit non-atlas example is
the line spanned by `[0,0,0,0,0,1,2,0]`; its incidence in all three source
charts and absence from the incumbent one-dimensional atlas are checked. The
three fresh-chart separating assignments are included.

These are **not** exclusions of other old-receipt descendants, source or
deadline timings, multi-relay schemes, altered stock, different decoder
bases, or general networks. A successful span screen would still require a
literal causal word, all old consumers, independent owner recovery, both
orientations, the 411/tree contract, and a full signed caller and ordinary
invoice. No candidate reached that gate here. The fixed old word and caller
were separately checked, but the old baseline is not a validation of a
changed word.

## Why rank 21 alone does not settle price

At tariff `r^(1 − κ)`, the three **complete old return charges** total
`3 × (2 + 5^(1 − κ))` per native call. A hypothetical common relay of
dimension `d` would charge `3 × ((7 − d)^(1 − κ) + d^(1 − κ))` before any
other cost. At the first higher decimal trial `0.003879928046156`, these are
approximately:

| Relay dimension | Old three-return charge | Hypothetical new charge | Return-charge difference over 36 calls |
| --- | ---: | ---: | ---: |
| 1 | 20.9066242964420 | 20.8752997930670 | +1.12768212150 |
| 2 | 20.9066242964420 | 20.8905098078788 | +0.58012158828 |
| 4 | 20.9066242964420 | 20.8973474204217 | +0.33396753673 |

These are **arithmetic diagnostics of rejected hypothetical paths**, not
achieved savings or a complete changed-candidate invoice. JSON records also
include one-return alternatives and both trial rates, including
`0.003879929046155`. The Decimal values are approximations; no directed
interval is claimed. The full caller, ordinary records, owned fields, dirty
retirements, preparation, cleanup, and any changed downstream returns must be
recounted for an actual surviving word.

## Verification and provenance

From this directory, run `python3 -B verify.py`. It uses only Python's
standard library, needs Python 3.10 or later, and executes serially. It
replays the pinned peer triple script, independently tracks the 680 public
rows and nine receipt flags, recomputes atlas inclusion, validates all 459
separating inputs by dot products, checks incumbent controls, and checks that
a deliberately corrupted witness is rejected. It regenerates the JSON in a
temporary directory and compares the exact non-price records with the saved
receipts. Rounded price diagnostics are compared within `1e−45`.

The #7830 `binary_operator.py` replay checks the **baseline** 680-by-680 maps
in both directions, 111 contact pairs/222 main owners, 2,874 paid moves,
3,554 dirty retirements per direction, owner-411 bridge and omission control,
and the 18-stage 36-call caller polynomial. The separate separator checker
uses that same pinned baseline replay, but reimplements tagged stock tracking
with sets and checks witness parity directly, not the generating screen's
binary elimination routine. It is not a separate compiler implementation.
`SOURCES.md`, `NOTICE`, `NOTICE-7830`, and `LICENSE` preserve sources and
attributions. Exact files are in `expected/` and are regenerated in isolation.
