#!/usr/bin/env python3
import gzip,json
from itertools import combinations
from functools import reduce
from operator import or_
from pathlib import Path
import verify_decoder_triples as v
w=json.load(gzip.open('BIT-WORD.json.gz','rt')); F={int(k):x for k,x in w['frames'].items()}
s=v.run_tape(w,False); a=v.run_tape(w,True); targets, stock=v.collect(w,F,s,a)
roots=[v.write_integral(F[c]['B'][0]) for c in w['start'][:v.PORTS]]
steps=v.lattice_steps(roots); red={c:v.saturated_image([v.write_integral(z) for z in f['B']],steps) for c,f in F.items()}
lines=[red[c][0] for c in w['start'][:v.PORTS]]
def tensor(z,u):return sum(z<<(8*j) for j in v.indices(u))
triples=[]
for tri in combinations(range(9),3):
 labels=[sum(((targets[g]>>i)&1)<<j for j,g in enumerate(tri)) for i in range(v.PORTS)]
 rank=len(v.binary_basis(tensor(line,u) for line,u in zip(lines,labels)))
 if rank==21:triples.append(tri)
assert len(triples)==1
tri=triples[0]; returns=[t for t,(_,b,_) in s.items() if b==0]; sel={a[t][2] for t in returns}
groups=[[t for t in sorted(s) if a[t][2]==a[returns[g]][2]] for g in range(9)]
watch=set(sum((groups[g] for g in tri),[])); charts=list(w['start'])+[None]*w['owned_fields']; rows=[1<<i for i in range(w['public'])]+[0]*w['owned_fields']; snapshots={}
for t,(op,addr,*args) in enumerate(w['program']):
 if t in watch:
  src,dst=args; active=[(i,rows[i]) for i,c in enumerate(charts) if c==src and i!=addr]
  snapshots[t]={'owner':addr,'row_hex':hex(rows[addr]),'source_live_fields':len(active),'source_live_nonzero':sum(x!=0 for _,x in active),'source_row_reconstructible':v.reduce_binary(rows[addr],v.binary_basis(x for _,x in active))==0,'source_owners':[i for i,x in active if x], 'source_dimensions':len(v.binary_basis(x for _,x in active))}
 if op=='INIT': charts[addr]=args[0];rows[addr]=0
 elif op=='CLEAR':charts[addr]=None;rows[addr]=0
 elif op=='ADD':peer,chart=args;rows[addr]^=rows[peer]
 elif op=='SWAP':peer,=args;rows[addr],rows[peer]=rows[peer],rows[addr];charts[addr],charts[peer]=charts[peer],charts[addr]
 elif op=='MOVE':charts[addr]=args[1]
 else:raise Exception(op)
result={'rank21_triple_zero_based':tri,'returns':[]}
for i in range(9):
 moves=[]
 for t in groups[i]:
  src,dst,row=s[t]
  m={'clock':t,'owner':w['program'][t][1],'source_chart':src,'destination_chart':dst,'source_dim':F[src]['dim'],'destination_dim':F[dst]['dim'],'grade':F[src]['dim']-F[dst]['dim'],'forward_row_hex':hex(row),'forward_live_support':list(v.indices(row & v.LIVE))}
  if t in snapshots:m['liveness']=snapshots[t]
  moves.append(m)
 result['returns'].append({'index_zero_based':i,'in_rank21_triple':i in tri,'final_clock':returns[i],'selector_hex':hex(a[returns[i]][2]),'target_live_support':list(v.indices(targets[i])),'moves':moves})
Path('TRIPLE.json').write_text(json.dumps(result,indent=2)+'\n')
for g in tri:
 x=result['returns'][g]
 print('return',g,'selector',x['selector_hex'],'target',x['target_live_support'])
 for m in x['moves']:
  l=m['liveness'];print(' ',m['clock'],m['owner'],f"{m['source_chart']}({m['source_dim']}) -> {m['destination_chart']}({m['destination_dim']})",'grade',m['grade'],'support',m['forward_live_support'],'live',l['source_live_nonzero'],'rank',l['source_dimensions'],'reconstruct',l['source_row_reconstructible'])
