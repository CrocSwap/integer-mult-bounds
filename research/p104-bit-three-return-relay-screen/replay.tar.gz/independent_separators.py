#!/usr/bin/env python3
"""Recheck saved 680-bit separating inputs using an independent tagged replay.

No row-elimination function from the generating screen is used here.
"""
import gzip,json,hashlib
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import binary_operator as b
w=json.load(gzip.open('BIT-WORD.json.gz','rt')); out=json.load(open('ONE-RELAY-SCREEN.json'))
assert hashlib.sha256(Path('BIT-WORD.json.gz').read_bytes()).hexdigest()==b.WORD_GZIP
atlas=b.Atlas(w['frames']);fwd,adj,_=b.native_checks(w,atlas)
fwd={p.clock:p for p in fwd.packets.values()}; adj={p.clock:p for p in adj.packets.values()}
returns=sorted(t for t,p in fwd.items() if p.receiver==0)
tri=(2,6,7)
groups={g:sorted(t for t in fwd if adj[t].arrival.row==adj[returns[g]].arrival.row) for g in tri}
assert [groups[g] for g in tri]==[[10302,11483,11488],[10342,13060,13065],[10352,15592,15597]]
mark={t:(g,j) for g in tri for j,t in enumerate(groups[g])}
values=[1<<i for i in range(680)]+[0]*w['owned_fields']; tags=[set() for _ in values]
chart=list(w['start'])+[None]*w['owned_fields']; first={};firstall={};last={};lastall={};target={}
starts={groups[g][0]:g for g in tri};ends={groups[g][2]:g for g in tri}
for t,(op,addr,*arg) in enumerate(w['program']):
 if t in starts:
  g=starts[t]; source=fwd[t].source
  first[g]=[values[i] for i in range(len(values)) if chart[i]==source and values[i]]
  firstall[g]=[values[i] for i in range(len(values)) if chart[i]==source and values[i] and not tags[i]]
 if t in ends:
  g=ends[t]; st=defaultdict(list);st_all=defaultdict(list)
  for i in range(len(values)):
   if chart[i] is None or not values[i]:continue
   if not any(group==g for group,_ in tags[i]):st[chart[i]].append(values[i])
   if not tags[i]:st_all[chart[i]].append(values[i])
  last[g]=st;lastall[g]=st_all;target[g]=values[addr]
  assert values[addr]==fwd[t].arrival.row
 if op=='ADD':
  peer=arg[0];values[addr]^=values[peer];tags[addr]^=tags[peer]
 elif op=='SWAP':
  peer=arg[0];values[addr],values[peer]=values[peer],values[addr];tags[addr],tags[peer]=tags[peer],tags[addr];chart[addr],chart[peer]=chart[peer],chart[addr]
 elif op=='INIT':assert chart[addr] is None;chart[addr]=arg[0];values[addr]=0;tags[addr]=set()
 elif op=='CLEAR':assert chart[addr]==arg[0];chart[addr]=None;values[addr]=0;tags[addr]=set()
 elif op=='MOVE':
  assert chart[addr]==arg[0];chart[addr]=arg[1]
  if t in mark:tags[addr]^={mark[t]}
 else:raise ValueError(op)

def check(support,rows,goal):
 assert len(set(support))==len(support) and all(0<=i<680 for i in support)
 pulse=sum(1<<i for i in support)
 assert all((pulse&r).bit_count()%2==0 for r in rows)
 assert (pulse&goal).bit_count()%2==1

def nested(c,d):
 return all(sum(Fraction(x)*Fraction(y) for x,y in zip(z,a))==0 for z in w['frames'][str(c)]['B'] for a in w['frames'][str(d)]['A'])
charts=[int(c) for c in w['frames']];dims={int(c):x['dim'] for c,x in w['frames'].items()}
assert [r['return_index'] for r in out['records']]==list(tri)
single_count=0
for g,rec in zip(tri,out['records']):
 src=fwd[groups[g][0]].source
 eligible={c for c in charts if 0<dims[c]<7 and nested(c,src)}
 witness={x['chart']:x['owner_support'] for x in rec['separating_inputs']}
 assert eligible==set(witness) and not rec['feasible']
 for c,support in witness.items():
  check(support,first[g]+last[g][c]+last[g][0],target[g]);single_count+=1
joint=out['joint_common_relay'];eligible={c for c in charts if 0<dims[c]<7 and all(nested(c,fwd[groups[g][0]].source) for g in tri)}
assert eligible==set(x['chart'] for x in joint['rejected']) and not joint['feasible']
source=sum((firstall[g] for g in tri),[]);joint_count=0
for event in joint['rejected']:
 c=event['chart'];prev=[]
 assert [f['return_index'] for f in event['separating_inputs']]==list(tri)
 for f,g in zip(event['separating_inputs'],tri):
  check(f['owner_support'],source+lastall[g][c]+lastall[g][0]+prev,target[g]);joint_count+=1;prev.append(target[g])
fresh=out['fresh_empty_relay'];z=list(map(Fraction,fresh['example_basis_vector']))
for g in tri:
 c=fwd[groups[g][0]].source
 assert all(sum(x*Fraction(y) for x,y in zip(z,a))==0 for a in w['frames'][str(c)]['A'])
assert not any(dims[c]==1 and all(z[i]*Fraction(w['frames'][str(c)]['B'][0][j])==z[j]*Fraction(w['frames'][str(c)]['B'][0][i]) for i in range(8) for j in range(8)) for c in charts)
prev=[]
for f,g in zip(fresh['separating_inputs'],tri):
 check(f['owner_support'],source+lastall[g][0]+prev,target[g]);prev.append(target[g])
result={'single_return_separator_count':single_count,'common_relay_separator_count':joint_count,'fresh_empty_relay_separator_count':len(tri),'single_charts_per_return':[len(r['separating_inputs']) for r in out['records']],'common_relay_charts':len(eligible),'same_source_code_for_linear_elimination':False,'native_680_forward_and_adjoint_baseline':True}
Path('SEPARATOR-RECHECK.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
