#!/usr/bin/env python3
import gzip,json,hashlib
from collections import Counter
from pathlib import Path
import binary_operator as b
word=b.load_json(Path('BIT-WORD.json.gz'),b.WORD_GZIP,True)
assert b.canonical_hash(word)==b.WORD
caller=b.load_json(Path('EFREE-CALLER.json.gz'),b.CALLER,True)
atlas=b.Atlas(word['frames']); contacts=atlas.main_contacts(word['start'],word['final'])
fwd,adj,deleted=b.native_checks(word,atlas)
npaid,ntargets,paid,targets=b.binary_invoice(word,caller,atlas,fwd)
ordinary=b.ordinary_boundary(word,caller,paid,targets)
assert len(fwd.packets)==len(adj.packets)==2874 and len(npaid)==len(Counter(p.grade for p in adj.packets.values()))
assert npaid==Counter(p.grade for p in adj.packets.values())
result={'description':'Baseline only; no changed word passed the new-relay local stock screen. Existing source verifier, not a new independent compiler.',
        'word_compressed_sha256':b.WORD_GZIP,'word_canonical_sha256':b.WORD,'caller_sha256':b.CALLER,
        'main_contact_pairs':contacts,'main_owners':222,'public_owners_checked_each_direction':680,
        'original_dirty_retirements_each_direction':fwd.dirty,'paid_moves_each_direction':len(fwd.packets),
        'owner_411_bridge_clock':31290,'owner_411_omitted_add_control_clock':deleted,
        'caller_stages':18,'native_calls':ordinary['native_calls'],'caller_polynomial_both_directions':True,
        'native_paid_ranks':dict(sorted(npaid.items())),'native_productive_helper_ranks':dict(sorted(ntargets.items())),
        'caller_paid_ranks':dict(sorted(paid.items())),'caller_productive_ranks':dict(sorted(targets.items())),
        'ordinary_boundary':ordinary}
Path('BASELINE-CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
