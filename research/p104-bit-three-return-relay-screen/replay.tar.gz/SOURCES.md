# Pinned sources

All are in CrocSwap/integer-mult-bounds; links name immutable commits.

- Ali Romman, [decoder result](https://github.com/CrocSwap/integer-mult-bounds/blob/e33edecdd7fe17bec0247201306fc603f561eac9/research/p104-live-relative-gain/BINARY-DECODER.md), Git blob `ccd173d5990f1df776291582de9cd91503caa28e`, included as `ALI-BINARY-DECODER.md`.
- Ali Romman, [triple verifier](https://github.com/CrocSwap/integer-mult-bounds/blob/e33edecdd7fe17bec0247201306fc603f561eac9/research/p104-live-relative-gain/verify_decoder_triples.py), Git blob `e610678a9cbc7349b6064a94a1ae9dd9980c5842`, SHA-256 `02e4f8191b6aba3372df63b74e809e126c71d88a5dbbc3db23f0e4ecca6381a8`, verbatim.
- [#7786 BIT word](https://github.com/CrocSwap/integer-mult-bounds/blob/89a67c404226d51028e135de2b9169e9020d57af/research/p104-iterated-returns/binary/WORD.json.gz), Git blob `efb2e9d1c3caec25bea36803ca6994997e3256b0`, compressed SHA-256 `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`, verbatim as `BIT-WORD.json.gz`.
- [#7830 baseline replay](https://github.com/CrocSwap/integer-mult-bounds/blob/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier/review/binary_operator.py), SHA-256 `36b3da4f72f8a6c946136fbd58b20838c00b0243c2effaf909c20b76967a5349`, verbatim.
- [#7830 predecessor notice](https://github.com/CrocSwap/integer-mult-bounds/blob/87fbf4f7b35b0f18ab12b5767775a9a424cf0b15/research/p104-mixed-rank-supplier/NOTICE), SHA-256 `b213998c8dae6d88e4a1f0fd17c81dd78c31ef35bc9460fa16ca692326f1a02b`, verbatim as `NOTICE-7830`.
- [Locked paired caller](https://github.com/CrocSwap/integer-mult-bounds/blob/4f7c67ae387cc91580f469aeda4d508b372b9ec1/research/paired-query-only-bit/EFREE-CALLER.json.gz), Git blob `f022272a8d51ede841778dec76e2bfb24b614d04`, SHA-256 `757b3523798f840bdb02028b23708c3416627a99ea09e7a3c4bcdc5cd0c7ce4b`. Its attribution is retained in `NOTICE-7830`.

The Apache-2.0 text is identical to the peer `LICENSE`, Git blob
`261eeb9e9f8b2b4b0d119366dda99c6fd7d35c64`. New code is the screen and replay
wrappers in this directory. Their source pins and expected output digests are
also recorded in `SHA256SUMS`.
