#!/usr/bin/env python3
"""Reproduce the frozen ten-helper local-response transport and fresh controls."""
import argparse,hashlib,json,struct,subprocess
from pathlib import Path
H=lambda b:hashlib.sha256(b).hexdigest()
HERE=Path(__file__).resolve().parent

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--predecessor',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--native-bin',type=Path,required=True);a=ap.parse_args()
 p=a.predecessor.resolve();o=a.output.resolve();b=a.native_bin.resolve();pin=json.loads((HERE/'PIN.json').read_text())
 if o.exists():raise ValueError('output must be fresh')
 for name,want in pin['predecessor_files_sha256'].items():
  if H((p/name).read_bytes())!=want:raise ValueError('predecessor mismatch: '+name)
 r=json.loads((p/'COHORT249-REPLAY.json').read_text());r.pop('scope',None);r.pop('source_initial_scope',None)
 if H(json.dumps(r,sort_keys=True,separators=(',',':')).encode())!=pin['complete_numeric_and_nested_replay_sha256']:raise ValueError('complete normative predecessor replay mismatch')
 o.mkdir(parents=True)
 def run(name,args,log,success=True):
  exe=b/(name+('.exe' if (b/(name+'.exe')).exists() else ''))
  z=subprocess.run([str(exe),*map(str,args)],cwd=o,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (o/log).write_bytes(z.stdout)
  if success and z.returncode:raise RuntimeError(name+' failed; see '+log)
  if not success and not z.returncode:raise RuntimeError(name+' mutation was accepted')
  return z
 final=o/'final'
 run('local-response-transport',[p,HERE/'selection.json',final],'emit.log')
 if H((final/'COHORT249-RECORDS.bin').read_bytes())!=pin['expected_output_word_sha256']:raise ValueError('output word mismatch')
 rr=json.loads((final/'COHORT249-REPLAY.json').read_text())
 assert rr['new_rank_mass']==pin['expected_mass'] and rr['new_entrance_rank']==2620
 assert rr['actual_kernel_entrance_rank']==2439 and rr['actual_kernel_gauges']==1952
 run('frame-prime-guard',[final/'LOCAL-TRANSPORT-SELECTION.json',final/'PRIME.json'],'prime.log')
 run('global-exact',[final/'COHORT249-RECORDS.bin',final/'249-states.json',final/'GLOBAL.json'],'global.log')
 mut=json.loads((HERE/'selection.json').read_text());q=mut['candidates'][-1]['response'][0];q['coefficient']=str(int(q['coefficient'])+2);mp=o/'plus2.json';mp.write_text(json.dumps(mut))
 z=run('local-response-transport',[p,mp,o/'plus2-rejected'],'plus2.log',False)
 if b'exact complete response mismatch' not in z.stdout:raise RuntimeError('integer control failed for unrelated reason')
 raw=(final/'COHORT249-RECORDS.bin').read_bytes();rows=list(struct.iter_unpack('<6i',raw));kept=[r for r in rows if not(r[0]==1 and r[5]==60)]
 assert len(rows)-len(kept)==40
 omission=o/'omit60.bin';omission.write_bytes(b''.join(struct.pack('<6i',*r) for r in kept))
 z=run('global-exact',[omission,final/'249-states.json',o/'omit60-result.json'],'omit60.log',False)
 if b'local defining-decoder full formal column' not in z.stdout:raise RuntimeError('omission control failed for unrelated reason')
 cert={'status':'PASS_FROZEN_LOCAL_RESPONSE_TRANSPORT_WITH_EXECUTED_CONTROLS','word_sha256':pin['expected_output_word_sha256'],'transported_helpers':10,'transport_rank':181,'total_entrance_rank':2620,'kernel_rank':2439,'kernel_count':1952,'rank_mass':403946,'integer_plus2_rejected':True,'omitted_compensation_rejected':True,'scope':'Finite source-bound construction, complete integer local substitution, all five-stage F2 columns, exact signed magnitude bound, prime charts. All-size assembly interfaces inherited and require separate bank/price/finite receipts.'}
 (o/'CERTIFICATE.json').write_text(json.dumps(cert,indent=2)+'\n')
 print(json.dumps(cert))
if __name__=='__main__':main()
