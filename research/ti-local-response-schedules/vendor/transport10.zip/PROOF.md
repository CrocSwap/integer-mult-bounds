# Local response transport through a target flag

## Sufficient identity
Work over any commutative ring. Let a constant helper coordinate p have arbitrary dirty input a. Before a cut c, suppose p is never written or copied and its only incidences are a specified collection of additive reads into target coordinates. Delete precisely those reads. If the complete original prefix column of a at c is e_p + sum_t z_t e_t, insert target_t += z_t p at c. The resulting prefix is exactly the original prefix on every input: all columns other than p are unchanged by deletion, the deleted p contribution is exactly the displayed response, and p is still a. This argument uses signed integer coefficients, so it applies over every characteristic and does not assume clean helper input. The unchanged suffix therefore has exactly the same scalar map and restores the same dirty inputs.

Our emitter checks every prefix incidence of each helper, not merely the four nominated reads. It independently recomputes all signed integer entries of the entire helper column, including the temporary COPY coordinate, and verifies COPY restoration. Thus no unobserved helper or source output is assumed zero. Distinct helpers may be transformed together when these checks hold; linear superposition proves the joint identity.

## Paid physical implementation
Choose a nondegenerate common subspace E contained in the helper's next required frame and every affected target's next required frame. At the chosen cut each affected target is still in the ZERO frame. Give the helper initial frame E, remove the old ZERO reads, promote targets to E, and perform the deferred reads there. Reconstruct every subsequent MOVE from the actual current frame to the original required scalar/COPY frame and retain every actual final frame. The emitted nesting, COPY endpoints, exact basis rank and Gram inverse checks establish a sufficient physical implementation; the new entrance is paid by actual endpoint banking. Source initial inventory remains the original baseline's inventory. The new transported entrance rank is distinct from response-kernel rank.

For the concrete nine-helper witness E has dimension18, the helper's first old frame has dimension19, and the four target next frames have dimensions21,20,20,20. The exact histogram change per helper is {1:+1,18:+4,19:-1,2:+3,20:-3,21:-1,3:+1}. The rank mass decreases by18, exactly the new initial dimension. Whole assembly pricing, including actual bank tiling and finite precision, is required to turn this into a kappa claim.

## Shared-promotion extension
For a fixed admissible E and fixed legal local cuts, several helper columns can use the same promoted target coordinates. Charge each target's frame split once, and include each selected helper's true entrance/first-frame saving once. Selecting a helper forces all target promotions in its response support. If there are no other interactions, maximizing the resulting weighted closure is a standard source/sink minimum cut construction: positive helper profit is a source arc, target cost is a sink arc, and helper-to-required-target implications have capacity exceeding the total finite objective. This is sufficient only when the exact prefix, chronology and common-cap checks above hold for every selected helper, all shared targets use compatible cuts/frames, and the full emitted word is billed. Different E choices or additional retimed target operations require new compatibility proofs; the current nine-helper witness does not use an unverified closure solver.

## Current finite checks
The original frozen word and current reordered-plus37-kernel predecessor each admit the same nine helpers after fresh local-cut discovery. The combined predecessor mass404127 becomes403965. Nine exact integer columns and all actual nested COPY/frame transitions pass. Nine rational Gram inverse/odd-prime chart checks pass. Independent full five-stage22,463-column replay passes with signed row bounds3822 and3756, payload50408432093383483392 (66 bits). Removing all36 deferred reads is rejected by the independent complete-column replay. Adding2 to one compensation coefficient, invisible over F2, is rejected by the exact integer prefix audit. This is finite construction evidence, not Lean certification or an unconditional all-size multiplication theorem.

## Reproduction
Build local-transport.cpp, local-response.cpp and local-emit.cpp with C++17, json.hpp and Boost multiprecision. Run:

    local-transport COHORT LOCAL.json
    local-response COHORT LOCAL.json RESPONSES.json
    local-emit COHORT RESPONSES.json OUTPUT

The discovery programs produce nominations. local-emit rechecks the explicit positive witness, full integer response columns, helper incidence bounds, actual initial/final frames and rank conservation. The frozen selected rows are saved in OUTPUT/LOCAL-TRANSPORT-SELECTION.json. Independent global-exact and frame-prime-guard receipts are saved separately. Reproduction of the existing predecessor and all-size assumptions remains the inherited package's responsibility.

## Tenth helper with staggered local cuts

The multi-component extension adds one rank19 entrance on a helper whose four targets are separate target components. Its four delivery cuts differ. Each helper remains constant through its latest delivery cut; all removed gates and compensations before that point are controlled by that constant helper. Hence other input columns are unchanged. In addition to the exact original prefix response checks, the native emitter replays the complete new signed integer word on every selected dirty input and compares every final coordinate with the original word. This proves the full map equality for this finite staggered-cut construction without assuming that different local cuts are interchangeable. COPY preservation is checked in both signed runs, and physical target ZERO/cap nesting is checked at each actual delivery.

The ten-helper word lowers mass404127 to403946, with181 transported entrance dimensions and40 deferred reads. Its independent global22,463-column replay and all10 exact prime charts pass. These are finite supplier checks; actual banking and all47 assembly constraints remain separately necessary to state a new conditional kappa.
