# Ten local-response transports

This finite stage adds181 paid entrance dimensions by moving40 dirty-helper reads to later, exact local target cuts. It preserves the original source inventory, all1952 inherited kernels and their rank2439, and every actual final endpoint. It is not a new all-size theorem or a standalone kappa claim.

Build `local-response-transport.cpp` with C++17, Boost multiprecision and the inherited `json.hpp` include directory, producing `local-response-transport` in a native binary directory. That directory must also contain `frame-prime-guard` and `global-exact`, built from the authenticated inherited sources. Then run:

    python compose.py --predecessor PREDECESSOR --native-bin BIN --output FRESH_OUTPUT

All calculations are native C++; Python binds source files, invokes tools and constructs adversarial control inputs. PIN.json binds the complete predecessor word, source inventory, both actual endpoint maps, all frame data and selection bytes. Only two top-level prose fields in the replay receipt are ignored; every other nested or numeric field is bound canonically. No external service or machine-specific path is used.

The constructor rechecks exact arbitrary-dirty integer response columns before emitting. Fresh controls omit all40 deferred compensations and add2 to one coefficient, the latter being invisible over F2. Neither is accepted. The independent full-bank, finite-runtime, supplier and assembly checks must run on the emitted final directory; no earlier price may be reused.

The tenth helper uses four different local delivery cuts. The native constructor additionally compares complete final signed integer columns for every selected dirty helper before and after rewriting. Each helper remains constant through its latest delivery, and every changed gate is controlled by one such helper; therefore all other columns are unchanged.
