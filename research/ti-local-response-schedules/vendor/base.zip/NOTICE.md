# Current package and inherited notices

This package adds rank-modular response-subset construction, exact signed prefix validation and source-bound frame refinement. Donor-rank-weighted matching is an upstream PR275 contribution. The notice below is reproduced as upstream attribution; its prepared-for and package-description lines identify that original project, not the authorship of the current extension. Existing licenses and public contributor credits are retained.

## Verbatim inherited PR275 notice

# Attribution and scope

Prepared for George Lydakis with substantial OpenAI Codex assistance, including
Ody's matching research and coordinated independent integration and review.
New contributions are Apache-2.0; no exclusive priority is claimed.

This package contributes donor-rank-weighted compensated matching after producer
endpoint descent, its scoped fixed-graph proof, the regenerated word and literal
composition with PR299, a reproducible matching producer, and portable verification.
Compensated reuse itself, the gen5b modules, exact checkers, retiming, kernels,
early restoration, terminal sinks, complex supplier and pricing mechanisms are
inherited. Chafik Boukhalfa's full PR299 notice is preserved unchanged in
NOTICE-PR299.md, including credits to DreamingOfClouds, Rohan Arun, Eumemic,
Dugongue, utcorvusvolat-dotcom, Henry Grant, Jacob Sussman, Evan McKinney and the
full source chain, with their original assistance disclosures and licenses.

The all-size hypotheses remain conditional. Neither a complete formal proof of
integer multiplication nor global optimality is claimed.
