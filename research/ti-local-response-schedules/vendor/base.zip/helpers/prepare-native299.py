"""Bind an authenticated public299 export as a native predecessor."""
from pathlib import Path
import json,shutil,sys,hashlib
P,D=map(Path,sys.argv[1:]);D.mkdir(exist_ok=False)
for name in ['249-records.bin','249-states.json','frames.json','249-DONOR-OWNERSHIP.json']:
 shutil.copyfile(P/name,D/name)
s=json.loads((D/'249-states.json').read_text());b=(D/'249-records.bin').read_bytes();assert len(b)==24*s['record_count'] and hashlib.sha256(b).hexdigest()==s['record_sha256']
hist=s['physical']['paid_histogram'];mass=sum(int(r)*n for r,n in hist.items());j=dict(status='ACTUAL_SOURCE_BOUND_PUBLIC299_NATIVE_PREDECESSOR',histogram=hist,delta={},new_entrance_rank=0,new_gauges=0,new_rank_mass=mass,new_records=s['record_count'],inherited_public_kernel_entries=1720,inherited_public_kernel_entrance_rank=2192,inherited_endpoint_rank_deficit=440)
for name,value in [('COHORT249-INITIAL.json',s['initial']),('COHORT249-FINAL.json',s['final']),('COHORT249-FRAMES.json',{}),('COHORT249-SELECTION.json',dict(gauges=[])),('COHORT249-REPLAY.json',j)]: (D/name).write_text(json.dumps(value))
shutil.copyfile(D/'249-records.bin',D/'COHORT249-RECORDS.bin')
