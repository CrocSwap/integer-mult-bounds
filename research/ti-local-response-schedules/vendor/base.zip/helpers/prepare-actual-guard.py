"""Create a hash-bound guard view from actual COHORT metadata, without changing inputs."""
from pathlib import Path
import hashlib,json,shutil,sys
if len(sys.argv)!=3: raise SystemExit("COHORT OUTPUT")
s,d=map(Path,sys.argv[1:]);d.mkdir(parents=True,exist_ok=False)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=lambda n:json.loads((s/n).read_text())
names=["249-states.json","frames.json","COHORT249-RECORDS.bin","COHORT249-INITIAL.json","COHORT249-FINAL.json","COHORT249-FRAMES.json","COHORT249-REPLAY.json"]
before={n:h(s/n) for n in names}
st=j("249-states.json");fs=j("frames.json");extra=j("COHORT249-FRAMES.json")
for k,v in extra.items():
 if k in fs["frames"] and fs["frames"][k]!=v: raise ValueError("conflicting frame identifier "+k)
 fs["frames"][k]=v
r=j("COHORT249-REPLAY.json");st["initial"]=j("COHORT249-INITIAL.json");st["final"]=j("COHORT249-FINAL.json")
size=(s/"COHORT249-RECORDS.bin").stat().st_size
if size%24: raise ValueError("malformed record length")
st["record_count"]=size//24;st["physical"]["paid_histogram"]=r["histogram"]
shutil.copyfile(s/"COHORT249-RECORDS.bin",d/"249-records.bin")
(d/"frames.json").write_text(json.dumps(fs));(d/"249-states.json").write_text(json.dumps(st))
assert before=={n:h(s/n) for n in names}
b={"status":"BOUND_ACTUAL_COHORT_GUARD_VIEW","inputs":before,"outputs":{n:h(d/n) for n in ["249-records.bin","frames.json","249-states.json"]},"scope":"Actual COHORT word and actual initial/final maps; original plus new frames; guard checks run separately."}
d.with_name(d.name+"-binding.json").write_text(json.dumps(b,indent=2)+"\n")
print(json.dumps(b))
