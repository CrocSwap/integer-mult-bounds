# The tensor-isomorphism crossover used here

The transferable ingredients are exact response equivalence, adjoint/address-cap compatibility, and constructive nondegenerate frame changes. These are linear-algebra mechanisms; an average-case tensor-isomorphism theorem is not used as a worst-case oracle.

Equal formal responses permit a square-zero shear that suppresses selected cold reads. The change is sufficient only when a common nondegenerate address cap, available dirty workspace, and a legal restoration schedule exist. Here those data are constructed and checked on the actual word, with all setup, inverse, bank and chart costs included. Signed edge and prefix identities supplement F2 replay.

The useful orchestration insight is joint selection: an individually favorable response kernel may block a more valuable terminal sink. Removing two complete conflicting families and rebuilding the remaining word produces a better fully billed construction. Subsequent compatible frame retimings exploit the same nested-subspace representation without changing the scalar computation.

The weighted donor matching itself is credited to PR275. On its fixed eligible graph, independent donor sets form a transversal matroid and rank-ordered augmentation maximizes the monotone donor-only benefit. This does not prove optimality over changed frames, circuit families, or the full construction. PR300 supplies the second-descent idea; this package rechecks a compatible 61-gate subset on the different donor and sink word.

These mechanisms establish the specific conditional finite construction and κ recorded in RESULT.json. No universal optimization or complexity breakthrough is inferred from the finite search.


# Corrected rank-modular extension

# Corrected sufficient common-cap response-kernel construction

This note corrects the sentence in the frozen159 archive asserting that a relation of the form R(e_p+N e_p)=0 implies same-prefix commutation. That implication is false: RN e_p generally equals R e_p, not zero. No native source, selection, physical word, receipt or numerical contract is changed by this correction. The sufficient identity uses an altered prefix and the admitted whole-program map, as follows.

## Algebra over the binary response field

Let the state be (x,h), where h consists of all participating helper coordinates and x contains all other coordinates. Work over F2. In the actual cold prefix P, these helpers are unchanged, have no COPY incidence, and are read only through the permitted dirty-target reads. Its linear block form is

    P = [ B  R ]
        [ 0  I ].

B need not be the identity. R is the complete actual response through the cut, including propagation by every preceding operation, not merely the immediate target incidence matrix. The independent prefix checker computes these columns and checks that helper influence cannot escape the allowed target block.

Choose pivots p and donor sets D_p with

    R e_p = sum_{j in D_p} R e_j.

No pivot is a donor of any selected relation. Define N e_p = sum_{j in D_p} e_j, and N e_j=0 on nonpivots. Then N^2=0. Put Q=I+N; over F2, Q inverse=Q. The integer matrices I+N and I-N are also literal inverses, but the response relations in this statement are binary and are not asserted over the integers.

Delete every permitted read of each selected pivot through the cut, obtaining P prime. The helper coordinates are still unchanged. Its nonhelper block B is unchanged; its response R prime agrees with R on nonpivots and has zero pivot columns. The chosen relations establish exactly

    R prime = R Q,
    Qhat P prime = P Qhat,
    equivalently P prime Qhat = Qhat P,

where Qhat=diag(I,Q). This is intertwining with a modified prefix, not commutation with the same prefix. It follows directly by multiplying the displayed block matrices.

## Why the complete transformed program is equivalent

Write the admitted whole program as W=A P, where A is the suffix after the cut. The predecessor already implements a map independent of all arbitrary helper dirt and restores every helper. Consequently, in the (x,h) decomposition,

    W = diag(T,I),

for its admitted nonhelper map T; in particular W Qhat=Qhat W. This is a property of the complete admitted program, not an unsupported assumption about A or P separately.

The emitted program first executes P prime, inserts Q at the cut, executes the original suffix A, then inserts Q inverse at the end. Its total map is therefore

    W prime = Qhat inverse A Qhat P prime
            = Qhat inverse A P Qhat
            = Qhat inverse W Qhat
            = W.

Neither A Qhat=Qhat A nor P Qhat=Qhat P is required. The chronological location of the setup is essential: in this emitter setup is inserted after the altered cold prefix. Distinct ordered existing layers are treated as part of the admitted predecessor, with their real current prefix recomputed; the new layer is not flattened into an unjustified single square-zero matrix with all inherited layers.

## Physical realization and sufficient address hypotheses

For each selected relation, construct a nondegenerate address cap E_p contained in every participant's actual first required frame after its cut. The new pivot initially occupies E_p instead of the zero frame. Its erased prefix reads are precisely the reads that would have required that now-unavailable zero frame. Setup shears use E_p, all actual later operand charts remain nested, and inverse shears use the admitted full terminal frame. Donors reused across relations are scheduled through a single comparable chain of their required caps. Source-owned helper exclusion, live COPY lifetimes, actual endpoint frames and nondegenerate charts must be checked for the materialized schedule; these are not consequences of the response equation alone.

The frozen159 candidate satisfies those conditions by the native constructor and independent legality/Gram/prime checks. Its exact signed edge census matches every intended setup and inverse coefficient and frame. Omitting setup or inverse changes the full formal-column map. A duplicated pair of identical setup edges is invisible to F2 replay but is rejected by the exact integer edge census. The whole predecessor admission and the new all-column checks retain arbitrary independent helper dirt throughout; no dirty register is initialized to zero in the argument.

## Isolated-batch rank-modular bill

Fix one common nondegenerate cap E of dimension d for an isolated batch, with 0<d<m, 0<p<1 and m=120. Let psi(r)=(r/m)^p and psi(0)=0. Let h_i be each participating helper's actual first-frame dimension and Delta_i=psi(h_i)-psi(h_i-d).

For a finite eligible role set S, take a column basis D of R restricted to S and use all other columns as pivots, with systematic binary donor relations in D. Write k=rank(R_S). The sufficient construction's isolated normalized recurrence change is

    (|S|-k)*d/m + k*psi(d) - sum_{i in S} Delta_i
      = c*rank(R_S) - sum_{i in S} t_i,
    c = psi(d)-d/m > 0,
    t_i = Delta_i-d/m.

The first term is the added pivot entrance stock. Each used donor enters the shared cap only once, giving its psi(d) term, and every participating role gains the actual first-frame reduction Delta_i. An unused donor can be discarded; its cost psi(d)-Delta_i is nonnegative by concavity. All individual scalar additions, later chart transitions, complete bank tilings and finite arithmetic bills are still charged on the emitted word. A negative isolated expression is a sufficient nomination for an improving batch in this model, not by itself a certified global kappa or a license to add separate gains.

Linear-matroid rank minus modular weight is submodular. The bounded minimum-norm/greedy-basis procedure exploits this representation only to propose role sets. It makes no claim of global optimality, convergence certification or exact floating arithmetic. The selected159-pivot witness is materialized and independently checked; the final root invoice evaluates the complete composition with exact arithmetic.

## Exact finite coefficient certificate

The added donor sharing makes the old cancellation-free norm propagation too loose. The corrected checker retains the same104-bit ceiling and computes actual sparse integer rows for every intermediate register in both forward and reverse local traces. It validates all indices and COPY lifetimes first, widens coefficients to cpp_int before negation, and handles zero coefficients without introducing spurious entries. Each fresh COPY takes its recorded unchanged source row; DISCARD clears the temporary row. The reverse trace swaps COPY/DISCARD and negates ADD coefficients.

Induction proves every stored row exact. Its l1 norm bounds the corresponding register for inputs bounded by1. Every updated row is measured; COPY cannot exceed a previously measured source. For the frozen candidate the maximum forward norm is3822 and reverse norm3756. The unchanged five-stage invoice gives

    64 * 3822^3 * 3756^2 = 50408432093383483392 < 2^104.

No field size, prime guard, machine word limit or all-size analytic interface is relaxed. Nondegenerate-address/prime guards are separate from these signed coefficient bounds. Native finite admission is not Lean certification or an unconditional integer-multiplication theorem.

## Scope of the delivered claim

The witness supplies159 new rank-one gauges on the explicitly source-bound weighted predecessor, with original source inventory restored for accounting. The complete parent package also composes51 independently admitted public frame refinements and checks all actual charts, arbitrary-input columns, endpoint/stock/bank accounting, finite invoices and the unchanged47 assembly clauses. The asymptotic interpretation remains conditional on its explicitly inherited all-size interfaces. The native proof data are unchanged; this document supersedes only the incorrect same-prefix-commutation prose in the archived proof.
