# Joint kernel and sink selection

The input is the literal post-target word of PR275@03acc26f9624ce15c4149f927b7b9aeb0de301b8, whose input hash is pinned in RESULT.json and the public kernel selection. Its full 12-stage immutable source replay passes. No earlier physical donor assignment is substituted.

Public families 8 and 799 have pivots 16691 and 16635 and entrance ranks 16 and 11. Their response and cap data are checked on the actual input. Removing these complete families leaves 1,718 entries of rank 2,165 and permits two additional terminal sinks. The constructor rebinds every retained cut, installs the shears, checks every local column, replays all 440 restorations, and validates the nine sinks' compensation, cleanup, COPY and signed decoder traces. Its exact intermediate word is pinned separately.

The 38 subsequent gauges use fresh actual prefix relations and common nondegenerate address caps. The signed setup and inverse edges are independently checked, so characteristic-two column tests are not the only correctness evidence. Donor and source-owned roles are excluded. Full-frame, lifetime and ownership checks apply to the composed word.

The 61 PR300-inspired retimings replace only compatible original ADD frames. Inserted shear categories are protected. Actual source caps, nested predecessor/successor frames, nondegeneracy and endpoints are checked. The scalar stream is unchanged. The complete word is checked again after retiming; no saved gain is transferred by assumption.

The source inventory remains the original weighted producer inventory. Actual initial frames contain all 1,756 gauges. Layer-only counters separately record 38 entries and rank 78. This separation prevents repeated charging or omission of the retained public kernels.

The complete inventory is priced only after exact bank completion and the full finite invoice. Its conditional assembly is the inherited 47-inequality system, not a new unconditional all-size algorithm theorem.
