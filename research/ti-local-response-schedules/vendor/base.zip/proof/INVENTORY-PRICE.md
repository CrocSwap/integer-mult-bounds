# Actual inventory and price

Let v=1760, R=15423, and m=120. The original weighted source's initial helper-frame rank mass is 44634, hence the affine term is 96v−44634=124326. This is independently derived from the exact initial maps, not an older word's constant.

The actual initial helper frames have total rank 46877, so the aggregate kernel entrance rank is 2243. The final helper-frame rank is 369712, giving final endpoint deficit 24R−369712=440. Consequently the residual helper address mass is 369712−46877=322835.

Normalized stock is W=96v+322835=491795; equivalently W=124326+24R−440−2243. Literal stock is 5W=2458975. Every residual block is explicitly placed in a 120-wide bank partition; every chart, role/replica/stage assignment, occupied coordinate and omitted/repeated block control is checked.

The actual local word histogram has rank mass 404323. Replicate it 120 times and add 48v children at each rank 4,23,46,50. The resulting global rank mass is 120·404323+48v·(4+23+46+50)=58909800. Since 120W=59015400, the deficit is exactly 105600. The full histogram, rather than only this deficit, determines the moment.

price-complex.cpp brackets the weighted moment using directed exact rational bounds and verifies the adjacent coarse grid point. fixed-complex.cpp independently recomputes it, checks the complete finite primitive invoice and prime guards, evaluates the ordinary supplier chain, and validates all 47 strict assembly inequalities. No comparison baseline is reconstructed. Exponent clipping is supported by monotonicity but is inactive here.

The final κ is 150225174315373097537341/(2·10^26). The next 1/10^27 grid point is rejected. Inherited all-size interfaces remain explicit assumptions; neither the finite census nor native checks constitute a Lean certificate.
