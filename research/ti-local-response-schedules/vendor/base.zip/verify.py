#!/usr/bin/env python3
"""Offline source replay of weighted aliases, joint sinks, rank-modular kernels and exact frame refinements."""
from pathlib import Path,PurePosixPath
import argparse,concurrent.futures,hashlib,json,os,shutil,subprocess,sys,time,zipfile
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(b,s):
 if not b:raise RuntimeError(s)
def write(p,j):Path(p).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def norm(x):
 if isinstance(x,dict):return{k:norm(v)for k,v in x.items()if k not in('seconds','label','local_scalar_stream')}
 if isinstance(x,list):return list(map(norm,x))
 return x
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--output',type=Path,required=True);ap.add_argument('--cxx',default='g++');ap.add_argument('--boost-include',type=Path)
 ap.add_argument('--reuse-public-output',type=Path);ap.add_argument('--reuse-complex-output',type=Path);ap.add_argument('--reuse-posttarget',type=Path)
 a=ap.parse_args();need(__debug__ and sys.version_info>=(3,11)and sys.byteorder=='little','Unoptimized Python3.11+ little-endian required')
 O=a.output.resolve();need(not O.exists()and O!=HERE and HERE not in O.parents,'Fresh output outside package required')
 files=load(HERE/'MANIFEST.json')['files'];actual={p.relative_to(HERE).as_posix()for p in HERE.rglob('*')if p.is_file()and p!=HERE/'MANIFEST.json'}
 need(actual==set(files),'Package membership')
 for n,h in files.items():need(sha(HERE/n)==h,'Package hash '+n)
 O.mkdir(parents=True);start=time.monotonic()
 for name in ['logs','tmp','bin','public-source','kernel-source','inventory']:(O/name).mkdir()
 env={**os.environ,'TEMP':str(O/'tmp'),'TMP':str(O/'tmp'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONUTF8':'1'}
 def run(label,cmd):
  print(label,flush=True)
  with(O/'logs'/(label+'.log')).open('w',encoding='utf-8')as f:r=subprocess.run(list(map(str,cmd)),cwd=O,env=env,stdout=f,stderr=subprocess.STDOUT)
  need(r.returncode==0,label+' failed; inspect log')
 def extract(archive,inventory,dest):
  entries=load(inventory)['files']
  with zipfile.ZipFile(archive)as z:
   need(len(z.namelist())==len(entries)and set(z.namelist())==set(entries),'Archive membership')
   for info in z.infolist():
    p=PurePosixPath(info.filename);need(not p.is_absolute()and '..'not in p.parts and '\\'not in info.filename and ':'not in info.filename,'Unsafe archive path')
    need((info.external_attr>>16)&0o170000!=0o120000,'Symlink archive entry')
    data=z.read(info);need(hashlib.sha256(data).hexdigest()==entries[info.filename],'Archive source hash '+info.filename)
    q=dest/info.filename;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
  return entries
 P=O/'public-source';K=O/'kernel-source';R=load(HERE/'RESULT.json');G=O/'round5-source';G.mkdir()
 extract(HERE/'vendor/pr275-source.zip',HERE/'vendor/PR275-ARCHIVE-MANIFEST.json',P)
 extract(HERE/'vendor/kernel38.zip',HERE/'vendor/KERNEL-ARCHIVE-MANIFEST.json',K)
 extract(HERE/'vendor/round5.zip',HERE/'vendor/ROUND5-ARCHIVE-MANIFEST.json',G)
 need(sha(P/'MANIFEST.json')==R['public_source_manifest_sha256'],'Pinned PR275 source manifest')
 if a.reuse_public_output:
  U=a.reuse_public_output.resolve();reuse=load(HERE/'REUSE-PUBLIC.json');need(reuse['manifest_sha256']==sha(P/'MANIFEST.json'),'Public reuse source binding')
  for n,h in reuse['files'].items():need(sha(U/n)==h,'Completed public replay hash '+n)
 else:
  U=O/'public-replay';run('public-twelve-stage-source',[sys.executable,'-X','utf8','-B',P/'verify.py','--output',U])
 public=load(U/'verification.json');need(public['status']=='PASS_IMMUTABLE_GEN5_KERNEL_RESTORE_SINK_FIVE_STAGE_BANKED_CONSTRUCTION','Completed public source audit')
 need(public['manifest_sha256']==sha(P/'MANIFEST.json')and public['kappa']==R['public_claim'],'Public source/claim binding')
 need(set(public['fresh_stages'])=={'banks','bit','complex','finite','kernel','math','primes','raw','restore','scalar','sink','virtual'}and public['inputs_unchanged'],'All public stages')
 need(len(public['negative_controls'])==12 and len(load(U/'scalar.json')['controls'])==11 and len(load(U/'primes.json')['controls'])==6,'Public negative controls')
 gz=P/'inputs/complex/gcert1-p11-pr233-flow.json.gz';need(sha(gz)==R['complex_program_sha256'],'Actual public complex program')
 if a.reuse_complex_output:
  C=a.reuse_complex_output.resolve();reuse=load(HERE/'REUSE-COMPLEX.json');need(reuse['manifest_sha256']==sha(HERE/'vendor/complex/MANIFEST.json'),'Complex reuse source')
  for n,h in reuse['files'].items():need(sha(C/n)==h,'Completed complex output hash '+n)
 else:
  C=O/'complex-replay';cmd=[sys.executable,'-X','utf8','-B',HERE/'vendor/complex/verify-complex.py','--output',C,'--cxx',a.cxx]
  if a.boost_include:cmd+=['--boost-include',a.boost_include.resolve()]
  run('complex-source-native',cmd)
 cc=load(C/'CERTIFICATE.json');need(cc['status']=='PASS_FRESH_SOURCE_BOUND_STRONGER_COMPLEX_ADMISSION'and cc['manifest_sha256']==sha(HERE/'vendor/complex/MANIFEST.json'),'Complex certificate')
 need(cc['native_sha256']==sha(C/'NATIVE.json')and cc['program_compressed_sha256']==sha(gz),'Complex exact-program native binding')
 need(load(C/'NATIVE.json')['fourier_saving']==R['complex_saving'],'Actual complex saving')
 exe=lambda n:O/'bin'/(n+('.exe'if os.name=='nt'else''))
 def compile_one(p):
  cmd=[a.cxx,'-O2','-std=c++17','-I',HERE/'code','-I',HERE/'vendor']
  if a.boost_include:cmd+=['-I',a.boost_include.resolve()]
  run('compile-'+p.stem,cmd+[p,'-o',exe(p.stem)])
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(compile_one,sorted((HERE/'code').glob('*.cpp'))+[G/'utility/frame-prime-guard.cpp']+sorted((G/'retiming51/code').glob('*.cpp'))))
 if a.reuse_posttarget:
  B=a.reuse_posttarget.resolve();reuse=load(HERE/'REUSE-POSTTARGET.json')
  for n,h in reuse['files'].items():need(sha(B/n)==h,'Post-target explicit reuse '+n)
 else:
  B=O/'posttarget';run('posttarget-source-export',[sys.executable,'-X','utf8','-B',HERE/'helpers/export-posttarget299.py',P,B])
 need(sha(B/'249-records.bin')==R['posttarget_word_sha256']==load(P/'kernel-selection.json')['input_raw_sha256'],'Literal posttarget input')
 trade=O/'trade';run('joint-kernel-sink-construction',[sys.executable,'-X','utf8','-B',HERE/'code/compose-trade.py',P,B,HERE/'inputs/sinks9.json',O/'bin',trade,'9'])
 T=trade/'final';need(sha(T/'COHORT249-RECORDS.bin')==R['trade_word_sha256'],'1718-kernel nine-sink word')
 kr=O/'kernel-replay';cmd=[sys.executable,'-X','utf8','-B',K/'replay38.py','--predecessor',T,'--output',kr,'--cxx',a.cxx,'--include',HERE/'vendor']
 if a.boost_include:cmd+=['--include',a.boost_include.resolve()]
 run('kernels38-retiming61-fresh-source-and-controls',cmd)
 new=load(kr/'CERTIFICATE.json');need(new['status']=='PASS_SOURCE_BOUND_WEIGHTED275_KERNEL38_RETIMING_NATIVE_REPLAY'and new['all_controls_passed'],'Additional38/retiming61 complete certificate')
 need(new['compiled_here'] and new['source_baseline_restored'] and new['total_kernel_rank']==2243 and new['layer_kernel_rank']==78 and new['retiming']['changed_gates']==61,'Complete fresh kernel/retiming source audit');F=kr/new['final_directory'];need(sha(F/'COHORT249-RECORDS.bin')==R['inherited_word_sha256'],'Inherited1756 physical word')
 mr=O/'rank-modular-replay';cmd=[sys.executable,'-X','utf8','-B',G/'kernels159/replay159.py','--predecessor',F,'--output',mr,'--cxx',a.cxx,'--include',HERE/'vendor']
 if a.boost_include:cmd+=['--include',a.boost_include.resolve()]
 run('rank-modular159-fresh-source-and-controls',cmd)
 mc=load(mr/'CERTIFICATE.json');need(mc['status']=='PASS_SOURCE_BOUND_RANK_MODULAR159_NATIVE_REPLAY'and mc['all_controls_passed']and mc['compiled_here']and mc['source_baseline_restored'],'Fresh159 kernel and precision controls')
 need(mc['total_kernel_rank']==2402 and mc['layer_kernel_rank']==159,'Actual incremental159 inventory')
 MF=mr/mc['final_directory'];need(sha(MF/'COHORT249-RECORDS.bin')==R['rank_modular_word_sha256'],'Literal159 prefix word')
 F=O/'retiming51';run('actual51-source-span-frame-refinement',[sys.executable,'-X','utf8','-B',G/'retiming51/compose.py',MF,O/'bin',F])
 need(load(F/'DESCENT-CONSTRUCTOR.json')['selected_gates']==51 and sha(F/'COHORT249-RECORDS.bin')==R['word_sha256'],'Actual final1915 kernel112 retiming word')
 run('actual-guard-view',[sys.executable,'-X','utf8','-B',HERE/'helpers/prepare-actual-guard.py',F,O/'actual-guard'])
 run('all-actual-frame-state-rank-guards',[exe('export-guard'),O/'actual-guard',O/'ACTUAL-GUARD.json'])
 D=O/'inventory'
 for name in ['249-states.json','frames.json','249-DONOR-OWNERSHIP.json','COHORT249-RECORDS.bin','COHORT249-INITIAL.json','COHORT249-FINAL.json','COHORT249-FRAMES.json','COHORT249-REPLAY.json']:shutil.copyfile(F/name,D/name)
 shutil.copyfile(F/'249-records.bin',D/'249-records.bin');st=load(D/'249-states.json');st['final']=load(D/'COHORT249-FINAL.json');write(D/'249-states.json',st)
 run('all-current-global-columns',[exe('global'),D/'COHORT249-RECORDS.bin',D/'249-states.json',D/'GLOBAL.json'])
 rec=load(D/'COHORT249-REPLAY.json');need({str(k):v for k,v in load(D/'GLOBAL.json')['local_raw_H']}==rec['histogram'],'Actual word histogram receipt')
 guard=load(O/'ACTUAL-GUARD.json');need(guard['rank_mass']==rec['new_rank_mass']==R['paid_local_rank_mass']and guard['histogram']==rec['histogram'],'Independent frame/word mass')
 run('complete-banks',[exe('banks'),D,D/'COHORT249-INITIAL.json',D/'COHORT249-FRAMES.json',D,'gen5b-ti-response-kernels'])
 bank=load(D/'BANK-REVIEW.json');need(bank['actual_helper_roles']==R['actual_helper_roles']and bank['normalized_stock']==R['normalized_stock']and bank['literal_stock']==R['literal_stock'],'Actual stock/role binding')
 run('exact-inventory-price',[exe('price-complex'),D/'COHORT249-REPLAY.json',D/'BANK-REVIEW.json',C/'NATIVE.json',D/'PRICE.json'])
 run('complete-finite-invoice',[exe('finite'),D/'COHORT249-RECORDS.bin',D/'PRICE.json',D/'BANK-REVIEW.json',D/'GLOBAL.json',D/'FINITE.json'])
 run('dual-engine-fixed-prime-and47',[exe('fixed-complex'),D/'PRICE.json',D/'FINITE.json',C/'NATIVE.json',D/'FIXED-PRICE.json'])
 fixed=load(D/'FIXED-PRICE.json');need(fixed['kappa']==R['kappa']and len(fixed['strict_constraints'])==47,'Final exact kappa/47 binding')
 for p in sorted((HERE/'expected').glob('*.json')):need(norm(load(D/p.name))==norm(load(p)),'Expected native inventory '+p.name)
 for n,h in files.items():need(sha(HERE/n)==h,'Package changed '+n)
 for n,h in load(HERE/'vendor/PR275-ARCHIVE-MANIFEST.json')['files'].items():need(sha(P/n)==h,'Public source changed '+n)
 write(O/'CERTIFICATE.json',dict(status='PASS_SOURCE_BOUND_WEIGHTED1915_RANK_MODULAR159_RETIMING112_AND_EXACT47',package_manifest_sha256=sha(HERE/'MANIFEST.json'),public_head=R['public_head'],public_source_manifest_sha256=sha(P/'MANIFEST.json'),public_verification_sha256=sha(U/'verification.json'),public_output_reused=bool(a.reuse_public_output),complex_manifest_sha256=sha(HERE/'vendor/complex/MANIFEST.json'),complex_native_sha256=sha(C/'NATIVE.json'),complex_output_reused=bool(a.reuse_complex_output),posttarget_explicitly_reused=bool(a.reuse_posttarget),posttarget_word_sha256=sha(B/'249-records.bin'),trade_word_sha256=sha(T/'COHORT249-RECORDS.bin'),word_sha256=sha(F/'COHORT249-RECORDS.bin'),kernel_certificate_sha256=sha(kr/'CERTIFICATE.json'),rank_modular_certificate_sha256=sha(mr/'CERTIFICATE.json'),retiming_certificate_sha256=sha(F/'DESCENT-CONSTRUCTOR.json'),actual_guard_sha256=sha(O/'ACTUAL-GUARD.json'),inventory_receipt_sha256={n:sha(D/n)for n in ['BANK-REVIEW.json','GLOBAL.json','PRICE.json','FINITE.json','FIXED-PRICE.json']},fresh_executable_sha256={p.name:sha(p)for p in(O/'bin').iterdir()if p.is_file()},kappa=R['kappa'],decimal=R['decimal'],native_finite=True,inherited_all_size_interfaces=True,lean_certificate=False,seconds=time.monotonic()-start))
 print('PASS conditional kappa = '+R['decimal'],flush=True)
if __name__=='__main__':main()
