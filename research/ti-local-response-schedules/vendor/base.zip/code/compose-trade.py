"""Source-bound PR299 kernel/sink exchange; all mathematical checking is native."""
from pathlib import Path
import sys,json,struct,hashlib,shutil,subprocess,time
P,B,W,X,O=map(lambda x:Path(x).resolve(),sys.argv[1:6]);SINKCOUNT=int(sys.argv[6]) if len(sys.argv)>6 else 8
assert SINKCOUNT in (8,9)
OMIT={16635} if SINKCOUNT==8 else {16635,16691}
KCOUNT=1720-len(OMIT);KRANK=2192-11-(16 if SINKCOUNT==9 else 0)
O.mkdir(parents=True,exist_ok=True)
if any(O.iterdir()):raise RuntimeError('OUTPUT must be empty')
def load(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,separators=(',',':'))+'\n')
def run(name,*args):
 exe=X/(name+('.exe' if sys.platform=='win32' else ''));subprocess.run([str(exe),*map(str,args)],check=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mk(n):d=O/n;d.mkdir();return d
start=time.monotonic();k=load(P/'kernel-selection.json');st=load(B/'249-states.json');raw=(B/'249-records.bin').read_bytes();assert hashlib.sha256(raw).hexdigest()==k['input_raw_sha256'];assert st['physical']['scalar_projection_sha256']==k['input_scalar_sha256']
ev=list(struct.iter_unpack('<6i',raw));last={}
for i,(op,a,b,c,f,z) in enumerate(ev):
 if op==1 and z==4 and f==st['ZERO'] and st['v']<=a<2*st['v']:last[b]=i
entries=[dict(pivot=x['a'],roles=[x['a'],x['b']],dim=x['rank'],basis=x['basis'],cut_read=x['cut_read'])for x in k['pairs']]+[dict(pivot=x['pivot'],roles=[x['pivot']]+x['donors'],dim=x['rank'],basis=x['basis'],cut_read=x['cut_read'])for x in k['families']if x['pivot']not in OMIT]
assert len(entries)==KCOUNT and sum(x['dim']for x in entries)==KRANK
for x in entries:
 cut=max(last[r]for r in x['roles']);assert list(ev[cut][1:4])==x['cut_read'];x['cut']=cut
save(O/'selection1719.json',entries);seed=mk('seed');shutil.copyfile(B/'249-records.bin',seed/'COHORT249-RECORDS.bin')
for n,j in [('INITIAL',st['initial']),('FINAL',st['final']),('FRAMES',{}),('SELECTION',[]),('REPLAY',dict(cut_record=max(last.values()),new_gauges=0,new_entrance_rank=0,delta={},new_rank_mass=st['physical']['paid_rank_mass']))]:save(seed/('COHORT249-'+n+'.json'),j)
kout=mk('kernel');run('kernel-emit',B,seed,O/'selection1719.json',kout)
manifest=dict(states=str(B/'249-states.json'),new_selections=[],final_selection=str(kout/'COHORT249-SELECTION.json'),expected_layer_pivots=[KCOUNT],predecessor_words=[str(B/'249-records.bin')],final_word=str(kout/'COHORT249-RECORDS.bin'),setup_tags=[46],inverse_tags=[47]);save(O/'layer-manifest.json',manifest);run('layer-review',O/'layer-manifest.json',O/'LAYER-REVIEW.json')
r=mk('restored');run('restore',B,kout,r)
d=mk('restored-export');s=load(B/'249-states.json');s['initial']=load(r/'COHORT249-INITIAL.json');s['final']=load(r/'COHORT249-FINAL.json');fs=load(B/'frames.json');fs['frames'].update(load(r/'COHORT249-FRAMES.json'));raw=(r/'COHORT249-RECORDS.bin').read_bytes();ev=list(struct.iter_unpack('<6i',raw));s['physical']['paid_rank_mass']=load(r/'COHORT249-REPLAY.json')['new_rank_mass'];s['record_count']=len(ev);save(d/'249-states.json',s);save(d/'frames.json',fs);(d/'249-records.bin').write_bytes(raw);shutil.copyfile(B/'249-DONOR-OWNERSHIP.json',d/'249-DONOR-OWNERSHIP.json')
ss=load(W);ss['candidates']=[x for x in ss['candidates']if SINKCOUNT==9 or x['physical_role']!=16691];assert len(ss['candidates'])==SINKCOUNT
for x in ss['candidates']:
 writes=[i for i,e in enumerate(ev)if e[0]==1 and e[1]==x['physical_role'] and e[5]==12];assert writes;x['first_write_record']=min(writes);x['last_write_record']=max(writes);x['write_count']=len(writes);ff={e[4]for e in ev if e[0]==1 and e[2]==x['physical_role'] and e[5]==23};assert len(ff)==1;x['root_frame']=ff.pop()
save(O/'sinks8.json',ss);sink=mk('sink8');run('sink-transform',d,O/'sinks8.json',sink);run('sink-audit',d,sink,O/'SINK8-AUDIT.json')
f=mk('final');mp=load(sink/'OLD-TO-NEW.json');m=lambda x:mp[str(x)];actual=load(sink/'249-states.json');sel=load(r/'COHORT249-SELECTION.json');rec=load(sink/'receipt.json')
for x in sel:
 for q in ['pivot','a']:x[q]=m(x[q])
 for q in ['roles','partners']:x[q]=[m(z)for z in x[q]]
 assert min(x['roles'])>=0;x['original_pre_sink_cut']=x['cut'];x['cut']=rec['last_initial_D0_dirty_read']
rep=load(r/'COHORT249-REPLAY.json');rep.update(new_rank_mass=rec['rank_mass'],new_records=rec['records'],cut_record=rec['last_initial_D0_dirty_read'],histogram={str(a):c for a,c in rec['histogram']},actual_kernel_gauges=KCOUNT,actual_kernel_entrance_rank=KRANK,endpoint_stock_rank_saving=440,new_entrance_rank=KRANK,physical_sinks=SINKCOUNT)
for q,j in [('INITIAL',actual['initial']),('FINAL',actual['final']),('FRAMES',load(r/'COHORT249-FRAMES.json')),('SELECTION',sel),('REPLAY',rep)]:save(f/('COHORT249-'+q+'.json'),j)
for q in ['frames.json','249-DONOR-OWNERSHIP.json','OLD-TO-NEW.json','249-records.bin']:shutil.copyfile(sink/q,f/q)
shutil.copyfile(sink/'249-records.bin',f/'COHORT249-RECORDS.bin');actual['initial']={str(m(int(q))):z for q,z in st['initial'].items()if m(int(q))>=0};actual['final']={str(m(int(q))):z for q,z in st['final'].items()if m(int(q))>=0};save(f/'249-states.json',actual)
save(O/'TRADE-RECEIPT.json',dict(status='PASS_NATIVE_KERNEL_RESTORATION_SINK_EXCHANGE_NOT_BANK_OR_PRICE',kernel_input_sha256=k['input_raw_sha256'],kernel_selection_sha256=sha(P/'kernel-selection.json'),removed_kernel_pivots=sorted(OMIT),added_sinks=sorted(OMIT),kernel_entries=KCOUNT,entrance_rank=KRANK,sinks=SINKCOUNT,restorations=440,final_sha256=sha(f/'COHORT249-RECORDS.bin'),rank_mass=rec['rank_mass'],seconds=time.monotonic()-start))
