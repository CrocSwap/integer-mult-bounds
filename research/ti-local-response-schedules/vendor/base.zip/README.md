# Weighted gen5b with rank-modular response subsets

Conditional κ = 187790131334226197980871/250000000000000000000000000 ≈ 7.51160525336905 × 10⁻⁴. This finite native construction retains all 47 unchanged assembly inequalities. It is not a Lean certificate or an unconditional integer-multiplication theorem; inherited all-size analytic, compiler, routing, recovery and precision interfaces remain explicit conditions.

The new contribution is a sufficient response-kernel construction selected by a rank-plus-modular matroid objective. The 159 new rank-one gauges include proper subsets missed by earlier equal-response and whole-component scans. Exact signed integer prefix propagation admits dense donor sharing under the same 104-bit payload ceiling. The final word also rebinds 51 compatible post-sink refinements from PR299@7a30fddac2c413c9792a401e50a7e72bfbbb28f9. Every gain is priced from the actual complete word.

Actual inventory: 1,915 kernels, entrance rank 2,402, 9 sinks, 440 early restorations, 904 original plus 112 subsequent frame refinements, 15,423 independent helper roles, paid local rank mass 404,164, normalized stock 491,636, literal stock 2,458,180. The complex supplier is unchanged and independently source-audited.

Run an offline source checkout with Python 3.11+, a C++17 compiler, the included JSON header and Boost headers:

```text
python verify.py --output /fresh/output --cxx g++ --boost-include /path/to/boost/include
```

The default rebuilds the pinned public 12-stage source, both native suppliers, all successive physical constructions, every actual frame/endpoint/Gram guard, all arbitrary-dirty-input columns and signed prefix relations, new prime-admissible charts, complete stock/bank tiling, the finite invoice and two exact moment engines with all 47 strict clauses. Omission, F2-invisible double-edge, wrong-frame/scalar, malformed-index and extreme-coefficient controls are required. Optional authenticated reuse of completed unchanged checks is explicit in the receipt.

Final word SHA-256: c00eb838f0fcb21f5f069426b6503b47b2838d3da8abe42fdc7392f10bf6ac7e. Archives contain reproducible source/data, not executable binaries. MANIFEST.json authenticates the complete package, with separate archive manifests and retained public licenses/notices. PUBLIC-COVERAGE.json distinguishes metadata coverage from downloaded or independently replayed sources: 304 PR heads reviewed does not mean 304 certified packages.

The sufficient construction and limits appear in proof/CROSSOVER.md and the archived stage proofs. Bounded minimum-norm discovery has no global-optimality certificate; the final witness is verified independently with exact arithmetic.
