#!/usr/bin/env python3
"""Frozen37-gauge response-subset replay on the admitted1915-gauge reordered predecessor."""
from pathlib import Path
import argparse,concurrent.futures,copy,hashlib,json,os,shutil,struct,subprocess,sys,time
HERE=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
def load(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,s):
 if not ok:raise RuntimeError(s)
def write(p,j):Path(p).write_text(json.dumps(j,indent=2)+'\n',encoding='utf-8')
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--predecessor',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--layers',type=int,choices=[1],default=1);ap.add_argument('--without-retiming',action='store_true');ap.add_argument('--bin',type=Path);ap.add_argument('--cxx',default='g++');ap.add_argument('--include',type=Path,action='append',default=[]);a=ap.parse_args()
 need(sys.version_info>=(3,11)and sys.byteorder=='little','Python3.11+ little-endian required');S=a.predecessor.resolve();O=a.output.resolve();need(not O.exists(),'Fresh output required');B=load(HERE/'BINDING.json');M=load(HERE/'MANIFEST.json')['files'];actual={p.relative_to(HERE).as_posix()for p in HERE.rglob('*')if p.is_file()and p!=HERE/'MANIFEST.json'};need(actual==set(M),'Source bundle membership')
 for n,h in M.items():need(sha(HERE/n)==h,'Source bundle hash '+n)
 def semantic_digest():
  st=load(S/'249-states.json');st['initial']=load(S/'COHORT249-INITIAL.json');st['final']=load(S/'COHORT249-FINAL.json');fs=load(S/'frames.json');fs['frames'].update(load(S/'COHORT249-FRAMES.json'))
  data=dict(state={k:st[k]for k in B['semantic_keys']},frames=fs,donors=load(S/'249-DONOR-OWNERSHIP.json'),original_initial=load(S/'249-states.json')['initial'])
  return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 need(sha(S/'COHORT249-RECORDS.bin')==B['input_word_sha256'],'Admitted predecessor word binding')
 need(semantic_digest()==B['input_semantics_sha256'],'Admitted predecessor semantic binding')
 O.mkdir();start=time.monotonic()
 for n in ['tmp','logs','bin','predecessor','controls']:(O/n).mkdir()
 env={**os.environ,'TEMP':str(O/'tmp'),'TMP':str(O/'tmp'),'PYTHONDONTWRITEBYTECODE':'1'}
 def run(label,cmd,reject=None):
  print(label,flush=True)
  with(O/'logs'/(label+'.log')).open('w',encoding='utf-8')as f:r=subprocess.run(list(map(str,cmd)),cwd=O,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=300)
  if reject is None:need(r.returncode==0,label+' failed')
  else:need(r.returncode!=0 and reject in(O/'logs'/(label+'.log')).read_text(encoding='utf-8',errors='replace'),label+' not rejected for intended reason')
 native=a.bin.resolve()if a.bin else O/'bin';exe=lambda n:native/(n+('.exe'if os.name=='nt'else''))
 names=['kernel1-emit','layer-review','ordered-legality','kernel-prime-guard','global']
 if not a.bin:
  def compile_one(n):
   cmd=[a.cxx,'-O2','-std=c++17','-I',HERE/'code']
   for inc in a.include:cmd+=['-I',inc.resolve()]
   run('compile-'+n,cmd+[HERE/'code'/(n+'.cpp'),'-o',exe(n)])
  with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(compile_one,names))
 for n in names:need(exe(n).is_file(),'Native tool absent '+n)
 P=O/'predecessor';st=load(S/'249-states.json');fs=load(S/'frames.json');fs['frames'].update(load(S/'COHORT249-FRAMES.json'));st['initial']=load(S/'COHORT249-INITIAL.json');st['final']=load(S/'COHORT249-FINAL.json')
 for n in ['249-records.bin','249-DONOR-OWNERSHIP.json']:shutil.copyfile(S/n,P/n)
 shutil.copyfile(S/'COHORT249-RECORDS.bin',P/'COHORT249-RECORDS.bin');write(P/'249-states.json',st);write(P/'frames.json',fs);write(P/'COHORT249-FRAMES.json',{});write(P/'COHORT249-INITIAL.json',st['initial']);write(P/'COHORT249-FINAL.json',st['final']);write(P/'COHORT249-SELECTION.json',[])
 old=load(S/'COHORT249-REPLAY.json');rec=dict(inherited_predecessor_receipt=old,new_gauges=0,new_entrance_rank=0,actual_kernel_gauges=0,actual_kernel_entrance_rank=0,cut_record=613370,histogram={},delta={},scope='Admitted1915kernel9sink input; counters measure only additional54/55 layer.');write(P/'COHORT249-REPLAY.json',rec)
 current=P;preds=[];sels=[];counts=[];setup=[];inverse=[];checks=[]
 for i in range(1,a.layers+1):
  D=O/('final'if i==a.layers else'layer'+str(i));D.mkdir();q=B['layers'][i-1];sel=HERE/'inputs'/('kernel'+str(i)+'.json');run('emit'+str(i),[exe('kernel'+str(i)+'-emit'),current,current,sel,D]);need(sha(D/'COHORT249-RECORDS.bin')==q['word_sha256'],'Frozen emitted word mismatch')
  for n in ['249-records.bin','249-states.json','frames.json','249-DONOR-OWNERSHIP.json']:shutil.copyfile(P/n,D/n)
  preds.append(str(current/'COHORT249-RECORDS.bin'));sels.append(str(sel));counts.append(q['pivots']);setup.append(q['setup']);inverse.append(q['inverse'])
  J=dict(states=str(D/'249-states.json'),new_selections=sels[1:],final_selection=str(D/'COHORT249-SELECTION.json'),predecessor_words=preds.copy(),final_word=str(D/'COHORT249-RECORDS.bin'),expected_layer_pivots=counts.copy(),setup_tags=setup.copy(),inverse_tags=inverse.copy());jp=O/('LAYER'+str(i)+'-INPUTS.json');write(jp,J)
  run('signed-prefix'+str(i),[exe('layer-review'),jp,D/'LAYERS.json']);run('legality'+str(i),[exe('ordered-legality'),P,D,D/'LEGALITY.json',json.dumps(counts)])
  frames=[dict(basis=x['basis'],new_frame=x['new_frame_id'])for x in load(D/'INCREMENTAL-SELECTED.json')];need(frames==load(HERE/'inputs'/('frames'+str(i)+'.json')),'Actual new frame/basis binding');fp=O/('FRAMES'+str(i)+'.json');write(fp,frames);run('prime'+str(i),[exe('kernel-prime-guard'),fp,D/'PRIME.json']);run('global'+str(i),[exe('global'),D/'COHORT249-RECORDS.bin',D/'249-states.json',D/'GLOBAL.json'])
  r=load(D/'INCREMENTAL-RECEIPT.json');need((r['new_gauges'],r['new_entrance_rank'],r['old_rank_mass'],r['new_rank_mass'])==(q['pivots'],q['rank'],q['old_mass'],q['new_mass']),'Physical incremental bill');need(r['omitted_Q_nonzero_wrong_words']>0 and r['omitted_Qinverse_nonzero_wrong_words']>0,'Nonvacuous omission controls')
  w=bytearray((D/'COHORT249-RECORDS.bin').read_bytes());found=False
  for k in range(0,len(w),24):
   e=struct.unpack_from('<6i',w,k)
   if e[0]==1 and e[5]==q['setup']:w[k:k]=bytes(w[k:k+24])*2;found=True;break
  need(found,'Setup tag absent');bad=O/'controls'/('even'+str(i)+'.bin');bad.write_bytes(w);j=copy.deepcopy(J);j['final_word']=str(bad);bj=O/'controls'/('even'+str(i)+'.json');write(bj,j)
  run('even-F2-'+str(i),[exe('global'),bad,D/'249-states.json',O/'controls'/('even-F2-'+str(i)+'.json')]);run('even-integer-'+str(i),[exe('layer-review'),bj,O/'controls'/('even-Z-'+str(i)+'.json')],reject='literal selected edge mismatch')
  for label,reason in [('zero','basis rank'),('oversized','finite prime guard exceeded')]:
   v=copy.deepcopy(frames)
   if label=='zero':v[0]['basis'][0]=[0]*24
   else:v[0]['basis'][0][0]=str(2**90)
   bad=O/'controls'/(label+str(i)+'.json');write(bad,v);run(label+str(i),[exe('kernel-prime-guard'),bad,O/'controls'/(label+str(i)+'-receipt.json')],reject=reason)
  checks.append(dict(pivots=q['pivots'],rank=q['rank'],word_sha256=q['word_sha256'],input_word_sha256=sha(current/'COHORT249-RECORDS.bin'),receipts={n:sha(D/n)for n in ['LAYERS.json','LEGALITY.json','PRIME.json','GLOBAL.json','INCREMENTAL-RECEIPT.json']}));current=D
 retiming_check=None
 # Restore the original source inventory after auditing the normalized predecessor.
 # Actual COHORT initial/final frames and the physical word remain unchanged.
 source_initial=load(S/'249-states.json')['initial'];outstates=load(current/'249-states.json');outstates['initial']=source_initial;write(current/'249-states.json',outstates)
 outrec=load(current/'COHORT249-REPLAY.json');outrec.update(scope='Fields layer_* measure37 new gauges/rank37; new_* and actual_kernel_* aggregate1952 gauges/rank2439 over the original source initial inventory.',layer_new_entrance_rank=37,layer_new_gauges=37,new_entrance_rank=2439,new_gauges=1952,actual_kernel_entrance_rank=2439,actual_kernel_gauges=1952,source_initial_scope='Original weighted source inventory; actual COHORT initial contains1915 inherited plus37 new gauges.');write(current/'COHORT249-REPLAY.json',outrec)
 need((outstates['n'],outstates['v'])==(st['n'],st['v']),'Global row dimensions unchanged by source-inventory metadata restore')
 shutil.copyfile(current/'GLOBAL.json',current/'GLOBAL-SOURCE-BASELINE.json')
 # global.cpp reads only n,v from states; the literal word and dimensions are unchanged.
 tiny=O/'controls'/'tiny-states.json';write(tiny,dict(n=3,v=1));copy_blocks=[(2,0,0,0,0,1),(3,0,0,0,0,1)]*24
 for label,gate,reason in [('out-of-range',(1,4,0,1,0,0),'local dst'),('int-min',(1,1,0,-2147483648,0,0),'payloadfiniteprefix2^104')]:
  bad=O/'controls'/(label+'.bin');bad.write_bytes(b''.join(struct.pack('<6i',*q)for q in [gate]+copy_blocks));run(label,[exe('global'),bad,tiny,O/'controls'/(label+'.json')],reject=reason)

 for n,h in M.items():need(sha(HERE/n)==h,'Bundle changed during replay')
 need(sha(S/'COHORT249-RECORDS.bin')==B['input_word_sha256'] and semantic_digest()==B['input_semantics_sha256'],'Predecessor changed during replay')
 write(O/'CERTIFICATE.json',dict(status='PASS_SOURCE_BOUND_RANK_MODULAR37_NATIVE_REPLAY',manifest_sha256=sha(HERE/'MANIFEST.json'),input_word_sha256=B['input_word_sha256'],input_semantics_sha256=B['input_semantics_sha256'],output_files={p.relative_to(current).as_posix():sha(p)for p in current.iterdir()if p.is_file()},layers=checks,retiming=retiming_check,source_baseline_restored=True,total_kernel_rank=2439,layer_kernel_rank=37,final_directory=current.relative_to(O).as_posix(),compiled_here=not bool(a.bin),native_executable_sha256={n:sha(exe(n))for n in names},all_controls_passed=True,kappa_claimed=False,lean_certificate=False,scope='Exact native construction on a bound predecessor. Parent validates public-source admission, banks, finite billing, complex supplier and all47 root constraints. Inherited1915 gauges and440 endpoints are included in the actual input inventory;37/rank37 is incremental only. Exact signed prefix bounds retain the original2^104 ceiling.',seconds=time.monotonic()-start));print('PASS frozen gen5b kernel composition',flush=True)
if __name__=='__main__':main()
