# Exceptional HOST assigned to a degree-two nonleaf

## Conditional result

For the specific assignment and legal-word hypotheses below, the actual
type-B caller invoice satisfies

\[
 \frac{104}{76}\operatorname{repo}
 \le \frac{122406021878059699}{950000000000000}
 < 128.848444082169 < 128.891.
\]

The rational is an outward enclosure of the optimum of a **relaxed** price
problem, not an attained invoice. Its certified gap below 128.891 is
`40428121940301/950000000000000`, about `0.0425559178319`. The argument
extends the exceptional-leaf branch of
[#7919](https://github.com/CrocSwap/integer-mult-bounds/pull/7919) at head
`55b3e740a798e1647f00668540ed0ac13e2762cc`: now the second HOST incidence
at the exceptional stage belongs to a specifically named **degree-two**
nonleaf. It does not cover exceptional nonleaves of other degrees, arbitrary
HOST assignments, or general k=76 words. It constructs no legal word and
makes no κ claim. The structural deductions here are a paper argument, not a
new Lean theorem. The standard-library checkers verify finite arithmetic and
the stated small controls, not the structural hypotheses.

## Hypotheses

Use the type-B, k=76, Q=T=1 signed-frame and actual caller-word setup of
#7919 and [#7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869)
at head `06c207a9feb3994a4b987dc3010657b6e85b7956`:

1. There are 76 ordered two-column HOST stages, 151 positive-degree odd
   target roles, and exactly 76 degree-one roles (leaves). The field has
   characteristic not 2, `P=-I`, the diagonal HOST K-blocks are invertible,
   host columns obey target-mask support, and the #7919 rank-two and
   invertible cross-HOST Gram consequences hold.
2. The **nonempty charged stage-incidence events** are globally and
   bijectively assigned to pieces of roles: each role's nonempty pieces are
   disjoint and partition that role's target stage mask. The underlying
   event data satisfy `CallerEv.x_supp`, multi-stage `x_ker`, and the
   shared-stage biorthogonality laws. Per-stage `CallerEv.Match` alone does
   not establish this global partition.
3. One nonleaf `h` meets all stages, and another nonleaf `g` meets all but
   the exceptional stage `e`. At every common stage the two HOST singleton
   events are assigned one each to `h` and `g`. At `e`, one HOST singleton
   is assigned to `h`, and the other to a distinct specified role `r0`
   whose mask is exactly `{e,t}`, for one common stage `t`. There are 72
   other nonleaf, nonhub roles, each of degree at least two.
4. The frame and events arise through the `CallerWord` / `CallerWordD`
   bridges from a SPEC-legal type-B word with its sole thin in its own time
   slot. That thin is a QUERY or an odd IDLE, and the actual invoice has the
   `SchemaCostB.repo_eq` correction. These word/time/support conditions are
   needed to identify the actual invoice, not just its event-form model.

In particular, the desired assignment to `h,g,r0` is an additional
structural hypothesis. A global partition's mere existence does not select
these assignments. The global partition required here is **mask-only**:
the pair argument uses the separate event support law, not a requirement
that an assigned event's vector have support on its assigned role.
[#7918](https://github.com/CrocSwap/integer-mult-bounds/pull/7918) at
`5b17d4e4f2a89a8734d553489ece7d4efe5abe1e` proves mask-only existence under
certain invariant flags; it neither proves this named assignment nor covers
all irreducible blocks. Its strict-support separator has even q targets and
no HOSTs, and does not refute the present mask-only premise.

## The word-level thin correction

`CallerThin.leaf_rank` and HOST target-mask support give at most one leaf at
each HOST. The 76 leaves therefore occupy the 76 stages, one each. For each
leaf, the same support and `CallerThin.leaf_zero` force a nonzero B entry in
the unique thin column: without that entry, the leaf basis vector is invisible
outside its own HOST, contradicting `P=-I` and the nondegenerate HOST block.

If the unique thin is an odd IDLE with nonempty stage mask `S`, choose
`s∈S` and a leaf at another stage `u≠s`. The word-level q-odd B-vector is
the D-incidence vector at `q=1,D=1`: `idle_base` gives the identity base,
`CallerWord.terms` supplies the odd factor, and `CallerWordD.legal_masks`
gives zero on the leaf whose target mask is `{u}`. This contradicts the
leaf's required nonzero thin B entry. Therefore an odd IDLE's mask is empty;
alternatively the thin is a QUERY. The correction in `SchemaCostB.repo_eq`
is zero in either case. This repeats #7919's word argument, whose HOST-to-leaf
assignment was not used. It does **not** follow from abstract `EvData` alone.

## Pair coverage under the global partition

For each common stage `s`, let `H` be the roles whose masks contain both
`e` and `s`. Role `h` lies in `H`; `g` and all leaves do not. HOST block
support reduces the invertible cross Gram block `B_e^T A_s` to a product
through coordinates in `H`. Consequently `B_e^T` has rank two on the
coordinate subspace indexed by `H`.

Suppose that every role in `H\{h}` has `e` and `s` in the same assigned
piece. Each such piece is a distinct multi-stage event. Its event vector is
supported in `H` by `x_supp`, lies in the kernel of `B_e^T` by `x_ker`, and
the vectors are independent by shared-stage biorthogonality. This would put
`|H|-1` independent vectors into a kernel of dimension `|H|-2`, impossible.
Hence for every `s≠e`, at least one nonhub nonleaf containing `e,s` has them
in different pieces.

The HOST event assigned to `r0` at `e` is the singleton `{e}`. Its degree-two
mask and the global partition force a second, distinct singleton event `{t}`.
It covers exactly one of the 75 exceptional/common pairs. Since the two
HOSTs at `t` already belong to `h,g`, the `{t}` event assigned to `r0` is
not one of those HOST events. For every other common stage, `r0` is absent
from `H`, so the separating role is among the remaining 72 nonleaves.
Writing `P_r(e)` for the assigned piece containing `e`, the actual data obey

\[
 \sum_{r\ne h,g,r0:\ e\in M_r\text{ and }r\text{ split}}
      (|M_r|-|P_r(e)|)\ge74. \tag{1}
\]

Each split role has degree `d≤76` and covers at most `d-1` of these pairs.
Assigning that full capacity to every split role, even one missing `e`, is
an intentionally favorable relaxation.

## Invoice and single charging

Put `p(x)=x^(99/100)`, `v(d)=p(8d+1)-p(8d)`,
`s(d)=v(2)-v(d)`, and

\[
 \Delta(d)=p(8)+p(8d-8)-p(8d),\qquad c(d)=s(d)+\Delta(d).
\]

Before charging split losses, the standard event-form baseline is

\[
 B=\frac{104}{76}[p(609)-76p(8)+p(601)-75p(8)
 +76v(1)+73v(2)-1]. \tag{2}
\]

The terms for `h,g` pay for their 151 HOST incidences. All 76 leaf pieces
are singleton events; at `e` the leaf's event is distinct from both HOST
incidences. The baseline treats `r0` optimistically as an unsplit degree-two
role, contributing `v(2)=p(17)-p(16)`. Its actual two singleton pieces
contribute `p(17)-2p(8)`, so the baseline must be reduced by exactly
`Δ(2)=2p(8)-p(16)`. This accounts for the exceptional HOST singleton and the
separate `{t}` singleton **once each**. Equivalently, the full unsplit-other-
roles expression has coefficients `-229 p(8)-72 p(16)`; of the 229
singleton charges, 152 are native HOST incidences and 77 are non-HOST events
(76 leaf events plus `r0`'s `{t}` event). There is no separate subtraction
for the exceptional HOST. The `-1` is the sole Q charge, and the word-level
correction has been shown to vanish.

For any other degree-`d` nonleaf, an unsplit role loses `s(d)≥0` against
`v(2)`. A split role loses at least `c(d)`: merging pieces cannot increase
fragmentation loss, and concavity places the least two-piece loss at sizes
`1,d-1`.
The checker verifies all relevant finite degree inequalities with integer
root enclosures; the merging/subadditivity step is a paper deduction.

## Exact finite price certificate

At scale `S=10^14`, the checker bounds every `p(b)` by consecutive integers
verified through 100th powers. With all coefficients outward-rounded,
`B` before the factor `104/76` is at most `9470634903078812/S`, and
`Δ(2)≥10824560279425/S`. For remaining-pair demand `q` the checker computes

\[
 F(0)=0,\qquad
 F(q)=\min_{2\le d\le76}\{c_{\rm low}(d)
          +F(\max(0,q-d+1))\}.
\]

It permits an unlimited number of split roles, although the actual case has
at most 72. The exact integer dynamic program returns
`F(74)=43962506025564/S`, at degree 75. Thus (1)–(2) give the rational
ceiling stated at the start. A separate checker uses Newton roots at scale
`10^15` and a different, bounded 72-role dynamic program; its conservative
ceiling is `153007527347570207/1187500000000000`, also below the bar.

The inherited #7919 split-coverage checker independently returns the same
`(75,2)` relaxed profile and the same primary upper for its ≥2 nonhub-split
branch. Its one-split triple/cell duals are not needed for this case.

## Calibration and failure controls

* In the original exceptional-leaf assignment, the pair cut alone permits
  an abstract one-split degree-76 profile. Its root-enclosed modeled value
  exceeds `128.995`; thus our forced second split cannot be imported there.
  #7919's triple/cell constraints and integer-anchor duals handle that
  additional case. The modeled profile is not a legal-word construction.
* Treating `r0` as unsplit and omitting its residual singleton's split loss
  leaves a relaxed value above `128.996`. The local partition checker rejects
  both an omitted `{t}` event and an overlapping `{e,t}` event alongside
  the HOST singleton; it also detects assigning that same HOST to a leaf.
* A fictitious nonempty two-stage odd IDLE has positive correction
  `1+p(16)-p(17)`; adding it to the relaxed price gives a value above
  `128.899`. This is an invalid controller for the stated word slice and
  illustrates why its word-level correction proof is needed.

The numerical controllers are only relaxations. No one of them supplies a
signed frame, global event assignment, or legal caller word.

## Reproduction and provenance

The direct sources are pinned #7919, #7869, and Round 4 stream 16 / #7918;
their relevant manifests, two replay archives and the #7869 open targets are
under `source/`. `verify_sources.py` checks Git blob identities observed at
those heads, replay SHA-256 digests, both inner archive manifests and the
readable #7918 copy. Source checks do not re-prove upstream claims.

```sh
python3 -I -B verify_sources.py
python3 -I -B check.py
python3 -I -B independent_check.py
```

Calibration additionally extracted the pinned #7919 archive and ran its
`check.py`, `independent_check.py` and `review_check.py`; all passed. Its
leaf proof and duals are frozen in `source/7919/replay.tar.gz` and their
logs in `calibration/`. The #7918 strict-separator and independent
certificate scripts also passed from the pinned archive. `RESULT.json` is
regenerated by `check.py`.

Remaining premises are the actual legal-word/host bridge and zero-correction
argument, the stated signed frame and `EvData` laws, existence of the global
mask partition with these **particular** HOST assignments, the 76-leaf and
degree-two mask hypotheses, and a formalization/review of the new pair and
accounting deductions. None is supplied by the numerical DP.
