#!/usr/bin/env python3
"""Exact arithmetic and small bookkeeping controls for the degree-2 HOST case.

No numerical assertion establishes an actual legal word, its frame, the global
event partition, or the paper rank/word arguments. Read README.md first.
"""
from collections import defaultdict
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction
import json
from pathlib import Path

S = 10**14
BAR = Fraction(128891, 1000)
ROOTS = {}


def p_root(n):
    """Enclose n^(99/100) at scale S by exact 100th-power comparison."""
    if n not in ROOTS:
        target = n**99 * S**100
        lo, hi = 0, (n + 1) * S
        while lo + 1 < hi:
            mid = (lo + hi) // 2
            if mid**100 <= target:
                lo = mid
            else:
                hi = mid
        assert lo**100 <= target < (lo + 1)**100
        ROOTS[n] = (lo, lo if lo**100 == target else lo + 1)
    return ROOTS[n]


def bound(terms, upper):
    counts = defaultdict(int)
    for n, coeff in terms:
        counts[n] += coeff
    return sum(coeff * p_root(n)[int((coeff > 0) == upper)]
               for n, coeff in counts.items() if coeff)


def s_terms(d):
    return [(17, 1), (16, -1), (8*d+1, -1), (8*d, 1)]


def delta_terms(d):
    return [(8, 1), (8*(d-1), 1), (8*d, -1)]


def split_terms(d):
    return s_terms(d) + delta_terms(d)


BASE = [(609, 1), (601, 1), (9, 76), (17, 73),
        (8, -227), (16, -73), (1, -1)]


def scaled(x):
    return Fraction(104*x, 76*S)


def decimal_up(value):
    with localcontext() as ctx:
        ctx.prec = 60
        ctx.rounding = ROUND_CEILING
        return str((Decimal(value.numerator) / Decimal(value.denominator))
                   .quantize(Decimal('0.000000000001')))


def valid_partition(mask, events):
    """Local mask-only check: unique nonempty IDs, disjoint union = mask."""
    seen_ids, union = set(), set()
    for name, piece in events:
        if name in seen_ids or not piece or not piece <= mask or union & piece:
            return False
        seen_ids.add(name)
        union |= piece
    return union == mask


def main():
    # Degree losses and two-part minimum: higher partition counts only add
    # concave fragmentation loss, by subadditivity of x^(99/100).
    costs = {d: bound(split_terms(d), False) for d in range(2, 77)}
    assert all(costs[d] > 0 for d in costs)
    assert all(bound(s_terms(d), True) < bound(s_terms(d+1), False)
               for d in range(2, 76))
    for d in range(4, 77):
        for a in range(2, d-1):
            two_piece = [(8*a, 1), (8*(d-a), 1), (8*d, -1)]
            assert bound(two_piece, False) > bound(delta_terms(d), True)

    # The specified role r0 contributes only one of the required 75 pairs.
    # Arbitrarily many other split roles are allowed here (a relaxation of 72).
    # need[q] is the least root-enclosed loss covering at least q pairs.
    need, winner = [0], [None]
    for q in range(1, 75):
        total, d = min((costs[d] + need[max(0, q-(d-1))], d)
                       for d in range(2, 77))
        need.append(total)
        winner.append(d)
    assert winner[74] == 75
    assert need[74] == costs[75]
    r0_loss = bound(delta_terms(2), False)
    base_hi = bound(BASE, True)
    upper = scaled(base_hi - r0_loss - need[74])
    assert upper < BAR

    # Calibration: the leaf-HOST assumptions permit the coarse degree-only
    # controller with one degree-76 split covering all 75 pairs. It is not a
    # legal word/frame, and the real #7919 triple/cell cuts still apply.
    leaf_relaxation_lower = scaled(bound(BASE, False)
                                   - bound(split_terms(76), True))
    assert leaf_relaxation_lower > BAR
    # If the exceptional degree-2 role were incorrectly charged as unsplit,
    # the best remaining-split controller is also too expensive for the bar.
    no_residual_charge_lower = scaled(bound(BASE, False)
                                      - bound(split_terms(75), True))
    assert no_residual_charge_lower > BAR

    # A nonempty odd IDLE has a positive correction. If a two-stage odd IDLE
    # were allowed on top of the relaxed maximizing profile, it would put its
    # modeled invoice above the bar; legal-word leaf support excludes this.
    idle2_correction = [(1, 1), (16, 1), (17, -1)]
    assert bound(idle2_correction, False) > 0
    fake_idle_lower = scaled(bound(BASE, False)
                             - bound(delta_terms(2), True)
                             - bound(split_terms(75), True)
                             + bound(idle2_correction, False))
    assert fake_idle_lower > BAR

    # The named HOST is assigned once to r0; partition forces a distinct
    # residual event on t. Cheaper merged and missing-event controls fail.
    mask = {'e', 't'}
    correct = [('host_e', {'e'}), ('residual_t', {'t'})]
    missing_residual = [('host_e', {'e'})]
    illegal_merge = [('host_e', {'e'}), ('merged', {'e', 't'})]
    assert valid_partition(mask, correct)
    assert not valid_partition(mask, missing_residual)
    assert not valid_partition(mask, illegal_merge)
    assigned_to_r0 = {x for x, _ in correct}
    falsely_assigned_to_leaf = {'host_e'}
    assert assigned_to_r0 & falsely_assigned_to_leaf

    # #7919's independently replayed 2+-split certificate has the same bound.
    inherited = Fraction(122406021878059699, 950000000000000)
    assert upper == inherited
    out = {
        'scope': 'conditional one degree-two exceptional nonleaf HOST assignment',
        'root_scale': S,
        'root_count': len(ROOTS),
        'required_pairs_total': 75,
        'specified_degree_two_role_coverage': 1,
        'other_roles_required_coverage': 74,
        'other_role_count_allowed_by_relaxation': 'unbounded (actual at most 72)',
        'other_role_optimum': {'degrees': [75], 'loss_lower_scaled': need[74]},
        'specified_degree_two_split_loss_lower_scaled': r0_loss,
        'base_upper_scaled': base_hi,
        'normalized_upper': str(upper),
        'normalized_upper_decimal_rounded_up': decimal_up(upper),
        'bar': str(BAR),
        'gap_lower': str(BAR-upper),
        'gap_decimal_display': f'{float(BAR-upper):.12f}',
        'calibration': {
            'leaf_one_split_degree76_relaxation_lower': str(leaf_relaxation_lower),
            'leaf_controller_above_bar': leaf_relaxation_lower > BAR,
            'unbilled_residual_split_relaxation_lower': str(no_residual_charge_lower),
            'unbilled_residual_split_control_above_bar': no_residual_charge_lower > BAR,
            'fake_two_stage_odd_idle_relaxation_lower': str(fake_idle_lower),
            'fake_odd_idle_control_above_bar': fake_idle_lower > BAR,
            'legal_degree2_piece_partition': True,
            'missing_residual_rejected': True,
            'merged_piece_plus_host_rejected': True,
            'duplicate_host_assignment_detected': True,
            'note': 'Controls are relaxed arithmetic and local masks, not legal caller witnesses.'
        },
        'proof_status': 'exact finite arithmetic; structural and legal-word premises remain paper arguments'
    }
    Path(__file__).with_name('RESULT.json').write_text(json.dumps(out, indent=2) + '\n')
    print(json.dumps(out, indent=2))


if __name__ == '__main__':
    main()
