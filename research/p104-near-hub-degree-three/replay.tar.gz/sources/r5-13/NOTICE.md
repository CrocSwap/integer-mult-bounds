This research packet was prepared with substantial OpenAI Codex assistance.
It retains the Apache-2.0 license and predecessor notices in the pinned
archives and readable #7918 source. The P104 signed-frame, event, cost and
legal-word infrastructure and #7869 guidance are credited to DreamingOfClouds
with Claude Opus 5.5 via Claude Code. The near-hub, invariant-flag, and
earlier predecessor sources retain their original notices and authorship in
`source/7919/replay.tar.gz` and `source/7918-published/replay.tar.gz`.

The new degree-two nonleaf pair-coverage and invoice argument is a scoped
paper derivation; the included programs check arithmetic and controls. It is
not presented as a Lean theorem or a general k=76 result.
