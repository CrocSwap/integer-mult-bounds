#!/usr/bin/env python3
"""Independent Newton roots and bounded-count coverage DP; arithmetic only."""
from fractions import Fraction

S = 10**15
R = {}


def root(n):
    if n not in R:
        rhs = n**99*S**100
        x = (n+1)*S
        while True:
            y = (99*x + rhs//x**99)//100
            if y >= x:
                break
            x = y
        while (x+1)**100 <= rhs:
            x += 1
        while x**100 > rhs:
            x -= 1
        assert x**100 <= rhs < (x+1)**100
        R[n] = (x, x + (x**100 < rhs))
    return R[n]


def calc(terms, upper=False):
    # Unlike the primary checker, each occurrence is rounded separately.
    # This is conservative even where the same base occurs more than once.
    return sum(coeff*root(n)[int(upper == (coeff > 0))]
               for n, coeff in terms if coeff)


def s(d):
    if d == 2:
        return 0
    return calc([(17, 1), (16, -1), (8*d+1, -1), (8*d, 1)])


def delta(d):
    return calc([(8, 1), (8*(d-1), 1), (8*d, -1)])


def main():
    split_cost = {d: s(d)+delta(d) for d in range(2, 77)}
    assert all(x > 0 for x in split_cost.values())
    # States encode coverage after exactly count other split roles. The true
    # case has 72 such roles; this deliberately grants each full d-1 capacity.
    states = {0: 0}
    best = None
    for count in range(1, 73):
        nxt = {}
        for already, loss in states.items():
            for d in range(2, 77):
                covered = min(74, already+d-1)
                candidate = loss+split_cost[d]
                nxt[covered] = min(nxt.get(covered, candidate), candidate)
        states = nxt
        if best is None or states[74] < best[0]:
            best = states[74], count
    assert best == (split_cost[75], 1)
    base = calc([(609, 1), (601, 1), (9, 76), (17, 73),
                 (8, -227), (16, -73), (1, -1)], upper=True)
    result = Fraction(104*(base - delta(2) - best[0]), 76*S)
    bar = Fraction(128891, 1000)
    assert result < bar
    print('PASS independent Newton roots:', len(R))
    print('PASS bounded 72-role coverage DP; minimizer degrees:', [75])
    print('PASS conditional directed upper:', result, '=', float(result), '<', bar)
    print('Paper rank, global partition, legal word and price bridges are not checked.')


if __name__ == '__main__':
    main()
