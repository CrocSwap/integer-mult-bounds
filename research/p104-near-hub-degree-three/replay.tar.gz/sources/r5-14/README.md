# Q=0 rank-three mask attribution: one shared stage and a finite screen

Research note, 2026-11-21. Parent: Round 4 stream 16 and [PR #7918](https://github.com/CrocSwap/integer-mult-bounds/pull/7918), pinned at `5b17d4e4f2a89a8734d553489ece7d4efe5abe1e`. The Q=0 word checker comes from [PR #7869](https://github.com/CrocSwap/integer-mult-bounds/pull/7869) at `06c207a9feb3994a4b987dc3010657b6e85b7956`. This note concerns **mask-only event attribution**. It does not prove strict support, an odd-q HOST caller, a P104 invoice, or a new κ bound.

There are two results. First, an endpoint-mask overlap condition gives a constructive attribution in any quotient dimension: all overlaps between distinct target masks must be confined to at most one stage. Second, exact enumeration plus a matrix obstruction proves the same conclusion for **all three-dimensional quotients with at most four stages**, without any overlap restriction. A literal absolutely irreducible three-dimensional positive control shows that the first result applies outside #7918's one-/two-dimensional flag criterion.

## Formal domain

Work over a characteristic-zero field K. In a d-dimensional quotient, each incidence event e has a nonempty squarefree stage mask `S_e`, and a rank-one idempotent `p_e`. There are independent indeterminates `D_1,...,D_k` and a fixed event order satisfying the *full formal polynomial identity*

```
F(D) = product_e [(I - p_e) + (product_{t in S_e} D_t) p_e]
     = sum_{r=1}^d (product_{t in M_r} D_t) E_r.
```

Here `E_r` are pairwise annihilating rank-one idempotents with sum I; each endpoint mask `M_r` is squarefree. Empty endpoint masks and repeated endpoint masks are allowed, and distinct events may have identical masks. The matrix product is ordered; no commutativity is assumed. An attribution assigns every event to one r so that its masks are disjoint and their union is exactly `M_r`.

For a common invariant flag of the original incidence projectors as in #7918, every rank-one event has nonzero rank on exactly one quotient: the quotient traces are nonnegative integers summing to one. The original endpoint is diagonal and its coefficient projectors, grouped by equal endpoint monomials, preserve every flag subspace, since the flag is invariant under the formal endpoint polynomial. On each quotient these grouped projectors remain pairwise orthogonal idempotents. Splitting each grouped eigenspace into one-dimensional summands gives the fixed `E_r` above and matches the quotient endpoint monomials to actual roles, with multiplicity. Thus attributions obtained separately on quotients combine globally, while preserving #7918's caveat that a chosen grade need not have strict support on its named original role.

## Stage-projector lemma

For stage t, let `P_t = sum_{r:t in M_r} E_r` and `E(t)={e:t in S_e}`. Determinants of the full identity give `|E(t)| = rank(P_t) = m_t`. Now put all other D variables equal to 1 and differentiate at `D_t=1`; no commutation is used:

```
sum_{e in E(t)} p_e = P_t.
```

Write the m rank-one projectors as `p_i=v_i w_i`, with `w_i v_i=1`, and put V and W together from these columns and rows. The equation `VW=P_t` and `rank(P_t)=m` give both factors rank m. Since `(VW)^2=VW`, left and right inverses imply `WV=I_m`. Hence

```
p_i p_j = 0 for i != j,       P_t p_i = p_i P_t = p_i.
```

Both multiplication orders vanish. Consequently, `p_e` is supported in `R_e={r:S_e subset M_r}`: `p_e = P_R p_e P_R` for the sum of its eligible `E_r`. In particular `R_e` cannot be empty. The stage-local events also admit a role matching: the independent V columns restricted to the stage's coordinate subspace have a nonsingular square matrix, so one determinant term gives a matching using nonzero entries. This mask-level matching is weaker than strict original-role attribution.

## Positive theorem: disjoint masks and one shared stage

**Theorem.** If the endpoint masks are pairwise disjoint, or if every stage belonging to more than one endpoint mask is the same stage t, the formal identity implies a mask-only attribution. This holds for every d, including d=3, regardless of reducibility and event order.

**Proof.** If a stage s is in only endpoint mask `M_r`, the determinant gives exactly one incidence event containing s, and the stage-projector lemma forces its projector to be `E_r`. Therefore any event containing exclusive stages can contain exclusive stages of at most one role, and is assigned to that role. This covers each exclusive stage exactly once. In the disjoint case every nonempty event has such a stage, so the construction is complete.

In the one-shared-stage case, every event containing t and an exclusive stage is already assigned to its forced role. The stage lemma shows its `E_r` lies in the range of `P_t`, so t is actually in that role's mask. Two such events cannot have the same role, because their projectors would both be `E_r` while t forces them to annihilate one another. Every remaining unassigned event contains only t. The determinant counts exactly as many t events as t-bearing endpoint roles. Assign these remaining singleton events bijectively to the as-yet-unassigned t-bearing roles. All role masks are partitioned. □

This is a sufficient condition, not a characterization. The actual #7869 controls can have many overlapping stages and the result does not settle their general high-dimensional case.

## Exact finite theorem: dimension three and at most four stages

For each stage-labelled k=1,2,3,4 and each unordered triple of squarefree endpoint masks, including empty and repeated masks, `mask_scan.py` enumerates **every multiset** of nonempty squarefree event masks with the same stage multiplicities as the endpoints. It keeps only events lying in at least one endpoint, then tests stage-local matching, individual trace-subset support, and a global exact mask partition.

Trace support is necessary: expand `tr F(D)` in event subsets. Every endpoint monomial has a positive integer multiplicity in characteristic zero. If an endpoint monomial occurs, some event subset has exactly that mask, with no repeated stage. The exterior-square trace supplies only the complementary two-endpoint subset supports here: determinant identifies a subset's complement, so no additional independent support test is claimed.

The surviving nonpartitions are all impossible by the following exact matrix condition. If a set R has h roles and h event projectors are pairwise orthogonal and supported inside R, their sum is the coordinate projector `P_R`. Pairwise shared stages suffice for orthogonality, by the stage lemma. If two such saturated collections for the same R differ by only one event on each side, those two projectors are equal. Equality is impossible when those events share a stage, or when their eligible role sets are disjoint. `mask_scan.py` checks this condition by finite combinations, with event indices distinct even for repeated masks.

| k | Endpoint triples | Compatible event multisets | Pass local matching and trace | Without global partition | Ruled out by saturated projectors |
|---|---:|---:|---:|---:|---:|
| 1 | 4 | 4 | 4 | 0 | 0 |
| 2 | 20 | 36 | 35 | 0 | 0 |
| 3 | 120 | 721 | 642 | 7 | 7 |
| 4 | 816 | 27,750 | 21,387 | 666 | 666 |

A separate `crosscheck_masks.py` uses a different enumeration order: it first enumerates all event multisets and buckets them by stage degrees, then assigns endpoint triples. It checks each role's exact-cover subsets by event-index bitsets, checks global coverage independently, and recomputes saturation certificates. It reproduces every count in the table. Therefore **every formal quotient identity in the stated domain with dimension three and k≤4 has a mask-only attribution**. This is a finite result and does not prove the arbitrary-k rank-three case.

For a representative mask-level near miss, let the endpoint masks be `12,1234,1234` and event masks `124,13,23,1,2,4`. The necessary local and trace checks pass, but no global partition exists. The events `124`, `13`, and `23` all have projectors supported on the two full-mask roles. The pairs `(124,13)` and `(124,23)` each share a stage and saturate those two roles, so their sums are equal; hence `p_13=p_23`. These two events share stage 3, so they must annihilate, a contradiction to nonzero idempotence. No literal symbolic word realizing this near miss is claimed.

## Literal controls and boundaries

`one_shared-word.json` has three roles and four stages, with masks `{1,4}`, `{2,4}`, `{3,4}`. It is a q-free source word made from IDLE_ONE and invertible ADD operations. Its stage-4 events are conjugates of a complete coordinate decomposition; the middle stage-4 block is the scalar `D_4 I`. The original #7869 checker verifies the exact symbolic-D identity at all four fourth roots of q, and an independent SymPy row-operation replay verifies the formal identity directly. A mutated stage mask fails both checks.

For this word the three private-stage projectors are `E_0,E_1,E_2`, and one stage-4 projector is

```
p = [[ 1, 1, 1],
     [ 1, 1, 1],
     [-1,-1,-1]].
```

All nine `E_i p E_j` are nonzero multiples of the nine matrix units; their flattened matrix has exact determinant `-1` and rank 9. The projectors therefore generate `M_3(Q)` and are absolutely irreducible, including over field extensions. The theorem applies despite the lack of any nontrivial common invariant subspace. `disjoint-word.json` provides a separate three-role disjoint-mask control. Exact mask-only and strict witnesses for these examples are in `WORD-CONTROLS.json`.

Both words have no HOST and even q targets; the irreducible example has `n+2=5` and `2k=8`. They do not satisfy the full tight odd-target HOST branch. The finite-screen obstructions are mask systems, not symbolic word counterexamples. No new strict-support theorem or caller-cost conclusion follows.

## Reproduction and sources

Run with Python 3 and SymPy:

```
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -B verify.py
```

It validates the manifest and source bytes, independently regenerates the words and results in a temporary directory, reruns both enumeration methods, and compares all outputs. The source #7918 replay archive is `SOURCE-7918.tar.gz`, fetched from the pinned commit and checked against its published SHA-256 `beab0fdb56c3b3fabbe9650048d24c784ea82c3ef45e744ab240462f1b00403e`; its attribution and #7869 checker bytes agree with the copied files under `source/`. The same checker also matches the pinned #7869 git object. See `UPSTREAM-NOTICE.md` and `LICENSE` for the original toolkit credit and terms. #7918 was prepared by Clear1nsight with substantial OpenAI Codex assistance; DreamingOfClouds authored the pinned toolkit. The present proof, two enumerators, and examples were prepared with OpenAI Codex assistance.

Next condition: extend the saturation certificate or prove an analogue for k≥5, or exhibit a literal rank-three word with a missing global attribution and independently verify its full symbolic identity. A mask-only candidate is not a counterexample. Separately identify strict-support and tight odd-target HOST premises before drawing any full-caller conclusion.
