# Validation

On 2026-11-21, the source-snapshot checks, primary directed integer-root
coverage DP and synthetic price-accounting controls, Newton-root 72-role DP,
and separate reviewer 10^20-root DP passed. The reviewer separately examined
the exceptional pair-kernel proof, the exact 152 HOST charges, leaf and
residual event counts, the one-thin idle correction, and the standalone
nonodd-target billing algebra. The review remains conditional on the named
global assignment, frame and actual-word bridge, and does not build a caller.

The replay commands are in README.md. `RESULT.json` is exact primary output;
`independent.log` records the second arithmetic implementation. The original
combined reviewer program and result are copied unchanged under `reviewer/`;
its near-hub-only extraction reproduces the near-hub part without requiring
the other round-six placement input. Source hash checks establish selected
copied blob identities, not the mathematical implications.
