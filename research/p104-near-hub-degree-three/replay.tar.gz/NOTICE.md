This research packet was prepared with substantial OpenAI Codex assistance.
It retains the Apache-2.0 license and copied predecessor notices under
`sources/`. The P104 signed-frame, event, word and price infrastructure and
#7869 guidance are credited to DreamingOfClouds with Claude Opus 5.5 via
Claude Code. The Round 5 stream 13/14 sources retain their original notices.

The degree-three conditional pair-coverage and complete signed-invoice
argument here is a scoped paper derivation. An independent Codex campaign
reviewer checked the structure and supplied the original combined arithmetic
checker under `reviewer/`; the near-hub extraction is marked as such. Neither
review nor numerical checking is represented as a formal proof, a caller
construction, or a general κ bound.
