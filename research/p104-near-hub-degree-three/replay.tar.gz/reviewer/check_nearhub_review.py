#!/usr/bin/env python3
"""Near-hub-only extract of the independent reviewer checker.

The unchanged original and original combined result are in this directory.
"""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json

S = 10**20
@lru_cache(None)
def root(n):
    value = n**99 * S**100
    a,b=0,(n+1)*S
    while a+1<b:
        m=(a+b)//2
        if m**100<=value: a=m
        else: b=m
    return a, a if a**100==value else a+1

def bounds(terms):
    c=Counter()
    for n,v in terms: c[n]+=v
    lo=hi=0
    for n,v in c.items():
        a,b=root(n)
        if v>=0: lo+=v*a;hi+=v*b
        else: lo+=v*b;hi+=v*a
    return lo,hi

def cost(d):
    # v(2)-v(d) plus smallest possible loss for two nonempty pieces.
    return bounds([(17,1),(16,-1),(8*d+1,-1),(8,1),(8*(d-1),1)])[0]

# Up to 72 split roles, allow each of them full d-1 pair coverage.
dp=[0]+[None]*73
for _ in range(72):
    prev=dp[:]
    for q in range(1,74):
        vals=[cost(d)+prev[max(0,q-d+1)] for d in range(2,77)
              if prev[max(0,q-d+1)] is not None]
        if vals:
            val=min(vals)
            dp[q]=val if dp[q] is None else min(dp[q],val)
assert dp[73]==cost(74)
base=[(609,1),(601,1),(9,76),(17,73),(8,-227),(16,-73),(1,-1)]
idle=[(1,1),(608,1),(609,-1)]
# Concavity makes 1+p(8d)-p(8d+1) increase with d; bound all 76 directly too.
idle_hi=max(bounds([(1,1),(8*d,1),(8*d+1,-1)])[1] for d in range(1,77))
assert idle_hi==bounds(idle)[1]
res={}
for key,loss in {
    'e_plus_st':[(17,1),(25,-1),(8,1)],
    'e_plus_s_plus_t':[(17,1),(16,-1),(25,-1),(8,3)]}.items():
    hi=Fraction(104*(bounds(base)[1]-bounds(loss)[0]-dp[73]+idle_hi),76*S)
    assert hi<Fraction('128.891')
    res[key]=str(hi)

print(json.dumps({"independent_scale": S, "bounded_72_role_dp_lower": dp[73], "max_idle_correction_upper": idle_hi, "upper_with_max_idle": res}, indent=2))
