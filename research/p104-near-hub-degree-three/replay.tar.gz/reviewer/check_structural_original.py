#!/usr/bin/env python3
"""Independent finite arithmetic for R6 near-hub and k71 placement."""
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import combinations
from pathlib import Path
import json

S = 10**20
@lru_cache(None)
def root(n):
    value = n**99 * S**100
    a,b=0,(n+1)*S
    while a+1<b:
        m=(a+b)//2
        if m**100<=value: a=m
        else: b=m
    return a, a if a**100==value else a+1

def bounds(terms):
    c=Counter()
    for n,v in terms: c[n]+=v
    lo=hi=0
    for n,v in c.items():
        a,b=root(n)
        if v>=0: lo+=v*a;hi+=v*b
        else: lo+=v*b;hi+=v*a
    return lo,hi

def cost(d):
    # v(2)-v(d) plus smallest possible loss for two nonempty pieces.
    return bounds([(17,1),(16,-1),(8*d+1,-1),(8,1),(8*(d-1),1)])[0]

# Up to 72 split roles, allow each of them full d-1 pair coverage.
dp=[0]+[None]*73
for _ in range(72):
    prev=dp[:]
    for q in range(1,74):
        vals=[cost(d)+prev[max(0,q-d+1)] for d in range(2,77)
              if prev[max(0,q-d+1)] is not None]
        if vals:
            val=min(vals)
            dp[q]=val if dp[q] is None else min(dp[q],val)
assert dp[73]==cost(74)
base=[(609,1),(601,1),(9,76),(17,73),(8,-227),(16,-73),(1,-1)]
idle=[(1,1),(608,1),(609,-1)]
# Concavity makes 1+p(8d)-p(8d+1) increase with d; bound all 76 directly too.
idle_hi=max(bounds([(1,1),(8*d,1),(8*d+1,-1)])[1] for d in range(1,77))
assert idle_hi==bounds(idle)[1]
res={}
for key,loss in {
    'e_plus_st':[(17,1),(25,-1),(8,1)],
    'e_plus_s_plus_t':[(17,1),(16,-1),(25,-1),(8,3)]}.items():
    hi=Fraction(104*(bounds(base)[1]-bounds(loss)[0]-dp[73]+idle_hi),76*S)
    assert hi<Fraction('128.891')
    res[key]=str(hi)

src=Path('/tmp/p104-round6/streams/15-k71-triple-deletion/placement.json')
raw=src.read_bytes();roles=json.loads(raw)['roles']
assert len(roles)==140
hub=[r for r in roles if len(r['mask'])==71]
nh=[r for r in roles if len(r['mask'])!=71]
assert len(hub)==2 and len(nh)==138 and all(2<=len(r['mask'])<=32 for r in nh)
T=sum(len(r['mask']) for r in nh);assert T==447
for r in roles:
    pcs=[set(p) for p in r['pieces']]
    assert set().union(*pcs)==set(r['mask']) and sum(map(len,pcs))==len(r['mask'])
    assert all({m} in pcs for m in r['main'])
assert all(sum(s in r['main'] for r in roles)==2 for s in range(71))
cap=lambda z:max(0,min(32,z)-1)
pair_values=[]
for s,t in combinations(range(71),2):
    d={s,t}
    pair_values.append(sum(cap(len(set(r['mask'])-d)) for r in roles))
    sep=sum(any(s in p for p in r['pieces']) and any(t in p for p in r['pieces']) and
            not any(s in p and t in p for p in r['pieces']) for r in roles)
    assert sep==2
assert min(pair_values)>=330
triple={0,1,2}
tri_cap=sum(cap(len(set(r['mask'])-triple)) for r in roles)
rank=sum(2*(len(range(j,68,2**lev))//2) for lev in range(5) for j in range(2**lev))
assert (tri_cap,rank)==(324,328)
remaining=sorted(set(range(71))-triple)
cross=0
for lev in range(5):
    for j in range(2**lev):
        a=remaining[j::2**lev];x=set(a[::2]);y=set(a[1::2])
        cross+=sum(bool(set(r['mask'])&x) and bool(set(r['mask'])&y) for r in roles)
assert cross==324
terms=[]
for r in roles:
    terms.append((8*len(r['mask'])+1,1))
    terms.extend((8*len(p),-1) for p in r['pieces'])
low,high=bounds(terms)
lo=Fraction(104*low,71*S);hi=Fraction(104*high,71*S)
assert Fraction('128.896193445305629')<lo<=hi<Fraction('128.896193445305630')
assert lo>Fraction('128.891')
out={'nearhub':{'independent_scale':S,'bounded_72_role_dp_lower':dp[73],
     'max_idle_correction_upper':idle_hi,'upper_with_max_idle':res,
     'scope':'conditional frame, event assignment and invoice; no legal-word proof'},
     'k71':{'source':str(src),'source_sha256':sha256(raw).hexdigest(),
     'T':T,'min_pair_capacity':min(pair_values),'pair_count':len(pair_values),
     'all_pair_separations_exactly_two':True,'triple_012_capacity':tri_cap,
     'triple_012_raw_tree_cross':cross,'triple_rank_demand':rank,
     'exact_type_invoice_interval':[str(lo),str(hi)],
     'scope':'literal relaxation placement, not a legal frame or kappa result'}}
Path(__file__).with_name('STRUCTURAL-CHECK.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
