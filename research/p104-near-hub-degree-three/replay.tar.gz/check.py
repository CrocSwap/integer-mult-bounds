#!/usr/bin/env python3
"""Directed integer-root certificate and global-mask accounting controls.

The assumptions and paper frame argument are in README.md. This script does
not construct a legal caller or prove the frame, partition, or word bridge.
"""
from collections import Counter
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction
from pathlib import Path
import json

SCALE = 10**14
BAR = Fraction(128891, 1000)
ROOT = {}


def p(n):
    if n not in ROOT:
        x = n**99 * SCALE**100
        low, high = 0, (n+1)*SCALE
        while low+1 < high:
            mid = (low+high)//2
            if mid**100 <= x:
                low = mid
            else:
                high = mid
        assert low**100 <= x < (low+1)**100
        ROOT[n] = (low, low + int(low**100 != x))
    return ROOT[n]


def interval(terms, upper):
    merged = Counter()
    for base, coeff in terms:
        merged[base] += coeff
    return sum(c*p(b)[int((c > 0) == upper)] for b, c in merged.items() if c)


def expr(terms):
    out = Counter()
    for n,c in terms:
        out[n] += c
    return {b:c for b,c in sorted(out.items()) if c}


def value(n):
    return Fraction(104*n, 76*SCALE)


def dec_up(q):
    with localcontext() as ctx:
        ctx.prec = 60
        ctx.rounding = ROUND_CEILING
        return str((Decimal(q.numerator)/Decimal(q.denominator)).quantize(Decimal('0.000000000001')))


def slope_loss(d):
    return [(17,1),(16,-1),(8*d+1,-1),(8*d,1)]


def split_loss(d):
    return slope_loss(d)+[(8,1),(8*(d-1),1),(8*d,-1)]


def role_loss(parts):
    # v(2) minus the full target and event bill of the specified role.
    return [(17,1),(16,-1),(25,-1)]+[(8*x,1) for x in parts]


def valid_assignment(roles, events):
    """Each named event is used once, with nonempty disjoint role pieces."""
    used = set()
    for role, mask in roles.items():
        seen = set()
        for event, piece in events[role]:
            if not piece or event in used or not piece <= mask or seen & piece:
                return False
            used.add(event)
            seen |= piece
        if seen != mask:
            return False
    return True


def partitions(s):
    """Enumerate all set partitions, canonicalizing by smallest member."""
    if not s:
        yield []
        return
    x = min(s)
    rest = s-{x}
    for old in partitions(rest):
        yield [frozenset({x})]+old
        for i in range(len(old)):
            yield old[:i]+[old[i]|{x}]+old[i+1:]


def synthetic(parts):
    """Finite mask/price control. It is not a frame or a legal word."""
    # 0=e; 1=s, 2=t; the other 73 common stages are 3..75.
    stages = set(range(76))
    roles = {'h':stages, 'g':stages-{0}, 'r0':{0,1,2},
             'r74':stages-{1,2}}
    events = {'h':[(f'h{i}',{i}) for i in range(76)],
              'g':[(f'g{i}',{i}) for i in range(1,76)],
              'r0':[('r0e',{0})] + [(f'r0res{i}',set(x)) for i,x in enumerate(parts)],
              'r74':[('r74e',{0}),('r74rest',set(range(3,76)))]}
    for i in range(76):
        roles[f'leaf{i}'] = {i}
        events[f'leaf{i}'] = [(f'leaf{i}ev',{i})]
    for i in range(71):
        roles[f'other{i}'] = {1,2}
        events[f'other{i}'] = [(f'other{i}ev',{1,2})]
    assert len(roles) == 151 and valid_assignment(roles,events)
    # All e/common pairs are separated by r0 or r74.
    for t in range(1,76):
        assert any(0 in roles[r] and t in roles[r] and
                   not any(0 in z and t in z for _,z in events[r])
                   for r in ('r0','r74'))
    hosts = {f'h{i}' for i in range(76)}|{f'g{i}' for i in range(1,76)}|{'r0e'}
    assert len(hosts)==152
    model_terms = [(8*len(m)+1,1) for m in roles.values()]
    model_terms += [(8*len(piece),-1) for v in events.values() for _,piece in v]
    model_terms += [(1,-1)]
    # Plain QUERY and no IDLE correction. Native 152 HOSTs charged once.
    repo_query = [(8*len(m)+1,1) for m in roles.values()]
    repo_query += [(8,-152),(1,-1)]
    repo_query += [(8*len(piece),-1) for v in events.values() for e,piece in v if e not in hosts]
    assert expr(model_terms) == expr(repo_query)
    # Replace QUERY by an odd IDLE on the first residual and compare the
    # actual price to the correctly ADDED idle correction.
    d = len(parts[0])
    odd_repo = repo_query + [(1,1),(8*d,1),(8*d+1,-1)]
    direct_idle = [(8*len(m)+1,1) for m in roles.values()] + [(8,-152)]
    direct_idle += [(8*len(piece)+(e=='r0res0'),-1)
                    for v in events.values() for e,piece in v if e not in hosts]
    assert expr(odd_repo) == expr(direct_idle)
    # An even target has p(24), not p(25): price-only identity; even target
    # parity does not satisfy the signed P=-I premise used in the paper cut.
    direct_even = direct_idle + [(25,-1),(24,1)]
    assert expr(direct_even) == expr(model_terms+[(1,1),(8*d,1),(8*d+1,-1),(25,-1),(24,1)])
    # Duplicate event IDs or overlap cannot be a global bijection/partition.
    bad = dict(events)
    bad['leaf0'] = [('r0e',{0})]
    assert not valid_assignment(roles,bad)
    return model_terms


def main():
    assert sorted([sorted(map(sorted,x)) for x in partitions({0,1,2}) if frozenset({0}) in x]) == [
        [[0],[1],[2]], [[0],[1,2]]]
    costs = {d:interval(split_loss(d),False) for d in range(2,77)}
    assert all(costs[d]>0 for d in costs)
    assert interval(slope_loss(2),False)==0
    assert interval([(9,1),(8,-1),(17,-1),(16,1)],False)>0
    assert all(interval(slope_loss(d),True)<interval(slope_loss(d+1),False) for d in range(2,76))
    for d in range(4,77):
        for a in range(2,d-1):
            interior = [(8*a,1),(8*(d-a),1),(8*d,-1)]
            endpoint = [(8,1),(8*(d-1),1),(8*d,-1)]
            assert interval(interior,False)>interval(endpoint,True)
    need, path = [0],[[]]
    for q in range(1,74):
        cost,d = min((costs[d]+need[max(0,q-d+1)],d) for d in range(2,77))
        need.append(cost)
        path.append([d]+path[max(0,q-d+1)])
    assert path[73]==[74] and need[73]==costs[74]
    base = [(609,1),(601,1),(9,76),(17,73),(8,-227),(16,-73),(1,-1)]
    # Delta(d)=1+p(8d)-p(8d+1) increases for d>=1, by the
    # finite slope checks above; Delta(0)=0. Its maximum is d=76.
    idle = [(1,1),(608,1),(609,-1)]
    assert all(interval([(8*d+1,1),(8*d,-1)],False)>0 for d in range(1,77))
    assert all(interval([(1,1),(8*d,1),(8*d+1,-1)],False)>0 for d in range(1,77))
    branches = {}
    for key,parts in [('host_e_plus_st', [{1,2}]),('host_e_plus_s_plus_t',[{1},{2}])]:
        loss = role_loss([1]+[len(p) for p in parts])
        control = synthetic(parts)
        assert expr(control)==expr(base+[(b,-c) for b,c in loss]+[(b,-c) for b,c in split_loss(74)])
        lo,hi=interval(loss,False),interval(loss,True)
        zero=value(interval(base,True)-lo-need[73])
        robust=value(interval(base+idle,True)-lo-need[73])
        assert robust<BAR and zero<robust
        branches[key] = {
            'role_loss_scaled_lower':lo,
            'role_loss_scaled_upper':hi,
            'zero_idle_ceiling':str(zero),
            'zero_idle_ceiling_decimal_up':dec_up(zero),
            'arbitrary_one_thin_idle_ceiling':str(robust),
            'arbitrary_one_thin_idle_ceiling_decimal_up':dec_up(robust),
            'gap_below_bar_with_max_idle':str(BAR-robust),
            'gap_decimal_lower_display':float(BAR-robust),
        }
    unbilled = value(interval(base,False)-interval(split_loss(74),True))
    assert unbilled>BAR
    out={
        'scope':'conditional k=76 named degree-three HOST assignment; not a legal word construction',
        'scale':SCALE,'root_count':len(ROOT),'bar':str(BAR),
        'pair_demand':75,'specified_role_covers':2,'other_role_demand':73,
        'other_role_limit':'unlimited relaxation; actual at most 72',
        'other_role_coverage_optimum':{'degrees':path[73],'loss_scaled_lower':need[73]},
        'base_scaled_upper':interval(base,True),
        'branches':branches,
        'maximum_idle_correction_scaled_upper':interval(idle,True),
        'unbilled_role_loss_controller_lower':str(unbilled),
        'controls':{
            'all_two_local_partitions_enumerated':True,
            'synthetic_global_mask_assignments_and_exact_bills':True,
            'native_host_count':152,
            'duplicate_assigned_host_rejected':True,
            'model_to_repo_odd_idle_sign_checked':True,
            'model_to_repo_even_target_deficit_checked':True,
            'unbilled_role_controller_above_bar':True,
            'synthetic_controls_are_legal_caller_witnesses':False,
        },
        'proof_status':'finite arithmetic and bookkeeping only; structural deductions are paper arguments'
    }
    print(json.dumps(out,indent=2))


if __name__ == '__main__':
    main()
