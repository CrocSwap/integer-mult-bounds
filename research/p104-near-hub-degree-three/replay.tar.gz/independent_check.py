#!/usr/bin/env python3
"""Independent Newton-root enclosure and bounded 72-role coverage DP.

Only arithmetic is checked; no word, frame, matching or price bridge is built.
"""
from fractions import Fraction

SCALE = 10**15
ROOTS = {}


def root(b):
    if b not in ROOTS:
        n = b**99*SCALE**100
        x = (b+1)*SCALE
        while True:
            y = (99*x+n//x**99)//100
            if y >= x:
                break
            x = y
        while (x+1)**100 <= n:
            x += 1
        while x**100 > n:
            x -= 1
        assert x**100 <= n < (x+1)**100
        ROOTS[b] = (x,x+int(x**100<n))
    return ROOTS[b]


def cost(terms, upper=False):
    # Round each term separately, independent of aggregation in check.py.
    return sum(c*root(b)[int((c>0)==upper)] for b,c in terms)


def main():
    loss = {}
    for d in range(2,77):
        # s(2) is exactly zero, not the sum of interval endpoints.
        slope = 0 if d==2 else cost([(17,1),(16,-1),(8*d+1,-1),(8*d,1)])
        frag = cost([(8,1),(8*(d-1),1),(8*d,-1)])
        loss[d]=slope+frag
        assert loss[d]>0
    # State is minimum cost for exactly j split roles and coverage clipped
    # to 73. This considers every count 1..72 (actual count is at most 72).
    states = {0:0}
    best = None
    for count in range(1,73):
        following={}
        for covered,current in states.items():
            for d in range(2,77):
                nxt=min(73,covered+d-1)
                candidate=current+loss[d]
                following[nxt]=min(following.get(nxt,candidate),candidate)
        states=following
        if 73 in states and (best is None or states[73]<best[0]):
            best=(states[73],count)
    assert best==(loss[74],1)
    baseline=cost([(609,1),(601,1),(9,76),(17,73),(8,-227),(16,-73),(1,-1)],True)
    idle=cost([(1,1),(608,1),(609,-1)],True)
    branch1=cost([(17,1),(25,-1),(8,1)])
    branch2=cost([(17,1),(16,-1),(25,-1),(8,3)])
    for label,branch in [('e + st',branch1),('e + s + t',branch2)]:
        zero=Fraction(104*(baseline-branch-best[0]),76*SCALE)
        max_idle=Fraction(104*(baseline-branch-best[0]+idle),76*SCALE)
        assert max_idle<Fraction(128891,1000)
        print(f'PASS {label}: zero-IDLE {zero} = {float(zero):.12f}')
        print(f'PASS {label}: max IDLE {max_idle} = {float(max_idle):.12f}')
    print('PASS 72-role bounded DP: one degree-74 role covers 73 pairs')
    print('PASS distinct Newton root bounds; root bases:',len(ROOTS))
    print('Paper rank, global partition, legal word, and cost bridges remain assumptions.')


if __name__=='__main__':
    main()
