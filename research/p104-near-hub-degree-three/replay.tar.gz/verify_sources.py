#!/usr/bin/env python3
"""Check selected source snapshots against inherited observed Git blob IDs."""
from hashlib import sha1
from pathlib import Path

HERE=Path(__file__).resolve().parent
EXPECTED={
 'sources/p7852/CallerEv.lean':'ad5aba9f52bd1d4b60c3023a8325ff68310c5561',
 'sources/p7852/CallerSGram.lean':'6c03a7f3b3c50fe4340cd105378409ca39abc474',
 'sources/p7852/CallerThin.lean':'f85fc659414297e2444489f9982bf966d5fadb9f',
 'sources/p7852/CallerWord.lean':'4d8d2ab8e4a1338cb172b35dc45d8070c3c3270c',
 'sources/p7852/CallerWordD.lean':'6d1b7ae061de0d0e93a8720f0c81b79a4dbf8347',
 'sources/p7852/SchemaCostB.lean':'b6a1c4b03a81a99e59c433d110871f605bef9694',
 'sources/p7869/OPEN-PROBLEMS.md':'f753dbab5ea9d84b9332261a93f8d0e7adfce6f6',
}
for path,wanted in EXPECTED.items():
    raw=(HERE/path).read_bytes()
    got=sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert got==wanted,(path,got,wanted)
print('PASS six selected #7852 source blobs at 41beda1d6435760dc99e38bd7e65f36798aad212')
print('PASS #7869 OPEN-PROBLEMS blob at 06c207a9feb3994a4b987dc3010657b6e85b7956')
print('Blob identities check copied bytes, not theorem hypotheses or current PR status.')
