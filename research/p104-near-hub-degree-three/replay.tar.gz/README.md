# Conditional k=76 ceiling with a degree-three exceptional HOST role

This is a paper argument plus exact finite arithmetic and bookkeeping
controls. It neither produces a legal caller word nor establishes a new
κ bound. It uses the Round 5 stream 13 near-hub degree-two argument and
stream 14 mask-only attribution research as parents. Source snapshots and
exact scope are recorded below.

For the named assignment and hypotheses in this note, even allowing the
largest possible correction for the unique odd IDLE,

\[
  \frac{104}{76}\operatorname{repo}
  \le \frac{24488606814627813}{190000000000000}
  <128.887404287515<128.891.
\]

The rational is an outward enclosure of an intentionally relaxed price
problem, not an achieved invoice. The proven arithmetic margin below the
bar is `683185372187/190000000000000` (approximately `0.003595712485`).
With a QUERY or empty-mask odd IDLE the better directed enclosure is
`122350113760112069/950000000000000 < 128.789593431697`. These are the
weaker of the two possible partitions of the specified role; see the table
below. The rank, event-attribution, and legal-word implications are paper
arguments and assumptions, not consequences established by the scripts.

## Explicit domain

Assume the following.

1. A SPEC-legal, tight type-B caller word has `k=76`, `n=151`, exactly two
   nonzero q-odd HOST columns per stage and one plain thin column `T=Q=1`,
   so the signed frame has exactly `n+2=153` columns. The 76 HOST time slots
   are distinct, and the thin has a separate slot. All column time labels lie
   in the finite frame order. Every target exponent is `-1`, so all 151
   target rows are odd. Its signed
   frame satisfies `P=-I` in characteristic not 2, the 76 diagonal HOST
   K-blocks are nondegenerate, and the HOST-column target-mask support and
   invertible cross-HOST Gram consequences of the pinned signed-frame
   infrastructure hold. All role masks have positive degree.
2. Exactly 76 roles are degree-one leaves. There is a **single global
   bijection** from all nonempty charged stage-incidence events, including
   native HOST events, to named role pieces. For each role, its pieces are
   nonempty, pairwise disjoint and partition its whole target mask. Event
   vectors satisfy the separate `CallerEv.x_supp`, multi-stage `x_ker`, and
   shared-stage biorthogonality laws. This is mask-only assignment: an event's
   vector need not be strictly supported on the role to which it is assigned.
3. Two nonleaf roles `h,g` have masks all 76 stages and all stages except
   one exceptional stage `e`, respectively. At every common stage, the two
   singleton HOST events are assigned one each to `h` and `g`. At `e`, the
   HOST singletons are assigned to `h` and a **specified distinct role**
   `r0` with target mask exactly `{e,s,t}`, where `s` and `t` are distinct
   common stages. The other 72 nonhub nonleaf roles have degree at least two.
4. The word supplies the stated frame, support, and incidence data through
   the pinned word bridges and uses the actual type-B native contact and
   plain-event pricing. The sole plain thin is a QUERY or odd IDLE and has
   its own event time. The `SchemaCostB` assumptions apply.

These are strong joint hypotheses. Per-stage `CallerEv.Match` does not give
one global partition, and a global partition's existence does not force the
specified HOST-to-`r0` assignment. Round 5 stream 14 establishes its
mask-only result for certain flag/overlap situations and for dimension-three
quotients with at most four stages; that theorem does **not** furnish this
named attribution or a general 76-stage signed HOST word. The arguments here
do not cover other assignments or degrees of `r0`.

## The two possible residual partitions

The event assigned to `r0` at `e` is the native singleton `{e}`. The global
partition therefore forces exactly one of these possibilities:

* `{e}` and `{s,t}`;
* `{e}`, `{s}`, and `{t}`.

At `s` and `t` both native HOST events are already assigned to `h,g`.
Consequently `r0`'s residual event or events are distinct non-HOST events.
By `CallerThin.leaf_rank`, the 76 leaves occupy the 76 stages, one apiece.
Their assigned pieces are singleton events, also distinct from the 152
native HOST events because each HOST event has already been assigned to
`h`, `g`, or `r0`. None of these charges may be omitted, and no native HOST
may be subtracted a second time.

## Pair-kernel coverage

Fix a common stage `u` and let `H` consist of roles whose masks contain both
`e,u`. It contains `h`, no `g`, and no leaves. Suppose every role in
`H \ {h}` puts `e,u` in the same assigned event piece. The corresponding
pieces identify distinct events by the global assignment. Each event vector
is supported on `H` by `x_supp`, belongs to the kernel of `B_e^T` by `x_ker`,
and these `|H|-1` vectors are independent by biorthogonality at stage `e`.

HOST support localizes the invertible cross Gram block `B_e^T A_u` to `H`.
Thus `B_e^T` has rank two on that coordinate space and a kernel of dimension
`|H|-2`, a contradiction. Therefore a role other than `h` contains both
`e,u` and puts them in different pieces. The role `h` itself has **76
singleton pieces**, and is deliberately excluded from this contradiction;
it is not an unsplit role.

For `u=s,t`, `r0` is a separator. For each of the other 73 common stages,
`r0` is absent from `H`; a separator is one of the other 72 nonhub nonleaf
roles. Write `P_r(e)` for its unique assigned piece containing `e`. The
necessary inequality is

\[
 \sum_{\substack{r\notin\{h,g,r0\}\\e\in M_r,\ r\text{ split}}}
       (|M_r|-|P_r(e)|) \ge 73. \tag{1}
\]

A degree-`d` split role has capacity at most `d-1`. Giving that full capacity
to every split role, even one missing `e`, and permitting more than 72 of
them are favorable relaxations. The controls include a global **mask**
assignment realizing this relaxed coverage count, but it is not asserted to
be a signed frame or a legal word.

## Complete event bill and the odd-IDLE correction

Let `p(x)=x^(99/100)` (with `p(0)=0`), and set

\[
 v(d)=p(8d+1)-p(8d),\quad
 s(d)=v(2)-v(d),\quad
 c(d)=s(d)+p(8)+p(8d-8)-p(8d).
\]

With all targets odd, the full event-form invoice has unnormalized baseline

\[
 B=p(609)-76p(8)+p(601)-75p(8)+76v(1)+73v(2)-1. \tag{2}
\]

The first two terms are the fully split hub bills, `76v(1)` pays for every
leaf, and the 73 nonhub nonleaf terms use the favorable unsplit degree-two
proxy. The `-1` is the one plain thin's event-form charge. In expanded form
this is `p(609)+p(601)+76p(9)+73p(17)-227p(8)-73p(16)-1`.
The baseline is just an accounting proxy: after replacing `r0`'s term, it
contains all 152 HOST events exactly once.

The actual `r0` contribution and loss versus its optimistic `v(2)` are:

| Assigned pieces | Actual target minus event charges | Loss versus `v(2)` |
|---|---|---|
| `{e}`, `{s,t}` | `p(25)-p(8)-p(16)` | `p(17)-p(25)+p(8)` |
| `{e}`, `{s}`, `{t}` | `p(25)-3p(8)` | `p(17)-p(16)-p(25)+3p(8)` |

For the first line, after substitution, the coefficient of `p(8)` is `-228`
(152 HOST singleton charges and 76 leaf singleton charges); the residual
`{s,t}` contributes a separate `-p(16)`. For the second it is `-230`
(152 HOST, 76 leaf, and 2 residual singletons). Other-role singleton charges
are already incorporated in their own partitions and split losses. No
additional HOST charge is taken from (2).

For any other degree-`d≥2` role, a split costs at least `c(d)` against
`v(2)`: merging pieces cannot increase fragmentation loss, and concavity
makes a `1,(d-1)` partition the least expensive two-piece split. An unsplit
role loses the nonnegative `s(d)`. The finite degree comparisons are checked
with directed integer roots; the general merging and partition argument is
paper reasoning.

A QUERY contributes no discrepancy between this event model and the actual
plain-event price. An odd IDLE on nonempty `S` contributes an **added**
correction

\[
 \delta(|S|)=1+p(8|S|)-p(8|S|+1),
\]

and an empty-mask odd IDLE contributes zero. Because there is only one thin
and `|S|≤76`, concavity gives `0≤δ≤δ(76)`. The certificate *adds* `δ(76)`
to each upper bound. Thus the headline does not need to exclude nonempty
odd IDLEs or infer any thin-mask restriction from abstract event data.

The inherited leaf argument suggests the stronger zero-correction case for
the stated real-word slice: `leaf_zero` forces a nonzero thin B-entry at
every leaf; `idle_base`, `terms`, and `legal_masks` make that entry zero on
a leaf at a stage outside any chosen stage in a nonempty odd IDLE mask. This
uses the separate time slot and the word-to-incidence bridge, not just
abstract `EvData`. The numerical headline is valid without spending this
paper deduction.

For clarity about nonodd target rows, `SchemaCostB.repo_eq` as cited assumes
`ex=-1` for every row, which is included above. Independently, direct
operation-by-operation price algebra for a grammar with one plain thin gives

\[
 \operatorname{repo}=\Bigl[\sum_r p(8d_r+1)-\sum_{\text{nonempty events }j}p(8|S_j|)-1\Bigr]
 +\sum_{\text{odd IDLE }j}\delta(|S_j|)
 -\sum_{\text{even target }r}v(d_r). \tag{3}
\]

The sum over events includes both native HOST contacts and plain incidences;
zero masks contribute no event charge. A nonodd target therefore introduces
a **subtraction**, never an extra positive IDLE correction. Equation (3)
is a pricing identity only: allowing even target exponents does not establish
`P=-I`, the signed pair cut, or the other structural assumptions. We make no
extension of the conditional theorem to mixed-parity frames. The synthetic
control checks both signs by independently reconstructing plain-event and
HOST bills.

## Directed finite certificate

At scale `10^14`, `check.py` encloses each `p(b)` by consecutive integers
certified by 100th-power comparisons. For the remaining pair demand `q`, it
computes

\[
 F(0)=0,\qquad F(q)=\min_{2\le d\le76}
   \{c_{\mathrm{low}}(d)+F(\max(0,q-d+1))\}.
\]

It obtains `F(73)=43849638857811/10^14`, with a single degree-74 role.
This DP allows unlimited split roles, although the actual slice has at most
72. The full directed enclosures are:

| `r0` pieces | Zero IDLE correction | Maximum one-IDLE correction |
|---|---:|---:|
| `{e}`, `{s,t}` | `< 128.789593431697` | `< 128.887404287515` |
| `{e}`, `{s}`, `{t}` | `< 128.641467869979` | `< 128.739278725797` |

The separate Newton-root script uses scale `10^15`, separately rounded
terms, and a 72-role bounded dynamic program. It confirms both ceilings, with
the same degree-74 minimizer. A second Codex campaign reviewer independently
examined the pair-kernel proof and bookkeeping and ran a different 72-role
DP at scale `10^20`, enumerating all 76 nonempty odd-IDLE sizes. Its original
combined checker and output, plus a runnable near-hub-only extraction, are
in `reviewer/`. That review found the deductions coherent under the stated
hypotheses; it is not a Lean proof or an external mathematical referee report.
Exact fractions and directed rounding are in `RESULT.json`,
`independent.log` and `reviewer/NEARHUB-REPLAY.json`.

A favorable arithmetic controller that omits the specified role's loss is
above `128.998`; the role split is essential to this pair-only price proof.
The scripts enumerate both legal *local mask partitions*, reject duplicate
HOST assignment, build abstract global-mask controls, and compare synthetic
QUERY, odd-IDLE and nonodd-target billing symbolically. None of those masks
is supplied with a compatible signed frame, actual target exponents, or a
legal word. These controls do not establish attainability or an obstruction
beyond the stated assumptions.

## Sources and reproducibility

Pinned toolkit: [#7852 at `41beda1d6435760dc99e38bd7e65f36798aad212`](https://github.com/CrocSwap/integer-mult-bounds/commit/41beda1d6435760dc99e38bd7e65f36798aad212).
Pinned guidance: [#7869 at `06c207a9feb3994a4b987dc3010657b6e85b7956`](https://github.com/CrocSwap/integer-mult-bounds/commit/06c207a9feb3994a4b987dc3010657b6e85b7956).
Selected source bytes are in `sources/p7852` and `sources/p7869`; their
recorded Git blob identities are checked by `verify_sources.py`. The Round 5
stream 13 and 14 notes and associated local results are copied under
`sources/r5-13` and `sources/r5-14` for traceability; their contents are
parents of this argument, not independent verification of it. Source checks
establish selected byte identities, not current PR status or upstream proofs.

```sh
python3 -I -B verify_sources.py
python3 -I -B check.py | cmp RESULT.json -
python3 -I -B independent_check.py
python3 -I -B reviewer/check_nearhub_review.py
```

Remaining work before any stronger claim includes independent scrutiny of
the cross-Gram kernel deduction, exact global assignment, word/frame support
bridge, role counts and the directed signed invoice. There is no Lean proof
of the new deduction and no all-k=76 or κ conclusion.
