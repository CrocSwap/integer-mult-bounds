#!/usr/bin/env python3
"""Independent exact check of the stream-18 zero-split dual certificates.

This checks finite arithmetic only; the common-kernel triple lemma, word
support, Turan and pricing identities remain mathematical hypotheses.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import combinations_with_replacement, product
from math import comb
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
S=10**14
M=10**18
assert M % S == 0
BAR=Fraction(128891,1000)
K=76
ROOT={}

def root(b):
    if b not in ROOT:
        target=b**99*S**100
        lo,hi=0,(b+1)*S
        while lo+1<hi:
            z=(lo+hi)//2
            if z**100<=target:lo=z
            else:hi=z
        assert lo**100<=target<(lo+1)**100
        ROOT[b]=(lo,lo if lo**100==target else lo+1)
    return ROOT[b]

def poly(terms, upper):
    ans=0
    for b,c in terms.items():
        low,high=root(b)
        ans+=c*(high if ((c>0)==upper) else low)
    return ans

def cost(d, upper=False):
    c=Counter({17:1,16:-1})
    c[8*d+1]-=1;c[8*d]+=1
    return poly(c,upper)

def cap(d):return comb(d,2)*(76-d)-74

def independent_set_cap(m):
    """Enumerate signature multiplicities, test forbidden triple types."""
    n=1<<m;bad=[]
    for a,b,c in combinations_with_replacement(range(n),3):
        if not any(((a>>j)&1)+((b>>j)&1)+((c>>j)&1)==2 for j in range(m)):
            req=[0]*n
            for i in (a,b,c):req[i]+=1
            bad.append(req)
    optimum=0;witness=None
    for counts in product(range(3),repeat=n):
        if any(all(counts[i]>=v for i,v in enumerate(req) if v) for req in bad):continue
        if sum(counts)>optimum:optimum=sum(counts);witness=counts
    return optimum,witness

def turan_edges(n,alpha):
    q,r=divmod(n,alpha)
    return (alpha-r)*comb(q,2)+r*comb(q+1,2)

def cases(L,alphas):
    records=[]
    for m,alpha in enumerate(alphas):
        q=L-m
        if q>=1:
            N=max(n for n in range(77) if turan_edges(n,alpha)<=73-L)
            records.append((q,76-N))
    return records

def ceilfrac(x):return -((-x.numerator)//x.denominator)

def main():
    raw=(HERE/'duals.json').read_bytes()
    assert sha256(raw).hexdigest()=='180c2092144b2e08131fc72b753c67318e4b90d14026eca5229b04db5966636d'
    duals=json.loads(raw);assert duals['scale']==M
    entry={(r['long_count'],r['anchor']):r['mu'] for r in duals['rows']}
    assert len(entry)==len(duals['rows'])
    alphas=tuple(independent_set_cap(m)[0] for m in range(4))
    assert alphas==(2,3,4,7)
    for L in range(4):assert turan_edges(76,alphas[L])>73-L
    lowercost={d:cost(d) for d in range(3,77)}
    assert all(lowercost[d]>0 for d in lowercost)
    assert all(cost(d,True)<lowercost[d+1] for d in range(3,76))
    base=Counter({609:2,17:73,9:76,8:-228,16:-73,1:-1})
    base_upper=poly(base,True)
    # Degree-only fractional control from the other lane: it meets every
    # prefix/triple relaxation here but has a modeled price above the bar.
    # This is not a frame or a legal word.
    mean_degree=Fraction(59*3+41*49,100)
    assert all(q*mean_degree>=need for q,need in cases(5,alphas))
    assert Fraction(5*(59*cap(3)+41*cap(49)),100)>=64898
    loss_hi=Fraction(5*(59*cost(3,True)+41*cost(49,True)),100*S)
    fractional=Fraction(104,76)*(Fraction(poly(base,False),S)-loss_hi)
    assert fractional>BAR
    # We verify unnormalized actual price (base upper minus cost lower)
    # against BAR*76/104. No numerical LP/MILP outputs are used.
    def ceiling(z):return Fraction(104*(base_upper*(M//S)-z),76*M)
    large=ceiling(29*lowercost[3]*(M//S));assert large<BAR
    required=comb(76,3)-73*74;assert required==64898
    seen=set();counts=Counter();best=None
    for L in range(4,29):
        prefixes=cases(L,alphas);assert len(prefixes)==4
        q=L-3;minprefix=dict(prefixes)[q]
        for a in range(3,77):
            if q*a<minprefix:counts['impossible']+=1;continue
            simple=((q-1)*lowercost[3]+4*lowercost[a])*(M//S)
            if ceiling(simple)<BAR:
                counts['simple']+=1;bound=simple
            else:
                mu=entry[(L,a)]
                assert len(mu)==5 and all(isinstance(u,int) and u>=0 for u in mu)
                seen.add((L,a));counts['dual']+=1
                # Fully per-position derivation, independent of the other
                # checker's repeated-role grouping/anchor algebra.
                bound=sum(mu[j]*need for j,(_,need) in enumerate(prefixes))+mu[4]*required
                for i in range(1,L+1):
                    domain=range(3,a+1) if i<q else ([a] if i==q else range(a,77))
                    def term(d):
                        weight=sum(mu[j] for j,(end,_) in enumerate(prefixes) if i<=end)
                        return lowercost[d]*(M//S)-weight*d-mu[4]*cap(d)
                    bound+=min(map(term,domain))
                assert ceiling(bound)<BAR,(L,a,ceiling(bound))
            if best is None or ceiling(bound)>best[0]:best=(ceiling(bound),L,a)
    assert seen==set(entry)
    overall=max(best[0],large)
    assert overall==Fraction(30611566615138613,237500000000000)
    print('PASS independent signature multiplicity enumeration:',alphas)
    print('PASS exact per-position dual verification:',dict(counts),'duals',len(seen))
    print('worst L<29:',best)
    print('L>=29 rational ceiling:',large)
    print('overall:',overall,'=',float(overall),'<',BAR)
    print('fractional degree-only control above bar:',fractional)
    print('N.B. structural/word implications are not proved by this computation.')

if __name__=='__main__':main()
