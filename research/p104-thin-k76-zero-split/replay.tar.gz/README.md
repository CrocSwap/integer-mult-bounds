# The k=76 zero-split two-hub slice

## Result and scope

Under **all** of the hypotheses listed below, the actual type-B repository
invoice satisfies the strict outward bound

\[
\frac{104}{76}\,\mathrm{repo}
\le \frac{30611566615138613}{237500000000000}
<128.890806800584<128.891.
\]

This is a conditional upper bound, not a legal caller construction, an
unconditional bound, or a kappa improvement. Its margin is about 0.0001932.
The common-kernel and one-thin arguments below are paper proofs, **not**
Lean-checked. The finite arithmetic and weak-duality steps have an exact
stdlib checker. A legal-word bridge matters here: the conclusion that the
odd-idle correction is zero does **not** follow merely from the abstract
`CallerEv.EvData` event axioms.

The slice is the complement of the *nonhub split* condition in
[#7883 at `ddb2499be243594c8165c7508c457782c1a4af3b`](https://github.com/CrocSwap/integer-mult-bounds/commit/ddb2499be243594c8165c7508c457782c1a4af3b), **only
inside their shared two-hub, exact-count, global-partition, frame and invoice
hypotheses**. Under those common ambient hypotheses, including the actual
legal-word bridge stated below, this packet and #7883 cover the disjoint
zero-split and split cases with the combined ceiling shown above. Neither
result removes those hypotheses or the ordinary stage-match /
global-partition gap. We do not claim a new bound for all k=76 callers.

The hypotheses are:

1. There are 76 ordered, distinct two-column host stages, 151 odd-target roles,
   `T=Q=1`, and a signed frame over a field of characteristic different from
   2 with product `P=-I` and every host diagonal block of `K` invertible.
   Hence `rank K<=2`, and every cross-host block is invertible.
2. Two hub roles meet all 76 stages, each assigned one singleton event per
   stage. Exactly 76 nonhub roles are leaves, and the other 73 nonhubs have
   degree at least 2. Each nonhub role is assigned **one** full-mask charged
   event. The global assignment is bijective on nonempty charged events and
   partitions each role's mask. The `CallerEv` support, multi-event kernel,
   and shared-stage biorthogonality laws hold.
3. The signed columns come from a SPEC-legal type-B caller word using the
   bridge in [CallerWord](https://github.com/CrocSwap/integer-mult-bounds/blob/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit/lean/Nov15/CallerWord.lean)
   and its D-incidence support theorem in
   [CallerWordD](https://github.com/CrocSwap/integer-mult-bounds/blob/41beda1d6435760dc99e38bd7e65f36798aad212/research/p104-lowerbound-toolkit/lean/Nov15/CallerWordD.lean).
   In particular the only thin is an odd `QUERY` or odd `IDLE`, in its own
   time slot, host support is in the target masks, and the odd-idle correction
   is the one given by `SchemaCostB.repo_eq`.

The actual word interpretation in item 3 is an added qualification for
this zero-split result, beyond what the abstract event data alone supplies.
The source derivations of the word model, frame bridge and invoice are due to
the upstream authors. The triple common-kernel obstruction is the special
zero-split case of #7883, building on
[#7861](https://github.com/CrocSwap/integer-mult-bounds/pull/7861). The
signature/Turán amplification and the thin-support application below are this
packet's contributions. No external-priority claim is made.

## Why the one real odd-idle correction vanishes

The pinned [CallerThin leaf-rank lemma](source/p7852/CallerThin.lean) implies
there can be at most one leaf at a host stage. For if two leaf basis vectors
have B-rows supported only on that host and the one thin, some nonzero linear
combination has zero B-row on the thin. The product equation then makes this
vector a `-1` eigenvector of the host factor, impossible because its signed
diagonal block is invertible. Thus the 76 leaves occupy all 76 different
stages, and the B-entry of the sole thin is nonzero on each leaf. The latter
also follows directly for one leaf: otherwise all other factors fix its basis
vector and the same `-1`-eigenvector contradiction applies.

Suppose the thin came from an `IDLE_ODD` with nonempty stage mask `S`, and
choose `t` in `S`. At `q=1,D=1` this idle is the identity, so for that event
`Aw=-2 incV` and `Bw=incW`. The D-incidence support theorem says `incW` is
zero on any role whose mask misses `t`. Choose the leaf at a different host
`u`: its target mask is `{u}`, so the thin's B-entry on that leaf is zero,
contradiction. Thus the single thin is either a `QUERY` or an `IDLE_ODD`
with empty `S`. In both cases the actual invoice correction in `repo_eq` is
exactly zero. No bound on the correction by `delta(76)` is used.

## Common kernels give a graph constraint

If no nonhub role meets a chosen stage triple in exactly two stages, all
roles meeting a pair meet all three; call this common pair-intersection set
`H`. Every nonhub role in `H` has one full-mask multi-event. Its event vector
is supported in `H`, kills the B-block at all three stages, and these
`|H|-2` vectors are independent by shared-stage biorthogonality. Cross-host
block invertibility makes each relevant `B^T` map onto dimension 2, so these
vectors form a common kernel. The rank-two signed common-kernel obstruction
of #7861 rules out the triple. Consequently every stage triple is
**differentiated** by at least one nonhub mask containing exactly two of its
members.

Let `L` be the number of degree-at-least-three nonhubs, and let `73-L` be the
number of degree-two nonhubs. Their two-element masks form the edges of a
simple graph, ignoring multiple edges; it has at most `73-L` distinct edges.
Sort the long degrees `D_1<=...<=D_L`.

Remove the union of the smallest `q` long masks. At least
`76-sum_{i<=q} D_i` stages remain. If the induced pair graph has an
independent set, every triple in that set must be differentiated by one of
only `m=L-q` surviving long masks. Give each stage its `m`-bit incidence
signature. A signature may appear at most twice, because three equal
signatures are never differentiated. Exact enumeration of all `3^(2^m)`
signature multiplicity vectors gives the maximum independent-set sizes

| remaining masks `m` | 0 | 1 | 2 | 3 |
| --- | ---: | ---: | ---: | ---: |
| maximum independent stages `a_m` | 2 | 3 | 4 | 7 |

For example, at `m=3`, the seven signatures `000,011,011,101,101,110,110`
attain 7. This is a **signature multiset control**, not a signed frame.
The checker enumerates all 6,561 multiplicity vectors for this row.

Turán's theorem on the graph complement now gives an edge lower bound
`T(n,a)` for a graph of `n` vertices with independence number at most `a`:
if `n=a t+r` and `0<=r<a`, then

\[
T(n,a)=(a-r)\binom t2+r\binom{t+1}2.
\]

Define `N_m(L)=max{n<=76 : T(n,a_m)<=73-L}`. For
`m=0,1,2,3` and `q=L-m>0`, every actual degree profile therefore obeys

\[
\sum_{i=1}^{q}D_i\ge 76-N_m(L). \tag{1}
\]

For `L<=3`, applying the relevant bound to all 76 stages already requires
more than `73-L` pair edges, so no such profile exists. In comparison, the
previous equal-signature-cell bound treats cells separately and misses
undifferentiated triples that use several comparable signatures.

Counting all differentiated triples with multiplicity separately gives

\[
\sum_{i=1}^{L}\left[\binom{D_i}{2}(76-D_i)-74\right]
\ge \binom{76}{3}-73\cdot74=64898. \tag{2}
\]

No graph or role-placement sufficiency is claimed for (1) or (2).

## Ordered local CROSS adds a distinct restriction

Take any four stages `a<b<c<d` in one long-mask signature cell. For every
long role, either all four stages occur in its mask or none do. The common
full-piece kernels restrict the contribution of all shared long roles and
the two hubs to rank at most 2 on the block with rows `{a,c}` and columns
`{b,d}`. The full block has rank 4 by the signed alternating CROSS law.
Each pair role contributes rank at most 1. Therefore **at least two** of
`{a,b},{a,d},{c,b},{c,d}` must be pair-role edges, counted with
multiplicity. More generally, for disjoint `X,Y` inside a single signature
cell, at least `2c-2` pair roles cross them, where `c` is the cyclic
alternation number in the actual stage order.

This is genuinely stronger locally than the triple condition: on four stages,
the two pair edges `{a,c}` and `{b,d}` meet every triple, yet put zero edges
across this alternating cut. The checker verifies that control. The price
bound below does **not** spend this further ordered CROSS constraint; it is
available for later refinements and is not asserted for an arbitrary
fractional type point.

## Price certificate

Put `p(x)=x^(99/100)`, `v(d)=p(8d+1)-p(8d)`, and
`s(d)=v(2)-v(d)`. The degree-two baseline for the stated family is

\[
 B=\frac{104}{76}\left(2[p(609)-76p(8)]
       +73v(2)+76v(1)-1\right).
\]

Because each nonhub has one full-mask piece and the actual thin correction
is zero, the real invoice is `B-(104/76) sum_i s(D_i)`. All long-role losses
are positive and increase with degree. For `L>=29`, `29 s(3)` alone suffices
for the final ceiling; this is the weakest branch in the check.

For `4<=L<=28`, set `q=L-3` and condition on the **integer** value
`a=D_q`. The first `q-1` long degrees are in `[3,a]`, and each of the
remaining three is in `[a,76]`. The checker tests every `a=3,...,76`.

* `q*a < 76-N_3(L)` is impossible by (1).
* The elementary bound `(q-1)s(3)+4s(a)` settles many further values.
* For each other value, the supplied `duals.json` gives nonnegative rational
  multipliers on all four inequalities (1) and on (2). The verifier evaluates
  the minimum of the resulting scalar expression over each allowed integer
  degree. This is weak duality: a fractional grouping of the `q-1` low
  slots and the last three slots only relaxes a true sorted integer profile.
  It checks 199 independently reconstructed dual rows without SciPy or
  floating-point arithmetic.

All power intervals are certified at scale `10^14` by integer 100th powers;
all dual multipliers have denominator `10^18`. The checker uses outward
rounding in the unfavorable direction and asserts each branch is below the
exact rational bar `128891/1000`. These finite calculations certify the
arithmetic **conditional on** the paper lemmas and hypotheses above.

A deliberately weaker *fractional degree-only* relaxation still lies above
128.891: use five long slots, each with 59/100 of degree 3 and 41/100 of
degree 49, and 68 pair roles. It meets the expected forms of (1) and (2), and
has price at least `128.941977...` by the checked root bounds. It does not
specify masks, event vectors, CROSS, a signed frame, or a legal word. Thus
there is no contradiction with the anchor-conditioned integer certificate,
and it must not be reported as a caller witness.

## Reproduce and provenance

```sh
python3 -I -B check.py
python3 -I -B independent_check.py
python3 -I -B verify_source_snapshots.py
python3 -I -B replay_upstream_q1.py
```

Both independent arithmetic checks need only Python 3's standard library.
The first writes [RESULT.json](RESULT.json); the independent per-position
checker and its scope review are in [AUDIT.md](AUDIT.md). The 199 dual
multipliers were originally **searched** with SciPy (`generate_duals.py` and `anchor_lp.py`); SciPy is not trusted or needed
for verification. Their saved floating values are explanatory metadata and
are never read as proof inputs. The exact checker independently rebuilds the
relevant inequalities and verifies the stored integer multipliers. The
baseline and split comparison were checked against the inert [#7883 proof](source/p7883/PROOF.md) and [result](source/p7883/RESULT.json).
The unchanged #7869 verifier and the predecessor's independent root wrapper
are included for replay. The wider modeled LP comparison uses #7869 at
[`06c207a9feb3994a4b987dc3010657b6e85b7956`](https://github.com/CrocSwap/integer-mult-bounds/commit/06c207a9feb3994a4b987dc3010657b6e85b7956),
notably `certs/q1_k76.json`, `notes/scherk.md` and `notes/schemacost.md`.
The #7869 modeled upper certificate is `129.007628111417802187...`, above the
bar. It is not a legal-caller witness, and its invoice requires care with
odd-idle correction.

The local source excerpts in [source/](source/) are identified by Git blob
SHA-1 in [SOURCE-MANIFEST.json](SOURCE-MANIFEST.json). The source checker
verifies those byte identities and checks the two cited prior ceiling values;
it does not re-prove the upstream results. The prior #7883 result JSON is an
inert replay snapshot, not an independent replay by this packet.
