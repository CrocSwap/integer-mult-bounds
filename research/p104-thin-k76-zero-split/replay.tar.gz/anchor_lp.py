import math,time,numpy as np
from scipy.optimize import linprog
p=lambda x:x**.99
v=lambda d:p(8*d+1)-p(8*d)
s=lambda d:v(2)-v(d)
def f(d):return d*(d-1)//2*(76-d)-74
def g(n,a):
 t,r=divmod(n,a);return (a-r)*t*(t-1)//2+r*t*(t+1)//2
def bounds(L):
 out=[]
 for m,alpha in enumerate((2,3,4,7)):
  q=L-m
  if q>0:
   N=max(n for n in range(77) if g(n,alpha)<=73-L)
   out.append((q,76-N))
 return out

def run(L,a):
 q=L-3; small=list(range(3,a+1)); large=list(range(a,77)); groups=([small] if q>1 else [])+[large]*3
 cols=[(j,d) for j,group in enumerate(groups) for d in group]; shift=1 if q>1 else 0
 c=np.array([s(d) for _,d in cols]); E=np.array([[int(j==idx) for j,d in cols] for idx in range(len(groups))]);eb=np.array(([q-1] if q>1 else [])+[1]*3)
 A=[];bb=[]
 for pfx,b in bounds(L):
  row=[]
  for j,d in cols:
   if q>1 and j==0: coeff=1
   else: coeff=int(pfx>=q+1+j-shift)
   row.append(-coeff*d)
  A.append(row);bb.append(-b+a)
 A.append([-f(d) for j,d in cols]);bb.append(-(70300-73*74)+f(a))
 res=linprog(c,A_ub=np.array(A),b_ub=np.array(bb),A_eq=E,b_eq=eb,bounds=(0,None),method='highs')
 return (res.fun+s(a),res) if res.success else (1e10,res)

BUD=.11002145795334264
for L in range(4,29):
 q=L-3; b=dict(bounds(L))[q]; lows=[]
 for a in range(3,77):
  if q*a<b:continue
  lb=(q-1)*s(3)+4*s(a)
  if lb>BUD:continue
  c,r=run(L,a);lows.append((c,a))
 print(L,'eligible',len(lows),'best',min(lows) if lows else None,'bad',[(round(c,8),a) for c,a in lows if c<=BUD],flush=True)
