# Independent audit of the k=76 zero-split screen

The certificate in this directory is **arithmetically
confirmed** by this independently written standard-library checker. It uses a
byte-pinned copy of that lane's proposed dual multipliers; it does not
independently generate them, prove the common-kernel lemma, or re-establish
legal-word or Lean hypotheses.

```sh
python3 -I -B independent_check.py
```

The checker enumerates forbidden signature triple **types** and counts rather
than the other checker's explicit sequences. It independently obtains
`A_0,A_1,A_2,A_3 = 2,3,4,7`; verifies the Turan prefix thresholds; computes
outward integer-root bounds for the price terms; and checks every proposed
nonnegative integer dual by a separate position-by-position weak-duality sum.
It finds 102 impossible anchors, 1549 elementary-price cases and 199 checked
dual cases. Its worst case for `L<29` is

`122446250356819987/950000000000000 = 128.8907898492841968...`.

For `L>=29`, monotonicity gives 29 times the degree-three loss and the overall
outward ceiling

`30611566615138613/237500000000000 = 128.8908068005836337... < 128.891`.

The lower-enclosed margin is about `0.0001931994163663`. This is not an
attained value. The companion `check.py` independently checks a five-long-role degree-only
fractional control that satisfies the tested prefix and triple rows while its modeled value exceeds
the bar; it is not a signed frame or a legal word. Consequently the
integer-anchor condition is material in this relaxation.

## Scope and sign review

Assume the same conditional frame as the split packet: `k=76`, `Q=T=1`,
two all-stage singleton-piece hubs, exactly 76 leaves and 73 non-hub
nonleaves, full-mask event pieces on all those nonleaves (zero split), a
single global event-to-role partition, signed `P=-I`, invertible host
blocks, and supported/biorthogonal event kernel vectors. Each triple then
has a non-hub mask meeting exactly two of its stages, by the earlier
common-kernel rank obstruction. If `L` non-hubs have degree at least three,
the other `73-L` yield at most that many distinct pair edges.

Remove the `q` smallest long-role masks. On the remaining stages an
independent set in the pair graph has all triples distinguished by the
remaining long-mask signatures. For `m=L-q` equal to 0, 1, 2 or 3, the
finite maxima above apply. Turan therefore forces the prefix lower bounds
used by the certificate. The aggregate triple count forces
`sum_i [binom(D_i,2)*(76-D_i)-74] >= 64898`; this includes no hub or leaf
contribution. If `a=D_(L-3)` for sorted long degrees, then its earlier
positions range over `[3,a]`, the anchor equals `a`, and the last three range
over `[a,76]`. These are relaxations of the actual sorted vector.

For each anchor, the independent check takes nonnegative multipliers for the
four necessary prefix rows and the aggregate triple row. It adds their
right-hand sides, then independently minimizes the reduced cost of each
position over its stated integer range. This is a lower bound on the sum of
true degree losses: the exponentials are first bounded **down** in those
losses and the baseline **up**. Multipliers have scale `10^18` and root
bounds have scale `10^14`; all operations and comparisons against
`128891/1000` are exact integer/rational arithmetic. Cases with impossible
prefix sum or already-sufficient monotone degree-three losses require no dual.
The copied `duals.json` has SHA-256
`180c2092144b2e08131fc72b753c67318e4b90d14026eca5229b04db5966636d`.

## The nonempty odd-idle correction

The zero-split number above bounds the actual type-B invoice only when its
odd-idle correction is zero. For an actual `CallerWord.Legal` word with a
single thin at its own event time and two singleton leaves at different
nondegenerate host stages, this follows from pinned #7852 source:

1. `CallerThin.leaf_zero` applied to a singleton leaf forces the unique
   thin column's `Bw` component on that role to be nonzero; the leaf's host
   `Bw` entries vanish outside its own host slot, and all other non-host
   odd columns are absent.
2. For an odd IDLE at event `j` on register `r`, `CallerWord.terms` gives
   `(r,r,-2)`, and `CallerWordD.idle_base` gives `P1(j+1)=P1(j)`. Hence its
   `Aw` equals `-2 * incV`, and its `Bw` equals `incW`, respectively.
   The two frame vectors need not be proportional to each other.
3. If the IDLE mask contains stage `t`, `CallerWordD.legal_masks` says its
   incidence vectors vanish on every role whose target mask misses `t`.
   Choose a leaf at the other stage. Its thin `Bw` component vanishes,
   contradicting step 1. Thus the odd IDLE mask is empty; a QUERY also has
   zero correction.

This correction argument does not require zero split or a global
role-partition, but it **does** require the legal word's SPEC evaluations,
the target-mask/host-support bridge, separate host and plain event slots,
and the frame nondegeneracy. The finite checker proves none of those
bridges. In particular, the abstract `EvData`/per-stage-matching model alone
is not enough to assert zero correction.

Subject to all these stated hypotheses, combining this zero-split ceiling
with the earlier `128.879425704223` corrected split-case ceiling covers the
specified two-hub template. It does not establish a bound for all k=76
callers or a kappa improvement.
