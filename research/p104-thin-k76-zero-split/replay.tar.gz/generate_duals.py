#!/usr/bin/env python3
"""Generate optional dual multipliers. The independent verifier needs only stdlib.

Generation uses SciPy floating-point only as a search heuristic. All published
claims are rechecked with exact integer arithmetic by check.py.
"""
from pathlib import Path
import json
exec(Path(__file__).with_name('anchor_lp.py').read_text().split('\nBUD=')[0])
BUD=.11002145795334264
M=10**18
rows=[]
for L in range(4,29):
 q=L-3; b=dict(bounds(L))[q]
 for a in range(3,77):
  if q*a<b or (q-1)*s(3)+4*s(a)>BUD: continue
  value,res=run(L,a)
  assert res.success and value>BUD,(L,a,value,res.message)
  mu=[max(0,round(-float(x)*M)) for x in res.ineqlin.marginals]
  assert len(mu)==5
  rows.append({'long_count':L,'anchor':a,'mu':mu,'numerical_loss':value})
Path(__file__).with_name('duals.json').write_text(json.dumps({'scale':M,'rows':rows},indent=2)+'\n')
print('wrote',len(rows),'dual rows')
