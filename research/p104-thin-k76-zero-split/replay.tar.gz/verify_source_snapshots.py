#!/usr/bin/env python3
"""Check inert selected source snapshots and cited prior-result identities.

This verifies only the recorded bytes and arithmetic comparison. It does not
establish source theorems, replay #7883, or prove the word/frame hypotheses.
"""
from fractions import Fraction
from hashlib import sha1,sha256
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
expected={
 'source/p7852/CallerSGram.lean':'6c03a7f3b3c50fe4340cd105378409ca39abc474',
 'source/p7852/CallerRC2.lean':'321ec331931fecddd844f3b12fe0caf27178269c',
 'source/p7852/CallerEv.lean':'ad5aba9f52bd1d4b60c3023a8325ff68310c5561',
 'source/p7852/SchemaCostB.lean':'b6a1c4b03a81a99e59c433d110871f605bef9694',
 'source/p7852/CallerThin.lean':'f85fc659414297e2444489f9982bf966d5fadb9f',
 'source/p7861/SHARED-HUB-PROOF.md':'14d37abc0ff73ca77935aea5c8906b57fea38d82',
 'source/p7852/CallerWord.lean':'4d8d2ab8e4a1338cb172b35dc45d8070c3c3270c',
 'source/p7852/CallerWordD.lean':'6d1b7ae061de0d0e93a8720f0c81b79a4dbf8347',
 'source/p7869/certs/q1_k76.json':'c80dd74e4be0ebeae7b305ce3727d4055e034360',
 'source/p7869/certs/verify_q1.py':'a3500cbbecc38af21f9f07b9bf3425a7e1071b58',
 'source/p7869/scherk.md':'ebdc416a0998b59c471b028392de66176ba99913',
 'source/p7869/schemacost.md':'701d42ebf7b305d64cccba38fd6bc8ca61c44363',
 'source/p7883/PROOF.md':'9b82c2a317841dd70dd0e02edac40776e0a56f93',
}
def blob(data):return sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def main():
 manifest=json.loads((HERE/'SOURCE-MANIFEST.json').read_text())
 assert len(manifest['sources'])==len(list((HERE/'source').rglob('*')))-sum(p.is_dir() for p in (HERE/'source').rglob('*'))
 for row in manifest['sources']:
  name=row['local_path'];data=(HERE/name).read_bytes()
  assert sha256(data).hexdigest()==row['sha256'],name
  assert blob(data)==row['git_blob_sha1'],name
  if name in expected:assert blob(data)==expected[name],name
 assert set(expected)<=set(r['local_path'] for r in manifest['sources'])
 result=json.loads((HERE/'source/p7883/RESULT.json').read_text())
 assert Fraction(result['combined_ceiling_exact'])==Fraction(24487090883802209,190000000000000)
 assert Fraction(result['combined_ceiling_exact'])<Fraction(30611566615138613,237500000000000)<Fraction(128891,1000)
 print('PASS',len(manifest['sources']),'source snapshot identities and conditional split/zero ceiling comparison')
 print('The #7883 result is a recorded replay snapshot; source and frame theorems are not proved here.')
if __name__=='__main__':main()
