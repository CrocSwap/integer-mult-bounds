# Validation receipt

A fresh relative-path copy of this directory was checked with Python 3 and
no optional packages:

```
python3 -I -B check.py
python3 -I -B independent_check.py
python3 -I -B verify_source_snapshots.py
python3 -I -B replay_upstream_q1.py
```

All four commands returned exit status 0. The generated `RESULT.json` was
byte-identical to the shipped result. The independently written checker
separately enumerated the forbidden signature triple types and reconstructed
the degree-loss weak-duality bound position by position. It used the same
byte-pinned proposed dual multipliers, not an independent dual search. The
results were:

* Signature independence caps: `(2,3,4,7)` for 0, 1, 2 and 3 long masks.
* Anchor cases: 102 ruled out by degree sums, 1,549 by elementary monotone
  price bounds, and 199 checked by exact nonnegative rational duals.
* Exact combined zero-split ceiling: `30611566615138613/237500000000000`.
* Exact predecessor #7883 split ceiling, checked as a pinned recorded result:
  `24487090883802209/190000000000000`.
* #7869 unchanged verifier plus predecessor root wrapper: modeled upper
  `49715125551675529173873011821938159/385365782469381738054997774434304`
  and 152 independent integer-root enclosure checks. The modeled upper is not
  a feasible-point or legal-caller witness.
* All 19 selected source snapshots matched the recorded byte hashes.

Three mutations in separate temporary copies were rejected: a negative dual
multiplier by `check.py`, a changed `CallerThin.lean` source by the snapshot
checker, and a changed `q1_k76.json` by the predecessor replay wrapper.

The checker certifies only finite inequalities and the supplied power bounds.
The signed-frame triple/common-kernel step, the mask-signature and Turán
reasoning, the `CallerWord.Legal` thin-column support application, and the
passage from those hypotheses to the actual invoice remain the paper
arguments and explicit qualifications in [README.md](README.md). They are not
re-proved by either checker and no new Lean replay is claimed. This packet
provides no legal caller construction or kappa improvement.
