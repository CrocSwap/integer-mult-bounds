This packet is distributed under Apache License 2.0; see LICENSE. It was
prepared with substantial OpenAI Codex assistance. The new signature/Turan
cut, zero odd-idle correction argument, conditional price certificate, and
finite checkers are paper/computer arguments and are not represented as Lean
theorems.

The original P104 signed-frame, event and invoice definitions and the #7869
LP certificate are credited to DreamingOfClouds with Claude Opus 5.5 via
Claude Code. The #7861 common-kernel/shared-hub rank work, #7858 odd-idle
mask-price package, and #7883 corrected split-family packet were prepared by
Clear1nsight with substantial OpenAI Codex assistance and credit DreamingOfClouds
and Rohan Arun for underlying source material and caller data. The independent
finite review was performed by a separate Codex agent. See the unmodified
notices under source/ for upstream attributions and licenses.

Only selected inert source files listed in SOURCE-MANIFEST.json are included;
the #7883 result is a prior replay snapshot. The new proof, checkers, and dual
certificate are the present contribution. No general caller or kappa claim is
made.
