#!/usr/bin/env python3
"""Check the k=76 zero-split price bound using only exact integer arithmetic.

The signed-frame/common-kernel, word-bridge, Turan and CROSS implications
are paper proofs in README.md, not established or Lean-checked by this file.
The dual multipliers were found numerically; no floating-point solver is used
in this checker and each weak-duality inequality is reconstructed independently.
"""
from collections import Counter
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction
from itertools import combinations, product
from math import comb
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
K=76
S=10**14
M=10**18
BAR=Fraction(128891,1000)
ALPHAS=(2,3,4,7)
F=comb(76,3)-73*74
roots={}

def root(b):
 if b not in roots:
  target=b**99*S**100
  lo,hi=0,(b+1)*S
  while lo+1<hi:
   mid=(lo+hi)//2
   if mid**100<=target:lo=mid
   else:hi=mid
  assert lo**100<=target<(lo+1)**100
  roots[b]=(lo,lo if lo**100==target else lo+1)
 return roots[b]

def lower(terms):
 return sum(c*root(b)[0 if c>0 else 1] for b,c in terms.items())
def upper(terms):
 return sum(c*root(b)[1 if c>0 else 0] for b,c in terms.items())
def loss_terms(d):
 t=Counter({17:1,16:-1})
 t[8*d+1]-=1
 t[8*d]+=1
 return t
def loss(d):return lower(loss_terms(d))
def f(d):return comb(d,2)*(76-d)-74
def graph_floor(n,a):
 t,r=divmod(n,a)
 return (a-r)*comb(t,2)+r*comb(t+1,2)
def bounds(L):
 out=[]
 for m,alpha in enumerate(ALPHAS):
  q=L-m
  if q>0:
   cap=max(n for n in range(77) if graph_floor(n,alpha)<=73-L)
   out.append((q,76-cap))
 return out

def distinguishes(tup,m):
 return any(sum((x>>i)&1 for x in tup)==2 for i in range(m))
def signature_max(m):
 best=0;winner=None;tested=0
 for count in product(range(3),repeat=1<<m):
  a=sum(count)
  if a<=best:continue
  tested+=1
  seq=[s for s,c in enumerate(count) for _ in range(c)]
  if all(distinguishes(t,m) for t in combinations(seq,3)):
   best=a;winner=seq
 return best,winner,tested

def dec_up(frac):
 with localcontext() as c:
  c.prec=60;c.rounding=ROUND_CEILING
  return str((Decimal(frac.numerator)/Decimal(frac.denominator)).quantize(Decimal('0.000000000001')))

def main():
 assert S==10**14 and M%S==0
 counts=[]
 for m,expected in enumerate(ALPHAS):
  got,winner,tested=signature_max(m)
  assert got==expected,(m,got,winner)
  counts.append({'bits':m,'max_independent_stages':got,'witness':winner,'count_vectors_enumerated':3**(1<<m)})
 # 4-stage control: no undifferentiated triple survives the pair diagonals,
 # yet both required CROSS edges vanish for X={0,2},Y={1,3}.
 diag={(0,2),(1,3)}
 assert all(any(set(e).issubset(t) for e in diag) for t in combinations(range(4),3))
 assert sum((u%2)!=(v%2) for u,v in diag)==0

 lo={d:loss(d) for d in range(3,77)}
 assert all(v>0 for v in lo.values())
 assert all(upper(loss_terms(d))<lo[d+1] for d in range(3,76))
 # Baseline: two full singleton-event hubs, 73 degree-two roles, 76 leaves,
 # and the Q=1 modeled thin charge, in unnormalized invoice units.
 base={609:2,17:73,9:76,8:-228,16:-73,1:-1}
 bu=upper(base)
 # Fractional degree-only control: each of five long slots uses 59/100
 # of degree 3 and 41/100 of degree 49; the other 68 roles are pairs.
 L=5; expected_degree=Fraction(59*3+41*49,100)
 assert all(q*expected_degree>=need for q,need in bounds(L))
 assert Fraction(5*(59*f(3)+41*f(49)),100)>=F
 fractional_loss=Fraction(5*(59*upper(loss_terms(3))+41*upper(loss_terms(49))),100*S)
 fractional_lower=Fraction(104,76)*(Fraction(lower(base),S)-fractional_loss)
 assert fractional_lower>BAR
 def real_upper(loss_scaled):return Fraction(104*(bu*(M//S)-loss_scaled),76*M)
 assert real_upper(29*lo[3]*(M//S))<BAR

 # L<=3 is impossible by an independence bound on the WHOLE pair graph.
 for L in range(4):assert graph_floor(76,ALPHAS[L])>73-L
 data=json.loads((HERE/'duals.json').read_text())
 assert data['scale']==M
 rows={(int(r['long_count']),int(r['anchor'])):r['mu'] for r in data['rows']}
 assert len(rows)==len(data['rows'])
 used=set(); evaluated=[]; impossible=cheap=certified=0
 for L in range(4,29):
  q=L-3
  bs=bounds(L)
  b=dict(bs)[q]
  for a in range(3,77):
   if q*a<b:
    impossible+=1;continue
   simple=((q-1)*lo[3]+4*lo[a])*(M//S)
   simple_upper=real_upper(simple)
   if simple_upper<BAR:
    cheap+=1;evaluated.append((simple_upper,L,a,'simple'))
    continue
   key=(L,a); assert key in rows,('missing dual',key)
   mu=rows[key]
   assert len(mu)==5 and all(isinstance(t,int) and t>=0 for t in mu)
   used.add(key); certified+=1
   prefix=mu[:4];lam=mu[4]
   assert len(bs)==4
   # First q−1 slots range over [3,a]; anchor slot is a; remaining
   # slots are separately relaxed over [a,76]. Prefix constraints and
   # f-capacity are charged by the nonnegative proposed multipliers.
   val=lo[a]*(M//S)+sum(u*(need-a) for u,(_,need) in zip(prefix,bs))+lam*(F-f(a))
   if q>1:
    small=min(lo[d]*(M//S)-sum(prefix)*d-lam*f(d) for d in range(3,a+1))
    val+=(q-1)*small
   for j in range(1,4):
    coefficient=sum(u for u,(end,_) in zip(prefix,bs) if q+j<=end)
    val+=min(lo[d]*(M//S)-coefficient*d-lam*f(d) for d in range(a,77))
   result=real_upper(val)
   assert result<BAR,('failed certificate',key,str(result),dec_up(result))
   evaluated.append((result,L,a,'dual'))
 assert used==set(rows),('unused or duplicate dual',set(rows)-used)
 worst=max(evaluated)
 largest=real_upper(29*lo[3]*(M//S))
 ceiling=max(worst[0],largest)
 assert ceiling<BAR
 report={
  'scope':'conditional two-hub zero-split k76 family and actual word thin support; paper linear algebra, no legal witness and no kappa claim',
  'signature_controls':counts,
  'fractional_degree_relaxation_control':{'L':5,'mixture_per_slot':{'3':'59/100','49':'41/100'},'pair_roles':68,'certified_value_lower_fraction':str(fractional_lower),'certified_value_above_bar':True,'meaning':'degree-only fractional relaxation, not a frame, event assignment, or legal word'},
  'triple_capacity_surplus_required':F,
  'baseline_upper_fraction':str(real_upper(0)),
  'baseline_upper_decimal':dec_up(real_upper(0)),
  'ceiling_fraction':str(ceiling),
  'ceiling_decimal':dec_up(ceiling),
  'worst_long_count':29 if largest>=worst[0] else worst[1],
  'worst_anchor':None if largest>=worst[0] else worst[2],
  'worst_proof':'29 times the minimum long-role loss' if largest>=worst[0] else 'anchor relaxation '+worst[3],
  'impossible_anchor_cases':impossible,'simple_cases':cheap,'dual_cases':certified,
  'large_long_count_minimum':29,
  'max_upper_at_29_long':dec_up(real_upper(29*lo[3]*(M//S))),
  'root_scale':S,'dual_scale':M,'root_certificate_count':len(roots),
  'local_cross_control':{'pair_edges':[[0,2],[1,3]],'triple_cut':'pass','interleaving_cross_required':2,'interleaving_cross_found':0}
 }
 (HERE/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))

if __name__=='__main__':main()
