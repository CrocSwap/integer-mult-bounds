# Separate whole paid fields across the 36 P104 binary calls

Exact pinned paired caller and native word, arbitrary original inputs, one old paid MOVE per selected distinct invocation. A fusion retains both original receipt observation points, a neutral identity-packet baseline and a single original-volume paid lane.

An explicit q+1 square-zero inverse gives independence of arbitrary selected complete fields. The required two-field defect outranks every one-lane neutral interchange, including the nominally funded (5,6) and (6,6) cases. Exact stage-18 external hub identities give a constructive decoder conditional on actual delivery; tested prior stock and one-field return models do not supply it. The separately cold-checked 36-slot calendar includes a changed donor that preserves an actual QUERY at clock 198. No single paid donor substitute preserving its own clocked value can add the missing final hub.

Build an independently funded stage-18 hub path, or change the protected blocked baseline or multiple paid slots and verify both complete operators.

The original #7830 word at head `87fbf4f7b35b0f18ab12b5767775a9a424cf0b15` is pinned in the surviving archive source files. The native gzip SHA-256 is `d28f0d28d9d87d5fe57b8ef19e12faf98014f0bbef781987ce22daaa82f21cb9`.

Run `sha256sum -c SHA256SUMS`. Extract each inner archive into its own directory and run the exact checks in its README. An independent clean extraction checked every hash and the isolated verify.py replay, with all native output endpoints, both whole-field algebra orientations, 81-site negative and doubled-volume positive controls, signed price pairs, and exact stage-18 stock checks. The companion independently recovered every old paid innovation and the positive changed QUERY donor while rejecting the final hub supply.
