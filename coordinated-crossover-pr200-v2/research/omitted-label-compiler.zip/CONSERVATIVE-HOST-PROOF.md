# Complete conservative hybrid host and paid bill

This is a sufficient concrete fallback implementation of the entire new hybrid scalar query layer. It deliberately reconstructs each query independently and gives no credit for an unproved old-P import, scalar carrier matching, clean scratch, or mismatched-frame read. It is far too expensive to reach the requested threshold and is retained as a correct architectural reference, not as an improved exponent.

## Physical construction

Freeze structural/unified-graph-fused.json. For every new side root, expand its positive, support-disjoint source expression into the literal source list in conservative-flat-host.json. Use one independent physical dirty role for each source term. Before either old or new source-pair mixing, copy the original source into that role at its rank-one source line. This keeps each original data control at the same line during every new capture. It then follows its unchanged partner path.

For a side root with cap F of rank d, move each captured role from its source line to F. Every literal source line lies in F, and the native checker verifies this membership, the exact dimension of F, and G-nondegeneracy. Sum all roles into the first role using ordinary scalar shears at that one fixed common frame F. Every other role retires at F. The carrier is read at F into the root's literal receiver group. All roles then complete their inherited full-rank tails. No incomparable frame is traversed.

For a cube root, d=20 and read before the restored old target word. For face roots, use the actual minimal compatible delivery partitions: 440 rank-21 groups and 3,520 singleton rank-23 deliveries, with their saved global insertion cuts. New bad targets first receive their common rank-22 roots and the new partner deliveries, then their individual rank-23 roots. New bad centre contributions are captured the same way and added at each retained centre's full-star rank-23 frame after old phase one; there are no later old touches of those roles.

Retain arbitrary scratch. Read the negative exact adjoint response of each new zero-gauge scratch field at the initial common zero frame. Then execute the captures and sum shears, the old word with the new deliveries at their proved cuts, and the literal inverse of every new shear/capture. The old and new data partner mixes are undone before reversing the captures. The linear identity -QLa+QL(a+Xx)=QLXx proves correctness for every initial dirty array. This uses the same physical common-frame gates as the inherited interface. It does not presume that a source array is spatially sparse.

The source lists define the literal program unambiguously: allocate the listed source-term roles in root-index order; capture their original controls at their source lines; move to the recorded root cap; add roles 2 through k into role 1; read role 1 into the listed targets; reverse in reverse order. For a centre, add the listed captured roles into the already retained centre. The exact fresh-source decoder was separately checked on all 2,024 source columns by the structural lane. No arbitrary dirty column is omitted from the algebraic adjoint identity.

## Complete local ledger

Each new role follows 0 -> source line (rank 1) -> root cap (rank d) -> full local rank 24. In three stages it contributes children of ranks 1, d-1, and 24-d, each with multiplicity three. The rank sum is 72 per role. The roots are ordinary zero-gauge roles, so no entrance-bank saving is invented.

Native counted role stock:

- 11,880 bad-to-good cube source captures;
- 43,560 bad-to-good face source captures;
- 792 new centre-source captures;
- 52,536 new bad common-root source captures;
- 60,720 new bad singleton-root source captures.

Total new roles: 169,488. All 319,704 literal source/covector memberships pass, and every declared root cap has its exact rank and is nondegenerate.

Restore the 34 original zero-gauge terminal roles: W increases by 34, and three rank-21 plus three rank-3 children are added per restored role. Prepending the cube rank-20 read splits the 880 original initial rank-21 target movements into rank 20 plus rank 1. Face insertions add zero target entropy. The 24 centre endpoints split their old rank-2 tails into two rank-1 transitions, while their copied-centre charge increases from 22 to 23. Add the 528 new data fields, the actual 132 carrier/passive source-pair chains, the 264 new target chains 0 -> 22 -> 23, and the inherited rank-2 data-diagonal children.

Starting from the checked 302-frame entrance-bank profile, the native final exact bill is:

- m=72;
- W=566552/3;
- total child rank=13,594,856;
- deficit mW-rank=2,392;
- maximum child=23.

The child histogram is saved verbatim in conservative-flat-host-summary.json. Its floating entropy diagnostic is about 21,234,221.07; the resulting linear-entropy upper bound on coarse saving is about 0.00011264835, already far below 0.0007. This last comparison is a diagnostic until replayed by the exact rational moment engine. It is not an asserted new κ certificate.

## Explicit falsifier for the tempting free block-read shortcut

A rank-one Fourier-frame operator is an invertible operator on the entire physical array. Rank one counts Fourier factors; it does not mean a rank-one linear map or a spatially supported line. Arbitrary input blocks remain arbitrary after this operator. Therefore a slice-and-broadcast map cannot replace a mismatched F/T frame transition merely because each formal source label lies in F. Such a replacement needs a separate proved promise on the actual encoded arrays. The inherited arbitrary-array interface supplies no such promise. The public Clifford-frame note explicitly requires the same exact representative on both incident registers at a scalar gate. Equal preimages allow rank-zero adapters, but proper F subset T is not an equal-preimage case.

## Research consequence

This concrete bill excludes the naive flatten-and-reconstruct architecture as a route to the requested threshold. It does not exclude the hybrid family. Real reuse now requires the structural lane's actual contracted old-P creation frames, paid copies and a correct expanded dirty-response strategy, or a stronger physical architecture. All finite witnesses and positive local sufficient lemmas are preserved.