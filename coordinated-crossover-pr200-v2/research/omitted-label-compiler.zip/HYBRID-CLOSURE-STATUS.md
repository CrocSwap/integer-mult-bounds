# Hybrid closure status — 2026-10-09

The 264-label hybrid extension is not an improved κ certificate. The best admitted package being prepared by the lead remains κ=0.000683741579363015. The requested 0.0007 threshold has not been reached. This lane has preserved complete sufficient fallback constructions and exact finite witnesses, rather than declaring the hybrid closed from fresh scalar identities alone.

## Positive mathematical and finite results

1. All 220 old good-cube common caps have exact rank 20. Before terminal elimination, each is contained in all eight receivers' first inherited frames: 1,760 exact checks pass. The actual redirected terminal word has exactly 34 incompatible pivots. Restoring those 34 independent zero-gauge terminal roles is a concrete sufficient paid repair: delta W=34, delta children=102 at rank 21 plus 102 at rank 3, delta deficit=0.
2. Exact minimal face delivery partitions preserve the old target chronology. Of 1,320 coordinate faces, 440 use one rank-21 root; 880 require four singleton rank-23 roots. Total 3,960 delivery roles. Every chosen read is at an existing target frame, so it adds zero target entropy. Cube insertion additionally splits 880 initial rank-21 movements into rank 20 plus rank 1; that cost is included in the final bill.
3. Every old retained centre has no touches after phase one. The lead checked all 24 old rank-22 centre spaces inside their full rank-23 star spaces. Thus augmentation at rank 23 before the centre read preserves a literal usable role history. It requires actual new bad-source captures; no fresh centre-sum oracle is assumed.
4. The structural lane proved and saved the 132 new source partners, their positive residual decomposition and all 69,696 bad/bad decoder entries. All new data controls must be captured before their partner mixes; partner delivery is at the common rank-22 receiver cap before individual rank-23 reads.
5. The 59-row scalar co-tree had 133 actual minimal-frame nesting failures. A literal ordered-chain-cover repair has 139 physical roles, 233 shears and zero frame nesting failures. It passes all 11 source and 139 dirty columns over the integers, 8,250 output entries and 20,850 inverse-restoration entries. This is a universal sufficient framed local construction for independent U/V family vectors. A paired U instantiation must still form its two-control leaves, conservatively paying 11 additional capture roles per module.
6. The structural lane contracted all 240 distinct old-P creation events corresponding to 264 desired bindings. It changed 2,094 actual frames, passed all fixed-boundary inclusions and fresh containment tests, and preserved rank mass. Its local entropy cost is +2,713.612175 (multiply by three for the three stages). All 1,222 distinct contracted frames also passed basis-rank and Gram determinant admission for every prime above 2^80. These are real repaired copies, not free reuse of the formerly invalid padded rows.

## Complete conservative fallback bill

The fully explicit flat host captures each source term of every new positive root into a distinct dirty role at its source line, expands that role to the root's actual common cap, sums using the first role as carrier, reads at the proved target cut, and reverses. It reconstructs the new good-to-bad queries from actual source controls and makes no unadmitted old-P import. Every role trajectory is 0 -> line1 -> cap_d -> full24. The initial negative exact adjoint read at frame zero cancels all arbitrary initial scratch. Original data controls remain at their source lines during all captures and then follow their admitted partner chains.

The final native computation starts from admitted-cut/new-profile.json and checks all 319,704 source/covector memberships, every exact root-cap rank and rational nondegeneracy, and the complete telescoping bill:

- 169,488 new capture roles: 11,880 cube, 43,560 face, 792 centre, 52,536 new-bad common, 60,720 new-bad singleton;
- m=72 and W=566552/3;
- child rank=13,594,856;
- deficit=2,392;
- largest child=23.

It includes the 34 restored old terminals, the 880 target-first splits, the 24 rank-23 centre extensions, 528 new data fields, all 132 new source-pair chains, all new target chains, and the inherited data-diagonal children. The exact histogram and literal root/source/control lists are in conservative-flat-host-final.json. The short receipt is conservative-flat-host-final-summary.json. The floating entropy diagnostic is 21,231,936.521068577, giving a linear-entropy upper-bound diagnostic of 0.00011266047247. This conservative architecture is therefore vastly below the requested threshold; no improved κ is claimed from it. The exact rational moment engine can independently replay its histogram if desired.

## The repaired old-P reuse still needs a noise-safe host

A copied old-P row contains arbitrary old scratch noise as well as P(X). Its actual fresh support and repaired cap are now sufficient for the physical copy. They do not prove that reading the copy adds only P(X).

Extending the old global adjoint response into new bad targets extends the old selected-gauge compensation reads as well. The enlarged new-target sequence must be proved nested at the actual sigma frames and within the correct caps. Individual sigma-to-cap containment does not establish that chronological chain. Subtracting the complete current P row at a deferred birth would cancel P(X) too and is not a repair.

One sufficient concrete alternative is to pre-capture relevant initial old dirty fields at their original entry frames into zero-gauge helper roles, before the old word runs. Carry those helpers into each new root cap and subtract the exact Q L_old noise response while retaining the fresh P(X) from the repaired creation copy. Their captures, forward normalizers, initial-helper compensation and root uses must be paid. A shared replica of the required dirty-only ancestor circuit is another concrete option, with its own stock and field-copy costs. Neither helper implementation nor the enlarged selected-gauge chronology is complete in this checkpoint. Therefore the contracted P import is not yet a closed optimized hybrid supplier.

## Rejected shortcut, with precise scope

The inherited source-frame operator of Fourier rank one is invertible on an arbitrary whole array. Fourier rank one is not rank one as a linear map, and not a promise that the physical source array is supported on a line. A slice-and-broadcast replacement of a proper F/T transition needs an additional proved promise on actual encoded arrays. The current arbitrary-array interface gives no such promise. The frozen exact Clifford note requires one identical representative on incident registers at a scalar gate; equal preimages permit rank-zero adapters, but F properly contained in T does not.

## Minimal portable research appendix files

Core sufficient host: CONSERVATIVE-HOST-PROOF.md; conservative-flat-host.cpp; conservative-flat-host-final-summary.json; conservative-flat-host-final.json. External frozen inputs: structural/unified-graph-fused.json and admitted-cut/new-profile.json. Supply json.hpp from the already downloaded nlohmann header. Build with C++20 g++; the exact rational helper uses checked int128 and throws on overflow.

Carrier theorem and witness: cotree-chain-compiler.cpp; cotree-chain-program.witness.txt; cotree-chain-formal.cpp; cotree-chain-formal.json; cotree-chain-compiler.json. Optional ledgers: cotree-chain-ledger.cpp; cotree-u-ledger.json; cotree-v-ledger.json.

Actual target schedule: target-face-partitions.cpp; target-face-partitions.json; target-cube-full-chronology.cpp; target-cube-full-chronology.json; target-cube-cut.cpp; target-cube-cut.json. Centre audit: centre-touch-audit.cpp; centre-touch-audit.json.

Cross-lane sufficient witnesses: structural/bad-partner-pairs.witness.txt; structural/bad-partners-residual.cpp; structural/old-p-contracted-bases.json; structural/old-p-contraction.json; structural/old-p-prime-admission.json. Preserve their frozen source graphs and current-frame inputs in the research archive. Do not ship executable binaries, abandoned intermediate receipts, or claim that this appendix constitutes a full optimized hybrid certification.

All owned computations are C++. No Lean formalization or publication was performed. All finite witnesses remain on disk. No owned computation is running at this checkpoint; unrelated persistent services were not stopped.