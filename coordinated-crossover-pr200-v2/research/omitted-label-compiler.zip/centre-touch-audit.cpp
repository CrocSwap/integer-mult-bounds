#include "json.hpp"
#include <fstream>
#include <iostream>
#include <set>
#include <map>
using nlohmann::json;json load(const std::string&p){std::ifstream f(p);json j;f>>j;return j;}
int main(int argc,char**argv){std::string D=argv[1];json w=load(D+"/word_p12.json"),g=load(D+"/graph_p12.json"),out;std::set<int>phase;for(auto x:w["phase1"])phase.insert(x.get<int>());int centres=0,late=0;for(int j=0;j<(int)g["roots"].size();j++)if(g["roots"][j]["kind"]=="center"){int s=w["rootroles"][j],n=0;std::vector<int>lateops;for(int i=0;i<(int)w["ops"].size();i++)if(w["ops"][i][0]==s||w["ops"][i][1]==s){n++;if(!phase.count(i)){late++;lateops.push_back(i);}}out["centres"].push_back({{"root",j},{"role",s},{"total_touches",n},{"touches_after_phase1",lateops}});centres++;}out["centre_count"]=centres;out["after_phase1_touch_count"]=late;out["safe_augment_after_phase1_without_later_old_touches"]=late==0;std::cout<<out.dump(2)<<"\n";}