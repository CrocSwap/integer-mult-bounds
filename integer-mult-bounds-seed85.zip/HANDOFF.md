# Handoff: exact modular rank fast path

**Ready local contribution — tooling improvement, no new kappa.**

The historical joint-frame certificate takes 12.8% less median wall time
in seven same-input, alternating fresh-process pairs: 1.952577 -> 1.701918
seconds. All fourteen full certificates are byte-identical. One pair was
slower; timings are specific to the recorded environment.

- Repository: https://github.com/CrocSwap/integer-mult-bounds
- Exact base: `66849e1475c930fd7732b1a0067ffee7e1e95f60`
- Contribution commit: `ff900e04b51bfed3e751735ffe963ea710441b20`
- Branch: `tooling/seed85-exact-rank-screen`
- Assignment: OS-random seed **85**, verification engineering.
- Patch SHA-256: `b13b0e9c796dc8416196eb3b34b27912063af18fc08521b9c8b210a7d30e8136`
- Contribution tree: `9b84c56f027d9adbe50a60f928dcb244182c03ee`

## Apply and reproduce

Apply `integer-mult-bounds-seed85.patch` to a checkout at the exact base
with `git am /absolute/path/integer-mult-bounds-seed85.patch`, or use
`git apply` for an uncommitted review. Then run:

```sh
python3 -I -B research/joint-frame-modular-screen/verify.py --pairs 7 --output /tmp/joint-frame-rank-result.json
```

Use Python 3.11+ and a fresh result path. No third-party dependencies.
Expected final marker: **PASS_JOINT_FRAME_MODULAR_SCREEN**. Linux and macOS
are supported by the benchmark's POSIX CPU-time measurement.

## Review map

Only `research/joint-frame-modular-screen/` is added. The implementation
certifies full rank modulo 101; rank-deficient reductions and exceptional
denominators always use the unchanged exact rational fallback.

- `kernel.py`: 69-line exact fast path.
- `PROOF.md`: general algebraic equivalence on exact rectangular matrices.
- `replay.py`: source admission and unchanged historical certificate/tests.
- `test_kernel.py`: 12 test groups, independent minor oracle, four bad kernels.
- `SOURCE.json`: exact SHA-256 and Git-blob pins for 36 predecessor inputs.
- `EXPECTED.json`: unchanged historical certificate.
- `RESULT.json`: all raw A/B samples, environment and implementation hashes.
- `CLAIM.json`: three candidates, scope, local claim/result and overlap review.
- `NOTICE.md`: predecessor credit and substantial OpenAI Codex disclosure.

The ZIP includes a readable copy of this package in addition to the patch.
The patch is authoritative for applying it to the repository.

## Verification completed

- All 2,644 actual uncached rank calls compared individually with the
  original; 752 modular certificates and 1,892 exact fallbacks.
- 530 binary matrices checked with an independent determinant/minor oracle;
  240 seed-85 rational matrices, rectangular and singular cases, exact
  denominator exceptions, input preservation and source-drift controls.
- Four incorrect algorithms produce detected numerical counterexamples.
- All eight unchanged historical tests pass with each engine.
- Disabled inherited assertions are rejected; all 14 timed full certificates match.
- `make selected-record-check` and staged whitespace checks pass.
- The delivered patch applies to a fresh worktree at the exact base;
  that worktree reproduces the certificate and all 2,644 rank comparisons.
  Its resulting Git tree exactly matches the contribution tree above.
- The contribution branch is clean. All pre-existing files, including
  `upstream/`, are byte-identical to the base. A final fetch still returned
  the same main commit.

## Scope and remaining work

This is an opt-in historical checker acceleration. It does not activate
new defaults, reopen the closed fixed-boundary search, change the selected
#626/#543 conditional saving, or prove the full multiplication theorem.
All inherited compiler/realization/hosting/residual/precision/tape/analytic
obligations remain. Full `make verify`, selected cold reconstruction,
Lean and hosted CI were not run or claimed for this package.

GitHub's public API was available, but there was no write connection and
the user declined the GitHub plugin. **No PR or issue comment was posted.**
No pinned sprint issue was found; the claim and result are local. The last
full PR refresh inspected 582 open PRs through #763 at
2026-10-13T05:15:10.714617Z, with no task matching this historical audit.
PR367's integer frame algebra, PR700's PR468 modular audit, and the newer
PR752/756 tooling concern different methods or workloads and are credited.

Prepared at Martin Rivera's request with substantial OpenAI Codex assistance.
Apache-2.0. No independent human review is asserted.
